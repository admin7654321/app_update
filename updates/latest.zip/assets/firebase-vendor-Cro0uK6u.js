const Xa=()=>{};var As={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ur={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x2e6188,_0x23bb55){if(!_0x2e6188)throw ot(_0x23bb55);},ot=function(_0x449dcb){return new Error('Firebase\x20Database\x20('+Ur['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x449dcb);},Wr=function(_0x3eafd4){const _0x5c42ba=[];let _0x5d79be=0x0;for(let _0x5d16c0=0x0;_0x5d16c0<_0x3eafd4['length'];_0x5d16c0++){let _0x112f7c=_0x3eafd4['charCodeAt'](_0x5d16c0);_0x112f7c<0x80?_0x5c42ba[_0x5d79be++]=_0x112f7c:_0x112f7c<0x800?(_0x5c42ba[_0x5d79be++]=_0x112f7c>>0x6|0xc0,_0x5c42ba[_0x5d79be++]=_0x112f7c&0x3f|0x80):(_0x112f7c&0xfc00)===0xd800&&_0x5d16c0+0x1<_0x3eafd4['length']&&(_0x3eafd4['charCodeAt'](_0x5d16c0+0x1)&0xfc00)===0xdc00?(_0x112f7c=0x10000+((_0x112f7c&0x3ff)<<0xa)+(_0x3eafd4['charCodeAt'](++_0x5d16c0)&0x3ff),_0x5c42ba[_0x5d79be++]=_0x112f7c>>0x12|0xf0,_0x5c42ba[_0x5d79be++]=_0x112f7c>>0xc&0x3f|0x80,_0x5c42ba[_0x5d79be++]=_0x112f7c>>0x6&0x3f|0x80,_0x5c42ba[_0x5d79be++]=_0x112f7c&0x3f|0x80):(_0x5c42ba[_0x5d79be++]=_0x112f7c>>0xc|0xe0,_0x5c42ba[_0x5d79be++]=_0x112f7c>>0x6&0x3f|0x80,_0x5c42ba[_0x5d79be++]=_0x112f7c&0x3f|0x80);}return _0x5c42ba;},Za=function(_0x164ddd){const _0x1af562=[];let _0x5adc77=0x0,_0x2124a9=0x0;for(;_0x5adc77<_0x164ddd['length'];){const _0xc73ce9=_0x164ddd[_0x5adc77++];if(_0xc73ce9<0x80)_0x1af562[_0x2124a9++]=String['fromCharCode'](_0xc73ce9);else{if(_0xc73ce9>0xbf&&_0xc73ce9<0xe0){const _0x16aa82=_0x164ddd[_0x5adc77++];_0x1af562[_0x2124a9++]=String['fromCharCode']((_0xc73ce9&0x1f)<<0x6|_0x16aa82&0x3f);}else{if(_0xc73ce9>0xef&&_0xc73ce9<0x16d){const _0x4745f4=_0x164ddd[_0x5adc77++],_0x237541=_0x164ddd[_0x5adc77++],_0x34b6fe=_0x164ddd[_0x5adc77++],_0xea1da0=((_0xc73ce9&0x7)<<0x12|(_0x4745f4&0x3f)<<0xc|(_0x237541&0x3f)<<0x6|_0x34b6fe&0x3f)-0x10000;_0x1af562[_0x2124a9++]=String['fromCharCode'](0xd800+(_0xea1da0>>0xa)),_0x1af562[_0x2124a9++]=String['fromCharCode'](0xdc00+(_0xea1da0&0x3ff));}else{const _0x4759b0=_0x164ddd[_0x5adc77++],_0x5e278f=_0x164ddd[_0x5adc77++];_0x1af562[_0x2124a9++]=String['fromCharCode']((_0xc73ce9&0xf)<<0xc|(_0x4759b0&0x3f)<<0x6|_0x5e278f&0x3f);}}}}return _0x1af562['join']('');},Di={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x567151,_0x2436a9){if(!Array['isArray'](_0x567151))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x4f1e7f=_0x2436a9?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x4946fb=[];for(let _0x4a5e57=0x0;_0x4a5e57<_0x567151['length'];_0x4a5e57+=0x3){const _0x3e669b=_0x567151[_0x4a5e57],_0x585baf=_0x4a5e57+0x1<_0x567151['length'],_0x56e365=_0x585baf?_0x567151[_0x4a5e57+0x1]:0x0,_0x2c9679=_0x4a5e57+0x2<_0x567151['length'],_0x2cd1cb=_0x2c9679?_0x567151[_0x4a5e57+0x2]:0x0,_0x4491c5=_0x3e669b>>0x2,_0x1022a7=(_0x3e669b&0x3)<<0x4|_0x56e365>>0x4;let _0x2fa10b=(_0x56e365&0xf)<<0x2|_0x2cd1cb>>0x6,_0x3c37dc=_0x2cd1cb&0x3f;_0x2c9679||(_0x3c37dc=0x40,_0x585baf||(_0x2fa10b=0x40)),_0x4946fb['push'](_0x4f1e7f[_0x4491c5],_0x4f1e7f[_0x1022a7],_0x4f1e7f[_0x2fa10b],_0x4f1e7f[_0x3c37dc]);}return _0x4946fb['join']('');},'encodeString'(_0x22f144,_0x4d1775){return this['HAS_NATIVE_SUPPORT']&&!_0x4d1775?btoa(_0x22f144):this['encodeByteArray'](Wr(_0x22f144),_0x4d1775);},'decodeString'(_0x5ad801,_0x281108){return this['HAS_NATIVE_SUPPORT']&&!_0x281108?atob(_0x5ad801):Za(this['decodeStringToByteArray'](_0x5ad801,_0x281108));},'decodeStringToByteArray'(_0xae1b53,_0x50693f){this['init_']();const _0x521aaa=_0x50693f?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x2ec85b=[];for(let _0x3499a0=0x0;_0x3499a0<_0xae1b53['length'];){const _0x483346=_0x521aaa[_0xae1b53['charAt'](_0x3499a0++)],_0x5883d1=_0x3499a0<_0xae1b53['length']?_0x521aaa[_0xae1b53['charAt'](_0x3499a0)]:0x0;++_0x3499a0;const _0x366a80=_0x3499a0<_0xae1b53['length']?_0x521aaa[_0xae1b53['charAt'](_0x3499a0)]:0x40;++_0x3499a0;const _0x3e22bf=_0x3499a0<_0xae1b53['length']?_0x521aaa[_0xae1b53['charAt'](_0x3499a0)]:0x40;if(++_0x3499a0,_0x483346==null||_0x5883d1==null||_0x366a80==null||_0x3e22bf==null)throw new ec();const _0x52ed6f=_0x483346<<0x2|_0x5883d1>>0x4;if(_0x2ec85b['push'](_0x52ed6f),_0x366a80!==0x40){const _0xe03cc8=_0x5883d1<<0x4&0xf0|_0x366a80>>0x2;if(_0x2ec85b['push'](_0xe03cc8),_0x3e22bf!==0x40){const _0x135b31=_0x366a80<<0x6&0xc0|_0x3e22bf;_0x2ec85b['push'](_0x135b31);}}}return _0x2ec85b;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x389fa9=0x0;_0x389fa9<this['ENCODED_VALS']['length'];_0x389fa9++)this['byteToCharMap_'][_0x389fa9]=this['ENCODED_VALS']['charAt'](_0x389fa9),this['charToByteMap_'][this['byteToCharMap_'][_0x389fa9]]=_0x389fa9,this['byteToCharMapWebSafe_'][_0x389fa9]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x389fa9),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x389fa9]]=_0x389fa9,_0x389fa9>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x389fa9)]=_0x389fa9,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x389fa9)]=_0x389fa9);}}};class ec extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Br=function(_0xa7b866){const _0x5e2de2=Wr(_0xa7b866);return Di['encodeByteArray'](_0x5e2de2,!0x0);},an=function(_0x230095){return Br(_0x230095)['replace'](/\./g,'');},cn=function(_0x40afd3){try{return Di['decodeString'](_0x40afd3,!0x0);}catch(_0x442690){console['error']('base64Decode\x20failed:\x20',_0x442690);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tc(_0x558c4b){return Vr(void 0x0,_0x558c4b);}function Vr(_0x4402dd,_0x29decc){if(!(_0x29decc instanceof Object))return _0x29decc;switch(_0x29decc['constructor']){case Date:const _0x578314=_0x29decc;return new Date(_0x578314['getTime']());case Object:_0x4402dd===void 0x0&&(_0x4402dd={});break;case Array:_0x4402dd=[];break;default:return _0x29decc;}for(const _0x854158 in _0x29decc)!_0x29decc['hasOwnProperty'](_0x854158)||!nc(_0x854158)||(_0x4402dd[_0x854158]=Vr(_0x4402dd[_0x854158],_0x29decc[_0x854158]));return _0x4402dd;}function nc(_0x4580f9){return _0x4580f9!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ic(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sc=()=>ic()['__FIREBASE_DEFAULTS__'],rc=()=>{if(typeof process>'u'||typeof As>'u')return;const _0x45da96=As['__FIREBASE_DEFAULTS__'];if(_0x45da96)return JSON['parse'](_0x45da96);},oc=()=>{if(typeof document>'u')return;let _0x16aab7;try{_0x16aab7=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x7c1713=_0x16aab7&&cn(_0x16aab7[0x1]);return _0x7c1713&&JSON['parse'](_0x7c1713);},Mi=()=>{try{return Xa()||sc()||rc()||oc();}catch(_0x30ec46){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x30ec46);return;}},Hr=_0x3595f0=>{var _0x49f7fb,_0x3ec9af;return(_0x3ec9af=(_0x49f7fb=Mi())==null?void 0x0:_0x49f7fb['emulatorHosts'])==null?void 0x0:_0x3ec9af[_0x3595f0];},ac=_0x2835cc=>{const _0x4ba716=Hr(_0x2835cc);if(!_0x4ba716)return;const _0x352d93=_0x4ba716['lastIndexOf'](':');if(_0x352d93<=0x0||_0x352d93+0x1===_0x4ba716['length'])throw new Error('Invalid\x20host\x20'+_0x4ba716+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x323f0e=parseInt(_0x4ba716['substring'](_0x352d93+0x1),0xa);return _0x4ba716[0x0]==='['?[_0x4ba716['substring'](0x1,_0x352d93-0x1),_0x323f0e]:[_0x4ba716['substring'](0x0,_0x352d93),_0x323f0e];},$r=()=>{var _0x466fd0;return(_0x466fd0=Mi())==null?void 0x0:_0x466fd0['config'];},Gr=_0x16e03a=>{var _0x105488;return(_0x105488=Mi())==null?void 0x0:_0x105488['_'+_0x16e03a];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x41ccd5,_0x23f4fd)=>{this['resolve']=_0x41ccd5,this['reject']=_0x23f4fd;});}['wrapCallback'](_0x427ad6){return(_0x5a0eb0,_0x23e251)=>{_0x5a0eb0?this['reject'](_0x5a0eb0):this['resolve'](_0x23e251),typeof _0x427ad6=='function'&&(this['promise']['catch'](()=>{}),_0x427ad6['length']===0x1?_0x427ad6(_0x5a0eb0):_0x427ad6(_0x5a0eb0,_0x23e251));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cc(_0x105178,_0x446ffe){if(_0x105178['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0xae5119={'alg':'none','type':'JWT'},_0x249e6d=_0x446ffe||'demo-project',_0x13379e=_0x105178['iat']||0x0,_0x5d5c52=_0x105178['sub']||_0x105178['user_id'];if(!_0x5d5c52)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x583251={'iss':'https://securetoken.google.com/'+_0x249e6d,'aud':_0x249e6d,'iat':_0x13379e,'exp':_0x13379e+0xe10,'auth_time':_0x13379e,'sub':_0x5d5c52,'user_id':_0x5d5c52,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x105178};return[an(JSON['stringify'](_0xae5119)),an(JSON['stringify'](_0x583251)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Li(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function lc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function hc(){const _0x2d64f4=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x2d64f4=='object'&&_0x2d64f4['id']!==void 0x0;}function qr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function uc(){const _0x36e73f=W();return _0x36e73f['indexOf']('MSIE\x20')>=0x0||_0x36e73f['indexOf']('Trident/')>=0x0;}function dc(){return Ur['NODE_ADMIN']===!0x0;}function fc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function pc(){return new Promise((_0x543de5,_0x581556)=>{try{let _0x23bd87=!0x0;const _0x1ead3a='validate-browser-context-for-indexeddb-analytics-module',_0x14c750=self['indexedDB']['open'](_0x1ead3a);_0x14c750['onsuccess']=()=>{_0x14c750['result']['close'](),_0x23bd87||self['indexedDB']['deleteDatabase'](_0x1ead3a),_0x543de5(!0x0);},_0x14c750['onupgradeneeded']=()=>{_0x23bd87=!0x1;},_0x14c750['onerror']=()=>{var _0xe7a228;_0x581556(((_0xe7a228=_0x14c750['error'])==null?void 0x0:_0xe7a228['message'])||'');};}catch(_0x28f6c8){_0x581556(_0x28f6c8);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _c='FirebaseError';class Se extends Error{constructor(_0x3bbe6b,_0xa4f9e2,_0x3ed9b8){super(_0xa4f9e2),this['code']=_0x3bbe6b,this['customData']=_0x3ed9b8,this['name']=_c,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Ut['prototype']['create']);}}class Ut{constructor(_0xc75d66,_0x1b7fc8,_0x1fbeb3){this['service']=_0xc75d66,this['serviceName']=_0x1b7fc8,this['errors']=_0x1fbeb3;}['create'](_0x1d5443,..._0x292cc0){const _0x5ac0fd=_0x292cc0[0x0]||{},_0x54cc03=this['service']+'/'+_0x1d5443,_0x447a75=this['errors'][_0x1d5443],_0x5f0f09=_0x447a75?gc(_0x447a75,_0x5ac0fd):'Error',_0x45a381=this['serviceName']+':\x20'+_0x5f0f09+'\x20('+_0x54cc03+').';return new Se(_0x54cc03,_0x45a381,_0x5ac0fd);}}function gc(_0x39409a,_0x1e742d){return _0x39409a['replace'](mc,(_0x38a803,_0x510fab)=>{const _0x234adf=_0x1e742d[_0x510fab];return _0x234adf!=null?String(_0x234adf):'<'+_0x510fab+'?>';});}const mc=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bt(_0x459fa1){return JSON['parse'](_0x459fa1);}function O(_0x224774){return JSON['stringify'](_0x224774);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zr=function(_0x55d6eb){let _0x5247b5={},_0x20e8f4={},_0x5ca6a7={},_0x2ddace='';try{const _0x11a8b7=_0x55d6eb['split']('.');_0x5247b5=bt(cn(_0x11a8b7[0x0])||''),_0x20e8f4=bt(cn(_0x11a8b7[0x1])||''),_0x2ddace=_0x11a8b7[0x2],_0x5ca6a7=_0x20e8f4['d']||{},delete _0x20e8f4['d'];}catch{}return{'header':_0x5247b5,'claims':_0x20e8f4,'data':_0x5ca6a7,'signature':_0x2ddace};},yc=function(_0x19a329){const _0x331146=zr(_0x19a329),_0x186bb2=_0x331146['claims'];return!!_0x186bb2&&typeof _0x186bb2=='object'&&_0x186bb2['hasOwnProperty']('iat');},vc=function(_0x251fdc){const _0x54c171=zr(_0x251fdc)['claims'];return typeof _0x54c171=='object'&&_0x54c171['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x4691cf,_0x24f250){return Object['prototype']['hasOwnProperty']['call'](_0x4691cf,_0x24f250);}function Oe(_0x33e973,_0x885fb8){if(Object['prototype']['hasOwnProperty']['call'](_0x33e973,_0x885fb8))return _0x33e973[_0x885fb8];}function hi(_0xefcd6e){for(const _0x3c5c02 in _0xefcd6e)if(Object['prototype']['hasOwnProperty']['call'](_0xefcd6e,_0x3c5c02))return!0x1;return!0x0;}function ln(_0x5140d1,_0x546630,_0x2773c4){const _0xc94b57={};for(const _0x126d66 in _0x5140d1)Object['prototype']['hasOwnProperty']['call'](_0x5140d1,_0x126d66)&&(_0xc94b57[_0x126d66]=_0x546630['call'](_0x2773c4,_0x5140d1[_0x126d66],_0x126d66,_0x5140d1));return _0xc94b57;}function De(_0xef7dea,_0x551b08){if(_0xef7dea===_0x551b08)return!0x0;const _0x48d501=Object['keys'](_0xef7dea),_0x773e1e=Object['keys'](_0x551b08);for(const _0x552032 of _0x48d501){if(!_0x773e1e['includes'](_0x552032))return!0x1;const _0x4a551d=_0xef7dea[_0x552032],_0x24da5e=_0x551b08[_0x552032];if(ks(_0x4a551d)&&ks(_0x24da5e)){if(!De(_0x4a551d,_0x24da5e))return!0x1;}else{if(_0x4a551d!==_0x24da5e)return!0x1;}}for(const _0x266545 of _0x773e1e)if(!_0x48d501['includes'](_0x266545))return!0x1;return!0x0;}function ks(_0x502c98){return _0x502c98!==null&&typeof _0x502c98=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x5937b0){const _0x1afa9e=[];for(const [_0x3a93fa,_0x13a9de]of Object['entries'](_0x5937b0))Array['isArray'](_0x13a9de)?_0x13a9de['forEach'](_0x249d4a=>{_0x1afa9e['push'](encodeURIComponent(_0x3a93fa)+'='+encodeURIComponent(_0x249d4a));}):_0x1afa9e['push'](encodeURIComponent(_0x3a93fa)+'='+encodeURIComponent(_0x13a9de));return _0x1afa9e['length']?'&'+_0x1afa9e['join']('&'):'';}function yt(_0xccc948){const _0x4c7599={};return _0xccc948['replace'](/^\?/,'')['split']('&')['forEach'](_0x578f95=>{if(_0x578f95){const [_0x12cf28,_0x385bd0]=_0x578f95['split']('=');_0x4c7599[decodeURIComponent(_0x12cf28)]=decodeURIComponent(_0x385bd0);}}),_0x4c7599;}function vt(_0x4f0bf7){const _0x1edf81=_0x4f0bf7['indexOf']('?');if(!_0x1edf81)return'';const _0x4eafaa=_0x4f0bf7['indexOf']('#',_0x1edf81);return _0x4f0bf7['substring'](_0x1edf81,_0x4eafaa>0x0?_0x4eafaa:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ec{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x5bc78d=0x1;_0x5bc78d<this['blockSize'];++_0x5bc78d)this['pad_'][_0x5bc78d]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x398669,_0x488ead){_0x488ead||(_0x488ead=0x0);const _0x51911a=this['W_'];if(typeof _0x398669=='string'){for(let _0x2583e5=0x0;_0x2583e5<0x10;_0x2583e5++)_0x51911a[_0x2583e5]=_0x398669['charCodeAt'](_0x488ead)<<0x18|_0x398669['charCodeAt'](_0x488ead+0x1)<<0x10|_0x398669['charCodeAt'](_0x488ead+0x2)<<0x8|_0x398669['charCodeAt'](_0x488ead+0x3),_0x488ead+=0x4;}else{for(let _0x1ea2cb=0x0;_0x1ea2cb<0x10;_0x1ea2cb++)_0x51911a[_0x1ea2cb]=_0x398669[_0x488ead]<<0x18|_0x398669[_0x488ead+0x1]<<0x10|_0x398669[_0x488ead+0x2]<<0x8|_0x398669[_0x488ead+0x3],_0x488ead+=0x4;}for(let _0x2cd679=0x10;_0x2cd679<0x50;_0x2cd679++){const _0x17a292=_0x51911a[_0x2cd679-0x3]^_0x51911a[_0x2cd679-0x8]^_0x51911a[_0x2cd679-0xe]^_0x51911a[_0x2cd679-0x10];_0x51911a[_0x2cd679]=(_0x17a292<<0x1|_0x17a292>>>0x1f)&0xffffffff;}let _0x2a9124=this['chain_'][0x0],_0x51d6c6=this['chain_'][0x1],_0x204551=this['chain_'][0x2],_0x251c61=this['chain_'][0x3],_0x45b032=this['chain_'][0x4],_0x36635d,_0x28a5dd;for(let _0x42b511=0x0;_0x42b511<0x50;_0x42b511++){_0x42b511<0x28?_0x42b511<0x14?(_0x36635d=_0x251c61^_0x51d6c6&(_0x204551^_0x251c61),_0x28a5dd=0x5a827999):(_0x36635d=_0x51d6c6^_0x204551^_0x251c61,_0x28a5dd=0x6ed9eba1):_0x42b511<0x3c?(_0x36635d=_0x51d6c6&_0x204551|_0x251c61&(_0x51d6c6|_0x204551),_0x28a5dd=0x8f1bbcdc):(_0x36635d=_0x51d6c6^_0x204551^_0x251c61,_0x28a5dd=0xca62c1d6);const _0x14dca5=(_0x2a9124<<0x5|_0x2a9124>>>0x1b)+_0x36635d+_0x45b032+_0x28a5dd+_0x51911a[_0x42b511]&0xffffffff;_0x45b032=_0x251c61,_0x251c61=_0x204551,_0x204551=(_0x51d6c6<<0x1e|_0x51d6c6>>>0x2)&0xffffffff,_0x51d6c6=_0x2a9124,_0x2a9124=_0x14dca5;}this['chain_'][0x0]=this['chain_'][0x0]+_0x2a9124&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x51d6c6&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x204551&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x251c61&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x45b032&0xffffffff;}['update'](_0x5c3377,_0x560dcf){if(_0x5c3377==null)return;_0x560dcf===void 0x0&&(_0x560dcf=_0x5c3377['length']);const _0x59af4d=_0x560dcf-this['blockSize'];let _0x56bd06=0x0;const _0x373d03=this['buf_'];let _0x32dea8=this['inbuf_'];for(;_0x56bd06<_0x560dcf;){if(_0x32dea8===0x0){for(;_0x56bd06<=_0x59af4d;)this['compress_'](_0x5c3377,_0x56bd06),_0x56bd06+=this['blockSize'];}if(typeof _0x5c3377=='string'){for(;_0x56bd06<_0x560dcf;)if(_0x373d03[_0x32dea8]=_0x5c3377['charCodeAt'](_0x56bd06),++_0x32dea8,++_0x56bd06,_0x32dea8===this['blockSize']){this['compress_'](_0x373d03),_0x32dea8=0x0;break;}}else{for(;_0x56bd06<_0x560dcf;)if(_0x373d03[_0x32dea8]=_0x5c3377[_0x56bd06],++_0x32dea8,++_0x56bd06,_0x32dea8===this['blockSize']){this['compress_'](_0x373d03),_0x32dea8=0x0;break;}}}this['inbuf_']=_0x32dea8,this['total_']+=_0x560dcf;}['digest'](){const _0x14097d=[];let _0x370587=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x507a02=this['blockSize']-0x1;_0x507a02>=0x38;_0x507a02--)this['buf_'][_0x507a02]=_0x370587&0xff,_0x370587/=0x100;this['compress_'](this['buf_']);let _0x4a2d18=0x0;for(let _0xf48ef4=0x0;_0xf48ef4<0x5;_0xf48ef4++)for(let _0xc14640=0x18;_0xc14640>=0x0;_0xc14640-=0x8)_0x14097d[_0x4a2d18]=this['chain_'][_0xf48ef4]>>_0xc14640&0xff,++_0x4a2d18;return _0x14097d;}}function Ic(_0x1a2326,_0x31d323){const _0x354c9e=new wc(_0x1a2326,_0x31d323);return _0x354c9e['subscribe']['bind'](_0x354c9e);}class wc{constructor(_0x20df67,_0x408201){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x408201,this['task']['then'](()=>{_0x20df67(this);})['catch'](_0x3e6129=>{this['error'](_0x3e6129);});}['next'](_0x9b91a1){this['forEachObserver'](_0x27aa97=>{_0x27aa97['next'](_0x9b91a1);});}['error'](_0x39eabb){this['forEachObserver'](_0x3c9687=>{_0x3c9687['error'](_0x39eabb);}),this['close'](_0x39eabb);}['complete'](){this['forEachObserver'](_0x101fe7=>{_0x101fe7['complete']();}),this['close']();}['subscribe'](_0x1e283b,_0x31ff06,_0x37c2b8){let _0xea000d;if(_0x1e283b===void 0x0&&_0x31ff06===void 0x0&&_0x37c2b8===void 0x0)throw new Error('Missing\x20Observer.');Cc(_0x1e283b,['next','error','complete'])?_0xea000d=_0x1e283b:_0xea000d={'next':_0x1e283b,'error':_0x31ff06,'complete':_0x37c2b8},_0xea000d['next']===void 0x0&&(_0xea000d['next']=Qn),_0xea000d['error']===void 0x0&&(_0xea000d['error']=Qn),_0xea000d['complete']===void 0x0&&(_0xea000d['complete']=Qn);const _0x16717b=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0xea000d['error'](this['finalError']):_0xea000d['complete']();}catch{}}),this['observers']['push'](_0xea000d),_0x16717b;}['unsubscribeOne'](_0x54ae32){this['observers']===void 0x0||this['observers'][_0x54ae32]===void 0x0||(delete this['observers'][_0x54ae32],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x21ed76){if(!this['finalized']){for(let _0x2ad4f9=0x0;_0x2ad4f9<this['observers']['length'];_0x2ad4f9++)this['sendOne'](_0x2ad4f9,_0x21ed76);}}['sendOne'](_0x2f00c7,_0x31dbf0){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x2f00c7]!==void 0x0)try{_0x31dbf0(this['observers'][_0x2f00c7]);}catch(_0xf7f66a){typeof console<'u'&&console['error']&&console['error'](_0xf7f66a);}});}['close'](_0x1024df){this['finalized']||(this['finalized']=!0x0,_0x1024df!==void 0x0&&(this['finalError']=_0x1024df),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function Cc(_0x3c63e2,_0x184109){if(typeof _0x3c63e2!='object'||_0x3c63e2===null)return!0x1;for(const _0x447eed of _0x184109)if(_0x447eed in _0x3c63e2&&typeof _0x3c63e2[_0x447eed]=='function')return!0x0;return!0x1;}function Qn(){}function Nn(_0x5f5ce4,_0x1f7101){return _0x5f5ce4+'\x20failed:\x20'+_0x1f7101+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tc=function(_0xb1c99){const _0xdad009=[];let _0x1de39f=0x0;for(let _0x5939b5=0x0;_0x5939b5<_0xb1c99['length'];_0x5939b5++){let _0x370bb1=_0xb1c99['charCodeAt'](_0x5939b5);if(_0x370bb1>=0xd800&&_0x370bb1<=0xdbff){const _0x5bbb61=_0x370bb1-0xd800;_0x5939b5++,f(_0x5939b5<_0xb1c99['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x101571=_0xb1c99['charCodeAt'](_0x5939b5)-0xdc00;_0x370bb1=0x10000+(_0x5bbb61<<0xa)+_0x101571;}_0x370bb1<0x80?_0xdad009[_0x1de39f++]=_0x370bb1:_0x370bb1<0x800?(_0xdad009[_0x1de39f++]=_0x370bb1>>0x6|0xc0,_0xdad009[_0x1de39f++]=_0x370bb1&0x3f|0x80):_0x370bb1<0x10000?(_0xdad009[_0x1de39f++]=_0x370bb1>>0xc|0xe0,_0xdad009[_0x1de39f++]=_0x370bb1>>0x6&0x3f|0x80,_0xdad009[_0x1de39f++]=_0x370bb1&0x3f|0x80):(_0xdad009[_0x1de39f++]=_0x370bb1>>0x12|0xf0,_0xdad009[_0x1de39f++]=_0x370bb1>>0xc&0x3f|0x80,_0xdad009[_0x1de39f++]=_0x370bb1>>0x6&0x3f|0x80,_0xdad009[_0x1de39f++]=_0x370bb1&0x3f|0x80);}return _0xdad009;},Pn=function(_0x3d5718){let _0x426894=0x0;for(let _0x281ddd=0x0;_0x281ddd<_0x3d5718['length'];_0x281ddd++){const _0x5a9923=_0x3d5718['charCodeAt'](_0x281ddd);_0x5a9923<0x80?_0x426894++:_0x5a9923<0x800?_0x426894+=0x2:_0x5a9923>=0xd800&&_0x5a9923<=0xdbff?(_0x426894+=0x4,_0x281ddd++):_0x426894+=0x3;}return _0x426894;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function k(_0x20218b){return _0x20218b&&_0x20218b['_delegate']?_0x20218b['_delegate']:_0x20218b;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wt(_0x427a29){try{return(_0x427a29['startsWith']('http://')||_0x427a29['startsWith']('https://')?new URL(_0x427a29)['hostname']:_0x427a29)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x8925c){return(await fetch(_0x8925c,{'credentials':'include'}))['ok'];}class Me{constructor(_0x5b319a,_0x4d273f,_0x236cac){this['name']=_0x5b319a,this['instanceFactory']=_0x4d273f,this['type']=_0x236cac,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x22311a){return this['instantiationMode']=_0x22311a,this;}['setMultipleInstances'](_0x271ed){return this['multipleInstances']=_0x271ed,this;}['setServiceProps'](_0x4e797c){return this['serviceProps']=_0x4e797c,this;}['setInstanceCreatedCallback'](_0x166953){return this['onInstanceCreated']=_0x166953,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ke='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sc{constructor(_0x9a60e5,_0x328858){this['name']=_0x9a60e5,this['container']=_0x328858,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x4d4f18){const _0x7a4867=this['normalizeInstanceIdentifier'](_0x4d4f18);if(!this['instancesDeferred']['has'](_0x7a4867)){const _0x429558=new Ve();if(this['instancesDeferred']['set'](_0x7a4867,_0x429558),this['isInitialized'](_0x7a4867)||this['shouldAutoInitialize']())try{const _0x123165=this['getOrInitializeService']({'instanceIdentifier':_0x7a4867});_0x123165&&_0x429558['resolve'](_0x123165);}catch{}}return this['instancesDeferred']['get'](_0x7a4867)['promise'];}['getImmediate'](_0x17b765){const _0x4abc15=this['normalizeInstanceIdentifier'](_0x17b765==null?void 0x0:_0x17b765['identifier']),_0x35b655=(_0x17b765==null?void 0x0:_0x17b765['optional'])??!0x1;if(this['isInitialized'](_0x4abc15)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x4abc15});}catch(_0x467faf){if(_0x35b655)return null;throw _0x467faf;}else{if(_0x35b655)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x2f77f3){if(_0x2f77f3['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x2f77f3['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x2f77f3,!!this['shouldAutoInitialize']()){if(Rc(_0x2f77f3))try{this['getOrInitializeService']({'instanceIdentifier':ke});}catch{}for(const [_0x3ba73b,_0x43af7f]of this['instancesDeferred']['entries']()){const _0x59da20=this['normalizeInstanceIdentifier'](_0x3ba73b);try{const _0x2a4ba3=this['getOrInitializeService']({'instanceIdentifier':_0x59da20});_0x43af7f['resolve'](_0x2a4ba3);}catch{}}}}['clearInstance'](_0x34a3f1=ke){this['instancesDeferred']['delete'](_0x34a3f1),this['instancesOptions']['delete'](_0x34a3f1),this['instances']['delete'](_0x34a3f1);}async['delete'](){const _0x562dac=Array['from'](this['instances']['values']());await Promise['all']([..._0x562dac['filter'](_0x40ed73=>'INTERNAL'in _0x40ed73)['map'](_0x3e0ca4=>_0x3e0ca4['INTERNAL']['delete']()),..._0x562dac['filter'](_0x35ff2a=>'_delete'in _0x35ff2a)['map'](_0x46c561=>_0x46c561['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x3f4a1d=ke){return this['instances']['has'](_0x3f4a1d);}['getOptions'](_0x39b11c=ke){return this['instancesOptions']['get'](_0x39b11c)||{};}['initialize'](_0x140fbe={}){const {options:_0x2b0407={}}=_0x140fbe,_0x1ab2a6=this['normalizeInstanceIdentifier'](_0x140fbe['instanceIdentifier']);if(this['isInitialized'](_0x1ab2a6))throw Error(this['name']+'('+_0x1ab2a6+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x3c6c7c=this['getOrInitializeService']({'instanceIdentifier':_0x1ab2a6,'options':_0x2b0407});for(const [_0xa1e2d6,_0x5f1952]of this['instancesDeferred']['entries']()){const _0x55e572=this['normalizeInstanceIdentifier'](_0xa1e2d6);_0x1ab2a6===_0x55e572&&_0x5f1952['resolve'](_0x3c6c7c);}return _0x3c6c7c;}['onInit'](_0x241931,_0x3b7b22){const _0x5aada8=this['normalizeInstanceIdentifier'](_0x3b7b22),_0x57fef8=this['onInitCallbacks']['get'](_0x5aada8)??new Set();_0x57fef8['add'](_0x241931),this['onInitCallbacks']['set'](_0x5aada8,_0x57fef8);const _0x408775=this['instances']['get'](_0x5aada8);return _0x408775&&_0x241931(_0x408775,_0x5aada8),()=>{_0x57fef8['delete'](_0x241931);};}['invokeOnInitCallbacks'](_0x26a4ad,_0x1b9ecb){const _0x4f9c28=this['onInitCallbacks']['get'](_0x1b9ecb);if(_0x4f9c28){for(const _0xfc61fb of _0x4f9c28)try{_0xfc61fb(_0x26a4ad,_0x1b9ecb);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x5bbffe,options:_0x357851={}}){let _0x3be309=this['instances']['get'](_0x5bbffe);if(!_0x3be309&&this['component']&&(_0x3be309=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':bc(_0x5bbffe),'options':_0x357851}),this['instances']['set'](_0x5bbffe,_0x3be309),this['instancesOptions']['set'](_0x5bbffe,_0x357851),this['invokeOnInitCallbacks'](_0x3be309,_0x5bbffe),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x5bbffe,_0x3be309);}catch{}return _0x3be309||null;}['normalizeInstanceIdentifier'](_0x356d89=ke){return this['component']?this['component']['multipleInstances']?_0x356d89:ke:_0x356d89;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function bc(_0x3da7d6){return _0x3da7d6===ke?void 0x0:_0x3da7d6;}function Rc(_0x46bbfd){return _0x46bbfd['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x1e6895){this['name']=_0x1e6895,this['providers']=new Map();}['addComponent'](_0x48548e){const _0xc4b865=this['getProvider'](_0x48548e['name']);if(_0xc4b865['isComponentSet']())throw new Error('Component\x20'+_0x48548e['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0xc4b865['setComponent'](_0x48548e);}['addOrOverwriteComponent'](_0x168750){this['getProvider'](_0x168750['name'])['isComponentSet']()&&this['providers']['delete'](_0x168750['name']),this['addComponent'](_0x168750);}['getProvider'](_0x7e947e){if(this['providers']['has'](_0x7e947e))return this['providers']['get'](_0x7e947e);const _0x3119d8=new Sc(_0x7e947e,this);return this['providers']['set'](_0x7e947e,_0x3119d8),_0x3119d8;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x390f21){_0x390f21[_0x390f21['DEBUG']=0x0]='DEBUG',_0x390f21[_0x390f21['VERBOSE']=0x1]='VERBOSE',_0x390f21[_0x390f21['INFO']=0x2]='INFO',_0x390f21[_0x390f21['WARN']=0x3]='WARN',_0x390f21[_0x390f21['ERROR']=0x4]='ERROR',_0x390f21[_0x390f21['SILENT']=0x5]='SILENT';}(T||(T={})));const kc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Nc=T['INFO'],Pc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Oc=(_0x3f4370,_0x56c7b4,..._0x3a5a87)=>{if(_0x56c7b4<_0x3f4370['logLevel'])return;const _0x275e76=new Date()['toISOString'](),_0x4a0f7f=Pc[_0x56c7b4];if(_0x4a0f7f)console[_0x4a0f7f]('['+_0x275e76+']\x20\x20'+_0x3f4370['name']+':',..._0x3a5a87);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x56c7b4+')');};class xi{constructor(_0x38bf08){this['name']=_0x38bf08,this['_logLevel']=Nc,this['_logHandler']=Oc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x6b4147){if(!(_0x6b4147 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x6b4147+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x6b4147;}['setLogLevel'](_0x5703bb){this['_logLevel']=typeof _0x5703bb=='string'?kc[_0x5703bb]:_0x5703bb;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x282292){if(typeof _0x282292!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x282292;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x407348){this['_userLogHandler']=_0x407348;}['debug'](..._0x4ec01a){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x4ec01a),this['_logHandler'](this,T['DEBUG'],..._0x4ec01a);}['log'](..._0x244bc8){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x244bc8),this['_logHandler'](this,T['VERBOSE'],..._0x244bc8);}['info'](..._0x38f2df){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x38f2df),this['_logHandler'](this,T['INFO'],..._0x38f2df);}['warn'](..._0x41d78c){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x41d78c),this['_logHandler'](this,T['WARN'],..._0x41d78c);}['error'](..._0xe9207c){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0xe9207c),this['_logHandler'](this,T['ERROR'],..._0xe9207c);}}const Dc=(_0x561c8e,_0x5d03f7)=>_0x5d03f7['some'](_0x434832=>_0x561c8e instanceof _0x434832);let Ns,Ps;function Mc(){return Ns||(Ns=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Lc(){return Ps||(Ps=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Kr=new WeakMap(),ui=new WeakMap(),Yr=new WeakMap(),Jn=new WeakMap(),Fi=new WeakMap();function xc(_0x1dbba9){const _0xf5d138=new Promise((_0x27cb3b,_0xa081cb)=>{const _0x1f750e=()=>{_0x1dbba9['removeEventListener']('success',_0x47d7e),_0x1dbba9['removeEventListener']('error',_0x416d8f);},_0x47d7e=()=>{_0x27cb3b(_e(_0x1dbba9['result'])),_0x1f750e();},_0x416d8f=()=>{_0xa081cb(_0x1dbba9['error']),_0x1f750e();};_0x1dbba9['addEventListener']('success',_0x47d7e),_0x1dbba9['addEventListener']('error',_0x416d8f);});return _0xf5d138['then'](_0x50a793=>{_0x50a793 instanceof IDBCursor&&Kr['set'](_0x50a793,_0x1dbba9);})['catch'](()=>{}),Fi['set'](_0xf5d138,_0x1dbba9),_0xf5d138;}function Fc(_0x46910c){if(ui['has'](_0x46910c))return;const _0x3b9c53=new Promise((_0x3e561f,_0x54f1a6)=>{const _0x8c2a5c=()=>{_0x46910c['removeEventListener']('complete',_0x2b6852),_0x46910c['removeEventListener']('error',_0x4aa023),_0x46910c['removeEventListener']('abort',_0x4aa023);},_0x2b6852=()=>{_0x3e561f(),_0x8c2a5c();},_0x4aa023=()=>{_0x54f1a6(_0x46910c['error']||new DOMException('AbortError','AbortError')),_0x8c2a5c();};_0x46910c['addEventListener']('complete',_0x2b6852),_0x46910c['addEventListener']('error',_0x4aa023),_0x46910c['addEventListener']('abort',_0x4aa023);});ui['set'](_0x46910c,_0x3b9c53);}let di={'get'(_0x5ca071,_0x5d1db6,_0x439ab0){if(_0x5ca071 instanceof IDBTransaction){if(_0x5d1db6==='done')return ui['get'](_0x5ca071);if(_0x5d1db6==='objectStoreNames')return _0x5ca071['objectStoreNames']||Yr['get'](_0x5ca071);if(_0x5d1db6==='store')return _0x439ab0['objectStoreNames'][0x1]?void 0x0:_0x439ab0['objectStore'](_0x439ab0['objectStoreNames'][0x0]);}return _e(_0x5ca071[_0x5d1db6]);},'set'(_0x3e7291,_0x4a0eb3,_0x3d51ca){return _0x3e7291[_0x4a0eb3]=_0x3d51ca,!0x0;},'has'(_0x25359d,_0x140287){return _0x25359d instanceof IDBTransaction&&(_0x140287==='done'||_0x140287==='store')?!0x0:_0x140287 in _0x25359d;}};function Uc(_0x1d6299){di=_0x1d6299(di);}function Wc(_0x1a2c97){return _0x1a2c97===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x366637,..._0x304393){const _0x2d5d38=_0x1a2c97['call'](Xn(this),_0x366637,..._0x304393);return Yr['set'](_0x2d5d38,_0x366637['sort']?_0x366637['sort']():[_0x366637]),_e(_0x2d5d38);}:Lc()['includes'](_0x1a2c97)?function(..._0x3a6d3e){return _0x1a2c97['apply'](Xn(this),_0x3a6d3e),_e(Kr['get'](this));}:function(..._0x243d9a){return _e(_0x1a2c97['apply'](Xn(this),_0x243d9a));};}function Bc(_0x107669){return typeof _0x107669=='function'?Wc(_0x107669):(_0x107669 instanceof IDBTransaction&&Fc(_0x107669),Dc(_0x107669,Mc())?new Proxy(_0x107669,di):_0x107669);}function _e(_0x590c88){if(_0x590c88 instanceof IDBRequest)return xc(_0x590c88);if(Jn['has'](_0x590c88))return Jn['get'](_0x590c88);const _0x8e9c1c=Bc(_0x590c88);return _0x8e9c1c!==_0x590c88&&(Jn['set'](_0x590c88,_0x8e9c1c),Fi['set'](_0x8e9c1c,_0x590c88)),_0x8e9c1c;}const Xn=_0x483927=>Fi['get'](_0x483927);function Vc(_0x359084,_0x2170a2,{blocked:_0x377267,upgrade:_0x3d8b2b,blocking:_0x4ed0a3,terminated:_0x38422f}={}){const _0x3ced25=indexedDB['open'](_0x359084,_0x2170a2),_0x1e1f0b=_e(_0x3ced25);return _0x3d8b2b&&_0x3ced25['addEventListener']('upgradeneeded',_0xd5a667=>{_0x3d8b2b(_e(_0x3ced25['result']),_0xd5a667['oldVersion'],_0xd5a667['newVersion'],_e(_0x3ced25['transaction']),_0xd5a667);}),_0x377267&&_0x3ced25['addEventListener']('blocked',_0x319be6=>_0x377267(_0x319be6['oldVersion'],_0x319be6['newVersion'],_0x319be6)),_0x1e1f0b['then'](_0x1e8031=>{_0x38422f&&_0x1e8031['addEventListener']('close',()=>_0x38422f()),_0x4ed0a3&&_0x1e8031['addEventListener']('versionchange',_0x42ad2c=>_0x4ed0a3(_0x42ad2c['oldVersion'],_0x42ad2c['newVersion'],_0x42ad2c));})['catch'](()=>{}),_0x1e1f0b;}const Hc=['get','getKey','getAll','getAllKeys','count'],$c=['put','add','delete','clear'],Zn=new Map();function Os(_0x1dadf4,_0x2f9d63){if(!(_0x1dadf4 instanceof IDBDatabase&&!(_0x2f9d63 in _0x1dadf4)&&typeof _0x2f9d63=='string'))return;if(Zn['get'](_0x2f9d63))return Zn['get'](_0x2f9d63);const _0x48f824=_0x2f9d63['replace'](/FromIndex$/,''),_0x425349=_0x2f9d63!==_0x48f824,_0x48d09d=$c['includes'](_0x48f824);if(!(_0x48f824 in(_0x425349?IDBIndex:IDBObjectStore)['prototype'])||!(_0x48d09d||Hc['includes'](_0x48f824)))return;const _0x8b2432=async function(_0x1f92a9,..._0x222742){const _0x321a1a=this['transaction'](_0x1f92a9,_0x48d09d?'readwrite':'readonly');let _0xc0913c=_0x321a1a['store'];return _0x425349&&(_0xc0913c=_0xc0913c['index'](_0x222742['shift']())),(await Promise['all']([_0xc0913c[_0x48f824](..._0x222742),_0x48d09d&&_0x321a1a['done']]))[0x0];};return Zn['set'](_0x2f9d63,_0x8b2432),_0x8b2432;}Uc(_0xe18d3a=>({..._0xe18d3a,'get':(_0x3c5c1a,_0x406779,_0x4668aa)=>Os(_0x3c5c1a,_0x406779)||_0xe18d3a['get'](_0x3c5c1a,_0x406779,_0x4668aa),'has':(_0x492f03,_0x2340fc)=>!!Os(_0x492f03,_0x2340fc)||_0xe18d3a['has'](_0x492f03,_0x2340fc)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gc{constructor(_0x3a5195){this['container']=_0x3a5195;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x494b7e=>{if(qc(_0x494b7e)){const _0x4579bb=_0x494b7e['getImmediate']();return _0x4579bb['library']+'/'+_0x4579bb['version'];}else return null;})['filter'](_0x41b2fc=>_0x41b2fc)['join']('\x20');}}function qc(_0x40d916){const _0x37e95c=_0x40d916['getComponent']();return(_0x37e95c==null?void 0x0:_0x37e95c['type'])==='VERSION';}const fi='@firebase/app',Ds='0.15.1',re=new xi('@firebase/app'),zc='@firebase/app-compat',jc='@firebase/analytics-compat',Kc='@firebase/analytics',Yc='@firebase/app-check-compat',Qc='@firebase/app-check',Jc='@firebase/auth',Xc='@firebase/auth-compat',Zc='@firebase/database',el='@firebase/data-connect',tl='@firebase/database-compat',nl='@firebase/functions',il='@firebase/functions-compat',sl='@firebase/installations',rl='@firebase/installations-compat',ol='@firebase/messaging',al='@firebase/messaging-compat',cl='@firebase/performance',ll='@firebase/performance-compat',hl='@firebase/remote-config',ul='@firebase/remote-config-compat',dl='@firebase/storage',fl='@firebase/storage-compat',pl='@firebase/firestore',_l='@firebase/ai',gl='@firebase/firestore-compat',ml='firebase',yl='12.16.0',pi='[DEFAULT]',vl={[fi]:'fire-core',[zc]:'fire-core-compat',[Kc]:'fire-analytics',[jc]:'fire-analytics-compat',[Qc]:'fire-app-check',[Yc]:'fire-app-check-compat',[Jc]:'fire-auth',[Xc]:'fire-auth-compat',[Zc]:'fire-rtdb',[el]:'fire-data-connect',[tl]:'fire-rtdb-compat',[nl]:'fire-fn',[il]:'fire-fn-compat',[sl]:'fire-iid',[rl]:'fire-iid-compat',[ol]:'fire-fcm',[al]:'fire-fcm-compat',[cl]:'fire-perf',[ll]:'fire-perf-compat',[hl]:'fire-rc',[ul]:'fire-rc-compat',[dl]:'fire-gcs',[fl]:'fire-gcs-compat',[pl]:'fire-fst',[gl]:'fire-fst-compat',[_l]:'fire-vertex','fire-js':'fire-js',[ml]:'fire-js-all'},Le=new Map(),_i=new Map(),gi=new Map();function Ms(_0x1bb276,_0x468c17){try{_0x1bb276['container']['addComponent'](_0x468c17);}catch(_0x1250be){re['debug']('Component\x20'+_0x468c17['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x1bb276['name'],_0x1250be);}}function et(_0x579acf){const _0x599b73=_0x579acf['name'];if(gi['has'](_0x599b73))return re['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x599b73+'.'),!0x1;gi['set'](_0x599b73,_0x579acf);for(const _0x1b94a3 of Le['values']())Ms(_0x1b94a3,_0x579acf);for(const _0x584c56 of _i['values']())Ms(_0x584c56,_0x579acf);return!0x0;}function Ui(_0x2fc4ff,_0xe5470b){const _0xad904f=_0x2fc4ff['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0xad904f&&_0xad904f['triggerHeartbeat'](),_0x2fc4ff['container']['getProvider'](_0xe5470b);}function H(_0x14c723){return _0x14c723==null?!0x1:_0x14c723['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const El={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Ut('app','Firebase',El);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Il{constructor(_0x34b122,_0x4dd2bd,_0xf87e71){this['_isDeleted']=!0x1,this['_options']={..._0x34b122},this['_config']={..._0x4dd2bd},this['_name']=_0x4dd2bd['name'],this['_automaticDataCollectionEnabled']=_0x4dd2bd['automaticDataCollectionEnabled'],this['_container']=_0xf87e71,this['container']['addComponent'](new Me('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x33a830){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x33a830;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x199f97){this['_isDeleted']=_0x199f97;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ct=yl;function wl(_0xc83a73,_0x320b9e={}){let _0x3038e6=_0xc83a73;typeof _0x320b9e!='object'&&(_0x320b9e={'name':_0x320b9e});const _0x3339c2={'name':pi,'automaticDataCollectionEnabled':!0x0,..._0x320b9e},_0x2ccde4=_0x3339c2['name'];if(typeof _0x2ccde4!='string'||!_0x2ccde4)throw ge['create']('bad-app-name',{'appName':String(_0x2ccde4)});if(_0x3038e6||(_0x3038e6=$r()),!_0x3038e6)throw ge['create']('no-options');const _0x26638a=Le['get'](_0x2ccde4);if(_0x26638a){if(De(_0x3038e6,_0x26638a['options'])&&De(_0x3339c2,_0x26638a['config']))return _0x26638a;throw ge['create']('duplicate-app',{'appName':_0x2ccde4});}const _0xf38e25=new Ac(_0x2ccde4);for(const _0x202282 of gi['values']())_0xf38e25['addComponent'](_0x202282);const _0x19197f=new Il(_0x3038e6,_0x3339c2,_0xf38e25);return Le['set'](_0x2ccde4,_0x19197f),_0x19197f;}function Qr(_0x10844f=pi){const _0x2badb1=Le['get'](_0x10844f);if(!_0x2badb1&&_0x10844f===pi&&$r())return wl();if(!_0x2badb1)throw ge['create']('no-app',{'appName':_0x10844f});return _0x2badb1;}function c_(){return Array['from'](Le['values']());}async function l_(_0x3e0db2){let _0xfe95cd=!0x1;const _0x440575=_0x3e0db2['name'];Le['has'](_0x440575)?(_0xfe95cd=!0x0,Le['delete'](_0x440575)):_i['has'](_0x440575)&&_0x3e0db2['decRefCount']()<=0x0&&(_i['delete'](_0x440575),_0xfe95cd=!0x0),_0xfe95cd&&(await Promise['all'](_0x3e0db2['container']['getProviders']()['map'](_0x5cc483=>_0x5cc483['delete']())),_0x3e0db2['isDeleted']=!0x0);}function me(_0x5d0cf4,_0x1aac99,_0xa16b70){let _0x2697e6=vl[_0x5d0cf4]??_0x5d0cf4;_0xa16b70&&(_0x2697e6+='-'+_0xa16b70);const _0x7e7637=_0x2697e6['match'](/\s|\//),_0x1454d7=_0x1aac99['match'](/\s|\//);if(_0x7e7637||_0x1454d7){const _0x3e0e4d=['Unable\x20to\x20register\x20library\x20\x22'+_0x2697e6+'\x22\x20with\x20version\x20\x22'+_0x1aac99+'\x22:'];_0x7e7637&&_0x3e0e4d['push']('library\x20name\x20\x22'+_0x2697e6+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x7e7637&&_0x1454d7&&_0x3e0e4d['push']('and'),_0x1454d7&&_0x3e0e4d['push']('version\x20name\x20\x22'+_0x1aac99+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),re['warn'](_0x3e0e4d['join']('\x20'));return;}et(new Me(_0x2697e6+'-version',()=>({'library':_0x2697e6,'version':_0x1aac99}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl='firebase-heartbeat-database',Tl=0x1,Rt='firebase-heartbeat-store';let ei=null;function Jr(){return ei||(ei=Vc(Cl,Tl,{'upgrade':(_0x25c077,_0x4dc344)=>{switch(_0x4dc344){case 0x0:try{_0x25c077['createObjectStore'](Rt);}catch(_0x21c98c){console['warn'](_0x21c98c);}}}})['catch'](_0x4b7ef1=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x4b7ef1['message']});})),ei;}async function Sl(_0x5d4b30){try{const _0x53e08b=(await Jr())['transaction'](Rt),_0x5c5a39=await _0x53e08b['objectStore'](Rt)['get'](Xr(_0x5d4b30));return await _0x53e08b['done'],_0x5c5a39;}catch(_0x2de2ae){if(_0x2de2ae instanceof Se)re['warn'](_0x2de2ae['message']);else{const _0x3b8b68=ge['create']('idb-get',{'originalErrorMessage':_0x2de2ae==null?void 0x0:_0x2de2ae['message']});re['warn'](_0x3b8b68['message']);}}}async function Ls(_0x531a50,_0x1ed0a7){try{const _0xacb3ef=(await Jr())['transaction'](Rt,'readwrite');await _0xacb3ef['objectStore'](Rt)['put'](_0x1ed0a7,Xr(_0x531a50)),await _0xacb3ef['done'];}catch(_0x414549){if(_0x414549 instanceof Se)re['warn'](_0x414549['message']);else{const _0x3516d6=ge['create']('idb-set',{'originalErrorMessage':_0x414549==null?void 0x0:_0x414549['message']});re['warn'](_0x3516d6['message']);}}}function Xr(_0x2f64a8){return _0x2f64a8['name']+'!'+_0x2f64a8['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl=0x400,Rl=0x1e;class Al{constructor(_0x4b7e0f){this['container']=_0x4b7e0f,this['_heartbeatsCache']=null;const _0x338072=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Nl(_0x338072),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x54726b=>(this['_heartbeatsCache']=_0x54726b,_0x54726b));}async['triggerHeartbeat'](){var _0x29d415,_0x5e391a;try{const _0x5a1df8=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x4c680a=xs();if(((_0x29d415=this['_heartbeatsCache'])==null?void 0x0:_0x29d415['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x5e391a=this['_heartbeatsCache'])==null?void 0x0:_0x5e391a['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x4c680a||this['_heartbeatsCache']['heartbeats']['some'](_0x337c11=>_0x337c11['date']===_0x4c680a))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x4c680a,'agent':_0x5a1df8}),this['_heartbeatsCache']['heartbeats']['length']>Rl){const _0x517cc4=Pl(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x517cc4,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x324f9d){re['warn'](_0x324f9d);}}async['getHeartbeatsHeader'](){var _0x4ffbf7;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x4ffbf7=this['_heartbeatsCache'])==null?void 0x0:_0x4ffbf7['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x505bb9=xs(),{heartbeatsToSend:_0x2c021f,unsentEntries:_0x1fd8dd}=kl(this['_heartbeatsCache']['heartbeats']),_0x34e7ab=an(JSON['stringify']({'version':0x2,'heartbeats':_0x2c021f}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x505bb9,_0x1fd8dd['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x1fd8dd,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x34e7ab;}catch(_0x56d1f0){return re['warn'](_0x56d1f0),'';}}}function xs(){return new Date()['toISOString']()['substring'](0x0,0xa);}function kl(_0x59cb51,_0x898c68=bl){const _0x4f14c9=[];let _0x319cc0=_0x59cb51['slice']();for(const _0x4e2469 of _0x59cb51){const _0x5bdf64=_0x4f14c9['find'](_0x490568=>_0x490568['agent']===_0x4e2469['agent']);if(_0x5bdf64){if(_0x5bdf64['dates']['push'](_0x4e2469['date']),Fs(_0x4f14c9)>_0x898c68){_0x5bdf64['dates']['pop']();break;}}else{if(_0x4f14c9['push']({'agent':_0x4e2469['agent'],'dates':[_0x4e2469['date']]}),Fs(_0x4f14c9)>_0x898c68){_0x4f14c9['pop']();break;}}_0x319cc0=_0x319cc0['slice'](0x1);}return{'heartbeatsToSend':_0x4f14c9,'unsentEntries':_0x319cc0};}class Nl{constructor(_0x5b2dd8){this['app']=_0x5b2dd8,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return fc()?pc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0xc3e5e6=await Sl(this['app']);return _0xc3e5e6!=null&&_0xc3e5e6['heartbeats']?_0xc3e5e6:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x10c856){if(await this['_canUseIndexedDBPromise']){const _0x30b821=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x10c856['lastSentHeartbeatDate']??_0x30b821['lastSentHeartbeatDate'],'heartbeats':_0x10c856['heartbeats']});}else return;}async['add'](_0x305834){if(await this['_canUseIndexedDBPromise']){const _0x5754c7=await this['read']();return Ls(this['app'],{'lastSentHeartbeatDate':_0x305834['lastSentHeartbeatDate']??_0x5754c7['lastSentHeartbeatDate'],'heartbeats':[..._0x5754c7['heartbeats'],..._0x305834['heartbeats']]});}else return;}}function Fs(_0x31732e){return an(JSON['stringify']({'version':0x2,'heartbeats':_0x31732e}))['length'];}function Pl(_0x3ba075){if(_0x3ba075['length']===0x0)return-0x1;let _0x29ae8d=0x0,_0x71daea=_0x3ba075[0x0]['date'];for(let _0x3148c1=0x1;_0x3148c1<_0x3ba075['length'];_0x3148c1++)_0x3ba075[_0x3148c1]['date']<_0x71daea&&(_0x71daea=_0x3ba075[_0x3148c1]['date'],_0x29ae8d=_0x3148c1);return _0x29ae8d;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ol(_0x4c0fa2){et(new Me('platform-logger',_0x74325=>new Gc(_0x74325),'PRIVATE')),et(new Me('heartbeat',_0xa6bd38=>new Al(_0xa6bd38),'PRIVATE')),me(fi,Ds,_0x4c0fa2),me(fi,Ds,'esm2020'),me('fire-js','');}Ol('');var Dl='firebase',Ml='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(Dl,Ml,'app');var Us={};const Ws='@firebase/database',Bs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zr='';function Ll(_0x1136f6){Zr=_0x1136f6;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xl{constructor(_0x421509){this['domStorage_']=_0x421509,this['prefix_']='firebase:';}['set'](_0x523899,_0x24fd04){_0x24fd04==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x523899)):this['domStorage_']['setItem'](this['prefixedName_'](_0x523899),O(_0x24fd04));}['get'](_0x15d9dc){const _0x2b1356=this['domStorage_']['getItem'](this['prefixedName_'](_0x15d9dc));return _0x2b1356==null?null:bt(_0x2b1356);}['remove'](_0x4d26ea){this['domStorage_']['removeItem'](this['prefixedName_'](_0x4d26ea));}['prefixedName_'](_0x224672){return this['prefix_']+_0x224672;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x553e06,_0x449cc9){_0x449cc9==null?delete this['cache_'][_0x553e06]:this['cache_'][_0x553e06]=_0x449cc9;}['get'](_0x48639b){return Y(this['cache_'],_0x48639b)?this['cache_'][_0x48639b]:null;}['remove'](_0x47d2d6){delete this['cache_'][_0x47d2d6];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const eo=function(_0x31879a){try{if(typeof window<'u'&&typeof window[_0x31879a]<'u'){const _0x3e11ea=window[_0x31879a];return _0x3e11ea['setItem']('firebase:sentinel','cache'),_0x3e11ea['removeItem']('firebase:sentinel'),new xl(_0x3e11ea);}}catch{}return new Fl();},Pe=eo('localStorage'),Ul=eo('sessionStorage'),Qe=new xi('@firebase/database'),to=(function(){let _0x1ad8a0=0x1;return function(){return _0x1ad8a0++;};}()),no=function(_0x1d8aa1){const _0x163368=Tc(_0x1d8aa1),_0x4fa1c8=new Ec();_0x4fa1c8['update'](_0x163368);const _0x5623c1=_0x4fa1c8['digest']();return Di['encodeByteArray'](_0x5623c1);},Bt=function(..._0x4d1f17){let _0x5eaeda='';for(let _0x7dc6e2=0x0;_0x7dc6e2<_0x4d1f17['length'];_0x7dc6e2++){const _0x158dd0=_0x4d1f17[_0x7dc6e2];Array['isArray'](_0x158dd0)||_0x158dd0&&typeof _0x158dd0=='object'&&typeof _0x158dd0['length']=='number'?_0x5eaeda+=Bt['apply'](null,_0x158dd0):typeof _0x158dd0=='object'?_0x5eaeda+=O(_0x158dd0):_0x5eaeda+=_0x158dd0,_0x5eaeda+='\x20';}return _0x5eaeda;};let Et=null,Vs=!0x0;const Wl=function(_0x5175fc,_0x320db1){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Qe['logLevel']=T['VERBOSE'],Et=Qe['log']['bind'](Qe);},L=function(..._0x7ab198){if(Vs===!0x0&&(Vs=!0x1,Et===null&&Ul['get']('logging_enabled')===!0x0&&Wl()),Et){const _0x135e7f=Bt['apply'](null,_0x7ab198);Et(_0x135e7f);}},Vt=function(_0x51f360){return function(..._0x221499){L(_0x51f360,..._0x221499);};},mi=function(..._0x35b2a1){const _0x16f48d='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Bt(..._0x35b2a1);Qe['error'](_0x16f48d);},oe=function(..._0x5b8d27){const _0x3aa6d6='FIREBASE\x20FATAL\x20ERROR:\x20'+Bt(..._0x5b8d27);throw Qe['error'](_0x3aa6d6),new Error(_0x3aa6d6);},U=function(..._0x3b77c5){const _0x21e3f8='FIREBASE\x20WARNING:\x20'+Bt(..._0x3b77c5);Qe['warn'](_0x21e3f8);},Bl=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Wi=function(_0x5eca27){return typeof _0x5eca27=='number'&&(_0x5eca27!==_0x5eca27||_0x5eca27===Number['POSITIVE_INFINITY']||_0x5eca27===Number['NEGATIVE_INFINITY']);},Vl=function(_0x50c062){if(document['readyState']==='complete')_0x50c062();else{let _0xd58d77=!0x1;const _0x4f47a6=function(){if(!document['body']){setTimeout(_0x4f47a6,Math['floor'](0xa));return;}_0xd58d77||(_0xd58d77=!0x0,_0x50c062());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x4f47a6,!0x1),window['addEventListener']('load',_0x4f47a6,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x4f47a6();}),window['attachEvent']('onload',_0x4f47a6));}},xe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x1faf3e,_0xeccd08){if(_0x1faf3e===_0xeccd08)return 0x0;if(_0x1faf3e===xe||_0xeccd08===Ie)return-0x1;if(_0xeccd08===xe||_0x1faf3e===Ie)return 0x1;{const _0x5c4aeb=Hs(_0x1faf3e),_0x9acd9=Hs(_0xeccd08);return _0x5c4aeb!==null?_0x9acd9!==null?_0x5c4aeb-_0x9acd9===0x0?_0x1faf3e['length']-_0xeccd08['length']:_0x5c4aeb-_0x9acd9:-0x1:_0x9acd9!==null?0x1:_0x1faf3e<_0xeccd08?-0x1:0x1;}},Hl=function(_0xce11a9,_0x59e2c0){return _0xce11a9===_0x59e2c0?0x0:_0xce11a9<_0x59e2c0?-0x1:0x1;},pt=function(_0x1780a8,_0x334f56){if(_0x334f56&&_0x1780a8 in _0x334f56)return _0x334f56[_0x1780a8];throw new Error('Missing\x20required\x20key\x20('+_0x1780a8+')\x20in\x20object:\x20'+O(_0x334f56));},Bi=function(_0x422aed){if(typeof _0x422aed!='object'||_0x422aed===null)return O(_0x422aed);const _0x1c8390=[];for(const _0x169d5b in _0x422aed)_0x1c8390['push'](_0x169d5b);_0x1c8390['sort']();let _0x74912e='{';for(let _0x2a0178=0x0;_0x2a0178<_0x1c8390['length'];_0x2a0178++)_0x2a0178!==0x0&&(_0x74912e+=','),_0x74912e+=O(_0x1c8390[_0x2a0178]),_0x74912e+=':',_0x74912e+=Bi(_0x422aed[_0x1c8390[_0x2a0178]]);return _0x74912e+='}',_0x74912e;},io=function(_0x13ed85,_0x41f657){const _0xac4692=_0x13ed85['length'];if(_0xac4692<=_0x41f657)return[_0x13ed85];const _0x2f28e9=[];for(let _0x53c1ed=0x0;_0x53c1ed<_0xac4692;_0x53c1ed+=_0x41f657)_0x53c1ed+_0x41f657>_0xac4692?_0x2f28e9['push'](_0x13ed85['substring'](_0x53c1ed,_0xac4692)):_0x2f28e9['push'](_0x13ed85['substring'](_0x53c1ed,_0x53c1ed+_0x41f657));return _0x2f28e9;};function x(_0x566de5,_0x3b4a53){for(const _0x5e4585 in _0x566de5)_0x566de5['hasOwnProperty'](_0x5e4585)&&_0x3b4a53(_0x5e4585,_0x566de5[_0x5e4585]);}const so=function(_0x173c9b){f(!Wi(_0x173c9b),'Invalid\x20JSON\x20number');const _0x496b93=0xb,_0x2e3e03=0x34,_0x58088d=(0x1<<_0x496b93-0x1)-0x1;let _0x57f246,_0x15a0a0,_0x4c78a6,_0x490321,_0xca2060;_0x173c9b===0x0?(_0x15a0a0=0x0,_0x4c78a6=0x0,_0x57f246=0x1/_0x173c9b===-0x1/0x0?0x1:0x0):(_0x57f246=_0x173c9b<0x0,_0x173c9b=Math['abs'](_0x173c9b),_0x173c9b>=Math['pow'](0x2,0x1-_0x58088d)?(_0x490321=Math['min'](Math['floor'](Math['log'](_0x173c9b)/Math['LN2']),_0x58088d),_0x15a0a0=_0x490321+_0x58088d,_0x4c78a6=Math['round'](_0x173c9b*Math['pow'](0x2,_0x2e3e03-_0x490321)-Math['pow'](0x2,_0x2e3e03))):(_0x15a0a0=0x0,_0x4c78a6=Math['round'](_0x173c9b/Math['pow'](0x2,0x1-_0x58088d-_0x2e3e03))));const _0x2e27e4=[];for(_0xca2060=_0x2e3e03;_0xca2060;_0xca2060-=0x1)_0x2e27e4['push'](_0x4c78a6%0x2?0x1:0x0),_0x4c78a6=Math['floor'](_0x4c78a6/0x2);for(_0xca2060=_0x496b93;_0xca2060;_0xca2060-=0x1)_0x2e27e4['push'](_0x15a0a0%0x2?0x1:0x0),_0x15a0a0=Math['floor'](_0x15a0a0/0x2);_0x2e27e4['push'](_0x57f246?0x1:0x0),_0x2e27e4['reverse']();const _0x508ec7=_0x2e27e4['join']('');let _0x4fe37f='';for(_0xca2060=0x0;_0xca2060<0x40;_0xca2060+=0x8){let _0x389bb1=parseInt(_0x508ec7['substr'](_0xca2060,0x8),0x2)['toString'](0x10);_0x389bb1['length']===0x1&&(_0x389bb1='0'+_0x389bb1),_0x4fe37f=_0x4fe37f+_0x389bb1;}return _0x4fe37f['toLowerCase']();},$l=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},Gl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function ql(_0x43dece,_0x314443){let _0x31fd8a='Unknown\x20Error';_0x43dece==='too_big'?_0x31fd8a='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x43dece==='permission_denied'?_0x31fd8a='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x43dece==='unavailable'&&(_0x31fd8a='The\x20service\x20is\x20unavailable');const _0x5ce5d5=new Error(_0x43dece+'\x20at\x20'+_0x314443['_path']['toString']()+':\x20'+_0x31fd8a);return _0x5ce5d5['code']=_0x43dece['toUpperCase'](),_0x5ce5d5;}const zl=new RegExp('^-?(0*)\x5cd{1,10}$'),jl=-0x80000000,Kl=0x7fffffff,Hs=function(_0x3201f1){if(zl['test'](_0x3201f1)){const _0x1a1a02=Number(_0x3201f1);if(_0x1a1a02>=jl&&_0x1a1a02<=Kl)return _0x1a1a02;}return null;},lt=function(_0x259c61){try{_0x259c61();}catch(_0x2e14cf){setTimeout(()=>{const _0x9f9b2c=_0x2e14cf['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x9f9b2c),_0x2e14cf;},Math['floor'](0x0));}},Yl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},It=function(_0x232dd,_0x1631fc){const _0x32f36f=setTimeout(_0x232dd,_0x1631fc);return typeof _0x32f36f=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x32f36f):typeof _0x32f36f=='object'&&_0x32f36f['unref']&&_0x32f36f['unref'](),_0x32f36f;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ql{constructor(_0x6efe6c,_0x4049b1){this['appCheckProvider']=_0x4049b1,this['appName']=_0x6efe6c['name'],H(_0x6efe6c)&&_0x6efe6c['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x6efe6c['settings']['appCheckToken']),this['appCheck']=_0x4049b1==null?void 0x0:_0x4049b1['getImmediate']({'optional':!0x0}),this['appCheck']||_0x4049b1==null||_0x4049b1['get']()['then'](_0x466975=>this['appCheck']=_0x466975);}['getToken'](_0x5ec39d){if(this['serverAppAppCheckToken']){if(_0x5ec39d)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x5ec39d):new Promise((_0x3952a1,_0x2fd952)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x5ec39d)['then'](_0x3952a1,_0x2fd952):_0x3952a1(null);},0x0);});}['addTokenChangeListener'](_0xb73c41){var _0x5c95fa;(_0x5c95fa=this['appCheckProvider'])==null||_0x5c95fa['get']()['then'](_0x329fef=>_0x329fef['addTokenListener'](_0xb73c41));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jl{constructor(_0x192afd,_0x1410f6,_0x58dca1){this['appName_']=_0x192afd,this['firebaseOptions_']=_0x1410f6,this['authProvider_']=_0x58dca1,this['auth_']=null,this['auth_']=_0x58dca1['getImmediate']({'optional':!0x0}),this['auth_']||_0x58dca1['onInit'](_0x27abd6=>this['auth_']=_0x27abd6);}['getToken'](_0x407104){return this['auth_']?this['auth_']['getToken'](_0x407104)['catch'](_0x1e0070=>_0x1e0070&&_0x1e0070['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x1e0070)):new Promise((_0x59a34e,_0x45fdc2)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x407104)['then'](_0x59a34e,_0x45fdc2):_0x59a34e(null);},0x0);});}['addTokenChangeListener'](_0x65b20d){this['auth_']?this['auth_']['addAuthTokenListener'](_0x65b20d):this['authProvider_']['get']()['then'](_0x75b1e=>_0x75b1e['addAuthTokenListener'](_0x65b20d));}['removeTokenChangeListener'](_0x59d409){this['authProvider_']['get']()['then'](_0x3f4b62=>_0x3f4b62['removeAuthTokenListener'](_0x59d409));}['notifyForInvalidToken'](){let _0x33e368='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x33e368+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x33e368+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x33e368+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x33e368);}}class tn{constructor(_0x2e444c){this['accessToken']=_0x2e444c;}['getToken'](_0x59030d){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x21e42b){_0x21e42b(this['accessToken']);}['removeTokenChangeListener'](_0x3cefc3){}['notifyForInvalidToken'](){}}tn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vi='5',ro='v',oo='s',ao='r',co='f',lo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,ho='ls',uo='p',yi='ac',fo='websocket',po='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _o{constructor(_0x53d11a,_0x5729e3,_0x2df6f3,_0x31a5f4,_0x2bd20d=!0x1,_0x5dd207='',_0x5c9741=!0x1,_0x45dccf=!0x1,_0x545e01=null){this['secure']=_0x5729e3,this['namespace']=_0x2df6f3,this['webSocketOnly']=_0x31a5f4,this['nodeAdmin']=_0x2bd20d,this['persistenceKey']=_0x5dd207,this['includeNamespaceInQueryParams']=_0x5c9741,this['isUsingEmulator']=_0x45dccf,this['emulatorOptions']=_0x545e01,this['_host']=_0x53d11a['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Pe['get']('host:'+_0x53d11a)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x1a2b94){_0x1a2b94!==this['internalHost']&&(this['internalHost']=_0x1a2b94,this['isCacheableHost']()&&Pe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x178f0b=this['toURLString']();return this['persistenceKey']&&(_0x178f0b+='<'+this['persistenceKey']+'>'),_0x178f0b;}['toURLString'](){const _0x3be0bc=this['secure']?'https://':'http://',_0xad85f4=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x3be0bc+this['host']+'/'+_0xad85f4;}}function Xl(_0x12316d){return _0x12316d['host']!==_0x12316d['internalHost']||_0x12316d['isCustomHost']()||_0x12316d['includeNamespaceInQueryParams'];}function go(_0x45053b,_0xc6dbd8,_0x1a1b7a){f(typeof _0xc6dbd8=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x1a1b7a=='object','typeof\x20params\x20must\x20==\x20object');let _0x1816ff;if(_0xc6dbd8===fo)_0x1816ff=(_0x45053b['secure']?'wss://':'ws://')+_0x45053b['internalHost']+'/.ws?';else{if(_0xc6dbd8===po)_0x1816ff=(_0x45053b['secure']?'https://':'http://')+_0x45053b['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0xc6dbd8);}Xl(_0x45053b)&&(_0x1a1b7a['ns']=_0x45053b['namespace']);const _0x160c6c=[];return x(_0x1a1b7a,(_0x5e28cb,_0x3bfe98)=>{_0x160c6c['push'](_0x5e28cb+'='+_0x3bfe98);}),_0x1816ff+_0x160c6c['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(){this['counters_']={};}['incrementCounter'](_0x3c08e1,_0x2cf71e=0x1){Y(this['counters_'],_0x3c08e1)||(this['counters_'][_0x3c08e1]=0x0),this['counters_'][_0x3c08e1]+=_0x2cf71e;}['get'](){return tc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ti={},ni={};function Hi(_0x3fc954){const _0x2de00b=_0x3fc954['toString']();return ti[_0x2de00b]||(ti[_0x2de00b]=new Zl()),ti[_0x2de00b];}function eh(_0x2f53f4,_0x69184f){const _0x1c035b=_0x2f53f4['toString']();return ni[_0x1c035b]||(ni[_0x1c035b]=_0x69184f()),ni[_0x1c035b];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class th{constructor(_0xcf765b){this['onMessage_']=_0xcf765b,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x5ef30b,_0x4e4f11){this['closeAfterResponse']=_0x5ef30b,this['onClose']=_0x4e4f11,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x14089d,_0x23801e){for(this['pendingResponses'][_0x14089d]=_0x23801e;this['pendingResponses'][this['currentResponseNum']];){const _0x41c992=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x3f0e95=0x0;_0x3f0e95<_0x41c992['length'];++_0x3f0e95)_0x41c992[_0x3f0e95]&&lt(()=>{this['onMessage_'](_0x41c992[_0x3f0e95]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $s='start',nh='close',ih='pLPCommand',sh='pRTLPCB',mo='id',yo='pw',vo='ser',rh='cb',oh='seg',ah='ts',ch='d',lh='dframe',Eo=0x74e,Io=0x1e,hh=Eo-Io,uh=0x61a8,dh=0x7530;class Ke{constructor(_0x1911cf,_0x141d55,_0x3ba7ef,_0x3352d2,_0x511caa,_0x3126cc,_0x52dd9d){this['connId']=_0x1911cf,this['repoInfo']=_0x141d55,this['applicationId']=_0x3ba7ef,this['appCheckToken']=_0x3352d2,this['authToken']=_0x511caa,this['transportSessionId']=_0x3126cc,this['lastSessionId']=_0x52dd9d,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Vt(_0x1911cf),this['stats_']=Hi(_0x141d55),this['urlFn']=_0xe96c6b=>(this['appCheckToken']&&(_0xe96c6b[yi]=this['appCheckToken']),go(_0x141d55,po,_0xe96c6b));}['open'](_0x532cb5,_0x4807ed){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x4807ed,this['myPacketOrderer']=new th(_0x532cb5),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](dh)),Vl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new $i((..._0x2bbe34)=>{const [_0x506e27,_0x2a06f4,_0x4f0746,_0x4234a9,_0x4e4054]=_0x2bbe34;if(this['incrementIncomingBytes_'](_0x2bbe34),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x506e27===$s)this['id']=_0x2a06f4,this['password']=_0x4f0746;else{if(_0x506e27===nh)_0x2a06f4?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x2a06f4,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x506e27);}}},(..._0x17572c)=>{const [_0x1e43f3,_0x532b8a]=_0x17572c;this['incrementIncomingBytes_'](_0x17572c),this['myPacketOrderer']['handleResponse'](_0x1e43f3,_0x532b8a);},()=>{this['onClosed_']();},this['urlFn']);const _0x120432={};_0x120432[$s]='t',_0x120432[vo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x120432[rh]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x120432[ro]=Vi,this['transportSessionId']&&(_0x120432[oo]=this['transportSessionId']),this['lastSessionId']&&(_0x120432[ho]=this['lastSessionId']),this['applicationId']&&(_0x120432[uo]=this['applicationId']),this['appCheckToken']&&(_0x120432[yi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x120432[ao]=co);const _0x4fcabe=this['urlFn'](_0x120432);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x4fcabe),this['scriptTagHolder']['addTag'](_0x4fcabe,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Ke['forceAllow_']=!0x0;}static['forceDisallow'](){Ke['forceDisallow_']=!0x0;}static['isAvailable'](){return Ke['forceAllow_']?!0x0:!Ke['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!$l()&&!Gl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x584ad9){const _0x98bc48=O(_0x584ad9);this['bytesSent']+=_0x98bc48['length'],this['stats_']['incrementCounter']('bytes_sent',_0x98bc48['length']);const _0x3570a9=Br(_0x98bc48),_0x2f4c7c=io(_0x3570a9,hh);for(let _0x3a6dbf=0x0;_0x3a6dbf<_0x2f4c7c['length'];_0x3a6dbf++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x2f4c7c['length'],_0x2f4c7c[_0x3a6dbf]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x351597,_0x579b0a){this['myDisconnFrame']=document['createElement']('iframe');const _0x426ba4={};_0x426ba4[lh]='t',_0x426ba4[mo]=_0x351597,_0x426ba4[yo]=_0x579b0a,this['myDisconnFrame']['src']=this['urlFn'](_0x426ba4),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x202ee4){const _0x247f9a=O(_0x202ee4)['length'];this['bytesReceived']+=_0x247f9a,this['stats_']['incrementCounter']('bytes_received',_0x247f9a);}}class $i{constructor(_0x2ccd37,_0x4fa541,_0x1d434c,_0x4c69d3){this['onDisconnect']=_0x1d434c,this['urlFn']=_0x4c69d3,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=to(),window[ih+this['uniqueCallbackIdentifier']]=_0x2ccd37,window[sh+this['uniqueCallbackIdentifier']]=_0x4fa541,this['myIFrame']=$i['createIFrame_']();let _0x2ba8bb='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x2ba8bb='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x2d6456='<html><body>'+_0x2ba8bb+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x2d6456),this['myIFrame']['doc']['close']();}catch(_0xeb7bb4){L('frame\x20writing\x20exception'),_0xeb7bb4['stack']&&L(_0xeb7bb4['stack']),L(_0xeb7bb4);}}}static['createIFrame_'](){const _0x241391=document['createElement']('iframe');if(_0x241391['style']['display']='none',document['body']){document['body']['appendChild'](_0x241391);try{_0x241391['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x333e92=document['domain'];_0x241391['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x333e92+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x241391['contentDocument']?_0x241391['doc']=_0x241391['contentDocument']:_0x241391['contentWindow']?_0x241391['doc']=_0x241391['contentWindow']['document']:_0x241391['document']&&(_0x241391['doc']=_0x241391['document']),_0x241391;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x3e536b=this['onDisconnect'];_0x3e536b&&(this['onDisconnect']=null,_0x3e536b());}['startLongPoll'](_0x3ef980,_0x4ba4ae){for(this['myID']=_0x3ef980,this['myPW']=_0x4ba4ae,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0xb528b2={};_0xb528b2[mo]=this['myID'],_0xb528b2[yo]=this['myPW'],_0xb528b2[vo]=this['currentSerial'];let _0x204a50=this['urlFn'](_0xb528b2),_0x52f92d='',_0x31200a=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+Io+_0x52f92d['length']<=Eo;){const _0x59972c=this['pendingSegs']['shift']();_0x52f92d=_0x52f92d+'&'+oh+_0x31200a+'='+_0x59972c['seg']+'&'+ah+_0x31200a+'='+_0x59972c['ts']+'&'+ch+_0x31200a+'='+_0x59972c['d'],_0x31200a++;}return _0x204a50=_0x204a50+_0x52f92d,this['addLongPollTag_'](_0x204a50,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x5b70e8,_0x26a3b2,_0x487524){this['pendingSegs']['push']({'seg':_0x5b70e8,'ts':_0x26a3b2,'d':_0x487524}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x3912a5,_0x1b9645){this['outstandingRequests']['add'](_0x1b9645);const _0x261311=()=>{this['outstandingRequests']['delete'](_0x1b9645),this['newRequest_']();},_0x501937=setTimeout(_0x261311,Math['floor'](uh)),_0x31c055=()=>{clearTimeout(_0x501937),_0x261311();};this['addTag'](_0x3912a5,_0x31c055);}['addTag'](_0x3cb649,_0xa7503){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x1b7f6e=this['myIFrame']['doc']['createElement']('script');_0x1b7f6e['type']='text/javascript',_0x1b7f6e['async']=!0x0,_0x1b7f6e['src']=_0x3cb649,_0x1b7f6e['onload']=_0x1b7f6e['onreadystatechange']=function(){const _0x5e3504=_0x1b7f6e['readyState'];(!_0x5e3504||_0x5e3504==='loaded'||_0x5e3504==='complete')&&(_0x1b7f6e['onload']=_0x1b7f6e['onreadystatechange']=null,_0x1b7f6e['parentNode']&&_0x1b7f6e['parentNode']['removeChild'](_0x1b7f6e),_0xa7503());},_0x1b7f6e['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x3cb649),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x1b7f6e);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fh=0x4000,ph=0xafc8;let hn=null;typeof MozWebSocket<'u'?hn=MozWebSocket:typeof WebSocket<'u'&&(hn=WebSocket);class G{constructor(_0x216342,_0x864466,_0x2e7137,_0x3714e0,_0x57a973,_0x3dd596,_0x578426){this['connId']=_0x216342,this['applicationId']=_0x2e7137,this['appCheckToken']=_0x3714e0,this['authToken']=_0x57a973,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Vt(this['connId']),this['stats_']=Hi(_0x864466),this['connURL']=G['connectionURL_'](_0x864466,_0x3dd596,_0x578426,_0x3714e0,_0x2e7137),this['nodeAdmin']=_0x864466['nodeAdmin'];}static['connectionURL_'](_0x322855,_0x1feec6,_0x19146c,_0x4be374,_0x4cbc86){const _0x8c777c={};return _0x8c777c[ro]=Vi,typeof location<'u'&&location['hostname']&&lo['test'](location['hostname'])&&(_0x8c777c[ao]=co),_0x1feec6&&(_0x8c777c[oo]=_0x1feec6),_0x19146c&&(_0x8c777c[ho]=_0x19146c),_0x4be374&&(_0x8c777c[yi]=_0x4be374),_0x4cbc86&&(_0x8c777c[uo]=_0x4cbc86),go(_0x322855,fo,_0x8c777c);}['open'](_0x4c8379,_0xcad367){this['onDisconnect']=_0xcad367,this['onMessage']=_0x4c8379,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Pe['set']('previous_websocket_failure',!0x0);try{let _0x311fd5;dc(),this['mySock']=new hn(this['connURL'],[],_0x311fd5);}catch(_0x47e41c){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x547ea8=_0x47e41c['message']||_0x47e41c['data'];_0x547ea8&&this['log_'](_0x547ea8),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x29cbdb=>{this['handleIncomingFrame'](_0x29cbdb);},this['mySock']['onerror']=_0x43b8b1=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x2772d1=_0x43b8b1['message']||_0x43b8b1['data'];_0x2772d1&&this['log_'](_0x2772d1),this['onClosed_']();};}['start'](){}static['forceDisallow'](){G['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x4d9b97=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x1b2abe=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x208e76=navigator['userAgent']['match'](_0x1b2abe);_0x208e76&&_0x208e76['length']>0x1&&parseFloat(_0x208e76[0x1])<4.4&&(_0x4d9b97=!0x0);}return!_0x4d9b97&&hn!==null&&!G['forceDisallow_'];}static['previouslyFailed'](){return Pe['isInMemoryStorage']||Pe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Pe['remove']('previous_websocket_failure');}['appendFrame_'](_0x1b45cd){if(this['frames']['push'](_0x1b45cd),this['frames']['length']===this['totalFrames']){const _0x438404=this['frames']['join']('');this['frames']=null;const _0x4f3811=bt(_0x438404);this['onMessage'](_0x4f3811);}}['handleNewFrameCount_'](_0x2e05c7){this['totalFrames']=_0x2e05c7,this['frames']=[];}['extractFrameCount_'](_0x5710b2){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x5710b2['length']<=0x6){const _0x565975=Number(_0x5710b2);if(!isNaN(_0x565975))return this['handleNewFrameCount_'](_0x565975),null;}return this['handleNewFrameCount_'](0x1),_0x5710b2;}['handleIncomingFrame'](_0x352bc5){if(this['mySock']===null)return;const _0x177797=_0x352bc5['data'];if(this['bytesReceived']+=_0x177797['length'],this['stats_']['incrementCounter']('bytes_received',_0x177797['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x177797);else{const _0x18c002=this['extractFrameCount_'](_0x177797);_0x18c002!==null&&this['appendFrame_'](_0x18c002);}}['send'](_0x17bd6b){this['resetKeepAlive']();const _0x46cac2=O(_0x17bd6b);this['bytesSent']+=_0x46cac2['length'],this['stats_']['incrementCounter']('bytes_sent',_0x46cac2['length']);const _0x281b1b=io(_0x46cac2,fh);_0x281b1b['length']>0x1&&this['sendString_'](String(_0x281b1b['length']));for(let _0x4a385e=0x0;_0x4a385e<_0x281b1b['length'];_0x4a385e++)this['sendString_'](_0x281b1b[_0x4a385e]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](ph));}['sendString_'](_0x2f0a11){try{this['mySock']['send'](_0x2f0a11);}catch(_0x33db47){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x33db47['message']||_0x33db47['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}G['responsesRequiredToBeHealthy']=0x2,G['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class At{static get['ALL_TRANSPORTS'](){return[Ke,G];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x5df239){this['initTransports_'](_0x5df239);}['initTransports_'](_0x237ae7){const _0x36e6db=G&&G['isAvailable']();let _0x54de8f=_0x36e6db&&!G['previouslyFailed']();if(_0x237ae7['webSocketOnly']&&(_0x36e6db||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x54de8f=!0x0),_0x54de8f)this['transports_']=[G];else{const _0x4f18ea=this['transports_']=[];for(const _0x1e22cd of At['ALL_TRANSPORTS'])_0x1e22cd&&_0x1e22cd['isAvailable']()&&_0x4f18ea['push'](_0x1e22cd);At['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}At['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _h=0xea60,gh=0x1388,mh=0xa*0x400,yh=0x64*0x400,ii='t',Gs='d',vh='s',qs='r',Eh='e',zs='o',js='a',Ks='n',Ys='p',Ih='h';class wh{constructor(_0xb681d3,_0x590fd5,_0x467bcc,_0x153821,_0x51238d,_0x9e38a1,_0x4b4753,_0x343997,_0x1b7d12,_0x25951c){this['id']=_0xb681d3,this['repoInfo_']=_0x590fd5,this['applicationId_']=_0x467bcc,this['appCheckToken_']=_0x153821,this['authToken_']=_0x51238d,this['onMessage_']=_0x9e38a1,this['onReady_']=_0x4b4753,this['onDisconnect_']=_0x343997,this['onKill_']=_0x1b7d12,this['lastSessionId']=_0x25951c,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Vt('c:'+this['id']+':'),this['transportManager_']=new At(_0x590fd5),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x1897ca=this['transportManager_']['initialTransport']();this['conn_']=new _0x1897ca(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x1897ca['responsesRequiredToBeHealthy']||0x0;const _0x35887c=this['connReceiver_'](this['conn_']),_0x35d087=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x35887c,_0x35d087);},Math['floor'](0x0));const _0x5d922a=_0x1897ca['healthyTimeout']||0x0;_0x5d922a>0x0&&(this['healthyTimeout_']=It(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>yh?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>mh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x5d922a)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x2a45a9){return _0x627a5=>{_0x2a45a9===this['conn_']?this['onConnectionLost_'](_0x627a5):_0x2a45a9===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0xca8e38){return _0x3d6287=>{this['state_']!==0x2&&(_0xca8e38===this['rx_']?this['onPrimaryMessageReceived_'](_0x3d6287):_0xca8e38===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x3d6287):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x28b3b9){const _0x1be8d3={'t':'d','d':_0x28b3b9};this['sendData_'](_0x1be8d3);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x7cb0b6){if(ii in _0x7cb0b6){const _0x47ade0=_0x7cb0b6[ii];_0x47ade0===js?this['upgradeIfSecondaryHealthy_']():_0x47ade0===qs?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x47ade0===zs&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x33c566){const _0x22421c=pt('t',_0x33c566),_0x4a3301=pt('d',_0x33c566);if(_0x22421c==='c')this['onSecondaryControl_'](_0x4a3301);else{if(_0x22421c==='d')this['pendingDataMessages']['push'](_0x4a3301);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x22421c);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':js,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Ks,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x5752a6){const _0x495598=pt('t',_0x5752a6),_0x32148a=pt('d',_0x5752a6);_0x495598==='c'?this['onControl_'](_0x32148a):_0x495598==='d'&&this['onDataMessage_'](_0x32148a);}['onDataMessage_'](_0x17c673){this['onPrimaryResponse_'](),this['onMessage_'](_0x17c673);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x3f60c6){const _0x51e7b9=pt(ii,_0x3f60c6);if(Gs in _0x3f60c6){const _0x328777=_0x3f60c6[Gs];if(_0x51e7b9===Ih){const _0x93f4c4={..._0x328777};this['repoInfo_']['isUsingEmulator']&&(_0x93f4c4['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x93f4c4);}else{if(_0x51e7b9===Ks){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x18c122=0x0;_0x18c122<this['pendingDataMessages']['length'];++_0x18c122)this['onDataMessage_'](this['pendingDataMessages'][_0x18c122]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x51e7b9===vh?this['onConnectionShutdown_'](_0x328777):_0x51e7b9===qs?this['onReset_'](_0x328777):_0x51e7b9===Eh?mi('Server\x20Error:\x20'+_0x328777):_0x51e7b9===zs?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):mi('Unknown\x20control\x20packet\x20command:\x20'+_0x51e7b9);}}}['onHandshake_'](_0x3c26e7){const _0x3003ce=_0x3c26e7['ts'],_0x5ef068=_0x3c26e7['v'],_0x1ce883=_0x3c26e7['h'];this['sessionId']=_0x3c26e7['s'],this['repoInfo_']['host']=_0x1ce883,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x3003ce),Vi!==_0x5ef068&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x3b2236=this['transportManager_']['upgradeTransport']();_0x3b2236&&this['startUpgrade_'](_0x3b2236);}['startUpgrade_'](_0x355d1d){this['secondaryConn_']=new _0x355d1d(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x355d1d['responsesRequiredToBeHealthy']||0x0;const _0x2d1fa5=this['connReceiver_'](this['secondaryConn_']),_0x1c7fca=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x2d1fa5,_0x1c7fca),It(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](_h));}['onReset_'](_0x4b32a7){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x4b32a7),this['repoInfo_']['host']=_0x4b32a7,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x50ade0,_0x512d){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x50ade0,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x512d,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):It(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](gh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Ys,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x2b1980=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x2b1980||this['rx_']===_0x2b1980)&&this['close']();}['onConnectionLost_'](_0x53c662){this['conn_']=null,!_0x53c662&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Pe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x369998){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x369998),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x15f638){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x15f638);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wo{['put'](_0x9bc7c0,_0xd166fb,_0x1ab4e7,_0x2b4200){}['merge'](_0x37d0b1,_0x4097f4,_0x4ba2b4,_0x2fda21){}['refreshAuthToken'](_0x1c3ba6){}['refreshAppCheckToken'](_0x2a4fc){}['onDisconnectPut'](_0x2bedd2,_0x6e9f40,_0x4f10ed){}['onDisconnectMerge'](_0x2ee47f,_0x55808f,_0x16eb36){}['onDisconnectCancel'](_0x4a55db,_0x4dd2f3){}['reportStats'](_0x3c7b7f){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Co{constructor(_0x144547){this['allowedEvents_']=_0x144547,this['listeners_']={},f(Array['isArray'](_0x144547)&&_0x144547['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x118db1,..._0x283afd){if(Array['isArray'](this['listeners_'][_0x118db1])){const _0x445610=[...this['listeners_'][_0x118db1]];for(let _0x3f6f87=0x0;_0x3f6f87<_0x445610['length'];_0x3f6f87++)_0x445610[_0x3f6f87]['callback']['apply'](_0x445610[_0x3f6f87]['context'],_0x283afd);}}['on'](_0x2eee86,_0x39df57,_0xa7fa0a){this['validateEventType_'](_0x2eee86),this['listeners_'][_0x2eee86]=this['listeners_'][_0x2eee86]||[],this['listeners_'][_0x2eee86]['push']({'callback':_0x39df57,'context':_0xa7fa0a});const _0x5e5fd9=this['getInitialEvent'](_0x2eee86);_0x5e5fd9&&_0x39df57['apply'](_0xa7fa0a,_0x5e5fd9);}['off'](_0x3fd2dc,_0x5847b,_0x318f87){this['validateEventType_'](_0x3fd2dc);const _0x41db87=this['listeners_'][_0x3fd2dc]||[];for(let _0x17d1ec=0x0;_0x17d1ec<_0x41db87['length'];_0x17d1ec++)if(_0x41db87[_0x17d1ec]['callback']===_0x5847b&&(!_0x318f87||_0x318f87===_0x41db87[_0x17d1ec]['context'])){_0x41db87['splice'](_0x17d1ec,0x1);return;}}['validateEventType_'](_0x107d24){f(this['allowedEvents_']['find'](_0x176034=>_0x176034===_0x107d24),'Unknown\x20event:\x20'+_0x107d24);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class un extends Co{static['getInstance'](){return new un();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Li()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x14d1a0){return f(_0x14d1a0==='online','Unknown\x20event\x20type:\x20'+_0x14d1a0),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qs=0x20,Js=0x300;class C{constructor(_0x5b8b00,_0x110841){if(_0x110841===void 0x0){this['pieces_']=_0x5b8b00['split']('/');let _0x226a72=0x0;for(let _0xbf2ae2=0x0;_0xbf2ae2<this['pieces_']['length'];_0xbf2ae2++)this['pieces_'][_0xbf2ae2]['length']>0x0&&(this['pieces_'][_0x226a72]=this['pieces_'][_0xbf2ae2],_0x226a72++);this['pieces_']['length']=_0x226a72,this['pieceNum_']=0x0;}else this['pieces_']=_0x5b8b00,this['pieceNum_']=_0x110841;}['toString'](){let _0x2fec59='';for(let _0x1887b9=this['pieceNum_'];_0x1887b9<this['pieces_']['length'];_0x1887b9++)this['pieces_'][_0x1887b9]!==''&&(_0x2fec59+='/'+this['pieces_'][_0x1887b9]);return _0x2fec59||'/';}}function w(){return new C('');}function y(_0x4ea23f){return _0x4ea23f['pieceNum_']>=_0x4ea23f['pieces_']['length']?null:_0x4ea23f['pieces_'][_0x4ea23f['pieceNum_']];}function we(_0x4b8ec1){return _0x4b8ec1['pieces_']['length']-_0x4b8ec1['pieceNum_'];}function b(_0x2df209){let _0x13d9f1=_0x2df209['pieceNum_'];return _0x13d9f1<_0x2df209['pieces_']['length']&&_0x13d9f1++,new C(_0x2df209['pieces_'],_0x13d9f1);}function Gi(_0x4adb77){return _0x4adb77['pieceNum_']<_0x4adb77['pieces_']['length']?_0x4adb77['pieces_'][_0x4adb77['pieces_']['length']-0x1]:null;}function Ch(_0x1775df){let _0x2bb404='';for(let _0x5c42bd=_0x1775df['pieceNum_'];_0x5c42bd<_0x1775df['pieces_']['length'];_0x5c42bd++)_0x1775df['pieces_'][_0x5c42bd]!==''&&(_0x2bb404+='/'+encodeURIComponent(String(_0x1775df['pieces_'][_0x5c42bd])));return _0x2bb404||'/';}function kt(_0x44fd65,_0xd0053=0x0){return _0x44fd65['pieces_']['slice'](_0x44fd65['pieceNum_']+_0xd0053);}function To(_0x2c789b){if(_0x2c789b['pieceNum_']>=_0x2c789b['pieces_']['length'])return null;const _0x19081b=[];for(let _0x21d8ba=_0x2c789b['pieceNum_'];_0x21d8ba<_0x2c789b['pieces_']['length']-0x1;_0x21d8ba++)_0x19081b['push'](_0x2c789b['pieces_'][_0x21d8ba]);return new C(_0x19081b,0x0);}function A(_0xce8c3b,_0x89ae65){const _0x314a60=[];for(let _0x218791=_0xce8c3b['pieceNum_'];_0x218791<_0xce8c3b['pieces_']['length'];_0x218791++)_0x314a60['push'](_0xce8c3b['pieces_'][_0x218791]);if(_0x89ae65 instanceof C){for(let _0x168239=_0x89ae65['pieceNum_'];_0x168239<_0x89ae65['pieces_']['length'];_0x168239++)_0x314a60['push'](_0x89ae65['pieces_'][_0x168239]);}else{const _0x2d5c7d=_0x89ae65['split']('/');for(let _0x1818e6=0x0;_0x1818e6<_0x2d5c7d['length'];_0x1818e6++)_0x2d5c7d[_0x1818e6]['length']>0x0&&_0x314a60['push'](_0x2d5c7d[_0x1818e6]);}return new C(_0x314a60,0x0);}function v(_0x16de5d){return _0x16de5d['pieceNum_']>=_0x16de5d['pieces_']['length'];}function F(_0x173f34,_0x25cc46){const _0x57cb4f=y(_0x173f34),_0x56beae=y(_0x25cc46);if(_0x57cb4f===null)return _0x25cc46;if(_0x57cb4f===_0x56beae)return F(b(_0x173f34),b(_0x25cc46));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x25cc46+')\x20is\x20not\x20within\x20outerPath\x20('+_0x173f34+')');}function Th(_0x185974,_0xf179a9){const _0x3c5adf=kt(_0x185974,0x0),_0x4bce8b=kt(_0xf179a9,0x0);for(let _0x11c0a4=0x0;_0x11c0a4<_0x3c5adf['length']&&_0x11c0a4<_0x4bce8b['length'];_0x11c0a4++){const _0x2ac83a=He(_0x3c5adf[_0x11c0a4],_0x4bce8b[_0x11c0a4]);if(_0x2ac83a!==0x0)return _0x2ac83a;}return _0x3c5adf['length']===_0x4bce8b['length']?0x0:_0x3c5adf['length']<_0x4bce8b['length']?-0x1:0x1;}function qi(_0x67134f,_0x2e092d){if(we(_0x67134f)!==we(_0x2e092d))return!0x1;for(let _0x5c29e7=_0x67134f['pieceNum_'],_0x4f23f2=_0x2e092d['pieceNum_'];_0x5c29e7<=_0x67134f['pieces_']['length'];_0x5c29e7++,_0x4f23f2++)if(_0x67134f['pieces_'][_0x5c29e7]!==_0x2e092d['pieces_'][_0x4f23f2])return!0x1;return!0x0;}function $(_0x4c1e67,_0x340893){let _0x439bf0=_0x4c1e67['pieceNum_'],_0x11c6e2=_0x340893['pieceNum_'];if(we(_0x4c1e67)>we(_0x340893))return!0x1;for(;_0x439bf0<_0x4c1e67['pieces_']['length'];){if(_0x4c1e67['pieces_'][_0x439bf0]!==_0x340893['pieces_'][_0x11c6e2])return!0x1;++_0x439bf0,++_0x11c6e2;}return!0x0;}class Sh{constructor(_0x140f76,_0x5b3c91){this['errorPrefix_']=_0x5b3c91,this['parts_']=kt(_0x140f76,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x2aa591=0x0;_0x2aa591<this['parts_']['length'];_0x2aa591++)this['byteLength_']+=Pn(this['parts_'][_0x2aa591]);So(this);}}function bh(_0x946373,_0x262e27){_0x946373['parts_']['length']>0x0&&(_0x946373['byteLength_']+=0x1),_0x946373['parts_']['push'](_0x262e27),_0x946373['byteLength_']+=Pn(_0x262e27),So(_0x946373);}function Rh(_0x3f5ecd){const _0x59eec5=_0x3f5ecd['parts_']['pop']();_0x3f5ecd['byteLength_']-=Pn(_0x59eec5),_0x3f5ecd['parts_']['length']>0x0&&(_0x3f5ecd['byteLength_']-=0x1);}function So(_0x3399a4){if(_0x3399a4['byteLength_']>Js)throw new Error(_0x3399a4['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Js+'\x20bytes\x20('+_0x3399a4['byteLength_']+').');if(_0x3399a4['parts_']['length']>Qs)throw new Error(_0x3399a4['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Qs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Ne(_0x3399a4));}function Ne(_0x3c694c){return _0x3c694c['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x3c694c['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class zi extends Co{static['getInstance'](){return new zi();}constructor(){super(['visible']);let _0x4e3b94,_0x1e9da7;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x1e9da7='visibilitychange',_0x4e3b94='hidden'):typeof document['mozHidden']<'u'?(_0x1e9da7='mozvisibilitychange',_0x4e3b94='mozHidden'):typeof document['msHidden']<'u'?(_0x1e9da7='msvisibilitychange',_0x4e3b94='msHidden'):typeof document['webkitHidden']<'u'&&(_0x1e9da7='webkitvisibilitychange',_0x4e3b94='webkitHidden')),this['visible_']=!0x0,_0x1e9da7&&document['addEventListener'](_0x1e9da7,()=>{const _0x9a44ad=!document[_0x4e3b94];_0x9a44ad!==this['visible_']&&(this['visible_']=_0x9a44ad,this['trigger']('visible',_0x9a44ad));},!0x1);}['getInitialEvent'](_0x3dc0cf){return f(_0x3dc0cf==='visible','Unknown\x20event\x20type:\x20'+_0x3dc0cf),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const _t=0x3e8,Ah=0x12c*0x3e8,Xs=0x1e*0x3e8,kh=1.3,Nh=0x7530,Ph='server_kill',Zs=0x3;class ie extends wo{constructor(_0x562b8f,_0x51247e,_0x11f806,_0x11306f,_0x2a6806,_0x2ba747,_0x1d734d,_0x10ec5d){if(super(),this['repoInfo_']=_0x562b8f,this['applicationId_']=_0x51247e,this['onDataUpdate_']=_0x11f806,this['onConnectStatus_']=_0x11306f,this['onServerInfoUpdate_']=_0x2a6806,this['authTokenProvider_']=_0x2ba747,this['appCheckTokenProvider_']=_0x1d734d,this['authOverride_']=_0x10ec5d,this['id']=ie['nextPersistentConnectionId_']++,this['log_']=Vt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=_t,this['maxReconnectDelay_']=Ah,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x10ec5d)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');zi['getInstance']()['on']('visible',this['onVisible_'],this),_0x562b8f['host']['indexOf']('fblocal')===-0x1&&un['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x3e3777,_0x2e33d4,_0x395572){const _0x21d6a9=++this['requestNumber_'],_0x1b412b={'r':_0x21d6a9,'a':_0x3e3777,'b':_0x2e33d4};this['log_'](O(_0x1b412b)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x1b412b),_0x395572&&(this['requestCBHash_'][_0x21d6a9]=_0x395572);}['get'](_0x5be0cf){this['initConnection_']();const _0x4250c2=new Ve(),_0x32c750={'action':'g','request':{'p':_0x5be0cf['_path']['toString'](),'q':_0x5be0cf['_queryObject']},'onComplete':_0x555ce6=>{const _0x386078=_0x555ce6['d'];_0x555ce6['s']==='ok'?_0x4250c2['resolve'](_0x386078):_0x4250c2['reject'](_0x386078);}};this['outstandingGets_']['push'](_0x32c750),this['outstandingGetCount_']++;const _0x4fe5f5=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x4fe5f5),_0x4250c2['promise'];}['listen'](_0x3bc68a,_0x287d31,_0x226c5f,_0x52261d){this['initConnection_']();const _0x52c44c=_0x3bc68a['_queryIdentifier'],_0x3380a6=_0x3bc68a['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x3380a6+'\x20'+_0x52c44c),this['listens']['has'](_0x3380a6)||this['listens']['set'](_0x3380a6,new Map()),f(_0x3bc68a['_queryParams']['isDefault']()||!_0x3bc68a['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x3380a6)['has'](_0x52c44c),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x58abed={'onComplete':_0x52261d,'hashFn':_0x287d31,'query':_0x3bc68a,'tag':_0x226c5f};this['listens']['get'](_0x3380a6)['set'](_0x52c44c,_0x58abed),this['connected_']&&this['sendListen_'](_0x58abed);}['sendGet_'](_0x1fab4c){const _0x5afa39=this['outstandingGets_'][_0x1fab4c];this['sendRequest']('g',_0x5afa39['request'],_0x238f68=>{delete this['outstandingGets_'][_0x1fab4c],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x5afa39['onComplete']&&_0x5afa39['onComplete'](_0x238f68);});}['sendListen_'](_0x309854){const _0x3d18b2=_0x309854['query'],_0x59880d=_0x3d18b2['_path']['toString'](),_0x588574=_0x3d18b2['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x59880d+'\x20for\x20'+_0x588574);const _0x2c24ec={'p':_0x59880d},_0x227b3c='q';_0x309854['tag']&&(_0x2c24ec['q']=_0x3d18b2['_queryObject'],_0x2c24ec['t']=_0x309854['tag']),_0x2c24ec['h']=_0x309854['hashFn'](),this['sendRequest'](_0x227b3c,_0x2c24ec,_0x439e92=>{const _0x1705e1=_0x439e92['d'],_0x4a765c=_0x439e92['s'];ie['warnOnListenWarnings_'](_0x1705e1,_0x3d18b2),(this['listens']['get'](_0x59880d)&&this['listens']['get'](_0x59880d)['get'](_0x588574))===_0x309854&&(this['log_']('listen\x20response',_0x439e92),_0x4a765c!=='ok'&&this['removeListen_'](_0x59880d,_0x588574),_0x309854['onComplete']&&_0x309854['onComplete'](_0x4a765c,_0x1705e1));});}static['warnOnListenWarnings_'](_0x505193,_0x5a9249){if(_0x505193&&typeof _0x505193=='object'&&Y(_0x505193,'w')){const _0x4480d3=Oe(_0x505193,'w');if(Array['isArray'](_0x4480d3)&&~_0x4480d3['indexOf']('no_index')){const _0x13c2aa='\x22.indexOn\x22:\x20\x22'+_0x5a9249['_queryParams']['getIndex']()['toString']()+'\x22',_0x202975=_0x5a9249['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x13c2aa+'\x20at\x20'+_0x202975+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x42e7e5){this['authToken_']=_0x42e7e5,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x42e7e5);}['reduceReconnectDelayIfAdminCredential_'](_0x59d15d){(_0x59d15d&&_0x59d15d['length']===0x28||vc(_0x59d15d))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=Xs);}['refreshAppCheckToken'](_0x219a0c){this['appCheckToken_']=_0x219a0c,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x575636=this['authToken_'],_0x3da004=yc(_0x575636)?'auth':'gauth',_0x36fa83={'cred':_0x575636};this['authOverride_']===null?_0x36fa83['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x36fa83['authvar']=this['authOverride_']),this['sendRequest'](_0x3da004,_0x36fa83,_0x5def51=>{const _0x505b6c=_0x5def51['s'],_0x26cfed=_0x5def51['d']||'error';this['authToken_']===_0x575636&&(_0x505b6c==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x505b6c,_0x26cfed));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x13f09b=>{const _0x42db89=_0x13f09b['s'],_0x3eacf6=_0x13f09b['d']||'error';_0x42db89==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x42db89,_0x3eacf6);});}['unlisten'](_0x1257b5,_0x1e9488){const _0x28c5a6=_0x1257b5['_path']['toString'](),_0x16442f=_0x1257b5['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x28c5a6+'\x20'+_0x16442f),f(_0x1257b5['_queryParams']['isDefault']()||!_0x1257b5['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x28c5a6,_0x16442f)&&this['connected_']&&this['sendUnlisten_'](_0x28c5a6,_0x16442f,_0x1257b5['_queryObject'],_0x1e9488);}['sendUnlisten_'](_0x3488ec,_0x5b08c2,_0xf4ca30,_0x5dbb74){this['log_']('Unlisten\x20on\x20'+_0x3488ec+'\x20for\x20'+_0x5b08c2);const _0x396e35={'p':_0x3488ec},_0x582d4e='n';_0x5dbb74&&(_0x396e35['q']=_0xf4ca30,_0x396e35['t']=_0x5dbb74),this['sendRequest'](_0x582d4e,_0x396e35);}['onDisconnectPut'](_0x18826f,_0x17180d,_0x29fc46){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x18826f,_0x17180d,_0x29fc46):this['onDisconnectRequestQueue_']['push']({'pathString':_0x18826f,'action':'o','data':_0x17180d,'onComplete':_0x29fc46});}['onDisconnectMerge'](_0x1ccf64,_0x21b4f7,_0x2d4618){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x1ccf64,_0x21b4f7,_0x2d4618):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1ccf64,'action':'om','data':_0x21b4f7,'onComplete':_0x2d4618});}['onDisconnectCancel'](_0x32b85f,_0x3562b4){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x32b85f,null,_0x3562b4):this['onDisconnectRequestQueue_']['push']({'pathString':_0x32b85f,'action':'oc','data':null,'onComplete':_0x3562b4});}['sendOnDisconnect_'](_0x2964c2,_0x129a5c,_0x249809,_0x10acf2){const _0x3895f6={'p':_0x129a5c,'d':_0x249809};this['log_']('onDisconnect\x20'+_0x2964c2,_0x3895f6),this['sendRequest'](_0x2964c2,_0x3895f6,_0x36cf9c=>{_0x10acf2&&setTimeout(()=>{_0x10acf2(_0x36cf9c['s'],_0x36cf9c['d']);},Math['floor'](0x0));});}['put'](_0x2092da,_0x4d495a,_0x10aae5,_0x42bac2){this['putInternal']('p',_0x2092da,_0x4d495a,_0x10aae5,_0x42bac2);}['merge'](_0x353875,_0x470fa2,_0x5e14c0,_0x19819a){this['putInternal']('m',_0x353875,_0x470fa2,_0x5e14c0,_0x19819a);}['putInternal'](_0x58aeac,_0x2542e5,_0x33f9c4,_0x2aebfc,_0x6a4636){this['initConnection_']();const _0x44d8cf={'p':_0x2542e5,'d':_0x33f9c4};_0x6a4636!==void 0x0&&(_0x44d8cf['h']=_0x6a4636),this['outstandingPuts_']['push']({'action':_0x58aeac,'request':_0x44d8cf,'onComplete':_0x2aebfc}),this['outstandingPutCount_']++;const _0xf8deee=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0xf8deee):this['log_']('Buffering\x20put:\x20'+_0x2542e5);}['sendPut_'](_0x5e1473){const _0xe59d1e=this['outstandingPuts_'][_0x5e1473]['action'],_0x11a232=this['outstandingPuts_'][_0x5e1473]['request'],_0x2c0ec0=this['outstandingPuts_'][_0x5e1473]['onComplete'];this['outstandingPuts_'][_0x5e1473]['queued']=this['connected_'],this['sendRequest'](_0xe59d1e,_0x11a232,_0x3d2370=>{this['log_'](_0xe59d1e+'\x20response',_0x3d2370),delete this['outstandingPuts_'][_0x5e1473],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x2c0ec0&&_0x2c0ec0(_0x3d2370['s'],_0x3d2370['d']);});}['reportStats'](_0x22e0ee){if(this['connected_']){const _0x4045e5={'c':_0x22e0ee};this['log_']('reportStats',_0x4045e5),this['sendRequest']('s',_0x4045e5,_0x211a09=>{if(_0x211a09['s']!=='ok'){const _0x258956=_0x211a09['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x258956);}});}}['onDataMessage_'](_0x52834e){if('r'in _0x52834e){this['log_']('from\x20server:\x20'+O(_0x52834e));const _0x25e456=_0x52834e['r'],_0x4cb612=this['requestCBHash_'][_0x25e456];_0x4cb612&&(delete this['requestCBHash_'][_0x25e456],_0x4cb612(_0x52834e['b']));}else{if('error'in _0x52834e)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x52834e['error'];'a'in _0x52834e&&this['onDataPush_'](_0x52834e['a'],_0x52834e['b']);}}['onDataPush_'](_0x57c0db,_0x42b2e2){this['log_']('handleServerMessage',_0x57c0db,_0x42b2e2),_0x57c0db==='d'?this['onDataUpdate_'](_0x42b2e2['p'],_0x42b2e2['d'],!0x1,_0x42b2e2['t']):_0x57c0db==='m'?this['onDataUpdate_'](_0x42b2e2['p'],_0x42b2e2['d'],!0x0,_0x42b2e2['t']):_0x57c0db==='c'?this['onListenRevoked_'](_0x42b2e2['p'],_0x42b2e2['q']):_0x57c0db==='ac'?this['onAuthRevoked_'](_0x42b2e2['s'],_0x42b2e2['d']):_0x57c0db==='apc'?this['onAppCheckRevoked_'](_0x42b2e2['s'],_0x42b2e2['d']):_0x57c0db==='sd'?this['onSecurityDebugPacket_'](_0x42b2e2):mi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x57c0db)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x512465,_0x12ba10){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x512465),this['lastSessionId']=_0x12ba10,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x1aef49){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x1aef49));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x4d024){_0x4d024&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x4d024;}['onOnline_'](_0x58b0cf){_0x58b0cf?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Nh&&(this['reconnectDelay_']=_t),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x2a6357=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x545219=Math['max'](0x0,this['reconnectDelay_']-_0x2a6357);_0x545219=Math['random']()*_0x545219,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x545219+'ms'),this['scheduleConnect_'](_0x545219),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*kh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x58d670=this['onDataMessage_']['bind'](this),_0x294fa5=this['onReady_']['bind'](this),_0x392018=this['onRealtimeDisconnect_']['bind'](this),_0x539116=this['id']+':'+ie['nextConnectionId_']++,_0x3e12bc=this['lastSessionId'];let _0x53aff7=!0x1,_0x130c2f=null;const _0x3e04a0=function(){_0x130c2f?_0x130c2f['close']():(_0x53aff7=!0x0,_0x392018());},_0x504fcb=function(_0x216ec8){f(_0x130c2f,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x130c2f['sendRequest'](_0x216ec8);};this['realtime_']={'close':_0x3e04a0,'sendRequest':_0x504fcb};const _0x26813c=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x116915,_0x5e540d]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x26813c),this['appCheckTokenProvider_']['getToken'](_0x26813c)]);_0x53aff7?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x116915&&_0x116915['accessToken'],this['appCheckToken_']=_0x5e540d&&_0x5e540d['token'],_0x130c2f=new wh(_0x539116,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x58d670,_0x294fa5,_0x392018,_0x1ffcfa=>{U(_0x1ffcfa+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Ph);},_0x3e12bc));}catch(_0x393427){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x393427),_0x53aff7||(this['repoInfo_']['nodeAdmin']&&U(_0x393427),_0x3e04a0());}}}['interrupt'](_0x37ba01){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x37ba01),this['interruptReasons_'][_0x37ba01]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x49d774){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x49d774),delete this['interruptReasons_'][_0x49d774],hi(this['interruptReasons_'])&&(this['reconnectDelay_']=_t,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x394bf9){const _0x1f896b=_0x394bf9-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x1f896b});}['cancelSentTransactions_'](){for(let _0xa81d65=0x0;_0xa81d65<this['outstandingPuts_']['length'];_0xa81d65++){const _0x26440b=this['outstandingPuts_'][_0xa81d65];_0x26440b&&'h'in _0x26440b['request']&&_0x26440b['queued']&&(_0x26440b['onComplete']&&_0x26440b['onComplete']('disconnect'),delete this['outstandingPuts_'][_0xa81d65],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x1a4472,_0x13a5e5){let _0x3e209e;_0x13a5e5?_0x3e209e=_0x13a5e5['map'](_0x391fe0=>Bi(_0x391fe0))['join']('$'):_0x3e209e='default';const _0x28d143=this['removeListen_'](_0x1a4472,_0x3e209e);_0x28d143&&_0x28d143['onComplete']&&_0x28d143['onComplete']('permission_denied');}['removeListen_'](_0x39c6f4,_0x46a8e6){const _0x700878=new C(_0x39c6f4)['toString']();let _0x40fde0;if(this['listens']['has'](_0x700878)){const _0x21456d=this['listens']['get'](_0x700878);_0x40fde0=_0x21456d['get'](_0x46a8e6),_0x21456d['delete'](_0x46a8e6),_0x21456d['size']===0x0&&this['listens']['delete'](_0x700878);}else _0x40fde0=void 0x0;return _0x40fde0;}['onAuthRevoked_'](_0x46b431,_0xc2e65b){L('Auth\x20token\x20revoked:\x20'+_0x46b431+'/'+_0xc2e65b),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x46b431==='invalid_token'||_0x46b431==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=Zs&&(this['reconnectDelay_']=Xs,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x5768b2,_0x2b0d50){L('App\x20check\x20token\x20revoked:\x20'+_0x5768b2+'/'+_0x2b0d50),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x5768b2==='invalid_token'||_0x5768b2==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=Zs&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x2195ac){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x2195ac):'msg'in _0x2195ac&&console['log']('FIREBASE:\x20'+_0x2195ac['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x4ca237 of this['listens']['values']())for(const _0x2f6f27 of _0x4ca237['values']())this['sendListen_'](_0x2f6f27);for(let _0xc41a1c=0x0;_0xc41a1c<this['outstandingPuts_']['length'];_0xc41a1c++)this['outstandingPuts_'][_0xc41a1c]&&this['sendPut_'](_0xc41a1c);for(;this['onDisconnectRequestQueue_']['length'];){const _0x1c9296=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x1c9296['action'],_0x1c9296['pathString'],_0x1c9296['data'],_0x1c9296['onComplete']);}for(let _0x100683=0x0;_0x100683<this['outstandingGets_']['length'];_0x100683++)this['outstandingGets_'][_0x100683]&&this['sendGet_'](_0x100683);}['sendConnectStats_'](){const _0x2c1015={};let _0x4bb68e='js';_0x2c1015['sdk.'+_0x4bb68e+'.'+Zr['replace'](/\./g,'-')]=0x1,Li()?_0x2c1015['framework.cordova']=0x1:qr()&&(_0x2c1015['framework.reactnative']=0x1),this['reportStats'](_0x2c1015);}['shouldReconnect_'](){const _0x5f19f1=un['getInstance']()['currentlyOnline']();return hi(this['interruptReasons_'])&&_0x5f19f1;}}ie['nextPersistentConnectionId_']=0x0,ie['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x4155ed,_0x55a6d5){this['name']=_0x4155ed,this['node']=_0x55a6d5;}static['Wrap'](_0x96047b,_0x22677a){return new E(_0x96047b,_0x22677a);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x34d481,_0x315ed1){const _0x241038=new E(xe,_0x34d481),_0x40ab2b=new E(xe,_0x315ed1);return this['compare'](_0x241038,_0x40ab2b)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Xt;class bo extends On{static get['__EMPTY_NODE'](){return Xt;}static set['__EMPTY_NODE'](_0x27e368){Xt=_0x27e368;}['compare'](_0x3614ac,_0x4384c8){return He(_0x3614ac['name'],_0x4384c8['name']);}['isDefinedOn'](_0x503522){throw ot('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x31c22d,_0x12f434){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Xt);}['makePost'](_0x383adc,_0x20f9d0){return f(typeof _0x383adc=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x383adc,Xt);}['toString'](){return'.key';}}const ye=new bo();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x5ecf62,_0x3f09b9,_0x5a3772,_0xa4eae0,_0x569bb2=null){this['isReverse_']=_0xa4eae0,this['resultGenerator_']=_0x569bb2,this['nodeStack_']=[];let _0x44007d=0x1;for(;!_0x5ecf62['isEmpty']();)if(_0x5ecf62=_0x5ecf62,_0x44007d=_0x3f09b9?_0x5a3772(_0x5ecf62['key'],_0x3f09b9):0x1,_0xa4eae0&&(_0x44007d*=-0x1),_0x44007d<0x0)this['isReverse_']?_0x5ecf62=_0x5ecf62['left']:_0x5ecf62=_0x5ecf62['right'];else{if(_0x44007d===0x0){this['nodeStack_']['push'](_0x5ecf62);break;}else this['nodeStack_']['push'](_0x5ecf62),this['isReverse_']?_0x5ecf62=_0x5ecf62['right']:_0x5ecf62=_0x5ecf62['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x315812=this['nodeStack_']['pop'](),_0x5ecbcc;if(this['resultGenerator_']?_0x5ecbcc=this['resultGenerator_'](_0x315812['key'],_0x315812['value']):_0x5ecbcc={'key':_0x315812['key'],'value':_0x315812['value']},this['isReverse_']){for(_0x315812=_0x315812['left'];!_0x315812['isEmpty']();)this['nodeStack_']['push'](_0x315812),_0x315812=_0x315812['right'];}else{for(_0x315812=_0x315812['right'];!_0x315812['isEmpty']();)this['nodeStack_']['push'](_0x315812),_0x315812=_0x315812['left'];}return _0x5ecbcc;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x28fd28=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x28fd28['key'],_0x28fd28['value']):{'key':_0x28fd28['key'],'value':_0x28fd28['value']};}}class M{constructor(_0x1a2192,_0x2a54a7,_0x594264,_0x1ca55f,_0x78a0d5){this['key']=_0x1a2192,this['value']=_0x2a54a7,this['color']=_0x594264??M['RED'],this['left']=_0x1ca55f??B['EMPTY_NODE'],this['right']=_0x78a0d5??B['EMPTY_NODE'];}['copy'](_0x558a4a,_0x1568b4,_0x3270fa,_0x53c3f2,_0x1041fb){return new M(_0x558a4a??this['key'],_0x1568b4??this['value'],_0x3270fa??this['color'],_0x53c3f2??this['left'],_0x1041fb??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x9806e4){return this['left']['inorderTraversal'](_0x9806e4)||!!_0x9806e4(this['key'],this['value'])||this['right']['inorderTraversal'](_0x9806e4);}['reverseTraversal'](_0x3d84e0){return this['right']['reverseTraversal'](_0x3d84e0)||_0x3d84e0(this['key'],this['value'])||this['left']['reverseTraversal'](_0x3d84e0);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x233db9,_0x269862,_0x131989){let _0x38c057=this;const _0x4c8e74=_0x131989(_0x233db9,_0x38c057['key']);return _0x4c8e74<0x0?_0x38c057=_0x38c057['copy'](null,null,null,_0x38c057['left']['insert'](_0x233db9,_0x269862,_0x131989),null):_0x4c8e74===0x0?_0x38c057=_0x38c057['copy'](null,_0x269862,null,null,null):_0x38c057=_0x38c057['copy'](null,null,null,null,_0x38c057['right']['insert'](_0x233db9,_0x269862,_0x131989)),_0x38c057['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x115ca6=this;return!_0x115ca6['left']['isRed_']()&&!_0x115ca6['left']['left']['isRed_']()&&(_0x115ca6=_0x115ca6['moveRedLeft_']()),_0x115ca6=_0x115ca6['copy'](null,null,null,_0x115ca6['left']['removeMin_'](),null),_0x115ca6['fixUp_']();}['remove'](_0x1769d2,_0xcb4295){let _0x2135da,_0x16f840;if(_0x2135da=this,_0xcb4295(_0x1769d2,_0x2135da['key'])<0x0)!_0x2135da['left']['isEmpty']()&&!_0x2135da['left']['isRed_']()&&!_0x2135da['left']['left']['isRed_']()&&(_0x2135da=_0x2135da['moveRedLeft_']()),_0x2135da=_0x2135da['copy'](null,null,null,_0x2135da['left']['remove'](_0x1769d2,_0xcb4295),null);else{if(_0x2135da['left']['isRed_']()&&(_0x2135da=_0x2135da['rotateRight_']()),!_0x2135da['right']['isEmpty']()&&!_0x2135da['right']['isRed_']()&&!_0x2135da['right']['left']['isRed_']()&&(_0x2135da=_0x2135da['moveRedRight_']()),_0xcb4295(_0x1769d2,_0x2135da['key'])===0x0){if(_0x2135da['right']['isEmpty']())return B['EMPTY_NODE'];_0x16f840=_0x2135da['right']['min_'](),_0x2135da=_0x2135da['copy'](_0x16f840['key'],_0x16f840['value'],null,null,_0x2135da['right']['removeMin_']());}_0x2135da=_0x2135da['copy'](null,null,null,null,_0x2135da['right']['remove'](_0x1769d2,_0xcb4295));}return _0x2135da['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x14b7cb=this;return _0x14b7cb['right']['isRed_']()&&!_0x14b7cb['left']['isRed_']()&&(_0x14b7cb=_0x14b7cb['rotateLeft_']()),_0x14b7cb['left']['isRed_']()&&_0x14b7cb['left']['left']['isRed_']()&&(_0x14b7cb=_0x14b7cb['rotateRight_']()),_0x14b7cb['left']['isRed_']()&&_0x14b7cb['right']['isRed_']()&&(_0x14b7cb=_0x14b7cb['colorFlip_']()),_0x14b7cb;}['moveRedLeft_'](){let _0x19eb8f=this['colorFlip_']();return _0x19eb8f['right']['left']['isRed_']()&&(_0x19eb8f=_0x19eb8f['copy'](null,null,null,null,_0x19eb8f['right']['rotateRight_']()),_0x19eb8f=_0x19eb8f['rotateLeft_'](),_0x19eb8f=_0x19eb8f['colorFlip_']()),_0x19eb8f;}['moveRedRight_'](){let _0x2e8baa=this['colorFlip_']();return _0x2e8baa['left']['left']['isRed_']()&&(_0x2e8baa=_0x2e8baa['rotateRight_'](),_0x2e8baa=_0x2e8baa['colorFlip_']()),_0x2e8baa;}['rotateLeft_'](){const _0x4ae43c=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x4ae43c,null);}['rotateRight_'](){const _0x28c2e0=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x28c2e0);}['colorFlip_'](){const _0x2c9f2e=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x5ef15c=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x2c9f2e,_0x5ef15c);}['checkMaxDepth_'](){const _0x39e3b8=this['check_']();return Math['pow'](0x2,_0x39e3b8)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x1aa19c=this['left']['check_']();if(_0x1aa19c!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x1aa19c+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Oh{['copy'](_0x50fbe6,_0x5259e0,_0x437fc6,_0x10234f,_0x45818c){return this;}['insert'](_0xce26ed,_0xbed60b,_0x443d39){return new M(_0xce26ed,_0xbed60b,null);}['remove'](_0x2a8f7a,_0x53ed36){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x3ae719){return!0x1;}['reverseTraversal'](_0x3d75ad){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x356420,_0x238614=B['EMPTY_NODE']){this['comparator_']=_0x356420,this['root_']=_0x238614;}['insert'](_0x4c5d63,_0x4664c6){return new B(this['comparator_'],this['root_']['insert'](_0x4c5d63,_0x4664c6,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x41c2ef){return new B(this['comparator_'],this['root_']['remove'](_0x41c2ef,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x1b4264){let _0x964099,_0xf08da0=this['root_'];for(;!_0xf08da0['isEmpty']();){if(_0x964099=this['comparator_'](_0x1b4264,_0xf08da0['key']),_0x964099===0x0)return _0xf08da0['value'];_0x964099<0x0?_0xf08da0=_0xf08da0['left']:_0x964099>0x0&&(_0xf08da0=_0xf08da0['right']);}return null;}['getPredecessorKey'](_0xfd7a34){let _0x5750e6,_0x1b5a1f=this['root_'],_0x36b377=null;for(;!_0x1b5a1f['isEmpty']();)if(_0x5750e6=this['comparator_'](_0xfd7a34,_0x1b5a1f['key']),_0x5750e6===0x0){if(_0x1b5a1f['left']['isEmpty']())return _0x36b377?_0x36b377['key']:null;for(_0x1b5a1f=_0x1b5a1f['left'];!_0x1b5a1f['right']['isEmpty']();)_0x1b5a1f=_0x1b5a1f['right'];return _0x1b5a1f['key'];}else _0x5750e6<0x0?_0x1b5a1f=_0x1b5a1f['left']:_0x5750e6>0x0&&(_0x36b377=_0x1b5a1f,_0x1b5a1f=_0x1b5a1f['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x49211c){return this['root_']['inorderTraversal'](_0x49211c);}['reverseTraversal'](_0xf6238c){return this['root_']['reverseTraversal'](_0xf6238c);}['getIterator'](_0x92e9b7){return new Zt(this['root_'],null,this['comparator_'],!0x1,_0x92e9b7);}['getIteratorFrom'](_0x4cb6dc,_0x166706){return new Zt(this['root_'],_0x4cb6dc,this['comparator_'],!0x1,_0x166706);}['getReverseIteratorFrom'](_0x47c5e8,_0x1d61a6){return new Zt(this['root_'],_0x47c5e8,this['comparator_'],!0x0,_0x1d61a6);}['getReverseIterator'](_0x98a269){return new Zt(this['root_'],null,this['comparator_'],!0x0,_0x98a269);}}B['EMPTY_NODE']=new Oh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dh(_0x56bf99,_0x487599){return He(_0x56bf99['name'],_0x487599['name']);}function ji(_0x2199ec,_0x452b75){return He(_0x2199ec,_0x452b75);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let vi;function Mh(_0x1f3187){vi=_0x1f3187;}const Ro=function(_0x572d2f){return typeof _0x572d2f=='number'?'number:'+so(_0x572d2f):'string:'+_0x572d2f;},Ao=function(_0x399640){if(_0x399640['isLeafNode']()){const _0x35a507=_0x399640['val']();f(typeof _0x35a507=='string'||typeof _0x35a507=='number'||typeof _0x35a507=='object'&&Y(_0x35a507,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x399640===vi||_0x399640['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x399640===vi||_0x399640['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let er;class D{static set['__childrenNodeConstructor'](_0xabc204){er=_0xabc204;}static get['__childrenNodeConstructor'](){return er;}constructor(_0x2f9637,_0x1c88c5=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x2f9637,this['priorityNode_']=_0x1c88c5,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Ao(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x573aaf){return new D(this['value_'],_0x573aaf);}['getImmediateChild'](_0x4a988b){return _0x4a988b==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x551ce1){return v(_0x551ce1)?this:y(_0x551ce1)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x145d12,_0xa78fc8){return null;}['updateImmediateChild'](_0xef1071,_0x332d5d){return _0xef1071==='.priority'?this['updatePriority'](_0x332d5d):_0x332d5d['isEmpty']()&&_0xef1071!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0xef1071,_0x332d5d)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x4c8335,_0x2612ca){const _0x108baa=y(_0x4c8335);return _0x108baa===null?_0x2612ca:_0x2612ca['isEmpty']()&&_0x108baa!=='.priority'?this:(f(_0x108baa!=='.priority'||we(_0x4c8335)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x108baa,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x4c8335),_0x2612ca)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x3defcf,_0xcbec1e){return!0x1;}['val'](_0x4c16d9){return _0x4c16d9&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x1ddcb1='';this['priorityNode_']['isEmpty']()||(_0x1ddcb1+='priority:'+Ro(this['priorityNode_']['val']())+':');const _0x244e15=typeof this['value_'];_0x1ddcb1+=_0x244e15+':',_0x244e15==='number'?_0x1ddcb1+=so(this['value_']):_0x1ddcb1+=this['value_'],this['lazyHash_']=no(_0x1ddcb1);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x19552f){return _0x19552f===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x19552f instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x19552f['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x19552f));}['compareToLeafNode_'](_0x3160ec){const _0x275b53=typeof _0x3160ec['value_'],_0x4865c8=typeof this['value_'],_0x125883=D['VALUE_TYPE_ORDER']['indexOf'](_0x275b53),_0x44f676=D['VALUE_TYPE_ORDER']['indexOf'](_0x4865c8);return f(_0x125883>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x275b53),f(_0x44f676>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x4865c8),_0x125883===_0x44f676?_0x4865c8==='object'?0x0:this['value_']<_0x3160ec['value_']?-0x1:this['value_']===_0x3160ec['value_']?0x0:0x1:_0x44f676-_0x125883;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x3ad359){if(_0x3ad359===this)return!0x0;if(_0x3ad359['isLeafNode']()){const _0x145c97=_0x3ad359;return this['value_']===_0x145c97['value_']&&this['priorityNode_']['equals'](_0x145c97['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ko,No;function Lh(_0x160526){ko=_0x160526;}function xh(_0x3b44bb){No=_0x3b44bb;}class Fh extends On{['compare'](_0x3fd497,_0x169cce){const _0x5291c6=_0x3fd497['node']['getPriority'](),_0x4d6c13=_0x169cce['node']['getPriority'](),_0x3c208a=_0x5291c6['compareTo'](_0x4d6c13);return _0x3c208a===0x0?He(_0x3fd497['name'],_0x169cce['name']):_0x3c208a;}['isDefinedOn'](_0x5e03b4){return!_0x5e03b4['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x203672,_0x2ded3d){return!_0x203672['getPriority']()['equals'](_0x2ded3d['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',No));}['makePost'](_0x1003ae,_0x4c55df){const _0x4f992b=ko(_0x1003ae);return new E(_0x4c55df,new D('[PRIORITY-POST]',_0x4f992b));}['toString'](){return'.priority';}}const R=new Fh(),Uh=Math['log'](0x2);class Wh{constructor(_0x54e4e9){const _0x44bc5c=_0x473bb9=>parseInt(Math['log'](_0x473bb9)/Uh,0xa),_0x1d7fc9=_0x5ee9e3=>parseInt(Array(_0x5ee9e3+0x1)['join']('1'),0x2);this['count']=_0x44bc5c(_0x54e4e9+0x1),this['current_']=this['count']-0x1;const _0x48afd0=_0x1d7fc9(this['count']);this['bits_']=_0x54e4e9+0x1&_0x48afd0;}['nextBitIsOne'](){const _0x580095=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x580095;}}const dn=function(_0x4bb825,_0x32c4b9,_0x31a61f,_0x470064){_0x4bb825['sort'](_0x32c4b9);const _0x26fa18=function(_0x3b68e9,_0x42f6bb){const _0x3d73c6=_0x42f6bb-_0x3b68e9;let _0x4a0190,_0xcec81e;if(_0x3d73c6===0x0)return null;if(_0x3d73c6===0x1)return _0x4a0190=_0x4bb825[_0x3b68e9],_0xcec81e=_0x31a61f?_0x31a61f(_0x4a0190):_0x4a0190,new M(_0xcec81e,_0x4a0190['node'],M['BLACK'],null,null);{const _0x44b070=parseInt(_0x3d73c6/0x2,0xa)+_0x3b68e9,_0xc77639=_0x26fa18(_0x3b68e9,_0x44b070),_0x20311d=_0x26fa18(_0x44b070+0x1,_0x42f6bb);return _0x4a0190=_0x4bb825[_0x44b070],_0xcec81e=_0x31a61f?_0x31a61f(_0x4a0190):_0x4a0190,new M(_0xcec81e,_0x4a0190['node'],M['BLACK'],_0xc77639,_0x20311d);}},_0x433fb9=function(_0x8e0d71){let _0x16ce2c=null,_0x4ac8a2=null,_0x5427c7=_0x4bb825['length'];const _0x1a0d00=function(_0x27a708,_0x2818d1){const _0x14e982=_0x5427c7-_0x27a708,_0xabf488=_0x5427c7;_0x5427c7-=_0x27a708;const _0x54276e=_0x26fa18(_0x14e982+0x1,_0xabf488),_0x3ecbee=_0x4bb825[_0x14e982],_0x26768a=_0x31a61f?_0x31a61f(_0x3ecbee):_0x3ecbee;_0x52fd0f(new M(_0x26768a,_0x3ecbee['node'],_0x2818d1,null,_0x54276e));},_0x52fd0f=function(_0x5b3d81){_0x16ce2c?(_0x16ce2c['left']=_0x5b3d81,_0x16ce2c=_0x5b3d81):(_0x4ac8a2=_0x5b3d81,_0x16ce2c=_0x5b3d81);};for(let _0x6a33bc=0x0;_0x6a33bc<_0x8e0d71['count'];++_0x6a33bc){const _0x822e94=_0x8e0d71['nextBitIsOne'](),_0xff0d09=Math['pow'](0x2,_0x8e0d71['count']-(_0x6a33bc+0x1));_0x822e94?_0x1a0d00(_0xff0d09,M['BLACK']):(_0x1a0d00(_0xff0d09,M['BLACK']),_0x1a0d00(_0xff0d09,M['RED']));}return _0x4ac8a2;},_0x10b41f=new Wh(_0x4bb825['length']),_0x3287b3=_0x433fb9(_0x10b41f);return new B(_0x470064||_0x32c4b9,_0x3287b3);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let si;const je={};class ee{static get['Default'](){return f(je&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),si=si||new ee({'.priority':je},{'.priority':R}),si;}constructor(_0x2ee582,_0x20c11b){this['indexes_']=_0x2ee582,this['indexSet_']=_0x20c11b;}['get'](_0x4cc96f){const _0x2f2e57=Oe(this['indexes_'],_0x4cc96f);if(!_0x2f2e57)throw new Error('No\x20index\x20defined\x20for\x20'+_0x4cc96f);return _0x2f2e57 instanceof B?_0x2f2e57:null;}['hasIndex'](_0x594610){return Y(this['indexSet_'],_0x594610['toString']());}['addIndex'](_0x2913e7,_0x3695d6){f(_0x2913e7!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x1edfd0=[];let _0x40219e=!0x1;const _0x521b63=_0x3695d6['getIterator'](E['Wrap']);let _0x5265eb=_0x521b63['getNext']();for(;_0x5265eb;)_0x40219e=_0x40219e||_0x2913e7['isDefinedOn'](_0x5265eb['node']),_0x1edfd0['push'](_0x5265eb),_0x5265eb=_0x521b63['getNext']();let _0xb5b86d;_0x40219e?_0xb5b86d=dn(_0x1edfd0,_0x2913e7['getCompare']()):_0xb5b86d=je;const _0x2a8c81=_0x2913e7['toString'](),_0x3a7561={...this['indexSet_']};_0x3a7561[_0x2a8c81]=_0x2913e7;const _0x1641ae={...this['indexes_']};return _0x1641ae[_0x2a8c81]=_0xb5b86d,new ee(_0x1641ae,_0x3a7561);}['addToIndexes'](_0x3a6e5e,_0x4c1441){const _0x117b6c=ln(this['indexes_'],(_0x29d61c,_0x587a6c)=>{const _0x5c08b7=Oe(this['indexSet_'],_0x587a6c);if(f(_0x5c08b7,'Missing\x20index\x20implementation\x20for\x20'+_0x587a6c),_0x29d61c===je){if(_0x5c08b7['isDefinedOn'](_0x3a6e5e['node'])){const _0x17ff42=[],_0x43a343=_0x4c1441['getIterator'](E['Wrap']);let _0x2e940a=_0x43a343['getNext']();for(;_0x2e940a;)_0x2e940a['name']!==_0x3a6e5e['name']&&_0x17ff42['push'](_0x2e940a),_0x2e940a=_0x43a343['getNext']();return _0x17ff42['push'](_0x3a6e5e),dn(_0x17ff42,_0x5c08b7['getCompare']());}else return je;}else{const _0xdd7cee=_0x4c1441['get'](_0x3a6e5e['name']);let _0x465ca1=_0x29d61c;return _0xdd7cee&&(_0x465ca1=_0x465ca1['remove'](new E(_0x3a6e5e['name'],_0xdd7cee))),_0x465ca1['insert'](_0x3a6e5e,_0x3a6e5e['node']);}});return new ee(_0x117b6c,this['indexSet_']);}['removeFromIndexes'](_0x4d3c78,_0x146ee8){const _0x491d12=ln(this['indexes_'],_0x39b555=>{if(_0x39b555===je)return _0x39b555;{const _0x1ba179=_0x146ee8['get'](_0x4d3c78['name']);return _0x1ba179?_0x39b555['remove'](new E(_0x4d3c78['name'],_0x1ba179)):_0x39b555;}});return new ee(_0x491d12,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let gt;class g{static get['EMPTY_NODE'](){return gt||(gt=new g(new B(ji),null,ee['Default']));}constructor(_0x85806b,_0x301405,_0x43c029){this['children_']=_0x85806b,this['priorityNode_']=_0x301405,this['indexMap_']=_0x43c029,this['lazyHash_']=null,this['priorityNode_']&&Ao(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||gt;}['updatePriority'](_0x1e1c27){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x1e1c27,this['indexMap_']);}['getImmediateChild'](_0x24fa45){if(_0x24fa45==='.priority')return this['getPriority']();{const _0x28ab6a=this['children_']['get'](_0x24fa45);return _0x28ab6a===null?gt:_0x28ab6a;}}['getChild'](_0x4b4415){const _0x132aca=y(_0x4b4415);return _0x132aca===null?this:this['getImmediateChild'](_0x132aca)['getChild'](b(_0x4b4415));}['hasChild'](_0x3a3e26){return this['children_']['get'](_0x3a3e26)!==null;}['updateImmediateChild'](_0x4bb0d3,_0x4aa0a5){if(f(_0x4aa0a5,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x4bb0d3==='.priority')return this['updatePriority'](_0x4aa0a5);{const _0x396a85=new E(_0x4bb0d3,_0x4aa0a5);let _0x275d38,_0x803b0b;_0x4aa0a5['isEmpty']()?(_0x275d38=this['children_']['remove'](_0x4bb0d3),_0x803b0b=this['indexMap_']['removeFromIndexes'](_0x396a85,this['children_'])):(_0x275d38=this['children_']['insert'](_0x4bb0d3,_0x4aa0a5),_0x803b0b=this['indexMap_']['addToIndexes'](_0x396a85,this['children_']));const _0x239ec3=_0x275d38['isEmpty']()?gt:this['priorityNode_'];return new g(_0x275d38,_0x239ec3,_0x803b0b);}}['updateChild'](_0x2e04d5,_0x3a8ea8){const _0x2a17f2=y(_0x2e04d5);if(_0x2a17f2===null)return _0x3a8ea8;{f(y(_0x2e04d5)!=='.priority'||we(_0x2e04d5)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x1bb745=this['getImmediateChild'](_0x2a17f2)['updateChild'](b(_0x2e04d5),_0x3a8ea8);return this['updateImmediateChild'](_0x2a17f2,_0x1bb745);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x30a07a){if(this['isEmpty']())return null;const _0x4df0da={};let _0x3f9d89=0x0,_0x2a9c8b=0x0,_0x363f45=!0x0;if(this['forEachChild'](R,(_0x33cb6b,_0x10a7ed)=>{_0x4df0da[_0x33cb6b]=_0x10a7ed['val'](_0x30a07a),_0x3f9d89++,_0x363f45&&g['INTEGER_REGEXP_']['test'](_0x33cb6b)?_0x2a9c8b=Math['max'](_0x2a9c8b,Number(_0x33cb6b)):_0x363f45=!0x1;}),!_0x30a07a&&_0x363f45&&_0x2a9c8b<0x2*_0x3f9d89){const _0x330afc=[];for(const _0x142c42 in _0x4df0da)_0x330afc[_0x142c42]=_0x4df0da[_0x142c42];return _0x330afc;}else return _0x30a07a&&!this['getPriority']()['isEmpty']()&&(_0x4df0da['.priority']=this['getPriority']()['val']()),_0x4df0da;}['hash'](){if(this['lazyHash_']===null){let _0x394c84='';this['getPriority']()['isEmpty']()||(_0x394c84+='priority:'+Ro(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0xadb27,_0x3fa770)=>{const _0x31d042=_0x3fa770['hash']();_0x31d042!==''&&(_0x394c84+=':'+_0xadb27+':'+_0x31d042);}),this['lazyHash_']=_0x394c84===''?'':no(_0x394c84);}return this['lazyHash_'];}['getPredecessorChildName'](_0x3a9f33,_0x1bd435,_0x75d00a){const _0x1cb080=this['resolveIndex_'](_0x75d00a);if(_0x1cb080){const _0x558a9c=_0x1cb080['getPredecessorKey'](new E(_0x3a9f33,_0x1bd435));return _0x558a9c?_0x558a9c['name']:null;}else return this['children_']['getPredecessorKey'](_0x3a9f33);}['getFirstChildName'](_0x3558f0){const _0x10de7e=this['resolveIndex_'](_0x3558f0);if(_0x10de7e){const _0x42458b=_0x10de7e['minKey']();return _0x42458b&&_0x42458b['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x4792f1){const _0x37432f=this['getFirstChildName'](_0x4792f1);return _0x37432f?new E(_0x37432f,this['children_']['get'](_0x37432f)):null;}['getLastChildName'](_0x4c1da7){const _0x3c1f13=this['resolveIndex_'](_0x4c1da7);if(_0x3c1f13){const _0x122d0e=_0x3c1f13['maxKey']();return _0x122d0e&&_0x122d0e['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x4bb66b){const _0x157af3=this['getLastChildName'](_0x4bb66b);return _0x157af3?new E(_0x157af3,this['children_']['get'](_0x157af3)):null;}['forEachChild'](_0xb3859d,_0x1e4324){const _0x2eb6a4=this['resolveIndex_'](_0xb3859d);return _0x2eb6a4?_0x2eb6a4['inorderTraversal'](_0x4dc5ac=>_0x1e4324(_0x4dc5ac['name'],_0x4dc5ac['node'])):this['children_']['inorderTraversal'](_0x1e4324);}['getIterator'](_0x3f50ff){return this['getIteratorFrom'](_0x3f50ff['minPost'](),_0x3f50ff);}['getIteratorFrom'](_0x29aec2,_0x99b957){const _0x31e908=this['resolveIndex_'](_0x99b957);if(_0x31e908)return _0x31e908['getIteratorFrom'](_0x29aec2,_0x1b2948=>_0x1b2948);{const _0xcc2522=this['children_']['getIteratorFrom'](_0x29aec2['name'],E['Wrap']);let _0x466214=_0xcc2522['peek']();for(;_0x466214!=null&&_0x99b957['compare'](_0x466214,_0x29aec2)<0x0;)_0xcc2522['getNext'](),_0x466214=_0xcc2522['peek']();return _0xcc2522;}}['getReverseIterator'](_0xc619a9){return this['getReverseIteratorFrom'](_0xc619a9['maxPost'](),_0xc619a9);}['getReverseIteratorFrom'](_0xed7a97,_0x561926){const _0x2fa93f=this['resolveIndex_'](_0x561926);if(_0x2fa93f)return _0x2fa93f['getReverseIteratorFrom'](_0xed7a97,_0x308132=>_0x308132);{const _0x1b6c20=this['children_']['getReverseIteratorFrom'](_0xed7a97['name'],E['Wrap']);let _0x52e4e7=_0x1b6c20['peek']();for(;_0x52e4e7!=null&&_0x561926['compare'](_0x52e4e7,_0xed7a97)>0x0;)_0x1b6c20['getNext'](),_0x52e4e7=_0x1b6c20['peek']();return _0x1b6c20;}}['compareTo'](_0x23918a){return this['isEmpty']()?_0x23918a['isEmpty']()?0x0:-0x1:_0x23918a['isLeafNode']()||_0x23918a['isEmpty']()?0x1:_0x23918a===Ht?-0x1:0x0;}['withIndex'](_0x45e6f7){if(_0x45e6f7===ye||this['indexMap_']['hasIndex'](_0x45e6f7))return this;{const _0x2e7f1a=this['indexMap_']['addIndex'](_0x45e6f7,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x2e7f1a);}}['isIndexed'](_0x4f9026){return _0x4f9026===ye||this['indexMap_']['hasIndex'](_0x4f9026);}['equals'](_0x4b9ada){if(_0x4b9ada===this)return!0x0;if(_0x4b9ada['isLeafNode']())return!0x1;{const _0x5890b2=_0x4b9ada;if(this['getPriority']()['equals'](_0x5890b2['getPriority']())){if(this['children_']['count']()===_0x5890b2['children_']['count']()){const _0x46a3a0=this['getIterator'](R),_0x2bcc65=_0x5890b2['getIterator'](R);let _0x5bc619=_0x46a3a0['getNext'](),_0x377717=_0x2bcc65['getNext']();for(;_0x5bc619&&_0x377717;){if(_0x5bc619['name']!==_0x377717['name']||!_0x5bc619['node']['equals'](_0x377717['node']))return!0x1;_0x5bc619=_0x46a3a0['getNext'](),_0x377717=_0x2bcc65['getNext']();}return _0x5bc619===null&&_0x377717===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x441dca){return _0x441dca===ye?null:this['indexMap_']['get'](_0x441dca['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class Bh extends g{constructor(){super(new B(ji),g['EMPTY_NODE'],ee['Default']);}['compareTo'](_0x53d3d6){return _0x53d3d6===this?0x0:0x1;}['equals'](_0x160eca){return _0x160eca===this;}['getPriority'](){return this;}['getImmediateChild'](_0x38d704){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Ht=new Bh();Object['defineProperties'](E,{'MIN':{'value':new E(xe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,Ht)}}),bo['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Mh(Ht),xh(Ht);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vh=!0x0;function N(_0x149cef,_0x4b2e89=null){if(_0x149cef===null)return g['EMPTY_NODE'];if(typeof _0x149cef=='object'&&'.priority'in _0x149cef&&(_0x4b2e89=_0x149cef['.priority']),f(_0x4b2e89===null||typeof _0x4b2e89=='string'||typeof _0x4b2e89=='number'||typeof _0x4b2e89=='object'&&'.sv'in _0x4b2e89,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x4b2e89),typeof _0x149cef=='object'&&'.value'in _0x149cef&&_0x149cef['.value']!==null&&(_0x149cef=_0x149cef['.value']),typeof _0x149cef!='object'||'.sv'in _0x149cef){const _0x24b04f=_0x149cef;return new D(_0x24b04f,N(_0x4b2e89));}if(!(_0x149cef instanceof Array)&&Vh){const _0x1b2183=[];let _0x118b5e=!0x1;if(x(_0x149cef,(_0x59fe42,_0x1117ed)=>{if(_0x59fe42['substring'](0x0,0x1)!=='.'){const _0x38167f=N(_0x1117ed);_0x38167f['isEmpty']()||(_0x118b5e=_0x118b5e||!_0x38167f['getPriority']()['isEmpty'](),_0x1b2183['push'](new E(_0x59fe42,_0x38167f)));}}),_0x1b2183['length']===0x0)return g['EMPTY_NODE'];const _0x30651e=dn(_0x1b2183,Dh,_0xd8236f=>_0xd8236f['name'],ji);if(_0x118b5e){const _0x53bc2c=dn(_0x1b2183,R['getCompare']());return new g(_0x30651e,N(_0x4b2e89),new ee({'.priority':_0x53bc2c},{'.priority':R}));}else return new g(_0x30651e,N(_0x4b2e89),ee['Default']);}else{let _0x364a7a=g['EMPTY_NODE'];return x(_0x149cef,(_0x47cb9f,_0x19af28)=>{if(Y(_0x149cef,_0x47cb9f)&&_0x47cb9f['substring'](0x0,0x1)!=='.'){const _0x349190=N(_0x19af28);(_0x349190['isLeafNode']()||!_0x349190['isEmpty']())&&(_0x364a7a=_0x364a7a['updateImmediateChild'](_0x47cb9f,_0x349190));}}),_0x364a7a['updatePriority'](N(_0x4b2e89));}}Lh(N);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends On{constructor(_0x2ebac7){super(),this['indexPath_']=_0x2ebac7,f(!v(_0x2ebac7)&&y(_0x2ebac7)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x67e457){return _0x67e457['getChild'](this['indexPath_']);}['isDefinedOn'](_0x15effa){return!_0x15effa['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0xd7685f,_0x138637){const _0xb8b4f5=this['extractChild'](_0xd7685f['node']),_0x511438=this['extractChild'](_0x138637['node']),_0x1dc9cf=_0xb8b4f5['compareTo'](_0x511438);return _0x1dc9cf===0x0?He(_0xd7685f['name'],_0x138637['name']):_0x1dc9cf;}['makePost'](_0x25f25d,_0x1b5537){const _0x136f9c=N(_0x25f25d),_0x37181b=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x136f9c);return new E(_0x1b5537,_0x37181b);}['maxPost'](){const _0xed46cb=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Ht);return new E(Ie,_0xed46cb);}['toString'](){return kt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Hh extends On{['compare'](_0x1b9151,_0xbbf15f){const _0x2908aa=_0x1b9151['node']['compareTo'](_0xbbf15f['node']);return _0x2908aa===0x0?He(_0x1b9151['name'],_0xbbf15f['name']):_0x2908aa;}['isDefinedOn'](_0x1ef1cd){return!0x0;}['indexedValueChanged'](_0xfed67d,_0xad084d){return!_0xfed67d['equals'](_0xad084d);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x2c664d,_0x48037c){const _0x1c347b=N(_0x2c664d);return new E(_0x48037c,_0x1c347b);}['toString'](){return'.value';}}const Po=new Hh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oo(_0x4b4bbd){return{'type':'value','snapshotNode':_0x4b4bbd};}function tt(_0x240034,_0x14fff0){return{'type':'child_added','snapshotNode':_0x14fff0,'childName':_0x240034};}function Nt(_0x512575,_0x3e9da9){return{'type':'child_removed','snapshotNode':_0x3e9da9,'childName':_0x512575};}function Pt(_0x35a936,_0x245a2f,_0xf327c7){return{'type':'child_changed','snapshotNode':_0x245a2f,'childName':_0x35a936,'oldSnap':_0xf327c7};}function $h(_0x377250,_0x1ecc06){return{'type':'child_moved','snapshotNode':_0x1ecc06,'childName':_0x377250};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi{constructor(_0x485b9f){this['index_']=_0x485b9f;}['updateChild'](_0x46dc60,_0x4a2536,_0x3df878,_0x1d3b5e,_0x2f5d16,_0x3fb4ba){f(_0x46dc60['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x58adea=_0x46dc60['getImmediateChild'](_0x4a2536);return _0x58adea['getChild'](_0x1d3b5e)['equals'](_0x3df878['getChild'](_0x1d3b5e))&&_0x58adea['isEmpty']()===_0x3df878['isEmpty']()||(_0x3fb4ba!=null&&(_0x3df878['isEmpty']()?_0x46dc60['hasChild'](_0x4a2536)?_0x3fb4ba['trackChildChange'](Nt(_0x4a2536,_0x58adea)):f(_0x46dc60['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x58adea['isEmpty']()?_0x3fb4ba['trackChildChange'](tt(_0x4a2536,_0x3df878)):_0x3fb4ba['trackChildChange'](Pt(_0x4a2536,_0x3df878,_0x58adea))),_0x46dc60['isLeafNode']()&&_0x3df878['isEmpty']())?_0x46dc60:_0x46dc60['updateImmediateChild'](_0x4a2536,_0x3df878)['withIndex'](this['index_']);}['updateFullNode'](_0x4105fc,_0x50ccff,_0x3b6bb1){return _0x3b6bb1!=null&&(_0x4105fc['isLeafNode']()||_0x4105fc['forEachChild'](R,(_0x12d0b8,_0x56f4fa)=>{_0x50ccff['hasChild'](_0x12d0b8)||_0x3b6bb1['trackChildChange'](Nt(_0x12d0b8,_0x56f4fa));}),_0x50ccff['isLeafNode']()||_0x50ccff['forEachChild'](R,(_0x4960db,_0x1568d5)=>{if(_0x4105fc['hasChild'](_0x4960db)){const _0x4d0489=_0x4105fc['getImmediateChild'](_0x4960db);_0x4d0489['equals'](_0x1568d5)||_0x3b6bb1['trackChildChange'](Pt(_0x4960db,_0x1568d5,_0x4d0489));}else _0x3b6bb1['trackChildChange'](tt(_0x4960db,_0x1568d5));})),_0x50ccff['withIndex'](this['index_']);}['updatePriority'](_0x418e7a,_0x3bfe80){return _0x418e7a['isEmpty']()?g['EMPTY_NODE']:_0x418e7a['updatePriority'](_0x3bfe80);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ot{constructor(_0x415b70){this['indexedFilter_']=new Yi(_0x415b70['getIndex']()),this['index_']=_0x415b70['getIndex'](),this['startPost_']=Ot['getStartPost_'](_0x415b70),this['endPost_']=Ot['getEndPost_'](_0x415b70),this['startIsInclusive_']=!_0x415b70['startAfterSet_'],this['endIsInclusive_']=!_0x415b70['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x267fc2){const _0x279527=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x267fc2)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x267fc2)<0x0,_0x3ff69d=this['endIsInclusive_']?this['index_']['compare'](_0x267fc2,this['getEndPost']())<=0x0:this['index_']['compare'](_0x267fc2,this['getEndPost']())<0x0;return _0x279527&&_0x3ff69d;}['updateChild'](_0x4194bc,_0x16d188,_0x23727c,_0x1935a8,_0x232962,_0x371723){return this['matches'](new E(_0x16d188,_0x23727c))||(_0x23727c=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x4194bc,_0x16d188,_0x23727c,_0x1935a8,_0x232962,_0x371723);}['updateFullNode'](_0x544e8b,_0x18f511,_0x114fa1){_0x18f511['isLeafNode']()&&(_0x18f511=g['EMPTY_NODE']);let _0x53f428=_0x18f511['withIndex'](this['index_']);_0x53f428=_0x53f428['updatePriority'](g['EMPTY_NODE']);const _0x2b6da5=this;return _0x18f511['forEachChild'](R,(_0x216c48,_0x55e021)=>{_0x2b6da5['matches'](new E(_0x216c48,_0x55e021))||(_0x53f428=_0x53f428['updateImmediateChild'](_0x216c48,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x544e8b,_0x53f428,_0x114fa1);}['updatePriority'](_0x350d9f,_0x2e833b){return _0x350d9f;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x4ec9b3){if(_0x4ec9b3['hasStart']()){const _0x2a4981=_0x4ec9b3['getIndexStartName']();return _0x4ec9b3['getIndex']()['makePost'](_0x4ec9b3['getIndexStartValue'](),_0x2a4981);}else return _0x4ec9b3['getIndex']()['minPost']();}static['getEndPost_'](_0x5121ba){if(_0x5121ba['hasEnd']()){const _0x300c8f=_0x5121ba['getIndexEndName']();return _0x5121ba['getIndex']()['makePost'](_0x5121ba['getIndexEndValue'](),_0x300c8f);}else return _0x5121ba['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Gh{constructor(_0x37de0a){this['withinDirectionalStart']=_0x505b97=>this['reverse_']?this['withinEndPost'](_0x505b97):this['withinStartPost'](_0x505b97),this['withinDirectionalEnd']=_0x9ad087=>this['reverse_']?this['withinStartPost'](_0x9ad087):this['withinEndPost'](_0x9ad087),this['withinStartPost']=_0x328a03=>{const _0x29938d=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x328a03);return this['startIsInclusive_']?_0x29938d<=0x0:_0x29938d<0x0;},this['withinEndPost']=_0x549b8d=>{const _0x519ae2=this['index_']['compare'](_0x549b8d,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x519ae2<=0x0:_0x519ae2<0x0;},this['rangedFilter_']=new Ot(_0x37de0a),this['index_']=_0x37de0a['getIndex'](),this['limit_']=_0x37de0a['getLimit'](),this['reverse_']=!_0x37de0a['isViewFromLeft'](),this['startIsInclusive_']=!_0x37de0a['startAfterSet_'],this['endIsInclusive_']=!_0x37de0a['endBeforeSet_'];}['updateChild'](_0x5db30e,_0x332dd2,_0x38bfe4,_0x109506,_0x343d7c,_0x5bc2b3){return this['rangedFilter_']['matches'](new E(_0x332dd2,_0x38bfe4))||(_0x38bfe4=g['EMPTY_NODE']),_0x5db30e['getImmediateChild'](_0x332dd2)['equals'](_0x38bfe4)?_0x5db30e:_0x5db30e['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x5db30e,_0x332dd2,_0x38bfe4,_0x109506,_0x343d7c,_0x5bc2b3):this['fullLimitUpdateChild_'](_0x5db30e,_0x332dd2,_0x38bfe4,_0x343d7c,_0x5bc2b3);}['updateFullNode'](_0x4e860a,_0x12dee2,_0xcdd78e){let _0xa5041;if(_0x12dee2['isLeafNode']()||_0x12dee2['isEmpty']())_0xa5041=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x12dee2['numChildren']()&&_0x12dee2['isIndexed'](this['index_'])){_0xa5041=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x29be7a;this['reverse_']?_0x29be7a=_0x12dee2['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x29be7a=_0x12dee2['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x2472b1=0x0;for(;_0x29be7a['hasNext']()&&_0x2472b1<this['limit_'];){const _0x38806f=_0x29be7a['getNext']();if(this['withinDirectionalStart'](_0x38806f)){if(this['withinDirectionalEnd'](_0x38806f))_0xa5041=_0xa5041['updateImmediateChild'](_0x38806f['name'],_0x38806f['node']),_0x2472b1++;else break;}else continue;}}else{_0xa5041=_0x12dee2['withIndex'](this['index_']),_0xa5041=_0xa5041['updatePriority'](g['EMPTY_NODE']);let _0x57c8d3;this['reverse_']?_0x57c8d3=_0xa5041['getReverseIterator'](this['index_']):_0x57c8d3=_0xa5041['getIterator'](this['index_']);let _0x1ce3b0=0x0;for(;_0x57c8d3['hasNext']();){const _0x62019a=_0x57c8d3['getNext']();_0x1ce3b0<this['limit_']&&this['withinDirectionalStart'](_0x62019a)&&this['withinDirectionalEnd'](_0x62019a)?_0x1ce3b0++:_0xa5041=_0xa5041['updateImmediateChild'](_0x62019a['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x4e860a,_0xa5041,_0xcdd78e);}['updatePriority'](_0x2e44e5,_0x2a8a9c){return _0x2e44e5;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0xf6c4e8,_0xde905d,_0x100e52,_0x2c33ca,_0x926315){let _0xbeabe1;if(this['reverse_']){const _0x18e3f0=this['index_']['getCompare']();_0xbeabe1=(_0x2e7229,_0x44c043)=>_0x18e3f0(_0x44c043,_0x2e7229);}else _0xbeabe1=this['index_']['getCompare']();const _0x362a7c=_0xf6c4e8;f(_0x362a7c['numChildren']()===this['limit_'],'');const _0x12539c=new E(_0xde905d,_0x100e52),_0x129468=this['reverse_']?_0x362a7c['getFirstChild'](this['index_']):_0x362a7c['getLastChild'](this['index_']),_0xa5b2cc=this['rangedFilter_']['matches'](_0x12539c);if(_0x362a7c['hasChild'](_0xde905d)){const _0x545d33=_0x362a7c['getImmediateChild'](_0xde905d);let _0x1dd1b2=_0x2c33ca['getChildAfterChild'](this['index_'],_0x129468,this['reverse_']);for(;_0x1dd1b2!=null&&(_0x1dd1b2['name']===_0xde905d||_0x362a7c['hasChild'](_0x1dd1b2['name']));)_0x1dd1b2=_0x2c33ca['getChildAfterChild'](this['index_'],_0x1dd1b2,this['reverse_']);const _0x3c91f2=_0x1dd1b2==null?0x1:_0xbeabe1(_0x1dd1b2,_0x12539c);if(_0xa5b2cc&&!_0x100e52['isEmpty']()&&_0x3c91f2>=0x0)return _0x926315!=null&&_0x926315['trackChildChange'](Pt(_0xde905d,_0x100e52,_0x545d33)),_0x362a7c['updateImmediateChild'](_0xde905d,_0x100e52);{_0x926315!=null&&_0x926315['trackChildChange'](Nt(_0xde905d,_0x545d33));const _0x460ff9=_0x362a7c['updateImmediateChild'](_0xde905d,g['EMPTY_NODE']);return _0x1dd1b2!=null&&this['rangedFilter_']['matches'](_0x1dd1b2)?(_0x926315!=null&&_0x926315['trackChildChange'](tt(_0x1dd1b2['name'],_0x1dd1b2['node'])),_0x460ff9['updateImmediateChild'](_0x1dd1b2['name'],_0x1dd1b2['node'])):_0x460ff9;}}else return _0x100e52['isEmpty']()?_0xf6c4e8:_0xa5b2cc&&_0xbeabe1(_0x129468,_0x12539c)>=0x0?(_0x926315!=null&&(_0x926315['trackChildChange'](Nt(_0x129468['name'],_0x129468['node'])),_0x926315['trackChildChange'](tt(_0xde905d,_0x100e52))),_0x362a7c['updateImmediateChild'](_0xde905d,_0x100e52)['updateImmediateChild'](_0x129468['name'],g['EMPTY_NODE'])):_0xf6c4e8;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:xe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x3795a7=new Qi();return _0x3795a7['limitSet_']=this['limitSet_'],_0x3795a7['limit_']=this['limit_'],_0x3795a7['startSet_']=this['startSet_'],_0x3795a7['startAfterSet_']=this['startAfterSet_'],_0x3795a7['indexStartValue_']=this['indexStartValue_'],_0x3795a7['startNameSet_']=this['startNameSet_'],_0x3795a7['indexStartName_']=this['indexStartName_'],_0x3795a7['endSet_']=this['endSet_'],_0x3795a7['endBeforeSet_']=this['endBeforeSet_'],_0x3795a7['indexEndValue_']=this['indexEndValue_'],_0x3795a7['endNameSet_']=this['endNameSet_'],_0x3795a7['indexEndName_']=this['indexEndName_'],_0x3795a7['index_']=this['index_'],_0x3795a7['viewFrom_']=this['viewFrom_'],_0x3795a7;}}function qh(_0x126200){return _0x126200['loadsAllData']()?new Yi(_0x126200['getIndex']()):_0x126200['hasLimit']()?new Gh(_0x126200):new Ot(_0x126200);}function zh(_0x5016b5,_0x44c968){const _0x5d5609=_0x5016b5['copy']();return _0x5d5609['limitSet_']=!0x0,_0x5d5609['limit_']=_0x44c968,_0x5d5609['viewFrom_']='l',_0x5d5609;}function jh(_0x55ce02,_0x5ed0e6,_0x4529ac){const _0xb079ac=_0x55ce02['copy']();return _0xb079ac['startSet_']=!0x0,_0x5ed0e6===void 0x0&&(_0x5ed0e6=null),_0xb079ac['indexStartValue_']=_0x5ed0e6,_0x4529ac!=null?(_0xb079ac['startNameSet_']=!0x0,_0xb079ac['indexStartName_']=_0x4529ac):(_0xb079ac['startNameSet_']=!0x1,_0xb079ac['indexStartName_']=''),_0xb079ac;}function Kh(_0x53a1a5,_0x55bf60,_0x542ebf){const _0x3e59b8=_0x53a1a5['copy']();return _0x3e59b8['endSet_']=!0x0,_0x55bf60===void 0x0&&(_0x55bf60=null),_0x3e59b8['indexEndValue_']=_0x55bf60,_0x542ebf!==void 0x0?(_0x3e59b8['endNameSet_']=!0x0,_0x3e59b8['indexEndName_']=_0x542ebf):(_0x3e59b8['endNameSet_']=!0x1,_0x3e59b8['indexEndName_']=''),_0x3e59b8;}function Do(_0x1bcbd5,_0x597aad){const _0x1b0211=_0x1bcbd5['copy']();return _0x1b0211['index_']=_0x597aad,_0x1b0211;}function tr(_0x2b19a5){const _0x11f243={};if(_0x2b19a5['isDefault']())return _0x11f243;let _0x390290;if(_0x2b19a5['index_']===R?_0x390290='$priority':_0x2b19a5['index_']===Po?_0x390290='$value':_0x2b19a5['index_']===ye?_0x390290='$key':(f(_0x2b19a5['index_']instanceof Ki,'Unrecognized\x20index\x20type!'),_0x390290=_0x2b19a5['index_']['toString']()),_0x11f243['orderBy']=O(_0x390290),_0x2b19a5['startSet_']){const _0x5b6a3d=_0x2b19a5['startAfterSet_']?'startAfter':'startAt';_0x11f243[_0x5b6a3d]=O(_0x2b19a5['indexStartValue_']),_0x2b19a5['startNameSet_']&&(_0x11f243[_0x5b6a3d]+=','+O(_0x2b19a5['indexStartName_']));}if(_0x2b19a5['endSet_']){const _0x3fa0f2=_0x2b19a5['endBeforeSet_']?'endBefore':'endAt';_0x11f243[_0x3fa0f2]=O(_0x2b19a5['indexEndValue_']),_0x2b19a5['endNameSet_']&&(_0x11f243[_0x3fa0f2]+=','+O(_0x2b19a5['indexEndName_']));}return _0x2b19a5['limitSet_']&&(_0x2b19a5['isViewFromLeft']()?_0x11f243['limitToFirst']=_0x2b19a5['limit_']:_0x11f243['limitToLast']=_0x2b19a5['limit_']),_0x11f243;}function nr(_0x59b50d){const _0x3de97d={};if(_0x59b50d['startSet_']&&(_0x3de97d['sp']=_0x59b50d['indexStartValue_'],_0x59b50d['startNameSet_']&&(_0x3de97d['sn']=_0x59b50d['indexStartName_']),_0x3de97d['sin']=!_0x59b50d['startAfterSet_']),_0x59b50d['endSet_']&&(_0x3de97d['ep']=_0x59b50d['indexEndValue_'],_0x59b50d['endNameSet_']&&(_0x3de97d['en']=_0x59b50d['indexEndName_']),_0x3de97d['ein']=!_0x59b50d['endBeforeSet_']),_0x59b50d['limitSet_']){_0x3de97d['l']=_0x59b50d['limit_'];let _0x44b06a=_0x59b50d['viewFrom_'];_0x44b06a===''&&(_0x59b50d['isViewFromLeft']()?_0x44b06a='l':_0x44b06a='r'),_0x3de97d['vf']=_0x44b06a;}return _0x59b50d['index_']!==R&&(_0x3de97d['i']=_0x59b50d['index_']['toString']()),_0x3de97d;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fn extends wo{['reportStats'](_0x5604da){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x5f1090,_0x1be194){return _0x1be194!==void 0x0?'tag$'+_0x1be194:(f(_0x5f1090['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x5f1090['_path']['toString']());}constructor(_0x55ac4b,_0x1f6a8b,_0x814ba3,_0x2bf31){super(),this['repoInfo_']=_0x55ac4b,this['onDataUpdate_']=_0x1f6a8b,this['authTokenProvider_']=_0x814ba3,this['appCheckTokenProvider_']=_0x2bf31,this['log_']=Vt('p:rest:'),this['listens_']={};}['listen'](_0x18bc53,_0x5eb934,_0x31a800,_0x145334){const _0x1f9b71=_0x18bc53['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x1f9b71+'\x20'+_0x18bc53['_queryIdentifier']);const _0x54225d=fn['getListenId_'](_0x18bc53,_0x31a800),_0x25f216={};this['listens_'][_0x54225d]=_0x25f216;const _0x226ca4=tr(_0x18bc53['_queryParams']);this['restRequest_'](_0x1f9b71+'.json',_0x226ca4,(_0x2517b8,_0x13ff44)=>{let _0x5cb1cd=_0x13ff44;if(_0x2517b8===0x194&&(_0x5cb1cd=null,_0x2517b8=null),_0x2517b8===null&&this['onDataUpdate_'](_0x1f9b71,_0x5cb1cd,!0x1,_0x31a800),Oe(this['listens_'],_0x54225d)===_0x25f216){let _0x12c79c;_0x2517b8?_0x2517b8===0x191?_0x12c79c='permission_denied':_0x12c79c='rest_error:'+_0x2517b8:_0x12c79c='ok',_0x145334(_0x12c79c,null);}});}['unlisten'](_0x51f2f6,_0x57d0f8){const _0x2e820e=fn['getListenId_'](_0x51f2f6,_0x57d0f8);delete this['listens_'][_0x2e820e];}['get'](_0x2883ee){const _0x954211=tr(_0x2883ee['_queryParams']),_0x375f15=_0x2883ee['_path']['toString'](),_0x94ffc=new Ve();return this['restRequest_'](_0x375f15+'.json',_0x954211,(_0x286ba5,_0x326877)=>{let _0x1f344f=_0x326877;_0x286ba5===0x194&&(_0x1f344f=null,_0x286ba5=null),_0x286ba5===null?(this['onDataUpdate_'](_0x375f15,_0x1f344f,!0x1,null),_0x94ffc['resolve'](_0x1f344f)):_0x94ffc['reject'](new Error(_0x1f344f));}),_0x94ffc['promise'];}['refreshAuthToken'](_0x2538e5){}['restRequest_'](_0x27c408,_0x172357={},_0x4ff1de){return _0x172357['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x5ec969,_0x4632a8])=>{_0x5ec969&&_0x5ec969['accessToken']&&(_0x172357['auth']=_0x5ec969['accessToken']),_0x4632a8&&_0x4632a8['token']&&(_0x172357['ac']=_0x4632a8['token']);const _0x1edb49=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x27c408+'?ns='+this['repoInfo_']['namespace']+at(_0x172357);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x1edb49);const _0x34f427=new XMLHttpRequest();_0x34f427['onreadystatechange']=()=>{if(_0x4ff1de&&_0x34f427['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x1edb49+'\x20received.\x20status:',_0x34f427['status'],'response:',_0x34f427['responseText']);let _0x21e612=null;if(_0x34f427['status']>=0xc8&&_0x34f427['status']<0x12c){try{_0x21e612=bt(_0x34f427['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x1edb49+':\x20'+_0x34f427['responseText']);}_0x4ff1de(null,_0x21e612);}else _0x34f427['status']!==0x191&&_0x34f427['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x1edb49+'\x20Status:\x20'+_0x34f427['status']),_0x4ff1de(_0x34f427['status']);_0x4ff1de=null;}},_0x34f427['open']('GET',_0x1edb49,!0x0),_0x34f427['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x396a83){return this['rootNode_']['getChild'](_0x396a83);}['updateSnapshot'](_0x30ff04,_0x2f10e5){this['rootNode_']=this['rootNode_']['updateChild'](_0x30ff04,_0x2f10e5);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function pn(){return{'value':null,'children':new Map()};}function Mo(_0x93decc,_0x4ed51a,_0xde3741){if(v(_0x4ed51a))_0x93decc['value']=_0xde3741,_0x93decc['children']['clear']();else{if(_0x93decc['value']!==null)_0x93decc['value']=_0x93decc['value']['updateChild'](_0x4ed51a,_0xde3741);else{const _0x2dac72=y(_0x4ed51a);_0x93decc['children']['has'](_0x2dac72)||_0x93decc['children']['set'](_0x2dac72,pn());const _0x1ac3fe=_0x93decc['children']['get'](_0x2dac72);_0x4ed51a=b(_0x4ed51a),Mo(_0x1ac3fe,_0x4ed51a,_0xde3741);}}}function Ei(_0x418e25,_0x1edcb4,_0x43e119){_0x418e25['value']!==null?_0x43e119(_0x1edcb4,_0x418e25['value']):Qh(_0x418e25,(_0x4af062,_0x2f4624)=>{const _0x31fd34=new C(_0x1edcb4['toString']()+'/'+_0x4af062);Ei(_0x2f4624,_0x31fd34,_0x43e119);});}function Qh(_0x202ce3,_0x3af85c){_0x202ce3['children']['forEach']((_0x910c5c,_0x58e740)=>{_0x3af85c(_0x58e740,_0x910c5c);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jh{constructor(_0x2ab1d4){this['collection_']=_0x2ab1d4,this['last_']=null;}['get'](){const _0x38662a=this['collection_']['get'](),_0x470926={..._0x38662a};return this['last_']&&x(this['last_'],(_0x4e9c14,_0x588706)=>{_0x470926[_0x4e9c14]=_0x470926[_0x4e9c14]-_0x588706;}),this['last_']=_0x38662a,_0x470926;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ir=0xa*0x3e8,Xh=0x1e*0x3e8,Zh=0x12c*0x3e8;class eu{constructor(_0x4869e3,_0x547376){this['server_']=_0x547376,this['statsToReport_']={},this['statsListener_']=new Jh(_0x4869e3);const _0x6091d5=ir+(Xh-ir)*Math['random']();It(this['reportStats_']['bind'](this),Math['floor'](_0x6091d5));}['reportStats_'](){const _0xa32c34=this['statsListener_']['get'](),_0xb5c19={};let _0x1afa5a=!0x1;x(_0xa32c34,(_0x35af8c,_0x19406e)=>{_0x19406e>0x0&&Y(this['statsToReport_'],_0x35af8c)&&(_0xb5c19[_0x35af8c]=_0x19406e,_0x1afa5a=!0x0);}),_0x1afa5a&&this['server_']['reportStats'](_0xb5c19),It(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*Zh));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var q;(function(_0x407cfa){_0x407cfa[_0x407cfa['OVERWRITE']=0x0]='OVERWRITE',_0x407cfa[_0x407cfa['MERGE']=0x1]='MERGE',_0x407cfa[_0x407cfa['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x407cfa[_0x407cfa['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(q||(q={})));function Ji(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function Xi(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function Zi(_0x22ba64){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x22ba64,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _n{constructor(_0x257ce0,_0x1f46b7,_0xf6d213){this['path']=_0x257ce0,this['affectedTree']=_0x1f46b7,this['revert']=_0xf6d213,this['type']=q['ACK_USER_WRITE'],this['source']=Ji();}['operationForChild'](_0x552fcc){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0xbacf8f=this['affectedTree']['subtree'](new C(_0x552fcc));return new _n(w(),_0xbacf8f,this['revert']);}}else return f(y(this['path'])===_0x552fcc,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new _n(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{constructor(_0x13f728,_0x236369){this['source']=_0x13f728,this['path']=_0x236369,this['type']=q['LISTEN_COMPLETE'];}['operationForChild'](_0x1426f5){return v(this['path'])?new Dt(this['source'],w()):new Dt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fe{constructor(_0x58fc6c,_0x5c8343,_0x3bb18d){this['source']=_0x58fc6c,this['path']=_0x5c8343,this['snap']=_0x3bb18d,this['type']=q['OVERWRITE'];}['operationForChild'](_0x7126a3){return v(this['path'])?new Fe(this['source'],w(),this['snap']['getImmediateChild'](_0x7126a3)):new Fe(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nt{constructor(_0x56d17c,_0x2b6bef,_0x224125){this['source']=_0x56d17c,this['path']=_0x2b6bef,this['children']=_0x224125,this['type']=q['MERGE'];}['operationForChild'](_0x3d239b){if(v(this['path'])){const _0x2b59a3=this['children']['subtree'](new C(_0x3d239b));return _0x2b59a3['isEmpty']()?null:_0x2b59a3['value']?new Fe(this['source'],w(),_0x2b59a3['value']):new nt(this['source'],w(),_0x2b59a3);}else return f(y(this['path'])===_0x3d239b,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new nt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x1bd29c,_0x5d3fe9,_0x5c759c){this['node_']=_0x1bd29c,this['fullyInitialized_']=_0x5d3fe9,this['filtered_']=_0x5c759c;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x24c3ca){if(v(_0x24c3ca))return this['isFullyInitialized']()&&!this['filtered_'];const _0x254291=y(_0x24c3ca);return this['isCompleteForChild'](_0x254291);}['isCompleteForChild'](_0x16bafc){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x16bafc);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tu{constructor(_0xfbc4da){this['query_']=_0xfbc4da,this['index_']=this['query_']['_queryParams']['getIndex']();}}function nu(_0x3fe956,_0x3e4bb6,_0x2064c3,_0x328c8f){const _0x95b793=[],_0x56fc57=[];return _0x3e4bb6['forEach'](_0x1ca004=>{_0x1ca004['type']==='child_changed'&&_0x3fe956['index_']['indexedValueChanged'](_0x1ca004['oldSnap'],_0x1ca004['snapshotNode'])&&_0x56fc57['push']($h(_0x1ca004['childName'],_0x1ca004['snapshotNode']));}),mt(_0x3fe956,_0x95b793,'child_removed',_0x3e4bb6,_0x328c8f,_0x2064c3),mt(_0x3fe956,_0x95b793,'child_added',_0x3e4bb6,_0x328c8f,_0x2064c3),mt(_0x3fe956,_0x95b793,'child_moved',_0x56fc57,_0x328c8f,_0x2064c3),mt(_0x3fe956,_0x95b793,'child_changed',_0x3e4bb6,_0x328c8f,_0x2064c3),mt(_0x3fe956,_0x95b793,'value',_0x3e4bb6,_0x328c8f,_0x2064c3),_0x95b793;}function mt(_0x3774fe,_0x2e8c72,_0x2c6cc1,_0x189bf6,_0x464fd2,_0x296f7a){const _0x3d235f=_0x189bf6['filter'](_0x49e12c=>_0x49e12c['type']===_0x2c6cc1);_0x3d235f['sort']((_0x48ab02,_0x127a15)=>su(_0x3774fe,_0x48ab02,_0x127a15)),_0x3d235f['forEach'](_0x5bead3=>{const _0x16af23=iu(_0x3774fe,_0x5bead3,_0x296f7a);_0x464fd2['forEach'](_0x24eefd=>{_0x24eefd['respondsTo'](_0x5bead3['type'])&&_0x2e8c72['push'](_0x24eefd['createEvent'](_0x16af23,_0x3774fe['query_']));});});}function iu(_0x491cd4,_0x1a1690,_0x22c33a){return _0x1a1690['type']==='value'||_0x1a1690['type']==='child_removed'||(_0x1a1690['prevName']=_0x22c33a['getPredecessorChildName'](_0x1a1690['childName'],_0x1a1690['snapshotNode'],_0x491cd4['index_'])),_0x1a1690;}function su(_0x2e0bc0,_0xd1db11,_0x2eb063){if(_0xd1db11['childName']==null||_0x2eb063['childName']==null)throw ot('Should\x20only\x20compare\x20child_\x20events.');const _0x4dd871=new E(_0xd1db11['childName'],_0xd1db11['snapshotNode']),_0x30aff4=new E(_0x2eb063['childName'],_0x2eb063['snapshotNode']);return _0x2e0bc0['index_']['compare'](_0x4dd871,_0x30aff4);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Dn(_0x2ed4a9,_0x55bd96){return{'eventCache':_0x2ed4a9,'serverCache':_0x55bd96};}function wt(_0x37e526,_0x458a4d,_0x3cb939,_0x315ae8){return Dn(new Ce(_0x458a4d,_0x3cb939,_0x315ae8),_0x37e526['serverCache']);}function Lo(_0x334904,_0x307d38,_0x49efb8,_0x3e86b7){return Dn(_0x334904['eventCache'],new Ce(_0x307d38,_0x49efb8,_0x3e86b7));}function gn(_0x2688b9){return _0x2688b9['eventCache']['isFullyInitialized']()?_0x2688b9['eventCache']['getNode']():null;}function Ue(_0x2383c6){return _0x2383c6['serverCache']['isFullyInitialized']()?_0x2383c6['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ru=()=>(ri||(ri=new B(Hl)),ri);class S{static['fromObject'](_0x5d3f04){let _0x305262=new S(null);return x(_0x5d3f04,(_0x4cf464,_0x4c6ca7)=>{_0x305262=_0x305262['set'](new C(_0x4cf464),_0x4c6ca7);}),_0x305262;}constructor(_0x3311fe,_0x43c9c3=ru()){this['value']=_0x3311fe,this['children']=_0x43c9c3;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x4aed58,_0x4b6e29){if(this['value']!=null&&_0x4b6e29(this['value']))return{'path':w(),'value':this['value']};if(v(_0x4aed58))return null;{const _0x5c6352=y(_0x4aed58),_0x3b7404=this['children']['get'](_0x5c6352);if(_0x3b7404!==null){const _0x3edcc5=_0x3b7404['findRootMostMatchingPathAndValue'](b(_0x4aed58),_0x4b6e29);return _0x3edcc5!=null?{'path':A(new C(_0x5c6352),_0x3edcc5['path']),'value':_0x3edcc5['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x101981){return this['findRootMostMatchingPathAndValue'](_0x101981,()=>!0x0);}['subtree'](_0x131a8f){if(v(_0x131a8f))return this;{const _0x3249ee=y(_0x131a8f),_0x35e4a8=this['children']['get'](_0x3249ee);return _0x35e4a8!==null?_0x35e4a8['subtree'](b(_0x131a8f)):new S(null);}}['set'](_0x967896,_0x5b0a9b){if(v(_0x967896))return new S(_0x5b0a9b,this['children']);{const _0x3fd84c=y(_0x967896),_0x3f0030=(this['children']['get'](_0x3fd84c)||new S(null))['set'](b(_0x967896),_0x5b0a9b),_0x5ceb64=this['children']['insert'](_0x3fd84c,_0x3f0030);return new S(this['value'],_0x5ceb64);}}['remove'](_0x265818){if(v(_0x265818))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x12e21b=y(_0x265818),_0x1c6025=this['children']['get'](_0x12e21b);if(_0x1c6025){const _0x184296=_0x1c6025['remove'](b(_0x265818));let _0x239054;return _0x184296['isEmpty']()?_0x239054=this['children']['remove'](_0x12e21b):_0x239054=this['children']['insert'](_0x12e21b,_0x184296),this['value']===null&&_0x239054['isEmpty']()?new S(null):new S(this['value'],_0x239054);}else return this;}}['get'](_0x323c5c){if(v(_0x323c5c))return this['value'];{const _0x576c21=y(_0x323c5c),_0x223346=this['children']['get'](_0x576c21);return _0x223346?_0x223346['get'](b(_0x323c5c)):null;}}['setTree'](_0x3db7c6,_0xa0d10){if(v(_0x3db7c6))return _0xa0d10;{const _0x441e81=y(_0x3db7c6),_0x50ed77=(this['children']['get'](_0x441e81)||new S(null))['setTree'](b(_0x3db7c6),_0xa0d10);let _0x511d62;return _0x50ed77['isEmpty']()?_0x511d62=this['children']['remove'](_0x441e81):_0x511d62=this['children']['insert'](_0x441e81,_0x50ed77),new S(this['value'],_0x511d62);}}['fold'](_0x3098f2){return this['fold_'](w(),_0x3098f2);}['fold_'](_0x294085,_0x368ce7){const _0x59a0ad={};return this['children']['inorderTraversal']((_0x317fb8,_0x14b306)=>{_0x59a0ad[_0x317fb8]=_0x14b306['fold_'](A(_0x294085,_0x317fb8),_0x368ce7);}),_0x368ce7(_0x294085,this['value'],_0x59a0ad);}['findOnPath'](_0x1930bd,_0x3cf6f1){return this['findOnPath_'](_0x1930bd,w(),_0x3cf6f1);}['findOnPath_'](_0x2c40b4,_0x1d071a,_0x3d24a5){const _0x5ef623=this['value']?_0x3d24a5(_0x1d071a,this['value']):!0x1;if(_0x5ef623)return _0x5ef623;if(v(_0x2c40b4))return null;{const _0x3945f0=y(_0x2c40b4),_0x3499cb=this['children']['get'](_0x3945f0);return _0x3499cb?_0x3499cb['findOnPath_'](b(_0x2c40b4),A(_0x1d071a,_0x3945f0),_0x3d24a5):null;}}['foreachOnPath'](_0x51f0a7,_0x348e60){return this['foreachOnPath_'](_0x51f0a7,w(),_0x348e60);}['foreachOnPath_'](_0x34fc4e,_0x54f464,_0x25f3cb){if(v(_0x34fc4e))return this;{this['value']&&_0x25f3cb(_0x54f464,this['value']);const _0x43108a=y(_0x34fc4e),_0x33c134=this['children']['get'](_0x43108a);return _0x33c134?_0x33c134['foreachOnPath_'](b(_0x34fc4e),A(_0x54f464,_0x43108a),_0x25f3cb):new S(null);}}['foreach'](_0x4b8319){this['foreach_'](w(),_0x4b8319);}['foreach_'](_0xcbbfe0,_0x54ecf8){this['children']['inorderTraversal']((_0x3f1e38,_0x49d2e0)=>{_0x49d2e0['foreach_'](A(_0xcbbfe0,_0x3f1e38),_0x54ecf8);}),this['value']&&_0x54ecf8(_0xcbbfe0,this['value']);}['foreachChild'](_0x334033){this['children']['inorderTraversal']((_0x4855f3,_0x32a486)=>{_0x32a486['value']&&_0x334033(_0x4855f3,_0x32a486['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class j{constructor(_0x5d78d3){this['writeTree_']=_0x5d78d3;}static['empty'](){return new j(new S(null));}}function Ct(_0x5dec5e,_0x5d6989,_0x7fd328){if(v(_0x5d6989))return new j(new S(_0x7fd328));{const _0x48716d=_0x5dec5e['writeTree_']['findRootMostValueAndPath'](_0x5d6989);if(_0x48716d!=null){const _0x4c1d97=_0x48716d['path'];let _0x2219ed=_0x48716d['value'];const _0x3cbf6c=F(_0x4c1d97,_0x5d6989);return _0x2219ed=_0x2219ed['updateChild'](_0x3cbf6c,_0x7fd328),new j(_0x5dec5e['writeTree_']['set'](_0x4c1d97,_0x2219ed));}else{const _0x5878c5=new S(_0x7fd328),_0x57f8bc=_0x5dec5e['writeTree_']['setTree'](_0x5d6989,_0x5878c5);return new j(_0x57f8bc);}}}function Ii(_0x1c750c,_0x432d57,_0x4d3184){let _0x44d07e=_0x1c750c;return x(_0x4d3184,(_0x4f38b8,_0x93a6b0)=>{_0x44d07e=Ct(_0x44d07e,A(_0x432d57,_0x4f38b8),_0x93a6b0);}),_0x44d07e;}function sr(_0x4841f7,_0xf9afb4){if(v(_0xf9afb4))return j['empty']();{const _0x8af5b2=_0x4841f7['writeTree_']['setTree'](_0xf9afb4,new S(null));return new j(_0x8af5b2);}}function wi(_0xec16ee,_0x3dc91c){return $e(_0xec16ee,_0x3dc91c)!=null;}function $e(_0x1a2f59,_0x5f14a7){const _0x1b5173=_0x1a2f59['writeTree_']['findRootMostValueAndPath'](_0x5f14a7);return _0x1b5173!=null?_0x1a2f59['writeTree_']['get'](_0x1b5173['path'])['getChild'](F(_0x1b5173['path'],_0x5f14a7)):null;}function rr(_0x3cbcb0){const _0x226e6a=[],_0x2e27e1=_0x3cbcb0['writeTree_']['value'];return _0x2e27e1!=null?_0x2e27e1['isLeafNode']()||_0x2e27e1['forEachChild'](R,(_0x464f35,_0x2e7312)=>{_0x226e6a['push'](new E(_0x464f35,_0x2e7312));}):_0x3cbcb0['writeTree_']['children']['inorderTraversal']((_0x2efe37,_0x3d4413)=>{_0x3d4413['value']!=null&&_0x226e6a['push'](new E(_0x2efe37,_0x3d4413['value']));}),_0x226e6a;}function ve(_0x35d610,_0x30786d){if(v(_0x30786d))return _0x35d610;{const _0x440903=$e(_0x35d610,_0x30786d);return _0x440903!=null?new j(new S(_0x440903)):new j(_0x35d610['writeTree_']['subtree'](_0x30786d));}}function Ci(_0x16724e){return _0x16724e['writeTree_']['isEmpty']();}function it(_0x26ff40,_0x38cfbb){return xo(w(),_0x26ff40['writeTree_'],_0x38cfbb);}function xo(_0x13f9c9,_0x42bcbe,_0x3e02af){if(_0x42bcbe['value']!=null)return _0x3e02af['updateChild'](_0x13f9c9,_0x42bcbe['value']);{let _0x2651f6=null;return _0x42bcbe['children']['inorderTraversal']((_0x5304f6,_0x347e63)=>{_0x5304f6==='.priority'?(f(_0x347e63['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x2651f6=_0x347e63['value']):_0x3e02af=xo(A(_0x13f9c9,_0x5304f6),_0x347e63,_0x3e02af);}),!_0x3e02af['getChild'](_0x13f9c9)['isEmpty']()&&_0x2651f6!==null&&(_0x3e02af=_0x3e02af['updateChild'](A(_0x13f9c9,'.priority'),_0x2651f6)),_0x3e02af;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x1feeb0,_0x5815c2){return Bo(_0x5815c2,_0x1feeb0);}function ou(_0x2b09e8,_0x4204c9,_0x1b44d4,_0x455d48,_0x3bfd33){f(_0x455d48>_0x2b09e8['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x3bfd33===void 0x0&&(_0x3bfd33=!0x0),_0x2b09e8['allWrites']['push']({'path':_0x4204c9,'snap':_0x1b44d4,'writeId':_0x455d48,'visible':_0x3bfd33}),_0x3bfd33&&(_0x2b09e8['visibleWrites']=Ct(_0x2b09e8['visibleWrites'],_0x4204c9,_0x1b44d4)),_0x2b09e8['lastWriteId']=_0x455d48;}function au(_0x2a3e14,_0x8eee63,_0x2442b0,_0x20b6a5){f(_0x20b6a5>_0x2a3e14['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x2a3e14['allWrites']['push']({'path':_0x8eee63,'children':_0x2442b0,'writeId':_0x20b6a5,'visible':!0x0}),_0x2a3e14['visibleWrites']=Ii(_0x2a3e14['visibleWrites'],_0x8eee63,_0x2442b0),_0x2a3e14['lastWriteId']=_0x20b6a5;}function cu(_0x57a1d7,_0x2c423f){for(let _0x2f896e=0x0;_0x2f896e<_0x57a1d7['allWrites']['length'];_0x2f896e++){const _0x528fc0=_0x57a1d7['allWrites'][_0x2f896e];if(_0x528fc0['writeId']===_0x2c423f)return _0x528fc0;}return null;}function lu(_0x2086c8,_0x2fbe30){const _0x49c685=_0x2086c8['allWrites']['findIndex'](_0x17bf9b=>_0x17bf9b['writeId']===_0x2fbe30);f(_0x49c685>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x41ccc5=_0x2086c8['allWrites'][_0x49c685];_0x2086c8['allWrites']['splice'](_0x49c685,0x1);let _0x2ae8f0=_0x41ccc5['visible'],_0x7fd9b1=!0x1,_0x105b2e=_0x2086c8['allWrites']['length']-0x1;for(;_0x2ae8f0&&_0x105b2e>=0x0;){const _0x48bc84=_0x2086c8['allWrites'][_0x105b2e];_0x48bc84['visible']&&(_0x105b2e>=_0x49c685&&hu(_0x48bc84,_0x41ccc5['path'])?_0x2ae8f0=!0x1:$(_0x41ccc5['path'],_0x48bc84['path'])&&(_0x7fd9b1=!0x0)),_0x105b2e--;}if(_0x2ae8f0){if(_0x7fd9b1)return uu(_0x2086c8),!0x0;if(_0x41ccc5['snap'])_0x2086c8['visibleWrites']=sr(_0x2086c8['visibleWrites'],_0x41ccc5['path']);else{const _0x3d6ea4=_0x41ccc5['children'];x(_0x3d6ea4,_0x40597a=>{_0x2086c8['visibleWrites']=sr(_0x2086c8['visibleWrites'],A(_0x41ccc5['path'],_0x40597a));});}return!0x0;}else return!0x1;}function hu(_0x2d4b54,_0x383b17){if(_0x2d4b54['snap'])return $(_0x2d4b54['path'],_0x383b17);for(const _0x70f1d4 in _0x2d4b54['children'])if(_0x2d4b54['children']['hasOwnProperty'](_0x70f1d4)&&$(A(_0x2d4b54['path'],_0x70f1d4),_0x383b17))return!0x0;return!0x1;}function uu(_0x47d82b){_0x47d82b['visibleWrites']=Fo(_0x47d82b['allWrites'],du,w()),_0x47d82b['allWrites']['length']>0x0?_0x47d82b['lastWriteId']=_0x47d82b['allWrites'][_0x47d82b['allWrites']['length']-0x1]['writeId']:_0x47d82b['lastWriteId']=-0x1;}function du(_0x1297fe){return _0x1297fe['visible'];}function Fo(_0x542f77,_0x2a24a0,_0xd89dc5){let _0x203df1=j['empty']();for(let _0x8e6c4b=0x0;_0x8e6c4b<_0x542f77['length'];++_0x8e6c4b){const _0x5c9a69=_0x542f77[_0x8e6c4b];if(_0x2a24a0(_0x5c9a69)){const _0x5204eb=_0x5c9a69['path'];let _0x4eea19;if(_0x5c9a69['snap'])$(_0xd89dc5,_0x5204eb)?(_0x4eea19=F(_0xd89dc5,_0x5204eb),_0x203df1=Ct(_0x203df1,_0x4eea19,_0x5c9a69['snap'])):$(_0x5204eb,_0xd89dc5)&&(_0x4eea19=F(_0x5204eb,_0xd89dc5),_0x203df1=Ct(_0x203df1,w(),_0x5c9a69['snap']['getChild'](_0x4eea19)));else{if(_0x5c9a69['children']){if($(_0xd89dc5,_0x5204eb))_0x4eea19=F(_0xd89dc5,_0x5204eb),_0x203df1=Ii(_0x203df1,_0x4eea19,_0x5c9a69['children']);else{if($(_0x5204eb,_0xd89dc5)){if(_0x4eea19=F(_0x5204eb,_0xd89dc5),v(_0x4eea19))_0x203df1=Ii(_0x203df1,w(),_0x5c9a69['children']);else{const _0x50f03b=Oe(_0x5c9a69['children'],y(_0x4eea19));if(_0x50f03b){const _0x3df848=_0x50f03b['getChild'](b(_0x4eea19));_0x203df1=Ct(_0x203df1,w(),_0x3df848);}}}}}else throw ot('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x203df1;}function Uo(_0x42e6c1,_0x39f452,_0x5bf5c9,_0x4fb342,_0x4a0045){if(!_0x4fb342&&!_0x4a0045){const _0x1a8f56=$e(_0x42e6c1['visibleWrites'],_0x39f452);if(_0x1a8f56!=null)return _0x1a8f56;{const _0x5080b8=ve(_0x42e6c1['visibleWrites'],_0x39f452);if(Ci(_0x5080b8))return _0x5bf5c9;if(_0x5bf5c9==null&&!wi(_0x5080b8,w()))return null;{const _0x268f59=_0x5bf5c9||g['EMPTY_NODE'];return it(_0x5080b8,_0x268f59);}}}else{const _0x1d0d37=ve(_0x42e6c1['visibleWrites'],_0x39f452);if(!_0x4a0045&&Ci(_0x1d0d37))return _0x5bf5c9;if(!_0x4a0045&&_0x5bf5c9==null&&!wi(_0x1d0d37,w()))return null;{const _0x11b97e=function(_0x173d51){return(_0x173d51['visible']||_0x4a0045)&&(!_0x4fb342||!~_0x4fb342['indexOf'](_0x173d51['writeId']))&&($(_0x173d51['path'],_0x39f452)||$(_0x39f452,_0x173d51['path']));},_0x3a3818=Fo(_0x42e6c1['allWrites'],_0x11b97e,_0x39f452),_0x1f7384=_0x5bf5c9||g['EMPTY_NODE'];return it(_0x3a3818,_0x1f7384);}}}function fu(_0xd59287,_0x1dca7f,_0x1c7844){let _0x124d0c=g['EMPTY_NODE'];const _0x52c03f=$e(_0xd59287['visibleWrites'],_0x1dca7f);if(_0x52c03f)return _0x52c03f['isLeafNode']()||_0x52c03f['forEachChild'](R,(_0x3546a8,_0x374551)=>{_0x124d0c=_0x124d0c['updateImmediateChild'](_0x3546a8,_0x374551);}),_0x124d0c;if(_0x1c7844){const _0xd9f55a=ve(_0xd59287['visibleWrites'],_0x1dca7f);return _0x1c7844['forEachChild'](R,(_0x3dc60d,_0x172a00)=>{const _0x231dff=it(ve(_0xd9f55a,new C(_0x3dc60d)),_0x172a00);_0x124d0c=_0x124d0c['updateImmediateChild'](_0x3dc60d,_0x231dff);}),rr(_0xd9f55a)['forEach'](_0x226a7a=>{_0x124d0c=_0x124d0c['updateImmediateChild'](_0x226a7a['name'],_0x226a7a['node']);}),_0x124d0c;}else{const _0x328b5a=ve(_0xd59287['visibleWrites'],_0x1dca7f);return rr(_0x328b5a)['forEach'](_0x31888d=>{_0x124d0c=_0x124d0c['updateImmediateChild'](_0x31888d['name'],_0x31888d['node']);}),_0x124d0c;}}function pu(_0x1e23b7,_0x1c07b6,_0x14de49,_0x4f6a89,_0x451cce){f(_0x4f6a89||_0x451cce,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x57ed0c=A(_0x1c07b6,_0x14de49);if(wi(_0x1e23b7['visibleWrites'],_0x57ed0c))return null;{const _0x39b653=ve(_0x1e23b7['visibleWrites'],_0x57ed0c);return Ci(_0x39b653)?_0x451cce['getChild'](_0x14de49):it(_0x39b653,_0x451cce['getChild'](_0x14de49));}}function _u(_0x17678e,_0x428b25,_0x355d9e,_0x43c3d2){const _0x51b15d=A(_0x428b25,_0x355d9e),_0xf4e139=$e(_0x17678e['visibleWrites'],_0x51b15d);if(_0xf4e139!=null)return _0xf4e139;if(_0x43c3d2['isCompleteForChild'](_0x355d9e)){const _0x29253c=ve(_0x17678e['visibleWrites'],_0x51b15d);return it(_0x29253c,_0x43c3d2['getNode']()['getImmediateChild'](_0x355d9e));}else return null;}function gu(_0x593e12,_0x12dd09){return $e(_0x593e12['visibleWrites'],_0x12dd09);}function mu(_0x4c692d,_0x4fa31e,_0x1e90ba,_0x4a3520,_0x522385,_0x5bb6ea,_0xa1da0){let _0x56ca18;const _0x46ac8b=ve(_0x4c692d['visibleWrites'],_0x4fa31e),_0x24bfd0=$e(_0x46ac8b,w());if(_0x24bfd0!=null)_0x56ca18=_0x24bfd0;else{if(_0x1e90ba!=null)_0x56ca18=it(_0x46ac8b,_0x1e90ba);else return[];}if(_0x56ca18=_0x56ca18['withIndex'](_0xa1da0),!_0x56ca18['isEmpty']()&&!_0x56ca18['isLeafNode']()){const _0x411853=[],_0x1e24d5=_0xa1da0['getCompare'](),_0x15a3a6=_0x5bb6ea?_0x56ca18['getReverseIteratorFrom'](_0x4a3520,_0xa1da0):_0x56ca18['getIteratorFrom'](_0x4a3520,_0xa1da0);let _0x5a80d8=_0x15a3a6['getNext']();for(;_0x5a80d8&&_0x411853['length']<_0x522385;)_0x1e24d5(_0x5a80d8,_0x4a3520)!==0x0&&_0x411853['push'](_0x5a80d8),_0x5a80d8=_0x15a3a6['getNext']();return _0x411853;}else return[];}function yu(){return{'visibleWrites':j['empty'](),'allWrites':[],'lastWriteId':-0x1};}function mn(_0x2e4e72,_0x50ca26,_0x828b3b,_0x286152){return Uo(_0x2e4e72['writeTree'],_0x2e4e72['treePath'],_0x50ca26,_0x828b3b,_0x286152);}function es(_0x27de1a,_0x2b07d2){return fu(_0x27de1a['writeTree'],_0x27de1a['treePath'],_0x2b07d2);}function or(_0x23d578,_0x532083,_0x1184ed,_0x4b5a15){return pu(_0x23d578['writeTree'],_0x23d578['treePath'],_0x532083,_0x1184ed,_0x4b5a15);}function yn(_0x3e186c,_0x2f53da){return gu(_0x3e186c['writeTree'],A(_0x3e186c['treePath'],_0x2f53da));}function vu(_0x2df261,_0x1b0767,_0x2d8431,_0x570b59,_0x4b6467,_0x3fb35a){return mu(_0x2df261['writeTree'],_0x2df261['treePath'],_0x1b0767,_0x2d8431,_0x570b59,_0x4b6467,_0x3fb35a);}function ts(_0x5caca2,_0x31d899,_0xf02e9c){return _u(_0x5caca2['writeTree'],_0x5caca2['treePath'],_0x31d899,_0xf02e9c);}function Wo(_0x48eef0,_0x11a9a4){return Bo(A(_0x48eef0['treePath'],_0x11a9a4),_0x48eef0['writeTree']);}function Bo(_0x3abee5,_0x3c4e7c){return{'treePath':_0x3abee5,'writeTree':_0x3c4e7c};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Eu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0xa56b3b){const _0x10d6d4=_0xa56b3b['type'],_0x2f7490=_0xa56b3b['childName'];f(_0x10d6d4==='child_added'||_0x10d6d4==='child_changed'||_0x10d6d4==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x2f7490!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x701b15=this['changeMap']['get'](_0x2f7490);if(_0x701b15){const _0x48caa9=_0x701b15['type'];if(_0x10d6d4==='child_added'&&_0x48caa9==='child_removed')this['changeMap']['set'](_0x2f7490,Pt(_0x2f7490,_0xa56b3b['snapshotNode'],_0x701b15['snapshotNode']));else{if(_0x10d6d4==='child_removed'&&_0x48caa9==='child_added')this['changeMap']['delete'](_0x2f7490);else{if(_0x10d6d4==='child_removed'&&_0x48caa9==='child_changed')this['changeMap']['set'](_0x2f7490,Nt(_0x2f7490,_0x701b15['oldSnap']));else{if(_0x10d6d4==='child_changed'&&_0x48caa9==='child_added')this['changeMap']['set'](_0x2f7490,tt(_0x2f7490,_0xa56b3b['snapshotNode']));else{if(_0x10d6d4==='child_changed'&&_0x48caa9==='child_changed')this['changeMap']['set'](_0x2f7490,Pt(_0x2f7490,_0xa56b3b['snapshotNode'],_0x701b15['oldSnap']));else throw ot('Illegal\x20combination\x20of\x20changes:\x20'+_0xa56b3b+'\x20occurred\x20after\x20'+_0x701b15);}}}}}else this['changeMap']['set'](_0x2f7490,_0xa56b3b);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Iu{['getCompleteChild'](_0x1eeed6){return null;}['getChildAfterChild'](_0x4d9093,_0x5a1759,_0x2bb399){return null;}}const Vo=new Iu();class ns{constructor(_0x5df76f,_0x3d7fae,_0x17e4b5=null){this['writes_']=_0x5df76f,this['viewCache_']=_0x3d7fae,this['optCompleteServerCache_']=_0x17e4b5;}['getCompleteChild'](_0x2d9184){const _0x25c77c=this['viewCache_']['eventCache'];if(_0x25c77c['isCompleteForChild'](_0x2d9184))return _0x25c77c['getNode']()['getImmediateChild'](_0x2d9184);{const _0x3192af=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ts(this['writes_'],_0x2d9184,_0x3192af);}}['getChildAfterChild'](_0x40fcac,_0x3d32d4,_0x3a0bfb){const _0x376da7=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ue(this['viewCache_']),_0x1a2b8c=vu(this['writes_'],_0x376da7,_0x3d32d4,0x1,_0x3a0bfb,_0x40fcac);return _0x1a2b8c['length']===0x0?null:_0x1a2b8c[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function wu(_0x5e6c7){return{'filter':_0x5e6c7};}function Cu(_0x3db997,_0x599cbd){f(_0x599cbd['eventCache']['getNode']()['isIndexed'](_0x3db997['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x599cbd['serverCache']['getNode']()['isIndexed'](_0x3db997['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Tu(_0x42dfde,_0x118eab,_0x4f89e0,_0x4efd3f,_0x2825ef){const _0x1b56ba=new Eu();let _0x23bf92,_0x227613;if(_0x4f89e0['type']===q['OVERWRITE']){const _0x33b20f=_0x4f89e0;_0x33b20f['source']['fromUser']?_0x23bf92=Ti(_0x42dfde,_0x118eab,_0x33b20f['path'],_0x33b20f['snap'],_0x4efd3f,_0x2825ef,_0x1b56ba):(f(_0x33b20f['source']['fromServer'],'Unknown\x20source.'),_0x227613=_0x33b20f['source']['tagged']||_0x118eab['serverCache']['isFiltered']()&&!v(_0x33b20f['path']),_0x23bf92=vn(_0x42dfde,_0x118eab,_0x33b20f['path'],_0x33b20f['snap'],_0x4efd3f,_0x2825ef,_0x227613,_0x1b56ba));}else{if(_0x4f89e0['type']===q['MERGE']){const _0xa60df5=_0x4f89e0;_0xa60df5['source']['fromUser']?_0x23bf92=bu(_0x42dfde,_0x118eab,_0xa60df5['path'],_0xa60df5['children'],_0x4efd3f,_0x2825ef,_0x1b56ba):(f(_0xa60df5['source']['fromServer'],'Unknown\x20source.'),_0x227613=_0xa60df5['source']['tagged']||_0x118eab['serverCache']['isFiltered'](),_0x23bf92=Si(_0x42dfde,_0x118eab,_0xa60df5['path'],_0xa60df5['children'],_0x4efd3f,_0x2825ef,_0x227613,_0x1b56ba));}else{if(_0x4f89e0['type']===q['ACK_USER_WRITE']){const _0x25990d=_0x4f89e0;_0x25990d['revert']?_0x23bf92=ku(_0x42dfde,_0x118eab,_0x25990d['path'],_0x4efd3f,_0x2825ef,_0x1b56ba):_0x23bf92=Ru(_0x42dfde,_0x118eab,_0x25990d['path'],_0x25990d['affectedTree'],_0x4efd3f,_0x2825ef,_0x1b56ba);}else{if(_0x4f89e0['type']===q['LISTEN_COMPLETE'])_0x23bf92=Au(_0x42dfde,_0x118eab,_0x4f89e0['path'],_0x4efd3f,_0x1b56ba);else throw ot('Unknown\x20operation\x20type:\x20'+_0x4f89e0['type']);}}}const _0x10e3da=_0x1b56ba['getChanges']();return Su(_0x118eab,_0x23bf92,_0x10e3da),{'viewCache':_0x23bf92,'changes':_0x10e3da};}function Su(_0x46010f,_0x55e879,_0x3e0448){const _0x5c73cb=_0x55e879['eventCache'];if(_0x5c73cb['isFullyInitialized']()){const _0x47d45d=_0x5c73cb['getNode']()['isLeafNode']()||_0x5c73cb['getNode']()['isEmpty'](),_0x514d50=gn(_0x46010f);(_0x3e0448['length']>0x0||!_0x46010f['eventCache']['isFullyInitialized']()||_0x47d45d&&!_0x5c73cb['getNode']()['equals'](_0x514d50)||!_0x5c73cb['getNode']()['getPriority']()['equals'](_0x514d50['getPriority']()))&&_0x3e0448['push'](Oo(gn(_0x55e879)));}}function Ho(_0x854931,_0x5ec27e,_0x4f3c50,_0x50db4a,_0xa5ad4,_0x553e8e){const _0x772b0a=_0x5ec27e['eventCache'];if(yn(_0x50db4a,_0x4f3c50)!=null)return _0x5ec27e;{let _0x1b2e68,_0x2b28f5;if(v(_0x4f3c50)){if(f(_0x5ec27e['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x5ec27e['serverCache']['isFiltered']()){const _0x51a4f1=Ue(_0x5ec27e),_0x264190=_0x51a4f1 instanceof g?_0x51a4f1:g['EMPTY_NODE'],_0x31a83c=es(_0x50db4a,_0x264190);_0x1b2e68=_0x854931['filter']['updateFullNode'](_0x5ec27e['eventCache']['getNode'](),_0x31a83c,_0x553e8e);}else{const _0x46516d=mn(_0x50db4a,Ue(_0x5ec27e));_0x1b2e68=_0x854931['filter']['updateFullNode'](_0x5ec27e['eventCache']['getNode'](),_0x46516d,_0x553e8e);}}else{const _0x1a4c67=y(_0x4f3c50);if(_0x1a4c67==='.priority'){f(we(_0x4f3c50)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x2adf36=_0x772b0a['getNode']();_0x2b28f5=_0x5ec27e['serverCache']['getNode']();const _0x3da90b=or(_0x50db4a,_0x4f3c50,_0x2adf36,_0x2b28f5);_0x3da90b!=null?_0x1b2e68=_0x854931['filter']['updatePriority'](_0x2adf36,_0x3da90b):_0x1b2e68=_0x772b0a['getNode']();}else{const _0x2993f4=b(_0x4f3c50);let _0x9925b8;if(_0x772b0a['isCompleteForChild'](_0x1a4c67)){_0x2b28f5=_0x5ec27e['serverCache']['getNode']();const _0x298085=or(_0x50db4a,_0x4f3c50,_0x772b0a['getNode'](),_0x2b28f5);_0x298085!=null?_0x9925b8=_0x772b0a['getNode']()['getImmediateChild'](_0x1a4c67)['updateChild'](_0x2993f4,_0x298085):_0x9925b8=_0x772b0a['getNode']()['getImmediateChild'](_0x1a4c67);}else _0x9925b8=ts(_0x50db4a,_0x1a4c67,_0x5ec27e['serverCache']);_0x9925b8!=null?_0x1b2e68=_0x854931['filter']['updateChild'](_0x772b0a['getNode'](),_0x1a4c67,_0x9925b8,_0x2993f4,_0xa5ad4,_0x553e8e):_0x1b2e68=_0x772b0a['getNode']();}}return wt(_0x5ec27e,_0x1b2e68,_0x772b0a['isFullyInitialized']()||v(_0x4f3c50),_0x854931['filter']['filtersNodes']());}}function vn(_0x482636,_0x1a19e7,_0x33400d,_0x1111b7,_0x47694d,_0x5d4d7c,_0x46b803,_0x30e9c5){const _0x26d708=_0x1a19e7['serverCache'];let _0x215ad4;const _0x11d83e=_0x46b803?_0x482636['filter']:_0x482636['filter']['getIndexedFilter']();if(v(_0x33400d))_0x215ad4=_0x11d83e['updateFullNode'](_0x26d708['getNode'](),_0x1111b7,null);else{if(_0x11d83e['filtersNodes']()&&!_0x26d708['isFiltered']()){const _0x26e516=_0x26d708['getNode']()['updateChild'](_0x33400d,_0x1111b7);_0x215ad4=_0x11d83e['updateFullNode'](_0x26d708['getNode'](),_0x26e516,null);}else{const _0x11f5d0=y(_0x33400d);if(!_0x26d708['isCompleteForPath'](_0x33400d)&&we(_0x33400d)>0x1)return _0x1a19e7;const _0x21d14d=b(_0x33400d),_0x1e511c=_0x26d708['getNode']()['getImmediateChild'](_0x11f5d0)['updateChild'](_0x21d14d,_0x1111b7);_0x11f5d0==='.priority'?_0x215ad4=_0x11d83e['updatePriority'](_0x26d708['getNode'](),_0x1e511c):_0x215ad4=_0x11d83e['updateChild'](_0x26d708['getNode'](),_0x11f5d0,_0x1e511c,_0x21d14d,Vo,null);}}const _0x3661bd=Lo(_0x1a19e7,_0x215ad4,_0x26d708['isFullyInitialized']()||v(_0x33400d),_0x11d83e['filtersNodes']()),_0x59698c=new ns(_0x47694d,_0x3661bd,_0x5d4d7c);return Ho(_0x482636,_0x3661bd,_0x33400d,_0x47694d,_0x59698c,_0x30e9c5);}function Ti(_0x550e60,_0x62da28,_0x1da6ae,_0x49b0fa,_0x5d024d,_0x588fd9,_0x33a24c){const _0x567cab=_0x62da28['eventCache'];let _0x37ef84,_0x190e7b;const _0x2197b3=new ns(_0x5d024d,_0x62da28,_0x588fd9);if(v(_0x1da6ae))_0x190e7b=_0x550e60['filter']['updateFullNode'](_0x62da28['eventCache']['getNode'](),_0x49b0fa,_0x33a24c),_0x37ef84=wt(_0x62da28,_0x190e7b,!0x0,_0x550e60['filter']['filtersNodes']());else{const _0x4f1766=y(_0x1da6ae);if(_0x4f1766==='.priority')_0x190e7b=_0x550e60['filter']['updatePriority'](_0x62da28['eventCache']['getNode'](),_0x49b0fa),_0x37ef84=wt(_0x62da28,_0x190e7b,_0x567cab['isFullyInitialized'](),_0x567cab['isFiltered']());else{const _0x5c849e=b(_0x1da6ae),_0x475634=_0x567cab['getNode']()['getImmediateChild'](_0x4f1766);let _0x1ae1a3;if(v(_0x5c849e))_0x1ae1a3=_0x49b0fa;else{const _0x3060e9=_0x2197b3['getCompleteChild'](_0x4f1766);_0x3060e9!=null?Gi(_0x5c849e)==='.priority'&&_0x3060e9['getChild'](To(_0x5c849e))['isEmpty']()?_0x1ae1a3=_0x3060e9:_0x1ae1a3=_0x3060e9['updateChild'](_0x5c849e,_0x49b0fa):_0x1ae1a3=g['EMPTY_NODE'];}if(_0x475634['equals'](_0x1ae1a3))_0x37ef84=_0x62da28;else{const _0x39d76f=_0x550e60['filter']['updateChild'](_0x567cab['getNode'](),_0x4f1766,_0x1ae1a3,_0x5c849e,_0x2197b3,_0x33a24c);_0x37ef84=wt(_0x62da28,_0x39d76f,_0x567cab['isFullyInitialized'](),_0x550e60['filter']['filtersNodes']());}}}return _0x37ef84;}function ar(_0x54e2d2,_0x345c31){return _0x54e2d2['eventCache']['isCompleteForChild'](_0x345c31);}function bu(_0x1fd94e,_0x3f164b,_0x29b5c4,_0x340c56,_0x5b850d,_0x3714b0,_0x82b39f){let _0x526ab7=_0x3f164b;return _0x340c56['foreach']((_0x520d64,_0x2114f9)=>{const _0x266187=A(_0x29b5c4,_0x520d64);ar(_0x3f164b,y(_0x266187))&&(_0x526ab7=Ti(_0x1fd94e,_0x526ab7,_0x266187,_0x2114f9,_0x5b850d,_0x3714b0,_0x82b39f));}),_0x340c56['foreach']((_0x4ecddd,_0x6f84ad)=>{const _0x28be00=A(_0x29b5c4,_0x4ecddd);ar(_0x3f164b,y(_0x28be00))||(_0x526ab7=Ti(_0x1fd94e,_0x526ab7,_0x28be00,_0x6f84ad,_0x5b850d,_0x3714b0,_0x82b39f));}),_0x526ab7;}function cr(_0x5934f8,_0x2de54c,_0x145baf){return _0x145baf['foreach']((_0x1ec01a,_0x454877)=>{_0x2de54c=_0x2de54c['updateChild'](_0x1ec01a,_0x454877);}),_0x2de54c;}function Si(_0x3afa6b,_0x2257b2,_0x48e7e0,_0x1e6d5b,_0x5b379b,_0x4453c7,_0x356d2b,_0x2c5cda){if(_0x2257b2['serverCache']['getNode']()['isEmpty']()&&!_0x2257b2['serverCache']['isFullyInitialized']())return _0x2257b2;let _0x66bac8=_0x2257b2,_0x3fd030;v(_0x48e7e0)?_0x3fd030=_0x1e6d5b:_0x3fd030=new S(null)['setTree'](_0x48e7e0,_0x1e6d5b);const _0x8dd9b9=_0x2257b2['serverCache']['getNode']();return _0x3fd030['children']['inorderTraversal']((_0x3bcc75,_0x457175)=>{if(_0x8dd9b9['hasChild'](_0x3bcc75)){const _0x16fa1e=_0x2257b2['serverCache']['getNode']()['getImmediateChild'](_0x3bcc75),_0x5d5c1b=cr(_0x3afa6b,_0x16fa1e,_0x457175);_0x66bac8=vn(_0x3afa6b,_0x66bac8,new C(_0x3bcc75),_0x5d5c1b,_0x5b379b,_0x4453c7,_0x356d2b,_0x2c5cda);}}),_0x3fd030['children']['inorderTraversal']((_0xc88c3e,_0x31fdb2)=>{const _0x2ed590=!_0x2257b2['serverCache']['isCompleteForChild'](_0xc88c3e)&&_0x31fdb2['value']===null;if(!_0x8dd9b9['hasChild'](_0xc88c3e)&&!_0x2ed590){const _0x1f258e=_0x2257b2['serverCache']['getNode']()['getImmediateChild'](_0xc88c3e),_0x187d0b=cr(_0x3afa6b,_0x1f258e,_0x31fdb2);_0x66bac8=vn(_0x3afa6b,_0x66bac8,new C(_0xc88c3e),_0x187d0b,_0x5b379b,_0x4453c7,_0x356d2b,_0x2c5cda);}}),_0x66bac8;}function Ru(_0x1482b7,_0x21d77c,_0x555ffc,_0xdbb113,_0x35f9f1,_0x23753d,_0x5e45a0){if(yn(_0x35f9f1,_0x555ffc)!=null)return _0x21d77c;const _0xac10d7=_0x21d77c['serverCache']['isFiltered'](),_0x4502f0=_0x21d77c['serverCache'];if(_0xdbb113['value']!=null){if(v(_0x555ffc)&&_0x4502f0['isFullyInitialized']()||_0x4502f0['isCompleteForPath'](_0x555ffc))return vn(_0x1482b7,_0x21d77c,_0x555ffc,_0x4502f0['getNode']()['getChild'](_0x555ffc),_0x35f9f1,_0x23753d,_0xac10d7,_0x5e45a0);if(v(_0x555ffc)){let _0x1a2704=new S(null);return _0x4502f0['getNode']()['forEachChild'](ye,(_0x479396,_0x4e5ee0)=>{_0x1a2704=_0x1a2704['set'](new C(_0x479396),_0x4e5ee0);}),Si(_0x1482b7,_0x21d77c,_0x555ffc,_0x1a2704,_0x35f9f1,_0x23753d,_0xac10d7,_0x5e45a0);}else return _0x21d77c;}else{let _0x1ffdd3=new S(null);return _0xdbb113['foreach']((_0x539709,_0xa8e0e2)=>{const _0x16045e=A(_0x555ffc,_0x539709);_0x4502f0['isCompleteForPath'](_0x16045e)&&(_0x1ffdd3=_0x1ffdd3['set'](_0x539709,_0x4502f0['getNode']()['getChild'](_0x16045e)));}),Si(_0x1482b7,_0x21d77c,_0x555ffc,_0x1ffdd3,_0x35f9f1,_0x23753d,_0xac10d7,_0x5e45a0);}}function Au(_0x27dcdc,_0x4a7aed,_0x2aaee7,_0x431386,_0x212048){const _0x33ee0d=_0x4a7aed['serverCache'],_0xef5dc=Lo(_0x4a7aed,_0x33ee0d['getNode'](),_0x33ee0d['isFullyInitialized']()||v(_0x2aaee7),_0x33ee0d['isFiltered']());return Ho(_0x27dcdc,_0xef5dc,_0x2aaee7,_0x431386,Vo,_0x212048);}function ku(_0x590640,_0x566984,_0x3de05d,_0x53f963,_0x253147,_0x48a36a){let _0x3cdaca;if(yn(_0x53f963,_0x3de05d)!=null)return _0x566984;{const _0xca3c21=new ns(_0x53f963,_0x566984,_0x253147),_0x169f57=_0x566984['eventCache']['getNode']();let _0x40f0dd;if(v(_0x3de05d)||y(_0x3de05d)==='.priority'){let _0xf3920c;if(_0x566984['serverCache']['isFullyInitialized']())_0xf3920c=mn(_0x53f963,Ue(_0x566984));else{const _0x2d9b36=_0x566984['serverCache']['getNode']();f(_0x2d9b36 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0xf3920c=es(_0x53f963,_0x2d9b36);}_0xf3920c=_0xf3920c,_0x40f0dd=_0x590640['filter']['updateFullNode'](_0x169f57,_0xf3920c,_0x48a36a);}else{const _0x221857=y(_0x3de05d);let _0x43d668=ts(_0x53f963,_0x221857,_0x566984['serverCache']);_0x43d668==null&&_0x566984['serverCache']['isCompleteForChild'](_0x221857)&&(_0x43d668=_0x169f57['getImmediateChild'](_0x221857)),_0x43d668!=null?_0x40f0dd=_0x590640['filter']['updateChild'](_0x169f57,_0x221857,_0x43d668,b(_0x3de05d),_0xca3c21,_0x48a36a):_0x566984['eventCache']['getNode']()['hasChild'](_0x221857)?_0x40f0dd=_0x590640['filter']['updateChild'](_0x169f57,_0x221857,g['EMPTY_NODE'],b(_0x3de05d),_0xca3c21,_0x48a36a):_0x40f0dd=_0x169f57,_0x40f0dd['isEmpty']()&&_0x566984['serverCache']['isFullyInitialized']()&&(_0x3cdaca=mn(_0x53f963,Ue(_0x566984)),_0x3cdaca['isLeafNode']()&&(_0x40f0dd=_0x590640['filter']['updateFullNode'](_0x40f0dd,_0x3cdaca,_0x48a36a)));}return _0x3cdaca=_0x566984['serverCache']['isFullyInitialized']()||yn(_0x53f963,w())!=null,wt(_0x566984,_0x40f0dd,_0x3cdaca,_0x590640['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nu{constructor(_0x20a094,_0x56306d){this['query_']=_0x20a094,this['eventRegistrations_']=[];const _0x39daaf=this['query_']['_queryParams'],_0x25d373=new Yi(_0x39daaf['getIndex']()),_0x38bfad=qh(_0x39daaf);this['processor_']=wu(_0x38bfad);const _0x38900f=_0x56306d['serverCache'],_0x470aeb=_0x56306d['eventCache'],_0x571696=_0x25d373['updateFullNode'](g['EMPTY_NODE'],_0x38900f['getNode'](),null),_0x27dd4c=_0x38bfad['updateFullNode'](g['EMPTY_NODE'],_0x470aeb['getNode'](),null),_0x145012=new Ce(_0x571696,_0x38900f['isFullyInitialized'](),_0x25d373['filtersNodes']()),_0x29cae6=new Ce(_0x27dd4c,_0x470aeb['isFullyInitialized'](),_0x38bfad['filtersNodes']());this['viewCache_']=Dn(_0x29cae6,_0x145012),this['eventGenerator_']=new tu(this['query_']);}get['query'](){return this['query_'];}}function Pu(_0x2103e4){return _0x2103e4['viewCache_']['serverCache']['getNode']();}function Ou(_0x3ac364){return gn(_0x3ac364['viewCache_']);}function Du(_0x1b3193,_0x3e0473){const _0x14f3c7=Ue(_0x1b3193['viewCache_']);return _0x14f3c7&&(_0x1b3193['query']['_queryParams']['loadsAllData']()||!v(_0x3e0473)&&!_0x14f3c7['getImmediateChild'](y(_0x3e0473))['isEmpty']())?_0x14f3c7['getChild'](_0x3e0473):null;}function lr(_0x22a21c){return _0x22a21c['eventRegistrations_']['length']===0x0;}function Mu(_0x1be849,_0x512eb0){_0x1be849['eventRegistrations_']['push'](_0x512eb0);}function hr(_0x38120f,_0xea8acb,_0x171aea){const _0xe3cba2=[];if(_0x171aea){f(_0xea8acb==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x1cb313=_0x38120f['query']['_path'];_0x38120f['eventRegistrations_']['forEach'](_0x686424=>{const _0x5d9858=_0x686424['createCancelEvent'](_0x171aea,_0x1cb313);_0x5d9858&&_0xe3cba2['push'](_0x5d9858);});}if(_0xea8acb){let _0x25a761=[];for(let _0x38badb=0x0;_0x38badb<_0x38120f['eventRegistrations_']['length'];++_0x38badb){const _0x23238a=_0x38120f['eventRegistrations_'][_0x38badb];if(!_0x23238a['matches'](_0xea8acb))_0x25a761['push'](_0x23238a);else{if(_0xea8acb['hasAnyCallback']()){_0x25a761=_0x25a761['concat'](_0x38120f['eventRegistrations_']['slice'](_0x38badb+0x1));break;}}}_0x38120f['eventRegistrations_']=_0x25a761;}else _0x38120f['eventRegistrations_']=[];return _0xe3cba2;}function ur(_0x40c911,_0x3f1e48,_0x4b813a,_0x581cf5){_0x3f1e48['type']===q['MERGE']&&_0x3f1e48['source']['queryId']!==null&&(f(Ue(_0x40c911['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(gn(_0x40c911['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x3935ca=_0x40c911['viewCache_'],_0x32dd07=Tu(_0x40c911['processor_'],_0x3935ca,_0x3f1e48,_0x4b813a,_0x581cf5);return Cu(_0x40c911['processor_'],_0x32dd07['viewCache']),f(_0x32dd07['viewCache']['serverCache']['isFullyInitialized']()||!_0x3935ca['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x40c911['viewCache_']=_0x32dd07['viewCache'],$o(_0x40c911,_0x32dd07['changes'],_0x32dd07['viewCache']['eventCache']['getNode'](),null);}function Lu(_0x197f39,_0x4ad1fc){const _0x17c55f=_0x197f39['viewCache_']['eventCache'],_0x52ee47=[];return _0x17c55f['getNode']()['isLeafNode']()||_0x17c55f['getNode']()['forEachChild'](R,(_0x159e9c,_0x292abd)=>{_0x52ee47['push'](tt(_0x159e9c,_0x292abd));}),_0x17c55f['isFullyInitialized']()&&_0x52ee47['push'](Oo(_0x17c55f['getNode']())),$o(_0x197f39,_0x52ee47,_0x17c55f['getNode'](),_0x4ad1fc);}function $o(_0x295973,_0x3dd600,_0x5cf832,_0x8af068){const _0x16e2f0=_0x8af068?[_0x8af068]:_0x295973['eventRegistrations_'];return nu(_0x295973['eventGenerator_'],_0x3dd600,_0x5cf832,_0x16e2f0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let En;class Go{constructor(){this['views']=new Map();}}function xu(_0x50d41f){f(!En,'__referenceConstructor\x20has\x20already\x20been\x20defined'),En=_0x50d41f;}function Fu(){return f(En,'Reference.ts\x20has\x20not\x20been\x20loaded'),En;}function Uu(_0x1adc29){return _0x1adc29['views']['size']===0x0;}function is(_0x1f31cf,_0x29d419,_0x3d6158,_0x522ba2){const _0x2ab425=_0x29d419['source']['queryId'];if(_0x2ab425!==null){const _0x3c9f3b=_0x1f31cf['views']['get'](_0x2ab425);return f(_0x3c9f3b!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),ur(_0x3c9f3b,_0x29d419,_0x3d6158,_0x522ba2);}else{let _0x3a0e6c=[];for(const _0x3ade8b of _0x1f31cf['views']['values']())_0x3a0e6c=_0x3a0e6c['concat'](ur(_0x3ade8b,_0x29d419,_0x3d6158,_0x522ba2));return _0x3a0e6c;}}function qo(_0x158422,_0x539598,_0xa4284,_0xe718af,_0x41bf0b){const _0xcd1778=_0x539598['_queryIdentifier'],_0xb320ad=_0x158422['views']['get'](_0xcd1778);if(!_0xb320ad){let _0x3f1275=mn(_0xa4284,_0x41bf0b?_0xe718af:null),_0x2ed3b1=!0x1;_0x3f1275?_0x2ed3b1=!0x0:_0xe718af instanceof g?(_0x3f1275=es(_0xa4284,_0xe718af),_0x2ed3b1=!0x1):(_0x3f1275=g['EMPTY_NODE'],_0x2ed3b1=!0x1);const _0x5e55eb=Dn(new Ce(_0x3f1275,_0x2ed3b1,!0x1),new Ce(_0xe718af,_0x41bf0b,!0x1));return new Nu(_0x539598,_0x5e55eb);}return _0xb320ad;}function Wu(_0x3c547a,_0x3a4b5c,_0x382438,_0x5c997f,_0x17097b,_0x5c52bb){const _0x38fd1d=qo(_0x3c547a,_0x3a4b5c,_0x5c997f,_0x17097b,_0x5c52bb);return _0x3c547a['views']['has'](_0x3a4b5c['_queryIdentifier'])||_0x3c547a['views']['set'](_0x3a4b5c['_queryIdentifier'],_0x38fd1d),Mu(_0x38fd1d,_0x382438),Lu(_0x38fd1d,_0x382438);}function Bu(_0x2181d5,_0x1072a7,_0x7d156,_0x3a23cd){const _0x29d201=_0x1072a7['_queryIdentifier'],_0x3c1148=[];let _0x55dff8=[];const _0x215c1b=Te(_0x2181d5);if(_0x29d201==='default'){for(const [_0x2d273b,_0x59c9ee]of _0x2181d5['views']['entries']())_0x55dff8=_0x55dff8['concat'](hr(_0x59c9ee,_0x7d156,_0x3a23cd)),lr(_0x59c9ee)&&(_0x2181d5['views']['delete'](_0x2d273b),_0x59c9ee['query']['_queryParams']['loadsAllData']()||_0x3c1148['push'](_0x59c9ee['query']));}else{const _0x1d6807=_0x2181d5['views']['get'](_0x29d201);_0x1d6807&&(_0x55dff8=_0x55dff8['concat'](hr(_0x1d6807,_0x7d156,_0x3a23cd)),lr(_0x1d6807)&&(_0x2181d5['views']['delete'](_0x29d201),_0x1d6807['query']['_queryParams']['loadsAllData']()||_0x3c1148['push'](_0x1d6807['query'])));}return _0x215c1b&&!Te(_0x2181d5)&&_0x3c1148['push'](new(Fu())(_0x1072a7['_repo'],_0x1072a7['_path'])),{'removed':_0x3c1148,'events':_0x55dff8};}function zo(_0x349b02){const _0x4b8c1a=[];for(const _0x2d5bdc of _0x349b02['views']['values']())_0x2d5bdc['query']['_queryParams']['loadsAllData']()||_0x4b8c1a['push'](_0x2d5bdc);return _0x4b8c1a;}function Ee(_0x586be5,_0x11eda7){let _0x2df274=null;for(const _0x445293 of _0x586be5['views']['values']())_0x2df274=_0x2df274||Du(_0x445293,_0x11eda7);return _0x2df274;}function jo(_0x4ca5ea,_0x4e560f){if(_0x4e560f['_queryParams']['loadsAllData']())return Ln(_0x4ca5ea);{const _0x1af3af=_0x4e560f['_queryIdentifier'];return _0x4ca5ea['views']['get'](_0x1af3af);}}function Ko(_0x290c0d,_0x45c940){return jo(_0x290c0d,_0x45c940)!=null;}function Te(_0x48f89b){return Ln(_0x48f89b)!=null;}function Ln(_0x43ebbd){for(const _0x25ecc6 of _0x43ebbd['views']['values']())if(_0x25ecc6['query']['_queryParams']['loadsAllData']())return _0x25ecc6;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;function Vu(_0x1c626c){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x1c626c;}function Hu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}let $u=0x1;class dr{constructor(_0x11a889){this['listenProvider_']=_0x11a889,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=yu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function ss(_0x30a0a4,_0x38610f,_0x58ecd3,_0x28cf9a,_0x3d3139){return ou(_0x30a0a4['pendingWriteTree_'],_0x38610f,_0x58ecd3,_0x28cf9a,_0x3d3139),_0x3d3139?ht(_0x30a0a4,new Fe(Ji(),_0x38610f,_0x58ecd3)):[];}function Gu(_0x89f6f3,_0x85f559,_0x1ef7c0,_0x2b38f7){au(_0x89f6f3['pendingWriteTree_'],_0x85f559,_0x1ef7c0,_0x2b38f7);const _0x286156=S['fromObject'](_0x1ef7c0);return ht(_0x89f6f3,new nt(Ji(),_0x85f559,_0x286156));}function pe(_0x8308c7,_0x3e4437,_0x138011=!0x1){const _0x5787bf=cu(_0x8308c7['pendingWriteTree_'],_0x3e4437);if(lu(_0x8308c7['pendingWriteTree_'],_0x3e4437)){let _0x56382d=new S(null);return _0x5787bf['snap']!=null?_0x56382d=_0x56382d['set'](w(),!0x0):x(_0x5787bf['children'],_0xc461cb=>{_0x56382d=_0x56382d['set'](new C(_0xc461cb),!0x0);}),ht(_0x8308c7,new _n(_0x5787bf['path'],_0x56382d,_0x138011));}else return[];}function $t(_0x23e4e1,_0x3cc7b3,_0x307319){return ht(_0x23e4e1,new Fe(Xi(),_0x3cc7b3,_0x307319));}function qu(_0x44947c,_0x3a96ff,_0x503c49){const _0x1ae6b7=S['fromObject'](_0x503c49);return ht(_0x44947c,new nt(Xi(),_0x3a96ff,_0x1ae6b7));}function zu(_0x429b26,_0x229cf1){return ht(_0x429b26,new Dt(Xi(),_0x229cf1));}function ju(_0x447c34,_0x1672a7,_0x321536){const _0x87ea57=rs(_0x447c34,_0x321536);if(_0x87ea57){const _0x27adc5=os(_0x87ea57),_0x5882cf=_0x27adc5['path'],_0x1334b3=_0x27adc5['queryId'],_0x5961a4=F(_0x5882cf,_0x1672a7),_0x3b449b=new Dt(Zi(_0x1334b3),_0x5961a4);return as(_0x447c34,_0x5882cf,_0x3b449b);}else return[];}function wn(_0xe2987d,_0xaebab8,_0x383731,_0x116ede,_0x82e387=!0x1){const _0x469d38=_0xaebab8['_path'],_0x11db50=_0xe2987d['syncPointTree_']['get'](_0x469d38);let _0x3bc944=[];if(_0x11db50&&(_0xaebab8['_queryIdentifier']==='default'||Ko(_0x11db50,_0xaebab8))){const _0xb43c7=Bu(_0x11db50,_0xaebab8,_0x383731,_0x116ede);Uu(_0x11db50)&&(_0xe2987d['syncPointTree_']=_0xe2987d['syncPointTree_']['remove'](_0x469d38));const _0x1a018f=_0xb43c7['removed'];if(_0x3bc944=_0xb43c7['events'],!_0x82e387){const _0x3ac3c4=_0x1a018f['findIndex'](_0x51f02f=>_0x51f02f['_queryParams']['loadsAllData']())!==-0x1,_0x1f40c1=_0xe2987d['syncPointTree_']['findOnPath'](_0x469d38,(_0xe6779d,_0x2be1b2)=>Te(_0x2be1b2));if(_0x3ac3c4&&!_0x1f40c1){const _0x2e9a5b=_0xe2987d['syncPointTree_']['subtree'](_0x469d38);if(!_0x2e9a5b['isEmpty']()){const _0x953593=Qu(_0x2e9a5b);for(let _0x14fb25=0x0;_0x14fb25<_0x953593['length'];++_0x14fb25){const _0x1a0ca8=_0x953593[_0x14fb25],_0x108364=_0x1a0ca8['query'],_0x4d20c8=Xo(_0xe2987d,_0x1a0ca8);_0xe2987d['listenProvider_']['startListening'](Tt(_0x108364),Mt(_0xe2987d,_0x108364),_0x4d20c8['hashFn'],_0x4d20c8['onComplete']);}}}!_0x1f40c1&&_0x1a018f['length']>0x0&&!_0x116ede&&(_0x3ac3c4?_0xe2987d['listenProvider_']['stopListening'](Tt(_0xaebab8),null):_0x1a018f['forEach'](_0x59cbe6=>{const _0x1b0975=_0xe2987d['queryToTagMap']['get'](Fn(_0x59cbe6));_0xe2987d['listenProvider_']['stopListening'](Tt(_0x59cbe6),_0x1b0975);}));}Ju(_0xe2987d,_0x1a018f);}return _0x3bc944;}function Yo(_0x23a684,_0x3ca31f,_0x368ecc,_0x511024){const _0x4aebfa=rs(_0x23a684,_0x511024);if(_0x4aebfa!=null){const _0x3143c1=os(_0x4aebfa),_0x2a9027=_0x3143c1['path'],_0x563faf=_0x3143c1['queryId'],_0x2c6ac=F(_0x2a9027,_0x3ca31f),_0x234562=new Fe(Zi(_0x563faf),_0x2c6ac,_0x368ecc);return as(_0x23a684,_0x2a9027,_0x234562);}else return[];}function Ku(_0x5dbc75,_0x49b363,_0x3e9109,_0x36beaf){const _0x22a297=rs(_0x5dbc75,_0x36beaf);if(_0x22a297){const _0x578ff0=os(_0x22a297),_0x3067a=_0x578ff0['path'],_0x327e8c=_0x578ff0['queryId'],_0x438857=F(_0x3067a,_0x49b363),_0x319b93=S['fromObject'](_0x3e9109),_0x3cde7e=new nt(Zi(_0x327e8c),_0x438857,_0x319b93);return as(_0x5dbc75,_0x3067a,_0x3cde7e);}else return[];}function bi(_0x30518a,_0x49756e,_0x3239c3,_0x38d3b7=!0x1){const _0x3878e5=_0x49756e['_path'];let _0x4833f4=null,_0x54e6f8=!0x1;_0x30518a['syncPointTree_']['foreachOnPath'](_0x3878e5,(_0x3246d0,_0x5d9a23)=>{const _0x349e50=F(_0x3246d0,_0x3878e5);_0x4833f4=_0x4833f4||Ee(_0x5d9a23,_0x349e50),_0x54e6f8=_0x54e6f8||Te(_0x5d9a23);});let _0x2ab16e=_0x30518a['syncPointTree_']['get'](_0x3878e5);_0x2ab16e?(_0x54e6f8=_0x54e6f8||Te(_0x2ab16e),_0x4833f4=_0x4833f4||Ee(_0x2ab16e,w())):(_0x2ab16e=new Go(),_0x30518a['syncPointTree_']=_0x30518a['syncPointTree_']['set'](_0x3878e5,_0x2ab16e));let _0x29a3fd;_0x4833f4!=null?_0x29a3fd=!0x0:(_0x29a3fd=!0x1,_0x4833f4=g['EMPTY_NODE'],_0x30518a['syncPointTree_']['subtree'](_0x3878e5)['foreachChild']((_0xaa6f26,_0x106b72)=>{const _0x19c0af=Ee(_0x106b72,w());_0x19c0af&&(_0x4833f4=_0x4833f4['updateImmediateChild'](_0xaa6f26,_0x19c0af));}));const _0x5d151d=Ko(_0x2ab16e,_0x49756e);if(!_0x5d151d&&!_0x49756e['_queryParams']['loadsAllData']()){const _0x3e3b44=Fn(_0x49756e);f(!_0x30518a['queryToTagMap']['has'](_0x3e3b44),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x1d99fc=Xu();_0x30518a['queryToTagMap']['set'](_0x3e3b44,_0x1d99fc),_0x30518a['tagToQueryMap']['set'](_0x1d99fc,_0x3e3b44);}const _0x5b52dd=Mn(_0x30518a['pendingWriteTree_'],_0x3878e5);let _0x158848=Wu(_0x2ab16e,_0x49756e,_0x3239c3,_0x5b52dd,_0x4833f4,_0x29a3fd);if(!_0x5d151d&&!_0x54e6f8&&!_0x38d3b7){const _0x46f797=jo(_0x2ab16e,_0x49756e);_0x158848=_0x158848['concat'](Zu(_0x30518a,_0x49756e,_0x46f797));}return _0x158848;}function xn(_0x49df65,_0x359703,_0x479a29){const _0x335a79=_0x49df65['pendingWriteTree_'],_0x50fd71=_0x49df65['syncPointTree_']['findOnPath'](_0x359703,(_0x242c16,_0x360384)=>{const _0x36ebca=F(_0x242c16,_0x359703),_0x10a309=Ee(_0x360384,_0x36ebca);if(_0x10a309)return _0x10a309;});return Uo(_0x335a79,_0x359703,_0x50fd71,_0x479a29,!0x0);}function Yu(_0x147791,_0x37d719){const _0x280f67=_0x37d719['_path'];let _0x1fec87=null;_0x147791['syncPointTree_']['foreachOnPath'](_0x280f67,(_0x2a6f5e,_0x5dd447)=>{const _0x3d4617=F(_0x2a6f5e,_0x280f67);_0x1fec87=_0x1fec87||Ee(_0x5dd447,_0x3d4617);});let _0x2e569e=_0x147791['syncPointTree_']['get'](_0x280f67);_0x2e569e?_0x1fec87=_0x1fec87||Ee(_0x2e569e,w()):(_0x2e569e=new Go(),_0x147791['syncPointTree_']=_0x147791['syncPointTree_']['set'](_0x280f67,_0x2e569e));const _0x4c9698=_0x1fec87!=null,_0x3cc921=_0x4c9698?new Ce(_0x1fec87,!0x0,!0x1):null,_0x1dc368=Mn(_0x147791['pendingWriteTree_'],_0x37d719['_path']),_0x200e53=qo(_0x2e569e,_0x37d719,_0x1dc368,_0x4c9698?_0x3cc921['getNode']():g['EMPTY_NODE'],_0x4c9698);return Ou(_0x200e53);}function ht(_0x344263,_0x482653){return Qo(_0x482653,_0x344263['syncPointTree_'],null,Mn(_0x344263['pendingWriteTree_'],w()));}function Qo(_0x4ebe54,_0x2dc8a8,_0x15a139,_0x166e18){if(v(_0x4ebe54['path']))return Jo(_0x4ebe54,_0x2dc8a8,_0x15a139,_0x166e18);{const _0x3e2a3b=_0x2dc8a8['get'](w());_0x15a139==null&&_0x3e2a3b!=null&&(_0x15a139=Ee(_0x3e2a3b,w()));let _0x75094f=[];const _0xf3024d=y(_0x4ebe54['path']),_0xa5490c=_0x4ebe54['operationForChild'](_0xf3024d),_0x22c81d=_0x2dc8a8['children']['get'](_0xf3024d);if(_0x22c81d&&_0xa5490c){const _0x4bf0b5=_0x15a139?_0x15a139['getImmediateChild'](_0xf3024d):null,_0x1362e2=Wo(_0x166e18,_0xf3024d);_0x75094f=_0x75094f['concat'](Qo(_0xa5490c,_0x22c81d,_0x4bf0b5,_0x1362e2));}return _0x3e2a3b&&(_0x75094f=_0x75094f['concat'](is(_0x3e2a3b,_0x4ebe54,_0x166e18,_0x15a139))),_0x75094f;}}function Jo(_0x18d6c5,_0x54b8a0,_0x16c389,_0x1c3a40){const _0x308657=_0x54b8a0['get'](w());_0x16c389==null&&_0x308657!=null&&(_0x16c389=Ee(_0x308657,w()));let _0x14420d=[];return _0x54b8a0['children']['inorderTraversal']((_0xdc2210,_0x182a6b)=>{const _0x44ecda=_0x16c389?_0x16c389['getImmediateChild'](_0xdc2210):null,_0x106210=Wo(_0x1c3a40,_0xdc2210),_0x1e5323=_0x18d6c5['operationForChild'](_0xdc2210);_0x1e5323&&(_0x14420d=_0x14420d['concat'](Jo(_0x1e5323,_0x182a6b,_0x44ecda,_0x106210)));}),_0x308657&&(_0x14420d=_0x14420d['concat'](is(_0x308657,_0x18d6c5,_0x1c3a40,_0x16c389))),_0x14420d;}function Xo(_0x183d3e,_0x52ab9a){const _0x5770ef=_0x52ab9a['query'],_0x5370cf=Mt(_0x183d3e,_0x5770ef);return{'hashFn':()=>(Pu(_0x52ab9a)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x3c9871=>{if(_0x3c9871==='ok')return _0x5370cf?ju(_0x183d3e,_0x5770ef['_path'],_0x5370cf):zu(_0x183d3e,_0x5770ef['_path']);{const _0x52a100=ql(_0x3c9871,_0x5770ef);return wn(_0x183d3e,_0x5770ef,null,_0x52a100);}}};}function Mt(_0x5010da,_0x59e753){const _0x51e463=Fn(_0x59e753);return _0x5010da['queryToTagMap']['get'](_0x51e463);}function Fn(_0x495cbf){return _0x495cbf['_path']['toString']()+'$'+_0x495cbf['_queryIdentifier'];}function rs(_0x165db7,_0xf7d83c){return _0x165db7['tagToQueryMap']['get'](_0xf7d83c);}function os(_0x294cd7){const _0x5942bd=_0x294cd7['indexOf']('$');return f(_0x5942bd!==-0x1&&_0x5942bd<_0x294cd7['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x294cd7['substr'](_0x5942bd+0x1),'path':new C(_0x294cd7['substr'](0x0,_0x5942bd))};}function as(_0x16097d,_0x1eb43b,_0x4de0fe){const _0x393a57=_0x16097d['syncPointTree_']['get'](_0x1eb43b);f(_0x393a57,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x1bde1b=Mn(_0x16097d['pendingWriteTree_'],_0x1eb43b);return is(_0x393a57,_0x4de0fe,_0x1bde1b,null);}function Qu(_0x54a2bf){return _0x54a2bf['fold']((_0x57f41a,_0x5a1dfa,_0x368acc)=>{if(_0x5a1dfa&&Te(_0x5a1dfa))return[Ln(_0x5a1dfa)];{let _0x26c806=[];return _0x5a1dfa&&(_0x26c806=zo(_0x5a1dfa)),x(_0x368acc,(_0x571790,_0x5d7758)=>{_0x26c806=_0x26c806['concat'](_0x5d7758);}),_0x26c806;}});}function Tt(_0x4e91f7){return _0x4e91f7['_queryParams']['loadsAllData']()&&!_0x4e91f7['_queryParams']['isDefault']()?new(Hu())(_0x4e91f7['_repo'],_0x4e91f7['_path']):_0x4e91f7;}function Ju(_0x2266b5,_0x268237){for(let _0xa30599=0x0;_0xa30599<_0x268237['length'];++_0xa30599){const _0x30c086=_0x268237[_0xa30599];if(!_0x30c086['_queryParams']['loadsAllData']()){const _0x2ab6fd=Fn(_0x30c086),_0x52d8c3=_0x2266b5['queryToTagMap']['get'](_0x2ab6fd);_0x2266b5['queryToTagMap']['delete'](_0x2ab6fd),_0x2266b5['tagToQueryMap']['delete'](_0x52d8c3);}}}function Xu(){return $u++;}function Zu(_0x42eb0b,_0x25f1e0,_0x5cf8a4){const _0xa59ad8=_0x25f1e0['_path'],_0x76785e=Mt(_0x42eb0b,_0x25f1e0),_0x3170ee=Xo(_0x42eb0b,_0x5cf8a4),_0x540636=_0x42eb0b['listenProvider_']['startListening'](Tt(_0x25f1e0),_0x76785e,_0x3170ee['hashFn'],_0x3170ee['onComplete']),_0x6a2ca=_0x42eb0b['syncPointTree_']['subtree'](_0xa59ad8);if(_0x76785e)f(!Te(_0x6a2ca['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x367db8=_0x6a2ca['fold']((_0x31477a,_0x3dcf9f,_0xae37e)=>{if(!v(_0x31477a)&&_0x3dcf9f&&Te(_0x3dcf9f))return[Ln(_0x3dcf9f)['query']];{let _0x704e51=[];return _0x3dcf9f&&(_0x704e51=_0x704e51['concat'](zo(_0x3dcf9f)['map'](_0x48cb60=>_0x48cb60['query']))),x(_0xae37e,(_0x3f0cbe,_0xde6aaf)=>{_0x704e51=_0x704e51['concat'](_0xde6aaf);}),_0x704e51;}});for(let _0x443682=0x0;_0x443682<_0x367db8['length'];++_0x443682){const _0x2ec91c=_0x367db8[_0x443682];_0x42eb0b['listenProvider_']['stopListening'](Tt(_0x2ec91c),Mt(_0x42eb0b,_0x2ec91c));}}return _0x540636;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class cs{constructor(_0x507b08){this['node_']=_0x507b08;}['getImmediateChild'](_0x15692c){const _0x4e2d4d=this['node_']['getImmediateChild'](_0x15692c);return new cs(_0x4e2d4d);}['node'](){return this['node_'];}}class ls{constructor(_0x4d54ea,_0x5359a0){this['syncTree_']=_0x4d54ea,this['path_']=_0x5359a0;}['getImmediateChild'](_0x4b2e5d){const _0x336532=A(this['path_'],_0x4b2e5d);return new ls(this['syncTree_'],_0x336532);}['node'](){return xn(this['syncTree_'],this['path_']);}}const ed=function(_0x38c720){return _0x38c720=_0x38c720||{},_0x38c720['timestamp']=_0x38c720['timestamp']||new Date()['getTime'](),_0x38c720;},fr=function(_0x258766,_0x4923ff,_0xee78d5){if(!_0x258766||typeof _0x258766!='object')return _0x258766;if(f('.sv'in _0x258766,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x258766['.sv']=='string')return td(_0x258766['.sv'],_0x4923ff,_0xee78d5);if(typeof _0x258766['.sv']=='object')return nd(_0x258766['.sv'],_0x4923ff);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x258766,null,0x2));},td=function(_0x2c7a71,_0x1dd573,_0x4b738e){switch(_0x2c7a71){case'timestamp':return _0x4b738e['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x2c7a71);}},nd=function(_0x554f1e,_0x440cd8,_0x571096){_0x554f1e['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x554f1e,null,0x2));const _0x39e0eb=_0x554f1e['increment'];typeof _0x39e0eb!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x39e0eb);const _0x140d99=_0x440cd8['node']();if(f(_0x140d99!==null&&typeof _0x140d99<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x140d99['isLeafNode']())return _0x39e0eb;const _0x41c741=_0x140d99['getValue']();return typeof _0x41c741!='number'?_0x39e0eb:_0x41c741+_0x39e0eb;},Zo=function(_0x391bbf,_0x7b80d9,_0x32fce2,_0x1a5b02){return us(_0x7b80d9,new ls(_0x32fce2,_0x391bbf),_0x1a5b02);},hs=function(_0x544660,_0x2c1616,_0x4c06c4){return us(_0x544660,new cs(_0x2c1616),_0x4c06c4);};function us(_0x2b38a0,_0x1d8162,_0x12fa9f){const _0x3a9844=_0x2b38a0['getPriority']()['val'](),_0x69ce61=fr(_0x3a9844,_0x1d8162['getImmediateChild']('.priority'),_0x12fa9f);let _0x465376;if(_0x2b38a0['isLeafNode']()){const _0x180710=_0x2b38a0,_0x5d3f62=fr(_0x180710['getValue'](),_0x1d8162,_0x12fa9f);return _0x5d3f62!==_0x180710['getValue']()||_0x69ce61!==_0x180710['getPriority']()['val']()?new D(_0x5d3f62,N(_0x69ce61)):_0x2b38a0;}else{const _0x54aa99=_0x2b38a0;return _0x465376=_0x54aa99,_0x69ce61!==_0x54aa99['getPriority']()['val']()&&(_0x465376=_0x465376['updatePriority'](new D(_0x69ce61))),_0x54aa99['forEachChild'](R,(_0x539c42,_0x158a2e)=>{const _0x173946=us(_0x158a2e,_0x1d8162['getImmediateChild'](_0x539c42),_0x12fa9f);_0x173946!==_0x158a2e&&(_0x465376=_0x465376['updateImmediateChild'](_0x539c42,_0x173946));}),_0x465376;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ds{constructor(_0x3ce2b8='',_0x4a5fa1=null,_0x3f2ffb={'children':{},'childCount':0x0}){this['name']=_0x3ce2b8,this['parent']=_0x4a5fa1,this['node']=_0x3f2ffb;}}function Un(_0x53255c,_0x57a49d){let _0x1afbe8=_0x57a49d instanceof C?_0x57a49d:new C(_0x57a49d),_0x58d10d=_0x53255c,_0x498d26=y(_0x1afbe8);for(;_0x498d26!==null;){const _0x5ca489=Oe(_0x58d10d['node']['children'],_0x498d26)||{'children':{},'childCount':0x0};_0x58d10d=new ds(_0x498d26,_0x58d10d,_0x5ca489),_0x1afbe8=b(_0x1afbe8),_0x498d26=y(_0x1afbe8);}return _0x58d10d;}function Ge(_0x2084fa){return _0x2084fa['node']['value'];}function fs(_0x2de2d6,_0x380408){_0x2de2d6['node']['value']=_0x380408,Ri(_0x2de2d6);}function ea(_0x434896){return _0x434896['node']['childCount']>0x0;}function id(_0xf2563b){return Ge(_0xf2563b)===void 0x0&&!ea(_0xf2563b);}function Wn(_0x46b2ae,_0x2a0509){x(_0x46b2ae['node']['children'],(_0xc25f25,_0x2cf63f)=>{_0x2a0509(new ds(_0xc25f25,_0x46b2ae,_0x2cf63f));});}function ta(_0x10b6b9,_0xae4d05,_0x560a9c,_0x5c5124){_0x560a9c&&_0xae4d05(_0x10b6b9),Wn(_0x10b6b9,_0xfaabdb=>{ta(_0xfaabdb,_0xae4d05,!0x0);});}function sd(_0x36861b,_0x41d226,_0x5887a0){let _0x8c1cf3=_0x36861b['parent'];for(;_0x8c1cf3!==null;){if(_0x41d226(_0x8c1cf3))return!0x0;_0x8c1cf3=_0x8c1cf3['parent'];}return!0x1;}function Gt(_0x4fc8ad){return new C(_0x4fc8ad['parent']===null?_0x4fc8ad['name']:Gt(_0x4fc8ad['parent'])+'/'+_0x4fc8ad['name']);}function Ri(_0x1d4be2){_0x1d4be2['parent']!==null&&rd(_0x1d4be2['parent'],_0x1d4be2['name'],_0x1d4be2);}function rd(_0x42e067,_0x405eab,_0x2c1a40){const _0x204aa7=id(_0x2c1a40),_0x3171c5=Y(_0x42e067['node']['children'],_0x405eab);_0x204aa7&&_0x3171c5?(delete _0x42e067['node']['children'][_0x405eab],_0x42e067['node']['childCount']--,Ri(_0x42e067)):!_0x204aa7&&!_0x3171c5&&(_0x42e067['node']['children'][_0x405eab]=_0x2c1a40['node'],_0x42e067['node']['childCount']++,Ri(_0x42e067));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const od=/[\[\].#$\/\u0000-\u001F\u007F]/,ad=/[\[\].#$\u0000-\u001F\u007F]/,oi=0xa*0x400*0x400,ps=function(_0x169571){return typeof _0x169571=='string'&&_0x169571['length']!==0x0&&!od['test'](_0x169571);},na=function(_0x5663fc){return typeof _0x5663fc=='string'&&_0x5663fc['length']!==0x0&&!ad['test'](_0x5663fc);},cd=function(_0x5591ff){return _0x5591ff&&(_0x5591ff=_0x5591ff['replace'](/^\/*\.info(\/|$)/,'/')),na(_0x5591ff);},Cn=function(_0x577df6){return _0x577df6===null||typeof _0x577df6=='string'||typeof _0x577df6=='number'&&!Wi(_0x577df6)||_0x577df6&&typeof _0x577df6=='object'&&Y(_0x577df6,'.sv');},qt=function(_0x4f39cf,_0xf5f818,_0x219572,_0x59064e){_0x59064e&&_0xf5f818===void 0x0||zt(Nn(_0x4f39cf,'value'),_0xf5f818,_0x219572);},zt=function(_0x59b619,_0x156d97,_0x1c55d3){const _0x440ff0=_0x1c55d3 instanceof C?new Sh(_0x1c55d3,_0x59b619):_0x1c55d3;if(_0x156d97===void 0x0)throw new Error(_0x59b619+'contains\x20undefined\x20'+Ne(_0x440ff0));if(typeof _0x156d97=='function')throw new Error(_0x59b619+'contains\x20a\x20function\x20'+Ne(_0x440ff0)+'\x20with\x20contents\x20=\x20'+_0x156d97['toString']());if(Wi(_0x156d97))throw new Error(_0x59b619+'contains\x20'+_0x156d97['toString']()+'\x20'+Ne(_0x440ff0));if(typeof _0x156d97=='string'&&_0x156d97['length']>oi/0x3&&Pn(_0x156d97)>oi)throw new Error(_0x59b619+'contains\x20a\x20string\x20greater\x20than\x20'+oi+'\x20utf8\x20bytes\x20'+Ne(_0x440ff0)+'\x20(\x27'+_0x156d97['substring'](0x0,0x32)+'...\x27)');if(_0x156d97&&typeof _0x156d97=='object'){let _0x4955d5=!0x1,_0x24baf1=!0x1;if(x(_0x156d97,(_0x287bd8,_0x2b8dde)=>{if(_0x287bd8==='.value')_0x4955d5=!0x0;else{if(_0x287bd8!=='.priority'&&_0x287bd8!=='.sv'&&(_0x24baf1=!0x0,!ps(_0x287bd8)))throw new Error(_0x59b619+'\x20contains\x20an\x20invalid\x20key\x20('+_0x287bd8+')\x20'+Ne(_0x440ff0)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}bh(_0x440ff0,_0x287bd8),zt(_0x59b619,_0x2b8dde,_0x440ff0),Rh(_0x440ff0);}),_0x4955d5&&_0x24baf1)throw new Error(_0x59b619+'\x20contains\x20\x22.value\x22\x20child\x20'+Ne(_0x440ff0)+'\x20in\x20addition\x20to\x20actual\x20children.');}},ld=function(_0x20d66a,_0x46cb34){let _0x32f4f3,_0x34d093;for(_0x32f4f3=0x0;_0x32f4f3<_0x46cb34['length'];_0x32f4f3++){_0x34d093=_0x46cb34[_0x32f4f3];const _0x1fedf8=kt(_0x34d093);for(let _0x1c56f7=0x0;_0x1c56f7<_0x1fedf8['length'];_0x1c56f7++)if(!(_0x1fedf8[_0x1c56f7]==='.priority'&&_0x1c56f7===_0x1fedf8['length']-0x1)){if(!ps(_0x1fedf8[_0x1c56f7]))throw new Error(_0x20d66a+'contains\x20an\x20invalid\x20key\x20('+_0x1fedf8[_0x1c56f7]+')\x20in\x20path\x20'+_0x34d093['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x46cb34['sort'](Th);let _0x2dda55=null;for(_0x32f4f3=0x0;_0x32f4f3<_0x46cb34['length'];_0x32f4f3++){if(_0x34d093=_0x46cb34[_0x32f4f3],_0x2dda55!==null&&$(_0x2dda55,_0x34d093))throw new Error(_0x20d66a+'contains\x20a\x20path\x20'+_0x2dda55['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x34d093['toString']());_0x2dda55=_0x34d093;}},hd=function(_0x2efa19,_0x163804,_0x5e9637,_0xdb3767){const _0x395573=Nn(_0x2efa19,'values');if(!(_0x163804&&typeof _0x163804=='object')||Array['isArray'](_0x163804))throw new Error(_0x395573+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x22132f=[];x(_0x163804,(_0x236a1c,_0x48f4c3)=>{const _0x32f713=new C(_0x236a1c);if(zt(_0x395573,_0x48f4c3,A(_0x5e9637,_0x32f713)),Gi(_0x32f713)==='.priority'&&!Cn(_0x48f4c3))throw new Error(_0x395573+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x32f713['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x22132f['push'](_0x32f713);}),ld(_0x395573,_0x22132f);},_s=function(_0x582e05,_0x525310,_0x2460f8,_0x203f0c){if(!na(_0x2460f8))throw new Error(Nn(_0x582e05,_0x525310)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x2460f8+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},ud=function(_0x15957a,_0x2f99ee,_0x5da9b5,_0x1945a8){_0x5da9b5&&(_0x5da9b5=_0x5da9b5['replace'](/^\/*\.info(\/|$)/,'/')),_s(_0x15957a,_0x2f99ee,_0x5da9b5);},gs=function(_0x2830d8,_0x41cb5b){if(y(_0x41cb5b)==='.info')throw new Error(_0x2830d8+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},dd=function(_0x19e4ea,_0x137387){const _0x4e45cd=_0x137387['path']['toString']();if(typeof _0x137387['repoInfo']['host']!='string'||_0x137387['repoInfo']['host']['length']===0x0||!ps(_0x137387['repoInfo']['namespace'])&&_0x137387['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x4e45cd['length']!==0x0&&!cd(_0x4e45cd))throw new Error(Nn(_0x19e4ea,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Bn(_0x307f2b,_0x14edc7){let _0x153432=null;for(let _0x451df6=0x0;_0x451df6<_0x14edc7['length'];_0x451df6++){const _0x42064a=_0x14edc7[_0x451df6],_0x1594d0=_0x42064a['getPath']();_0x153432!==null&&!qi(_0x1594d0,_0x153432['path'])&&(_0x307f2b['eventLists_']['push'](_0x153432),_0x153432=null),_0x153432===null&&(_0x153432={'events':[],'path':_0x1594d0}),_0x153432['events']['push'](_0x42064a);}_0x153432&&_0x307f2b['eventLists_']['push'](_0x153432);}function ia(_0x1e0ba3,_0x4e55c6,_0x14d18d){Bn(_0x1e0ba3,_0x14d18d),sa(_0x1e0ba3,_0x12832d=>qi(_0x12832d,_0x4e55c6));}function V(_0x5cd31c,_0x3ffa6b,_0x2d3a29){Bn(_0x5cd31c,_0x2d3a29),sa(_0x5cd31c,_0x58416d=>$(_0x58416d,_0x3ffa6b)||$(_0x3ffa6b,_0x58416d));}function sa(_0xb5a79,_0x4b2165){_0xb5a79['recursionDepth_']++;let _0x19a1cd=!0x0;for(let _0x139e2c=0x0;_0x139e2c<_0xb5a79['eventLists_']['length'];_0x139e2c++){const _0x4a8a36=_0xb5a79['eventLists_'][_0x139e2c];if(_0x4a8a36){const _0x496f88=_0x4a8a36['path'];_0x4b2165(_0x496f88)?(pd(_0xb5a79['eventLists_'][_0x139e2c]),_0xb5a79['eventLists_'][_0x139e2c]=null):_0x19a1cd=!0x1;}}_0x19a1cd&&(_0xb5a79['eventLists_']=[]),_0xb5a79['recursionDepth_']--;}function pd(_0x4db134){for(let _0x117df7=0x0;_0x117df7<_0x4db134['events']['length'];_0x117df7++){const _0x3fc1e3=_0x4db134['events'][_0x117df7];if(_0x3fc1e3!==null){_0x4db134['events'][_0x117df7]=null;const _0x100bb9=_0x3fc1e3['getEventRunner']();Et&&L('event:\x20'+_0x3fc1e3['toString']()),lt(_0x100bb9);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ra='repo_interrupt',_d=0x19;class gd{constructor(_0x260168,_0x5a748f,_0x46ecbc,_0x40d0ec){this['repoInfo_']=_0x260168,this['forceRestClient_']=_0x5a748f,this['authTokenProvider_']=_0x46ecbc,this['appCheckProvider_']=_0x40d0ec,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new fd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=pn(),this['transactionQueueTree_']=new ds(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function md(_0x18d68e,_0x3f9660,_0x4b7efa){if(_0x18d68e['stats_']=Hi(_0x18d68e['repoInfo_']),_0x18d68e['forceRestClient_']||Yl())_0x18d68e['server_']=new fn(_0x18d68e['repoInfo_'],(_0x2e4281,_0x5b0cd5,_0x8c31ac,_0x2e8d5f)=>{pr(_0x18d68e,_0x2e4281,_0x5b0cd5,_0x8c31ac,_0x2e8d5f);},_0x18d68e['authTokenProvider_'],_0x18d68e['appCheckProvider_']),setTimeout(()=>_r(_0x18d68e,!0x0),0x0);else{if(typeof _0x4b7efa<'u'&&_0x4b7efa!==null){if(typeof _0x4b7efa!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x4b7efa);}catch(_0x156b54){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x156b54);}}_0x18d68e['persistentConnection_']=new ie(_0x18d68e['repoInfo_'],_0x3f9660,(_0x518e48,_0x4a6b49,_0x2df2b0,_0x233a99)=>{pr(_0x18d68e,_0x518e48,_0x4a6b49,_0x2df2b0,_0x233a99);},_0x2ba035=>{_r(_0x18d68e,_0x2ba035);},_0x40166c=>{yd(_0x18d68e,_0x40166c);},_0x18d68e['authTokenProvider_'],_0x18d68e['appCheckProvider_'],_0x4b7efa),_0x18d68e['server_']=_0x18d68e['persistentConnection_'];}_0x18d68e['authTokenProvider_']['addTokenChangeListener'](_0x2ebbb8=>{_0x18d68e['server_']['refreshAuthToken'](_0x2ebbb8);}),_0x18d68e['appCheckProvider_']['addTokenChangeListener'](_0x2fbe9e=>{_0x18d68e['server_']['refreshAppCheckToken'](_0x2fbe9e['token']);}),_0x18d68e['statsReporter_']=eh(_0x18d68e['repoInfo_'],()=>new eu(_0x18d68e['stats_'],_0x18d68e['server_'])),_0x18d68e['infoData_']=new Yh(),_0x18d68e['infoSyncTree_']=new dr({'startListening':(_0xcbe7c0,_0xb2f2b4,_0x398e95,_0x350658)=>{let _0x53ba95=[];const _0x14745b=_0x18d68e['infoData_']['getNode'](_0xcbe7c0['_path']);return _0x14745b['isEmpty']()||(_0x53ba95=$t(_0x18d68e['infoSyncTree_'],_0xcbe7c0['_path'],_0x14745b),setTimeout(()=>{_0x350658('ok');},0x0)),_0x53ba95;},'stopListening':()=>{}}),ms(_0x18d68e,'connected',!0x1),_0x18d68e['serverSyncTree_']=new dr({'startListening':(_0x4705b3,_0x569208,_0x345781,_0x3f795c)=>(_0x18d68e['server_']['listen'](_0x4705b3,_0x345781,_0x569208,(_0x499c84,_0x26e49e)=>{const _0x39598f=_0x3f795c(_0x499c84,_0x26e49e);V(_0x18d68e['eventQueue_'],_0x4705b3['_path'],_0x39598f);}),[]),'stopListening':(_0x544752,_0x274d42)=>{_0x18d68e['server_']['unlisten'](_0x544752,_0x274d42);}});}function oa(_0x42a50b){const _0x55c888=_0x42a50b['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x55c888;}function jt(_0x5413c9){return ed({'timestamp':oa(_0x5413c9)});}function pr(_0x5c6fa1,_0x4b8b09,_0xc0447f,_0x17b427,_0xbe24ed){_0x5c6fa1['dataUpdateCount']++;const _0x4834eb=new C(_0x4b8b09);_0xc0447f=_0x5c6fa1['interceptServerDataCallback_']?_0x5c6fa1['interceptServerDataCallback_'](_0x4b8b09,_0xc0447f):_0xc0447f;let _0x19915f=[];if(_0xbe24ed){if(_0x17b427){const _0x102f11=ln(_0xc0447f,_0x1a8f52=>N(_0x1a8f52));_0x19915f=Ku(_0x5c6fa1['serverSyncTree_'],_0x4834eb,_0x102f11,_0xbe24ed);}else{const _0x2d0d3c=N(_0xc0447f);_0x19915f=Yo(_0x5c6fa1['serverSyncTree_'],_0x4834eb,_0x2d0d3c,_0xbe24ed);}}else{if(_0x17b427){const _0x34894a=ln(_0xc0447f,_0x28fe71=>N(_0x28fe71));_0x19915f=qu(_0x5c6fa1['serverSyncTree_'],_0x4834eb,_0x34894a);}else{const _0x5bb533=N(_0xc0447f);_0x19915f=$t(_0x5c6fa1['serverSyncTree_'],_0x4834eb,_0x5bb533);}}let _0x11d37e=_0x4834eb;_0x19915f['length']>0x0&&(_0x11d37e=st(_0x5c6fa1,_0x4834eb)),V(_0x5c6fa1['eventQueue_'],_0x11d37e,_0x19915f);}function _r(_0x871acf,_0xa59e24){ms(_0x871acf,'connected',_0xa59e24),_0xa59e24===!0x1&&wd(_0x871acf);}function yd(_0x3711c7,_0x2ac329){x(_0x2ac329,(_0x373413,_0x220f0b)=>{ms(_0x3711c7,_0x373413,_0x220f0b);});}function ms(_0x114b4c,_0x4c7705,_0x42f8ea){const _0x57e67c=new C('/.info/'+_0x4c7705),_0x3f722e=N(_0x42f8ea);_0x114b4c['infoData_']['updateSnapshot'](_0x57e67c,_0x3f722e);const _0x575825=$t(_0x114b4c['infoSyncTree_'],_0x57e67c,_0x3f722e);V(_0x114b4c['eventQueue_'],_0x57e67c,_0x575825);}function Vn(_0xa11416){return _0xa11416['nextWriteId_']++;}function vd(_0x438336,_0x7a8c88,_0x3d7e7b){const _0x120e16=Yu(_0x438336['serverSyncTree_'],_0x7a8c88);return _0x120e16!=null?Promise['resolve'](_0x120e16):_0x438336['server_']['get'](_0x7a8c88)['then'](_0x6e453c=>{const _0x1c8577=N(_0x6e453c)['withIndex'](_0x7a8c88['_queryParams']['getIndex']());bi(_0x438336['serverSyncTree_'],_0x7a8c88,_0x3d7e7b,!0x0);let _0x442a36;if(_0x7a8c88['_queryParams']['loadsAllData']())_0x442a36=$t(_0x438336['serverSyncTree_'],_0x7a8c88['_path'],_0x1c8577);else{const _0x26faf3=Mt(_0x438336['serverSyncTree_'],_0x7a8c88);_0x442a36=Yo(_0x438336['serverSyncTree_'],_0x7a8c88['_path'],_0x1c8577,_0x26faf3);}return V(_0x438336['eventQueue_'],_0x7a8c88['_path'],_0x442a36),wn(_0x438336['serverSyncTree_'],_0x7a8c88,_0x3d7e7b,null,!0x0),_0x1c8577;},_0xd4484=>(ut(_0x438336,'get\x20for\x20query\x20'+O(_0x7a8c88)+'\x20failed:\x20'+_0xd4484),Promise['reject'](new Error(_0xd4484))));}function Ed(_0x2c1716,_0x257907,_0x756190,_0x4ef29a,_0x1569b5){ut(_0x2c1716,'set',{'path':_0x257907['toString'](),'value':_0x756190,'priority':_0x4ef29a});const _0x8e8718=jt(_0x2c1716),_0x3ad2cf=N(_0x756190,_0x4ef29a),_0x88005a=xn(_0x2c1716['serverSyncTree_'],_0x257907),_0x1c1b33=hs(_0x3ad2cf,_0x88005a,_0x8e8718),_0x5a9a62=Vn(_0x2c1716),_0x38727b=ss(_0x2c1716['serverSyncTree_'],_0x257907,_0x1c1b33,_0x5a9a62,!0x0);Bn(_0x2c1716['eventQueue_'],_0x38727b),_0x2c1716['server_']['put'](_0x257907['toString'](),_0x3ad2cf['val'](!0x0),(_0x17060a,_0x5d2559)=>{const _0x282167=_0x17060a==='ok';_0x282167||U('set\x20at\x20'+_0x257907+'\x20failed:\x20'+_0x17060a);const _0x461c1e=pe(_0x2c1716['serverSyncTree_'],_0x5a9a62,!_0x282167);V(_0x2c1716['eventQueue_'],_0x257907,_0x461c1e),Ai(_0x2c1716,_0x1569b5,_0x17060a,_0x5d2559);});const _0xde44d3=vs(_0x2c1716,_0x257907);st(_0x2c1716,_0xde44d3),V(_0x2c1716['eventQueue_'],_0xde44d3,[]);}function Id(_0x20e21f,_0x1707e8,_0x4ddfe4,_0x300e0f){ut(_0x20e21f,'update',{'path':_0x1707e8['toString'](),'value':_0x4ddfe4});let _0x3e10fa=!0x0;const _0x46d3d6=jt(_0x20e21f),_0x298839={};if(x(_0x4ddfe4,(_0x6b22d,_0x30065e)=>{_0x3e10fa=!0x1,_0x298839[_0x6b22d]=Zo(A(_0x1707e8,_0x6b22d),N(_0x30065e),_0x20e21f['serverSyncTree_'],_0x46d3d6);}),_0x3e10fa)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),Ai(_0x20e21f,_0x300e0f,'ok',void 0x0);else{const _0x137d2f=Vn(_0x20e21f),_0x101f26=Gu(_0x20e21f['serverSyncTree_'],_0x1707e8,_0x298839,_0x137d2f);Bn(_0x20e21f['eventQueue_'],_0x101f26),_0x20e21f['server_']['merge'](_0x1707e8['toString'](),_0x4ddfe4,(_0x14819f,_0x15f75d)=>{const _0x234951=_0x14819f==='ok';_0x234951||U('update\x20at\x20'+_0x1707e8+'\x20failed:\x20'+_0x14819f);const _0x5d6e11=pe(_0x20e21f['serverSyncTree_'],_0x137d2f,!_0x234951),_0x3befe8=_0x5d6e11['length']>0x0?st(_0x20e21f,_0x1707e8):_0x1707e8;V(_0x20e21f['eventQueue_'],_0x3befe8,_0x5d6e11),Ai(_0x20e21f,_0x300e0f,_0x14819f,_0x15f75d);}),x(_0x4ddfe4,_0x56d8b1=>{const _0x126dce=vs(_0x20e21f,A(_0x1707e8,_0x56d8b1));st(_0x20e21f,_0x126dce);}),V(_0x20e21f['eventQueue_'],_0x1707e8,[]);}}function wd(_0x56af09){ut(_0x56af09,'onDisconnectEvents');const _0x521399=jt(_0x56af09),_0x3bdcc5=pn();Ei(_0x56af09['onDisconnect_'],w(),(_0x4869b1,_0x464fd6)=>{const _0x38a922=Zo(_0x4869b1,_0x464fd6,_0x56af09['serverSyncTree_'],_0x521399);Mo(_0x3bdcc5,_0x4869b1,_0x38a922);});let _0x49b4c4=[];Ei(_0x3bdcc5,w(),(_0x508ef4,_0x20f7ce)=>{_0x49b4c4=_0x49b4c4['concat']($t(_0x56af09['serverSyncTree_'],_0x508ef4,_0x20f7ce));const _0x4927ee=vs(_0x56af09,_0x508ef4);st(_0x56af09,_0x4927ee);}),_0x56af09['onDisconnect_']=pn(),V(_0x56af09['eventQueue_'],w(),_0x49b4c4);}function Cd(_0x4f8440,_0x2559fd,_0x14b8b6){let _0x39fbc8;y(_0x2559fd['_path'])==='.info'?_0x39fbc8=bi(_0x4f8440['infoSyncTree_'],_0x2559fd,_0x14b8b6):_0x39fbc8=bi(_0x4f8440['serverSyncTree_'],_0x2559fd,_0x14b8b6),ia(_0x4f8440['eventQueue_'],_0x2559fd['_path'],_0x39fbc8);}function Td(_0x2f4771,_0x1cd253,_0x3b28b0){let _0x17d347;y(_0x1cd253['_path'])==='.info'?_0x17d347=wn(_0x2f4771['infoSyncTree_'],_0x1cd253,_0x3b28b0):_0x17d347=wn(_0x2f4771['serverSyncTree_'],_0x1cd253,_0x3b28b0),ia(_0x2f4771['eventQueue_'],_0x1cd253['_path'],_0x17d347);}function aa(_0x475ecb){_0x475ecb['persistentConnection_']&&_0x475ecb['persistentConnection_']['interrupt'](ra);}function Sd(_0x4947b8){_0x4947b8['persistentConnection_']&&_0x4947b8['persistentConnection_']['resume'](ra);}function ut(_0x41d82e,..._0x19587a){let _0x583a0e='';_0x41d82e['persistentConnection_']&&(_0x583a0e=_0x41d82e['persistentConnection_']['id']+':'),L(_0x583a0e,..._0x19587a);}function Ai(_0x13af45,_0x2b5eff,_0x30ef9b,_0x244fdc){_0x2b5eff&&lt(()=>{if(_0x30ef9b==='ok')_0x2b5eff(null);else{const _0x49f4c3=(_0x30ef9b||'error')['toUpperCase']();let _0x3b24c5=_0x49f4c3;_0x244fdc&&(_0x3b24c5+=':\x20'+_0x244fdc);const _0x5163a6=new Error(_0x3b24c5);_0x5163a6['code']=_0x49f4c3,_0x2b5eff(_0x5163a6);}});}function bd(_0x4e3775,_0xc8936b,_0x21e5d3,_0x539155,_0x567722,_0x14e69f){ut(_0x4e3775,'transaction\x20on\x20'+_0xc8936b);const _0x10218e={'path':_0xc8936b,'update':_0x21e5d3,'onComplete':_0x539155,'status':null,'order':to(),'applyLocally':_0x14e69f,'retryCount':0x0,'unwatcher':_0x567722,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x1996a5=ys(_0x4e3775,_0xc8936b,void 0x0);_0x10218e['currentInputSnapshot']=_0x1996a5;const _0x134c4f=_0x10218e['update'](_0x1996a5['val']());if(_0x134c4f===void 0x0)_0x10218e['unwatcher'](),_0x10218e['currentOutputSnapshotRaw']=null,_0x10218e['currentOutputSnapshotResolved']=null,_0x10218e['onComplete']&&_0x10218e['onComplete'](null,!0x1,_0x10218e['currentInputSnapshot']);else{zt('transaction\x20failed:\x20Data\x20returned\x20',_0x134c4f,_0x10218e['path']),_0x10218e['status']=0x0;const _0x6e8432=Un(_0x4e3775['transactionQueueTree_'],_0xc8936b),_0x144131=Ge(_0x6e8432)||[];_0x144131['push'](_0x10218e),fs(_0x6e8432,_0x144131);let _0x27647e;typeof _0x134c4f=='object'&&_0x134c4f!==null&&Y(_0x134c4f,'.priority')?(_0x27647e=Oe(_0x134c4f,'.priority'),f(Cn(_0x27647e),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x27647e=(xn(_0x4e3775['serverSyncTree_'],_0xc8936b)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x43141d=jt(_0x4e3775),_0x3c14bf=N(_0x134c4f,_0x27647e),_0x31d095=hs(_0x3c14bf,_0x1996a5,_0x43141d);_0x10218e['currentOutputSnapshotRaw']=_0x3c14bf,_0x10218e['currentOutputSnapshotResolved']=_0x31d095,_0x10218e['currentWriteId']=Vn(_0x4e3775);const _0x13c8d2=ss(_0x4e3775['serverSyncTree_'],_0xc8936b,_0x31d095,_0x10218e['currentWriteId'],_0x10218e['applyLocally']);V(_0x4e3775['eventQueue_'],_0xc8936b,_0x13c8d2),Hn(_0x4e3775,_0x4e3775['transactionQueueTree_']);}}function ys(_0x53cf90,_0x42857b,_0x46bee2){return xn(_0x53cf90['serverSyncTree_'],_0x42857b,_0x46bee2)||g['EMPTY_NODE'];}function Hn(_0x34e0a4,_0x260e05=_0x34e0a4['transactionQueueTree_']){if(_0x260e05||$n(_0x34e0a4,_0x260e05),Ge(_0x260e05)){const _0x3d9865=la(_0x34e0a4,_0x260e05);f(_0x3d9865['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x3d9865['every'](_0x5a47ab=>_0x5a47ab['status']===0x0)&&Rd(_0x34e0a4,Gt(_0x260e05),_0x3d9865);}else ea(_0x260e05)&&Wn(_0x260e05,_0x18ef64=>{Hn(_0x34e0a4,_0x18ef64);});}function Rd(_0x1db9a5,_0x87bb0c,_0x4ce06e){const _0x4df97d=_0x4ce06e['map'](_0x17c059=>_0x17c059['currentWriteId']),_0x571f59=ys(_0x1db9a5,_0x87bb0c,_0x4df97d);let _0x5df3f1=_0x571f59;const _0x5cff3a=_0x571f59['hash']();for(let _0x176f3e=0x0;_0x176f3e<_0x4ce06e['length'];_0x176f3e++){const _0x4a682f=_0x4ce06e[_0x176f3e];f(_0x4a682f['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x4a682f['status']=0x1,_0x4a682f['retryCount']++;const _0x41fd6b=F(_0x87bb0c,_0x4a682f['path']);_0x5df3f1=_0x5df3f1['updateChild'](_0x41fd6b,_0x4a682f['currentOutputSnapshotRaw']);}const _0x3e25ce=_0x5df3f1['val'](!0x0),_0x2e14cb=_0x87bb0c;_0x1db9a5['server_']['put'](_0x2e14cb['toString'](),_0x3e25ce,_0x367dd6=>{ut(_0x1db9a5,'transaction\x20put\x20response',{'path':_0x2e14cb['toString'](),'status':_0x367dd6});let _0x1bb052=[];if(_0x367dd6==='ok'){const _0x52599f=[];for(let _0x83aecf=0x0;_0x83aecf<_0x4ce06e['length'];_0x83aecf++)_0x4ce06e[_0x83aecf]['status']=0x2,_0x1bb052=_0x1bb052['concat'](pe(_0x1db9a5['serverSyncTree_'],_0x4ce06e[_0x83aecf]['currentWriteId'])),_0x4ce06e[_0x83aecf]['onComplete']&&_0x52599f['push'](()=>_0x4ce06e[_0x83aecf]['onComplete'](null,!0x0,_0x4ce06e[_0x83aecf]['currentOutputSnapshotResolved'])),_0x4ce06e[_0x83aecf]['unwatcher']();$n(_0x1db9a5,Un(_0x1db9a5['transactionQueueTree_'],_0x87bb0c)),Hn(_0x1db9a5,_0x1db9a5['transactionQueueTree_']),V(_0x1db9a5['eventQueue_'],_0x87bb0c,_0x1bb052);for(let _0x2c44b8=0x0;_0x2c44b8<_0x52599f['length'];_0x2c44b8++)lt(_0x52599f[_0x2c44b8]);}else{if(_0x367dd6==='datastale'){for(let _0x3ed1cb=0x0;_0x3ed1cb<_0x4ce06e['length'];_0x3ed1cb++)_0x4ce06e[_0x3ed1cb]['status']===0x3?_0x4ce06e[_0x3ed1cb]['status']=0x4:_0x4ce06e[_0x3ed1cb]['status']=0x0;}else{U('transaction\x20at\x20'+_0x2e14cb['toString']()+'\x20failed:\x20'+_0x367dd6);for(let _0x1e2655=0x0;_0x1e2655<_0x4ce06e['length'];_0x1e2655++)_0x4ce06e[_0x1e2655]['status']=0x4,_0x4ce06e[_0x1e2655]['abortReason']=_0x367dd6;}st(_0x1db9a5,_0x87bb0c);}},_0x5cff3a);}function st(_0x5c5a1b,_0x2b57fa){const _0x49e601=ca(_0x5c5a1b,_0x2b57fa),_0x4750f6=Gt(_0x49e601),_0x445cf5=la(_0x5c5a1b,_0x49e601);return Ad(_0x5c5a1b,_0x445cf5,_0x4750f6),_0x4750f6;}function Ad(_0x5062fd,_0x179429,_0xdceb20){if(_0x179429['length']===0x0)return;const _0x3090b7=[];let _0x3acf09=[];const _0x563215=_0x179429['filter'](_0x3184b2=>_0x3184b2['status']===0x0)['map'](_0x586fe4=>_0x586fe4['currentWriteId']);for(let _0x47f26b=0x0;_0x47f26b<_0x179429['length'];_0x47f26b++){const _0x1bd389=_0x179429[_0x47f26b],_0x510014=F(_0xdceb20,_0x1bd389['path']);let _0x2ce198=!0x1,_0x2afd87;if(f(_0x510014!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x1bd389['status']===0x4)_0x2ce198=!0x0,_0x2afd87=_0x1bd389['abortReason'],_0x3acf09=_0x3acf09['concat'](pe(_0x5062fd['serverSyncTree_'],_0x1bd389['currentWriteId'],!0x0));else{if(_0x1bd389['status']===0x0){if(_0x1bd389['retryCount']>=_d)_0x2ce198=!0x0,_0x2afd87='maxretry',_0x3acf09=_0x3acf09['concat'](pe(_0x5062fd['serverSyncTree_'],_0x1bd389['currentWriteId'],!0x0));else{const _0x394a84=ys(_0x5062fd,_0x1bd389['path'],_0x563215);_0x1bd389['currentInputSnapshot']=_0x394a84;const _0x79a142=_0x179429[_0x47f26b]['update'](_0x394a84['val']());if(_0x79a142!==void 0x0){zt('transaction\x20failed:\x20Data\x20returned\x20',_0x79a142,_0x1bd389['path']);let _0x351118=N(_0x79a142);typeof _0x79a142=='object'&&_0x79a142!=null&&Y(_0x79a142,'.priority')||(_0x351118=_0x351118['updatePriority'](_0x394a84['getPriority']()));const _0xdd2991=_0x1bd389['currentWriteId'],_0x56b60f=jt(_0x5062fd),_0x27e785=hs(_0x351118,_0x394a84,_0x56b60f);_0x1bd389['currentOutputSnapshotRaw']=_0x351118,_0x1bd389['currentOutputSnapshotResolved']=_0x27e785,_0x1bd389['currentWriteId']=Vn(_0x5062fd),_0x563215['splice'](_0x563215['indexOf'](_0xdd2991),0x1),_0x3acf09=_0x3acf09['concat'](ss(_0x5062fd['serverSyncTree_'],_0x1bd389['path'],_0x27e785,_0x1bd389['currentWriteId'],_0x1bd389['applyLocally'])),_0x3acf09=_0x3acf09['concat'](pe(_0x5062fd['serverSyncTree_'],_0xdd2991,!0x0));}else _0x2ce198=!0x0,_0x2afd87='nodata',_0x3acf09=_0x3acf09['concat'](pe(_0x5062fd['serverSyncTree_'],_0x1bd389['currentWriteId'],!0x0));}}}V(_0x5062fd['eventQueue_'],_0xdceb20,_0x3acf09),_0x3acf09=[],_0x2ce198&&(_0x179429[_0x47f26b]['status']=0x2,function(_0x1c170b){setTimeout(_0x1c170b,Math['floor'](0x0));}(_0x179429[_0x47f26b]['unwatcher']),_0x179429[_0x47f26b]['onComplete']&&(_0x2afd87==='nodata'?_0x3090b7['push'](()=>_0x179429[_0x47f26b]['onComplete'](null,!0x1,_0x179429[_0x47f26b]['currentInputSnapshot'])):_0x3090b7['push'](()=>_0x179429[_0x47f26b]['onComplete'](new Error(_0x2afd87),!0x1,null))));}$n(_0x5062fd,_0x5062fd['transactionQueueTree_']);for(let _0x3a09be=0x0;_0x3a09be<_0x3090b7['length'];_0x3a09be++)lt(_0x3090b7[_0x3a09be]);Hn(_0x5062fd,_0x5062fd['transactionQueueTree_']);}function ca(_0x1c1be1,_0x391fe9){let _0x20e9b6,_0x32ee10=_0x1c1be1['transactionQueueTree_'];for(_0x20e9b6=y(_0x391fe9);_0x20e9b6!==null&&Ge(_0x32ee10)===void 0x0;)_0x32ee10=Un(_0x32ee10,_0x20e9b6),_0x391fe9=b(_0x391fe9),_0x20e9b6=y(_0x391fe9);return _0x32ee10;}function la(_0x3a26a3,_0x1718a7){const _0x3cab69=[];return ha(_0x3a26a3,_0x1718a7,_0x3cab69),_0x3cab69['sort']((_0x376095,_0x2332e3)=>_0x376095['order']-_0x2332e3['order']),_0x3cab69;}function ha(_0x1a6345,_0x1b1512,_0x1579c5){const _0x4bf8e2=Ge(_0x1b1512);if(_0x4bf8e2){for(let _0x2f42d6=0x0;_0x2f42d6<_0x4bf8e2['length'];_0x2f42d6++)_0x1579c5['push'](_0x4bf8e2[_0x2f42d6]);}Wn(_0x1b1512,_0x1215e7=>{ha(_0x1a6345,_0x1215e7,_0x1579c5);});}function $n(_0x48b3d5,_0x50a3ee){const _0x181bee=Ge(_0x50a3ee);if(_0x181bee){let _0x145cca=0x0;for(let _0x559aae=0x0;_0x559aae<_0x181bee['length'];_0x559aae++)_0x181bee[_0x559aae]['status']!==0x2&&(_0x181bee[_0x145cca]=_0x181bee[_0x559aae],_0x145cca++);_0x181bee['length']=_0x145cca,fs(_0x50a3ee,_0x181bee['length']>0x0?_0x181bee:void 0x0);}Wn(_0x50a3ee,_0x264e40=>{$n(_0x48b3d5,_0x264e40);});}function vs(_0x421c2e,_0x1d06cd){const _0x52b935=Gt(ca(_0x421c2e,_0x1d06cd)),_0x1a9db5=Un(_0x421c2e['transactionQueueTree_'],_0x1d06cd);return sd(_0x1a9db5,_0x28ffeb=>{ai(_0x421c2e,_0x28ffeb);}),ai(_0x421c2e,_0x1a9db5),ta(_0x1a9db5,_0x5d4d23=>{ai(_0x421c2e,_0x5d4d23);}),_0x52b935;}function ai(_0x1b64b9,_0x653cf4){const _0x5256ca=Ge(_0x653cf4);if(_0x5256ca){const _0x844591=[];let _0x546f15=[],_0x52bd63=-0x1;for(let _0x53ce76=0x0;_0x53ce76<_0x5256ca['length'];_0x53ce76++)_0x5256ca[_0x53ce76]['status']===0x3||(_0x5256ca[_0x53ce76]['status']===0x1?(f(_0x52bd63===_0x53ce76-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x52bd63=_0x53ce76,_0x5256ca[_0x53ce76]['status']=0x3,_0x5256ca[_0x53ce76]['abortReason']='set'):(f(_0x5256ca[_0x53ce76]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x5256ca[_0x53ce76]['unwatcher'](),_0x546f15=_0x546f15['concat'](pe(_0x1b64b9['serverSyncTree_'],_0x5256ca[_0x53ce76]['currentWriteId'],!0x0)),_0x5256ca[_0x53ce76]['onComplete']&&_0x844591['push'](_0x5256ca[_0x53ce76]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x52bd63===-0x1?fs(_0x653cf4,void 0x0):_0x5256ca['length']=_0x52bd63+0x1,V(_0x1b64b9['eventQueue_'],Gt(_0x653cf4),_0x546f15);for(let _0x3e67ab=0x0;_0x3e67ab<_0x844591['length'];_0x3e67ab++)lt(_0x844591[_0x3e67ab]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function kd(_0x3be541){let _0x318185='';const _0x50d804=_0x3be541['split']('/');for(let _0x47b908=0x0;_0x47b908<_0x50d804['length'];_0x47b908++)if(_0x50d804[_0x47b908]['length']>0x0){let _0x217ebc=_0x50d804[_0x47b908];try{_0x217ebc=decodeURIComponent(_0x217ebc['replace'](/\+/g,'\x20'));}catch{}_0x318185+='/'+_0x217ebc;}return _0x318185;}function Nd(_0x150765){const _0x49aefe={};_0x150765['charAt'](0x0)==='?'&&(_0x150765=_0x150765['substring'](0x1));for(const _0x1810c4 of _0x150765['split']('&')){if(_0x1810c4['length']===0x0)continue;const _0x36b934=_0x1810c4['split']('=');_0x36b934['length']===0x2?_0x49aefe[decodeURIComponent(_0x36b934[0x0])]=decodeURIComponent(_0x36b934[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x1810c4+'\x27\x20in\x20query\x20\x27'+_0x150765+'\x27');}return _0x49aefe;}const gr=function(_0x14e722,_0x26ab20){const _0x2fb514=Pd(_0x14e722),_0x33e06e=_0x2fb514['namespace'];_0x2fb514['domain']==='firebase.com'&&oe(_0x2fb514['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x33e06e||_0x33e06e==='undefined')&&_0x2fb514['domain']!=='localhost'&&oe('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x2fb514['secure']||Bl();const _0x128bf0=_0x2fb514['scheme']==='ws'||_0x2fb514['scheme']==='wss';return{'repoInfo':new _o(_0x2fb514['host'],_0x2fb514['secure'],_0x33e06e,_0x128bf0,_0x26ab20,'',_0x33e06e!==_0x2fb514['subdomain']),'path':new C(_0x2fb514['pathString'])};},Pd=function(_0x439107){let _0x139e57='',_0x4bc498='',_0xeab566='',_0x283508='',_0x4e812b='',_0x38b127=!0x0,_0x5dc6e4='https',_0x3a8ce3=0x1bb;if(typeof _0x439107=='string'){let _0x5cb28b=_0x439107['indexOf']('//');_0x5cb28b>=0x0&&(_0x5dc6e4=_0x439107['substring'](0x0,_0x5cb28b-0x1),_0x439107=_0x439107['substring'](_0x5cb28b+0x2));let _0x5980ee=_0x439107['indexOf']('/');_0x5980ee===-0x1&&(_0x5980ee=_0x439107['length']);let _0x217859=_0x439107['indexOf']('?');_0x217859===-0x1&&(_0x217859=_0x439107['length']),_0x139e57=_0x439107['substring'](0x0,Math['min'](_0x5980ee,_0x217859)),_0x5980ee<_0x217859&&(_0x283508=kd(_0x439107['substring'](_0x5980ee,_0x217859)));const _0x3150b0=Nd(_0x439107['substring'](Math['min'](_0x439107['length'],_0x217859)));_0x5cb28b=_0x139e57['indexOf'](':'),_0x5cb28b>=0x0?(_0x38b127=_0x5dc6e4==='https'||_0x5dc6e4==='wss',_0x3a8ce3=parseInt(_0x139e57['substring'](_0x5cb28b+0x1),0xa)):_0x5cb28b=_0x139e57['length'];const _0x49fc22=_0x139e57['slice'](0x0,_0x5cb28b);if(_0x49fc22['toLowerCase']()==='localhost')_0x4bc498='localhost';else{if(_0x49fc22['split']('.')['length']<=0x2)_0x4bc498=_0x49fc22;else{const _0x191b5e=_0x139e57['indexOf']('.');_0xeab566=_0x139e57['substring'](0x0,_0x191b5e)['toLowerCase'](),_0x4bc498=_0x139e57['substring'](_0x191b5e+0x1),_0x4e812b=_0xeab566;}}'ns'in _0x3150b0&&(_0x4e812b=_0x3150b0['ns']);}return{'host':_0x139e57,'port':_0x3a8ce3,'domain':_0x4bc498,'subdomain':_0xeab566,'secure':_0x38b127,'scheme':_0x5dc6e4,'pathString':_0x283508,'namespace':_0x4e812b};},mr='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Od=(function(){let _0x5f58c2=0x0;const _0x2caf2c=[];return function(_0x22037c){const _0x11a9b1=_0x22037c===_0x5f58c2;_0x5f58c2=_0x22037c;let _0x3b4b79;const _0x30bbf4=new Array(0x8);for(_0x3b4b79=0x7;_0x3b4b79>=0x0;_0x3b4b79--)_0x30bbf4[_0x3b4b79]=mr['charAt'](_0x22037c%0x40),_0x22037c=Math['floor'](_0x22037c/0x40);f(_0x22037c===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x5934c5=_0x30bbf4['join']('');if(_0x11a9b1){for(_0x3b4b79=0xb;_0x3b4b79>=0x0&&_0x2caf2c[_0x3b4b79]===0x3f;_0x3b4b79--)_0x2caf2c[_0x3b4b79]=0x0;_0x2caf2c[_0x3b4b79]++;}else{for(_0x3b4b79=0x0;_0x3b4b79<0xc;_0x3b4b79++)_0x2caf2c[_0x3b4b79]=Math['floor'](Math['random']()*0x40);}for(_0x3b4b79=0x0;_0x3b4b79<0xc;_0x3b4b79++)_0x5934c5+=mr['charAt'](_0x2caf2c[_0x3b4b79]);return f(_0x5934c5['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x5934c5;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dd{constructor(_0x205a04,_0x397aa2,_0x1354dd,_0x18f138){this['eventType']=_0x205a04,this['eventRegistration']=_0x397aa2,this['snapshot']=_0x1354dd,this['prevName']=_0x18f138;}['getPath'](){const _0x4632fd=this['snapshot']['ref'];return this['eventType']==='value'?_0x4632fd['_path']:_0x4632fd['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Md{constructor(_0x123c62,_0x2a06c5,_0x5fa48d){this['eventRegistration']=_0x123c62,this['error']=_0x2a06c5,this['path']=_0x5fa48d;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ua{constructor(_0x2025be,_0x543c7f){this['snapshotCallback']=_0x2025be,this['cancelCallback']=_0x543c7f;}['onValue'](_0x6f7bf2,_0x29a7de){this['snapshotCallback']['call'](null,_0x6f7bf2,_0x29a7de);}['onCancel'](_0x43ff48){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x43ff48);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x418cf5){return this['snapshotCallback']===_0x418cf5['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x418cf5['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x418cf5['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x3eb2fb,_0x44234f,_0x1f861e,_0x35e5b1){this['_repo']=_0x3eb2fb,this['_path']=_0x44234f,this['_queryParams']=_0x1f861e,this['_orderByCalled']=_0x35e5b1;}get['key'](){return v(this['_path'])?null:Gi(this['_path']);}get['ref'](){return new Z(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x10ba65=nr(this['_queryParams']),_0x2d8136=Bi(_0x10ba65);return _0x2d8136==='{}'?'default':_0x2d8136;}get['_queryObject'](){return nr(this['_queryParams']);}['isEqual'](_0x17f50b){if(_0x17f50b=k(_0x17f50b),!(_0x17f50b instanceof be))return!0x1;const _0x2a1bfe=this['_repo']===_0x17f50b['_repo'],_0x301b2e=qi(this['_path'],_0x17f50b['_path']),_0x58109e=this['_queryIdentifier']===_0x17f50b['_queryIdentifier'];return _0x2a1bfe&&_0x301b2e&&_0x58109e;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+Ch(this['_path']);}}function da(_0x5abc7e,_0x2835ad){if(_0x5abc7e['_orderByCalled']===!0x0)throw new Error(_0x2835ad+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Gn(_0x54c51a){let _0x49c927=null,_0x2a3736=null;if(_0x54c51a['hasStart']()&&(_0x49c927=_0x54c51a['getIndexStartValue']()),_0x54c51a['hasEnd']()&&(_0x2a3736=_0x54c51a['getIndexEndValue']()),_0x54c51a['getIndex']()===ye){const _0x4f14c7='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x31997c='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x54c51a['hasStart']()){if(_0x54c51a['getIndexStartName']()!==xe)throw new Error(_0x4f14c7);if(typeof _0x49c927!='string')throw new Error(_0x31997c);}if(_0x54c51a['hasEnd']()){if(_0x54c51a['getIndexEndName']()!==Ie)throw new Error(_0x4f14c7);if(typeof _0x2a3736!='string')throw new Error(_0x31997c);}}else{if(_0x54c51a['getIndex']()===R){if(_0x49c927!=null&&!Cn(_0x49c927)||_0x2a3736!=null&&!Cn(_0x2a3736))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x54c51a['getIndex']()instanceof Ki||_0x54c51a['getIndex']()===Po,'unknown\x20index\x20type.'),_0x49c927!=null&&typeof _0x49c927=='object'||_0x2a3736!=null&&typeof _0x2a3736=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function fa(_0x2f91f6){if(_0x2f91f6['hasStart']()&&_0x2f91f6['hasEnd']()&&_0x2f91f6['hasLimit']()&&!_0x2f91f6['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class Z extends be{constructor(_0x2dddcc,_0x3e64d5){super(_0x2dddcc,_0x3e64d5,new Qi(),!0x1);}get['parent'](){const _0x31d55e=To(this['_path']);return _0x31d55e===null?null:new Z(this['_repo'],_0x31d55e);}get['root'](){let _0x3557c9=this;for(;_0x3557c9['parent']!==null;)_0x3557c9=_0x3557c9['parent'];return _0x3557c9;}}class rt{constructor(_0x2392e8,_0x406022,_0x2160e5){this['_node']=_0x2392e8,this['ref']=_0x406022,this['_index']=_0x2160e5;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x1ca435){const _0xacb252=new C(_0x1ca435),_0x492155=Lt(this['ref'],_0x1ca435);return new rt(this['_node']['getChild'](_0xacb252),_0x492155,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x158155){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x24a6b7,_0x38b1b5)=>_0x158155(new rt(_0x38b1b5,Lt(this['ref'],_0x24a6b7),R)));}['hasChild'](_0x1e4ed3){const _0x372985=new C(_0x1e4ed3);return!this['_node']['getChild'](_0x372985)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function h_(_0x195434,_0x350e3c){return _0x195434=k(_0x195434),_0x195434['_checkNotDeleted']('ref'),_0x350e3c!==void 0x0?Lt(_0x195434['_root'],_0x350e3c):_0x195434['_root'];}function Lt(_0x4a11ad,_0x407653){return _0x4a11ad=k(_0x4a11ad),y(_0x4a11ad['_path'])===null?ud('child','path',_0x407653):_s('child','path',_0x407653),new Z(_0x4a11ad['_repo'],A(_0x4a11ad['_path'],_0x407653));}function u_(_0x634f8a,_0xb0692d){_0x634f8a=k(_0x634f8a),gs('push',_0x634f8a['_path']),qt('push',_0xb0692d,_0x634f8a['_path'],!0x0);const _0x5b4d8e=oa(_0x634f8a['_repo']),_0x38e69c=Od(_0x5b4d8e),_0x785fec=Lt(_0x634f8a,_0x38e69c),_0x5f28a3=Lt(_0x634f8a,_0x38e69c);let _0x1e69ce;return _0xb0692d!=null?_0x1e69ce=Ld(_0x5f28a3,_0xb0692d)['then'](()=>_0x5f28a3):_0x1e69ce=Promise['resolve'](_0x5f28a3),_0x785fec['then']=_0x1e69ce['then']['bind'](_0x1e69ce),_0x785fec['catch']=_0x1e69ce['then']['bind'](_0x1e69ce,void 0x0),_0x785fec;}function Ld(_0x2ae025,_0x44d104){_0x2ae025=k(_0x2ae025),gs('set',_0x2ae025['_path']),qt('set',_0x44d104,_0x2ae025['_path'],!0x1);const _0x541db0=new Ve();return Ed(_0x2ae025['_repo'],_0x2ae025['_path'],_0x44d104,null,_0x541db0['wrapCallback'](()=>{})),_0x541db0['promise'];}function d_(_0x38f91d,_0x84e96e){hd('update',_0x84e96e,_0x38f91d['_path']);const _0x5a1b97=new Ve();return Id(_0x38f91d['_repo'],_0x38f91d['_path'],_0x84e96e,_0x5a1b97['wrapCallback'](()=>{})),_0x5a1b97['promise'];}function f_(_0x333e21){_0x333e21=k(_0x333e21);const _0x3c7402=new ua(()=>{}),_0xb3ecdd=new qn(_0x3c7402);return vd(_0x333e21['_repo'],_0x333e21,_0xb3ecdd)['then'](_0x4dacb1=>new rt(_0x4dacb1,new Z(_0x333e21['_repo'],_0x333e21['_path']),_0x333e21['_queryParams']['getIndex']()));}class qn{constructor(_0x174094){this['callbackContext']=_0x174094;}['respondsTo'](_0x3e0af7){return _0x3e0af7==='value';}['createEvent'](_0x108d88,_0x1852c7){const _0xa07bfa=_0x1852c7['_queryParams']['getIndex']();return new Dd('value',this,new rt(_0x108d88['snapshotNode'],new Z(_0x1852c7['_repo'],_0x1852c7['_path']),_0xa07bfa));}['getEventRunner'](_0x3ae115){return _0x3ae115['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x3ae115['error']):()=>this['callbackContext']['onValue'](_0x3ae115['snapshot'],null);}['createCancelEvent'](_0x390b22,_0x4f6343){return this['callbackContext']['hasCancelCallback']?new Md(this,_0x390b22,_0x4f6343):null;}['matches'](_0x1afd35){return _0x1afd35 instanceof qn?!_0x1afd35['callbackContext']||!this['callbackContext']?!0x0:_0x1afd35['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function xd(_0x50dfd6,_0x3dc560,_0x3bc3e2,_0x3996be,_0x3c1d9b){const _0x74ce2e=new ua(_0x3bc3e2,void 0x0),_0x2f5b89=new qn(_0x74ce2e);return Cd(_0x50dfd6['_repo'],_0x50dfd6,_0x2f5b89),()=>Td(_0x50dfd6['_repo'],_0x50dfd6,_0x2f5b89);}function Fd(_0x5c2f74,_0x19e7a2,_0x2b900d,_0x36d9d1){return xd(_0x5c2f74,'value',_0x19e7a2);}class dt{}class pa extends dt{constructor(_0x3f1455,_0x137d34){super(),this['_value']=_0x3f1455,this['_key']=_0x137d34,this['type']='endAt';}['_apply'](_0x389227){qt('endAt',this['_value'],_0x389227['_path'],!0x0);const _0xe36731=Kh(_0x389227['_queryParams'],this['_value'],this['_key']);if(fa(_0xe36731),Gn(_0xe36731),_0x389227['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x389227['_repo'],_0x389227['_path'],_0xe36731,_0x389227['_orderByCalled']);}}function p_(_0x204483,_0x2a65d9){return new pa(_0x204483,_0x2a65d9);}class _a extends dt{constructor(_0x283c9f,_0x361bed){super(),this['_value']=_0x283c9f,this['_key']=_0x361bed,this['type']='startAt';}['_apply'](_0x3987e0){qt('startAt',this['_value'],_0x3987e0['_path'],!0x0);const _0x4958cd=jh(_0x3987e0['_queryParams'],this['_value'],this['_key']);if(fa(_0x4958cd),Gn(_0x4958cd),_0x3987e0['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x3987e0['_repo'],_0x3987e0['_path'],_0x4958cd,_0x3987e0['_orderByCalled']);}}function __(_0x52c5ea=null,_0x1e6aa7){return new _a(_0x52c5ea,_0x1e6aa7);}class Ud extends dt{constructor(_0x3983dd){super(),this['_limit']=_0x3983dd,this['type']='limitToFirst';}['_apply'](_0x55a199){if(_0x55a199['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x55a199['_repo'],_0x55a199['_path'],zh(_0x55a199['_queryParams'],this['_limit']),_0x55a199['_orderByCalled']);}}function g_(_0x49c7a3){if(Math['floor'](_0x49c7a3)!==_0x49c7a3||_0x49c7a3<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Ud(_0x49c7a3);}class Wd extends dt{constructor(_0x4d6579){super(),this['_path']=_0x4d6579,this['type']='orderByChild';}['_apply'](_0x2fe244){da(_0x2fe244,'orderByChild');const _0x4feb17=new C(this['_path']);if(v(_0x4feb17))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x43d64c=new Ki(_0x4feb17),_0xbbae6d=Do(_0x2fe244['_queryParams'],_0x43d64c);return Gn(_0xbbae6d),new be(_0x2fe244['_repo'],_0x2fe244['_path'],_0xbbae6d,!0x0);}}function m_(_0x23f272){if(_0x23f272==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x23f272==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x23f272==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return _s('orderByChild','path',_0x23f272),new Wd(_0x23f272);}class Bd extends dt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0xe69257){da(_0xe69257,'orderByKey');const _0x4df4c6=Do(_0xe69257['_queryParams'],ye);return Gn(_0x4df4c6),new be(_0xe69257['_repo'],_0xe69257['_path'],_0x4df4c6,!0x0);}}function y_(){return new Bd();}class Vd extends dt{constructor(_0x79b63d,_0x5c57ba){super(),this['_value']=_0x79b63d,this['_key']=_0x5c57ba,this['type']='equalTo';}['_apply'](_0x35de5f){if(qt('equalTo',this['_value'],_0x35de5f['_path'],!0x1),_0x35de5f['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x35de5f['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new pa(this['_value'],this['_key'])['_apply'](new _a(this['_value'],this['_key'])['_apply'](_0x35de5f));}}function v_(_0xbe1962,_0x560228){return new Vd(_0xbe1962,_0x560228);}function E_(_0x144e82,..._0x227f59){let _0x5b4930=k(_0x144e82);for(const _0x4e7315 of _0x227f59)_0x5b4930=_0x4e7315['_apply'](_0x5b4930);return _0x5b4930;}xu(Z),Vu(Z);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hd='FIREBASE_DATABASE_EMULATOR_HOST',ki={};let $d=!0x1;function Gd(_0x27282b,_0x5aef0a,_0x300b03,_0x29e587){const _0x230692=_0x5aef0a['lastIndexOf'](':'),_0x2c0dbc=_0x5aef0a['substring'](0x0,_0x230692),_0x17354f=Wt(_0x2c0dbc);_0x27282b['repoInfo_']=new _o(_0x5aef0a,_0x17354f,_0x27282b['repoInfo_']['namespace'],_0x27282b['repoInfo_']['webSocketOnly'],_0x27282b['repoInfo_']['nodeAdmin'],_0x27282b['repoInfo_']['persistenceKey'],_0x27282b['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x300b03),_0x29e587&&(_0x27282b['authTokenProvider_']=_0x29e587);}function qd(_0x5e9d30,_0x57ca8e,_0x2f6b98,_0x4687d0,_0x3379f3){let _0x15bb12=_0x4687d0||_0x5e9d30['options']['databaseURL'];_0x15bb12===void 0x0&&(_0x5e9d30['options']['projectId']||oe('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x5e9d30['options']['projectId']),_0x15bb12=_0x5e9d30['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x548498=gr(_0x15bb12,_0x3379f3),_0x2aafa4=_0x548498['repoInfo'],_0x2d75e6;typeof process<'u'&&Us&&(_0x2d75e6=Us[Hd]),_0x2d75e6?(_0x15bb12='http://'+_0x2d75e6+'?ns='+_0x2aafa4['namespace'],_0x548498=gr(_0x15bb12,_0x3379f3),_0x2aafa4=_0x548498['repoInfo']):_0x548498['repoInfo']['secure'];const _0x463282=new Jl(_0x5e9d30['name'],_0x5e9d30['options'],_0x57ca8e);dd('Invalid\x20Firebase\x20Database\x20URL',_0x548498),v(_0x548498['path'])||oe('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0xa85e34=jd(_0x2aafa4,_0x5e9d30,_0x463282,new Ql(_0x5e9d30,_0x2f6b98));return new Kd(_0xa85e34,_0x5e9d30);}function zd(_0x4d63a4,_0x226077){const _0x35f566=ki[_0x226077];(!_0x35f566||_0x35f566[_0x4d63a4['key']]!==_0x4d63a4)&&oe('Database\x20'+_0x226077+'('+_0x4d63a4['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),aa(_0x4d63a4),delete _0x35f566[_0x4d63a4['key']];}function jd(_0x28cf84,_0x4f10d0,_0x44a7d7,_0x2806d7){let _0x5d2cca=ki[_0x4f10d0['name']];_0x5d2cca||(_0x5d2cca={},ki[_0x4f10d0['name']]=_0x5d2cca);let _0x452f48=_0x5d2cca[_0x28cf84['toURLString']()];return _0x452f48&&oe('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x452f48=new gd(_0x28cf84,$d,_0x44a7d7,_0x2806d7),_0x5d2cca[_0x28cf84['toURLString']()]=_0x452f48,_0x452f48;}class Kd{constructor(_0x1ed972,_0x4dbc3e){this['_repoInternal']=_0x1ed972,this['app']=_0x4dbc3e,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(md(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new Z(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x1fd6ac){this['_rootInternal']===null&&oe('Cannot\x20call\x20'+_0x1fd6ac+'\x20on\x20a\x20deleted\x20database.');}}function I_(_0x8066c1=Qr(),_0x530f91){const _0x7de548=Ui(_0x8066c1,'database')['getImmediate']({'identifier':_0x530f91});if(!_0x7de548['_instanceStarted']){const _0x17a318=ac('database');_0x17a318&&Yd(_0x7de548,..._0x17a318);}return _0x7de548;}function Yd(_0x41d871,_0x2c595a,_0xb6e486,_0xa270b={}){_0x41d871=k(_0x41d871),_0x41d871['_checkNotDeleted']('useEmulator');const _0x5da129=_0x2c595a+':'+_0xb6e486,_0x4fc5c0=_0x41d871['_repoInternal'];if(_0x41d871['_instanceStarted']){if(_0x5da129===_0x41d871['_repoInternal']['repoInfo_']['host']&&De(_0xa270b,_0x4fc5c0['repoInfo_']['emulatorOptions']))return;oe('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x543580;if(_0x4fc5c0['repoInfo_']['nodeAdmin'])_0xa270b['mockUserToken']&&oe('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x543580=new tn(tn['OWNER']);else{if(_0xa270b['mockUserToken']){const _0x4345f1=typeof _0xa270b['mockUserToken']=='string'?_0xa270b['mockUserToken']:cc(_0xa270b['mockUserToken'],_0x41d871['app']['options']['projectId']);_0x543580=new tn(_0x4345f1);}}Wt(_0x2c595a)&&jr(_0x2c595a),Gd(_0x4fc5c0,_0x5da129,_0xa270b,_0x543580);}function w_(_0x54b975){_0x54b975=k(_0x54b975),_0x54b975['_checkNotDeleted']('goOffline'),aa(_0x54b975['_repo']);}function C_(_0x464eea){_0x464eea=k(_0x464eea),_0x464eea['_checkNotDeleted']('goOnline'),Sd(_0x464eea['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Qd(_0x16b2d2){Ll(ct),et(new Me('database',(_0x3ee1ce,{instanceIdentifier:_0x21eccd})=>{const _0x205c21=_0x3ee1ce['getProvider']('app')['getImmediate'](),_0x503353=_0x3ee1ce['getProvider']('auth-internal'),_0x3b633a=_0x3ee1ce['getProvider']('app-check-internal');return qd(_0x205c21,_0x503353,_0x3b633a,_0x21eccd);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Ws,Bs,_0x16b2d2),me(Ws,Bs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jd{constructor(_0x4fba7a,_0x5cf692){this['committed']=_0x4fba7a,this['snapshot']=_0x5cf692;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function T_(_0x4e00c6,_0x4755d4,_0x156df5){if(_0x4e00c6=k(_0x4e00c6),gs('Reference.transaction',_0x4e00c6['_path']),_0x4e00c6['key']==='.length'||_0x4e00c6['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x4e00c6['key']+'\x20is\x20a\x20read-only\x20object.';const _0x62500=!0x0,_0x4a41e8=new Ve(),_0x6bd993=(_0x37ba45,_0x250b89,_0x35ccc7)=>{let _0x532ec2=null;_0x37ba45?_0x4a41e8['reject'](_0x37ba45):(_0x532ec2=new rt(_0x35ccc7,new Z(_0x4e00c6['_repo'],_0x4e00c6['_path']),R),_0x4a41e8['resolve'](new Jd(_0x250b89,_0x532ec2)));},_0x574c8d=Fd(_0x4e00c6,()=>{});return bd(_0x4e00c6['_repo'],_0x4e00c6['_path'],_0x4755d4,_0x6bd993,_0x574c8d,_0x62500),_0x4a41e8['promise'];}ie['prototype']['simpleListen']=function(_0x543315,_0x665cca){this['sendRequest']('q',{'p':_0x543315},_0x665cca);},ie['prototype']['echo']=function(_0x433b42,_0x5782cc){this['sendRequest']('echo',{'d':_0x433b42},_0x5782cc);},Qd();function ga(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const Xd=ga,ma=new Ut('auth','Firebase',ga()),Tn=new xi('@firebase/auth');function Zd(_0x2049bd,..._0x5193d1){Tn['logLevel']<=T['WARN']&&Tn['warn']('Auth\x20('+ct+'):\x20'+_0x2049bd,..._0x5193d1);}function nn(_0x2317ad,..._0x42bcd9){Tn['logLevel']<=T['ERROR']&&Tn['error']('Auth\x20('+ct+'):\x20'+_0x2317ad,..._0x42bcd9);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function K(_0x95545a,..._0x23c9d7){throw Es(_0x95545a,..._0x23c9d7);}function J(_0x1966d8,..._0x2c28fc){return Es(_0x1966d8,..._0x2c28fc);}function ya(_0x23a8b3,_0xf06e86,_0x521c74){const _0xa98ac7={...Xd(),[_0xf06e86]:_0x521c74};return new Ut('auth','Firebase',_0xa98ac7)['create'](_0xf06e86,{'appName':_0x23a8b3['name']});}function se(_0x2e1ea5){return ya(_0x2e1ea5,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function Es(_0x311bf0,..._0x5f159e){if(typeof _0x311bf0!='string'){const _0x18b68e=_0x5f159e[0x0],_0x7043a2=[..._0x5f159e['slice'](0x1)];return _0x7043a2[0x0]&&(_0x7043a2[0x0]['appName']=_0x311bf0['name']),_0x311bf0['_errorFactory']['create'](_0x18b68e,..._0x7043a2);}return ma['create'](_0x311bf0,..._0x5f159e);}function m(_0x59c2ff,_0x4f6d62,..._0x3fac74){if(!_0x59c2ff)throw Es(_0x4f6d62,..._0x3fac74);}function te(_0x1ac025){const _0x6eff2='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x1ac025;throw nn(_0x6eff2),new Error(_0x6eff2);}function ae(_0x37973f,_0x22c1cd){_0x37973f||te(_0x22c1cd);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ni(){var _0x4ffe1c;return typeof self<'u'&&((_0x4ffe1c=self['location'])==null?void 0x0:_0x4ffe1c['href'])||'';}function ef(){return yr()==='http:'||yr()==='https:';}function yr(){var _0x4bab54;return typeof self<'u'&&((_0x4bab54=self['location'])==null?void 0x0:_0x4bab54['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function tf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(ef()||hc()||'connection'in navigator)?navigator['onLine']:!0x0;}function nf(){if(typeof navigator>'u')return null;const _0xcb84bb=navigator;return _0xcb84bb['languages']&&_0xcb84bb['languages'][0x0]||_0xcb84bb['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kt{constructor(_0x23dd2c,_0x3c7de7){this['shortDelay']=_0x23dd2c,this['longDelay']=_0x3c7de7,ae(_0x3c7de7>_0x23dd2c,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Li()||qr();}['get'](){return tf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Is(_0x2e6226,_0x4fbdea){ae(_0x2e6226['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x1315f3}=_0x2e6226['emulator'];return _0x4fbdea?''+_0x1315f3+(_0x4fbdea['startsWith']('/')?_0x4fbdea['slice'](0x1):_0x4fbdea):_0x1315f3;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class va{static['initialize'](_0x5d8efc,_0x2d9299,_0x26b438){this['fetchImpl']=_0x5d8efc,_0x2d9299&&(this['headersImpl']=_0x2d9299),_0x26b438&&(this['responseImpl']=_0x26b438);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;te('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;te('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;te('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const sf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},rf=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],of=new Kt(0x7530,0xea60);function Re(_0x15dbe3,_0x580e7b){return _0x15dbe3['tenantId']&&!_0x580e7b['tenantId']?{..._0x580e7b,'tenantId':_0x15dbe3['tenantId']}:_0x580e7b;}async function Ae(_0xaa705,_0x546b6f,_0xe43618,_0x5b5e07,_0xce23b5={}){return Ea(_0xaa705,_0xce23b5,async()=>{let _0x287adf={},_0x1aaab4={};_0x5b5e07&&(_0x546b6f==='GET'?_0x1aaab4=_0x5b5e07:_0x287adf={'body':JSON['stringify'](_0x5b5e07)});const _0x4e1524=at({..._0x1aaab4,'key':_0xaa705['config']['apiKey']})['slice'](0x1),_0x334906=await _0xaa705['_getAdditionalHeaders']();_0x334906['Content-Type']='application/json',_0xaa705['languageCode']&&(_0x334906['X-Firebase-Locale']=_0xaa705['languageCode']);const _0x41cb03={'method':_0x546b6f,'headers':_0x334906,..._0x287adf};return lc()||(_0x41cb03['referrerPolicy']='strict-origin-when-cross-origin'),_0xaa705['emulatorConfig']&&Wt(_0xaa705['emulatorConfig']['host'])&&(_0x41cb03['credentials']='include'),va['fetch']()(await Ia(_0xaa705,_0xaa705['config']['apiHost'],_0xe43618,_0x4e1524),_0x41cb03);});}async function Ea(_0x329c99,_0x2dfac8,_0x48e0eb){_0x329c99['_canInitEmulator']=!0x1;const _0x2ffd2f={...sf,..._0x2dfac8};try{const _0x4fb653=new cf(_0x329c99),_0x5054cc=await Promise['race']([_0x48e0eb(),_0x4fb653['promise']]);_0x4fb653['clearNetworkTimeout']();const _0x498a76=await _0x5054cc['json']();if('needConfirmation'in _0x498a76)throw en(_0x329c99,'account-exists-with-different-credential',_0x498a76);if(_0x5054cc['ok']&&!('errorMessage'in _0x498a76))return _0x498a76;{const _0xeee61b=_0x5054cc['ok']?_0x498a76['errorMessage']:_0x498a76['error']['message'],[_0x11397b,_0x171326]=_0xeee61b['split']('\x20:\x20');if(_0x11397b==='FEDERATED_USER_ID_ALREADY_LINKED')throw en(_0x329c99,'credential-already-in-use',_0x498a76);if(_0x11397b==='EMAIL_EXISTS')throw en(_0x329c99,'email-already-in-use',_0x498a76);if(_0x11397b==='USER_DISABLED')throw en(_0x329c99,'user-disabled',_0x498a76);const _0x1273b0=_0x2ffd2f[_0x11397b]||_0x11397b['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x171326)throw ya(_0x329c99,_0x1273b0,_0x171326);K(_0x329c99,_0x1273b0);}}catch(_0xbf184f){if(_0xbf184f instanceof Se)throw _0xbf184f;K(_0x329c99,'network-request-failed',{'message':String(_0xbf184f)});}}async function Yt(_0x1a4047,_0x201de8,_0x29db04,_0x4f04cc,_0x2b3dd5={}){const _0xe58d84=await Ae(_0x1a4047,_0x201de8,_0x29db04,_0x4f04cc,_0x2b3dd5);return'mfaPendingCredential'in _0xe58d84&&K(_0x1a4047,'multi-factor-auth-required',{'_serverResponse':_0xe58d84}),_0xe58d84;}async function Ia(_0x9a7be2,_0x4b82a3,_0x374c47,_0x4927c9){const _0x1e814a=''+_0x4b82a3+_0x374c47+'?'+_0x4927c9,_0x2cd68a=_0x9a7be2,_0x4868ce=_0x2cd68a['config']['emulator']?Is(_0x9a7be2['config'],_0x1e814a):_0x9a7be2['config']['apiScheme']+'://'+_0x1e814a;return rf['includes'](_0x374c47)&&(await _0x2cd68a['_persistenceManagerAvailable'],_0x2cd68a['_getPersistenceType']()==='COOKIE')?_0x2cd68a['_getPersistence']()['_getFinalTarget'](_0x4868ce)['toString']():_0x4868ce;}function af(_0x5753f6){switch(_0x5753f6){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class cf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x25aa46){this['auth']=_0x25aa46,this['timer']=null,this['promise']=new Promise((_0x15406a,_0x1dbfc2)=>{this['timer']=setTimeout(()=>_0x1dbfc2(J(this['auth'],'network-request-failed')),of['get']());});}}function en(_0x80280b,_0x58ee75,_0x552f2a){const _0x37ddec={'appName':_0x80280b['name']};_0x552f2a['email']&&(_0x37ddec['email']=_0x552f2a['email']),_0x552f2a['phoneNumber']&&(_0x37ddec['phoneNumber']=_0x552f2a['phoneNumber']);const _0x1264bd=J(_0x80280b,_0x58ee75,_0x37ddec);return _0x1264bd['customData']['_tokenResponse']=_0x552f2a,_0x1264bd;}function vr(_0x31934a){return _0x31934a!==void 0x0&&_0x31934a['enterprise']!==void 0x0;}class lf{constructor(_0x474cb7){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x474cb7['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x474cb7['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x474cb7['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x2e826c){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x37acd7 of this['recaptchaEnforcementState'])if(_0x37acd7['provider']&&_0x37acd7['provider']===_0x2e826c)return af(_0x37acd7['enforcementState']);return null;}['isProviderEnabled'](_0x4c992){return this['getProviderEnforcementState'](_0x4c992)==='ENFORCE'||this['getProviderEnforcementState'](_0x4c992)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function hf(_0x4efef4,_0x310e44){return Ae(_0x4efef4,'GET','/v2/recaptchaConfig',Re(_0x4efef4,_0x310e44));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function uf(_0x5ca6a6,_0x346594){return Ae(_0x5ca6a6,'POST','/v1/accounts:delete',_0x346594);}async function Sn(_0x210125,_0x2504af){return Ae(_0x210125,'POST','/v1/accounts:lookup',_0x2504af);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function St(_0x1d929d){if(_0x1d929d)try{const _0x4431e1=new Date(Number(_0x1d929d));if(!isNaN(_0x4431e1['getTime']()))return _0x4431e1['toUTCString']();}catch{}}async function df(_0x43e7c3,_0x5fc2ea=!0x1){const _0x46fdec=k(_0x43e7c3),_0x14438f=await _0x46fdec['getIdToken'](_0x5fc2ea),_0x13206a=ws(_0x14438f);m(_0x13206a&&_0x13206a['exp']&&_0x13206a['auth_time']&&_0x13206a['iat'],_0x46fdec['auth'],'internal-error');const _0x6b19b8=typeof _0x13206a['firebase']=='object'?_0x13206a['firebase']:void 0x0,_0x256070=_0x6b19b8==null?void 0x0:_0x6b19b8['sign_in_provider'];return{'claims':_0x13206a,'token':_0x14438f,'authTime':St(ci(_0x13206a['auth_time'])),'issuedAtTime':St(ci(_0x13206a['iat'])),'expirationTime':St(ci(_0x13206a['exp'])),'signInProvider':_0x256070||null,'signInSecondFactor':(_0x6b19b8==null?void 0x0:_0x6b19b8['sign_in_second_factor'])||null};}function ci(_0x36f382){return Number(_0x36f382)*0x3e8;}function ws(_0x1011a2){const [_0x4865c2,_0x43ee97,_0x90218]=_0x1011a2['split']('.');if(_0x4865c2===void 0x0||_0x43ee97===void 0x0||_0x90218===void 0x0)return nn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x2045a4=cn(_0x43ee97);return _0x2045a4?JSON['parse'](_0x2045a4):(nn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x2a8808){return nn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x2a8808==null?void 0x0:_0x2a8808['toString']()),null;}}function Er(_0x15bf67){const _0x4ff7d1=ws(_0x15bf67);return m(_0x4ff7d1,'internal-error'),m(typeof _0x4ff7d1['exp']<'u','internal-error'),m(typeof _0x4ff7d1['iat']<'u','internal-error'),Number(_0x4ff7d1['exp'])-Number(_0x4ff7d1['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function xt(_0x46dfd8,_0x4f1a33,_0x30fc9a=!0x1){if(_0x30fc9a)return _0x4f1a33;try{return await _0x4f1a33;}catch(_0x559ca4){throw _0x559ca4 instanceof Se&&ff(_0x559ca4)&&_0x46dfd8['auth']['currentUser']===_0x46dfd8&&await _0x46dfd8['auth']['signOut'](),_0x559ca4;}}function ff({code:_0xe48a17}){return _0xe48a17==='auth/user-disabled'||_0xe48a17==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pf{constructor(_0x15560a){this['user']=_0x15560a,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x212c90){if(_0x212c90){const _0x117520=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x117520;}else{this['errorBackoff']=0x7530;const _0x3edca5=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x3edca5);}}['schedule'](_0x14e039=!0x1){if(!this['isRunning'])return;const _0x3b635d=this['getInterval'](_0x14e039);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x3b635d);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x599865){(_0x599865==null?void 0x0:_0x599865['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pi{constructor(_0x4d8fb8,_0x4a2028){this['createdAt']=_0x4d8fb8,this['lastLoginAt']=_0x4a2028,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=St(this['lastLoginAt']),this['creationTime']=St(this['createdAt']);}['_copy'](_0x4c4823){this['createdAt']=_0x4c4823['createdAt'],this['lastLoginAt']=_0x4c4823['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bn(_0x336de1){var _0x5478c2;const _0x272f08=_0x336de1['auth'],_0x40d039=await _0x336de1['getIdToken'](),_0x50530f=await xt(_0x336de1,Sn(_0x272f08,{'idToken':_0x40d039}));m(_0x50530f==null?void 0x0:_0x50530f['users']['length'],_0x272f08,'internal-error');const _0x11d704=_0x50530f['users'][0x0];_0x336de1['_notifyReloadListener'](_0x11d704);const _0x43822b=(_0x5478c2=_0x11d704['providerUserInfo'])!=null&&_0x5478c2['length']?wa(_0x11d704['providerUserInfo']):[],_0x4eb830=gf(_0x336de1['providerData'],_0x43822b),_0x37e0cc=_0x336de1['isAnonymous'],_0x5c7899=!(_0x336de1['email']&&_0x11d704['passwordHash'])&&!(_0x4eb830!=null&&_0x4eb830['length']),_0x16b768=_0x37e0cc?_0x5c7899:!0x1,_0x513ddc={'uid':_0x11d704['localId'],'displayName':_0x11d704['displayName']||null,'photoURL':_0x11d704['photoUrl']||null,'email':_0x11d704['email']||null,'emailVerified':_0x11d704['emailVerified']||!0x1,'phoneNumber':_0x11d704['phoneNumber']||null,'tenantId':_0x11d704['tenantId']||null,'providerData':_0x4eb830,'metadata':new Pi(_0x11d704['createdAt'],_0x11d704['lastLoginAt']),'isAnonymous':_0x16b768};Object['assign'](_0x336de1,_0x513ddc);}async function _f(_0x3a7d43){const _0x525762=k(_0x3a7d43);await bn(_0x525762),await _0x525762['auth']['_persistUserIfCurrent'](_0x525762),_0x525762['auth']['_notifyListenersIfCurrent'](_0x525762);}function gf(_0x121787,_0x29b52d){return[..._0x121787['filter'](_0x2707e2=>!_0x29b52d['some'](_0x385682=>_0x385682['providerId']===_0x2707e2['providerId'])),..._0x29b52d];}function wa(_0x218664){return _0x218664['map'](({providerId:_0x32d186,..._0x30379f})=>({'providerId':_0x32d186,'uid':_0x30379f['rawId']||'','displayName':_0x30379f['displayName']||null,'email':_0x30379f['email']||null,'phoneNumber':_0x30379f['phoneNumber']||null,'photoURL':_0x30379f['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function mf(_0x3fc1d0,_0x1a340f){const _0xe1c754=await Ea(_0x3fc1d0,{},async()=>{const _0x1899d5=at({'grant_type':'refresh_token','refresh_token':_0x1a340f})['slice'](0x1),{tokenApiHost:_0x5e07f5,apiKey:_0x336331}=_0x3fc1d0['config'],_0x119138=await Ia(_0x3fc1d0,_0x5e07f5,'/v1/token','key='+_0x336331),_0x4d1d14=await _0x3fc1d0['_getAdditionalHeaders']();_0x4d1d14['Content-Type']='application/x-www-form-urlencoded';const _0x4dc320={'method':'POST','headers':_0x4d1d14,'body':_0x1899d5};return _0x3fc1d0['emulatorConfig']&&Wt(_0x3fc1d0['emulatorConfig']['host'])&&(_0x4dc320['credentials']='include'),va['fetch']()(_0x119138,_0x4dc320);});return{'accessToken':_0xe1c754['access_token'],'expiresIn':_0xe1c754['expires_in'],'refreshToken':_0xe1c754['refresh_token']};}async function yf(_0x26642d,_0x236e6f){return Ae(_0x26642d,'POST','/v2/accounts:revokeToken',Re(_0x26642d,_0x236e6f));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Je{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x359cca){m(_0x359cca['idToken'],'internal-error'),m(typeof _0x359cca['idToken']<'u','internal-error'),m(typeof _0x359cca['refreshToken']<'u','internal-error');const _0x554a30='expiresIn'in _0x359cca&&typeof _0x359cca['expiresIn']<'u'?Number(_0x359cca['expiresIn']):Er(_0x359cca['idToken']);this['updateTokensAndExpiration'](_0x359cca['idToken'],_0x359cca['refreshToken'],_0x554a30);}['updateFromIdToken'](_0x497120){m(_0x497120['length']!==0x0,'internal-error');const _0x5303a4=Er(_0x497120);this['updateTokensAndExpiration'](_0x497120,null,_0x5303a4);}async['getToken'](_0x2228fb,_0x1feff6=!0x1){return!_0x1feff6&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x2228fb,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x2228fb,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x552752,_0x219288){const {accessToken:_0x5a5426,refreshToken:_0x5ee16d,expiresIn:_0xbfac79}=await mf(_0x552752,_0x219288);this['updateTokensAndExpiration'](_0x5a5426,_0x5ee16d,Number(_0xbfac79));}['updateTokensAndExpiration'](_0x29fd30,_0x5ca654,_0x459dbb){this['refreshToken']=_0x5ca654||null,this['accessToken']=_0x29fd30||null,this['expirationTime']=Date['now']()+_0x459dbb*0x3e8;}static['fromJSON'](_0x26729f,_0x1a33f8){const {refreshToken:_0x27d9d9,accessToken:_0x1197c4,expirationTime:_0x1fc116}=_0x1a33f8,_0x7c5de1=new Je();return _0x27d9d9&&(m(typeof _0x27d9d9=='string','internal-error',{'appName':_0x26729f}),_0x7c5de1['refreshToken']=_0x27d9d9),_0x1197c4&&(m(typeof _0x1197c4=='string','internal-error',{'appName':_0x26729f}),_0x7c5de1['accessToken']=_0x1197c4),_0x1fc116&&(m(typeof _0x1fc116=='number','internal-error',{'appName':_0x26729f}),_0x7c5de1['expirationTime']=_0x1fc116),_0x7c5de1;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0xeef809){this['accessToken']=_0xeef809['accessToken'],this['refreshToken']=_0xeef809['refreshToken'],this['expirationTime']=_0xeef809['expirationTime'];}['_clone'](){return Object['assign'](new Je(),this['toJSON']());}['_performRefresh'](){return te('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ce(_0x20c482,_0x123264){m(typeof _0x20c482=='string'||typeof _0x20c482>'u','internal-error',{'appName':_0x123264});}class z{constructor({uid:_0x2b22a2,auth:_0x445f78,stsTokenManager:_0x2b09c4,..._0x53fca2}){this['providerId']='firebase',this['proactiveRefresh']=new pf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x2b22a2,this['auth']=_0x445f78,this['stsTokenManager']=_0x2b09c4,this['accessToken']=_0x2b09c4['accessToken'],this['displayName']=_0x53fca2['displayName']||null,this['email']=_0x53fca2['email']||null,this['emailVerified']=_0x53fca2['emailVerified']||!0x1,this['phoneNumber']=_0x53fca2['phoneNumber']||null,this['photoURL']=_0x53fca2['photoURL']||null,this['isAnonymous']=_0x53fca2['isAnonymous']||!0x1,this['tenantId']=_0x53fca2['tenantId']||null,this['providerData']=_0x53fca2['providerData']?[..._0x53fca2['providerData']]:[],this['metadata']=new Pi(_0x53fca2['createdAt']||void 0x0,_0x53fca2['lastLoginAt']||void 0x0);}async['getIdToken'](_0xf5080e){const _0x2ea3c7=await xt(this,this['stsTokenManager']['getToken'](this['auth'],_0xf5080e));return m(_0x2ea3c7,this['auth'],'internal-error'),this['accessToken']!==_0x2ea3c7&&(this['accessToken']=_0x2ea3c7,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x2ea3c7;}['getIdTokenResult'](_0x1ccbe2){return df(this,_0x1ccbe2);}['reload'](){return _f(this);}['_assign'](_0x41b14b){this!==_0x41b14b&&(m(this['uid']===_0x41b14b['uid'],this['auth'],'internal-error'),this['displayName']=_0x41b14b['displayName'],this['photoURL']=_0x41b14b['photoURL'],this['email']=_0x41b14b['email'],this['emailVerified']=_0x41b14b['emailVerified'],this['phoneNumber']=_0x41b14b['phoneNumber'],this['isAnonymous']=_0x41b14b['isAnonymous'],this['tenantId']=_0x41b14b['tenantId'],this['providerData']=_0x41b14b['providerData']['map'](_0x86609c=>({..._0x86609c})),this['metadata']['_copy'](_0x41b14b['metadata']),this['stsTokenManager']['_assign'](_0x41b14b['stsTokenManager']));}['_clone'](_0x5d344f){const _0x3117b3=new z({...this,'auth':_0x5d344f,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x3117b3['metadata']['_copy'](this['metadata']),_0x3117b3;}['_onReload'](_0x30f300){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x30f300,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x108ec9){this['reloadListener']?this['reloadListener'](_0x108ec9):this['reloadUserInfo']=_0x108ec9;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x11dece,_0x1d968d=!0x1){let _0x4661c8=!0x1;_0x11dece['idToken']&&_0x11dece['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x11dece),_0x4661c8=!0x0),_0x1d968d&&await bn(this),await this['auth']['_persistUserIfCurrent'](this),_0x4661c8&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if(H(this['auth']['app']))return Promise['reject'](se(this['auth']));const _0x1df04d=await this['getIdToken']();return await xt(this,uf(this['auth'],{'idToken':_0x1df04d})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x75400e=>({..._0x75400e})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x5e5fd6,_0x357d45){const _0x2bc5f1=_0x357d45['displayName']??void 0x0,_0x106736=_0x357d45['email']??void 0x0,_0xd3e003=_0x357d45['phoneNumber']??void 0x0,_0x52ab4a=_0x357d45['photoURL']??void 0x0,_0x25c7ba=_0x357d45['tenantId']??void 0x0,_0x520545=_0x357d45['_redirectEventId']??void 0x0,_0x5ed2cd=_0x357d45['createdAt']??void 0x0,_0x117f9c=_0x357d45['lastLoginAt']??void 0x0,{uid:_0x2a1ee4,emailVerified:_0x54e4b8,isAnonymous:_0x3ed1d0,providerData:_0x5baaa2,stsTokenManager:_0x1308b7}=_0x357d45;m(_0x2a1ee4&&_0x1308b7,_0x5e5fd6,'internal-error');const _0x202450=Je['fromJSON'](this['name'],_0x1308b7);m(typeof _0x2a1ee4=='string',_0x5e5fd6,'internal-error'),ce(_0x2bc5f1,_0x5e5fd6['name']),ce(_0x106736,_0x5e5fd6['name']),m(typeof _0x54e4b8=='boolean',_0x5e5fd6,'internal-error'),m(typeof _0x3ed1d0=='boolean',_0x5e5fd6,'internal-error'),ce(_0xd3e003,_0x5e5fd6['name']),ce(_0x52ab4a,_0x5e5fd6['name']),ce(_0x25c7ba,_0x5e5fd6['name']),ce(_0x520545,_0x5e5fd6['name']),ce(_0x5ed2cd,_0x5e5fd6['name']),ce(_0x117f9c,_0x5e5fd6['name']);const _0x415c77=new z({'uid':_0x2a1ee4,'auth':_0x5e5fd6,'email':_0x106736,'emailVerified':_0x54e4b8,'displayName':_0x2bc5f1,'isAnonymous':_0x3ed1d0,'photoURL':_0x52ab4a,'phoneNumber':_0xd3e003,'tenantId':_0x25c7ba,'stsTokenManager':_0x202450,'createdAt':_0x5ed2cd,'lastLoginAt':_0x117f9c});return _0x5baaa2&&Array['isArray'](_0x5baaa2)&&(_0x415c77['providerData']=_0x5baaa2['map'](_0x4c9123=>({..._0x4c9123}))),_0x520545&&(_0x415c77['_redirectEventId']=_0x520545),_0x415c77;}static async['_fromIdTokenResponse'](_0x2b7f07,_0x51de6a,_0x22d448=!0x1){const _0x4bccae=new Je();_0x4bccae['updateFromServerResponse'](_0x51de6a);const _0x5342d5=new z({'uid':_0x51de6a['localId'],'auth':_0x2b7f07,'stsTokenManager':_0x4bccae,'isAnonymous':_0x22d448});return await bn(_0x5342d5),_0x5342d5;}static async['_fromGetAccountInfoResponse'](_0x185176,_0x59bdd2,_0xcb89f){const _0xe5ac89=_0x59bdd2['users'][0x0];m(_0xe5ac89['localId']!==void 0x0,'internal-error');const _0xd698eb=_0xe5ac89['providerUserInfo']!==void 0x0?wa(_0xe5ac89['providerUserInfo']):[],_0x573b31=!(_0xe5ac89['email']&&_0xe5ac89['passwordHash'])&&!(_0xd698eb!=null&&_0xd698eb['length']),_0x50701f=new Je();_0x50701f['updateFromIdToken'](_0xcb89f);const _0x52b3ce=new z({'uid':_0xe5ac89['localId'],'auth':_0x185176,'stsTokenManager':_0x50701f,'isAnonymous':_0x573b31}),_0xbc469a={'uid':_0xe5ac89['localId'],'displayName':_0xe5ac89['displayName']||null,'photoURL':_0xe5ac89['photoUrl']||null,'email':_0xe5ac89['email']||null,'emailVerified':_0xe5ac89['emailVerified']||!0x1,'phoneNumber':_0xe5ac89['phoneNumber']||null,'tenantId':_0xe5ac89['tenantId']||null,'providerData':_0xd698eb,'metadata':new Pi(_0xe5ac89['createdAt'],_0xe5ac89['lastLoginAt']),'isAnonymous':!(_0xe5ac89['email']&&_0xe5ac89['passwordHash'])&&!(_0xd698eb!=null&&_0xd698eb['length'])};return Object['assign'](_0x52b3ce,_0xbc469a),_0x52b3ce;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ir=new Map();function ne(_0x24c34b){ae(_0x24c34b instanceof Function,'Expected\x20a\x20class\x20definition');let _0x41f5e1=Ir['get'](_0x24c34b);return _0x41f5e1?(ae(_0x41f5e1 instanceof _0x24c34b,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x41f5e1):(_0x41f5e1=new _0x24c34b(),Ir['set'](_0x24c34b,_0x41f5e1),_0x41f5e1);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ca{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x3f84a9,_0x406d0e){this['storage'][_0x3f84a9]=_0x406d0e;}async['_get'](_0x25f87b){const _0x358a2e=this['storage'][_0x25f87b];return _0x358a2e===void 0x0?null:_0x358a2e;}async['_remove'](_0xcebd2e){delete this['storage'][_0xcebd2e];}['_addListener'](_0x3667c4,_0x3605fd){}['_removeListener'](_0x21a268,_0x56bf7f){}}Ca['type']='NONE';const wr=Ca;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sn(_0x33494f,_0x507d68,_0x46bec4){return'firebase:'+_0x33494f+':'+_0x507d68+':'+_0x46bec4;}class Xe{constructor(_0x5995fc,_0x31f0a4,_0x35a1ad){this['persistence']=_0x5995fc,this['auth']=_0x31f0a4,this['userKey']=_0x35a1ad;const {config:_0x26ba87,name:_0x160e12}=this['auth'];this['fullUserKey']=sn(this['userKey'],_0x26ba87['apiKey'],_0x160e12),this['fullPersistenceKey']=sn('persistence',_0x26ba87['apiKey'],_0x160e12),this['boundEventHandler']=_0x31f0a4['_onStorageEvent']['bind'](_0x31f0a4),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0xd389e4){return this['persistence']['_set'](this['fullUserKey'],_0xd389e4['toJSON']());}async['getCurrentUser'](){const _0x5e2817=await this['persistence']['_get'](this['fullUserKey']);if(!_0x5e2817)return null;if(typeof _0x5e2817=='string'){const _0x352ade=await Sn(this['auth'],{'idToken':_0x5e2817})['catch'](()=>{});return _0x352ade?z['_fromGetAccountInfoResponse'](this['auth'],_0x352ade,_0x5e2817):null;}return z['_fromJSON'](this['auth'],_0x5e2817);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x3770e4){if(this['persistence']===_0x3770e4)return;const _0x2bf21f=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x3770e4,_0x2bf21f)return this['setCurrentUser'](_0x2bf21f);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x376480,_0x103e78,_0x2fe75c='authUser'){if(!_0x103e78['length'])return new Xe(ne(wr),_0x376480,_0x2fe75c);const _0x1e2e66=(await Promise['all'](_0x103e78['map'](async _0x3eed51=>{if(await _0x3eed51['_isAvailable']())return _0x3eed51;})))['filter'](_0x53a56c=>_0x53a56c);let _0x174bf3=_0x1e2e66[0x0]||ne(wr);const _0x48f2ca=sn(_0x2fe75c,_0x376480['config']['apiKey'],_0x376480['name']);let _0x123b2a=null;for(const _0x500525 of _0x103e78)try{const _0x475e2e=await _0x500525['_get'](_0x48f2ca);if(_0x475e2e){let _0x5ea59a;if(typeof _0x475e2e=='string'){const _0x4cbce9=await Sn(_0x376480,{'idToken':_0x475e2e})['catch'](()=>{});if(!_0x4cbce9)break;_0x5ea59a=await z['_fromGetAccountInfoResponse'](_0x376480,_0x4cbce9,_0x475e2e);}else _0x5ea59a=z['_fromJSON'](_0x376480,_0x475e2e);_0x500525!==_0x174bf3&&(_0x123b2a=_0x5ea59a),_0x174bf3=_0x500525;break;}}catch{}const _0x2dbfab=_0x1e2e66['filter'](_0x1fcefa=>_0x1fcefa['_shouldAllowMigration']);return!_0x174bf3['_shouldAllowMigration']||!_0x2dbfab['length']?new Xe(_0x174bf3,_0x376480,_0x2fe75c):(_0x174bf3=_0x2dbfab[0x0],_0x123b2a&&await _0x174bf3['_set'](_0x48f2ca,_0x123b2a['toJSON']()),await Promise['all'](_0x103e78['map'](async _0x1759f=>{if(_0x1759f!==_0x174bf3)try{await _0x1759f['_remove'](_0x48f2ca);}catch{}})),new Xe(_0x174bf3,_0x376480,_0x2fe75c));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cr(_0x1b59d3){const _0x1fd041=_0x1b59d3['toLowerCase']();if(_0x1fd041['includes']('opera/')||_0x1fd041['includes']('opr/')||_0x1fd041['includes']('opios/'))return'Opera';if(Ra(_0x1fd041))return'IEMobile';if(_0x1fd041['includes']('msie')||_0x1fd041['includes']('trident/'))return'IE';if(_0x1fd041['includes']('edge/'))return'Edge';if(Ta(_0x1fd041))return'Firefox';if(_0x1fd041['includes']('silk/'))return'Silk';if(ka(_0x1fd041))return'Blackberry';if(Na(_0x1fd041))return'Webos';if(Sa(_0x1fd041))return'Safari';if((_0x1fd041['includes']('chrome/')||ba(_0x1fd041))&&!_0x1fd041['includes']('edge/'))return'Chrome';if(Aa(_0x1fd041))return'Android';{const _0x55f702=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x1b627d=_0x1b59d3['match'](_0x55f702);if((_0x1b627d==null?void 0x0:_0x1b627d['length'])===0x2)return _0x1b627d[0x1];}return'Other';}function Ta(_0x5f2d7c=W()){return/firefox\//i['test'](_0x5f2d7c);}function Sa(_0x54abc0=W()){const _0x2ff07d=_0x54abc0['toLowerCase']();return _0x2ff07d['includes']('safari/')&&!_0x2ff07d['includes']('chrome/')&&!_0x2ff07d['includes']('crios/')&&!_0x2ff07d['includes']('android');}function ba(_0x2b0538=W()){return/crios\//i['test'](_0x2b0538);}function Ra(_0x1afadd=W()){return/iemobile/i['test'](_0x1afadd);}function Aa(_0x2ad83a=W()){return/android/i['test'](_0x2ad83a);}function ka(_0x3c31bb=W()){return/blackberry/i['test'](_0x3c31bb);}function Na(_0x4a1e91=W()){return/webos/i['test'](_0x4a1e91);}function Cs(_0x303404=W()){return/iphone|ipad|ipod/i['test'](_0x303404)||/macintosh/i['test'](_0x303404)&&/mobile/i['test'](_0x303404);}function vf(_0x56943d=W()){var _0x3e8585;return Cs(_0x56943d)&&!!((_0x3e8585=window['navigator'])!=null&&_0x3e8585['standalone']);}function Ef(){return uc()&&document['documentMode']===0xa;}function Pa(_0x5e8024=W()){return Cs(_0x5e8024)||Aa(_0x5e8024)||Na(_0x5e8024)||ka(_0x5e8024)||/windows phone/i['test'](_0x5e8024)||Ra(_0x5e8024);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Oa(_0x3afcc8,_0x45eee3=[]){let _0x26596e;switch(_0x3afcc8){case'Browser':_0x26596e=Cr(W());break;case'Worker':_0x26596e=Cr(W())+'-'+_0x3afcc8;break;default:_0x26596e=_0x3afcc8;}const _0x43c611=_0x45eee3['length']?_0x45eee3['join'](','):'FirebaseCore-web';return _0x26596e+'/JsCore/'+ct+'/'+_0x43c611;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class If{constructor(_0x20d7aa){this['auth']=_0x20d7aa,this['queue']=[];}['pushCallback'](_0x438b82,_0x4d7be8){const _0x21eddb=_0x369023=>new Promise((_0x55c1ea,_0x58cb97)=>{try{const _0x43ef82=_0x438b82(_0x369023);_0x55c1ea(_0x43ef82);}catch(_0x453a72){_0x58cb97(_0x453a72);}});_0x21eddb['onAbort']=_0x4d7be8,this['queue']['push'](_0x21eddb);const _0x915c16=this['queue']['length']-0x1;return()=>{this['queue'][_0x915c16]=()=>Promise['resolve']();};}async['runMiddleware'](_0x133579){if(this['auth']['currentUser']===_0x133579)return;const _0x3e810b=[];try{for(const _0x1d5410 of this['queue'])await _0x1d5410(_0x133579),_0x1d5410['onAbort']&&_0x3e810b['push'](_0x1d5410['onAbort']);}catch(_0x17540){_0x3e810b['reverse']();for(const _0x284116 of _0x3e810b)try{_0x284116();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x17540==null?void 0x0:_0x17540['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function wf(_0x3629b7,_0x3da3ab={}){return Ae(_0x3629b7,'GET','/v2/passwordPolicy',Re(_0x3629b7,_0x3da3ab));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cf=0x6;class Tf{constructor(_0x4c4972){var _0xba128b;const _0x683845=_0x4c4972['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x683845['minPasswordLength']??Cf,_0x683845['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x683845['maxPasswordLength']),_0x683845['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x683845['containsLowercaseCharacter']),_0x683845['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x683845['containsUppercaseCharacter']),_0x683845['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x683845['containsNumericCharacter']),_0x683845['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x683845['containsNonAlphanumericCharacter']),this['enforcementState']=_0x4c4972['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0xba128b=_0x4c4972['allowedNonAlphanumericCharacters'])==null?void 0x0:_0xba128b['join'](''))??'',this['forceUpgradeOnSignin']=_0x4c4972['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x4c4972['schemaVersion'];}['validatePassword'](_0x455fb2){const _0x5b70eb={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x455fb2,_0x5b70eb),this['validatePasswordCharacterOptions'](_0x455fb2,_0x5b70eb),_0x5b70eb['isValid']&&(_0x5b70eb['isValid']=_0x5b70eb['meetsMinPasswordLength']??!0x0),_0x5b70eb['isValid']&&(_0x5b70eb['isValid']=_0x5b70eb['meetsMaxPasswordLength']??!0x0),_0x5b70eb['isValid']&&(_0x5b70eb['isValid']=_0x5b70eb['containsLowercaseLetter']??!0x0),_0x5b70eb['isValid']&&(_0x5b70eb['isValid']=_0x5b70eb['containsUppercaseLetter']??!0x0),_0x5b70eb['isValid']&&(_0x5b70eb['isValid']=_0x5b70eb['containsNumericCharacter']??!0x0),_0x5b70eb['isValid']&&(_0x5b70eb['isValid']=_0x5b70eb['containsNonAlphanumericCharacter']??!0x0),_0x5b70eb;}['validatePasswordLengthOptions'](_0x1e2534,_0x515b63){const _0x1435c3=this['customStrengthOptions']['minPasswordLength'],_0x2bae60=this['customStrengthOptions']['maxPasswordLength'];_0x1435c3&&(_0x515b63['meetsMinPasswordLength']=_0x1e2534['length']>=_0x1435c3),_0x2bae60&&(_0x515b63['meetsMaxPasswordLength']=_0x1e2534['length']<=_0x2bae60);}['validatePasswordCharacterOptions'](_0x342928,_0x2294c8){this['updatePasswordCharacterOptionsStatuses'](_0x2294c8,!0x1,!0x1,!0x1,!0x1);let _0x3de639;for(let _0x4946b4=0x0;_0x4946b4<_0x342928['length'];_0x4946b4++)_0x3de639=_0x342928['charAt'](_0x4946b4),this['updatePasswordCharacterOptionsStatuses'](_0x2294c8,_0x3de639>='a'&&_0x3de639<='z',_0x3de639>='A'&&_0x3de639<='Z',_0x3de639>='0'&&_0x3de639<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x3de639));}['updatePasswordCharacterOptionsStatuses'](_0x12947a,_0x2e23e9,_0xc30fe4,_0x562b3c,_0x2473c1){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x12947a['containsLowercaseLetter']||(_0x12947a['containsLowercaseLetter']=_0x2e23e9)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x12947a['containsUppercaseLetter']||(_0x12947a['containsUppercaseLetter']=_0xc30fe4)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x12947a['containsNumericCharacter']||(_0x12947a['containsNumericCharacter']=_0x562b3c)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x12947a['containsNonAlphanumericCharacter']||(_0x12947a['containsNonAlphanumericCharacter']=_0x2473c1));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sf{constructor(_0x139d94,_0x2b8ffc,_0x12087c,_0x22ff80){this['app']=_0x139d94,this['heartbeatServiceProvider']=_0x2b8ffc,this['appCheckServiceProvider']=_0x12087c,this['config']=_0x22ff80,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Tr(this),this['idTokenSubscription']=new Tr(this),this['beforeStateQueue']=new If(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=ma,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x139d94['name'],this['clientVersion']=_0x22ff80['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x2a8340=>this['_resolvePersistenceManagerAvailable']=_0x2a8340);}['_initializeWithPersistence'](_0x463461,_0x56dc60){return _0x56dc60&&(this['_popupRedirectResolver']=ne(_0x56dc60)),this['_initializationPromise']=this['queue'](async()=>{var _0x348a71,_0x2c0601,_0xb2eae5;if(!this['_deleted']&&(this['persistenceManager']=await Xe['create'](this,_0x463461),(_0x348a71=this['_resolvePersistenceManagerAvailable'])==null||_0x348a71['call'](this),!this['_deleted'])){if((_0x2c0601=this['_popupRedirectResolver'])!=null&&_0x2c0601['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x56dc60),this['lastNotifiedUid']=((_0xb2eae5=this['currentUser'])==null?void 0x0:_0xb2eae5['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x1a89b6=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x1a89b6)){if(this['currentUser']&&_0x1a89b6&&this['currentUser']['uid']===_0x1a89b6['uid']){this['_currentUser']['_assign'](_0x1a89b6),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x1a89b6,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x468b3a){try{const _0x5cce8e=await Sn(this,{'idToken':_0x468b3a}),_0xada59=await z['_fromGetAccountInfoResponse'](this,_0x5cce8e,_0x468b3a);await this['directlySetCurrentUser'](_0xada59);}catch(_0x548fb4){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x548fb4),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x3b3f82){var _0x1d6880;if(H(this['app'])){const _0x26f927=this['app']['settings']['authIdToken'];return _0x26f927?new Promise(_0x18e26f=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x26f927)['then'](_0x18e26f,_0x18e26f));}):this['directlySetCurrentUser'](null);}const _0xb8c3ad=await this['assertedPersistence']['getCurrentUser']();let _0x1f0626=_0xb8c3ad,_0x294619=!0x1;if(_0x3b3f82&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x480eb7=(_0x1d6880=this['redirectUser'])==null?void 0x0:_0x1d6880['_redirectEventId'],_0x269573=_0x1f0626==null?void 0x0:_0x1f0626['_redirectEventId'],_0x224c5c=await this['tryRedirectSignIn'](_0x3b3f82);(!_0x480eb7||_0x480eb7===_0x269573)&&(_0x224c5c!=null&&_0x224c5c['user'])&&(_0x1f0626=_0x224c5c['user'],_0x294619=!0x0);}if(!_0x1f0626)return this['directlySetCurrentUser'](null);if(!_0x1f0626['_redirectEventId']){if(_0x294619)try{await this['beforeStateQueue']['runMiddleware'](_0x1f0626);}catch(_0xd639ee){_0x1f0626=_0xb8c3ad,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0xd639ee));}return _0x1f0626?this['reloadAndSetCurrentUserOrClear'](_0x1f0626):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x1f0626['_redirectEventId']?this['directlySetCurrentUser'](_0x1f0626):this['reloadAndSetCurrentUserOrClear'](_0x1f0626);}async['tryRedirectSignIn'](_0x539ebb){let _0x5057f1=null;try{_0x5057f1=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x539ebb,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x5057f1;}async['reloadAndSetCurrentUserOrClear'](_0x554b33){try{await bn(_0x554b33);}catch(_0x35b305){if((_0x35b305==null?void 0x0:_0x35b305['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x554b33);}['useDeviceLanguage'](){this['languageCode']=nf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x992cb){if(H(this['app']))return Promise['reject'](se(this));const _0x3dfdae=_0x992cb?k(_0x992cb):null;return _0x3dfdae&&m(_0x3dfdae['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x3dfdae&&_0x3dfdae['_clone'](this));}async['_updateCurrentUser'](_0x296f6e,_0x1d3836=!0x1){if(!this['_deleted'])return _0x296f6e&&m(this['tenantId']===_0x296f6e['tenantId'],this,'tenant-id-mismatch'),_0x1d3836||await this['beforeStateQueue']['runMiddleware'](_0x296f6e),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x296f6e),this['notifyAuthListeners']();});}async['signOut'](){return H(this['app'])?Promise['reject'](se(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x143869){return H(this['app'])?Promise['reject'](se(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ne(_0x143869));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x172399){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x5dcf59=this['_getPasswordPolicyInternal']();return _0x5dcf59['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x5dcf59['validatePassword'](_0x172399);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x3eb14f=await wf(this),_0x42e985=new Tf(_0x3eb14f);this['tenantId']===null?this['_projectPasswordPolicy']=_0x42e985:this['_tenantPasswordPolicies'][this['tenantId']]=_0x42e985;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x3db440){this['_errorFactory']=new Ut('auth','Firebase',_0x3db440());}['onAuthStateChanged'](_0x45e318,_0x2fb020,_0x32ed42){return this['registerStateListener'](this['authStateSubscription'],_0x45e318,_0x2fb020,_0x32ed42);}['beforeAuthStateChanged'](_0x33a3f1,_0x1081e4){return this['beforeStateQueue']['pushCallback'](_0x33a3f1,_0x1081e4);}['onIdTokenChanged'](_0x8f212f,_0x274700,_0x2e072b){return this['registerStateListener'](this['idTokenSubscription'],_0x8f212f,_0x274700,_0x2e072b);}['authStateReady'](){return new Promise((_0x18acf5,_0x5baa49)=>{if(this['currentUser'])_0x18acf5();else{const _0x2b5312=this['onAuthStateChanged'](()=>{_0x2b5312(),_0x18acf5();},_0x5baa49);}});}async['revokeAccessToken'](_0x329777){if(this['currentUser']){const _0x4e3114=await this['currentUser']['getIdToken'](),_0x10ea3e={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x329777,'idToken':_0x4e3114};this['tenantId']!=null&&(_0x10ea3e['tenantId']=this['tenantId']),await yf(this,_0x10ea3e);}}['toJSON'](){var _0x157a02;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x157a02=this['_currentUser'])==null?void 0x0:_0x157a02['toJSON']()};}async['_setRedirectUser'](_0xb01769,_0x517156){const _0x9a336c=await this['getOrInitRedirectPersistenceManager'](_0x517156);return _0xb01769===null?_0x9a336c['removeCurrentUser']():_0x9a336c['setCurrentUser'](_0xb01769);}async['getOrInitRedirectPersistenceManager'](_0x57efcb){if(!this['redirectPersistenceManager']){const _0x5c462f=_0x57efcb&&ne(_0x57efcb)||this['_popupRedirectResolver'];m(_0x5c462f,this,'argument-error'),this['redirectPersistenceManager']=await Xe['create'](this,[ne(_0x5c462f['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x5e7e11){var _0x32ebca,_0x4d1305;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x32ebca=this['_currentUser'])==null?void 0x0:_0x32ebca['_redirectEventId'])===_0x5e7e11?this['_currentUser']:((_0x4d1305=this['redirectUser'])==null?void 0x0:_0x4d1305['_redirectEventId'])===_0x5e7e11?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x3aded5){if(_0x3aded5===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x3aded5));}['_notifyListenersIfCurrent'](_0x257a16){_0x257a16===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x1db289;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x559bc1=((_0x1db289=this['currentUser'])==null?void 0x0:_0x1db289['uid'])??null;this['lastNotifiedUid']!==_0x559bc1&&(this['lastNotifiedUid']=_0x559bc1,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x4de758,_0xb928b4,_0x1a6a95,_0x1f779e){if(this['_deleted'])return()=>{};const _0x40dc2a=typeof _0xb928b4=='function'?_0xb928b4:_0xb928b4['next']['bind'](_0xb928b4);let _0xe5e613=!0x1;const _0x265b48=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x265b48,this,'internal-error'),_0x265b48['then'](()=>{_0xe5e613||_0x40dc2a(this['currentUser']);}),typeof _0xb928b4=='function'){const _0x9bdd48=_0x4de758['addObserver'](_0xb928b4,_0x1a6a95,_0x1f779e);return()=>{_0xe5e613=!0x0,_0x9bdd48();};}else{const _0xb7eaaf=_0x4de758['addObserver'](_0xb928b4);return()=>{_0xe5e613=!0x0,_0xb7eaaf();};}}async['directlySetCurrentUser'](_0x32426e){this['currentUser']&&this['currentUser']!==_0x32426e&&this['_currentUser']['_stopProactiveRefresh'](),_0x32426e&&this['isProactiveRefreshEnabled']&&_0x32426e['_startProactiveRefresh'](),this['currentUser']=_0x32426e,_0x32426e?await this['assertedPersistence']['setCurrentUser'](_0x32426e):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x3d57e8){return this['operations']=this['operations']['then'](_0x3d57e8,_0x3d57e8),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x443c7d){!_0x443c7d||this['frameworks']['includes'](_0x443c7d)||(this['frameworks']['push'](_0x443c7d),this['frameworks']['sort'](),this['clientVersion']=Oa(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x857965;const _0xeb1930={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0xeb1930['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x1c4e5d=await((_0x857965=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x857965['getHeartbeatsHeader']());_0x1c4e5d&&(_0xeb1930['X-Firebase-Client']=_0x1c4e5d);const _0x2f5c42=await this['_getAppCheckToken']();return _0x2f5c42&&(_0xeb1930['X-Firebase-AppCheck']=_0x2f5c42),_0xeb1930;}async['_getAppCheckToken'](){var _0xf4b7c0;if(H(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x10be97=await((_0xf4b7c0=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0xf4b7c0['getToken']());return _0x10be97!=null&&_0x10be97['error']&&Zd('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x10be97['error']),_0x10be97==null?void 0x0:_0x10be97['token'];}}function qe(_0x2ad08c){return k(_0x2ad08c);}class Tr{constructor(_0x1aafcc){this['auth']=_0x1aafcc,this['observer']=null,this['addObserver']=Ic(_0x165eb6=>this['observer']=_0x165eb6);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let zn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function bf(_0x3e9e71){zn=_0x3e9e71;}function Da(_0x257263){return zn['loadJS'](_0x257263);}function Rf(){return zn['recaptchaEnterpriseScript'];}function Af(){return zn['gapiScript'];}function kf(_0x25c9a2){return'__'+_0x25c9a2+Math['floor'](Math['random']()*0xf4240);}class Nf{constructor(){this['enterprise']=new Pf();}['ready'](_0x42a950){_0x42a950();}['execute'](_0x537043,_0x3183d4){return Promise['resolve']('token');}['render'](_0x23b730,_0x2b18b0){return'';}}class Pf{['ready'](_0x1be87a){_0x1be87a();}['execute'](_0x41dc8e,_0x4362c3){return Promise['resolve']('token');}['render'](_0x388e41,_0x419372){return'';}}const Of='recaptcha-enterprise',Ma='NO_RECAPTCHA',Sr='onFirebaseAuthREInstanceReady';class le{constructor(_0x534bbf){this['type']=Of,this['auth']=qe(_0x534bbf);}async['verify'](_0x15737c='verify',_0x2d0169=!0x1){async function _0x4d4644(_0xb5b56c){if(!_0x2d0169){if(_0xb5b56c['tenantId']==null&&_0xb5b56c['_agentRecaptchaConfig']!=null)return _0xb5b56c['_agentRecaptchaConfig']['siteKey'];if(_0xb5b56c['tenantId']!=null&&_0xb5b56c['_tenantRecaptchaConfigs'][_0xb5b56c['tenantId']]!==void 0x0)return _0xb5b56c['_tenantRecaptchaConfigs'][_0xb5b56c['tenantId']]['siteKey'];}return new Promise(async(_0x496b57,_0x5c74cf)=>{hf(_0xb5b56c,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x42f028=>{if(_0x42f028['recaptchaKey']===void 0x0)_0x5c74cf(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x5b2264=new lf(_0x42f028);return _0xb5b56c['tenantId']==null?_0xb5b56c['_agentRecaptchaConfig']=_0x5b2264:_0xb5b56c['_tenantRecaptchaConfigs'][_0xb5b56c['tenantId']]=_0x5b2264,_0x496b57(_0x5b2264['siteKey']);}})['catch'](_0x2c01fe=>{_0x5c74cf(_0x2c01fe);});});}function _0x3791d5(_0x281813,_0x675ed6,_0x51d33c){const _0x2ab0c2=window['grecaptcha'];vr(_0x2ab0c2)?_0x2ab0c2['enterprise']['ready'](()=>{_0x2ab0c2['enterprise']['execute'](_0x281813,{'action':_0x15737c})['then'](_0x3c9dae=>{_0x675ed6(_0x3c9dae);})['catch'](()=>{_0x675ed6(Ma);});}):_0x51d33c(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Nf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x4e8a8e,_0x977d23)=>{_0x4d4644(this['auth'])['then'](async _0x5b5093=>{if(!_0x2d0169&&vr(window['grecaptcha'])&&le['scriptInjectionDeferred'])await le['scriptInjectionDeferred']['promise'],_0x3791d5(_0x5b5093,_0x4e8a8e,_0x977d23);else{if(typeof window>'u'){_0x977d23(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x42b3d3=Rf();_0x42b3d3['length']!==0x0&&(_0x42b3d3+=_0x5b5093+('&onload='+Sr)),le['scriptInjectionDeferred']=new Ve(),window[Sr]=()=>{var _0x4f3eea;(_0x4f3eea=le['scriptInjectionDeferred'])==null||_0x4f3eea['resolve']();},Da(_0x42b3d3)['then'](()=>{var _0x4f7d75;return(_0x4f7d75=le['scriptInjectionDeferred'])==null?void 0x0:_0x4f7d75['promise'];})['then'](()=>{_0x3791d5(_0x5b5093,_0x4e8a8e,_0x977d23);})['catch'](_0x3def9e=>{_0x977d23(_0x3def9e);});}})['catch'](_0x35a684=>{_0x977d23(_0x35a684);});});}}le['scriptInjectionDeferred']=null;async function br(_0x5c3b30,_0x5710a8,_0x53e71e,_0x527413=!0x1,_0x450571=!0x1){const _0x17b684=new le(_0x5c3b30);let _0x236305;if(_0x450571)_0x236305=Ma;else try{_0x236305=await _0x17b684['verify'](_0x53e71e);}catch{_0x236305=await _0x17b684['verify'](_0x53e71e,!0x0);}const _0x14eb8b={..._0x5710a8};if(_0x53e71e==='mfaSmsEnrollment'||_0x53e71e==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x14eb8b){const _0x254fcf=_0x14eb8b['phoneEnrollmentInfo']['phoneNumber'],_0x1734cd=_0x14eb8b['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x14eb8b,{'phoneEnrollmentInfo':{'phoneNumber':_0x254fcf,'recaptchaToken':_0x1734cd,'captchaResponse':_0x236305,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x14eb8b){const _0x259728=_0x14eb8b['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x14eb8b,{'phoneSignInInfo':{'recaptchaToken':_0x259728,'captchaResponse':_0x236305,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x14eb8b;}return _0x527413?Object['assign'](_0x14eb8b,{'captchaResp':_0x236305}):Object['assign'](_0x14eb8b,{'captchaResponse':_0x236305}),Object['assign'](_0x14eb8b,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x14eb8b,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x14eb8b;}async function Oi(_0x235cc3,_0x29b78d,_0x4d280f,_0x5ee5ad,_0x3b3920){var _0xc00afe;if((_0xc00afe=_0x235cc3['_getRecaptchaConfig']())!=null&&_0xc00afe['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x10b85b=await br(_0x235cc3,_0x29b78d,_0x4d280f,_0x4d280f==='getOobCode');return _0x5ee5ad(_0x235cc3,_0x10b85b);}else return _0x5ee5ad(_0x235cc3,_0x29b78d)['catch'](async _0x4790e3=>{if(_0x4790e3['code']==='auth/missing-recaptcha-token'){console['log'](_0x4d280f+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x2948e8=await br(_0x235cc3,_0x29b78d,_0x4d280f,_0x4d280f==='getOobCode');return _0x5ee5ad(_0x235cc3,_0x2948e8);}else return Promise['reject'](_0x4790e3);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Df(_0x31392b,_0x26c691){const _0x33132c=Ui(_0x31392b,'auth');if(_0x33132c['isInitialized']()){const _0x156783=_0x33132c['getImmediate'](),_0x5acdc6=_0x33132c['getOptions']();if(De(_0x5acdc6,_0x26c691??{}))return _0x156783;K(_0x156783,'already-initialized');}return _0x33132c['initialize']({'options':_0x26c691});}function Mf(_0x1685b8,_0x4d0dd5){const _0x4d8527=(_0x4d0dd5==null?void 0x0:_0x4d0dd5['persistence'])||[],_0x4a591d=(Array['isArray'](_0x4d8527)?_0x4d8527:[_0x4d8527])['map'](ne);_0x4d0dd5!=null&&_0x4d0dd5['errorMap']&&_0x1685b8['_updateErrorMap'](_0x4d0dd5['errorMap']),_0x1685b8['_initializeWithPersistence'](_0x4a591d,_0x4d0dd5==null?void 0x0:_0x4d0dd5['popupRedirectResolver']);}function Lf(_0x503aa9,_0x4de775,_0x244274){const _0x117ce7=qe(_0x503aa9);m(/^https?:\/\//['test'](_0x4de775),_0x117ce7,'invalid-emulator-scheme');const _0x555582=!0x1,_0x29287e=La(_0x4de775),{host:_0x3baf78,port:_0x2fb8ab}=xf(_0x4de775),_0x2a55f7=_0x2fb8ab===null?'':':'+_0x2fb8ab,_0x28801e={'url':_0x29287e+'//'+_0x3baf78+_0x2a55f7+'/'},_0x405a59=Object['freeze']({'host':_0x3baf78,'port':_0x2fb8ab,'protocol':_0x29287e['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x555582})});if(!_0x117ce7['_canInitEmulator']){m(_0x117ce7['config']['emulator']&&_0x117ce7['emulatorConfig'],_0x117ce7,'emulator-config-failed'),m(De(_0x28801e,_0x117ce7['config']['emulator'])&&De(_0x405a59,_0x117ce7['emulatorConfig']),_0x117ce7,'emulator-config-failed');return;}_0x117ce7['config']['emulator']=_0x28801e,_0x117ce7['emulatorConfig']=_0x405a59,_0x117ce7['settings']['appVerificationDisabledForTesting']=!0x0,Wt(_0x3baf78)?jr(_0x29287e+'//'+_0x3baf78+_0x2a55f7):Ff();}function La(_0x1a4c48){const _0x41982a=_0x1a4c48['indexOf'](':');return _0x41982a<0x0?'':_0x1a4c48['substr'](0x0,_0x41982a+0x1);}function xf(_0x1cfb88){const _0x8e65c3=La(_0x1cfb88),_0x334c3b=/(\/\/)?([^?#/]+)/['exec'](_0x1cfb88['substr'](_0x8e65c3['length']));if(!_0x334c3b)return{'host':'','port':null};const _0x35776e=_0x334c3b[0x2]['split']('@')['pop']()||'',_0x130018=/^(\[[^\]]+\])(:|$)/['exec'](_0x35776e);if(_0x130018){const _0x5b0286=_0x130018[0x1];return{'host':_0x5b0286,'port':Rr(_0x35776e['substr'](_0x5b0286['length']+0x1))};}else{const [_0x11db0f,_0x226b70]=_0x35776e['split'](':');return{'host':_0x11db0f,'port':Rr(_0x226b70)};}}function Rr(_0x1c63c7){if(!_0x1c63c7)return null;const _0x305574=Number(_0x1c63c7);return isNaN(_0x305574)?null:_0x305574;}function Ff(){function _0x28c5b8(){const _0x5b4788=document['createElement']('p'),_0x117433=_0x5b4788['style'];_0x5b4788['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x117433['position']='fixed',_0x117433['width']='100%',_0x117433['backgroundColor']='#ffffff',_0x117433['border']='.1em\x20solid\x20#000000',_0x117433['color']='#b50000',_0x117433['bottom']='0px',_0x117433['left']='0px',_0x117433['margin']='0px',_0x117433['zIndex']='10000',_0x117433['textAlign']='center',_0x5b4788['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x5b4788);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x28c5b8):_0x28c5b8());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ts{constructor(_0x59d24a,_0x2f8425){this['providerId']=_0x59d24a,this['signInMethod']=_0x2f8425;}['toJSON'](){return te('not\x20implemented');}['_getIdTokenResponse'](_0x24494c){return te('not\x20implemented');}['_linkToIdToken'](_0x5525f2,_0x405703){return te('not\x20implemented');}['_getReauthenticationResolver'](_0x4375ac){return te('not\x20implemented');}}async function Uf(_0x3d5ec7,_0x4b6077){return Ae(_0x3d5ec7,'POST','/v1/accounts:signUp',_0x4b6077);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wf(_0x5931e0,_0x1f50bc){return Yt(_0x5931e0,'POST','/v1/accounts:signInWithPassword',Re(_0x5931e0,_0x1f50bc));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Bf(_0x3f6d86,_0x3c05c2){return Yt(_0x3f6d86,'POST','/v1/accounts:signInWithEmailLink',Re(_0x3f6d86,_0x3c05c2));}async function Vf(_0x3f636e,_0x1abc58){return Yt(_0x3f636e,'POST','/v1/accounts:signInWithEmailLink',Re(_0x3f636e,_0x1abc58));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft extends Ts{constructor(_0x2fc9d9,_0x35886a,_0x543f35,_0x309be5=null){super('password',_0x543f35),this['_email']=_0x2fc9d9,this['_password']=_0x35886a,this['_tenantId']=_0x309be5;}static['_fromEmailAndPassword'](_0x12db2f,_0x454747){return new Ft(_0x12db2f,_0x454747,'password');}static['_fromEmailAndCode'](_0x59533f,_0x2d4e23,_0x4e4a3e=null){return new Ft(_0x59533f,_0x2d4e23,'emailLink',_0x4e4a3e);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0xb7d04e){const _0x3d1f89=typeof _0xb7d04e=='string'?JSON['parse'](_0xb7d04e):_0xb7d04e;if(_0x3d1f89!=null&&_0x3d1f89['email']&&(_0x3d1f89!=null&&_0x3d1f89['password'])){if(_0x3d1f89['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x3d1f89['email'],_0x3d1f89['password']);if(_0x3d1f89['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x3d1f89['email'],_0x3d1f89['password'],_0x3d1f89['tenantId']);}return null;}async['_getIdTokenResponse'](_0x200d11){switch(this['signInMethod']){case'password':const _0x42297a={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x200d11,_0x42297a,'signInWithPassword',Wf);case'emailLink':return Bf(_0x200d11,{'email':this['_email'],'oobCode':this['_password']});default:K(_0x200d11,'internal-error');}}async['_linkToIdToken'](_0x693d33,_0x5d3998){switch(this['signInMethod']){case'password':const _0x4aa5d3={'idToken':_0x5d3998,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Oi(_0x693d33,_0x4aa5d3,'signUpPassword',Uf);case'emailLink':return Vf(_0x693d33,{'idToken':_0x5d3998,'email':this['_email'],'oobCode':this['_password']});default:K(_0x693d33,'internal-error');}}['_getReauthenticationResolver'](_0x69b514){return this['_getIdTokenResponse'](_0x69b514);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ze(_0x1415e5,_0x38d755){return Yt(_0x1415e5,'POST','/v1/accounts:signInWithIdp',Re(_0x1415e5,_0x38d755));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hf='http://localhost';class We extends Ts{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x77811b){const _0x10da8a=new We(_0x77811b['providerId'],_0x77811b['signInMethod']);return _0x77811b['idToken']||_0x77811b['accessToken']?(_0x77811b['idToken']&&(_0x10da8a['idToken']=_0x77811b['idToken']),_0x77811b['accessToken']&&(_0x10da8a['accessToken']=_0x77811b['accessToken']),_0x77811b['nonce']&&!_0x77811b['pendingToken']&&(_0x10da8a['nonce']=_0x77811b['nonce']),_0x77811b['pendingToken']&&(_0x10da8a['pendingToken']=_0x77811b['pendingToken'])):_0x77811b['oauthToken']&&_0x77811b['oauthTokenSecret']?(_0x10da8a['accessToken']=_0x77811b['oauthToken'],_0x10da8a['secret']=_0x77811b['oauthTokenSecret']):K('argument-error'),_0x10da8a;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x422972){const _0x3ba874=typeof _0x422972=='string'?JSON['parse'](_0x422972):_0x422972,{providerId:_0x2ca375,signInMethod:_0x5c186b,..._0x23c975}=_0x3ba874;if(!_0x2ca375||!_0x5c186b)return null;const _0x5a51bd=new We(_0x2ca375,_0x5c186b);return _0x5a51bd['idToken']=_0x23c975['idToken']||void 0x0,_0x5a51bd['accessToken']=_0x23c975['accessToken']||void 0x0,_0x5a51bd['secret']=_0x23c975['secret'],_0x5a51bd['nonce']=_0x23c975['nonce'],_0x5a51bd['pendingToken']=_0x23c975['pendingToken']||null,_0x5a51bd;}['_getIdTokenResponse'](_0x236719){const _0x546e3d=this['buildRequest']();return Ze(_0x236719,_0x546e3d);}['_linkToIdToken'](_0x31a96a,_0x4e0931){const _0x1ee2cc=this['buildRequest']();return _0x1ee2cc['idToken']=_0x4e0931,Ze(_0x31a96a,_0x1ee2cc);}['_getReauthenticationResolver'](_0x1437d6){const _0x2a96bf=this['buildRequest']();return _0x2a96bf['autoCreate']=!0x1,Ze(_0x1437d6,_0x2a96bf);}['buildRequest'](){const _0x123324={'requestUri':Hf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x123324['pendingToken']=this['pendingToken'];else{const _0x10e882={};this['idToken']&&(_0x10e882['id_token']=this['idToken']),this['accessToken']&&(_0x10e882['access_token']=this['accessToken']),this['secret']&&(_0x10e882['oauth_token_secret']=this['secret']),_0x10e882['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x10e882['nonce']=this['nonce']),_0x123324['postBody']=at(_0x10e882);}return _0x123324;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function $f(_0x284321){switch(_0x284321){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Gf(_0x13f865){const _0x9611b9=yt(vt(_0x13f865))['link'],_0xfc2f96=_0x9611b9?yt(vt(_0x9611b9))['deep_link_id']:null,_0x3ebdc8=yt(vt(_0x13f865))['deep_link_id'];return(_0x3ebdc8?yt(vt(_0x3ebdc8))['link']:null)||_0x3ebdc8||_0xfc2f96||_0x9611b9||_0x13f865;}class Ss{constructor(_0x200157){const _0x5a00f1=yt(vt(_0x200157)),_0x2a2b0a=_0x5a00f1['apiKey']??null,_0x5ae610=_0x5a00f1['oobCode']??null,_0x4ac712=$f(_0x5a00f1['mode']??null);m(_0x2a2b0a&&_0x5ae610&&_0x4ac712,'argument-error'),this['apiKey']=_0x2a2b0a,this['operation']=_0x4ac712,this['code']=_0x5ae610,this['continueUrl']=_0x5a00f1['continueUrl']??null,this['languageCode']=_0x5a00f1['lang']??null,this['tenantId']=_0x5a00f1['tenantId']??null;}static['parseLink'](_0x3da8ca){const _0xb21193=Gf(_0x3da8ca);try{return new Ss(_0xb21193);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ft{constructor(){this['providerId']=ft['PROVIDER_ID'];}static['credential'](_0x39d032,_0x39665a){return Ft['_fromEmailAndPassword'](_0x39d032,_0x39665a);}static['credentialWithLink'](_0x54486a,_0x5c1518){const _0x167f6b=Ss['parseLink'](_0x5c1518);return m(_0x167f6b,'argument-error'),Ft['_fromEmailAndCode'](_0x54486a,_0x167f6b['code'],_0x167f6b['tenantId']);}}ft['PROVIDER_ID']='password',ft['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',ft['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xa{constructor(_0x5431b9){this['providerId']=_0x5431b9,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x46f820){this['defaultLanguageCode']=_0x46f820;}['setCustomParameters'](_0xbfefd4){return this['customParameters']=_0xbfefd4,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qt extends xa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x2867ce){return this['scopes']['includes'](_0x2867ce)||this['scopes']['push'](_0x2867ce),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Qt{constructor(){super('facebook.com');}static['credential'](_0x51b57d){return We['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x51b57d});}static['credentialFromResult'](_0x1883c1){return he['credentialFromTaggedObject'](_0x1883c1);}static['credentialFromError'](_0x51c7e7){return he['credentialFromTaggedObject'](_0x51c7e7['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x8f58d}){if(!_0x8f58d||!('oauthAccessToken'in _0x8f58d)||!_0x8f58d['oauthAccessToken'])return null;try{return he['credential'](_0x8f58d['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Qt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x82c8a2,_0x5577a2){return We['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x82c8a2,'accessToken':_0x5577a2});}static['credentialFromResult'](_0xb657c7){return ue['credentialFromTaggedObject'](_0xb657c7);}static['credentialFromError'](_0x4f063d){return ue['credentialFromTaggedObject'](_0x4f063d['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x36d897}){if(!_0x36d897)return null;const {oauthIdToken:_0x4b809d,oauthAccessToken:_0x1bb150}=_0x36d897;if(!_0x4b809d&&!_0x1bb150)return null;try{return ue['credential'](_0x4b809d,_0x1bb150);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Qt{constructor(){super('github.com');}static['credential'](_0x283409){return We['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x283409});}static['credentialFromResult'](_0x3f93b8){return de['credentialFromTaggedObject'](_0x3f93b8);}static['credentialFromError'](_0x43cf14){return de['credentialFromTaggedObject'](_0x43cf14['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x3f565e}){if(!_0x3f565e||!('oauthAccessToken'in _0x3f565e)||!_0x3f565e['oauthAccessToken'])return null;try{return de['credential'](_0x3f565e['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Qt{constructor(){super('twitter.com');}static['credential'](_0x458c18,_0xd532f0){return We['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x458c18,'oauthTokenSecret':_0xd532f0});}static['credentialFromResult'](_0x2d0261){return fe['credentialFromTaggedObject'](_0x2d0261);}static['credentialFromError'](_0x2cad95){return fe['credentialFromTaggedObject'](_0x2cad95['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x33d633}){if(!_0x33d633)return null;const {oauthAccessToken:_0x56ccae,oauthTokenSecret:_0x3dbf5f}=_0x33d633;if(!_0x56ccae||!_0x3dbf5f)return null;try{return fe['credential'](_0x56ccae,_0x3dbf5f);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function qf(_0xae67df,_0x2eba51){return Yt(_0xae67df,'POST','/v1/accounts:signUp',Re(_0xae67df,_0x2eba51));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x407b10){this['user']=_0x407b10['user'],this['providerId']=_0x407b10['providerId'],this['_tokenResponse']=_0x407b10['_tokenResponse'],this['operationType']=_0x407b10['operationType'];}static async['_fromIdTokenResponse'](_0x4cdaa7,_0x2b5aaf,_0x539a89,_0x322588=!0x1){const _0x4466ac=await z['_fromIdTokenResponse'](_0x4cdaa7,_0x539a89,_0x322588),_0x38f0c1=Ar(_0x539a89);return new Be({'user':_0x4466ac,'providerId':_0x38f0c1,'_tokenResponse':_0x539a89,'operationType':_0x2b5aaf});}static async['_forOperation'](_0x118a27,_0x2f39af,_0x1f03a7){await _0x118a27['_updateTokensIfNecessary'](_0x1f03a7,!0x0);const _0x37f6c3=Ar(_0x1f03a7);return new Be({'user':_0x118a27,'providerId':_0x37f6c3,'_tokenResponse':_0x1f03a7,'operationType':_0x2f39af});}}function Ar(_0x2050de){return _0x2050de['providerId']?_0x2050de['providerId']:'phoneNumber'in _0x2050de?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rn extends Se{constructor(_0x1625b8,_0x344750,_0x46e346,_0x274314){super(_0x344750['code'],_0x344750['message']),this['operationType']=_0x46e346,this['user']=_0x274314,Object['setPrototypeOf'](this,Rn['prototype']),this['customData']={'appName':_0x1625b8['name'],'tenantId':_0x1625b8['tenantId']??void 0x0,'_serverResponse':_0x344750['customData']['_serverResponse'],'operationType':_0x46e346};}static['_fromErrorAndOperation'](_0x218239,_0xd562cf,_0x27cc93,_0x17902e){return new Rn(_0x218239,_0xd562cf,_0x27cc93,_0x17902e);}}function Fa(_0xf04da9,_0x32a90c,_0x221d4a,_0x10b68e){return(_0x32a90c==='reauthenticate'?_0x221d4a['_getReauthenticationResolver'](_0xf04da9):_0x221d4a['_getIdTokenResponse'](_0xf04da9))['catch'](_0x24118d=>{throw _0x24118d['code']==='auth/multi-factor-auth-required'?Rn['_fromErrorAndOperation'](_0xf04da9,_0x24118d,_0x32a90c,_0x10b68e):_0x24118d;});}async function zf(_0x525ba0,_0xebf2b3,_0xd571ee=!0x1){const _0x3dcd7f=await xt(_0x525ba0,_0xebf2b3['_linkToIdToken'](_0x525ba0['auth'],await _0x525ba0['getIdToken']()),_0xd571ee);return Be['_forOperation'](_0x525ba0,'link',_0x3dcd7f);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x5e3c98,_0x2c6a61,_0x23ede9=!0x1){const {auth:_0x4ec4f5}=_0x5e3c98;if(H(_0x4ec4f5['app']))return Promise['reject'](se(_0x4ec4f5));const _0x35fad3='reauthenticate';try{const _0x11d8ea=await xt(_0x5e3c98,Fa(_0x4ec4f5,_0x35fad3,_0x2c6a61,_0x5e3c98),_0x23ede9);m(_0x11d8ea['idToken'],_0x4ec4f5,'internal-error');const _0x554dc2=ws(_0x11d8ea['idToken']);m(_0x554dc2,_0x4ec4f5,'internal-error');const {sub:_0x3d3946}=_0x554dc2;return m(_0x5e3c98['uid']===_0x3d3946,_0x4ec4f5,'user-mismatch'),Be['_forOperation'](_0x5e3c98,_0x35fad3,_0x11d8ea);}catch(_0x520217){throw(_0x520217==null?void 0x0:_0x520217['code'])==='auth/user-not-found'&&K(_0x4ec4f5,'user-mismatch'),_0x520217;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ua(_0x224b37,_0x770124,_0x2c8c43=!0x1){if(H(_0x224b37['app']))return Promise['reject'](se(_0x224b37));const _0x2a8e3b='signIn',_0x22ea73=await Fa(_0x224b37,_0x2a8e3b,_0x770124),_0x109e81=await Be['_fromIdTokenResponse'](_0x224b37,_0x2a8e3b,_0x22ea73);return _0x2c8c43||await _0x224b37['_updateCurrentUser'](_0x109e81['user']),_0x109e81;}async function Kf(_0x2ae53b,_0x56eb00){return Ua(qe(_0x2ae53b),_0x56eb00);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Wa(_0x2d4627){const _0x58a277=qe(_0x2d4627);_0x58a277['_getPasswordPolicyInternal']()&&await _0x58a277['_updatePasswordPolicy']();}async function S_(_0x4792a0,_0x2a189c,_0x953904){if(H(_0x4792a0['app']))return Promise['reject'](se(_0x4792a0));const _0x4b2c0e=qe(_0x4792a0),_0x349f1c=await Oi(_0x4b2c0e,{'returnSecureToken':!0x0,'email':_0x2a189c,'password':_0x953904,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',qf)['catch'](_0x45bc15=>{throw _0x45bc15['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x4792a0),_0x45bc15;}),_0x3f91a2=await Be['_fromIdTokenResponse'](_0x4b2c0e,'signIn',_0x349f1c);return await _0x4b2c0e['_updateCurrentUser'](_0x3f91a2['user']),_0x3f91a2;}function b_(_0x163336,_0x172b99,_0x479ba6){return H(_0x163336['app'])?Promise['reject'](se(_0x163336)):Kf(k(_0x163336),ft['credential'](_0x172b99,_0x479ba6))['catch'](async _0x332db4=>{throw _0x332db4['code']==='auth/password-does-not-meet-requirements'&&Wa(_0x163336),_0x332db4;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function R_(_0x4b342f,_0x41a4c4){return k(_0x4b342f)['setPersistence'](_0x41a4c4);}function Yf(_0x3d7f52,_0x223264,_0x176bc6,_0x3282c1){return k(_0x3d7f52)['onIdTokenChanged'](_0x223264,_0x176bc6,_0x3282c1);}function Qf(_0x420801,_0x48b362,_0x5fb4c4){return k(_0x420801)['beforeAuthStateChanged'](_0x48b362,_0x5fb4c4);}function A_(_0x5428da,_0x5b99d5,_0x115a6d,_0x38892b){return k(_0x5428da)['onAuthStateChanged'](_0x5b99d5,_0x115a6d,_0x38892b);}function k_(_0x3a2b54){return k(_0x3a2b54)['signOut']();}const An='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ba{constructor(_0x3165dd,_0xf8592d){this['storageRetriever']=_0x3165dd,this['type']=_0xf8592d;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](An,'1'),this['storage']['removeItem'](An),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x2abbfb,_0x40d9c3){return this['storage']['setItem'](_0x2abbfb,JSON['stringify'](_0x40d9c3)),Promise['resolve']();}['_get'](_0x1f0050){const _0x232f0c=this['storage']['getItem'](_0x1f0050);return Promise['resolve'](_0x232f0c?JSON['parse'](_0x232f0c):null);}['_remove'](_0x15aaaf){return this['storage']['removeItem'](_0x15aaaf),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Jf=0x3e8,Xf=0xa;class Va extends Ba{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x3ef176,_0x1f6492)=>this['onStorageEvent'](_0x3ef176,_0x1f6492),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Pa(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x50ffc5){for(const _0x2b0c07 of Object['keys'](this['listeners'])){const _0xd4f5da=this['storage']['getItem'](_0x2b0c07),_0x35a857=this['localCache'][_0x2b0c07];_0xd4f5da!==_0x35a857&&_0x50ffc5(_0x2b0c07,_0x35a857,_0xd4f5da);}}['onStorageEvent'](_0x21c533,_0x35e0ee=!0x1){if(!_0x21c533['key']){this['forAllChangedKeys']((_0x4fa9db,_0x1a70d0,_0x286042)=>{this['notifyListeners'](_0x4fa9db,_0x286042);});return;}const _0x1045c5=_0x21c533['key'];_0x35e0ee?this['detachListener']():this['stopPolling']();const _0x2f39cf=()=>{const _0x55a111=this['storage']['getItem'](_0x1045c5);!_0x35e0ee&&this['localCache'][_0x1045c5]===_0x55a111||this['notifyListeners'](_0x1045c5,_0x55a111);},_0x4b153c=this['storage']['getItem'](_0x1045c5);Ef()&&_0x4b153c!==_0x21c533['newValue']&&_0x21c533['newValue']!==_0x21c533['oldValue']?setTimeout(_0x2f39cf,Xf):_0x2f39cf();}['notifyListeners'](_0x253e40,_0x43666d){this['localCache'][_0x253e40]=_0x43666d;const _0x31cb4d=this['listeners'][_0x253e40];if(_0x31cb4d){for(const _0x222009 of Array['from'](_0x31cb4d))_0x222009(_0x43666d&&JSON['parse'](_0x43666d));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x1f4d68,_0x489060,_0x501ae3)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x1f4d68,'oldValue':_0x489060,'newValue':_0x501ae3}),!0x0);});},Jf);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x2fb9ca,_0x485ace){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x2fb9ca]||(this['listeners'][_0x2fb9ca]=new Set(),this['localCache'][_0x2fb9ca]=this['storage']['getItem'](_0x2fb9ca)),this['listeners'][_0x2fb9ca]['add'](_0x485ace);}['_removeListener'](_0x57264a,_0x30521e){this['listeners'][_0x57264a]&&(this['listeners'][_0x57264a]['delete'](_0x30521e),this['listeners'][_0x57264a]['size']===0x0&&delete this['listeners'][_0x57264a]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x5c8147,_0x1830ab){await super['_set'](_0x5c8147,_0x1830ab),this['localCache'][_0x5c8147]=JSON['stringify'](_0x1830ab);}async['_get'](_0x3d9fc0){const _0x28c982=await super['_get'](_0x3d9fc0);return this['localCache'][_0x3d9fc0]=JSON['stringify'](_0x28c982),_0x28c982;}async['_remove'](_0x2d0ecf){await super['_remove'](_0x2d0ecf),delete this['localCache'][_0x2d0ecf];}}Va['type']='LOCAL';const Zf=Va;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ha extends Ba{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x3448be,_0x217062){}['_removeListener'](_0x51aaf9,_0x40f3d4){}}Ha['type']='SESSION';const $a=Ha;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ep(_0x49ba35){return Promise['all'](_0x49ba35['map'](async _0x8ee0b2=>{try{return{'fulfilled':!0x0,'value':await _0x8ee0b2};}catch(_0x103bc3){return{'fulfilled':!0x1,'reason':_0x103bc3};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jn{constructor(_0x1ca932){this['eventTarget']=_0x1ca932,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x669bf4){const _0xdfe57b=this['receivers']['find'](_0x2b7218=>_0x2b7218['isListeningto'](_0x669bf4));if(_0xdfe57b)return _0xdfe57b;const _0x23e852=new jn(_0x669bf4);return this['receivers']['push'](_0x23e852),_0x23e852;}['isListeningto'](_0x140c26){return this['eventTarget']===_0x140c26;}async['handleEvent'](_0x1bd34d){const _0x17dc6f=_0x1bd34d,{eventId:_0x334454,eventType:_0x42cea0,data:_0x24050b}=_0x17dc6f['data'],_0x29920b=this['handlersMap'][_0x42cea0];if(!(_0x29920b!=null&&_0x29920b['size']))return;_0x17dc6f['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x334454,'eventType':_0x42cea0});const _0x32c7dc=Array['from'](_0x29920b)['map'](async _0x199a06=>_0x199a06(_0x17dc6f['origin'],_0x24050b)),_0x171fe0=await ep(_0x32c7dc);_0x17dc6f['ports'][0x0]['postMessage']({'status':'done','eventId':_0x334454,'eventType':_0x42cea0,'response':_0x171fe0});}['_subscribe'](_0x4bff19,_0x2722d4){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x4bff19]||(this['handlersMap'][_0x4bff19]=new Set()),this['handlersMap'][_0x4bff19]['add'](_0x2722d4);}['_unsubscribe'](_0x4340cb,_0x514ec9){this['handlersMap'][_0x4340cb]&&_0x514ec9&&this['handlersMap'][_0x4340cb]['delete'](_0x514ec9),(!_0x514ec9||this['handlersMap'][_0x4340cb]['size']===0x0)&&delete this['handlersMap'][_0x4340cb],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}jn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bs(_0x949f50='',_0x166878=0xa){let _0x4c3287='';for(let _0x1325bf=0x0;_0x1325bf<_0x166878;_0x1325bf++)_0x4c3287+=Math['floor'](Math['random']()*0xa);return _0x949f50+_0x4c3287;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tp{constructor(_0x13e851){this['target']=_0x13e851,this['handlers']=new Set();}['removeMessageHandler'](_0x2f98b7){_0x2f98b7['messageChannel']&&(_0x2f98b7['messageChannel']['port1']['removeEventListener']('message',_0x2f98b7['onMessage']),_0x2f98b7['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x2f98b7);}async['_send'](_0xe46812,_0x294090,_0x2ac540=0x32){const _0x13cb3e=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x13cb3e)throw new Error('connection_unavailable');let _0x59c92f,_0x32b04a;return new Promise((_0x3b552d,_0x1e888a)=>{const _0xc6bf31=bs('',0x14);_0x13cb3e['port1']['start']();const _0x2eaa57=setTimeout(()=>{_0x1e888a(new Error('unsupported_event'));},_0x2ac540);_0x32b04a={'messageChannel':_0x13cb3e,'onMessage'(_0x4c6d56){const _0x416971=_0x4c6d56;if(_0x416971['data']['eventId']===_0xc6bf31)switch(_0x416971['data']['status']){case'ack':clearTimeout(_0x2eaa57),_0x59c92f=setTimeout(()=>{_0x1e888a(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x59c92f),_0x3b552d(_0x416971['data']['response']);break;default:clearTimeout(_0x2eaa57),clearTimeout(_0x59c92f),_0x1e888a(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x32b04a),_0x13cb3e['port1']['addEventListener']('message',_0x32b04a['onMessage']),this['target']['postMessage']({'eventType':_0xe46812,'eventId':_0xc6bf31,'data':_0x294090},[_0x13cb3e['port2']]);})['finally'](()=>{_0x32b04a&&this['removeMessageHandler'](_0x32b04a);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function X(){return window;}function np(_0xc5b928){X()['location']['href']=_0xc5b928;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ga(){return typeof X()['WorkerGlobalScope']<'u'&&typeof X()['importScripts']=='function';}async function ip(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function sp(){var _0x37979c;return((_0x37979c=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x37979c['controller'])||null;}function rp(){return Ga()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qa='firebaseLocalStorageDb',op=0x1,kn='firebaseLocalStorage',za='fbase_key';class Jt{constructor(_0x5f5874){this['request']=_0x5f5874;}['toPromise'](){return new Promise((_0x7d5a84,_0x3f6e3e)=>{this['request']['addEventListener']('success',()=>{_0x7d5a84(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x3f6e3e(this['request']['error']);});});}}function Kn(_0x206325,_0x56e8b2){return _0x206325['transaction']([kn],_0x56e8b2?'readwrite':'readonly')['objectStore'](kn);}function ap(){const _0x2dc1cd=indexedDB['deleteDatabase'](qa);return new Jt(_0x2dc1cd)['toPromise']();}function ja(){const _0x357146=indexedDB['open'](qa,op);return new Promise((_0x5003bf,_0x367fec)=>{_0x357146['addEventListener']('error',()=>{_0x367fec(_0x357146['error']);}),_0x357146['addEventListener']('upgradeneeded',()=>{const _0x318b66=_0x357146['result'];try{_0x318b66['createObjectStore'](kn,{'keyPath':za});}catch(_0x264c30){_0x367fec(_0x264c30);}}),_0x357146['addEventListener']('success',async()=>{const _0x68991f=_0x357146['result'];_0x68991f['objectStoreNames']['contains'](kn)?_0x5003bf(_0x68991f):(_0x68991f['close'](),await ap(),_0x5003bf(await ja()));});});}async function kr(_0x15e600,_0x328db9,_0x242233){const _0x5d6f06=Kn(_0x15e600,!0x0)['put']({[za]:_0x328db9,'value':_0x242233});return new Jt(_0x5d6f06)['toPromise']();}async function cp(_0x71ec89,_0x3661fe){const _0x3259a6=Kn(_0x71ec89,!0x1)['get'](_0x3661fe),_0x44ce27=await new Jt(_0x3259a6)['toPromise']();return _0x44ce27===void 0x0?null:_0x44ce27['value'];}function Nr(_0x1a1445,_0x2b2f2a){const _0x582abb=Kn(_0x1a1445,!0x0)['delete'](_0x2b2f2a);return new Jt(_0x582abb)['toPromise']();}const lp=0x320,hp=0x3;class Ka{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=ja(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0xad1b3b){let _0x462f01=0x0;for(;;)try{const _0x16d95d=await this['_openDb']();return await _0xad1b3b(_0x16d95d);}catch(_0x7dd492){if(_0x462f01++>hp)throw _0x7dd492;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return Ga()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=jn['_getInstance'](rp()),this['receiver']['_subscribe']('keyChanged',async(_0x11eefe,_0x4b991a)=>({'keyProcessed':(await this['_poll']())['includes'](_0x4b991a['key'])})),this['receiver']['_subscribe']('ping',async(_0x347b27,_0x3a154b)=>['keyChanged']);}async['initializeSender'](){var _0x3666c9,_0x3f74e7;if(this['activeServiceWorker']=await ip(),!this['activeServiceWorker'])return;this['sender']=new tp(this['activeServiceWorker']);const _0x21d436=await this['sender']['_send']('ping',{},0x320);_0x21d436&&(_0x3666c9=_0x21d436[0x0])!=null&&_0x3666c9['fulfilled']&&(_0x3f74e7=_0x21d436[0x0])!=null&&_0x3f74e7['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x52e442){if(!(!this['sender']||!this['activeServiceWorker']||sp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x52e442},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x1275ff=>{await kr(_0x1275ff,An,'1'),await Nr(_0x1275ff,An);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x51e3f0){this['pendingWrites']++;try{await _0x51e3f0();}finally{this['pendingWrites']--;}}async['_set'](_0x1a9314,_0x5dec85){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x6bbbb6=>kr(_0x6bbbb6,_0x1a9314,_0x5dec85)),this['localCache'][_0x1a9314]=_0x5dec85,this['notifyServiceWorker'](_0x1a9314)));}async['_get'](_0x333a39){const _0x28db26=await this['_withRetries'](_0x35bd91=>cp(_0x35bd91,_0x333a39));return this['localCache'][_0x333a39]=_0x28db26,_0x28db26;}async['_remove'](_0x2522c2){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x2ad06a=>Nr(_0x2ad06a,_0x2522c2)),delete this['localCache'][_0x2522c2],this['notifyServiceWorker'](_0x2522c2)));}async['_poll'](){const _0x15791d=await this['_withRetries'](_0x2015c6=>{const _0x6bf3ac=Kn(_0x2015c6,!0x1)['getAll']();return new Jt(_0x6bf3ac)['toPromise']();});if(!_0x15791d)return[];if(this['pendingWrites']!==0x0)return[];const _0x483b41=[],_0x38a265=new Set();if(_0x15791d['length']!==0x0){for(const {fbase_key:_0x660ccf,value:_0x5a69e9}of _0x15791d)_0x38a265['add'](_0x660ccf),JSON['stringify'](this['localCache'][_0x660ccf])!==JSON['stringify'](_0x5a69e9)&&(this['notifyListeners'](_0x660ccf,_0x5a69e9),_0x483b41['push'](_0x660ccf));}for(const _0x491ad2 of Object['keys'](this['localCache']))this['localCache'][_0x491ad2]&&!_0x38a265['has'](_0x491ad2)&&(this['notifyListeners'](_0x491ad2,null),_0x483b41['push'](_0x491ad2));return _0x483b41;}['notifyListeners'](_0x37ba60,_0x11b25f){this['localCache'][_0x37ba60]=_0x11b25f;const _0x522fe8=this['listeners'][_0x37ba60];if(_0x522fe8){for(const _0x5e7f28 of Array['from'](_0x522fe8))_0x5e7f28(_0x11b25f);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),lp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x323de9,_0x3419dc){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x323de9]||(this['listeners'][_0x323de9]=new Set(),this['_get'](_0x323de9)),this['listeners'][_0x323de9]['add'](_0x3419dc);}['_removeListener'](_0x17c7df,_0xa279ad){this['listeners'][_0x17c7df]&&(this['listeners'][_0x17c7df]['delete'](_0xa279ad),this['listeners'][_0x17c7df]['size']===0x0&&delete this['listeners'][_0x17c7df]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ka['type']='LOCAL';const up=Ka;new Kt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function dp(_0x3e6956,_0x4c61ce){return _0x4c61ce?ne(_0x4c61ce):(m(_0x3e6956['_popupRedirectResolver'],_0x3e6956,'argument-error'),_0x3e6956['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Rs extends Ts{constructor(_0x25b63e){super('custom','custom'),this['params']=_0x25b63e;}['_getIdTokenResponse'](_0x431f20){return Ze(_0x431f20,this['_buildIdpRequest']());}['_linkToIdToken'](_0x166e21,_0xd0714d){return Ze(_0x166e21,this['_buildIdpRequest'](_0xd0714d));}['_getReauthenticationResolver'](_0x1c430a){return Ze(_0x1c430a,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x5f2d23){const _0x63c8e4={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x5f2d23&&(_0x63c8e4['idToken']=_0x5f2d23),_0x63c8e4;}}function fp(_0x4992d2){return Ua(_0x4992d2['auth'],new Rs(_0x4992d2),_0x4992d2['bypassAuthState']);}function pp(_0x1fd389){const {auth:_0x24e9fb,user:_0x53dc29}=_0x1fd389;return m(_0x53dc29,_0x24e9fb,'internal-error'),jf(_0x53dc29,new Rs(_0x1fd389),_0x1fd389['bypassAuthState']);}async function _p(_0xa250c6){const {auth:_0x3848e6,user:_0x5bde8c}=_0xa250c6;return m(_0x5bde8c,_0x3848e6,'internal-error'),zf(_0x5bde8c,new Rs(_0xa250c6),_0xa250c6['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ya{constructor(_0x4b26bc,_0x4b9172,_0x43fe55,_0x2a4000,_0x11aa3e=!0x1){this['auth']=_0x4b26bc,this['resolver']=_0x43fe55,this['user']=_0x2a4000,this['bypassAuthState']=_0x11aa3e,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x4b9172)?_0x4b9172:[_0x4b9172];}['execute'](){return new Promise(async(_0xd9db1,_0x23b3ab)=>{this['pendingPromise']={'resolve':_0xd9db1,'reject':_0x23b3ab};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0xbf098c){this['reject'](_0xbf098c);}});}async['onAuthEvent'](_0x2c282a){const {urlResponse:_0x5ac163,sessionId:_0x59da9d,postBody:_0x148032,tenantId:_0x3a860d,error:_0x46241e,type:_0x3eb70a}=_0x2c282a;if(_0x46241e){this['reject'](_0x46241e);return;}const _0x2d0230={'auth':this['auth'],'requestUri':_0x5ac163,'sessionId':_0x59da9d,'tenantId':_0x3a860d||void 0x0,'postBody':_0x148032||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x3eb70a)(_0x2d0230));}catch(_0x2c683b){this['reject'](_0x2c683b);}}['onError'](_0x13bf7d){this['reject'](_0x13bf7d);}['getIdpTask'](_0x443386){switch(_0x443386){case'signInViaPopup':case'signInViaRedirect':return fp;case'linkViaPopup':case'linkViaRedirect':return _p;case'reauthViaPopup':case'reauthViaRedirect':return pp;default:K(this['auth'],'internal-error');}}['resolve'](_0x43ac18){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x43ac18),this['unregisterAndCleanUp']();}['reject'](_0x223044){ae(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x223044),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gp=new Kt(0x7d0,0x2710);class Ye extends Ya{constructor(_0x5d93c8,_0x13b4d3,_0x3bec57,_0x2475ae,_0x471637){super(_0x5d93c8,_0x13b4d3,_0x2475ae,_0x471637),this['provider']=_0x3bec57,this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']&&Ye['currentPopupAction']['cancel'](),Ye['currentPopupAction']=this;}async['executeNotNull'](){const _0x2ea5a1=await this['execute']();return m(_0x2ea5a1,this['auth'],'internal-error'),_0x2ea5a1;}async['onExecution'](){ae(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x44ae6a=bs();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x44ae6a),this['authWindow']['associatedEvent']=_0x44ae6a,this['resolver']['_originValidation'](this['auth'])['catch'](_0x374b1c=>{this['reject'](_0x374b1c);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x192dc0=>{_0x192dc0||this['reject'](J(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x36b7b9;return((_0x36b7b9=this['authWindow'])==null?void 0x0:_0x36b7b9['associatedEvent'])||null;}['cancel'](){this['reject'](J(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ye['currentPopupAction']=null;}['pollUserCancellation'](){const _0x2b5ffd=()=>{var _0x4e03f9,_0x43dffd;if((_0x43dffd=(_0x4e03f9=this['authWindow'])==null?void 0x0:_0x4e03f9['window'])!=null&&_0x43dffd['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](J(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x2b5ffd,gp['get']());};_0x2b5ffd();}}Ye['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const mp='pendingRedirect',rn=new Map();class yp extends Ya{constructor(_0x5ec8d9,_0x64f217,_0x38d38b=!0x1){super(_0x5ec8d9,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x64f217,void 0x0,_0x38d38b),this['eventId']=null;}async['execute'](){let _0x1512dc=rn['get'](this['auth']['_key']());if(!_0x1512dc){try{const _0x2a1b04=await vp(this['resolver'],this['auth'])?await super['execute']():null;_0x1512dc=()=>Promise['resolve'](_0x2a1b04);}catch(_0x582839){_0x1512dc=()=>Promise['reject'](_0x582839);}rn['set'](this['auth']['_key'](),_0x1512dc);}return this['bypassAuthState']||rn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x1512dc();}async['onAuthEvent'](_0x87840f){if(_0x87840f['type']==='signInViaRedirect')return super['onAuthEvent'](_0x87840f);if(_0x87840f['type']==='unknown'){this['resolve'](null);return;}if(_0x87840f['eventId']){const _0x3fd253=await this['auth']['_redirectUserForId'](_0x87840f['eventId']);if(_0x3fd253)return this['user']=_0x3fd253,super['onAuthEvent'](_0x87840f);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function vp(_0x2582af,_0x3ced3d){const _0x768b17=wp(_0x3ced3d),_0x22ef94=Ip(_0x2582af);if(!await _0x22ef94['_isAvailable']())return!0x1;const _0x3467e0=await _0x22ef94['_get'](_0x768b17)==='true';return await _0x22ef94['_remove'](_0x768b17),_0x3467e0;}function Ep(_0x5709fd,_0xcd885f){rn['set'](_0x5709fd['_key'](),_0xcd885f);}function Ip(_0x4d6dee){return ne(_0x4d6dee['_redirectPersistence']);}function wp(_0x37a546){return sn(mp,_0x37a546['config']['apiKey'],_0x37a546['name']);}async function Cp(_0x69ed05,_0x321fde,_0xbec2e4=!0x1){if(H(_0x69ed05['app']))return Promise['reject'](se(_0x69ed05));const _0x56d638=qe(_0x69ed05),_0x257dc7=dp(_0x56d638,_0x321fde),_0x3c549b=await new yp(_0x56d638,_0x257dc7,_0xbec2e4)['execute']();return _0x3c549b&&!_0xbec2e4&&(delete _0x3c549b['user']['_redirectEventId'],await _0x56d638['_persistUserIfCurrent'](_0x3c549b['user']),await _0x56d638['_setRedirectUser'](null,_0x321fde)),_0x3c549b;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=0x258*0x3e8;class Sp{constructor(_0x33e9b3){this['auth']=_0x33e9b3,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x203cf5){this['consumers']['add'](_0x203cf5),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x203cf5)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x203cf5),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x26fe9e){this['consumers']['delete'](_0x26fe9e);}['onEvent'](_0xa69ae7){if(this['hasEventBeenHandled'](_0xa69ae7))return!0x1;let _0x5af0ac=!0x1;return this['consumers']['forEach'](_0x33cd7e=>{this['isEventForConsumer'](_0xa69ae7,_0x33cd7e)&&(_0x5af0ac=!0x0,this['sendToConsumer'](_0xa69ae7,_0x33cd7e),this['saveEventToCache'](_0xa69ae7));}),this['hasHandledPotentialRedirect']||!bp(_0xa69ae7)||(this['hasHandledPotentialRedirect']=!0x0,_0x5af0ac||(this['queuedRedirectEvent']=_0xa69ae7,_0x5af0ac=!0x0)),_0x5af0ac;}['sendToConsumer'](_0x42c582,_0x5da3f0){var _0x350b13;if(_0x42c582['error']&&!Qa(_0x42c582)){const _0x3bd739=((_0x350b13=_0x42c582['error']['code'])==null?void 0x0:_0x350b13['split']('auth/')[0x1])||'internal-error';_0x5da3f0['onError'](J(this['auth'],_0x3bd739));}else _0x5da3f0['onAuthEvent'](_0x42c582);}['isEventForConsumer'](_0x4fb4d2,_0x50d989){const _0xf7409d=_0x50d989['eventId']===null||!!_0x4fb4d2['eventId']&&_0x4fb4d2['eventId']===_0x50d989['eventId'];return _0x50d989['filter']['includes'](_0x4fb4d2['type'])&&_0xf7409d;}['hasEventBeenHandled'](_0x2ec0a6){return Date['now']()-this['lastProcessedEventTime']>=Tp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Pr(_0x2ec0a6));}['saveEventToCache'](_0x4a458c){this['cachedEventUids']['add'](Pr(_0x4a458c)),this['lastProcessedEventTime']=Date['now']();}}function Pr(_0xcd8b54){return[_0xcd8b54['type'],_0xcd8b54['eventId'],_0xcd8b54['sessionId'],_0xcd8b54['tenantId']]['filter'](_0xb49976=>_0xb49976)['join']('-');}function Qa({type:_0x325dc6,error:_0xa3ed2d}){return _0x325dc6==='unknown'&&(_0xa3ed2d==null?void 0x0:_0xa3ed2d['code'])==='auth/no-auth-event';}function bp(_0x2a2001){switch(_0x2a2001['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Qa(_0x2a2001);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Rp(_0x112d13,_0x42317={}){return Ae(_0x112d13,'GET','/v1/projects',_0x42317);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ap=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,kp=/^https?/;async function Np(_0x22a513){if(_0x22a513['config']['emulator'])return;const {authorizedDomains:_0xa262a0}=await Rp(_0x22a513);for(const _0x1e7f91 of _0xa262a0)try{if(Pp(_0x1e7f91))return;}catch{}K(_0x22a513,'unauthorized-domain');}function Pp(_0x44692a){const _0x48f23d=Ni(),{protocol:_0x33420e,hostname:_0x582155}=new URL(_0x48f23d);if(_0x44692a['startsWith']('chrome-extension://')){const _0x890816=new URL(_0x44692a);return _0x890816['hostname']===''&&_0x582155===''?_0x33420e==='chrome-extension:'&&_0x44692a['replace']('chrome-extension://','')===_0x48f23d['replace']('chrome-extension://',''):_0x33420e==='chrome-extension:'&&_0x890816['hostname']===_0x582155;}if(!kp['test'](_0x33420e))return!0x1;if(Ap['test'](_0x44692a))return _0x582155===_0x44692a;const _0x21d853=_0x44692a['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x21d853+'|'+_0x21d853+')$','i')['test'](_0x582155);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=new Kt(0x7530,0xea60);function Or(){const _0x5a4ef8=X()['___jsl'];if(_0x5a4ef8!=null&&_0x5a4ef8['H']){for(const _0x1108d2 of Object['keys'](_0x5a4ef8['H']))if(_0x5a4ef8['H'][_0x1108d2]['r']=_0x5a4ef8['H'][_0x1108d2]['r']||[],_0x5a4ef8['H'][_0x1108d2]['L']=_0x5a4ef8['H'][_0x1108d2]['L']||[],_0x5a4ef8['H'][_0x1108d2]['r']=[..._0x5a4ef8['H'][_0x1108d2]['L']],_0x5a4ef8['CP']){for(let _0x20d430=0x0;_0x20d430<_0x5a4ef8['CP']['length'];_0x20d430++)_0x5a4ef8['CP'][_0x20d430]=null;}}}function Dp(_0x50b291){return new Promise((_0x2e16ba,_0x134d9e)=>{var _0x1b24c9,_0x5f0215,_0x29675f;function _0x3b40ae(){Or(),gapi['load']('gapi.iframes',{'callback':()=>{_0x2e16ba(gapi['iframes']['getContext']());},'ontimeout':()=>{Or(),_0x134d9e(J(_0x50b291,'network-request-failed'));},'timeout':Op['get']()});}if((_0x5f0215=(_0x1b24c9=X()['gapi'])==null?void 0x0:_0x1b24c9['iframes'])!=null&&_0x5f0215['Iframe'])_0x2e16ba(gapi['iframes']['getContext']());else{if((_0x29675f=X()['gapi'])!=null&&_0x29675f['load'])_0x3b40ae();else{const _0x25e13e=kf('iframefcb');return X()[_0x25e13e]=()=>{gapi['load']?_0x3b40ae():_0x134d9e(J(_0x50b291,'network-request-failed'));},Da(Af()+'?onload='+_0x25e13e)['catch'](_0x38063c=>_0x134d9e(_0x38063c));}}})['catch'](_0x4b0c1f=>{throw on=null,_0x4b0c1f;});}let on=null;function Mp(_0x1b1791){return on=on||Dp(_0x1b1791),on;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Lp=new Kt(0x1388,0x3a98),xp='__/auth/iframe',Fp='emulator/auth/iframe',Up={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Wp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Bp(_0x4347e7){const _0xcbc12d=_0x4347e7['config'];m(_0xcbc12d['authDomain'],_0x4347e7,'auth-domain-config-required');const _0x30d594=_0xcbc12d['emulator']?Is(_0xcbc12d,Fp):'https://'+_0x4347e7['config']['authDomain']+'/'+xp,_0x34e3f7={'apiKey':_0xcbc12d['apiKey'],'appName':_0x4347e7['name'],'v':ct},_0x25f2d7=Wp['get'](_0x4347e7['config']['apiHost']);_0x25f2d7&&(_0x34e3f7['eid']=_0x25f2d7);const _0x103625=_0x4347e7['_getFrameworks']();return _0x103625['length']&&(_0x34e3f7['fw']=_0x103625['join'](',')),_0x30d594+'?'+at(_0x34e3f7)['slice'](0x1);}async function Vp(_0x1c0a08){const _0x401386=await Mp(_0x1c0a08),_0x2a5b9f=X()['gapi'];return m(_0x2a5b9f,_0x1c0a08,'internal-error'),_0x401386['open']({'where':document['body'],'url':Bp(_0x1c0a08),'messageHandlersFilter':_0x2a5b9f['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':Up,'dontclear':!0x0},_0x143b41=>new Promise(async(_0x24b35b,_0x87d9b8)=>{await _0x143b41['restyle']({'setHideOnLeave':!0x1});const _0x376a38=J(_0x1c0a08,'network-request-failed'),_0x5f347a=X()['setTimeout'](()=>{_0x87d9b8(_0x376a38);},Lp['get']());function _0x43575c(){X()['clearTimeout'](_0x5f347a),_0x24b35b(_0x143b41);}_0x143b41['ping'](_0x43575c)['then'](_0x43575c,()=>{_0x87d9b8(_0x376a38);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Hp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},$p=0x1f4,Gp=0x258,qp='_blank',zp='http://localhost';class Dr{constructor(_0x4319bf){this['window']=_0x4319bf,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function jp(_0x20a153,_0xe6714b,_0x4f460f,_0x5438ad=$p,_0x58c17a=Gp){const _0x589e8f=Math['max']((window['screen']['availHeight']-_0x58c17a)/0x2,0x0)['toString'](),_0x37bdae=Math['max']((window['screen']['availWidth']-_0x5438ad)/0x2,0x0)['toString']();let _0x5bef01='';const _0x1e6ccb={...Hp,'width':_0x5438ad['toString'](),'height':_0x58c17a['toString'](),'top':_0x589e8f,'left':_0x37bdae},_0x280ea6=W()['toLowerCase']();_0x4f460f&&(_0x5bef01=ba(_0x280ea6)?qp:_0x4f460f),Ta(_0x280ea6)&&(_0xe6714b=_0xe6714b||zp,_0x1e6ccb['scrollbars']='yes');const _0x5371d6=Object['entries'](_0x1e6ccb)['reduce']((_0x4334b9,[_0x54ccf0,_0x33b988])=>''+_0x4334b9+_0x54ccf0+'='+_0x33b988+',','');if(vf(_0x280ea6)&&_0x5bef01!=='_self')return Kp(_0xe6714b||'',_0x5bef01),new Dr(null);const _0x4eb255=window['open'](_0xe6714b||'',_0x5bef01,_0x5371d6);m(_0x4eb255,_0x20a153,'popup-blocked');try{_0x4eb255['focus']();}catch{}return new Dr(_0x4eb255);}function Kp(_0x21cc37,_0x4ca9b3){const _0xa1ee3b=document['createElement']('a');_0xa1ee3b['href']=_0x21cc37,_0xa1ee3b['target']=_0x4ca9b3;const _0x1b73b2=document['createEvent']('MouseEvent');_0x1b73b2['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0xa1ee3b['dispatchEvent'](_0x1b73b2);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yp='__/auth/handler',Qp='emulator/auth/handler',Jp=encodeURIComponent('fac');async function Mr(_0x2904d5,_0x55dd78,_0x4e214a,_0x561220,_0x2c576a,_0x220375){m(_0x2904d5['config']['authDomain'],_0x2904d5,'auth-domain-config-required'),m(_0x2904d5['config']['apiKey'],_0x2904d5,'invalid-api-key');const _0x249b71={'apiKey':_0x2904d5['config']['apiKey'],'appName':_0x2904d5['name'],'authType':_0x4e214a,'redirectUrl':_0x561220,'v':ct,'eventId':_0x2c576a};if(_0x55dd78 instanceof xa){_0x55dd78['setDefaultLanguage'](_0x2904d5['languageCode']),_0x249b71['providerId']=_0x55dd78['providerId']||'',hi(_0x55dd78['getCustomParameters']())||(_0x249b71['customParameters']=JSON['stringify'](_0x55dd78['getCustomParameters']()));for(const [_0x455edd,_0x292d80]of Object['entries']({}))_0x249b71[_0x455edd]=_0x292d80;}if(_0x55dd78 instanceof Qt){const _0x3c0c03=_0x55dd78['getScopes']()['filter'](_0x451106=>_0x451106!=='');_0x3c0c03['length']>0x0&&(_0x249b71['scopes']=_0x3c0c03['join'](','));}_0x2904d5['tenantId']&&(_0x249b71['tid']=_0x2904d5['tenantId']);const _0x388a45=_0x249b71;for(const _0x27cba3 of Object['keys'](_0x388a45))_0x388a45[_0x27cba3]===void 0x0&&delete _0x388a45[_0x27cba3];const _0x331a99=await _0x2904d5['_getAppCheckToken'](),_0x16a0f7=_0x331a99?'#'+Jp+'='+encodeURIComponent(_0x331a99):'';return Xp(_0x2904d5)+'?'+at(_0x388a45)['slice'](0x1)+_0x16a0f7;}function Xp({config:_0x7ccc5c}){return _0x7ccc5c['emulator']?Is(_0x7ccc5c,Qp):'https://'+_0x7ccc5c['authDomain']+'/'+Yp;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const li='webStorageSupport';class Zp{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=$a,this['_completeRedirectFn']=Cp,this['_overrideRedirectResult']=Ep;}async['_openPopup'](_0x5b6920,_0xeb6a3a,_0x1668d0,_0x54db6a){var _0x55d584;ae((_0x55d584=this['eventManagers'][_0x5b6920['_key']()])==null?void 0x0:_0x55d584['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x1aed64=await Mr(_0x5b6920,_0xeb6a3a,_0x1668d0,Ni(),_0x54db6a);return jp(_0x5b6920,_0x1aed64,bs());}async['_openRedirect'](_0x149535,_0x4bd17a,_0x42a6fe,_0x842cdb){await this['_originValidation'](_0x149535);const _0x5cc2e4=await Mr(_0x149535,_0x4bd17a,_0x42a6fe,Ni(),_0x842cdb);return np(_0x5cc2e4),new Promise(()=>{});}['_initialize'](_0x2617d9){const _0x27d689=_0x2617d9['_key']();if(this['eventManagers'][_0x27d689]){const {manager:_0xb6ecbf,promise:_0x5875d1}=this['eventManagers'][_0x27d689];return _0xb6ecbf?Promise['resolve'](_0xb6ecbf):(ae(_0x5875d1,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x5875d1);}const _0x55e7a8=this['initAndGetManager'](_0x2617d9);return this['eventManagers'][_0x27d689]={'promise':_0x55e7a8},_0x55e7a8['catch'](()=>{delete this['eventManagers'][_0x27d689];}),_0x55e7a8;}async['initAndGetManager'](_0x4502d6){const _0x1f2cfe=await Vp(_0x4502d6),_0x4a7e3c=new Sp(_0x4502d6);return _0x1f2cfe['register']('authEvent',_0x48152d=>(m(_0x48152d==null?void 0x0:_0x48152d['authEvent'],_0x4502d6,'invalid-auth-event'),{'status':_0x4a7e3c['onEvent'](_0x48152d['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x4502d6['_key']()]={'manager':_0x4a7e3c},this['iframes'][_0x4502d6['_key']()]=_0x1f2cfe,_0x4a7e3c;}['_isIframeWebStorageSupported'](_0x413998,_0x4ff3db){this['iframes'][_0x413998['_key']()]['send'](li,{'type':li},_0x5b2dde=>{var _0x5b1523;const _0x56f2c3=(_0x5b1523=_0x5b2dde==null?void 0x0:_0x5b2dde[0x0])==null?void 0x0:_0x5b1523[li];_0x56f2c3!==void 0x0&&_0x4ff3db(!!_0x56f2c3),K(_0x413998,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x440e61){const _0x3a954d=_0x440e61['_key']();return this['originValidationPromises'][_0x3a954d]||(this['originValidationPromises'][_0x3a954d]=Np(_0x440e61)),this['originValidationPromises'][_0x3a954d];}get['_shouldInitProactively'](){return Pa()||Sa()||Cs();}}const e_=Zp;var Lr='@firebase/auth',xr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class t_{constructor(_0x3139f7){this['auth']=_0x3139f7,this['internalListeners']=new Map();}['getUid'](){var _0x3f59c0;return this['assertAuthConfigured'](),((_0x3f59c0=this['auth']['currentUser'])==null?void 0x0:_0x3f59c0['uid'])||null;}async['getToken'](_0xc2c1be){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0xc2c1be)}:null;}['addAuthTokenListener'](_0x5d881b){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x5d881b))return;const _0x2aa3cb=this['auth']['onIdTokenChanged'](_0x3a6f2a=>{_0x5d881b((_0x3a6f2a==null?void 0x0:_0x3a6f2a['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x5d881b,_0x2aa3cb),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x1d8bc6){this['assertAuthConfigured']();const _0x6b8f5f=this['internalListeners']['get'](_0x1d8bc6);_0x6b8f5f&&(this['internalListeners']['delete'](_0x1d8bc6),_0x6b8f5f(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function n_(_0x4dcdc8){switch(_0x4dcdc8){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function i_(_0x590bf0){et(new Me('auth',(_0x11e147,{options:_0x1e17db})=>{const _0x5ad01d=_0x11e147['getProvider']('app')['getImmediate'](),_0x38da4b=_0x11e147['getProvider']('heartbeat'),_0x5ecc2c=_0x11e147['getProvider']('app-check-internal'),{apiKey:_0x23b4ff,authDomain:_0x3369b9}=_0x5ad01d['options'];m(_0x23b4ff&&!_0x23b4ff['includes'](':'),'invalid-api-key',{'appName':_0x5ad01d['name']});const _0x1afc23={'apiKey':_0x23b4ff,'authDomain':_0x3369b9,'clientPlatform':_0x590bf0,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':Oa(_0x590bf0)},_0x1679f8=new Sf(_0x5ad01d,_0x38da4b,_0x5ecc2c,_0x1afc23);return Mf(_0x1679f8,_0x1e17db),_0x1679f8;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x427b49,_0x29edb9,_0x517aa1)=>{_0x427b49['getProvider']('auth-internal')['initialize']();})),et(new Me('auth-internal',_0x56ab1c=>{const _0x2da58d=qe(_0x56ab1c['getProvider']('auth')['getImmediate']());return(_0x33b3c8=>new t_(_0x33b3c8))(_0x2da58d);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Lr,xr,n_(_0x590bf0)),me(Lr,xr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const s_=0x12c,r_=Gr('authIdTokenMaxAge')||s_;let Fr=null;const o_=_0x11d741=>async _0x5df887=>{const _0x23a690=_0x5df887&&await _0x5df887['getIdTokenResult'](),_0x43fba9=_0x23a690&&(new Date()['getTime']()-Date['parse'](_0x23a690['issuedAtTime']))/0x3e8;if(_0x43fba9&&_0x43fba9>r_)return;const _0x106b80=_0x23a690==null?void 0x0:_0x23a690['token'];Fr!==_0x106b80&&(Fr=_0x106b80,await fetch(_0x11d741,{'method':_0x106b80?'POST':'DELETE','headers':_0x106b80?{'Authorization':'Bearer\x20'+_0x106b80}:{}}));};function N_(_0x4b5bac=Qr()){const _0x4bf2d9=Ui(_0x4b5bac,'auth');if(_0x4bf2d9['isInitialized']())return _0x4bf2d9['getImmediate']();const _0x13430e=Df(_0x4b5bac,{'popupRedirectResolver':e_,'persistence':[up,Zf,$a]}),_0x1205ae=Gr('authTokenSyncURL');if(_0x1205ae&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x39b573=new URL(_0x1205ae,location['origin']);if(location['origin']===_0x39b573['origin']){const _0x1a8ebe=o_(_0x39b573['toString']());Qf(_0x13430e,_0x1a8ebe,()=>_0x1a8ebe(_0x13430e['currentUser'])),Yf(_0x13430e,_0x1f8f9d=>_0x1a8ebe(_0x1f8f9d));}}const _0x3f13bf=Hr('auth');return _0x3f13bf&&Lf(_0x13430e,'http://'+_0x3f13bf),_0x13430e;}function a_(){var _0x275cf5;return((_0x275cf5=document['getElementsByTagName']('head'))==null?void 0x0:_0x275cf5[0x0])??document;}bf({'loadJS'(_0x252f3d){return new Promise((_0x22707a,_0x51246b)=>{const _0x4aeb53=document['createElement']('script');_0x4aeb53['setAttribute']('src',_0x252f3d),_0x4aeb53['onload']=_0x22707a,_0x4aeb53['onerror']=_0x196a4c=>{const _0x21adf4=J('internal-error');_0x21adf4['customData']=_0x196a4c,_0x51246b(_0x21adf4);},_0x4aeb53['type']='text/javascript',_0x4aeb53['charset']='UTF-8',a_()['appendChild'](_0x4aeb53);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),i_('Browser');export{k_ as A,y_ as B,N_ as a,Zf as b,b_ as c,c_ as d,l_ as e,Qr as f,I_ as g,f_ as h,wl as i,v_ as j,Lt as k,Ld as l,A_ as m,C_ as n,m_ as o,u_ as p,E_ as q,h_ as r,R_ as s,w_ as t,d_ as u,T_ as v,__ as w,p_ as x,g_ as y,S_ as z};