const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0xad0be7,_0x2390c8){if(!_0xad0be7)throw ht(_0x2390c8);},ht=function(_0x372e18){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x372e18);},Hr=function(_0x445790){const _0x2ee802=[];let _0x43abec=0x0;for(let _0x3ba0e2=0x0;_0x3ba0e2<_0x445790['length'];_0x3ba0e2++){let _0x474bc0=_0x445790['charCodeAt'](_0x3ba0e2);_0x474bc0<0x80?_0x2ee802[_0x43abec++]=_0x474bc0:_0x474bc0<0x800?(_0x2ee802[_0x43abec++]=_0x474bc0>>0x6|0xc0,_0x2ee802[_0x43abec++]=_0x474bc0&0x3f|0x80):(_0x474bc0&0xfc00)===0xd800&&_0x3ba0e2+0x1<_0x445790['length']&&(_0x445790['charCodeAt'](_0x3ba0e2+0x1)&0xfc00)===0xdc00?(_0x474bc0=0x10000+((_0x474bc0&0x3ff)<<0xa)+(_0x445790['charCodeAt'](++_0x3ba0e2)&0x3ff),_0x2ee802[_0x43abec++]=_0x474bc0>>0x12|0xf0,_0x2ee802[_0x43abec++]=_0x474bc0>>0xc&0x3f|0x80,_0x2ee802[_0x43abec++]=_0x474bc0>>0x6&0x3f|0x80,_0x2ee802[_0x43abec++]=_0x474bc0&0x3f|0x80):(_0x2ee802[_0x43abec++]=_0x474bc0>>0xc|0xe0,_0x2ee802[_0x43abec++]=_0x474bc0>>0x6&0x3f|0x80,_0x2ee802[_0x43abec++]=_0x474bc0&0x3f|0x80);}return _0x2ee802;},nc=function(_0x54c905){const _0x2975e7=[];let _0x4e0b0a=0x0,_0x27cf87=0x0;for(;_0x4e0b0a<_0x54c905['length'];){const _0x53ac91=_0x54c905[_0x4e0b0a++];if(_0x53ac91<0x80)_0x2975e7[_0x27cf87++]=String['fromCharCode'](_0x53ac91);else{if(_0x53ac91>0xbf&&_0x53ac91<0xe0){const _0x534d28=_0x54c905[_0x4e0b0a++];_0x2975e7[_0x27cf87++]=String['fromCharCode']((_0x53ac91&0x1f)<<0x6|_0x534d28&0x3f);}else{if(_0x53ac91>0xef&&_0x53ac91<0x16d){const _0x54a553=_0x54c905[_0x4e0b0a++],_0x30463c=_0x54c905[_0x4e0b0a++],_0x55a26a=_0x54c905[_0x4e0b0a++],_0x1680eb=((_0x53ac91&0x7)<<0x12|(_0x54a553&0x3f)<<0xc|(_0x30463c&0x3f)<<0x6|_0x55a26a&0x3f)-0x10000;_0x2975e7[_0x27cf87++]=String['fromCharCode'](0xd800+(_0x1680eb>>0xa)),_0x2975e7[_0x27cf87++]=String['fromCharCode'](0xdc00+(_0x1680eb&0x3ff));}else{const _0x28a1e8=_0x54c905[_0x4e0b0a++],_0x114eba=_0x54c905[_0x4e0b0a++];_0x2975e7[_0x27cf87++]=String['fromCharCode']((_0x53ac91&0xf)<<0xc|(_0x28a1e8&0x3f)<<0x6|_0x114eba&0x3f);}}}}return _0x2975e7['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x2a52e2,_0x543b5b){if(!Array['isArray'](_0x2a52e2))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x10f7f6=_0x543b5b?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x16deb7=[];for(let _0xe5585f=0x0;_0xe5585f<_0x2a52e2['length'];_0xe5585f+=0x3){const _0x5ef1c9=_0x2a52e2[_0xe5585f],_0x50d93b=_0xe5585f+0x1<_0x2a52e2['length'],_0x4c7f7f=_0x50d93b?_0x2a52e2[_0xe5585f+0x1]:0x0,_0x436729=_0xe5585f+0x2<_0x2a52e2['length'],_0x1b0c86=_0x436729?_0x2a52e2[_0xe5585f+0x2]:0x0,_0x46dd4e=_0x5ef1c9>>0x2,_0x59cdc0=(_0x5ef1c9&0x3)<<0x4|_0x4c7f7f>>0x4;let _0x3c0333=(_0x4c7f7f&0xf)<<0x2|_0x1b0c86>>0x6,_0x4bc6b3=_0x1b0c86&0x3f;_0x436729||(_0x4bc6b3=0x40,_0x50d93b||(_0x3c0333=0x40)),_0x16deb7['push'](_0x10f7f6[_0x46dd4e],_0x10f7f6[_0x59cdc0],_0x10f7f6[_0x3c0333],_0x10f7f6[_0x4bc6b3]);}return _0x16deb7['join']('');},'encodeString'(_0x4431dd,_0x5769bf){return this['HAS_NATIVE_SUPPORT']&&!_0x5769bf?btoa(_0x4431dd):this['encodeByteArray'](Hr(_0x4431dd),_0x5769bf);},'decodeString'(_0x1f82de,_0x20923f){return this['HAS_NATIVE_SUPPORT']&&!_0x20923f?atob(_0x1f82de):nc(this['decodeStringToByteArray'](_0x1f82de,_0x20923f));},'decodeStringToByteArray'(_0x209cab,_0x10e986){this['init_']();const _0x4808c8=_0x10e986?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0xd776f5=[];for(let _0x3daa3b=0x0;_0x3daa3b<_0x209cab['length'];){const _0x5b8edd=_0x4808c8[_0x209cab['charAt'](_0x3daa3b++)],_0x3e6287=_0x3daa3b<_0x209cab['length']?_0x4808c8[_0x209cab['charAt'](_0x3daa3b)]:0x0;++_0x3daa3b;const _0x4cec5a=_0x3daa3b<_0x209cab['length']?_0x4808c8[_0x209cab['charAt'](_0x3daa3b)]:0x40;++_0x3daa3b;const _0x15b9c8=_0x3daa3b<_0x209cab['length']?_0x4808c8[_0x209cab['charAt'](_0x3daa3b)]:0x40;if(++_0x3daa3b,_0x5b8edd==null||_0x3e6287==null||_0x4cec5a==null||_0x15b9c8==null)throw new ic();const _0x3a57db=_0x5b8edd<<0x2|_0x3e6287>>0x4;if(_0xd776f5['push'](_0x3a57db),_0x4cec5a!==0x40){const _0x11db18=_0x3e6287<<0x4&0xf0|_0x4cec5a>>0x2;if(_0xd776f5['push'](_0x11db18),_0x15b9c8!==0x40){const _0x55edda=_0x4cec5a<<0x6&0xc0|_0x15b9c8;_0xd776f5['push'](_0x55edda);}}}return _0xd776f5;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x476fd1=0x0;_0x476fd1<this['ENCODED_VALS']['length'];_0x476fd1++)this['byteToCharMap_'][_0x476fd1]=this['ENCODED_VALS']['charAt'](_0x476fd1),this['charToByteMap_'][this['byteToCharMap_'][_0x476fd1]]=_0x476fd1,this['byteToCharMapWebSafe_'][_0x476fd1]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x476fd1),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x476fd1]]=_0x476fd1,_0x476fd1>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x476fd1)]=_0x476fd1,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x476fd1)]=_0x476fd1);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x4416d6){const _0x30ebc2=Hr(_0x4416d6);return Fi['encodeByteArray'](_0x30ebc2,!0x0);},dn=function(_0x4f8993){return $r(_0x4f8993)['replace'](/\./g,'');},fn=function(_0x17360c){try{return Fi['decodeString'](_0x17360c,!0x0);}catch(_0x2aaffb){console['error']('base64Decode\x20failed:\x20',_0x2aaffb);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x3e763b){return Gr(void 0x0,_0x3e763b);}function Gr(_0x32baf7,_0x37e141){if(!(_0x37e141 instanceof Object))return _0x37e141;switch(_0x37e141['constructor']){case Date:const _0x3ce260=_0x37e141;return new Date(_0x3ce260['getTime']());case Object:_0x32baf7===void 0x0&&(_0x32baf7={});break;case Array:_0x32baf7=[];break;default:return _0x37e141;}for(const _0x1f9b38 in _0x37e141)!_0x37e141['hasOwnProperty'](_0x1f9b38)||!rc(_0x1f9b38)||(_0x32baf7[_0x1f9b38]=Gr(_0x32baf7[_0x1f9b38],_0x37e141[_0x1f9b38]));return _0x32baf7;}function rc(_0x2f3aeb){return _0x2f3aeb!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x55427d=Ps['__FIREBASE_DEFAULTS__'];if(_0x55427d)return JSON['parse'](_0x55427d);},lc=()=>{if(typeof document>'u')return;let _0x335d9c;try{_0x335d9c=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x44accb=_0x335d9c&&fn(_0x335d9c[0x1]);return _0x44accb&&JSON['parse'](_0x44accb);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x1d0de9){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x1d0de9);return;}},qr=_0x1fe207=>{var _0x41f3e3,_0x9dd01a;return(_0x9dd01a=(_0x41f3e3=Ui())==null?void 0x0:_0x41f3e3['emulatorHosts'])==null?void 0x0:_0x9dd01a[_0x1fe207];},hc=_0x2ed754=>{const _0xfedb09=qr(_0x2ed754);if(!_0xfedb09)return;const _0x7ebadb=_0xfedb09['lastIndexOf'](':');if(_0x7ebadb<=0x0||_0x7ebadb+0x1===_0xfedb09['length'])throw new Error('Invalid\x20host\x20'+_0xfedb09+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x1d1976=parseInt(_0xfedb09['substring'](_0x7ebadb+0x1),0xa);return _0xfedb09[0x0]==='['?[_0xfedb09['substring'](0x1,_0x7ebadb-0x1),_0x1d1976]:[_0xfedb09['substring'](0x0,_0x7ebadb),_0x1d1976];},zr=()=>{var _0x1c8f17;return(_0x1c8f17=Ui())==null?void 0x0:_0x1c8f17['config'];},jr=_0x22bfb7=>{var _0xd84b9c;return(_0xd84b9c=Ui())==null?void 0x0:_0xd84b9c['_'+_0x22bfb7];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x52fda3,_0xfe1bca)=>{this['resolve']=_0x52fda3,this['reject']=_0xfe1bca;});}['wrapCallback'](_0x597bec){return(_0x1f8bb0,_0x4685e0)=>{_0x1f8bb0?this['reject'](_0x1f8bb0):this['resolve'](_0x4685e0),typeof _0x597bec=='function'&&(this['promise']['catch'](()=>{}),_0x597bec['length']===0x1?_0x597bec(_0x1f8bb0):_0x597bec(_0x1f8bb0,_0x4685e0));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x2690c7,_0x297532){if(_0x2690c7['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x718e9f={'alg':'none','type':'JWT'},_0x1459b1=_0x297532||'demo-project',_0x3c63c9=_0x2690c7['iat']||0x0,_0x4f0611=_0x2690c7['sub']||_0x2690c7['user_id'];if(!_0x4f0611)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x14c2b4={'iss':'https://securetoken.google.com/'+_0x1459b1,'aud':_0x1459b1,'iat':_0x3c63c9,'exp':_0x3c63c9+0xe10,'auth_time':_0x3c63c9,'sub':_0x4f0611,'user_id':_0x4f0611,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x2690c7};return[dn(JSON['stringify'](_0x718e9f)),dn(JSON['stringify'](_0x14c2b4)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x15511d=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x15511d=='object'&&_0x15511d['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x58eecd=W();return _0x58eecd['indexOf']('MSIE\x20')>=0x0||_0x58eecd['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x164d24,_0x1d5b87)=>{try{let _0x53f6bd=!0x0;const _0x557aec='validate-browser-context-for-indexeddb-analytics-module',_0x28934d=self['indexedDB']['open'](_0x557aec);_0x28934d['onsuccess']=()=>{_0x28934d['result']['close'](),_0x53f6bd||self['indexedDB']['deleteDatabase'](_0x557aec),_0x164d24(!0x0);},_0x28934d['onupgradeneeded']=()=>{_0x53f6bd=!0x1;},_0x28934d['onerror']=()=>{var _0x463b7b;_0x1d5b87(((_0x463b7b=_0x28934d['error'])==null?void 0x0:_0x463b7b['message'])||'');};}catch(_0x5d98a3){_0x1d5b87(_0x5d98a3);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x57b24c,_0x16626a,_0x394dcc){super(_0x16626a),this['code']=_0x57b24c,this['customData']=_0x394dcc,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x4ee5fe,_0x2f2366,_0x4edffe){this['service']=_0x4ee5fe,this['serviceName']=_0x2f2366,this['errors']=_0x4edffe;}['create'](_0x2b6aa0,..._0x2f30c2){const _0x4f5bbc=_0x2f30c2[0x0]||{},_0x235fea=this['service']+'/'+_0x2b6aa0,_0x509cd4=this['errors'][_0x2b6aa0],_0x2eca7f=_0x509cd4?vc(_0x509cd4,_0x4f5bbc):'Error',_0x1da240=this['serviceName']+':\x20'+_0x2eca7f+'\x20('+_0x235fea+').';return new Re(_0x235fea,_0x1da240,_0x4f5bbc);}}function vc(_0x41476f,_0x3d85b4){return _0x41476f['replace'](Ec,(_0x3b9aa6,_0x3d513d)=>{const _0x331dba=_0x3d85b4[_0x3d513d];return _0x331dba!=null?String(_0x331dba):'<'+_0x3d513d+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x516512){return JSON['parse'](_0x516512);}function O(_0x62aa8c){return JSON['stringify'](_0x62aa8c);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x3d4806){let _0x5b5a90={},_0x257a11={},_0x42c915={},_0x5b5bdf='';try{const _0x2cbeda=_0x3d4806['split']('.');_0x5b5a90=Nt(fn(_0x2cbeda[0x0])||''),_0x257a11=Nt(fn(_0x2cbeda[0x1])||''),_0x5b5bdf=_0x2cbeda[0x2],_0x42c915=_0x257a11['d']||{},delete _0x257a11['d'];}catch{}return{'header':_0x5b5a90,'claims':_0x257a11,'data':_0x42c915,'signature':_0x5b5bdf};},Ic=function(_0x239a5a){const _0x48078f=Yr(_0x239a5a),_0x1d4c51=_0x48078f['claims'];return!!_0x1d4c51&&typeof _0x1d4c51=='object'&&_0x1d4c51['hasOwnProperty']('iat');},wc=function(_0x4b9437){const _0x4b9951=Yr(_0x4b9437)['claims'];return typeof _0x4b9951=='object'&&_0x4b9951['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x4c6438,_0x3aad63){return Object['prototype']['hasOwnProperty']['call'](_0x4c6438,_0x3aad63);}function Le(_0x1b95a5,_0x4eb5d4){if(Object['prototype']['hasOwnProperty']['call'](_0x1b95a5,_0x4eb5d4))return _0x1b95a5[_0x4eb5d4];}function pn(_0x4cc2b5){for(const _0x4f20fa in _0x4cc2b5)if(Object['prototype']['hasOwnProperty']['call'](_0x4cc2b5,_0x4f20fa))return!0x1;return!0x0;}function _n(_0x412718,_0x26fe2b,_0x132271){const _0x131791={};for(const _0x2212be in _0x412718)Object['prototype']['hasOwnProperty']['call'](_0x412718,_0x2212be)&&(_0x131791[_0x2212be]=_0x26fe2b['call'](_0x132271,_0x412718[_0x2212be],_0x2212be,_0x412718));return _0x131791;}function xe(_0x24388e,_0x437e7f){if(_0x24388e===_0x437e7f)return!0x0;const _0x1b27f8=Object['keys'](_0x24388e),_0x49d4ca=Object['keys'](_0x437e7f);for(const _0x51d1ad of _0x1b27f8){if(!_0x49d4ca['includes'](_0x51d1ad))return!0x1;const _0x16e32b=_0x24388e[_0x51d1ad],_0x3a8e1b=_0x437e7f[_0x51d1ad];if(Ns(_0x16e32b)&&Ns(_0x3a8e1b)){if(!xe(_0x16e32b,_0x3a8e1b))return!0x1;}else{if(_0x16e32b!==_0x3a8e1b)return!0x1;}}for(const _0xe7c465 of _0x49d4ca)if(!_0x1b27f8['includes'](_0xe7c465))return!0x1;return!0x0;}function Ns(_0x4c30fb){return _0x4c30fb!==null&&typeof _0x4c30fb=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x8d2996){const _0x412c7c=[];for(const [_0x552bff,_0x2862bd]of Object['entries'](_0x8d2996))Array['isArray'](_0x2862bd)?_0x2862bd['forEach'](_0x4f3c66=>{_0x412c7c['push'](encodeURIComponent(_0x552bff)+'='+encodeURIComponent(_0x4f3c66));}):_0x412c7c['push'](encodeURIComponent(_0x552bff)+'='+encodeURIComponent(_0x2862bd));return _0x412c7c['length']?'&'+_0x412c7c['join']('&'):'';}function Ct(_0x5de62b){const _0x32ee3a={};return _0x5de62b['replace'](/^\?/,'')['split']('&')['forEach'](_0x54a577=>{if(_0x54a577){const [_0x163bf8,_0x591245]=_0x54a577['split']('=');_0x32ee3a[decodeURIComponent(_0x163bf8)]=decodeURIComponent(_0x591245);}}),_0x32ee3a;}function Tt(_0x2d22da){const _0x33950a=_0x2d22da['indexOf']('?');if(!_0x33950a)return'';const _0x3aec86=_0x2d22da['indexOf']('#',_0x33950a);return _0x2d22da['substring'](_0x33950a,_0x3aec86>0x0?_0x3aec86:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x19790c=0x1;_0x19790c<this['blockSize'];++_0x19790c)this['pad_'][_0x19790c]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x42757e,_0x28b00f){_0x28b00f||(_0x28b00f=0x0);const _0x1836ba=this['W_'];if(typeof _0x42757e=='string'){for(let _0x51f091=0x0;_0x51f091<0x10;_0x51f091++)_0x1836ba[_0x51f091]=_0x42757e['charCodeAt'](_0x28b00f)<<0x18|_0x42757e['charCodeAt'](_0x28b00f+0x1)<<0x10|_0x42757e['charCodeAt'](_0x28b00f+0x2)<<0x8|_0x42757e['charCodeAt'](_0x28b00f+0x3),_0x28b00f+=0x4;}else{for(let _0x27f44f=0x0;_0x27f44f<0x10;_0x27f44f++)_0x1836ba[_0x27f44f]=_0x42757e[_0x28b00f]<<0x18|_0x42757e[_0x28b00f+0x1]<<0x10|_0x42757e[_0x28b00f+0x2]<<0x8|_0x42757e[_0x28b00f+0x3],_0x28b00f+=0x4;}for(let _0x3a5495=0x10;_0x3a5495<0x50;_0x3a5495++){const _0x17b5c3=_0x1836ba[_0x3a5495-0x3]^_0x1836ba[_0x3a5495-0x8]^_0x1836ba[_0x3a5495-0xe]^_0x1836ba[_0x3a5495-0x10];_0x1836ba[_0x3a5495]=(_0x17b5c3<<0x1|_0x17b5c3>>>0x1f)&0xffffffff;}let _0x4b568e=this['chain_'][0x0],_0x3eb537=this['chain_'][0x1],_0x55977b=this['chain_'][0x2],_0x2d15cc=this['chain_'][0x3],_0x12fa26=this['chain_'][0x4],_0x3edfbe,_0x561b19;for(let _0x503a2b=0x0;_0x503a2b<0x50;_0x503a2b++){_0x503a2b<0x28?_0x503a2b<0x14?(_0x3edfbe=_0x2d15cc^_0x3eb537&(_0x55977b^_0x2d15cc),_0x561b19=0x5a827999):(_0x3edfbe=_0x3eb537^_0x55977b^_0x2d15cc,_0x561b19=0x6ed9eba1):_0x503a2b<0x3c?(_0x3edfbe=_0x3eb537&_0x55977b|_0x2d15cc&(_0x3eb537|_0x55977b),_0x561b19=0x8f1bbcdc):(_0x3edfbe=_0x3eb537^_0x55977b^_0x2d15cc,_0x561b19=0xca62c1d6);const _0x22c0bd=(_0x4b568e<<0x5|_0x4b568e>>>0x1b)+_0x3edfbe+_0x12fa26+_0x561b19+_0x1836ba[_0x503a2b]&0xffffffff;_0x12fa26=_0x2d15cc,_0x2d15cc=_0x55977b,_0x55977b=(_0x3eb537<<0x1e|_0x3eb537>>>0x2)&0xffffffff,_0x3eb537=_0x4b568e,_0x4b568e=_0x22c0bd;}this['chain_'][0x0]=this['chain_'][0x0]+_0x4b568e&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x3eb537&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x55977b&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x2d15cc&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x12fa26&0xffffffff;}['update'](_0x5a5605,_0x32d4fb){if(_0x5a5605==null)return;_0x32d4fb===void 0x0&&(_0x32d4fb=_0x5a5605['length']);const _0xb3eeb3=_0x32d4fb-this['blockSize'];let _0x177f4a=0x0;const _0xc1357f=this['buf_'];let _0x5a7ed9=this['inbuf_'];for(;_0x177f4a<_0x32d4fb;){if(_0x5a7ed9===0x0){for(;_0x177f4a<=_0xb3eeb3;)this['compress_'](_0x5a5605,_0x177f4a),_0x177f4a+=this['blockSize'];}if(typeof _0x5a5605=='string'){for(;_0x177f4a<_0x32d4fb;)if(_0xc1357f[_0x5a7ed9]=_0x5a5605['charCodeAt'](_0x177f4a),++_0x5a7ed9,++_0x177f4a,_0x5a7ed9===this['blockSize']){this['compress_'](_0xc1357f),_0x5a7ed9=0x0;break;}}else{for(;_0x177f4a<_0x32d4fb;)if(_0xc1357f[_0x5a7ed9]=_0x5a5605[_0x177f4a],++_0x5a7ed9,++_0x177f4a,_0x5a7ed9===this['blockSize']){this['compress_'](_0xc1357f),_0x5a7ed9=0x0;break;}}}this['inbuf_']=_0x5a7ed9,this['total_']+=_0x32d4fb;}['digest'](){const _0x390b06=[];let _0x100a60=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x48c352=this['blockSize']-0x1;_0x48c352>=0x38;_0x48c352--)this['buf_'][_0x48c352]=_0x100a60&0xff,_0x100a60/=0x100;this['compress_'](this['buf_']);let _0x2090e3=0x0;for(let _0xf82009=0x0;_0xf82009<0x5;_0xf82009++)for(let _0x2486f4=0x18;_0x2486f4>=0x0;_0x2486f4-=0x8)_0x390b06[_0x2090e3]=this['chain_'][_0xf82009]>>_0x2486f4&0xff,++_0x2090e3;return _0x390b06;}}function Tc(_0x446e0b,_0x2ddc11){const _0x3475cf=new Sc(_0x446e0b,_0x2ddc11);return _0x3475cf['subscribe']['bind'](_0x3475cf);}class Sc{constructor(_0x5842f3,_0x23296a){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x23296a,this['task']['then'](()=>{_0x5842f3(this);})['catch'](_0x59e5c1=>{this['error'](_0x59e5c1);});}['next'](_0xebbd37){this['forEachObserver'](_0x32f95a=>{_0x32f95a['next'](_0xebbd37);});}['error'](_0x5b8148){this['forEachObserver'](_0x20874a=>{_0x20874a['error'](_0x5b8148);}),this['close'](_0x5b8148);}['complete'](){this['forEachObserver'](_0x3c9a47=>{_0x3c9a47['complete']();}),this['close']();}['subscribe'](_0x2fb118,_0x408716,_0x3a22ec){let _0x27753a;if(_0x2fb118===void 0x0&&_0x408716===void 0x0&&_0x3a22ec===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x2fb118,['next','error','complete'])?_0x27753a=_0x2fb118:_0x27753a={'next':_0x2fb118,'error':_0x408716,'complete':_0x3a22ec},_0x27753a['next']===void 0x0&&(_0x27753a['next']=ti),_0x27753a['error']===void 0x0&&(_0x27753a['error']=ti),_0x27753a['complete']===void 0x0&&(_0x27753a['complete']=ti);const _0x4c2f2d=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x27753a['error'](this['finalError']):_0x27753a['complete']();}catch{}}),this['observers']['push'](_0x27753a),_0x4c2f2d;}['unsubscribeOne'](_0x2ac934){this['observers']===void 0x0||this['observers'][_0x2ac934]===void 0x0||(delete this['observers'][_0x2ac934],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x49cc3b){if(!this['finalized']){for(let _0x1313d6=0x0;_0x1313d6<this['observers']['length'];_0x1313d6++)this['sendOne'](_0x1313d6,_0x49cc3b);}}['sendOne'](_0x5431d2,_0x245be2){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x5431d2]!==void 0x0)try{_0x245be2(this['observers'][_0x5431d2]);}catch(_0x358675){typeof console<'u'&&console['error']&&console['error'](_0x358675);}});}['close'](_0x1c6243){this['finalized']||(this['finalized']=!0x0,_0x1c6243!==void 0x0&&(this['finalError']=_0x1c6243),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0xec95ce,_0x235fe6){if(typeof _0xec95ce!='object'||_0xec95ce===null)return!0x1;for(const _0x146dc0 of _0x235fe6)if(_0x146dc0 in _0xec95ce&&typeof _0xec95ce[_0x146dc0]=='function')return!0x0;return!0x1;}function ti(){}function it(_0xa9485a,_0x4e826b){return _0xa9485a+'\x20failed:\x20'+_0x4e826b+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x1ca648){const _0x9d114f=[];let _0x18e4e9=0x0;for(let _0x3f7516=0x0;_0x3f7516<_0x1ca648['length'];_0x3f7516++){let _0x3d78eb=_0x1ca648['charCodeAt'](_0x3f7516);if(_0x3d78eb>=0xd800&&_0x3d78eb<=0xdbff){const _0x5034b3=_0x3d78eb-0xd800;_0x3f7516++,f(_0x3f7516<_0x1ca648['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x9cc846=_0x1ca648['charCodeAt'](_0x3f7516)-0xdc00;_0x3d78eb=0x10000+(_0x5034b3<<0xa)+_0x9cc846;}_0x3d78eb<0x80?_0x9d114f[_0x18e4e9++]=_0x3d78eb:_0x3d78eb<0x800?(_0x9d114f[_0x18e4e9++]=_0x3d78eb>>0x6|0xc0,_0x9d114f[_0x18e4e9++]=_0x3d78eb&0x3f|0x80):_0x3d78eb<0x10000?(_0x9d114f[_0x18e4e9++]=_0x3d78eb>>0xc|0xe0,_0x9d114f[_0x18e4e9++]=_0x3d78eb>>0x6&0x3f|0x80,_0x9d114f[_0x18e4e9++]=_0x3d78eb&0x3f|0x80):(_0x9d114f[_0x18e4e9++]=_0x3d78eb>>0x12|0xf0,_0x9d114f[_0x18e4e9++]=_0x3d78eb>>0xc&0x3f|0x80,_0x9d114f[_0x18e4e9++]=_0x3d78eb>>0x6&0x3f|0x80,_0x9d114f[_0x18e4e9++]=_0x3d78eb&0x3f|0x80);}return _0x9d114f;},Ln=function(_0x5892d5){let _0x39e1c9=0x0;for(let _0x521ddd=0x0;_0x521ddd<_0x5892d5['length'];_0x521ddd++){const _0x5e13a7=_0x5892d5['charCodeAt'](_0x521ddd);_0x5e13a7<0x80?_0x39e1c9++:_0x5e13a7<0x800?_0x39e1c9+=0x2:_0x5e13a7>=0xd800&&_0x5e13a7<=0xdbff?(_0x39e1c9+=0x4,_0x521ddd++):_0x39e1c9+=0x3;}return _0x39e1c9;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x25871a){return _0x25871a&&_0x25871a['_delegate']?_0x25871a['_delegate']:_0x25871a;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x10b48e){try{return(_0x10b48e['startsWith']('http://')||_0x10b48e['startsWith']('https://')?new URL(_0x10b48e)['hostname']:_0x10b48e)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x1edbff){return(await fetch(_0x1edbff,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x1eebb1,_0x2a7543,_0x33c928){this['name']=_0x1eebb1,this['instanceFactory']=_0x2a7543,this['type']=_0x33c928,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x54be13){return this['instantiationMode']=_0x54be13,this;}['setMultipleInstances'](_0x348d7f){return this['multipleInstances']=_0x348d7f,this;}['setServiceProps'](_0x26e7f1){return this['serviceProps']=_0x26e7f1,this;}['setInstanceCreatedCallback'](_0x444b6c){return this['onInstanceCreated']=_0x444b6c,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x4c67b9,_0xcd5cbd){this['name']=_0x4c67b9,this['container']=_0xcd5cbd,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x2be68b){const _0x7d9158=this['normalizeInstanceIdentifier'](_0x2be68b);if(!this['instancesDeferred']['has'](_0x7d9158)){const _0x151d0c=new H();if(this['instancesDeferred']['set'](_0x7d9158,_0x151d0c),this['isInitialized'](_0x7d9158)||this['shouldAutoInitialize']())try{const _0x5e0d47=this['getOrInitializeService']({'instanceIdentifier':_0x7d9158});_0x5e0d47&&_0x151d0c['resolve'](_0x5e0d47);}catch{}}return this['instancesDeferred']['get'](_0x7d9158)['promise'];}['getImmediate'](_0x511265){const _0x42768b=this['normalizeInstanceIdentifier'](_0x511265==null?void 0x0:_0x511265['identifier']),_0x7f8220=(_0x511265==null?void 0x0:_0x511265['optional'])??!0x1;if(this['isInitialized'](_0x42768b)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x42768b});}catch(_0x14c5de){if(_0x7f8220)return null;throw _0x14c5de;}else{if(_0x7f8220)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x4b429e){if(_0x4b429e['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x4b429e['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x4b429e,!!this['shouldAutoInitialize']()){if(Pc(_0x4b429e))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x28db01,_0x10618e]of this['instancesDeferred']['entries']()){const _0x1266e9=this['normalizeInstanceIdentifier'](_0x28db01);try{const _0x3a153a=this['getOrInitializeService']({'instanceIdentifier':_0x1266e9});_0x10618e['resolve'](_0x3a153a);}catch{}}}}['clearInstance'](_0x23846b=Ne){this['instancesDeferred']['delete'](_0x23846b),this['instancesOptions']['delete'](_0x23846b),this['instances']['delete'](_0x23846b);}async['delete'](){const _0x154ffd=Array['from'](this['instances']['values']());await Promise['all']([..._0x154ffd['filter'](_0x41e00a=>'INTERNAL'in _0x41e00a)['map'](_0x42aa7e=>_0x42aa7e['INTERNAL']['delete']()),..._0x154ffd['filter'](_0x36de4d=>'_delete'in _0x36de4d)['map'](_0x3b24f1=>_0x3b24f1['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x451b96=Ne){return this['instances']['has'](_0x451b96);}['getOptions'](_0x22cd38=Ne){return this['instancesOptions']['get'](_0x22cd38)||{};}['initialize'](_0x31c7f6={}){const {options:_0x5b06fc={}}=_0x31c7f6,_0x29efaa=this['normalizeInstanceIdentifier'](_0x31c7f6['instanceIdentifier']);if(this['isInitialized'](_0x29efaa))throw Error(this['name']+'('+_0x29efaa+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x13f158=this['getOrInitializeService']({'instanceIdentifier':_0x29efaa,'options':_0x5b06fc});for(const [_0x419524,_0x2da466]of this['instancesDeferred']['entries']()){const _0x4e7813=this['normalizeInstanceIdentifier'](_0x419524);_0x29efaa===_0x4e7813&&_0x2da466['resolve'](_0x13f158);}return _0x13f158;}['onInit'](_0x243a78,_0x44635a){const _0x1f4555=this['normalizeInstanceIdentifier'](_0x44635a),_0x2b57dc=this['onInitCallbacks']['get'](_0x1f4555)??new Set();_0x2b57dc['add'](_0x243a78),this['onInitCallbacks']['set'](_0x1f4555,_0x2b57dc);const _0x3337af=this['instances']['get'](_0x1f4555);return _0x3337af&&_0x243a78(_0x3337af,_0x1f4555),()=>{_0x2b57dc['delete'](_0x243a78);};}['invokeOnInitCallbacks'](_0x51b626,_0x3136ed){const _0x209e43=this['onInitCallbacks']['get'](_0x3136ed);if(_0x209e43){for(const _0x1345c8 of _0x209e43)try{_0x1345c8(_0x51b626,_0x3136ed);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x62738a,options:_0x30cb53={}}){let _0x467e56=this['instances']['get'](_0x62738a);if(!_0x467e56&&this['component']&&(_0x467e56=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x62738a),'options':_0x30cb53}),this['instances']['set'](_0x62738a,_0x467e56),this['instancesOptions']['set'](_0x62738a,_0x30cb53),this['invokeOnInitCallbacks'](_0x467e56,_0x62738a),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x62738a,_0x467e56);}catch{}return _0x467e56||null;}['normalizeInstanceIdentifier'](_0xa881b=Ne){return this['component']?this['component']['multipleInstances']?_0xa881b:Ne:_0xa881b;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x641375){return _0x641375===Ne?void 0x0:_0x641375;}function Pc(_0x84f29e){return _0x84f29e['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x303459){this['name']=_0x303459,this['providers']=new Map();}['addComponent'](_0x3d36a6){const _0x34231c=this['getProvider'](_0x3d36a6['name']);if(_0x34231c['isComponentSet']())throw new Error('Component\x20'+_0x3d36a6['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x34231c['setComponent'](_0x3d36a6);}['addOrOverwriteComponent'](_0x167ffe){this['getProvider'](_0x167ffe['name'])['isComponentSet']()&&this['providers']['delete'](_0x167ffe['name']),this['addComponent'](_0x167ffe);}['getProvider'](_0x204048){if(this['providers']['has'](_0x204048))return this['providers']['get'](_0x204048);const _0x2b6389=new Ac(_0x204048,this);return this['providers']['set'](_0x204048,_0x2b6389),_0x2b6389;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x53d509){_0x53d509[_0x53d509['DEBUG']=0x0]='DEBUG',_0x53d509[_0x53d509['VERBOSE']=0x1]='VERBOSE',_0x53d509[_0x53d509['INFO']=0x2]='INFO',_0x53d509[_0x53d509['WARN']=0x3]='WARN',_0x53d509[_0x53d509['ERROR']=0x4]='ERROR',_0x53d509[_0x53d509['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x3e214c,_0xd3953f,..._0x3f920f)=>{if(_0xd3953f<_0x3e214c['logLevel'])return;const _0x451e49=new Date()['toISOString'](),_0x329e4d=Mc[_0xd3953f];if(_0x329e4d)console[_0x329e4d]('['+_0x451e49+']\x20\x20'+_0x3e214c['name']+':',..._0x3f920f);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0xd3953f+')');};class Bi{constructor(_0x37d27a){this['name']=_0x37d27a,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x128336){if(!(_0x128336 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x128336+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x128336;}['setLogLevel'](_0x262017){this['_logLevel']=typeof _0x262017=='string'?Oc[_0x262017]:_0x262017;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x5877aa){if(typeof _0x5877aa!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x5877aa;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x2f4d3f){this['_userLogHandler']=_0x2f4d3f;}['debug'](..._0x276dff){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x276dff),this['_logHandler'](this,T['DEBUG'],..._0x276dff);}['log'](..._0x33a254){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x33a254),this['_logHandler'](this,T['VERBOSE'],..._0x33a254);}['info'](..._0x18d7d1){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x18d7d1),this['_logHandler'](this,T['INFO'],..._0x18d7d1);}['warn'](..._0x3d40a4){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x3d40a4),this['_logHandler'](this,T['WARN'],..._0x3d40a4);}['error'](..._0x1e533c){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x1e533c),this['_logHandler'](this,T['ERROR'],..._0x1e533c);}}const xc=(_0x5de028,_0x4c5911)=>_0x4c5911['some'](_0x37d645=>_0x5de028 instanceof _0x37d645);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x8b827e){const _0x37b4d4=new Promise((_0x43a57f,_0x814f69)=>{const _0xe16b54=()=>{_0x8b827e['removeEventListener']('success',_0x620a1b),_0x8b827e['removeEventListener']('error',_0x5b9a9c);},_0x620a1b=()=>{_0x43a57f(ge(_0x8b827e['result'])),_0xe16b54();},_0x5b9a9c=()=>{_0x814f69(_0x8b827e['error']),_0xe16b54();};_0x8b827e['addEventListener']('success',_0x620a1b),_0x8b827e['addEventListener']('error',_0x5b9a9c);});return _0x37b4d4['then'](_0x4c1bcb=>{_0x4c1bcb instanceof IDBCursor&&Jr['set'](_0x4c1bcb,_0x8b827e);})['catch'](()=>{}),Vi['set'](_0x37b4d4,_0x8b827e),_0x37b4d4;}function Bc(_0x519a70){if(_i['has'](_0x519a70))return;const _0x119bf2=new Promise((_0x5ebc23,_0x412ee8)=>{const _0x29f9db=()=>{_0x519a70['removeEventListener']('complete',_0x363f06),_0x519a70['removeEventListener']('error',_0x15a9ca),_0x519a70['removeEventListener']('abort',_0x15a9ca);},_0x363f06=()=>{_0x5ebc23(),_0x29f9db();},_0x15a9ca=()=>{_0x412ee8(_0x519a70['error']||new DOMException('AbortError','AbortError')),_0x29f9db();};_0x519a70['addEventListener']('complete',_0x363f06),_0x519a70['addEventListener']('error',_0x15a9ca),_0x519a70['addEventListener']('abort',_0x15a9ca);});_i['set'](_0x519a70,_0x119bf2);}let gi={'get'(_0x423f23,_0x5e61aa,_0x1c3022){if(_0x423f23 instanceof IDBTransaction){if(_0x5e61aa==='done')return _i['get'](_0x423f23);if(_0x5e61aa==='objectStoreNames')return _0x423f23['objectStoreNames']||Xr['get'](_0x423f23);if(_0x5e61aa==='store')return _0x1c3022['objectStoreNames'][0x1]?void 0x0:_0x1c3022['objectStore'](_0x1c3022['objectStoreNames'][0x0]);}return ge(_0x423f23[_0x5e61aa]);},'set'(_0xa3174b,_0x51f8b3,_0x19c8a7){return _0xa3174b[_0x51f8b3]=_0x19c8a7,!0x0;},'has'(_0x35f794,_0x43ebf8){return _0x35f794 instanceof IDBTransaction&&(_0x43ebf8==='done'||_0x43ebf8==='store')?!0x0:_0x43ebf8 in _0x35f794;}};function Vc(_0x13d817){gi=_0x13d817(gi);}function Hc(_0x55dfb3){return _0x55dfb3===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x54a3b7,..._0x3959cf){const _0xcdd91f=_0x55dfb3['call'](ii(this),_0x54a3b7,..._0x3959cf);return Xr['set'](_0xcdd91f,_0x54a3b7['sort']?_0x54a3b7['sort']():[_0x54a3b7]),ge(_0xcdd91f);}:Uc()['includes'](_0x55dfb3)?function(..._0x57ef2b){return _0x55dfb3['apply'](ii(this),_0x57ef2b),ge(Jr['get'](this));}:function(..._0x2a1a42){return ge(_0x55dfb3['apply'](ii(this),_0x2a1a42));};}function $c(_0x4f2e8d){return typeof _0x4f2e8d=='function'?Hc(_0x4f2e8d):(_0x4f2e8d instanceof IDBTransaction&&Bc(_0x4f2e8d),xc(_0x4f2e8d,Fc())?new Proxy(_0x4f2e8d,gi):_0x4f2e8d);}function ge(_0x4b5279){if(_0x4b5279 instanceof IDBRequest)return Wc(_0x4b5279);if(ni['has'](_0x4b5279))return ni['get'](_0x4b5279);const _0x5b4f9c=$c(_0x4b5279);return _0x5b4f9c!==_0x4b5279&&(ni['set'](_0x4b5279,_0x5b4f9c),Vi['set'](_0x5b4f9c,_0x4b5279)),_0x5b4f9c;}const ii=_0x52a59e=>Vi['get'](_0x52a59e);function Gc(_0x13d4c6,_0x2b2ec1,{blocked:_0x3be2b9,upgrade:_0x471397,blocking:_0x4c190f,terminated:_0x5b953e}={}){const _0x198f51=indexedDB['open'](_0x13d4c6,_0x2b2ec1),_0x2ee560=ge(_0x198f51);return _0x471397&&_0x198f51['addEventListener']('upgradeneeded',_0x3d850a=>{_0x471397(ge(_0x198f51['result']),_0x3d850a['oldVersion'],_0x3d850a['newVersion'],ge(_0x198f51['transaction']),_0x3d850a);}),_0x3be2b9&&_0x198f51['addEventListener']('blocked',_0x285409=>_0x3be2b9(_0x285409['oldVersion'],_0x285409['newVersion'],_0x285409)),_0x2ee560['then'](_0x1cdcc8=>{_0x5b953e&&_0x1cdcc8['addEventListener']('close',()=>_0x5b953e()),_0x4c190f&&_0x1cdcc8['addEventListener']('versionchange',_0x53dd7f=>_0x4c190f(_0x53dd7f['oldVersion'],_0x53dd7f['newVersion'],_0x53dd7f));})['catch'](()=>{}),_0x2ee560;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x44f22e,_0x385014){if(!(_0x44f22e instanceof IDBDatabase&&!(_0x385014 in _0x44f22e)&&typeof _0x385014=='string'))return;if(si['get'](_0x385014))return si['get'](_0x385014);const _0xd5280f=_0x385014['replace'](/FromIndex$/,''),_0x5563f8=_0x385014!==_0xd5280f,_0x33ad7d=zc['includes'](_0xd5280f);if(!(_0xd5280f in(_0x5563f8?IDBIndex:IDBObjectStore)['prototype'])||!(_0x33ad7d||qc['includes'](_0xd5280f)))return;const _0x1c830a=async function(_0x10d28d,..._0x420c06){const _0x3136ae=this['transaction'](_0x10d28d,_0x33ad7d?'readwrite':'readonly');let _0x52a65b=_0x3136ae['store'];return _0x5563f8&&(_0x52a65b=_0x52a65b['index'](_0x420c06['shift']())),(await Promise['all']([_0x52a65b[_0xd5280f](..._0x420c06),_0x33ad7d&&_0x3136ae['done']]))[0x0];};return si['set'](_0x385014,_0x1c830a),_0x1c830a;}Vc(_0x4fbf70=>({..._0x4fbf70,'get':(_0x83400e,_0x5236f4,_0x26b7b9)=>Ms(_0x83400e,_0x5236f4)||_0x4fbf70['get'](_0x83400e,_0x5236f4,_0x26b7b9),'has':(_0x42df39,_0x25fdf7)=>!!Ms(_0x42df39,_0x25fdf7)||_0x4fbf70['has'](_0x42df39,_0x25fdf7)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x4cc4cc){this['container']=_0x4cc4cc;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x5bf5c1=>{if(Kc(_0x5bf5c1)){const _0x2f9881=_0x5bf5c1['getImmediate']();return _0x2f9881['library']+'/'+_0x2f9881['version'];}else return null;})['filter'](_0x2a2eee=>_0x2a2eee)['join']('\x20');}}function Kc(_0x231d67){const _0x35bd20=_0x231d67['getComponent']();return(_0x35bd20==null?void 0x0:_0x35bd20['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x3d44c3,_0x494d75){try{_0x3d44c3['container']['addComponent'](_0x494d75);}catch(_0x252a48){oe['debug']('Component\x20'+_0x494d75['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x3d44c3['name'],_0x252a48);}}function st(_0x21c17c){const _0xbf2acd=_0x21c17c['name'];if(Ei['has'](_0xbf2acd))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0xbf2acd+'.'),!0x1;Ei['set'](_0xbf2acd,_0x21c17c);for(const _0x286ff0 of Ue['values']())xs(_0x286ff0,_0x21c17c);for(const _0x2c86c7 of vi['values']())xs(_0x2c86c7,_0x21c17c);return!0x0;}function Hi(_0x4b17e0,_0x11d5fd){const _0x41e981=_0x4b17e0['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x41e981&&_0x41e981['triggerHeartbeat'](),_0x4b17e0['container']['getProvider'](_0x11d5fd);}function $(_0x3cedb6){return _0x3cedb6==null?!0x1:_0x3cedb6['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x3d97e0,_0x425c65,_0x59064c){this['_isDeleted']=!0x1,this['_options']={..._0x3d97e0},this['_config']={..._0x425c65},this['_name']=_0x425c65['name'],this['_automaticDataCollectionEnabled']=_0x425c65['automaticDataCollectionEnabled'],this['_container']=_0x59064c,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x4f3321){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x4f3321;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x352218){this['_isDeleted']=_0x352218;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x27d399,_0x4f79f5={}){let _0x24e0dc=_0x27d399;typeof _0x4f79f5!='object'&&(_0x4f79f5={'name':_0x4f79f5});const _0x18e947={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x4f79f5},_0x4cc3d5=_0x18e947['name'];if(typeof _0x4cc3d5!='string'||!_0x4cc3d5)throw me['create']('bad-app-name',{'appName':String(_0x4cc3d5)});if(_0x24e0dc||(_0x24e0dc=zr()),!_0x24e0dc)throw me['create']('no-options');const _0x51a6de=Ue['get'](_0x4cc3d5);if(_0x51a6de){if(xe(_0x24e0dc,_0x51a6de['options'])&&xe(_0x18e947,_0x51a6de['config']))return _0x51a6de;throw me['create']('duplicate-app',{'appName':_0x4cc3d5});}const _0x43c478=new Nc(_0x4cc3d5);for(const _0x2ef28b of Ei['values']())_0x43c478['addComponent'](_0x2ef28b);const _0x5e4660=new Tl(_0x24e0dc,_0x18e947,_0x43c478);return Ue['set'](_0x4cc3d5,_0x5e4660),_0x5e4660;}function Zr(_0xcdff61=yi){const _0xf29df7=Ue['get'](_0xcdff61);if(!_0xf29df7&&_0xcdff61===yi&&zr())return Sl();if(!_0xf29df7)throw me['create']('no-app',{'appName':_0xcdff61});return _0xf29df7;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x9aad4e){let _0x4924d2=!0x1;const _0x27ca3d=_0x9aad4e['name'];Ue['has'](_0x27ca3d)?(_0x4924d2=!0x0,Ue['delete'](_0x27ca3d)):vi['has'](_0x27ca3d)&&_0x9aad4e['decRefCount']()<=0x0&&(vi['delete'](_0x27ca3d),_0x4924d2=!0x0),_0x4924d2&&(await Promise['all'](_0x9aad4e['container']['getProviders']()['map'](_0x4f728e=>_0x4f728e['delete']())),_0x9aad4e['isDeleted']=!0x0);}function ye(_0x56918f,_0x4db6b4,_0x6a212){let _0x347a77=wl[_0x56918f]??_0x56918f;_0x6a212&&(_0x347a77+='-'+_0x6a212);const _0x577a81=_0x347a77['match'](/\s|\//),_0x967f32=_0x4db6b4['match'](/\s|\//);if(_0x577a81||_0x967f32){const _0x278786=['Unable\x20to\x20register\x20library\x20\x22'+_0x347a77+'\x22\x20with\x20version\x20\x22'+_0x4db6b4+'\x22:'];_0x577a81&&_0x278786['push']('library\x20name\x20\x22'+_0x347a77+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x577a81&&_0x967f32&&_0x278786['push']('and'),_0x967f32&&_0x278786['push']('version\x20name\x20\x22'+_0x4db6b4+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x278786['join']('\x20'));return;}st(new Fe(_0x347a77+'-version',()=>({'library':_0x347a77,'version':_0x4db6b4}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x58b452,_0x1c61d0)=>{switch(_0x1c61d0){case 0x0:try{_0x58b452['createObjectStore'](Ot);}catch(_0x3e8156){console['warn'](_0x3e8156);}}}})['catch'](_0x385e7f=>{throw me['create']('idb-open',{'originalErrorMessage':_0x385e7f['message']});})),ri;}async function Al(_0x389bd3){try{const _0x47310f=(await eo())['transaction'](Ot),_0x2a60ed=await _0x47310f['objectStore'](Ot)['get'](to(_0x389bd3));return await _0x47310f['done'],_0x2a60ed;}catch(_0x576f2a){if(_0x576f2a instanceof Re)oe['warn'](_0x576f2a['message']);else{const _0x2a4aa0=me['create']('idb-get',{'originalErrorMessage':_0x576f2a==null?void 0x0:_0x576f2a['message']});oe['warn'](_0x2a4aa0['message']);}}}async function Fs(_0x434b90,_0x2a681d){try{const _0x2c72f4=(await eo())['transaction'](Ot,'readwrite');await _0x2c72f4['objectStore'](Ot)['put'](_0x2a681d,to(_0x434b90)),await _0x2c72f4['done'];}catch(_0x339f73){if(_0x339f73 instanceof Re)oe['warn'](_0x339f73['message']);else{const _0x5a8592=me['create']('idb-set',{'originalErrorMessage':_0x339f73==null?void 0x0:_0x339f73['message']});oe['warn'](_0x5a8592['message']);}}}function to(_0x5cf663){return _0x5cf663['name']+'!'+_0x5cf663['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x14ca55){this['container']=_0x14ca55,this['_heartbeatsCache']=null;const _0x1ec205=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x1ec205),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x2db841=>(this['_heartbeatsCache']=_0x2db841,_0x2db841));}async['triggerHeartbeat'](){var _0x48778e,_0x30362d;try{const _0x19eb45=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0xd629f1=Us();if(((_0x48778e=this['_heartbeatsCache'])==null?void 0x0:_0x48778e['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x30362d=this['_heartbeatsCache'])==null?void 0x0:_0x30362d['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0xd629f1||this['_heartbeatsCache']['heartbeats']['some'](_0x44b948=>_0x44b948['date']===_0xd629f1))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0xd629f1,'agent':_0x19eb45}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x390c4f=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x390c4f,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x5b334b){oe['warn'](_0x5b334b);}}async['getHeartbeatsHeader'](){var _0x5ab347;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x5ab347=this['_heartbeatsCache'])==null?void 0x0:_0x5ab347['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x3756d7=Us(),{heartbeatsToSend:_0x2f44de,unsentEntries:_0x247235}=Ol(this['_heartbeatsCache']['heartbeats']),_0x3be7f2=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x2f44de}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x3756d7,_0x247235['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x247235,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x3be7f2;}catch(_0x17f381){return oe['warn'](_0x17f381),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x5e805d,_0x3cab94=kl){const _0x301fb6=[];let _0x419802=_0x5e805d['slice']();for(const _0x575b28 of _0x5e805d){const _0x267496=_0x301fb6['find'](_0x52a8d1=>_0x52a8d1['agent']===_0x575b28['agent']);if(_0x267496){if(_0x267496['dates']['push'](_0x575b28['date']),Ws(_0x301fb6)>_0x3cab94){_0x267496['dates']['pop']();break;}}else{if(_0x301fb6['push']({'agent':_0x575b28['agent'],'dates':[_0x575b28['date']]}),Ws(_0x301fb6)>_0x3cab94){_0x301fb6['pop']();break;}}_0x419802=_0x419802['slice'](0x1);}return{'heartbeatsToSend':_0x301fb6,'unsentEntries':_0x419802};}class Dl{constructor(_0x1f3413){this['app']=_0x1f3413,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x319ad9=await Al(this['app']);return _0x319ad9!=null&&_0x319ad9['heartbeats']?_0x319ad9:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x3c72ce){if(await this['_canUseIndexedDBPromise']){const _0x4bf74d=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x3c72ce['lastSentHeartbeatDate']??_0x4bf74d['lastSentHeartbeatDate'],'heartbeats':_0x3c72ce['heartbeats']});}else return;}async['add'](_0x324bca){if(await this['_canUseIndexedDBPromise']){const _0x3c87e6=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x324bca['lastSentHeartbeatDate']??_0x3c87e6['lastSentHeartbeatDate'],'heartbeats':[..._0x3c87e6['heartbeats'],..._0x324bca['heartbeats']]});}else return;}}function Ws(_0x1eb2d0){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x1eb2d0}))['length'];}function Ml(_0x663c7b){if(_0x663c7b['length']===0x0)return-0x1;let _0x104f37=0x0,_0x2bf2fd=_0x663c7b[0x0]['date'];for(let _0x55f4e5=0x1;_0x55f4e5<_0x663c7b['length'];_0x55f4e5++)_0x663c7b[_0x55f4e5]['date']<_0x2bf2fd&&(_0x2bf2fd=_0x663c7b[_0x55f4e5]['date'],_0x104f37=_0x55f4e5);return _0x104f37;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x3b41d2){st(new Fe('platform-logger',_0x2b4015=>new jc(_0x2b4015),'PRIVATE')),st(new Fe('heartbeat',_0x2e0103=>new Nl(_0x2e0103),'PRIVATE')),ye(mi,Ls,_0x3b41d2),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x1e9fa3){no=_0x1e9fa3;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x2c0169){this['domStorage_']=_0x2c0169,this['prefix_']='firebase:';}['set'](_0x1e3821,_0x1c151e){_0x1c151e==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x1e3821)):this['domStorage_']['setItem'](this['prefixedName_'](_0x1e3821),O(_0x1c151e));}['get'](_0x80940f){const _0x38d322=this['domStorage_']['getItem'](this['prefixedName_'](_0x80940f));return _0x38d322==null?null:Nt(_0x38d322);}['remove'](_0x1afa22){this['domStorage_']['removeItem'](this['prefixedName_'](_0x1afa22));}['prefixedName_'](_0x191d81){return this['prefix_']+_0x191d81;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x5ea0db,_0x56e516){_0x56e516==null?delete this['cache_'][_0x5ea0db]:this['cache_'][_0x5ea0db]=_0x56e516;}['get'](_0x2836ac){return Q(this['cache_'],_0x2836ac)?this['cache_'][_0x2836ac]:null;}['remove'](_0xae775f){delete this['cache_'][_0xae775f];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x37a2d8){try{if(typeof window<'u'&&typeof window[_0x37a2d8]<'u'){const _0x486782=window[_0x37a2d8];return _0x486782['setItem']('firebase:sentinel','cache'),_0x486782['removeItem']('firebase:sentinel'),new Wl(_0x486782);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x1b516f=0x1;return function(){return _0x1b516f++;};}()),ro=function(_0x1b552b){const _0x3b8ebd=Rc(_0x1b552b),_0x3c1445=new Cc();_0x3c1445['update'](_0x3b8ebd);const _0x52be12=_0x3c1445['digest']();return Fi['encodeByteArray'](_0x52be12);},zt=function(..._0x3125a2){let _0x108058='';for(let _0x2afefc=0x0;_0x2afefc<_0x3125a2['length'];_0x2afefc++){const _0x1c4772=_0x3125a2[_0x2afefc];Array['isArray'](_0x1c4772)||_0x1c4772&&typeof _0x1c4772=='object'&&typeof _0x1c4772['length']=='number'?_0x108058+=zt['apply'](null,_0x1c4772):typeof _0x1c4772=='object'?_0x108058+=O(_0x1c4772):_0x108058+=_0x1c4772,_0x108058+='\x20';}return _0x108058;};let St=null,$s=!0x0;const Hl=function(_0x21eb7f,_0x1c56fd){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x37f01d){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x5cd58b=zt['apply'](null,_0x37f01d);St(_0x5cd58b);}},jt=function(_0x27ed11){return function(..._0x5bf19f){L(_0x27ed11,..._0x5bf19f);};},Ii=function(..._0x36823a){const _0x1c7bab='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x36823a);Ze['error'](_0x1c7bab);},ae=function(..._0x515e22){const _0x4cbc12='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x515e22);throw Ze['error'](_0x4cbc12),new Error(_0x4cbc12);},U=function(..._0x1a0b67){const _0x3d1aa0='FIREBASE\x20WARNING:\x20'+zt(..._0x1a0b67);Ze['warn'](_0x3d1aa0);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x3cca4f){return typeof _0x3cca4f=='number'&&(_0x3cca4f!==_0x3cca4f||_0x3cca4f===Number['POSITIVE_INFINITY']||_0x3cca4f===Number['NEGATIVE_INFINITY']);},Gl=function(_0x38369d){if(document['readyState']==='complete')_0x38369d();else{let _0x1bf7c3=!0x1;const _0x165b96=function(){if(!document['body']){setTimeout(_0x165b96,Math['floor'](0xa));return;}_0x1bf7c3||(_0x1bf7c3=!0x0,_0x38369d());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x165b96,!0x1),window['addEventListener']('load',_0x165b96,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x165b96();}),window['attachEvent']('onload',_0x165b96));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x382cee,_0x508ec3){if(_0x382cee===_0x508ec3)return 0x0;if(_0x382cee===We||_0x508ec3===we)return-0x1;if(_0x508ec3===We||_0x382cee===we)return 0x1;{const _0x4099de=Gs(_0x382cee),_0x36c7a9=Gs(_0x508ec3);return _0x4099de!==null?_0x36c7a9!==null?_0x4099de-_0x36c7a9===0x0?_0x382cee['length']-_0x508ec3['length']:_0x4099de-_0x36c7a9:-0x1:_0x36c7a9!==null?0x1:_0x382cee<_0x508ec3?-0x1:0x1;}},ql=function(_0xcd463a,_0x35916e){return _0xcd463a===_0x35916e?0x0:_0xcd463a<_0x35916e?-0x1:0x1;},vt=function(_0x407a05,_0x5ef49f){if(_0x5ef49f&&_0x407a05 in _0x5ef49f)return _0x5ef49f[_0x407a05];throw new Error('Missing\x20required\x20key\x20('+_0x407a05+')\x20in\x20object:\x20'+O(_0x5ef49f));},$i=function(_0x4b2371){if(typeof _0x4b2371!='object'||_0x4b2371===null)return O(_0x4b2371);const _0x4b9c3b=[];for(const _0x49691a in _0x4b2371)_0x4b9c3b['push'](_0x49691a);_0x4b9c3b['sort']();let _0x8810f9='{';for(let _0x5aeb57=0x0;_0x5aeb57<_0x4b9c3b['length'];_0x5aeb57++)_0x5aeb57!==0x0&&(_0x8810f9+=','),_0x8810f9+=O(_0x4b9c3b[_0x5aeb57]),_0x8810f9+=':',_0x8810f9+=$i(_0x4b2371[_0x4b9c3b[_0x5aeb57]]);return _0x8810f9+='}',_0x8810f9;},oo=function(_0x3b381f,_0x5ae2e0){const _0x46f661=_0x3b381f['length'];if(_0x46f661<=_0x5ae2e0)return[_0x3b381f];const _0x1a3e62=[];for(let _0x47f44b=0x0;_0x47f44b<_0x46f661;_0x47f44b+=_0x5ae2e0)_0x47f44b+_0x5ae2e0>_0x46f661?_0x1a3e62['push'](_0x3b381f['substring'](_0x47f44b,_0x46f661)):_0x1a3e62['push'](_0x3b381f['substring'](_0x47f44b,_0x47f44b+_0x5ae2e0));return _0x1a3e62;};function x(_0xefb782,_0x40b8b8){for(const _0x1d8186 in _0xefb782)_0xefb782['hasOwnProperty'](_0x1d8186)&&_0x40b8b8(_0x1d8186,_0xefb782[_0x1d8186]);}const ao=function(_0x3a999a){f(!xn(_0x3a999a),'Invalid\x20JSON\x20number');const _0x3b7f35=0xb,_0x550f26=0x34,_0x51fc42=(0x1<<_0x3b7f35-0x1)-0x1;let _0x3ea87b,_0x31a7f4,_0x304db9,_0x4b3bc0,_0x202412;_0x3a999a===0x0?(_0x31a7f4=0x0,_0x304db9=0x0,_0x3ea87b=0x1/_0x3a999a===-0x1/0x0?0x1:0x0):(_0x3ea87b=_0x3a999a<0x0,_0x3a999a=Math['abs'](_0x3a999a),_0x3a999a>=Math['pow'](0x2,0x1-_0x51fc42)?(_0x4b3bc0=Math['min'](Math['floor'](Math['log'](_0x3a999a)/Math['LN2']),_0x51fc42),_0x31a7f4=_0x4b3bc0+_0x51fc42,_0x304db9=Math['round'](_0x3a999a*Math['pow'](0x2,_0x550f26-_0x4b3bc0)-Math['pow'](0x2,_0x550f26))):(_0x31a7f4=0x0,_0x304db9=Math['round'](_0x3a999a/Math['pow'](0x2,0x1-_0x51fc42-_0x550f26))));const _0x3d34b7=[];for(_0x202412=_0x550f26;_0x202412;_0x202412-=0x1)_0x3d34b7['push'](_0x304db9%0x2?0x1:0x0),_0x304db9=Math['floor'](_0x304db9/0x2);for(_0x202412=_0x3b7f35;_0x202412;_0x202412-=0x1)_0x3d34b7['push'](_0x31a7f4%0x2?0x1:0x0),_0x31a7f4=Math['floor'](_0x31a7f4/0x2);_0x3d34b7['push'](_0x3ea87b?0x1:0x0),_0x3d34b7['reverse']();const _0x70f9e2=_0x3d34b7['join']('');let _0x534c93='';for(_0x202412=0x0;_0x202412<0x40;_0x202412+=0x8){let _0x7e0250=parseInt(_0x70f9e2['substr'](_0x202412,0x8),0x2)['toString'](0x10);_0x7e0250['length']===0x1&&(_0x7e0250='0'+_0x7e0250),_0x534c93=_0x534c93+_0x7e0250;}return _0x534c93['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x4267fa,_0x1abef6){let _0x10ba81='Unknown\x20Error';_0x4267fa==='too_big'?_0x10ba81='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x4267fa==='permission_denied'?_0x10ba81='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x4267fa==='unavailable'&&(_0x10ba81='The\x20service\x20is\x20unavailable');const _0xef7519=new Error(_0x4267fa+'\x20at\x20'+_0x1abef6['_path']['toString']()+':\x20'+_0x10ba81);return _0xef7519['code']=_0x4267fa['toUpperCase'](),_0xef7519;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x296809){if(Yl['test'](_0x296809)){const _0x19161a=Number(_0x296809);if(_0x19161a>=Ql&&_0x19161a<=Jl)return _0x19161a;}return null;},ft=function(_0x2376e6){try{_0x2376e6();}catch(_0x4f4eaa){setTimeout(()=>{const _0xe72754=_0x4f4eaa['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0xe72754),_0x4f4eaa;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x1c1b2c,_0x1322c2){const _0x4053fa=setTimeout(_0x1c1b2c,_0x1322c2);return typeof _0x4053fa=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x4053fa):typeof _0x4053fa=='object'&&_0x4053fa['unref']&&_0x4053fa['unref'](),_0x4053fa;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x1d4977,_0x11c2ee){this['appCheckProvider']=_0x11c2ee,this['appName']=_0x1d4977['name'],$(_0x1d4977)&&_0x1d4977['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x1d4977['settings']['appCheckToken']),this['appCheck']=_0x11c2ee==null?void 0x0:_0x11c2ee['getImmediate']({'optional':!0x0}),this['appCheck']||_0x11c2ee==null||_0x11c2ee['get']()['then'](_0x119b79=>this['appCheck']=_0x119b79);}['getToken'](_0x1ac60a){if(this['serverAppAppCheckToken']){if(_0x1ac60a)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x1ac60a):new Promise((_0x27671d,_0x236274)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x1ac60a)['then'](_0x27671d,_0x236274):_0x27671d(null);},0x0);});}['addTokenChangeListener'](_0x219093){var _0x224212;(_0x224212=this['appCheckProvider'])==null||_0x224212['get']()['then'](_0x278c3b=>_0x278c3b['addTokenListener'](_0x219093));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x3b08a4,_0x162729,_0x461f7d){this['appName_']=_0x3b08a4,this['firebaseOptions_']=_0x162729,this['authProvider_']=_0x461f7d,this['auth_']=null,this['auth_']=_0x461f7d['getImmediate']({'optional':!0x0}),this['auth_']||_0x461f7d['onInit'](_0x407094=>this['auth_']=_0x407094);}['getToken'](_0x176a16){return this['auth_']?this['auth_']['getToken'](_0x176a16)['catch'](_0x4b5247=>_0x4b5247&&_0x4b5247['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x4b5247)):new Promise((_0x356752,_0x31730a)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x176a16)['then'](_0x356752,_0x31730a):_0x356752(null);},0x0);});}['addTokenChangeListener'](_0x286981){this['auth_']?this['auth_']['addAuthTokenListener'](_0x286981):this['authProvider_']['get']()['then'](_0x40eb4e=>_0x40eb4e['addAuthTokenListener'](_0x286981));}['removeTokenChangeListener'](_0x489580){this['authProvider_']['get']()['then'](_0x65b612=>_0x65b612['removeAuthTokenListener'](_0x489580));}['notifyForInvalidToken'](){let _0x50e9ff='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x50e9ff+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x50e9ff+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x50e9ff+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x50e9ff);}}class an{constructor(_0x5ced8d){this['accessToken']=_0x5ced8d;}['getToken'](_0x4e4539){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x949de0){_0x949de0(this['accessToken']);}['removeTokenChangeListener'](_0x262590){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x34569b,_0x7087f7,_0x3ee85f,_0x2eb6b4,_0x883a54=!0x1,_0xe28d94='',_0x5109ca=!0x1,_0x1a60af=!0x1,_0x10caf1=null){this['secure']=_0x7087f7,this['namespace']=_0x3ee85f,this['webSocketOnly']=_0x2eb6b4,this['nodeAdmin']=_0x883a54,this['persistenceKey']=_0xe28d94,this['includeNamespaceInQueryParams']=_0x5109ca,this['isUsingEmulator']=_0x1a60af,this['emulatorOptions']=_0x10caf1,this['_host']=_0x34569b['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x34569b)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0xb845e2){_0xb845e2!==this['internalHost']&&(this['internalHost']=_0xb845e2,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x548002=this['toURLString']();return this['persistenceKey']&&(_0x548002+='<'+this['persistenceKey']+'>'),_0x548002;}['toURLString'](){const _0x3bb1a2=this['secure']?'https://':'http://',_0x2bc4d4=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x3bb1a2+this['host']+'/'+_0x2bc4d4;}}function th(_0x4d3df8){return _0x4d3df8['host']!==_0x4d3df8['internalHost']||_0x4d3df8['isCustomHost']()||_0x4d3df8['includeNamespaceInQueryParams'];}function vo(_0x33695e,_0x39bdd7,_0x3153ce){f(typeof _0x39bdd7=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x3153ce=='object','typeof\x20params\x20must\x20==\x20object');let _0x1a4e33;if(_0x39bdd7===go)_0x1a4e33=(_0x33695e['secure']?'wss://':'ws://')+_0x33695e['internalHost']+'/.ws?';else{if(_0x39bdd7===mo)_0x1a4e33=(_0x33695e['secure']?'https://':'http://')+_0x33695e['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x39bdd7);}th(_0x33695e)&&(_0x3153ce['ns']=_0x33695e['namespace']);const _0x5de420=[];return x(_0x3153ce,(_0xf3667f,_0x179f92)=>{_0x5de420['push'](_0xf3667f+'='+_0x179f92);}),_0x1a4e33+_0x5de420['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x19b7f1,_0x179abd=0x1){Q(this['counters_'],_0x19b7f1)||(this['counters_'][_0x19b7f1]=0x0),this['counters_'][_0x19b7f1]+=_0x179abd;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0xaac2a9){const _0x52f80a=_0xaac2a9['toString']();return oi[_0x52f80a]||(oi[_0x52f80a]=new nh()),oi[_0x52f80a];}function ih(_0x340267,_0x5ecaf3){const _0x86fbd1=_0x340267['toString']();return ai[_0x86fbd1]||(ai[_0x86fbd1]=_0x5ecaf3()),ai[_0x86fbd1];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x422298){this['onMessage_']=_0x422298,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x11101b,_0x54ea28){this['closeAfterResponse']=_0x11101b,this['onClose']=_0x54ea28,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x5a89e3,_0x5b685d){for(this['pendingResponses'][_0x5a89e3]=_0x5b685d;this['pendingResponses'][this['currentResponseNum']];){const _0xb9b224=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x4fa10e=0x0;_0x4fa10e<_0xb9b224['length'];++_0x4fa10e)_0xb9b224[_0x4fa10e]&&ft(()=>{this['onMessage_'](_0xb9b224[_0x4fa10e]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x3d6509,_0x142519,_0x13fa7a,_0x5f0a95,_0x592362,_0x2aeae6,_0xef93e){this['connId']=_0x3d6509,this['repoInfo']=_0x142519,this['applicationId']=_0x13fa7a,this['appCheckToken']=_0x5f0a95,this['authToken']=_0x592362,this['transportSessionId']=_0x2aeae6,this['lastSessionId']=_0xef93e,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x3d6509),this['stats_']=qi(_0x142519),this['urlFn']=_0x36bc61=>(this['appCheckToken']&&(_0x36bc61[wi]=this['appCheckToken']),vo(_0x142519,mo,_0x36bc61));}['open'](_0x3b05d9,_0x1c3c3b){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x1c3c3b,this['myPacketOrderer']=new sh(_0x3b05d9),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x4491ce)=>{const [_0x561b28,_0x198833,_0x1badfc,_0x357f9a,_0x2128b5]=_0x4491ce;if(this['incrementIncomingBytes_'](_0x4491ce),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x561b28===qs)this['id']=_0x198833,this['password']=_0x1badfc;else{if(_0x561b28===rh)_0x198833?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x198833,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x561b28);}}},(..._0x1571f5)=>{const [_0x2a14f3,_0x4140bd]=_0x1571f5;this['incrementIncomingBytes_'](_0x1571f5),this['myPacketOrderer']['handleResponse'](_0x2a14f3,_0x4140bd);},()=>{this['onClosed_']();},this['urlFn']);const _0x3e90c4={};_0x3e90c4[qs]='t',_0x3e90c4[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x3e90c4[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x3e90c4[co]=Gi,this['transportSessionId']&&(_0x3e90c4[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x3e90c4[po]=this['lastSessionId']),this['applicationId']&&(_0x3e90c4[_o]=this['applicationId']),this['appCheckToken']&&(_0x3e90c4[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x3e90c4[ho]=uo);const _0x310b25=this['urlFn'](_0x3e90c4);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x310b25),this['scriptTagHolder']['addTag'](_0x310b25,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x58abe1){const _0x459b36=O(_0x58abe1);this['bytesSent']+=_0x459b36['length'],this['stats_']['incrementCounter']('bytes_sent',_0x459b36['length']);const _0x2dd857=$r(_0x459b36),_0x385510=oo(_0x2dd857,fh);for(let _0x4719fc=0x0;_0x4719fc<_0x385510['length'];_0x4719fc++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x385510['length'],_0x385510[_0x4719fc]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x54aff8,_0xe153cd){this['myDisconnFrame']=document['createElement']('iframe');const _0x1e1ace={};_0x1e1ace[dh]='t',_0x1e1ace[Eo]=_0x54aff8,_0x1e1ace[Io]=_0xe153cd,this['myDisconnFrame']['src']=this['urlFn'](_0x1e1ace),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x51a277){const _0x28c774=O(_0x51a277)['length'];this['bytesReceived']+=_0x28c774,this['stats_']['incrementCounter']('bytes_received',_0x28c774);}}class zi{constructor(_0x1ca26f,_0x32e5f3,_0x4ac45d,_0x11ec01){this['onDisconnect']=_0x4ac45d,this['urlFn']=_0x11ec01,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x1ca26f,window[ah+this['uniqueCallbackIdentifier']]=_0x32e5f3,this['myIFrame']=zi['createIFrame_']();let _0x50d0db='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x50d0db='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x50e965='<html><body>'+_0x50d0db+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x50e965),this['myIFrame']['doc']['close']();}catch(_0x2419dc){L('frame\x20writing\x20exception'),_0x2419dc['stack']&&L(_0x2419dc['stack']),L(_0x2419dc);}}}static['createIFrame_'](){const _0x5bb5fd=document['createElement']('iframe');if(_0x5bb5fd['style']['display']='none',document['body']){document['body']['appendChild'](_0x5bb5fd);try{_0x5bb5fd['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x1241ac=document['domain'];_0x5bb5fd['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x1241ac+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x5bb5fd['contentDocument']?_0x5bb5fd['doc']=_0x5bb5fd['contentDocument']:_0x5bb5fd['contentWindow']?_0x5bb5fd['doc']=_0x5bb5fd['contentWindow']['document']:_0x5bb5fd['document']&&(_0x5bb5fd['doc']=_0x5bb5fd['document']),_0x5bb5fd;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x8c6db3=this['onDisconnect'];_0x8c6db3&&(this['onDisconnect']=null,_0x8c6db3());}['startLongPoll'](_0x36c7e,_0x14df67){for(this['myID']=_0x36c7e,this['myPW']=_0x14df67,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0xd7af8a={};_0xd7af8a[Eo]=this['myID'],_0xd7af8a[Io]=this['myPW'],_0xd7af8a[wo]=this['currentSerial'];let _0x3aeca6=this['urlFn'](_0xd7af8a),_0xb44e63='',_0x2fd0d5=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0xb44e63['length']<=Co;){const _0xb86883=this['pendingSegs']['shift']();_0xb44e63=_0xb44e63+'&'+lh+_0x2fd0d5+'='+_0xb86883['seg']+'&'+hh+_0x2fd0d5+'='+_0xb86883['ts']+'&'+uh+_0x2fd0d5+'='+_0xb86883['d'],_0x2fd0d5++;}return _0x3aeca6=_0x3aeca6+_0xb44e63,this['addLongPollTag_'](_0x3aeca6,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x178e76,_0x4d0221,_0x1836f6){this['pendingSegs']['push']({'seg':_0x178e76,'ts':_0x4d0221,'d':_0x1836f6}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x1c1302,_0xa2ffb9){this['outstandingRequests']['add'](_0xa2ffb9);const _0x122f42=()=>{this['outstandingRequests']['delete'](_0xa2ffb9),this['newRequest_']();},_0x49f726=setTimeout(_0x122f42,Math['floor'](ph)),_0x5ee29d=()=>{clearTimeout(_0x49f726),_0x122f42();};this['addTag'](_0x1c1302,_0x5ee29d);}['addTag'](_0x266138,_0x315739){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x3e205b=this['myIFrame']['doc']['createElement']('script');_0x3e205b['type']='text/javascript',_0x3e205b['async']=!0x0,_0x3e205b['src']=_0x266138,_0x3e205b['onload']=_0x3e205b['onreadystatechange']=function(){const _0x1351c9=_0x3e205b['readyState'];(!_0x1351c9||_0x1351c9==='loaded'||_0x1351c9==='complete')&&(_0x3e205b['onload']=_0x3e205b['onreadystatechange']=null,_0x3e205b['parentNode']&&_0x3e205b['parentNode']['removeChild'](_0x3e205b),_0x315739());},_0x3e205b['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x266138),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x3e205b);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0xaa95ab,_0x1e4b35,_0x4de73c,_0x3c7e44,_0x5953f4,_0x5a22b1,_0x4f06f1){this['connId']=_0xaa95ab,this['applicationId']=_0x4de73c,this['appCheckToken']=_0x3c7e44,this['authToken']=_0x5953f4,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x1e4b35),this['connURL']=q['connectionURL_'](_0x1e4b35,_0x5a22b1,_0x4f06f1,_0x3c7e44,_0x4de73c),this['nodeAdmin']=_0x1e4b35['nodeAdmin'];}static['connectionURL_'](_0x193164,_0x1429d3,_0x2e01ea,_0x2fef5d,_0x591697){const _0x329a11={};return _0x329a11[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x329a11[ho]=uo),_0x1429d3&&(_0x329a11[lo]=_0x1429d3),_0x2e01ea&&(_0x329a11[po]=_0x2e01ea),_0x2fef5d&&(_0x329a11[wi]=_0x2fef5d),_0x591697&&(_0x329a11[_o]=_0x591697),vo(_0x193164,go,_0x329a11);}['open'](_0x3ad06c,_0x15b1d7){this['onDisconnect']=_0x15b1d7,this['onMessage']=_0x3ad06c,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x4fd12e;_c(),this['mySock']=new gn(this['connURL'],[],_0x4fd12e);}catch(_0xcd8841){this['log_']('Error\x20instantiating\x20WebSocket.');const _0xab23cf=_0xcd8841['message']||_0xcd8841['data'];_0xab23cf&&this['log_'](_0xab23cf),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0xe58fc=>{this['handleIncomingFrame'](_0xe58fc);},this['mySock']['onerror']=_0x3e9cdb=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x37aed3=_0x3e9cdb['message']||_0x3e9cdb['data'];_0x37aed3&&this['log_'](_0x37aed3),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x2617cc=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x2640aa=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x198b2e=navigator['userAgent']['match'](_0x2640aa);_0x198b2e&&_0x198b2e['length']>0x1&&parseFloat(_0x198b2e[0x1])<4.4&&(_0x2617cc=!0x0);}return!_0x2617cc&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x28935e){if(this['frames']['push'](_0x28935e),this['frames']['length']===this['totalFrames']){const _0x32d353=this['frames']['join']('');this['frames']=null;const _0xbb858c=Nt(_0x32d353);this['onMessage'](_0xbb858c);}}['handleNewFrameCount_'](_0x48d1dc){this['totalFrames']=_0x48d1dc,this['frames']=[];}['extractFrameCount_'](_0x4af1f8){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x4af1f8['length']<=0x6){const _0x23980e=Number(_0x4af1f8);if(!isNaN(_0x23980e))return this['handleNewFrameCount_'](_0x23980e),null;}return this['handleNewFrameCount_'](0x1),_0x4af1f8;}['handleIncomingFrame'](_0x404998){if(this['mySock']===null)return;const _0x499b65=_0x404998['data'];if(this['bytesReceived']+=_0x499b65['length'],this['stats_']['incrementCounter']('bytes_received',_0x499b65['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x499b65);else{const _0x504b06=this['extractFrameCount_'](_0x499b65);_0x504b06!==null&&this['appendFrame_'](_0x504b06);}}['send'](_0x1fc924){this['resetKeepAlive']();const _0xa74a04=O(_0x1fc924);this['bytesSent']+=_0xa74a04['length'],this['stats_']['incrementCounter']('bytes_sent',_0xa74a04['length']);const _0x4d45a7=oo(_0xa74a04,gh);_0x4d45a7['length']>0x1&&this['sendString_'](String(_0x4d45a7['length']));for(let _0x61a5db=0x0;_0x61a5db<_0x4d45a7['length'];_0x61a5db++)this['sendString_'](_0x4d45a7[_0x61a5db]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x47bcda){try{this['mySock']['send'](_0x47bcda);}catch(_0x219e4b){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x219e4b['message']||_0x219e4b['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x280461){this['initTransports_'](_0x280461);}['initTransports_'](_0x29d9e1){const _0x2be71b=q&&q['isAvailable']();let _0x2c8aca=_0x2be71b&&!q['previouslyFailed']();if(_0x29d9e1['webSocketOnly']&&(_0x2be71b||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x2c8aca=!0x0),_0x2c8aca)this['transports_']=[q];else{const _0x4ed405=this['transports_']=[];for(const _0x231b06 of Dt['ALL_TRANSPORTS'])_0x231b06&&_0x231b06['isAvailable']()&&_0x4ed405['push'](_0x231b06);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x441b35,_0x356b71,_0x1d5481,_0x2308ad,_0xec7129,_0x22c016,_0xd70f9f,_0x1815cd,_0x18144a,_0x163248){this['id']=_0x441b35,this['repoInfo_']=_0x356b71,this['applicationId_']=_0x1d5481,this['appCheckToken_']=_0x2308ad,this['authToken_']=_0xec7129,this['onMessage_']=_0x22c016,this['onReady_']=_0xd70f9f,this['onDisconnect_']=_0x1815cd,this['onKill_']=_0x18144a,this['lastSessionId']=_0x163248,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x356b71),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x1a36db=this['transportManager_']['initialTransport']();this['conn_']=new _0x1a36db(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x1a36db['responsesRequiredToBeHealthy']||0x0;const _0x1b848f=this['connReceiver_'](this['conn_']),_0x499c2e=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x1b848f,_0x499c2e);},Math['floor'](0x0));const _0x192f48=_0x1a36db['healthyTimeout']||0x0;_0x192f48>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x192f48)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x1ad8c8){return _0x329632=>{_0x1ad8c8===this['conn_']?this['onConnectionLost_'](_0x329632):_0x1ad8c8===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x368c84){return _0x5df47b=>{this['state_']!==0x2&&(_0x368c84===this['rx_']?this['onPrimaryMessageReceived_'](_0x5df47b):_0x368c84===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x5df47b):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x5d5d33){const _0x4b2399={'t':'d','d':_0x5d5d33};this['sendData_'](_0x4b2399);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x37df8d){if(ci in _0x37df8d){const _0x4920e4=_0x37df8d[ci];_0x4920e4===Ys?this['upgradeIfSecondaryHealthy_']():_0x4920e4===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x4920e4===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x29cc43){const _0x35533c=vt('t',_0x29cc43),_0x31665c=vt('d',_0x29cc43);if(_0x35533c==='c')this['onSecondaryControl_'](_0x31665c);else{if(_0x35533c==='d')this['pendingDataMessages']['push'](_0x31665c);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x35533c);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0xff6454){const _0x34dce1=vt('t',_0xff6454),_0xc75454=vt('d',_0xff6454);_0x34dce1==='c'?this['onControl_'](_0xc75454):_0x34dce1==='d'&&this['onDataMessage_'](_0xc75454);}['onDataMessage_'](_0x331a49){this['onPrimaryResponse_'](),this['onMessage_'](_0x331a49);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x44e598){const _0x31821e=vt(ci,_0x44e598);if(zs in _0x44e598){const _0x3c1281=_0x44e598[zs];if(_0x31821e===Th){const _0x10740c={..._0x3c1281};this['repoInfo_']['isUsingEmulator']&&(_0x10740c['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x10740c);}else{if(_0x31821e===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x47a98c=0x0;_0x47a98c<this['pendingDataMessages']['length'];++_0x47a98c)this['onDataMessage_'](this['pendingDataMessages'][_0x47a98c]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x31821e===wh?this['onConnectionShutdown_'](_0x3c1281):_0x31821e===js?this['onReset_'](_0x3c1281):_0x31821e===Ch?Ii('Server\x20Error:\x20'+_0x3c1281):_0x31821e===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x31821e);}}}['onHandshake_'](_0x48b803){const _0x3b852c=_0x48b803['ts'],_0x1a719d=_0x48b803['v'],_0x169f79=_0x48b803['h'];this['sessionId']=_0x48b803['s'],this['repoInfo_']['host']=_0x169f79,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x3b852c),Gi!==_0x1a719d&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x464f76=this['transportManager_']['upgradeTransport']();_0x464f76&&this['startUpgrade_'](_0x464f76);}['startUpgrade_'](_0x1e0c1e){this['secondaryConn_']=new _0x1e0c1e(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x1e0c1e['responsesRequiredToBeHealthy']||0x0;const _0x3142e1=this['connReceiver_'](this['secondaryConn_']),_0x218ca7=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x3142e1,_0x218ca7),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x21b73f){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x21b73f),this['repoInfo_']['host']=_0x21b73f,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x10e11a,_0x33163b){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x10e11a,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x33163b,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x4e6c67=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x4e6c67||this['rx_']===_0x4e6c67)&&this['close']();}['onConnectionLost_'](_0x39b489){this['conn_']=null,!_0x39b489&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x14fdab){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x14fdab),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x3d0416){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x3d0416);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x46d3be,_0x4ad772,_0x5b2c95,_0x4b0784){}['merge'](_0x3d5c8a,_0x3c6b0d,_0x5f4109,_0xf2eba2){}['refreshAuthToken'](_0x48660d){}['refreshAppCheckToken'](_0x571b45){}['onDisconnectPut'](_0x2d70d9,_0x4ed6fb,_0x29161e){}['onDisconnectMerge'](_0x52e003,_0xb4db9a,_0x124271){}['onDisconnectCancel'](_0x5b7b49,_0x1908f9){}['reportStats'](_0x368774){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x729f32){this['allowedEvents_']=_0x729f32,this['listeners_']={},f(Array['isArray'](_0x729f32)&&_0x729f32['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x14739f,..._0x5d6ced){if(Array['isArray'](this['listeners_'][_0x14739f])){const _0x24f4b9=[...this['listeners_'][_0x14739f]];for(let _0x4412da=0x0;_0x4412da<_0x24f4b9['length'];_0x4412da++)_0x24f4b9[_0x4412da]['callback']['apply'](_0x24f4b9[_0x4412da]['context'],_0x5d6ced);}}['on'](_0x5a8e50,_0x15bfbd,_0x5763a1){this['validateEventType_'](_0x5a8e50),this['listeners_'][_0x5a8e50]=this['listeners_'][_0x5a8e50]||[],this['listeners_'][_0x5a8e50]['push']({'callback':_0x15bfbd,'context':_0x5763a1});const _0x362735=this['getInitialEvent'](_0x5a8e50);_0x362735&&_0x15bfbd['apply'](_0x5763a1,_0x362735);}['off'](_0x5d06a2,_0x4cb43c,_0x3130dd){this['validateEventType_'](_0x5d06a2);const _0x504750=this['listeners_'][_0x5d06a2]||[];for(let _0x2b1170=0x0;_0x2b1170<_0x504750['length'];_0x2b1170++)if(_0x504750[_0x2b1170]['callback']===_0x4cb43c&&(!_0x3130dd||_0x3130dd===_0x504750[_0x2b1170]['context'])){_0x504750['splice'](_0x2b1170,0x1);return;}}['validateEventType_'](_0x54c97a){f(this['allowedEvents_']['find'](_0x215f1a=>_0x215f1a===_0x54c97a),'Unknown\x20event:\x20'+_0x54c97a);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x423e2){return f(_0x423e2==='online','Unknown\x20event\x20type:\x20'+_0x423e2),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x1c1af5,_0x38ad36){if(_0x38ad36===void 0x0){this['pieces_']=_0x1c1af5['split']('/');let _0x1be5bd=0x0;for(let _0x2b997c=0x0;_0x2b997c<this['pieces_']['length'];_0x2b997c++)this['pieces_'][_0x2b997c]['length']>0x0&&(this['pieces_'][_0x1be5bd]=this['pieces_'][_0x2b997c],_0x1be5bd++);this['pieces_']['length']=_0x1be5bd,this['pieceNum_']=0x0;}else this['pieces_']=_0x1c1af5,this['pieceNum_']=_0x38ad36;}['toString'](){let _0x5b2ddc='';for(let _0x26748e=this['pieceNum_'];_0x26748e<this['pieces_']['length'];_0x26748e++)this['pieces_'][_0x26748e]!==''&&(_0x5b2ddc+='/'+this['pieces_'][_0x26748e]);return _0x5b2ddc||'/';}}function w(){return new C('');}function y(_0x2e4581){return _0x2e4581['pieceNum_']>=_0x2e4581['pieces_']['length']?null:_0x2e4581['pieces_'][_0x2e4581['pieceNum_']];}function Ce(_0xc72762){return _0xc72762['pieces_']['length']-_0xc72762['pieceNum_'];}function S(_0x582aec){let _0x188c8b=_0x582aec['pieceNum_'];return _0x188c8b<_0x582aec['pieces_']['length']&&_0x188c8b++,new C(_0x582aec['pieces_'],_0x188c8b);}function ji(_0x5797ea){return _0x5797ea['pieceNum_']<_0x5797ea['pieces_']['length']?_0x5797ea['pieces_'][_0x5797ea['pieces_']['length']-0x1]:null;}function bh(_0x2aff89){let _0x5c0ecc='';for(let _0x143c55=_0x2aff89['pieceNum_'];_0x143c55<_0x2aff89['pieces_']['length'];_0x143c55++)_0x2aff89['pieces_'][_0x143c55]!==''&&(_0x5c0ecc+='/'+encodeURIComponent(String(_0x2aff89['pieces_'][_0x143c55])));return _0x5c0ecc||'/';}function Mt(_0x135a64,_0x14e87a=0x0){return _0x135a64['pieces_']['slice'](_0x135a64['pieceNum_']+_0x14e87a);}function Ro(_0x348e91){if(_0x348e91['pieceNum_']>=_0x348e91['pieces_']['length'])return null;const _0x433a75=[];for(let _0x2e0904=_0x348e91['pieceNum_'];_0x2e0904<_0x348e91['pieces_']['length']-0x1;_0x2e0904++)_0x433a75['push'](_0x348e91['pieces_'][_0x2e0904]);return new C(_0x433a75,0x0);}function k(_0x550a5d,_0x35432b){const _0x262651=[];for(let _0x42fce2=_0x550a5d['pieceNum_'];_0x42fce2<_0x550a5d['pieces_']['length'];_0x42fce2++)_0x262651['push'](_0x550a5d['pieces_'][_0x42fce2]);if(_0x35432b instanceof C){for(let _0x1e3035=_0x35432b['pieceNum_'];_0x1e3035<_0x35432b['pieces_']['length'];_0x1e3035++)_0x262651['push'](_0x35432b['pieces_'][_0x1e3035]);}else{const _0x12a17a=_0x35432b['split']('/');for(let _0x21888d=0x0;_0x21888d<_0x12a17a['length'];_0x21888d++)_0x12a17a[_0x21888d]['length']>0x0&&_0x262651['push'](_0x12a17a[_0x21888d]);}return new C(_0x262651,0x0);}function v(_0x4132a8){return _0x4132a8['pieceNum_']>=_0x4132a8['pieces_']['length'];}function F(_0xeb279c,_0x309d5b){const _0x3c9c07=y(_0xeb279c),_0x506dfa=y(_0x309d5b);if(_0x3c9c07===null)return _0x309d5b;if(_0x3c9c07===_0x506dfa)return F(S(_0xeb279c),S(_0x309d5b));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x309d5b+')\x20is\x20not\x20within\x20outerPath\x20('+_0xeb279c+')');}function Rh(_0x3cbf04,_0x58db97){const _0x693490=Mt(_0x3cbf04,0x0),_0x5a5381=Mt(_0x58db97,0x0);for(let _0x4a0052=0x0;_0x4a0052<_0x693490['length']&&_0x4a0052<_0x5a5381['length'];_0x4a0052++){const _0x5ba396=qe(_0x693490[_0x4a0052],_0x5a5381[_0x4a0052]);if(_0x5ba396!==0x0)return _0x5ba396;}return _0x693490['length']===_0x5a5381['length']?0x0:_0x693490['length']<_0x5a5381['length']?-0x1:0x1;}function Ki(_0x33ea9f,_0x334fbe){if(Ce(_0x33ea9f)!==Ce(_0x334fbe))return!0x1;for(let _0x32ef78=_0x33ea9f['pieceNum_'],_0xc54aaf=_0x334fbe['pieceNum_'];_0x32ef78<=_0x33ea9f['pieces_']['length'];_0x32ef78++,_0xc54aaf++)if(_0x33ea9f['pieces_'][_0x32ef78]!==_0x334fbe['pieces_'][_0xc54aaf])return!0x1;return!0x0;}function G(_0x3d7639,_0x4bf682){let _0x13e8a5=_0x3d7639['pieceNum_'],_0x492652=_0x4bf682['pieceNum_'];if(Ce(_0x3d7639)>Ce(_0x4bf682))return!0x1;for(;_0x13e8a5<_0x3d7639['pieces_']['length'];){if(_0x3d7639['pieces_'][_0x13e8a5]!==_0x4bf682['pieces_'][_0x492652])return!0x1;++_0x13e8a5,++_0x492652;}return!0x0;}class Ah{constructor(_0x16b484,_0x3a7200){this['errorPrefix_']=_0x3a7200,this['parts_']=Mt(_0x16b484,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x1d2a99=0x0;_0x1d2a99<this['parts_']['length'];_0x1d2a99++)this['byteLength_']+=Ln(this['parts_'][_0x1d2a99]);Ao(this);}}function kh(_0x2242aa,_0x2446c3){_0x2242aa['parts_']['length']>0x0&&(_0x2242aa['byteLength_']+=0x1),_0x2242aa['parts_']['push'](_0x2446c3),_0x2242aa['byteLength_']+=Ln(_0x2446c3),Ao(_0x2242aa);}function Ph(_0x5497f8){const _0x460f4b=_0x5497f8['parts_']['pop']();_0x5497f8['byteLength_']-=Ln(_0x460f4b),_0x5497f8['parts_']['length']>0x0&&(_0x5497f8['byteLength_']-=0x1);}function Ao(_0xd4b006){if(_0xd4b006['byteLength_']>Zs)throw new Error(_0xd4b006['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0xd4b006['byteLength_']+').');if(_0xd4b006['parts_']['length']>Xs)throw new Error(_0xd4b006['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0xd4b006));}function Oe(_0x22a3ce){return _0x22a3ce['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x22a3ce['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x1ea27f,_0x1f9bac;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x1f9bac='visibilitychange',_0x1ea27f='hidden'):typeof document['mozHidden']<'u'?(_0x1f9bac='mozvisibilitychange',_0x1ea27f='mozHidden'):typeof document['msHidden']<'u'?(_0x1f9bac='msvisibilitychange',_0x1ea27f='msHidden'):typeof document['webkitHidden']<'u'&&(_0x1f9bac='webkitvisibilitychange',_0x1ea27f='webkitHidden')),this['visible_']=!0x0,_0x1f9bac&&document['addEventListener'](_0x1f9bac,()=>{const _0x416b35=!document[_0x1ea27f];_0x416b35!==this['visible_']&&(this['visible_']=_0x416b35,this['trigger']('visible',_0x416b35));},!0x1);}['getInitialEvent'](_0x59ff15){return f(_0x59ff15==='visible','Unknown\x20event\x20type:\x20'+_0x59ff15),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x4618cd,_0x5b1f72,_0xfb2fe6,_0x27adc8,_0x3ab418,_0x261c03,_0x357e43,_0x4e4e89){if(super(),this['repoInfo_']=_0x4618cd,this['applicationId_']=_0x5b1f72,this['onDataUpdate_']=_0xfb2fe6,this['onConnectStatus_']=_0x27adc8,this['onServerInfoUpdate_']=_0x3ab418,this['authTokenProvider_']=_0x261c03,this['appCheckTokenProvider_']=_0x357e43,this['authOverride_']=_0x4e4e89,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x4e4e89)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x4618cd['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x4a2e29,_0xced658,_0x1403d0){const _0x18c7d0=++this['requestNumber_'],_0x33546e={'r':_0x18c7d0,'a':_0x4a2e29,'b':_0xced658};this['log_'](O(_0x33546e)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x33546e),_0x1403d0&&(this['requestCBHash_'][_0x18c7d0]=_0x1403d0);}['get'](_0x3378d1){this['initConnection_']();const _0x24e220=new H(),_0x425233={'action':'g','request':{'p':_0x3378d1['_path']['toString'](),'q':_0x3378d1['_queryObject']},'onComplete':_0x2205fc=>{const _0x4eb608=_0x2205fc['d'];_0x2205fc['s']==='ok'?_0x24e220['resolve'](_0x4eb608):_0x24e220['reject'](_0x4eb608);}};this['outstandingGets_']['push'](_0x425233),this['outstandingGetCount_']++;const _0x2d3b93=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x2d3b93),_0x24e220['promise'];}['listen'](_0x1f436f,_0x38cbbf,_0x4942ca,_0x4ad9a3){this['initConnection_']();const _0x2db140=_0x1f436f['_queryIdentifier'],_0x483a4f=_0x1f436f['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x483a4f+'\x20'+_0x2db140),this['listens']['has'](_0x483a4f)||this['listens']['set'](_0x483a4f,new Map()),f(_0x1f436f['_queryParams']['isDefault']()||!_0x1f436f['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x483a4f)['has'](_0x2db140),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x36a531={'onComplete':_0x4ad9a3,'hashFn':_0x38cbbf,'query':_0x1f436f,'tag':_0x4942ca};this['listens']['get'](_0x483a4f)['set'](_0x2db140,_0x36a531),this['connected_']&&this['sendListen_'](_0x36a531);}['sendGet_'](_0x4691ac){const _0x2a0353=this['outstandingGets_'][_0x4691ac];this['sendRequest']('g',_0x2a0353['request'],_0x236485=>{delete this['outstandingGets_'][_0x4691ac],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x2a0353['onComplete']&&_0x2a0353['onComplete'](_0x236485);});}['sendListen_'](_0x496535){const _0x253b75=_0x496535['query'],_0x48a84e=_0x253b75['_path']['toString'](),_0x40f6ad=_0x253b75['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x48a84e+'\x20for\x20'+_0x40f6ad);const _0x4e0664={'p':_0x48a84e},_0x4bf225='q';_0x496535['tag']&&(_0x4e0664['q']=_0x253b75['_queryObject'],_0x4e0664['t']=_0x496535['tag']),_0x4e0664['h']=_0x496535['hashFn'](),this['sendRequest'](_0x4bf225,_0x4e0664,_0x24a11e=>{const _0x1a4321=_0x24a11e['d'],_0x571b56=_0x24a11e['s'];se['warnOnListenWarnings_'](_0x1a4321,_0x253b75),(this['listens']['get'](_0x48a84e)&&this['listens']['get'](_0x48a84e)['get'](_0x40f6ad))===_0x496535&&(this['log_']('listen\x20response',_0x24a11e),_0x571b56!=='ok'&&this['removeListen_'](_0x48a84e,_0x40f6ad),_0x496535['onComplete']&&_0x496535['onComplete'](_0x571b56,_0x1a4321));});}static['warnOnListenWarnings_'](_0x8bb1bf,_0x5baad4){if(_0x8bb1bf&&typeof _0x8bb1bf=='object'&&Q(_0x8bb1bf,'w')){const _0xde1479=Le(_0x8bb1bf,'w');if(Array['isArray'](_0xde1479)&&~_0xde1479['indexOf']('no_index')){const _0x287cdc='\x22.indexOn\x22:\x20\x22'+_0x5baad4['_queryParams']['getIndex']()['toString']()+'\x22',_0x49fc4b=_0x5baad4['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x287cdc+'\x20at\x20'+_0x49fc4b+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x38d57c){this['authToken_']=_0x38d57c,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x38d57c);}['reduceReconnectDelayIfAdminCredential_'](_0x3e655e){(_0x3e655e&&_0x3e655e['length']===0x28||wc(_0x3e655e))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x525724){this['appCheckToken_']=_0x525724,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x2ee27d=this['authToken_'],_0x5cc834=Ic(_0x2ee27d)?'auth':'gauth',_0x554eb9={'cred':_0x2ee27d};this['authOverride_']===null?_0x554eb9['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x554eb9['authvar']=this['authOverride_']),this['sendRequest'](_0x5cc834,_0x554eb9,_0x17789c=>{const _0x32d9ad=_0x17789c['s'],_0x291990=_0x17789c['d']||'error';this['authToken_']===_0x2ee27d&&(_0x32d9ad==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x32d9ad,_0x291990));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x74d97d=>{const _0x1ff7d1=_0x74d97d['s'],_0x637e22=_0x74d97d['d']||'error';_0x1ff7d1==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x1ff7d1,_0x637e22);});}['unlisten'](_0x2633b3,_0x36b6cf){const _0x161853=_0x2633b3['_path']['toString'](),_0x1faecb=_0x2633b3['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x161853+'\x20'+_0x1faecb),f(_0x2633b3['_queryParams']['isDefault']()||!_0x2633b3['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x161853,_0x1faecb)&&this['connected_']&&this['sendUnlisten_'](_0x161853,_0x1faecb,_0x2633b3['_queryObject'],_0x36b6cf);}['sendUnlisten_'](_0x1e31b3,_0x23c789,_0x19ac93,_0x831109){this['log_']('Unlisten\x20on\x20'+_0x1e31b3+'\x20for\x20'+_0x23c789);const _0x589fb1={'p':_0x1e31b3},_0x5ee518='n';_0x831109&&(_0x589fb1['q']=_0x19ac93,_0x589fb1['t']=_0x831109),this['sendRequest'](_0x5ee518,_0x589fb1);}['onDisconnectPut'](_0x213145,_0x26b391,_0x110064){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x213145,_0x26b391,_0x110064):this['onDisconnectRequestQueue_']['push']({'pathString':_0x213145,'action':'o','data':_0x26b391,'onComplete':_0x110064});}['onDisconnectMerge'](_0x16967c,_0x4c18da,_0x414dd8){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x16967c,_0x4c18da,_0x414dd8):this['onDisconnectRequestQueue_']['push']({'pathString':_0x16967c,'action':'om','data':_0x4c18da,'onComplete':_0x414dd8});}['onDisconnectCancel'](_0x151b3,_0x129b6d){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x151b3,null,_0x129b6d):this['onDisconnectRequestQueue_']['push']({'pathString':_0x151b3,'action':'oc','data':null,'onComplete':_0x129b6d});}['sendOnDisconnect_'](_0x1e17c8,_0x220539,_0x252f81,_0x4a295a){const _0x1af8e0={'p':_0x220539,'d':_0x252f81};this['log_']('onDisconnect\x20'+_0x1e17c8,_0x1af8e0),this['sendRequest'](_0x1e17c8,_0x1af8e0,_0x426d81=>{_0x4a295a&&setTimeout(()=>{_0x4a295a(_0x426d81['s'],_0x426d81['d']);},Math['floor'](0x0));});}['put'](_0x47674e,_0x3cffc8,_0x111b64,_0x390508){this['putInternal']('p',_0x47674e,_0x3cffc8,_0x111b64,_0x390508);}['merge'](_0x18aa2d,_0x5100cd,_0x356433,_0x81e44a){this['putInternal']('m',_0x18aa2d,_0x5100cd,_0x356433,_0x81e44a);}['putInternal'](_0x4a2a2d,_0x301084,_0x1b0f5a,_0x38aaac,_0x2152eb){this['initConnection_']();const _0x18b139={'p':_0x301084,'d':_0x1b0f5a};_0x2152eb!==void 0x0&&(_0x18b139['h']=_0x2152eb),this['outstandingPuts_']['push']({'action':_0x4a2a2d,'request':_0x18b139,'onComplete':_0x38aaac}),this['outstandingPutCount_']++;const _0x3b9cf3=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x3b9cf3):this['log_']('Buffering\x20put:\x20'+_0x301084);}['sendPut_'](_0x360046){const _0xfa1fcf=this['outstandingPuts_'][_0x360046]['action'],_0x42f9c6=this['outstandingPuts_'][_0x360046]['request'],_0x4f1eb9=this['outstandingPuts_'][_0x360046]['onComplete'];this['outstandingPuts_'][_0x360046]['queued']=this['connected_'],this['sendRequest'](_0xfa1fcf,_0x42f9c6,_0x5f0034=>{this['log_'](_0xfa1fcf+'\x20response',_0x5f0034),delete this['outstandingPuts_'][_0x360046],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x4f1eb9&&_0x4f1eb9(_0x5f0034['s'],_0x5f0034['d']);});}['reportStats'](_0x1fd424){if(this['connected_']){const _0x2aed02={'c':_0x1fd424};this['log_']('reportStats',_0x2aed02),this['sendRequest']('s',_0x2aed02,_0x39491e=>{if(_0x39491e['s']!=='ok'){const _0x304e8b=_0x39491e['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x304e8b);}});}}['onDataMessage_'](_0x11c0bf){if('r'in _0x11c0bf){this['log_']('from\x20server:\x20'+O(_0x11c0bf));const _0xd7fc44=_0x11c0bf['r'],_0x108448=this['requestCBHash_'][_0xd7fc44];_0x108448&&(delete this['requestCBHash_'][_0xd7fc44],_0x108448(_0x11c0bf['b']));}else{if('error'in _0x11c0bf)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x11c0bf['error'];'a'in _0x11c0bf&&this['onDataPush_'](_0x11c0bf['a'],_0x11c0bf['b']);}}['onDataPush_'](_0x3d23be,_0x3487c3){this['log_']('handleServerMessage',_0x3d23be,_0x3487c3),_0x3d23be==='d'?this['onDataUpdate_'](_0x3487c3['p'],_0x3487c3['d'],!0x1,_0x3487c3['t']):_0x3d23be==='m'?this['onDataUpdate_'](_0x3487c3['p'],_0x3487c3['d'],!0x0,_0x3487c3['t']):_0x3d23be==='c'?this['onListenRevoked_'](_0x3487c3['p'],_0x3487c3['q']):_0x3d23be==='ac'?this['onAuthRevoked_'](_0x3487c3['s'],_0x3487c3['d']):_0x3d23be==='apc'?this['onAppCheckRevoked_'](_0x3487c3['s'],_0x3487c3['d']):_0x3d23be==='sd'?this['onSecurityDebugPacket_'](_0x3487c3):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x3d23be)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x4a8238,_0x4cd563){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x4a8238),this['lastSessionId']=_0x4cd563,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x26a9ea){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x26a9ea));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x31a4f1){_0x31a4f1&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x31a4f1;}['onOnline_'](_0x5151e9){_0x5151e9?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x5a1677=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x979579=Math['max'](0x0,this['reconnectDelay_']-_0x5a1677);_0x979579=Math['random']()*_0x979579,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x979579+'ms'),this['scheduleConnect_'](_0x979579),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x1678f0=this['onDataMessage_']['bind'](this),_0x400c6e=this['onReady_']['bind'](this),_0x1b6af5=this['onRealtimeDisconnect_']['bind'](this),_0x1da522=this['id']+':'+se['nextConnectionId_']++,_0x24b447=this['lastSessionId'];let _0x3642b2=!0x1,_0x459567=null;const _0xff858=function(){_0x459567?_0x459567['close']():(_0x3642b2=!0x0,_0x1b6af5());},_0x43ffd9=function(_0x493245){f(_0x459567,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x459567['sendRequest'](_0x493245);};this['realtime_']={'close':_0xff858,'sendRequest':_0x43ffd9};const _0x15b65c=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x5200f9,_0x2cc5dd]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x15b65c),this['appCheckTokenProvider_']['getToken'](_0x15b65c)]);_0x3642b2?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x5200f9&&_0x5200f9['accessToken'],this['appCheckToken_']=_0x2cc5dd&&_0x2cc5dd['token'],_0x459567=new Sh(_0x1da522,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x1678f0,_0x400c6e,_0x1b6af5,_0x41c903=>{U(_0x41c903+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x24b447));}catch(_0x1033d6){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x1033d6),_0x3642b2||(this['repoInfo_']['nodeAdmin']&&U(_0x1033d6),_0xff858());}}}['interrupt'](_0x44555a){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x44555a),this['interruptReasons_'][_0x44555a]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x57fce0){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x57fce0),delete this['interruptReasons_'][_0x57fce0],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x5971b4){const _0x14adaf=_0x5971b4-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x14adaf});}['cancelSentTransactions_'](){for(let _0xc41a06=0x0;_0xc41a06<this['outstandingPuts_']['length'];_0xc41a06++){const _0x1b667d=this['outstandingPuts_'][_0xc41a06];_0x1b667d&&'h'in _0x1b667d['request']&&_0x1b667d['queued']&&(_0x1b667d['onComplete']&&_0x1b667d['onComplete']('disconnect'),delete this['outstandingPuts_'][_0xc41a06],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x97ba69,_0x5007b3){let _0x548eb4;_0x5007b3?_0x548eb4=_0x5007b3['map'](_0x15e6e7=>$i(_0x15e6e7))['join']('$'):_0x548eb4='default';const _0x33ad99=this['removeListen_'](_0x97ba69,_0x548eb4);_0x33ad99&&_0x33ad99['onComplete']&&_0x33ad99['onComplete']('permission_denied');}['removeListen_'](_0xb7e9fa,_0x278459){const _0x468003=new C(_0xb7e9fa)['toString']();let _0x57ba7a;if(this['listens']['has'](_0x468003)){const _0x3902a4=this['listens']['get'](_0x468003);_0x57ba7a=_0x3902a4['get'](_0x278459),_0x3902a4['delete'](_0x278459),_0x3902a4['size']===0x0&&this['listens']['delete'](_0x468003);}else _0x57ba7a=void 0x0;return _0x57ba7a;}['onAuthRevoked_'](_0x5971cd,_0x3baeb1){L('Auth\x20token\x20revoked:\x20'+_0x5971cd+'/'+_0x3baeb1),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x5971cd==='invalid_token'||_0x5971cd==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x4e7e2e,_0x3ff55d){L('App\x20check\x20token\x20revoked:\x20'+_0x4e7e2e+'/'+_0x3ff55d),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x4e7e2e==='invalid_token'||_0x4e7e2e==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x3c59db){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x3c59db):'msg'in _0x3c59db&&console['log']('FIREBASE:\x20'+_0x3c59db['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x382eba of this['listens']['values']())for(const _0x37799d of _0x382eba['values']())this['sendListen_'](_0x37799d);for(let _0x193681=0x0;_0x193681<this['outstandingPuts_']['length'];_0x193681++)this['outstandingPuts_'][_0x193681]&&this['sendPut_'](_0x193681);for(;this['onDisconnectRequestQueue_']['length'];){const _0xe716e2=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0xe716e2['action'],_0xe716e2['pathString'],_0xe716e2['data'],_0xe716e2['onComplete']);}for(let _0x45c162=0x0;_0x45c162<this['outstandingGets_']['length'];_0x45c162++)this['outstandingGets_'][_0x45c162]&&this['sendGet_'](_0x45c162);}['sendConnectStats_'](){const _0x3fbbd6={};let _0x3e1c65='js';_0x3fbbd6['sdk.'+_0x3e1c65+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x3fbbd6['framework.cordova']=0x1:Kr()&&(_0x3fbbd6['framework.reactnative']=0x1),this['reportStats'](_0x3fbbd6);}['shouldReconnect_'](){const _0x3e3d4f=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x3e3d4f;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x592c07,_0x293d6b){this['name']=_0x592c07,this['node']=_0x293d6b;}static['Wrap'](_0xa6f748,_0x59a174){return new E(_0xa6f748,_0x59a174);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x2df467,_0x19c224){const _0x47a8e5=new E(We,_0x2df467),_0x397f0c=new E(We,_0x19c224);return this['compare'](_0x47a8e5,_0x397f0c)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x21b583){sn=_0x21b583;}['compare'](_0x8b28b2,_0x3684ca){return qe(_0x8b28b2['name'],_0x3684ca['name']);}['isDefinedOn'](_0x5dfb2e){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x51bb43,_0x4ad816){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x4318b6,_0x4572c0){return f(typeof _0x4318b6=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x4318b6,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x257ac3,_0x5aeb4c,_0x2978b7,_0x3c1e52,_0x437ee1=null){this['isReverse_']=_0x3c1e52,this['resultGenerator_']=_0x437ee1,this['nodeStack_']=[];let _0x471e48=0x1;for(;!_0x257ac3['isEmpty']();)if(_0x257ac3=_0x257ac3,_0x471e48=_0x5aeb4c?_0x2978b7(_0x257ac3['key'],_0x5aeb4c):0x1,_0x3c1e52&&(_0x471e48*=-0x1),_0x471e48<0x0)this['isReverse_']?_0x257ac3=_0x257ac3['left']:_0x257ac3=_0x257ac3['right'];else{if(_0x471e48===0x0){this['nodeStack_']['push'](_0x257ac3);break;}else this['nodeStack_']['push'](_0x257ac3),this['isReverse_']?_0x257ac3=_0x257ac3['right']:_0x257ac3=_0x257ac3['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x540e28=this['nodeStack_']['pop'](),_0x58d8a9;if(this['resultGenerator_']?_0x58d8a9=this['resultGenerator_'](_0x540e28['key'],_0x540e28['value']):_0x58d8a9={'key':_0x540e28['key'],'value':_0x540e28['value']},this['isReverse_']){for(_0x540e28=_0x540e28['left'];!_0x540e28['isEmpty']();)this['nodeStack_']['push'](_0x540e28),_0x540e28=_0x540e28['right'];}else{for(_0x540e28=_0x540e28['right'];!_0x540e28['isEmpty']();)this['nodeStack_']['push'](_0x540e28),_0x540e28=_0x540e28['left'];}return _0x58d8a9;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x1fb646=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x1fb646['key'],_0x1fb646['value']):{'key':_0x1fb646['key'],'value':_0x1fb646['value']};}}class M{constructor(_0x2b0039,_0x3044aa,_0x16301a,_0x12d76e,_0x6b8b34){this['key']=_0x2b0039,this['value']=_0x3044aa,this['color']=_0x16301a??M['RED'],this['left']=_0x12d76e??B['EMPTY_NODE'],this['right']=_0x6b8b34??B['EMPTY_NODE'];}['copy'](_0x29bc19,_0x48193c,_0x32d638,_0x36deaf,_0x25b1c7){return new M(_0x29bc19??this['key'],_0x48193c??this['value'],_0x32d638??this['color'],_0x36deaf??this['left'],_0x25b1c7??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x10bdfa){return this['left']['inorderTraversal'](_0x10bdfa)||!!_0x10bdfa(this['key'],this['value'])||this['right']['inorderTraversal'](_0x10bdfa);}['reverseTraversal'](_0xd8a1f){return this['right']['reverseTraversal'](_0xd8a1f)||_0xd8a1f(this['key'],this['value'])||this['left']['reverseTraversal'](_0xd8a1f);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x1dfcd5,_0x3ad009,_0x13dc16){let _0x1d6a5f=this;const _0x1d1afc=_0x13dc16(_0x1dfcd5,_0x1d6a5f['key']);return _0x1d1afc<0x0?_0x1d6a5f=_0x1d6a5f['copy'](null,null,null,_0x1d6a5f['left']['insert'](_0x1dfcd5,_0x3ad009,_0x13dc16),null):_0x1d1afc===0x0?_0x1d6a5f=_0x1d6a5f['copy'](null,_0x3ad009,null,null,null):_0x1d6a5f=_0x1d6a5f['copy'](null,null,null,null,_0x1d6a5f['right']['insert'](_0x1dfcd5,_0x3ad009,_0x13dc16)),_0x1d6a5f['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x4cd8d3=this;return!_0x4cd8d3['left']['isRed_']()&&!_0x4cd8d3['left']['left']['isRed_']()&&(_0x4cd8d3=_0x4cd8d3['moveRedLeft_']()),_0x4cd8d3=_0x4cd8d3['copy'](null,null,null,_0x4cd8d3['left']['removeMin_'](),null),_0x4cd8d3['fixUp_']();}['remove'](_0x1d5112,_0x3f24d4){let _0x2abbd2,_0x47e080;if(_0x2abbd2=this,_0x3f24d4(_0x1d5112,_0x2abbd2['key'])<0x0)!_0x2abbd2['left']['isEmpty']()&&!_0x2abbd2['left']['isRed_']()&&!_0x2abbd2['left']['left']['isRed_']()&&(_0x2abbd2=_0x2abbd2['moveRedLeft_']()),_0x2abbd2=_0x2abbd2['copy'](null,null,null,_0x2abbd2['left']['remove'](_0x1d5112,_0x3f24d4),null);else{if(_0x2abbd2['left']['isRed_']()&&(_0x2abbd2=_0x2abbd2['rotateRight_']()),!_0x2abbd2['right']['isEmpty']()&&!_0x2abbd2['right']['isRed_']()&&!_0x2abbd2['right']['left']['isRed_']()&&(_0x2abbd2=_0x2abbd2['moveRedRight_']()),_0x3f24d4(_0x1d5112,_0x2abbd2['key'])===0x0){if(_0x2abbd2['right']['isEmpty']())return B['EMPTY_NODE'];_0x47e080=_0x2abbd2['right']['min_'](),_0x2abbd2=_0x2abbd2['copy'](_0x47e080['key'],_0x47e080['value'],null,null,_0x2abbd2['right']['removeMin_']());}_0x2abbd2=_0x2abbd2['copy'](null,null,null,null,_0x2abbd2['right']['remove'](_0x1d5112,_0x3f24d4));}return _0x2abbd2['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x3e746a=this;return _0x3e746a['right']['isRed_']()&&!_0x3e746a['left']['isRed_']()&&(_0x3e746a=_0x3e746a['rotateLeft_']()),_0x3e746a['left']['isRed_']()&&_0x3e746a['left']['left']['isRed_']()&&(_0x3e746a=_0x3e746a['rotateRight_']()),_0x3e746a['left']['isRed_']()&&_0x3e746a['right']['isRed_']()&&(_0x3e746a=_0x3e746a['colorFlip_']()),_0x3e746a;}['moveRedLeft_'](){let _0x2e8d1a=this['colorFlip_']();return _0x2e8d1a['right']['left']['isRed_']()&&(_0x2e8d1a=_0x2e8d1a['copy'](null,null,null,null,_0x2e8d1a['right']['rotateRight_']()),_0x2e8d1a=_0x2e8d1a['rotateLeft_'](),_0x2e8d1a=_0x2e8d1a['colorFlip_']()),_0x2e8d1a;}['moveRedRight_'](){let _0x4fa5c0=this['colorFlip_']();return _0x4fa5c0['left']['left']['isRed_']()&&(_0x4fa5c0=_0x4fa5c0['rotateRight_'](),_0x4fa5c0=_0x4fa5c0['colorFlip_']()),_0x4fa5c0;}['rotateLeft_'](){const _0x440ef6=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x440ef6,null);}['rotateRight_'](){const _0x246880=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x246880);}['colorFlip_'](){const _0x18d4cd=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x225854=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x18d4cd,_0x225854);}['checkMaxDepth_'](){const _0x27e33a=this['check_']();return Math['pow'](0x2,_0x27e33a)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x55ba52=this['left']['check_']();if(_0x55ba52!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x55ba52+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x31f399,_0x470a92,_0x3ce3e5,_0x108200,_0x58fce9){return this;}['insert'](_0x371bc9,_0x459e3d,_0xb853){return new M(_0x371bc9,_0x459e3d,null);}['remove'](_0x28b61d,_0x1a0635){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x397f90){return!0x1;}['reverseTraversal'](_0x315be5){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x43ce52,_0x4cd62e=B['EMPTY_NODE']){this['comparator_']=_0x43ce52,this['root_']=_0x4cd62e;}['insert'](_0x39b3c8,_0x518606){return new B(this['comparator_'],this['root_']['insert'](_0x39b3c8,_0x518606,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x4c4007){return new B(this['comparator_'],this['root_']['remove'](_0x4c4007,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x1bd854){let _0x31b207,_0x598644=this['root_'];for(;!_0x598644['isEmpty']();){if(_0x31b207=this['comparator_'](_0x1bd854,_0x598644['key']),_0x31b207===0x0)return _0x598644['value'];_0x31b207<0x0?_0x598644=_0x598644['left']:_0x31b207>0x0&&(_0x598644=_0x598644['right']);}return null;}['getPredecessorKey'](_0x1e9eb9){let _0x37eae9,_0x3acf27=this['root_'],_0x5ba247=null;for(;!_0x3acf27['isEmpty']();)if(_0x37eae9=this['comparator_'](_0x1e9eb9,_0x3acf27['key']),_0x37eae9===0x0){if(_0x3acf27['left']['isEmpty']())return _0x5ba247?_0x5ba247['key']:null;for(_0x3acf27=_0x3acf27['left'];!_0x3acf27['right']['isEmpty']();)_0x3acf27=_0x3acf27['right'];return _0x3acf27['key'];}else _0x37eae9<0x0?_0x3acf27=_0x3acf27['left']:_0x37eae9>0x0&&(_0x5ba247=_0x3acf27,_0x3acf27=_0x3acf27['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x18999c){return this['root_']['inorderTraversal'](_0x18999c);}['reverseTraversal'](_0x4da493){return this['root_']['reverseTraversal'](_0x4da493);}['getIterator'](_0x1becf5){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x1becf5);}['getIteratorFrom'](_0x4b4f3a,_0x5ea83b){return new rn(this['root_'],_0x4b4f3a,this['comparator_'],!0x1,_0x5ea83b);}['getReverseIteratorFrom'](_0x404ccf,_0x4da857){return new rn(this['root_'],_0x404ccf,this['comparator_'],!0x0,_0x4da857);}['getReverseIterator'](_0x3062d9){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x3062d9);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x2a40a9,_0x7db6f1){return qe(_0x2a40a9['name'],_0x7db6f1['name']);}function Qi(_0x57ae53,_0x11f013){return qe(_0x57ae53,_0x11f013);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x194c77){Ci=_0x194c77;}const Po=function(_0x56f615){return typeof _0x56f615=='number'?'number:'+ao(_0x56f615):'string:'+_0x56f615;},No=function(_0xf3de7a){if(_0xf3de7a['isLeafNode']()){const _0x5f3ed3=_0xf3de7a['val']();f(typeof _0x5f3ed3=='string'||typeof _0x5f3ed3=='number'||typeof _0x5f3ed3=='object'&&Q(_0x5f3ed3,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0xf3de7a===Ci||_0xf3de7a['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0xf3de7a===Ci||_0xf3de7a['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x2c22bd){nr=_0x2c22bd;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x683306,_0x246534=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x683306,this['priorityNode_']=_0x246534,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x41bbe7){return new D(this['value_'],_0x41bbe7);}['getImmediateChild'](_0x525b2d){return _0x525b2d==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x36d8c8){return v(_0x36d8c8)?this:y(_0x36d8c8)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x37be0b,_0x1b4316){return null;}['updateImmediateChild'](_0x539b13,_0x1105c1){return _0x539b13==='.priority'?this['updatePriority'](_0x1105c1):_0x1105c1['isEmpty']()&&_0x539b13!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x539b13,_0x1105c1)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x2c3d60,_0x5df6a4){const _0x76472a=y(_0x2c3d60);return _0x76472a===null?_0x5df6a4:_0x5df6a4['isEmpty']()&&_0x76472a!=='.priority'?this:(f(_0x76472a!=='.priority'||Ce(_0x2c3d60)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x76472a,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x2c3d60),_0x5df6a4)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x46177e,_0x4ce7d2){return!0x1;}['val'](_0x4f2d7e){return _0x4f2d7e&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x347a46='';this['priorityNode_']['isEmpty']()||(_0x347a46+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x5ebf23=typeof this['value_'];_0x347a46+=_0x5ebf23+':',_0x5ebf23==='number'?_0x347a46+=ao(this['value_']):_0x347a46+=this['value_'],this['lazyHash_']=ro(_0x347a46);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x1e7364){return _0x1e7364===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x1e7364 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x1e7364['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x1e7364));}['compareToLeafNode_'](_0x3c0c4a){const _0x40809e=typeof _0x3c0c4a['value_'],_0x3ebd2d=typeof this['value_'],_0x5c3021=D['VALUE_TYPE_ORDER']['indexOf'](_0x40809e),_0x3f7c2b=D['VALUE_TYPE_ORDER']['indexOf'](_0x3ebd2d);return f(_0x5c3021>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x40809e),f(_0x3f7c2b>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x3ebd2d),_0x5c3021===_0x3f7c2b?_0x3ebd2d==='object'?0x0:this['value_']<_0x3c0c4a['value_']?-0x1:this['value_']===_0x3c0c4a['value_']?0x0:0x1:_0x3f7c2b-_0x5c3021;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x4b6de4){if(_0x4b6de4===this)return!0x0;if(_0x4b6de4['isLeafNode']()){const _0x2ca558=_0x4b6de4;return this['value_']===_0x2ca558['value_']&&this['priorityNode_']['equals'](_0x2ca558['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x23ce5d){Oo=_0x23ce5d;}function Wh(_0x5bd1fa){Do=_0x5bd1fa;}class Bh extends Fn{['compare'](_0x2124ed,_0x5cc8f9){const _0x1ccef1=_0x2124ed['node']['getPriority'](),_0x2c1a1d=_0x5cc8f9['node']['getPriority'](),_0x54c4d1=_0x1ccef1['compareTo'](_0x2c1a1d);return _0x54c4d1===0x0?qe(_0x2124ed['name'],_0x5cc8f9['name']):_0x54c4d1;}['isDefinedOn'](_0xa4a22c){return!_0xa4a22c['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x4cafff,_0x12feae){return!_0x4cafff['getPriority']()['equals'](_0x12feae['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x127df0,_0x40a906){const _0x5e3b16=Oo(_0x127df0);return new E(_0x40a906,new D('[PRIORITY-POST]',_0x5e3b16));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x5c4a7b){const _0x4d3d04=_0x2b75f0=>parseInt(Math['log'](_0x2b75f0)/Vh,0xa),_0x4216c3=_0x196d93=>parseInt(Array(_0x196d93+0x1)['join']('1'),0x2);this['count']=_0x4d3d04(_0x5c4a7b+0x1),this['current_']=this['count']-0x1;const _0x1bd587=_0x4216c3(this['count']);this['bits_']=_0x5c4a7b+0x1&_0x1bd587;}['nextBitIsOne'](){const _0x4f7a51=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x4f7a51;}}const yn=function(_0x575b34,_0x5d9e81,_0x5e0d33,_0x36b306){_0x575b34['sort'](_0x5d9e81);const _0x815cdb=function(_0x2556e0,_0x47d7eb){const _0xb3dda=_0x47d7eb-_0x2556e0;let _0x1a7bc6,_0x3b770e;if(_0xb3dda===0x0)return null;if(_0xb3dda===0x1)return _0x1a7bc6=_0x575b34[_0x2556e0],_0x3b770e=_0x5e0d33?_0x5e0d33(_0x1a7bc6):_0x1a7bc6,new M(_0x3b770e,_0x1a7bc6['node'],M['BLACK'],null,null);{const _0x193fcb=parseInt(_0xb3dda/0x2,0xa)+_0x2556e0,_0x13425d=_0x815cdb(_0x2556e0,_0x193fcb),_0x4b5bc=_0x815cdb(_0x193fcb+0x1,_0x47d7eb);return _0x1a7bc6=_0x575b34[_0x193fcb],_0x3b770e=_0x5e0d33?_0x5e0d33(_0x1a7bc6):_0x1a7bc6,new M(_0x3b770e,_0x1a7bc6['node'],M['BLACK'],_0x13425d,_0x4b5bc);}},_0x36e683=function(_0x166334){let _0x37ea2b=null,_0x236601=null,_0x360038=_0x575b34['length'];const _0x4ac481=function(_0x986c8f,_0x23f992){const _0x517ab8=_0x360038-_0x986c8f,_0x376d7b=_0x360038;_0x360038-=_0x986c8f;const _0x17e134=_0x815cdb(_0x517ab8+0x1,_0x376d7b),_0x2dd634=_0x575b34[_0x517ab8],_0x213c26=_0x5e0d33?_0x5e0d33(_0x2dd634):_0x2dd634;_0x167a77(new M(_0x213c26,_0x2dd634['node'],_0x23f992,null,_0x17e134));},_0x167a77=function(_0x2abc94){_0x37ea2b?(_0x37ea2b['left']=_0x2abc94,_0x37ea2b=_0x2abc94):(_0x236601=_0x2abc94,_0x37ea2b=_0x2abc94);};for(let _0x3830e=0x0;_0x3830e<_0x166334['count'];++_0x3830e){const _0x401a6f=_0x166334['nextBitIsOne'](),_0x8275ac=Math['pow'](0x2,_0x166334['count']-(_0x3830e+0x1));_0x401a6f?_0x4ac481(_0x8275ac,M['BLACK']):(_0x4ac481(_0x8275ac,M['BLACK']),_0x4ac481(_0x8275ac,M['RED']));}return _0x236601;},_0x1bdac5=new Hh(_0x575b34['length']),_0x3b09ee=_0x36e683(_0x1bdac5);return new B(_0x36b306||_0x5d9e81,_0x3b09ee);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x33a2a6,_0x50e1be){this['indexes_']=_0x33a2a6,this['indexSet_']=_0x50e1be;}['get'](_0x313ae9){const _0x51b695=Le(this['indexes_'],_0x313ae9);if(!_0x51b695)throw new Error('No\x20index\x20defined\x20for\x20'+_0x313ae9);return _0x51b695 instanceof B?_0x51b695:null;}['hasIndex'](_0x5b5c90){return Q(this['indexSet_'],_0x5b5c90['toString']());}['addIndex'](_0x31139b,_0x38d7eb){f(_0x31139b!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x489307=[];let _0x579453=!0x1;const _0x1c5f15=_0x38d7eb['getIterator'](E['Wrap']);let _0x3be551=_0x1c5f15['getNext']();for(;_0x3be551;)_0x579453=_0x579453||_0x31139b['isDefinedOn'](_0x3be551['node']),_0x489307['push'](_0x3be551),_0x3be551=_0x1c5f15['getNext']();let _0x45b252;_0x579453?_0x45b252=yn(_0x489307,_0x31139b['getCompare']()):_0x45b252=Qe;const _0x330d03=_0x31139b['toString'](),_0x38616a={...this['indexSet_']};_0x38616a[_0x330d03]=_0x31139b;const _0x1cd002={...this['indexes_']};return _0x1cd002[_0x330d03]=_0x45b252,new te(_0x1cd002,_0x38616a);}['addToIndexes'](_0xf704f3,_0xbaa8a6){const _0x20e34a=_n(this['indexes_'],(_0x117da3,_0x47c191)=>{const _0x3cb789=Le(this['indexSet_'],_0x47c191);if(f(_0x3cb789,'Missing\x20index\x20implementation\x20for\x20'+_0x47c191),_0x117da3===Qe){if(_0x3cb789['isDefinedOn'](_0xf704f3['node'])){const _0x3ab6b2=[],_0x265044=_0xbaa8a6['getIterator'](E['Wrap']);let _0x3c2e21=_0x265044['getNext']();for(;_0x3c2e21;)_0x3c2e21['name']!==_0xf704f3['name']&&_0x3ab6b2['push'](_0x3c2e21),_0x3c2e21=_0x265044['getNext']();return _0x3ab6b2['push'](_0xf704f3),yn(_0x3ab6b2,_0x3cb789['getCompare']());}else return Qe;}else{const _0x30fc62=_0xbaa8a6['get'](_0xf704f3['name']);let _0x14a09b=_0x117da3;return _0x30fc62&&(_0x14a09b=_0x14a09b['remove'](new E(_0xf704f3['name'],_0x30fc62))),_0x14a09b['insert'](_0xf704f3,_0xf704f3['node']);}});return new te(_0x20e34a,this['indexSet_']);}['removeFromIndexes'](_0x2459fe,_0x455035){const _0x564d7b=_n(this['indexes_'],_0x3b38be=>{if(_0x3b38be===Qe)return _0x3b38be;{const _0x1d254e=_0x455035['get'](_0x2459fe['name']);return _0x1d254e?_0x3b38be['remove'](new E(_0x2459fe['name'],_0x1d254e)):_0x3b38be;}});return new te(_0x564d7b,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x25f60f,_0x5ebb90,_0x2c62b6){this['children_']=_0x25f60f,this['priorityNode_']=_0x5ebb90,this['indexMap_']=_0x2c62b6,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x131bbc){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x131bbc,this['indexMap_']);}['getImmediateChild'](_0x1cc9df){if(_0x1cc9df==='.priority')return this['getPriority']();{const _0x5495b3=this['children_']['get'](_0x1cc9df);return _0x5495b3===null?It:_0x5495b3;}}['getChild'](_0x625939){const _0x6fbf03=y(_0x625939);return _0x6fbf03===null?this:this['getImmediateChild'](_0x6fbf03)['getChild'](S(_0x625939));}['hasChild'](_0x1e5a82){return this['children_']['get'](_0x1e5a82)!==null;}['updateImmediateChild'](_0x2659f3,_0x4bb0ed){if(f(_0x4bb0ed,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x2659f3==='.priority')return this['updatePriority'](_0x4bb0ed);{const _0x2df5a5=new E(_0x2659f3,_0x4bb0ed);let _0x1175f2,_0x5bb523;_0x4bb0ed['isEmpty']()?(_0x1175f2=this['children_']['remove'](_0x2659f3),_0x5bb523=this['indexMap_']['removeFromIndexes'](_0x2df5a5,this['children_'])):(_0x1175f2=this['children_']['insert'](_0x2659f3,_0x4bb0ed),_0x5bb523=this['indexMap_']['addToIndexes'](_0x2df5a5,this['children_']));const _0x4f9b24=_0x1175f2['isEmpty']()?It:this['priorityNode_'];return new g(_0x1175f2,_0x4f9b24,_0x5bb523);}}['updateChild'](_0x13f394,_0x1929fb){const _0x2eb8d5=y(_0x13f394);if(_0x2eb8d5===null)return _0x1929fb;{f(y(_0x13f394)!=='.priority'||Ce(_0x13f394)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x4fd787=this['getImmediateChild'](_0x2eb8d5)['updateChild'](S(_0x13f394),_0x1929fb);return this['updateImmediateChild'](_0x2eb8d5,_0x4fd787);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x274367){if(this['isEmpty']())return null;const _0xc5d99b={};let _0x153cc7=0x0,_0x3f34cd=0x0,_0x26bf41=!0x0;if(this['forEachChild'](R,(_0x2af1ed,_0xa39566)=>{_0xc5d99b[_0x2af1ed]=_0xa39566['val'](_0x274367),_0x153cc7++,_0x26bf41&&g['INTEGER_REGEXP_']['test'](_0x2af1ed)?_0x3f34cd=Math['max'](_0x3f34cd,Number(_0x2af1ed)):_0x26bf41=!0x1;}),!_0x274367&&_0x26bf41&&_0x3f34cd<0x2*_0x153cc7){const _0x256627=[];for(const _0x1744c5 in _0xc5d99b)_0x256627[_0x1744c5]=_0xc5d99b[_0x1744c5];return _0x256627;}else return _0x274367&&!this['getPriority']()['isEmpty']()&&(_0xc5d99b['.priority']=this['getPriority']()['val']()),_0xc5d99b;}['hash'](){if(this['lazyHash_']===null){let _0x3d32e6='';this['getPriority']()['isEmpty']()||(_0x3d32e6+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x49010b,_0x412305)=>{const _0x206426=_0x412305['hash']();_0x206426!==''&&(_0x3d32e6+=':'+_0x49010b+':'+_0x206426);}),this['lazyHash_']=_0x3d32e6===''?'':ro(_0x3d32e6);}return this['lazyHash_'];}['getPredecessorChildName'](_0xf08317,_0x3bffcb,_0x13519d){const _0x117508=this['resolveIndex_'](_0x13519d);if(_0x117508){const _0x364137=_0x117508['getPredecessorKey'](new E(_0xf08317,_0x3bffcb));return _0x364137?_0x364137['name']:null;}else return this['children_']['getPredecessorKey'](_0xf08317);}['getFirstChildName'](_0x424ced){const _0x3f1a4c=this['resolveIndex_'](_0x424ced);if(_0x3f1a4c){const _0x3237d4=_0x3f1a4c['minKey']();return _0x3237d4&&_0x3237d4['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x2ff44c){const _0x5e6da9=this['getFirstChildName'](_0x2ff44c);return _0x5e6da9?new E(_0x5e6da9,this['children_']['get'](_0x5e6da9)):null;}['getLastChildName'](_0x18ab2d){const _0x19db3c=this['resolveIndex_'](_0x18ab2d);if(_0x19db3c){const _0x5ee98e=_0x19db3c['maxKey']();return _0x5ee98e&&_0x5ee98e['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x21f723){const _0x4adf47=this['getLastChildName'](_0x21f723);return _0x4adf47?new E(_0x4adf47,this['children_']['get'](_0x4adf47)):null;}['forEachChild'](_0x450bfd,_0x253ac5){const _0x13390c=this['resolveIndex_'](_0x450bfd);return _0x13390c?_0x13390c['inorderTraversal'](_0x1cd98a=>_0x253ac5(_0x1cd98a['name'],_0x1cd98a['node'])):this['children_']['inorderTraversal'](_0x253ac5);}['getIterator'](_0x35cdd9){return this['getIteratorFrom'](_0x35cdd9['minPost'](),_0x35cdd9);}['getIteratorFrom'](_0x562c6a,_0x4181b8){const _0x17ad52=this['resolveIndex_'](_0x4181b8);if(_0x17ad52)return _0x17ad52['getIteratorFrom'](_0x562c6a,_0x1439d4=>_0x1439d4);{const _0x35379a=this['children_']['getIteratorFrom'](_0x562c6a['name'],E['Wrap']);let _0x2c5c90=_0x35379a['peek']();for(;_0x2c5c90!=null&&_0x4181b8['compare'](_0x2c5c90,_0x562c6a)<0x0;)_0x35379a['getNext'](),_0x2c5c90=_0x35379a['peek']();return _0x35379a;}}['getReverseIterator'](_0x35c34e){return this['getReverseIteratorFrom'](_0x35c34e['maxPost'](),_0x35c34e);}['getReverseIteratorFrom'](_0x334de1,_0x1ef643){const _0x475c22=this['resolveIndex_'](_0x1ef643);if(_0x475c22)return _0x475c22['getReverseIteratorFrom'](_0x334de1,_0x5393a1=>_0x5393a1);{const _0x532a29=this['children_']['getReverseIteratorFrom'](_0x334de1['name'],E['Wrap']);let _0x5de10a=_0x532a29['peek']();for(;_0x5de10a!=null&&_0x1ef643['compare'](_0x5de10a,_0x334de1)>0x0;)_0x532a29['getNext'](),_0x5de10a=_0x532a29['peek']();return _0x532a29;}}['compareTo'](_0x182af2){return this['isEmpty']()?_0x182af2['isEmpty']()?0x0:-0x1:_0x182af2['isLeafNode']()||_0x182af2['isEmpty']()?0x1:_0x182af2===Kt?-0x1:0x0;}['withIndex'](_0x1abd79){if(_0x1abd79===ve||this['indexMap_']['hasIndex'](_0x1abd79))return this;{const _0x2f15c8=this['indexMap_']['addIndex'](_0x1abd79,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x2f15c8);}}['isIndexed'](_0x5ea01f){return _0x5ea01f===ve||this['indexMap_']['hasIndex'](_0x5ea01f);}['equals'](_0x439c96){if(_0x439c96===this)return!0x0;if(_0x439c96['isLeafNode']())return!0x1;{const _0x30036f=_0x439c96;if(this['getPriority']()['equals'](_0x30036f['getPriority']())){if(this['children_']['count']()===_0x30036f['children_']['count']()){const _0x481ba8=this['getIterator'](R),_0x369b87=_0x30036f['getIterator'](R);let _0x15f30a=_0x481ba8['getNext'](),_0x46c9c9=_0x369b87['getNext']();for(;_0x15f30a&&_0x46c9c9;){if(_0x15f30a['name']!==_0x46c9c9['name']||!_0x15f30a['node']['equals'](_0x46c9c9['node']))return!0x1;_0x15f30a=_0x481ba8['getNext'](),_0x46c9c9=_0x369b87['getNext']();}return _0x15f30a===null&&_0x46c9c9===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x5213c7){return _0x5213c7===ve?null:this['indexMap_']['get'](_0x5213c7['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x19ac74){return _0x19ac74===this?0x0:0x1;}['equals'](_0x195acc){return _0x195acc===this;}['getPriority'](){return this;}['getImmediateChild'](_0x4e860a){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x3b0a3a,_0x5444b7=null){if(_0x3b0a3a===null)return g['EMPTY_NODE'];if(typeof _0x3b0a3a=='object'&&'.priority'in _0x3b0a3a&&(_0x5444b7=_0x3b0a3a['.priority']),f(_0x5444b7===null||typeof _0x5444b7=='string'||typeof _0x5444b7=='number'||typeof _0x5444b7=='object'&&'.sv'in _0x5444b7,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x5444b7),typeof _0x3b0a3a=='object'&&'.value'in _0x3b0a3a&&_0x3b0a3a['.value']!==null&&(_0x3b0a3a=_0x3b0a3a['.value']),typeof _0x3b0a3a!='object'||'.sv'in _0x3b0a3a){const _0xc51fec=_0x3b0a3a;return new D(_0xc51fec,A(_0x5444b7));}if(!(_0x3b0a3a instanceof Array)&&Gh){const _0x4efe80=[];let _0x3559d3=!0x1;if(x(_0x3b0a3a,(_0x354da8,_0x214f7a)=>{if(_0x354da8['substring'](0x0,0x1)!=='.'){const _0x50fff5=A(_0x214f7a);_0x50fff5['isEmpty']()||(_0x3559d3=_0x3559d3||!_0x50fff5['getPriority']()['isEmpty'](),_0x4efe80['push'](new E(_0x354da8,_0x50fff5)));}}),_0x4efe80['length']===0x0)return g['EMPTY_NODE'];const _0x5cf4b1=yn(_0x4efe80,xh,_0x22907f=>_0x22907f['name'],Qi);if(_0x3559d3){const _0x133175=yn(_0x4efe80,R['getCompare']());return new g(_0x5cf4b1,A(_0x5444b7),new te({'.priority':_0x133175},{'.priority':R}));}else return new g(_0x5cf4b1,A(_0x5444b7),te['Default']);}else{let _0x52bdb9=g['EMPTY_NODE'];return x(_0x3b0a3a,(_0x35fb9d,_0x348ec5)=>{if(Q(_0x3b0a3a,_0x35fb9d)&&_0x35fb9d['substring'](0x0,0x1)!=='.'){const _0x95b497=A(_0x348ec5);(_0x95b497['isLeafNode']()||!_0x95b497['isEmpty']())&&(_0x52bdb9=_0x52bdb9['updateImmediateChild'](_0x35fb9d,_0x95b497));}}),_0x52bdb9['updatePriority'](A(_0x5444b7));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x349b91){super(),this['indexPath_']=_0x349b91,f(!v(_0x349b91)&&y(_0x349b91)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x185b00){return _0x185b00['getChild'](this['indexPath_']);}['isDefinedOn'](_0x483c92){return!_0x483c92['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x240317,_0x4fbf11){const _0x4dc04b=this['extractChild'](_0x240317['node']),_0x94fd0f=this['extractChild'](_0x4fbf11['node']),_0x440c49=_0x4dc04b['compareTo'](_0x94fd0f);return _0x440c49===0x0?qe(_0x240317['name'],_0x4fbf11['name']):_0x440c49;}['makePost'](_0x4bfee7,_0x24bc7d){const _0xdd37ab=A(_0x4bfee7),_0x3b9d54=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0xdd37ab);return new E(_0x24bc7d,_0x3b9d54);}['maxPost'](){const _0x47a14d=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x47a14d);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x99a5f7,_0x306bdd){const _0x238d44=_0x99a5f7['node']['compareTo'](_0x306bdd['node']);return _0x238d44===0x0?qe(_0x99a5f7['name'],_0x306bdd['name']):_0x238d44;}['isDefinedOn'](_0xb5411a){return!0x0;}['indexedValueChanged'](_0x1eaebb,_0xea0a56){return!_0x1eaebb['equals'](_0xea0a56);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x57d5ce,_0x3628f9){const _0xde4d9d=A(_0x57d5ce);return new E(_0x3628f9,_0xde4d9d);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x325f6b){return{'type':'value','snapshotNode':_0x325f6b};}function rt(_0x3d2f78,_0x4bea49){return{'type':'child_added','snapshotNode':_0x4bea49,'childName':_0x3d2f78};}function Lt(_0x43721d,_0x2490e1){return{'type':'child_removed','snapshotNode':_0x2490e1,'childName':_0x43721d};}function xt(_0x279377,_0x3a5327,_0x23222b){return{'type':'child_changed','snapshotNode':_0x3a5327,'childName':_0x279377,'oldSnap':_0x23222b};}function zh(_0x2141ec,_0xc57c62){return{'type':'child_moved','snapshotNode':_0xc57c62,'childName':_0x2141ec};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x2bc7cf){this['index_']=_0x2bc7cf;}['updateChild'](_0x59c1ab,_0x51db69,_0x2cf38b,_0x4f8ca6,_0x176274,_0x16a453){f(_0x59c1ab['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x12bb15=_0x59c1ab['getImmediateChild'](_0x51db69);return _0x12bb15['getChild'](_0x4f8ca6)['equals'](_0x2cf38b['getChild'](_0x4f8ca6))&&_0x12bb15['isEmpty']()===_0x2cf38b['isEmpty']()||(_0x16a453!=null&&(_0x2cf38b['isEmpty']()?_0x59c1ab['hasChild'](_0x51db69)?_0x16a453['trackChildChange'](Lt(_0x51db69,_0x12bb15)):f(_0x59c1ab['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x12bb15['isEmpty']()?_0x16a453['trackChildChange'](rt(_0x51db69,_0x2cf38b)):_0x16a453['trackChildChange'](xt(_0x51db69,_0x2cf38b,_0x12bb15))),_0x59c1ab['isLeafNode']()&&_0x2cf38b['isEmpty']())?_0x59c1ab:_0x59c1ab['updateImmediateChild'](_0x51db69,_0x2cf38b)['withIndex'](this['index_']);}['updateFullNode'](_0x51cb4e,_0x1dfec9,_0x2bad74){return _0x2bad74!=null&&(_0x51cb4e['isLeafNode']()||_0x51cb4e['forEachChild'](R,(_0x169613,_0x37f9d2)=>{_0x1dfec9['hasChild'](_0x169613)||_0x2bad74['trackChildChange'](Lt(_0x169613,_0x37f9d2));}),_0x1dfec9['isLeafNode']()||_0x1dfec9['forEachChild'](R,(_0x38d5cd,_0x39ee5e)=>{if(_0x51cb4e['hasChild'](_0x38d5cd)){const _0x4ba6b0=_0x51cb4e['getImmediateChild'](_0x38d5cd);_0x4ba6b0['equals'](_0x39ee5e)||_0x2bad74['trackChildChange'](xt(_0x38d5cd,_0x39ee5e,_0x4ba6b0));}else _0x2bad74['trackChildChange'](rt(_0x38d5cd,_0x39ee5e));})),_0x1dfec9['withIndex'](this['index_']);}['updatePriority'](_0x4b9bd3,_0x1b60f1){return _0x4b9bd3['isEmpty']()?g['EMPTY_NODE']:_0x4b9bd3['updatePriority'](_0x1b60f1);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x142dba){this['indexedFilter_']=new Xi(_0x142dba['getIndex']()),this['index_']=_0x142dba['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x142dba),this['endPost_']=Ft['getEndPost_'](_0x142dba),this['startIsInclusive_']=!_0x142dba['startAfterSet_'],this['endIsInclusive_']=!_0x142dba['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x393efe){const _0x154e55=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x393efe)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x393efe)<0x0,_0x40dc41=this['endIsInclusive_']?this['index_']['compare'](_0x393efe,this['getEndPost']())<=0x0:this['index_']['compare'](_0x393efe,this['getEndPost']())<0x0;return _0x154e55&&_0x40dc41;}['updateChild'](_0x32cdc4,_0x158b8c,_0x53deb0,_0x15a17b,_0x3bc7fb,_0x361241){return this['matches'](new E(_0x158b8c,_0x53deb0))||(_0x53deb0=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x32cdc4,_0x158b8c,_0x53deb0,_0x15a17b,_0x3bc7fb,_0x361241);}['updateFullNode'](_0x41a6ee,_0x35fcb7,_0x5dd62f){_0x35fcb7['isLeafNode']()&&(_0x35fcb7=g['EMPTY_NODE']);let _0x534406=_0x35fcb7['withIndex'](this['index_']);_0x534406=_0x534406['updatePriority'](g['EMPTY_NODE']);const _0x28fcd4=this;return _0x35fcb7['forEachChild'](R,(_0x44e93a,_0x1f5cdf)=>{_0x28fcd4['matches'](new E(_0x44e93a,_0x1f5cdf))||(_0x534406=_0x534406['updateImmediateChild'](_0x44e93a,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x41a6ee,_0x534406,_0x5dd62f);}['updatePriority'](_0x720531,_0x32078b){return _0x720531;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0xdf679b){if(_0xdf679b['hasStart']()){const _0x220c03=_0xdf679b['getIndexStartName']();return _0xdf679b['getIndex']()['makePost'](_0xdf679b['getIndexStartValue'](),_0x220c03);}else return _0xdf679b['getIndex']()['minPost']();}static['getEndPost_'](_0x957459){if(_0x957459['hasEnd']()){const _0x5a1346=_0x957459['getIndexEndName']();return _0x957459['getIndex']()['makePost'](_0x957459['getIndexEndValue'](),_0x5a1346);}else return _0x957459['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x4b2678){this['withinDirectionalStart']=_0x1aecc4=>this['reverse_']?this['withinEndPost'](_0x1aecc4):this['withinStartPost'](_0x1aecc4),this['withinDirectionalEnd']=_0x3e6916=>this['reverse_']?this['withinStartPost'](_0x3e6916):this['withinEndPost'](_0x3e6916),this['withinStartPost']=_0x40c447=>{const _0xe530ca=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x40c447);return this['startIsInclusive_']?_0xe530ca<=0x0:_0xe530ca<0x0;},this['withinEndPost']=_0x366bf9=>{const _0x3ea8a2=this['index_']['compare'](_0x366bf9,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x3ea8a2<=0x0:_0x3ea8a2<0x0;},this['rangedFilter_']=new Ft(_0x4b2678),this['index_']=_0x4b2678['getIndex'](),this['limit_']=_0x4b2678['getLimit'](),this['reverse_']=!_0x4b2678['isViewFromLeft'](),this['startIsInclusive_']=!_0x4b2678['startAfterSet_'],this['endIsInclusive_']=!_0x4b2678['endBeforeSet_'];}['updateChild'](_0x55f08f,_0xf55f52,_0x24e878,_0x2bf5bd,_0x5044a3,_0x4cf95e){return this['rangedFilter_']['matches'](new E(_0xf55f52,_0x24e878))||(_0x24e878=g['EMPTY_NODE']),_0x55f08f['getImmediateChild'](_0xf55f52)['equals'](_0x24e878)?_0x55f08f:_0x55f08f['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x55f08f,_0xf55f52,_0x24e878,_0x2bf5bd,_0x5044a3,_0x4cf95e):this['fullLimitUpdateChild_'](_0x55f08f,_0xf55f52,_0x24e878,_0x5044a3,_0x4cf95e);}['updateFullNode'](_0x267fd0,_0x114f68,_0x12d89b){let _0x553c58;if(_0x114f68['isLeafNode']()||_0x114f68['isEmpty']())_0x553c58=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x114f68['numChildren']()&&_0x114f68['isIndexed'](this['index_'])){_0x553c58=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x5cf035;this['reverse_']?_0x5cf035=_0x114f68['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x5cf035=_0x114f68['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x56ee2e=0x0;for(;_0x5cf035['hasNext']()&&_0x56ee2e<this['limit_'];){const _0xf54212=_0x5cf035['getNext']();if(this['withinDirectionalStart'](_0xf54212)){if(this['withinDirectionalEnd'](_0xf54212))_0x553c58=_0x553c58['updateImmediateChild'](_0xf54212['name'],_0xf54212['node']),_0x56ee2e++;else break;}else continue;}}else{_0x553c58=_0x114f68['withIndex'](this['index_']),_0x553c58=_0x553c58['updatePriority'](g['EMPTY_NODE']);let _0xbff825;this['reverse_']?_0xbff825=_0x553c58['getReverseIterator'](this['index_']):_0xbff825=_0x553c58['getIterator'](this['index_']);let _0x45969a=0x0;for(;_0xbff825['hasNext']();){const _0x2031be=_0xbff825['getNext']();_0x45969a<this['limit_']&&this['withinDirectionalStart'](_0x2031be)&&this['withinDirectionalEnd'](_0x2031be)?_0x45969a++:_0x553c58=_0x553c58['updateImmediateChild'](_0x2031be['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x267fd0,_0x553c58,_0x12d89b);}['updatePriority'](_0x13f24d,_0x127c05){return _0x13f24d;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x28942b,_0x3da1cc,_0x141599,_0x274ae1,_0x367670){let _0x47393d;if(this['reverse_']){const _0x49e5cc=this['index_']['getCompare']();_0x47393d=(_0x389848,_0x34c6cb)=>_0x49e5cc(_0x34c6cb,_0x389848);}else _0x47393d=this['index_']['getCompare']();const _0x250ca4=_0x28942b;f(_0x250ca4['numChildren']()===this['limit_'],'');const _0x305c26=new E(_0x3da1cc,_0x141599),_0x38c018=this['reverse_']?_0x250ca4['getFirstChild'](this['index_']):_0x250ca4['getLastChild'](this['index_']),_0xc45cd8=this['rangedFilter_']['matches'](_0x305c26);if(_0x250ca4['hasChild'](_0x3da1cc)){const _0x130402=_0x250ca4['getImmediateChild'](_0x3da1cc);let _0x391e3e=_0x274ae1['getChildAfterChild'](this['index_'],_0x38c018,this['reverse_']);for(;_0x391e3e!=null&&(_0x391e3e['name']===_0x3da1cc||_0x250ca4['hasChild'](_0x391e3e['name']));)_0x391e3e=_0x274ae1['getChildAfterChild'](this['index_'],_0x391e3e,this['reverse_']);const _0x5af8a9=_0x391e3e==null?0x1:_0x47393d(_0x391e3e,_0x305c26);if(_0xc45cd8&&!_0x141599['isEmpty']()&&_0x5af8a9>=0x0)return _0x367670!=null&&_0x367670['trackChildChange'](xt(_0x3da1cc,_0x141599,_0x130402)),_0x250ca4['updateImmediateChild'](_0x3da1cc,_0x141599);{_0x367670!=null&&_0x367670['trackChildChange'](Lt(_0x3da1cc,_0x130402));const _0x21370b=_0x250ca4['updateImmediateChild'](_0x3da1cc,g['EMPTY_NODE']);return _0x391e3e!=null&&this['rangedFilter_']['matches'](_0x391e3e)?(_0x367670!=null&&_0x367670['trackChildChange'](rt(_0x391e3e['name'],_0x391e3e['node'])),_0x21370b['updateImmediateChild'](_0x391e3e['name'],_0x391e3e['node'])):_0x21370b;}}else return _0x141599['isEmpty']()?_0x28942b:_0xc45cd8&&_0x47393d(_0x38c018,_0x305c26)>=0x0?(_0x367670!=null&&(_0x367670['trackChildChange'](Lt(_0x38c018['name'],_0x38c018['node'])),_0x367670['trackChildChange'](rt(_0x3da1cc,_0x141599))),_0x250ca4['updateImmediateChild'](_0x3da1cc,_0x141599)['updateImmediateChild'](_0x38c018['name'],g['EMPTY_NODE'])):_0x28942b;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x3737e0=new Zi();return _0x3737e0['limitSet_']=this['limitSet_'],_0x3737e0['limit_']=this['limit_'],_0x3737e0['startSet_']=this['startSet_'],_0x3737e0['startAfterSet_']=this['startAfterSet_'],_0x3737e0['indexStartValue_']=this['indexStartValue_'],_0x3737e0['startNameSet_']=this['startNameSet_'],_0x3737e0['indexStartName_']=this['indexStartName_'],_0x3737e0['endSet_']=this['endSet_'],_0x3737e0['endBeforeSet_']=this['endBeforeSet_'],_0x3737e0['indexEndValue_']=this['indexEndValue_'],_0x3737e0['endNameSet_']=this['endNameSet_'],_0x3737e0['indexEndName_']=this['indexEndName_'],_0x3737e0['index_']=this['index_'],_0x3737e0['viewFrom_']=this['viewFrom_'],_0x3737e0;}}function Kh(_0x1122aa){return _0x1122aa['loadsAllData']()?new Xi(_0x1122aa['getIndex']()):_0x1122aa['hasLimit']()?new jh(_0x1122aa):new Ft(_0x1122aa);}function Yh(_0x5a15de,_0x4ac860){const _0x8aba02=_0x5a15de['copy']();return _0x8aba02['limitSet_']=!0x0,_0x8aba02['limit_']=_0x4ac860,_0x8aba02['viewFrom_']='l',_0x8aba02;}function Qh(_0x214714,_0x5b5099,_0x31fa4c){const _0x2a24cc=_0x214714['copy']();return _0x2a24cc['startSet_']=!0x0,_0x5b5099===void 0x0&&(_0x5b5099=null),_0x2a24cc['indexStartValue_']=_0x5b5099,_0x31fa4c!=null?(_0x2a24cc['startNameSet_']=!0x0,_0x2a24cc['indexStartName_']=_0x31fa4c):(_0x2a24cc['startNameSet_']=!0x1,_0x2a24cc['indexStartName_']=''),_0x2a24cc;}function Jh(_0x41bc3f,_0xb65864,_0x4c6a7c){const _0x5258b6=_0x41bc3f['copy']();return _0x5258b6['endSet_']=!0x0,_0xb65864===void 0x0&&(_0xb65864=null),_0x5258b6['indexEndValue_']=_0xb65864,_0x4c6a7c!==void 0x0?(_0x5258b6['endNameSet_']=!0x0,_0x5258b6['indexEndName_']=_0x4c6a7c):(_0x5258b6['endNameSet_']=!0x1,_0x5258b6['indexEndName_']=''),_0x5258b6;}function xo(_0x3d4034,_0x5c8ef6){const _0x4d4894=_0x3d4034['copy']();return _0x4d4894['index_']=_0x5c8ef6,_0x4d4894;}function ir(_0x1b7043){const _0x4ea879={};if(_0x1b7043['isDefault']())return _0x4ea879;let _0x160d0f;if(_0x1b7043['index_']===R?_0x160d0f='$priority':_0x1b7043['index_']===Mo?_0x160d0f='$value':_0x1b7043['index_']===ve?_0x160d0f='$key':(f(_0x1b7043['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x160d0f=_0x1b7043['index_']['toString']()),_0x4ea879['orderBy']=O(_0x160d0f),_0x1b7043['startSet_']){const _0x3de1bb=_0x1b7043['startAfterSet_']?'startAfter':'startAt';_0x4ea879[_0x3de1bb]=O(_0x1b7043['indexStartValue_']),_0x1b7043['startNameSet_']&&(_0x4ea879[_0x3de1bb]+=','+O(_0x1b7043['indexStartName_']));}if(_0x1b7043['endSet_']){const _0x2bd733=_0x1b7043['endBeforeSet_']?'endBefore':'endAt';_0x4ea879[_0x2bd733]=O(_0x1b7043['indexEndValue_']),_0x1b7043['endNameSet_']&&(_0x4ea879[_0x2bd733]+=','+O(_0x1b7043['indexEndName_']));}return _0x1b7043['limitSet_']&&(_0x1b7043['isViewFromLeft']()?_0x4ea879['limitToFirst']=_0x1b7043['limit_']:_0x4ea879['limitToLast']=_0x1b7043['limit_']),_0x4ea879;}function sr(_0x7ac122){const _0x34d70c={};if(_0x7ac122['startSet_']&&(_0x34d70c['sp']=_0x7ac122['indexStartValue_'],_0x7ac122['startNameSet_']&&(_0x34d70c['sn']=_0x7ac122['indexStartName_']),_0x34d70c['sin']=!_0x7ac122['startAfterSet_']),_0x7ac122['endSet_']&&(_0x34d70c['ep']=_0x7ac122['indexEndValue_'],_0x7ac122['endNameSet_']&&(_0x34d70c['en']=_0x7ac122['indexEndName_']),_0x34d70c['ein']=!_0x7ac122['endBeforeSet_']),_0x7ac122['limitSet_']){_0x34d70c['l']=_0x7ac122['limit_'];let _0x1d1a52=_0x7ac122['viewFrom_'];_0x1d1a52===''&&(_0x7ac122['isViewFromLeft']()?_0x1d1a52='l':_0x1d1a52='r'),_0x34d70c['vf']=_0x1d1a52;}return _0x7ac122['index_']!==R&&(_0x34d70c['i']=_0x7ac122['index_']['toString']()),_0x34d70c;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x511fac){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x44fd16,_0x558134){return _0x558134!==void 0x0?'tag$'+_0x558134:(f(_0x44fd16['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x44fd16['_path']['toString']());}constructor(_0x3789df,_0x4211d1,_0xa37d33,_0x462579){super(),this['repoInfo_']=_0x3789df,this['onDataUpdate_']=_0x4211d1,this['authTokenProvider_']=_0xa37d33,this['appCheckTokenProvider_']=_0x462579,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x3b99ba,_0x558566,_0xbb36db,_0x321a10){const _0x5c4c18=_0x3b99ba['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x5c4c18+'\x20'+_0x3b99ba['_queryIdentifier']);const _0x4f2c13=vn['getListenId_'](_0x3b99ba,_0xbb36db),_0xe7d3a3={};this['listens_'][_0x4f2c13]=_0xe7d3a3;const _0x1c5e66=ir(_0x3b99ba['_queryParams']);this['restRequest_'](_0x5c4c18+'.json',_0x1c5e66,(_0x5ad6db,_0x84ae16)=>{let _0x47aa0c=_0x84ae16;if(_0x5ad6db===0x194&&(_0x47aa0c=null,_0x5ad6db=null),_0x5ad6db===null&&this['onDataUpdate_'](_0x5c4c18,_0x47aa0c,!0x1,_0xbb36db),Le(this['listens_'],_0x4f2c13)===_0xe7d3a3){let _0x3adefe;_0x5ad6db?_0x5ad6db===0x191?_0x3adefe='permission_denied':_0x3adefe='rest_error:'+_0x5ad6db:_0x3adefe='ok',_0x321a10(_0x3adefe,null);}});}['unlisten'](_0x46dfa6,_0x360c2b){const _0x4c624f=vn['getListenId_'](_0x46dfa6,_0x360c2b);delete this['listens_'][_0x4c624f];}['get'](_0x2865ba){const _0x587da9=ir(_0x2865ba['_queryParams']),_0x2403cf=_0x2865ba['_path']['toString'](),_0xd2497=new H();return this['restRequest_'](_0x2403cf+'.json',_0x587da9,(_0x47149a,_0x15b286)=>{let _0x1dc244=_0x15b286;_0x47149a===0x194&&(_0x1dc244=null,_0x47149a=null),_0x47149a===null?(this['onDataUpdate_'](_0x2403cf,_0x1dc244,!0x1,null),_0xd2497['resolve'](_0x1dc244)):_0xd2497['reject'](new Error(_0x1dc244));}),_0xd2497['promise'];}['refreshAuthToken'](_0x19a57b){}['restRequest_'](_0x1ae6fd,_0x4dd292={},_0x4b9aa5){return _0x4dd292['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x313e24,_0x4fc195])=>{_0x313e24&&_0x313e24['accessToken']&&(_0x4dd292['auth']=_0x313e24['accessToken']),_0x4fc195&&_0x4fc195['token']&&(_0x4dd292['ac']=_0x4fc195['token']);const _0x2dc00f=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x1ae6fd+'?ns='+this['repoInfo_']['namespace']+ut(_0x4dd292);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x2dc00f);const _0x24f89b=new XMLHttpRequest();_0x24f89b['onreadystatechange']=()=>{if(_0x4b9aa5&&_0x24f89b['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x2dc00f+'\x20received.\x20status:',_0x24f89b['status'],'response:',_0x24f89b['responseText']);let _0x1d8b91=null;if(_0x24f89b['status']>=0xc8&&_0x24f89b['status']<0x12c){try{_0x1d8b91=Nt(_0x24f89b['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x2dc00f+':\x20'+_0x24f89b['responseText']);}_0x4b9aa5(null,_0x1d8b91);}else _0x24f89b['status']!==0x191&&_0x24f89b['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x2dc00f+'\x20Status:\x20'+_0x24f89b['status']),_0x4b9aa5(_0x24f89b['status']);_0x4b9aa5=null;}},_0x24f89b['open']('GET',_0x2dc00f,!0x0),_0x24f89b['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x35db09){return this['rootNode_']['getChild'](_0x35db09);}['updateSnapshot'](_0x230062,_0x3d44e6){this['rootNode_']=this['rootNode_']['updateChild'](_0x230062,_0x3d44e6);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x4d6f18,_0x92064d,_0x457d9d){if(v(_0x92064d))_0x4d6f18['value']=_0x457d9d,_0x4d6f18['children']['clear']();else{if(_0x4d6f18['value']!==null)_0x4d6f18['value']=_0x4d6f18['value']['updateChild'](_0x92064d,_0x457d9d);else{const _0x3f3644=y(_0x92064d);_0x4d6f18['children']['has'](_0x3f3644)||_0x4d6f18['children']['set'](_0x3f3644,En());const _0x2757fe=_0x4d6f18['children']['get'](_0x3f3644);_0x92064d=S(_0x92064d),pt(_0x2757fe,_0x92064d,_0x457d9d);}}}function Ti(_0x36bc9d,_0x52d8dd){if(v(_0x52d8dd))return _0x36bc9d['value']=null,_0x36bc9d['children']['clear'](),!0x0;if(_0x36bc9d['value']!==null){if(_0x36bc9d['value']['isLeafNode']())return!0x1;{const _0x13ff39=_0x36bc9d['value'];return _0x36bc9d['value']=null,_0x13ff39['forEachChild'](R,(_0x2ee002,_0x5986de)=>{pt(_0x36bc9d,new C(_0x2ee002),_0x5986de);}),Ti(_0x36bc9d,_0x52d8dd);}}else{if(_0x36bc9d['children']['size']>0x0){const _0x200b4f=y(_0x52d8dd);return _0x52d8dd=S(_0x52d8dd),_0x36bc9d['children']['has'](_0x200b4f)&&Ti(_0x36bc9d['children']['get'](_0x200b4f),_0x52d8dd)&&_0x36bc9d['children']['delete'](_0x200b4f),_0x36bc9d['children']['size']===0x0;}else return!0x0;}}function Si(_0x1faf0d,_0x14651f,_0x11dbfa){_0x1faf0d['value']!==null?_0x11dbfa(_0x14651f,_0x1faf0d['value']):Zh(_0x1faf0d,(_0xdab84,_0x2d5e1e)=>{const _0x53644c=new C(_0x14651f['toString']()+'/'+_0xdab84);Si(_0x2d5e1e,_0x53644c,_0x11dbfa);});}function Zh(_0x59f60b,_0x30c078){_0x59f60b['children']['forEach']((_0x31f7ad,_0x13b271)=>{_0x30c078(_0x13b271,_0x31f7ad);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x964bc2){this['collection_']=_0x964bc2,this['last_']=null;}['get'](){const _0x212f5a=this['collection_']['get'](),_0x20bd89={..._0x212f5a};return this['last_']&&x(this['last_'],(_0x46ba4b,_0x381a8a)=>{_0x20bd89[_0x46ba4b]=_0x20bd89[_0x46ba4b]-_0x381a8a;}),this['last_']=_0x212f5a,_0x20bd89;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x4a3f06,_0x5007e9){this['server_']=_0x5007e9,this['statsToReport_']={},this['statsListener_']=new eu(_0x4a3f06);const _0x1be860=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x1be860));}['reportStats_'](){const _0x1d8948=this['statsListener_']['get'](),_0x6fa71={};let _0x51090e=!0x1;x(_0x1d8948,(_0xf84124,_0x376135)=>{_0x376135>0x0&&Q(this['statsToReport_'],_0xf84124)&&(_0x6fa71[_0xf84124]=_0x376135,_0x51090e=!0x0);}),_0x51090e&&this['server_']['reportStats'](_0x6fa71),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x53b342){_0x53b342[_0x53b342['OVERWRITE']=0x0]='OVERWRITE',_0x53b342[_0x53b342['MERGE']=0x1]='MERGE',_0x53b342[_0x53b342['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x53b342[_0x53b342['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0xde1828){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0xde1828,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x4528a4,_0x5e182f,_0x88d5b8){this['path']=_0x4528a4,this['affectedTree']=_0x5e182f,this['revert']=_0x88d5b8,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x145517){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x57bb57=this['affectedTree']['subtree'](new C(_0x145517));return new In(w(),_0x57bb57,this['revert']);}}else return f(y(this['path'])===_0x145517,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x24a5bb,_0x24c25a){this['source']=_0x24a5bb,this['path']=_0x24c25a,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x3f98c2){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x342634,_0x1dc331,_0x14a64a){this['source']=_0x342634,this['path']=_0x1dc331,this['snap']=_0x14a64a,this['type']=z['OVERWRITE'];}['operationForChild'](_0x2cd9d3){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x2cd9d3)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x3297bd,_0x461b17,_0x307a9e){this['source']=_0x3297bd,this['path']=_0x461b17,this['children']=_0x307a9e,this['type']=z['MERGE'];}['operationForChild'](_0x49ac85){if(v(this['path'])){const _0x542c29=this['children']['subtree'](new C(_0x49ac85));return _0x542c29['isEmpty']()?null:_0x542c29['value']?new Be(this['source'],w(),_0x542c29['value']):new ot(this['source'],w(),_0x542c29);}else return f(y(this['path'])===_0x49ac85,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x14df13,_0x2266a4,_0x2f117f){this['node_']=_0x14df13,this['fullyInitialized_']=_0x2266a4,this['filtered_']=_0x2f117f;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x2ef99b){if(v(_0x2ef99b))return this['isFullyInitialized']()&&!this['filtered_'];const _0x1fc567=y(_0x2ef99b);return this['isCompleteForChild'](_0x1fc567);}['isCompleteForChild'](_0x45b3c5){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x45b3c5);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x31de13){this['query_']=_0x31de13,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x1a8be9,_0x56b2d1,_0x51ccd8,_0x45cf61){const _0x12cc5b=[],_0x4e9537=[];return _0x56b2d1['forEach'](_0x5cd3b2=>{_0x5cd3b2['type']==='child_changed'&&_0x1a8be9['index_']['indexedValueChanged'](_0x5cd3b2['oldSnap'],_0x5cd3b2['snapshotNode'])&&_0x4e9537['push'](zh(_0x5cd3b2['childName'],_0x5cd3b2['snapshotNode']));}),wt(_0x1a8be9,_0x12cc5b,'child_removed',_0x56b2d1,_0x45cf61,_0x51ccd8),wt(_0x1a8be9,_0x12cc5b,'child_added',_0x56b2d1,_0x45cf61,_0x51ccd8),wt(_0x1a8be9,_0x12cc5b,'child_moved',_0x4e9537,_0x45cf61,_0x51ccd8),wt(_0x1a8be9,_0x12cc5b,'child_changed',_0x56b2d1,_0x45cf61,_0x51ccd8),wt(_0x1a8be9,_0x12cc5b,'value',_0x56b2d1,_0x45cf61,_0x51ccd8),_0x12cc5b;}function wt(_0x43053a,_0x2b66ca,_0x4c9d4f,_0x2fb540,_0x25e4da,_0x17a675){const _0x284d42=_0x2fb540['filter'](_0x508e7e=>_0x508e7e['type']===_0x4c9d4f);_0x284d42['sort']((_0xc189f0,_0x526d46)=>au(_0x43053a,_0xc189f0,_0x526d46)),_0x284d42['forEach'](_0xfc9d8b=>{const _0x33e8cc=ou(_0x43053a,_0xfc9d8b,_0x17a675);_0x25e4da['forEach'](_0x24947e=>{_0x24947e['respondsTo'](_0xfc9d8b['type'])&&_0x2b66ca['push'](_0x24947e['createEvent'](_0x33e8cc,_0x43053a['query_']));});});}function ou(_0x1c8b09,_0xe47acc,_0x415e41){return _0xe47acc['type']==='value'||_0xe47acc['type']==='child_removed'||(_0xe47acc['prevName']=_0x415e41['getPredecessorChildName'](_0xe47acc['childName'],_0xe47acc['snapshotNode'],_0x1c8b09['index_'])),_0xe47acc;}function au(_0x5519b8,_0x48d936,_0x4156a7){if(_0x48d936['childName']==null||_0x4156a7['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x2a1a9c=new E(_0x48d936['childName'],_0x48d936['snapshotNode']),_0x4f4afa=new E(_0x4156a7['childName'],_0x4156a7['snapshotNode']);return _0x5519b8['index_']['compare'](_0x2a1a9c,_0x4f4afa);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x43e161,_0x487d5a){return{'eventCache':_0x43e161,'serverCache':_0x487d5a};}function Rt(_0x324f6a,_0x1f99c5,_0x59d332,_0x264424){return Un(new Te(_0x1f99c5,_0x59d332,_0x264424),_0x324f6a['serverCache']);}function Fo(_0x586ec1,_0x575db5,_0x4d88ec,_0xe6a3cc){return Un(_0x586ec1['eventCache'],new Te(_0x575db5,_0x4d88ec,_0xe6a3cc));}function wn(_0x2122c5){return _0x2122c5['eventCache']['isFullyInitialized']()?_0x2122c5['eventCache']['getNode']():null;}function Ve(_0x30a040){return _0x30a040['serverCache']['isFullyInitialized']()?_0x30a040['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x101815){let _0x2e46e0=new b(null);return x(_0x101815,(_0x17bc0e,_0x196876)=>{_0x2e46e0=_0x2e46e0['set'](new C(_0x17bc0e),_0x196876);}),_0x2e46e0;}constructor(_0x489680,_0x12cf3c=cu()){this['value']=_0x489680,this['children']=_0x12cf3c;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x2bace5,_0x48eb84){if(this['value']!=null&&_0x48eb84(this['value']))return{'path':w(),'value':this['value']};if(v(_0x2bace5))return null;{const _0x48ff96=y(_0x2bace5),_0x1ea81d=this['children']['get'](_0x48ff96);if(_0x1ea81d!==null){const _0x5ddabd=_0x1ea81d['findRootMostMatchingPathAndValue'](S(_0x2bace5),_0x48eb84);return _0x5ddabd!=null?{'path':k(new C(_0x48ff96),_0x5ddabd['path']),'value':_0x5ddabd['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x2f9528){return this['findRootMostMatchingPathAndValue'](_0x2f9528,()=>!0x0);}['subtree'](_0x327469){if(v(_0x327469))return this;{const _0x140cb0=y(_0x327469),_0x4bcd86=this['children']['get'](_0x140cb0);return _0x4bcd86!==null?_0x4bcd86['subtree'](S(_0x327469)):new b(null);}}['set'](_0x5c736f,_0x57cbf5){if(v(_0x5c736f))return new b(_0x57cbf5,this['children']);{const _0x187e8b=y(_0x5c736f),_0x1286f7=(this['children']['get'](_0x187e8b)||new b(null))['set'](S(_0x5c736f),_0x57cbf5),_0x49438e=this['children']['insert'](_0x187e8b,_0x1286f7);return new b(this['value'],_0x49438e);}}['remove'](_0x318646){if(v(_0x318646))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x30a7ac=y(_0x318646),_0xf0273b=this['children']['get'](_0x30a7ac);if(_0xf0273b){const _0xb6b012=_0xf0273b['remove'](S(_0x318646));let _0xfa9a54;return _0xb6b012['isEmpty']()?_0xfa9a54=this['children']['remove'](_0x30a7ac):_0xfa9a54=this['children']['insert'](_0x30a7ac,_0xb6b012),this['value']===null&&_0xfa9a54['isEmpty']()?new b(null):new b(this['value'],_0xfa9a54);}else return this;}}['get'](_0x1124d5){if(v(_0x1124d5))return this['value'];{const _0x25e283=y(_0x1124d5),_0x2251db=this['children']['get'](_0x25e283);return _0x2251db?_0x2251db['get'](S(_0x1124d5)):null;}}['setTree'](_0x250f5a,_0x2b5974){if(v(_0x250f5a))return _0x2b5974;{const _0x1986c0=y(_0x250f5a),_0x317042=(this['children']['get'](_0x1986c0)||new b(null))['setTree'](S(_0x250f5a),_0x2b5974);let _0x5dad5d;return _0x317042['isEmpty']()?_0x5dad5d=this['children']['remove'](_0x1986c0):_0x5dad5d=this['children']['insert'](_0x1986c0,_0x317042),new b(this['value'],_0x5dad5d);}}['fold'](_0x32052c){return this['fold_'](w(),_0x32052c);}['fold_'](_0xed70,_0x13b851){const _0x2d0bc8={};return this['children']['inorderTraversal']((_0x24dbfa,_0x263b2d)=>{_0x2d0bc8[_0x24dbfa]=_0x263b2d['fold_'](k(_0xed70,_0x24dbfa),_0x13b851);}),_0x13b851(_0xed70,this['value'],_0x2d0bc8);}['findOnPath'](_0x2d7719,_0x3f9e0c){return this['findOnPath_'](_0x2d7719,w(),_0x3f9e0c);}['findOnPath_'](_0x454d6b,_0x3a2138,_0x251c70){const _0x21ab27=this['value']?_0x251c70(_0x3a2138,this['value']):!0x1;if(_0x21ab27)return _0x21ab27;if(v(_0x454d6b))return null;{const _0x30d155=y(_0x454d6b),_0x5d7d72=this['children']['get'](_0x30d155);return _0x5d7d72?_0x5d7d72['findOnPath_'](S(_0x454d6b),k(_0x3a2138,_0x30d155),_0x251c70):null;}}['foreachOnPath'](_0x3198d6,_0x4d2400){return this['foreachOnPath_'](_0x3198d6,w(),_0x4d2400);}['foreachOnPath_'](_0x4a28b6,_0x203cb7,_0x133266){if(v(_0x4a28b6))return this;{this['value']&&_0x133266(_0x203cb7,this['value']);const _0x1ba154=y(_0x4a28b6),_0x31371a=this['children']['get'](_0x1ba154);return _0x31371a?_0x31371a['foreachOnPath_'](S(_0x4a28b6),k(_0x203cb7,_0x1ba154),_0x133266):new b(null);}}['foreach'](_0x3ea91a){this['foreach_'](w(),_0x3ea91a);}['foreach_'](_0x5cd4ed,_0x270553){this['children']['inorderTraversal']((_0x565a86,_0xba2dca)=>{_0xba2dca['foreach_'](k(_0x5cd4ed,_0x565a86),_0x270553);}),this['value']&&_0x270553(_0x5cd4ed,this['value']);}['foreachChild'](_0x27aab3){this['children']['inorderTraversal']((_0xaf5e97,_0x2f0500)=>{_0x2f0500['value']&&_0x27aab3(_0xaf5e97,_0x2f0500['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x10a481){this['writeTree_']=_0x10a481;}static['empty'](){return new K(new b(null));}}function At(_0x4d6716,_0x7809ed,_0x2b1bdb){if(v(_0x7809ed))return new K(new b(_0x2b1bdb));{const _0x278809=_0x4d6716['writeTree_']['findRootMostValueAndPath'](_0x7809ed);if(_0x278809!=null){const _0x52d594=_0x278809['path'];let _0x200fca=_0x278809['value'];const _0x36e7f1=F(_0x52d594,_0x7809ed);return _0x200fca=_0x200fca['updateChild'](_0x36e7f1,_0x2b1bdb),new K(_0x4d6716['writeTree_']['set'](_0x52d594,_0x200fca));}else{const _0x43cc63=new b(_0x2b1bdb),_0x1ac302=_0x4d6716['writeTree_']['setTree'](_0x7809ed,_0x43cc63);return new K(_0x1ac302);}}}function bi(_0x4d74ec,_0x3f6fd8,_0x4ec79c){let _0x131d76=_0x4d74ec;return x(_0x4ec79c,(_0x1dd02e,_0x5e8226)=>{_0x131d76=At(_0x131d76,k(_0x3f6fd8,_0x1dd02e),_0x5e8226);}),_0x131d76;}function or(_0x1c7cef,_0x2ed51c){if(v(_0x2ed51c))return K['empty']();{const _0x3822f3=_0x1c7cef['writeTree_']['setTree'](_0x2ed51c,new b(null));return new K(_0x3822f3);}}function Ri(_0x2b58ec,_0x3af4f7){return ze(_0x2b58ec,_0x3af4f7)!=null;}function ze(_0x2eafbb,_0x334b08){const _0x5c896d=_0x2eafbb['writeTree_']['findRootMostValueAndPath'](_0x334b08);return _0x5c896d!=null?_0x2eafbb['writeTree_']['get'](_0x5c896d['path'])['getChild'](F(_0x5c896d['path'],_0x334b08)):null;}function ar(_0x2b5361){const _0x204160=[],_0x462ac7=_0x2b5361['writeTree_']['value'];return _0x462ac7!=null?_0x462ac7['isLeafNode']()||_0x462ac7['forEachChild'](R,(_0xc3084f,_0x45462b)=>{_0x204160['push'](new E(_0xc3084f,_0x45462b));}):_0x2b5361['writeTree_']['children']['inorderTraversal']((_0xdfaad2,_0x4cdacd)=>{_0x4cdacd['value']!=null&&_0x204160['push'](new E(_0xdfaad2,_0x4cdacd['value']));}),_0x204160;}function Ee(_0x33a59c,_0x1b4619){if(v(_0x1b4619))return _0x33a59c;{const _0xcc30ae=ze(_0x33a59c,_0x1b4619);return _0xcc30ae!=null?new K(new b(_0xcc30ae)):new K(_0x33a59c['writeTree_']['subtree'](_0x1b4619));}}function Ai(_0x59b97a){return _0x59b97a['writeTree_']['isEmpty']();}function at(_0x3e7443,_0x528905){return Uo(w(),_0x3e7443['writeTree_'],_0x528905);}function Uo(_0x44b294,_0x39469a,_0x590291){if(_0x39469a['value']!=null)return _0x590291['updateChild'](_0x44b294,_0x39469a['value']);{let _0x2e2ba1=null;return _0x39469a['children']['inorderTraversal']((_0xb0f951,_0x3dbeff)=>{_0xb0f951==='.priority'?(f(_0x3dbeff['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x2e2ba1=_0x3dbeff['value']):_0x590291=Uo(k(_0x44b294,_0xb0f951),_0x3dbeff,_0x590291);}),!_0x590291['getChild'](_0x44b294)['isEmpty']()&&_0x2e2ba1!==null&&(_0x590291=_0x590291['updateChild'](k(_0x44b294,'.priority'),_0x2e2ba1)),_0x590291;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x5e3526,_0x4d02b1){return Ho(_0x4d02b1,_0x5e3526);}function lu(_0x30c9f8,_0xa14ede,_0x3ca604,_0x10278d,_0x53b59a){f(_0x10278d>_0x30c9f8['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x53b59a===void 0x0&&(_0x53b59a=!0x0),_0x30c9f8['allWrites']['push']({'path':_0xa14ede,'snap':_0x3ca604,'writeId':_0x10278d,'visible':_0x53b59a}),_0x53b59a&&(_0x30c9f8['visibleWrites']=At(_0x30c9f8['visibleWrites'],_0xa14ede,_0x3ca604)),_0x30c9f8['lastWriteId']=_0x10278d;}function hu(_0xe041b9,_0x49736e,_0x4ee39f,_0xdc2cda){f(_0xdc2cda>_0xe041b9['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0xe041b9['allWrites']['push']({'path':_0x49736e,'children':_0x4ee39f,'writeId':_0xdc2cda,'visible':!0x0}),_0xe041b9['visibleWrites']=bi(_0xe041b9['visibleWrites'],_0x49736e,_0x4ee39f),_0xe041b9['lastWriteId']=_0xdc2cda;}function uu(_0x294a24,_0xeea05d){for(let _0x313620=0x0;_0x313620<_0x294a24['allWrites']['length'];_0x313620++){const _0x58b454=_0x294a24['allWrites'][_0x313620];if(_0x58b454['writeId']===_0xeea05d)return _0x58b454;}return null;}function du(_0x1f1ab9,_0x2bc353){const _0x491cf1=_0x1f1ab9['allWrites']['findIndex'](_0x3bc273=>_0x3bc273['writeId']===_0x2bc353);f(_0x491cf1>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x582937=_0x1f1ab9['allWrites'][_0x491cf1];_0x1f1ab9['allWrites']['splice'](_0x491cf1,0x1);let _0x199a26=_0x582937['visible'],_0x447f71=!0x1,_0xd7aed5=_0x1f1ab9['allWrites']['length']-0x1;for(;_0x199a26&&_0xd7aed5>=0x0;){const _0x1395fa=_0x1f1ab9['allWrites'][_0xd7aed5];_0x1395fa['visible']&&(_0xd7aed5>=_0x491cf1&&fu(_0x1395fa,_0x582937['path'])?_0x199a26=!0x1:G(_0x582937['path'],_0x1395fa['path'])&&(_0x447f71=!0x0)),_0xd7aed5--;}if(_0x199a26){if(_0x447f71)return pu(_0x1f1ab9),!0x0;if(_0x582937['snap'])_0x1f1ab9['visibleWrites']=or(_0x1f1ab9['visibleWrites'],_0x582937['path']);else{const _0x47d706=_0x582937['children'];x(_0x47d706,_0x29913d=>{_0x1f1ab9['visibleWrites']=or(_0x1f1ab9['visibleWrites'],k(_0x582937['path'],_0x29913d));});}return!0x0;}else return!0x1;}function fu(_0x574da9,_0x43c8da){if(_0x574da9['snap'])return G(_0x574da9['path'],_0x43c8da);for(const _0x2eea6d in _0x574da9['children'])if(_0x574da9['children']['hasOwnProperty'](_0x2eea6d)&&G(k(_0x574da9['path'],_0x2eea6d),_0x43c8da))return!0x0;return!0x1;}function pu(_0x3a2494){_0x3a2494['visibleWrites']=Wo(_0x3a2494['allWrites'],_u,w()),_0x3a2494['allWrites']['length']>0x0?_0x3a2494['lastWriteId']=_0x3a2494['allWrites'][_0x3a2494['allWrites']['length']-0x1]['writeId']:_0x3a2494['lastWriteId']=-0x1;}function _u(_0x36f566){return _0x36f566['visible'];}function Wo(_0x171824,_0x5b87b3,_0xc96800){let _0x154a4c=K['empty']();for(let _0x5f2265=0x0;_0x5f2265<_0x171824['length'];++_0x5f2265){const _0x73baf5=_0x171824[_0x5f2265];if(_0x5b87b3(_0x73baf5)){const _0x1f3c28=_0x73baf5['path'];let _0x1a8099;if(_0x73baf5['snap'])G(_0xc96800,_0x1f3c28)?(_0x1a8099=F(_0xc96800,_0x1f3c28),_0x154a4c=At(_0x154a4c,_0x1a8099,_0x73baf5['snap'])):G(_0x1f3c28,_0xc96800)&&(_0x1a8099=F(_0x1f3c28,_0xc96800),_0x154a4c=At(_0x154a4c,w(),_0x73baf5['snap']['getChild'](_0x1a8099)));else{if(_0x73baf5['children']){if(G(_0xc96800,_0x1f3c28))_0x1a8099=F(_0xc96800,_0x1f3c28),_0x154a4c=bi(_0x154a4c,_0x1a8099,_0x73baf5['children']);else{if(G(_0x1f3c28,_0xc96800)){if(_0x1a8099=F(_0x1f3c28,_0xc96800),v(_0x1a8099))_0x154a4c=bi(_0x154a4c,w(),_0x73baf5['children']);else{const _0x205278=Le(_0x73baf5['children'],y(_0x1a8099));if(_0x205278){const _0x598a79=_0x205278['getChild'](S(_0x1a8099));_0x154a4c=At(_0x154a4c,w(),_0x598a79);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x154a4c;}function Bo(_0x2fbb8a,_0x3fb1c9,_0x40a636,_0x1b8ae8,_0x8aa28f){if(!_0x1b8ae8&&!_0x8aa28f){const _0x818026=ze(_0x2fbb8a['visibleWrites'],_0x3fb1c9);if(_0x818026!=null)return _0x818026;{const _0x415981=Ee(_0x2fbb8a['visibleWrites'],_0x3fb1c9);if(Ai(_0x415981))return _0x40a636;if(_0x40a636==null&&!Ri(_0x415981,w()))return null;{const _0x53b457=_0x40a636||g['EMPTY_NODE'];return at(_0x415981,_0x53b457);}}}else{const _0x2348c2=Ee(_0x2fbb8a['visibleWrites'],_0x3fb1c9);if(!_0x8aa28f&&Ai(_0x2348c2))return _0x40a636;if(!_0x8aa28f&&_0x40a636==null&&!Ri(_0x2348c2,w()))return null;{const _0x3ab65d=function(_0x52eec6){return(_0x52eec6['visible']||_0x8aa28f)&&(!_0x1b8ae8||!~_0x1b8ae8['indexOf'](_0x52eec6['writeId']))&&(G(_0x52eec6['path'],_0x3fb1c9)||G(_0x3fb1c9,_0x52eec6['path']));},_0x1bf7ae=Wo(_0x2fbb8a['allWrites'],_0x3ab65d,_0x3fb1c9),_0x1ace9a=_0x40a636||g['EMPTY_NODE'];return at(_0x1bf7ae,_0x1ace9a);}}}function gu(_0xa240ba,_0x4e73b2,_0xed2fb5){let _0x159aea=g['EMPTY_NODE'];const _0x3b2316=ze(_0xa240ba['visibleWrites'],_0x4e73b2);if(_0x3b2316)return _0x3b2316['isLeafNode']()||_0x3b2316['forEachChild'](R,(_0x11fb20,_0x34ad8d)=>{_0x159aea=_0x159aea['updateImmediateChild'](_0x11fb20,_0x34ad8d);}),_0x159aea;if(_0xed2fb5){const _0xd853af=Ee(_0xa240ba['visibleWrites'],_0x4e73b2);return _0xed2fb5['forEachChild'](R,(_0x273ee0,_0x537aa2)=>{const _0x1bf369=at(Ee(_0xd853af,new C(_0x273ee0)),_0x537aa2);_0x159aea=_0x159aea['updateImmediateChild'](_0x273ee0,_0x1bf369);}),ar(_0xd853af)['forEach'](_0x5c3264=>{_0x159aea=_0x159aea['updateImmediateChild'](_0x5c3264['name'],_0x5c3264['node']);}),_0x159aea;}else{const _0x15866f=Ee(_0xa240ba['visibleWrites'],_0x4e73b2);return ar(_0x15866f)['forEach'](_0x3ec333=>{_0x159aea=_0x159aea['updateImmediateChild'](_0x3ec333['name'],_0x3ec333['node']);}),_0x159aea;}}function mu(_0x42a5a4,_0x38cddb,_0x35810a,_0x3db1df,_0x2b5dc7){f(_0x3db1df||_0x2b5dc7,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x4b660c=k(_0x38cddb,_0x35810a);if(Ri(_0x42a5a4['visibleWrites'],_0x4b660c))return null;{const _0x488b13=Ee(_0x42a5a4['visibleWrites'],_0x4b660c);return Ai(_0x488b13)?_0x2b5dc7['getChild'](_0x35810a):at(_0x488b13,_0x2b5dc7['getChild'](_0x35810a));}}function yu(_0x13639c,_0x38514d,_0x31965f,_0xfce01a){const _0x427f35=k(_0x38514d,_0x31965f),_0xb89c4a=ze(_0x13639c['visibleWrites'],_0x427f35);if(_0xb89c4a!=null)return _0xb89c4a;if(_0xfce01a['isCompleteForChild'](_0x31965f)){const _0x4472d0=Ee(_0x13639c['visibleWrites'],_0x427f35);return at(_0x4472d0,_0xfce01a['getNode']()['getImmediateChild'](_0x31965f));}else return null;}function vu(_0x110316,_0x12ee2a){return ze(_0x110316['visibleWrites'],_0x12ee2a);}function Eu(_0x73c4c6,_0x2d89fb,_0x12f117,_0x265a8a,_0x107304,_0x14d3b2,_0x3eb8ed){let _0x24319b;const _0x1b313b=Ee(_0x73c4c6['visibleWrites'],_0x2d89fb),_0x40fb80=ze(_0x1b313b,w());if(_0x40fb80!=null)_0x24319b=_0x40fb80;else{if(_0x12f117!=null)_0x24319b=at(_0x1b313b,_0x12f117);else return[];}if(_0x24319b=_0x24319b['withIndex'](_0x3eb8ed),!_0x24319b['isEmpty']()&&!_0x24319b['isLeafNode']()){const _0x4f17e9=[],_0x3649d2=_0x3eb8ed['getCompare'](),_0x491ffc=_0x14d3b2?_0x24319b['getReverseIteratorFrom'](_0x265a8a,_0x3eb8ed):_0x24319b['getIteratorFrom'](_0x265a8a,_0x3eb8ed);let _0x5c917e=_0x491ffc['getNext']();for(;_0x5c917e&&_0x4f17e9['length']<_0x107304;)_0x3649d2(_0x5c917e,_0x265a8a)!==0x0&&_0x4f17e9['push'](_0x5c917e),_0x5c917e=_0x491ffc['getNext']();return _0x4f17e9;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x52ac6c,_0x3585a4,_0x5ce972,_0x4504fd){return Bo(_0x52ac6c['writeTree'],_0x52ac6c['treePath'],_0x3585a4,_0x5ce972,_0x4504fd);}function is(_0x47f7c8,_0xa1ef84){return gu(_0x47f7c8['writeTree'],_0x47f7c8['treePath'],_0xa1ef84);}function cr(_0x5a4283,_0x4440bb,_0x2435da,_0x2b673a){return mu(_0x5a4283['writeTree'],_0x5a4283['treePath'],_0x4440bb,_0x2435da,_0x2b673a);}function Tn(_0x18478c,_0x4648fb){return vu(_0x18478c['writeTree'],k(_0x18478c['treePath'],_0x4648fb));}function wu(_0x3bae65,_0x3398b6,_0x270f60,_0x23d93e,_0x3da4ea,_0x35195e){return Eu(_0x3bae65['writeTree'],_0x3bae65['treePath'],_0x3398b6,_0x270f60,_0x23d93e,_0x3da4ea,_0x35195e);}function ss(_0x29f6dd,_0x926b29,_0x380178){return yu(_0x29f6dd['writeTree'],_0x29f6dd['treePath'],_0x926b29,_0x380178);}function Vo(_0x59cd8f,_0x4a8148){return Ho(k(_0x59cd8f['treePath'],_0x4a8148),_0x59cd8f['writeTree']);}function Ho(_0x49085e,_0xc41320){return{'treePath':_0x49085e,'writeTree':_0xc41320};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x56d2de){const _0x33cd1a=_0x56d2de['type'],_0x48ed2d=_0x56d2de['childName'];f(_0x33cd1a==='child_added'||_0x33cd1a==='child_changed'||_0x33cd1a==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x48ed2d!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x4ef81a=this['changeMap']['get'](_0x48ed2d);if(_0x4ef81a){const _0x1c2d5f=_0x4ef81a['type'];if(_0x33cd1a==='child_added'&&_0x1c2d5f==='child_removed')this['changeMap']['set'](_0x48ed2d,xt(_0x48ed2d,_0x56d2de['snapshotNode'],_0x4ef81a['snapshotNode']));else{if(_0x33cd1a==='child_removed'&&_0x1c2d5f==='child_added')this['changeMap']['delete'](_0x48ed2d);else{if(_0x33cd1a==='child_removed'&&_0x1c2d5f==='child_changed')this['changeMap']['set'](_0x48ed2d,Lt(_0x48ed2d,_0x4ef81a['oldSnap']));else{if(_0x33cd1a==='child_changed'&&_0x1c2d5f==='child_added')this['changeMap']['set'](_0x48ed2d,rt(_0x48ed2d,_0x56d2de['snapshotNode']));else{if(_0x33cd1a==='child_changed'&&_0x1c2d5f==='child_changed')this['changeMap']['set'](_0x48ed2d,xt(_0x48ed2d,_0x56d2de['snapshotNode'],_0x4ef81a['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x56d2de+'\x20occurred\x20after\x20'+_0x4ef81a);}}}}}else this['changeMap']['set'](_0x48ed2d,_0x56d2de);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x3c0707){return null;}['getChildAfterChild'](_0x3e3701,_0x150e59,_0x4b5314){return null;}}const $o=new Tu();class rs{constructor(_0x29004d,_0x3ed4ab,_0x312500=null){this['writes_']=_0x29004d,this['viewCache_']=_0x3ed4ab,this['optCompleteServerCache_']=_0x312500;}['getCompleteChild'](_0x3a630a){const _0x772be4=this['viewCache_']['eventCache'];if(_0x772be4['isCompleteForChild'](_0x3a630a))return _0x772be4['getNode']()['getImmediateChild'](_0x3a630a);{const _0x24c788=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x3a630a,_0x24c788);}}['getChildAfterChild'](_0xc12b20,_0x35c154,_0x14c493){const _0x278dee=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x58b1a0=wu(this['writes_'],_0x278dee,_0x35c154,0x1,_0x14c493,_0xc12b20);return _0x58b1a0['length']===0x0?null:_0x58b1a0[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x14872a){return{'filter':_0x14872a};}function bu(_0x258bc9,_0x8f0447){f(_0x8f0447['eventCache']['getNode']()['isIndexed'](_0x258bc9['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x8f0447['serverCache']['getNode']()['isIndexed'](_0x258bc9['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x51d8a1,_0x2cdf7c,_0x43f79b,_0x300644,_0x49b0b4){const _0xd4df64=new Cu();let _0xd67e3f,_0x1ec4ec;if(_0x43f79b['type']===z['OVERWRITE']){const _0x1679d0=_0x43f79b;_0x1679d0['source']['fromUser']?_0xd67e3f=ki(_0x51d8a1,_0x2cdf7c,_0x1679d0['path'],_0x1679d0['snap'],_0x300644,_0x49b0b4,_0xd4df64):(f(_0x1679d0['source']['fromServer'],'Unknown\x20source.'),_0x1ec4ec=_0x1679d0['source']['tagged']||_0x2cdf7c['serverCache']['isFiltered']()&&!v(_0x1679d0['path']),_0xd67e3f=Sn(_0x51d8a1,_0x2cdf7c,_0x1679d0['path'],_0x1679d0['snap'],_0x300644,_0x49b0b4,_0x1ec4ec,_0xd4df64));}else{if(_0x43f79b['type']===z['MERGE']){const _0xa64a23=_0x43f79b;_0xa64a23['source']['fromUser']?_0xd67e3f=ku(_0x51d8a1,_0x2cdf7c,_0xa64a23['path'],_0xa64a23['children'],_0x300644,_0x49b0b4,_0xd4df64):(f(_0xa64a23['source']['fromServer'],'Unknown\x20source.'),_0x1ec4ec=_0xa64a23['source']['tagged']||_0x2cdf7c['serverCache']['isFiltered'](),_0xd67e3f=Pi(_0x51d8a1,_0x2cdf7c,_0xa64a23['path'],_0xa64a23['children'],_0x300644,_0x49b0b4,_0x1ec4ec,_0xd4df64));}else{if(_0x43f79b['type']===z['ACK_USER_WRITE']){const _0x34f7e4=_0x43f79b;_0x34f7e4['revert']?_0xd67e3f=Ou(_0x51d8a1,_0x2cdf7c,_0x34f7e4['path'],_0x300644,_0x49b0b4,_0xd4df64):_0xd67e3f=Pu(_0x51d8a1,_0x2cdf7c,_0x34f7e4['path'],_0x34f7e4['affectedTree'],_0x300644,_0x49b0b4,_0xd4df64);}else{if(_0x43f79b['type']===z['LISTEN_COMPLETE'])_0xd67e3f=Nu(_0x51d8a1,_0x2cdf7c,_0x43f79b['path'],_0x300644,_0xd4df64);else throw ht('Unknown\x20operation\x20type:\x20'+_0x43f79b['type']);}}}const _0x4d6572=_0xd4df64['getChanges']();return Au(_0x2cdf7c,_0xd67e3f,_0x4d6572),{'viewCache':_0xd67e3f,'changes':_0x4d6572};}function Au(_0x4bf652,_0x245f8a,_0x1df814){const _0x4ba286=_0x245f8a['eventCache'];if(_0x4ba286['isFullyInitialized']()){const _0x13a0be=_0x4ba286['getNode']()['isLeafNode']()||_0x4ba286['getNode']()['isEmpty'](),_0x17663c=wn(_0x4bf652);(_0x1df814['length']>0x0||!_0x4bf652['eventCache']['isFullyInitialized']()||_0x13a0be&&!_0x4ba286['getNode']()['equals'](_0x17663c)||!_0x4ba286['getNode']()['getPriority']()['equals'](_0x17663c['getPriority']()))&&_0x1df814['push'](Lo(wn(_0x245f8a)));}}function Go(_0x4e2b07,_0x48a768,_0x32e29c,_0x341bbe,_0x44bb70,_0xf75aaf){const _0x52a71c=_0x48a768['eventCache'];if(Tn(_0x341bbe,_0x32e29c)!=null)return _0x48a768;{let _0x2a379b,_0x16aa52;if(v(_0x32e29c)){if(f(_0x48a768['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x48a768['serverCache']['isFiltered']()){const _0x492d5f=Ve(_0x48a768),_0x129253=_0x492d5f instanceof g?_0x492d5f:g['EMPTY_NODE'],_0x4b6878=is(_0x341bbe,_0x129253);_0x2a379b=_0x4e2b07['filter']['updateFullNode'](_0x48a768['eventCache']['getNode'](),_0x4b6878,_0xf75aaf);}else{const _0x402040=Cn(_0x341bbe,Ve(_0x48a768));_0x2a379b=_0x4e2b07['filter']['updateFullNode'](_0x48a768['eventCache']['getNode'](),_0x402040,_0xf75aaf);}}else{const _0x319b7f=y(_0x32e29c);if(_0x319b7f==='.priority'){f(Ce(_0x32e29c)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x2f433f=_0x52a71c['getNode']();_0x16aa52=_0x48a768['serverCache']['getNode']();const _0x34768c=cr(_0x341bbe,_0x32e29c,_0x2f433f,_0x16aa52);_0x34768c!=null?_0x2a379b=_0x4e2b07['filter']['updatePriority'](_0x2f433f,_0x34768c):_0x2a379b=_0x52a71c['getNode']();}else{const _0x8d843=S(_0x32e29c);let _0x511829;if(_0x52a71c['isCompleteForChild'](_0x319b7f)){_0x16aa52=_0x48a768['serverCache']['getNode']();const _0x113b3c=cr(_0x341bbe,_0x32e29c,_0x52a71c['getNode'](),_0x16aa52);_0x113b3c!=null?_0x511829=_0x52a71c['getNode']()['getImmediateChild'](_0x319b7f)['updateChild'](_0x8d843,_0x113b3c):_0x511829=_0x52a71c['getNode']()['getImmediateChild'](_0x319b7f);}else _0x511829=ss(_0x341bbe,_0x319b7f,_0x48a768['serverCache']);_0x511829!=null?_0x2a379b=_0x4e2b07['filter']['updateChild'](_0x52a71c['getNode'](),_0x319b7f,_0x511829,_0x8d843,_0x44bb70,_0xf75aaf):_0x2a379b=_0x52a71c['getNode']();}}return Rt(_0x48a768,_0x2a379b,_0x52a71c['isFullyInitialized']()||v(_0x32e29c),_0x4e2b07['filter']['filtersNodes']());}}function Sn(_0x106902,_0x128f30,_0x5516ab,_0x4a377d,_0x5bd855,_0x56ce88,_0x8760e1,_0x595458){const _0x47c29c=_0x128f30['serverCache'];let _0x2f5eb7;const _0x4d3cb2=_0x8760e1?_0x106902['filter']:_0x106902['filter']['getIndexedFilter']();if(v(_0x5516ab))_0x2f5eb7=_0x4d3cb2['updateFullNode'](_0x47c29c['getNode'](),_0x4a377d,null);else{if(_0x4d3cb2['filtersNodes']()&&!_0x47c29c['isFiltered']()){const _0x513451=_0x47c29c['getNode']()['updateChild'](_0x5516ab,_0x4a377d);_0x2f5eb7=_0x4d3cb2['updateFullNode'](_0x47c29c['getNode'](),_0x513451,null);}else{const _0x7f4d34=y(_0x5516ab);if(!_0x47c29c['isCompleteForPath'](_0x5516ab)&&Ce(_0x5516ab)>0x1)return _0x128f30;const _0x57dceb=S(_0x5516ab),_0x5a5055=_0x47c29c['getNode']()['getImmediateChild'](_0x7f4d34)['updateChild'](_0x57dceb,_0x4a377d);_0x7f4d34==='.priority'?_0x2f5eb7=_0x4d3cb2['updatePriority'](_0x47c29c['getNode'](),_0x5a5055):_0x2f5eb7=_0x4d3cb2['updateChild'](_0x47c29c['getNode'](),_0x7f4d34,_0x5a5055,_0x57dceb,$o,null);}}const _0x4ad0a0=Fo(_0x128f30,_0x2f5eb7,_0x47c29c['isFullyInitialized']()||v(_0x5516ab),_0x4d3cb2['filtersNodes']()),_0x49faa7=new rs(_0x5bd855,_0x4ad0a0,_0x56ce88);return Go(_0x106902,_0x4ad0a0,_0x5516ab,_0x5bd855,_0x49faa7,_0x595458);}function ki(_0xc3e9cc,_0x58ecea,_0x5635fa,_0x6a7e0d,_0x3c6b2e,_0x66d55b,_0x1be38a){const _0x13f96c=_0x58ecea['eventCache'];let _0x1baf48,_0x6599ad;const _0x525444=new rs(_0x3c6b2e,_0x58ecea,_0x66d55b);if(v(_0x5635fa))_0x6599ad=_0xc3e9cc['filter']['updateFullNode'](_0x58ecea['eventCache']['getNode'](),_0x6a7e0d,_0x1be38a),_0x1baf48=Rt(_0x58ecea,_0x6599ad,!0x0,_0xc3e9cc['filter']['filtersNodes']());else{const _0x227846=y(_0x5635fa);if(_0x227846==='.priority')_0x6599ad=_0xc3e9cc['filter']['updatePriority'](_0x58ecea['eventCache']['getNode'](),_0x6a7e0d),_0x1baf48=Rt(_0x58ecea,_0x6599ad,_0x13f96c['isFullyInitialized'](),_0x13f96c['isFiltered']());else{const _0x13149e=S(_0x5635fa),_0x27c073=_0x13f96c['getNode']()['getImmediateChild'](_0x227846);let _0x4cfc22;if(v(_0x13149e))_0x4cfc22=_0x6a7e0d;else{const _0x4ce1a6=_0x525444['getCompleteChild'](_0x227846);_0x4ce1a6!=null?ji(_0x13149e)==='.priority'&&_0x4ce1a6['getChild'](Ro(_0x13149e))['isEmpty']()?_0x4cfc22=_0x4ce1a6:_0x4cfc22=_0x4ce1a6['updateChild'](_0x13149e,_0x6a7e0d):_0x4cfc22=g['EMPTY_NODE'];}if(_0x27c073['equals'](_0x4cfc22))_0x1baf48=_0x58ecea;else{const _0x1330e6=_0xc3e9cc['filter']['updateChild'](_0x13f96c['getNode'](),_0x227846,_0x4cfc22,_0x13149e,_0x525444,_0x1be38a);_0x1baf48=Rt(_0x58ecea,_0x1330e6,_0x13f96c['isFullyInitialized'](),_0xc3e9cc['filter']['filtersNodes']());}}}return _0x1baf48;}function lr(_0x522cd4,_0x591e3d){return _0x522cd4['eventCache']['isCompleteForChild'](_0x591e3d);}function ku(_0x2c39bc,_0x55215f,_0xe251a1,_0x73c740,_0x1071e6,_0x597c3b,_0x14a357){let _0x57b22d=_0x55215f;return _0x73c740['foreach']((_0x54e428,_0x5c32d0)=>{const _0x46865c=k(_0xe251a1,_0x54e428);lr(_0x55215f,y(_0x46865c))&&(_0x57b22d=ki(_0x2c39bc,_0x57b22d,_0x46865c,_0x5c32d0,_0x1071e6,_0x597c3b,_0x14a357));}),_0x73c740['foreach']((_0xdc7d5,_0x1d9a92)=>{const _0x552047=k(_0xe251a1,_0xdc7d5);lr(_0x55215f,y(_0x552047))||(_0x57b22d=ki(_0x2c39bc,_0x57b22d,_0x552047,_0x1d9a92,_0x1071e6,_0x597c3b,_0x14a357));}),_0x57b22d;}function hr(_0x3247bd,_0x5cc7f4,_0x1e899d){return _0x1e899d['foreach']((_0x4a906b,_0x1e1e98)=>{_0x5cc7f4=_0x5cc7f4['updateChild'](_0x4a906b,_0x1e1e98);}),_0x5cc7f4;}function Pi(_0x34e88e,_0x4c39bb,_0x31b470,_0x255c43,_0x3cb899,_0xb3ddf3,_0xc69cc9,_0x16c903){if(_0x4c39bb['serverCache']['getNode']()['isEmpty']()&&!_0x4c39bb['serverCache']['isFullyInitialized']())return _0x4c39bb;let _0x43ca6c=_0x4c39bb,_0x2eef6e;v(_0x31b470)?_0x2eef6e=_0x255c43:_0x2eef6e=new b(null)['setTree'](_0x31b470,_0x255c43);const _0x171cf3=_0x4c39bb['serverCache']['getNode']();return _0x2eef6e['children']['inorderTraversal']((_0x5eb1ee,_0x1b0352)=>{if(_0x171cf3['hasChild'](_0x5eb1ee)){const _0x18041f=_0x4c39bb['serverCache']['getNode']()['getImmediateChild'](_0x5eb1ee),_0x112a9c=hr(_0x34e88e,_0x18041f,_0x1b0352);_0x43ca6c=Sn(_0x34e88e,_0x43ca6c,new C(_0x5eb1ee),_0x112a9c,_0x3cb899,_0xb3ddf3,_0xc69cc9,_0x16c903);}}),_0x2eef6e['children']['inorderTraversal']((_0x5ba190,_0x2916f5)=>{const _0x7bd7b2=!_0x4c39bb['serverCache']['isCompleteForChild'](_0x5ba190)&&_0x2916f5['value']===null;if(!_0x171cf3['hasChild'](_0x5ba190)&&!_0x7bd7b2){const _0x493f39=_0x4c39bb['serverCache']['getNode']()['getImmediateChild'](_0x5ba190),_0x49de22=hr(_0x34e88e,_0x493f39,_0x2916f5);_0x43ca6c=Sn(_0x34e88e,_0x43ca6c,new C(_0x5ba190),_0x49de22,_0x3cb899,_0xb3ddf3,_0xc69cc9,_0x16c903);}}),_0x43ca6c;}function Pu(_0x6ed333,_0x11c023,_0x5f3839,_0x4daba1,_0x323c1a,_0x3f59ba,_0x58ed77){if(Tn(_0x323c1a,_0x5f3839)!=null)return _0x11c023;const _0x4ee115=_0x11c023['serverCache']['isFiltered'](),_0x10ed85=_0x11c023['serverCache'];if(_0x4daba1['value']!=null){if(v(_0x5f3839)&&_0x10ed85['isFullyInitialized']()||_0x10ed85['isCompleteForPath'](_0x5f3839))return Sn(_0x6ed333,_0x11c023,_0x5f3839,_0x10ed85['getNode']()['getChild'](_0x5f3839),_0x323c1a,_0x3f59ba,_0x4ee115,_0x58ed77);if(v(_0x5f3839)){let _0x13828b=new b(null);return _0x10ed85['getNode']()['forEachChild'](ve,(_0x14f3de,_0x43e78a)=>{_0x13828b=_0x13828b['set'](new C(_0x14f3de),_0x43e78a);}),Pi(_0x6ed333,_0x11c023,_0x5f3839,_0x13828b,_0x323c1a,_0x3f59ba,_0x4ee115,_0x58ed77);}else return _0x11c023;}else{let _0x37ca56=new b(null);return _0x4daba1['foreach']((_0x382cba,_0x506bd0)=>{const _0x95c23d=k(_0x5f3839,_0x382cba);_0x10ed85['isCompleteForPath'](_0x95c23d)&&(_0x37ca56=_0x37ca56['set'](_0x382cba,_0x10ed85['getNode']()['getChild'](_0x95c23d)));}),Pi(_0x6ed333,_0x11c023,_0x5f3839,_0x37ca56,_0x323c1a,_0x3f59ba,_0x4ee115,_0x58ed77);}}function Nu(_0x1ca676,_0x109b82,_0xba97b,_0x39d922,_0x4b11f6){const _0x379330=_0x109b82['serverCache'],_0xfc3131=Fo(_0x109b82,_0x379330['getNode'](),_0x379330['isFullyInitialized']()||v(_0xba97b),_0x379330['isFiltered']());return Go(_0x1ca676,_0xfc3131,_0xba97b,_0x39d922,$o,_0x4b11f6);}function Ou(_0x4244ac,_0x3427b8,_0xb41c4a,_0xc0619c,_0x4fd77b,_0x57ebed){let _0x10cc5e;if(Tn(_0xc0619c,_0xb41c4a)!=null)return _0x3427b8;{const _0x4cfa23=new rs(_0xc0619c,_0x3427b8,_0x4fd77b),_0x275b50=_0x3427b8['eventCache']['getNode']();let _0xcf75cc;if(v(_0xb41c4a)||y(_0xb41c4a)==='.priority'){let _0x1702f5;if(_0x3427b8['serverCache']['isFullyInitialized']())_0x1702f5=Cn(_0xc0619c,Ve(_0x3427b8));else{const _0xec9c34=_0x3427b8['serverCache']['getNode']();f(_0xec9c34 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x1702f5=is(_0xc0619c,_0xec9c34);}_0x1702f5=_0x1702f5,_0xcf75cc=_0x4244ac['filter']['updateFullNode'](_0x275b50,_0x1702f5,_0x57ebed);}else{const _0x3889b9=y(_0xb41c4a);let _0x1edc91=ss(_0xc0619c,_0x3889b9,_0x3427b8['serverCache']);_0x1edc91==null&&_0x3427b8['serverCache']['isCompleteForChild'](_0x3889b9)&&(_0x1edc91=_0x275b50['getImmediateChild'](_0x3889b9)),_0x1edc91!=null?_0xcf75cc=_0x4244ac['filter']['updateChild'](_0x275b50,_0x3889b9,_0x1edc91,S(_0xb41c4a),_0x4cfa23,_0x57ebed):_0x3427b8['eventCache']['getNode']()['hasChild'](_0x3889b9)?_0xcf75cc=_0x4244ac['filter']['updateChild'](_0x275b50,_0x3889b9,g['EMPTY_NODE'],S(_0xb41c4a),_0x4cfa23,_0x57ebed):_0xcf75cc=_0x275b50,_0xcf75cc['isEmpty']()&&_0x3427b8['serverCache']['isFullyInitialized']()&&(_0x10cc5e=Cn(_0xc0619c,Ve(_0x3427b8)),_0x10cc5e['isLeafNode']()&&(_0xcf75cc=_0x4244ac['filter']['updateFullNode'](_0xcf75cc,_0x10cc5e,_0x57ebed)));}return _0x10cc5e=_0x3427b8['serverCache']['isFullyInitialized']()||Tn(_0xc0619c,w())!=null,Rt(_0x3427b8,_0xcf75cc,_0x10cc5e,_0x4244ac['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x12187c,_0x1e3bde){this['query_']=_0x12187c,this['eventRegistrations_']=[];const _0x15078e=this['query_']['_queryParams'],_0x3c7892=new Xi(_0x15078e['getIndex']()),_0x3ed435=Kh(_0x15078e);this['processor_']=Su(_0x3ed435);const _0x128a9e=_0x1e3bde['serverCache'],_0x400bb3=_0x1e3bde['eventCache'],_0x42bee4=_0x3c7892['updateFullNode'](g['EMPTY_NODE'],_0x128a9e['getNode'](),null),_0x3fd66d=_0x3ed435['updateFullNode'](g['EMPTY_NODE'],_0x400bb3['getNode'](),null),_0x48192a=new Te(_0x42bee4,_0x128a9e['isFullyInitialized'](),_0x3c7892['filtersNodes']()),_0x184a74=new Te(_0x3fd66d,_0x400bb3['isFullyInitialized'](),_0x3ed435['filtersNodes']());this['viewCache_']=Un(_0x184a74,_0x48192a),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x789e22){return _0x789e22['viewCache_']['serverCache']['getNode']();}function Lu(_0x5106ef){return wn(_0x5106ef['viewCache_']);}function xu(_0x519471,_0x1f346f){const _0x4e43f7=Ve(_0x519471['viewCache_']);return _0x4e43f7&&(_0x519471['query']['_queryParams']['loadsAllData']()||!v(_0x1f346f)&&!_0x4e43f7['getImmediateChild'](y(_0x1f346f))['isEmpty']())?_0x4e43f7['getChild'](_0x1f346f):null;}function ur(_0x2e45d3){return _0x2e45d3['eventRegistrations_']['length']===0x0;}function Fu(_0xe8cca2,_0x107086){_0xe8cca2['eventRegistrations_']['push'](_0x107086);}function dr(_0xd273e5,_0x4c2cc2,_0x1c2d2e){const _0x2d4f87=[];if(_0x1c2d2e){f(_0x4c2cc2==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x17160e=_0xd273e5['query']['_path'];_0xd273e5['eventRegistrations_']['forEach'](_0x880e5c=>{const _0x2ebc26=_0x880e5c['createCancelEvent'](_0x1c2d2e,_0x17160e);_0x2ebc26&&_0x2d4f87['push'](_0x2ebc26);});}if(_0x4c2cc2){let _0x338d3a=[];for(let _0x59c49c=0x0;_0x59c49c<_0xd273e5['eventRegistrations_']['length'];++_0x59c49c){const _0x2ccf96=_0xd273e5['eventRegistrations_'][_0x59c49c];if(!_0x2ccf96['matches'](_0x4c2cc2))_0x338d3a['push'](_0x2ccf96);else{if(_0x4c2cc2['hasAnyCallback']()){_0x338d3a=_0x338d3a['concat'](_0xd273e5['eventRegistrations_']['slice'](_0x59c49c+0x1));break;}}}_0xd273e5['eventRegistrations_']=_0x338d3a;}else _0xd273e5['eventRegistrations_']=[];return _0x2d4f87;}function fr(_0x3a1b52,_0x39b382,_0x118d38,_0x261116){_0x39b382['type']===z['MERGE']&&_0x39b382['source']['queryId']!==null&&(f(Ve(_0x3a1b52['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x3a1b52['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x585ab4=_0x3a1b52['viewCache_'],_0x42a197=Ru(_0x3a1b52['processor_'],_0x585ab4,_0x39b382,_0x118d38,_0x261116);return bu(_0x3a1b52['processor_'],_0x42a197['viewCache']),f(_0x42a197['viewCache']['serverCache']['isFullyInitialized']()||!_0x585ab4['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x3a1b52['viewCache_']=_0x42a197['viewCache'],qo(_0x3a1b52,_0x42a197['changes'],_0x42a197['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x42362b,_0x332607){const _0x4132c9=_0x42362b['viewCache_']['eventCache'],_0xb2f655=[];return _0x4132c9['getNode']()['isLeafNode']()||_0x4132c9['getNode']()['forEachChild'](R,(_0x1747ea,_0x4b5593)=>{_0xb2f655['push'](rt(_0x1747ea,_0x4b5593));}),_0x4132c9['isFullyInitialized']()&&_0xb2f655['push'](Lo(_0x4132c9['getNode']())),qo(_0x42362b,_0xb2f655,_0x4132c9['getNode'](),_0x332607);}function qo(_0x1e79b2,_0x1a73f5,_0x5d0ac3,_0x4608b1){const _0x9cda26=_0x4608b1?[_0x4608b1]:_0x1e79b2['eventRegistrations_'];return ru(_0x1e79b2['eventGenerator_'],_0x1a73f5,_0x5d0ac3,_0x9cda26);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x465c7f){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x465c7f;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x3818bb){return _0x3818bb['views']['size']===0x0;}function os(_0x49ee98,_0x196b94,_0x253948,_0x203365){const _0x338012=_0x196b94['source']['queryId'];if(_0x338012!==null){const _0x4dcfa8=_0x49ee98['views']['get'](_0x338012);return f(_0x4dcfa8!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x4dcfa8,_0x196b94,_0x253948,_0x203365);}else{let _0x52244b=[];for(const _0x1dd028 of _0x49ee98['views']['values']())_0x52244b=_0x52244b['concat'](fr(_0x1dd028,_0x196b94,_0x253948,_0x203365));return _0x52244b;}}function jo(_0x18d1b2,_0x15d453,_0x35d335,_0x198b9b,_0x84edd7){const _0x514cb4=_0x15d453['_queryIdentifier'],_0x4d6220=_0x18d1b2['views']['get'](_0x514cb4);if(!_0x4d6220){let _0x329e15=Cn(_0x35d335,_0x84edd7?_0x198b9b:null),_0x11ea65=!0x1;_0x329e15?_0x11ea65=!0x0:_0x198b9b instanceof g?(_0x329e15=is(_0x35d335,_0x198b9b),_0x11ea65=!0x1):(_0x329e15=g['EMPTY_NODE'],_0x11ea65=!0x1);const _0x5c57ad=Un(new Te(_0x329e15,_0x11ea65,!0x1),new Te(_0x198b9b,_0x84edd7,!0x1));return new Du(_0x15d453,_0x5c57ad);}return _0x4d6220;}function Hu(_0x1f4738,_0x3648e1,_0x176ecd,_0x27cf2d,_0x7d74f4,_0x3cb30c){const _0x46c194=jo(_0x1f4738,_0x3648e1,_0x27cf2d,_0x7d74f4,_0x3cb30c);return _0x1f4738['views']['has'](_0x3648e1['_queryIdentifier'])||_0x1f4738['views']['set'](_0x3648e1['_queryIdentifier'],_0x46c194),Fu(_0x46c194,_0x176ecd),Uu(_0x46c194,_0x176ecd);}function $u(_0x4ed447,_0x2ff32f,_0x1a7c9f,_0x1fdd48){const _0x220e5b=_0x2ff32f['_queryIdentifier'],_0x472519=[];let _0x6b0bc6=[];const _0x25437f=Se(_0x4ed447);if(_0x220e5b==='default'){for(const [_0x487104,_0x159ef9]of _0x4ed447['views']['entries']())_0x6b0bc6=_0x6b0bc6['concat'](dr(_0x159ef9,_0x1a7c9f,_0x1fdd48)),ur(_0x159ef9)&&(_0x4ed447['views']['delete'](_0x487104),_0x159ef9['query']['_queryParams']['loadsAllData']()||_0x472519['push'](_0x159ef9['query']));}else{const _0x22674a=_0x4ed447['views']['get'](_0x220e5b);_0x22674a&&(_0x6b0bc6=_0x6b0bc6['concat'](dr(_0x22674a,_0x1a7c9f,_0x1fdd48)),ur(_0x22674a)&&(_0x4ed447['views']['delete'](_0x220e5b),_0x22674a['query']['_queryParams']['loadsAllData']()||_0x472519['push'](_0x22674a['query'])));}return _0x25437f&&!Se(_0x4ed447)&&_0x472519['push'](new(Bu())(_0x2ff32f['_repo'],_0x2ff32f['_path'])),{'removed':_0x472519,'events':_0x6b0bc6};}function Ko(_0x125f11){const _0x2f6708=[];for(const _0x338801 of _0x125f11['views']['values']())_0x338801['query']['_queryParams']['loadsAllData']()||_0x2f6708['push'](_0x338801);return _0x2f6708;}function Ie(_0x4854c4,_0x2c1a95){let _0x22b657=null;for(const _0x17c928 of _0x4854c4['views']['values']())_0x22b657=_0x22b657||xu(_0x17c928,_0x2c1a95);return _0x22b657;}function Yo(_0xd7cef2,_0x393a7d){if(_0x393a7d['_queryParams']['loadsAllData']())return Bn(_0xd7cef2);{const _0x28db13=_0x393a7d['_queryIdentifier'];return _0xd7cef2['views']['get'](_0x28db13);}}function Qo(_0x46ba73,_0x12e499){return Yo(_0x46ba73,_0x12e499)!=null;}function Se(_0x4808c0){return Bn(_0x4808c0)!=null;}function Bn(_0x16532c){for(const _0x5e14c4 of _0x16532c['views']['values']())if(_0x5e14c4['query']['_queryParams']['loadsAllData']())return _0x5e14c4;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x166928){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x166928;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0xf93f73){this['listenProvider_']=_0xf93f73,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x5222de,_0x12d392,_0x5a0d5d,_0x49ebb7,_0x6d556a){return lu(_0x5222de['pendingWriteTree_'],_0x12d392,_0x5a0d5d,_0x49ebb7,_0x6d556a),_0x6d556a?_t(_0x5222de,new Be(es(),_0x12d392,_0x5a0d5d)):[];}function ju(_0x6ae827,_0x4182c0,_0x2b7a64,_0x37dd40){hu(_0x6ae827['pendingWriteTree_'],_0x4182c0,_0x2b7a64,_0x37dd40);const _0x19d838=b['fromObject'](_0x2b7a64);return _t(_0x6ae827,new ot(es(),_0x4182c0,_0x19d838));}function _e(_0x3e68ec,_0x15fec4,_0x536436=!0x1){const _0x444212=uu(_0x3e68ec['pendingWriteTree_'],_0x15fec4);if(du(_0x3e68ec['pendingWriteTree_'],_0x15fec4)){let _0x3e51d9=new b(null);return _0x444212['snap']!=null?_0x3e51d9=_0x3e51d9['set'](w(),!0x0):x(_0x444212['children'],_0x3fc8fb=>{_0x3e51d9=_0x3e51d9['set'](new C(_0x3fc8fb),!0x0);}),_t(_0x3e68ec,new In(_0x444212['path'],_0x3e51d9,_0x536436));}else return[];}function Yt(_0x23e8cd,_0x1e2bd8,_0x578c1e){return _t(_0x23e8cd,new Be(ts(),_0x1e2bd8,_0x578c1e));}function Ku(_0x3306c2,_0x1f4c7f,_0x3157cf){const _0x28aac3=b['fromObject'](_0x3157cf);return _t(_0x3306c2,new ot(ts(),_0x1f4c7f,_0x28aac3));}function Yu(_0x2de44b,_0x40a3e2){return _t(_0x2de44b,new Ut(ts(),_0x40a3e2));}function Qu(_0x22b624,_0x366d14,_0xd44bed){const _0x4a6a54=cs(_0x22b624,_0xd44bed);if(_0x4a6a54){const _0x3c7b96=ls(_0x4a6a54),_0x4b8766=_0x3c7b96['path'],_0x3207e1=_0x3c7b96['queryId'],_0x590987=F(_0x4b8766,_0x366d14),_0x40408d=new Ut(ns(_0x3207e1),_0x590987);return hs(_0x22b624,_0x4b8766,_0x40408d);}else return[];}function An(_0x8e2544,_0x2cb0e2,_0x4fbdd1,_0x34a335,_0x3c23b1=!0x1){const _0x362134=_0x2cb0e2['_path'],_0x20a4a5=_0x8e2544['syncPointTree_']['get'](_0x362134);let _0x31409d=[];if(_0x20a4a5&&(_0x2cb0e2['_queryIdentifier']==='default'||Qo(_0x20a4a5,_0x2cb0e2))){const _0x5c4792=$u(_0x20a4a5,_0x2cb0e2,_0x4fbdd1,_0x34a335);Vu(_0x20a4a5)&&(_0x8e2544['syncPointTree_']=_0x8e2544['syncPointTree_']['remove'](_0x362134));const _0x5f1c4f=_0x5c4792['removed'];if(_0x31409d=_0x5c4792['events'],!_0x3c23b1){const _0x41dce6=_0x5f1c4f['findIndex'](_0x477889=>_0x477889['_queryParams']['loadsAllData']())!==-0x1,_0x3b4538=_0x8e2544['syncPointTree_']['findOnPath'](_0x362134,(_0x5e123b,_0x4bff83)=>Se(_0x4bff83));if(_0x41dce6&&!_0x3b4538){const _0x3e924a=_0x8e2544['syncPointTree_']['subtree'](_0x362134);if(!_0x3e924a['isEmpty']()){const _0x4feede=Zu(_0x3e924a);for(let _0x180446=0x0;_0x180446<_0x4feede['length'];++_0x180446){const _0x1a6282=_0x4feede[_0x180446],_0x1dfebe=_0x1a6282['query'],_0x4db189=ea(_0x8e2544,_0x1a6282);_0x8e2544['listenProvider_']['startListening'](kt(_0x1dfebe),Wt(_0x8e2544,_0x1dfebe),_0x4db189['hashFn'],_0x4db189['onComplete']);}}}!_0x3b4538&&_0x5f1c4f['length']>0x0&&!_0x34a335&&(_0x41dce6?_0x8e2544['listenProvider_']['stopListening'](kt(_0x2cb0e2),null):_0x5f1c4f['forEach'](_0x467f49=>{const _0x3d3b3e=_0x8e2544['queryToTagMap']['get'](Hn(_0x467f49));_0x8e2544['listenProvider_']['stopListening'](kt(_0x467f49),_0x3d3b3e);}));}ed(_0x8e2544,_0x5f1c4f);}return _0x31409d;}function Jo(_0x5ed5cf,_0xe6f506,_0xe5b5ff,_0xe891dd){const _0x4e01a6=cs(_0x5ed5cf,_0xe891dd);if(_0x4e01a6!=null){const _0x928cb9=ls(_0x4e01a6),_0x1d4254=_0x928cb9['path'],_0x36324d=_0x928cb9['queryId'],_0xbc192e=F(_0x1d4254,_0xe6f506),_0xcc1a37=new Be(ns(_0x36324d),_0xbc192e,_0xe5b5ff);return hs(_0x5ed5cf,_0x1d4254,_0xcc1a37);}else return[];}function Ju(_0x1143e8,_0x4f2c00,_0x2948f4,_0x43c2b9){const _0xfb3afd=cs(_0x1143e8,_0x43c2b9);if(_0xfb3afd){const _0x551298=ls(_0xfb3afd),_0x1cf2d0=_0x551298['path'],_0x5dfee8=_0x551298['queryId'],_0x1d8e4b=F(_0x1cf2d0,_0x4f2c00),_0x4fbd64=b['fromObject'](_0x2948f4),_0x314c99=new ot(ns(_0x5dfee8),_0x1d8e4b,_0x4fbd64);return hs(_0x1143e8,_0x1cf2d0,_0x314c99);}else return[];}function Ni(_0x3864e4,_0x3ebac3,_0x20e9c3,_0x268ae1=!0x1){const _0x401437=_0x3ebac3['_path'];let _0x3204d9=null,_0x28b4ad=!0x1;_0x3864e4['syncPointTree_']['foreachOnPath'](_0x401437,(_0x8ff495,_0x4ec03b)=>{const _0xeb828b=F(_0x8ff495,_0x401437);_0x3204d9=_0x3204d9||Ie(_0x4ec03b,_0xeb828b),_0x28b4ad=_0x28b4ad||Se(_0x4ec03b);});let _0xa26673=_0x3864e4['syncPointTree_']['get'](_0x401437);_0xa26673?(_0x28b4ad=_0x28b4ad||Se(_0xa26673),_0x3204d9=_0x3204d9||Ie(_0xa26673,w())):(_0xa26673=new zo(),_0x3864e4['syncPointTree_']=_0x3864e4['syncPointTree_']['set'](_0x401437,_0xa26673));let _0x4494ac;_0x3204d9!=null?_0x4494ac=!0x0:(_0x4494ac=!0x1,_0x3204d9=g['EMPTY_NODE'],_0x3864e4['syncPointTree_']['subtree'](_0x401437)['foreachChild']((_0x114472,_0x53c9c3)=>{const _0x4f9dfa=Ie(_0x53c9c3,w());_0x4f9dfa&&(_0x3204d9=_0x3204d9['updateImmediateChild'](_0x114472,_0x4f9dfa));}));const _0x3090d6=Qo(_0xa26673,_0x3ebac3);if(!_0x3090d6&&!_0x3ebac3['_queryParams']['loadsAllData']()){const _0x70ccb6=Hn(_0x3ebac3);f(!_0x3864e4['queryToTagMap']['has'](_0x70ccb6),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x188655=td();_0x3864e4['queryToTagMap']['set'](_0x70ccb6,_0x188655),_0x3864e4['tagToQueryMap']['set'](_0x188655,_0x70ccb6);}const _0xc2189f=Wn(_0x3864e4['pendingWriteTree_'],_0x401437);let _0x13c490=Hu(_0xa26673,_0x3ebac3,_0x20e9c3,_0xc2189f,_0x3204d9,_0x4494ac);if(!_0x3090d6&&!_0x28b4ad&&!_0x268ae1){const _0x2e6412=Yo(_0xa26673,_0x3ebac3);_0x13c490=_0x13c490['concat'](nd(_0x3864e4,_0x3ebac3,_0x2e6412));}return _0x13c490;}function Vn(_0x14b046,_0x3214e9,_0x17c3bd){const _0x1ea8b1=_0x14b046['pendingWriteTree_'],_0x3a95de=_0x14b046['syncPointTree_']['findOnPath'](_0x3214e9,(_0x2d94ea,_0x32ff21)=>{const _0x20e193=F(_0x2d94ea,_0x3214e9),_0x4e9c55=Ie(_0x32ff21,_0x20e193);if(_0x4e9c55)return _0x4e9c55;});return Bo(_0x1ea8b1,_0x3214e9,_0x3a95de,_0x17c3bd,!0x0);}function Xu(_0x2b67eb,_0x59d789){const _0x3f3032=_0x59d789['_path'];let _0x324b5c=null;_0x2b67eb['syncPointTree_']['foreachOnPath'](_0x3f3032,(_0xa72fe6,_0x8798a2)=>{const _0x34246a=F(_0xa72fe6,_0x3f3032);_0x324b5c=_0x324b5c||Ie(_0x8798a2,_0x34246a);});let _0x3774b1=_0x2b67eb['syncPointTree_']['get'](_0x3f3032);_0x3774b1?_0x324b5c=_0x324b5c||Ie(_0x3774b1,w()):(_0x3774b1=new zo(),_0x2b67eb['syncPointTree_']=_0x2b67eb['syncPointTree_']['set'](_0x3f3032,_0x3774b1));const _0x57eced=_0x324b5c!=null,_0x450a0c=_0x57eced?new Te(_0x324b5c,!0x0,!0x1):null,_0x335048=Wn(_0x2b67eb['pendingWriteTree_'],_0x59d789['_path']),_0x4b096f=jo(_0x3774b1,_0x59d789,_0x335048,_0x57eced?_0x450a0c['getNode']():g['EMPTY_NODE'],_0x57eced);return Lu(_0x4b096f);}function _t(_0x122b52,_0x17deaf){return Xo(_0x17deaf,_0x122b52['syncPointTree_'],null,Wn(_0x122b52['pendingWriteTree_'],w()));}function Xo(_0x4f3474,_0x4b1351,_0x157dc3,_0x2b2811){if(v(_0x4f3474['path']))return Zo(_0x4f3474,_0x4b1351,_0x157dc3,_0x2b2811);{const _0x3725ca=_0x4b1351['get'](w());_0x157dc3==null&&_0x3725ca!=null&&(_0x157dc3=Ie(_0x3725ca,w()));let _0x283224=[];const _0x483fc0=y(_0x4f3474['path']),_0x399395=_0x4f3474['operationForChild'](_0x483fc0),_0x347079=_0x4b1351['children']['get'](_0x483fc0);if(_0x347079&&_0x399395){const _0x28d981=_0x157dc3?_0x157dc3['getImmediateChild'](_0x483fc0):null,_0x1a2cce=Vo(_0x2b2811,_0x483fc0);_0x283224=_0x283224['concat'](Xo(_0x399395,_0x347079,_0x28d981,_0x1a2cce));}return _0x3725ca&&(_0x283224=_0x283224['concat'](os(_0x3725ca,_0x4f3474,_0x2b2811,_0x157dc3))),_0x283224;}}function Zo(_0x11b659,_0x3e84ae,_0x2dd218,_0x597d85){const _0x31f100=_0x3e84ae['get'](w());_0x2dd218==null&&_0x31f100!=null&&(_0x2dd218=Ie(_0x31f100,w()));let _0x3b4984=[];return _0x3e84ae['children']['inorderTraversal']((_0x10c8a6,_0x2adbc5)=>{const _0x449d6f=_0x2dd218?_0x2dd218['getImmediateChild'](_0x10c8a6):null,_0x292602=Vo(_0x597d85,_0x10c8a6),_0x273f85=_0x11b659['operationForChild'](_0x10c8a6);_0x273f85&&(_0x3b4984=_0x3b4984['concat'](Zo(_0x273f85,_0x2adbc5,_0x449d6f,_0x292602)));}),_0x31f100&&(_0x3b4984=_0x3b4984['concat'](os(_0x31f100,_0x11b659,_0x597d85,_0x2dd218))),_0x3b4984;}function ea(_0x416d1b,_0x56a247){const _0x168727=_0x56a247['query'],_0x1ff58a=Wt(_0x416d1b,_0x168727);return{'hashFn':()=>(Mu(_0x56a247)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x3d0900=>{if(_0x3d0900==='ok')return _0x1ff58a?Qu(_0x416d1b,_0x168727['_path'],_0x1ff58a):Yu(_0x416d1b,_0x168727['_path']);{const _0x1afb0a=Kl(_0x3d0900,_0x168727);return An(_0x416d1b,_0x168727,null,_0x1afb0a);}}};}function Wt(_0x2cb675,_0x3b790b){const _0xcf236a=Hn(_0x3b790b);return _0x2cb675['queryToTagMap']['get'](_0xcf236a);}function Hn(_0x523c63){return _0x523c63['_path']['toString']()+'$'+_0x523c63['_queryIdentifier'];}function cs(_0x442e99,_0x396317){return _0x442e99['tagToQueryMap']['get'](_0x396317);}function ls(_0x10c502){const _0x43cbbb=_0x10c502['indexOf']('$');return f(_0x43cbbb!==-0x1&&_0x43cbbb<_0x10c502['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x10c502['substr'](_0x43cbbb+0x1),'path':new C(_0x10c502['substr'](0x0,_0x43cbbb))};}function hs(_0x278bec,_0x2b3288,_0x3e3255){const _0x1c731c=_0x278bec['syncPointTree_']['get'](_0x2b3288);f(_0x1c731c,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x5291c4=Wn(_0x278bec['pendingWriteTree_'],_0x2b3288);return os(_0x1c731c,_0x3e3255,_0x5291c4,null);}function Zu(_0x30a064){return _0x30a064['fold']((_0x56c100,_0x2ee250,_0xb1caec)=>{if(_0x2ee250&&Se(_0x2ee250))return[Bn(_0x2ee250)];{let _0x4bd2f4=[];return _0x2ee250&&(_0x4bd2f4=Ko(_0x2ee250)),x(_0xb1caec,(_0x57a9b7,_0x53fe7f)=>{_0x4bd2f4=_0x4bd2f4['concat'](_0x53fe7f);}),_0x4bd2f4;}});}function kt(_0x257620){return _0x257620['_queryParams']['loadsAllData']()&&!_0x257620['_queryParams']['isDefault']()?new(qu())(_0x257620['_repo'],_0x257620['_path']):_0x257620;}function ed(_0x18bb1d,_0x271674){for(let _0x4f7863=0x0;_0x4f7863<_0x271674['length'];++_0x4f7863){const _0x3f0c45=_0x271674[_0x4f7863];if(!_0x3f0c45['_queryParams']['loadsAllData']()){const _0x139722=Hn(_0x3f0c45),_0x38ac60=_0x18bb1d['queryToTagMap']['get'](_0x139722);_0x18bb1d['queryToTagMap']['delete'](_0x139722),_0x18bb1d['tagToQueryMap']['delete'](_0x38ac60);}}}function td(){return zu++;}function nd(_0x51fc79,_0x43cc1c,_0x1e7d90){const _0x31b551=_0x43cc1c['_path'],_0x510c8e=Wt(_0x51fc79,_0x43cc1c),_0x5146=ea(_0x51fc79,_0x1e7d90),_0xadf301=_0x51fc79['listenProvider_']['startListening'](kt(_0x43cc1c),_0x510c8e,_0x5146['hashFn'],_0x5146['onComplete']),_0x2f13d2=_0x51fc79['syncPointTree_']['subtree'](_0x31b551);if(_0x510c8e)f(!Se(_0x2f13d2['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x13001d=_0x2f13d2['fold']((_0x4bdc76,_0x2289eb,_0x612b9d)=>{if(!v(_0x4bdc76)&&_0x2289eb&&Se(_0x2289eb))return[Bn(_0x2289eb)['query']];{let _0x4f9a05=[];return _0x2289eb&&(_0x4f9a05=_0x4f9a05['concat'](Ko(_0x2289eb)['map'](_0x341d98=>_0x341d98['query']))),x(_0x612b9d,(_0x3a2285,_0xb4ccb8)=>{_0x4f9a05=_0x4f9a05['concat'](_0xb4ccb8);}),_0x4f9a05;}});for(let _0x3dd433=0x0;_0x3dd433<_0x13001d['length'];++_0x3dd433){const _0x467939=_0x13001d[_0x3dd433];_0x51fc79['listenProvider_']['stopListening'](kt(_0x467939),Wt(_0x51fc79,_0x467939));}}return _0xadf301;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x57cdd1){this['node_']=_0x57cdd1;}['getImmediateChild'](_0x4c1505){const _0x33c7fa=this['node_']['getImmediateChild'](_0x4c1505);return new us(_0x33c7fa);}['node'](){return this['node_'];}}class ds{constructor(_0x4c3b37,_0x1fa10b){this['syncTree_']=_0x4c3b37,this['path_']=_0x1fa10b;}['getImmediateChild'](_0x12b2cd){const _0x532bbb=k(this['path_'],_0x12b2cd);return new ds(this['syncTree_'],_0x532bbb);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x57dda4){return _0x57dda4=_0x57dda4||{},_0x57dda4['timestamp']=_0x57dda4['timestamp']||new Date()['getTime'](),_0x57dda4;},_r=function(_0x4c9e49,_0x5db6c5,_0x1138cf){if(!_0x4c9e49||typeof _0x4c9e49!='object')return _0x4c9e49;if(f('.sv'in _0x4c9e49,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x4c9e49['.sv']=='string')return sd(_0x4c9e49['.sv'],_0x5db6c5,_0x1138cf);if(typeof _0x4c9e49['.sv']=='object')return rd(_0x4c9e49['.sv'],_0x5db6c5);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x4c9e49,null,0x2));},sd=function(_0x52281d,_0x382c33,_0x41f4aa){switch(_0x52281d){case'timestamp':return _0x41f4aa['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x52281d);}},rd=function(_0x4de8b3,_0x20b649,_0x54b090){_0x4de8b3['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x4de8b3,null,0x2));const _0x13c4d6=_0x4de8b3['increment'];typeof _0x13c4d6!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x13c4d6);const _0x5233fd=_0x20b649['node']();if(f(_0x5233fd!==null&&typeof _0x5233fd<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x5233fd['isLeafNode']())return _0x13c4d6;const _0x29f140=_0x5233fd['getValue']();return typeof _0x29f140!='number'?_0x13c4d6:_0x29f140+_0x13c4d6;},ta=function(_0x551955,_0x21853f,_0x2b8b01,_0x18cc2f){return ps(_0x21853f,new ds(_0x2b8b01,_0x551955),_0x18cc2f);},fs=function(_0x2c6f29,_0x1bbb9a,_0x585787){return ps(_0x2c6f29,new us(_0x1bbb9a),_0x585787);};function ps(_0x3043e7,_0x5a0abe,_0x13a73c){const _0x324b96=_0x3043e7['getPriority']()['val'](),_0x39380a=_r(_0x324b96,_0x5a0abe['getImmediateChild']('.priority'),_0x13a73c);let _0x5eeab6;if(_0x3043e7['isLeafNode']()){const _0x3e3b7d=_0x3043e7,_0x439a04=_r(_0x3e3b7d['getValue'](),_0x5a0abe,_0x13a73c);return _0x439a04!==_0x3e3b7d['getValue']()||_0x39380a!==_0x3e3b7d['getPriority']()['val']()?new D(_0x439a04,A(_0x39380a)):_0x3043e7;}else{const _0x578873=_0x3043e7;return _0x5eeab6=_0x578873,_0x39380a!==_0x578873['getPriority']()['val']()&&(_0x5eeab6=_0x5eeab6['updatePriority'](new D(_0x39380a))),_0x578873['forEachChild'](R,(_0x88d975,_0x321b03)=>{const _0x5312cb=ps(_0x321b03,_0x5a0abe['getImmediateChild'](_0x88d975),_0x13a73c);_0x5312cb!==_0x321b03&&(_0x5eeab6=_0x5eeab6['updateImmediateChild'](_0x88d975,_0x5312cb));}),_0x5eeab6;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x4348bf='',_0x14bfd0=null,_0x132640={'children':{},'childCount':0x0}){this['name']=_0x4348bf,this['parent']=_0x14bfd0,this['node']=_0x132640;}}function $n(_0xa7b023,_0x32c6d6){let _0x818829=_0x32c6d6 instanceof C?_0x32c6d6:new C(_0x32c6d6),_0x437c8b=_0xa7b023,_0x41705f=y(_0x818829);for(;_0x41705f!==null;){const _0x45013a=Le(_0x437c8b['node']['children'],_0x41705f)||{'children':{},'childCount':0x0};_0x437c8b=new _s(_0x41705f,_0x437c8b,_0x45013a),_0x818829=S(_0x818829),_0x41705f=y(_0x818829);}return _0x437c8b;}function je(_0x1c11d2){return _0x1c11d2['node']['value'];}function gs(_0x17b1b0,_0x49b124){_0x17b1b0['node']['value']=_0x49b124,Oi(_0x17b1b0);}function na(_0x3a8ba6){return _0x3a8ba6['node']['childCount']>0x0;}function od(_0x54efeb){return je(_0x54efeb)===void 0x0&&!na(_0x54efeb);}function Gn(_0x22efdb,_0x51e7ad){x(_0x22efdb['node']['children'],(_0x1c2588,_0x50d5eb)=>{_0x51e7ad(new _s(_0x1c2588,_0x22efdb,_0x50d5eb));});}function ia(_0x429856,_0xfe27f7,_0x536dab,_0x40a142){_0x536dab&&_0xfe27f7(_0x429856),Gn(_0x429856,_0x37d262=>{ia(_0x37d262,_0xfe27f7,!0x0);});}function ad(_0x2d4ea3,_0x69756a,_0x3bdfc9){let _0x2ab4d2=_0x2d4ea3['parent'];for(;_0x2ab4d2!==null;){if(_0x69756a(_0x2ab4d2))return!0x0;_0x2ab4d2=_0x2ab4d2['parent'];}return!0x1;}function Qt(_0x119a4){return new C(_0x119a4['parent']===null?_0x119a4['name']:Qt(_0x119a4['parent'])+'/'+_0x119a4['name']);}function Oi(_0x2c9ec9){_0x2c9ec9['parent']!==null&&cd(_0x2c9ec9['parent'],_0x2c9ec9['name'],_0x2c9ec9);}function cd(_0x18bbde,_0x3519f1,_0x447b1c){const _0x27c77d=od(_0x447b1c),_0x2ed805=Q(_0x18bbde['node']['children'],_0x3519f1);_0x27c77d&&_0x2ed805?(delete _0x18bbde['node']['children'][_0x3519f1],_0x18bbde['node']['childCount']--,Oi(_0x18bbde)):!_0x27c77d&&!_0x2ed805&&(_0x18bbde['node']['children'][_0x3519f1]=_0x447b1c['node'],_0x18bbde['node']['childCount']++,Oi(_0x18bbde));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x1a4f32){return typeof _0x1a4f32=='string'&&_0x1a4f32['length']!==0x0&&!ld['test'](_0x1a4f32);},sa=function(_0x17389b){return typeof _0x17389b=='string'&&_0x17389b['length']!==0x0&&!hd['test'](_0x17389b);},ud=function(_0x1c2795){return _0x1c2795&&(_0x1c2795=_0x1c2795['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x1c2795);},Bt=function(_0x339e39){return _0x339e39===null||typeof _0x339e39=='string'||typeof _0x339e39=='number'&&!xn(_0x339e39)||_0x339e39&&typeof _0x339e39=='object'&&Q(_0x339e39,'.sv');},He=function(_0x2b7668,_0x2a5a00,_0x274192,_0x571073){_0x571073&&_0x2a5a00===void 0x0||Jt(it(_0x2b7668,'value'),_0x2a5a00,_0x274192);},Jt=function(_0x2fc093,_0x179f8a,_0x50515b){const _0x506a72=_0x50515b instanceof C?new Ah(_0x50515b,_0x2fc093):_0x50515b;if(_0x179f8a===void 0x0)throw new Error(_0x2fc093+'contains\x20undefined\x20'+Oe(_0x506a72));if(typeof _0x179f8a=='function')throw new Error(_0x2fc093+'contains\x20a\x20function\x20'+Oe(_0x506a72)+'\x20with\x20contents\x20=\x20'+_0x179f8a['toString']());if(xn(_0x179f8a))throw new Error(_0x2fc093+'contains\x20'+_0x179f8a['toString']()+'\x20'+Oe(_0x506a72));if(typeof _0x179f8a=='string'&&_0x179f8a['length']>ui/0x3&&Ln(_0x179f8a)>ui)throw new Error(_0x2fc093+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x506a72)+'\x20(\x27'+_0x179f8a['substring'](0x0,0x32)+'...\x27)');if(_0x179f8a&&typeof _0x179f8a=='object'){let _0x479cd3=!0x1,_0x4983da=!0x1;if(x(_0x179f8a,(_0x2fca15,_0x1c81b8)=>{if(_0x2fca15==='.value')_0x479cd3=!0x0;else{if(_0x2fca15!=='.priority'&&_0x2fca15!=='.sv'&&(_0x4983da=!0x0,!ms(_0x2fca15)))throw new Error(_0x2fc093+'\x20contains\x20an\x20invalid\x20key\x20('+_0x2fca15+')\x20'+Oe(_0x506a72)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x506a72,_0x2fca15),Jt(_0x2fc093,_0x1c81b8,_0x506a72),Ph(_0x506a72);}),_0x479cd3&&_0x4983da)throw new Error(_0x2fc093+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x506a72)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x1e567f,_0x504a85){let _0x2e77d4,_0x3980ac;for(_0x2e77d4=0x0;_0x2e77d4<_0x504a85['length'];_0x2e77d4++){_0x3980ac=_0x504a85[_0x2e77d4];const _0x3f6be7=Mt(_0x3980ac);for(let _0x16d872=0x0;_0x16d872<_0x3f6be7['length'];_0x16d872++)if(!(_0x3f6be7[_0x16d872]==='.priority'&&_0x16d872===_0x3f6be7['length']-0x1)){if(!ms(_0x3f6be7[_0x16d872]))throw new Error(_0x1e567f+'contains\x20an\x20invalid\x20key\x20('+_0x3f6be7[_0x16d872]+')\x20in\x20path\x20'+_0x3980ac['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x504a85['sort'](Rh);let _0xba6413=null;for(_0x2e77d4=0x0;_0x2e77d4<_0x504a85['length'];_0x2e77d4++){if(_0x3980ac=_0x504a85[_0x2e77d4],_0xba6413!==null&&G(_0xba6413,_0x3980ac))throw new Error(_0x1e567f+'contains\x20a\x20path\x20'+_0xba6413['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x3980ac['toString']());_0xba6413=_0x3980ac;}},ra=function(_0x562321,_0x37d1c0,_0x5656a8,_0x2ab1cc){const _0xecd1aa=it(_0x562321,'values');if(!(_0x37d1c0&&typeof _0x37d1c0=='object')||Array['isArray'](_0x37d1c0))throw new Error(_0xecd1aa+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x12f8e5=[];x(_0x37d1c0,(_0x5bb69c,_0x30bd38)=>{const _0x5c3056=new C(_0x5bb69c);if(Jt(_0xecd1aa,_0x30bd38,k(_0x5656a8,_0x5c3056)),ji(_0x5c3056)==='.priority'&&!Bt(_0x30bd38))throw new Error(_0xecd1aa+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x5c3056['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x12f8e5['push'](_0x5c3056);}),dd(_0xecd1aa,_0x12f8e5);},fd=function(_0x106a4d,_0xb0bd13,_0x232dda){if(xn(_0xb0bd13))throw new Error(it(_0x106a4d,'priority')+'is\x20'+_0xb0bd13['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0xb0bd13))throw new Error(it(_0x106a4d,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x2c8189,_0x14c895,_0x1b9143,_0x978e1a){if(!sa(_0x1b9143))throw new Error(it(_0x2c8189,_0x14c895)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x1b9143+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x23e548,_0x5f3da9,_0x19d20d,_0x256f95){_0x19d20d&&(_0x19d20d=_0x19d20d['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x23e548,_0x5f3da9,_0x19d20d);},Me=function(_0x308fed,_0x4740bc){if(y(_0x4740bc)==='.info')throw new Error(_0x308fed+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x50b1c0,_0x346800){const _0x3df7b8=_0x346800['path']['toString']();if(typeof _0x346800['repoInfo']['host']!='string'||_0x346800['repoInfo']['host']['length']===0x0||!ms(_0x346800['repoInfo']['namespace'])&&_0x346800['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x3df7b8['length']!==0x0&&!ud(_0x3df7b8))throw new Error(it(_0x50b1c0,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x152ae5,_0x2579c8){let _0x175177=null;for(let _0x281b72=0x0;_0x281b72<_0x2579c8['length'];_0x281b72++){const _0x38ea8e=_0x2579c8[_0x281b72],_0x253b04=_0x38ea8e['getPath']();_0x175177!==null&&!Ki(_0x253b04,_0x175177['path'])&&(_0x152ae5['eventLists_']['push'](_0x175177),_0x175177=null),_0x175177===null&&(_0x175177={'events':[],'path':_0x253b04}),_0x175177['events']['push'](_0x38ea8e);}_0x175177&&_0x152ae5['eventLists_']['push'](_0x175177);}function oa(_0x284c1f,_0x111e03,_0x14cfc2){qn(_0x284c1f,_0x14cfc2),aa(_0x284c1f,_0x54b3c8=>Ki(_0x54b3c8,_0x111e03));}function V(_0x34b2c2,_0x6db197,_0x21bc79){qn(_0x34b2c2,_0x21bc79),aa(_0x34b2c2,_0x11676d=>G(_0x11676d,_0x6db197)||G(_0x6db197,_0x11676d));}function aa(_0x3a47a2,_0x8987a7){_0x3a47a2['recursionDepth_']++;let _0x592572=!0x0;for(let _0x48e862=0x0;_0x48e862<_0x3a47a2['eventLists_']['length'];_0x48e862++){const _0x2bb7dc=_0x3a47a2['eventLists_'][_0x48e862];if(_0x2bb7dc){const _0x4323ab=_0x2bb7dc['path'];_0x8987a7(_0x4323ab)?(md(_0x3a47a2['eventLists_'][_0x48e862]),_0x3a47a2['eventLists_'][_0x48e862]=null):_0x592572=!0x1;}}_0x592572&&(_0x3a47a2['eventLists_']=[]),_0x3a47a2['recursionDepth_']--;}function md(_0x1b6055){for(let _0x264e0b=0x0;_0x264e0b<_0x1b6055['events']['length'];_0x264e0b++){const _0x2f666d=_0x1b6055['events'][_0x264e0b];if(_0x2f666d!==null){_0x1b6055['events'][_0x264e0b]=null;const _0x1af63a=_0x2f666d['getEventRunner']();St&&L('event:\x20'+_0x2f666d['toString']()),ft(_0x1af63a);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x4d0322,_0x160703,_0xe42aa4,_0xb62136){this['repoInfo_']=_0x4d0322,this['forceRestClient_']=_0x160703,this['authTokenProvider_']=_0xe42aa4,this['appCheckProvider_']=_0xb62136,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x59e009,_0x541dcf,_0x433d40){if(_0x59e009['stats_']=qi(_0x59e009['repoInfo_']),_0x59e009['forceRestClient_']||Xl())_0x59e009['server_']=new vn(_0x59e009['repoInfo_'],(_0x566e8c,_0x80b127,_0x3c6c81,_0x2b93d6)=>{gr(_0x59e009,_0x566e8c,_0x80b127,_0x3c6c81,_0x2b93d6);},_0x59e009['authTokenProvider_'],_0x59e009['appCheckProvider_']),setTimeout(()=>mr(_0x59e009,!0x0),0x0);else{if(typeof _0x433d40<'u'&&_0x433d40!==null){if(typeof _0x433d40!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x433d40);}catch(_0x394a99){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x394a99);}}_0x59e009['persistentConnection_']=new se(_0x59e009['repoInfo_'],_0x541dcf,(_0x4bea01,_0x409d99,_0x194413,_0x3fd67c)=>{gr(_0x59e009,_0x4bea01,_0x409d99,_0x194413,_0x3fd67c);},_0x116d18=>{mr(_0x59e009,_0x116d18);},_0x440ff7=>{Id(_0x59e009,_0x440ff7);},_0x59e009['authTokenProvider_'],_0x59e009['appCheckProvider_'],_0x433d40),_0x59e009['server_']=_0x59e009['persistentConnection_'];}_0x59e009['authTokenProvider_']['addTokenChangeListener'](_0x33c627=>{_0x59e009['server_']['refreshAuthToken'](_0x33c627);}),_0x59e009['appCheckProvider_']['addTokenChangeListener'](_0x14cd69=>{_0x59e009['server_']['refreshAppCheckToken'](_0x14cd69['token']);}),_0x59e009['statsReporter_']=ih(_0x59e009['repoInfo_'],()=>new iu(_0x59e009['stats_'],_0x59e009['server_'])),_0x59e009['infoData_']=new Xh(),_0x59e009['infoSyncTree_']=new pr({'startListening':(_0x1bbb2c,_0x52d63a,_0xc8f9fa,_0x4619de)=>{let _0x11ac36=[];const _0x5c2f6c=_0x59e009['infoData_']['getNode'](_0x1bbb2c['_path']);return _0x5c2f6c['isEmpty']()||(_0x11ac36=Yt(_0x59e009['infoSyncTree_'],_0x1bbb2c['_path'],_0x5c2f6c),setTimeout(()=>{_0x4619de('ok');},0x0)),_0x11ac36;},'stopListening':()=>{}}),vs(_0x59e009,'connected',!0x1),_0x59e009['serverSyncTree_']=new pr({'startListening':(_0x37656c,_0x34b615,_0x48a69e,_0x5a7d8c)=>(_0x59e009['server_']['listen'](_0x37656c,_0x48a69e,_0x34b615,(_0x28b826,_0x1540da)=>{const _0xa299b0=_0x5a7d8c(_0x28b826,_0x1540da);V(_0x59e009['eventQueue_'],_0x37656c['_path'],_0xa299b0);}),[]),'stopListening':(_0x3439ee,_0x1803b1)=>{_0x59e009['server_']['unlisten'](_0x3439ee,_0x1803b1);}});}function la(_0x5dd32a){const _0xa7ef27=_0x5dd32a['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0xa7ef27;}function Xt(_0x3cfbb6){return id({'timestamp':la(_0x3cfbb6)});}function gr(_0x46934e,_0x3580a2,_0x58784f,_0x3e3f7d,_0x1b74ee){_0x46934e['dataUpdateCount']++;const _0x7b277f=new C(_0x3580a2);_0x58784f=_0x46934e['interceptServerDataCallback_']?_0x46934e['interceptServerDataCallback_'](_0x3580a2,_0x58784f):_0x58784f;let _0x233a4b=[];if(_0x1b74ee){if(_0x3e3f7d){const _0x2b2ede=_n(_0x58784f,_0x4e4358=>A(_0x4e4358));_0x233a4b=Ju(_0x46934e['serverSyncTree_'],_0x7b277f,_0x2b2ede,_0x1b74ee);}else{const _0x27a1cd=A(_0x58784f);_0x233a4b=Jo(_0x46934e['serverSyncTree_'],_0x7b277f,_0x27a1cd,_0x1b74ee);}}else{if(_0x3e3f7d){const _0x454b1b=_n(_0x58784f,_0x55fa01=>A(_0x55fa01));_0x233a4b=Ku(_0x46934e['serverSyncTree_'],_0x7b277f,_0x454b1b);}else{const _0x45a91b=A(_0x58784f);_0x233a4b=Yt(_0x46934e['serverSyncTree_'],_0x7b277f,_0x45a91b);}}let _0x19ce4f=_0x7b277f;_0x233a4b['length']>0x0&&(_0x19ce4f=ct(_0x46934e,_0x7b277f)),V(_0x46934e['eventQueue_'],_0x19ce4f,_0x233a4b);}function mr(_0xf9e31,_0x332465){vs(_0xf9e31,'connected',_0x332465),_0x332465===!0x1&&Sd(_0xf9e31);}function Id(_0x28de2a,_0x486c5f){x(_0x486c5f,(_0x10ea49,_0xaebf30)=>{vs(_0x28de2a,_0x10ea49,_0xaebf30);});}function vs(_0x50826f,_0x3a9899,_0x207d77){const _0x236ea7=new C('/.info/'+_0x3a9899),_0x9beecf=A(_0x207d77);_0x50826f['infoData_']['updateSnapshot'](_0x236ea7,_0x9beecf);const _0x57ccd4=Yt(_0x50826f['infoSyncTree_'],_0x236ea7,_0x9beecf);V(_0x50826f['eventQueue_'],_0x236ea7,_0x57ccd4);}function zn(_0x28ff47){return _0x28ff47['nextWriteId_']++;}function wd(_0x23e2f0,_0x26ed7d,_0x53bdc9){const _0xd9f682=Xu(_0x23e2f0['serverSyncTree_'],_0x26ed7d);return _0xd9f682!=null?Promise['resolve'](_0xd9f682):_0x23e2f0['server_']['get'](_0x26ed7d)['then'](_0xd29d1=>{const _0x1d3b37=A(_0xd29d1)['withIndex'](_0x26ed7d['_queryParams']['getIndex']());Ni(_0x23e2f0['serverSyncTree_'],_0x26ed7d,_0x53bdc9,!0x0);let _0x5c96bb;if(_0x26ed7d['_queryParams']['loadsAllData']())_0x5c96bb=Yt(_0x23e2f0['serverSyncTree_'],_0x26ed7d['_path'],_0x1d3b37);else{const _0x152b34=Wt(_0x23e2f0['serverSyncTree_'],_0x26ed7d);_0x5c96bb=Jo(_0x23e2f0['serverSyncTree_'],_0x26ed7d['_path'],_0x1d3b37,_0x152b34);}return V(_0x23e2f0['eventQueue_'],_0x26ed7d['_path'],_0x5c96bb),An(_0x23e2f0['serverSyncTree_'],_0x26ed7d,_0x53bdc9,null,!0x0),_0x1d3b37;},_0x26df11=>(gt(_0x23e2f0,'get\x20for\x20query\x20'+O(_0x26ed7d)+'\x20failed:\x20'+_0x26df11),Promise['reject'](new Error(_0x26df11))));}function Cd(_0x35e5fb,_0x54390c,_0x1f617b,_0x137894,_0x47b286){gt(_0x35e5fb,'set',{'path':_0x54390c['toString'](),'value':_0x1f617b,'priority':_0x137894});const _0x2259b5=Xt(_0x35e5fb),_0x8aba19=A(_0x1f617b,_0x137894),_0x30c081=Vn(_0x35e5fb['serverSyncTree_'],_0x54390c),_0x236e72=fs(_0x8aba19,_0x30c081,_0x2259b5),_0x5d843a=zn(_0x35e5fb),_0x1a36b8=as(_0x35e5fb['serverSyncTree_'],_0x54390c,_0x236e72,_0x5d843a,!0x0);qn(_0x35e5fb['eventQueue_'],_0x1a36b8),_0x35e5fb['server_']['put'](_0x54390c['toString'](),_0x8aba19['val'](!0x0),(_0x371c13,_0x3f597f)=>{const _0x48738e=_0x371c13==='ok';_0x48738e||U('set\x20at\x20'+_0x54390c+'\x20failed:\x20'+_0x371c13);const _0x3d112c=_e(_0x35e5fb['serverSyncTree_'],_0x5d843a,!_0x48738e);V(_0x35e5fb['eventQueue_'],_0x54390c,_0x3d112c),be(_0x35e5fb,_0x47b286,_0x371c13,_0x3f597f);});const _0x590fa9=Is(_0x35e5fb,_0x54390c);ct(_0x35e5fb,_0x590fa9),V(_0x35e5fb['eventQueue_'],_0x590fa9,[]);}function Td(_0xeeff8,_0x139ff4,_0x11b498,_0x28dd34){gt(_0xeeff8,'update',{'path':_0x139ff4['toString'](),'value':_0x11b498});let _0x42dca0=!0x0;const _0x3b3959=Xt(_0xeeff8),_0x41b5b1={};if(x(_0x11b498,(_0x10569f,_0x70a070)=>{_0x42dca0=!0x1,_0x41b5b1[_0x10569f]=ta(k(_0x139ff4,_0x10569f),A(_0x70a070),_0xeeff8['serverSyncTree_'],_0x3b3959);}),_0x42dca0)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0xeeff8,_0x28dd34,'ok',void 0x0);else{const _0x35f379=zn(_0xeeff8),_0x435496=ju(_0xeeff8['serverSyncTree_'],_0x139ff4,_0x41b5b1,_0x35f379);qn(_0xeeff8['eventQueue_'],_0x435496),_0xeeff8['server_']['merge'](_0x139ff4['toString'](),_0x11b498,(_0x2b022f,_0xd691a2)=>{const _0x26d3df=_0x2b022f==='ok';_0x26d3df||U('update\x20at\x20'+_0x139ff4+'\x20failed:\x20'+_0x2b022f);const _0x309c04=_e(_0xeeff8['serverSyncTree_'],_0x35f379,!_0x26d3df),_0x523694=_0x309c04['length']>0x0?ct(_0xeeff8,_0x139ff4):_0x139ff4;V(_0xeeff8['eventQueue_'],_0x523694,_0x309c04),be(_0xeeff8,_0x28dd34,_0x2b022f,_0xd691a2);}),x(_0x11b498,_0x268183=>{const _0x88c286=Is(_0xeeff8,k(_0x139ff4,_0x268183));ct(_0xeeff8,_0x88c286);}),V(_0xeeff8['eventQueue_'],_0x139ff4,[]);}}function Sd(_0x585748){gt(_0x585748,'onDisconnectEvents');const _0x4c1969=Xt(_0x585748),_0x3c5842=En();Si(_0x585748['onDisconnect_'],w(),(_0x3a6dd2,_0x34a59f)=>{const _0x53d2ec=ta(_0x3a6dd2,_0x34a59f,_0x585748['serverSyncTree_'],_0x4c1969);pt(_0x3c5842,_0x3a6dd2,_0x53d2ec);});let _0x22a234=[];Si(_0x3c5842,w(),(_0x3b3cdb,_0x46fb3b)=>{_0x22a234=_0x22a234['concat'](Yt(_0x585748['serverSyncTree_'],_0x3b3cdb,_0x46fb3b));const _0x9118c2=Is(_0x585748,_0x3b3cdb);ct(_0x585748,_0x9118c2);}),_0x585748['onDisconnect_']=En(),V(_0x585748['eventQueue_'],w(),_0x22a234);}function bd(_0x5ba18c,_0x48336c,_0x43d8f3){_0x5ba18c['server_']['onDisconnectCancel'](_0x48336c['toString'](),(_0x27e1b0,_0x4ac1d8)=>{_0x27e1b0==='ok'&&Ti(_0x5ba18c['onDisconnect_'],_0x48336c),be(_0x5ba18c,_0x43d8f3,_0x27e1b0,_0x4ac1d8);});}function yr(_0x512164,_0xc63dd,_0x33dac0,_0x1f39f2){const _0x520fb7=A(_0x33dac0);_0x512164['server_']['onDisconnectPut'](_0xc63dd['toString'](),_0x520fb7['val'](!0x0),(_0x14064d,_0x56e3c5)=>{_0x14064d==='ok'&&pt(_0x512164['onDisconnect_'],_0xc63dd,_0x520fb7),be(_0x512164,_0x1f39f2,_0x14064d,_0x56e3c5);});}function Rd(_0x5d5a57,_0x372b21,_0x230553,_0x4d3d54,_0x2522e2){const _0xc067fa=A(_0x230553,_0x4d3d54);_0x5d5a57['server_']['onDisconnectPut'](_0x372b21['toString'](),_0xc067fa['val'](!0x0),(_0x37e503,_0x5c64eb)=>{_0x37e503==='ok'&&pt(_0x5d5a57['onDisconnect_'],_0x372b21,_0xc067fa),be(_0x5d5a57,_0x2522e2,_0x37e503,_0x5c64eb);});}function Ad(_0x3eb1f3,_0x38f6c8,_0x43767d,_0x289263){if(pn(_0x43767d)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x3eb1f3,_0x289263,'ok',void 0x0);return;}_0x3eb1f3['server_']['onDisconnectMerge'](_0x38f6c8['toString'](),_0x43767d,(_0x16addc,_0x527540)=>{_0x16addc==='ok'&&x(_0x43767d,(_0x23ae2e,_0xa18f50)=>{const _0x18e193=A(_0xa18f50);pt(_0x3eb1f3['onDisconnect_'],k(_0x38f6c8,_0x23ae2e),_0x18e193);}),be(_0x3eb1f3,_0x289263,_0x16addc,_0x527540);});}function kd(_0x102a5d,_0x479f89,_0xc92c58){let _0x4a3742;y(_0x479f89['_path'])==='.info'?_0x4a3742=Ni(_0x102a5d['infoSyncTree_'],_0x479f89,_0xc92c58):_0x4a3742=Ni(_0x102a5d['serverSyncTree_'],_0x479f89,_0xc92c58),oa(_0x102a5d['eventQueue_'],_0x479f89['_path'],_0x4a3742);}function Pd(_0x17812f,_0x31988b,_0x31535f){let _0x301627;y(_0x31988b['_path'])==='.info'?_0x301627=An(_0x17812f['infoSyncTree_'],_0x31988b,_0x31535f):_0x301627=An(_0x17812f['serverSyncTree_'],_0x31988b,_0x31535f),oa(_0x17812f['eventQueue_'],_0x31988b['_path'],_0x301627);}function ha(_0x2439ab){_0x2439ab['persistentConnection_']&&_0x2439ab['persistentConnection_']['interrupt'](ca);}function Nd(_0x1881f9){_0x1881f9['persistentConnection_']&&_0x1881f9['persistentConnection_']['resume'](ca);}function gt(_0x44c5a4,..._0x3b1cdd){let _0xfdfc2b='';_0x44c5a4['persistentConnection_']&&(_0xfdfc2b=_0x44c5a4['persistentConnection_']['id']+':'),L(_0xfdfc2b,..._0x3b1cdd);}function be(_0x2b5904,_0x554990,_0xd01680,_0x4f9bb4){_0x554990&&ft(()=>{if(_0xd01680==='ok')_0x554990(null);else{const _0x19ea57=(_0xd01680||'error')['toUpperCase']();let _0x1b6753=_0x19ea57;_0x4f9bb4&&(_0x1b6753+=':\x20'+_0x4f9bb4);const _0xed17a7=new Error(_0x1b6753);_0xed17a7['code']=_0x19ea57,_0x554990(_0xed17a7);}});}function Od(_0x5405d6,_0x4c18fc,_0xa33606,_0x6167ea,_0x30e029,_0x4c6d99){gt(_0x5405d6,'transaction\x20on\x20'+_0x4c18fc);const _0x2d664c={'path':_0x4c18fc,'update':_0xa33606,'onComplete':_0x6167ea,'status':null,'order':so(),'applyLocally':_0x4c6d99,'retryCount':0x0,'unwatcher':_0x30e029,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x5bc343=Es(_0x5405d6,_0x4c18fc,void 0x0);_0x2d664c['currentInputSnapshot']=_0x5bc343;const _0x4581c3=_0x2d664c['update'](_0x5bc343['val']());if(_0x4581c3===void 0x0)_0x2d664c['unwatcher'](),_0x2d664c['currentOutputSnapshotRaw']=null,_0x2d664c['currentOutputSnapshotResolved']=null,_0x2d664c['onComplete']&&_0x2d664c['onComplete'](null,!0x1,_0x2d664c['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x4581c3,_0x2d664c['path']),_0x2d664c['status']=0x0;const _0x2f4afc=$n(_0x5405d6['transactionQueueTree_'],_0x4c18fc),_0x5eaae9=je(_0x2f4afc)||[];_0x5eaae9['push'](_0x2d664c),gs(_0x2f4afc,_0x5eaae9);let _0x344401;typeof _0x4581c3=='object'&&_0x4581c3!==null&&Q(_0x4581c3,'.priority')?(_0x344401=Le(_0x4581c3,'.priority'),f(Bt(_0x344401),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x344401=(Vn(_0x5405d6['serverSyncTree_'],_0x4c18fc)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x35baca=Xt(_0x5405d6),_0x1331f3=A(_0x4581c3,_0x344401),_0x1bf3f5=fs(_0x1331f3,_0x5bc343,_0x35baca);_0x2d664c['currentOutputSnapshotRaw']=_0x1331f3,_0x2d664c['currentOutputSnapshotResolved']=_0x1bf3f5,_0x2d664c['currentWriteId']=zn(_0x5405d6);const _0x76d92f=as(_0x5405d6['serverSyncTree_'],_0x4c18fc,_0x1bf3f5,_0x2d664c['currentWriteId'],_0x2d664c['applyLocally']);V(_0x5405d6['eventQueue_'],_0x4c18fc,_0x76d92f),jn(_0x5405d6,_0x5405d6['transactionQueueTree_']);}}function Es(_0x4b006b,_0x45b304,_0x503d8d){return Vn(_0x4b006b['serverSyncTree_'],_0x45b304,_0x503d8d)||g['EMPTY_NODE'];}function jn(_0x312a05,_0xe55116=_0x312a05['transactionQueueTree_']){if(_0xe55116||Kn(_0x312a05,_0xe55116),je(_0xe55116)){const _0x328d17=da(_0x312a05,_0xe55116);f(_0x328d17['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x328d17['every'](_0x3c0e45=>_0x3c0e45['status']===0x0)&&Dd(_0x312a05,Qt(_0xe55116),_0x328d17);}else na(_0xe55116)&&Gn(_0xe55116,_0x8ab728=>{jn(_0x312a05,_0x8ab728);});}function Dd(_0x1707e1,_0x2ef716,_0x308ae6){const _0x58a316=_0x308ae6['map'](_0x565d4a=>_0x565d4a['currentWriteId']),_0x2cdaa2=Es(_0x1707e1,_0x2ef716,_0x58a316);let _0x595666=_0x2cdaa2;const _0x32131e=_0x2cdaa2['hash']();for(let _0x1087ee=0x0;_0x1087ee<_0x308ae6['length'];_0x1087ee++){const _0x383cec=_0x308ae6[_0x1087ee];f(_0x383cec['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x383cec['status']=0x1,_0x383cec['retryCount']++;const _0x5e2fc3=F(_0x2ef716,_0x383cec['path']);_0x595666=_0x595666['updateChild'](_0x5e2fc3,_0x383cec['currentOutputSnapshotRaw']);}const _0x3e56a5=_0x595666['val'](!0x0),_0x506d05=_0x2ef716;_0x1707e1['server_']['put'](_0x506d05['toString'](),_0x3e56a5,_0x1a3c2c=>{gt(_0x1707e1,'transaction\x20put\x20response',{'path':_0x506d05['toString'](),'status':_0x1a3c2c});let _0x19f8a4=[];if(_0x1a3c2c==='ok'){const _0x5aeb54=[];for(let _0x5dfc06=0x0;_0x5dfc06<_0x308ae6['length'];_0x5dfc06++)_0x308ae6[_0x5dfc06]['status']=0x2,_0x19f8a4=_0x19f8a4['concat'](_e(_0x1707e1['serverSyncTree_'],_0x308ae6[_0x5dfc06]['currentWriteId'])),_0x308ae6[_0x5dfc06]['onComplete']&&_0x5aeb54['push'](()=>_0x308ae6[_0x5dfc06]['onComplete'](null,!0x0,_0x308ae6[_0x5dfc06]['currentOutputSnapshotResolved'])),_0x308ae6[_0x5dfc06]['unwatcher']();Kn(_0x1707e1,$n(_0x1707e1['transactionQueueTree_'],_0x2ef716)),jn(_0x1707e1,_0x1707e1['transactionQueueTree_']),V(_0x1707e1['eventQueue_'],_0x2ef716,_0x19f8a4);for(let _0x431783=0x0;_0x431783<_0x5aeb54['length'];_0x431783++)ft(_0x5aeb54[_0x431783]);}else{if(_0x1a3c2c==='datastale'){for(let _0x15c2f4=0x0;_0x15c2f4<_0x308ae6['length'];_0x15c2f4++)_0x308ae6[_0x15c2f4]['status']===0x3?_0x308ae6[_0x15c2f4]['status']=0x4:_0x308ae6[_0x15c2f4]['status']=0x0;}else{U('transaction\x20at\x20'+_0x506d05['toString']()+'\x20failed:\x20'+_0x1a3c2c);for(let _0x519d74=0x0;_0x519d74<_0x308ae6['length'];_0x519d74++)_0x308ae6[_0x519d74]['status']=0x4,_0x308ae6[_0x519d74]['abortReason']=_0x1a3c2c;}ct(_0x1707e1,_0x2ef716);}},_0x32131e);}function ct(_0x167eb0,_0x19ead0){const _0x1aa1c2=ua(_0x167eb0,_0x19ead0),_0x25276a=Qt(_0x1aa1c2),_0x3e188f=da(_0x167eb0,_0x1aa1c2);return Md(_0x167eb0,_0x3e188f,_0x25276a),_0x25276a;}function Md(_0x3bb0ef,_0x44b920,_0x1f3ce4){if(_0x44b920['length']===0x0)return;const _0x40371b=[];let _0x33bc31=[];const _0x1542f3=_0x44b920['filter'](_0x25f284=>_0x25f284['status']===0x0)['map'](_0x298251=>_0x298251['currentWriteId']);for(let _0x322eb5=0x0;_0x322eb5<_0x44b920['length'];_0x322eb5++){const _0x5d3836=_0x44b920[_0x322eb5],_0x5e2fca=F(_0x1f3ce4,_0x5d3836['path']);let _0xa71bc5=!0x1,_0x4723c3;if(f(_0x5e2fca!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x5d3836['status']===0x4)_0xa71bc5=!0x0,_0x4723c3=_0x5d3836['abortReason'],_0x33bc31=_0x33bc31['concat'](_e(_0x3bb0ef['serverSyncTree_'],_0x5d3836['currentWriteId'],!0x0));else{if(_0x5d3836['status']===0x0){if(_0x5d3836['retryCount']>=yd)_0xa71bc5=!0x0,_0x4723c3='maxretry',_0x33bc31=_0x33bc31['concat'](_e(_0x3bb0ef['serverSyncTree_'],_0x5d3836['currentWriteId'],!0x0));else{const _0x1858f6=Es(_0x3bb0ef,_0x5d3836['path'],_0x1542f3);_0x5d3836['currentInputSnapshot']=_0x1858f6;const _0x4c78a6=_0x44b920[_0x322eb5]['update'](_0x1858f6['val']());if(_0x4c78a6!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x4c78a6,_0x5d3836['path']);let _0x386d45=A(_0x4c78a6);typeof _0x4c78a6=='object'&&_0x4c78a6!=null&&Q(_0x4c78a6,'.priority')||(_0x386d45=_0x386d45['updatePriority'](_0x1858f6['getPriority']()));const _0x4517dc=_0x5d3836['currentWriteId'],_0x569a65=Xt(_0x3bb0ef),_0x3431ce=fs(_0x386d45,_0x1858f6,_0x569a65);_0x5d3836['currentOutputSnapshotRaw']=_0x386d45,_0x5d3836['currentOutputSnapshotResolved']=_0x3431ce,_0x5d3836['currentWriteId']=zn(_0x3bb0ef),_0x1542f3['splice'](_0x1542f3['indexOf'](_0x4517dc),0x1),_0x33bc31=_0x33bc31['concat'](as(_0x3bb0ef['serverSyncTree_'],_0x5d3836['path'],_0x3431ce,_0x5d3836['currentWriteId'],_0x5d3836['applyLocally'])),_0x33bc31=_0x33bc31['concat'](_e(_0x3bb0ef['serverSyncTree_'],_0x4517dc,!0x0));}else _0xa71bc5=!0x0,_0x4723c3='nodata',_0x33bc31=_0x33bc31['concat'](_e(_0x3bb0ef['serverSyncTree_'],_0x5d3836['currentWriteId'],!0x0));}}}V(_0x3bb0ef['eventQueue_'],_0x1f3ce4,_0x33bc31),_0x33bc31=[],_0xa71bc5&&(_0x44b920[_0x322eb5]['status']=0x2,function(_0x395c68){setTimeout(_0x395c68,Math['floor'](0x0));}(_0x44b920[_0x322eb5]['unwatcher']),_0x44b920[_0x322eb5]['onComplete']&&(_0x4723c3==='nodata'?_0x40371b['push'](()=>_0x44b920[_0x322eb5]['onComplete'](null,!0x1,_0x44b920[_0x322eb5]['currentInputSnapshot'])):_0x40371b['push'](()=>_0x44b920[_0x322eb5]['onComplete'](new Error(_0x4723c3),!0x1,null))));}Kn(_0x3bb0ef,_0x3bb0ef['transactionQueueTree_']);for(let _0x1baa77=0x0;_0x1baa77<_0x40371b['length'];_0x1baa77++)ft(_0x40371b[_0x1baa77]);jn(_0x3bb0ef,_0x3bb0ef['transactionQueueTree_']);}function ua(_0x336226,_0x34eeee){let _0x89f1fc,_0x415150=_0x336226['transactionQueueTree_'];for(_0x89f1fc=y(_0x34eeee);_0x89f1fc!==null&&je(_0x415150)===void 0x0;)_0x415150=$n(_0x415150,_0x89f1fc),_0x34eeee=S(_0x34eeee),_0x89f1fc=y(_0x34eeee);return _0x415150;}function da(_0xbed4aa,_0x120e67){const _0x2050c4=[];return fa(_0xbed4aa,_0x120e67,_0x2050c4),_0x2050c4['sort']((_0x3d76da,_0x4fb7b8)=>_0x3d76da['order']-_0x4fb7b8['order']),_0x2050c4;}function fa(_0x364dec,_0x1a4f27,_0x341cdc){const _0x329306=je(_0x1a4f27);if(_0x329306){for(let _0x4ca733=0x0;_0x4ca733<_0x329306['length'];_0x4ca733++)_0x341cdc['push'](_0x329306[_0x4ca733]);}Gn(_0x1a4f27,_0x25bebd=>{fa(_0x364dec,_0x25bebd,_0x341cdc);});}function Kn(_0x397d30,_0x37314f){const _0x2dbf78=je(_0x37314f);if(_0x2dbf78){let _0x386f2f=0x0;for(let _0x4b1abe=0x0;_0x4b1abe<_0x2dbf78['length'];_0x4b1abe++)_0x2dbf78[_0x4b1abe]['status']!==0x2&&(_0x2dbf78[_0x386f2f]=_0x2dbf78[_0x4b1abe],_0x386f2f++);_0x2dbf78['length']=_0x386f2f,gs(_0x37314f,_0x2dbf78['length']>0x0?_0x2dbf78:void 0x0);}Gn(_0x37314f,_0x516d69=>{Kn(_0x397d30,_0x516d69);});}function Is(_0x314584,_0x39c5fa){const _0x4aaa2c=Qt(ua(_0x314584,_0x39c5fa)),_0xf66650=$n(_0x314584['transactionQueueTree_'],_0x39c5fa);return ad(_0xf66650,_0x436ac0=>{di(_0x314584,_0x436ac0);}),di(_0x314584,_0xf66650),ia(_0xf66650,_0x1fb27e=>{di(_0x314584,_0x1fb27e);}),_0x4aaa2c;}function di(_0x4e6588,_0x1850e0){const _0x351dc5=je(_0x1850e0);if(_0x351dc5){const _0x568339=[];let _0x495d05=[],_0x16f06a=-0x1;for(let _0x12c54d=0x0;_0x12c54d<_0x351dc5['length'];_0x12c54d++)_0x351dc5[_0x12c54d]['status']===0x3||(_0x351dc5[_0x12c54d]['status']===0x1?(f(_0x16f06a===_0x12c54d-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x16f06a=_0x12c54d,_0x351dc5[_0x12c54d]['status']=0x3,_0x351dc5[_0x12c54d]['abortReason']='set'):(f(_0x351dc5[_0x12c54d]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x351dc5[_0x12c54d]['unwatcher'](),_0x495d05=_0x495d05['concat'](_e(_0x4e6588['serverSyncTree_'],_0x351dc5[_0x12c54d]['currentWriteId'],!0x0)),_0x351dc5[_0x12c54d]['onComplete']&&_0x568339['push'](_0x351dc5[_0x12c54d]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x16f06a===-0x1?gs(_0x1850e0,void 0x0):_0x351dc5['length']=_0x16f06a+0x1,V(_0x4e6588['eventQueue_'],Qt(_0x1850e0),_0x495d05);for(let _0x323b72=0x0;_0x323b72<_0x568339['length'];_0x323b72++)ft(_0x568339[_0x323b72]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x2f587d){let _0x4fef5b='';const _0x5b3f60=_0x2f587d['split']('/');for(let _0x14b84b=0x0;_0x14b84b<_0x5b3f60['length'];_0x14b84b++)if(_0x5b3f60[_0x14b84b]['length']>0x0){let _0x263b68=_0x5b3f60[_0x14b84b];try{_0x263b68=decodeURIComponent(_0x263b68['replace'](/\+/g,'\x20'));}catch{}_0x4fef5b+='/'+_0x263b68;}return _0x4fef5b;}function xd(_0x539154){const _0x417be9={};_0x539154['charAt'](0x0)==='?'&&(_0x539154=_0x539154['substring'](0x1));for(const _0x36b50a of _0x539154['split']('&')){if(_0x36b50a['length']===0x0)continue;const _0x26ff27=_0x36b50a['split']('=');_0x26ff27['length']===0x2?_0x417be9[decodeURIComponent(_0x26ff27[0x0])]=decodeURIComponent(_0x26ff27[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x36b50a+'\x27\x20in\x20query\x20\x27'+_0x539154+'\x27');}return _0x417be9;}const vr=function(_0x38ed02,_0x37bf8b){const _0x40c10f=Fd(_0x38ed02),_0x2118de=_0x40c10f['namespace'];_0x40c10f['domain']==='firebase.com'&&ae(_0x40c10f['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x2118de||_0x2118de==='undefined')&&_0x40c10f['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x40c10f['secure']||$l();const _0x4da3a8=_0x40c10f['scheme']==='ws'||_0x40c10f['scheme']==='wss';return{'repoInfo':new yo(_0x40c10f['host'],_0x40c10f['secure'],_0x2118de,_0x4da3a8,_0x37bf8b,'',_0x2118de!==_0x40c10f['subdomain']),'path':new C(_0x40c10f['pathString'])};},Fd=function(_0x140adb){let _0x54edae='',_0x8d851c='',_0x2f554c='',_0x487df9='',_0xd8024d='',_0x272c8f=!0x0,_0x48c4a6='https',_0x28cbcd=0x1bb;if(typeof _0x140adb=='string'){let _0x5b0697=_0x140adb['indexOf']('//');_0x5b0697>=0x0&&(_0x48c4a6=_0x140adb['substring'](0x0,_0x5b0697-0x1),_0x140adb=_0x140adb['substring'](_0x5b0697+0x2));let _0x453a3d=_0x140adb['indexOf']('/');_0x453a3d===-0x1&&(_0x453a3d=_0x140adb['length']);let _0x326393=_0x140adb['indexOf']('?');_0x326393===-0x1&&(_0x326393=_0x140adb['length']),_0x54edae=_0x140adb['substring'](0x0,Math['min'](_0x453a3d,_0x326393)),_0x453a3d<_0x326393&&(_0x487df9=Ld(_0x140adb['substring'](_0x453a3d,_0x326393)));const _0x277bdc=xd(_0x140adb['substring'](Math['min'](_0x140adb['length'],_0x326393)));_0x5b0697=_0x54edae['indexOf'](':'),_0x5b0697>=0x0?(_0x272c8f=_0x48c4a6==='https'||_0x48c4a6==='wss',_0x28cbcd=parseInt(_0x54edae['substring'](_0x5b0697+0x1),0xa)):_0x5b0697=_0x54edae['length'];const _0x23c910=_0x54edae['slice'](0x0,_0x5b0697);if(_0x23c910['toLowerCase']()==='localhost')_0x8d851c='localhost';else{if(_0x23c910['split']('.')['length']<=0x2)_0x8d851c=_0x23c910;else{const _0x37cc43=_0x54edae['indexOf']('.');_0x2f554c=_0x54edae['substring'](0x0,_0x37cc43)['toLowerCase'](),_0x8d851c=_0x54edae['substring'](_0x37cc43+0x1),_0xd8024d=_0x2f554c;}}'ns'in _0x277bdc&&(_0xd8024d=_0x277bdc['ns']);}return{'host':_0x54edae,'port':_0x28cbcd,'domain':_0x8d851c,'subdomain':_0x2f554c,'secure':_0x272c8f,'scheme':_0x48c4a6,'pathString':_0x487df9,'namespace':_0xd8024d};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x12eeed=0x0;const _0x1a272a=[];return function(_0x1b78f9){const _0x30561f=_0x1b78f9===_0x12eeed;_0x12eeed=_0x1b78f9;let _0x49d7cf;const _0x3e4264=new Array(0x8);for(_0x49d7cf=0x7;_0x49d7cf>=0x0;_0x49d7cf--)_0x3e4264[_0x49d7cf]=Er['charAt'](_0x1b78f9%0x40),_0x1b78f9=Math['floor'](_0x1b78f9/0x40);f(_0x1b78f9===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x1cd5fe=_0x3e4264['join']('');if(_0x30561f){for(_0x49d7cf=0xb;_0x49d7cf>=0x0&&_0x1a272a[_0x49d7cf]===0x3f;_0x49d7cf--)_0x1a272a[_0x49d7cf]=0x0;_0x1a272a[_0x49d7cf]++;}else{for(_0x49d7cf=0x0;_0x49d7cf<0xc;_0x49d7cf++)_0x1a272a[_0x49d7cf]=Math['floor'](Math['random']()*0x40);}for(_0x49d7cf=0x0;_0x49d7cf<0xc;_0x49d7cf++)_0x1cd5fe+=Er['charAt'](_0x1a272a[_0x49d7cf]);return f(_0x1cd5fe['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x1cd5fe;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x10b8cb,_0x123f54,_0x45bcc6,_0x270324){this['eventType']=_0x10b8cb,this['eventRegistration']=_0x123f54,this['snapshot']=_0x45bcc6,this['prevName']=_0x270324;}['getPath'](){const _0x5a2a20=this['snapshot']['ref'];return this['eventType']==='value'?_0x5a2a20['_path']:_0x5a2a20['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x3d97db,_0x9fdd48,_0x3a8ebc){this['eventRegistration']=_0x3d97db,this['error']=_0x9fdd48,this['path']=_0x3a8ebc;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x3c6672,_0x22525f){this['snapshotCallback']=_0x3c6672,this['cancelCallback']=_0x22525f;}['onValue'](_0x34f188,_0x237d02){this['snapshotCallback']['call'](null,_0x34f188,_0x237d02);}['onCancel'](_0x37fbab){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x37fbab);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x254785){return this['snapshotCallback']===_0x254785['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x254785['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x254785['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x141fb5,_0x163794){this['_repo']=_0x141fb5,this['_path']=_0x163794;}['cancel'](){const _0x4524f8=new H();return bd(this['_repo'],this['_path'],_0x4524f8['wrapCallback'](()=>{})),_0x4524f8['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0xaa02fc=new H();return yr(this['_repo'],this['_path'],null,_0xaa02fc['wrapCallback'](()=>{})),_0xaa02fc['promise'];}['set'](_0x453a13){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x453a13,this['_path'],!0x1);const _0x9e19fe=new H();return yr(this['_repo'],this['_path'],_0x453a13,_0x9e19fe['wrapCallback'](()=>{})),_0x9e19fe['promise'];}['setWithPriority'](_0x260be2,_0x1b5886){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x260be2,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x1b5886);const _0x2cc7da=new H();return Rd(this['_repo'],this['_path'],_0x260be2,_0x1b5886,_0x2cc7da['wrapCallback'](()=>{})),_0x2cc7da['promise'];}['update'](_0x35765d){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x35765d,this['_path']);const _0xf45268=new H();return Ad(this['_repo'],this['_path'],_0x35765d,_0xf45268['wrapCallback'](()=>{})),_0xf45268['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0xe76a69,_0x5a55c0,_0x1743c2,_0x148205){this['_repo']=_0xe76a69,this['_path']=_0x5a55c0,this['_queryParams']=_0x1743c2,this['_orderByCalled']=_0x148205;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x395f72=sr(this['_queryParams']),_0x151b55=$i(_0x395f72);return _0x151b55==='{}'?'default':_0x151b55;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x105484){if(_0x105484=P(_0x105484),!(_0x105484 instanceof Ae))return!0x1;const _0xdb0850=this['_repo']===_0x105484['_repo'],_0x14d5ea=Ki(this['_path'],_0x105484['_path']),_0x5e2031=this['_queryIdentifier']===_0x105484['_queryIdentifier'];return _0xdb0850&&_0x14d5ea&&_0x5e2031;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x517a4a,_0x2bd98d){if(_0x517a4a['_orderByCalled']===!0x0)throw new Error(_0x2bd98d+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x515cc3){let _0x1f820a=null,_0x41d892=null;if(_0x515cc3['hasStart']()&&(_0x1f820a=_0x515cc3['getIndexStartValue']()),_0x515cc3['hasEnd']()&&(_0x41d892=_0x515cc3['getIndexEndValue']()),_0x515cc3['getIndex']()===ve){const _0x507135='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x57af34='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x515cc3['hasStart']()){if(_0x515cc3['getIndexStartName']()!==We)throw new Error(_0x507135);if(typeof _0x1f820a!='string')throw new Error(_0x57af34);}if(_0x515cc3['hasEnd']()){if(_0x515cc3['getIndexEndName']()!==we)throw new Error(_0x507135);if(typeof _0x41d892!='string')throw new Error(_0x57af34);}}else{if(_0x515cc3['getIndex']()===R){if(_0x1f820a!=null&&!Bt(_0x1f820a)||_0x41d892!=null&&!Bt(_0x41d892))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x515cc3['getIndex']()instanceof Ji||_0x515cc3['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x1f820a!=null&&typeof _0x1f820a=='object'||_0x41d892!=null&&typeof _0x41d892=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x4b04ac){if(_0x4b04ac['hasStart']()&&_0x4b04ac['hasEnd']()&&_0x4b04ac['hasLimit']()&&!_0x4b04ac['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x1806e5,_0x2e0174){super(_0x1806e5,_0x2e0174,new Zi(),!0x1);}get['parent'](){const _0x47da5a=Ro(this['_path']);return _0x47da5a===null?null:new ee(this['_repo'],_0x47da5a);}get['root'](){let _0x59d113=this;for(;_0x59d113['parent']!==null;)_0x59d113=_0x59d113['parent'];return _0x59d113;}}class lt{constructor(_0xabc61c,_0x18808f,_0x14368b){this['_node']=_0xabc61c,this['ref']=_0x18808f,this['_index']=_0x14368b;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x2636a7){const _0x27f2a5=new C(_0x2636a7),_0x3dc3d6=Vt(this['ref'],_0x2636a7);return new lt(this['_node']['getChild'](_0x27f2a5),_0x3dc3d6,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x620ea){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x4c4cc1,_0x5d572c)=>_0x620ea(new lt(_0x5d572c,Vt(this['ref'],_0x4c4cc1),R)));}['hasChild'](_0x256fa6){const _0x3f60cb=new C(_0x256fa6);return!this['_node']['getChild'](_0x3f60cb)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x1d9491,_0x25501e){return _0x1d9491=P(_0x1d9491),_0x1d9491['_checkNotDeleted']('ref'),_0x25501e!==void 0x0?Vt(_0x1d9491['_root'],_0x25501e):_0x1d9491['_root'];}function Vt(_0x4b076d,_0x550e27){return _0x4b076d=P(_0x4b076d),y(_0x4b076d['_path'])===null?pd('child','path',_0x550e27):ys('child','path',_0x550e27),new ee(_0x4b076d['_repo'],k(_0x4b076d['_path'],_0x550e27));}function v_(_0x3f57fc){return _0x3f57fc=P(_0x3f57fc),new Vd(_0x3f57fc['_repo'],_0x3f57fc['_path']);}function E_(_0x1440b5,_0x4b37e2){_0x1440b5=P(_0x1440b5),Me('push',_0x1440b5['_path']),He('push',_0x4b37e2,_0x1440b5['_path'],!0x0);const _0x5ba70b=la(_0x1440b5['_repo']),_0x294786=Ud(_0x5ba70b),_0x2bd5e4=Vt(_0x1440b5,_0x294786),_0x21b034=Vt(_0x1440b5,_0x294786);let _0x407926;return _0x4b37e2!=null?_0x407926=Hd(_0x21b034,_0x4b37e2)['then'](()=>_0x21b034):_0x407926=Promise['resolve'](_0x21b034),_0x2bd5e4['then']=_0x407926['then']['bind'](_0x407926),_0x2bd5e4['catch']=_0x407926['then']['bind'](_0x407926,void 0x0),_0x2bd5e4;}function Hd(_0xb3f7bc,_0x441fd6){_0xb3f7bc=P(_0xb3f7bc),Me('set',_0xb3f7bc['_path']),He('set',_0x441fd6,_0xb3f7bc['_path'],!0x1);const _0x4be75b=new H();return Cd(_0xb3f7bc['_repo'],_0xb3f7bc['_path'],_0x441fd6,null,_0x4be75b['wrapCallback'](()=>{})),_0x4be75b['promise'];}function I_(_0x593eac,_0x585298){ra('update',_0x585298,_0x593eac['_path']);const _0x2efc5c=new H();return Td(_0x593eac['_repo'],_0x593eac['_path'],_0x585298,_0x2efc5c['wrapCallback'](()=>{})),_0x2efc5c['promise'];}function w_(_0x4d7bb3){_0x4d7bb3=P(_0x4d7bb3);const _0x9e56e3=new pa(()=>{}),_0x39ef1d=new Qn(_0x9e56e3);return wd(_0x4d7bb3['_repo'],_0x4d7bb3,_0x39ef1d)['then'](_0x4f47d9=>new lt(_0x4f47d9,new ee(_0x4d7bb3['_repo'],_0x4d7bb3['_path']),_0x4d7bb3['_queryParams']['getIndex']()));}class Qn{constructor(_0x571729){this['callbackContext']=_0x571729;}['respondsTo'](_0x3ef3a9){return _0x3ef3a9==='value';}['createEvent'](_0x525480,_0x4c3c2d){const _0x3fc3a7=_0x4c3c2d['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x525480['snapshotNode'],new ee(_0x4c3c2d['_repo'],_0x4c3c2d['_path']),_0x3fc3a7));}['getEventRunner'](_0x376ec1){return _0x376ec1['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x376ec1['error']):()=>this['callbackContext']['onValue'](_0x376ec1['snapshot'],null);}['createCancelEvent'](_0x5cf2d6,_0x4f7b36){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x5cf2d6,_0x4f7b36):null;}['matches'](_0x6d32cf){return _0x6d32cf instanceof Qn?!_0x6d32cf['callbackContext']||!this['callbackContext']?!0x0:_0x6d32cf['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x19100f,_0xe31820,_0x49e308,_0x2b9ea1,_0x346050){const _0x16612f=new pa(_0x49e308,void 0x0),_0x3b9e44=new Qn(_0x16612f);return kd(_0x19100f['_repo'],_0x19100f,_0x3b9e44),()=>Pd(_0x19100f['_repo'],_0x19100f,_0x3b9e44);}function Gd(_0x3ee2ba,_0x562a4c,_0x318b30,_0x1ea3a0){return $d(_0x3ee2ba,'value',_0x562a4c);}class mt{}class ma extends mt{constructor(_0x24f785,_0x4f18a8){super(),this['_value']=_0x24f785,this['_key']=_0x4f18a8,this['type']='endAt';}['_apply'](_0x47a8d4){He('endAt',this['_value'],_0x47a8d4['_path'],!0x0);const _0x112c9e=Jh(_0x47a8d4['_queryParams'],this['_value'],this['_key']);if(ga(_0x112c9e),Yn(_0x112c9e),_0x47a8d4['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x47a8d4['_repo'],_0x47a8d4['_path'],_0x112c9e,_0x47a8d4['_orderByCalled']);}}function C_(_0xee5e32,_0x4790de){return new ma(_0xee5e32,_0x4790de);}class ya extends mt{constructor(_0x584422,_0x2ff4b2){super(),this['_value']=_0x584422,this['_key']=_0x2ff4b2,this['type']='startAt';}['_apply'](_0x146455){He('startAt',this['_value'],_0x146455['_path'],!0x0);const _0x2555b2=Qh(_0x146455['_queryParams'],this['_value'],this['_key']);if(ga(_0x2555b2),Yn(_0x2555b2),_0x146455['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x146455['_repo'],_0x146455['_path'],_0x2555b2,_0x146455['_orderByCalled']);}}function T_(_0x477309=null,_0x43cc55){return new ya(_0x477309,_0x43cc55);}class qd extends mt{constructor(_0x30b17e){super(),this['_limit']=_0x30b17e,this['type']='limitToFirst';}['_apply'](_0x595846){if(_0x595846['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x595846['_repo'],_0x595846['_path'],Yh(_0x595846['_queryParams'],this['_limit']),_0x595846['_orderByCalled']);}}function S_(_0xbe3b68){if(Math['floor'](_0xbe3b68)!==_0xbe3b68||_0xbe3b68<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0xbe3b68);}class zd extends mt{constructor(_0x21d8ca){super(),this['_path']=_0x21d8ca,this['type']='orderByChild';}['_apply'](_0xe77ff3){_a(_0xe77ff3,'orderByChild');const _0x17069b=new C(this['_path']);if(v(_0x17069b))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x5ab270=new Ji(_0x17069b),_0x47447d=xo(_0xe77ff3['_queryParams'],_0x5ab270);return Yn(_0x47447d),new Ae(_0xe77ff3['_repo'],_0xe77ff3['_path'],_0x47447d,!0x0);}}function b_(_0x4fc340){if(_0x4fc340==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x4fc340==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x4fc340==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x4fc340),new zd(_0x4fc340);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x64e59){_a(_0x64e59,'orderByKey');const _0x323637=xo(_0x64e59['_queryParams'],ve);return Yn(_0x323637),new Ae(_0x64e59['_repo'],_0x64e59['_path'],_0x323637,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x25c0a2,_0x3bb450){super(),this['_value']=_0x25c0a2,this['_key']=_0x3bb450,this['type']='equalTo';}['_apply'](_0x371fe4){if(He('equalTo',this['_value'],_0x371fe4['_path'],!0x1),_0x371fe4['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x371fe4['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x371fe4));}}function A_(_0x21893c,_0x95a080){return new Kd(_0x21893c,_0x95a080);}function k_(_0x529370,..._0x37f866){let _0x247034=P(_0x529370);for(const _0x57edb2 of _0x37f866)_0x247034=_0x57edb2['_apply'](_0x247034);return _0x247034;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x325635,_0x540aeb,_0x4e9427,_0x5ca269){const _0xe0b492=_0x540aeb['lastIndexOf'](':'),_0x19e3a6=_0x540aeb['substring'](0x0,_0xe0b492),_0x41d1d8=qt(_0x19e3a6);_0x325635['repoInfo_']=new yo(_0x540aeb,_0x41d1d8,_0x325635['repoInfo_']['namespace'],_0x325635['repoInfo_']['webSocketOnly'],_0x325635['repoInfo_']['nodeAdmin'],_0x325635['repoInfo_']['persistenceKey'],_0x325635['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x4e9427),_0x5ca269&&(_0x325635['authTokenProvider_']=_0x5ca269);}function Xd(_0x4947ce,_0x363664,_0x5926be,_0x1520d7,_0x4229bd){let _0x152d0a=_0x1520d7||_0x4947ce['options']['databaseURL'];_0x152d0a===void 0x0&&(_0x4947ce['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x4947ce['options']['projectId']),_0x152d0a=_0x4947ce['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x1bcaa2=vr(_0x152d0a,_0x4229bd),_0x1a2f05=_0x1bcaa2['repoInfo'],_0x74b584;typeof process<'u'&&Bs&&(_0x74b584=Bs[Yd]),_0x74b584?(_0x152d0a='http://'+_0x74b584+'?ns='+_0x1a2f05['namespace'],_0x1bcaa2=vr(_0x152d0a,_0x4229bd),_0x1a2f05=_0x1bcaa2['repoInfo']):_0x1bcaa2['repoInfo']['secure'];const _0x429399=new eh(_0x4947ce['name'],_0x4947ce['options'],_0x363664);_d('Invalid\x20Firebase\x20Database\x20URL',_0x1bcaa2),v(_0x1bcaa2['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x51b264=ef(_0x1a2f05,_0x4947ce,_0x429399,new Zl(_0x4947ce,_0x5926be));return new tf(_0x51b264,_0x4947ce);}function Zd(_0x19a1e2,_0x2d904b){const _0x470d06=Di[_0x2d904b];(!_0x470d06||_0x470d06[_0x19a1e2['key']]!==_0x19a1e2)&&ae('Database\x20'+_0x2d904b+'('+_0x19a1e2['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x19a1e2),delete _0x470d06[_0x19a1e2['key']];}function ef(_0x39ae1f,_0x46c4c9,_0xe26149,_0x564288){let _0x4f781c=Di[_0x46c4c9['name']];_0x4f781c||(_0x4f781c={},Di[_0x46c4c9['name']]=_0x4f781c);let _0x40c22a=_0x4f781c[_0x39ae1f['toURLString']()];return _0x40c22a&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x40c22a=new vd(_0x39ae1f,Qd,_0xe26149,_0x564288),_0x4f781c[_0x39ae1f['toURLString']()]=_0x40c22a,_0x40c22a;}class tf{constructor(_0xa12e00,_0x3a843a){this['_repoInternal']=_0xa12e00,this['app']=_0x3a843a,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x2c03e6){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x2c03e6+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x3476c6=Zr(),_0x49a03a){const _0x41e10b=Hi(_0x3476c6,'database')['getImmediate']({'identifier':_0x49a03a});if(!_0x41e10b['_instanceStarted']){const _0xb2881=hc('database');_0xb2881&&nf(_0x41e10b,..._0xb2881);}return _0x41e10b;}function nf(_0x56a240,_0x2baa65,_0x278c01,_0x24b101={}){_0x56a240=P(_0x56a240),_0x56a240['_checkNotDeleted']('useEmulator');const _0x18f7d0=_0x2baa65+':'+_0x278c01,_0x19808d=_0x56a240['_repoInternal'];if(_0x56a240['_instanceStarted']){if(_0x18f7d0===_0x56a240['_repoInternal']['repoInfo_']['host']&&xe(_0x24b101,_0x19808d['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x118cf9;if(_0x19808d['repoInfo_']['nodeAdmin'])_0x24b101['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x118cf9=new an(an['OWNER']);else{if(_0x24b101['mockUserToken']){const _0x5b2579=typeof _0x24b101['mockUserToken']=='string'?_0x24b101['mockUserToken']:uc(_0x24b101['mockUserToken'],_0x56a240['app']['options']['projectId']);_0x118cf9=new an(_0x5b2579);}}qt(_0x2baa65)&&Qr(_0x2baa65),Jd(_0x19808d,_0x18f7d0,_0x24b101,_0x118cf9);}function N_(_0x2f0036){_0x2f0036=P(_0x2f0036),_0x2f0036['_checkNotDeleted']('goOffline'),ha(_0x2f0036['_repo']);}function O_(_0x10ad10){_0x10ad10=P(_0x10ad10),_0x10ad10['_checkNotDeleted']('goOnline'),Nd(_0x10ad10['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x7eb645){Ul(dt),st(new Fe('database',(_0xf49b3b,{instanceIdentifier:_0xe81b84})=>{const _0x2e8916=_0xf49b3b['getProvider']('app')['getImmediate'](),_0x628ac8=_0xf49b3b['getProvider']('auth-internal'),_0x32449a=_0xf49b3b['getProvider']('app-check-internal');return Xd(_0x2e8916,_0x628ac8,_0x32449a,_0xe81b84);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x7eb645),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x19147f,_0x39cb70){this['committed']=_0x19147f,this['snapshot']=_0x39cb70;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x362b87,_0x39bb03,_0x36b7a4){if(_0x362b87=P(_0x362b87),Me('Reference.transaction',_0x362b87['_path']),_0x362b87['key']==='.length'||_0x362b87['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x362b87['key']+'\x20is\x20a\x20read-only\x20object.';const _0x37d733=!0x0,_0x15e1a3=new H(),_0x3665de=(_0x591c85,_0xb3cdea,_0x33c690)=>{let _0x1cca7d=null;_0x591c85?_0x15e1a3['reject'](_0x591c85):(_0x1cca7d=new lt(_0x33c690,new ee(_0x362b87['_repo'],_0x362b87['_path']),R),_0x15e1a3['resolve'](new of(_0xb3cdea,_0x1cca7d)));},_0x103045=Gd(_0x362b87,()=>{});return Od(_0x362b87['_repo'],_0x362b87['_path'],_0x39bb03,_0x3665de,_0x103045,_0x37d733),_0x15e1a3['promise'];}se['prototype']['simpleListen']=function(_0x20b17b,_0xfc0604){this['sendRequest']('q',{'p':_0x20b17b},_0xfc0604);},se['prototype']['echo']=function(_0x5755e9,_0x27e50e){this['sendRequest']('echo',{'d':_0x5755e9},_0x27e50e);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x8db956,..._0x41e020){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x8db956,..._0x41e020);}function cn(_0x5e72ae,..._0x4d79c9){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x5e72ae,..._0x4d79c9);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x3c929b,..._0x3a052d){throw ws(_0x3c929b,..._0x3a052d);}function X(_0x47b20f,..._0x496700){return ws(_0x47b20f,..._0x496700);}function Ia(_0x299348,_0x282292,_0x3e37fa){const _0x220d33={...af(),[_0x282292]:_0x3e37fa};return new Gt('auth','Firebase',_0x220d33)['create'](_0x282292,{'appName':_0x299348['name']});}function re(_0x42a260){return Ia(_0x42a260,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x1a2960,..._0x9333e6){if(typeof _0x1a2960!='string'){const _0x3f0305=_0x9333e6[0x0],_0x425c33=[..._0x9333e6['slice'](0x1)];return _0x425c33[0x0]&&(_0x425c33[0x0]['appName']=_0x1a2960['name']),_0x1a2960['_errorFactory']['create'](_0x3f0305,..._0x425c33);}return Ea['create'](_0x1a2960,..._0x9333e6);}function m(_0x2e7e52,_0x3172f8,..._0x4f2b26){if(!_0x2e7e52)throw ws(_0x3172f8,..._0x4f2b26);}function ne(_0x59bc49){const _0x3aebb9='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x59bc49;throw cn(_0x3aebb9),new Error(_0x3aebb9);}function ce(_0x5660b8,_0x40f14e){_0x5660b8||ne(_0x40f14e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x3ad030;return typeof self<'u'&&((_0x3ad030=self['location'])==null?void 0x0:_0x3ad030['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x445d70;return typeof self<'u'&&((_0x445d70=self['location'])==null?void 0x0:_0x445d70['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x10e6ba=navigator;return _0x10e6ba['languages']&&_0x10e6ba['languages'][0x0]||_0x10e6ba['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x1b0282,_0x46a0a7){this['shortDelay']=_0x1b0282,this['longDelay']=_0x46a0a7,ce(_0x46a0a7>_0x1b0282,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x51ad68,_0x32156d){ce(_0x51ad68['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x16b5e6}=_0x51ad68['emulator'];return _0x32156d?''+_0x16b5e6+(_0x32156d['startsWith']('/')?_0x32156d['slice'](0x1):_0x32156d):_0x16b5e6;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x1f2979,_0x136ec9,_0x1cb137){this['fetchImpl']=_0x1f2979,_0x136ec9&&(this['headersImpl']=_0x136ec9),_0x1cb137&&(this['responseImpl']=_0x1cb137);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x3a4a3e,_0x4bcffc){return _0x3a4a3e['tenantId']&&!_0x4bcffc['tenantId']?{..._0x4bcffc,'tenantId':_0x3a4a3e['tenantId']}:_0x4bcffc;}async function Pe(_0x538c34,_0x3481dd,_0x3290eb,_0x3052ee,_0x523daa={}){return Ca(_0x538c34,_0x523daa,async()=>{let _0x4a4b0a={},_0x2a6981={};_0x3052ee&&(_0x3481dd==='GET'?_0x2a6981=_0x3052ee:_0x4a4b0a={'body':JSON['stringify'](_0x3052ee)});const _0x173ce6=ut({..._0x2a6981,'key':_0x538c34['config']['apiKey']})['slice'](0x1),_0x2c052b=await _0x538c34['_getAdditionalHeaders']();_0x2c052b['Content-Type']='application/json',_0x538c34['languageCode']&&(_0x2c052b['X-Firebase-Locale']=_0x538c34['languageCode']);const _0x2a0b84={'method':_0x3481dd,'headers':_0x2c052b,..._0x4a4b0a};return dc()||(_0x2a0b84['referrerPolicy']='strict-origin-when-cross-origin'),_0x538c34['emulatorConfig']&&qt(_0x538c34['emulatorConfig']['host'])&&(_0x2a0b84['credentials']='include'),wa['fetch']()(await Ta(_0x538c34,_0x538c34['config']['apiHost'],_0x3290eb,_0x173ce6),_0x2a0b84);});}async function Ca(_0x288711,_0x717d0f,_0x40a5bb){_0x288711['_canInitEmulator']=!0x1;const _0x5d51d1={...df,..._0x717d0f};try{const _0x118ba0=new gf(_0x288711),_0x182c6d=await Promise['race']([_0x40a5bb(),_0x118ba0['promise']]);_0x118ba0['clearNetworkTimeout']();const _0x58dea4=await _0x182c6d['json']();if('needConfirmation'in _0x58dea4)throw on(_0x288711,'account-exists-with-different-credential',_0x58dea4);if(_0x182c6d['ok']&&!('errorMessage'in _0x58dea4))return _0x58dea4;{const _0x444ab6=_0x182c6d['ok']?_0x58dea4['errorMessage']:_0x58dea4['error']['message'],[_0x8603ce,_0x4ae71b]=_0x444ab6['split']('\x20:\x20');if(_0x8603ce==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x288711,'credential-already-in-use',_0x58dea4);if(_0x8603ce==='EMAIL_EXISTS')throw on(_0x288711,'email-already-in-use',_0x58dea4);if(_0x8603ce==='USER_DISABLED')throw on(_0x288711,'user-disabled',_0x58dea4);const _0x8d9f13=_0x5d51d1[_0x8603ce]||_0x8603ce['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x4ae71b)throw Ia(_0x288711,_0x8d9f13,_0x4ae71b);Y(_0x288711,_0x8d9f13);}}catch(_0x45fbe1){if(_0x45fbe1 instanceof Re)throw _0x45fbe1;Y(_0x288711,'network-request-failed',{'message':String(_0x45fbe1)});}}async function en(_0x447203,_0x3513d6,_0x2ac6b6,_0x56fa99,_0x5d54f8={}){const _0x8a69e0=await Pe(_0x447203,_0x3513d6,_0x2ac6b6,_0x56fa99,_0x5d54f8);return'mfaPendingCredential'in _0x8a69e0&&Y(_0x447203,'multi-factor-auth-required',{'_serverResponse':_0x8a69e0}),_0x8a69e0;}async function Ta(_0x2280c1,_0x209755,_0x4851b4,_0x49eba7){const _0x167759=''+_0x209755+_0x4851b4+'?'+_0x49eba7,_0x330739=_0x2280c1,_0x9eeaa2=_0x330739['config']['emulator']?Cs(_0x2280c1['config'],_0x167759):_0x2280c1['config']['apiScheme']+'://'+_0x167759;return ff['includes'](_0x4851b4)&&(await _0x330739['_persistenceManagerAvailable'],_0x330739['_getPersistenceType']()==='COOKIE')?_0x330739['_getPersistence']()['_getFinalTarget'](_0x9eeaa2)['toString']():_0x9eeaa2;}function _f(_0x299583){switch(_0x299583){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x3c0c18){this['auth']=_0x3c0c18,this['timer']=null,this['promise']=new Promise((_0x53c0e5,_0x43f38d)=>{this['timer']=setTimeout(()=>_0x43f38d(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x3cdf10,_0x563fdc,_0xd10e0e){const _0x4951cc={'appName':_0x3cdf10['name']};_0xd10e0e['email']&&(_0x4951cc['email']=_0xd10e0e['email']),_0xd10e0e['phoneNumber']&&(_0x4951cc['phoneNumber']=_0xd10e0e['phoneNumber']);const _0x563e51=X(_0x3cdf10,_0x563fdc,_0x4951cc);return _0x563e51['customData']['_tokenResponse']=_0xd10e0e,_0x563e51;}function wr(_0x2579a5){return _0x2579a5!==void 0x0&&_0x2579a5['enterprise']!==void 0x0;}class mf{constructor(_0x25c36a){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x25c36a['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x25c36a['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x25c36a['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x54ce58){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x293236 of this['recaptchaEnforcementState'])if(_0x293236['provider']&&_0x293236['provider']===_0x54ce58)return _f(_0x293236['enforcementState']);return null;}['isProviderEnabled'](_0x40b7fd){return this['getProviderEnforcementState'](_0x40b7fd)==='ENFORCE'||this['getProviderEnforcementState'](_0x40b7fd)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x2a0788,_0x3c3e79){return Pe(_0x2a0788,'GET','/v2/recaptchaConfig',ke(_0x2a0788,_0x3c3e79));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x1c39bc,_0x4bb8dd){return Pe(_0x1c39bc,'POST','/v1/accounts:delete',_0x4bb8dd);}async function Pn(_0x55d0fc,_0x5b47fd){return Pe(_0x55d0fc,'POST','/v1/accounts:lookup',_0x5b47fd);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x571809){if(_0x571809)try{const _0x4a09a9=new Date(Number(_0x571809));if(!isNaN(_0x4a09a9['getTime']()))return _0x4a09a9['toUTCString']();}catch{}}async function Ef(_0x14c48b,_0x2ec086=!0x1){const _0x59ef02=P(_0x14c48b),_0x20690d=await _0x59ef02['getIdToken'](_0x2ec086),_0x11f280=Ts(_0x20690d);m(_0x11f280&&_0x11f280['exp']&&_0x11f280['auth_time']&&_0x11f280['iat'],_0x59ef02['auth'],'internal-error');const _0x4099d2=typeof _0x11f280['firebase']=='object'?_0x11f280['firebase']:void 0x0,_0x2ad5cf=_0x4099d2==null?void 0x0:_0x4099d2['sign_in_provider'];return{'claims':_0x11f280,'token':_0x20690d,'authTime':Pt(fi(_0x11f280['auth_time'])),'issuedAtTime':Pt(fi(_0x11f280['iat'])),'expirationTime':Pt(fi(_0x11f280['exp'])),'signInProvider':_0x2ad5cf||null,'signInSecondFactor':(_0x4099d2==null?void 0x0:_0x4099d2['sign_in_second_factor'])||null};}function fi(_0x51bbb1){return Number(_0x51bbb1)*0x3e8;}function Ts(_0x414ead){const [_0x17d0d5,_0x382b2d,_0xb6d03d]=_0x414ead['split']('.');if(_0x17d0d5===void 0x0||_0x382b2d===void 0x0||_0xb6d03d===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x1032a3=fn(_0x382b2d);return _0x1032a3?JSON['parse'](_0x1032a3):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x7cad11){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x7cad11==null?void 0x0:_0x7cad11['toString']()),null;}}function Cr(_0x12c966){const _0x49039c=Ts(_0x12c966);return m(_0x49039c,'internal-error'),m(typeof _0x49039c['exp']<'u','internal-error'),m(typeof _0x49039c['iat']<'u','internal-error'),Number(_0x49039c['exp'])-Number(_0x49039c['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x2d8e1e,_0x478ada,_0x40582d=!0x1){if(_0x40582d)return _0x478ada;try{return await _0x478ada;}catch(_0x3acb18){throw _0x3acb18 instanceof Re&&If(_0x3acb18)&&_0x2d8e1e['auth']['currentUser']===_0x2d8e1e&&await _0x2d8e1e['auth']['signOut'](),_0x3acb18;}}function If({code:_0xea615e}){return _0xea615e==='auth/user-disabled'||_0xea615e==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x410e22){this['user']=_0x410e22,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x37437d){if(_0x37437d){const _0x52e127=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x52e127;}else{this['errorBackoff']=0x7530;const _0x14a434=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x14a434);}}['schedule'](_0x4bf311=!0x1){if(!this['isRunning'])return;const _0x33128e=this['getInterval'](_0x4bf311);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x33128e);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x10ed57){(_0x10ed57==null?void 0x0:_0x10ed57['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x53bcb0,_0xd2692d){this['createdAt']=_0x53bcb0,this['lastLoginAt']=_0xd2692d,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x45c9f0){this['createdAt']=_0x45c9f0['createdAt'],this['lastLoginAt']=_0x45c9f0['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x2899a3){var _0x4ce7f8;const _0x11b3a5=_0x2899a3['auth'],_0xa41244=await _0x2899a3['getIdToken'](),_0x46ba7f=await Ht(_0x2899a3,Pn(_0x11b3a5,{'idToken':_0xa41244}));m(_0x46ba7f==null?void 0x0:_0x46ba7f['users']['length'],_0x11b3a5,'internal-error');const _0x48c986=_0x46ba7f['users'][0x0];_0x2899a3['_notifyReloadListener'](_0x48c986);const _0x122a82=(_0x4ce7f8=_0x48c986['providerUserInfo'])!=null&&_0x4ce7f8['length']?Sa(_0x48c986['providerUserInfo']):[],_0x132345=Tf(_0x2899a3['providerData'],_0x122a82),_0x26a1a3=_0x2899a3['isAnonymous'],_0x3805db=!(_0x2899a3['email']&&_0x48c986['passwordHash'])&&!(_0x132345!=null&&_0x132345['length']),_0x517685=_0x26a1a3?_0x3805db:!0x1,_0x449266={'uid':_0x48c986['localId'],'displayName':_0x48c986['displayName']||null,'photoURL':_0x48c986['photoUrl']||null,'email':_0x48c986['email']||null,'emailVerified':_0x48c986['emailVerified']||!0x1,'phoneNumber':_0x48c986['phoneNumber']||null,'tenantId':_0x48c986['tenantId']||null,'providerData':_0x132345,'metadata':new Li(_0x48c986['createdAt'],_0x48c986['lastLoginAt']),'isAnonymous':_0x517685};Object['assign'](_0x2899a3,_0x449266);}async function Cf(_0x3e281f){const _0x59c512=P(_0x3e281f);await Nn(_0x59c512),await _0x59c512['auth']['_persistUserIfCurrent'](_0x59c512),_0x59c512['auth']['_notifyListenersIfCurrent'](_0x59c512);}function Tf(_0x452820,_0x2a8f30){return[..._0x452820['filter'](_0xe5e5e4=>!_0x2a8f30['some'](_0x3555bf=>_0x3555bf['providerId']===_0xe5e5e4['providerId'])),..._0x2a8f30];}function Sa(_0x56ee5c){return _0x56ee5c['map'](({providerId:_0x35e2df,..._0x52bc59})=>({'providerId':_0x35e2df,'uid':_0x52bc59['rawId']||'','displayName':_0x52bc59['displayName']||null,'email':_0x52bc59['email']||null,'phoneNumber':_0x52bc59['phoneNumber']||null,'photoURL':_0x52bc59['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x413ffb,_0x4bca78){const _0xf51939=await Ca(_0x413ffb,{},async()=>{const _0x26fec7=ut({'grant_type':'refresh_token','refresh_token':_0x4bca78})['slice'](0x1),{tokenApiHost:_0x4afdbc,apiKey:_0x4dbff4}=_0x413ffb['config'],_0x5de507=await Ta(_0x413ffb,_0x4afdbc,'/v1/token','key='+_0x4dbff4),_0x48cb09=await _0x413ffb['_getAdditionalHeaders']();_0x48cb09['Content-Type']='application/x-www-form-urlencoded';const _0xd6da4d={'method':'POST','headers':_0x48cb09,'body':_0x26fec7};return _0x413ffb['emulatorConfig']&&qt(_0x413ffb['emulatorConfig']['host'])&&(_0xd6da4d['credentials']='include'),wa['fetch']()(_0x5de507,_0xd6da4d);});return{'accessToken':_0xf51939['access_token'],'expiresIn':_0xf51939['expires_in'],'refreshToken':_0xf51939['refresh_token']};}async function bf(_0x5ae5ca,_0x523352){return Pe(_0x5ae5ca,'POST','/v2/accounts:revokeToken',ke(_0x5ae5ca,_0x523352));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x44e97f){m(_0x44e97f['idToken'],'internal-error'),m(typeof _0x44e97f['idToken']<'u','internal-error'),m(typeof _0x44e97f['refreshToken']<'u','internal-error');const _0x516771='expiresIn'in _0x44e97f&&typeof _0x44e97f['expiresIn']<'u'?Number(_0x44e97f['expiresIn']):Cr(_0x44e97f['idToken']);this['updateTokensAndExpiration'](_0x44e97f['idToken'],_0x44e97f['refreshToken'],_0x516771);}['updateFromIdToken'](_0x3433c1){m(_0x3433c1['length']!==0x0,'internal-error');const _0xb634c7=Cr(_0x3433c1);this['updateTokensAndExpiration'](_0x3433c1,null,_0xb634c7);}async['getToken'](_0x1f1a0b,_0x44a952=!0x1){return!_0x44a952&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x1f1a0b,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x1f1a0b,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x3a5bb7,_0x342493){const {accessToken:_0x55a0a6,refreshToken:_0x3592ba,expiresIn:_0x160ebb}=await Sf(_0x3a5bb7,_0x342493);this['updateTokensAndExpiration'](_0x55a0a6,_0x3592ba,Number(_0x160ebb));}['updateTokensAndExpiration'](_0x39a03d,_0x21358c,_0x42f12f){this['refreshToken']=_0x21358c||null,this['accessToken']=_0x39a03d||null,this['expirationTime']=Date['now']()+_0x42f12f*0x3e8;}static['fromJSON'](_0xa0047b,_0xf27967){const {refreshToken:_0x17dc3f,accessToken:_0x5c1e44,expirationTime:_0x2373ce}=_0xf27967,_0x56ea1f=new et();return _0x17dc3f&&(m(typeof _0x17dc3f=='string','internal-error',{'appName':_0xa0047b}),_0x56ea1f['refreshToken']=_0x17dc3f),_0x5c1e44&&(m(typeof _0x5c1e44=='string','internal-error',{'appName':_0xa0047b}),_0x56ea1f['accessToken']=_0x5c1e44),_0x2373ce&&(m(typeof _0x2373ce=='number','internal-error',{'appName':_0xa0047b}),_0x56ea1f['expirationTime']=_0x2373ce),_0x56ea1f;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0xa6b817){this['accessToken']=_0xa6b817['accessToken'],this['refreshToken']=_0xa6b817['refreshToken'],this['expirationTime']=_0xa6b817['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x114927,_0x165f85){m(typeof _0x114927=='string'||typeof _0x114927>'u','internal-error',{'appName':_0x165f85});}class j{constructor({uid:_0x17d8d4,auth:_0x132f21,stsTokenManager:_0x3b44c2,..._0x4f9aac}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x17d8d4,this['auth']=_0x132f21,this['stsTokenManager']=_0x3b44c2,this['accessToken']=_0x3b44c2['accessToken'],this['displayName']=_0x4f9aac['displayName']||null,this['email']=_0x4f9aac['email']||null,this['emailVerified']=_0x4f9aac['emailVerified']||!0x1,this['phoneNumber']=_0x4f9aac['phoneNumber']||null,this['photoURL']=_0x4f9aac['photoURL']||null,this['isAnonymous']=_0x4f9aac['isAnonymous']||!0x1,this['tenantId']=_0x4f9aac['tenantId']||null,this['providerData']=_0x4f9aac['providerData']?[..._0x4f9aac['providerData']]:[],this['metadata']=new Li(_0x4f9aac['createdAt']||void 0x0,_0x4f9aac['lastLoginAt']||void 0x0);}async['getIdToken'](_0x1b6558){const _0x134ae6=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x1b6558));return m(_0x134ae6,this['auth'],'internal-error'),this['accessToken']!==_0x134ae6&&(this['accessToken']=_0x134ae6,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x134ae6;}['getIdTokenResult'](_0x577128){return Ef(this,_0x577128);}['reload'](){return Cf(this);}['_assign'](_0x42068b){this!==_0x42068b&&(m(this['uid']===_0x42068b['uid'],this['auth'],'internal-error'),this['displayName']=_0x42068b['displayName'],this['photoURL']=_0x42068b['photoURL'],this['email']=_0x42068b['email'],this['emailVerified']=_0x42068b['emailVerified'],this['phoneNumber']=_0x42068b['phoneNumber'],this['isAnonymous']=_0x42068b['isAnonymous'],this['tenantId']=_0x42068b['tenantId'],this['providerData']=_0x42068b['providerData']['map'](_0x8bea36=>({..._0x8bea36})),this['metadata']['_copy'](_0x42068b['metadata']),this['stsTokenManager']['_assign'](_0x42068b['stsTokenManager']));}['_clone'](_0x26085a){const _0x2f3f12=new j({...this,'auth':_0x26085a,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x2f3f12['metadata']['_copy'](this['metadata']),_0x2f3f12;}['_onReload'](_0x859aab){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x859aab,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x738265){this['reloadListener']?this['reloadListener'](_0x738265):this['reloadUserInfo']=_0x738265;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0xfcf7e8,_0x33befb=!0x1){let _0x54379f=!0x1;_0xfcf7e8['idToken']&&_0xfcf7e8['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0xfcf7e8),_0x54379f=!0x0),_0x33befb&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x54379f&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x110ec5=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x110ec5})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x496d7b=>({..._0x496d7b})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x523af0,_0x2a8e75){const _0x4848d0=_0x2a8e75['displayName']??void 0x0,_0x4fb0fb=_0x2a8e75['email']??void 0x0,_0x134fb9=_0x2a8e75['phoneNumber']??void 0x0,_0x46be88=_0x2a8e75['photoURL']??void 0x0,_0x430201=_0x2a8e75['tenantId']??void 0x0,_0x2f7d44=_0x2a8e75['_redirectEventId']??void 0x0,_0x186876=_0x2a8e75['createdAt']??void 0x0,_0x2b48d8=_0x2a8e75['lastLoginAt']??void 0x0,{uid:_0x5712b3,emailVerified:_0x4e72b9,isAnonymous:_0x32f1c3,providerData:_0x249727,stsTokenManager:_0x15783b}=_0x2a8e75;m(_0x5712b3&&_0x15783b,_0x523af0,'internal-error');const _0x2f669f=et['fromJSON'](this['name'],_0x15783b);m(typeof _0x5712b3=='string',_0x523af0,'internal-error'),le(_0x4848d0,_0x523af0['name']),le(_0x4fb0fb,_0x523af0['name']),m(typeof _0x4e72b9=='boolean',_0x523af0,'internal-error'),m(typeof _0x32f1c3=='boolean',_0x523af0,'internal-error'),le(_0x134fb9,_0x523af0['name']),le(_0x46be88,_0x523af0['name']),le(_0x430201,_0x523af0['name']),le(_0x2f7d44,_0x523af0['name']),le(_0x186876,_0x523af0['name']),le(_0x2b48d8,_0x523af0['name']);const _0x1fe869=new j({'uid':_0x5712b3,'auth':_0x523af0,'email':_0x4fb0fb,'emailVerified':_0x4e72b9,'displayName':_0x4848d0,'isAnonymous':_0x32f1c3,'photoURL':_0x46be88,'phoneNumber':_0x134fb9,'tenantId':_0x430201,'stsTokenManager':_0x2f669f,'createdAt':_0x186876,'lastLoginAt':_0x2b48d8});return _0x249727&&Array['isArray'](_0x249727)&&(_0x1fe869['providerData']=_0x249727['map'](_0x828ff8=>({..._0x828ff8}))),_0x2f7d44&&(_0x1fe869['_redirectEventId']=_0x2f7d44),_0x1fe869;}static async['_fromIdTokenResponse'](_0x2a32e5,_0x6bdd09,_0x5a17b4=!0x1){const _0x2893eb=new et();_0x2893eb['updateFromServerResponse'](_0x6bdd09);const _0x29f5e6=new j({'uid':_0x6bdd09['localId'],'auth':_0x2a32e5,'stsTokenManager':_0x2893eb,'isAnonymous':_0x5a17b4});return await Nn(_0x29f5e6),_0x29f5e6;}static async['_fromGetAccountInfoResponse'](_0x3db5cd,_0x57f62f,_0x121675){const _0xb2bea2=_0x57f62f['users'][0x0];m(_0xb2bea2['localId']!==void 0x0,'internal-error');const _0x46b39d=_0xb2bea2['providerUserInfo']!==void 0x0?Sa(_0xb2bea2['providerUserInfo']):[],_0x1417f5=!(_0xb2bea2['email']&&_0xb2bea2['passwordHash'])&&!(_0x46b39d!=null&&_0x46b39d['length']),_0x4eb837=new et();_0x4eb837['updateFromIdToken'](_0x121675);const _0xf5b7d5=new j({'uid':_0xb2bea2['localId'],'auth':_0x3db5cd,'stsTokenManager':_0x4eb837,'isAnonymous':_0x1417f5}),_0x1f1985={'uid':_0xb2bea2['localId'],'displayName':_0xb2bea2['displayName']||null,'photoURL':_0xb2bea2['photoUrl']||null,'email':_0xb2bea2['email']||null,'emailVerified':_0xb2bea2['emailVerified']||!0x1,'phoneNumber':_0xb2bea2['phoneNumber']||null,'tenantId':_0xb2bea2['tenantId']||null,'providerData':_0x46b39d,'metadata':new Li(_0xb2bea2['createdAt'],_0xb2bea2['lastLoginAt']),'isAnonymous':!(_0xb2bea2['email']&&_0xb2bea2['passwordHash'])&&!(_0x46b39d!=null&&_0x46b39d['length'])};return Object['assign'](_0xf5b7d5,_0x1f1985),_0xf5b7d5;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x42639d){ce(_0x42639d instanceof Function,'Expected\x20a\x20class\x20definition');let _0x5423e9=Tr['get'](_0x42639d);return _0x5423e9?(ce(_0x5423e9 instanceof _0x42639d,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x5423e9):(_0x5423e9=new _0x42639d(),Tr['set'](_0x42639d,_0x5423e9),_0x5423e9);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x55e03b,_0xd573a1){this['storage'][_0x55e03b]=_0xd573a1;}async['_get'](_0x3f133a){const _0x320b73=this['storage'][_0x3f133a];return _0x320b73===void 0x0?null:_0x320b73;}async['_remove'](_0x52f4df){delete this['storage'][_0x52f4df];}['_addListener'](_0x14b3d5,_0x59218f){}['_removeListener'](_0x58ce5a,_0x36182d){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x975f6e,_0x345ce8,_0x25b023){return'firebase:'+_0x975f6e+':'+_0x345ce8+':'+_0x25b023;}class tt{constructor(_0x72681a,_0x421186,_0x4caea3){this['persistence']=_0x72681a,this['auth']=_0x421186,this['userKey']=_0x4caea3;const {config:_0x4da7b4,name:_0x4a5a31}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x4da7b4['apiKey'],_0x4a5a31),this['fullPersistenceKey']=ln('persistence',_0x4da7b4['apiKey'],_0x4a5a31),this['boundEventHandler']=_0x421186['_onStorageEvent']['bind'](_0x421186),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x50751c){return this['persistence']['_set'](this['fullUserKey'],_0x50751c['toJSON']());}async['getCurrentUser'](){const _0x2b915f=await this['persistence']['_get'](this['fullUserKey']);if(!_0x2b915f)return null;if(typeof _0x2b915f=='string'){const _0x55542b=await Pn(this['auth'],{'idToken':_0x2b915f})['catch'](()=>{});return _0x55542b?j['_fromGetAccountInfoResponse'](this['auth'],_0x55542b,_0x2b915f):null;}return j['_fromJSON'](this['auth'],_0x2b915f);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x24d23d){if(this['persistence']===_0x24d23d)return;const _0x2b26b2=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x24d23d,_0x2b26b2)return this['setCurrentUser'](_0x2b26b2);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x29ff3d,_0x1d7495,_0x7b189c='authUser'){if(!_0x1d7495['length'])return new tt(ie(Sr),_0x29ff3d,_0x7b189c);const _0x24c7aa=(await Promise['all'](_0x1d7495['map'](async _0x87371b=>{if(await _0x87371b['_isAvailable']())return _0x87371b;})))['filter'](_0xabcc8c=>_0xabcc8c);let _0x270151=_0x24c7aa[0x0]||ie(Sr);const _0x139ddb=ln(_0x7b189c,_0x29ff3d['config']['apiKey'],_0x29ff3d['name']);let _0x400021=null;for(const _0x131a02 of _0x1d7495)try{const _0x3710ae=await _0x131a02['_get'](_0x139ddb);if(_0x3710ae){let _0x3a9985;if(typeof _0x3710ae=='string'){const _0x9c73ef=await Pn(_0x29ff3d,{'idToken':_0x3710ae})['catch'](()=>{});if(!_0x9c73ef)break;_0x3a9985=await j['_fromGetAccountInfoResponse'](_0x29ff3d,_0x9c73ef,_0x3710ae);}else _0x3a9985=j['_fromJSON'](_0x29ff3d,_0x3710ae);_0x131a02!==_0x270151&&(_0x400021=_0x3a9985),_0x270151=_0x131a02;break;}}catch{}const _0x4f74d7=_0x24c7aa['filter'](_0x461f59=>_0x461f59['_shouldAllowMigration']);return!_0x270151['_shouldAllowMigration']||!_0x4f74d7['length']?new tt(_0x270151,_0x29ff3d,_0x7b189c):(_0x270151=_0x4f74d7[0x0],_0x400021&&await _0x270151['_set'](_0x139ddb,_0x400021['toJSON']()),await Promise['all'](_0x1d7495['map'](async _0x333662=>{if(_0x333662!==_0x270151)try{await _0x333662['_remove'](_0x139ddb);}catch{}})),new tt(_0x270151,_0x29ff3d,_0x7b189c));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x19be13){const _0x4656f7=_0x19be13['toLowerCase']();if(_0x4656f7['includes']('opera/')||_0x4656f7['includes']('opr/')||_0x4656f7['includes']('opios/'))return'Opera';if(Pa(_0x4656f7))return'IEMobile';if(_0x4656f7['includes']('msie')||_0x4656f7['includes']('trident/'))return'IE';if(_0x4656f7['includes']('edge/'))return'Edge';if(Ra(_0x4656f7))return'Firefox';if(_0x4656f7['includes']('silk/'))return'Silk';if(Oa(_0x4656f7))return'Blackberry';if(Da(_0x4656f7))return'Webos';if(Aa(_0x4656f7))return'Safari';if((_0x4656f7['includes']('chrome/')||ka(_0x4656f7))&&!_0x4656f7['includes']('edge/'))return'Chrome';if(Na(_0x4656f7))return'Android';{const _0x3cb726=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x5707e1=_0x19be13['match'](_0x3cb726);if((_0x5707e1==null?void 0x0:_0x5707e1['length'])===0x2)return _0x5707e1[0x1];}return'Other';}function Ra(_0x38e098=W()){return/firefox\//i['test'](_0x38e098);}function Aa(_0x3b34b8=W()){const _0x4e2084=_0x3b34b8['toLowerCase']();return _0x4e2084['includes']('safari/')&&!_0x4e2084['includes']('chrome/')&&!_0x4e2084['includes']('crios/')&&!_0x4e2084['includes']('android');}function ka(_0x54f085=W()){return/crios\//i['test'](_0x54f085);}function Pa(_0x2fe19a=W()){return/iemobile/i['test'](_0x2fe19a);}function Na(_0x41dc90=W()){return/android/i['test'](_0x41dc90);}function Oa(_0x201a46=W()){return/blackberry/i['test'](_0x201a46);}function Da(_0xd7df44=W()){return/webos/i['test'](_0xd7df44);}function Ss(_0xb0144=W()){return/iphone|ipad|ipod/i['test'](_0xb0144)||/macintosh/i['test'](_0xb0144)&&/mobile/i['test'](_0xb0144);}function Rf(_0x2f1a0d=W()){var _0x1fd6be;return Ss(_0x2f1a0d)&&!!((_0x1fd6be=window['navigator'])!=null&&_0x1fd6be['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x2f8f48=W()){return Ss(_0x2f8f48)||Na(_0x2f8f48)||Da(_0x2f8f48)||Oa(_0x2f8f48)||/windows phone/i['test'](_0x2f8f48)||Pa(_0x2f8f48);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x5604c1,_0x3fc689=[]){let _0x34ff02;switch(_0x5604c1){case'Browser':_0x34ff02=br(W());break;case'Worker':_0x34ff02=br(W())+'-'+_0x5604c1;break;default:_0x34ff02=_0x5604c1;}const _0x4f9453=_0x3fc689['length']?_0x3fc689['join'](','):'FirebaseCore-web';return _0x34ff02+'/JsCore/'+dt+'/'+_0x4f9453;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x4d98f4){this['auth']=_0x4d98f4,this['queue']=[];}['pushCallback'](_0x361a52,_0x54c0d1){const _0x127010=_0x3fb818=>new Promise((_0x5a708d,_0x296386)=>{try{const _0x58b489=_0x361a52(_0x3fb818);_0x5a708d(_0x58b489);}catch(_0x513335){_0x296386(_0x513335);}});_0x127010['onAbort']=_0x54c0d1,this['queue']['push'](_0x127010);const _0x54a07b=this['queue']['length']-0x1;return()=>{this['queue'][_0x54a07b]=()=>Promise['resolve']();};}async['runMiddleware'](_0x4a8991){if(this['auth']['currentUser']===_0x4a8991)return;const _0xabd5a=[];try{for(const _0x225cd2 of this['queue'])await _0x225cd2(_0x4a8991),_0x225cd2['onAbort']&&_0xabd5a['push'](_0x225cd2['onAbort']);}catch(_0x3056f9){_0xabd5a['reverse']();for(const _0x47e054 of _0xabd5a)try{_0x47e054();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x3056f9==null?void 0x0:_0x3056f9['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x37b273,_0x4cee79={}){return Pe(_0x37b273,'GET','/v2/passwordPolicy',ke(_0x37b273,_0x4cee79));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x40b7f8){var _0x430d33;const _0x109a93=_0x40b7f8['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x109a93['minPasswordLength']??Nf,_0x109a93['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x109a93['maxPasswordLength']),_0x109a93['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x109a93['containsLowercaseCharacter']),_0x109a93['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x109a93['containsUppercaseCharacter']),_0x109a93['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x109a93['containsNumericCharacter']),_0x109a93['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x109a93['containsNonAlphanumericCharacter']),this['enforcementState']=_0x40b7f8['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x430d33=_0x40b7f8['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x430d33['join'](''))??'',this['forceUpgradeOnSignin']=_0x40b7f8['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x40b7f8['schemaVersion'];}['validatePassword'](_0x46f875){const _0x3a12d2={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x46f875,_0x3a12d2),this['validatePasswordCharacterOptions'](_0x46f875,_0x3a12d2),_0x3a12d2['isValid']&&(_0x3a12d2['isValid']=_0x3a12d2['meetsMinPasswordLength']??!0x0),_0x3a12d2['isValid']&&(_0x3a12d2['isValid']=_0x3a12d2['meetsMaxPasswordLength']??!0x0),_0x3a12d2['isValid']&&(_0x3a12d2['isValid']=_0x3a12d2['containsLowercaseLetter']??!0x0),_0x3a12d2['isValid']&&(_0x3a12d2['isValid']=_0x3a12d2['containsUppercaseLetter']??!0x0),_0x3a12d2['isValid']&&(_0x3a12d2['isValid']=_0x3a12d2['containsNumericCharacter']??!0x0),_0x3a12d2['isValid']&&(_0x3a12d2['isValid']=_0x3a12d2['containsNonAlphanumericCharacter']??!0x0),_0x3a12d2;}['validatePasswordLengthOptions'](_0x1664f5,_0x1cc248){const _0x4ad0b3=this['customStrengthOptions']['minPasswordLength'],_0x5e6ee5=this['customStrengthOptions']['maxPasswordLength'];_0x4ad0b3&&(_0x1cc248['meetsMinPasswordLength']=_0x1664f5['length']>=_0x4ad0b3),_0x5e6ee5&&(_0x1cc248['meetsMaxPasswordLength']=_0x1664f5['length']<=_0x5e6ee5);}['validatePasswordCharacterOptions'](_0x4d548e,_0x5da2d5){this['updatePasswordCharacterOptionsStatuses'](_0x5da2d5,!0x1,!0x1,!0x1,!0x1);let _0x3e9363;for(let _0x3c84f5=0x0;_0x3c84f5<_0x4d548e['length'];_0x3c84f5++)_0x3e9363=_0x4d548e['charAt'](_0x3c84f5),this['updatePasswordCharacterOptionsStatuses'](_0x5da2d5,_0x3e9363>='a'&&_0x3e9363<='z',_0x3e9363>='A'&&_0x3e9363<='Z',_0x3e9363>='0'&&_0x3e9363<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x3e9363));}['updatePasswordCharacterOptionsStatuses'](_0x57d4c4,_0x4b3b2d,_0xb7843,_0x3af203,_0x47b5da){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x57d4c4['containsLowercaseLetter']||(_0x57d4c4['containsLowercaseLetter']=_0x4b3b2d)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x57d4c4['containsUppercaseLetter']||(_0x57d4c4['containsUppercaseLetter']=_0xb7843)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x57d4c4['containsNumericCharacter']||(_0x57d4c4['containsNumericCharacter']=_0x3af203)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x57d4c4['containsNonAlphanumericCharacter']||(_0x57d4c4['containsNonAlphanumericCharacter']=_0x47b5da));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x4b00ae,_0x3d4b0d,_0xa17cbf,_0x5664fc){this['app']=_0x4b00ae,this['heartbeatServiceProvider']=_0x3d4b0d,this['appCheckServiceProvider']=_0xa17cbf,this['config']=_0x5664fc,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x4b00ae['name'],this['clientVersion']=_0x5664fc['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x4e15ce=>this['_resolvePersistenceManagerAvailable']=_0x4e15ce);}['_initializeWithPersistence'](_0x30da0d,_0x32bb73){return _0x32bb73&&(this['_popupRedirectResolver']=ie(_0x32bb73)),this['_initializationPromise']=this['queue'](async()=>{var _0x3e7515,_0x2a1eec,_0x69bf4f;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x30da0d),(_0x3e7515=this['_resolvePersistenceManagerAvailable'])==null||_0x3e7515['call'](this),!this['_deleted'])){if((_0x2a1eec=this['_popupRedirectResolver'])!=null&&_0x2a1eec['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x32bb73),this['lastNotifiedUid']=((_0x69bf4f=this['currentUser'])==null?void 0x0:_0x69bf4f['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x577051=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x577051)){if(this['currentUser']&&_0x577051&&this['currentUser']['uid']===_0x577051['uid']){this['_currentUser']['_assign'](_0x577051),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x577051,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x39d380){try{const _0x1aec63=await Pn(this,{'idToken':_0x39d380}),_0x3cd07e=await j['_fromGetAccountInfoResponse'](this,_0x1aec63,_0x39d380);await this['directlySetCurrentUser'](_0x3cd07e);}catch(_0x6313d1){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x6313d1),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x2d337d){var _0x13e671;if($(this['app'])){const _0x1097d1=this['app']['settings']['authIdToken'];return _0x1097d1?new Promise(_0x34f45f=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x1097d1)['then'](_0x34f45f,_0x34f45f));}):this['directlySetCurrentUser'](null);}const _0x23060e=await this['assertedPersistence']['getCurrentUser']();let _0x5da354=_0x23060e,_0x38851f=!0x1;if(_0x2d337d&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x3bd7aa=(_0x13e671=this['redirectUser'])==null?void 0x0:_0x13e671['_redirectEventId'],_0x1e74f9=_0x5da354==null?void 0x0:_0x5da354['_redirectEventId'],_0x103aed=await this['tryRedirectSignIn'](_0x2d337d);(!_0x3bd7aa||_0x3bd7aa===_0x1e74f9)&&(_0x103aed!=null&&_0x103aed['user'])&&(_0x5da354=_0x103aed['user'],_0x38851f=!0x0);}if(!_0x5da354)return this['directlySetCurrentUser'](null);if(!_0x5da354['_redirectEventId']){if(_0x38851f)try{await this['beforeStateQueue']['runMiddleware'](_0x5da354);}catch(_0x30cecb){_0x5da354=_0x23060e,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x30cecb));}return _0x5da354?this['reloadAndSetCurrentUserOrClear'](_0x5da354):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x5da354['_redirectEventId']?this['directlySetCurrentUser'](_0x5da354):this['reloadAndSetCurrentUserOrClear'](_0x5da354);}async['tryRedirectSignIn'](_0x16a5e5){let _0x55e2f4=null;try{_0x55e2f4=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x16a5e5,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x55e2f4;}async['reloadAndSetCurrentUserOrClear'](_0x4c9e2a){try{await Nn(_0x4c9e2a);}catch(_0x2f8a97){if((_0x2f8a97==null?void 0x0:_0x2f8a97['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x4c9e2a);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0xb11f30){if($(this['app']))return Promise['reject'](re(this));const _0x3da589=_0xb11f30?P(_0xb11f30):null;return _0x3da589&&m(_0x3da589['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x3da589&&_0x3da589['_clone'](this));}async['_updateCurrentUser'](_0x48cd6,_0x133dee=!0x1){if(!this['_deleted'])return _0x48cd6&&m(this['tenantId']===_0x48cd6['tenantId'],this,'tenant-id-mismatch'),_0x133dee||await this['beforeStateQueue']['runMiddleware'](_0x48cd6),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x48cd6),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x1b082b){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x1b082b));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x105341){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x4fb75a=this['_getPasswordPolicyInternal']();return _0x4fb75a['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x4fb75a['validatePassword'](_0x105341);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x293643=await Pf(this),_0x5c3bde=new Of(_0x293643);this['tenantId']===null?this['_projectPasswordPolicy']=_0x5c3bde:this['_tenantPasswordPolicies'][this['tenantId']]=_0x5c3bde;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x48f737){this['_errorFactory']=new Gt('auth','Firebase',_0x48f737());}['onAuthStateChanged'](_0x427c12,_0x5d316f,_0x2b5fa5){return this['registerStateListener'](this['authStateSubscription'],_0x427c12,_0x5d316f,_0x2b5fa5);}['beforeAuthStateChanged'](_0x70b8ca,_0x4e05a4){return this['beforeStateQueue']['pushCallback'](_0x70b8ca,_0x4e05a4);}['onIdTokenChanged'](_0x39b4ec,_0x594641,_0xdfa33b){return this['registerStateListener'](this['idTokenSubscription'],_0x39b4ec,_0x594641,_0xdfa33b);}['authStateReady'](){return new Promise((_0x168dee,_0x45cf98)=>{if(this['currentUser'])_0x168dee();else{const _0x26ff3a=this['onAuthStateChanged'](()=>{_0x26ff3a(),_0x168dee();},_0x45cf98);}});}async['revokeAccessToken'](_0x15f0cc){if(this['currentUser']){const _0x4e1c93=await this['currentUser']['getIdToken'](),_0x3637f3={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x15f0cc,'idToken':_0x4e1c93};this['tenantId']!=null&&(_0x3637f3['tenantId']=this['tenantId']),await bf(this,_0x3637f3);}}['toJSON'](){var _0x3cbcbd;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x3cbcbd=this['_currentUser'])==null?void 0x0:_0x3cbcbd['toJSON']()};}async['_setRedirectUser'](_0x18312d,_0x40a5a9){const _0x7baa59=await this['getOrInitRedirectPersistenceManager'](_0x40a5a9);return _0x18312d===null?_0x7baa59['removeCurrentUser']():_0x7baa59['setCurrentUser'](_0x18312d);}async['getOrInitRedirectPersistenceManager'](_0x57cf48){if(!this['redirectPersistenceManager']){const _0xdcaa54=_0x57cf48&&ie(_0x57cf48)||this['_popupRedirectResolver'];m(_0xdcaa54,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0xdcaa54['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x2d817b){var _0x3ecd62,_0x3893cb;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x3ecd62=this['_currentUser'])==null?void 0x0:_0x3ecd62['_redirectEventId'])===_0x2d817b?this['_currentUser']:((_0x3893cb=this['redirectUser'])==null?void 0x0:_0x3893cb['_redirectEventId'])===_0x2d817b?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x238481){if(_0x238481===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x238481));}['_notifyListenersIfCurrent'](_0x14de69){_0x14de69===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x36025b;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x15f170=((_0x36025b=this['currentUser'])==null?void 0x0:_0x36025b['uid'])??null;this['lastNotifiedUid']!==_0x15f170&&(this['lastNotifiedUid']=_0x15f170,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0xf5ad27,_0x14edef,_0x4c8683,_0x4a38c5){if(this['_deleted'])return()=>{};const _0xfe016f=typeof _0x14edef=='function'?_0x14edef:_0x14edef['next']['bind'](_0x14edef);let _0x556ba7=!0x1;const _0x170aab=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x170aab,this,'internal-error'),_0x170aab['then'](()=>{_0x556ba7||_0xfe016f(this['currentUser']);}),typeof _0x14edef=='function'){const _0x1afe28=_0xf5ad27['addObserver'](_0x14edef,_0x4c8683,_0x4a38c5);return()=>{_0x556ba7=!0x0,_0x1afe28();};}else{const _0x2e2485=_0xf5ad27['addObserver'](_0x14edef);return()=>{_0x556ba7=!0x0,_0x2e2485();};}}async['directlySetCurrentUser'](_0x38dd12){this['currentUser']&&this['currentUser']!==_0x38dd12&&this['_currentUser']['_stopProactiveRefresh'](),_0x38dd12&&this['isProactiveRefreshEnabled']&&_0x38dd12['_startProactiveRefresh'](),this['currentUser']=_0x38dd12,_0x38dd12?await this['assertedPersistence']['setCurrentUser'](_0x38dd12):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x4e5397){return this['operations']=this['operations']['then'](_0x4e5397,_0x4e5397),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x3ebdf3){!_0x3ebdf3||this['frameworks']['includes'](_0x3ebdf3)||(this['frameworks']['push'](_0x3ebdf3),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x15a204;const _0x56730e={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x56730e['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x754f26=await((_0x15a204=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x15a204['getHeartbeatsHeader']());_0x754f26&&(_0x56730e['X-Firebase-Client']=_0x754f26);const _0xe384bb=await this['_getAppCheckToken']();return _0xe384bb&&(_0x56730e['X-Firebase-AppCheck']=_0xe384bb),_0x56730e;}async['_getAppCheckToken'](){var _0x28a79c;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x4ca7c5=await((_0x28a79c=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x28a79c['getToken']());return _0x4ca7c5!=null&&_0x4ca7c5['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x4ca7c5['error']),_0x4ca7c5==null?void 0x0:_0x4ca7c5['token'];}}function Ke(_0x185745){return P(_0x185745);}class Rr{constructor(_0x4b27c7){this['auth']=_0x4b27c7,this['observer']=null,this['addObserver']=Tc(_0x3d28e9=>this['observer']=_0x3d28e9);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x47cb2d){Jn=_0x47cb2d;}function xa(_0x393bbd){return Jn['loadJS'](_0x393bbd);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x1a2d02){return'__'+_0x1a2d02+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x1a0c35){_0x1a0c35();}['execute'](_0x39c8e5,_0x1754f1){return Promise['resolve']('token');}['render'](_0x36186f,_0x24d511){return'';}}class Wf{['ready'](_0x1906d2){_0x1906d2();}['execute'](_0x38462a,_0x2d4ef7){return Promise['resolve']('token');}['render'](_0x532cb9,_0xd7cebd){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x3a258b){this['type']=Bf,this['auth']=Ke(_0x3a258b);}async['verify'](_0x48ccbc='verify',_0x161a5b=!0x1){async function _0x3c40b6(_0x2bd53c){if(!_0x161a5b){if(_0x2bd53c['tenantId']==null&&_0x2bd53c['_agentRecaptchaConfig']!=null)return _0x2bd53c['_agentRecaptchaConfig']['siteKey'];if(_0x2bd53c['tenantId']!=null&&_0x2bd53c['_tenantRecaptchaConfigs'][_0x2bd53c['tenantId']]!==void 0x0)return _0x2bd53c['_tenantRecaptchaConfigs'][_0x2bd53c['tenantId']]['siteKey'];}return new Promise(async(_0x508add,_0x16732b)=>{yf(_0x2bd53c,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x4454d0=>{if(_0x4454d0['recaptchaKey']===void 0x0)_0x16732b(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x2ed8ac=new mf(_0x4454d0);return _0x2bd53c['tenantId']==null?_0x2bd53c['_agentRecaptchaConfig']=_0x2ed8ac:_0x2bd53c['_tenantRecaptchaConfigs'][_0x2bd53c['tenantId']]=_0x2ed8ac,_0x508add(_0x2ed8ac['siteKey']);}})['catch'](_0x18edb6=>{_0x16732b(_0x18edb6);});});}function _0x13e5fd(_0x4b3796,_0x2c49b3,_0xabfa80){const _0x11ef8e=window['grecaptcha'];wr(_0x11ef8e)?_0x11ef8e['enterprise']['ready'](()=>{_0x11ef8e['enterprise']['execute'](_0x4b3796,{'action':_0x48ccbc})['then'](_0x519369=>{_0x2c49b3(_0x519369);})['catch'](()=>{_0x2c49b3(Fa);});}):_0xabfa80(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x360f8d,_0x5ab04d)=>{_0x3c40b6(this['auth'])['then'](async _0x56353d=>{if(!_0x161a5b&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x13e5fd(_0x56353d,_0x360f8d,_0x5ab04d);else{if(typeof window>'u'){_0x5ab04d(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0xb8c41=Lf();_0xb8c41['length']!==0x0&&(_0xb8c41+=_0x56353d+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x5922bc;(_0x5922bc=he['scriptInjectionDeferred'])==null||_0x5922bc['resolve']();},xa(_0xb8c41)['then'](()=>{var _0x2dd572;return(_0x2dd572=he['scriptInjectionDeferred'])==null?void 0x0:_0x2dd572['promise'];})['then'](()=>{_0x13e5fd(_0x56353d,_0x360f8d,_0x5ab04d);})['catch'](_0x32d2b3=>{_0x5ab04d(_0x32d2b3);});}})['catch'](_0x1ccd9c=>{_0x5ab04d(_0x1ccd9c);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x516b51,_0x4c76b0,_0x7ef130,_0x6a24aa=!0x1,_0x1b3845=!0x1){const _0x560f91=new he(_0x516b51);let _0x24f0e4;if(_0x1b3845)_0x24f0e4=Fa;else try{_0x24f0e4=await _0x560f91['verify'](_0x7ef130);}catch{_0x24f0e4=await _0x560f91['verify'](_0x7ef130,!0x0);}const _0x5ef630={..._0x4c76b0};if(_0x7ef130==='mfaSmsEnrollment'||_0x7ef130==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x5ef630){const _0x4c7fd2=_0x5ef630['phoneEnrollmentInfo']['phoneNumber'],_0x32c661=_0x5ef630['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x5ef630,{'phoneEnrollmentInfo':{'phoneNumber':_0x4c7fd2,'recaptchaToken':_0x32c661,'captchaResponse':_0x24f0e4,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x5ef630){const _0x261364=_0x5ef630['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x5ef630,{'phoneSignInInfo':{'recaptchaToken':_0x261364,'captchaResponse':_0x24f0e4,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x5ef630;}return _0x6a24aa?Object['assign'](_0x5ef630,{'captchaResp':_0x24f0e4}):Object['assign'](_0x5ef630,{'captchaResponse':_0x24f0e4}),Object['assign'](_0x5ef630,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x5ef630,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x5ef630;}async function xi(_0x115f99,_0x702650,_0x55d77d,_0x327738,_0x52a6bd){var _0x4971a5;if((_0x4971a5=_0x115f99['_getRecaptchaConfig']())!=null&&_0x4971a5['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x49233a=await kr(_0x115f99,_0x702650,_0x55d77d,_0x55d77d==='getOobCode');return _0x327738(_0x115f99,_0x49233a);}else return _0x327738(_0x115f99,_0x702650)['catch'](async _0x5add0c=>{if(_0x5add0c['code']==='auth/missing-recaptcha-token'){console['log'](_0x55d77d+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x56a887=await kr(_0x115f99,_0x702650,_0x55d77d,_0x55d77d==='getOobCode');return _0x327738(_0x115f99,_0x56a887);}else return Promise['reject'](_0x5add0c);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x2f605d,_0x4e571f){const _0x40d400=Hi(_0x2f605d,'auth');if(_0x40d400['isInitialized']()){const _0x19bdc3=_0x40d400['getImmediate'](),_0x574222=_0x40d400['getOptions']();if(xe(_0x574222,_0x4e571f??{}))return _0x19bdc3;Y(_0x19bdc3,'already-initialized');}return _0x40d400['initialize']({'options':_0x4e571f});}function Hf(_0x38632a,_0x10d4d3){const _0x397dca=(_0x10d4d3==null?void 0x0:_0x10d4d3['persistence'])||[],_0x37b6f4=(Array['isArray'](_0x397dca)?_0x397dca:[_0x397dca])['map'](ie);_0x10d4d3!=null&&_0x10d4d3['errorMap']&&_0x38632a['_updateErrorMap'](_0x10d4d3['errorMap']),_0x38632a['_initializeWithPersistence'](_0x37b6f4,_0x10d4d3==null?void 0x0:_0x10d4d3['popupRedirectResolver']);}function $f(_0x20c0d4,_0x102e81,_0x3b1d5d){const _0x125030=Ke(_0x20c0d4);m(/^https?:\/\//['test'](_0x102e81),_0x125030,'invalid-emulator-scheme');const _0x57f8f8=!0x1,_0x51f529=Ua(_0x102e81),{host:_0x177aaa,port:_0x38125a}=Gf(_0x102e81),_0x2e2c52=_0x38125a===null?'':':'+_0x38125a,_0x4fb60e={'url':_0x51f529+'//'+_0x177aaa+_0x2e2c52+'/'},_0xcdf16d=Object['freeze']({'host':_0x177aaa,'port':_0x38125a,'protocol':_0x51f529['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x57f8f8})});if(!_0x125030['_canInitEmulator']){m(_0x125030['config']['emulator']&&_0x125030['emulatorConfig'],_0x125030,'emulator-config-failed'),m(xe(_0x4fb60e,_0x125030['config']['emulator'])&&xe(_0xcdf16d,_0x125030['emulatorConfig']),_0x125030,'emulator-config-failed');return;}_0x125030['config']['emulator']=_0x4fb60e,_0x125030['emulatorConfig']=_0xcdf16d,_0x125030['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x177aaa)?Qr(_0x51f529+'//'+_0x177aaa+_0x2e2c52):qf();}function Ua(_0xe795f7){const _0x413498=_0xe795f7['indexOf'](':');return _0x413498<0x0?'':_0xe795f7['substr'](0x0,_0x413498+0x1);}function Gf(_0x392395){const _0xd7bdc5=Ua(_0x392395),_0x2b9458=/(\/\/)?([^?#/]+)/['exec'](_0x392395['substr'](_0xd7bdc5['length']));if(!_0x2b9458)return{'host':'','port':null};const _0x456720=_0x2b9458[0x2]['split']('@')['pop']()||'',_0xe830b4=/^(\[[^\]]+\])(:|$)/['exec'](_0x456720);if(_0xe830b4){const _0x3ff163=_0xe830b4[0x1];return{'host':_0x3ff163,'port':Pr(_0x456720['substr'](_0x3ff163['length']+0x1))};}else{const [_0x429dac,_0x33bb94]=_0x456720['split'](':');return{'host':_0x429dac,'port':Pr(_0x33bb94)};}}function Pr(_0x5895c){if(!_0x5895c)return null;const _0xc4a7ac=Number(_0x5895c);return isNaN(_0xc4a7ac)?null:_0xc4a7ac;}function qf(){function _0x1dbf4f(){const _0x5523fc=document['createElement']('p'),_0x326a92=_0x5523fc['style'];_0x5523fc['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x326a92['position']='fixed',_0x326a92['width']='100%',_0x326a92['backgroundColor']='#ffffff',_0x326a92['border']='.1em\x20solid\x20#000000',_0x326a92['color']='#b50000',_0x326a92['bottom']='0px',_0x326a92['left']='0px',_0x326a92['margin']='0px',_0x326a92['zIndex']='10000',_0x326a92['textAlign']='center',_0x5523fc['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x5523fc);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x1dbf4f):_0x1dbf4f());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x175387,_0x17346a){this['providerId']=_0x175387,this['signInMethod']=_0x17346a;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x44aafb){return ne('not\x20implemented');}['_linkToIdToken'](_0x29f27d,_0x33f701){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x272f05){return ne('not\x20implemented');}}async function zf(_0x1f84b7,_0x27deb6){return Pe(_0x1f84b7,'POST','/v1/accounts:signUp',_0x27deb6);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x33150a,_0x52a43d){return en(_0x33150a,'POST','/v1/accounts:signInWithPassword',ke(_0x33150a,_0x52a43d));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x39c62b,_0x142ecc){return en(_0x39c62b,'POST','/v1/accounts:signInWithEmailLink',ke(_0x39c62b,_0x142ecc));}async function Yf(_0x57e160,_0x2e4018){return en(_0x57e160,'POST','/v1/accounts:signInWithEmailLink',ke(_0x57e160,_0x2e4018));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x14d81c,_0x4a8579,_0x23dc38,_0xbd40ec=null){super('password',_0x23dc38),this['_email']=_0x14d81c,this['_password']=_0x4a8579,this['_tenantId']=_0xbd40ec;}static['_fromEmailAndPassword'](_0x277df3,_0x9db6ef){return new $t(_0x277df3,_0x9db6ef,'password');}static['_fromEmailAndCode'](_0x136054,_0x39bc33,_0x6e7ed0=null){return new $t(_0x136054,_0x39bc33,'emailLink',_0x6e7ed0);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x54138f){const _0x94d195=typeof _0x54138f=='string'?JSON['parse'](_0x54138f):_0x54138f;if(_0x94d195!=null&&_0x94d195['email']&&(_0x94d195!=null&&_0x94d195['password'])){if(_0x94d195['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x94d195['email'],_0x94d195['password']);if(_0x94d195['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x94d195['email'],_0x94d195['password'],_0x94d195['tenantId']);}return null;}async['_getIdTokenResponse'](_0x59ce2e){switch(this['signInMethod']){case'password':const _0x5c4230={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x59ce2e,_0x5c4230,'signInWithPassword',jf);case'emailLink':return Kf(_0x59ce2e,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x59ce2e,'internal-error');}}async['_linkToIdToken'](_0x2b6d63,_0x2cfa1f){switch(this['signInMethod']){case'password':const _0x53da1d={'idToken':_0x2cfa1f,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x2b6d63,_0x53da1d,'signUpPassword',zf);case'emailLink':return Yf(_0x2b6d63,{'idToken':_0x2cfa1f,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x2b6d63,'internal-error');}}['_getReauthenticationResolver'](_0xcf9056){return this['_getIdTokenResponse'](_0xcf9056);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x584627,_0x1af6c0){return en(_0x584627,'POST','/v1/accounts:signInWithIdp',ke(_0x584627,_0x1af6c0));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x37c5ae){const _0x1505a1=new $e(_0x37c5ae['providerId'],_0x37c5ae['signInMethod']);return _0x37c5ae['idToken']||_0x37c5ae['accessToken']?(_0x37c5ae['idToken']&&(_0x1505a1['idToken']=_0x37c5ae['idToken']),_0x37c5ae['accessToken']&&(_0x1505a1['accessToken']=_0x37c5ae['accessToken']),_0x37c5ae['nonce']&&!_0x37c5ae['pendingToken']&&(_0x1505a1['nonce']=_0x37c5ae['nonce']),_0x37c5ae['pendingToken']&&(_0x1505a1['pendingToken']=_0x37c5ae['pendingToken'])):_0x37c5ae['oauthToken']&&_0x37c5ae['oauthTokenSecret']?(_0x1505a1['accessToken']=_0x37c5ae['oauthToken'],_0x1505a1['secret']=_0x37c5ae['oauthTokenSecret']):Y('argument-error'),_0x1505a1;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x1e86d7){const _0x4500dd=typeof _0x1e86d7=='string'?JSON['parse'](_0x1e86d7):_0x1e86d7,{providerId:_0x460bd5,signInMethod:_0x230eab,..._0x2b97de}=_0x4500dd;if(!_0x460bd5||!_0x230eab)return null;const _0x2350ca=new $e(_0x460bd5,_0x230eab);return _0x2350ca['idToken']=_0x2b97de['idToken']||void 0x0,_0x2350ca['accessToken']=_0x2b97de['accessToken']||void 0x0,_0x2350ca['secret']=_0x2b97de['secret'],_0x2350ca['nonce']=_0x2b97de['nonce'],_0x2350ca['pendingToken']=_0x2b97de['pendingToken']||null,_0x2350ca;}['_getIdTokenResponse'](_0xa3ea){const _0x506bd7=this['buildRequest']();return nt(_0xa3ea,_0x506bd7);}['_linkToIdToken'](_0x3ca131,_0x14db27){const _0x58bbc7=this['buildRequest']();return _0x58bbc7['idToken']=_0x14db27,nt(_0x3ca131,_0x58bbc7);}['_getReauthenticationResolver'](_0x579e26){const _0x424517=this['buildRequest']();return _0x424517['autoCreate']=!0x1,nt(_0x579e26,_0x424517);}['buildRequest'](){const _0x2154c4={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x2154c4['pendingToken']=this['pendingToken'];else{const _0x3b7836={};this['idToken']&&(_0x3b7836['id_token']=this['idToken']),this['accessToken']&&(_0x3b7836['access_token']=this['accessToken']),this['secret']&&(_0x3b7836['oauth_token_secret']=this['secret']),_0x3b7836['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x3b7836['nonce']=this['nonce']),_0x2154c4['postBody']=ut(_0x3b7836);}return _0x2154c4;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x57bac3){switch(_0x57bac3){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x24b3b6){const _0x52099b=Ct(Tt(_0x24b3b6))['link'],_0x39ee33=_0x52099b?Ct(Tt(_0x52099b))['deep_link_id']:null,_0x1a8f16=Ct(Tt(_0x24b3b6))['deep_link_id'];return(_0x1a8f16?Ct(Tt(_0x1a8f16))['link']:null)||_0x1a8f16||_0x39ee33||_0x52099b||_0x24b3b6;}class Rs{constructor(_0x488430){const _0x3241c7=Ct(Tt(_0x488430)),_0x2e563f=_0x3241c7['apiKey']??null,_0x3fc9a9=_0x3241c7['oobCode']??null,_0x48780a=Jf(_0x3241c7['mode']??null);m(_0x2e563f&&_0x3fc9a9&&_0x48780a,'argument-error'),this['apiKey']=_0x2e563f,this['operation']=_0x48780a,this['code']=_0x3fc9a9,this['continueUrl']=_0x3241c7['continueUrl']??null,this['languageCode']=_0x3241c7['lang']??null,this['tenantId']=_0x3241c7['tenantId']??null;}static['parseLink'](_0x5e6c7e){const _0x50ee43=Xf(_0x5e6c7e);try{return new Rs(_0x50ee43);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x2dddaf,_0x4eed52){return $t['_fromEmailAndPassword'](_0x2dddaf,_0x4eed52);}static['credentialWithLink'](_0x28558e,_0x30b52e){const _0x329330=Rs['parseLink'](_0x30b52e);return m(_0x329330,'argument-error'),$t['_fromEmailAndCode'](_0x28558e,_0x329330['code'],_0x329330['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x293d5a){this['providerId']=_0x293d5a,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x31f5d){this['defaultLanguageCode']=_0x31f5d;}['setCustomParameters'](_0x4f6203){return this['customParameters']=_0x4f6203,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x705903){return this['scopes']['includes'](_0x705903)||this['scopes']['push'](_0x705903),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x2d64c3){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x2d64c3});}static['credentialFromResult'](_0x5624bf){return ue['credentialFromTaggedObject'](_0x5624bf);}static['credentialFromError'](_0x1b5f55){return ue['credentialFromTaggedObject'](_0x1b5f55['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x38db6f}){if(!_0x38db6f||!('oauthAccessToken'in _0x38db6f)||!_0x38db6f['oauthAccessToken'])return null;try{return ue['credential'](_0x38db6f['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x545591,_0x3ba10d){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x545591,'accessToken':_0x3ba10d});}static['credentialFromResult'](_0x95f7a7){return de['credentialFromTaggedObject'](_0x95f7a7);}static['credentialFromError'](_0x46fc08){return de['credentialFromTaggedObject'](_0x46fc08['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4eb035}){if(!_0x4eb035)return null;const {oauthIdToken:_0x38af2c,oauthAccessToken:_0x3c796a}=_0x4eb035;if(!_0x38af2c&&!_0x3c796a)return null;try{return de['credential'](_0x38af2c,_0x3c796a);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x3e73f8){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x3e73f8});}static['credentialFromResult'](_0x581410){return fe['credentialFromTaggedObject'](_0x581410);}static['credentialFromError'](_0x41b328){return fe['credentialFromTaggedObject'](_0x41b328['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5f4e69}){if(!_0x5f4e69||!('oauthAccessToken'in _0x5f4e69)||!_0x5f4e69['oauthAccessToken'])return null;try{return fe['credential'](_0x5f4e69['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x4800ec,_0x4770a5){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x4800ec,'oauthTokenSecret':_0x4770a5});}static['credentialFromResult'](_0x3c50aa){return pe['credentialFromTaggedObject'](_0x3c50aa);}static['credentialFromError'](_0x33222f){return pe['credentialFromTaggedObject'](_0x33222f['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x7313f8}){if(!_0x7313f8)return null;const {oauthAccessToken:_0x455981,oauthTokenSecret:_0x6b7f8a}=_0x7313f8;if(!_0x455981||!_0x6b7f8a)return null;try{return pe['credential'](_0x455981,_0x6b7f8a);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x76bba,_0xfe57e9){return en(_0x76bba,'POST','/v1/accounts:signUp',ke(_0x76bba,_0xfe57e9));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x5e38e2){this['user']=_0x5e38e2['user'],this['providerId']=_0x5e38e2['providerId'],this['_tokenResponse']=_0x5e38e2['_tokenResponse'],this['operationType']=_0x5e38e2['operationType'];}static async['_fromIdTokenResponse'](_0x9c9ac8,_0x14c090,_0x598eae,_0x17535d=!0x1){const _0x3bf090=await j['_fromIdTokenResponse'](_0x9c9ac8,_0x598eae,_0x17535d),_0xdca5ae=Nr(_0x598eae);return new Ge({'user':_0x3bf090,'providerId':_0xdca5ae,'_tokenResponse':_0x598eae,'operationType':_0x14c090});}static async['_forOperation'](_0x7a36f3,_0x158f96,_0x4b273c){await _0x7a36f3['_updateTokensIfNecessary'](_0x4b273c,!0x0);const _0x5df2b6=Nr(_0x4b273c);return new Ge({'user':_0x7a36f3,'providerId':_0x5df2b6,'_tokenResponse':_0x4b273c,'operationType':_0x158f96});}}function Nr(_0x571969){return _0x571969['providerId']?_0x571969['providerId']:'phoneNumber'in _0x571969?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x5483a6,_0x358680,_0x569123,_0x39af42){super(_0x358680['code'],_0x358680['message']),this['operationType']=_0x569123,this['user']=_0x39af42,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x5483a6['name'],'tenantId':_0x5483a6['tenantId']??void 0x0,'_serverResponse':_0x358680['customData']['_serverResponse'],'operationType':_0x569123};}static['_fromErrorAndOperation'](_0x40ac2c,_0x4d2b57,_0x2f08a4,_0x5b6b99){return new On(_0x40ac2c,_0x4d2b57,_0x2f08a4,_0x5b6b99);}}function Ba(_0x55b023,_0x22f513,_0x67126d,_0x45d908){return(_0x22f513==='reauthenticate'?_0x67126d['_getReauthenticationResolver'](_0x55b023):_0x67126d['_getIdTokenResponse'](_0x55b023))['catch'](_0x3cab6c=>{throw _0x3cab6c['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x55b023,_0x3cab6c,_0x22f513,_0x45d908):_0x3cab6c;});}async function ep(_0x5546c4,_0x46d95b,_0x49cb00=!0x1){const _0x42f5f2=await Ht(_0x5546c4,_0x46d95b['_linkToIdToken'](_0x5546c4['auth'],await _0x5546c4['getIdToken']()),_0x49cb00);return Ge['_forOperation'](_0x5546c4,'link',_0x42f5f2);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x38b794,_0x44fa50,_0x236348=!0x1){const {auth:_0x293b80}=_0x38b794;if($(_0x293b80['app']))return Promise['reject'](re(_0x293b80));const _0x138a48='reauthenticate';try{const _0x3167d2=await Ht(_0x38b794,Ba(_0x293b80,_0x138a48,_0x44fa50,_0x38b794),_0x236348);m(_0x3167d2['idToken'],_0x293b80,'internal-error');const _0x506cb4=Ts(_0x3167d2['idToken']);m(_0x506cb4,_0x293b80,'internal-error');const {sub:_0x14ca28}=_0x506cb4;return m(_0x38b794['uid']===_0x14ca28,_0x293b80,'user-mismatch'),Ge['_forOperation'](_0x38b794,_0x138a48,_0x3167d2);}catch(_0x28bd76){throw(_0x28bd76==null?void 0x0:_0x28bd76['code'])==='auth/user-not-found'&&Y(_0x293b80,'user-mismatch'),_0x28bd76;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x3e119f,_0x460c7f,_0x3c95cf=!0x1){if($(_0x3e119f['app']))return Promise['reject'](re(_0x3e119f));const _0x126f3='signIn',_0x23753b=await Ba(_0x3e119f,_0x126f3,_0x460c7f),_0x3749f0=await Ge['_fromIdTokenResponse'](_0x3e119f,_0x126f3,_0x23753b);return _0x3c95cf||await _0x3e119f['_updateCurrentUser'](_0x3749f0['user']),_0x3749f0;}async function np(_0x3c5e87,_0x104a3f){return Va(Ke(_0x3c5e87),_0x104a3f);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x44c377){const _0x17b6f3=Ke(_0x44c377);_0x17b6f3['_getPasswordPolicyInternal']()&&await _0x17b6f3['_updatePasswordPolicy']();}async function L_(_0x4dcc8f,_0x2286c8,_0x3c3295){if($(_0x4dcc8f['app']))return Promise['reject'](re(_0x4dcc8f));const _0xa1ae33=Ke(_0x4dcc8f),_0x596040=await xi(_0xa1ae33,{'returnSecureToken':!0x0,'email':_0x2286c8,'password':_0x3c3295,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x141f08=>{throw _0x141f08['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x4dcc8f),_0x141f08;}),_0x599ead=await Ge['_fromIdTokenResponse'](_0xa1ae33,'signIn',_0x596040);return await _0xa1ae33['_updateCurrentUser'](_0x599ead['user']),_0x599ead;}function x_(_0x308bdc,_0xcba135,_0x2776c0){return $(_0x308bdc['app'])?Promise['reject'](re(_0x308bdc)):np(P(_0x308bdc),yt['credential'](_0xcba135,_0x2776c0))['catch'](async _0x45be7f=>{throw _0x45be7f['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x308bdc),_0x45be7f;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x619a7,_0x34852c){return P(_0x619a7)['setPersistence'](_0x34852c);}function ip(_0x58666f,_0x8fd758,_0x14ef8d,_0x5ee94d){return P(_0x58666f)['onIdTokenChanged'](_0x8fd758,_0x14ef8d,_0x5ee94d);}function sp(_0x49dbcf,_0x44fc24,_0x4ded61){return P(_0x49dbcf)['beforeAuthStateChanged'](_0x44fc24,_0x4ded61);}function U_(_0x1fb2c4,_0x22691e,_0x1c3fc6,_0x34aa1f){return P(_0x1fb2c4)['onAuthStateChanged'](_0x22691e,_0x1c3fc6,_0x34aa1f);}function W_(_0x13fe81){return P(_0x13fe81)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x43ba0d,_0xd6cac9){this['storageRetriever']=_0x43ba0d,this['type']=_0xd6cac9;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x1e570d,_0x1da411){return this['storage']['setItem'](_0x1e570d,JSON['stringify'](_0x1da411)),Promise['resolve']();}['_get'](_0x18e234){const _0x4fa68b=this['storage']['getItem'](_0x18e234);return Promise['resolve'](_0x4fa68b?JSON['parse'](_0x4fa68b):null);}['_remove'](_0x1a1010){return this['storage']['removeItem'](_0x1a1010),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x398bd5,_0x2e157a)=>this['onStorageEvent'](_0x398bd5,_0x2e157a),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x406205){for(const _0x361128 of Object['keys'](this['listeners'])){const _0x4ac11d=this['storage']['getItem'](_0x361128),_0x13577c=this['localCache'][_0x361128];_0x4ac11d!==_0x13577c&&_0x406205(_0x361128,_0x13577c,_0x4ac11d);}}['onStorageEvent'](_0x5ca9ac,_0x228ab4=!0x1){if(!_0x5ca9ac['key']){this['forAllChangedKeys']((_0x32a2e6,_0x118dd4,_0x5ea5f5)=>{this['notifyListeners'](_0x32a2e6,_0x5ea5f5);});return;}const _0x45fc0a=_0x5ca9ac['key'];_0x228ab4?this['detachListener']():this['stopPolling']();const _0xa2bde9=()=>{const _0x346d5a=this['storage']['getItem'](_0x45fc0a);!_0x228ab4&&this['localCache'][_0x45fc0a]===_0x346d5a||this['notifyListeners'](_0x45fc0a,_0x346d5a);},_0x27059c=this['storage']['getItem'](_0x45fc0a);Af()&&_0x27059c!==_0x5ca9ac['newValue']&&_0x5ca9ac['newValue']!==_0x5ca9ac['oldValue']?setTimeout(_0xa2bde9,op):_0xa2bde9();}['notifyListeners'](_0x2f0b59,_0x20a011){this['localCache'][_0x2f0b59]=_0x20a011;const _0x156cea=this['listeners'][_0x2f0b59];if(_0x156cea){for(const _0x1c0ba9 of Array['from'](_0x156cea))_0x1c0ba9(_0x20a011&&JSON['parse'](_0x20a011));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x1a31a9,_0x404f13,_0x2a25cd)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x1a31a9,'oldValue':_0x404f13,'newValue':_0x2a25cd}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x334536,_0x183293){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x334536]||(this['listeners'][_0x334536]=new Set(),this['localCache'][_0x334536]=this['storage']['getItem'](_0x334536)),this['listeners'][_0x334536]['add'](_0x183293);}['_removeListener'](_0x264571,_0x26353c){this['listeners'][_0x264571]&&(this['listeners'][_0x264571]['delete'](_0x26353c),this['listeners'][_0x264571]['size']===0x0&&delete this['listeners'][_0x264571]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x542666,_0x25c57e){await super['_set'](_0x542666,_0x25c57e),this['localCache'][_0x542666]=JSON['stringify'](_0x25c57e);}async['_get'](_0x4fabc9){const _0x58c0fe=await super['_get'](_0x4fabc9);return this['localCache'][_0x4fabc9]=JSON['stringify'](_0x58c0fe),_0x58c0fe;}async['_remove'](_0x30f705){await super['_remove'](_0x30f705),delete this['localCache'][_0x30f705];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x3b51ee,_0x44a147){}['_removeListener'](_0x4c6aa9,_0x452df6){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x35e4f4){return Promise['all'](_0x35e4f4['map'](async _0x53527f=>{try{return{'fulfilled':!0x0,'value':await _0x53527f};}catch(_0x154696){return{'fulfilled':!0x1,'reason':_0x154696};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x365f04){this['eventTarget']=_0x365f04,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x588f94){const _0x2f6406=this['receivers']['find'](_0x1ba037=>_0x1ba037['isListeningto'](_0x588f94));if(_0x2f6406)return _0x2f6406;const _0x23a353=new Xn(_0x588f94);return this['receivers']['push'](_0x23a353),_0x23a353;}['isListeningto'](_0x2aa3d6){return this['eventTarget']===_0x2aa3d6;}async['handleEvent'](_0x18fafd){const _0x166cbb=_0x18fafd,{eventId:_0xa299cf,eventType:_0x455ef7,data:_0x3bcbc9}=_0x166cbb['data'],_0x24812a=this['handlersMap'][_0x455ef7];if(!(_0x24812a!=null&&_0x24812a['size']))return;_0x166cbb['ports'][0x0]['postMessage']({'status':'ack','eventId':_0xa299cf,'eventType':_0x455ef7});const _0x4dd84d=Array['from'](_0x24812a)['map'](async _0x8bbab0=>_0x8bbab0(_0x166cbb['origin'],_0x3bcbc9)),_0x190e80=await cp(_0x4dd84d);_0x166cbb['ports'][0x0]['postMessage']({'status':'done','eventId':_0xa299cf,'eventType':_0x455ef7,'response':_0x190e80});}['_subscribe'](_0x207cc0,_0x5021ef){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x207cc0]||(this['handlersMap'][_0x207cc0]=new Set()),this['handlersMap'][_0x207cc0]['add'](_0x5021ef);}['_unsubscribe'](_0xb6432d,_0xfdf61e){this['handlersMap'][_0xb6432d]&&_0xfdf61e&&this['handlersMap'][_0xb6432d]['delete'](_0xfdf61e),(!_0xfdf61e||this['handlersMap'][_0xb6432d]['size']===0x0)&&delete this['handlersMap'][_0xb6432d],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x5a089c='',_0x5d840b=0xa){let _0x585076='';for(let _0x7726ed=0x0;_0x7726ed<_0x5d840b;_0x7726ed++)_0x585076+=Math['floor'](Math['random']()*0xa);return _0x5a089c+_0x585076;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x2480b3){this['target']=_0x2480b3,this['handlers']=new Set();}['removeMessageHandler'](_0x294aa3){_0x294aa3['messageChannel']&&(_0x294aa3['messageChannel']['port1']['removeEventListener']('message',_0x294aa3['onMessage']),_0x294aa3['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x294aa3);}async['_send'](_0x3aec5a,_0x5c7c66,_0x502893=0x32){const _0xa6919e=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0xa6919e)throw new Error('connection_unavailable');let _0x18db1f,_0x2b32cd;return new Promise((_0x4e58cb,_0x5adb1b)=>{const _0x573e8c=As('',0x14);_0xa6919e['port1']['start']();const _0x5a91e7=setTimeout(()=>{_0x5adb1b(new Error('unsupported_event'));},_0x502893);_0x2b32cd={'messageChannel':_0xa6919e,'onMessage'(_0x32f8f5){const _0x2f6de5=_0x32f8f5;if(_0x2f6de5['data']['eventId']===_0x573e8c)switch(_0x2f6de5['data']['status']){case'ack':clearTimeout(_0x5a91e7),_0x18db1f=setTimeout(()=>{_0x5adb1b(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x18db1f),_0x4e58cb(_0x2f6de5['data']['response']);break;default:clearTimeout(_0x5a91e7),clearTimeout(_0x18db1f),_0x5adb1b(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x2b32cd),_0xa6919e['port1']['addEventListener']('message',_0x2b32cd['onMessage']),this['target']['postMessage']({'eventType':_0x3aec5a,'eventId':_0x573e8c,'data':_0x5c7c66},[_0xa6919e['port2']]);})['finally'](()=>{_0x2b32cd&&this['removeMessageHandler'](_0x2b32cd);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x3beecc){Z()['location']['href']=_0x3beecc;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x2f4874;return((_0x2f4874=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x2f4874['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x39910b){this['request']=_0x39910b;}['toPromise'](){return new Promise((_0x478dc3,_0x128e06)=>{this['request']['addEventListener']('success',()=>{_0x478dc3(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x128e06(this['request']['error']);});});}}function Zn(_0x6e2790,_0x18715a){return _0x6e2790['transaction']([Mn],_0x18715a?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x512b17=indexedDB['deleteDatabase'](Ka);return new nn(_0x512b17)['toPromise']();}function Qa(){const _0x288935=indexedDB['open'](Ka,pp);return new Promise((_0x31234b,_0x3277a4)=>{_0x288935['addEventListener']('error',()=>{_0x3277a4(_0x288935['error']);}),_0x288935['addEventListener']('upgradeneeded',()=>{const _0x9631b=_0x288935['result'];try{_0x9631b['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x34e82f){_0x3277a4(_0x34e82f);}}),_0x288935['addEventListener']('success',async()=>{const _0xfebee9=_0x288935['result'];_0xfebee9['objectStoreNames']['contains'](Mn)?_0x31234b(_0xfebee9):(_0xfebee9['close'](),await _p(),_0x31234b(await Qa()));});});}async function Or(_0xc73e3a,_0x4b3749,_0x30118a){const _0xc537a0=Zn(_0xc73e3a,!0x0)['put']({[Ya]:_0x4b3749,'value':_0x30118a});return new nn(_0xc537a0)['toPromise']();}async function gp(_0x4a188a,_0x1abfda){const _0x263d9d=Zn(_0x4a188a,!0x1)['get'](_0x1abfda),_0x331ed1=await new nn(_0x263d9d)['toPromise']();return _0x331ed1===void 0x0?null:_0x331ed1['value'];}function Dr(_0x1b45fe,_0x1a7b1d){const _0x4f040e=Zn(_0x1b45fe,!0x0)['delete'](_0x1a7b1d);return new nn(_0x4f040e)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x2997db){let _0xdf3b12=0x0;for(;;)try{const _0x4e6f45=await this['_openDb']();return await _0x2997db(_0x4e6f45);}catch(_0x31642c){if(_0xdf3b12++>yp)throw _0x31642c;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x4652f6,_0x5d7c36)=>({'keyProcessed':(await this['_poll']())['includes'](_0x5d7c36['key'])})),this['receiver']['_subscribe']('ping',async(_0x4fe154,_0x20dbc1)=>['keyChanged']);}async['initializeSender'](){var _0x231cb5,_0xc250e4;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x76920=await this['sender']['_send']('ping',{},0x320);_0x76920&&(_0x231cb5=_0x76920[0x0])!=null&&_0x231cb5['fulfilled']&&(_0xc250e4=_0x76920[0x0])!=null&&_0xc250e4['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x863981){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x863981},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x5b2d0b=>{await Or(_0x5b2d0b,Dn,'1'),await Dr(_0x5b2d0b,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x51d1e1){this['pendingWrites']++;try{await _0x51d1e1();}finally{this['pendingWrites']--;}}async['_set'](_0x5e6d4f,_0x58e6b8){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x4ea087=>Or(_0x4ea087,_0x5e6d4f,_0x58e6b8)),this['localCache'][_0x5e6d4f]=_0x58e6b8,this['notifyServiceWorker'](_0x5e6d4f)));}async['_get'](_0x4268de){const _0x4a4c7c=await this['_withRetries'](_0x1dae9a=>gp(_0x1dae9a,_0x4268de));return this['localCache'][_0x4268de]=_0x4a4c7c,_0x4a4c7c;}async['_remove'](_0xdecd2b){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x11ecd5=>Dr(_0x11ecd5,_0xdecd2b)),delete this['localCache'][_0xdecd2b],this['notifyServiceWorker'](_0xdecd2b)));}async['_poll'](){const _0x35893b=await this['_withRetries'](_0x277a35=>{const _0x28e99f=Zn(_0x277a35,!0x1)['getAll']();return new nn(_0x28e99f)['toPromise']();});if(!_0x35893b)return[];if(this['pendingWrites']!==0x0)return[];const _0x1432c7=[],_0x333350=new Set();if(_0x35893b['length']!==0x0){for(const {fbase_key:_0x2af501,value:_0x1fb34f}of _0x35893b)_0x333350['add'](_0x2af501),JSON['stringify'](this['localCache'][_0x2af501])!==JSON['stringify'](_0x1fb34f)&&(this['notifyListeners'](_0x2af501,_0x1fb34f),_0x1432c7['push'](_0x2af501));}for(const _0x1c2b09 of Object['keys'](this['localCache']))this['localCache'][_0x1c2b09]&&!_0x333350['has'](_0x1c2b09)&&(this['notifyListeners'](_0x1c2b09,null),_0x1432c7['push'](_0x1c2b09));return _0x1432c7;}['notifyListeners'](_0x5ad0ce,_0x296f90){this['localCache'][_0x5ad0ce]=_0x296f90;const _0x289ebe=this['listeners'][_0x5ad0ce];if(_0x289ebe){for(const _0x53e403 of Array['from'](_0x289ebe))_0x53e403(_0x296f90);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x40285e,_0x5695ba){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x40285e]||(this['listeners'][_0x40285e]=new Set(),this['_get'](_0x40285e)),this['listeners'][_0x40285e]['add'](_0x5695ba);}['_removeListener'](_0xe4bcce,_0x34d2bb){this['listeners'][_0xe4bcce]&&(this['listeners'][_0xe4bcce]['delete'](_0x34d2bb),this['listeners'][_0xe4bcce]['size']===0x0&&delete this['listeners'][_0xe4bcce]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x5aec7d,_0x53e629){return _0x53e629?ie(_0x53e629):(m(_0x5aec7d['_popupRedirectResolver'],_0x5aec7d,'argument-error'),_0x5aec7d['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x566b2c){super('custom','custom'),this['params']=_0x566b2c;}['_getIdTokenResponse'](_0x1a472a){return nt(_0x1a472a,this['_buildIdpRequest']());}['_linkToIdToken'](_0x375915,_0x450efe){return nt(_0x375915,this['_buildIdpRequest'](_0x450efe));}['_getReauthenticationResolver'](_0x57aa69){return nt(_0x57aa69,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x371336){const _0x31628d={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x371336&&(_0x31628d['idToken']=_0x371336),_0x31628d;}}function Ip(_0x3a087f){return Va(_0x3a087f['auth'],new ks(_0x3a087f),_0x3a087f['bypassAuthState']);}function wp(_0x4e87b2){const {auth:_0x2eb705,user:_0x1bb377}=_0x4e87b2;return m(_0x1bb377,_0x2eb705,'internal-error'),tp(_0x1bb377,new ks(_0x4e87b2),_0x4e87b2['bypassAuthState']);}async function Cp(_0xb21a5e){const {auth:_0x4b4fad,user:_0x14bb4}=_0xb21a5e;return m(_0x14bb4,_0x4b4fad,'internal-error'),ep(_0x14bb4,new ks(_0xb21a5e),_0xb21a5e['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x4e6c9d,_0x1b3bef,_0x1efa4b,_0x222d17,_0x366d44=!0x1){this['auth']=_0x4e6c9d,this['resolver']=_0x1efa4b,this['user']=_0x222d17,this['bypassAuthState']=_0x366d44,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x1b3bef)?_0x1b3bef:[_0x1b3bef];}['execute'](){return new Promise(async(_0x1cf803,_0x3e40a4)=>{this['pendingPromise']={'resolve':_0x1cf803,'reject':_0x3e40a4};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x3f7fa5){this['reject'](_0x3f7fa5);}});}async['onAuthEvent'](_0x2abb12){const {urlResponse:_0x195d32,sessionId:_0x238c2c,postBody:_0x29ef19,tenantId:_0x1adb4e,error:_0x2ccb06,type:_0x5b0fef}=_0x2abb12;if(_0x2ccb06){this['reject'](_0x2ccb06);return;}const _0x3bb80c={'auth':this['auth'],'requestUri':_0x195d32,'sessionId':_0x238c2c,'tenantId':_0x1adb4e||void 0x0,'postBody':_0x29ef19||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x5b0fef)(_0x3bb80c));}catch(_0x5e3c9c){this['reject'](_0x5e3c9c);}}['onError'](_0x2818e9){this['reject'](_0x2818e9);}['getIdpTask'](_0x2a0625){switch(_0x2a0625){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x3e35a3){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x3e35a3),this['unregisterAndCleanUp']();}['reject'](_0x28c7cc){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x28c7cc),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x2f0938,_0x3c8b27,_0x331572,_0x11c23c,_0x187536){super(_0x2f0938,_0x3c8b27,_0x11c23c,_0x187536),this['provider']=_0x331572,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x13c6b4=await this['execute']();return m(_0x13c6b4,this['auth'],'internal-error'),_0x13c6b4;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x22eaed=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x22eaed),this['authWindow']['associatedEvent']=_0x22eaed,this['resolver']['_originValidation'](this['auth'])['catch'](_0x3e2b7d=>{this['reject'](_0x3e2b7d);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x2bdc48=>{_0x2bdc48||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x3f500a;return((_0x3f500a=this['authWindow'])==null?void 0x0:_0x3f500a['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x100f50=()=>{var _0x144601,_0x1d18a8;if((_0x1d18a8=(_0x144601=this['authWindow'])==null?void 0x0:_0x144601['window'])!=null&&_0x1d18a8['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x100f50,Tp['get']());};_0x100f50();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x42080f,_0x4f7664,_0x2310da=!0x1){super(_0x42080f,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x4f7664,void 0x0,_0x2310da),this['eventId']=null;}async['execute'](){let _0x28e8c5=hn['get'](this['auth']['_key']());if(!_0x28e8c5){try{const _0x57db03=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x28e8c5=()=>Promise['resolve'](_0x57db03);}catch(_0x4c4ee0){_0x28e8c5=()=>Promise['reject'](_0x4c4ee0);}hn['set'](this['auth']['_key'](),_0x28e8c5);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x28e8c5();}async['onAuthEvent'](_0x234892){if(_0x234892['type']==='signInViaRedirect')return super['onAuthEvent'](_0x234892);if(_0x234892['type']==='unknown'){this['resolve'](null);return;}if(_0x234892['eventId']){const _0x3fa842=await this['auth']['_redirectUserForId'](_0x234892['eventId']);if(_0x3fa842)return this['user']=_0x3fa842,super['onAuthEvent'](_0x234892);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x59dc8b,_0x4f6210){const _0x3d972a=Pp(_0x4f6210),_0xdb16e0=kp(_0x59dc8b);if(!await _0xdb16e0['_isAvailable']())return!0x1;const _0x237194=await _0xdb16e0['_get'](_0x3d972a)==='true';return await _0xdb16e0['_remove'](_0x3d972a),_0x237194;}function Ap(_0x129682,_0x6ce2f0){hn['set'](_0x129682['_key'](),_0x6ce2f0);}function kp(_0x59e8a4){return ie(_0x59e8a4['_redirectPersistence']);}function Pp(_0x1be4d9){return ln(Sp,_0x1be4d9['config']['apiKey'],_0x1be4d9['name']);}async function Np(_0x373b8c,_0x2d88df,_0x2684fd=!0x1){if($(_0x373b8c['app']))return Promise['reject'](re(_0x373b8c));const _0x1a4c8d=Ke(_0x373b8c),_0xcdabe=Ep(_0x1a4c8d,_0x2d88df),_0x3d6c69=await new bp(_0x1a4c8d,_0xcdabe,_0x2684fd)['execute']();return _0x3d6c69&&!_0x2684fd&&(delete _0x3d6c69['user']['_redirectEventId'],await _0x1a4c8d['_persistUserIfCurrent'](_0x3d6c69['user']),await _0x1a4c8d['_setRedirectUser'](null,_0x2d88df)),_0x3d6c69;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x18431b){this['auth']=_0x18431b,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x2b1e08){this['consumers']['add'](_0x2b1e08),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x2b1e08)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x2b1e08),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x6e6eb2){this['consumers']['delete'](_0x6e6eb2);}['onEvent'](_0x2d0e00){if(this['hasEventBeenHandled'](_0x2d0e00))return!0x1;let _0x335164=!0x1;return this['consumers']['forEach'](_0x4f7570=>{this['isEventForConsumer'](_0x2d0e00,_0x4f7570)&&(_0x335164=!0x0,this['sendToConsumer'](_0x2d0e00,_0x4f7570),this['saveEventToCache'](_0x2d0e00));}),this['hasHandledPotentialRedirect']||!Mp(_0x2d0e00)||(this['hasHandledPotentialRedirect']=!0x0,_0x335164||(this['queuedRedirectEvent']=_0x2d0e00,_0x335164=!0x0)),_0x335164;}['sendToConsumer'](_0x1d679c,_0x1ea1c4){var _0x2bc454;if(_0x1d679c['error']&&!Za(_0x1d679c)){const _0x5ed941=((_0x2bc454=_0x1d679c['error']['code'])==null?void 0x0:_0x2bc454['split']('auth/')[0x1])||'internal-error';_0x1ea1c4['onError'](X(this['auth'],_0x5ed941));}else _0x1ea1c4['onAuthEvent'](_0x1d679c);}['isEventForConsumer'](_0x7c9356,_0x4b4647){const _0x1c27b6=_0x4b4647['eventId']===null||!!_0x7c9356['eventId']&&_0x7c9356['eventId']===_0x4b4647['eventId'];return _0x4b4647['filter']['includes'](_0x7c9356['type'])&&_0x1c27b6;}['hasEventBeenHandled'](_0xf1180b){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0xf1180b));}['saveEventToCache'](_0x3b8e19){this['cachedEventUids']['add'](Mr(_0x3b8e19)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x1def09){return[_0x1def09['type'],_0x1def09['eventId'],_0x1def09['sessionId'],_0x1def09['tenantId']]['filter'](_0x304f31=>_0x304f31)['join']('-');}function Za({type:_0x2a2181,error:_0x1800dd}){return _0x2a2181==='unknown'&&(_0x1800dd==null?void 0x0:_0x1800dd['code'])==='auth/no-auth-event';}function Mp(_0x5b8645){switch(_0x5b8645['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x5b8645);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x463c30,_0x29e443={}){return Pe(_0x463c30,'GET','/v1/projects',_0x29e443);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x4df865){if(_0x4df865['config']['emulator'])return;const {authorizedDomains:_0xfd02b5}=await Lp(_0x4df865);for(const _0x1ad037 of _0xfd02b5)try{if(Wp(_0x1ad037))return;}catch{}Y(_0x4df865,'unauthorized-domain');}function Wp(_0x21c9a5){const _0x473ba1=Mi(),{protocol:_0x7192e,hostname:_0xaa17f5}=new URL(_0x473ba1);if(_0x21c9a5['startsWith']('chrome-extension://')){const _0x522a2a=new URL(_0x21c9a5);return _0x522a2a['hostname']===''&&_0xaa17f5===''?_0x7192e==='chrome-extension:'&&_0x21c9a5['replace']('chrome-extension://','')===_0x473ba1['replace']('chrome-extension://',''):_0x7192e==='chrome-extension:'&&_0x522a2a['hostname']===_0xaa17f5;}if(!Fp['test'](_0x7192e))return!0x1;if(xp['test'](_0x21c9a5))return _0xaa17f5===_0x21c9a5;const _0x3a013c=_0x21c9a5['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x3a013c+'|'+_0x3a013c+')$','i')['test'](_0xaa17f5);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x582dfa=Z()['___jsl'];if(_0x582dfa!=null&&_0x582dfa['H']){for(const _0x546a8b of Object['keys'](_0x582dfa['H']))if(_0x582dfa['H'][_0x546a8b]['r']=_0x582dfa['H'][_0x546a8b]['r']||[],_0x582dfa['H'][_0x546a8b]['L']=_0x582dfa['H'][_0x546a8b]['L']||[],_0x582dfa['H'][_0x546a8b]['r']=[..._0x582dfa['H'][_0x546a8b]['L']],_0x582dfa['CP']){for(let _0x5c5424=0x0;_0x5c5424<_0x582dfa['CP']['length'];_0x5c5424++)_0x582dfa['CP'][_0x5c5424]=null;}}}function Vp(_0x59ca46){return new Promise((_0x1d040a,_0x1cd7cd)=>{var _0x193b72,_0x4c40a8,_0x5028fa;function _0x1bf62e(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x1d040a(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x1cd7cd(X(_0x59ca46,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x4c40a8=(_0x193b72=Z()['gapi'])==null?void 0x0:_0x193b72['iframes'])!=null&&_0x4c40a8['Iframe'])_0x1d040a(gapi['iframes']['getContext']());else{if((_0x5028fa=Z()['gapi'])!=null&&_0x5028fa['load'])_0x1bf62e();else{const _0x5144f9=Ff('iframefcb');return Z()[_0x5144f9]=()=>{gapi['load']?_0x1bf62e():_0x1cd7cd(X(_0x59ca46,'network-request-failed'));},xa(xf()+'?onload='+_0x5144f9)['catch'](_0x518e56=>_0x1cd7cd(_0x518e56));}}})['catch'](_0x357e5a=>{throw un=null,_0x357e5a;});}let un=null;function Hp(_0x491de1){return un=un||Vp(_0x491de1),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x5f36f7){const _0x4ba9df=_0x5f36f7['config'];m(_0x4ba9df['authDomain'],_0x5f36f7,'auth-domain-config-required');const _0x119ef1=_0x4ba9df['emulator']?Cs(_0x4ba9df,qp):'https://'+_0x5f36f7['config']['authDomain']+'/'+Gp,_0x31c133={'apiKey':_0x4ba9df['apiKey'],'appName':_0x5f36f7['name'],'v':dt},_0x28893e=jp['get'](_0x5f36f7['config']['apiHost']);_0x28893e&&(_0x31c133['eid']=_0x28893e);const _0x4872ae=_0x5f36f7['_getFrameworks']();return _0x4872ae['length']&&(_0x31c133['fw']=_0x4872ae['join'](',')),_0x119ef1+'?'+ut(_0x31c133)['slice'](0x1);}async function Yp(_0x1d266b){const _0x5c1179=await Hp(_0x1d266b),_0x4a7d88=Z()['gapi'];return m(_0x4a7d88,_0x1d266b,'internal-error'),_0x5c1179['open']({'where':document['body'],'url':Kp(_0x1d266b),'messageHandlersFilter':_0x4a7d88['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x5b47ce=>new Promise(async(_0x3d8f0b,_0x5af004)=>{await _0x5b47ce['restyle']({'setHideOnLeave':!0x1});const _0xce9e62=X(_0x1d266b,'network-request-failed'),_0x2068ee=Z()['setTimeout'](()=>{_0x5af004(_0xce9e62);},$p['get']());function _0xab1fb2(){Z()['clearTimeout'](_0x2068ee),_0x3d8f0b(_0x5b47ce);}_0x5b47ce['ping'](_0xab1fb2)['then'](_0xab1fb2,()=>{_0x5af004(_0xce9e62);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x57ea38){this['window']=_0x57ea38,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x154157,_0x3bb57a,_0x2e0ff7,_0x52a2e1=Jp,_0x1d5c52=Xp){const _0x3698b7=Math['max']((window['screen']['availHeight']-_0x1d5c52)/0x2,0x0)['toString'](),_0x29d500=Math['max']((window['screen']['availWidth']-_0x52a2e1)/0x2,0x0)['toString']();let _0x499966='';const _0x500588={...Qp,'width':_0x52a2e1['toString'](),'height':_0x1d5c52['toString'](),'top':_0x3698b7,'left':_0x29d500},_0x1e512b=W()['toLowerCase']();_0x2e0ff7&&(_0x499966=ka(_0x1e512b)?Zp:_0x2e0ff7),Ra(_0x1e512b)&&(_0x3bb57a=_0x3bb57a||e_,_0x500588['scrollbars']='yes');const _0x14a2f6=Object['entries'](_0x500588)['reduce']((_0x55e61,[_0x20aaad,_0x3352c6])=>''+_0x55e61+_0x20aaad+'='+_0x3352c6+',','');if(Rf(_0x1e512b)&&_0x499966!=='_self')return n_(_0x3bb57a||'',_0x499966),new xr(null);const _0x20aa6d=window['open'](_0x3bb57a||'',_0x499966,_0x14a2f6);m(_0x20aa6d,_0x154157,'popup-blocked');try{_0x20aa6d['focus']();}catch{}return new xr(_0x20aa6d);}function n_(_0xb93455,_0x15e4b5){const _0x68bf59=document['createElement']('a');_0x68bf59['href']=_0xb93455,_0x68bf59['target']=_0x15e4b5;const _0x488e53=document['createEvent']('MouseEvent');_0x488e53['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x68bf59['dispatchEvent'](_0x488e53);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x31753f,_0x288c2b,_0x398098,_0x581461,_0x38b170,_0x212695){m(_0x31753f['config']['authDomain'],_0x31753f,'auth-domain-config-required'),m(_0x31753f['config']['apiKey'],_0x31753f,'invalid-api-key');const _0x1d8ecb={'apiKey':_0x31753f['config']['apiKey'],'appName':_0x31753f['name'],'authType':_0x398098,'redirectUrl':_0x581461,'v':dt,'eventId':_0x38b170};if(_0x288c2b instanceof Wa){_0x288c2b['setDefaultLanguage'](_0x31753f['languageCode']),_0x1d8ecb['providerId']=_0x288c2b['providerId']||'',pn(_0x288c2b['getCustomParameters']())||(_0x1d8ecb['customParameters']=JSON['stringify'](_0x288c2b['getCustomParameters']()));for(const [_0x1290da,_0xc9d773]of Object['entries']({}))_0x1d8ecb[_0x1290da]=_0xc9d773;}if(_0x288c2b instanceof tn){const _0x26c4f0=_0x288c2b['getScopes']()['filter'](_0x405222=>_0x405222!=='');_0x26c4f0['length']>0x0&&(_0x1d8ecb['scopes']=_0x26c4f0['join'](','));}_0x31753f['tenantId']&&(_0x1d8ecb['tid']=_0x31753f['tenantId']);const _0x49f55e=_0x1d8ecb;for(const _0x3de6ac of Object['keys'](_0x49f55e))_0x49f55e[_0x3de6ac]===void 0x0&&delete _0x49f55e[_0x3de6ac];const _0x53a69a=await _0x31753f['_getAppCheckToken'](),_0x474922=_0x53a69a?'#'+r_+'='+encodeURIComponent(_0x53a69a):'';return o_(_0x31753f)+'?'+ut(_0x49f55e)['slice'](0x1)+_0x474922;}function o_({config:_0x2f8c20}){return _0x2f8c20['emulator']?Cs(_0x2f8c20,s_):'https://'+_0x2f8c20['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x284ff9,_0x3a5088,_0x2f70f9,_0x48835a){var _0x2546a2;ce((_0x2546a2=this['eventManagers'][_0x284ff9['_key']()])==null?void 0x0:_0x2546a2['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x362456=await Fr(_0x284ff9,_0x3a5088,_0x2f70f9,Mi(),_0x48835a);return t_(_0x284ff9,_0x362456,As());}async['_openRedirect'](_0x2efd66,_0x4e1916,_0x2b6d3f,_0xaa19d6){await this['_originValidation'](_0x2efd66);const _0x3bccea=await Fr(_0x2efd66,_0x4e1916,_0x2b6d3f,Mi(),_0xaa19d6);return hp(_0x3bccea),new Promise(()=>{});}['_initialize'](_0x5b49f1){const _0x3fb7d9=_0x5b49f1['_key']();if(this['eventManagers'][_0x3fb7d9]){const {manager:_0x4fc3e1,promise:_0x1af8ae}=this['eventManagers'][_0x3fb7d9];return _0x4fc3e1?Promise['resolve'](_0x4fc3e1):(ce(_0x1af8ae,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x1af8ae);}const _0x45a8a2=this['initAndGetManager'](_0x5b49f1);return this['eventManagers'][_0x3fb7d9]={'promise':_0x45a8a2},_0x45a8a2['catch'](()=>{delete this['eventManagers'][_0x3fb7d9];}),_0x45a8a2;}async['initAndGetManager'](_0x25f3c8){const _0x32b51a=await Yp(_0x25f3c8),_0x264b50=new Dp(_0x25f3c8);return _0x32b51a['register']('authEvent',_0x4dc1fd=>(m(_0x4dc1fd==null?void 0x0:_0x4dc1fd['authEvent'],_0x25f3c8,'invalid-auth-event'),{'status':_0x264b50['onEvent'](_0x4dc1fd['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x25f3c8['_key']()]={'manager':_0x264b50},this['iframes'][_0x25f3c8['_key']()]=_0x32b51a,_0x264b50;}['_isIframeWebStorageSupported'](_0x6e8c20,_0x43c473){this['iframes'][_0x6e8c20['_key']()]['send'](pi,{'type':pi},_0x5ccf60=>{var _0x3e8c8f;const _0x509d38=(_0x3e8c8f=_0x5ccf60==null?void 0x0:_0x5ccf60[0x0])==null?void 0x0:_0x3e8c8f[pi];_0x509d38!==void 0x0&&_0x43c473(!!_0x509d38),Y(_0x6e8c20,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x2fb5f9){const _0xb31ea6=_0x2fb5f9['_key']();return this['originValidationPromises'][_0xb31ea6]||(this['originValidationPromises'][_0xb31ea6]=Up(_0x2fb5f9)),this['originValidationPromises'][_0xb31ea6];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x4a2b5d){this['auth']=_0x4a2b5d,this['internalListeners']=new Map();}['getUid'](){var _0x3a812e;return this['assertAuthConfigured'](),((_0x3a812e=this['auth']['currentUser'])==null?void 0x0:_0x3a812e['uid'])||null;}async['getToken'](_0x2a23fa){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x2a23fa)}:null;}['addAuthTokenListener'](_0x3bf883){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x3bf883))return;const _0x36c470=this['auth']['onIdTokenChanged'](_0x16013e=>{_0x3bf883((_0x16013e==null?void 0x0:_0x16013e['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x3bf883,_0x36c470),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x382d41){this['assertAuthConfigured']();const _0x21ff78=this['internalListeners']['get'](_0x382d41);_0x21ff78&&(this['internalListeners']['delete'](_0x382d41),_0x21ff78(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x8fdc59){switch(_0x8fdc59){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0xceefc6){st(new Fe('auth',(_0x189f1e,{options:_0x2bc0ca})=>{const _0x5e2d1e=_0x189f1e['getProvider']('app')['getImmediate'](),_0x579b2e=_0x189f1e['getProvider']('heartbeat'),_0x4efa69=_0x189f1e['getProvider']('app-check-internal'),{apiKey:_0x387c19,authDomain:_0x2924aa}=_0x5e2d1e['options'];m(_0x387c19&&!_0x387c19['includes'](':'),'invalid-api-key',{'appName':_0x5e2d1e['name']});const _0x256772={'apiKey':_0x387c19,'authDomain':_0x2924aa,'clientPlatform':_0xceefc6,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0xceefc6)},_0x1bb62f=new Df(_0x5e2d1e,_0x579b2e,_0x4efa69,_0x256772);return Hf(_0x1bb62f,_0x2bc0ca),_0x1bb62f;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0xf01e42,_0x254c9d,_0x254096)=>{_0xf01e42['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x1463c9=>{const _0xd6c102=Ke(_0x1463c9['getProvider']('auth')['getImmediate']());return(_0x3616c4=>new l_(_0x3616c4))(_0xd6c102);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0xceefc6)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x3d88aa=>async _0xc89a5e=>{const _0xa9f7c1=_0xc89a5e&&await _0xc89a5e['getIdTokenResult'](),_0x45847a=_0xa9f7c1&&(new Date()['getTime']()-Date['parse'](_0xa9f7c1['issuedAtTime']))/0x3e8;if(_0x45847a&&_0x45847a>f_)return;const _0x592191=_0xa9f7c1==null?void 0x0:_0xa9f7c1['token'];Br!==_0x592191&&(Br=_0x592191,await fetch(_0x3d88aa,{'method':_0x592191?'POST':'DELETE','headers':_0x592191?{'Authorization':'Bearer\x20'+_0x592191}:{}}));};function B_(_0x390bce=Zr()){const _0x28cc0f=Hi(_0x390bce,'auth');if(_0x28cc0f['isInitialized']())return _0x28cc0f['getImmediate']();const _0x4fc94a=Vf(_0x390bce,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x53b618=jr('authTokenSyncURL');if(_0x53b618&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x5066c9=new URL(_0x53b618,location['origin']);if(location['origin']===_0x5066c9['origin']){const _0x5b5eb0=p_(_0x5066c9['toString']());sp(_0x4fc94a,_0x5b5eb0,()=>_0x5b5eb0(_0x4fc94a['currentUser'])),ip(_0x4fc94a,_0x1ead42=>_0x5b5eb0(_0x1ead42));}}const _0x3c6f29=qr('auth');return _0x3c6f29&&$f(_0x4fc94a,'http://'+_0x3c6f29),_0x4fc94a;}function __(){var _0x26d3d3;return((_0x26d3d3=document['getElementsByTagName']('head'))==null?void 0x0:_0x26d3d3[0x0])??document;}Mf({'loadJS'(_0x3f42d0){return new Promise((_0xc40d4c,_0x194bac)=>{const _0x3c8f4d=document['createElement']('script');_0x3c8f4d['setAttribute']('src',_0x3f42d0),_0x3c8f4d['onload']=_0xc40d4c,_0x3c8f4d['onerror']=_0x450f41=>{const _0xc97f2d=X('internal-error');_0xc97f2d['customData']=_0x450f41,_0x194bac(_0xc97f2d);},_0x3c8f4d['type']='text/javascript',_0x3c8f4d['charset']='UTF-8',__()['appendChild'](_0x3c8f4d);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,B_ as a,ap as b,x_ as c,g_ as d,m_ as e,Zr as f,P_ as g,v_ as h,Sl as i,Hd as j,D_ as k,w_ as l,b_ as m,A_ as n,Gd as o,E_ as p,k_ as q,y_ as r,F_ as s,Vt as t,I_ as u,N_ as v,U_ as w,O_ as x,M_ as y,T_ as z};