import{c as a17_0x1a41a5}from'./index-Bx9hrRqI.js';/**
 * @license lucide-react v0.556.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const e=[['path',{'d':'M15.2\x203a2\x202\x200\x200\x201\x201.4.6l3.8\x203.8a2\x202\x200\x200\x201\x20.6\x201.4V19a2\x202\x200\x200\x201-2\x202H5a2\x202\x200\x200\x201-2-2V5a2\x202\x200\x200\x201\x202-2z','key':'1c8476'}],['path',{'d':'M17\x2021v-7a1\x201\x200\x200\x200-1-1H8a1\x201\x200\x200\x200-1\x201v7','key':'1ydtos'}],['path',{'d':'M7\x203v4a1\x201\x200\x200\x200\x201\x201h7','key':'t51u73'}]],o=a17_0x1a41a5('save',e);export{o as S};