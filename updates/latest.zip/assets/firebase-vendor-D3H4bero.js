const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x12dc9f,_0x27ed37){if(!_0x12dc9f)throw ht(_0x27ed37);},ht=function(_0x20d079){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x20d079);},Hr=function(_0x5b2b14){const _0x2da3de=[];let _0x2d9417=0x0;for(let _0x4b8ab8=0x0;_0x4b8ab8<_0x5b2b14['length'];_0x4b8ab8++){let _0x2dd8b5=_0x5b2b14['charCodeAt'](_0x4b8ab8);_0x2dd8b5<0x80?_0x2da3de[_0x2d9417++]=_0x2dd8b5:_0x2dd8b5<0x800?(_0x2da3de[_0x2d9417++]=_0x2dd8b5>>0x6|0xc0,_0x2da3de[_0x2d9417++]=_0x2dd8b5&0x3f|0x80):(_0x2dd8b5&0xfc00)===0xd800&&_0x4b8ab8+0x1<_0x5b2b14['length']&&(_0x5b2b14['charCodeAt'](_0x4b8ab8+0x1)&0xfc00)===0xdc00?(_0x2dd8b5=0x10000+((_0x2dd8b5&0x3ff)<<0xa)+(_0x5b2b14['charCodeAt'](++_0x4b8ab8)&0x3ff),_0x2da3de[_0x2d9417++]=_0x2dd8b5>>0x12|0xf0,_0x2da3de[_0x2d9417++]=_0x2dd8b5>>0xc&0x3f|0x80,_0x2da3de[_0x2d9417++]=_0x2dd8b5>>0x6&0x3f|0x80,_0x2da3de[_0x2d9417++]=_0x2dd8b5&0x3f|0x80):(_0x2da3de[_0x2d9417++]=_0x2dd8b5>>0xc|0xe0,_0x2da3de[_0x2d9417++]=_0x2dd8b5>>0x6&0x3f|0x80,_0x2da3de[_0x2d9417++]=_0x2dd8b5&0x3f|0x80);}return _0x2da3de;},nc=function(_0x512695){const _0x35fa1f=[];let _0x372d8c=0x0,_0x156ef0=0x0;for(;_0x372d8c<_0x512695['length'];){const _0x2c9a8b=_0x512695[_0x372d8c++];if(_0x2c9a8b<0x80)_0x35fa1f[_0x156ef0++]=String['fromCharCode'](_0x2c9a8b);else{if(_0x2c9a8b>0xbf&&_0x2c9a8b<0xe0){const _0x361cd6=_0x512695[_0x372d8c++];_0x35fa1f[_0x156ef0++]=String['fromCharCode']((_0x2c9a8b&0x1f)<<0x6|_0x361cd6&0x3f);}else{if(_0x2c9a8b>0xef&&_0x2c9a8b<0x16d){const _0x5108ac=_0x512695[_0x372d8c++],_0x49035b=_0x512695[_0x372d8c++],_0xf63e3e=_0x512695[_0x372d8c++],_0x59835a=((_0x2c9a8b&0x7)<<0x12|(_0x5108ac&0x3f)<<0xc|(_0x49035b&0x3f)<<0x6|_0xf63e3e&0x3f)-0x10000;_0x35fa1f[_0x156ef0++]=String['fromCharCode'](0xd800+(_0x59835a>>0xa)),_0x35fa1f[_0x156ef0++]=String['fromCharCode'](0xdc00+(_0x59835a&0x3ff));}else{const _0x19ec19=_0x512695[_0x372d8c++],_0x58ae87=_0x512695[_0x372d8c++];_0x35fa1f[_0x156ef0++]=String['fromCharCode']((_0x2c9a8b&0xf)<<0xc|(_0x19ec19&0x3f)<<0x6|_0x58ae87&0x3f);}}}}return _0x35fa1f['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0xf8f33e,_0x5a70db){if(!Array['isArray'](_0xf8f33e))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x2238f4=_0x5a70db?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x539613=[];for(let _0x534512=0x0;_0x534512<_0xf8f33e['length'];_0x534512+=0x3){const _0x3b011e=_0xf8f33e[_0x534512],_0x30fc61=_0x534512+0x1<_0xf8f33e['length'],_0x3c3138=_0x30fc61?_0xf8f33e[_0x534512+0x1]:0x0,_0x4da769=_0x534512+0x2<_0xf8f33e['length'],_0x4a2a11=_0x4da769?_0xf8f33e[_0x534512+0x2]:0x0,_0x450006=_0x3b011e>>0x2,_0x3b5970=(_0x3b011e&0x3)<<0x4|_0x3c3138>>0x4;let _0x21bc11=(_0x3c3138&0xf)<<0x2|_0x4a2a11>>0x6,_0x46efb6=_0x4a2a11&0x3f;_0x4da769||(_0x46efb6=0x40,_0x30fc61||(_0x21bc11=0x40)),_0x539613['push'](_0x2238f4[_0x450006],_0x2238f4[_0x3b5970],_0x2238f4[_0x21bc11],_0x2238f4[_0x46efb6]);}return _0x539613['join']('');},'encodeString'(_0x537ee5,_0x440750){return this['HAS_NATIVE_SUPPORT']&&!_0x440750?btoa(_0x537ee5):this['encodeByteArray'](Hr(_0x537ee5),_0x440750);},'decodeString'(_0x34ea96,_0x292ded){return this['HAS_NATIVE_SUPPORT']&&!_0x292ded?atob(_0x34ea96):nc(this['decodeStringToByteArray'](_0x34ea96,_0x292ded));},'decodeStringToByteArray'(_0x32ec71,_0x17020b){this['init_']();const _0x1802ae=_0x17020b?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x1ba7b8=[];for(let _0x54f4ed=0x0;_0x54f4ed<_0x32ec71['length'];){const _0x288896=_0x1802ae[_0x32ec71['charAt'](_0x54f4ed++)],_0x538730=_0x54f4ed<_0x32ec71['length']?_0x1802ae[_0x32ec71['charAt'](_0x54f4ed)]:0x0;++_0x54f4ed;const _0x48de06=_0x54f4ed<_0x32ec71['length']?_0x1802ae[_0x32ec71['charAt'](_0x54f4ed)]:0x40;++_0x54f4ed;const _0x5d164c=_0x54f4ed<_0x32ec71['length']?_0x1802ae[_0x32ec71['charAt'](_0x54f4ed)]:0x40;if(++_0x54f4ed,_0x288896==null||_0x538730==null||_0x48de06==null||_0x5d164c==null)throw new ic();const _0x1c1c44=_0x288896<<0x2|_0x538730>>0x4;if(_0x1ba7b8['push'](_0x1c1c44),_0x48de06!==0x40){const _0x59233a=_0x538730<<0x4&0xf0|_0x48de06>>0x2;if(_0x1ba7b8['push'](_0x59233a),_0x5d164c!==0x40){const _0x1a0be=_0x48de06<<0x6&0xc0|_0x5d164c;_0x1ba7b8['push'](_0x1a0be);}}}return _0x1ba7b8;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x14fb8c=0x0;_0x14fb8c<this['ENCODED_VALS']['length'];_0x14fb8c++)this['byteToCharMap_'][_0x14fb8c]=this['ENCODED_VALS']['charAt'](_0x14fb8c),this['charToByteMap_'][this['byteToCharMap_'][_0x14fb8c]]=_0x14fb8c,this['byteToCharMapWebSafe_'][_0x14fb8c]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x14fb8c),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x14fb8c]]=_0x14fb8c,_0x14fb8c>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x14fb8c)]=_0x14fb8c,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x14fb8c)]=_0x14fb8c);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x31157c){const _0x1fe263=Hr(_0x31157c);return Fi['encodeByteArray'](_0x1fe263,!0x0);},dn=function(_0x23f7f3){return $r(_0x23f7f3)['replace'](/\./g,'');},fn=function(_0x475e2d){try{return Fi['decodeString'](_0x475e2d,!0x0);}catch(_0xeb4892){console['error']('base64Decode\x20failed:\x20',_0xeb4892);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x375d40){return Gr(void 0x0,_0x375d40);}function Gr(_0x1330ab,_0xf73fd5){if(!(_0xf73fd5 instanceof Object))return _0xf73fd5;switch(_0xf73fd5['constructor']){case Date:const _0x4b2514=_0xf73fd5;return new Date(_0x4b2514['getTime']());case Object:_0x1330ab===void 0x0&&(_0x1330ab={});break;case Array:_0x1330ab=[];break;default:return _0xf73fd5;}for(const _0x56346e in _0xf73fd5)!_0xf73fd5['hasOwnProperty'](_0x56346e)||!rc(_0x56346e)||(_0x1330ab[_0x56346e]=Gr(_0x1330ab[_0x56346e],_0xf73fd5[_0x56346e]));return _0x1330ab;}function rc(_0x52f8bb){return _0x52f8bb!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x5391f7=Ps['__FIREBASE_DEFAULTS__'];if(_0x5391f7)return JSON['parse'](_0x5391f7);},lc=()=>{if(typeof document>'u')return;let _0x50263c;try{_0x50263c=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0xc894d2=_0x50263c&&fn(_0x50263c[0x1]);return _0xc894d2&&JSON['parse'](_0xc894d2);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x24ee99){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x24ee99);return;}},qr=_0x2cbfd4=>{var _0x4f2387,_0x3c9972;return(_0x3c9972=(_0x4f2387=Ui())==null?void 0x0:_0x4f2387['emulatorHosts'])==null?void 0x0:_0x3c9972[_0x2cbfd4];},hc=_0x1e64b3=>{const _0x217a75=qr(_0x1e64b3);if(!_0x217a75)return;const _0x4e8760=_0x217a75['lastIndexOf'](':');if(_0x4e8760<=0x0||_0x4e8760+0x1===_0x217a75['length'])throw new Error('Invalid\x20host\x20'+_0x217a75+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x58a9eb=parseInt(_0x217a75['substring'](_0x4e8760+0x1),0xa);return _0x217a75[0x0]==='['?[_0x217a75['substring'](0x1,_0x4e8760-0x1),_0x58a9eb]:[_0x217a75['substring'](0x0,_0x4e8760),_0x58a9eb];},zr=()=>{var _0x5bbd65;return(_0x5bbd65=Ui())==null?void 0x0:_0x5bbd65['config'];},jr=_0x368d86=>{var _0x3249c0;return(_0x3249c0=Ui())==null?void 0x0:_0x3249c0['_'+_0x368d86];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x413d02,_0x5e665a)=>{this['resolve']=_0x413d02,this['reject']=_0x5e665a;});}['wrapCallback'](_0x3521a0){return(_0x162124,_0x2e0101)=>{_0x162124?this['reject'](_0x162124):this['resolve'](_0x2e0101),typeof _0x3521a0=='function'&&(this['promise']['catch'](()=>{}),_0x3521a0['length']===0x1?_0x3521a0(_0x162124):_0x3521a0(_0x162124,_0x2e0101));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x43f6de,_0x557768){if(_0x43f6de['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0xeed8b={'alg':'none','type':'JWT'},_0x5e27bf=_0x557768||'demo-project',_0x370fa7=_0x43f6de['iat']||0x0,_0x3a81a2=_0x43f6de['sub']||_0x43f6de['user_id'];if(!_0x3a81a2)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x164f5f={'iss':'https://securetoken.google.com/'+_0x5e27bf,'aud':_0x5e27bf,'iat':_0x370fa7,'exp':_0x370fa7+0xe10,'auth_time':_0x370fa7,'sub':_0x3a81a2,'user_id':_0x3a81a2,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x43f6de};return[dn(JSON['stringify'](_0xeed8b)),dn(JSON['stringify'](_0x164f5f)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x233c41=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x233c41=='object'&&_0x233c41['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0xc5d78d=W();return _0xc5d78d['indexOf']('MSIE\x20')>=0x0||_0xc5d78d['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x3ddd4b,_0x368f01)=>{try{let _0x26f03d=!0x0;const _0x149b7d='validate-browser-context-for-indexeddb-analytics-module',_0xdf018e=self['indexedDB']['open'](_0x149b7d);_0xdf018e['onsuccess']=()=>{_0xdf018e['result']['close'](),_0x26f03d||self['indexedDB']['deleteDatabase'](_0x149b7d),_0x3ddd4b(!0x0);},_0xdf018e['onupgradeneeded']=()=>{_0x26f03d=!0x1;},_0xdf018e['onerror']=()=>{var _0x35f33a;_0x368f01(((_0x35f33a=_0xdf018e['error'])==null?void 0x0:_0x35f33a['message'])||'');};}catch(_0x51169a){_0x368f01(_0x51169a);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x2e62ea,_0x3642c6,_0x2a53d6){super(_0x3642c6),this['code']=_0x2e62ea,this['customData']=_0x2a53d6,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x5abb4c,_0x287b8e,_0x1e259c){this['service']=_0x5abb4c,this['serviceName']=_0x287b8e,this['errors']=_0x1e259c;}['create'](_0x43d8ff,..._0x4b507d){const _0x8ffa3=_0x4b507d[0x0]||{},_0xeb888c=this['service']+'/'+_0x43d8ff,_0x573a5c=this['errors'][_0x43d8ff],_0x3b90da=_0x573a5c?vc(_0x573a5c,_0x8ffa3):'Error',_0x390865=this['serviceName']+':\x20'+_0x3b90da+'\x20('+_0xeb888c+').';return new Re(_0xeb888c,_0x390865,_0x8ffa3);}}function vc(_0x5c4f36,_0x48a38e){return _0x5c4f36['replace'](Ec,(_0x64d71d,_0x35d14f)=>{const _0x338d6d=_0x48a38e[_0x35d14f];return _0x338d6d!=null?String(_0x338d6d):'<'+_0x35d14f+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0xf120c5){return JSON['parse'](_0xf120c5);}function O(_0x51a8f0){return JSON['stringify'](_0x51a8f0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x1ca6db){let _0x4fdd0f={},_0x3ba358={},_0x279477={},_0x180816='';try{const _0x88aca8=_0x1ca6db['split']('.');_0x4fdd0f=Nt(fn(_0x88aca8[0x0])||''),_0x3ba358=Nt(fn(_0x88aca8[0x1])||''),_0x180816=_0x88aca8[0x2],_0x279477=_0x3ba358['d']||{},delete _0x3ba358['d'];}catch{}return{'header':_0x4fdd0f,'claims':_0x3ba358,'data':_0x279477,'signature':_0x180816};},Ic=function(_0x26099d){const _0xae817a=Yr(_0x26099d),_0x2ee8d7=_0xae817a['claims'];return!!_0x2ee8d7&&typeof _0x2ee8d7=='object'&&_0x2ee8d7['hasOwnProperty']('iat');},wc=function(_0x1c9c9b){const _0x304286=Yr(_0x1c9c9b)['claims'];return typeof _0x304286=='object'&&_0x304286['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x5be3de,_0x592017){return Object['prototype']['hasOwnProperty']['call'](_0x5be3de,_0x592017);}function Le(_0x831216,_0x2833bf){if(Object['prototype']['hasOwnProperty']['call'](_0x831216,_0x2833bf))return _0x831216[_0x2833bf];}function pn(_0xc14bb1){for(const _0x12036c in _0xc14bb1)if(Object['prototype']['hasOwnProperty']['call'](_0xc14bb1,_0x12036c))return!0x1;return!0x0;}function _n(_0x343195,_0x51f018,_0x4390db){const _0x114538={};for(const _0x3e6bae in _0x343195)Object['prototype']['hasOwnProperty']['call'](_0x343195,_0x3e6bae)&&(_0x114538[_0x3e6bae]=_0x51f018['call'](_0x4390db,_0x343195[_0x3e6bae],_0x3e6bae,_0x343195));return _0x114538;}function xe(_0x492fb7,_0x2569fe){if(_0x492fb7===_0x2569fe)return!0x0;const _0x1a4158=Object['keys'](_0x492fb7),_0x1ac456=Object['keys'](_0x2569fe);for(const _0x10ae62 of _0x1a4158){if(!_0x1ac456['includes'](_0x10ae62))return!0x1;const _0x4dc7b8=_0x492fb7[_0x10ae62],_0x1b42b5=_0x2569fe[_0x10ae62];if(Ns(_0x4dc7b8)&&Ns(_0x1b42b5)){if(!xe(_0x4dc7b8,_0x1b42b5))return!0x1;}else{if(_0x4dc7b8!==_0x1b42b5)return!0x1;}}for(const _0x1c90d2 of _0x1ac456)if(!_0x1a4158['includes'](_0x1c90d2))return!0x1;return!0x0;}function Ns(_0x2bdb5b){return _0x2bdb5b!==null&&typeof _0x2bdb5b=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x367d00){const _0x998d4=[];for(const [_0xead2e8,_0x219d71]of Object['entries'](_0x367d00))Array['isArray'](_0x219d71)?_0x219d71['forEach'](_0xc1b5ba=>{_0x998d4['push'](encodeURIComponent(_0xead2e8)+'='+encodeURIComponent(_0xc1b5ba));}):_0x998d4['push'](encodeURIComponent(_0xead2e8)+'='+encodeURIComponent(_0x219d71));return _0x998d4['length']?'&'+_0x998d4['join']('&'):'';}function Ct(_0x4a07af){const _0x1280d1={};return _0x4a07af['replace'](/^\?/,'')['split']('&')['forEach'](_0x577739=>{if(_0x577739){const [_0x20a1d5,_0x371e80]=_0x577739['split']('=');_0x1280d1[decodeURIComponent(_0x20a1d5)]=decodeURIComponent(_0x371e80);}}),_0x1280d1;}function Tt(_0x55b906){const _0x4caee9=_0x55b906['indexOf']('?');if(!_0x4caee9)return'';const _0x2d3cb9=_0x55b906['indexOf']('#',_0x4caee9);return _0x55b906['substring'](_0x4caee9,_0x2d3cb9>0x0?_0x2d3cb9:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x300623=0x1;_0x300623<this['blockSize'];++_0x300623)this['pad_'][_0x300623]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x2de138,_0x1f85e1){_0x1f85e1||(_0x1f85e1=0x0);const _0x548776=this['W_'];if(typeof _0x2de138=='string'){for(let _0x19cc97=0x0;_0x19cc97<0x10;_0x19cc97++)_0x548776[_0x19cc97]=_0x2de138['charCodeAt'](_0x1f85e1)<<0x18|_0x2de138['charCodeAt'](_0x1f85e1+0x1)<<0x10|_0x2de138['charCodeAt'](_0x1f85e1+0x2)<<0x8|_0x2de138['charCodeAt'](_0x1f85e1+0x3),_0x1f85e1+=0x4;}else{for(let _0x2efbd1=0x0;_0x2efbd1<0x10;_0x2efbd1++)_0x548776[_0x2efbd1]=_0x2de138[_0x1f85e1]<<0x18|_0x2de138[_0x1f85e1+0x1]<<0x10|_0x2de138[_0x1f85e1+0x2]<<0x8|_0x2de138[_0x1f85e1+0x3],_0x1f85e1+=0x4;}for(let _0x3556f2=0x10;_0x3556f2<0x50;_0x3556f2++){const _0x182a4b=_0x548776[_0x3556f2-0x3]^_0x548776[_0x3556f2-0x8]^_0x548776[_0x3556f2-0xe]^_0x548776[_0x3556f2-0x10];_0x548776[_0x3556f2]=(_0x182a4b<<0x1|_0x182a4b>>>0x1f)&0xffffffff;}let _0x4e86ba=this['chain_'][0x0],_0xcc2ee5=this['chain_'][0x1],_0x188184=this['chain_'][0x2],_0x22b597=this['chain_'][0x3],_0x2a963e=this['chain_'][0x4],_0x5982d5,_0xe027a5;for(let _0x19bb8a=0x0;_0x19bb8a<0x50;_0x19bb8a++){_0x19bb8a<0x28?_0x19bb8a<0x14?(_0x5982d5=_0x22b597^_0xcc2ee5&(_0x188184^_0x22b597),_0xe027a5=0x5a827999):(_0x5982d5=_0xcc2ee5^_0x188184^_0x22b597,_0xe027a5=0x6ed9eba1):_0x19bb8a<0x3c?(_0x5982d5=_0xcc2ee5&_0x188184|_0x22b597&(_0xcc2ee5|_0x188184),_0xe027a5=0x8f1bbcdc):(_0x5982d5=_0xcc2ee5^_0x188184^_0x22b597,_0xe027a5=0xca62c1d6);const _0x55ce15=(_0x4e86ba<<0x5|_0x4e86ba>>>0x1b)+_0x5982d5+_0x2a963e+_0xe027a5+_0x548776[_0x19bb8a]&0xffffffff;_0x2a963e=_0x22b597,_0x22b597=_0x188184,_0x188184=(_0xcc2ee5<<0x1e|_0xcc2ee5>>>0x2)&0xffffffff,_0xcc2ee5=_0x4e86ba,_0x4e86ba=_0x55ce15;}this['chain_'][0x0]=this['chain_'][0x0]+_0x4e86ba&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0xcc2ee5&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x188184&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x22b597&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x2a963e&0xffffffff;}['update'](_0xdba64a,_0x483863){if(_0xdba64a==null)return;_0x483863===void 0x0&&(_0x483863=_0xdba64a['length']);const _0x3677a8=_0x483863-this['blockSize'];let _0x5ae9ff=0x0;const _0x2ba020=this['buf_'];let _0x1841d8=this['inbuf_'];for(;_0x5ae9ff<_0x483863;){if(_0x1841d8===0x0){for(;_0x5ae9ff<=_0x3677a8;)this['compress_'](_0xdba64a,_0x5ae9ff),_0x5ae9ff+=this['blockSize'];}if(typeof _0xdba64a=='string'){for(;_0x5ae9ff<_0x483863;)if(_0x2ba020[_0x1841d8]=_0xdba64a['charCodeAt'](_0x5ae9ff),++_0x1841d8,++_0x5ae9ff,_0x1841d8===this['blockSize']){this['compress_'](_0x2ba020),_0x1841d8=0x0;break;}}else{for(;_0x5ae9ff<_0x483863;)if(_0x2ba020[_0x1841d8]=_0xdba64a[_0x5ae9ff],++_0x1841d8,++_0x5ae9ff,_0x1841d8===this['blockSize']){this['compress_'](_0x2ba020),_0x1841d8=0x0;break;}}}this['inbuf_']=_0x1841d8,this['total_']+=_0x483863;}['digest'](){const _0x31dbee=[];let _0x12f70a=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x7683c1=this['blockSize']-0x1;_0x7683c1>=0x38;_0x7683c1--)this['buf_'][_0x7683c1]=_0x12f70a&0xff,_0x12f70a/=0x100;this['compress_'](this['buf_']);let _0x1d3f3e=0x0;for(let _0x5c3f4e=0x0;_0x5c3f4e<0x5;_0x5c3f4e++)for(let _0x5df244=0x18;_0x5df244>=0x0;_0x5df244-=0x8)_0x31dbee[_0x1d3f3e]=this['chain_'][_0x5c3f4e]>>_0x5df244&0xff,++_0x1d3f3e;return _0x31dbee;}}function Tc(_0x1d877a,_0x5b5f5a){const _0x8797d1=new Sc(_0x1d877a,_0x5b5f5a);return _0x8797d1['subscribe']['bind'](_0x8797d1);}class Sc{constructor(_0x25fe42,_0x40098b){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x40098b,this['task']['then'](()=>{_0x25fe42(this);})['catch'](_0x3132b7=>{this['error'](_0x3132b7);});}['next'](_0x2d0582){this['forEachObserver'](_0x3ada29=>{_0x3ada29['next'](_0x2d0582);});}['error'](_0x51d4f1){this['forEachObserver'](_0x58af18=>{_0x58af18['error'](_0x51d4f1);}),this['close'](_0x51d4f1);}['complete'](){this['forEachObserver'](_0x14c592=>{_0x14c592['complete']();}),this['close']();}['subscribe'](_0xa379,_0x2d10d5,_0x1f8a6b){let _0x52a189;if(_0xa379===void 0x0&&_0x2d10d5===void 0x0&&_0x1f8a6b===void 0x0)throw new Error('Missing\x20Observer.');bc(_0xa379,['next','error','complete'])?_0x52a189=_0xa379:_0x52a189={'next':_0xa379,'error':_0x2d10d5,'complete':_0x1f8a6b},_0x52a189['next']===void 0x0&&(_0x52a189['next']=ti),_0x52a189['error']===void 0x0&&(_0x52a189['error']=ti),_0x52a189['complete']===void 0x0&&(_0x52a189['complete']=ti);const _0x3126b1=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x52a189['error'](this['finalError']):_0x52a189['complete']();}catch{}}),this['observers']['push'](_0x52a189),_0x3126b1;}['unsubscribeOne'](_0x4165e5){this['observers']===void 0x0||this['observers'][_0x4165e5]===void 0x0||(delete this['observers'][_0x4165e5],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x54c5dc){if(!this['finalized']){for(let _0x44d1a2=0x0;_0x44d1a2<this['observers']['length'];_0x44d1a2++)this['sendOne'](_0x44d1a2,_0x54c5dc);}}['sendOne'](_0x538215,_0x2cf4ee){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x538215]!==void 0x0)try{_0x2cf4ee(this['observers'][_0x538215]);}catch(_0x59f666){typeof console<'u'&&console['error']&&console['error'](_0x59f666);}});}['close'](_0x31a2c7){this['finalized']||(this['finalized']=!0x0,_0x31a2c7!==void 0x0&&(this['finalError']=_0x31a2c7),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x4a035a,_0xa2bd57){if(typeof _0x4a035a!='object'||_0x4a035a===null)return!0x1;for(const _0x25c60a of _0xa2bd57)if(_0x25c60a in _0x4a035a&&typeof _0x4a035a[_0x25c60a]=='function')return!0x0;return!0x1;}function ti(){}function it(_0xf096df,_0x2ee119){return _0xf096df+'\x20failed:\x20'+_0x2ee119+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x50c071){const _0x4b2d53=[];let _0x595de7=0x0;for(let _0x594b9a=0x0;_0x594b9a<_0x50c071['length'];_0x594b9a++){let _0x546698=_0x50c071['charCodeAt'](_0x594b9a);if(_0x546698>=0xd800&&_0x546698<=0xdbff){const _0x27777e=_0x546698-0xd800;_0x594b9a++,f(_0x594b9a<_0x50c071['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x148a8d=_0x50c071['charCodeAt'](_0x594b9a)-0xdc00;_0x546698=0x10000+(_0x27777e<<0xa)+_0x148a8d;}_0x546698<0x80?_0x4b2d53[_0x595de7++]=_0x546698:_0x546698<0x800?(_0x4b2d53[_0x595de7++]=_0x546698>>0x6|0xc0,_0x4b2d53[_0x595de7++]=_0x546698&0x3f|0x80):_0x546698<0x10000?(_0x4b2d53[_0x595de7++]=_0x546698>>0xc|0xe0,_0x4b2d53[_0x595de7++]=_0x546698>>0x6&0x3f|0x80,_0x4b2d53[_0x595de7++]=_0x546698&0x3f|0x80):(_0x4b2d53[_0x595de7++]=_0x546698>>0x12|0xf0,_0x4b2d53[_0x595de7++]=_0x546698>>0xc&0x3f|0x80,_0x4b2d53[_0x595de7++]=_0x546698>>0x6&0x3f|0x80,_0x4b2d53[_0x595de7++]=_0x546698&0x3f|0x80);}return _0x4b2d53;},Ln=function(_0x314099){let _0x287c75=0x0;for(let _0x39ff62=0x0;_0x39ff62<_0x314099['length'];_0x39ff62++){const _0x28c3c0=_0x314099['charCodeAt'](_0x39ff62);_0x28c3c0<0x80?_0x287c75++:_0x28c3c0<0x800?_0x287c75+=0x2:_0x28c3c0>=0xd800&&_0x28c3c0<=0xdbff?(_0x287c75+=0x4,_0x39ff62++):_0x287c75+=0x3;}return _0x287c75;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x527b24){return _0x527b24&&_0x527b24['_delegate']?_0x527b24['_delegate']:_0x527b24;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0xbb2cc){try{return(_0xbb2cc['startsWith']('http://')||_0xbb2cc['startsWith']('https://')?new URL(_0xbb2cc)['hostname']:_0xbb2cc)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x5b1578){return(await fetch(_0x5b1578,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x337797,_0x12ca29,_0x245cd3){this['name']=_0x337797,this['instanceFactory']=_0x12ca29,this['type']=_0x245cd3,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x134f1c){return this['instantiationMode']=_0x134f1c,this;}['setMultipleInstances'](_0x1a848a){return this['multipleInstances']=_0x1a848a,this;}['setServiceProps'](_0x4a0170){return this['serviceProps']=_0x4a0170,this;}['setInstanceCreatedCallback'](_0x12036d){return this['onInstanceCreated']=_0x12036d,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x1a1827,_0x25872f){this['name']=_0x1a1827,this['container']=_0x25872f,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0xcad1af){const _0xdfe4f0=this['normalizeInstanceIdentifier'](_0xcad1af);if(!this['instancesDeferred']['has'](_0xdfe4f0)){const _0x25fa57=new H();if(this['instancesDeferred']['set'](_0xdfe4f0,_0x25fa57),this['isInitialized'](_0xdfe4f0)||this['shouldAutoInitialize']())try{const _0x3595ed=this['getOrInitializeService']({'instanceIdentifier':_0xdfe4f0});_0x3595ed&&_0x25fa57['resolve'](_0x3595ed);}catch{}}return this['instancesDeferred']['get'](_0xdfe4f0)['promise'];}['getImmediate'](_0x5dfd34){const _0x140b9a=this['normalizeInstanceIdentifier'](_0x5dfd34==null?void 0x0:_0x5dfd34['identifier']),_0x395c62=(_0x5dfd34==null?void 0x0:_0x5dfd34['optional'])??!0x1;if(this['isInitialized'](_0x140b9a)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x140b9a});}catch(_0x4c2408){if(_0x395c62)return null;throw _0x4c2408;}else{if(_0x395c62)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x3f45d7){if(_0x3f45d7['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x3f45d7['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x3f45d7,!!this['shouldAutoInitialize']()){if(Pc(_0x3f45d7))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x3b8901,_0xca364c]of this['instancesDeferred']['entries']()){const _0x23f6d2=this['normalizeInstanceIdentifier'](_0x3b8901);try{const _0x5081f7=this['getOrInitializeService']({'instanceIdentifier':_0x23f6d2});_0xca364c['resolve'](_0x5081f7);}catch{}}}}['clearInstance'](_0x2638ec=Ne){this['instancesDeferred']['delete'](_0x2638ec),this['instancesOptions']['delete'](_0x2638ec),this['instances']['delete'](_0x2638ec);}async['delete'](){const _0x52fe3b=Array['from'](this['instances']['values']());await Promise['all']([..._0x52fe3b['filter'](_0x16d849=>'INTERNAL'in _0x16d849)['map'](_0x4623e5=>_0x4623e5['INTERNAL']['delete']()),..._0x52fe3b['filter'](_0x59214b=>'_delete'in _0x59214b)['map'](_0x4bc416=>_0x4bc416['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x91fe0a=Ne){return this['instances']['has'](_0x91fe0a);}['getOptions'](_0x386bd7=Ne){return this['instancesOptions']['get'](_0x386bd7)||{};}['initialize'](_0x4d282d={}){const {options:_0x79b659={}}=_0x4d282d,_0x1b726f=this['normalizeInstanceIdentifier'](_0x4d282d['instanceIdentifier']);if(this['isInitialized'](_0x1b726f))throw Error(this['name']+'('+_0x1b726f+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x368101=this['getOrInitializeService']({'instanceIdentifier':_0x1b726f,'options':_0x79b659});for(const [_0x5f56c1,_0x33dc74]of this['instancesDeferred']['entries']()){const _0x378107=this['normalizeInstanceIdentifier'](_0x5f56c1);_0x1b726f===_0x378107&&_0x33dc74['resolve'](_0x368101);}return _0x368101;}['onInit'](_0x1e8a60,_0x1593d7){const _0x341b85=this['normalizeInstanceIdentifier'](_0x1593d7),_0x3297ce=this['onInitCallbacks']['get'](_0x341b85)??new Set();_0x3297ce['add'](_0x1e8a60),this['onInitCallbacks']['set'](_0x341b85,_0x3297ce);const _0x5ec8a3=this['instances']['get'](_0x341b85);return _0x5ec8a3&&_0x1e8a60(_0x5ec8a3,_0x341b85),()=>{_0x3297ce['delete'](_0x1e8a60);};}['invokeOnInitCallbacks'](_0x448353,_0x43647d){const _0x321f9a=this['onInitCallbacks']['get'](_0x43647d);if(_0x321f9a){for(const _0xf124ba of _0x321f9a)try{_0xf124ba(_0x448353,_0x43647d);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x312bc8,options:_0xe8280e={}}){let _0x5df157=this['instances']['get'](_0x312bc8);if(!_0x5df157&&this['component']&&(_0x5df157=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x312bc8),'options':_0xe8280e}),this['instances']['set'](_0x312bc8,_0x5df157),this['instancesOptions']['set'](_0x312bc8,_0xe8280e),this['invokeOnInitCallbacks'](_0x5df157,_0x312bc8),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x312bc8,_0x5df157);}catch{}return _0x5df157||null;}['normalizeInstanceIdentifier'](_0x246ad0=Ne){return this['component']?this['component']['multipleInstances']?_0x246ad0:Ne:_0x246ad0;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0xcf7704){return _0xcf7704===Ne?void 0x0:_0xcf7704;}function Pc(_0x99944d){return _0x99944d['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x102bf8){this['name']=_0x102bf8,this['providers']=new Map();}['addComponent'](_0x148904){const _0x4c059f=this['getProvider'](_0x148904['name']);if(_0x4c059f['isComponentSet']())throw new Error('Component\x20'+_0x148904['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x4c059f['setComponent'](_0x148904);}['addOrOverwriteComponent'](_0x411d85){this['getProvider'](_0x411d85['name'])['isComponentSet']()&&this['providers']['delete'](_0x411d85['name']),this['addComponent'](_0x411d85);}['getProvider'](_0x516553){if(this['providers']['has'](_0x516553))return this['providers']['get'](_0x516553);const _0x35bdf6=new Ac(_0x516553,this);return this['providers']['set'](_0x516553,_0x35bdf6),_0x35bdf6;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x21ea5f){_0x21ea5f[_0x21ea5f['DEBUG']=0x0]='DEBUG',_0x21ea5f[_0x21ea5f['VERBOSE']=0x1]='VERBOSE',_0x21ea5f[_0x21ea5f['INFO']=0x2]='INFO',_0x21ea5f[_0x21ea5f['WARN']=0x3]='WARN',_0x21ea5f[_0x21ea5f['ERROR']=0x4]='ERROR',_0x21ea5f[_0x21ea5f['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x876a7b,_0x2f5d7e,..._0x50ef49)=>{if(_0x2f5d7e<_0x876a7b['logLevel'])return;const _0x25a649=new Date()['toISOString'](),_0x768d8d=Mc[_0x2f5d7e];if(_0x768d8d)console[_0x768d8d]('['+_0x25a649+']\x20\x20'+_0x876a7b['name']+':',..._0x50ef49);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x2f5d7e+')');};class Bi{constructor(_0x2ccf72){this['name']=_0x2ccf72,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x1e270f){if(!(_0x1e270f in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x1e270f+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x1e270f;}['setLogLevel'](_0x4fd7e3){this['_logLevel']=typeof _0x4fd7e3=='string'?Oc[_0x4fd7e3]:_0x4fd7e3;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x5c835d){if(typeof _0x5c835d!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x5c835d;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x1468dc){this['_userLogHandler']=_0x1468dc;}['debug'](..._0x2cb1be){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x2cb1be),this['_logHandler'](this,T['DEBUG'],..._0x2cb1be);}['log'](..._0x583d72){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x583d72),this['_logHandler'](this,T['VERBOSE'],..._0x583d72);}['info'](..._0x1bbe12){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x1bbe12),this['_logHandler'](this,T['INFO'],..._0x1bbe12);}['warn'](..._0x2e892d){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x2e892d),this['_logHandler'](this,T['WARN'],..._0x2e892d);}['error'](..._0x283e8c){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x283e8c),this['_logHandler'](this,T['ERROR'],..._0x283e8c);}}const xc=(_0x324911,_0x573b9a)=>_0x573b9a['some'](_0x49122e=>_0x324911 instanceof _0x49122e);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x5f4be9){const _0x18481c=new Promise((_0x264f11,_0x503c89)=>{const _0x426a70=()=>{_0x5f4be9['removeEventListener']('success',_0x313e15),_0x5f4be9['removeEventListener']('error',_0x79bab6);},_0x313e15=()=>{_0x264f11(ge(_0x5f4be9['result'])),_0x426a70();},_0x79bab6=()=>{_0x503c89(_0x5f4be9['error']),_0x426a70();};_0x5f4be9['addEventListener']('success',_0x313e15),_0x5f4be9['addEventListener']('error',_0x79bab6);});return _0x18481c['then'](_0x401286=>{_0x401286 instanceof IDBCursor&&Jr['set'](_0x401286,_0x5f4be9);})['catch'](()=>{}),Vi['set'](_0x18481c,_0x5f4be9),_0x18481c;}function Bc(_0x113dd9){if(_i['has'](_0x113dd9))return;const _0xfe3b14=new Promise((_0x464928,_0x428887)=>{const _0x1525bd=()=>{_0x113dd9['removeEventListener']('complete',_0x25a924),_0x113dd9['removeEventListener']('error',_0x5c37ac),_0x113dd9['removeEventListener']('abort',_0x5c37ac);},_0x25a924=()=>{_0x464928(),_0x1525bd();},_0x5c37ac=()=>{_0x428887(_0x113dd9['error']||new DOMException('AbortError','AbortError')),_0x1525bd();};_0x113dd9['addEventListener']('complete',_0x25a924),_0x113dd9['addEventListener']('error',_0x5c37ac),_0x113dd9['addEventListener']('abort',_0x5c37ac);});_i['set'](_0x113dd9,_0xfe3b14);}let gi={'get'(_0x4a6af4,_0x3196cc,_0x2bf462){if(_0x4a6af4 instanceof IDBTransaction){if(_0x3196cc==='done')return _i['get'](_0x4a6af4);if(_0x3196cc==='objectStoreNames')return _0x4a6af4['objectStoreNames']||Xr['get'](_0x4a6af4);if(_0x3196cc==='store')return _0x2bf462['objectStoreNames'][0x1]?void 0x0:_0x2bf462['objectStore'](_0x2bf462['objectStoreNames'][0x0]);}return ge(_0x4a6af4[_0x3196cc]);},'set'(_0x59a731,_0x5cc619,_0x49ed34){return _0x59a731[_0x5cc619]=_0x49ed34,!0x0;},'has'(_0x321926,_0x519875){return _0x321926 instanceof IDBTransaction&&(_0x519875==='done'||_0x519875==='store')?!0x0:_0x519875 in _0x321926;}};function Vc(_0x584f81){gi=_0x584f81(gi);}function Hc(_0x289688){return _0x289688===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x2458f0,..._0x5cc47a){const _0x215df5=_0x289688['call'](ii(this),_0x2458f0,..._0x5cc47a);return Xr['set'](_0x215df5,_0x2458f0['sort']?_0x2458f0['sort']():[_0x2458f0]),ge(_0x215df5);}:Uc()['includes'](_0x289688)?function(..._0x5d98d3){return _0x289688['apply'](ii(this),_0x5d98d3),ge(Jr['get'](this));}:function(..._0x3db168){return ge(_0x289688['apply'](ii(this),_0x3db168));};}function $c(_0xb46f32){return typeof _0xb46f32=='function'?Hc(_0xb46f32):(_0xb46f32 instanceof IDBTransaction&&Bc(_0xb46f32),xc(_0xb46f32,Fc())?new Proxy(_0xb46f32,gi):_0xb46f32);}function ge(_0x5e1337){if(_0x5e1337 instanceof IDBRequest)return Wc(_0x5e1337);if(ni['has'](_0x5e1337))return ni['get'](_0x5e1337);const _0x344c7f=$c(_0x5e1337);return _0x344c7f!==_0x5e1337&&(ni['set'](_0x5e1337,_0x344c7f),Vi['set'](_0x344c7f,_0x5e1337)),_0x344c7f;}const ii=_0x4fb7a9=>Vi['get'](_0x4fb7a9);function Gc(_0x5ecf97,_0x5ef463,{blocked:_0x17fa26,upgrade:_0x8035e2,blocking:_0x1cadea,terminated:_0x3b5830}={}){const _0x19ff15=indexedDB['open'](_0x5ecf97,_0x5ef463),_0x19f04b=ge(_0x19ff15);return _0x8035e2&&_0x19ff15['addEventListener']('upgradeneeded',_0x3fac66=>{_0x8035e2(ge(_0x19ff15['result']),_0x3fac66['oldVersion'],_0x3fac66['newVersion'],ge(_0x19ff15['transaction']),_0x3fac66);}),_0x17fa26&&_0x19ff15['addEventListener']('blocked',_0x209def=>_0x17fa26(_0x209def['oldVersion'],_0x209def['newVersion'],_0x209def)),_0x19f04b['then'](_0x580933=>{_0x3b5830&&_0x580933['addEventListener']('close',()=>_0x3b5830()),_0x1cadea&&_0x580933['addEventListener']('versionchange',_0x543bdb=>_0x1cadea(_0x543bdb['oldVersion'],_0x543bdb['newVersion'],_0x543bdb));})['catch'](()=>{}),_0x19f04b;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x276890,_0x37a388){if(!(_0x276890 instanceof IDBDatabase&&!(_0x37a388 in _0x276890)&&typeof _0x37a388=='string'))return;if(si['get'](_0x37a388))return si['get'](_0x37a388);const _0x79d264=_0x37a388['replace'](/FromIndex$/,''),_0x356f55=_0x37a388!==_0x79d264,_0x4f84b9=zc['includes'](_0x79d264);if(!(_0x79d264 in(_0x356f55?IDBIndex:IDBObjectStore)['prototype'])||!(_0x4f84b9||qc['includes'](_0x79d264)))return;const _0x5cbd51=async function(_0x57c5be,..._0x167105){const _0x4ebd36=this['transaction'](_0x57c5be,_0x4f84b9?'readwrite':'readonly');let _0xe47ecc=_0x4ebd36['store'];return _0x356f55&&(_0xe47ecc=_0xe47ecc['index'](_0x167105['shift']())),(await Promise['all']([_0xe47ecc[_0x79d264](..._0x167105),_0x4f84b9&&_0x4ebd36['done']]))[0x0];};return si['set'](_0x37a388,_0x5cbd51),_0x5cbd51;}Vc(_0x4816a1=>({..._0x4816a1,'get':(_0x56215b,_0x1e7072,_0x43aac1)=>Ms(_0x56215b,_0x1e7072)||_0x4816a1['get'](_0x56215b,_0x1e7072,_0x43aac1),'has':(_0x58441e,_0x1021c1)=>!!Ms(_0x58441e,_0x1021c1)||_0x4816a1['has'](_0x58441e,_0x1021c1)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x57927d){this['container']=_0x57927d;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0xe7fd8a=>{if(Kc(_0xe7fd8a)){const _0xff4305=_0xe7fd8a['getImmediate']();return _0xff4305['library']+'/'+_0xff4305['version'];}else return null;})['filter'](_0x4a63d2=>_0x4a63d2)['join']('\x20');}}function Kc(_0x3b26a9){const _0x4cd805=_0x3b26a9['getComponent']();return(_0x4cd805==null?void 0x0:_0x4cd805['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x17d7be,_0x4f022f){try{_0x17d7be['container']['addComponent'](_0x4f022f);}catch(_0x48c459){oe['debug']('Component\x20'+_0x4f022f['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x17d7be['name'],_0x48c459);}}function st(_0x4dd91f){const _0x12ecb7=_0x4dd91f['name'];if(Ei['has'](_0x12ecb7))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x12ecb7+'.'),!0x1;Ei['set'](_0x12ecb7,_0x4dd91f);for(const _0x566af8 of Ue['values']())xs(_0x566af8,_0x4dd91f);for(const _0x549ac8 of vi['values']())xs(_0x549ac8,_0x4dd91f);return!0x0;}function Hi(_0x48c8c2,_0x16c94d){const _0x56a4e1=_0x48c8c2['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x56a4e1&&_0x56a4e1['triggerHeartbeat'](),_0x48c8c2['container']['getProvider'](_0x16c94d);}function $(_0x2ed20b){return _0x2ed20b==null?!0x1:_0x2ed20b['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x445432,_0x55309d,_0x54860e){this['_isDeleted']=!0x1,this['_options']={..._0x445432},this['_config']={..._0x55309d},this['_name']=_0x55309d['name'],this['_automaticDataCollectionEnabled']=_0x55309d['automaticDataCollectionEnabled'],this['_container']=_0x54860e,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x9813fa){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x9813fa;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x2be68d){this['_isDeleted']=_0x2be68d;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x3a3e9e,_0x5b82e3={}){let _0x1598b9=_0x3a3e9e;typeof _0x5b82e3!='object'&&(_0x5b82e3={'name':_0x5b82e3});const _0x80b62a={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x5b82e3},_0x1e4127=_0x80b62a['name'];if(typeof _0x1e4127!='string'||!_0x1e4127)throw me['create']('bad-app-name',{'appName':String(_0x1e4127)});if(_0x1598b9||(_0x1598b9=zr()),!_0x1598b9)throw me['create']('no-options');const _0x522220=Ue['get'](_0x1e4127);if(_0x522220){if(xe(_0x1598b9,_0x522220['options'])&&xe(_0x80b62a,_0x522220['config']))return _0x522220;throw me['create']('duplicate-app',{'appName':_0x1e4127});}const _0xabc841=new Nc(_0x1e4127);for(const _0x40a822 of Ei['values']())_0xabc841['addComponent'](_0x40a822);const _0x74ae1f=new Tl(_0x1598b9,_0x80b62a,_0xabc841);return Ue['set'](_0x1e4127,_0x74ae1f),_0x74ae1f;}function Zr(_0x515e1c=yi){const _0x39116e=Ue['get'](_0x515e1c);if(!_0x39116e&&_0x515e1c===yi&&zr())return Sl();if(!_0x39116e)throw me['create']('no-app',{'appName':_0x515e1c});return _0x39116e;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x20c05b){let _0x3b1c08=!0x1;const _0x27e435=_0x20c05b['name'];Ue['has'](_0x27e435)?(_0x3b1c08=!0x0,Ue['delete'](_0x27e435)):vi['has'](_0x27e435)&&_0x20c05b['decRefCount']()<=0x0&&(vi['delete'](_0x27e435),_0x3b1c08=!0x0),_0x3b1c08&&(await Promise['all'](_0x20c05b['container']['getProviders']()['map'](_0x3661de=>_0x3661de['delete']())),_0x20c05b['isDeleted']=!0x0);}function ye(_0x2de230,_0x35d9e9,_0x58f622){let _0x59c550=wl[_0x2de230]??_0x2de230;_0x58f622&&(_0x59c550+='-'+_0x58f622);const _0x3c4225=_0x59c550['match'](/\s|\//),_0x1f2d43=_0x35d9e9['match'](/\s|\//);if(_0x3c4225||_0x1f2d43){const _0x4afb2c=['Unable\x20to\x20register\x20library\x20\x22'+_0x59c550+'\x22\x20with\x20version\x20\x22'+_0x35d9e9+'\x22:'];_0x3c4225&&_0x4afb2c['push']('library\x20name\x20\x22'+_0x59c550+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x3c4225&&_0x1f2d43&&_0x4afb2c['push']('and'),_0x1f2d43&&_0x4afb2c['push']('version\x20name\x20\x22'+_0x35d9e9+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x4afb2c['join']('\x20'));return;}st(new Fe(_0x59c550+'-version',()=>({'library':_0x59c550,'version':_0x35d9e9}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0xdc54a,_0x35df44)=>{switch(_0x35df44){case 0x0:try{_0xdc54a['createObjectStore'](Ot);}catch(_0x5d458b){console['warn'](_0x5d458b);}}}})['catch'](_0x37b0cb=>{throw me['create']('idb-open',{'originalErrorMessage':_0x37b0cb['message']});})),ri;}async function Al(_0x1fafcf){try{const _0x39ccce=(await eo())['transaction'](Ot),_0x4aa5fe=await _0x39ccce['objectStore'](Ot)['get'](to(_0x1fafcf));return await _0x39ccce['done'],_0x4aa5fe;}catch(_0x15108b){if(_0x15108b instanceof Re)oe['warn'](_0x15108b['message']);else{const _0x9ef371=me['create']('idb-get',{'originalErrorMessage':_0x15108b==null?void 0x0:_0x15108b['message']});oe['warn'](_0x9ef371['message']);}}}async function Fs(_0x4af06b,_0x22bc63){try{const _0x286596=(await eo())['transaction'](Ot,'readwrite');await _0x286596['objectStore'](Ot)['put'](_0x22bc63,to(_0x4af06b)),await _0x286596['done'];}catch(_0x3d7d76){if(_0x3d7d76 instanceof Re)oe['warn'](_0x3d7d76['message']);else{const _0x44f959=me['create']('idb-set',{'originalErrorMessage':_0x3d7d76==null?void 0x0:_0x3d7d76['message']});oe['warn'](_0x44f959['message']);}}}function to(_0x33bf06){return _0x33bf06['name']+'!'+_0x33bf06['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x15e7af){this['container']=_0x15e7af,this['_heartbeatsCache']=null;const _0x2d34ca=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x2d34ca),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x368d79=>(this['_heartbeatsCache']=_0x368d79,_0x368d79));}async['triggerHeartbeat'](){var _0x5b4dcb,_0x46a8de;try{const _0xb01aaf=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x5adba0=Us();if(((_0x5b4dcb=this['_heartbeatsCache'])==null?void 0x0:_0x5b4dcb['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x46a8de=this['_heartbeatsCache'])==null?void 0x0:_0x46a8de['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x5adba0||this['_heartbeatsCache']['heartbeats']['some'](_0xa186e6=>_0xa186e6['date']===_0x5adba0))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x5adba0,'agent':_0xb01aaf}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x5cca05=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x5cca05,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x30e30a){oe['warn'](_0x30e30a);}}async['getHeartbeatsHeader'](){var _0x5456a3;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x5456a3=this['_heartbeatsCache'])==null?void 0x0:_0x5456a3['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x55c104=Us(),{heartbeatsToSend:_0x161eb4,unsentEntries:_0x577cb3}=Ol(this['_heartbeatsCache']['heartbeats']),_0xb019a5=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x161eb4}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x55c104,_0x577cb3['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x577cb3,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0xb019a5;}catch(_0x3b6bbb){return oe['warn'](_0x3b6bbb),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x74930a,_0x59c397=kl){const _0x380704=[];let _0x27a27e=_0x74930a['slice']();for(const _0xbf8a8c of _0x74930a){const _0x5b8f68=_0x380704['find'](_0x49e4a5=>_0x49e4a5['agent']===_0xbf8a8c['agent']);if(_0x5b8f68){if(_0x5b8f68['dates']['push'](_0xbf8a8c['date']),Ws(_0x380704)>_0x59c397){_0x5b8f68['dates']['pop']();break;}}else{if(_0x380704['push']({'agent':_0xbf8a8c['agent'],'dates':[_0xbf8a8c['date']]}),Ws(_0x380704)>_0x59c397){_0x380704['pop']();break;}}_0x27a27e=_0x27a27e['slice'](0x1);}return{'heartbeatsToSend':_0x380704,'unsentEntries':_0x27a27e};}class Dl{constructor(_0x4510d6){this['app']=_0x4510d6,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x309996=await Al(this['app']);return _0x309996!=null&&_0x309996['heartbeats']?_0x309996:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x131641){if(await this['_canUseIndexedDBPromise']){const _0x1cf011=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x131641['lastSentHeartbeatDate']??_0x1cf011['lastSentHeartbeatDate'],'heartbeats':_0x131641['heartbeats']});}else return;}async['add'](_0x23d3fa){if(await this['_canUseIndexedDBPromise']){const _0x31474c=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x23d3fa['lastSentHeartbeatDate']??_0x31474c['lastSentHeartbeatDate'],'heartbeats':[..._0x31474c['heartbeats'],..._0x23d3fa['heartbeats']]});}else return;}}function Ws(_0x4d628c){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x4d628c}))['length'];}function Ml(_0x5bebeb){if(_0x5bebeb['length']===0x0)return-0x1;let _0x2640a3=0x0,_0x376bf8=_0x5bebeb[0x0]['date'];for(let _0x34bdf5=0x1;_0x34bdf5<_0x5bebeb['length'];_0x34bdf5++)_0x5bebeb[_0x34bdf5]['date']<_0x376bf8&&(_0x376bf8=_0x5bebeb[_0x34bdf5]['date'],_0x2640a3=_0x34bdf5);return _0x2640a3;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x2453ae){st(new Fe('platform-logger',_0x3d3a7e=>new jc(_0x3d3a7e),'PRIVATE')),st(new Fe('heartbeat',_0x25634c=>new Nl(_0x25634c),'PRIVATE')),ye(mi,Ls,_0x2453ae),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x238633){no=_0x238633;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x4a85a3){this['domStorage_']=_0x4a85a3,this['prefix_']='firebase:';}['set'](_0xad76b5,_0x448e96){_0x448e96==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0xad76b5)):this['domStorage_']['setItem'](this['prefixedName_'](_0xad76b5),O(_0x448e96));}['get'](_0x1ac4ad){const _0x4bbdfd=this['domStorage_']['getItem'](this['prefixedName_'](_0x1ac4ad));return _0x4bbdfd==null?null:Nt(_0x4bbdfd);}['remove'](_0x3f9b8e){this['domStorage_']['removeItem'](this['prefixedName_'](_0x3f9b8e));}['prefixedName_'](_0x56bf9f){return this['prefix_']+_0x56bf9f;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x51dfde,_0x36d147){_0x36d147==null?delete this['cache_'][_0x51dfde]:this['cache_'][_0x51dfde]=_0x36d147;}['get'](_0x44a810){return Q(this['cache_'],_0x44a810)?this['cache_'][_0x44a810]:null;}['remove'](_0x281b29){delete this['cache_'][_0x281b29];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x51c299){try{if(typeof window<'u'&&typeof window[_0x51c299]<'u'){const _0x5592b6=window[_0x51c299];return _0x5592b6['setItem']('firebase:sentinel','cache'),_0x5592b6['removeItem']('firebase:sentinel'),new Wl(_0x5592b6);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x30ab07=0x1;return function(){return _0x30ab07++;};}()),ro=function(_0x86b568){const _0x1f5f76=Rc(_0x86b568),_0xb60683=new Cc();_0xb60683['update'](_0x1f5f76);const _0x342f11=_0xb60683['digest']();return Fi['encodeByteArray'](_0x342f11);},zt=function(..._0x253d84){let _0x2cae1f='';for(let _0x5e5ed6=0x0;_0x5e5ed6<_0x253d84['length'];_0x5e5ed6++){const _0x1af883=_0x253d84[_0x5e5ed6];Array['isArray'](_0x1af883)||_0x1af883&&typeof _0x1af883=='object'&&typeof _0x1af883['length']=='number'?_0x2cae1f+=zt['apply'](null,_0x1af883):typeof _0x1af883=='object'?_0x2cae1f+=O(_0x1af883):_0x2cae1f+=_0x1af883,_0x2cae1f+='\x20';}return _0x2cae1f;};let St=null,$s=!0x0;const Hl=function(_0x26dc7e,_0x345465){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0xe115f8){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x3fd5a1=zt['apply'](null,_0xe115f8);St(_0x3fd5a1);}},jt=function(_0x4f89b7){return function(..._0x9a45){L(_0x4f89b7,..._0x9a45);};},Ii=function(..._0x3e3502){const _0x3f079b='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x3e3502);Ze['error'](_0x3f079b);},ae=function(..._0x4a50ff){const _0x4420ab='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x4a50ff);throw Ze['error'](_0x4420ab),new Error(_0x4420ab);},U=function(..._0x1e65b1){const _0xb3638c='FIREBASE\x20WARNING:\x20'+zt(..._0x1e65b1);Ze['warn'](_0xb3638c);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x5722fb){return typeof _0x5722fb=='number'&&(_0x5722fb!==_0x5722fb||_0x5722fb===Number['POSITIVE_INFINITY']||_0x5722fb===Number['NEGATIVE_INFINITY']);},Gl=function(_0x48464e){if(document['readyState']==='complete')_0x48464e();else{let _0x44a550=!0x1;const _0x37fb43=function(){if(!document['body']){setTimeout(_0x37fb43,Math['floor'](0xa));return;}_0x44a550||(_0x44a550=!0x0,_0x48464e());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x37fb43,!0x1),window['addEventListener']('load',_0x37fb43,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x37fb43();}),window['attachEvent']('onload',_0x37fb43));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x13a5f0,_0x1eafac){if(_0x13a5f0===_0x1eafac)return 0x0;if(_0x13a5f0===We||_0x1eafac===we)return-0x1;if(_0x1eafac===We||_0x13a5f0===we)return 0x1;{const _0x33f74a=Gs(_0x13a5f0),_0x7f74=Gs(_0x1eafac);return _0x33f74a!==null?_0x7f74!==null?_0x33f74a-_0x7f74===0x0?_0x13a5f0['length']-_0x1eafac['length']:_0x33f74a-_0x7f74:-0x1:_0x7f74!==null?0x1:_0x13a5f0<_0x1eafac?-0x1:0x1;}},ql=function(_0x443585,_0x271504){return _0x443585===_0x271504?0x0:_0x443585<_0x271504?-0x1:0x1;},vt=function(_0x4f2d0b,_0x2d96da){if(_0x2d96da&&_0x4f2d0b in _0x2d96da)return _0x2d96da[_0x4f2d0b];throw new Error('Missing\x20required\x20key\x20('+_0x4f2d0b+')\x20in\x20object:\x20'+O(_0x2d96da));},$i=function(_0x40eaef){if(typeof _0x40eaef!='object'||_0x40eaef===null)return O(_0x40eaef);const _0x40b385=[];for(const _0x1d8ec6 in _0x40eaef)_0x40b385['push'](_0x1d8ec6);_0x40b385['sort']();let _0x285cea='{';for(let _0x500c95=0x0;_0x500c95<_0x40b385['length'];_0x500c95++)_0x500c95!==0x0&&(_0x285cea+=','),_0x285cea+=O(_0x40b385[_0x500c95]),_0x285cea+=':',_0x285cea+=$i(_0x40eaef[_0x40b385[_0x500c95]]);return _0x285cea+='}',_0x285cea;},oo=function(_0x457262,_0x243c35){const _0x3672bb=_0x457262['length'];if(_0x3672bb<=_0x243c35)return[_0x457262];const _0x28be87=[];for(let _0x2e755b=0x0;_0x2e755b<_0x3672bb;_0x2e755b+=_0x243c35)_0x2e755b+_0x243c35>_0x3672bb?_0x28be87['push'](_0x457262['substring'](_0x2e755b,_0x3672bb)):_0x28be87['push'](_0x457262['substring'](_0x2e755b,_0x2e755b+_0x243c35));return _0x28be87;};function x(_0x5d86bc,_0x344238){for(const _0x339d17 in _0x5d86bc)_0x5d86bc['hasOwnProperty'](_0x339d17)&&_0x344238(_0x339d17,_0x5d86bc[_0x339d17]);}const ao=function(_0x417c12){f(!xn(_0x417c12),'Invalid\x20JSON\x20number');const _0x3e740e=0xb,_0x1a11d1=0x34,_0x530d6d=(0x1<<_0x3e740e-0x1)-0x1;let _0x4b19c8,_0x1e3685,_0x36e19b,_0xcbf874,_0x1e726a;_0x417c12===0x0?(_0x1e3685=0x0,_0x36e19b=0x0,_0x4b19c8=0x1/_0x417c12===-0x1/0x0?0x1:0x0):(_0x4b19c8=_0x417c12<0x0,_0x417c12=Math['abs'](_0x417c12),_0x417c12>=Math['pow'](0x2,0x1-_0x530d6d)?(_0xcbf874=Math['min'](Math['floor'](Math['log'](_0x417c12)/Math['LN2']),_0x530d6d),_0x1e3685=_0xcbf874+_0x530d6d,_0x36e19b=Math['round'](_0x417c12*Math['pow'](0x2,_0x1a11d1-_0xcbf874)-Math['pow'](0x2,_0x1a11d1))):(_0x1e3685=0x0,_0x36e19b=Math['round'](_0x417c12/Math['pow'](0x2,0x1-_0x530d6d-_0x1a11d1))));const _0x286bf4=[];for(_0x1e726a=_0x1a11d1;_0x1e726a;_0x1e726a-=0x1)_0x286bf4['push'](_0x36e19b%0x2?0x1:0x0),_0x36e19b=Math['floor'](_0x36e19b/0x2);for(_0x1e726a=_0x3e740e;_0x1e726a;_0x1e726a-=0x1)_0x286bf4['push'](_0x1e3685%0x2?0x1:0x0),_0x1e3685=Math['floor'](_0x1e3685/0x2);_0x286bf4['push'](_0x4b19c8?0x1:0x0),_0x286bf4['reverse']();const _0x3f4b60=_0x286bf4['join']('');let _0x1d91e5='';for(_0x1e726a=0x0;_0x1e726a<0x40;_0x1e726a+=0x8){let _0x569245=parseInt(_0x3f4b60['substr'](_0x1e726a,0x8),0x2)['toString'](0x10);_0x569245['length']===0x1&&(_0x569245='0'+_0x569245),_0x1d91e5=_0x1d91e5+_0x569245;}return _0x1d91e5['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x4d0297,_0x51ec5b){let _0x5b099c='Unknown\x20Error';_0x4d0297==='too_big'?_0x5b099c='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x4d0297==='permission_denied'?_0x5b099c='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x4d0297==='unavailable'&&(_0x5b099c='The\x20service\x20is\x20unavailable');const _0xbd825=new Error(_0x4d0297+'\x20at\x20'+_0x51ec5b['_path']['toString']()+':\x20'+_0x5b099c);return _0xbd825['code']=_0x4d0297['toUpperCase'](),_0xbd825;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x5b2890){if(Yl['test'](_0x5b2890)){const _0x258bc1=Number(_0x5b2890);if(_0x258bc1>=Ql&&_0x258bc1<=Jl)return _0x258bc1;}return null;},ft=function(_0x3cade3){try{_0x3cade3();}catch(_0x403acd){setTimeout(()=>{const _0x385d12=_0x403acd['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x385d12),_0x403acd;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x48f115,_0x42b84d){const _0x42ece2=setTimeout(_0x48f115,_0x42b84d);return typeof _0x42ece2=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x42ece2):typeof _0x42ece2=='object'&&_0x42ece2['unref']&&_0x42ece2['unref'](),_0x42ece2;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x3ac77f,_0x5e43cb){this['appCheckProvider']=_0x5e43cb,this['appName']=_0x3ac77f['name'],$(_0x3ac77f)&&_0x3ac77f['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x3ac77f['settings']['appCheckToken']),this['appCheck']=_0x5e43cb==null?void 0x0:_0x5e43cb['getImmediate']({'optional':!0x0}),this['appCheck']||_0x5e43cb==null||_0x5e43cb['get']()['then'](_0x2ae5fb=>this['appCheck']=_0x2ae5fb);}['getToken'](_0x1fdc5b){if(this['serverAppAppCheckToken']){if(_0x1fdc5b)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x1fdc5b):new Promise((_0x5aa8a8,_0x320c59)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x1fdc5b)['then'](_0x5aa8a8,_0x320c59):_0x5aa8a8(null);},0x0);});}['addTokenChangeListener'](_0x33d5ed){var _0x5dacd4;(_0x5dacd4=this['appCheckProvider'])==null||_0x5dacd4['get']()['then'](_0x1c5cb7=>_0x1c5cb7['addTokenListener'](_0x33d5ed));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x5c2ad7,_0x3add24,_0x1f38ce){this['appName_']=_0x5c2ad7,this['firebaseOptions_']=_0x3add24,this['authProvider_']=_0x1f38ce,this['auth_']=null,this['auth_']=_0x1f38ce['getImmediate']({'optional':!0x0}),this['auth_']||_0x1f38ce['onInit'](_0x529ec4=>this['auth_']=_0x529ec4);}['getToken'](_0x207c5b){return this['auth_']?this['auth_']['getToken'](_0x207c5b)['catch'](_0x5ca07a=>_0x5ca07a&&_0x5ca07a['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x5ca07a)):new Promise((_0x55463f,_0x47fe4c)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x207c5b)['then'](_0x55463f,_0x47fe4c):_0x55463f(null);},0x0);});}['addTokenChangeListener'](_0xe1f1a9){this['auth_']?this['auth_']['addAuthTokenListener'](_0xe1f1a9):this['authProvider_']['get']()['then'](_0x4dc9cb=>_0x4dc9cb['addAuthTokenListener'](_0xe1f1a9));}['removeTokenChangeListener'](_0x8eafc6){this['authProvider_']['get']()['then'](_0x4df5e2=>_0x4df5e2['removeAuthTokenListener'](_0x8eafc6));}['notifyForInvalidToken'](){let _0x43445e='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x43445e+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x43445e+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x43445e+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x43445e);}}class an{constructor(_0x421559){this['accessToken']=_0x421559;}['getToken'](_0x255dd8){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x29f83e){_0x29f83e(this['accessToken']);}['removeTokenChangeListener'](_0x3d6d19){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x59926b,_0xa443ad,_0x482ba8,_0x2b9988,_0x29ab6c=!0x1,_0x23770b='',_0x568822=!0x1,_0x2935c6=!0x1,_0x26cd83=null){this['secure']=_0xa443ad,this['namespace']=_0x482ba8,this['webSocketOnly']=_0x2b9988,this['nodeAdmin']=_0x29ab6c,this['persistenceKey']=_0x23770b,this['includeNamespaceInQueryParams']=_0x568822,this['isUsingEmulator']=_0x2935c6,this['emulatorOptions']=_0x26cd83,this['_host']=_0x59926b['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x59926b)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x4eb58d){_0x4eb58d!==this['internalHost']&&(this['internalHost']=_0x4eb58d,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x453e6e=this['toURLString']();return this['persistenceKey']&&(_0x453e6e+='<'+this['persistenceKey']+'>'),_0x453e6e;}['toURLString'](){const _0x2ff803=this['secure']?'https://':'http://',_0x1853e2=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x2ff803+this['host']+'/'+_0x1853e2;}}function th(_0x48d9b4){return _0x48d9b4['host']!==_0x48d9b4['internalHost']||_0x48d9b4['isCustomHost']()||_0x48d9b4['includeNamespaceInQueryParams'];}function vo(_0x980195,_0x2a89ab,_0x1efc5e){f(typeof _0x2a89ab=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x1efc5e=='object','typeof\x20params\x20must\x20==\x20object');let _0x40677b;if(_0x2a89ab===go)_0x40677b=(_0x980195['secure']?'wss://':'ws://')+_0x980195['internalHost']+'/.ws?';else{if(_0x2a89ab===mo)_0x40677b=(_0x980195['secure']?'https://':'http://')+_0x980195['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x2a89ab);}th(_0x980195)&&(_0x1efc5e['ns']=_0x980195['namespace']);const _0x198ed5=[];return x(_0x1efc5e,(_0x2bf2ca,_0x1d3b7c)=>{_0x198ed5['push'](_0x2bf2ca+'='+_0x1d3b7c);}),_0x40677b+_0x198ed5['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x5e005c,_0x3b2944=0x1){Q(this['counters_'],_0x5e005c)||(this['counters_'][_0x5e005c]=0x0),this['counters_'][_0x5e005c]+=_0x3b2944;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x1d386a){const _0x4dc73a=_0x1d386a['toString']();return oi[_0x4dc73a]||(oi[_0x4dc73a]=new nh()),oi[_0x4dc73a];}function ih(_0x13f7b0,_0x3054a1){const _0x372b7c=_0x13f7b0['toString']();return ai[_0x372b7c]||(ai[_0x372b7c]=_0x3054a1()),ai[_0x372b7c];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x691f77){this['onMessage_']=_0x691f77,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x48cb52,_0x1b58ba){this['closeAfterResponse']=_0x48cb52,this['onClose']=_0x1b58ba,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x5c2c6e,_0x1463c4){for(this['pendingResponses'][_0x5c2c6e]=_0x1463c4;this['pendingResponses'][this['currentResponseNum']];){const _0x11b95f=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x56e0c2=0x0;_0x56e0c2<_0x11b95f['length'];++_0x56e0c2)_0x11b95f[_0x56e0c2]&&ft(()=>{this['onMessage_'](_0x11b95f[_0x56e0c2]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x2122ed,_0x3be366,_0xcdd2b1,_0x4a21a5,_0x166a09,_0x10c0bd,_0x29896a){this['connId']=_0x2122ed,this['repoInfo']=_0x3be366,this['applicationId']=_0xcdd2b1,this['appCheckToken']=_0x4a21a5,this['authToken']=_0x166a09,this['transportSessionId']=_0x10c0bd,this['lastSessionId']=_0x29896a,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x2122ed),this['stats_']=qi(_0x3be366),this['urlFn']=_0x3afd8f=>(this['appCheckToken']&&(_0x3afd8f[wi]=this['appCheckToken']),vo(_0x3be366,mo,_0x3afd8f));}['open'](_0xc6b468,_0x2b49fa){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x2b49fa,this['myPacketOrderer']=new sh(_0xc6b468),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x4c109e)=>{const [_0x4cfb8c,_0x137d55,_0x7e310c,_0x275bc3,_0x1e881a]=_0x4c109e;if(this['incrementIncomingBytes_'](_0x4c109e),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x4cfb8c===qs)this['id']=_0x137d55,this['password']=_0x7e310c;else{if(_0x4cfb8c===rh)_0x137d55?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x137d55,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x4cfb8c);}}},(..._0x4ea53f)=>{const [_0x360c89,_0x3a9a51]=_0x4ea53f;this['incrementIncomingBytes_'](_0x4ea53f),this['myPacketOrderer']['handleResponse'](_0x360c89,_0x3a9a51);},()=>{this['onClosed_']();},this['urlFn']);const _0x5cab2f={};_0x5cab2f[qs]='t',_0x5cab2f[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x5cab2f[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x5cab2f[co]=Gi,this['transportSessionId']&&(_0x5cab2f[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x5cab2f[po]=this['lastSessionId']),this['applicationId']&&(_0x5cab2f[_o]=this['applicationId']),this['appCheckToken']&&(_0x5cab2f[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x5cab2f[ho]=uo);const _0x4e194a=this['urlFn'](_0x5cab2f);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x4e194a),this['scriptTagHolder']['addTag'](_0x4e194a,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x4cc1f8){const _0x3a77a1=O(_0x4cc1f8);this['bytesSent']+=_0x3a77a1['length'],this['stats_']['incrementCounter']('bytes_sent',_0x3a77a1['length']);const _0x4c44bb=$r(_0x3a77a1),_0x47c5d5=oo(_0x4c44bb,fh);for(let _0x58e0c3=0x0;_0x58e0c3<_0x47c5d5['length'];_0x58e0c3++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x47c5d5['length'],_0x47c5d5[_0x58e0c3]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x237d23,_0x523b46){this['myDisconnFrame']=document['createElement']('iframe');const _0x5b46df={};_0x5b46df[dh]='t',_0x5b46df[Eo]=_0x237d23,_0x5b46df[Io]=_0x523b46,this['myDisconnFrame']['src']=this['urlFn'](_0x5b46df),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x1d95c8){const _0x52fb4b=O(_0x1d95c8)['length'];this['bytesReceived']+=_0x52fb4b,this['stats_']['incrementCounter']('bytes_received',_0x52fb4b);}}class zi{constructor(_0x49fe68,_0x33235e,_0x5ba92c,_0x3714d9){this['onDisconnect']=_0x5ba92c,this['urlFn']=_0x3714d9,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x49fe68,window[ah+this['uniqueCallbackIdentifier']]=_0x33235e,this['myIFrame']=zi['createIFrame_']();let _0x32dfc2='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x32dfc2='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x321d2f='<html><body>'+_0x32dfc2+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x321d2f),this['myIFrame']['doc']['close']();}catch(_0x526650){L('frame\x20writing\x20exception'),_0x526650['stack']&&L(_0x526650['stack']),L(_0x526650);}}}static['createIFrame_'](){const _0x40934d=document['createElement']('iframe');if(_0x40934d['style']['display']='none',document['body']){document['body']['appendChild'](_0x40934d);try{_0x40934d['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x3c77cf=document['domain'];_0x40934d['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x3c77cf+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x40934d['contentDocument']?_0x40934d['doc']=_0x40934d['contentDocument']:_0x40934d['contentWindow']?_0x40934d['doc']=_0x40934d['contentWindow']['document']:_0x40934d['document']&&(_0x40934d['doc']=_0x40934d['document']),_0x40934d;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x210835=this['onDisconnect'];_0x210835&&(this['onDisconnect']=null,_0x210835());}['startLongPoll'](_0x35d706,_0x13ab5e){for(this['myID']=_0x35d706,this['myPW']=_0x13ab5e,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x49bf41={};_0x49bf41[Eo]=this['myID'],_0x49bf41[Io]=this['myPW'],_0x49bf41[wo]=this['currentSerial'];let _0x5d81bf=this['urlFn'](_0x49bf41),_0x1579ad='',_0x4eccaf=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x1579ad['length']<=Co;){const _0x3d5b30=this['pendingSegs']['shift']();_0x1579ad=_0x1579ad+'&'+lh+_0x4eccaf+'='+_0x3d5b30['seg']+'&'+hh+_0x4eccaf+'='+_0x3d5b30['ts']+'&'+uh+_0x4eccaf+'='+_0x3d5b30['d'],_0x4eccaf++;}return _0x5d81bf=_0x5d81bf+_0x1579ad,this['addLongPollTag_'](_0x5d81bf,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x281126,_0x27caa3,_0x5e19cb){this['pendingSegs']['push']({'seg':_0x281126,'ts':_0x27caa3,'d':_0x5e19cb}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x1f02ff,_0x49e56e){this['outstandingRequests']['add'](_0x49e56e);const _0x54cf3b=()=>{this['outstandingRequests']['delete'](_0x49e56e),this['newRequest_']();},_0x5eb692=setTimeout(_0x54cf3b,Math['floor'](ph)),_0x2c199d=()=>{clearTimeout(_0x5eb692),_0x54cf3b();};this['addTag'](_0x1f02ff,_0x2c199d);}['addTag'](_0x303d89,_0x523b96){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x46558a=this['myIFrame']['doc']['createElement']('script');_0x46558a['type']='text/javascript',_0x46558a['async']=!0x0,_0x46558a['src']=_0x303d89,_0x46558a['onload']=_0x46558a['onreadystatechange']=function(){const _0xfff518=_0x46558a['readyState'];(!_0xfff518||_0xfff518==='loaded'||_0xfff518==='complete')&&(_0x46558a['onload']=_0x46558a['onreadystatechange']=null,_0x46558a['parentNode']&&_0x46558a['parentNode']['removeChild'](_0x46558a),_0x523b96());},_0x46558a['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x303d89),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x46558a);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x2b27f2,_0x456bc4,_0x1eae4e,_0x2bb46d,_0x43dd74,_0x3d8ac8,_0x2bc1ba){this['connId']=_0x2b27f2,this['applicationId']=_0x1eae4e,this['appCheckToken']=_0x2bb46d,this['authToken']=_0x43dd74,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x456bc4),this['connURL']=q['connectionURL_'](_0x456bc4,_0x3d8ac8,_0x2bc1ba,_0x2bb46d,_0x1eae4e),this['nodeAdmin']=_0x456bc4['nodeAdmin'];}static['connectionURL_'](_0xbe4a57,_0x4a130c,_0x532722,_0x4b2fc7,_0x5102df){const _0x25b607={};return _0x25b607[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x25b607[ho]=uo),_0x4a130c&&(_0x25b607[lo]=_0x4a130c),_0x532722&&(_0x25b607[po]=_0x532722),_0x4b2fc7&&(_0x25b607[wi]=_0x4b2fc7),_0x5102df&&(_0x25b607[_o]=_0x5102df),vo(_0xbe4a57,go,_0x25b607);}['open'](_0x351432,_0x558615){this['onDisconnect']=_0x558615,this['onMessage']=_0x351432,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x92c28b;_c(),this['mySock']=new gn(this['connURL'],[],_0x92c28b);}catch(_0x1ba9bb){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x29f5f8=_0x1ba9bb['message']||_0x1ba9bb['data'];_0x29f5f8&&this['log_'](_0x29f5f8),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x17e0fa=>{this['handleIncomingFrame'](_0x17e0fa);},this['mySock']['onerror']=_0x1e7c6d=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x4f9d2a=_0x1e7c6d['message']||_0x1e7c6d['data'];_0x4f9d2a&&this['log_'](_0x4f9d2a),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x3e83ba=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x4d70ac=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x321d59=navigator['userAgent']['match'](_0x4d70ac);_0x321d59&&_0x321d59['length']>0x1&&parseFloat(_0x321d59[0x1])<4.4&&(_0x3e83ba=!0x0);}return!_0x3e83ba&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x2905c8){if(this['frames']['push'](_0x2905c8),this['frames']['length']===this['totalFrames']){const _0x5ab4bf=this['frames']['join']('');this['frames']=null;const _0x223df8=Nt(_0x5ab4bf);this['onMessage'](_0x223df8);}}['handleNewFrameCount_'](_0x1f8987){this['totalFrames']=_0x1f8987,this['frames']=[];}['extractFrameCount_'](_0x85db72){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x85db72['length']<=0x6){const _0x53fa37=Number(_0x85db72);if(!isNaN(_0x53fa37))return this['handleNewFrameCount_'](_0x53fa37),null;}return this['handleNewFrameCount_'](0x1),_0x85db72;}['handleIncomingFrame'](_0x2df94d){if(this['mySock']===null)return;const _0x4fbbc5=_0x2df94d['data'];if(this['bytesReceived']+=_0x4fbbc5['length'],this['stats_']['incrementCounter']('bytes_received',_0x4fbbc5['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x4fbbc5);else{const _0x45828e=this['extractFrameCount_'](_0x4fbbc5);_0x45828e!==null&&this['appendFrame_'](_0x45828e);}}['send'](_0x4942f1){this['resetKeepAlive']();const _0x39137c=O(_0x4942f1);this['bytesSent']+=_0x39137c['length'],this['stats_']['incrementCounter']('bytes_sent',_0x39137c['length']);const _0x2a9e61=oo(_0x39137c,gh);_0x2a9e61['length']>0x1&&this['sendString_'](String(_0x2a9e61['length']));for(let _0x4c1abf=0x0;_0x4c1abf<_0x2a9e61['length'];_0x4c1abf++)this['sendString_'](_0x2a9e61[_0x4c1abf]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x762600){try{this['mySock']['send'](_0x762600);}catch(_0x55fbb7){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x55fbb7['message']||_0x55fbb7['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x5360b7){this['initTransports_'](_0x5360b7);}['initTransports_'](_0x26d429){const _0x2fa0e0=q&&q['isAvailable']();let _0x5b2fc6=_0x2fa0e0&&!q['previouslyFailed']();if(_0x26d429['webSocketOnly']&&(_0x2fa0e0||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x5b2fc6=!0x0),_0x5b2fc6)this['transports_']=[q];else{const _0xc994db=this['transports_']=[];for(const _0x169801 of Dt['ALL_TRANSPORTS'])_0x169801&&_0x169801['isAvailable']()&&_0xc994db['push'](_0x169801);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x335d36,_0x51a12a,_0x10b51c,_0x3fdb4a,_0x4a4e,_0x3240b0,_0x2af03b,_0x4d8940,_0x49d599,_0x1a0e51){this['id']=_0x335d36,this['repoInfo_']=_0x51a12a,this['applicationId_']=_0x10b51c,this['appCheckToken_']=_0x3fdb4a,this['authToken_']=_0x4a4e,this['onMessage_']=_0x3240b0,this['onReady_']=_0x2af03b,this['onDisconnect_']=_0x4d8940,this['onKill_']=_0x49d599,this['lastSessionId']=_0x1a0e51,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x51a12a),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x3ea35c=this['transportManager_']['initialTransport']();this['conn_']=new _0x3ea35c(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x3ea35c['responsesRequiredToBeHealthy']||0x0;const _0x3eb3d6=this['connReceiver_'](this['conn_']),_0x1c9592=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x3eb3d6,_0x1c9592);},Math['floor'](0x0));const _0x3a0001=_0x3ea35c['healthyTimeout']||0x0;_0x3a0001>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x3a0001)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x2685f6){return _0x235f65=>{_0x2685f6===this['conn_']?this['onConnectionLost_'](_0x235f65):_0x2685f6===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x175ed6){return _0x5c249a=>{this['state_']!==0x2&&(_0x175ed6===this['rx_']?this['onPrimaryMessageReceived_'](_0x5c249a):_0x175ed6===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x5c249a):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x481274){const _0x1f920c={'t':'d','d':_0x481274};this['sendData_'](_0x1f920c);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x247348){if(ci in _0x247348){const _0x27c629=_0x247348[ci];_0x27c629===Ys?this['upgradeIfSecondaryHealthy_']():_0x27c629===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x27c629===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x176fe8){const _0x30bea7=vt('t',_0x176fe8),_0x5242d3=vt('d',_0x176fe8);if(_0x30bea7==='c')this['onSecondaryControl_'](_0x5242d3);else{if(_0x30bea7==='d')this['pendingDataMessages']['push'](_0x5242d3);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x30bea7);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x3bd374){const _0x76fb1b=vt('t',_0x3bd374),_0x4ad87d=vt('d',_0x3bd374);_0x76fb1b==='c'?this['onControl_'](_0x4ad87d):_0x76fb1b==='d'&&this['onDataMessage_'](_0x4ad87d);}['onDataMessage_'](_0x7cd83b){this['onPrimaryResponse_'](),this['onMessage_'](_0x7cd83b);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x1c5fca){const _0x36dcb9=vt(ci,_0x1c5fca);if(zs in _0x1c5fca){const _0x20c471=_0x1c5fca[zs];if(_0x36dcb9===Th){const _0x2574b1={..._0x20c471};this['repoInfo_']['isUsingEmulator']&&(_0x2574b1['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x2574b1);}else{if(_0x36dcb9===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x2cbbe2=0x0;_0x2cbbe2<this['pendingDataMessages']['length'];++_0x2cbbe2)this['onDataMessage_'](this['pendingDataMessages'][_0x2cbbe2]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x36dcb9===wh?this['onConnectionShutdown_'](_0x20c471):_0x36dcb9===js?this['onReset_'](_0x20c471):_0x36dcb9===Ch?Ii('Server\x20Error:\x20'+_0x20c471):_0x36dcb9===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x36dcb9);}}}['onHandshake_'](_0x32bf77){const _0x4c5c9d=_0x32bf77['ts'],_0x1a8ea7=_0x32bf77['v'],_0x1fde8a=_0x32bf77['h'];this['sessionId']=_0x32bf77['s'],this['repoInfo_']['host']=_0x1fde8a,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x4c5c9d),Gi!==_0x1a8ea7&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x2bc017=this['transportManager_']['upgradeTransport']();_0x2bc017&&this['startUpgrade_'](_0x2bc017);}['startUpgrade_'](_0x29c94e){this['secondaryConn_']=new _0x29c94e(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x29c94e['responsesRequiredToBeHealthy']||0x0;const _0xc2fa22=this['connReceiver_'](this['secondaryConn_']),_0x448bc3=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0xc2fa22,_0x448bc3),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x14f5ac){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x14f5ac),this['repoInfo_']['host']=_0x14f5ac,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x17e91d,_0x4f32d0){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x17e91d,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x4f32d0,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x9113cb=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x9113cb||this['rx_']===_0x9113cb)&&this['close']();}['onConnectionLost_'](_0x404b78){this['conn_']=null,!_0x404b78&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x501409){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x501409),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x3d7e81){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x3d7e81);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x2a6699,_0x35c744,_0x205ec7,_0x1e3bb0){}['merge'](_0x3a5835,_0x17849d,_0xd09363,_0x17f53e){}['refreshAuthToken'](_0x4df622){}['refreshAppCheckToken'](_0x473142){}['onDisconnectPut'](_0x199721,_0x29ac64,_0x501a08){}['onDisconnectMerge'](_0x5d28c7,_0x2e2e7b,_0x4cb643){}['onDisconnectCancel'](_0x5acc4d,_0x28293a){}['reportStats'](_0x2f96b0){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x186107){this['allowedEvents_']=_0x186107,this['listeners_']={},f(Array['isArray'](_0x186107)&&_0x186107['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x1bc5fd,..._0x38889b){if(Array['isArray'](this['listeners_'][_0x1bc5fd])){const _0x37c015=[...this['listeners_'][_0x1bc5fd]];for(let _0x58e26e=0x0;_0x58e26e<_0x37c015['length'];_0x58e26e++)_0x37c015[_0x58e26e]['callback']['apply'](_0x37c015[_0x58e26e]['context'],_0x38889b);}}['on'](_0x447fd8,_0x3add5c,_0xa69f3b){this['validateEventType_'](_0x447fd8),this['listeners_'][_0x447fd8]=this['listeners_'][_0x447fd8]||[],this['listeners_'][_0x447fd8]['push']({'callback':_0x3add5c,'context':_0xa69f3b});const _0x3d22ac=this['getInitialEvent'](_0x447fd8);_0x3d22ac&&_0x3add5c['apply'](_0xa69f3b,_0x3d22ac);}['off'](_0x55fab2,_0x5d181f,_0x44bd05){this['validateEventType_'](_0x55fab2);const _0x4ecd79=this['listeners_'][_0x55fab2]||[];for(let _0x503eb0=0x0;_0x503eb0<_0x4ecd79['length'];_0x503eb0++)if(_0x4ecd79[_0x503eb0]['callback']===_0x5d181f&&(!_0x44bd05||_0x44bd05===_0x4ecd79[_0x503eb0]['context'])){_0x4ecd79['splice'](_0x503eb0,0x1);return;}}['validateEventType_'](_0x346165){f(this['allowedEvents_']['find'](_0x5ef069=>_0x5ef069===_0x346165),'Unknown\x20event:\x20'+_0x346165);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x1cad71){return f(_0x1cad71==='online','Unknown\x20event\x20type:\x20'+_0x1cad71),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x51d001,_0x42cfbb){if(_0x42cfbb===void 0x0){this['pieces_']=_0x51d001['split']('/');let _0x44a3ec=0x0;for(let _0x27c114=0x0;_0x27c114<this['pieces_']['length'];_0x27c114++)this['pieces_'][_0x27c114]['length']>0x0&&(this['pieces_'][_0x44a3ec]=this['pieces_'][_0x27c114],_0x44a3ec++);this['pieces_']['length']=_0x44a3ec,this['pieceNum_']=0x0;}else this['pieces_']=_0x51d001,this['pieceNum_']=_0x42cfbb;}['toString'](){let _0x1564db='';for(let _0x4a1ae8=this['pieceNum_'];_0x4a1ae8<this['pieces_']['length'];_0x4a1ae8++)this['pieces_'][_0x4a1ae8]!==''&&(_0x1564db+='/'+this['pieces_'][_0x4a1ae8]);return _0x1564db||'/';}}function w(){return new C('');}function y(_0x182c9e){return _0x182c9e['pieceNum_']>=_0x182c9e['pieces_']['length']?null:_0x182c9e['pieces_'][_0x182c9e['pieceNum_']];}function Ce(_0x311a1e){return _0x311a1e['pieces_']['length']-_0x311a1e['pieceNum_'];}function S(_0x5eeee1){let _0x545120=_0x5eeee1['pieceNum_'];return _0x545120<_0x5eeee1['pieces_']['length']&&_0x545120++,new C(_0x5eeee1['pieces_'],_0x545120);}function ji(_0x31fd5b){return _0x31fd5b['pieceNum_']<_0x31fd5b['pieces_']['length']?_0x31fd5b['pieces_'][_0x31fd5b['pieces_']['length']-0x1]:null;}function bh(_0x24486a){let _0x48d942='';for(let _0x282df8=_0x24486a['pieceNum_'];_0x282df8<_0x24486a['pieces_']['length'];_0x282df8++)_0x24486a['pieces_'][_0x282df8]!==''&&(_0x48d942+='/'+encodeURIComponent(String(_0x24486a['pieces_'][_0x282df8])));return _0x48d942||'/';}function Mt(_0x545d08,_0x1855a0=0x0){return _0x545d08['pieces_']['slice'](_0x545d08['pieceNum_']+_0x1855a0);}function Ro(_0x1fd40d){if(_0x1fd40d['pieceNum_']>=_0x1fd40d['pieces_']['length'])return null;const _0x154d4f=[];for(let _0x5f317b=_0x1fd40d['pieceNum_'];_0x5f317b<_0x1fd40d['pieces_']['length']-0x1;_0x5f317b++)_0x154d4f['push'](_0x1fd40d['pieces_'][_0x5f317b]);return new C(_0x154d4f,0x0);}function k(_0x4ebdc7,_0x483363){const _0xc6181c=[];for(let _0x39b6a4=_0x4ebdc7['pieceNum_'];_0x39b6a4<_0x4ebdc7['pieces_']['length'];_0x39b6a4++)_0xc6181c['push'](_0x4ebdc7['pieces_'][_0x39b6a4]);if(_0x483363 instanceof C){for(let _0x3068b7=_0x483363['pieceNum_'];_0x3068b7<_0x483363['pieces_']['length'];_0x3068b7++)_0xc6181c['push'](_0x483363['pieces_'][_0x3068b7]);}else{const _0x53a940=_0x483363['split']('/');for(let _0x17c856=0x0;_0x17c856<_0x53a940['length'];_0x17c856++)_0x53a940[_0x17c856]['length']>0x0&&_0xc6181c['push'](_0x53a940[_0x17c856]);}return new C(_0xc6181c,0x0);}function v(_0x3c07b2){return _0x3c07b2['pieceNum_']>=_0x3c07b2['pieces_']['length'];}function F(_0x58bf8f,_0x59039e){const _0x2b3b12=y(_0x58bf8f),_0x2416ce=y(_0x59039e);if(_0x2b3b12===null)return _0x59039e;if(_0x2b3b12===_0x2416ce)return F(S(_0x58bf8f),S(_0x59039e));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x59039e+')\x20is\x20not\x20within\x20outerPath\x20('+_0x58bf8f+')');}function Rh(_0x520596,_0xdc5e3e){const _0x573c8e=Mt(_0x520596,0x0),_0x914c9f=Mt(_0xdc5e3e,0x0);for(let _0x4e2295=0x0;_0x4e2295<_0x573c8e['length']&&_0x4e2295<_0x914c9f['length'];_0x4e2295++){const _0x59a117=qe(_0x573c8e[_0x4e2295],_0x914c9f[_0x4e2295]);if(_0x59a117!==0x0)return _0x59a117;}return _0x573c8e['length']===_0x914c9f['length']?0x0:_0x573c8e['length']<_0x914c9f['length']?-0x1:0x1;}function Ki(_0x5e0e4d,_0x2ae874){if(Ce(_0x5e0e4d)!==Ce(_0x2ae874))return!0x1;for(let _0xf1b57b=_0x5e0e4d['pieceNum_'],_0x5b3b44=_0x2ae874['pieceNum_'];_0xf1b57b<=_0x5e0e4d['pieces_']['length'];_0xf1b57b++,_0x5b3b44++)if(_0x5e0e4d['pieces_'][_0xf1b57b]!==_0x2ae874['pieces_'][_0x5b3b44])return!0x1;return!0x0;}function G(_0x23bb8f,_0x58ac86){let _0x4b21bc=_0x23bb8f['pieceNum_'],_0x1d81ff=_0x58ac86['pieceNum_'];if(Ce(_0x23bb8f)>Ce(_0x58ac86))return!0x1;for(;_0x4b21bc<_0x23bb8f['pieces_']['length'];){if(_0x23bb8f['pieces_'][_0x4b21bc]!==_0x58ac86['pieces_'][_0x1d81ff])return!0x1;++_0x4b21bc,++_0x1d81ff;}return!0x0;}class Ah{constructor(_0x3395da,_0x24d098){this['errorPrefix_']=_0x24d098,this['parts_']=Mt(_0x3395da,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x42bb7e=0x0;_0x42bb7e<this['parts_']['length'];_0x42bb7e++)this['byteLength_']+=Ln(this['parts_'][_0x42bb7e]);Ao(this);}}function kh(_0x1af51e,_0x108034){_0x1af51e['parts_']['length']>0x0&&(_0x1af51e['byteLength_']+=0x1),_0x1af51e['parts_']['push'](_0x108034),_0x1af51e['byteLength_']+=Ln(_0x108034),Ao(_0x1af51e);}function Ph(_0x3ba67a){const _0x237c1c=_0x3ba67a['parts_']['pop']();_0x3ba67a['byteLength_']-=Ln(_0x237c1c),_0x3ba67a['parts_']['length']>0x0&&(_0x3ba67a['byteLength_']-=0x1);}function Ao(_0x48865b){if(_0x48865b['byteLength_']>Zs)throw new Error(_0x48865b['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x48865b['byteLength_']+').');if(_0x48865b['parts_']['length']>Xs)throw new Error(_0x48865b['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x48865b));}function Oe(_0x4262ed){return _0x4262ed['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x4262ed['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x1a9b2b,_0x473603;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x473603='visibilitychange',_0x1a9b2b='hidden'):typeof document['mozHidden']<'u'?(_0x473603='mozvisibilitychange',_0x1a9b2b='mozHidden'):typeof document['msHidden']<'u'?(_0x473603='msvisibilitychange',_0x1a9b2b='msHidden'):typeof document['webkitHidden']<'u'&&(_0x473603='webkitvisibilitychange',_0x1a9b2b='webkitHidden')),this['visible_']=!0x0,_0x473603&&document['addEventListener'](_0x473603,()=>{const _0x587901=!document[_0x1a9b2b];_0x587901!==this['visible_']&&(this['visible_']=_0x587901,this['trigger']('visible',_0x587901));},!0x1);}['getInitialEvent'](_0x55731d){return f(_0x55731d==='visible','Unknown\x20event\x20type:\x20'+_0x55731d),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x53682b,_0x4be120,_0x5b4aa0,_0x4827a1,_0x69c807,_0x32a8b0,_0x2a2a5b,_0x4bd520){if(super(),this['repoInfo_']=_0x53682b,this['applicationId_']=_0x4be120,this['onDataUpdate_']=_0x5b4aa0,this['onConnectStatus_']=_0x4827a1,this['onServerInfoUpdate_']=_0x69c807,this['authTokenProvider_']=_0x32a8b0,this['appCheckTokenProvider_']=_0x2a2a5b,this['authOverride_']=_0x4bd520,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x4bd520)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x53682b['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x5dfa65,_0x3f51ab,_0x1e5db4){const _0x18ae03=++this['requestNumber_'],_0x5b3366={'r':_0x18ae03,'a':_0x5dfa65,'b':_0x3f51ab};this['log_'](O(_0x5b3366)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x5b3366),_0x1e5db4&&(this['requestCBHash_'][_0x18ae03]=_0x1e5db4);}['get'](_0x3b699e){this['initConnection_']();const _0x29b95d=new H(),_0x19cc41={'action':'g','request':{'p':_0x3b699e['_path']['toString'](),'q':_0x3b699e['_queryObject']},'onComplete':_0x16a8c8=>{const _0x1f5f0b=_0x16a8c8['d'];_0x16a8c8['s']==='ok'?_0x29b95d['resolve'](_0x1f5f0b):_0x29b95d['reject'](_0x1f5f0b);}};this['outstandingGets_']['push'](_0x19cc41),this['outstandingGetCount_']++;const _0x42bebd=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x42bebd),_0x29b95d['promise'];}['listen'](_0xe30e02,_0x3c8ec6,_0x1f216b,_0x4b50f1){this['initConnection_']();const _0x3a1b37=_0xe30e02['_queryIdentifier'],_0x40bfc5=_0xe30e02['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x40bfc5+'\x20'+_0x3a1b37),this['listens']['has'](_0x40bfc5)||this['listens']['set'](_0x40bfc5,new Map()),f(_0xe30e02['_queryParams']['isDefault']()||!_0xe30e02['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x40bfc5)['has'](_0x3a1b37),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x1dd4ec={'onComplete':_0x4b50f1,'hashFn':_0x3c8ec6,'query':_0xe30e02,'tag':_0x1f216b};this['listens']['get'](_0x40bfc5)['set'](_0x3a1b37,_0x1dd4ec),this['connected_']&&this['sendListen_'](_0x1dd4ec);}['sendGet_'](_0x23c4b1){const _0xe183f8=this['outstandingGets_'][_0x23c4b1];this['sendRequest']('g',_0xe183f8['request'],_0x5c9714=>{delete this['outstandingGets_'][_0x23c4b1],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0xe183f8['onComplete']&&_0xe183f8['onComplete'](_0x5c9714);});}['sendListen_'](_0x419bf3){const _0x123081=_0x419bf3['query'],_0x5ec3c8=_0x123081['_path']['toString'](),_0x4cc16c=_0x123081['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x5ec3c8+'\x20for\x20'+_0x4cc16c);const _0x1922a4={'p':_0x5ec3c8},_0x45d217='q';_0x419bf3['tag']&&(_0x1922a4['q']=_0x123081['_queryObject'],_0x1922a4['t']=_0x419bf3['tag']),_0x1922a4['h']=_0x419bf3['hashFn'](),this['sendRequest'](_0x45d217,_0x1922a4,_0x5e5938=>{const _0x4904bd=_0x5e5938['d'],_0x5de3e6=_0x5e5938['s'];se['warnOnListenWarnings_'](_0x4904bd,_0x123081),(this['listens']['get'](_0x5ec3c8)&&this['listens']['get'](_0x5ec3c8)['get'](_0x4cc16c))===_0x419bf3&&(this['log_']('listen\x20response',_0x5e5938),_0x5de3e6!=='ok'&&this['removeListen_'](_0x5ec3c8,_0x4cc16c),_0x419bf3['onComplete']&&_0x419bf3['onComplete'](_0x5de3e6,_0x4904bd));});}static['warnOnListenWarnings_'](_0x4d8618,_0x14611f){if(_0x4d8618&&typeof _0x4d8618=='object'&&Q(_0x4d8618,'w')){const _0x32d1d5=Le(_0x4d8618,'w');if(Array['isArray'](_0x32d1d5)&&~_0x32d1d5['indexOf']('no_index')){const _0x539819='\x22.indexOn\x22:\x20\x22'+_0x14611f['_queryParams']['getIndex']()['toString']()+'\x22',_0x4f6920=_0x14611f['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x539819+'\x20at\x20'+_0x4f6920+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x41d363){this['authToken_']=_0x41d363,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x41d363);}['reduceReconnectDelayIfAdminCredential_'](_0x35dc8d){(_0x35dc8d&&_0x35dc8d['length']===0x28||wc(_0x35dc8d))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x2c332a){this['appCheckToken_']=_0x2c332a,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x9150af=this['authToken_'],_0x2884d4=Ic(_0x9150af)?'auth':'gauth',_0x349ebc={'cred':_0x9150af};this['authOverride_']===null?_0x349ebc['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x349ebc['authvar']=this['authOverride_']),this['sendRequest'](_0x2884d4,_0x349ebc,_0xcc9fc5=>{const _0x55996f=_0xcc9fc5['s'],_0x2ea817=_0xcc9fc5['d']||'error';this['authToken_']===_0x9150af&&(_0x55996f==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x55996f,_0x2ea817));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x5af485=>{const _0x32a768=_0x5af485['s'],_0x3df3ae=_0x5af485['d']||'error';_0x32a768==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x32a768,_0x3df3ae);});}['unlisten'](_0x119d41,_0x27126b){const _0x571bbf=_0x119d41['_path']['toString'](),_0x4f1a2=_0x119d41['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x571bbf+'\x20'+_0x4f1a2),f(_0x119d41['_queryParams']['isDefault']()||!_0x119d41['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x571bbf,_0x4f1a2)&&this['connected_']&&this['sendUnlisten_'](_0x571bbf,_0x4f1a2,_0x119d41['_queryObject'],_0x27126b);}['sendUnlisten_'](_0xa78340,_0x2d9ebe,_0x1167dc,_0x137563){this['log_']('Unlisten\x20on\x20'+_0xa78340+'\x20for\x20'+_0x2d9ebe);const _0x2d1615={'p':_0xa78340},_0x2e9f95='n';_0x137563&&(_0x2d1615['q']=_0x1167dc,_0x2d1615['t']=_0x137563),this['sendRequest'](_0x2e9f95,_0x2d1615);}['onDisconnectPut'](_0x193959,_0x511e64,_0x187493){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x193959,_0x511e64,_0x187493):this['onDisconnectRequestQueue_']['push']({'pathString':_0x193959,'action':'o','data':_0x511e64,'onComplete':_0x187493});}['onDisconnectMerge'](_0x417a3f,_0x36fec2,_0x24ed19){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x417a3f,_0x36fec2,_0x24ed19):this['onDisconnectRequestQueue_']['push']({'pathString':_0x417a3f,'action':'om','data':_0x36fec2,'onComplete':_0x24ed19});}['onDisconnectCancel'](_0x3e8b04,_0x495ebf){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x3e8b04,null,_0x495ebf):this['onDisconnectRequestQueue_']['push']({'pathString':_0x3e8b04,'action':'oc','data':null,'onComplete':_0x495ebf});}['sendOnDisconnect_'](_0x38e8a3,_0x11d6b9,_0x3a23bc,_0x13edab){const _0x232d80={'p':_0x11d6b9,'d':_0x3a23bc};this['log_']('onDisconnect\x20'+_0x38e8a3,_0x232d80),this['sendRequest'](_0x38e8a3,_0x232d80,_0x960835=>{_0x13edab&&setTimeout(()=>{_0x13edab(_0x960835['s'],_0x960835['d']);},Math['floor'](0x0));});}['put'](_0x77867d,_0x25f64c,_0x56dba4,_0x22ba09){this['putInternal']('p',_0x77867d,_0x25f64c,_0x56dba4,_0x22ba09);}['merge'](_0x5a0fbc,_0x559970,_0x52e4bc,_0x59c015){this['putInternal']('m',_0x5a0fbc,_0x559970,_0x52e4bc,_0x59c015);}['putInternal'](_0x41e56c,_0xe90b2c,_0x18935d,_0x2dcad9,_0x150da4){this['initConnection_']();const _0x501543={'p':_0xe90b2c,'d':_0x18935d};_0x150da4!==void 0x0&&(_0x501543['h']=_0x150da4),this['outstandingPuts_']['push']({'action':_0x41e56c,'request':_0x501543,'onComplete':_0x2dcad9}),this['outstandingPutCount_']++;const _0x440103=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x440103):this['log_']('Buffering\x20put:\x20'+_0xe90b2c);}['sendPut_'](_0x441917){const _0x349536=this['outstandingPuts_'][_0x441917]['action'],_0x1b20b5=this['outstandingPuts_'][_0x441917]['request'],_0x3fa11b=this['outstandingPuts_'][_0x441917]['onComplete'];this['outstandingPuts_'][_0x441917]['queued']=this['connected_'],this['sendRequest'](_0x349536,_0x1b20b5,_0x6b1ef9=>{this['log_'](_0x349536+'\x20response',_0x6b1ef9),delete this['outstandingPuts_'][_0x441917],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x3fa11b&&_0x3fa11b(_0x6b1ef9['s'],_0x6b1ef9['d']);});}['reportStats'](_0x3df835){if(this['connected_']){const _0x4b683a={'c':_0x3df835};this['log_']('reportStats',_0x4b683a),this['sendRequest']('s',_0x4b683a,_0x1d33ad=>{if(_0x1d33ad['s']!=='ok'){const _0x14be87=_0x1d33ad['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x14be87);}});}}['onDataMessage_'](_0x362ce3){if('r'in _0x362ce3){this['log_']('from\x20server:\x20'+O(_0x362ce3));const _0x231609=_0x362ce3['r'],_0x58e30b=this['requestCBHash_'][_0x231609];_0x58e30b&&(delete this['requestCBHash_'][_0x231609],_0x58e30b(_0x362ce3['b']));}else{if('error'in _0x362ce3)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x362ce3['error'];'a'in _0x362ce3&&this['onDataPush_'](_0x362ce3['a'],_0x362ce3['b']);}}['onDataPush_'](_0x432fbb,_0x15feea){this['log_']('handleServerMessage',_0x432fbb,_0x15feea),_0x432fbb==='d'?this['onDataUpdate_'](_0x15feea['p'],_0x15feea['d'],!0x1,_0x15feea['t']):_0x432fbb==='m'?this['onDataUpdate_'](_0x15feea['p'],_0x15feea['d'],!0x0,_0x15feea['t']):_0x432fbb==='c'?this['onListenRevoked_'](_0x15feea['p'],_0x15feea['q']):_0x432fbb==='ac'?this['onAuthRevoked_'](_0x15feea['s'],_0x15feea['d']):_0x432fbb==='apc'?this['onAppCheckRevoked_'](_0x15feea['s'],_0x15feea['d']):_0x432fbb==='sd'?this['onSecurityDebugPacket_'](_0x15feea):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x432fbb)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x562af7,_0x439a5c){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x562af7),this['lastSessionId']=_0x439a5c,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x22ca0f){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x22ca0f));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x27caf1){_0x27caf1&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x27caf1;}['onOnline_'](_0x33251b){_0x33251b?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x42faae=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x5c56d8=Math['max'](0x0,this['reconnectDelay_']-_0x42faae);_0x5c56d8=Math['random']()*_0x5c56d8,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x5c56d8+'ms'),this['scheduleConnect_'](_0x5c56d8),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x4709eb=this['onDataMessage_']['bind'](this),_0x51af7e=this['onReady_']['bind'](this),_0x4ed1fe=this['onRealtimeDisconnect_']['bind'](this),_0x87a4fa=this['id']+':'+se['nextConnectionId_']++,_0x11b6dd=this['lastSessionId'];let _0x292ae0=!0x1,_0x4d07be=null;const _0x5f52a4=function(){_0x4d07be?_0x4d07be['close']():(_0x292ae0=!0x0,_0x4ed1fe());},_0x233961=function(_0x49edbf){f(_0x4d07be,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x4d07be['sendRequest'](_0x49edbf);};this['realtime_']={'close':_0x5f52a4,'sendRequest':_0x233961};const _0x18b5d0=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x168df8,_0x38d712]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x18b5d0),this['appCheckTokenProvider_']['getToken'](_0x18b5d0)]);_0x292ae0?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x168df8&&_0x168df8['accessToken'],this['appCheckToken_']=_0x38d712&&_0x38d712['token'],_0x4d07be=new Sh(_0x87a4fa,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x4709eb,_0x51af7e,_0x4ed1fe,_0x5f30c9=>{U(_0x5f30c9+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x11b6dd));}catch(_0x5ef2a4){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x5ef2a4),_0x292ae0||(this['repoInfo_']['nodeAdmin']&&U(_0x5ef2a4),_0x5f52a4());}}}['interrupt'](_0x4d6c0b){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x4d6c0b),this['interruptReasons_'][_0x4d6c0b]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x246562){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x246562),delete this['interruptReasons_'][_0x246562],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x5ebff1){const _0x2103de=_0x5ebff1-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x2103de});}['cancelSentTransactions_'](){for(let _0x258378=0x0;_0x258378<this['outstandingPuts_']['length'];_0x258378++){const _0x536445=this['outstandingPuts_'][_0x258378];_0x536445&&'h'in _0x536445['request']&&_0x536445['queued']&&(_0x536445['onComplete']&&_0x536445['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x258378],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0xd8d812,_0x40d34c){let _0x43a3b7;_0x40d34c?_0x43a3b7=_0x40d34c['map'](_0x49dfa7=>$i(_0x49dfa7))['join']('$'):_0x43a3b7='default';const _0x2a4beb=this['removeListen_'](_0xd8d812,_0x43a3b7);_0x2a4beb&&_0x2a4beb['onComplete']&&_0x2a4beb['onComplete']('permission_denied');}['removeListen_'](_0x247b3c,_0x52b7b0){const _0x1f4c8b=new C(_0x247b3c)['toString']();let _0x492774;if(this['listens']['has'](_0x1f4c8b)){const _0x4da260=this['listens']['get'](_0x1f4c8b);_0x492774=_0x4da260['get'](_0x52b7b0),_0x4da260['delete'](_0x52b7b0),_0x4da260['size']===0x0&&this['listens']['delete'](_0x1f4c8b);}else _0x492774=void 0x0;return _0x492774;}['onAuthRevoked_'](_0x8c1991,_0x3c1564){L('Auth\x20token\x20revoked:\x20'+_0x8c1991+'/'+_0x3c1564),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x8c1991==='invalid_token'||_0x8c1991==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x416680,_0x3c8f15){L('App\x20check\x20token\x20revoked:\x20'+_0x416680+'/'+_0x3c8f15),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x416680==='invalid_token'||_0x416680==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x71fa1d){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x71fa1d):'msg'in _0x71fa1d&&console['log']('FIREBASE:\x20'+_0x71fa1d['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x20d122 of this['listens']['values']())for(const _0x5c2fe5 of _0x20d122['values']())this['sendListen_'](_0x5c2fe5);for(let _0x370c75=0x0;_0x370c75<this['outstandingPuts_']['length'];_0x370c75++)this['outstandingPuts_'][_0x370c75]&&this['sendPut_'](_0x370c75);for(;this['onDisconnectRequestQueue_']['length'];){const _0x145036=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x145036['action'],_0x145036['pathString'],_0x145036['data'],_0x145036['onComplete']);}for(let _0x5429f7=0x0;_0x5429f7<this['outstandingGets_']['length'];_0x5429f7++)this['outstandingGets_'][_0x5429f7]&&this['sendGet_'](_0x5429f7);}['sendConnectStats_'](){const _0x196b5c={};let _0x1c7a6e='js';_0x196b5c['sdk.'+_0x1c7a6e+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x196b5c['framework.cordova']=0x1:Kr()&&(_0x196b5c['framework.reactnative']=0x1),this['reportStats'](_0x196b5c);}['shouldReconnect_'](){const _0x712022=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x712022;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x322a83,_0x12be86){this['name']=_0x322a83,this['node']=_0x12be86;}static['Wrap'](_0x2d319e,_0x3fe27b){return new E(_0x2d319e,_0x3fe27b);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0xb2f5cb,_0xde97c7){const _0x13791d=new E(We,_0xb2f5cb),_0x232b75=new E(We,_0xde97c7);return this['compare'](_0x13791d,_0x232b75)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x5c3eb4){sn=_0x5c3eb4;}['compare'](_0x400779,_0x5eca47){return qe(_0x400779['name'],_0x5eca47['name']);}['isDefinedOn'](_0xe5c8a8){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x1e1cc6,_0x3af2f7){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x164690,_0x1c9326){return f(typeof _0x164690=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x164690,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x289e80,_0x4d2b93,_0x1317c8,_0xc7087f,_0x346425=null){this['isReverse_']=_0xc7087f,this['resultGenerator_']=_0x346425,this['nodeStack_']=[];let _0x411276=0x1;for(;!_0x289e80['isEmpty']();)if(_0x289e80=_0x289e80,_0x411276=_0x4d2b93?_0x1317c8(_0x289e80['key'],_0x4d2b93):0x1,_0xc7087f&&(_0x411276*=-0x1),_0x411276<0x0)this['isReverse_']?_0x289e80=_0x289e80['left']:_0x289e80=_0x289e80['right'];else{if(_0x411276===0x0){this['nodeStack_']['push'](_0x289e80);break;}else this['nodeStack_']['push'](_0x289e80),this['isReverse_']?_0x289e80=_0x289e80['right']:_0x289e80=_0x289e80['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x5170c6=this['nodeStack_']['pop'](),_0x331bcc;if(this['resultGenerator_']?_0x331bcc=this['resultGenerator_'](_0x5170c6['key'],_0x5170c6['value']):_0x331bcc={'key':_0x5170c6['key'],'value':_0x5170c6['value']},this['isReverse_']){for(_0x5170c6=_0x5170c6['left'];!_0x5170c6['isEmpty']();)this['nodeStack_']['push'](_0x5170c6),_0x5170c6=_0x5170c6['right'];}else{for(_0x5170c6=_0x5170c6['right'];!_0x5170c6['isEmpty']();)this['nodeStack_']['push'](_0x5170c6),_0x5170c6=_0x5170c6['left'];}return _0x331bcc;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x1a37cf=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x1a37cf['key'],_0x1a37cf['value']):{'key':_0x1a37cf['key'],'value':_0x1a37cf['value']};}}class M{constructor(_0x409808,_0x106c3b,_0x3cbdaf,_0x23aa47,_0xadc08){this['key']=_0x409808,this['value']=_0x106c3b,this['color']=_0x3cbdaf??M['RED'],this['left']=_0x23aa47??B['EMPTY_NODE'],this['right']=_0xadc08??B['EMPTY_NODE'];}['copy'](_0x3639fe,_0xa5eabd,_0x1e5f0b,_0xc89a9b,_0x2f8974){return new M(_0x3639fe??this['key'],_0xa5eabd??this['value'],_0x1e5f0b??this['color'],_0xc89a9b??this['left'],_0x2f8974??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x4c931c){return this['left']['inorderTraversal'](_0x4c931c)||!!_0x4c931c(this['key'],this['value'])||this['right']['inorderTraversal'](_0x4c931c);}['reverseTraversal'](_0x12e0eb){return this['right']['reverseTraversal'](_0x12e0eb)||_0x12e0eb(this['key'],this['value'])||this['left']['reverseTraversal'](_0x12e0eb);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x4ba3e4,_0x3ee2dc,_0x39c45f){let _0x4f8f33=this;const _0x502505=_0x39c45f(_0x4ba3e4,_0x4f8f33['key']);return _0x502505<0x0?_0x4f8f33=_0x4f8f33['copy'](null,null,null,_0x4f8f33['left']['insert'](_0x4ba3e4,_0x3ee2dc,_0x39c45f),null):_0x502505===0x0?_0x4f8f33=_0x4f8f33['copy'](null,_0x3ee2dc,null,null,null):_0x4f8f33=_0x4f8f33['copy'](null,null,null,null,_0x4f8f33['right']['insert'](_0x4ba3e4,_0x3ee2dc,_0x39c45f)),_0x4f8f33['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x3129fb=this;return!_0x3129fb['left']['isRed_']()&&!_0x3129fb['left']['left']['isRed_']()&&(_0x3129fb=_0x3129fb['moveRedLeft_']()),_0x3129fb=_0x3129fb['copy'](null,null,null,_0x3129fb['left']['removeMin_'](),null),_0x3129fb['fixUp_']();}['remove'](_0x13e4c6,_0x1974ae){let _0x327550,_0x57b9fc;if(_0x327550=this,_0x1974ae(_0x13e4c6,_0x327550['key'])<0x0)!_0x327550['left']['isEmpty']()&&!_0x327550['left']['isRed_']()&&!_0x327550['left']['left']['isRed_']()&&(_0x327550=_0x327550['moveRedLeft_']()),_0x327550=_0x327550['copy'](null,null,null,_0x327550['left']['remove'](_0x13e4c6,_0x1974ae),null);else{if(_0x327550['left']['isRed_']()&&(_0x327550=_0x327550['rotateRight_']()),!_0x327550['right']['isEmpty']()&&!_0x327550['right']['isRed_']()&&!_0x327550['right']['left']['isRed_']()&&(_0x327550=_0x327550['moveRedRight_']()),_0x1974ae(_0x13e4c6,_0x327550['key'])===0x0){if(_0x327550['right']['isEmpty']())return B['EMPTY_NODE'];_0x57b9fc=_0x327550['right']['min_'](),_0x327550=_0x327550['copy'](_0x57b9fc['key'],_0x57b9fc['value'],null,null,_0x327550['right']['removeMin_']());}_0x327550=_0x327550['copy'](null,null,null,null,_0x327550['right']['remove'](_0x13e4c6,_0x1974ae));}return _0x327550['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x533df5=this;return _0x533df5['right']['isRed_']()&&!_0x533df5['left']['isRed_']()&&(_0x533df5=_0x533df5['rotateLeft_']()),_0x533df5['left']['isRed_']()&&_0x533df5['left']['left']['isRed_']()&&(_0x533df5=_0x533df5['rotateRight_']()),_0x533df5['left']['isRed_']()&&_0x533df5['right']['isRed_']()&&(_0x533df5=_0x533df5['colorFlip_']()),_0x533df5;}['moveRedLeft_'](){let _0x489a62=this['colorFlip_']();return _0x489a62['right']['left']['isRed_']()&&(_0x489a62=_0x489a62['copy'](null,null,null,null,_0x489a62['right']['rotateRight_']()),_0x489a62=_0x489a62['rotateLeft_'](),_0x489a62=_0x489a62['colorFlip_']()),_0x489a62;}['moveRedRight_'](){let _0x5b1ed5=this['colorFlip_']();return _0x5b1ed5['left']['left']['isRed_']()&&(_0x5b1ed5=_0x5b1ed5['rotateRight_'](),_0x5b1ed5=_0x5b1ed5['colorFlip_']()),_0x5b1ed5;}['rotateLeft_'](){const _0x3d1896=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x3d1896,null);}['rotateRight_'](){const _0x10aa7b=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x10aa7b);}['colorFlip_'](){const _0x466164=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x4327f7=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x466164,_0x4327f7);}['checkMaxDepth_'](){const _0x4ccdd3=this['check_']();return Math['pow'](0x2,_0x4ccdd3)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0xd47b0f=this['left']['check_']();if(_0xd47b0f!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0xd47b0f+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0xf9b989,_0x5cd210,_0x27703a,_0x4e23e3,_0x258d44){return this;}['insert'](_0x9ec492,_0x31eb71,_0x2394c6){return new M(_0x9ec492,_0x31eb71,null);}['remove'](_0x43ea54,_0x224fc2){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x38ae51){return!0x1;}['reverseTraversal'](_0x275e57){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x27de36,_0x4352a6=B['EMPTY_NODE']){this['comparator_']=_0x27de36,this['root_']=_0x4352a6;}['insert'](_0x52b566,_0x4a9325){return new B(this['comparator_'],this['root_']['insert'](_0x52b566,_0x4a9325,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x46cc50){return new B(this['comparator_'],this['root_']['remove'](_0x46cc50,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x500504){let _0x94d6e1,_0x399ec0=this['root_'];for(;!_0x399ec0['isEmpty']();){if(_0x94d6e1=this['comparator_'](_0x500504,_0x399ec0['key']),_0x94d6e1===0x0)return _0x399ec0['value'];_0x94d6e1<0x0?_0x399ec0=_0x399ec0['left']:_0x94d6e1>0x0&&(_0x399ec0=_0x399ec0['right']);}return null;}['getPredecessorKey'](_0x4308dc){let _0xfe8022,_0x2598bc=this['root_'],_0x388120=null;for(;!_0x2598bc['isEmpty']();)if(_0xfe8022=this['comparator_'](_0x4308dc,_0x2598bc['key']),_0xfe8022===0x0){if(_0x2598bc['left']['isEmpty']())return _0x388120?_0x388120['key']:null;for(_0x2598bc=_0x2598bc['left'];!_0x2598bc['right']['isEmpty']();)_0x2598bc=_0x2598bc['right'];return _0x2598bc['key'];}else _0xfe8022<0x0?_0x2598bc=_0x2598bc['left']:_0xfe8022>0x0&&(_0x388120=_0x2598bc,_0x2598bc=_0x2598bc['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x317c65){return this['root_']['inorderTraversal'](_0x317c65);}['reverseTraversal'](_0x235379){return this['root_']['reverseTraversal'](_0x235379);}['getIterator'](_0xc263a8){return new rn(this['root_'],null,this['comparator_'],!0x1,_0xc263a8);}['getIteratorFrom'](_0xf7b1cf,_0x153ec8){return new rn(this['root_'],_0xf7b1cf,this['comparator_'],!0x1,_0x153ec8);}['getReverseIteratorFrom'](_0x38e874,_0x4bb5d7){return new rn(this['root_'],_0x38e874,this['comparator_'],!0x0,_0x4bb5d7);}['getReverseIterator'](_0x1385b6){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x1385b6);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x5a4ee7,_0x7459a6){return qe(_0x5a4ee7['name'],_0x7459a6['name']);}function Qi(_0x5052c8,_0xe8d8b7){return qe(_0x5052c8,_0xe8d8b7);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x2ca5aa){Ci=_0x2ca5aa;}const Po=function(_0xa8f234){return typeof _0xa8f234=='number'?'number:'+ao(_0xa8f234):'string:'+_0xa8f234;},No=function(_0x260964){if(_0x260964['isLeafNode']()){const _0x4851fb=_0x260964['val']();f(typeof _0x4851fb=='string'||typeof _0x4851fb=='number'||typeof _0x4851fb=='object'&&Q(_0x4851fb,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x260964===Ci||_0x260964['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x260964===Ci||_0x260964['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x7dec01){nr=_0x7dec01;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x4c5a1c,_0x2c8131=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x4c5a1c,this['priorityNode_']=_0x2c8131,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x1f26be){return new D(this['value_'],_0x1f26be);}['getImmediateChild'](_0x45f68d){return _0x45f68d==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x33d85f){return v(_0x33d85f)?this:y(_0x33d85f)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x30ccab,_0x139f8b){return null;}['updateImmediateChild'](_0x72cd4,_0x509962){return _0x72cd4==='.priority'?this['updatePriority'](_0x509962):_0x509962['isEmpty']()&&_0x72cd4!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x72cd4,_0x509962)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x24b36b,_0x1ed14c){const _0x3e4a77=y(_0x24b36b);return _0x3e4a77===null?_0x1ed14c:_0x1ed14c['isEmpty']()&&_0x3e4a77!=='.priority'?this:(f(_0x3e4a77!=='.priority'||Ce(_0x24b36b)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x3e4a77,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x24b36b),_0x1ed14c)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x56305f,_0x3f4486){return!0x1;}['val'](_0x4bd05b){return _0x4bd05b&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x5ce634='';this['priorityNode_']['isEmpty']()||(_0x5ce634+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x23b08d=typeof this['value_'];_0x5ce634+=_0x23b08d+':',_0x23b08d==='number'?_0x5ce634+=ao(this['value_']):_0x5ce634+=this['value_'],this['lazyHash_']=ro(_0x5ce634);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x2a3eab){return _0x2a3eab===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x2a3eab instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x2a3eab['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x2a3eab));}['compareToLeafNode_'](_0x229cdf){const _0x1ba013=typeof _0x229cdf['value_'],_0x4f4f12=typeof this['value_'],_0x4385a3=D['VALUE_TYPE_ORDER']['indexOf'](_0x1ba013),_0x202090=D['VALUE_TYPE_ORDER']['indexOf'](_0x4f4f12);return f(_0x4385a3>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x1ba013),f(_0x202090>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x4f4f12),_0x4385a3===_0x202090?_0x4f4f12==='object'?0x0:this['value_']<_0x229cdf['value_']?-0x1:this['value_']===_0x229cdf['value_']?0x0:0x1:_0x202090-_0x4385a3;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x3fe62d){if(_0x3fe62d===this)return!0x0;if(_0x3fe62d['isLeafNode']()){const _0x1429b5=_0x3fe62d;return this['value_']===_0x1429b5['value_']&&this['priorityNode_']['equals'](_0x1429b5['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x3b502a){Oo=_0x3b502a;}function Wh(_0x3d9cc5){Do=_0x3d9cc5;}class Bh extends Fn{['compare'](_0x20b95d,_0x2b9d78){const _0x5123a3=_0x20b95d['node']['getPriority'](),_0x27b88a=_0x2b9d78['node']['getPriority'](),_0x4fa2f8=_0x5123a3['compareTo'](_0x27b88a);return _0x4fa2f8===0x0?qe(_0x20b95d['name'],_0x2b9d78['name']):_0x4fa2f8;}['isDefinedOn'](_0x1b454f){return!_0x1b454f['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x45936c,_0x200d98){return!_0x45936c['getPriority']()['equals'](_0x200d98['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x2d9876,_0x4b8f37){const _0x41e2f6=Oo(_0x2d9876);return new E(_0x4b8f37,new D('[PRIORITY-POST]',_0x41e2f6));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x300c18){const _0x5e4c3f=_0x4ddbee=>parseInt(Math['log'](_0x4ddbee)/Vh,0xa),_0x5f4ff2=_0xe59475=>parseInt(Array(_0xe59475+0x1)['join']('1'),0x2);this['count']=_0x5e4c3f(_0x300c18+0x1),this['current_']=this['count']-0x1;const _0x1b1fab=_0x5f4ff2(this['count']);this['bits_']=_0x300c18+0x1&_0x1b1fab;}['nextBitIsOne'](){const _0x2488ed=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x2488ed;}}const yn=function(_0x206c82,_0x3a1bb9,_0x248940,_0x5d18c0){_0x206c82['sort'](_0x3a1bb9);const _0x289513=function(_0x1439ba,_0x11c8f9){const _0x1cfd7d=_0x11c8f9-_0x1439ba;let _0x4acead,_0x171525;if(_0x1cfd7d===0x0)return null;if(_0x1cfd7d===0x1)return _0x4acead=_0x206c82[_0x1439ba],_0x171525=_0x248940?_0x248940(_0x4acead):_0x4acead,new M(_0x171525,_0x4acead['node'],M['BLACK'],null,null);{const _0x545a98=parseInt(_0x1cfd7d/0x2,0xa)+_0x1439ba,_0x3dad88=_0x289513(_0x1439ba,_0x545a98),_0x4dfc09=_0x289513(_0x545a98+0x1,_0x11c8f9);return _0x4acead=_0x206c82[_0x545a98],_0x171525=_0x248940?_0x248940(_0x4acead):_0x4acead,new M(_0x171525,_0x4acead['node'],M['BLACK'],_0x3dad88,_0x4dfc09);}},_0xf43a8d=function(_0xf94b17){let _0x54751f=null,_0x5c4a47=null,_0x4f2759=_0x206c82['length'];const _0x1836a6=function(_0x3b12ef,_0x1dc37e){const _0x513514=_0x4f2759-_0x3b12ef,_0x21222e=_0x4f2759;_0x4f2759-=_0x3b12ef;const _0x156f87=_0x289513(_0x513514+0x1,_0x21222e),_0x84aa41=_0x206c82[_0x513514],_0x357d5a=_0x248940?_0x248940(_0x84aa41):_0x84aa41;_0x55ac82(new M(_0x357d5a,_0x84aa41['node'],_0x1dc37e,null,_0x156f87));},_0x55ac82=function(_0x52a1ca){_0x54751f?(_0x54751f['left']=_0x52a1ca,_0x54751f=_0x52a1ca):(_0x5c4a47=_0x52a1ca,_0x54751f=_0x52a1ca);};for(let _0x3e91d9=0x0;_0x3e91d9<_0xf94b17['count'];++_0x3e91d9){const _0x5c7f42=_0xf94b17['nextBitIsOne'](),_0x40d7a1=Math['pow'](0x2,_0xf94b17['count']-(_0x3e91d9+0x1));_0x5c7f42?_0x1836a6(_0x40d7a1,M['BLACK']):(_0x1836a6(_0x40d7a1,M['BLACK']),_0x1836a6(_0x40d7a1,M['RED']));}return _0x5c4a47;},_0x45d891=new Hh(_0x206c82['length']),_0x308d71=_0xf43a8d(_0x45d891);return new B(_0x5d18c0||_0x3a1bb9,_0x308d71);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x138769,_0x3048e7){this['indexes_']=_0x138769,this['indexSet_']=_0x3048e7;}['get'](_0x153e76){const _0x42e0ec=Le(this['indexes_'],_0x153e76);if(!_0x42e0ec)throw new Error('No\x20index\x20defined\x20for\x20'+_0x153e76);return _0x42e0ec instanceof B?_0x42e0ec:null;}['hasIndex'](_0x4af046){return Q(this['indexSet_'],_0x4af046['toString']());}['addIndex'](_0x231d79,_0x5dc31c){f(_0x231d79!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x2426e0=[];let _0x256972=!0x1;const _0x44e4a0=_0x5dc31c['getIterator'](E['Wrap']);let _0x31ce51=_0x44e4a0['getNext']();for(;_0x31ce51;)_0x256972=_0x256972||_0x231d79['isDefinedOn'](_0x31ce51['node']),_0x2426e0['push'](_0x31ce51),_0x31ce51=_0x44e4a0['getNext']();let _0x237bae;_0x256972?_0x237bae=yn(_0x2426e0,_0x231d79['getCompare']()):_0x237bae=Qe;const _0x3e52ea=_0x231d79['toString'](),_0x6266e8={...this['indexSet_']};_0x6266e8[_0x3e52ea]=_0x231d79;const _0x23035b={...this['indexes_']};return _0x23035b[_0x3e52ea]=_0x237bae,new te(_0x23035b,_0x6266e8);}['addToIndexes'](_0x784fb0,_0xeb4c0e){const _0x16413b=_n(this['indexes_'],(_0x45d192,_0x5707fd)=>{const _0x3c1114=Le(this['indexSet_'],_0x5707fd);if(f(_0x3c1114,'Missing\x20index\x20implementation\x20for\x20'+_0x5707fd),_0x45d192===Qe){if(_0x3c1114['isDefinedOn'](_0x784fb0['node'])){const _0x3bc65a=[],_0xff023e=_0xeb4c0e['getIterator'](E['Wrap']);let _0x43475b=_0xff023e['getNext']();for(;_0x43475b;)_0x43475b['name']!==_0x784fb0['name']&&_0x3bc65a['push'](_0x43475b),_0x43475b=_0xff023e['getNext']();return _0x3bc65a['push'](_0x784fb0),yn(_0x3bc65a,_0x3c1114['getCompare']());}else return Qe;}else{const _0x597888=_0xeb4c0e['get'](_0x784fb0['name']);let _0x5ce696=_0x45d192;return _0x597888&&(_0x5ce696=_0x5ce696['remove'](new E(_0x784fb0['name'],_0x597888))),_0x5ce696['insert'](_0x784fb0,_0x784fb0['node']);}});return new te(_0x16413b,this['indexSet_']);}['removeFromIndexes'](_0x5f1ff6,_0x1c67ad){const _0x2e0fc1=_n(this['indexes_'],_0x423bd1=>{if(_0x423bd1===Qe)return _0x423bd1;{const _0x238f87=_0x1c67ad['get'](_0x5f1ff6['name']);return _0x238f87?_0x423bd1['remove'](new E(_0x5f1ff6['name'],_0x238f87)):_0x423bd1;}});return new te(_0x2e0fc1,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x3ce1d3,_0x11f7a4,_0x26d76c){this['children_']=_0x3ce1d3,this['priorityNode_']=_0x11f7a4,this['indexMap_']=_0x26d76c,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x1b69af){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x1b69af,this['indexMap_']);}['getImmediateChild'](_0x1339d5){if(_0x1339d5==='.priority')return this['getPriority']();{const _0x3da765=this['children_']['get'](_0x1339d5);return _0x3da765===null?It:_0x3da765;}}['getChild'](_0x382afb){const _0x3b4745=y(_0x382afb);return _0x3b4745===null?this:this['getImmediateChild'](_0x3b4745)['getChild'](S(_0x382afb));}['hasChild'](_0x361203){return this['children_']['get'](_0x361203)!==null;}['updateImmediateChild'](_0x22037b,_0x4517d9){if(f(_0x4517d9,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x22037b==='.priority')return this['updatePriority'](_0x4517d9);{const _0xf8fc18=new E(_0x22037b,_0x4517d9);let _0x5062f1,_0x1c0c36;_0x4517d9['isEmpty']()?(_0x5062f1=this['children_']['remove'](_0x22037b),_0x1c0c36=this['indexMap_']['removeFromIndexes'](_0xf8fc18,this['children_'])):(_0x5062f1=this['children_']['insert'](_0x22037b,_0x4517d9),_0x1c0c36=this['indexMap_']['addToIndexes'](_0xf8fc18,this['children_']));const _0x212f89=_0x5062f1['isEmpty']()?It:this['priorityNode_'];return new g(_0x5062f1,_0x212f89,_0x1c0c36);}}['updateChild'](_0x59d790,_0x34efe8){const _0xbef3c4=y(_0x59d790);if(_0xbef3c4===null)return _0x34efe8;{f(y(_0x59d790)!=='.priority'||Ce(_0x59d790)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x1bea89=this['getImmediateChild'](_0xbef3c4)['updateChild'](S(_0x59d790),_0x34efe8);return this['updateImmediateChild'](_0xbef3c4,_0x1bea89);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0xc8770a){if(this['isEmpty']())return null;const _0x674939={};let _0x3807af=0x0,_0x266b9c=0x0,_0x49547f=!0x0;if(this['forEachChild'](R,(_0x5c8484,_0x53b3c5)=>{_0x674939[_0x5c8484]=_0x53b3c5['val'](_0xc8770a),_0x3807af++,_0x49547f&&g['INTEGER_REGEXP_']['test'](_0x5c8484)?_0x266b9c=Math['max'](_0x266b9c,Number(_0x5c8484)):_0x49547f=!0x1;}),!_0xc8770a&&_0x49547f&&_0x266b9c<0x2*_0x3807af){const _0x4b1003=[];for(const _0x3847ed in _0x674939)_0x4b1003[_0x3847ed]=_0x674939[_0x3847ed];return _0x4b1003;}else return _0xc8770a&&!this['getPriority']()['isEmpty']()&&(_0x674939['.priority']=this['getPriority']()['val']()),_0x674939;}['hash'](){if(this['lazyHash_']===null){let _0x1d8488='';this['getPriority']()['isEmpty']()||(_0x1d8488+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x373cd6,_0x2a4276)=>{const _0xb02d9=_0x2a4276['hash']();_0xb02d9!==''&&(_0x1d8488+=':'+_0x373cd6+':'+_0xb02d9);}),this['lazyHash_']=_0x1d8488===''?'':ro(_0x1d8488);}return this['lazyHash_'];}['getPredecessorChildName'](_0xfad8de,_0x20b63c,_0x296faf){const _0x415b2f=this['resolveIndex_'](_0x296faf);if(_0x415b2f){const _0x157a43=_0x415b2f['getPredecessorKey'](new E(_0xfad8de,_0x20b63c));return _0x157a43?_0x157a43['name']:null;}else return this['children_']['getPredecessorKey'](_0xfad8de);}['getFirstChildName'](_0x4e04aa){const _0x4ae013=this['resolveIndex_'](_0x4e04aa);if(_0x4ae013){const _0x1a95cf=_0x4ae013['minKey']();return _0x1a95cf&&_0x1a95cf['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x1bd8ac){const _0x13b47a=this['getFirstChildName'](_0x1bd8ac);return _0x13b47a?new E(_0x13b47a,this['children_']['get'](_0x13b47a)):null;}['getLastChildName'](_0x5a70f6){const _0x40afab=this['resolveIndex_'](_0x5a70f6);if(_0x40afab){const _0x4b3e19=_0x40afab['maxKey']();return _0x4b3e19&&_0x4b3e19['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x21c73b){const _0x59fad0=this['getLastChildName'](_0x21c73b);return _0x59fad0?new E(_0x59fad0,this['children_']['get'](_0x59fad0)):null;}['forEachChild'](_0x128a35,_0x5bcfc0){const _0x450f95=this['resolveIndex_'](_0x128a35);return _0x450f95?_0x450f95['inorderTraversal'](_0x3e8c76=>_0x5bcfc0(_0x3e8c76['name'],_0x3e8c76['node'])):this['children_']['inorderTraversal'](_0x5bcfc0);}['getIterator'](_0x20dcc0){return this['getIteratorFrom'](_0x20dcc0['minPost'](),_0x20dcc0);}['getIteratorFrom'](_0x427186,_0x4194cf){const _0x52cd6f=this['resolveIndex_'](_0x4194cf);if(_0x52cd6f)return _0x52cd6f['getIteratorFrom'](_0x427186,_0x1b6e85=>_0x1b6e85);{const _0x468764=this['children_']['getIteratorFrom'](_0x427186['name'],E['Wrap']);let _0x42355e=_0x468764['peek']();for(;_0x42355e!=null&&_0x4194cf['compare'](_0x42355e,_0x427186)<0x0;)_0x468764['getNext'](),_0x42355e=_0x468764['peek']();return _0x468764;}}['getReverseIterator'](_0x51f052){return this['getReverseIteratorFrom'](_0x51f052['maxPost'](),_0x51f052);}['getReverseIteratorFrom'](_0x55da19,_0x35fbf0){const _0x4550be=this['resolveIndex_'](_0x35fbf0);if(_0x4550be)return _0x4550be['getReverseIteratorFrom'](_0x55da19,_0x55694d=>_0x55694d);{const _0x1c71dc=this['children_']['getReverseIteratorFrom'](_0x55da19['name'],E['Wrap']);let _0x4f36e6=_0x1c71dc['peek']();for(;_0x4f36e6!=null&&_0x35fbf0['compare'](_0x4f36e6,_0x55da19)>0x0;)_0x1c71dc['getNext'](),_0x4f36e6=_0x1c71dc['peek']();return _0x1c71dc;}}['compareTo'](_0xf20553){return this['isEmpty']()?_0xf20553['isEmpty']()?0x0:-0x1:_0xf20553['isLeafNode']()||_0xf20553['isEmpty']()?0x1:_0xf20553===Kt?-0x1:0x0;}['withIndex'](_0x4802e3){if(_0x4802e3===ve||this['indexMap_']['hasIndex'](_0x4802e3))return this;{const _0xa8c695=this['indexMap_']['addIndex'](_0x4802e3,this['children_']);return new g(this['children_'],this['priorityNode_'],_0xa8c695);}}['isIndexed'](_0x38e0a2){return _0x38e0a2===ve||this['indexMap_']['hasIndex'](_0x38e0a2);}['equals'](_0x246128){if(_0x246128===this)return!0x0;if(_0x246128['isLeafNode']())return!0x1;{const _0x91d53a=_0x246128;if(this['getPriority']()['equals'](_0x91d53a['getPriority']())){if(this['children_']['count']()===_0x91d53a['children_']['count']()){const _0x3c504e=this['getIterator'](R),_0x2f6248=_0x91d53a['getIterator'](R);let _0x3bd9f2=_0x3c504e['getNext'](),_0x478fd1=_0x2f6248['getNext']();for(;_0x3bd9f2&&_0x478fd1;){if(_0x3bd9f2['name']!==_0x478fd1['name']||!_0x3bd9f2['node']['equals'](_0x478fd1['node']))return!0x1;_0x3bd9f2=_0x3c504e['getNext'](),_0x478fd1=_0x2f6248['getNext']();}return _0x3bd9f2===null&&_0x478fd1===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x237f1e){return _0x237f1e===ve?null:this['indexMap_']['get'](_0x237f1e['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x338cbe){return _0x338cbe===this?0x0:0x1;}['equals'](_0x2c0e30){return _0x2c0e30===this;}['getPriority'](){return this;}['getImmediateChild'](_0x142715){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0xd9e88d,_0x28082b=null){if(_0xd9e88d===null)return g['EMPTY_NODE'];if(typeof _0xd9e88d=='object'&&'.priority'in _0xd9e88d&&(_0x28082b=_0xd9e88d['.priority']),f(_0x28082b===null||typeof _0x28082b=='string'||typeof _0x28082b=='number'||typeof _0x28082b=='object'&&'.sv'in _0x28082b,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x28082b),typeof _0xd9e88d=='object'&&'.value'in _0xd9e88d&&_0xd9e88d['.value']!==null&&(_0xd9e88d=_0xd9e88d['.value']),typeof _0xd9e88d!='object'||'.sv'in _0xd9e88d){const _0x3b0273=_0xd9e88d;return new D(_0x3b0273,A(_0x28082b));}if(!(_0xd9e88d instanceof Array)&&Gh){const _0x2c99ed=[];let _0x5d0436=!0x1;if(x(_0xd9e88d,(_0xfc4ba2,_0x282d44)=>{if(_0xfc4ba2['substring'](0x0,0x1)!=='.'){const _0x4c9624=A(_0x282d44);_0x4c9624['isEmpty']()||(_0x5d0436=_0x5d0436||!_0x4c9624['getPriority']()['isEmpty'](),_0x2c99ed['push'](new E(_0xfc4ba2,_0x4c9624)));}}),_0x2c99ed['length']===0x0)return g['EMPTY_NODE'];const _0x20a95a=yn(_0x2c99ed,xh,_0x53842c=>_0x53842c['name'],Qi);if(_0x5d0436){const _0x385246=yn(_0x2c99ed,R['getCompare']());return new g(_0x20a95a,A(_0x28082b),new te({'.priority':_0x385246},{'.priority':R}));}else return new g(_0x20a95a,A(_0x28082b),te['Default']);}else{let _0xa21428=g['EMPTY_NODE'];return x(_0xd9e88d,(_0x1e049d,_0x44eec6)=>{if(Q(_0xd9e88d,_0x1e049d)&&_0x1e049d['substring'](0x0,0x1)!=='.'){const _0x3057c6=A(_0x44eec6);(_0x3057c6['isLeafNode']()||!_0x3057c6['isEmpty']())&&(_0xa21428=_0xa21428['updateImmediateChild'](_0x1e049d,_0x3057c6));}}),_0xa21428['updatePriority'](A(_0x28082b));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x17c257){super(),this['indexPath_']=_0x17c257,f(!v(_0x17c257)&&y(_0x17c257)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x461e14){return _0x461e14['getChild'](this['indexPath_']);}['isDefinedOn'](_0x3e62ff){return!_0x3e62ff['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x197264,_0x387d85){const _0x387459=this['extractChild'](_0x197264['node']),_0x2e84f4=this['extractChild'](_0x387d85['node']),_0x461598=_0x387459['compareTo'](_0x2e84f4);return _0x461598===0x0?qe(_0x197264['name'],_0x387d85['name']):_0x461598;}['makePost'](_0x10ea4d,_0x4d3187){const _0x2a5ca4=A(_0x10ea4d),_0x3e344b=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x2a5ca4);return new E(_0x4d3187,_0x3e344b);}['maxPost'](){const _0x1097b4=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x1097b4);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x27d0b9,_0x1931f2){const _0x5e066d=_0x27d0b9['node']['compareTo'](_0x1931f2['node']);return _0x5e066d===0x0?qe(_0x27d0b9['name'],_0x1931f2['name']):_0x5e066d;}['isDefinedOn'](_0x2a4a34){return!0x0;}['indexedValueChanged'](_0x50a882,_0x3159f2){return!_0x50a882['equals'](_0x3159f2);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x3cb280,_0x33b233){const _0xcec028=A(_0x3cb280);return new E(_0x33b233,_0xcec028);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0xdc7c1e){return{'type':'value','snapshotNode':_0xdc7c1e};}function rt(_0x409d36,_0x3c34b9){return{'type':'child_added','snapshotNode':_0x3c34b9,'childName':_0x409d36};}function Lt(_0x37f7df,_0x21fbf7){return{'type':'child_removed','snapshotNode':_0x21fbf7,'childName':_0x37f7df};}function xt(_0x252246,_0x2b1b98,_0x31368a){return{'type':'child_changed','snapshotNode':_0x2b1b98,'childName':_0x252246,'oldSnap':_0x31368a};}function zh(_0x545f83,_0x1474d7){return{'type':'child_moved','snapshotNode':_0x1474d7,'childName':_0x545f83};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x1adbda){this['index_']=_0x1adbda;}['updateChild'](_0x34b4dc,_0x3f98c1,_0x5b4f25,_0xf901eb,_0xd31789,_0x3c4022){f(_0x34b4dc['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x1707a5=_0x34b4dc['getImmediateChild'](_0x3f98c1);return _0x1707a5['getChild'](_0xf901eb)['equals'](_0x5b4f25['getChild'](_0xf901eb))&&_0x1707a5['isEmpty']()===_0x5b4f25['isEmpty']()||(_0x3c4022!=null&&(_0x5b4f25['isEmpty']()?_0x34b4dc['hasChild'](_0x3f98c1)?_0x3c4022['trackChildChange'](Lt(_0x3f98c1,_0x1707a5)):f(_0x34b4dc['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x1707a5['isEmpty']()?_0x3c4022['trackChildChange'](rt(_0x3f98c1,_0x5b4f25)):_0x3c4022['trackChildChange'](xt(_0x3f98c1,_0x5b4f25,_0x1707a5))),_0x34b4dc['isLeafNode']()&&_0x5b4f25['isEmpty']())?_0x34b4dc:_0x34b4dc['updateImmediateChild'](_0x3f98c1,_0x5b4f25)['withIndex'](this['index_']);}['updateFullNode'](_0x58459a,_0x4c8506,_0x2e72cf){return _0x2e72cf!=null&&(_0x58459a['isLeafNode']()||_0x58459a['forEachChild'](R,(_0x2f1c39,_0x21ab48)=>{_0x4c8506['hasChild'](_0x2f1c39)||_0x2e72cf['trackChildChange'](Lt(_0x2f1c39,_0x21ab48));}),_0x4c8506['isLeafNode']()||_0x4c8506['forEachChild'](R,(_0x4dd96e,_0x2b4cb9)=>{if(_0x58459a['hasChild'](_0x4dd96e)){const _0x4f80fa=_0x58459a['getImmediateChild'](_0x4dd96e);_0x4f80fa['equals'](_0x2b4cb9)||_0x2e72cf['trackChildChange'](xt(_0x4dd96e,_0x2b4cb9,_0x4f80fa));}else _0x2e72cf['trackChildChange'](rt(_0x4dd96e,_0x2b4cb9));})),_0x4c8506['withIndex'](this['index_']);}['updatePriority'](_0x3d9801,_0x1076a7){return _0x3d9801['isEmpty']()?g['EMPTY_NODE']:_0x3d9801['updatePriority'](_0x1076a7);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x1b029b){this['indexedFilter_']=new Xi(_0x1b029b['getIndex']()),this['index_']=_0x1b029b['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x1b029b),this['endPost_']=Ft['getEndPost_'](_0x1b029b),this['startIsInclusive_']=!_0x1b029b['startAfterSet_'],this['endIsInclusive_']=!_0x1b029b['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x2ca6d0){const _0x8af7d4=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x2ca6d0)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x2ca6d0)<0x0,_0x5758d5=this['endIsInclusive_']?this['index_']['compare'](_0x2ca6d0,this['getEndPost']())<=0x0:this['index_']['compare'](_0x2ca6d0,this['getEndPost']())<0x0;return _0x8af7d4&&_0x5758d5;}['updateChild'](_0x13deb3,_0x54f886,_0x46049d,_0x4e6f1b,_0x4c5948,_0x56f739){return this['matches'](new E(_0x54f886,_0x46049d))||(_0x46049d=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x13deb3,_0x54f886,_0x46049d,_0x4e6f1b,_0x4c5948,_0x56f739);}['updateFullNode'](_0x3a69be,_0x3c67d9,_0x598f27){_0x3c67d9['isLeafNode']()&&(_0x3c67d9=g['EMPTY_NODE']);let _0x50c55d=_0x3c67d9['withIndex'](this['index_']);_0x50c55d=_0x50c55d['updatePriority'](g['EMPTY_NODE']);const _0x10e42f=this;return _0x3c67d9['forEachChild'](R,(_0x53c3cb,_0x5d76c2)=>{_0x10e42f['matches'](new E(_0x53c3cb,_0x5d76c2))||(_0x50c55d=_0x50c55d['updateImmediateChild'](_0x53c3cb,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x3a69be,_0x50c55d,_0x598f27);}['updatePriority'](_0x3f32b5,_0x4ffeba){return _0x3f32b5;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0xdbe24d){if(_0xdbe24d['hasStart']()){const _0x3319f8=_0xdbe24d['getIndexStartName']();return _0xdbe24d['getIndex']()['makePost'](_0xdbe24d['getIndexStartValue'](),_0x3319f8);}else return _0xdbe24d['getIndex']()['minPost']();}static['getEndPost_'](_0x547fae){if(_0x547fae['hasEnd']()){const _0x1f7691=_0x547fae['getIndexEndName']();return _0x547fae['getIndex']()['makePost'](_0x547fae['getIndexEndValue'](),_0x1f7691);}else return _0x547fae['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x5ab904){this['withinDirectionalStart']=_0x868d7f=>this['reverse_']?this['withinEndPost'](_0x868d7f):this['withinStartPost'](_0x868d7f),this['withinDirectionalEnd']=_0x3fdeb5=>this['reverse_']?this['withinStartPost'](_0x3fdeb5):this['withinEndPost'](_0x3fdeb5),this['withinStartPost']=_0x273ef8=>{const _0xe068c6=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x273ef8);return this['startIsInclusive_']?_0xe068c6<=0x0:_0xe068c6<0x0;},this['withinEndPost']=_0x33cea3=>{const _0x4fa1b1=this['index_']['compare'](_0x33cea3,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x4fa1b1<=0x0:_0x4fa1b1<0x0;},this['rangedFilter_']=new Ft(_0x5ab904),this['index_']=_0x5ab904['getIndex'](),this['limit_']=_0x5ab904['getLimit'](),this['reverse_']=!_0x5ab904['isViewFromLeft'](),this['startIsInclusive_']=!_0x5ab904['startAfterSet_'],this['endIsInclusive_']=!_0x5ab904['endBeforeSet_'];}['updateChild'](_0x755651,_0x21137f,_0x3e4330,_0x1f1ac0,_0x840762,_0x955e0a){return this['rangedFilter_']['matches'](new E(_0x21137f,_0x3e4330))||(_0x3e4330=g['EMPTY_NODE']),_0x755651['getImmediateChild'](_0x21137f)['equals'](_0x3e4330)?_0x755651:_0x755651['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x755651,_0x21137f,_0x3e4330,_0x1f1ac0,_0x840762,_0x955e0a):this['fullLimitUpdateChild_'](_0x755651,_0x21137f,_0x3e4330,_0x840762,_0x955e0a);}['updateFullNode'](_0x377434,_0x32eb05,_0x4f32d4){let _0x300808;if(_0x32eb05['isLeafNode']()||_0x32eb05['isEmpty']())_0x300808=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x32eb05['numChildren']()&&_0x32eb05['isIndexed'](this['index_'])){_0x300808=g['EMPTY_NODE']['withIndex'](this['index_']);let _0xdace7c;this['reverse_']?_0xdace7c=_0x32eb05['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0xdace7c=_0x32eb05['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0xc0c3f8=0x0;for(;_0xdace7c['hasNext']()&&_0xc0c3f8<this['limit_'];){const _0x1df662=_0xdace7c['getNext']();if(this['withinDirectionalStart'](_0x1df662)){if(this['withinDirectionalEnd'](_0x1df662))_0x300808=_0x300808['updateImmediateChild'](_0x1df662['name'],_0x1df662['node']),_0xc0c3f8++;else break;}else continue;}}else{_0x300808=_0x32eb05['withIndex'](this['index_']),_0x300808=_0x300808['updatePriority'](g['EMPTY_NODE']);let _0x33eec3;this['reverse_']?_0x33eec3=_0x300808['getReverseIterator'](this['index_']):_0x33eec3=_0x300808['getIterator'](this['index_']);let _0x587367=0x0;for(;_0x33eec3['hasNext']();){const _0x5bcc24=_0x33eec3['getNext']();_0x587367<this['limit_']&&this['withinDirectionalStart'](_0x5bcc24)&&this['withinDirectionalEnd'](_0x5bcc24)?_0x587367++:_0x300808=_0x300808['updateImmediateChild'](_0x5bcc24['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x377434,_0x300808,_0x4f32d4);}['updatePriority'](_0x24b081,_0xee422b){return _0x24b081;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x36afac,_0x55790e,_0x22a424,_0x63f6ef,_0x4f857c){let _0x393553;if(this['reverse_']){const _0x1fe2cb=this['index_']['getCompare']();_0x393553=(_0x22345e,_0x27e08b)=>_0x1fe2cb(_0x27e08b,_0x22345e);}else _0x393553=this['index_']['getCompare']();const _0x5ba544=_0x36afac;f(_0x5ba544['numChildren']()===this['limit_'],'');const _0x540323=new E(_0x55790e,_0x22a424),_0x5c746f=this['reverse_']?_0x5ba544['getFirstChild'](this['index_']):_0x5ba544['getLastChild'](this['index_']),_0x1edbaf=this['rangedFilter_']['matches'](_0x540323);if(_0x5ba544['hasChild'](_0x55790e)){const _0x174564=_0x5ba544['getImmediateChild'](_0x55790e);let _0x21f9bb=_0x63f6ef['getChildAfterChild'](this['index_'],_0x5c746f,this['reverse_']);for(;_0x21f9bb!=null&&(_0x21f9bb['name']===_0x55790e||_0x5ba544['hasChild'](_0x21f9bb['name']));)_0x21f9bb=_0x63f6ef['getChildAfterChild'](this['index_'],_0x21f9bb,this['reverse_']);const _0x348cb8=_0x21f9bb==null?0x1:_0x393553(_0x21f9bb,_0x540323);if(_0x1edbaf&&!_0x22a424['isEmpty']()&&_0x348cb8>=0x0)return _0x4f857c!=null&&_0x4f857c['trackChildChange'](xt(_0x55790e,_0x22a424,_0x174564)),_0x5ba544['updateImmediateChild'](_0x55790e,_0x22a424);{_0x4f857c!=null&&_0x4f857c['trackChildChange'](Lt(_0x55790e,_0x174564));const _0x1ac9d7=_0x5ba544['updateImmediateChild'](_0x55790e,g['EMPTY_NODE']);return _0x21f9bb!=null&&this['rangedFilter_']['matches'](_0x21f9bb)?(_0x4f857c!=null&&_0x4f857c['trackChildChange'](rt(_0x21f9bb['name'],_0x21f9bb['node'])),_0x1ac9d7['updateImmediateChild'](_0x21f9bb['name'],_0x21f9bb['node'])):_0x1ac9d7;}}else return _0x22a424['isEmpty']()?_0x36afac:_0x1edbaf&&_0x393553(_0x5c746f,_0x540323)>=0x0?(_0x4f857c!=null&&(_0x4f857c['trackChildChange'](Lt(_0x5c746f['name'],_0x5c746f['node'])),_0x4f857c['trackChildChange'](rt(_0x55790e,_0x22a424))),_0x5ba544['updateImmediateChild'](_0x55790e,_0x22a424)['updateImmediateChild'](_0x5c746f['name'],g['EMPTY_NODE'])):_0x36afac;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0xca9a74=new Zi();return _0xca9a74['limitSet_']=this['limitSet_'],_0xca9a74['limit_']=this['limit_'],_0xca9a74['startSet_']=this['startSet_'],_0xca9a74['startAfterSet_']=this['startAfterSet_'],_0xca9a74['indexStartValue_']=this['indexStartValue_'],_0xca9a74['startNameSet_']=this['startNameSet_'],_0xca9a74['indexStartName_']=this['indexStartName_'],_0xca9a74['endSet_']=this['endSet_'],_0xca9a74['endBeforeSet_']=this['endBeforeSet_'],_0xca9a74['indexEndValue_']=this['indexEndValue_'],_0xca9a74['endNameSet_']=this['endNameSet_'],_0xca9a74['indexEndName_']=this['indexEndName_'],_0xca9a74['index_']=this['index_'],_0xca9a74['viewFrom_']=this['viewFrom_'],_0xca9a74;}}function Kh(_0x4a9d8c){return _0x4a9d8c['loadsAllData']()?new Xi(_0x4a9d8c['getIndex']()):_0x4a9d8c['hasLimit']()?new jh(_0x4a9d8c):new Ft(_0x4a9d8c);}function Yh(_0x13fe95,_0x5da7f9){const _0x2fa494=_0x13fe95['copy']();return _0x2fa494['limitSet_']=!0x0,_0x2fa494['limit_']=_0x5da7f9,_0x2fa494['viewFrom_']='l',_0x2fa494;}function Qh(_0xea1960,_0x55d3a7,_0x58d32a){const _0xc31738=_0xea1960['copy']();return _0xc31738['startSet_']=!0x0,_0x55d3a7===void 0x0&&(_0x55d3a7=null),_0xc31738['indexStartValue_']=_0x55d3a7,_0x58d32a!=null?(_0xc31738['startNameSet_']=!0x0,_0xc31738['indexStartName_']=_0x58d32a):(_0xc31738['startNameSet_']=!0x1,_0xc31738['indexStartName_']=''),_0xc31738;}function Jh(_0x43a36f,_0x21ba6a,_0x1d9394){const _0x112fe9=_0x43a36f['copy']();return _0x112fe9['endSet_']=!0x0,_0x21ba6a===void 0x0&&(_0x21ba6a=null),_0x112fe9['indexEndValue_']=_0x21ba6a,_0x1d9394!==void 0x0?(_0x112fe9['endNameSet_']=!0x0,_0x112fe9['indexEndName_']=_0x1d9394):(_0x112fe9['endNameSet_']=!0x1,_0x112fe9['indexEndName_']=''),_0x112fe9;}function xo(_0x5beae4,_0x2c5a7f){const _0x17e8e7=_0x5beae4['copy']();return _0x17e8e7['index_']=_0x2c5a7f,_0x17e8e7;}function ir(_0x42db12){const _0x156a1f={};if(_0x42db12['isDefault']())return _0x156a1f;let _0x42ce7c;if(_0x42db12['index_']===R?_0x42ce7c='$priority':_0x42db12['index_']===Mo?_0x42ce7c='$value':_0x42db12['index_']===ve?_0x42ce7c='$key':(f(_0x42db12['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x42ce7c=_0x42db12['index_']['toString']()),_0x156a1f['orderBy']=O(_0x42ce7c),_0x42db12['startSet_']){const _0x204232=_0x42db12['startAfterSet_']?'startAfter':'startAt';_0x156a1f[_0x204232]=O(_0x42db12['indexStartValue_']),_0x42db12['startNameSet_']&&(_0x156a1f[_0x204232]+=','+O(_0x42db12['indexStartName_']));}if(_0x42db12['endSet_']){const _0x9343f4=_0x42db12['endBeforeSet_']?'endBefore':'endAt';_0x156a1f[_0x9343f4]=O(_0x42db12['indexEndValue_']),_0x42db12['endNameSet_']&&(_0x156a1f[_0x9343f4]+=','+O(_0x42db12['indexEndName_']));}return _0x42db12['limitSet_']&&(_0x42db12['isViewFromLeft']()?_0x156a1f['limitToFirst']=_0x42db12['limit_']:_0x156a1f['limitToLast']=_0x42db12['limit_']),_0x156a1f;}function sr(_0x44d62e){const _0x5dd32d={};if(_0x44d62e['startSet_']&&(_0x5dd32d['sp']=_0x44d62e['indexStartValue_'],_0x44d62e['startNameSet_']&&(_0x5dd32d['sn']=_0x44d62e['indexStartName_']),_0x5dd32d['sin']=!_0x44d62e['startAfterSet_']),_0x44d62e['endSet_']&&(_0x5dd32d['ep']=_0x44d62e['indexEndValue_'],_0x44d62e['endNameSet_']&&(_0x5dd32d['en']=_0x44d62e['indexEndName_']),_0x5dd32d['ein']=!_0x44d62e['endBeforeSet_']),_0x44d62e['limitSet_']){_0x5dd32d['l']=_0x44d62e['limit_'];let _0x14740d=_0x44d62e['viewFrom_'];_0x14740d===''&&(_0x44d62e['isViewFromLeft']()?_0x14740d='l':_0x14740d='r'),_0x5dd32d['vf']=_0x14740d;}return _0x44d62e['index_']!==R&&(_0x5dd32d['i']=_0x44d62e['index_']['toString']()),_0x5dd32d;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x213a75){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x3cc9b9,_0x27b7ec){return _0x27b7ec!==void 0x0?'tag$'+_0x27b7ec:(f(_0x3cc9b9['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x3cc9b9['_path']['toString']());}constructor(_0x49d9dd,_0x11d61c,_0x3de5fc,_0x2e29a2){super(),this['repoInfo_']=_0x49d9dd,this['onDataUpdate_']=_0x11d61c,this['authTokenProvider_']=_0x3de5fc,this['appCheckTokenProvider_']=_0x2e29a2,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x1c0f65,_0x109f18,_0x254123,_0x31dd82){const _0x19560a=_0x1c0f65['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x19560a+'\x20'+_0x1c0f65['_queryIdentifier']);const _0x1e97e6=vn['getListenId_'](_0x1c0f65,_0x254123),_0x317be3={};this['listens_'][_0x1e97e6]=_0x317be3;const _0x426f1c=ir(_0x1c0f65['_queryParams']);this['restRequest_'](_0x19560a+'.json',_0x426f1c,(_0x3c71e0,_0x2beca7)=>{let _0x30c322=_0x2beca7;if(_0x3c71e0===0x194&&(_0x30c322=null,_0x3c71e0=null),_0x3c71e0===null&&this['onDataUpdate_'](_0x19560a,_0x30c322,!0x1,_0x254123),Le(this['listens_'],_0x1e97e6)===_0x317be3){let _0x41349f;_0x3c71e0?_0x3c71e0===0x191?_0x41349f='permission_denied':_0x41349f='rest_error:'+_0x3c71e0:_0x41349f='ok',_0x31dd82(_0x41349f,null);}});}['unlisten'](_0x572f70,_0x4cc57c){const _0x5aec2c=vn['getListenId_'](_0x572f70,_0x4cc57c);delete this['listens_'][_0x5aec2c];}['get'](_0xcc5199){const _0x1233a9=ir(_0xcc5199['_queryParams']),_0x5cbe01=_0xcc5199['_path']['toString'](),_0x3eb347=new H();return this['restRequest_'](_0x5cbe01+'.json',_0x1233a9,(_0x149ac9,_0x2690d6)=>{let _0x10f6f7=_0x2690d6;_0x149ac9===0x194&&(_0x10f6f7=null,_0x149ac9=null),_0x149ac9===null?(this['onDataUpdate_'](_0x5cbe01,_0x10f6f7,!0x1,null),_0x3eb347['resolve'](_0x10f6f7)):_0x3eb347['reject'](new Error(_0x10f6f7));}),_0x3eb347['promise'];}['refreshAuthToken'](_0x18b10d){}['restRequest_'](_0x19da33,_0x35f7d9={},_0x5118f5){return _0x35f7d9['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x557f2c,_0x2f7a1a])=>{_0x557f2c&&_0x557f2c['accessToken']&&(_0x35f7d9['auth']=_0x557f2c['accessToken']),_0x2f7a1a&&_0x2f7a1a['token']&&(_0x35f7d9['ac']=_0x2f7a1a['token']);const _0x325512=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x19da33+'?ns='+this['repoInfo_']['namespace']+ut(_0x35f7d9);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x325512);const _0x57c522=new XMLHttpRequest();_0x57c522['onreadystatechange']=()=>{if(_0x5118f5&&_0x57c522['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x325512+'\x20received.\x20status:',_0x57c522['status'],'response:',_0x57c522['responseText']);let _0x1e7b1a=null;if(_0x57c522['status']>=0xc8&&_0x57c522['status']<0x12c){try{_0x1e7b1a=Nt(_0x57c522['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x325512+':\x20'+_0x57c522['responseText']);}_0x5118f5(null,_0x1e7b1a);}else _0x57c522['status']!==0x191&&_0x57c522['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x325512+'\x20Status:\x20'+_0x57c522['status']),_0x5118f5(_0x57c522['status']);_0x5118f5=null;}},_0x57c522['open']('GET',_0x325512,!0x0),_0x57c522['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x2daff8){return this['rootNode_']['getChild'](_0x2daff8);}['updateSnapshot'](_0x440ebd,_0x3bec15){this['rootNode_']=this['rootNode_']['updateChild'](_0x440ebd,_0x3bec15);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x52709c,_0x403df0,_0x5705d){if(v(_0x403df0))_0x52709c['value']=_0x5705d,_0x52709c['children']['clear']();else{if(_0x52709c['value']!==null)_0x52709c['value']=_0x52709c['value']['updateChild'](_0x403df0,_0x5705d);else{const _0x447139=y(_0x403df0);_0x52709c['children']['has'](_0x447139)||_0x52709c['children']['set'](_0x447139,En());const _0xc9412a=_0x52709c['children']['get'](_0x447139);_0x403df0=S(_0x403df0),pt(_0xc9412a,_0x403df0,_0x5705d);}}}function Ti(_0xe151c5,_0x21ef35){if(v(_0x21ef35))return _0xe151c5['value']=null,_0xe151c5['children']['clear'](),!0x0;if(_0xe151c5['value']!==null){if(_0xe151c5['value']['isLeafNode']())return!0x1;{const _0x48cb05=_0xe151c5['value'];return _0xe151c5['value']=null,_0x48cb05['forEachChild'](R,(_0x9f3dce,_0x2183b2)=>{pt(_0xe151c5,new C(_0x9f3dce),_0x2183b2);}),Ti(_0xe151c5,_0x21ef35);}}else{if(_0xe151c5['children']['size']>0x0){const _0x1349d6=y(_0x21ef35);return _0x21ef35=S(_0x21ef35),_0xe151c5['children']['has'](_0x1349d6)&&Ti(_0xe151c5['children']['get'](_0x1349d6),_0x21ef35)&&_0xe151c5['children']['delete'](_0x1349d6),_0xe151c5['children']['size']===0x0;}else return!0x0;}}function Si(_0x1154f6,_0x9a1526,_0x26fedf){_0x1154f6['value']!==null?_0x26fedf(_0x9a1526,_0x1154f6['value']):Zh(_0x1154f6,(_0x25814f,_0x483332)=>{const _0x5440e8=new C(_0x9a1526['toString']()+'/'+_0x25814f);Si(_0x483332,_0x5440e8,_0x26fedf);});}function Zh(_0x2fb210,_0x5719e4){_0x2fb210['children']['forEach']((_0x54eb02,_0x2b0617)=>{_0x5719e4(_0x2b0617,_0x54eb02);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x58e715){this['collection_']=_0x58e715,this['last_']=null;}['get'](){const _0x5eaaa9=this['collection_']['get'](),_0x19c60a={..._0x5eaaa9};return this['last_']&&x(this['last_'],(_0x2b7d0e,_0x14721e)=>{_0x19c60a[_0x2b7d0e]=_0x19c60a[_0x2b7d0e]-_0x14721e;}),this['last_']=_0x5eaaa9,_0x19c60a;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x3a07ec,_0x5ae4e0){this['server_']=_0x5ae4e0,this['statsToReport_']={},this['statsListener_']=new eu(_0x3a07ec);const _0x1dbb3f=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x1dbb3f));}['reportStats_'](){const _0x49f887=this['statsListener_']['get'](),_0x2484b8={};let _0x1663a3=!0x1;x(_0x49f887,(_0x1d3ab4,_0x2c165e)=>{_0x2c165e>0x0&&Q(this['statsToReport_'],_0x1d3ab4)&&(_0x2484b8[_0x1d3ab4]=_0x2c165e,_0x1663a3=!0x0);}),_0x1663a3&&this['server_']['reportStats'](_0x2484b8),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x4a989b){_0x4a989b[_0x4a989b['OVERWRITE']=0x0]='OVERWRITE',_0x4a989b[_0x4a989b['MERGE']=0x1]='MERGE',_0x4a989b[_0x4a989b['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x4a989b[_0x4a989b['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x242840){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x242840,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x3480e4,_0x17d3ab,_0x57b38a){this['path']=_0x3480e4,this['affectedTree']=_0x17d3ab,this['revert']=_0x57b38a,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x30ab6a){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x26fe84=this['affectedTree']['subtree'](new C(_0x30ab6a));return new In(w(),_0x26fe84,this['revert']);}}else return f(y(this['path'])===_0x30ab6a,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x3488fa,_0x3797fa){this['source']=_0x3488fa,this['path']=_0x3797fa,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x3d1743){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x892adf,_0x2765a1,_0x3388be){this['source']=_0x892adf,this['path']=_0x2765a1,this['snap']=_0x3388be,this['type']=z['OVERWRITE'];}['operationForChild'](_0x8e46ff){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x8e46ff)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0xd43a8a,_0x5886b4,_0x5ba63f){this['source']=_0xd43a8a,this['path']=_0x5886b4,this['children']=_0x5ba63f,this['type']=z['MERGE'];}['operationForChild'](_0x55d541){if(v(this['path'])){const _0x4c6784=this['children']['subtree'](new C(_0x55d541));return _0x4c6784['isEmpty']()?null:_0x4c6784['value']?new Be(this['source'],w(),_0x4c6784['value']):new ot(this['source'],w(),_0x4c6784);}else return f(y(this['path'])===_0x55d541,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x1129e7,_0x1dee88,_0x34b50b){this['node_']=_0x1129e7,this['fullyInitialized_']=_0x1dee88,this['filtered_']=_0x34b50b;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x40d78e){if(v(_0x40d78e))return this['isFullyInitialized']()&&!this['filtered_'];const _0x1c7b93=y(_0x40d78e);return this['isCompleteForChild'](_0x1c7b93);}['isCompleteForChild'](_0x34137b){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x34137b);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x5cc8c4){this['query_']=_0x5cc8c4,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x48638e,_0x200c66,_0x1aab2e,_0x344b3e){const _0x2e85fc=[],_0x469b00=[];return _0x200c66['forEach'](_0x411a37=>{_0x411a37['type']==='child_changed'&&_0x48638e['index_']['indexedValueChanged'](_0x411a37['oldSnap'],_0x411a37['snapshotNode'])&&_0x469b00['push'](zh(_0x411a37['childName'],_0x411a37['snapshotNode']));}),wt(_0x48638e,_0x2e85fc,'child_removed',_0x200c66,_0x344b3e,_0x1aab2e),wt(_0x48638e,_0x2e85fc,'child_added',_0x200c66,_0x344b3e,_0x1aab2e),wt(_0x48638e,_0x2e85fc,'child_moved',_0x469b00,_0x344b3e,_0x1aab2e),wt(_0x48638e,_0x2e85fc,'child_changed',_0x200c66,_0x344b3e,_0x1aab2e),wt(_0x48638e,_0x2e85fc,'value',_0x200c66,_0x344b3e,_0x1aab2e),_0x2e85fc;}function wt(_0x268343,_0x2c7cd4,_0x2a21ab,_0x58034c,_0x3c08d2,_0x1bd48c){const _0x5a43cc=_0x58034c['filter'](_0x325e00=>_0x325e00['type']===_0x2a21ab);_0x5a43cc['sort']((_0x58abdc,_0x105f8c)=>au(_0x268343,_0x58abdc,_0x105f8c)),_0x5a43cc['forEach'](_0x379e68=>{const _0x29d8fd=ou(_0x268343,_0x379e68,_0x1bd48c);_0x3c08d2['forEach'](_0xcc245a=>{_0xcc245a['respondsTo'](_0x379e68['type'])&&_0x2c7cd4['push'](_0xcc245a['createEvent'](_0x29d8fd,_0x268343['query_']));});});}function ou(_0x3b4a3f,_0x4de145,_0xc93ace){return _0x4de145['type']==='value'||_0x4de145['type']==='child_removed'||(_0x4de145['prevName']=_0xc93ace['getPredecessorChildName'](_0x4de145['childName'],_0x4de145['snapshotNode'],_0x3b4a3f['index_'])),_0x4de145;}function au(_0xe7a7c,_0x39ac2f,_0x445017){if(_0x39ac2f['childName']==null||_0x445017['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x5939cb=new E(_0x39ac2f['childName'],_0x39ac2f['snapshotNode']),_0x320bc4=new E(_0x445017['childName'],_0x445017['snapshotNode']);return _0xe7a7c['index_']['compare'](_0x5939cb,_0x320bc4);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0xc425ca,_0x49b06e){return{'eventCache':_0xc425ca,'serverCache':_0x49b06e};}function Rt(_0xe59b8d,_0x349e8f,_0xb62fbd,_0x3b0532){return Un(new Te(_0x349e8f,_0xb62fbd,_0x3b0532),_0xe59b8d['serverCache']);}function Fo(_0x42a1d6,_0xfa9b72,_0x47f36e,_0x11d10f){return Un(_0x42a1d6['eventCache'],new Te(_0xfa9b72,_0x47f36e,_0x11d10f));}function wn(_0x3f8839){return _0x3f8839['eventCache']['isFullyInitialized']()?_0x3f8839['eventCache']['getNode']():null;}function Ve(_0x8cf649){return _0x8cf649['serverCache']['isFullyInitialized']()?_0x8cf649['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x4402cf){let _0x52cbeb=new b(null);return x(_0x4402cf,(_0x498a4c,_0x397a97)=>{_0x52cbeb=_0x52cbeb['set'](new C(_0x498a4c),_0x397a97);}),_0x52cbeb;}constructor(_0x2b3e12,_0x2a7c58=cu()){this['value']=_0x2b3e12,this['children']=_0x2a7c58;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x423bb0,_0x34f842){if(this['value']!=null&&_0x34f842(this['value']))return{'path':w(),'value':this['value']};if(v(_0x423bb0))return null;{const _0x14bc8c=y(_0x423bb0),_0x4925bc=this['children']['get'](_0x14bc8c);if(_0x4925bc!==null){const _0x52d537=_0x4925bc['findRootMostMatchingPathAndValue'](S(_0x423bb0),_0x34f842);return _0x52d537!=null?{'path':k(new C(_0x14bc8c),_0x52d537['path']),'value':_0x52d537['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x46c461){return this['findRootMostMatchingPathAndValue'](_0x46c461,()=>!0x0);}['subtree'](_0x33f53c){if(v(_0x33f53c))return this;{const _0x1eff67=y(_0x33f53c),_0x4ac531=this['children']['get'](_0x1eff67);return _0x4ac531!==null?_0x4ac531['subtree'](S(_0x33f53c)):new b(null);}}['set'](_0x21d0e1,_0x387a7a){if(v(_0x21d0e1))return new b(_0x387a7a,this['children']);{const _0x52efe4=y(_0x21d0e1),_0x18cde0=(this['children']['get'](_0x52efe4)||new b(null))['set'](S(_0x21d0e1),_0x387a7a),_0x43dc4d=this['children']['insert'](_0x52efe4,_0x18cde0);return new b(this['value'],_0x43dc4d);}}['remove'](_0x2e33aa){if(v(_0x2e33aa))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x5e9047=y(_0x2e33aa),_0x33ff1c=this['children']['get'](_0x5e9047);if(_0x33ff1c){const _0x3fbfb1=_0x33ff1c['remove'](S(_0x2e33aa));let _0x122d5c;return _0x3fbfb1['isEmpty']()?_0x122d5c=this['children']['remove'](_0x5e9047):_0x122d5c=this['children']['insert'](_0x5e9047,_0x3fbfb1),this['value']===null&&_0x122d5c['isEmpty']()?new b(null):new b(this['value'],_0x122d5c);}else return this;}}['get'](_0x49df7e){if(v(_0x49df7e))return this['value'];{const _0x57d60a=y(_0x49df7e),_0xb9912f=this['children']['get'](_0x57d60a);return _0xb9912f?_0xb9912f['get'](S(_0x49df7e)):null;}}['setTree'](_0x3451a9,_0x160e1d){if(v(_0x3451a9))return _0x160e1d;{const _0x335aae=y(_0x3451a9),_0x57cf82=(this['children']['get'](_0x335aae)||new b(null))['setTree'](S(_0x3451a9),_0x160e1d);let _0x4b3a18;return _0x57cf82['isEmpty']()?_0x4b3a18=this['children']['remove'](_0x335aae):_0x4b3a18=this['children']['insert'](_0x335aae,_0x57cf82),new b(this['value'],_0x4b3a18);}}['fold'](_0x27fc88){return this['fold_'](w(),_0x27fc88);}['fold_'](_0x6e7f0c,_0x53c7c8){const _0x18f16a={};return this['children']['inorderTraversal']((_0x12c41e,_0x1dfe39)=>{_0x18f16a[_0x12c41e]=_0x1dfe39['fold_'](k(_0x6e7f0c,_0x12c41e),_0x53c7c8);}),_0x53c7c8(_0x6e7f0c,this['value'],_0x18f16a);}['findOnPath'](_0x1c6c97,_0x1655b7){return this['findOnPath_'](_0x1c6c97,w(),_0x1655b7);}['findOnPath_'](_0x35efcd,_0x28ad4b,_0x4f4bd0){const _0x3740da=this['value']?_0x4f4bd0(_0x28ad4b,this['value']):!0x1;if(_0x3740da)return _0x3740da;if(v(_0x35efcd))return null;{const _0x46cd45=y(_0x35efcd),_0x42c17c=this['children']['get'](_0x46cd45);return _0x42c17c?_0x42c17c['findOnPath_'](S(_0x35efcd),k(_0x28ad4b,_0x46cd45),_0x4f4bd0):null;}}['foreachOnPath'](_0x7864e0,_0x28c7be){return this['foreachOnPath_'](_0x7864e0,w(),_0x28c7be);}['foreachOnPath_'](_0x4db064,_0x1f0bdf,_0x2b85c7){if(v(_0x4db064))return this;{this['value']&&_0x2b85c7(_0x1f0bdf,this['value']);const _0x2a38ac=y(_0x4db064),_0x16f770=this['children']['get'](_0x2a38ac);return _0x16f770?_0x16f770['foreachOnPath_'](S(_0x4db064),k(_0x1f0bdf,_0x2a38ac),_0x2b85c7):new b(null);}}['foreach'](_0x38dda8){this['foreach_'](w(),_0x38dda8);}['foreach_'](_0x40c6ba,_0x217680){this['children']['inorderTraversal']((_0x4925ef,_0x16151b)=>{_0x16151b['foreach_'](k(_0x40c6ba,_0x4925ef),_0x217680);}),this['value']&&_0x217680(_0x40c6ba,this['value']);}['foreachChild'](_0x515485){this['children']['inorderTraversal']((_0x1151bf,_0xd298b9)=>{_0xd298b9['value']&&_0x515485(_0x1151bf,_0xd298b9['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x5413ab){this['writeTree_']=_0x5413ab;}static['empty'](){return new K(new b(null));}}function At(_0x2c6c98,_0x53bcac,_0x47d7ad){if(v(_0x53bcac))return new K(new b(_0x47d7ad));{const _0xba1f0f=_0x2c6c98['writeTree_']['findRootMostValueAndPath'](_0x53bcac);if(_0xba1f0f!=null){const _0x52629e=_0xba1f0f['path'];let _0x9cf3d1=_0xba1f0f['value'];const _0x33e6ed=F(_0x52629e,_0x53bcac);return _0x9cf3d1=_0x9cf3d1['updateChild'](_0x33e6ed,_0x47d7ad),new K(_0x2c6c98['writeTree_']['set'](_0x52629e,_0x9cf3d1));}else{const _0x2e1e82=new b(_0x47d7ad),_0x3891d5=_0x2c6c98['writeTree_']['setTree'](_0x53bcac,_0x2e1e82);return new K(_0x3891d5);}}}function bi(_0x7263c7,_0x1b0431,_0x42f565){let _0x16cffc=_0x7263c7;return x(_0x42f565,(_0x1e7eee,_0x4db0fb)=>{_0x16cffc=At(_0x16cffc,k(_0x1b0431,_0x1e7eee),_0x4db0fb);}),_0x16cffc;}function or(_0x198f45,_0x223266){if(v(_0x223266))return K['empty']();{const _0x31c2e2=_0x198f45['writeTree_']['setTree'](_0x223266,new b(null));return new K(_0x31c2e2);}}function Ri(_0x931969,_0x24e6d8){return ze(_0x931969,_0x24e6d8)!=null;}function ze(_0x49972a,_0x434be3){const _0x2f91ad=_0x49972a['writeTree_']['findRootMostValueAndPath'](_0x434be3);return _0x2f91ad!=null?_0x49972a['writeTree_']['get'](_0x2f91ad['path'])['getChild'](F(_0x2f91ad['path'],_0x434be3)):null;}function ar(_0x3d439e){const _0x35dc7d=[],_0x4db45a=_0x3d439e['writeTree_']['value'];return _0x4db45a!=null?_0x4db45a['isLeafNode']()||_0x4db45a['forEachChild'](R,(_0x3b8c50,_0x3ea161)=>{_0x35dc7d['push'](new E(_0x3b8c50,_0x3ea161));}):_0x3d439e['writeTree_']['children']['inorderTraversal']((_0x4462ef,_0x2a5871)=>{_0x2a5871['value']!=null&&_0x35dc7d['push'](new E(_0x4462ef,_0x2a5871['value']));}),_0x35dc7d;}function Ee(_0x272745,_0x5c9c8d){if(v(_0x5c9c8d))return _0x272745;{const _0x15a1de=ze(_0x272745,_0x5c9c8d);return _0x15a1de!=null?new K(new b(_0x15a1de)):new K(_0x272745['writeTree_']['subtree'](_0x5c9c8d));}}function Ai(_0x4b972d){return _0x4b972d['writeTree_']['isEmpty']();}function at(_0x52c311,_0x1d88e3){return Uo(w(),_0x52c311['writeTree_'],_0x1d88e3);}function Uo(_0x236531,_0x469eec,_0xe6dec0){if(_0x469eec['value']!=null)return _0xe6dec0['updateChild'](_0x236531,_0x469eec['value']);{let _0x47c1e0=null;return _0x469eec['children']['inorderTraversal']((_0x2d8945,_0x29e080)=>{_0x2d8945==='.priority'?(f(_0x29e080['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x47c1e0=_0x29e080['value']):_0xe6dec0=Uo(k(_0x236531,_0x2d8945),_0x29e080,_0xe6dec0);}),!_0xe6dec0['getChild'](_0x236531)['isEmpty']()&&_0x47c1e0!==null&&(_0xe6dec0=_0xe6dec0['updateChild'](k(_0x236531,'.priority'),_0x47c1e0)),_0xe6dec0;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x3bb7e9,_0x35bb55){return Ho(_0x35bb55,_0x3bb7e9);}function lu(_0x188e1e,_0x4f0961,_0x51c469,_0x53e93d,_0x1cf709){f(_0x53e93d>_0x188e1e['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x1cf709===void 0x0&&(_0x1cf709=!0x0),_0x188e1e['allWrites']['push']({'path':_0x4f0961,'snap':_0x51c469,'writeId':_0x53e93d,'visible':_0x1cf709}),_0x1cf709&&(_0x188e1e['visibleWrites']=At(_0x188e1e['visibleWrites'],_0x4f0961,_0x51c469)),_0x188e1e['lastWriteId']=_0x53e93d;}function hu(_0x26d823,_0x5ee681,_0x2dcd97,_0x2884bf){f(_0x2884bf>_0x26d823['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x26d823['allWrites']['push']({'path':_0x5ee681,'children':_0x2dcd97,'writeId':_0x2884bf,'visible':!0x0}),_0x26d823['visibleWrites']=bi(_0x26d823['visibleWrites'],_0x5ee681,_0x2dcd97),_0x26d823['lastWriteId']=_0x2884bf;}function uu(_0x417464,_0x5cf852){for(let _0x4e25a0=0x0;_0x4e25a0<_0x417464['allWrites']['length'];_0x4e25a0++){const _0x495cdb=_0x417464['allWrites'][_0x4e25a0];if(_0x495cdb['writeId']===_0x5cf852)return _0x495cdb;}return null;}function du(_0x13eb4c,_0x184e0f){const _0x2cabb1=_0x13eb4c['allWrites']['findIndex'](_0x49fa46=>_0x49fa46['writeId']===_0x184e0f);f(_0x2cabb1>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x2f2414=_0x13eb4c['allWrites'][_0x2cabb1];_0x13eb4c['allWrites']['splice'](_0x2cabb1,0x1);let _0x30adf2=_0x2f2414['visible'],_0x16bfde=!0x1,_0x452c21=_0x13eb4c['allWrites']['length']-0x1;for(;_0x30adf2&&_0x452c21>=0x0;){const _0x308d73=_0x13eb4c['allWrites'][_0x452c21];_0x308d73['visible']&&(_0x452c21>=_0x2cabb1&&fu(_0x308d73,_0x2f2414['path'])?_0x30adf2=!0x1:G(_0x2f2414['path'],_0x308d73['path'])&&(_0x16bfde=!0x0)),_0x452c21--;}if(_0x30adf2){if(_0x16bfde)return pu(_0x13eb4c),!0x0;if(_0x2f2414['snap'])_0x13eb4c['visibleWrites']=or(_0x13eb4c['visibleWrites'],_0x2f2414['path']);else{const _0x4ab470=_0x2f2414['children'];x(_0x4ab470,_0x3df382=>{_0x13eb4c['visibleWrites']=or(_0x13eb4c['visibleWrites'],k(_0x2f2414['path'],_0x3df382));});}return!0x0;}else return!0x1;}function fu(_0x307153,_0x377a3d){if(_0x307153['snap'])return G(_0x307153['path'],_0x377a3d);for(const _0x221c4e in _0x307153['children'])if(_0x307153['children']['hasOwnProperty'](_0x221c4e)&&G(k(_0x307153['path'],_0x221c4e),_0x377a3d))return!0x0;return!0x1;}function pu(_0x44c383){_0x44c383['visibleWrites']=Wo(_0x44c383['allWrites'],_u,w()),_0x44c383['allWrites']['length']>0x0?_0x44c383['lastWriteId']=_0x44c383['allWrites'][_0x44c383['allWrites']['length']-0x1]['writeId']:_0x44c383['lastWriteId']=-0x1;}function _u(_0x340374){return _0x340374['visible'];}function Wo(_0x34b85d,_0x176e79,_0x31946c){let _0x52739c=K['empty']();for(let _0xa0205a=0x0;_0xa0205a<_0x34b85d['length'];++_0xa0205a){const _0x1e8c81=_0x34b85d[_0xa0205a];if(_0x176e79(_0x1e8c81)){const _0x2ec696=_0x1e8c81['path'];let _0xc344ba;if(_0x1e8c81['snap'])G(_0x31946c,_0x2ec696)?(_0xc344ba=F(_0x31946c,_0x2ec696),_0x52739c=At(_0x52739c,_0xc344ba,_0x1e8c81['snap'])):G(_0x2ec696,_0x31946c)&&(_0xc344ba=F(_0x2ec696,_0x31946c),_0x52739c=At(_0x52739c,w(),_0x1e8c81['snap']['getChild'](_0xc344ba)));else{if(_0x1e8c81['children']){if(G(_0x31946c,_0x2ec696))_0xc344ba=F(_0x31946c,_0x2ec696),_0x52739c=bi(_0x52739c,_0xc344ba,_0x1e8c81['children']);else{if(G(_0x2ec696,_0x31946c)){if(_0xc344ba=F(_0x2ec696,_0x31946c),v(_0xc344ba))_0x52739c=bi(_0x52739c,w(),_0x1e8c81['children']);else{const _0x31161f=Le(_0x1e8c81['children'],y(_0xc344ba));if(_0x31161f){const _0x323de6=_0x31161f['getChild'](S(_0xc344ba));_0x52739c=At(_0x52739c,w(),_0x323de6);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x52739c;}function Bo(_0x54f285,_0x52298c,_0x10c2e6,_0x3b4321,_0x4a2b12){if(!_0x3b4321&&!_0x4a2b12){const _0xbebba4=ze(_0x54f285['visibleWrites'],_0x52298c);if(_0xbebba4!=null)return _0xbebba4;{const _0x11770f=Ee(_0x54f285['visibleWrites'],_0x52298c);if(Ai(_0x11770f))return _0x10c2e6;if(_0x10c2e6==null&&!Ri(_0x11770f,w()))return null;{const _0x529834=_0x10c2e6||g['EMPTY_NODE'];return at(_0x11770f,_0x529834);}}}else{const _0x1138bc=Ee(_0x54f285['visibleWrites'],_0x52298c);if(!_0x4a2b12&&Ai(_0x1138bc))return _0x10c2e6;if(!_0x4a2b12&&_0x10c2e6==null&&!Ri(_0x1138bc,w()))return null;{const _0x159389=function(_0x220c53){return(_0x220c53['visible']||_0x4a2b12)&&(!_0x3b4321||!~_0x3b4321['indexOf'](_0x220c53['writeId']))&&(G(_0x220c53['path'],_0x52298c)||G(_0x52298c,_0x220c53['path']));},_0x253094=Wo(_0x54f285['allWrites'],_0x159389,_0x52298c),_0x123991=_0x10c2e6||g['EMPTY_NODE'];return at(_0x253094,_0x123991);}}}function gu(_0x417dc9,_0x4af0c5,_0x4c07f8){let _0xff6463=g['EMPTY_NODE'];const _0x219b73=ze(_0x417dc9['visibleWrites'],_0x4af0c5);if(_0x219b73)return _0x219b73['isLeafNode']()||_0x219b73['forEachChild'](R,(_0x1fe023,_0x2340ce)=>{_0xff6463=_0xff6463['updateImmediateChild'](_0x1fe023,_0x2340ce);}),_0xff6463;if(_0x4c07f8){const _0xfefcfa=Ee(_0x417dc9['visibleWrites'],_0x4af0c5);return _0x4c07f8['forEachChild'](R,(_0x5ef1ed,_0x18afa8)=>{const _0x24cacc=at(Ee(_0xfefcfa,new C(_0x5ef1ed)),_0x18afa8);_0xff6463=_0xff6463['updateImmediateChild'](_0x5ef1ed,_0x24cacc);}),ar(_0xfefcfa)['forEach'](_0x4421fe=>{_0xff6463=_0xff6463['updateImmediateChild'](_0x4421fe['name'],_0x4421fe['node']);}),_0xff6463;}else{const _0x3e14d1=Ee(_0x417dc9['visibleWrites'],_0x4af0c5);return ar(_0x3e14d1)['forEach'](_0x4080f5=>{_0xff6463=_0xff6463['updateImmediateChild'](_0x4080f5['name'],_0x4080f5['node']);}),_0xff6463;}}function mu(_0x5f3f5e,_0x14a3f5,_0x3fe2b5,_0x1d0da0,_0x34d9ac){f(_0x1d0da0||_0x34d9ac,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x18bcef=k(_0x14a3f5,_0x3fe2b5);if(Ri(_0x5f3f5e['visibleWrites'],_0x18bcef))return null;{const _0x33ac40=Ee(_0x5f3f5e['visibleWrites'],_0x18bcef);return Ai(_0x33ac40)?_0x34d9ac['getChild'](_0x3fe2b5):at(_0x33ac40,_0x34d9ac['getChild'](_0x3fe2b5));}}function yu(_0x81c6fc,_0x874dd6,_0x4fe910,_0x39ab99){const _0x568816=k(_0x874dd6,_0x4fe910),_0x9e14d6=ze(_0x81c6fc['visibleWrites'],_0x568816);if(_0x9e14d6!=null)return _0x9e14d6;if(_0x39ab99['isCompleteForChild'](_0x4fe910)){const _0x427fbb=Ee(_0x81c6fc['visibleWrites'],_0x568816);return at(_0x427fbb,_0x39ab99['getNode']()['getImmediateChild'](_0x4fe910));}else return null;}function vu(_0x180b64,_0x5b4920){return ze(_0x180b64['visibleWrites'],_0x5b4920);}function Eu(_0x4d13b9,_0x5bc4fc,_0x3749de,_0x407a2c,_0x28f6a3,_0x3a37a2,_0x5dbc1f){let _0xcffef3;const _0x466e1a=Ee(_0x4d13b9['visibleWrites'],_0x5bc4fc),_0x2fc287=ze(_0x466e1a,w());if(_0x2fc287!=null)_0xcffef3=_0x2fc287;else{if(_0x3749de!=null)_0xcffef3=at(_0x466e1a,_0x3749de);else return[];}if(_0xcffef3=_0xcffef3['withIndex'](_0x5dbc1f),!_0xcffef3['isEmpty']()&&!_0xcffef3['isLeafNode']()){const _0x4e1675=[],_0x442923=_0x5dbc1f['getCompare'](),_0x5327f3=_0x3a37a2?_0xcffef3['getReverseIteratorFrom'](_0x407a2c,_0x5dbc1f):_0xcffef3['getIteratorFrom'](_0x407a2c,_0x5dbc1f);let _0x18f7ad=_0x5327f3['getNext']();for(;_0x18f7ad&&_0x4e1675['length']<_0x28f6a3;)_0x442923(_0x18f7ad,_0x407a2c)!==0x0&&_0x4e1675['push'](_0x18f7ad),_0x18f7ad=_0x5327f3['getNext']();return _0x4e1675;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x2bcdd3,_0x43d5ea,_0x11f631,_0x41d2d1){return Bo(_0x2bcdd3['writeTree'],_0x2bcdd3['treePath'],_0x43d5ea,_0x11f631,_0x41d2d1);}function is(_0x1ee119,_0x129065){return gu(_0x1ee119['writeTree'],_0x1ee119['treePath'],_0x129065);}function cr(_0x484441,_0x366ace,_0x43e774,_0x1df833){return mu(_0x484441['writeTree'],_0x484441['treePath'],_0x366ace,_0x43e774,_0x1df833);}function Tn(_0x15d3a0,_0x94e75e){return vu(_0x15d3a0['writeTree'],k(_0x15d3a0['treePath'],_0x94e75e));}function wu(_0x427559,_0x740ec8,_0x5bc55e,_0x190abc,_0x2f7010,_0x69741e){return Eu(_0x427559['writeTree'],_0x427559['treePath'],_0x740ec8,_0x5bc55e,_0x190abc,_0x2f7010,_0x69741e);}function ss(_0x3b28a3,_0x56ed23,_0x572bc5){return yu(_0x3b28a3['writeTree'],_0x3b28a3['treePath'],_0x56ed23,_0x572bc5);}function Vo(_0x1425c6,_0x3bed5c){return Ho(k(_0x1425c6['treePath'],_0x3bed5c),_0x1425c6['writeTree']);}function Ho(_0x99423b,_0x16ec72){return{'treePath':_0x99423b,'writeTree':_0x16ec72};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x6dba0){const _0x5a7994=_0x6dba0['type'],_0x55db72=_0x6dba0['childName'];f(_0x5a7994==='child_added'||_0x5a7994==='child_changed'||_0x5a7994==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x55db72!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x4e455f=this['changeMap']['get'](_0x55db72);if(_0x4e455f){const _0x9962f3=_0x4e455f['type'];if(_0x5a7994==='child_added'&&_0x9962f3==='child_removed')this['changeMap']['set'](_0x55db72,xt(_0x55db72,_0x6dba0['snapshotNode'],_0x4e455f['snapshotNode']));else{if(_0x5a7994==='child_removed'&&_0x9962f3==='child_added')this['changeMap']['delete'](_0x55db72);else{if(_0x5a7994==='child_removed'&&_0x9962f3==='child_changed')this['changeMap']['set'](_0x55db72,Lt(_0x55db72,_0x4e455f['oldSnap']));else{if(_0x5a7994==='child_changed'&&_0x9962f3==='child_added')this['changeMap']['set'](_0x55db72,rt(_0x55db72,_0x6dba0['snapshotNode']));else{if(_0x5a7994==='child_changed'&&_0x9962f3==='child_changed')this['changeMap']['set'](_0x55db72,xt(_0x55db72,_0x6dba0['snapshotNode'],_0x4e455f['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x6dba0+'\x20occurred\x20after\x20'+_0x4e455f);}}}}}else this['changeMap']['set'](_0x55db72,_0x6dba0);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x588253){return null;}['getChildAfterChild'](_0x1ed5ec,_0x1e789b,_0x2c48ab){return null;}}const $o=new Tu();class rs{constructor(_0x22233a,_0xe67bcd,_0x41b949=null){this['writes_']=_0x22233a,this['viewCache_']=_0xe67bcd,this['optCompleteServerCache_']=_0x41b949;}['getCompleteChild'](_0x12d96a){const _0x52afdb=this['viewCache_']['eventCache'];if(_0x52afdb['isCompleteForChild'](_0x12d96a))return _0x52afdb['getNode']()['getImmediateChild'](_0x12d96a);{const _0x3b1e5d=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x12d96a,_0x3b1e5d);}}['getChildAfterChild'](_0x5d7c60,_0x15d0a2,_0x5904fc){const _0x12f433=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x13cf7a=wu(this['writes_'],_0x12f433,_0x15d0a2,0x1,_0x5904fc,_0x5d7c60);return _0x13cf7a['length']===0x0?null:_0x13cf7a[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x32fc6c){return{'filter':_0x32fc6c};}function bu(_0x22ab69,_0x43ea0b){f(_0x43ea0b['eventCache']['getNode']()['isIndexed'](_0x22ab69['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x43ea0b['serverCache']['getNode']()['isIndexed'](_0x22ab69['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x49933b,_0x32c755,_0x1bca07,_0x1365b1,_0x28b2e5){const _0xe4b9e6=new Cu();let _0x34184f,_0x251cae;if(_0x1bca07['type']===z['OVERWRITE']){const _0x42efcf=_0x1bca07;_0x42efcf['source']['fromUser']?_0x34184f=ki(_0x49933b,_0x32c755,_0x42efcf['path'],_0x42efcf['snap'],_0x1365b1,_0x28b2e5,_0xe4b9e6):(f(_0x42efcf['source']['fromServer'],'Unknown\x20source.'),_0x251cae=_0x42efcf['source']['tagged']||_0x32c755['serverCache']['isFiltered']()&&!v(_0x42efcf['path']),_0x34184f=Sn(_0x49933b,_0x32c755,_0x42efcf['path'],_0x42efcf['snap'],_0x1365b1,_0x28b2e5,_0x251cae,_0xe4b9e6));}else{if(_0x1bca07['type']===z['MERGE']){const _0x565b73=_0x1bca07;_0x565b73['source']['fromUser']?_0x34184f=ku(_0x49933b,_0x32c755,_0x565b73['path'],_0x565b73['children'],_0x1365b1,_0x28b2e5,_0xe4b9e6):(f(_0x565b73['source']['fromServer'],'Unknown\x20source.'),_0x251cae=_0x565b73['source']['tagged']||_0x32c755['serverCache']['isFiltered'](),_0x34184f=Pi(_0x49933b,_0x32c755,_0x565b73['path'],_0x565b73['children'],_0x1365b1,_0x28b2e5,_0x251cae,_0xe4b9e6));}else{if(_0x1bca07['type']===z['ACK_USER_WRITE']){const _0x3a8cb0=_0x1bca07;_0x3a8cb0['revert']?_0x34184f=Ou(_0x49933b,_0x32c755,_0x3a8cb0['path'],_0x1365b1,_0x28b2e5,_0xe4b9e6):_0x34184f=Pu(_0x49933b,_0x32c755,_0x3a8cb0['path'],_0x3a8cb0['affectedTree'],_0x1365b1,_0x28b2e5,_0xe4b9e6);}else{if(_0x1bca07['type']===z['LISTEN_COMPLETE'])_0x34184f=Nu(_0x49933b,_0x32c755,_0x1bca07['path'],_0x1365b1,_0xe4b9e6);else throw ht('Unknown\x20operation\x20type:\x20'+_0x1bca07['type']);}}}const _0x2fb97f=_0xe4b9e6['getChanges']();return Au(_0x32c755,_0x34184f,_0x2fb97f),{'viewCache':_0x34184f,'changes':_0x2fb97f};}function Au(_0x1fa611,_0x31bfd7,_0x22c9fd){const _0x24b7f4=_0x31bfd7['eventCache'];if(_0x24b7f4['isFullyInitialized']()){const _0x1a519a=_0x24b7f4['getNode']()['isLeafNode']()||_0x24b7f4['getNode']()['isEmpty'](),_0x11683d=wn(_0x1fa611);(_0x22c9fd['length']>0x0||!_0x1fa611['eventCache']['isFullyInitialized']()||_0x1a519a&&!_0x24b7f4['getNode']()['equals'](_0x11683d)||!_0x24b7f4['getNode']()['getPriority']()['equals'](_0x11683d['getPriority']()))&&_0x22c9fd['push'](Lo(wn(_0x31bfd7)));}}function Go(_0x4db447,_0x39944b,_0x77c0a4,_0x5ce3dc,_0x5867f4,_0x242788){const _0x34c99a=_0x39944b['eventCache'];if(Tn(_0x5ce3dc,_0x77c0a4)!=null)return _0x39944b;{let _0x47737e,_0x3e0fbc;if(v(_0x77c0a4)){if(f(_0x39944b['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x39944b['serverCache']['isFiltered']()){const _0x33b8a5=Ve(_0x39944b),_0x3574ed=_0x33b8a5 instanceof g?_0x33b8a5:g['EMPTY_NODE'],_0x3cb93e=is(_0x5ce3dc,_0x3574ed);_0x47737e=_0x4db447['filter']['updateFullNode'](_0x39944b['eventCache']['getNode'](),_0x3cb93e,_0x242788);}else{const _0xad433e=Cn(_0x5ce3dc,Ve(_0x39944b));_0x47737e=_0x4db447['filter']['updateFullNode'](_0x39944b['eventCache']['getNode'](),_0xad433e,_0x242788);}}else{const _0x370915=y(_0x77c0a4);if(_0x370915==='.priority'){f(Ce(_0x77c0a4)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0xbd7af=_0x34c99a['getNode']();_0x3e0fbc=_0x39944b['serverCache']['getNode']();const _0x290277=cr(_0x5ce3dc,_0x77c0a4,_0xbd7af,_0x3e0fbc);_0x290277!=null?_0x47737e=_0x4db447['filter']['updatePriority'](_0xbd7af,_0x290277):_0x47737e=_0x34c99a['getNode']();}else{const _0x44760e=S(_0x77c0a4);let _0x149d68;if(_0x34c99a['isCompleteForChild'](_0x370915)){_0x3e0fbc=_0x39944b['serverCache']['getNode']();const _0x5e6f77=cr(_0x5ce3dc,_0x77c0a4,_0x34c99a['getNode'](),_0x3e0fbc);_0x5e6f77!=null?_0x149d68=_0x34c99a['getNode']()['getImmediateChild'](_0x370915)['updateChild'](_0x44760e,_0x5e6f77):_0x149d68=_0x34c99a['getNode']()['getImmediateChild'](_0x370915);}else _0x149d68=ss(_0x5ce3dc,_0x370915,_0x39944b['serverCache']);_0x149d68!=null?_0x47737e=_0x4db447['filter']['updateChild'](_0x34c99a['getNode'](),_0x370915,_0x149d68,_0x44760e,_0x5867f4,_0x242788):_0x47737e=_0x34c99a['getNode']();}}return Rt(_0x39944b,_0x47737e,_0x34c99a['isFullyInitialized']()||v(_0x77c0a4),_0x4db447['filter']['filtersNodes']());}}function Sn(_0x44ba56,_0x1f5eba,_0x5b5bc2,_0x322be6,_0x284f3f,_0x1e3676,_0x3f1463,_0x103c5c){const _0x50745b=_0x1f5eba['serverCache'];let _0x43ea17;const _0x424b77=_0x3f1463?_0x44ba56['filter']:_0x44ba56['filter']['getIndexedFilter']();if(v(_0x5b5bc2))_0x43ea17=_0x424b77['updateFullNode'](_0x50745b['getNode'](),_0x322be6,null);else{if(_0x424b77['filtersNodes']()&&!_0x50745b['isFiltered']()){const _0x2e2c4b=_0x50745b['getNode']()['updateChild'](_0x5b5bc2,_0x322be6);_0x43ea17=_0x424b77['updateFullNode'](_0x50745b['getNode'](),_0x2e2c4b,null);}else{const _0x4bae02=y(_0x5b5bc2);if(!_0x50745b['isCompleteForPath'](_0x5b5bc2)&&Ce(_0x5b5bc2)>0x1)return _0x1f5eba;const _0x15f482=S(_0x5b5bc2),_0x3c6d28=_0x50745b['getNode']()['getImmediateChild'](_0x4bae02)['updateChild'](_0x15f482,_0x322be6);_0x4bae02==='.priority'?_0x43ea17=_0x424b77['updatePriority'](_0x50745b['getNode'](),_0x3c6d28):_0x43ea17=_0x424b77['updateChild'](_0x50745b['getNode'](),_0x4bae02,_0x3c6d28,_0x15f482,$o,null);}}const _0xc70633=Fo(_0x1f5eba,_0x43ea17,_0x50745b['isFullyInitialized']()||v(_0x5b5bc2),_0x424b77['filtersNodes']()),_0x63f190=new rs(_0x284f3f,_0xc70633,_0x1e3676);return Go(_0x44ba56,_0xc70633,_0x5b5bc2,_0x284f3f,_0x63f190,_0x103c5c);}function ki(_0x356d7c,_0xeab9fb,_0x4efe79,_0x513586,_0x5c6a6c,_0x983078,_0x3ef2dc){const _0x49b175=_0xeab9fb['eventCache'];let _0x3033bb,_0xff34a9;const _0x17bfca=new rs(_0x5c6a6c,_0xeab9fb,_0x983078);if(v(_0x4efe79))_0xff34a9=_0x356d7c['filter']['updateFullNode'](_0xeab9fb['eventCache']['getNode'](),_0x513586,_0x3ef2dc),_0x3033bb=Rt(_0xeab9fb,_0xff34a9,!0x0,_0x356d7c['filter']['filtersNodes']());else{const _0x1e88d5=y(_0x4efe79);if(_0x1e88d5==='.priority')_0xff34a9=_0x356d7c['filter']['updatePriority'](_0xeab9fb['eventCache']['getNode'](),_0x513586),_0x3033bb=Rt(_0xeab9fb,_0xff34a9,_0x49b175['isFullyInitialized'](),_0x49b175['isFiltered']());else{const _0x74f873=S(_0x4efe79),_0x161818=_0x49b175['getNode']()['getImmediateChild'](_0x1e88d5);let _0x39eb33;if(v(_0x74f873))_0x39eb33=_0x513586;else{const _0x421a76=_0x17bfca['getCompleteChild'](_0x1e88d5);_0x421a76!=null?ji(_0x74f873)==='.priority'&&_0x421a76['getChild'](Ro(_0x74f873))['isEmpty']()?_0x39eb33=_0x421a76:_0x39eb33=_0x421a76['updateChild'](_0x74f873,_0x513586):_0x39eb33=g['EMPTY_NODE'];}if(_0x161818['equals'](_0x39eb33))_0x3033bb=_0xeab9fb;else{const _0x559862=_0x356d7c['filter']['updateChild'](_0x49b175['getNode'](),_0x1e88d5,_0x39eb33,_0x74f873,_0x17bfca,_0x3ef2dc);_0x3033bb=Rt(_0xeab9fb,_0x559862,_0x49b175['isFullyInitialized'](),_0x356d7c['filter']['filtersNodes']());}}}return _0x3033bb;}function lr(_0x576780,_0x2b2eec){return _0x576780['eventCache']['isCompleteForChild'](_0x2b2eec);}function ku(_0x1054ad,_0x48530f,_0x4a13d6,_0x4b0650,_0x1b74b0,_0x8b0667,_0x33bc54){let _0x399945=_0x48530f;return _0x4b0650['foreach']((_0x14ce39,_0x44bd82)=>{const _0x49b684=k(_0x4a13d6,_0x14ce39);lr(_0x48530f,y(_0x49b684))&&(_0x399945=ki(_0x1054ad,_0x399945,_0x49b684,_0x44bd82,_0x1b74b0,_0x8b0667,_0x33bc54));}),_0x4b0650['foreach']((_0x267187,_0x235b08)=>{const _0x595941=k(_0x4a13d6,_0x267187);lr(_0x48530f,y(_0x595941))||(_0x399945=ki(_0x1054ad,_0x399945,_0x595941,_0x235b08,_0x1b74b0,_0x8b0667,_0x33bc54));}),_0x399945;}function hr(_0x53505f,_0x1da723,_0x3b3f48){return _0x3b3f48['foreach']((_0x54f847,_0xd1ab94)=>{_0x1da723=_0x1da723['updateChild'](_0x54f847,_0xd1ab94);}),_0x1da723;}function Pi(_0x1bfe8b,_0x5765bf,_0x5664df,_0x400308,_0xc19eba,_0x55fa7c,_0x2924e8,_0x2dff29){if(_0x5765bf['serverCache']['getNode']()['isEmpty']()&&!_0x5765bf['serverCache']['isFullyInitialized']())return _0x5765bf;let _0xf333b6=_0x5765bf,_0x5dc744;v(_0x5664df)?_0x5dc744=_0x400308:_0x5dc744=new b(null)['setTree'](_0x5664df,_0x400308);const _0x29e871=_0x5765bf['serverCache']['getNode']();return _0x5dc744['children']['inorderTraversal']((_0xa61070,_0x19fe14)=>{if(_0x29e871['hasChild'](_0xa61070)){const _0x43f180=_0x5765bf['serverCache']['getNode']()['getImmediateChild'](_0xa61070),_0x27ceab=hr(_0x1bfe8b,_0x43f180,_0x19fe14);_0xf333b6=Sn(_0x1bfe8b,_0xf333b6,new C(_0xa61070),_0x27ceab,_0xc19eba,_0x55fa7c,_0x2924e8,_0x2dff29);}}),_0x5dc744['children']['inorderTraversal']((_0x2901ae,_0x578383)=>{const _0x2dec7f=!_0x5765bf['serverCache']['isCompleteForChild'](_0x2901ae)&&_0x578383['value']===null;if(!_0x29e871['hasChild'](_0x2901ae)&&!_0x2dec7f){const _0x41626f=_0x5765bf['serverCache']['getNode']()['getImmediateChild'](_0x2901ae),_0x45af67=hr(_0x1bfe8b,_0x41626f,_0x578383);_0xf333b6=Sn(_0x1bfe8b,_0xf333b6,new C(_0x2901ae),_0x45af67,_0xc19eba,_0x55fa7c,_0x2924e8,_0x2dff29);}}),_0xf333b6;}function Pu(_0x36c0e8,_0xc5ed0d,_0x1dbb73,_0x413b07,_0x4856c7,_0xf17517,_0xae29c9){if(Tn(_0x4856c7,_0x1dbb73)!=null)return _0xc5ed0d;const _0xe7a487=_0xc5ed0d['serverCache']['isFiltered'](),_0x19ada5=_0xc5ed0d['serverCache'];if(_0x413b07['value']!=null){if(v(_0x1dbb73)&&_0x19ada5['isFullyInitialized']()||_0x19ada5['isCompleteForPath'](_0x1dbb73))return Sn(_0x36c0e8,_0xc5ed0d,_0x1dbb73,_0x19ada5['getNode']()['getChild'](_0x1dbb73),_0x4856c7,_0xf17517,_0xe7a487,_0xae29c9);if(v(_0x1dbb73)){let _0x4c7a10=new b(null);return _0x19ada5['getNode']()['forEachChild'](ve,(_0x2b4bf0,_0x1c53ec)=>{_0x4c7a10=_0x4c7a10['set'](new C(_0x2b4bf0),_0x1c53ec);}),Pi(_0x36c0e8,_0xc5ed0d,_0x1dbb73,_0x4c7a10,_0x4856c7,_0xf17517,_0xe7a487,_0xae29c9);}else return _0xc5ed0d;}else{let _0x402901=new b(null);return _0x413b07['foreach']((_0x5860d9,_0x1d36ea)=>{const _0x21fad4=k(_0x1dbb73,_0x5860d9);_0x19ada5['isCompleteForPath'](_0x21fad4)&&(_0x402901=_0x402901['set'](_0x5860d9,_0x19ada5['getNode']()['getChild'](_0x21fad4)));}),Pi(_0x36c0e8,_0xc5ed0d,_0x1dbb73,_0x402901,_0x4856c7,_0xf17517,_0xe7a487,_0xae29c9);}}function Nu(_0x11f048,_0xd68594,_0x228044,_0x33fad9,_0x494126){const _0x2f2ca9=_0xd68594['serverCache'],_0x5949a7=Fo(_0xd68594,_0x2f2ca9['getNode'](),_0x2f2ca9['isFullyInitialized']()||v(_0x228044),_0x2f2ca9['isFiltered']());return Go(_0x11f048,_0x5949a7,_0x228044,_0x33fad9,$o,_0x494126);}function Ou(_0x15c4d1,_0x48208e,_0x55defb,_0x567a92,_0x1acf4d,_0x347828){let _0x59cfec;if(Tn(_0x567a92,_0x55defb)!=null)return _0x48208e;{const _0x31d497=new rs(_0x567a92,_0x48208e,_0x1acf4d),_0x405659=_0x48208e['eventCache']['getNode']();let _0x49274a;if(v(_0x55defb)||y(_0x55defb)==='.priority'){let _0x5af3e7;if(_0x48208e['serverCache']['isFullyInitialized']())_0x5af3e7=Cn(_0x567a92,Ve(_0x48208e));else{const _0x219f1a=_0x48208e['serverCache']['getNode']();f(_0x219f1a instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x5af3e7=is(_0x567a92,_0x219f1a);}_0x5af3e7=_0x5af3e7,_0x49274a=_0x15c4d1['filter']['updateFullNode'](_0x405659,_0x5af3e7,_0x347828);}else{const _0x5d6dec=y(_0x55defb);let _0x16861f=ss(_0x567a92,_0x5d6dec,_0x48208e['serverCache']);_0x16861f==null&&_0x48208e['serverCache']['isCompleteForChild'](_0x5d6dec)&&(_0x16861f=_0x405659['getImmediateChild'](_0x5d6dec)),_0x16861f!=null?_0x49274a=_0x15c4d1['filter']['updateChild'](_0x405659,_0x5d6dec,_0x16861f,S(_0x55defb),_0x31d497,_0x347828):_0x48208e['eventCache']['getNode']()['hasChild'](_0x5d6dec)?_0x49274a=_0x15c4d1['filter']['updateChild'](_0x405659,_0x5d6dec,g['EMPTY_NODE'],S(_0x55defb),_0x31d497,_0x347828):_0x49274a=_0x405659,_0x49274a['isEmpty']()&&_0x48208e['serverCache']['isFullyInitialized']()&&(_0x59cfec=Cn(_0x567a92,Ve(_0x48208e)),_0x59cfec['isLeafNode']()&&(_0x49274a=_0x15c4d1['filter']['updateFullNode'](_0x49274a,_0x59cfec,_0x347828)));}return _0x59cfec=_0x48208e['serverCache']['isFullyInitialized']()||Tn(_0x567a92,w())!=null,Rt(_0x48208e,_0x49274a,_0x59cfec,_0x15c4d1['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x33dcd0,_0x4dcd52){this['query_']=_0x33dcd0,this['eventRegistrations_']=[];const _0x49af59=this['query_']['_queryParams'],_0x334e0b=new Xi(_0x49af59['getIndex']()),_0x10f6a4=Kh(_0x49af59);this['processor_']=Su(_0x10f6a4);const _0x954be7=_0x4dcd52['serverCache'],_0x41216f=_0x4dcd52['eventCache'],_0x1192e1=_0x334e0b['updateFullNode'](g['EMPTY_NODE'],_0x954be7['getNode'](),null),_0x47eca7=_0x10f6a4['updateFullNode'](g['EMPTY_NODE'],_0x41216f['getNode'](),null),_0xd01c1e=new Te(_0x1192e1,_0x954be7['isFullyInitialized'](),_0x334e0b['filtersNodes']()),_0x531266=new Te(_0x47eca7,_0x41216f['isFullyInitialized'](),_0x10f6a4['filtersNodes']());this['viewCache_']=Un(_0x531266,_0xd01c1e),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x5a27e1){return _0x5a27e1['viewCache_']['serverCache']['getNode']();}function Lu(_0x7ccfb2){return wn(_0x7ccfb2['viewCache_']);}function xu(_0x324636,_0x35b5ac){const _0x1a3996=Ve(_0x324636['viewCache_']);return _0x1a3996&&(_0x324636['query']['_queryParams']['loadsAllData']()||!v(_0x35b5ac)&&!_0x1a3996['getImmediateChild'](y(_0x35b5ac))['isEmpty']())?_0x1a3996['getChild'](_0x35b5ac):null;}function ur(_0x47b0e8){return _0x47b0e8['eventRegistrations_']['length']===0x0;}function Fu(_0x3ea8c4,_0xb0004b){_0x3ea8c4['eventRegistrations_']['push'](_0xb0004b);}function dr(_0x43a0dd,_0x5d42d4,_0x14ee34){const _0x57316a=[];if(_0x14ee34){f(_0x5d42d4==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x1f6ab7=_0x43a0dd['query']['_path'];_0x43a0dd['eventRegistrations_']['forEach'](_0x4ca323=>{const _0x7ef9db=_0x4ca323['createCancelEvent'](_0x14ee34,_0x1f6ab7);_0x7ef9db&&_0x57316a['push'](_0x7ef9db);});}if(_0x5d42d4){let _0x19cb57=[];for(let _0x14cf0c=0x0;_0x14cf0c<_0x43a0dd['eventRegistrations_']['length'];++_0x14cf0c){const _0x12eff6=_0x43a0dd['eventRegistrations_'][_0x14cf0c];if(!_0x12eff6['matches'](_0x5d42d4))_0x19cb57['push'](_0x12eff6);else{if(_0x5d42d4['hasAnyCallback']()){_0x19cb57=_0x19cb57['concat'](_0x43a0dd['eventRegistrations_']['slice'](_0x14cf0c+0x1));break;}}}_0x43a0dd['eventRegistrations_']=_0x19cb57;}else _0x43a0dd['eventRegistrations_']=[];return _0x57316a;}function fr(_0x574afd,_0x4410ac,_0x37818c,_0x4c7b71){_0x4410ac['type']===z['MERGE']&&_0x4410ac['source']['queryId']!==null&&(f(Ve(_0x574afd['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x574afd['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x37d2c6=_0x574afd['viewCache_'],_0x4df1ba=Ru(_0x574afd['processor_'],_0x37d2c6,_0x4410ac,_0x37818c,_0x4c7b71);return bu(_0x574afd['processor_'],_0x4df1ba['viewCache']),f(_0x4df1ba['viewCache']['serverCache']['isFullyInitialized']()||!_0x37d2c6['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x574afd['viewCache_']=_0x4df1ba['viewCache'],qo(_0x574afd,_0x4df1ba['changes'],_0x4df1ba['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x228d6b,_0x1c083e){const _0x550684=_0x228d6b['viewCache_']['eventCache'],_0xdae639=[];return _0x550684['getNode']()['isLeafNode']()||_0x550684['getNode']()['forEachChild'](R,(_0x40614c,_0x445d51)=>{_0xdae639['push'](rt(_0x40614c,_0x445d51));}),_0x550684['isFullyInitialized']()&&_0xdae639['push'](Lo(_0x550684['getNode']())),qo(_0x228d6b,_0xdae639,_0x550684['getNode'](),_0x1c083e);}function qo(_0x42d3ac,_0x16bc8e,_0x37a4c5,_0x50c5e9){const _0x2f3838=_0x50c5e9?[_0x50c5e9]:_0x42d3ac['eventRegistrations_'];return ru(_0x42d3ac['eventGenerator_'],_0x16bc8e,_0x37a4c5,_0x2f3838);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x5ab542){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x5ab542;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x3d4c00){return _0x3d4c00['views']['size']===0x0;}function os(_0x241e75,_0x2f8de7,_0x4cfda1,_0x53a7e9){const _0x18b131=_0x2f8de7['source']['queryId'];if(_0x18b131!==null){const _0x192639=_0x241e75['views']['get'](_0x18b131);return f(_0x192639!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x192639,_0x2f8de7,_0x4cfda1,_0x53a7e9);}else{let _0x14877e=[];for(const _0x1fd685 of _0x241e75['views']['values']())_0x14877e=_0x14877e['concat'](fr(_0x1fd685,_0x2f8de7,_0x4cfda1,_0x53a7e9));return _0x14877e;}}function jo(_0x406f66,_0x5001a6,_0x53e1ed,_0x345544,_0x4e6aed){const _0x390600=_0x5001a6['_queryIdentifier'],_0x465069=_0x406f66['views']['get'](_0x390600);if(!_0x465069){let _0x2e6986=Cn(_0x53e1ed,_0x4e6aed?_0x345544:null),_0x1c0ad2=!0x1;_0x2e6986?_0x1c0ad2=!0x0:_0x345544 instanceof g?(_0x2e6986=is(_0x53e1ed,_0x345544),_0x1c0ad2=!0x1):(_0x2e6986=g['EMPTY_NODE'],_0x1c0ad2=!0x1);const _0x2db9f2=Un(new Te(_0x2e6986,_0x1c0ad2,!0x1),new Te(_0x345544,_0x4e6aed,!0x1));return new Du(_0x5001a6,_0x2db9f2);}return _0x465069;}function Hu(_0x2eddbf,_0x260f82,_0x4fa63d,_0x536c0a,_0x56f9dc,_0x4c0fea){const _0x11a94a=jo(_0x2eddbf,_0x260f82,_0x536c0a,_0x56f9dc,_0x4c0fea);return _0x2eddbf['views']['has'](_0x260f82['_queryIdentifier'])||_0x2eddbf['views']['set'](_0x260f82['_queryIdentifier'],_0x11a94a),Fu(_0x11a94a,_0x4fa63d),Uu(_0x11a94a,_0x4fa63d);}function $u(_0x1374b7,_0x1a5195,_0x4fefe0,_0x4a66ba){const _0x16c0a4=_0x1a5195['_queryIdentifier'],_0x5695e7=[];let _0x1c5e66=[];const _0x33ddb1=Se(_0x1374b7);if(_0x16c0a4==='default'){for(const [_0x47703f,_0x2c3402]of _0x1374b7['views']['entries']())_0x1c5e66=_0x1c5e66['concat'](dr(_0x2c3402,_0x4fefe0,_0x4a66ba)),ur(_0x2c3402)&&(_0x1374b7['views']['delete'](_0x47703f),_0x2c3402['query']['_queryParams']['loadsAllData']()||_0x5695e7['push'](_0x2c3402['query']));}else{const _0x4beb97=_0x1374b7['views']['get'](_0x16c0a4);_0x4beb97&&(_0x1c5e66=_0x1c5e66['concat'](dr(_0x4beb97,_0x4fefe0,_0x4a66ba)),ur(_0x4beb97)&&(_0x1374b7['views']['delete'](_0x16c0a4),_0x4beb97['query']['_queryParams']['loadsAllData']()||_0x5695e7['push'](_0x4beb97['query'])));}return _0x33ddb1&&!Se(_0x1374b7)&&_0x5695e7['push'](new(Bu())(_0x1a5195['_repo'],_0x1a5195['_path'])),{'removed':_0x5695e7,'events':_0x1c5e66};}function Ko(_0x3f624){const _0x11d466=[];for(const _0x1215e6 of _0x3f624['views']['values']())_0x1215e6['query']['_queryParams']['loadsAllData']()||_0x11d466['push'](_0x1215e6);return _0x11d466;}function Ie(_0x3e941c,_0x6c1ccc){let _0x496aab=null;for(const _0x11c71f of _0x3e941c['views']['values']())_0x496aab=_0x496aab||xu(_0x11c71f,_0x6c1ccc);return _0x496aab;}function Yo(_0x2ef947,_0xb54e2b){if(_0xb54e2b['_queryParams']['loadsAllData']())return Bn(_0x2ef947);{const _0x39cd06=_0xb54e2b['_queryIdentifier'];return _0x2ef947['views']['get'](_0x39cd06);}}function Qo(_0x3f1d5f,_0x2b4b35){return Yo(_0x3f1d5f,_0x2b4b35)!=null;}function Se(_0x2dc6c7){return Bn(_0x2dc6c7)!=null;}function Bn(_0x2f98d6){for(const _0x3024eb of _0x2f98d6['views']['values']())if(_0x3024eb['query']['_queryParams']['loadsAllData']())return _0x3024eb;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0xc37b24){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0xc37b24;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x3bd6bd){this['listenProvider_']=_0x3bd6bd,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x3c5dd8,_0x102534,_0x3a9f37,_0x555e6a,_0x12e160){return lu(_0x3c5dd8['pendingWriteTree_'],_0x102534,_0x3a9f37,_0x555e6a,_0x12e160),_0x12e160?_t(_0x3c5dd8,new Be(es(),_0x102534,_0x3a9f37)):[];}function ju(_0x288d65,_0x55c2bc,_0x14de1f,_0x4ca9c2){hu(_0x288d65['pendingWriteTree_'],_0x55c2bc,_0x14de1f,_0x4ca9c2);const _0x1dda0f=b['fromObject'](_0x14de1f);return _t(_0x288d65,new ot(es(),_0x55c2bc,_0x1dda0f));}function _e(_0x21df9b,_0xd1fda2,_0x9da751=!0x1){const _0x2612d2=uu(_0x21df9b['pendingWriteTree_'],_0xd1fda2);if(du(_0x21df9b['pendingWriteTree_'],_0xd1fda2)){let _0x4e988f=new b(null);return _0x2612d2['snap']!=null?_0x4e988f=_0x4e988f['set'](w(),!0x0):x(_0x2612d2['children'],_0x3e149f=>{_0x4e988f=_0x4e988f['set'](new C(_0x3e149f),!0x0);}),_t(_0x21df9b,new In(_0x2612d2['path'],_0x4e988f,_0x9da751));}else return[];}function Yt(_0x5076a6,_0x189177,_0x38cfc3){return _t(_0x5076a6,new Be(ts(),_0x189177,_0x38cfc3));}function Ku(_0x222df7,_0x16aab8,_0x9a72c5){const _0x281b56=b['fromObject'](_0x9a72c5);return _t(_0x222df7,new ot(ts(),_0x16aab8,_0x281b56));}function Yu(_0x3f84e6,_0x1ea0b1){return _t(_0x3f84e6,new Ut(ts(),_0x1ea0b1));}function Qu(_0x4ce428,_0x3ea01a,_0x3aa24b){const _0x2282a6=cs(_0x4ce428,_0x3aa24b);if(_0x2282a6){const _0x5b661c=ls(_0x2282a6),_0x1cb5bb=_0x5b661c['path'],_0x304fa1=_0x5b661c['queryId'],_0x1653ba=F(_0x1cb5bb,_0x3ea01a),_0x482d04=new Ut(ns(_0x304fa1),_0x1653ba);return hs(_0x4ce428,_0x1cb5bb,_0x482d04);}else return[];}function An(_0x4724d4,_0x54be12,_0x1fc235,_0x5cc7ef,_0x5c889a=!0x1){const _0x4165f6=_0x54be12['_path'],_0x37f727=_0x4724d4['syncPointTree_']['get'](_0x4165f6);let _0x5b3cf3=[];if(_0x37f727&&(_0x54be12['_queryIdentifier']==='default'||Qo(_0x37f727,_0x54be12))){const _0x3c5e98=$u(_0x37f727,_0x54be12,_0x1fc235,_0x5cc7ef);Vu(_0x37f727)&&(_0x4724d4['syncPointTree_']=_0x4724d4['syncPointTree_']['remove'](_0x4165f6));const _0x2ba2cf=_0x3c5e98['removed'];if(_0x5b3cf3=_0x3c5e98['events'],!_0x5c889a){const _0x11d854=_0x2ba2cf['findIndex'](_0x4a17b8=>_0x4a17b8['_queryParams']['loadsAllData']())!==-0x1,_0x52a81b=_0x4724d4['syncPointTree_']['findOnPath'](_0x4165f6,(_0x1faacf,_0x491ba7)=>Se(_0x491ba7));if(_0x11d854&&!_0x52a81b){const _0x3d936a=_0x4724d4['syncPointTree_']['subtree'](_0x4165f6);if(!_0x3d936a['isEmpty']()){const _0x73941c=Zu(_0x3d936a);for(let _0x401cce=0x0;_0x401cce<_0x73941c['length'];++_0x401cce){const _0x3a3fca=_0x73941c[_0x401cce],_0x1618e1=_0x3a3fca['query'],_0x39b6d4=ea(_0x4724d4,_0x3a3fca);_0x4724d4['listenProvider_']['startListening'](kt(_0x1618e1),Wt(_0x4724d4,_0x1618e1),_0x39b6d4['hashFn'],_0x39b6d4['onComplete']);}}}!_0x52a81b&&_0x2ba2cf['length']>0x0&&!_0x5cc7ef&&(_0x11d854?_0x4724d4['listenProvider_']['stopListening'](kt(_0x54be12),null):_0x2ba2cf['forEach'](_0x381604=>{const _0xa35384=_0x4724d4['queryToTagMap']['get'](Hn(_0x381604));_0x4724d4['listenProvider_']['stopListening'](kt(_0x381604),_0xa35384);}));}ed(_0x4724d4,_0x2ba2cf);}return _0x5b3cf3;}function Jo(_0x33911b,_0x4b5094,_0x111e29,_0x30a4c9){const _0x88b96e=cs(_0x33911b,_0x30a4c9);if(_0x88b96e!=null){const _0x42ac47=ls(_0x88b96e),_0x24a931=_0x42ac47['path'],_0x238385=_0x42ac47['queryId'],_0x281a00=F(_0x24a931,_0x4b5094),_0x5b20d9=new Be(ns(_0x238385),_0x281a00,_0x111e29);return hs(_0x33911b,_0x24a931,_0x5b20d9);}else return[];}function Ju(_0x1ed245,_0x163762,_0x376bd5,_0x57f0a3){const _0x57e653=cs(_0x1ed245,_0x57f0a3);if(_0x57e653){const _0x3b1ef7=ls(_0x57e653),_0x3e9bf0=_0x3b1ef7['path'],_0x5cda0e=_0x3b1ef7['queryId'],_0x16b7a6=F(_0x3e9bf0,_0x163762),_0x2f948d=b['fromObject'](_0x376bd5),_0x27649e=new ot(ns(_0x5cda0e),_0x16b7a6,_0x2f948d);return hs(_0x1ed245,_0x3e9bf0,_0x27649e);}else return[];}function Ni(_0x14ef8d,_0x44888e,_0xf5e744,_0x512295=!0x1){const _0x4cdf67=_0x44888e['_path'];let _0x5c4c71=null,_0x49ad6a=!0x1;_0x14ef8d['syncPointTree_']['foreachOnPath'](_0x4cdf67,(_0x17d022,_0x1638cc)=>{const _0x21991a=F(_0x17d022,_0x4cdf67);_0x5c4c71=_0x5c4c71||Ie(_0x1638cc,_0x21991a),_0x49ad6a=_0x49ad6a||Se(_0x1638cc);});let _0x922009=_0x14ef8d['syncPointTree_']['get'](_0x4cdf67);_0x922009?(_0x49ad6a=_0x49ad6a||Se(_0x922009),_0x5c4c71=_0x5c4c71||Ie(_0x922009,w())):(_0x922009=new zo(),_0x14ef8d['syncPointTree_']=_0x14ef8d['syncPointTree_']['set'](_0x4cdf67,_0x922009));let _0x27257f;_0x5c4c71!=null?_0x27257f=!0x0:(_0x27257f=!0x1,_0x5c4c71=g['EMPTY_NODE'],_0x14ef8d['syncPointTree_']['subtree'](_0x4cdf67)['foreachChild']((_0x3dc801,_0x56a4fd)=>{const _0x276a70=Ie(_0x56a4fd,w());_0x276a70&&(_0x5c4c71=_0x5c4c71['updateImmediateChild'](_0x3dc801,_0x276a70));}));const _0x227d3c=Qo(_0x922009,_0x44888e);if(!_0x227d3c&&!_0x44888e['_queryParams']['loadsAllData']()){const _0x324c39=Hn(_0x44888e);f(!_0x14ef8d['queryToTagMap']['has'](_0x324c39),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x50c99f=td();_0x14ef8d['queryToTagMap']['set'](_0x324c39,_0x50c99f),_0x14ef8d['tagToQueryMap']['set'](_0x50c99f,_0x324c39);}const _0x4c39f8=Wn(_0x14ef8d['pendingWriteTree_'],_0x4cdf67);let _0x3ae2fd=Hu(_0x922009,_0x44888e,_0xf5e744,_0x4c39f8,_0x5c4c71,_0x27257f);if(!_0x227d3c&&!_0x49ad6a&&!_0x512295){const _0x44ba3b=Yo(_0x922009,_0x44888e);_0x3ae2fd=_0x3ae2fd['concat'](nd(_0x14ef8d,_0x44888e,_0x44ba3b));}return _0x3ae2fd;}function Vn(_0x2797e6,_0x1662d9,_0x5742e4){const _0x5875bd=_0x2797e6['pendingWriteTree_'],_0x76143c=_0x2797e6['syncPointTree_']['findOnPath'](_0x1662d9,(_0x42994e,_0x259d5a)=>{const _0xe9c98=F(_0x42994e,_0x1662d9),_0x302a39=Ie(_0x259d5a,_0xe9c98);if(_0x302a39)return _0x302a39;});return Bo(_0x5875bd,_0x1662d9,_0x76143c,_0x5742e4,!0x0);}function Xu(_0x3b9ff3,_0x241ee1){const _0xbbcec4=_0x241ee1['_path'];let _0x7bdbad=null;_0x3b9ff3['syncPointTree_']['foreachOnPath'](_0xbbcec4,(_0x57f77e,_0x4cbe18)=>{const _0x505721=F(_0x57f77e,_0xbbcec4);_0x7bdbad=_0x7bdbad||Ie(_0x4cbe18,_0x505721);});let _0x5e5de5=_0x3b9ff3['syncPointTree_']['get'](_0xbbcec4);_0x5e5de5?_0x7bdbad=_0x7bdbad||Ie(_0x5e5de5,w()):(_0x5e5de5=new zo(),_0x3b9ff3['syncPointTree_']=_0x3b9ff3['syncPointTree_']['set'](_0xbbcec4,_0x5e5de5));const _0x3423bc=_0x7bdbad!=null,_0xaa26da=_0x3423bc?new Te(_0x7bdbad,!0x0,!0x1):null,_0x6ca586=Wn(_0x3b9ff3['pendingWriteTree_'],_0x241ee1['_path']),_0x58d42c=jo(_0x5e5de5,_0x241ee1,_0x6ca586,_0x3423bc?_0xaa26da['getNode']():g['EMPTY_NODE'],_0x3423bc);return Lu(_0x58d42c);}function _t(_0xce6df1,_0x1b174e){return Xo(_0x1b174e,_0xce6df1['syncPointTree_'],null,Wn(_0xce6df1['pendingWriteTree_'],w()));}function Xo(_0x7b0cf3,_0x42a675,_0x5d5baa,_0x2ad27f){if(v(_0x7b0cf3['path']))return Zo(_0x7b0cf3,_0x42a675,_0x5d5baa,_0x2ad27f);{const _0x12fc55=_0x42a675['get'](w());_0x5d5baa==null&&_0x12fc55!=null&&(_0x5d5baa=Ie(_0x12fc55,w()));let _0x11689d=[];const _0x2e35fc=y(_0x7b0cf3['path']),_0x180d53=_0x7b0cf3['operationForChild'](_0x2e35fc),_0x4aaead=_0x42a675['children']['get'](_0x2e35fc);if(_0x4aaead&&_0x180d53){const _0x5d2167=_0x5d5baa?_0x5d5baa['getImmediateChild'](_0x2e35fc):null,_0x5a179c=Vo(_0x2ad27f,_0x2e35fc);_0x11689d=_0x11689d['concat'](Xo(_0x180d53,_0x4aaead,_0x5d2167,_0x5a179c));}return _0x12fc55&&(_0x11689d=_0x11689d['concat'](os(_0x12fc55,_0x7b0cf3,_0x2ad27f,_0x5d5baa))),_0x11689d;}}function Zo(_0x39b6ae,_0x5d2319,_0xfc438,_0x560c13){const _0x216f16=_0x5d2319['get'](w());_0xfc438==null&&_0x216f16!=null&&(_0xfc438=Ie(_0x216f16,w()));let _0x1b9827=[];return _0x5d2319['children']['inorderTraversal']((_0x222fdb,_0x51fa2c)=>{const _0x2cebed=_0xfc438?_0xfc438['getImmediateChild'](_0x222fdb):null,_0x5906c8=Vo(_0x560c13,_0x222fdb),_0x37a045=_0x39b6ae['operationForChild'](_0x222fdb);_0x37a045&&(_0x1b9827=_0x1b9827['concat'](Zo(_0x37a045,_0x51fa2c,_0x2cebed,_0x5906c8)));}),_0x216f16&&(_0x1b9827=_0x1b9827['concat'](os(_0x216f16,_0x39b6ae,_0x560c13,_0xfc438))),_0x1b9827;}function ea(_0x24ba99,_0x105430){const _0x3b9bf2=_0x105430['query'],_0x368cb6=Wt(_0x24ba99,_0x3b9bf2);return{'hashFn':()=>(Mu(_0x105430)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x49f567=>{if(_0x49f567==='ok')return _0x368cb6?Qu(_0x24ba99,_0x3b9bf2['_path'],_0x368cb6):Yu(_0x24ba99,_0x3b9bf2['_path']);{const _0x196a04=Kl(_0x49f567,_0x3b9bf2);return An(_0x24ba99,_0x3b9bf2,null,_0x196a04);}}};}function Wt(_0x17c3fd,_0x99bfb2){const _0x405a46=Hn(_0x99bfb2);return _0x17c3fd['queryToTagMap']['get'](_0x405a46);}function Hn(_0x28cbfa){return _0x28cbfa['_path']['toString']()+'$'+_0x28cbfa['_queryIdentifier'];}function cs(_0x40d894,_0x21960f){return _0x40d894['tagToQueryMap']['get'](_0x21960f);}function ls(_0x48bbd5){const _0x47b3e8=_0x48bbd5['indexOf']('$');return f(_0x47b3e8!==-0x1&&_0x47b3e8<_0x48bbd5['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x48bbd5['substr'](_0x47b3e8+0x1),'path':new C(_0x48bbd5['substr'](0x0,_0x47b3e8))};}function hs(_0x232433,_0x167ee2,_0x169428){const _0x4b5c43=_0x232433['syncPointTree_']['get'](_0x167ee2);f(_0x4b5c43,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x33106c=Wn(_0x232433['pendingWriteTree_'],_0x167ee2);return os(_0x4b5c43,_0x169428,_0x33106c,null);}function Zu(_0x52c365){return _0x52c365['fold']((_0x1ab089,_0x39e8fe,_0x286e3f)=>{if(_0x39e8fe&&Se(_0x39e8fe))return[Bn(_0x39e8fe)];{let _0x2bec30=[];return _0x39e8fe&&(_0x2bec30=Ko(_0x39e8fe)),x(_0x286e3f,(_0x49253c,_0x8a6969)=>{_0x2bec30=_0x2bec30['concat'](_0x8a6969);}),_0x2bec30;}});}function kt(_0x5b7be6){return _0x5b7be6['_queryParams']['loadsAllData']()&&!_0x5b7be6['_queryParams']['isDefault']()?new(qu())(_0x5b7be6['_repo'],_0x5b7be6['_path']):_0x5b7be6;}function ed(_0x890de1,_0x5adb5d){for(let _0x5f2526=0x0;_0x5f2526<_0x5adb5d['length'];++_0x5f2526){const _0x1e9c7a=_0x5adb5d[_0x5f2526];if(!_0x1e9c7a['_queryParams']['loadsAllData']()){const _0x162d8c=Hn(_0x1e9c7a),_0x117d45=_0x890de1['queryToTagMap']['get'](_0x162d8c);_0x890de1['queryToTagMap']['delete'](_0x162d8c),_0x890de1['tagToQueryMap']['delete'](_0x117d45);}}}function td(){return zu++;}function nd(_0x1677a2,_0xffe36b,_0x1d6947){const _0x2a6042=_0xffe36b['_path'],_0x5a8ba4=Wt(_0x1677a2,_0xffe36b),_0x4384f0=ea(_0x1677a2,_0x1d6947),_0x5341c7=_0x1677a2['listenProvider_']['startListening'](kt(_0xffe36b),_0x5a8ba4,_0x4384f0['hashFn'],_0x4384f0['onComplete']),_0x23b51e=_0x1677a2['syncPointTree_']['subtree'](_0x2a6042);if(_0x5a8ba4)f(!Se(_0x23b51e['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0xfa61ae=_0x23b51e['fold']((_0x295ee2,_0x4ff884,_0x2ba566)=>{if(!v(_0x295ee2)&&_0x4ff884&&Se(_0x4ff884))return[Bn(_0x4ff884)['query']];{let _0x4b11a2=[];return _0x4ff884&&(_0x4b11a2=_0x4b11a2['concat'](Ko(_0x4ff884)['map'](_0x954102=>_0x954102['query']))),x(_0x2ba566,(_0x42b7fd,_0x4ccfd1)=>{_0x4b11a2=_0x4b11a2['concat'](_0x4ccfd1);}),_0x4b11a2;}});for(let _0x25e877=0x0;_0x25e877<_0xfa61ae['length'];++_0x25e877){const _0x13293b=_0xfa61ae[_0x25e877];_0x1677a2['listenProvider_']['stopListening'](kt(_0x13293b),Wt(_0x1677a2,_0x13293b));}}return _0x5341c7;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x54bc14){this['node_']=_0x54bc14;}['getImmediateChild'](_0x16c343){const _0x323e73=this['node_']['getImmediateChild'](_0x16c343);return new us(_0x323e73);}['node'](){return this['node_'];}}class ds{constructor(_0xf3e21c,_0x4bb410){this['syncTree_']=_0xf3e21c,this['path_']=_0x4bb410;}['getImmediateChild'](_0x7fa7f8){const _0x13b836=k(this['path_'],_0x7fa7f8);return new ds(this['syncTree_'],_0x13b836);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x174e11){return _0x174e11=_0x174e11||{},_0x174e11['timestamp']=_0x174e11['timestamp']||new Date()['getTime'](),_0x174e11;},_r=function(_0x5e0525,_0x315397,_0x5951de){if(!_0x5e0525||typeof _0x5e0525!='object')return _0x5e0525;if(f('.sv'in _0x5e0525,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x5e0525['.sv']=='string')return sd(_0x5e0525['.sv'],_0x315397,_0x5951de);if(typeof _0x5e0525['.sv']=='object')return rd(_0x5e0525['.sv'],_0x315397);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x5e0525,null,0x2));},sd=function(_0x592ad8,_0x79cf87,_0x22fb17){switch(_0x592ad8){case'timestamp':return _0x22fb17['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x592ad8);}},rd=function(_0x276776,_0x5431d5,_0x5d7c98){_0x276776['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x276776,null,0x2));const _0x5a82d5=_0x276776['increment'];typeof _0x5a82d5!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x5a82d5);const _0x144812=_0x5431d5['node']();if(f(_0x144812!==null&&typeof _0x144812<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x144812['isLeafNode']())return _0x5a82d5;const _0x3b48f9=_0x144812['getValue']();return typeof _0x3b48f9!='number'?_0x5a82d5:_0x3b48f9+_0x5a82d5;},ta=function(_0x2b8d22,_0x24f369,_0x42d1a8,_0x1b2d31){return ps(_0x24f369,new ds(_0x42d1a8,_0x2b8d22),_0x1b2d31);},fs=function(_0x5a7a95,_0x41e4db,_0x56e79e){return ps(_0x5a7a95,new us(_0x41e4db),_0x56e79e);};function ps(_0x16c182,_0x586c29,_0x144d85){const _0x242b12=_0x16c182['getPriority']()['val'](),_0xf9c991=_r(_0x242b12,_0x586c29['getImmediateChild']('.priority'),_0x144d85);let _0x5e48b9;if(_0x16c182['isLeafNode']()){const _0x4604c8=_0x16c182,_0x9d2a12=_r(_0x4604c8['getValue'](),_0x586c29,_0x144d85);return _0x9d2a12!==_0x4604c8['getValue']()||_0xf9c991!==_0x4604c8['getPriority']()['val']()?new D(_0x9d2a12,A(_0xf9c991)):_0x16c182;}else{const _0x2739e1=_0x16c182;return _0x5e48b9=_0x2739e1,_0xf9c991!==_0x2739e1['getPriority']()['val']()&&(_0x5e48b9=_0x5e48b9['updatePriority'](new D(_0xf9c991))),_0x2739e1['forEachChild'](R,(_0x2fec3d,_0x4ebc8a)=>{const _0x44be89=ps(_0x4ebc8a,_0x586c29['getImmediateChild'](_0x2fec3d),_0x144d85);_0x44be89!==_0x4ebc8a&&(_0x5e48b9=_0x5e48b9['updateImmediateChild'](_0x2fec3d,_0x44be89));}),_0x5e48b9;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x173c3f='',_0x2f00e1=null,_0x42de40={'children':{},'childCount':0x0}){this['name']=_0x173c3f,this['parent']=_0x2f00e1,this['node']=_0x42de40;}}function $n(_0x4ce4cb,_0x1ff456){let _0x2f5496=_0x1ff456 instanceof C?_0x1ff456:new C(_0x1ff456),_0x237b6a=_0x4ce4cb,_0x513800=y(_0x2f5496);for(;_0x513800!==null;){const _0x410207=Le(_0x237b6a['node']['children'],_0x513800)||{'children':{},'childCount':0x0};_0x237b6a=new _s(_0x513800,_0x237b6a,_0x410207),_0x2f5496=S(_0x2f5496),_0x513800=y(_0x2f5496);}return _0x237b6a;}function je(_0x17bcbb){return _0x17bcbb['node']['value'];}function gs(_0x98a6fc,_0x519c16){_0x98a6fc['node']['value']=_0x519c16,Oi(_0x98a6fc);}function na(_0x5d4a89){return _0x5d4a89['node']['childCount']>0x0;}function od(_0x24738c){return je(_0x24738c)===void 0x0&&!na(_0x24738c);}function Gn(_0x27acb0,_0x437ee5){x(_0x27acb0['node']['children'],(_0x14e544,_0x4a2dd1)=>{_0x437ee5(new _s(_0x14e544,_0x27acb0,_0x4a2dd1));});}function ia(_0x47302c,_0x48e24e,_0x187cae,_0x52c05b){_0x187cae&&_0x48e24e(_0x47302c),Gn(_0x47302c,_0x23343e=>{ia(_0x23343e,_0x48e24e,!0x0);});}function ad(_0x260642,_0x4fe3fb,_0x4c5932){let _0x2aaebe=_0x260642['parent'];for(;_0x2aaebe!==null;){if(_0x4fe3fb(_0x2aaebe))return!0x0;_0x2aaebe=_0x2aaebe['parent'];}return!0x1;}function Qt(_0x7a137){return new C(_0x7a137['parent']===null?_0x7a137['name']:Qt(_0x7a137['parent'])+'/'+_0x7a137['name']);}function Oi(_0xd9d484){_0xd9d484['parent']!==null&&cd(_0xd9d484['parent'],_0xd9d484['name'],_0xd9d484);}function cd(_0x19f4ac,_0x4f9f8f,_0x50b722){const _0x319af3=od(_0x50b722),_0x21dec4=Q(_0x19f4ac['node']['children'],_0x4f9f8f);_0x319af3&&_0x21dec4?(delete _0x19f4ac['node']['children'][_0x4f9f8f],_0x19f4ac['node']['childCount']--,Oi(_0x19f4ac)):!_0x319af3&&!_0x21dec4&&(_0x19f4ac['node']['children'][_0x4f9f8f]=_0x50b722['node'],_0x19f4ac['node']['childCount']++,Oi(_0x19f4ac));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x2081c9){return typeof _0x2081c9=='string'&&_0x2081c9['length']!==0x0&&!ld['test'](_0x2081c9);},sa=function(_0x1ff117){return typeof _0x1ff117=='string'&&_0x1ff117['length']!==0x0&&!hd['test'](_0x1ff117);},ud=function(_0x54ede0){return _0x54ede0&&(_0x54ede0=_0x54ede0['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x54ede0);},Bt=function(_0x1209a7){return _0x1209a7===null||typeof _0x1209a7=='string'||typeof _0x1209a7=='number'&&!xn(_0x1209a7)||_0x1209a7&&typeof _0x1209a7=='object'&&Q(_0x1209a7,'.sv');},He=function(_0x1b6e8e,_0x5a5203,_0x225ff2,_0x840277){_0x840277&&_0x5a5203===void 0x0||Jt(it(_0x1b6e8e,'value'),_0x5a5203,_0x225ff2);},Jt=function(_0x2e9999,_0x2e1f4a,_0x3897d5){const _0x4d7cbc=_0x3897d5 instanceof C?new Ah(_0x3897d5,_0x2e9999):_0x3897d5;if(_0x2e1f4a===void 0x0)throw new Error(_0x2e9999+'contains\x20undefined\x20'+Oe(_0x4d7cbc));if(typeof _0x2e1f4a=='function')throw new Error(_0x2e9999+'contains\x20a\x20function\x20'+Oe(_0x4d7cbc)+'\x20with\x20contents\x20=\x20'+_0x2e1f4a['toString']());if(xn(_0x2e1f4a))throw new Error(_0x2e9999+'contains\x20'+_0x2e1f4a['toString']()+'\x20'+Oe(_0x4d7cbc));if(typeof _0x2e1f4a=='string'&&_0x2e1f4a['length']>ui/0x3&&Ln(_0x2e1f4a)>ui)throw new Error(_0x2e9999+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x4d7cbc)+'\x20(\x27'+_0x2e1f4a['substring'](0x0,0x32)+'...\x27)');if(_0x2e1f4a&&typeof _0x2e1f4a=='object'){let _0x51d25c=!0x1,_0x1f3378=!0x1;if(x(_0x2e1f4a,(_0x4ee5de,_0x3f89a8)=>{if(_0x4ee5de==='.value')_0x51d25c=!0x0;else{if(_0x4ee5de!=='.priority'&&_0x4ee5de!=='.sv'&&(_0x1f3378=!0x0,!ms(_0x4ee5de)))throw new Error(_0x2e9999+'\x20contains\x20an\x20invalid\x20key\x20('+_0x4ee5de+')\x20'+Oe(_0x4d7cbc)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x4d7cbc,_0x4ee5de),Jt(_0x2e9999,_0x3f89a8,_0x4d7cbc),Ph(_0x4d7cbc);}),_0x51d25c&&_0x1f3378)throw new Error(_0x2e9999+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x4d7cbc)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x4c1e6e,_0x21aaab){let _0x22bb7f,_0x16ef43;for(_0x22bb7f=0x0;_0x22bb7f<_0x21aaab['length'];_0x22bb7f++){_0x16ef43=_0x21aaab[_0x22bb7f];const _0x3b3937=Mt(_0x16ef43);for(let _0x8cbc3=0x0;_0x8cbc3<_0x3b3937['length'];_0x8cbc3++)if(!(_0x3b3937[_0x8cbc3]==='.priority'&&_0x8cbc3===_0x3b3937['length']-0x1)){if(!ms(_0x3b3937[_0x8cbc3]))throw new Error(_0x4c1e6e+'contains\x20an\x20invalid\x20key\x20('+_0x3b3937[_0x8cbc3]+')\x20in\x20path\x20'+_0x16ef43['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x21aaab['sort'](Rh);let _0x38f6d6=null;for(_0x22bb7f=0x0;_0x22bb7f<_0x21aaab['length'];_0x22bb7f++){if(_0x16ef43=_0x21aaab[_0x22bb7f],_0x38f6d6!==null&&G(_0x38f6d6,_0x16ef43))throw new Error(_0x4c1e6e+'contains\x20a\x20path\x20'+_0x38f6d6['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x16ef43['toString']());_0x38f6d6=_0x16ef43;}},ra=function(_0x5295ea,_0x34597c,_0x56f1d1,_0x68d2b0){const _0x5ef61c=it(_0x5295ea,'values');if(!(_0x34597c&&typeof _0x34597c=='object')||Array['isArray'](_0x34597c))throw new Error(_0x5ef61c+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x486d2c=[];x(_0x34597c,(_0x45dc00,_0x1ff4a6)=>{const _0x157299=new C(_0x45dc00);if(Jt(_0x5ef61c,_0x1ff4a6,k(_0x56f1d1,_0x157299)),ji(_0x157299)==='.priority'&&!Bt(_0x1ff4a6))throw new Error(_0x5ef61c+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x157299['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x486d2c['push'](_0x157299);}),dd(_0x5ef61c,_0x486d2c);},fd=function(_0x296cfc,_0x2e5a88,_0x52bf98){if(xn(_0x2e5a88))throw new Error(it(_0x296cfc,'priority')+'is\x20'+_0x2e5a88['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x2e5a88))throw new Error(it(_0x296cfc,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x30adad,_0x334be0,_0x4a4343,_0x2c0720){if(!sa(_0x4a4343))throw new Error(it(_0x30adad,_0x334be0)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x4a4343+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x5ba7b4,_0x5c1f0a,_0x2468b7,_0x21d5f3){_0x2468b7&&(_0x2468b7=_0x2468b7['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x5ba7b4,_0x5c1f0a,_0x2468b7);},Me=function(_0x21609d,_0x24a74b){if(y(_0x24a74b)==='.info')throw new Error(_0x21609d+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x13a05d,_0x2efe53){const _0x11de0d=_0x2efe53['path']['toString']();if(typeof _0x2efe53['repoInfo']['host']!='string'||_0x2efe53['repoInfo']['host']['length']===0x0||!ms(_0x2efe53['repoInfo']['namespace'])&&_0x2efe53['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x11de0d['length']!==0x0&&!ud(_0x11de0d))throw new Error(it(_0x13a05d,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x123ac5,_0x3ae509){let _0x52c4ad=null;for(let _0x50ba4f=0x0;_0x50ba4f<_0x3ae509['length'];_0x50ba4f++){const _0x345067=_0x3ae509[_0x50ba4f],_0x3441eb=_0x345067['getPath']();_0x52c4ad!==null&&!Ki(_0x3441eb,_0x52c4ad['path'])&&(_0x123ac5['eventLists_']['push'](_0x52c4ad),_0x52c4ad=null),_0x52c4ad===null&&(_0x52c4ad={'events':[],'path':_0x3441eb}),_0x52c4ad['events']['push'](_0x345067);}_0x52c4ad&&_0x123ac5['eventLists_']['push'](_0x52c4ad);}function oa(_0x537353,_0x3fa32f,_0x2447d1){qn(_0x537353,_0x2447d1),aa(_0x537353,_0x4f3b79=>Ki(_0x4f3b79,_0x3fa32f));}function V(_0xbca6e6,_0x5b152b,_0x1d718d){qn(_0xbca6e6,_0x1d718d),aa(_0xbca6e6,_0x2e3d1d=>G(_0x2e3d1d,_0x5b152b)||G(_0x5b152b,_0x2e3d1d));}function aa(_0x236c9a,_0x1c440d){_0x236c9a['recursionDepth_']++;let _0x5176dd=!0x0;for(let _0x2c5a71=0x0;_0x2c5a71<_0x236c9a['eventLists_']['length'];_0x2c5a71++){const _0x35d7e6=_0x236c9a['eventLists_'][_0x2c5a71];if(_0x35d7e6){const _0x5b2c24=_0x35d7e6['path'];_0x1c440d(_0x5b2c24)?(md(_0x236c9a['eventLists_'][_0x2c5a71]),_0x236c9a['eventLists_'][_0x2c5a71]=null):_0x5176dd=!0x1;}}_0x5176dd&&(_0x236c9a['eventLists_']=[]),_0x236c9a['recursionDepth_']--;}function md(_0x35a92e){for(let _0x1fe566=0x0;_0x1fe566<_0x35a92e['events']['length'];_0x1fe566++){const _0x8e8e7e=_0x35a92e['events'][_0x1fe566];if(_0x8e8e7e!==null){_0x35a92e['events'][_0x1fe566]=null;const _0x2a2975=_0x8e8e7e['getEventRunner']();St&&L('event:\x20'+_0x8e8e7e['toString']()),ft(_0x2a2975);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x15f036,_0x3aaa5c,_0x5d70fc,_0x10ca0c){this['repoInfo_']=_0x15f036,this['forceRestClient_']=_0x3aaa5c,this['authTokenProvider_']=_0x5d70fc,this['appCheckProvider_']=_0x10ca0c,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x4abc86,_0xce6290,_0x505356){if(_0x4abc86['stats_']=qi(_0x4abc86['repoInfo_']),_0x4abc86['forceRestClient_']||Xl())_0x4abc86['server_']=new vn(_0x4abc86['repoInfo_'],(_0x399dca,_0x12ec4e,_0x18a0fa,_0x3a4a8f)=>{gr(_0x4abc86,_0x399dca,_0x12ec4e,_0x18a0fa,_0x3a4a8f);},_0x4abc86['authTokenProvider_'],_0x4abc86['appCheckProvider_']),setTimeout(()=>mr(_0x4abc86,!0x0),0x0);else{if(typeof _0x505356<'u'&&_0x505356!==null){if(typeof _0x505356!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x505356);}catch(_0x4101c4){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x4101c4);}}_0x4abc86['persistentConnection_']=new se(_0x4abc86['repoInfo_'],_0xce6290,(_0x5039b5,_0x44c602,_0x4738ae,_0x52f6ba)=>{gr(_0x4abc86,_0x5039b5,_0x44c602,_0x4738ae,_0x52f6ba);},_0x59f69e=>{mr(_0x4abc86,_0x59f69e);},_0x322191=>{Id(_0x4abc86,_0x322191);},_0x4abc86['authTokenProvider_'],_0x4abc86['appCheckProvider_'],_0x505356),_0x4abc86['server_']=_0x4abc86['persistentConnection_'];}_0x4abc86['authTokenProvider_']['addTokenChangeListener'](_0x46b923=>{_0x4abc86['server_']['refreshAuthToken'](_0x46b923);}),_0x4abc86['appCheckProvider_']['addTokenChangeListener'](_0x3d36fb=>{_0x4abc86['server_']['refreshAppCheckToken'](_0x3d36fb['token']);}),_0x4abc86['statsReporter_']=ih(_0x4abc86['repoInfo_'],()=>new iu(_0x4abc86['stats_'],_0x4abc86['server_'])),_0x4abc86['infoData_']=new Xh(),_0x4abc86['infoSyncTree_']=new pr({'startListening':(_0x494d9d,_0x32c08d,_0x15baa1,_0x3f0610)=>{let _0x5de274=[];const _0x4daa28=_0x4abc86['infoData_']['getNode'](_0x494d9d['_path']);return _0x4daa28['isEmpty']()||(_0x5de274=Yt(_0x4abc86['infoSyncTree_'],_0x494d9d['_path'],_0x4daa28),setTimeout(()=>{_0x3f0610('ok');},0x0)),_0x5de274;},'stopListening':()=>{}}),vs(_0x4abc86,'connected',!0x1),_0x4abc86['serverSyncTree_']=new pr({'startListening':(_0x5245c5,_0x1ac020,_0x4b8453,_0xc5db2f)=>(_0x4abc86['server_']['listen'](_0x5245c5,_0x4b8453,_0x1ac020,(_0x139f63,_0x2eee4c)=>{const _0x2d68cb=_0xc5db2f(_0x139f63,_0x2eee4c);V(_0x4abc86['eventQueue_'],_0x5245c5['_path'],_0x2d68cb);}),[]),'stopListening':(_0x17c825,_0x5df8f2)=>{_0x4abc86['server_']['unlisten'](_0x17c825,_0x5df8f2);}});}function la(_0x190ff0){const _0x38ac3c=_0x190ff0['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x38ac3c;}function Xt(_0x52be2b){return id({'timestamp':la(_0x52be2b)});}function gr(_0x2c2055,_0x473746,_0x2372ec,_0x2e0ab4,_0x46aa3f){_0x2c2055['dataUpdateCount']++;const _0x281aaa=new C(_0x473746);_0x2372ec=_0x2c2055['interceptServerDataCallback_']?_0x2c2055['interceptServerDataCallback_'](_0x473746,_0x2372ec):_0x2372ec;let _0x3b410a=[];if(_0x46aa3f){if(_0x2e0ab4){const _0x47b717=_n(_0x2372ec,_0x4e437a=>A(_0x4e437a));_0x3b410a=Ju(_0x2c2055['serverSyncTree_'],_0x281aaa,_0x47b717,_0x46aa3f);}else{const _0x157a41=A(_0x2372ec);_0x3b410a=Jo(_0x2c2055['serverSyncTree_'],_0x281aaa,_0x157a41,_0x46aa3f);}}else{if(_0x2e0ab4){const _0x5e5347=_n(_0x2372ec,_0x274900=>A(_0x274900));_0x3b410a=Ku(_0x2c2055['serverSyncTree_'],_0x281aaa,_0x5e5347);}else{const _0x2f9063=A(_0x2372ec);_0x3b410a=Yt(_0x2c2055['serverSyncTree_'],_0x281aaa,_0x2f9063);}}let _0x52dade=_0x281aaa;_0x3b410a['length']>0x0&&(_0x52dade=ct(_0x2c2055,_0x281aaa)),V(_0x2c2055['eventQueue_'],_0x52dade,_0x3b410a);}function mr(_0x2b4043,_0x168236){vs(_0x2b4043,'connected',_0x168236),_0x168236===!0x1&&Sd(_0x2b4043);}function Id(_0x724833,_0xb2263d){x(_0xb2263d,(_0x4739ff,_0xa5eeb8)=>{vs(_0x724833,_0x4739ff,_0xa5eeb8);});}function vs(_0x5cd5f9,_0x1fb6cd,_0x4d79c0){const _0x508f93=new C('/.info/'+_0x1fb6cd),_0x425a8f=A(_0x4d79c0);_0x5cd5f9['infoData_']['updateSnapshot'](_0x508f93,_0x425a8f);const _0x52c9e6=Yt(_0x5cd5f9['infoSyncTree_'],_0x508f93,_0x425a8f);V(_0x5cd5f9['eventQueue_'],_0x508f93,_0x52c9e6);}function zn(_0xf66cfc){return _0xf66cfc['nextWriteId_']++;}function wd(_0x3ab1a1,_0x212f83,_0x883aaa){const _0x56c348=Xu(_0x3ab1a1['serverSyncTree_'],_0x212f83);return _0x56c348!=null?Promise['resolve'](_0x56c348):_0x3ab1a1['server_']['get'](_0x212f83)['then'](_0x2d87e9=>{const _0x2733d2=A(_0x2d87e9)['withIndex'](_0x212f83['_queryParams']['getIndex']());Ni(_0x3ab1a1['serverSyncTree_'],_0x212f83,_0x883aaa,!0x0);let _0xdac6b0;if(_0x212f83['_queryParams']['loadsAllData']())_0xdac6b0=Yt(_0x3ab1a1['serverSyncTree_'],_0x212f83['_path'],_0x2733d2);else{const _0x174355=Wt(_0x3ab1a1['serverSyncTree_'],_0x212f83);_0xdac6b0=Jo(_0x3ab1a1['serverSyncTree_'],_0x212f83['_path'],_0x2733d2,_0x174355);}return V(_0x3ab1a1['eventQueue_'],_0x212f83['_path'],_0xdac6b0),An(_0x3ab1a1['serverSyncTree_'],_0x212f83,_0x883aaa,null,!0x0),_0x2733d2;},_0x22f536=>(gt(_0x3ab1a1,'get\x20for\x20query\x20'+O(_0x212f83)+'\x20failed:\x20'+_0x22f536),Promise['reject'](new Error(_0x22f536))));}function Cd(_0x950457,_0x2dc0f1,_0x440a8b,_0x5c6174,_0x98ec17){gt(_0x950457,'set',{'path':_0x2dc0f1['toString'](),'value':_0x440a8b,'priority':_0x5c6174});const _0x3945bc=Xt(_0x950457),_0x51e033=A(_0x440a8b,_0x5c6174),_0x19013c=Vn(_0x950457['serverSyncTree_'],_0x2dc0f1),_0x46e475=fs(_0x51e033,_0x19013c,_0x3945bc),_0x44e2f4=zn(_0x950457),_0x1fecb8=as(_0x950457['serverSyncTree_'],_0x2dc0f1,_0x46e475,_0x44e2f4,!0x0);qn(_0x950457['eventQueue_'],_0x1fecb8),_0x950457['server_']['put'](_0x2dc0f1['toString'](),_0x51e033['val'](!0x0),(_0x74d979,_0x5abfac)=>{const _0x44dc70=_0x74d979==='ok';_0x44dc70||U('set\x20at\x20'+_0x2dc0f1+'\x20failed:\x20'+_0x74d979);const _0x497a7e=_e(_0x950457['serverSyncTree_'],_0x44e2f4,!_0x44dc70);V(_0x950457['eventQueue_'],_0x2dc0f1,_0x497a7e),be(_0x950457,_0x98ec17,_0x74d979,_0x5abfac);});const _0x4038f1=Is(_0x950457,_0x2dc0f1);ct(_0x950457,_0x4038f1),V(_0x950457['eventQueue_'],_0x4038f1,[]);}function Td(_0xa33b3,_0x4cbece,_0x2ca30c,_0x2719db){gt(_0xa33b3,'update',{'path':_0x4cbece['toString'](),'value':_0x2ca30c});let _0x450fd6=!0x0;const _0x47e6f4=Xt(_0xa33b3),_0xae318c={};if(x(_0x2ca30c,(_0x2701bb,_0x2c0c76)=>{_0x450fd6=!0x1,_0xae318c[_0x2701bb]=ta(k(_0x4cbece,_0x2701bb),A(_0x2c0c76),_0xa33b3['serverSyncTree_'],_0x47e6f4);}),_0x450fd6)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0xa33b3,_0x2719db,'ok',void 0x0);else{const _0x3ed8e7=zn(_0xa33b3),_0x50601f=ju(_0xa33b3['serverSyncTree_'],_0x4cbece,_0xae318c,_0x3ed8e7);qn(_0xa33b3['eventQueue_'],_0x50601f),_0xa33b3['server_']['merge'](_0x4cbece['toString'](),_0x2ca30c,(_0x1f9ee5,_0x3cf703)=>{const _0x14ebd0=_0x1f9ee5==='ok';_0x14ebd0||U('update\x20at\x20'+_0x4cbece+'\x20failed:\x20'+_0x1f9ee5);const _0x1a62fd=_e(_0xa33b3['serverSyncTree_'],_0x3ed8e7,!_0x14ebd0),_0x52d0e4=_0x1a62fd['length']>0x0?ct(_0xa33b3,_0x4cbece):_0x4cbece;V(_0xa33b3['eventQueue_'],_0x52d0e4,_0x1a62fd),be(_0xa33b3,_0x2719db,_0x1f9ee5,_0x3cf703);}),x(_0x2ca30c,_0x153366=>{const _0x1a3729=Is(_0xa33b3,k(_0x4cbece,_0x153366));ct(_0xa33b3,_0x1a3729);}),V(_0xa33b3['eventQueue_'],_0x4cbece,[]);}}function Sd(_0x2d4271){gt(_0x2d4271,'onDisconnectEvents');const _0x3fe68b=Xt(_0x2d4271),_0x536741=En();Si(_0x2d4271['onDisconnect_'],w(),(_0x5a65de,_0x57dc6d)=>{const _0x20c817=ta(_0x5a65de,_0x57dc6d,_0x2d4271['serverSyncTree_'],_0x3fe68b);pt(_0x536741,_0x5a65de,_0x20c817);});let _0x4bcb82=[];Si(_0x536741,w(),(_0x45757d,_0x8577ea)=>{_0x4bcb82=_0x4bcb82['concat'](Yt(_0x2d4271['serverSyncTree_'],_0x45757d,_0x8577ea));const _0x3bc836=Is(_0x2d4271,_0x45757d);ct(_0x2d4271,_0x3bc836);}),_0x2d4271['onDisconnect_']=En(),V(_0x2d4271['eventQueue_'],w(),_0x4bcb82);}function bd(_0x458d4b,_0x2ae40e,_0x5bc762){_0x458d4b['server_']['onDisconnectCancel'](_0x2ae40e['toString'](),(_0x439b2a,_0x14f7f5)=>{_0x439b2a==='ok'&&Ti(_0x458d4b['onDisconnect_'],_0x2ae40e),be(_0x458d4b,_0x5bc762,_0x439b2a,_0x14f7f5);});}function yr(_0x3eb78a,_0x557c8a,_0x94f1f0,_0x221521){const _0xca50d3=A(_0x94f1f0);_0x3eb78a['server_']['onDisconnectPut'](_0x557c8a['toString'](),_0xca50d3['val'](!0x0),(_0x303d10,_0xe36305)=>{_0x303d10==='ok'&&pt(_0x3eb78a['onDisconnect_'],_0x557c8a,_0xca50d3),be(_0x3eb78a,_0x221521,_0x303d10,_0xe36305);});}function Rd(_0xd4f854,_0x819bb7,_0x4924d5,_0x21b9b1,_0x32cb49){const _0x28460b=A(_0x4924d5,_0x21b9b1);_0xd4f854['server_']['onDisconnectPut'](_0x819bb7['toString'](),_0x28460b['val'](!0x0),(_0x33b76c,_0xb1d25e)=>{_0x33b76c==='ok'&&pt(_0xd4f854['onDisconnect_'],_0x819bb7,_0x28460b),be(_0xd4f854,_0x32cb49,_0x33b76c,_0xb1d25e);});}function Ad(_0x38d06e,_0x15e86d,_0x335fb6,_0xd309f0){if(pn(_0x335fb6)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x38d06e,_0xd309f0,'ok',void 0x0);return;}_0x38d06e['server_']['onDisconnectMerge'](_0x15e86d['toString'](),_0x335fb6,(_0x268581,_0x19beea)=>{_0x268581==='ok'&&x(_0x335fb6,(_0x58ce37,_0x1f96e8)=>{const _0x468cbe=A(_0x1f96e8);pt(_0x38d06e['onDisconnect_'],k(_0x15e86d,_0x58ce37),_0x468cbe);}),be(_0x38d06e,_0xd309f0,_0x268581,_0x19beea);});}function kd(_0x523668,_0x532287,_0xc548c){let _0x3e71ff;y(_0x532287['_path'])==='.info'?_0x3e71ff=Ni(_0x523668['infoSyncTree_'],_0x532287,_0xc548c):_0x3e71ff=Ni(_0x523668['serverSyncTree_'],_0x532287,_0xc548c),oa(_0x523668['eventQueue_'],_0x532287['_path'],_0x3e71ff);}function Pd(_0xcd6ae2,_0x72559a,_0x2430bf){let _0x4afce3;y(_0x72559a['_path'])==='.info'?_0x4afce3=An(_0xcd6ae2['infoSyncTree_'],_0x72559a,_0x2430bf):_0x4afce3=An(_0xcd6ae2['serverSyncTree_'],_0x72559a,_0x2430bf),oa(_0xcd6ae2['eventQueue_'],_0x72559a['_path'],_0x4afce3);}function ha(_0x541578){_0x541578['persistentConnection_']&&_0x541578['persistentConnection_']['interrupt'](ca);}function Nd(_0x361caf){_0x361caf['persistentConnection_']&&_0x361caf['persistentConnection_']['resume'](ca);}function gt(_0x390d8e,..._0x2d75d1){let _0x2a278b='';_0x390d8e['persistentConnection_']&&(_0x2a278b=_0x390d8e['persistentConnection_']['id']+':'),L(_0x2a278b,..._0x2d75d1);}function be(_0x513a3b,_0x24fb0e,_0x5b4941,_0x52ab5e){_0x24fb0e&&ft(()=>{if(_0x5b4941==='ok')_0x24fb0e(null);else{const _0x25fae6=(_0x5b4941||'error')['toUpperCase']();let _0x3e6cee=_0x25fae6;_0x52ab5e&&(_0x3e6cee+=':\x20'+_0x52ab5e);const _0x591fff=new Error(_0x3e6cee);_0x591fff['code']=_0x25fae6,_0x24fb0e(_0x591fff);}});}function Od(_0x4e83b3,_0x4a2484,_0x276555,_0x38d8ac,_0x4e04f6,_0x4a0d78){gt(_0x4e83b3,'transaction\x20on\x20'+_0x4a2484);const _0x1bc0c1={'path':_0x4a2484,'update':_0x276555,'onComplete':_0x38d8ac,'status':null,'order':so(),'applyLocally':_0x4a0d78,'retryCount':0x0,'unwatcher':_0x4e04f6,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x2c991d=Es(_0x4e83b3,_0x4a2484,void 0x0);_0x1bc0c1['currentInputSnapshot']=_0x2c991d;const _0x3f6c53=_0x1bc0c1['update'](_0x2c991d['val']());if(_0x3f6c53===void 0x0)_0x1bc0c1['unwatcher'](),_0x1bc0c1['currentOutputSnapshotRaw']=null,_0x1bc0c1['currentOutputSnapshotResolved']=null,_0x1bc0c1['onComplete']&&_0x1bc0c1['onComplete'](null,!0x1,_0x1bc0c1['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x3f6c53,_0x1bc0c1['path']),_0x1bc0c1['status']=0x0;const _0x5c5a6e=$n(_0x4e83b3['transactionQueueTree_'],_0x4a2484),_0x3457bd=je(_0x5c5a6e)||[];_0x3457bd['push'](_0x1bc0c1),gs(_0x5c5a6e,_0x3457bd);let _0x126edd;typeof _0x3f6c53=='object'&&_0x3f6c53!==null&&Q(_0x3f6c53,'.priority')?(_0x126edd=Le(_0x3f6c53,'.priority'),f(Bt(_0x126edd),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x126edd=(Vn(_0x4e83b3['serverSyncTree_'],_0x4a2484)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x1fd0f3=Xt(_0x4e83b3),_0x9e066d=A(_0x3f6c53,_0x126edd),_0x2780c6=fs(_0x9e066d,_0x2c991d,_0x1fd0f3);_0x1bc0c1['currentOutputSnapshotRaw']=_0x9e066d,_0x1bc0c1['currentOutputSnapshotResolved']=_0x2780c6,_0x1bc0c1['currentWriteId']=zn(_0x4e83b3);const _0x177598=as(_0x4e83b3['serverSyncTree_'],_0x4a2484,_0x2780c6,_0x1bc0c1['currentWriteId'],_0x1bc0c1['applyLocally']);V(_0x4e83b3['eventQueue_'],_0x4a2484,_0x177598),jn(_0x4e83b3,_0x4e83b3['transactionQueueTree_']);}}function Es(_0x11879d,_0x39a4dd,_0x1d194b){return Vn(_0x11879d['serverSyncTree_'],_0x39a4dd,_0x1d194b)||g['EMPTY_NODE'];}function jn(_0x1c2aed,_0x36b7d1=_0x1c2aed['transactionQueueTree_']){if(_0x36b7d1||Kn(_0x1c2aed,_0x36b7d1),je(_0x36b7d1)){const _0x5e7ef3=da(_0x1c2aed,_0x36b7d1);f(_0x5e7ef3['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x5e7ef3['every'](_0x1bf40f=>_0x1bf40f['status']===0x0)&&Dd(_0x1c2aed,Qt(_0x36b7d1),_0x5e7ef3);}else na(_0x36b7d1)&&Gn(_0x36b7d1,_0x477421=>{jn(_0x1c2aed,_0x477421);});}function Dd(_0x284357,_0x55035b,_0x3c1720){const _0x4acb38=_0x3c1720['map'](_0x1df042=>_0x1df042['currentWriteId']),_0x20731e=Es(_0x284357,_0x55035b,_0x4acb38);let _0x5cdd71=_0x20731e;const _0x3f77ad=_0x20731e['hash']();for(let _0x509f51=0x0;_0x509f51<_0x3c1720['length'];_0x509f51++){const _0x247f2e=_0x3c1720[_0x509f51];f(_0x247f2e['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x247f2e['status']=0x1,_0x247f2e['retryCount']++;const _0x5457ae=F(_0x55035b,_0x247f2e['path']);_0x5cdd71=_0x5cdd71['updateChild'](_0x5457ae,_0x247f2e['currentOutputSnapshotRaw']);}const _0x4bc1c4=_0x5cdd71['val'](!0x0),_0x9ebf7=_0x55035b;_0x284357['server_']['put'](_0x9ebf7['toString'](),_0x4bc1c4,_0x1d5828=>{gt(_0x284357,'transaction\x20put\x20response',{'path':_0x9ebf7['toString'](),'status':_0x1d5828});let _0x21744a=[];if(_0x1d5828==='ok'){const _0x181e6a=[];for(let _0x59f730=0x0;_0x59f730<_0x3c1720['length'];_0x59f730++)_0x3c1720[_0x59f730]['status']=0x2,_0x21744a=_0x21744a['concat'](_e(_0x284357['serverSyncTree_'],_0x3c1720[_0x59f730]['currentWriteId'])),_0x3c1720[_0x59f730]['onComplete']&&_0x181e6a['push'](()=>_0x3c1720[_0x59f730]['onComplete'](null,!0x0,_0x3c1720[_0x59f730]['currentOutputSnapshotResolved'])),_0x3c1720[_0x59f730]['unwatcher']();Kn(_0x284357,$n(_0x284357['transactionQueueTree_'],_0x55035b)),jn(_0x284357,_0x284357['transactionQueueTree_']),V(_0x284357['eventQueue_'],_0x55035b,_0x21744a);for(let _0x452e73=0x0;_0x452e73<_0x181e6a['length'];_0x452e73++)ft(_0x181e6a[_0x452e73]);}else{if(_0x1d5828==='datastale'){for(let _0x18a0a1=0x0;_0x18a0a1<_0x3c1720['length'];_0x18a0a1++)_0x3c1720[_0x18a0a1]['status']===0x3?_0x3c1720[_0x18a0a1]['status']=0x4:_0x3c1720[_0x18a0a1]['status']=0x0;}else{U('transaction\x20at\x20'+_0x9ebf7['toString']()+'\x20failed:\x20'+_0x1d5828);for(let _0x2d0600=0x0;_0x2d0600<_0x3c1720['length'];_0x2d0600++)_0x3c1720[_0x2d0600]['status']=0x4,_0x3c1720[_0x2d0600]['abortReason']=_0x1d5828;}ct(_0x284357,_0x55035b);}},_0x3f77ad);}function ct(_0x44ae44,_0x32e943){const _0x140fbb=ua(_0x44ae44,_0x32e943),_0xcd5920=Qt(_0x140fbb),_0x36f105=da(_0x44ae44,_0x140fbb);return Md(_0x44ae44,_0x36f105,_0xcd5920),_0xcd5920;}function Md(_0x1cf54d,_0x285314,_0x1ca4f3){if(_0x285314['length']===0x0)return;const _0x33207e=[];let _0x49cb03=[];const _0x5d2633=_0x285314['filter'](_0x5cf774=>_0x5cf774['status']===0x0)['map'](_0x582de5=>_0x582de5['currentWriteId']);for(let _0x1abb97=0x0;_0x1abb97<_0x285314['length'];_0x1abb97++){const _0x2b8a94=_0x285314[_0x1abb97],_0x356589=F(_0x1ca4f3,_0x2b8a94['path']);let _0x2fe41d=!0x1,_0x554a26;if(f(_0x356589!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x2b8a94['status']===0x4)_0x2fe41d=!0x0,_0x554a26=_0x2b8a94['abortReason'],_0x49cb03=_0x49cb03['concat'](_e(_0x1cf54d['serverSyncTree_'],_0x2b8a94['currentWriteId'],!0x0));else{if(_0x2b8a94['status']===0x0){if(_0x2b8a94['retryCount']>=yd)_0x2fe41d=!0x0,_0x554a26='maxretry',_0x49cb03=_0x49cb03['concat'](_e(_0x1cf54d['serverSyncTree_'],_0x2b8a94['currentWriteId'],!0x0));else{const _0x53529d=Es(_0x1cf54d,_0x2b8a94['path'],_0x5d2633);_0x2b8a94['currentInputSnapshot']=_0x53529d;const _0x2fd1ec=_0x285314[_0x1abb97]['update'](_0x53529d['val']());if(_0x2fd1ec!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x2fd1ec,_0x2b8a94['path']);let _0x4b612f=A(_0x2fd1ec);typeof _0x2fd1ec=='object'&&_0x2fd1ec!=null&&Q(_0x2fd1ec,'.priority')||(_0x4b612f=_0x4b612f['updatePriority'](_0x53529d['getPriority']()));const _0x123c6e=_0x2b8a94['currentWriteId'],_0x5dbacc=Xt(_0x1cf54d),_0x3ce3bc=fs(_0x4b612f,_0x53529d,_0x5dbacc);_0x2b8a94['currentOutputSnapshotRaw']=_0x4b612f,_0x2b8a94['currentOutputSnapshotResolved']=_0x3ce3bc,_0x2b8a94['currentWriteId']=zn(_0x1cf54d),_0x5d2633['splice'](_0x5d2633['indexOf'](_0x123c6e),0x1),_0x49cb03=_0x49cb03['concat'](as(_0x1cf54d['serverSyncTree_'],_0x2b8a94['path'],_0x3ce3bc,_0x2b8a94['currentWriteId'],_0x2b8a94['applyLocally'])),_0x49cb03=_0x49cb03['concat'](_e(_0x1cf54d['serverSyncTree_'],_0x123c6e,!0x0));}else _0x2fe41d=!0x0,_0x554a26='nodata',_0x49cb03=_0x49cb03['concat'](_e(_0x1cf54d['serverSyncTree_'],_0x2b8a94['currentWriteId'],!0x0));}}}V(_0x1cf54d['eventQueue_'],_0x1ca4f3,_0x49cb03),_0x49cb03=[],_0x2fe41d&&(_0x285314[_0x1abb97]['status']=0x2,function(_0x1044dc){setTimeout(_0x1044dc,Math['floor'](0x0));}(_0x285314[_0x1abb97]['unwatcher']),_0x285314[_0x1abb97]['onComplete']&&(_0x554a26==='nodata'?_0x33207e['push'](()=>_0x285314[_0x1abb97]['onComplete'](null,!0x1,_0x285314[_0x1abb97]['currentInputSnapshot'])):_0x33207e['push'](()=>_0x285314[_0x1abb97]['onComplete'](new Error(_0x554a26),!0x1,null))));}Kn(_0x1cf54d,_0x1cf54d['transactionQueueTree_']);for(let _0x1f08fe=0x0;_0x1f08fe<_0x33207e['length'];_0x1f08fe++)ft(_0x33207e[_0x1f08fe]);jn(_0x1cf54d,_0x1cf54d['transactionQueueTree_']);}function ua(_0x408aaa,_0x13136e){let _0x5d7271,_0x360053=_0x408aaa['transactionQueueTree_'];for(_0x5d7271=y(_0x13136e);_0x5d7271!==null&&je(_0x360053)===void 0x0;)_0x360053=$n(_0x360053,_0x5d7271),_0x13136e=S(_0x13136e),_0x5d7271=y(_0x13136e);return _0x360053;}function da(_0x3af41c,_0x59fbf0){const _0x171554=[];return fa(_0x3af41c,_0x59fbf0,_0x171554),_0x171554['sort']((_0x53e55b,_0x390e94)=>_0x53e55b['order']-_0x390e94['order']),_0x171554;}function fa(_0x5ed15e,_0x54e5bd,_0x3a569a){const _0x536d4c=je(_0x54e5bd);if(_0x536d4c){for(let _0x2d8c12=0x0;_0x2d8c12<_0x536d4c['length'];_0x2d8c12++)_0x3a569a['push'](_0x536d4c[_0x2d8c12]);}Gn(_0x54e5bd,_0x4f2cbf=>{fa(_0x5ed15e,_0x4f2cbf,_0x3a569a);});}function Kn(_0x38c0e3,_0x382f42){const _0x4a6ac7=je(_0x382f42);if(_0x4a6ac7){let _0x2265bf=0x0;for(let _0x58078f=0x0;_0x58078f<_0x4a6ac7['length'];_0x58078f++)_0x4a6ac7[_0x58078f]['status']!==0x2&&(_0x4a6ac7[_0x2265bf]=_0x4a6ac7[_0x58078f],_0x2265bf++);_0x4a6ac7['length']=_0x2265bf,gs(_0x382f42,_0x4a6ac7['length']>0x0?_0x4a6ac7:void 0x0);}Gn(_0x382f42,_0x556f46=>{Kn(_0x38c0e3,_0x556f46);});}function Is(_0x10034a,_0x2a1659){const _0x15c8ea=Qt(ua(_0x10034a,_0x2a1659)),_0x575dc7=$n(_0x10034a['transactionQueueTree_'],_0x2a1659);return ad(_0x575dc7,_0x4dda52=>{di(_0x10034a,_0x4dda52);}),di(_0x10034a,_0x575dc7),ia(_0x575dc7,_0x508204=>{di(_0x10034a,_0x508204);}),_0x15c8ea;}function di(_0x30df89,_0x145e20){const _0x347ea3=je(_0x145e20);if(_0x347ea3){const _0x1df69b=[];let _0x2bbedb=[],_0x641021=-0x1;for(let _0xf78945=0x0;_0xf78945<_0x347ea3['length'];_0xf78945++)_0x347ea3[_0xf78945]['status']===0x3||(_0x347ea3[_0xf78945]['status']===0x1?(f(_0x641021===_0xf78945-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x641021=_0xf78945,_0x347ea3[_0xf78945]['status']=0x3,_0x347ea3[_0xf78945]['abortReason']='set'):(f(_0x347ea3[_0xf78945]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x347ea3[_0xf78945]['unwatcher'](),_0x2bbedb=_0x2bbedb['concat'](_e(_0x30df89['serverSyncTree_'],_0x347ea3[_0xf78945]['currentWriteId'],!0x0)),_0x347ea3[_0xf78945]['onComplete']&&_0x1df69b['push'](_0x347ea3[_0xf78945]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x641021===-0x1?gs(_0x145e20,void 0x0):_0x347ea3['length']=_0x641021+0x1,V(_0x30df89['eventQueue_'],Qt(_0x145e20),_0x2bbedb);for(let _0x2b9fb9=0x0;_0x2b9fb9<_0x1df69b['length'];_0x2b9fb9++)ft(_0x1df69b[_0x2b9fb9]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x112573){let _0x86b518='';const _0x1eca35=_0x112573['split']('/');for(let _0x5c989a=0x0;_0x5c989a<_0x1eca35['length'];_0x5c989a++)if(_0x1eca35[_0x5c989a]['length']>0x0){let _0x237321=_0x1eca35[_0x5c989a];try{_0x237321=decodeURIComponent(_0x237321['replace'](/\+/g,'\x20'));}catch{}_0x86b518+='/'+_0x237321;}return _0x86b518;}function xd(_0x5d4b83){const _0x42de2c={};_0x5d4b83['charAt'](0x0)==='?'&&(_0x5d4b83=_0x5d4b83['substring'](0x1));for(const _0x42ce0e of _0x5d4b83['split']('&')){if(_0x42ce0e['length']===0x0)continue;const _0x10f002=_0x42ce0e['split']('=');_0x10f002['length']===0x2?_0x42de2c[decodeURIComponent(_0x10f002[0x0])]=decodeURIComponent(_0x10f002[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x42ce0e+'\x27\x20in\x20query\x20\x27'+_0x5d4b83+'\x27');}return _0x42de2c;}const vr=function(_0x37eebb,_0x1ac0e4){const _0x23f94f=Fd(_0x37eebb),_0x27a2a4=_0x23f94f['namespace'];_0x23f94f['domain']==='firebase.com'&&ae(_0x23f94f['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x27a2a4||_0x27a2a4==='undefined')&&_0x23f94f['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x23f94f['secure']||$l();const _0x51106b=_0x23f94f['scheme']==='ws'||_0x23f94f['scheme']==='wss';return{'repoInfo':new yo(_0x23f94f['host'],_0x23f94f['secure'],_0x27a2a4,_0x51106b,_0x1ac0e4,'',_0x27a2a4!==_0x23f94f['subdomain']),'path':new C(_0x23f94f['pathString'])};},Fd=function(_0x15ea6e){let _0x42480d='',_0x6544c1='',_0x15f8bf='',_0x3607c5='',_0x20600e='',_0x49afad=!0x0,_0xf05255='https',_0x5ea18c=0x1bb;if(typeof _0x15ea6e=='string'){let _0x40a71c=_0x15ea6e['indexOf']('//');_0x40a71c>=0x0&&(_0xf05255=_0x15ea6e['substring'](0x0,_0x40a71c-0x1),_0x15ea6e=_0x15ea6e['substring'](_0x40a71c+0x2));let _0x8c0e42=_0x15ea6e['indexOf']('/');_0x8c0e42===-0x1&&(_0x8c0e42=_0x15ea6e['length']);let _0x44038f=_0x15ea6e['indexOf']('?');_0x44038f===-0x1&&(_0x44038f=_0x15ea6e['length']),_0x42480d=_0x15ea6e['substring'](0x0,Math['min'](_0x8c0e42,_0x44038f)),_0x8c0e42<_0x44038f&&(_0x3607c5=Ld(_0x15ea6e['substring'](_0x8c0e42,_0x44038f)));const _0x408e9e=xd(_0x15ea6e['substring'](Math['min'](_0x15ea6e['length'],_0x44038f)));_0x40a71c=_0x42480d['indexOf'](':'),_0x40a71c>=0x0?(_0x49afad=_0xf05255==='https'||_0xf05255==='wss',_0x5ea18c=parseInt(_0x42480d['substring'](_0x40a71c+0x1),0xa)):_0x40a71c=_0x42480d['length'];const _0x4605e7=_0x42480d['slice'](0x0,_0x40a71c);if(_0x4605e7['toLowerCase']()==='localhost')_0x6544c1='localhost';else{if(_0x4605e7['split']('.')['length']<=0x2)_0x6544c1=_0x4605e7;else{const _0x4bf208=_0x42480d['indexOf']('.');_0x15f8bf=_0x42480d['substring'](0x0,_0x4bf208)['toLowerCase'](),_0x6544c1=_0x42480d['substring'](_0x4bf208+0x1),_0x20600e=_0x15f8bf;}}'ns'in _0x408e9e&&(_0x20600e=_0x408e9e['ns']);}return{'host':_0x42480d,'port':_0x5ea18c,'domain':_0x6544c1,'subdomain':_0x15f8bf,'secure':_0x49afad,'scheme':_0xf05255,'pathString':_0x3607c5,'namespace':_0x20600e};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x9f7a6b=0x0;const _0x51c04f=[];return function(_0x5c0fe8){const _0x43dab1=_0x5c0fe8===_0x9f7a6b;_0x9f7a6b=_0x5c0fe8;let _0x3dbd10;const _0x4c8967=new Array(0x8);for(_0x3dbd10=0x7;_0x3dbd10>=0x0;_0x3dbd10--)_0x4c8967[_0x3dbd10]=Er['charAt'](_0x5c0fe8%0x40),_0x5c0fe8=Math['floor'](_0x5c0fe8/0x40);f(_0x5c0fe8===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x5dc9b8=_0x4c8967['join']('');if(_0x43dab1){for(_0x3dbd10=0xb;_0x3dbd10>=0x0&&_0x51c04f[_0x3dbd10]===0x3f;_0x3dbd10--)_0x51c04f[_0x3dbd10]=0x0;_0x51c04f[_0x3dbd10]++;}else{for(_0x3dbd10=0x0;_0x3dbd10<0xc;_0x3dbd10++)_0x51c04f[_0x3dbd10]=Math['floor'](Math['random']()*0x40);}for(_0x3dbd10=0x0;_0x3dbd10<0xc;_0x3dbd10++)_0x5dc9b8+=Er['charAt'](_0x51c04f[_0x3dbd10]);return f(_0x5dc9b8['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x5dc9b8;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x2397b3,_0x5a1ba1,_0x50ff79,_0x52e64f){this['eventType']=_0x2397b3,this['eventRegistration']=_0x5a1ba1,this['snapshot']=_0x50ff79,this['prevName']=_0x52e64f;}['getPath'](){const _0x5532bd=this['snapshot']['ref'];return this['eventType']==='value'?_0x5532bd['_path']:_0x5532bd['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x3a56e4,_0x42d805,_0x44dfcf){this['eventRegistration']=_0x3a56e4,this['error']=_0x42d805,this['path']=_0x44dfcf;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x3132b3,_0x1eac55){this['snapshotCallback']=_0x3132b3,this['cancelCallback']=_0x1eac55;}['onValue'](_0x2be83f,_0x5dd64f){this['snapshotCallback']['call'](null,_0x2be83f,_0x5dd64f);}['onCancel'](_0x2957fb){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x2957fb);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x5bc395){return this['snapshotCallback']===_0x5bc395['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x5bc395['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x5bc395['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x74fa5f,_0x153ae4){this['_repo']=_0x74fa5f,this['_path']=_0x153ae4;}['cancel'](){const _0x307505=new H();return bd(this['_repo'],this['_path'],_0x307505['wrapCallback'](()=>{})),_0x307505['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x3928b4=new H();return yr(this['_repo'],this['_path'],null,_0x3928b4['wrapCallback'](()=>{})),_0x3928b4['promise'];}['set'](_0x381e48){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x381e48,this['_path'],!0x1);const _0x5bc36c=new H();return yr(this['_repo'],this['_path'],_0x381e48,_0x5bc36c['wrapCallback'](()=>{})),_0x5bc36c['promise'];}['setWithPriority'](_0x42a252,_0x3348f4){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x42a252,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x3348f4);const _0x542d14=new H();return Rd(this['_repo'],this['_path'],_0x42a252,_0x3348f4,_0x542d14['wrapCallback'](()=>{})),_0x542d14['promise'];}['update'](_0x1da295){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x1da295,this['_path']);const _0x38f3e0=new H();return Ad(this['_repo'],this['_path'],_0x1da295,_0x38f3e0['wrapCallback'](()=>{})),_0x38f3e0['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x50ddd8,_0x33ecf7,_0x53d516,_0x2006c3){this['_repo']=_0x50ddd8,this['_path']=_0x33ecf7,this['_queryParams']=_0x53d516,this['_orderByCalled']=_0x2006c3;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x5b6e5b=sr(this['_queryParams']),_0x32d86c=$i(_0x5b6e5b);return _0x32d86c==='{}'?'default':_0x32d86c;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x1a11da){if(_0x1a11da=P(_0x1a11da),!(_0x1a11da instanceof Ae))return!0x1;const _0x1e874=this['_repo']===_0x1a11da['_repo'],_0x79014d=Ki(this['_path'],_0x1a11da['_path']),_0x49e47a=this['_queryIdentifier']===_0x1a11da['_queryIdentifier'];return _0x1e874&&_0x79014d&&_0x49e47a;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x205dea,_0x2c18e0){if(_0x205dea['_orderByCalled']===!0x0)throw new Error(_0x2c18e0+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x495898){let _0xc7a51d=null,_0x347018=null;if(_0x495898['hasStart']()&&(_0xc7a51d=_0x495898['getIndexStartValue']()),_0x495898['hasEnd']()&&(_0x347018=_0x495898['getIndexEndValue']()),_0x495898['getIndex']()===ve){const _0x3bbdda='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x11c0ca='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x495898['hasStart']()){if(_0x495898['getIndexStartName']()!==We)throw new Error(_0x3bbdda);if(typeof _0xc7a51d!='string')throw new Error(_0x11c0ca);}if(_0x495898['hasEnd']()){if(_0x495898['getIndexEndName']()!==we)throw new Error(_0x3bbdda);if(typeof _0x347018!='string')throw new Error(_0x11c0ca);}}else{if(_0x495898['getIndex']()===R){if(_0xc7a51d!=null&&!Bt(_0xc7a51d)||_0x347018!=null&&!Bt(_0x347018))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x495898['getIndex']()instanceof Ji||_0x495898['getIndex']()===Mo,'unknown\x20index\x20type.'),_0xc7a51d!=null&&typeof _0xc7a51d=='object'||_0x347018!=null&&typeof _0x347018=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x4dd4e9){if(_0x4dd4e9['hasStart']()&&_0x4dd4e9['hasEnd']()&&_0x4dd4e9['hasLimit']()&&!_0x4dd4e9['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x5309c1,_0x4852c2){super(_0x5309c1,_0x4852c2,new Zi(),!0x1);}get['parent'](){const _0x2cbc1b=Ro(this['_path']);return _0x2cbc1b===null?null:new ee(this['_repo'],_0x2cbc1b);}get['root'](){let _0x3bdecc=this;for(;_0x3bdecc['parent']!==null;)_0x3bdecc=_0x3bdecc['parent'];return _0x3bdecc;}}class lt{constructor(_0x4445d5,_0x1a109e,_0x3adbd2){this['_node']=_0x4445d5,this['ref']=_0x1a109e,this['_index']=_0x3adbd2;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x193cc0){const _0x4ef8f5=new C(_0x193cc0),_0x391c8b=Vt(this['ref'],_0x193cc0);return new lt(this['_node']['getChild'](_0x4ef8f5),_0x391c8b,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x198060){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0xe4687e,_0x3f5d97)=>_0x198060(new lt(_0x3f5d97,Vt(this['ref'],_0xe4687e),R)));}['hasChild'](_0x1a2bd7){const _0x2aa37a=new C(_0x1a2bd7);return!this['_node']['getChild'](_0x2aa37a)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x4f76c6,_0x18bee4){return _0x4f76c6=P(_0x4f76c6),_0x4f76c6['_checkNotDeleted']('ref'),_0x18bee4!==void 0x0?Vt(_0x4f76c6['_root'],_0x18bee4):_0x4f76c6['_root'];}function Vt(_0x181c13,_0x38166d){return _0x181c13=P(_0x181c13),y(_0x181c13['_path'])===null?pd('child','path',_0x38166d):ys('child','path',_0x38166d),new ee(_0x181c13['_repo'],k(_0x181c13['_path'],_0x38166d));}function v_(_0x11aa3b){return _0x11aa3b=P(_0x11aa3b),new Vd(_0x11aa3b['_repo'],_0x11aa3b['_path']);}function E_(_0xef6e64,_0x533b0b){_0xef6e64=P(_0xef6e64),Me('push',_0xef6e64['_path']),He('push',_0x533b0b,_0xef6e64['_path'],!0x0);const _0x257b6c=la(_0xef6e64['_repo']),_0x38331c=Ud(_0x257b6c),_0x17ada3=Vt(_0xef6e64,_0x38331c),_0x147bc4=Vt(_0xef6e64,_0x38331c);let _0x3f54ec;return _0x533b0b!=null?_0x3f54ec=Hd(_0x147bc4,_0x533b0b)['then'](()=>_0x147bc4):_0x3f54ec=Promise['resolve'](_0x147bc4),_0x17ada3['then']=_0x3f54ec['then']['bind'](_0x3f54ec),_0x17ada3['catch']=_0x3f54ec['then']['bind'](_0x3f54ec,void 0x0),_0x17ada3;}function Hd(_0x12ff7c,_0x441fa0){_0x12ff7c=P(_0x12ff7c),Me('set',_0x12ff7c['_path']),He('set',_0x441fa0,_0x12ff7c['_path'],!0x1);const _0x12dabd=new H();return Cd(_0x12ff7c['_repo'],_0x12ff7c['_path'],_0x441fa0,null,_0x12dabd['wrapCallback'](()=>{})),_0x12dabd['promise'];}function I_(_0x689235,_0x30532e){ra('update',_0x30532e,_0x689235['_path']);const _0x313fb3=new H();return Td(_0x689235['_repo'],_0x689235['_path'],_0x30532e,_0x313fb3['wrapCallback'](()=>{})),_0x313fb3['promise'];}function w_(_0x395cc2){_0x395cc2=P(_0x395cc2);const _0x266052=new pa(()=>{}),_0x1c57f2=new Qn(_0x266052);return wd(_0x395cc2['_repo'],_0x395cc2,_0x1c57f2)['then'](_0x4b76f4=>new lt(_0x4b76f4,new ee(_0x395cc2['_repo'],_0x395cc2['_path']),_0x395cc2['_queryParams']['getIndex']()));}class Qn{constructor(_0x24eda4){this['callbackContext']=_0x24eda4;}['respondsTo'](_0x465f71){return _0x465f71==='value';}['createEvent'](_0x44c05b,_0x148c76){const _0x5ed94d=_0x148c76['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x44c05b['snapshotNode'],new ee(_0x148c76['_repo'],_0x148c76['_path']),_0x5ed94d));}['getEventRunner'](_0x5c5fb7){return _0x5c5fb7['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x5c5fb7['error']):()=>this['callbackContext']['onValue'](_0x5c5fb7['snapshot'],null);}['createCancelEvent'](_0x1a404e,_0xe5a07f){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x1a404e,_0xe5a07f):null;}['matches'](_0x331351){return _0x331351 instanceof Qn?!_0x331351['callbackContext']||!this['callbackContext']?!0x0:_0x331351['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x977b35,_0x209bb4,_0x28034c,_0x62fac2,_0x36cc16){const _0x39e26a=new pa(_0x28034c,void 0x0),_0x2b590d=new Qn(_0x39e26a);return kd(_0x977b35['_repo'],_0x977b35,_0x2b590d),()=>Pd(_0x977b35['_repo'],_0x977b35,_0x2b590d);}function Gd(_0x5211d3,_0x3c235a,_0x5c23b4,_0x1ff9ec){return $d(_0x5211d3,'value',_0x3c235a);}class mt{}class ma extends mt{constructor(_0x45ab3f,_0x58c96c){super(),this['_value']=_0x45ab3f,this['_key']=_0x58c96c,this['type']='endAt';}['_apply'](_0x9969c7){He('endAt',this['_value'],_0x9969c7['_path'],!0x0);const _0x70a5b7=Jh(_0x9969c7['_queryParams'],this['_value'],this['_key']);if(ga(_0x70a5b7),Yn(_0x70a5b7),_0x9969c7['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x9969c7['_repo'],_0x9969c7['_path'],_0x70a5b7,_0x9969c7['_orderByCalled']);}}function C_(_0x1a6de2,_0xc68053){return new ma(_0x1a6de2,_0xc68053);}class ya extends mt{constructor(_0x526523,_0x5e7de3){super(),this['_value']=_0x526523,this['_key']=_0x5e7de3,this['type']='startAt';}['_apply'](_0x5bcfda){He('startAt',this['_value'],_0x5bcfda['_path'],!0x0);const _0x2c28dd=Qh(_0x5bcfda['_queryParams'],this['_value'],this['_key']);if(ga(_0x2c28dd),Yn(_0x2c28dd),_0x5bcfda['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x5bcfda['_repo'],_0x5bcfda['_path'],_0x2c28dd,_0x5bcfda['_orderByCalled']);}}function T_(_0x2170e0=null,_0x38ae7b){return new ya(_0x2170e0,_0x38ae7b);}class qd extends mt{constructor(_0x1bc13b){super(),this['_limit']=_0x1bc13b,this['type']='limitToFirst';}['_apply'](_0x3f15db){if(_0x3f15db['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x3f15db['_repo'],_0x3f15db['_path'],Yh(_0x3f15db['_queryParams'],this['_limit']),_0x3f15db['_orderByCalled']);}}function S_(_0x405864){if(Math['floor'](_0x405864)!==_0x405864||_0x405864<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x405864);}class zd extends mt{constructor(_0x46f15f){super(),this['_path']=_0x46f15f,this['type']='orderByChild';}['_apply'](_0x2af2e8){_a(_0x2af2e8,'orderByChild');const _0x1a1d28=new C(this['_path']);if(v(_0x1a1d28))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x495f85=new Ji(_0x1a1d28),_0x153d6a=xo(_0x2af2e8['_queryParams'],_0x495f85);return Yn(_0x153d6a),new Ae(_0x2af2e8['_repo'],_0x2af2e8['_path'],_0x153d6a,!0x0);}}function b_(_0x161d84){if(_0x161d84==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x161d84==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x161d84==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x161d84),new zd(_0x161d84);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x2836cf){_a(_0x2836cf,'orderByKey');const _0x838424=xo(_0x2836cf['_queryParams'],ve);return Yn(_0x838424),new Ae(_0x2836cf['_repo'],_0x2836cf['_path'],_0x838424,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x50932d,_0x324709){super(),this['_value']=_0x50932d,this['_key']=_0x324709,this['type']='equalTo';}['_apply'](_0x2053e4){if(He('equalTo',this['_value'],_0x2053e4['_path'],!0x1),_0x2053e4['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x2053e4['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x2053e4));}}function A_(_0x5aba4d,_0x2ed24d){return new Kd(_0x5aba4d,_0x2ed24d);}function k_(_0x2ff0b8,..._0x1ed675){let _0x8dd5eb=P(_0x2ff0b8);for(const _0x6ea10d of _0x1ed675)_0x8dd5eb=_0x6ea10d['_apply'](_0x8dd5eb);return _0x8dd5eb;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x116a15,_0x2a9b70,_0x44255c,_0x258bea){const _0x2dcdf0=_0x2a9b70['lastIndexOf'](':'),_0x2c31ec=_0x2a9b70['substring'](0x0,_0x2dcdf0),_0x4399c9=qt(_0x2c31ec);_0x116a15['repoInfo_']=new yo(_0x2a9b70,_0x4399c9,_0x116a15['repoInfo_']['namespace'],_0x116a15['repoInfo_']['webSocketOnly'],_0x116a15['repoInfo_']['nodeAdmin'],_0x116a15['repoInfo_']['persistenceKey'],_0x116a15['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x44255c),_0x258bea&&(_0x116a15['authTokenProvider_']=_0x258bea);}function Xd(_0x18c4e1,_0x510562,_0x474da3,_0x2ab0aa,_0x2598e7){let _0xe65b38=_0x2ab0aa||_0x18c4e1['options']['databaseURL'];_0xe65b38===void 0x0&&(_0x18c4e1['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x18c4e1['options']['projectId']),_0xe65b38=_0x18c4e1['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x10a053=vr(_0xe65b38,_0x2598e7),_0x1bda15=_0x10a053['repoInfo'],_0x4fa26e;typeof process<'u'&&Bs&&(_0x4fa26e=Bs[Yd]),_0x4fa26e?(_0xe65b38='http://'+_0x4fa26e+'?ns='+_0x1bda15['namespace'],_0x10a053=vr(_0xe65b38,_0x2598e7),_0x1bda15=_0x10a053['repoInfo']):_0x10a053['repoInfo']['secure'];const _0x15a2e3=new eh(_0x18c4e1['name'],_0x18c4e1['options'],_0x510562);_d('Invalid\x20Firebase\x20Database\x20URL',_0x10a053),v(_0x10a053['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x195855=ef(_0x1bda15,_0x18c4e1,_0x15a2e3,new Zl(_0x18c4e1,_0x474da3));return new tf(_0x195855,_0x18c4e1);}function Zd(_0x1ccdf5,_0x57e24c){const _0x694bf5=Di[_0x57e24c];(!_0x694bf5||_0x694bf5[_0x1ccdf5['key']]!==_0x1ccdf5)&&ae('Database\x20'+_0x57e24c+'('+_0x1ccdf5['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x1ccdf5),delete _0x694bf5[_0x1ccdf5['key']];}function ef(_0x50e4c2,_0x38db0e,_0x150853,_0x23545b){let _0x5bb450=Di[_0x38db0e['name']];_0x5bb450||(_0x5bb450={},Di[_0x38db0e['name']]=_0x5bb450);let _0x2d591f=_0x5bb450[_0x50e4c2['toURLString']()];return _0x2d591f&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x2d591f=new vd(_0x50e4c2,Qd,_0x150853,_0x23545b),_0x5bb450[_0x50e4c2['toURLString']()]=_0x2d591f,_0x2d591f;}class tf{constructor(_0x482de9,_0x153a9b){this['_repoInternal']=_0x482de9,this['app']=_0x153a9b,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x5abec2){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x5abec2+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x755f8=Zr(),_0x23c33b){const _0x44ba6c=Hi(_0x755f8,'database')['getImmediate']({'identifier':_0x23c33b});if(!_0x44ba6c['_instanceStarted']){const _0x34097e=hc('database');_0x34097e&&nf(_0x44ba6c,..._0x34097e);}return _0x44ba6c;}function nf(_0x5250fe,_0x597bef,_0x1a0928,_0x549a88={}){_0x5250fe=P(_0x5250fe),_0x5250fe['_checkNotDeleted']('useEmulator');const _0x6fc26d=_0x597bef+':'+_0x1a0928,_0x57f5dc=_0x5250fe['_repoInternal'];if(_0x5250fe['_instanceStarted']){if(_0x6fc26d===_0x5250fe['_repoInternal']['repoInfo_']['host']&&xe(_0x549a88,_0x57f5dc['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x1c0225;if(_0x57f5dc['repoInfo_']['nodeAdmin'])_0x549a88['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x1c0225=new an(an['OWNER']);else{if(_0x549a88['mockUserToken']){const _0x27e639=typeof _0x549a88['mockUserToken']=='string'?_0x549a88['mockUserToken']:uc(_0x549a88['mockUserToken'],_0x5250fe['app']['options']['projectId']);_0x1c0225=new an(_0x27e639);}}qt(_0x597bef)&&Qr(_0x597bef),Jd(_0x57f5dc,_0x6fc26d,_0x549a88,_0x1c0225);}function N_(_0x52af6e){_0x52af6e=P(_0x52af6e),_0x52af6e['_checkNotDeleted']('goOffline'),ha(_0x52af6e['_repo']);}function O_(_0x31d6bc){_0x31d6bc=P(_0x31d6bc),_0x31d6bc['_checkNotDeleted']('goOnline'),Nd(_0x31d6bc['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0xe4f769){Ul(dt),st(new Fe('database',(_0x3db6a6,{instanceIdentifier:_0x350d27})=>{const _0x176537=_0x3db6a6['getProvider']('app')['getImmediate'](),_0x5bc378=_0x3db6a6['getProvider']('auth-internal'),_0x49ab69=_0x3db6a6['getProvider']('app-check-internal');return Xd(_0x176537,_0x5bc378,_0x49ab69,_0x350d27);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0xe4f769),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x543999,_0x116092){this['committed']=_0x543999,this['snapshot']=_0x116092;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x2fd457,_0x30d653,_0x2d6b5f){if(_0x2fd457=P(_0x2fd457),Me('Reference.transaction',_0x2fd457['_path']),_0x2fd457['key']==='.length'||_0x2fd457['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x2fd457['key']+'\x20is\x20a\x20read-only\x20object.';const _0x52f04e=!0x0,_0x21f10a=new H(),_0x544d2e=(_0x2931df,_0x5a7783,_0x43c1a1)=>{let _0x5e365f=null;_0x2931df?_0x21f10a['reject'](_0x2931df):(_0x5e365f=new lt(_0x43c1a1,new ee(_0x2fd457['_repo'],_0x2fd457['_path']),R),_0x21f10a['resolve'](new of(_0x5a7783,_0x5e365f)));},_0x39821f=Gd(_0x2fd457,()=>{});return Od(_0x2fd457['_repo'],_0x2fd457['_path'],_0x30d653,_0x544d2e,_0x39821f,_0x52f04e),_0x21f10a['promise'];}se['prototype']['simpleListen']=function(_0x1a0f2c,_0x3be48c){this['sendRequest']('q',{'p':_0x1a0f2c},_0x3be48c);},se['prototype']['echo']=function(_0x519d41,_0x2824fc){this['sendRequest']('echo',{'d':_0x519d41},_0x2824fc);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x5621db,..._0x4ae62a){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x5621db,..._0x4ae62a);}function cn(_0xa47457,..._0x21ec0e){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0xa47457,..._0x21ec0e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0xd792d0,..._0x3a9dd6){throw ws(_0xd792d0,..._0x3a9dd6);}function X(_0x193dc5,..._0x5fbf37){return ws(_0x193dc5,..._0x5fbf37);}function Ia(_0x2c3bb7,_0x1dd856,_0x425025){const _0x3d2bfd={...af(),[_0x1dd856]:_0x425025};return new Gt('auth','Firebase',_0x3d2bfd)['create'](_0x1dd856,{'appName':_0x2c3bb7['name']});}function re(_0x214058){return Ia(_0x214058,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x348809,..._0x50c788){if(typeof _0x348809!='string'){const _0x4672e0=_0x50c788[0x0],_0x1252b6=[..._0x50c788['slice'](0x1)];return _0x1252b6[0x0]&&(_0x1252b6[0x0]['appName']=_0x348809['name']),_0x348809['_errorFactory']['create'](_0x4672e0,..._0x1252b6);}return Ea['create'](_0x348809,..._0x50c788);}function m(_0x5e0a61,_0xd8e6d1,..._0x50ac10){if(!_0x5e0a61)throw ws(_0xd8e6d1,..._0x50ac10);}function ne(_0x52c290){const _0x20f9aa='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x52c290;throw cn(_0x20f9aa),new Error(_0x20f9aa);}function ce(_0x563cf0,_0x1d0998){_0x563cf0||ne(_0x1d0998);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x2bb73d;return typeof self<'u'&&((_0x2bb73d=self['location'])==null?void 0x0:_0x2bb73d['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x32c2fc;return typeof self<'u'&&((_0x32c2fc=self['location'])==null?void 0x0:_0x32c2fc['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x41aeb0=navigator;return _0x41aeb0['languages']&&_0x41aeb0['languages'][0x0]||_0x41aeb0['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x3767aa,_0x4c41be){this['shortDelay']=_0x3767aa,this['longDelay']=_0x4c41be,ce(_0x4c41be>_0x3767aa,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0xcdb44d,_0x1a9e99){ce(_0xcdb44d['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x4fae1f}=_0xcdb44d['emulator'];return _0x1a9e99?''+_0x4fae1f+(_0x1a9e99['startsWith']('/')?_0x1a9e99['slice'](0x1):_0x1a9e99):_0x4fae1f;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x567f9f,_0xcfb6f5,_0x295187){this['fetchImpl']=_0x567f9f,_0xcfb6f5&&(this['headersImpl']=_0xcfb6f5),_0x295187&&(this['responseImpl']=_0x295187);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x10e989,_0xd98ca7){return _0x10e989['tenantId']&&!_0xd98ca7['tenantId']?{..._0xd98ca7,'tenantId':_0x10e989['tenantId']}:_0xd98ca7;}async function Pe(_0xef17bd,_0x6a83fd,_0x510db0,_0x338262,_0x3ff991={}){return Ca(_0xef17bd,_0x3ff991,async()=>{let _0x1bb5d7={},_0x3447aa={};_0x338262&&(_0x6a83fd==='GET'?_0x3447aa=_0x338262:_0x1bb5d7={'body':JSON['stringify'](_0x338262)});const _0x26cbc2=ut({..._0x3447aa,'key':_0xef17bd['config']['apiKey']})['slice'](0x1),_0x31bbd1=await _0xef17bd['_getAdditionalHeaders']();_0x31bbd1['Content-Type']='application/json',_0xef17bd['languageCode']&&(_0x31bbd1['X-Firebase-Locale']=_0xef17bd['languageCode']);const _0x2a523a={'method':_0x6a83fd,'headers':_0x31bbd1,..._0x1bb5d7};return dc()||(_0x2a523a['referrerPolicy']='strict-origin-when-cross-origin'),_0xef17bd['emulatorConfig']&&qt(_0xef17bd['emulatorConfig']['host'])&&(_0x2a523a['credentials']='include'),wa['fetch']()(await Ta(_0xef17bd,_0xef17bd['config']['apiHost'],_0x510db0,_0x26cbc2),_0x2a523a);});}async function Ca(_0x450edc,_0x2bf5e3,_0x446989){_0x450edc['_canInitEmulator']=!0x1;const _0x25a6ac={...df,..._0x2bf5e3};try{const _0x1b703d=new gf(_0x450edc),_0x2c9572=await Promise['race']([_0x446989(),_0x1b703d['promise']]);_0x1b703d['clearNetworkTimeout']();const _0x23c837=await _0x2c9572['json']();if('needConfirmation'in _0x23c837)throw on(_0x450edc,'account-exists-with-different-credential',_0x23c837);if(_0x2c9572['ok']&&!('errorMessage'in _0x23c837))return _0x23c837;{const _0x38e40f=_0x2c9572['ok']?_0x23c837['errorMessage']:_0x23c837['error']['message'],[_0x598853,_0x626909]=_0x38e40f['split']('\x20:\x20');if(_0x598853==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x450edc,'credential-already-in-use',_0x23c837);if(_0x598853==='EMAIL_EXISTS')throw on(_0x450edc,'email-already-in-use',_0x23c837);if(_0x598853==='USER_DISABLED')throw on(_0x450edc,'user-disabled',_0x23c837);const _0x2849d0=_0x25a6ac[_0x598853]||_0x598853['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x626909)throw Ia(_0x450edc,_0x2849d0,_0x626909);Y(_0x450edc,_0x2849d0);}}catch(_0x2e4967){if(_0x2e4967 instanceof Re)throw _0x2e4967;Y(_0x450edc,'network-request-failed',{'message':String(_0x2e4967)});}}async function en(_0x582c79,_0x40bfaa,_0x57bf90,_0x2dace0,_0x32b080={}){const _0x1c150b=await Pe(_0x582c79,_0x40bfaa,_0x57bf90,_0x2dace0,_0x32b080);return'mfaPendingCredential'in _0x1c150b&&Y(_0x582c79,'multi-factor-auth-required',{'_serverResponse':_0x1c150b}),_0x1c150b;}async function Ta(_0x3738c1,_0x52fde9,_0x2d2b99,_0xe81453){const _0x278633=''+_0x52fde9+_0x2d2b99+'?'+_0xe81453,_0x44d52c=_0x3738c1,_0x21da1c=_0x44d52c['config']['emulator']?Cs(_0x3738c1['config'],_0x278633):_0x3738c1['config']['apiScheme']+'://'+_0x278633;return ff['includes'](_0x2d2b99)&&(await _0x44d52c['_persistenceManagerAvailable'],_0x44d52c['_getPersistenceType']()==='COOKIE')?_0x44d52c['_getPersistence']()['_getFinalTarget'](_0x21da1c)['toString']():_0x21da1c;}function _f(_0x396c7d){switch(_0x396c7d){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x1b7b04){this['auth']=_0x1b7b04,this['timer']=null,this['promise']=new Promise((_0x186dd2,_0x4db3d1)=>{this['timer']=setTimeout(()=>_0x4db3d1(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x547e74,_0x3c787d,_0x42ea0b){const _0x39cda1={'appName':_0x547e74['name']};_0x42ea0b['email']&&(_0x39cda1['email']=_0x42ea0b['email']),_0x42ea0b['phoneNumber']&&(_0x39cda1['phoneNumber']=_0x42ea0b['phoneNumber']);const _0xe83720=X(_0x547e74,_0x3c787d,_0x39cda1);return _0xe83720['customData']['_tokenResponse']=_0x42ea0b,_0xe83720;}function wr(_0x2d63b3){return _0x2d63b3!==void 0x0&&_0x2d63b3['enterprise']!==void 0x0;}class mf{constructor(_0x29135a){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x29135a['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x29135a['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x29135a['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x7e3e0c){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x46d2e7 of this['recaptchaEnforcementState'])if(_0x46d2e7['provider']&&_0x46d2e7['provider']===_0x7e3e0c)return _f(_0x46d2e7['enforcementState']);return null;}['isProviderEnabled'](_0x29ed3e){return this['getProviderEnforcementState'](_0x29ed3e)==='ENFORCE'||this['getProviderEnforcementState'](_0x29ed3e)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x5f21dd,_0xa73a0f){return Pe(_0x5f21dd,'GET','/v2/recaptchaConfig',ke(_0x5f21dd,_0xa73a0f));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x2c7470,_0x598172){return Pe(_0x2c7470,'POST','/v1/accounts:delete',_0x598172);}async function Pn(_0x3b073f,_0x4b5213){return Pe(_0x3b073f,'POST','/v1/accounts:lookup',_0x4b5213);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x17bdda){if(_0x17bdda)try{const _0x457ad2=new Date(Number(_0x17bdda));if(!isNaN(_0x457ad2['getTime']()))return _0x457ad2['toUTCString']();}catch{}}async function Ef(_0x1b9d03,_0x350919=!0x1){const _0x349084=P(_0x1b9d03),_0x2548c3=await _0x349084['getIdToken'](_0x350919),_0x3ab5ee=Ts(_0x2548c3);m(_0x3ab5ee&&_0x3ab5ee['exp']&&_0x3ab5ee['auth_time']&&_0x3ab5ee['iat'],_0x349084['auth'],'internal-error');const _0x3fa5ac=typeof _0x3ab5ee['firebase']=='object'?_0x3ab5ee['firebase']:void 0x0,_0x2032cb=_0x3fa5ac==null?void 0x0:_0x3fa5ac['sign_in_provider'];return{'claims':_0x3ab5ee,'token':_0x2548c3,'authTime':Pt(fi(_0x3ab5ee['auth_time'])),'issuedAtTime':Pt(fi(_0x3ab5ee['iat'])),'expirationTime':Pt(fi(_0x3ab5ee['exp'])),'signInProvider':_0x2032cb||null,'signInSecondFactor':(_0x3fa5ac==null?void 0x0:_0x3fa5ac['sign_in_second_factor'])||null};}function fi(_0x3b5d2b){return Number(_0x3b5d2b)*0x3e8;}function Ts(_0x501b0f){const [_0x1d2ef8,_0x58b29e,_0x36c396]=_0x501b0f['split']('.');if(_0x1d2ef8===void 0x0||_0x58b29e===void 0x0||_0x36c396===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x2f1925=fn(_0x58b29e);return _0x2f1925?JSON['parse'](_0x2f1925):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x9e4729){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x9e4729==null?void 0x0:_0x9e4729['toString']()),null;}}function Cr(_0x400faa){const _0x1843aa=Ts(_0x400faa);return m(_0x1843aa,'internal-error'),m(typeof _0x1843aa['exp']<'u','internal-error'),m(typeof _0x1843aa['iat']<'u','internal-error'),Number(_0x1843aa['exp'])-Number(_0x1843aa['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0xa7235f,_0x50d002,_0xa65212=!0x1){if(_0xa65212)return _0x50d002;try{return await _0x50d002;}catch(_0x1ad78f){throw _0x1ad78f instanceof Re&&If(_0x1ad78f)&&_0xa7235f['auth']['currentUser']===_0xa7235f&&await _0xa7235f['auth']['signOut'](),_0x1ad78f;}}function If({code:_0x3d9613}){return _0x3d9613==='auth/user-disabled'||_0x3d9613==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x5abd93){this['user']=_0x5abd93,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x590349){if(_0x590349){const _0xc94df3=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0xc94df3;}else{this['errorBackoff']=0x7530;const _0x30653c=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x30653c);}}['schedule'](_0x192540=!0x1){if(!this['isRunning'])return;const _0x4b1f20=this['getInterval'](_0x192540);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x4b1f20);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x25bb58){(_0x25bb58==null?void 0x0:_0x25bb58['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0xf29ed9,_0x21bd93){this['createdAt']=_0xf29ed9,this['lastLoginAt']=_0x21bd93,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x12b3a2){this['createdAt']=_0x12b3a2['createdAt'],this['lastLoginAt']=_0x12b3a2['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x56b8f7){var _0x53ebda;const _0x5f26c0=_0x56b8f7['auth'],_0x4797b3=await _0x56b8f7['getIdToken'](),_0x2f7cbe=await Ht(_0x56b8f7,Pn(_0x5f26c0,{'idToken':_0x4797b3}));m(_0x2f7cbe==null?void 0x0:_0x2f7cbe['users']['length'],_0x5f26c0,'internal-error');const _0x105c43=_0x2f7cbe['users'][0x0];_0x56b8f7['_notifyReloadListener'](_0x105c43);const _0x71d9b5=(_0x53ebda=_0x105c43['providerUserInfo'])!=null&&_0x53ebda['length']?Sa(_0x105c43['providerUserInfo']):[],_0x101237=Tf(_0x56b8f7['providerData'],_0x71d9b5),_0x44fd99=_0x56b8f7['isAnonymous'],_0x2589c9=!(_0x56b8f7['email']&&_0x105c43['passwordHash'])&&!(_0x101237!=null&&_0x101237['length']),_0x8c3d6b=_0x44fd99?_0x2589c9:!0x1,_0x46b77f={'uid':_0x105c43['localId'],'displayName':_0x105c43['displayName']||null,'photoURL':_0x105c43['photoUrl']||null,'email':_0x105c43['email']||null,'emailVerified':_0x105c43['emailVerified']||!0x1,'phoneNumber':_0x105c43['phoneNumber']||null,'tenantId':_0x105c43['tenantId']||null,'providerData':_0x101237,'metadata':new Li(_0x105c43['createdAt'],_0x105c43['lastLoginAt']),'isAnonymous':_0x8c3d6b};Object['assign'](_0x56b8f7,_0x46b77f);}async function Cf(_0xe6496){const _0x376d9d=P(_0xe6496);await Nn(_0x376d9d),await _0x376d9d['auth']['_persistUserIfCurrent'](_0x376d9d),_0x376d9d['auth']['_notifyListenersIfCurrent'](_0x376d9d);}function Tf(_0x5db73e,_0x3e9369){return[..._0x5db73e['filter'](_0x360ab9=>!_0x3e9369['some'](_0x544291=>_0x544291['providerId']===_0x360ab9['providerId'])),..._0x3e9369];}function Sa(_0x11cb0c){return _0x11cb0c['map'](({providerId:_0x52c043,..._0x248a95})=>({'providerId':_0x52c043,'uid':_0x248a95['rawId']||'','displayName':_0x248a95['displayName']||null,'email':_0x248a95['email']||null,'phoneNumber':_0x248a95['phoneNumber']||null,'photoURL':_0x248a95['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x107a9a,_0x36ca2d){const _0x428559=await Ca(_0x107a9a,{},async()=>{const _0x5bdb56=ut({'grant_type':'refresh_token','refresh_token':_0x36ca2d})['slice'](0x1),{tokenApiHost:_0x129b7e,apiKey:_0x3911ef}=_0x107a9a['config'],_0x38dad8=await Ta(_0x107a9a,_0x129b7e,'/v1/token','key='+_0x3911ef),_0x4a6025=await _0x107a9a['_getAdditionalHeaders']();_0x4a6025['Content-Type']='application/x-www-form-urlencoded';const _0x26a2ba={'method':'POST','headers':_0x4a6025,'body':_0x5bdb56};return _0x107a9a['emulatorConfig']&&qt(_0x107a9a['emulatorConfig']['host'])&&(_0x26a2ba['credentials']='include'),wa['fetch']()(_0x38dad8,_0x26a2ba);});return{'accessToken':_0x428559['access_token'],'expiresIn':_0x428559['expires_in'],'refreshToken':_0x428559['refresh_token']};}async function bf(_0x1adacf,_0x10fce3){return Pe(_0x1adacf,'POST','/v2/accounts:revokeToken',ke(_0x1adacf,_0x10fce3));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x4ad276){m(_0x4ad276['idToken'],'internal-error'),m(typeof _0x4ad276['idToken']<'u','internal-error'),m(typeof _0x4ad276['refreshToken']<'u','internal-error');const _0x2c185e='expiresIn'in _0x4ad276&&typeof _0x4ad276['expiresIn']<'u'?Number(_0x4ad276['expiresIn']):Cr(_0x4ad276['idToken']);this['updateTokensAndExpiration'](_0x4ad276['idToken'],_0x4ad276['refreshToken'],_0x2c185e);}['updateFromIdToken'](_0xb7ab98){m(_0xb7ab98['length']!==0x0,'internal-error');const _0xaa44c0=Cr(_0xb7ab98);this['updateTokensAndExpiration'](_0xb7ab98,null,_0xaa44c0);}async['getToken'](_0x22d64a,_0x5a560e=!0x1){return!_0x5a560e&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x22d64a,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x22d64a,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x225f8f,_0x185852){const {accessToken:_0x3580a6,refreshToken:_0x3a778b,expiresIn:_0x5c9f1f}=await Sf(_0x225f8f,_0x185852);this['updateTokensAndExpiration'](_0x3580a6,_0x3a778b,Number(_0x5c9f1f));}['updateTokensAndExpiration'](_0x26d0a0,_0x5cea2e,_0x1b0269){this['refreshToken']=_0x5cea2e||null,this['accessToken']=_0x26d0a0||null,this['expirationTime']=Date['now']()+_0x1b0269*0x3e8;}static['fromJSON'](_0x1a0f5f,_0x27be0e){const {refreshToken:_0x459985,accessToken:_0x3dd28a,expirationTime:_0x1ab4ef}=_0x27be0e,_0x297b86=new et();return _0x459985&&(m(typeof _0x459985=='string','internal-error',{'appName':_0x1a0f5f}),_0x297b86['refreshToken']=_0x459985),_0x3dd28a&&(m(typeof _0x3dd28a=='string','internal-error',{'appName':_0x1a0f5f}),_0x297b86['accessToken']=_0x3dd28a),_0x1ab4ef&&(m(typeof _0x1ab4ef=='number','internal-error',{'appName':_0x1a0f5f}),_0x297b86['expirationTime']=_0x1ab4ef),_0x297b86;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x4315ba){this['accessToken']=_0x4315ba['accessToken'],this['refreshToken']=_0x4315ba['refreshToken'],this['expirationTime']=_0x4315ba['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x3f4c1f,_0x4148d9){m(typeof _0x3f4c1f=='string'||typeof _0x3f4c1f>'u','internal-error',{'appName':_0x4148d9});}class j{constructor({uid:_0x37d9bb,auth:_0x772ed9,stsTokenManager:_0x22b8c0,..._0x1a65ae}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x37d9bb,this['auth']=_0x772ed9,this['stsTokenManager']=_0x22b8c0,this['accessToken']=_0x22b8c0['accessToken'],this['displayName']=_0x1a65ae['displayName']||null,this['email']=_0x1a65ae['email']||null,this['emailVerified']=_0x1a65ae['emailVerified']||!0x1,this['phoneNumber']=_0x1a65ae['phoneNumber']||null,this['photoURL']=_0x1a65ae['photoURL']||null,this['isAnonymous']=_0x1a65ae['isAnonymous']||!0x1,this['tenantId']=_0x1a65ae['tenantId']||null,this['providerData']=_0x1a65ae['providerData']?[..._0x1a65ae['providerData']]:[],this['metadata']=new Li(_0x1a65ae['createdAt']||void 0x0,_0x1a65ae['lastLoginAt']||void 0x0);}async['getIdToken'](_0xf6c52c){const _0x3c0f15=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0xf6c52c));return m(_0x3c0f15,this['auth'],'internal-error'),this['accessToken']!==_0x3c0f15&&(this['accessToken']=_0x3c0f15,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x3c0f15;}['getIdTokenResult'](_0x5b7aca){return Ef(this,_0x5b7aca);}['reload'](){return Cf(this);}['_assign'](_0x4aef23){this!==_0x4aef23&&(m(this['uid']===_0x4aef23['uid'],this['auth'],'internal-error'),this['displayName']=_0x4aef23['displayName'],this['photoURL']=_0x4aef23['photoURL'],this['email']=_0x4aef23['email'],this['emailVerified']=_0x4aef23['emailVerified'],this['phoneNumber']=_0x4aef23['phoneNumber'],this['isAnonymous']=_0x4aef23['isAnonymous'],this['tenantId']=_0x4aef23['tenantId'],this['providerData']=_0x4aef23['providerData']['map'](_0x12a9e7=>({..._0x12a9e7})),this['metadata']['_copy'](_0x4aef23['metadata']),this['stsTokenManager']['_assign'](_0x4aef23['stsTokenManager']));}['_clone'](_0x361f3e){const _0x3835d6=new j({...this,'auth':_0x361f3e,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x3835d6['metadata']['_copy'](this['metadata']),_0x3835d6;}['_onReload'](_0x275abf){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x275abf,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x2034fb){this['reloadListener']?this['reloadListener'](_0x2034fb):this['reloadUserInfo']=_0x2034fb;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x5af66f,_0x236cd1=!0x1){let _0x26b2c4=!0x1;_0x5af66f['idToken']&&_0x5af66f['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x5af66f),_0x26b2c4=!0x0),_0x236cd1&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x26b2c4&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x30edf5=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x30edf5})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x1b470d=>({..._0x1b470d})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x539970,_0x539069){const _0x366a91=_0x539069['displayName']??void 0x0,_0x26bb00=_0x539069['email']??void 0x0,_0x3962b0=_0x539069['phoneNumber']??void 0x0,_0x1d06f8=_0x539069['photoURL']??void 0x0,_0x517902=_0x539069['tenantId']??void 0x0,_0x1b51a1=_0x539069['_redirectEventId']??void 0x0,_0x408d18=_0x539069['createdAt']??void 0x0,_0x5bd730=_0x539069['lastLoginAt']??void 0x0,{uid:_0x4738f1,emailVerified:_0x30c4b0,isAnonymous:_0x152f7c,providerData:_0xe3ed76,stsTokenManager:_0x1cfaf9}=_0x539069;m(_0x4738f1&&_0x1cfaf9,_0x539970,'internal-error');const _0x4c1e21=et['fromJSON'](this['name'],_0x1cfaf9);m(typeof _0x4738f1=='string',_0x539970,'internal-error'),le(_0x366a91,_0x539970['name']),le(_0x26bb00,_0x539970['name']),m(typeof _0x30c4b0=='boolean',_0x539970,'internal-error'),m(typeof _0x152f7c=='boolean',_0x539970,'internal-error'),le(_0x3962b0,_0x539970['name']),le(_0x1d06f8,_0x539970['name']),le(_0x517902,_0x539970['name']),le(_0x1b51a1,_0x539970['name']),le(_0x408d18,_0x539970['name']),le(_0x5bd730,_0x539970['name']);const _0x1b6e3d=new j({'uid':_0x4738f1,'auth':_0x539970,'email':_0x26bb00,'emailVerified':_0x30c4b0,'displayName':_0x366a91,'isAnonymous':_0x152f7c,'photoURL':_0x1d06f8,'phoneNumber':_0x3962b0,'tenantId':_0x517902,'stsTokenManager':_0x4c1e21,'createdAt':_0x408d18,'lastLoginAt':_0x5bd730});return _0xe3ed76&&Array['isArray'](_0xe3ed76)&&(_0x1b6e3d['providerData']=_0xe3ed76['map'](_0x4e1ab9=>({..._0x4e1ab9}))),_0x1b51a1&&(_0x1b6e3d['_redirectEventId']=_0x1b51a1),_0x1b6e3d;}static async['_fromIdTokenResponse'](_0x2ef5fb,_0x2acab4,_0x1d40b9=!0x1){const _0x3bea6f=new et();_0x3bea6f['updateFromServerResponse'](_0x2acab4);const _0x3a11fe=new j({'uid':_0x2acab4['localId'],'auth':_0x2ef5fb,'stsTokenManager':_0x3bea6f,'isAnonymous':_0x1d40b9});return await Nn(_0x3a11fe),_0x3a11fe;}static async['_fromGetAccountInfoResponse'](_0x53ca35,_0x440a1a,_0x4b59dc){const _0x5f4028=_0x440a1a['users'][0x0];m(_0x5f4028['localId']!==void 0x0,'internal-error');const _0x177013=_0x5f4028['providerUserInfo']!==void 0x0?Sa(_0x5f4028['providerUserInfo']):[],_0x3ff202=!(_0x5f4028['email']&&_0x5f4028['passwordHash'])&&!(_0x177013!=null&&_0x177013['length']),_0x36a544=new et();_0x36a544['updateFromIdToken'](_0x4b59dc);const _0x21e543=new j({'uid':_0x5f4028['localId'],'auth':_0x53ca35,'stsTokenManager':_0x36a544,'isAnonymous':_0x3ff202}),_0x3eda22={'uid':_0x5f4028['localId'],'displayName':_0x5f4028['displayName']||null,'photoURL':_0x5f4028['photoUrl']||null,'email':_0x5f4028['email']||null,'emailVerified':_0x5f4028['emailVerified']||!0x1,'phoneNumber':_0x5f4028['phoneNumber']||null,'tenantId':_0x5f4028['tenantId']||null,'providerData':_0x177013,'metadata':new Li(_0x5f4028['createdAt'],_0x5f4028['lastLoginAt']),'isAnonymous':!(_0x5f4028['email']&&_0x5f4028['passwordHash'])&&!(_0x177013!=null&&_0x177013['length'])};return Object['assign'](_0x21e543,_0x3eda22),_0x21e543;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x46cd68){ce(_0x46cd68 instanceof Function,'Expected\x20a\x20class\x20definition');let _0xdb7ba9=Tr['get'](_0x46cd68);return _0xdb7ba9?(ce(_0xdb7ba9 instanceof _0x46cd68,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0xdb7ba9):(_0xdb7ba9=new _0x46cd68(),Tr['set'](_0x46cd68,_0xdb7ba9),_0xdb7ba9);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x2123d4,_0x498d17){this['storage'][_0x2123d4]=_0x498d17;}async['_get'](_0x2f630c){const _0xb46e64=this['storage'][_0x2f630c];return _0xb46e64===void 0x0?null:_0xb46e64;}async['_remove'](_0x274bc2){delete this['storage'][_0x274bc2];}['_addListener'](_0x5eee60,_0x5ac564){}['_removeListener'](_0x502d19,_0x42e2dd){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x157e17,_0x9c42df,_0x2ee3e3){return'firebase:'+_0x157e17+':'+_0x9c42df+':'+_0x2ee3e3;}class tt{constructor(_0x5cee3a,_0x2aaab5,_0x10b230){this['persistence']=_0x5cee3a,this['auth']=_0x2aaab5,this['userKey']=_0x10b230;const {config:_0x548e9c,name:_0x19540f}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x548e9c['apiKey'],_0x19540f),this['fullPersistenceKey']=ln('persistence',_0x548e9c['apiKey'],_0x19540f),this['boundEventHandler']=_0x2aaab5['_onStorageEvent']['bind'](_0x2aaab5),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x52d0f1){return this['persistence']['_set'](this['fullUserKey'],_0x52d0f1['toJSON']());}async['getCurrentUser'](){const _0x426718=await this['persistence']['_get'](this['fullUserKey']);if(!_0x426718)return null;if(typeof _0x426718=='string'){const _0x25559e=await Pn(this['auth'],{'idToken':_0x426718})['catch'](()=>{});return _0x25559e?j['_fromGetAccountInfoResponse'](this['auth'],_0x25559e,_0x426718):null;}return j['_fromJSON'](this['auth'],_0x426718);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x256d33){if(this['persistence']===_0x256d33)return;const _0x73f4b5=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x256d33,_0x73f4b5)return this['setCurrentUser'](_0x73f4b5);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0xc0949a,_0x17ff30,_0x287af1='authUser'){if(!_0x17ff30['length'])return new tt(ie(Sr),_0xc0949a,_0x287af1);const _0x277144=(await Promise['all'](_0x17ff30['map'](async _0x2e8f82=>{if(await _0x2e8f82['_isAvailable']())return _0x2e8f82;})))['filter'](_0x1bb240=>_0x1bb240);let _0x39897f=_0x277144[0x0]||ie(Sr);const _0x5d4df1=ln(_0x287af1,_0xc0949a['config']['apiKey'],_0xc0949a['name']);let _0x162ce3=null;for(const _0x50f392 of _0x17ff30)try{const _0x5a0db0=await _0x50f392['_get'](_0x5d4df1);if(_0x5a0db0){let _0x260c35;if(typeof _0x5a0db0=='string'){const _0x43eaf3=await Pn(_0xc0949a,{'idToken':_0x5a0db0})['catch'](()=>{});if(!_0x43eaf3)break;_0x260c35=await j['_fromGetAccountInfoResponse'](_0xc0949a,_0x43eaf3,_0x5a0db0);}else _0x260c35=j['_fromJSON'](_0xc0949a,_0x5a0db0);_0x50f392!==_0x39897f&&(_0x162ce3=_0x260c35),_0x39897f=_0x50f392;break;}}catch{}const _0x41b80c=_0x277144['filter'](_0x1b5280=>_0x1b5280['_shouldAllowMigration']);return!_0x39897f['_shouldAllowMigration']||!_0x41b80c['length']?new tt(_0x39897f,_0xc0949a,_0x287af1):(_0x39897f=_0x41b80c[0x0],_0x162ce3&&await _0x39897f['_set'](_0x5d4df1,_0x162ce3['toJSON']()),await Promise['all'](_0x17ff30['map'](async _0x14558b=>{if(_0x14558b!==_0x39897f)try{await _0x14558b['_remove'](_0x5d4df1);}catch{}})),new tt(_0x39897f,_0xc0949a,_0x287af1));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x370493){const _0x2a70e0=_0x370493['toLowerCase']();if(_0x2a70e0['includes']('opera/')||_0x2a70e0['includes']('opr/')||_0x2a70e0['includes']('opios/'))return'Opera';if(Pa(_0x2a70e0))return'IEMobile';if(_0x2a70e0['includes']('msie')||_0x2a70e0['includes']('trident/'))return'IE';if(_0x2a70e0['includes']('edge/'))return'Edge';if(Ra(_0x2a70e0))return'Firefox';if(_0x2a70e0['includes']('silk/'))return'Silk';if(Oa(_0x2a70e0))return'Blackberry';if(Da(_0x2a70e0))return'Webos';if(Aa(_0x2a70e0))return'Safari';if((_0x2a70e0['includes']('chrome/')||ka(_0x2a70e0))&&!_0x2a70e0['includes']('edge/'))return'Chrome';if(Na(_0x2a70e0))return'Android';{const _0x55577e=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x5eeb96=_0x370493['match'](_0x55577e);if((_0x5eeb96==null?void 0x0:_0x5eeb96['length'])===0x2)return _0x5eeb96[0x1];}return'Other';}function Ra(_0x39a386=W()){return/firefox\//i['test'](_0x39a386);}function Aa(_0x1d8be8=W()){const _0x5c1665=_0x1d8be8['toLowerCase']();return _0x5c1665['includes']('safari/')&&!_0x5c1665['includes']('chrome/')&&!_0x5c1665['includes']('crios/')&&!_0x5c1665['includes']('android');}function ka(_0x34ecfe=W()){return/crios\//i['test'](_0x34ecfe);}function Pa(_0x29ad3d=W()){return/iemobile/i['test'](_0x29ad3d);}function Na(_0x50a20d=W()){return/android/i['test'](_0x50a20d);}function Oa(_0x43adf1=W()){return/blackberry/i['test'](_0x43adf1);}function Da(_0x1fb373=W()){return/webos/i['test'](_0x1fb373);}function Ss(_0x37c6f7=W()){return/iphone|ipad|ipod/i['test'](_0x37c6f7)||/macintosh/i['test'](_0x37c6f7)&&/mobile/i['test'](_0x37c6f7);}function Rf(_0x2a34da=W()){var _0x1c6a22;return Ss(_0x2a34da)&&!!((_0x1c6a22=window['navigator'])!=null&&_0x1c6a22['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x300875=W()){return Ss(_0x300875)||Na(_0x300875)||Da(_0x300875)||Oa(_0x300875)||/windows phone/i['test'](_0x300875)||Pa(_0x300875);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x2ae4f7,_0x42cff0=[]){let _0x367f10;switch(_0x2ae4f7){case'Browser':_0x367f10=br(W());break;case'Worker':_0x367f10=br(W())+'-'+_0x2ae4f7;break;default:_0x367f10=_0x2ae4f7;}const _0x58f5a7=_0x42cff0['length']?_0x42cff0['join'](','):'FirebaseCore-web';return _0x367f10+'/JsCore/'+dt+'/'+_0x58f5a7;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x3fefc4){this['auth']=_0x3fefc4,this['queue']=[];}['pushCallback'](_0x77cf13,_0x30828d){const _0x5c70d4=_0x513020=>new Promise((_0x481947,_0x5e3430)=>{try{const _0x585831=_0x77cf13(_0x513020);_0x481947(_0x585831);}catch(_0x46f81c){_0x5e3430(_0x46f81c);}});_0x5c70d4['onAbort']=_0x30828d,this['queue']['push'](_0x5c70d4);const _0x392e31=this['queue']['length']-0x1;return()=>{this['queue'][_0x392e31]=()=>Promise['resolve']();};}async['runMiddleware'](_0x2ba6d1){if(this['auth']['currentUser']===_0x2ba6d1)return;const _0x29b1ec=[];try{for(const _0x557b89 of this['queue'])await _0x557b89(_0x2ba6d1),_0x557b89['onAbort']&&_0x29b1ec['push'](_0x557b89['onAbort']);}catch(_0x1bf4db){_0x29b1ec['reverse']();for(const _0x2ed9f7 of _0x29b1ec)try{_0x2ed9f7();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x1bf4db==null?void 0x0:_0x1bf4db['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x5a2833,_0xe828ec={}){return Pe(_0x5a2833,'GET','/v2/passwordPolicy',ke(_0x5a2833,_0xe828ec));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0xab5f95){var _0xb7d6b5;const _0xcfeb38=_0xab5f95['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0xcfeb38['minPasswordLength']??Nf,_0xcfeb38['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0xcfeb38['maxPasswordLength']),_0xcfeb38['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0xcfeb38['containsLowercaseCharacter']),_0xcfeb38['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0xcfeb38['containsUppercaseCharacter']),_0xcfeb38['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0xcfeb38['containsNumericCharacter']),_0xcfeb38['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0xcfeb38['containsNonAlphanumericCharacter']),this['enforcementState']=_0xab5f95['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0xb7d6b5=_0xab5f95['allowedNonAlphanumericCharacters'])==null?void 0x0:_0xb7d6b5['join'](''))??'',this['forceUpgradeOnSignin']=_0xab5f95['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0xab5f95['schemaVersion'];}['validatePassword'](_0x34bfab){const _0x3000b4={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x34bfab,_0x3000b4),this['validatePasswordCharacterOptions'](_0x34bfab,_0x3000b4),_0x3000b4['isValid']&&(_0x3000b4['isValid']=_0x3000b4['meetsMinPasswordLength']??!0x0),_0x3000b4['isValid']&&(_0x3000b4['isValid']=_0x3000b4['meetsMaxPasswordLength']??!0x0),_0x3000b4['isValid']&&(_0x3000b4['isValid']=_0x3000b4['containsLowercaseLetter']??!0x0),_0x3000b4['isValid']&&(_0x3000b4['isValid']=_0x3000b4['containsUppercaseLetter']??!0x0),_0x3000b4['isValid']&&(_0x3000b4['isValid']=_0x3000b4['containsNumericCharacter']??!0x0),_0x3000b4['isValid']&&(_0x3000b4['isValid']=_0x3000b4['containsNonAlphanumericCharacter']??!0x0),_0x3000b4;}['validatePasswordLengthOptions'](_0xc0aac,_0x200c68){const _0x365292=this['customStrengthOptions']['minPasswordLength'],_0x5597f6=this['customStrengthOptions']['maxPasswordLength'];_0x365292&&(_0x200c68['meetsMinPasswordLength']=_0xc0aac['length']>=_0x365292),_0x5597f6&&(_0x200c68['meetsMaxPasswordLength']=_0xc0aac['length']<=_0x5597f6);}['validatePasswordCharacterOptions'](_0xeaf38a,_0x5e188d){this['updatePasswordCharacterOptionsStatuses'](_0x5e188d,!0x1,!0x1,!0x1,!0x1);let _0x5d72f4;for(let _0x2675f3=0x0;_0x2675f3<_0xeaf38a['length'];_0x2675f3++)_0x5d72f4=_0xeaf38a['charAt'](_0x2675f3),this['updatePasswordCharacterOptionsStatuses'](_0x5e188d,_0x5d72f4>='a'&&_0x5d72f4<='z',_0x5d72f4>='A'&&_0x5d72f4<='Z',_0x5d72f4>='0'&&_0x5d72f4<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x5d72f4));}['updatePasswordCharacterOptionsStatuses'](_0x5b0f78,_0x500a98,_0x3caff3,_0x5e4012,_0x1209fe){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x5b0f78['containsLowercaseLetter']||(_0x5b0f78['containsLowercaseLetter']=_0x500a98)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x5b0f78['containsUppercaseLetter']||(_0x5b0f78['containsUppercaseLetter']=_0x3caff3)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x5b0f78['containsNumericCharacter']||(_0x5b0f78['containsNumericCharacter']=_0x5e4012)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x5b0f78['containsNonAlphanumericCharacter']||(_0x5b0f78['containsNonAlphanumericCharacter']=_0x1209fe));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x10a17a,_0x2b8a1b,_0x36d0cd,_0x3735f3){this['app']=_0x10a17a,this['heartbeatServiceProvider']=_0x2b8a1b,this['appCheckServiceProvider']=_0x36d0cd,this['config']=_0x3735f3,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x10a17a['name'],this['clientVersion']=_0x3735f3['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0xf35450=>this['_resolvePersistenceManagerAvailable']=_0xf35450);}['_initializeWithPersistence'](_0x61b7b6,_0xc4dfee){return _0xc4dfee&&(this['_popupRedirectResolver']=ie(_0xc4dfee)),this['_initializationPromise']=this['queue'](async()=>{var _0x572ab8,_0x1818a4,_0x3ef49d;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x61b7b6),(_0x572ab8=this['_resolvePersistenceManagerAvailable'])==null||_0x572ab8['call'](this),!this['_deleted'])){if((_0x1818a4=this['_popupRedirectResolver'])!=null&&_0x1818a4['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0xc4dfee),this['lastNotifiedUid']=((_0x3ef49d=this['currentUser'])==null?void 0x0:_0x3ef49d['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0xa9a432=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0xa9a432)){if(this['currentUser']&&_0xa9a432&&this['currentUser']['uid']===_0xa9a432['uid']){this['_currentUser']['_assign'](_0xa9a432),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0xa9a432,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x1c65ec){try{const _0x5966a6=await Pn(this,{'idToken':_0x1c65ec}),_0x5bf5a1=await j['_fromGetAccountInfoResponse'](this,_0x5966a6,_0x1c65ec);await this['directlySetCurrentUser'](_0x5bf5a1);}catch(_0x4af01c){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x4af01c),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x57d9bc){var _0x31dbc9;if($(this['app'])){const _0x13f802=this['app']['settings']['authIdToken'];return _0x13f802?new Promise(_0x5e0219=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x13f802)['then'](_0x5e0219,_0x5e0219));}):this['directlySetCurrentUser'](null);}const _0x2a7d54=await this['assertedPersistence']['getCurrentUser']();let _0x2e4ff3=_0x2a7d54,_0x2dc65a=!0x1;if(_0x57d9bc&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x3e5fe8=(_0x31dbc9=this['redirectUser'])==null?void 0x0:_0x31dbc9['_redirectEventId'],_0x2769a9=_0x2e4ff3==null?void 0x0:_0x2e4ff3['_redirectEventId'],_0x3ac74e=await this['tryRedirectSignIn'](_0x57d9bc);(!_0x3e5fe8||_0x3e5fe8===_0x2769a9)&&(_0x3ac74e!=null&&_0x3ac74e['user'])&&(_0x2e4ff3=_0x3ac74e['user'],_0x2dc65a=!0x0);}if(!_0x2e4ff3)return this['directlySetCurrentUser'](null);if(!_0x2e4ff3['_redirectEventId']){if(_0x2dc65a)try{await this['beforeStateQueue']['runMiddleware'](_0x2e4ff3);}catch(_0x25b4f7){_0x2e4ff3=_0x2a7d54,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x25b4f7));}return _0x2e4ff3?this['reloadAndSetCurrentUserOrClear'](_0x2e4ff3):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x2e4ff3['_redirectEventId']?this['directlySetCurrentUser'](_0x2e4ff3):this['reloadAndSetCurrentUserOrClear'](_0x2e4ff3);}async['tryRedirectSignIn'](_0x5db18b){let _0x3d64a6=null;try{_0x3d64a6=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x5db18b,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x3d64a6;}async['reloadAndSetCurrentUserOrClear'](_0x2ce900){try{await Nn(_0x2ce900);}catch(_0x28fbbf){if((_0x28fbbf==null?void 0x0:_0x28fbbf['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x2ce900);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x226f39){if($(this['app']))return Promise['reject'](re(this));const _0x469e4b=_0x226f39?P(_0x226f39):null;return _0x469e4b&&m(_0x469e4b['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x469e4b&&_0x469e4b['_clone'](this));}async['_updateCurrentUser'](_0x589b06,_0x5c9d4a=!0x1){if(!this['_deleted'])return _0x589b06&&m(this['tenantId']===_0x589b06['tenantId'],this,'tenant-id-mismatch'),_0x5c9d4a||await this['beforeStateQueue']['runMiddleware'](_0x589b06),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x589b06),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x40fe6c){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x40fe6c));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x4eaa6f){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x478b1f=this['_getPasswordPolicyInternal']();return _0x478b1f['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x478b1f['validatePassword'](_0x4eaa6f);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x17f0dd=await Pf(this),_0x185cb6=new Of(_0x17f0dd);this['tenantId']===null?this['_projectPasswordPolicy']=_0x185cb6:this['_tenantPasswordPolicies'][this['tenantId']]=_0x185cb6;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x2b2b63){this['_errorFactory']=new Gt('auth','Firebase',_0x2b2b63());}['onAuthStateChanged'](_0x34e394,_0x1ad5d6,_0x3c7749){return this['registerStateListener'](this['authStateSubscription'],_0x34e394,_0x1ad5d6,_0x3c7749);}['beforeAuthStateChanged'](_0x68b0a6,_0x1d91a9){return this['beforeStateQueue']['pushCallback'](_0x68b0a6,_0x1d91a9);}['onIdTokenChanged'](_0x5b7430,_0x5270b5,_0x556351){return this['registerStateListener'](this['idTokenSubscription'],_0x5b7430,_0x5270b5,_0x556351);}['authStateReady'](){return new Promise((_0x31acec,_0x34e1f4)=>{if(this['currentUser'])_0x31acec();else{const _0x4d9f02=this['onAuthStateChanged'](()=>{_0x4d9f02(),_0x31acec();},_0x34e1f4);}});}async['revokeAccessToken'](_0x25bc29){if(this['currentUser']){const _0x352dbc=await this['currentUser']['getIdToken'](),_0x4c903f={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x25bc29,'idToken':_0x352dbc};this['tenantId']!=null&&(_0x4c903f['tenantId']=this['tenantId']),await bf(this,_0x4c903f);}}['toJSON'](){var _0x465bf7;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x465bf7=this['_currentUser'])==null?void 0x0:_0x465bf7['toJSON']()};}async['_setRedirectUser'](_0x46cc60,_0x56bf37){const _0xc293f1=await this['getOrInitRedirectPersistenceManager'](_0x56bf37);return _0x46cc60===null?_0xc293f1['removeCurrentUser']():_0xc293f1['setCurrentUser'](_0x46cc60);}async['getOrInitRedirectPersistenceManager'](_0x22babc){if(!this['redirectPersistenceManager']){const _0x484559=_0x22babc&&ie(_0x22babc)||this['_popupRedirectResolver'];m(_0x484559,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x484559['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x198453){var _0x4a46eb,_0x156b44;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x4a46eb=this['_currentUser'])==null?void 0x0:_0x4a46eb['_redirectEventId'])===_0x198453?this['_currentUser']:((_0x156b44=this['redirectUser'])==null?void 0x0:_0x156b44['_redirectEventId'])===_0x198453?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x2779dc){if(_0x2779dc===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x2779dc));}['_notifyListenersIfCurrent'](_0x16eea4){_0x16eea4===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0xb45318;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x3e817b=((_0xb45318=this['currentUser'])==null?void 0x0:_0xb45318['uid'])??null;this['lastNotifiedUid']!==_0x3e817b&&(this['lastNotifiedUid']=_0x3e817b,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x3b16d9,_0x42bb85,_0xef0047,_0x271ffa){if(this['_deleted'])return()=>{};const _0x2ca481=typeof _0x42bb85=='function'?_0x42bb85:_0x42bb85['next']['bind'](_0x42bb85);let _0x31b6be=!0x1;const _0x13c818=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x13c818,this,'internal-error'),_0x13c818['then'](()=>{_0x31b6be||_0x2ca481(this['currentUser']);}),typeof _0x42bb85=='function'){const _0x5a3133=_0x3b16d9['addObserver'](_0x42bb85,_0xef0047,_0x271ffa);return()=>{_0x31b6be=!0x0,_0x5a3133();};}else{const _0x52e4d3=_0x3b16d9['addObserver'](_0x42bb85);return()=>{_0x31b6be=!0x0,_0x52e4d3();};}}async['directlySetCurrentUser'](_0x50e2cf){this['currentUser']&&this['currentUser']!==_0x50e2cf&&this['_currentUser']['_stopProactiveRefresh'](),_0x50e2cf&&this['isProactiveRefreshEnabled']&&_0x50e2cf['_startProactiveRefresh'](),this['currentUser']=_0x50e2cf,_0x50e2cf?await this['assertedPersistence']['setCurrentUser'](_0x50e2cf):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x1ef53f){return this['operations']=this['operations']['then'](_0x1ef53f,_0x1ef53f),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x348322){!_0x348322||this['frameworks']['includes'](_0x348322)||(this['frameworks']['push'](_0x348322),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0xa4d47d;const _0x26aab2={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x26aab2['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x297d05=await((_0xa4d47d=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0xa4d47d['getHeartbeatsHeader']());_0x297d05&&(_0x26aab2['X-Firebase-Client']=_0x297d05);const _0x51a9e7=await this['_getAppCheckToken']();return _0x51a9e7&&(_0x26aab2['X-Firebase-AppCheck']=_0x51a9e7),_0x26aab2;}async['_getAppCheckToken'](){var _0x514420;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x396720=await((_0x514420=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x514420['getToken']());return _0x396720!=null&&_0x396720['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x396720['error']),_0x396720==null?void 0x0:_0x396720['token'];}}function Ke(_0x170668){return P(_0x170668);}class Rr{constructor(_0x598ff3){this['auth']=_0x598ff3,this['observer']=null,this['addObserver']=Tc(_0x466a0d=>this['observer']=_0x466a0d);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x420a0f){Jn=_0x420a0f;}function xa(_0x103476){return Jn['loadJS'](_0x103476);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x3c573b){return'__'+_0x3c573b+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0xfa674){_0xfa674();}['execute'](_0x521258,_0x3db47a){return Promise['resolve']('token');}['render'](_0x1ab93c,_0x4bf4c7){return'';}}class Wf{['ready'](_0xe3e29c){_0xe3e29c();}['execute'](_0x5f352a,_0x478f38){return Promise['resolve']('token');}['render'](_0xc6283b,_0x3d78ac){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x29e191){this['type']=Bf,this['auth']=Ke(_0x29e191);}async['verify'](_0x4505b1='verify',_0x195517=!0x1){async function _0x2a7ac6(_0x4b5ad9){if(!_0x195517){if(_0x4b5ad9['tenantId']==null&&_0x4b5ad9['_agentRecaptchaConfig']!=null)return _0x4b5ad9['_agentRecaptchaConfig']['siteKey'];if(_0x4b5ad9['tenantId']!=null&&_0x4b5ad9['_tenantRecaptchaConfigs'][_0x4b5ad9['tenantId']]!==void 0x0)return _0x4b5ad9['_tenantRecaptchaConfigs'][_0x4b5ad9['tenantId']]['siteKey'];}return new Promise(async(_0x5895da,_0x1da9dc)=>{yf(_0x4b5ad9,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x22bc5e=>{if(_0x22bc5e['recaptchaKey']===void 0x0)_0x1da9dc(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x33da9a=new mf(_0x22bc5e);return _0x4b5ad9['tenantId']==null?_0x4b5ad9['_agentRecaptchaConfig']=_0x33da9a:_0x4b5ad9['_tenantRecaptchaConfigs'][_0x4b5ad9['tenantId']]=_0x33da9a,_0x5895da(_0x33da9a['siteKey']);}})['catch'](_0x1faff5=>{_0x1da9dc(_0x1faff5);});});}function _0x37cbdc(_0x28d5da,_0x19081c,_0x227d36){const _0x3e5bb6=window['grecaptcha'];wr(_0x3e5bb6)?_0x3e5bb6['enterprise']['ready'](()=>{_0x3e5bb6['enterprise']['execute'](_0x28d5da,{'action':_0x4505b1})['then'](_0x20105c=>{_0x19081c(_0x20105c);})['catch'](()=>{_0x19081c(Fa);});}):_0x227d36(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x5df68b,_0x34358b)=>{_0x2a7ac6(this['auth'])['then'](async _0x67c7b4=>{if(!_0x195517&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x37cbdc(_0x67c7b4,_0x5df68b,_0x34358b);else{if(typeof window>'u'){_0x34358b(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x8d2472=Lf();_0x8d2472['length']!==0x0&&(_0x8d2472+=_0x67c7b4+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x572924;(_0x572924=he['scriptInjectionDeferred'])==null||_0x572924['resolve']();},xa(_0x8d2472)['then'](()=>{var _0x5a77d6;return(_0x5a77d6=he['scriptInjectionDeferred'])==null?void 0x0:_0x5a77d6['promise'];})['then'](()=>{_0x37cbdc(_0x67c7b4,_0x5df68b,_0x34358b);})['catch'](_0x214ccb=>{_0x34358b(_0x214ccb);});}})['catch'](_0x36e4ce=>{_0x34358b(_0x36e4ce);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x2c1577,_0x598fcb,_0x18dab0,_0x4f763d=!0x1,_0x509ca9=!0x1){const _0x144f5a=new he(_0x2c1577);let _0x5e1726;if(_0x509ca9)_0x5e1726=Fa;else try{_0x5e1726=await _0x144f5a['verify'](_0x18dab0);}catch{_0x5e1726=await _0x144f5a['verify'](_0x18dab0,!0x0);}const _0x2c6da8={..._0x598fcb};if(_0x18dab0==='mfaSmsEnrollment'||_0x18dab0==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x2c6da8){const _0x4b75e4=_0x2c6da8['phoneEnrollmentInfo']['phoneNumber'],_0x4a3cc5=_0x2c6da8['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x2c6da8,{'phoneEnrollmentInfo':{'phoneNumber':_0x4b75e4,'recaptchaToken':_0x4a3cc5,'captchaResponse':_0x5e1726,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x2c6da8){const _0x419899=_0x2c6da8['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x2c6da8,{'phoneSignInInfo':{'recaptchaToken':_0x419899,'captchaResponse':_0x5e1726,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x2c6da8;}return _0x4f763d?Object['assign'](_0x2c6da8,{'captchaResp':_0x5e1726}):Object['assign'](_0x2c6da8,{'captchaResponse':_0x5e1726}),Object['assign'](_0x2c6da8,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x2c6da8,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x2c6da8;}async function xi(_0x122b05,_0xb3fac9,_0xad05a1,_0x59e4b0,_0x813a6b){var _0x1221de;if((_0x1221de=_0x122b05['_getRecaptchaConfig']())!=null&&_0x1221de['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x3cf5ee=await kr(_0x122b05,_0xb3fac9,_0xad05a1,_0xad05a1==='getOobCode');return _0x59e4b0(_0x122b05,_0x3cf5ee);}else return _0x59e4b0(_0x122b05,_0xb3fac9)['catch'](async _0x5b5de2=>{if(_0x5b5de2['code']==='auth/missing-recaptcha-token'){console['log'](_0xad05a1+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x55aac2=await kr(_0x122b05,_0xb3fac9,_0xad05a1,_0xad05a1==='getOobCode');return _0x59e4b0(_0x122b05,_0x55aac2);}else return Promise['reject'](_0x5b5de2);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x5760e5,_0x11d5d2){const _0x189199=Hi(_0x5760e5,'auth');if(_0x189199['isInitialized']()){const _0x9fd5a=_0x189199['getImmediate'](),_0x1f2226=_0x189199['getOptions']();if(xe(_0x1f2226,_0x11d5d2??{}))return _0x9fd5a;Y(_0x9fd5a,'already-initialized');}return _0x189199['initialize']({'options':_0x11d5d2});}function Hf(_0x4941a7,_0x2b008a){const _0x2c2b3d=(_0x2b008a==null?void 0x0:_0x2b008a['persistence'])||[],_0x124b93=(Array['isArray'](_0x2c2b3d)?_0x2c2b3d:[_0x2c2b3d])['map'](ie);_0x2b008a!=null&&_0x2b008a['errorMap']&&_0x4941a7['_updateErrorMap'](_0x2b008a['errorMap']),_0x4941a7['_initializeWithPersistence'](_0x124b93,_0x2b008a==null?void 0x0:_0x2b008a['popupRedirectResolver']);}function $f(_0x3dda6e,_0x2ee0fd,_0x3b6f9f){const _0x4fc1e5=Ke(_0x3dda6e);m(/^https?:\/\//['test'](_0x2ee0fd),_0x4fc1e5,'invalid-emulator-scheme');const _0x204264=!0x1,_0x57ef71=Ua(_0x2ee0fd),{host:_0x52922,port:_0xd0ec24}=Gf(_0x2ee0fd),_0x47d526=_0xd0ec24===null?'':':'+_0xd0ec24,_0x18dcd2={'url':_0x57ef71+'//'+_0x52922+_0x47d526+'/'},_0x22eccc=Object['freeze']({'host':_0x52922,'port':_0xd0ec24,'protocol':_0x57ef71['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x204264})});if(!_0x4fc1e5['_canInitEmulator']){m(_0x4fc1e5['config']['emulator']&&_0x4fc1e5['emulatorConfig'],_0x4fc1e5,'emulator-config-failed'),m(xe(_0x18dcd2,_0x4fc1e5['config']['emulator'])&&xe(_0x22eccc,_0x4fc1e5['emulatorConfig']),_0x4fc1e5,'emulator-config-failed');return;}_0x4fc1e5['config']['emulator']=_0x18dcd2,_0x4fc1e5['emulatorConfig']=_0x22eccc,_0x4fc1e5['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x52922)?Qr(_0x57ef71+'//'+_0x52922+_0x47d526):qf();}function Ua(_0x319d40){const _0x2e6d7a=_0x319d40['indexOf'](':');return _0x2e6d7a<0x0?'':_0x319d40['substr'](0x0,_0x2e6d7a+0x1);}function Gf(_0x8e7ffc){const _0x370850=Ua(_0x8e7ffc),_0x2ddaa4=/(\/\/)?([^?#/]+)/['exec'](_0x8e7ffc['substr'](_0x370850['length']));if(!_0x2ddaa4)return{'host':'','port':null};const _0x1f1217=_0x2ddaa4[0x2]['split']('@')['pop']()||'',_0x13b970=/^(\[[^\]]+\])(:|$)/['exec'](_0x1f1217);if(_0x13b970){const _0x324e3f=_0x13b970[0x1];return{'host':_0x324e3f,'port':Pr(_0x1f1217['substr'](_0x324e3f['length']+0x1))};}else{const [_0x279229,_0xc76cad]=_0x1f1217['split'](':');return{'host':_0x279229,'port':Pr(_0xc76cad)};}}function Pr(_0x1f71b6){if(!_0x1f71b6)return null;const _0x3ccfea=Number(_0x1f71b6);return isNaN(_0x3ccfea)?null:_0x3ccfea;}function qf(){function _0xf4876e(){const _0x17972c=document['createElement']('p'),_0x2a9cd2=_0x17972c['style'];_0x17972c['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x2a9cd2['position']='fixed',_0x2a9cd2['width']='100%',_0x2a9cd2['backgroundColor']='#ffffff',_0x2a9cd2['border']='.1em\x20solid\x20#000000',_0x2a9cd2['color']='#b50000',_0x2a9cd2['bottom']='0px',_0x2a9cd2['left']='0px',_0x2a9cd2['margin']='0px',_0x2a9cd2['zIndex']='10000',_0x2a9cd2['textAlign']='center',_0x17972c['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x17972c);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0xf4876e):_0xf4876e());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x421445,_0x342551){this['providerId']=_0x421445,this['signInMethod']=_0x342551;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x4538f5){return ne('not\x20implemented');}['_linkToIdToken'](_0xd8e6dc,_0x347552){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0xb9f2c0){return ne('not\x20implemented');}}async function zf(_0x123c0f,_0x52bb2b){return Pe(_0x123c0f,'POST','/v1/accounts:signUp',_0x52bb2b);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x347afb,_0x56b561){return en(_0x347afb,'POST','/v1/accounts:signInWithPassword',ke(_0x347afb,_0x56b561));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x322023,_0x292f72){return en(_0x322023,'POST','/v1/accounts:signInWithEmailLink',ke(_0x322023,_0x292f72));}async function Yf(_0x892154,_0x207749){return en(_0x892154,'POST','/v1/accounts:signInWithEmailLink',ke(_0x892154,_0x207749));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x3efc91,_0x2cfec6,_0x52a6f4,_0x6a964a=null){super('password',_0x52a6f4),this['_email']=_0x3efc91,this['_password']=_0x2cfec6,this['_tenantId']=_0x6a964a;}static['_fromEmailAndPassword'](_0x23d9e2,_0x4a9ee4){return new $t(_0x23d9e2,_0x4a9ee4,'password');}static['_fromEmailAndCode'](_0x1c4575,_0x6ea901,_0x32f140=null){return new $t(_0x1c4575,_0x6ea901,'emailLink',_0x32f140);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x17ead9){const _0x26befe=typeof _0x17ead9=='string'?JSON['parse'](_0x17ead9):_0x17ead9;if(_0x26befe!=null&&_0x26befe['email']&&(_0x26befe!=null&&_0x26befe['password'])){if(_0x26befe['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x26befe['email'],_0x26befe['password']);if(_0x26befe['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x26befe['email'],_0x26befe['password'],_0x26befe['tenantId']);}return null;}async['_getIdTokenResponse'](_0x480538){switch(this['signInMethod']){case'password':const _0x228ce5={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x480538,_0x228ce5,'signInWithPassword',jf);case'emailLink':return Kf(_0x480538,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x480538,'internal-error');}}async['_linkToIdToken'](_0x193b24,_0xdd9196){switch(this['signInMethod']){case'password':const _0x2be8f0={'idToken':_0xdd9196,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x193b24,_0x2be8f0,'signUpPassword',zf);case'emailLink':return Yf(_0x193b24,{'idToken':_0xdd9196,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x193b24,'internal-error');}}['_getReauthenticationResolver'](_0x13c80e){return this['_getIdTokenResponse'](_0x13c80e);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x2f61d8,_0x265912){return en(_0x2f61d8,'POST','/v1/accounts:signInWithIdp',ke(_0x2f61d8,_0x265912));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x36740b){const _0x3b5dc9=new $e(_0x36740b['providerId'],_0x36740b['signInMethod']);return _0x36740b['idToken']||_0x36740b['accessToken']?(_0x36740b['idToken']&&(_0x3b5dc9['idToken']=_0x36740b['idToken']),_0x36740b['accessToken']&&(_0x3b5dc9['accessToken']=_0x36740b['accessToken']),_0x36740b['nonce']&&!_0x36740b['pendingToken']&&(_0x3b5dc9['nonce']=_0x36740b['nonce']),_0x36740b['pendingToken']&&(_0x3b5dc9['pendingToken']=_0x36740b['pendingToken'])):_0x36740b['oauthToken']&&_0x36740b['oauthTokenSecret']?(_0x3b5dc9['accessToken']=_0x36740b['oauthToken'],_0x3b5dc9['secret']=_0x36740b['oauthTokenSecret']):Y('argument-error'),_0x3b5dc9;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x3a7bbe){const _0x5b4af6=typeof _0x3a7bbe=='string'?JSON['parse'](_0x3a7bbe):_0x3a7bbe,{providerId:_0xf3fc96,signInMethod:_0x59cf9d,..._0x2697ae}=_0x5b4af6;if(!_0xf3fc96||!_0x59cf9d)return null;const _0xc130d0=new $e(_0xf3fc96,_0x59cf9d);return _0xc130d0['idToken']=_0x2697ae['idToken']||void 0x0,_0xc130d0['accessToken']=_0x2697ae['accessToken']||void 0x0,_0xc130d0['secret']=_0x2697ae['secret'],_0xc130d0['nonce']=_0x2697ae['nonce'],_0xc130d0['pendingToken']=_0x2697ae['pendingToken']||null,_0xc130d0;}['_getIdTokenResponse'](_0x28b20c){const _0x59e954=this['buildRequest']();return nt(_0x28b20c,_0x59e954);}['_linkToIdToken'](_0x13331c,_0x1785eb){const _0x28c682=this['buildRequest']();return _0x28c682['idToken']=_0x1785eb,nt(_0x13331c,_0x28c682);}['_getReauthenticationResolver'](_0x23853c){const _0x282a5d=this['buildRequest']();return _0x282a5d['autoCreate']=!0x1,nt(_0x23853c,_0x282a5d);}['buildRequest'](){const _0x372335={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x372335['pendingToken']=this['pendingToken'];else{const _0x450e02={};this['idToken']&&(_0x450e02['id_token']=this['idToken']),this['accessToken']&&(_0x450e02['access_token']=this['accessToken']),this['secret']&&(_0x450e02['oauth_token_secret']=this['secret']),_0x450e02['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x450e02['nonce']=this['nonce']),_0x372335['postBody']=ut(_0x450e02);}return _0x372335;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0xd31a0c){switch(_0xd31a0c){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x44f2cb){const _0x18029d=Ct(Tt(_0x44f2cb))['link'],_0x46e5b5=_0x18029d?Ct(Tt(_0x18029d))['deep_link_id']:null,_0x2cab8f=Ct(Tt(_0x44f2cb))['deep_link_id'];return(_0x2cab8f?Ct(Tt(_0x2cab8f))['link']:null)||_0x2cab8f||_0x46e5b5||_0x18029d||_0x44f2cb;}class Rs{constructor(_0x4d4297){const _0x33caf5=Ct(Tt(_0x4d4297)),_0x2dab43=_0x33caf5['apiKey']??null,_0x28b594=_0x33caf5['oobCode']??null,_0x408078=Jf(_0x33caf5['mode']??null);m(_0x2dab43&&_0x28b594&&_0x408078,'argument-error'),this['apiKey']=_0x2dab43,this['operation']=_0x408078,this['code']=_0x28b594,this['continueUrl']=_0x33caf5['continueUrl']??null,this['languageCode']=_0x33caf5['lang']??null,this['tenantId']=_0x33caf5['tenantId']??null;}static['parseLink'](_0x5a866a){const _0x1d6f6c=Xf(_0x5a866a);try{return new Rs(_0x1d6f6c);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x12ff6a,_0x386a03){return $t['_fromEmailAndPassword'](_0x12ff6a,_0x386a03);}static['credentialWithLink'](_0x66f328,_0x1d8fc8){const _0x69c919=Rs['parseLink'](_0x1d8fc8);return m(_0x69c919,'argument-error'),$t['_fromEmailAndCode'](_0x66f328,_0x69c919['code'],_0x69c919['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x2bdcc0){this['providerId']=_0x2bdcc0,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x4aa91f){this['defaultLanguageCode']=_0x4aa91f;}['setCustomParameters'](_0x1fd2a2){return this['customParameters']=_0x1fd2a2,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0xdbcc84){return this['scopes']['includes'](_0xdbcc84)||this['scopes']['push'](_0xdbcc84),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x496066){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x496066});}static['credentialFromResult'](_0x1b0a5e){return ue['credentialFromTaggedObject'](_0x1b0a5e);}static['credentialFromError'](_0x776d2b){return ue['credentialFromTaggedObject'](_0x776d2b['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x118e47}){if(!_0x118e47||!('oauthAccessToken'in _0x118e47)||!_0x118e47['oauthAccessToken'])return null;try{return ue['credential'](_0x118e47['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x32c2c6,_0x525391){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x32c2c6,'accessToken':_0x525391});}static['credentialFromResult'](_0x4762c3){return de['credentialFromTaggedObject'](_0x4762c3);}static['credentialFromError'](_0x252fbb){return de['credentialFromTaggedObject'](_0x252fbb['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x2ce0b5}){if(!_0x2ce0b5)return null;const {oauthIdToken:_0x33cf75,oauthAccessToken:_0x404cb2}=_0x2ce0b5;if(!_0x33cf75&&!_0x404cb2)return null;try{return de['credential'](_0x33cf75,_0x404cb2);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x5e746f){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x5e746f});}static['credentialFromResult'](_0x102665){return fe['credentialFromTaggedObject'](_0x102665);}static['credentialFromError'](_0x2c73c3){return fe['credentialFromTaggedObject'](_0x2c73c3['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x22285d}){if(!_0x22285d||!('oauthAccessToken'in _0x22285d)||!_0x22285d['oauthAccessToken'])return null;try{return fe['credential'](_0x22285d['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x3dddba,_0x1a96f7){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x3dddba,'oauthTokenSecret':_0x1a96f7});}static['credentialFromResult'](_0x496ad1){return pe['credentialFromTaggedObject'](_0x496ad1);}static['credentialFromError'](_0x5bd7f6){return pe['credentialFromTaggedObject'](_0x5bd7f6['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x248bd6}){if(!_0x248bd6)return null;const {oauthAccessToken:_0x4445a1,oauthTokenSecret:_0x27c8e9}=_0x248bd6;if(!_0x4445a1||!_0x27c8e9)return null;try{return pe['credential'](_0x4445a1,_0x27c8e9);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x4d5b4d,_0x1c2e39){return en(_0x4d5b4d,'POST','/v1/accounts:signUp',ke(_0x4d5b4d,_0x1c2e39));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x496219){this['user']=_0x496219['user'],this['providerId']=_0x496219['providerId'],this['_tokenResponse']=_0x496219['_tokenResponse'],this['operationType']=_0x496219['operationType'];}static async['_fromIdTokenResponse'](_0x50e016,_0x34a397,_0x36c2d7,_0x345e9f=!0x1){const _0x1e78b4=await j['_fromIdTokenResponse'](_0x50e016,_0x36c2d7,_0x345e9f),_0x1028f6=Nr(_0x36c2d7);return new Ge({'user':_0x1e78b4,'providerId':_0x1028f6,'_tokenResponse':_0x36c2d7,'operationType':_0x34a397});}static async['_forOperation'](_0xce187b,_0x55e7da,_0x499b58){await _0xce187b['_updateTokensIfNecessary'](_0x499b58,!0x0);const _0x49f0b4=Nr(_0x499b58);return new Ge({'user':_0xce187b,'providerId':_0x49f0b4,'_tokenResponse':_0x499b58,'operationType':_0x55e7da});}}function Nr(_0x4dae18){return _0x4dae18['providerId']?_0x4dae18['providerId']:'phoneNumber'in _0x4dae18?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0xa50398,_0x5a946e,_0x115680,_0x82e542){super(_0x5a946e['code'],_0x5a946e['message']),this['operationType']=_0x115680,this['user']=_0x82e542,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0xa50398['name'],'tenantId':_0xa50398['tenantId']??void 0x0,'_serverResponse':_0x5a946e['customData']['_serverResponse'],'operationType':_0x115680};}static['_fromErrorAndOperation'](_0x196dc9,_0x4ddcb6,_0x4a9ec5,_0x56e2d4){return new On(_0x196dc9,_0x4ddcb6,_0x4a9ec5,_0x56e2d4);}}function Ba(_0x3d3571,_0x2d28fe,_0x457898,_0xf60016){return(_0x2d28fe==='reauthenticate'?_0x457898['_getReauthenticationResolver'](_0x3d3571):_0x457898['_getIdTokenResponse'](_0x3d3571))['catch'](_0x3e27fa=>{throw _0x3e27fa['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x3d3571,_0x3e27fa,_0x2d28fe,_0xf60016):_0x3e27fa;});}async function ep(_0x91441d,_0x319fd7,_0x59d9ff=!0x1){const _0xb3c3e5=await Ht(_0x91441d,_0x319fd7['_linkToIdToken'](_0x91441d['auth'],await _0x91441d['getIdToken']()),_0x59d9ff);return Ge['_forOperation'](_0x91441d,'link',_0xb3c3e5);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x4482f8,_0x44a9a0,_0x204786=!0x1){const {auth:_0xb43e1}=_0x4482f8;if($(_0xb43e1['app']))return Promise['reject'](re(_0xb43e1));const _0x5add2f='reauthenticate';try{const _0x436eee=await Ht(_0x4482f8,Ba(_0xb43e1,_0x5add2f,_0x44a9a0,_0x4482f8),_0x204786);m(_0x436eee['idToken'],_0xb43e1,'internal-error');const _0x390981=Ts(_0x436eee['idToken']);m(_0x390981,_0xb43e1,'internal-error');const {sub:_0x424da9}=_0x390981;return m(_0x4482f8['uid']===_0x424da9,_0xb43e1,'user-mismatch'),Ge['_forOperation'](_0x4482f8,_0x5add2f,_0x436eee);}catch(_0x2f66a3){throw(_0x2f66a3==null?void 0x0:_0x2f66a3['code'])==='auth/user-not-found'&&Y(_0xb43e1,'user-mismatch'),_0x2f66a3;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x8aa056,_0x438229,_0x4d977a=!0x1){if($(_0x8aa056['app']))return Promise['reject'](re(_0x8aa056));const _0x387d57='signIn',_0x1520a6=await Ba(_0x8aa056,_0x387d57,_0x438229),_0x12be11=await Ge['_fromIdTokenResponse'](_0x8aa056,_0x387d57,_0x1520a6);return _0x4d977a||await _0x8aa056['_updateCurrentUser'](_0x12be11['user']),_0x12be11;}async function np(_0xf965cb,_0x13bc9b){return Va(Ke(_0xf965cb),_0x13bc9b);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x25857a){const _0xf718cf=Ke(_0x25857a);_0xf718cf['_getPasswordPolicyInternal']()&&await _0xf718cf['_updatePasswordPolicy']();}async function L_(_0x26283b,_0x436bb8,_0x4472aa){if($(_0x26283b['app']))return Promise['reject'](re(_0x26283b));const _0x29e385=Ke(_0x26283b),_0x587a84=await xi(_0x29e385,{'returnSecureToken':!0x0,'email':_0x436bb8,'password':_0x4472aa,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x3b4b9d=>{throw _0x3b4b9d['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x26283b),_0x3b4b9d;}),_0xdaba6=await Ge['_fromIdTokenResponse'](_0x29e385,'signIn',_0x587a84);return await _0x29e385['_updateCurrentUser'](_0xdaba6['user']),_0xdaba6;}function x_(_0x40378d,_0x3fa8f8,_0x1906aa){return $(_0x40378d['app'])?Promise['reject'](re(_0x40378d)):np(P(_0x40378d),yt['credential'](_0x3fa8f8,_0x1906aa))['catch'](async _0x499c9d=>{throw _0x499c9d['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x40378d),_0x499c9d;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x403158,_0x425fac){return P(_0x403158)['setPersistence'](_0x425fac);}function ip(_0x2fd1ba,_0x5e2518,_0x329369,_0x463f5b){return P(_0x2fd1ba)['onIdTokenChanged'](_0x5e2518,_0x329369,_0x463f5b);}function sp(_0x3e4152,_0x12f68e,_0x387dde){return P(_0x3e4152)['beforeAuthStateChanged'](_0x12f68e,_0x387dde);}function U_(_0x38912b,_0xd54023,_0x1d897b,_0x4d5169){return P(_0x38912b)['onAuthStateChanged'](_0xd54023,_0x1d897b,_0x4d5169);}function W_(_0x212ee9){return P(_0x212ee9)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x2d3fb6,_0x4899de){this['storageRetriever']=_0x2d3fb6,this['type']=_0x4899de;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x589097,_0x1ec751){return this['storage']['setItem'](_0x589097,JSON['stringify'](_0x1ec751)),Promise['resolve']();}['_get'](_0x2c0026){const _0x5d61f6=this['storage']['getItem'](_0x2c0026);return Promise['resolve'](_0x5d61f6?JSON['parse'](_0x5d61f6):null);}['_remove'](_0x56b7c9){return this['storage']['removeItem'](_0x56b7c9),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0xe66588,_0x3f0459)=>this['onStorageEvent'](_0xe66588,_0x3f0459),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x21187a){for(const _0x18904c of Object['keys'](this['listeners'])){const _0x51330a=this['storage']['getItem'](_0x18904c),_0x5afc0e=this['localCache'][_0x18904c];_0x51330a!==_0x5afc0e&&_0x21187a(_0x18904c,_0x5afc0e,_0x51330a);}}['onStorageEvent'](_0x3f8453,_0x6c5b3c=!0x1){if(!_0x3f8453['key']){this['forAllChangedKeys']((_0xdad97d,_0x582bd4,_0x31f739)=>{this['notifyListeners'](_0xdad97d,_0x31f739);});return;}const _0x57e732=_0x3f8453['key'];_0x6c5b3c?this['detachListener']():this['stopPolling']();const _0x41ba25=()=>{const _0x53850d=this['storage']['getItem'](_0x57e732);!_0x6c5b3c&&this['localCache'][_0x57e732]===_0x53850d||this['notifyListeners'](_0x57e732,_0x53850d);},_0x2458a0=this['storage']['getItem'](_0x57e732);Af()&&_0x2458a0!==_0x3f8453['newValue']&&_0x3f8453['newValue']!==_0x3f8453['oldValue']?setTimeout(_0x41ba25,op):_0x41ba25();}['notifyListeners'](_0x1fe1d7,_0x337423){this['localCache'][_0x1fe1d7]=_0x337423;const _0x1f6c51=this['listeners'][_0x1fe1d7];if(_0x1f6c51){for(const _0x5653fa of Array['from'](_0x1f6c51))_0x5653fa(_0x337423&&JSON['parse'](_0x337423));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x52a30a,_0x59d98e,_0x42d1b7)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x52a30a,'oldValue':_0x59d98e,'newValue':_0x42d1b7}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x31fe63,_0x53c297){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x31fe63]||(this['listeners'][_0x31fe63]=new Set(),this['localCache'][_0x31fe63]=this['storage']['getItem'](_0x31fe63)),this['listeners'][_0x31fe63]['add'](_0x53c297);}['_removeListener'](_0x1473b5,_0x4ef191){this['listeners'][_0x1473b5]&&(this['listeners'][_0x1473b5]['delete'](_0x4ef191),this['listeners'][_0x1473b5]['size']===0x0&&delete this['listeners'][_0x1473b5]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x4c92dd,_0x571793){await super['_set'](_0x4c92dd,_0x571793),this['localCache'][_0x4c92dd]=JSON['stringify'](_0x571793);}async['_get'](_0x3658c9){const _0x48739b=await super['_get'](_0x3658c9);return this['localCache'][_0x3658c9]=JSON['stringify'](_0x48739b),_0x48739b;}async['_remove'](_0x1112d7){await super['_remove'](_0x1112d7),delete this['localCache'][_0x1112d7];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x242b15,_0x6536da){}['_removeListener'](_0x2cf7eb,_0x4952a5){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x3daba3){return Promise['all'](_0x3daba3['map'](async _0x3df348=>{try{return{'fulfilled':!0x0,'value':await _0x3df348};}catch(_0x533b0d){return{'fulfilled':!0x1,'reason':_0x533b0d};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x5bd72d){this['eventTarget']=_0x5bd72d,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x3e11ca){const _0x1b6259=this['receivers']['find'](_0x4ac442=>_0x4ac442['isListeningto'](_0x3e11ca));if(_0x1b6259)return _0x1b6259;const _0x2bd25d=new Xn(_0x3e11ca);return this['receivers']['push'](_0x2bd25d),_0x2bd25d;}['isListeningto'](_0x197fd2){return this['eventTarget']===_0x197fd2;}async['handleEvent'](_0x4fb93d){const _0x5c36dd=_0x4fb93d,{eventId:_0x192fb9,eventType:_0x289d74,data:_0x30cb7b}=_0x5c36dd['data'],_0x1811cd=this['handlersMap'][_0x289d74];if(!(_0x1811cd!=null&&_0x1811cd['size']))return;_0x5c36dd['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x192fb9,'eventType':_0x289d74});const _0x95528a=Array['from'](_0x1811cd)['map'](async _0x22ebba=>_0x22ebba(_0x5c36dd['origin'],_0x30cb7b)),_0x20c6f0=await cp(_0x95528a);_0x5c36dd['ports'][0x0]['postMessage']({'status':'done','eventId':_0x192fb9,'eventType':_0x289d74,'response':_0x20c6f0});}['_subscribe'](_0x3f7745,_0x5af9a4){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x3f7745]||(this['handlersMap'][_0x3f7745]=new Set()),this['handlersMap'][_0x3f7745]['add'](_0x5af9a4);}['_unsubscribe'](_0x292e57,_0x5a1463){this['handlersMap'][_0x292e57]&&_0x5a1463&&this['handlersMap'][_0x292e57]['delete'](_0x5a1463),(!_0x5a1463||this['handlersMap'][_0x292e57]['size']===0x0)&&delete this['handlersMap'][_0x292e57],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x55734a='',_0x2286b6=0xa){let _0x376e36='';for(let _0x2dd9a8=0x0;_0x2dd9a8<_0x2286b6;_0x2dd9a8++)_0x376e36+=Math['floor'](Math['random']()*0xa);return _0x55734a+_0x376e36;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x2510af){this['target']=_0x2510af,this['handlers']=new Set();}['removeMessageHandler'](_0x5722c5){_0x5722c5['messageChannel']&&(_0x5722c5['messageChannel']['port1']['removeEventListener']('message',_0x5722c5['onMessage']),_0x5722c5['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x5722c5);}async['_send'](_0x4fc4ae,_0x1f6218,_0x25d895=0x32){const _0xfb9bc7=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0xfb9bc7)throw new Error('connection_unavailable');let _0x4fd28b,_0x5b4219;return new Promise((_0xe99148,_0x1b391c)=>{const _0x375690=As('',0x14);_0xfb9bc7['port1']['start']();const _0x1e14ec=setTimeout(()=>{_0x1b391c(new Error('unsupported_event'));},_0x25d895);_0x5b4219={'messageChannel':_0xfb9bc7,'onMessage'(_0x12ee9f){const _0x5ebfb9=_0x12ee9f;if(_0x5ebfb9['data']['eventId']===_0x375690)switch(_0x5ebfb9['data']['status']){case'ack':clearTimeout(_0x1e14ec),_0x4fd28b=setTimeout(()=>{_0x1b391c(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x4fd28b),_0xe99148(_0x5ebfb9['data']['response']);break;default:clearTimeout(_0x1e14ec),clearTimeout(_0x4fd28b),_0x1b391c(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x5b4219),_0xfb9bc7['port1']['addEventListener']('message',_0x5b4219['onMessage']),this['target']['postMessage']({'eventType':_0x4fc4ae,'eventId':_0x375690,'data':_0x1f6218},[_0xfb9bc7['port2']]);})['finally'](()=>{_0x5b4219&&this['removeMessageHandler'](_0x5b4219);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x4b437b){Z()['location']['href']=_0x4b437b;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x3d04a2;return((_0x3d04a2=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x3d04a2['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x57a208){this['request']=_0x57a208;}['toPromise'](){return new Promise((_0x2ef8a9,_0x56854c)=>{this['request']['addEventListener']('success',()=>{_0x2ef8a9(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x56854c(this['request']['error']);});});}}function Zn(_0x508fea,_0x3c916f){return _0x508fea['transaction']([Mn],_0x3c916f?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x1d778b=indexedDB['deleteDatabase'](Ka);return new nn(_0x1d778b)['toPromise']();}function Qa(){const _0x2e8d38=indexedDB['open'](Ka,pp);return new Promise((_0x171cb0,_0x5da77f)=>{_0x2e8d38['addEventListener']('error',()=>{_0x5da77f(_0x2e8d38['error']);}),_0x2e8d38['addEventListener']('upgradeneeded',()=>{const _0x51b681=_0x2e8d38['result'];try{_0x51b681['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x764470){_0x5da77f(_0x764470);}}),_0x2e8d38['addEventListener']('success',async()=>{const _0x392550=_0x2e8d38['result'];_0x392550['objectStoreNames']['contains'](Mn)?_0x171cb0(_0x392550):(_0x392550['close'](),await _p(),_0x171cb0(await Qa()));});});}async function Or(_0x25b7f1,_0x498de2,_0x44c0df){const _0x243cf7=Zn(_0x25b7f1,!0x0)['put']({[Ya]:_0x498de2,'value':_0x44c0df});return new nn(_0x243cf7)['toPromise']();}async function gp(_0x299ea7,_0x135165){const _0x4d2aa4=Zn(_0x299ea7,!0x1)['get'](_0x135165),_0x2bb028=await new nn(_0x4d2aa4)['toPromise']();return _0x2bb028===void 0x0?null:_0x2bb028['value'];}function Dr(_0x48127a,_0x1574c1){const _0x41cc51=Zn(_0x48127a,!0x0)['delete'](_0x1574c1);return new nn(_0x41cc51)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x58e7f4){let _0x36946d=0x0;for(;;)try{const _0x25893a=await this['_openDb']();return await _0x58e7f4(_0x25893a);}catch(_0x4f576a){if(_0x36946d++>yp)throw _0x4f576a;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x5095a2,_0x3724a9)=>({'keyProcessed':(await this['_poll']())['includes'](_0x3724a9['key'])})),this['receiver']['_subscribe']('ping',async(_0x39b82d,_0x4c0397)=>['keyChanged']);}async['initializeSender'](){var _0x20f2be,_0xf357aa;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x55028e=await this['sender']['_send']('ping',{},0x320);_0x55028e&&(_0x20f2be=_0x55028e[0x0])!=null&&_0x20f2be['fulfilled']&&(_0xf357aa=_0x55028e[0x0])!=null&&_0xf357aa['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x3f5fc8){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x3f5fc8},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x535d20=>{await Or(_0x535d20,Dn,'1'),await Dr(_0x535d20,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x44bacd){this['pendingWrites']++;try{await _0x44bacd();}finally{this['pendingWrites']--;}}async['_set'](_0xb65e95,_0x4e0143){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x1c2c5e=>Or(_0x1c2c5e,_0xb65e95,_0x4e0143)),this['localCache'][_0xb65e95]=_0x4e0143,this['notifyServiceWorker'](_0xb65e95)));}async['_get'](_0x17c87e){const _0x18d9ad=await this['_withRetries'](_0x17457f=>gp(_0x17457f,_0x17c87e));return this['localCache'][_0x17c87e]=_0x18d9ad,_0x18d9ad;}async['_remove'](_0x368fc9){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x4a754c=>Dr(_0x4a754c,_0x368fc9)),delete this['localCache'][_0x368fc9],this['notifyServiceWorker'](_0x368fc9)));}async['_poll'](){const _0x2a03f7=await this['_withRetries'](_0x401fcc=>{const _0x539772=Zn(_0x401fcc,!0x1)['getAll']();return new nn(_0x539772)['toPromise']();});if(!_0x2a03f7)return[];if(this['pendingWrites']!==0x0)return[];const _0x52d811=[],_0x40f9ca=new Set();if(_0x2a03f7['length']!==0x0){for(const {fbase_key:_0x5d2eeb,value:_0x3dcebe}of _0x2a03f7)_0x40f9ca['add'](_0x5d2eeb),JSON['stringify'](this['localCache'][_0x5d2eeb])!==JSON['stringify'](_0x3dcebe)&&(this['notifyListeners'](_0x5d2eeb,_0x3dcebe),_0x52d811['push'](_0x5d2eeb));}for(const _0x3e8d97 of Object['keys'](this['localCache']))this['localCache'][_0x3e8d97]&&!_0x40f9ca['has'](_0x3e8d97)&&(this['notifyListeners'](_0x3e8d97,null),_0x52d811['push'](_0x3e8d97));return _0x52d811;}['notifyListeners'](_0x49a84e,_0x1c4da2){this['localCache'][_0x49a84e]=_0x1c4da2;const _0x1c6ad=this['listeners'][_0x49a84e];if(_0x1c6ad){for(const _0x4c8041 of Array['from'](_0x1c6ad))_0x4c8041(_0x1c4da2);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x245166,_0x177954){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x245166]||(this['listeners'][_0x245166]=new Set(),this['_get'](_0x245166)),this['listeners'][_0x245166]['add'](_0x177954);}['_removeListener'](_0x137b06,_0x48745f){this['listeners'][_0x137b06]&&(this['listeners'][_0x137b06]['delete'](_0x48745f),this['listeners'][_0x137b06]['size']===0x0&&delete this['listeners'][_0x137b06]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x501b89,_0x3833e1){return _0x3833e1?ie(_0x3833e1):(m(_0x501b89['_popupRedirectResolver'],_0x501b89,'argument-error'),_0x501b89['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x2e361a){super('custom','custom'),this['params']=_0x2e361a;}['_getIdTokenResponse'](_0x20c516){return nt(_0x20c516,this['_buildIdpRequest']());}['_linkToIdToken'](_0x580b5a,_0x134809){return nt(_0x580b5a,this['_buildIdpRequest'](_0x134809));}['_getReauthenticationResolver'](_0x3144e1){return nt(_0x3144e1,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x54f0d1){const _0x368daf={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x54f0d1&&(_0x368daf['idToken']=_0x54f0d1),_0x368daf;}}function Ip(_0x2b76a3){return Va(_0x2b76a3['auth'],new ks(_0x2b76a3),_0x2b76a3['bypassAuthState']);}function wp(_0x5592b7){const {auth:_0x3580e6,user:_0xe9e243}=_0x5592b7;return m(_0xe9e243,_0x3580e6,'internal-error'),tp(_0xe9e243,new ks(_0x5592b7),_0x5592b7['bypassAuthState']);}async function Cp(_0x2fa386){const {auth:_0x211990,user:_0x45dae6}=_0x2fa386;return m(_0x45dae6,_0x211990,'internal-error'),ep(_0x45dae6,new ks(_0x2fa386),_0x2fa386['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x1c93bf,_0x5530a4,_0x1baa66,_0x1add4f,_0x8e1f9c=!0x1){this['auth']=_0x1c93bf,this['resolver']=_0x1baa66,this['user']=_0x1add4f,this['bypassAuthState']=_0x8e1f9c,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x5530a4)?_0x5530a4:[_0x5530a4];}['execute'](){return new Promise(async(_0x302cc9,_0x497dbc)=>{this['pendingPromise']={'resolve':_0x302cc9,'reject':_0x497dbc};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x1d8c65){this['reject'](_0x1d8c65);}});}async['onAuthEvent'](_0xa674be){const {urlResponse:_0x498135,sessionId:_0x55444e,postBody:_0x1fba90,tenantId:_0x3414f2,error:_0x1d061f,type:_0x5d263d}=_0xa674be;if(_0x1d061f){this['reject'](_0x1d061f);return;}const _0x5199ca={'auth':this['auth'],'requestUri':_0x498135,'sessionId':_0x55444e,'tenantId':_0x3414f2||void 0x0,'postBody':_0x1fba90||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x5d263d)(_0x5199ca));}catch(_0x2d2359){this['reject'](_0x2d2359);}}['onError'](_0x48326a){this['reject'](_0x48326a);}['getIdpTask'](_0x2954b7){switch(_0x2954b7){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x490540){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x490540),this['unregisterAndCleanUp']();}['reject'](_0x426bae){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x426bae),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x5d09e4,_0x41e3db,_0x1f42df,_0x10ecf1,_0x1b28cf){super(_0x5d09e4,_0x41e3db,_0x10ecf1,_0x1b28cf),this['provider']=_0x1f42df,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x16532b=await this['execute']();return m(_0x16532b,this['auth'],'internal-error'),_0x16532b;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x5b5480=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x5b5480),this['authWindow']['associatedEvent']=_0x5b5480,this['resolver']['_originValidation'](this['auth'])['catch'](_0x479db2=>{this['reject'](_0x479db2);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x3dd28c=>{_0x3dd28c||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x311993;return((_0x311993=this['authWindow'])==null?void 0x0:_0x311993['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x5d57e4=()=>{var _0x5868be,_0x2b63a0;if((_0x2b63a0=(_0x5868be=this['authWindow'])==null?void 0x0:_0x5868be['window'])!=null&&_0x2b63a0['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x5d57e4,Tp['get']());};_0x5d57e4();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x1f7b14,_0xb05169,_0x2e2ac0=!0x1){super(_0x1f7b14,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0xb05169,void 0x0,_0x2e2ac0),this['eventId']=null;}async['execute'](){let _0x54a124=hn['get'](this['auth']['_key']());if(!_0x54a124){try{const _0x2752d3=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x54a124=()=>Promise['resolve'](_0x2752d3);}catch(_0x25af84){_0x54a124=()=>Promise['reject'](_0x25af84);}hn['set'](this['auth']['_key'](),_0x54a124);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x54a124();}async['onAuthEvent'](_0x4338be){if(_0x4338be['type']==='signInViaRedirect')return super['onAuthEvent'](_0x4338be);if(_0x4338be['type']==='unknown'){this['resolve'](null);return;}if(_0x4338be['eventId']){const _0x8e763c=await this['auth']['_redirectUserForId'](_0x4338be['eventId']);if(_0x8e763c)return this['user']=_0x8e763c,super['onAuthEvent'](_0x4338be);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0xb33168,_0x36d376){const _0x11c84b=Pp(_0x36d376),_0x44b8fc=kp(_0xb33168);if(!await _0x44b8fc['_isAvailable']())return!0x1;const _0xf2221=await _0x44b8fc['_get'](_0x11c84b)==='true';return await _0x44b8fc['_remove'](_0x11c84b),_0xf2221;}function Ap(_0x48e70b,_0x4cc6db){hn['set'](_0x48e70b['_key'](),_0x4cc6db);}function kp(_0x261123){return ie(_0x261123['_redirectPersistence']);}function Pp(_0x35b4d7){return ln(Sp,_0x35b4d7['config']['apiKey'],_0x35b4d7['name']);}async function Np(_0x11d1c0,_0x1b7985,_0x59be42=!0x1){if($(_0x11d1c0['app']))return Promise['reject'](re(_0x11d1c0));const _0x5cb1c1=Ke(_0x11d1c0),_0x42ac3d=Ep(_0x5cb1c1,_0x1b7985),_0x383802=await new bp(_0x5cb1c1,_0x42ac3d,_0x59be42)['execute']();return _0x383802&&!_0x59be42&&(delete _0x383802['user']['_redirectEventId'],await _0x5cb1c1['_persistUserIfCurrent'](_0x383802['user']),await _0x5cb1c1['_setRedirectUser'](null,_0x1b7985)),_0x383802;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x4969f4){this['auth']=_0x4969f4,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x4b9120){this['consumers']['add'](_0x4b9120),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x4b9120)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x4b9120),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x5e8c0a){this['consumers']['delete'](_0x5e8c0a);}['onEvent'](_0x2a3e59){if(this['hasEventBeenHandled'](_0x2a3e59))return!0x1;let _0x240932=!0x1;return this['consumers']['forEach'](_0x428c6c=>{this['isEventForConsumer'](_0x2a3e59,_0x428c6c)&&(_0x240932=!0x0,this['sendToConsumer'](_0x2a3e59,_0x428c6c),this['saveEventToCache'](_0x2a3e59));}),this['hasHandledPotentialRedirect']||!Mp(_0x2a3e59)||(this['hasHandledPotentialRedirect']=!0x0,_0x240932||(this['queuedRedirectEvent']=_0x2a3e59,_0x240932=!0x0)),_0x240932;}['sendToConsumer'](_0x2284d7,_0x40ed1a){var _0x1338ca;if(_0x2284d7['error']&&!Za(_0x2284d7)){const _0x325808=((_0x1338ca=_0x2284d7['error']['code'])==null?void 0x0:_0x1338ca['split']('auth/')[0x1])||'internal-error';_0x40ed1a['onError'](X(this['auth'],_0x325808));}else _0x40ed1a['onAuthEvent'](_0x2284d7);}['isEventForConsumer'](_0x5598f5,_0x33e01a){const _0x5f164d=_0x33e01a['eventId']===null||!!_0x5598f5['eventId']&&_0x5598f5['eventId']===_0x33e01a['eventId'];return _0x33e01a['filter']['includes'](_0x5598f5['type'])&&_0x5f164d;}['hasEventBeenHandled'](_0x2e344a){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x2e344a));}['saveEventToCache'](_0x11019a){this['cachedEventUids']['add'](Mr(_0x11019a)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x1cb466){return[_0x1cb466['type'],_0x1cb466['eventId'],_0x1cb466['sessionId'],_0x1cb466['tenantId']]['filter'](_0x2b087e=>_0x2b087e)['join']('-');}function Za({type:_0x40fa88,error:_0x5cc8b6}){return _0x40fa88==='unknown'&&(_0x5cc8b6==null?void 0x0:_0x5cc8b6['code'])==='auth/no-auth-event';}function Mp(_0x3dc62b){switch(_0x3dc62b['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x3dc62b);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x3d1f9d,_0x2903dd={}){return Pe(_0x3d1f9d,'GET','/v1/projects',_0x2903dd);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x517d89){if(_0x517d89['config']['emulator'])return;const {authorizedDomains:_0x22eaf0}=await Lp(_0x517d89);for(const _0x2da6d8 of _0x22eaf0)try{if(Wp(_0x2da6d8))return;}catch{}Y(_0x517d89,'unauthorized-domain');}function Wp(_0x2b55af){const _0x4a343c=Mi(),{protocol:_0x418b8f,hostname:_0x2291fc}=new URL(_0x4a343c);if(_0x2b55af['startsWith']('chrome-extension://')){const _0x2d90b7=new URL(_0x2b55af);return _0x2d90b7['hostname']===''&&_0x2291fc===''?_0x418b8f==='chrome-extension:'&&_0x2b55af['replace']('chrome-extension://','')===_0x4a343c['replace']('chrome-extension://',''):_0x418b8f==='chrome-extension:'&&_0x2d90b7['hostname']===_0x2291fc;}if(!Fp['test'](_0x418b8f))return!0x1;if(xp['test'](_0x2b55af))return _0x2291fc===_0x2b55af;const _0x2743eb=_0x2b55af['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x2743eb+'|'+_0x2743eb+')$','i')['test'](_0x2291fc);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x332eb9=Z()['___jsl'];if(_0x332eb9!=null&&_0x332eb9['H']){for(const _0x23156e of Object['keys'](_0x332eb9['H']))if(_0x332eb9['H'][_0x23156e]['r']=_0x332eb9['H'][_0x23156e]['r']||[],_0x332eb9['H'][_0x23156e]['L']=_0x332eb9['H'][_0x23156e]['L']||[],_0x332eb9['H'][_0x23156e]['r']=[..._0x332eb9['H'][_0x23156e]['L']],_0x332eb9['CP']){for(let _0xd32228=0x0;_0xd32228<_0x332eb9['CP']['length'];_0xd32228++)_0x332eb9['CP'][_0xd32228]=null;}}}function Vp(_0x2427c1){return new Promise((_0x137b5b,_0x4adf2e)=>{var _0x344ea3,_0x2eee50,_0x16aea8;function _0x13bc1f(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x137b5b(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x4adf2e(X(_0x2427c1,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x2eee50=(_0x344ea3=Z()['gapi'])==null?void 0x0:_0x344ea3['iframes'])!=null&&_0x2eee50['Iframe'])_0x137b5b(gapi['iframes']['getContext']());else{if((_0x16aea8=Z()['gapi'])!=null&&_0x16aea8['load'])_0x13bc1f();else{const _0x379ed4=Ff('iframefcb');return Z()[_0x379ed4]=()=>{gapi['load']?_0x13bc1f():_0x4adf2e(X(_0x2427c1,'network-request-failed'));},xa(xf()+'?onload='+_0x379ed4)['catch'](_0x465bfc=>_0x4adf2e(_0x465bfc));}}})['catch'](_0x52a2a0=>{throw un=null,_0x52a2a0;});}let un=null;function Hp(_0x41b9e1){return un=un||Vp(_0x41b9e1),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x2cc212){const _0x2a30db=_0x2cc212['config'];m(_0x2a30db['authDomain'],_0x2cc212,'auth-domain-config-required');const _0x1dee37=_0x2a30db['emulator']?Cs(_0x2a30db,qp):'https://'+_0x2cc212['config']['authDomain']+'/'+Gp,_0x7166ba={'apiKey':_0x2a30db['apiKey'],'appName':_0x2cc212['name'],'v':dt},_0x149665=jp['get'](_0x2cc212['config']['apiHost']);_0x149665&&(_0x7166ba['eid']=_0x149665);const _0x5ab6a7=_0x2cc212['_getFrameworks']();return _0x5ab6a7['length']&&(_0x7166ba['fw']=_0x5ab6a7['join'](',')),_0x1dee37+'?'+ut(_0x7166ba)['slice'](0x1);}async function Yp(_0x4e3546){const _0x1420f8=await Hp(_0x4e3546),_0x922ad3=Z()['gapi'];return m(_0x922ad3,_0x4e3546,'internal-error'),_0x1420f8['open']({'where':document['body'],'url':Kp(_0x4e3546),'messageHandlersFilter':_0x922ad3['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x1297a6=>new Promise(async(_0x55d521,_0x51197b)=>{await _0x1297a6['restyle']({'setHideOnLeave':!0x1});const _0x3c8eb0=X(_0x4e3546,'network-request-failed'),_0x37129d=Z()['setTimeout'](()=>{_0x51197b(_0x3c8eb0);},$p['get']());function _0x8288e5(){Z()['clearTimeout'](_0x37129d),_0x55d521(_0x1297a6);}_0x1297a6['ping'](_0x8288e5)['then'](_0x8288e5,()=>{_0x51197b(_0x3c8eb0);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x2c4dc8){this['window']=_0x2c4dc8,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x59ea2c,_0x55777f,_0x15cd8b,_0x5c6f71=Jp,_0x9cf3a4=Xp){const _0x391d6d=Math['max']((window['screen']['availHeight']-_0x9cf3a4)/0x2,0x0)['toString'](),_0x320064=Math['max']((window['screen']['availWidth']-_0x5c6f71)/0x2,0x0)['toString']();let _0x177abc='';const _0x5dde0d={...Qp,'width':_0x5c6f71['toString'](),'height':_0x9cf3a4['toString'](),'top':_0x391d6d,'left':_0x320064},_0x3e2aa3=W()['toLowerCase']();_0x15cd8b&&(_0x177abc=ka(_0x3e2aa3)?Zp:_0x15cd8b),Ra(_0x3e2aa3)&&(_0x55777f=_0x55777f||e_,_0x5dde0d['scrollbars']='yes');const _0x3ec9df=Object['entries'](_0x5dde0d)['reduce']((_0xf74c54,[_0x55deff,_0x1148b0])=>''+_0xf74c54+_0x55deff+'='+_0x1148b0+',','');if(Rf(_0x3e2aa3)&&_0x177abc!=='_self')return n_(_0x55777f||'',_0x177abc),new xr(null);const _0x2ee917=window['open'](_0x55777f||'',_0x177abc,_0x3ec9df);m(_0x2ee917,_0x59ea2c,'popup-blocked');try{_0x2ee917['focus']();}catch{}return new xr(_0x2ee917);}function n_(_0x4e8e07,_0x40b9b8){const _0x3b194c=document['createElement']('a');_0x3b194c['href']=_0x4e8e07,_0x3b194c['target']=_0x40b9b8;const _0xc5a8e9=document['createEvent']('MouseEvent');_0xc5a8e9['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x3b194c['dispatchEvent'](_0xc5a8e9);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x4c2f97,_0x3ce7f3,_0x2ec00e,_0x2d88e2,_0xfc7d70,_0x3bb8fa){m(_0x4c2f97['config']['authDomain'],_0x4c2f97,'auth-domain-config-required'),m(_0x4c2f97['config']['apiKey'],_0x4c2f97,'invalid-api-key');const _0x5739eb={'apiKey':_0x4c2f97['config']['apiKey'],'appName':_0x4c2f97['name'],'authType':_0x2ec00e,'redirectUrl':_0x2d88e2,'v':dt,'eventId':_0xfc7d70};if(_0x3ce7f3 instanceof Wa){_0x3ce7f3['setDefaultLanguage'](_0x4c2f97['languageCode']),_0x5739eb['providerId']=_0x3ce7f3['providerId']||'',pn(_0x3ce7f3['getCustomParameters']())||(_0x5739eb['customParameters']=JSON['stringify'](_0x3ce7f3['getCustomParameters']()));for(const [_0x5705c8,_0x42d87a]of Object['entries']({}))_0x5739eb[_0x5705c8]=_0x42d87a;}if(_0x3ce7f3 instanceof tn){const _0x47649e=_0x3ce7f3['getScopes']()['filter'](_0x3fa2f0=>_0x3fa2f0!=='');_0x47649e['length']>0x0&&(_0x5739eb['scopes']=_0x47649e['join'](','));}_0x4c2f97['tenantId']&&(_0x5739eb['tid']=_0x4c2f97['tenantId']);const _0xf5c388=_0x5739eb;for(const _0x3be7b3 of Object['keys'](_0xf5c388))_0xf5c388[_0x3be7b3]===void 0x0&&delete _0xf5c388[_0x3be7b3];const _0x7ed716=await _0x4c2f97['_getAppCheckToken'](),_0x1645ea=_0x7ed716?'#'+r_+'='+encodeURIComponent(_0x7ed716):'';return o_(_0x4c2f97)+'?'+ut(_0xf5c388)['slice'](0x1)+_0x1645ea;}function o_({config:_0x8ac9aa}){return _0x8ac9aa['emulator']?Cs(_0x8ac9aa,s_):'https://'+_0x8ac9aa['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x2df0f,_0x2f2d15,_0x31f35a,_0x392fad){var _0x2830c1;ce((_0x2830c1=this['eventManagers'][_0x2df0f['_key']()])==null?void 0x0:_0x2830c1['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x59e03b=await Fr(_0x2df0f,_0x2f2d15,_0x31f35a,Mi(),_0x392fad);return t_(_0x2df0f,_0x59e03b,As());}async['_openRedirect'](_0x3a6911,_0x3d00b,_0x5c50fe,_0x386662){await this['_originValidation'](_0x3a6911);const _0x1d3f21=await Fr(_0x3a6911,_0x3d00b,_0x5c50fe,Mi(),_0x386662);return hp(_0x1d3f21),new Promise(()=>{});}['_initialize'](_0x2504e0){const _0x163875=_0x2504e0['_key']();if(this['eventManagers'][_0x163875]){const {manager:_0x57b5b4,promise:_0x408ce7}=this['eventManagers'][_0x163875];return _0x57b5b4?Promise['resolve'](_0x57b5b4):(ce(_0x408ce7,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x408ce7);}const _0x283d79=this['initAndGetManager'](_0x2504e0);return this['eventManagers'][_0x163875]={'promise':_0x283d79},_0x283d79['catch'](()=>{delete this['eventManagers'][_0x163875];}),_0x283d79;}async['initAndGetManager'](_0x43e07f){const _0xb22bf3=await Yp(_0x43e07f),_0x428645=new Dp(_0x43e07f);return _0xb22bf3['register']('authEvent',_0x4eb322=>(m(_0x4eb322==null?void 0x0:_0x4eb322['authEvent'],_0x43e07f,'invalid-auth-event'),{'status':_0x428645['onEvent'](_0x4eb322['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x43e07f['_key']()]={'manager':_0x428645},this['iframes'][_0x43e07f['_key']()]=_0xb22bf3,_0x428645;}['_isIframeWebStorageSupported'](_0xafdcc1,_0x2022c5){this['iframes'][_0xafdcc1['_key']()]['send'](pi,{'type':pi},_0x18bac3=>{var _0x5b405c;const _0x8f3e57=(_0x5b405c=_0x18bac3==null?void 0x0:_0x18bac3[0x0])==null?void 0x0:_0x5b405c[pi];_0x8f3e57!==void 0x0&&_0x2022c5(!!_0x8f3e57),Y(_0xafdcc1,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x2462f6){const _0xb450e2=_0x2462f6['_key']();return this['originValidationPromises'][_0xb450e2]||(this['originValidationPromises'][_0xb450e2]=Up(_0x2462f6)),this['originValidationPromises'][_0xb450e2];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0xdca99f){this['auth']=_0xdca99f,this['internalListeners']=new Map();}['getUid'](){var _0xe544c7;return this['assertAuthConfigured'](),((_0xe544c7=this['auth']['currentUser'])==null?void 0x0:_0xe544c7['uid'])||null;}async['getToken'](_0x118265){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x118265)}:null;}['addAuthTokenListener'](_0x635598){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x635598))return;const _0x2922af=this['auth']['onIdTokenChanged'](_0x2725d9=>{_0x635598((_0x2725d9==null?void 0x0:_0x2725d9['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x635598,_0x2922af),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x23234e){this['assertAuthConfigured']();const _0x7bb1b5=this['internalListeners']['get'](_0x23234e);_0x7bb1b5&&(this['internalListeners']['delete'](_0x23234e),_0x7bb1b5(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x2a650e){switch(_0x2a650e){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x5f36ac){st(new Fe('auth',(_0x4a19fe,{options:_0x51da04})=>{const _0x484fff=_0x4a19fe['getProvider']('app')['getImmediate'](),_0x2f7960=_0x4a19fe['getProvider']('heartbeat'),_0x464969=_0x4a19fe['getProvider']('app-check-internal'),{apiKey:_0x5a468e,authDomain:_0x587535}=_0x484fff['options'];m(_0x5a468e&&!_0x5a468e['includes'](':'),'invalid-api-key',{'appName':_0x484fff['name']});const _0x5bdec7={'apiKey':_0x5a468e,'authDomain':_0x587535,'clientPlatform':_0x5f36ac,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x5f36ac)},_0x505d64=new Df(_0x484fff,_0x2f7960,_0x464969,_0x5bdec7);return Hf(_0x505d64,_0x51da04),_0x505d64;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x434a56,_0x3e51ed,_0x403816)=>{_0x434a56['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x5a5cf8=>{const _0x5cdab3=Ke(_0x5a5cf8['getProvider']('auth')['getImmediate']());return(_0x2caf3e=>new l_(_0x2caf3e))(_0x5cdab3);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x5f36ac)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x26cb47=>async _0x54a385=>{const _0x3927e5=_0x54a385&&await _0x54a385['getIdTokenResult'](),_0x222d98=_0x3927e5&&(new Date()['getTime']()-Date['parse'](_0x3927e5['issuedAtTime']))/0x3e8;if(_0x222d98&&_0x222d98>f_)return;const _0x2ab6e8=_0x3927e5==null?void 0x0:_0x3927e5['token'];Br!==_0x2ab6e8&&(Br=_0x2ab6e8,await fetch(_0x26cb47,{'method':_0x2ab6e8?'POST':'DELETE','headers':_0x2ab6e8?{'Authorization':'Bearer\x20'+_0x2ab6e8}:{}}));};function B_(_0x3e16f0=Zr()){const _0x1a90b8=Hi(_0x3e16f0,'auth');if(_0x1a90b8['isInitialized']())return _0x1a90b8['getImmediate']();const _0x4fe605=Vf(_0x3e16f0,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x2c22be=jr('authTokenSyncURL');if(_0x2c22be&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x3b2daa=new URL(_0x2c22be,location['origin']);if(location['origin']===_0x3b2daa['origin']){const _0x592b86=p_(_0x3b2daa['toString']());sp(_0x4fe605,_0x592b86,()=>_0x592b86(_0x4fe605['currentUser'])),ip(_0x4fe605,_0x2b4e76=>_0x592b86(_0x2b4e76));}}const _0x5667bf=qr('auth');return _0x5667bf&&$f(_0x4fe605,'http://'+_0x5667bf),_0x4fe605;}function __(){var _0x24aa70;return((_0x24aa70=document['getElementsByTagName']('head'))==null?void 0x0:_0x24aa70[0x0])??document;}Mf({'loadJS'(_0xed4b60){return new Promise((_0x1ecc54,_0x4729fc)=>{const _0x46447a=document['createElement']('script');_0x46447a['setAttribute']('src',_0xed4b60),_0x46447a['onload']=_0x1ecc54,_0x46447a['onerror']=_0x36e278=>{const _0x3c9e8e=X('internal-error');_0x3c9e8e['customData']=_0x36e278,_0x4729fc(_0x3c9e8e);},_0x46447a['type']='text/javascript',_0x46447a['charset']='UTF-8',__()['appendChild'](_0x46447a);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{Gd as A,Vt as B,N_ as C,U_ as D,O_ as E,M_ as a,C_ as b,B_ as c,L_ as d,A_ as e,W_ as f,w_ as g,m_ as h,Sl as i,Hd as j,R_ as k,S_ as l,g_ as m,P_ as n,b_ as o,E_ as p,k_ as q,y_ as r,T_ as s,F_ as t,I_ as u,ap as v,Zr as w,x_ as x,v_ as y,D_ as z};