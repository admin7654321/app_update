const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x633950,_0x5c81ba){if(!_0x633950)throw ht(_0x5c81ba);},ht=function(_0x5a9ebf){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x5a9ebf);},Hr=function(_0x12b7b6){const _0x3baf01=[];let _0x37dfcd=0x0;for(let _0x5a8ebd=0x0;_0x5a8ebd<_0x12b7b6['length'];_0x5a8ebd++){let _0x557004=_0x12b7b6['charCodeAt'](_0x5a8ebd);_0x557004<0x80?_0x3baf01[_0x37dfcd++]=_0x557004:_0x557004<0x800?(_0x3baf01[_0x37dfcd++]=_0x557004>>0x6|0xc0,_0x3baf01[_0x37dfcd++]=_0x557004&0x3f|0x80):(_0x557004&0xfc00)===0xd800&&_0x5a8ebd+0x1<_0x12b7b6['length']&&(_0x12b7b6['charCodeAt'](_0x5a8ebd+0x1)&0xfc00)===0xdc00?(_0x557004=0x10000+((_0x557004&0x3ff)<<0xa)+(_0x12b7b6['charCodeAt'](++_0x5a8ebd)&0x3ff),_0x3baf01[_0x37dfcd++]=_0x557004>>0x12|0xf0,_0x3baf01[_0x37dfcd++]=_0x557004>>0xc&0x3f|0x80,_0x3baf01[_0x37dfcd++]=_0x557004>>0x6&0x3f|0x80,_0x3baf01[_0x37dfcd++]=_0x557004&0x3f|0x80):(_0x3baf01[_0x37dfcd++]=_0x557004>>0xc|0xe0,_0x3baf01[_0x37dfcd++]=_0x557004>>0x6&0x3f|0x80,_0x3baf01[_0x37dfcd++]=_0x557004&0x3f|0x80);}return _0x3baf01;},nc=function(_0x5c0c33){const _0x4fdaf4=[];let _0x4d485f=0x0,_0x340102=0x0;for(;_0x4d485f<_0x5c0c33['length'];){const _0x108d9f=_0x5c0c33[_0x4d485f++];if(_0x108d9f<0x80)_0x4fdaf4[_0x340102++]=String['fromCharCode'](_0x108d9f);else{if(_0x108d9f>0xbf&&_0x108d9f<0xe0){const _0x5e36fd=_0x5c0c33[_0x4d485f++];_0x4fdaf4[_0x340102++]=String['fromCharCode']((_0x108d9f&0x1f)<<0x6|_0x5e36fd&0x3f);}else{if(_0x108d9f>0xef&&_0x108d9f<0x16d){const _0x66f88d=_0x5c0c33[_0x4d485f++],_0x824bb0=_0x5c0c33[_0x4d485f++],_0x2fc66b=_0x5c0c33[_0x4d485f++],_0x4c943d=((_0x108d9f&0x7)<<0x12|(_0x66f88d&0x3f)<<0xc|(_0x824bb0&0x3f)<<0x6|_0x2fc66b&0x3f)-0x10000;_0x4fdaf4[_0x340102++]=String['fromCharCode'](0xd800+(_0x4c943d>>0xa)),_0x4fdaf4[_0x340102++]=String['fromCharCode'](0xdc00+(_0x4c943d&0x3ff));}else{const _0x1f5433=_0x5c0c33[_0x4d485f++],_0x1475af=_0x5c0c33[_0x4d485f++];_0x4fdaf4[_0x340102++]=String['fromCharCode']((_0x108d9f&0xf)<<0xc|(_0x1f5433&0x3f)<<0x6|_0x1475af&0x3f);}}}}return _0x4fdaf4['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x539b47,_0x38fc48){if(!Array['isArray'](_0x539b47))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x3fbafc=_0x38fc48?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x206dd1=[];for(let _0x285e1a=0x0;_0x285e1a<_0x539b47['length'];_0x285e1a+=0x3){const _0x4f4f5e=_0x539b47[_0x285e1a],_0x379d3c=_0x285e1a+0x1<_0x539b47['length'],_0x3124fb=_0x379d3c?_0x539b47[_0x285e1a+0x1]:0x0,_0x571b49=_0x285e1a+0x2<_0x539b47['length'],_0xa05466=_0x571b49?_0x539b47[_0x285e1a+0x2]:0x0,_0x597b0f=_0x4f4f5e>>0x2,_0x31b612=(_0x4f4f5e&0x3)<<0x4|_0x3124fb>>0x4;let _0x240ffc=(_0x3124fb&0xf)<<0x2|_0xa05466>>0x6,_0x119dc9=_0xa05466&0x3f;_0x571b49||(_0x119dc9=0x40,_0x379d3c||(_0x240ffc=0x40)),_0x206dd1['push'](_0x3fbafc[_0x597b0f],_0x3fbafc[_0x31b612],_0x3fbafc[_0x240ffc],_0x3fbafc[_0x119dc9]);}return _0x206dd1['join']('');},'encodeString'(_0x496a60,_0x4a1a27){return this['HAS_NATIVE_SUPPORT']&&!_0x4a1a27?btoa(_0x496a60):this['encodeByteArray'](Hr(_0x496a60),_0x4a1a27);},'decodeString'(_0x420978,_0x1997da){return this['HAS_NATIVE_SUPPORT']&&!_0x1997da?atob(_0x420978):nc(this['decodeStringToByteArray'](_0x420978,_0x1997da));},'decodeStringToByteArray'(_0x4d87d9,_0x399209){this['init_']();const _0x12e8ee=_0x399209?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x599dfe=[];for(let _0x3d5576=0x0;_0x3d5576<_0x4d87d9['length'];){const _0x3bb36f=_0x12e8ee[_0x4d87d9['charAt'](_0x3d5576++)],_0x5bec12=_0x3d5576<_0x4d87d9['length']?_0x12e8ee[_0x4d87d9['charAt'](_0x3d5576)]:0x0;++_0x3d5576;const _0x2e387d=_0x3d5576<_0x4d87d9['length']?_0x12e8ee[_0x4d87d9['charAt'](_0x3d5576)]:0x40;++_0x3d5576;const _0x3e48d6=_0x3d5576<_0x4d87d9['length']?_0x12e8ee[_0x4d87d9['charAt'](_0x3d5576)]:0x40;if(++_0x3d5576,_0x3bb36f==null||_0x5bec12==null||_0x2e387d==null||_0x3e48d6==null)throw new ic();const _0x557ce5=_0x3bb36f<<0x2|_0x5bec12>>0x4;if(_0x599dfe['push'](_0x557ce5),_0x2e387d!==0x40){const _0x471941=_0x5bec12<<0x4&0xf0|_0x2e387d>>0x2;if(_0x599dfe['push'](_0x471941),_0x3e48d6!==0x40){const _0x73e744=_0x2e387d<<0x6&0xc0|_0x3e48d6;_0x599dfe['push'](_0x73e744);}}}return _0x599dfe;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x30d8e8=0x0;_0x30d8e8<this['ENCODED_VALS']['length'];_0x30d8e8++)this['byteToCharMap_'][_0x30d8e8]=this['ENCODED_VALS']['charAt'](_0x30d8e8),this['charToByteMap_'][this['byteToCharMap_'][_0x30d8e8]]=_0x30d8e8,this['byteToCharMapWebSafe_'][_0x30d8e8]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x30d8e8),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x30d8e8]]=_0x30d8e8,_0x30d8e8>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x30d8e8)]=_0x30d8e8,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x30d8e8)]=_0x30d8e8);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x446904){const _0x214a2d=Hr(_0x446904);return Fi['encodeByteArray'](_0x214a2d,!0x0);},dn=function(_0x550ff9){return $r(_0x550ff9)['replace'](/\./g,'');},fn=function(_0x2f9134){try{return Fi['decodeString'](_0x2f9134,!0x0);}catch(_0x2c0d9b){console['error']('base64Decode\x20failed:\x20',_0x2c0d9b);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x2254d7){return Gr(void 0x0,_0x2254d7);}function Gr(_0x193fed,_0x4c67a5){if(!(_0x4c67a5 instanceof Object))return _0x4c67a5;switch(_0x4c67a5['constructor']){case Date:const _0x15641f=_0x4c67a5;return new Date(_0x15641f['getTime']());case Object:_0x193fed===void 0x0&&(_0x193fed={});break;case Array:_0x193fed=[];break;default:return _0x4c67a5;}for(const _0xb06b9e in _0x4c67a5)!_0x4c67a5['hasOwnProperty'](_0xb06b9e)||!rc(_0xb06b9e)||(_0x193fed[_0xb06b9e]=Gr(_0x193fed[_0xb06b9e],_0x4c67a5[_0xb06b9e]));return _0x193fed;}function rc(_0x351786){return _0x351786!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x2ffa7f=Ps['__FIREBASE_DEFAULTS__'];if(_0x2ffa7f)return JSON['parse'](_0x2ffa7f);},lc=()=>{if(typeof document>'u')return;let _0x182c2f;try{_0x182c2f=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x2f248f=_0x182c2f&&fn(_0x182c2f[0x1]);return _0x2f248f&&JSON['parse'](_0x2f248f);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x193bae){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x193bae);return;}},qr=_0x477d3f=>{var _0x36f7f0,_0x14d739;return(_0x14d739=(_0x36f7f0=Ui())==null?void 0x0:_0x36f7f0['emulatorHosts'])==null?void 0x0:_0x14d739[_0x477d3f];},hc=_0x42a062=>{const _0x1728e2=qr(_0x42a062);if(!_0x1728e2)return;const _0x59fa82=_0x1728e2['lastIndexOf'](':');if(_0x59fa82<=0x0||_0x59fa82+0x1===_0x1728e2['length'])throw new Error('Invalid\x20host\x20'+_0x1728e2+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x4d0dec=parseInt(_0x1728e2['substring'](_0x59fa82+0x1),0xa);return _0x1728e2[0x0]==='['?[_0x1728e2['substring'](0x1,_0x59fa82-0x1),_0x4d0dec]:[_0x1728e2['substring'](0x0,_0x59fa82),_0x4d0dec];},zr=()=>{var _0x440f7d;return(_0x440f7d=Ui())==null?void 0x0:_0x440f7d['config'];},jr=_0x140c4f=>{var _0x3da9df;return(_0x3da9df=Ui())==null?void 0x0:_0x3da9df['_'+_0x140c4f];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x4d839b,_0x387e31)=>{this['resolve']=_0x4d839b,this['reject']=_0x387e31;});}['wrapCallback'](_0x547d5b){return(_0x2f02ea,_0x19fe53)=>{_0x2f02ea?this['reject'](_0x2f02ea):this['resolve'](_0x19fe53),typeof _0x547d5b=='function'&&(this['promise']['catch'](()=>{}),_0x547d5b['length']===0x1?_0x547d5b(_0x2f02ea):_0x547d5b(_0x2f02ea,_0x19fe53));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x3b1647,_0x68eac7){if(_0x3b1647['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x109411={'alg':'none','type':'JWT'},_0x4a7b7b=_0x68eac7||'demo-project',_0x42b72e=_0x3b1647['iat']||0x0,_0x297684=_0x3b1647['sub']||_0x3b1647['user_id'];if(!_0x297684)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x37fb98={'iss':'https://securetoken.google.com/'+_0x4a7b7b,'aud':_0x4a7b7b,'iat':_0x42b72e,'exp':_0x42b72e+0xe10,'auth_time':_0x42b72e,'sub':_0x297684,'user_id':_0x297684,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x3b1647};return[dn(JSON['stringify'](_0x109411)),dn(JSON['stringify'](_0x37fb98)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x570533=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x570533=='object'&&_0x570533['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x1cb7d0=W();return _0x1cb7d0['indexOf']('MSIE\x20')>=0x0||_0x1cb7d0['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x36d764,_0x165311)=>{try{let _0x2691e6=!0x0;const _0x1fec47='validate-browser-context-for-indexeddb-analytics-module',_0x2505e3=self['indexedDB']['open'](_0x1fec47);_0x2505e3['onsuccess']=()=>{_0x2505e3['result']['close'](),_0x2691e6||self['indexedDB']['deleteDatabase'](_0x1fec47),_0x36d764(!0x0);},_0x2505e3['onupgradeneeded']=()=>{_0x2691e6=!0x1;},_0x2505e3['onerror']=()=>{var _0x236abb;_0x165311(((_0x236abb=_0x2505e3['error'])==null?void 0x0:_0x236abb['message'])||'');};}catch(_0xa13c1a){_0x165311(_0xa13c1a);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x2a0438,_0x4e1312,_0x2b738a){super(_0x4e1312),this['code']=_0x2a0438,this['customData']=_0x2b738a,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0xb5dcb4,_0x3f258f,_0x52e801){this['service']=_0xb5dcb4,this['serviceName']=_0x3f258f,this['errors']=_0x52e801;}['create'](_0x33bfa0,..._0x2e6659){const _0x3362ad=_0x2e6659[0x0]||{},_0x42da47=this['service']+'/'+_0x33bfa0,_0xd7de03=this['errors'][_0x33bfa0],_0x2ccde9=_0xd7de03?vc(_0xd7de03,_0x3362ad):'Error',_0x16a854=this['serviceName']+':\x20'+_0x2ccde9+'\x20('+_0x42da47+').';return new Re(_0x42da47,_0x16a854,_0x3362ad);}}function vc(_0x2c48ea,_0x397ae6){return _0x2c48ea['replace'](Ec,(_0x30e31e,_0x3a6f27)=>{const _0x48590e=_0x397ae6[_0x3a6f27];return _0x48590e!=null?String(_0x48590e):'<'+_0x3a6f27+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x30f6d2){return JSON['parse'](_0x30f6d2);}function O(_0x2dbcb9){return JSON['stringify'](_0x2dbcb9);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x39f8d3){let _0xa8f078={},_0x4a33f9={},_0x36388e={},_0x132788='';try{const _0x2c724d=_0x39f8d3['split']('.');_0xa8f078=Nt(fn(_0x2c724d[0x0])||''),_0x4a33f9=Nt(fn(_0x2c724d[0x1])||''),_0x132788=_0x2c724d[0x2],_0x36388e=_0x4a33f9['d']||{},delete _0x4a33f9['d'];}catch{}return{'header':_0xa8f078,'claims':_0x4a33f9,'data':_0x36388e,'signature':_0x132788};},Ic=function(_0x2c52cc){const _0x8bf40a=Yr(_0x2c52cc),_0x7b60b4=_0x8bf40a['claims'];return!!_0x7b60b4&&typeof _0x7b60b4=='object'&&_0x7b60b4['hasOwnProperty']('iat');},wc=function(_0x46ecbd){const _0xc1f1fa=Yr(_0x46ecbd)['claims'];return typeof _0xc1f1fa=='object'&&_0xc1f1fa['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x116b3f,_0x36a1c2){return Object['prototype']['hasOwnProperty']['call'](_0x116b3f,_0x36a1c2);}function Le(_0x5b38f7,_0x4850d8){if(Object['prototype']['hasOwnProperty']['call'](_0x5b38f7,_0x4850d8))return _0x5b38f7[_0x4850d8];}function pn(_0x34dcaf){for(const _0x6d58d in _0x34dcaf)if(Object['prototype']['hasOwnProperty']['call'](_0x34dcaf,_0x6d58d))return!0x1;return!0x0;}function _n(_0xe681e5,_0x2319ab,_0x28aa5d){const _0x3366a1={};for(const _0x2418ee in _0xe681e5)Object['prototype']['hasOwnProperty']['call'](_0xe681e5,_0x2418ee)&&(_0x3366a1[_0x2418ee]=_0x2319ab['call'](_0x28aa5d,_0xe681e5[_0x2418ee],_0x2418ee,_0xe681e5));return _0x3366a1;}function xe(_0x1ed968,_0x181d23){if(_0x1ed968===_0x181d23)return!0x0;const _0x346467=Object['keys'](_0x1ed968),_0x32e6f2=Object['keys'](_0x181d23);for(const _0xe89c67 of _0x346467){if(!_0x32e6f2['includes'](_0xe89c67))return!0x1;const _0x3dbed9=_0x1ed968[_0xe89c67],_0x5285e4=_0x181d23[_0xe89c67];if(Ns(_0x3dbed9)&&Ns(_0x5285e4)){if(!xe(_0x3dbed9,_0x5285e4))return!0x1;}else{if(_0x3dbed9!==_0x5285e4)return!0x1;}}for(const _0x1f7ac6 of _0x32e6f2)if(!_0x346467['includes'](_0x1f7ac6))return!0x1;return!0x0;}function Ns(_0x379707){return _0x379707!==null&&typeof _0x379707=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x52a6db){const _0xd66166=[];for(const [_0xc43f,_0x311c09]of Object['entries'](_0x52a6db))Array['isArray'](_0x311c09)?_0x311c09['forEach'](_0x4fe9cb=>{_0xd66166['push'](encodeURIComponent(_0xc43f)+'='+encodeURIComponent(_0x4fe9cb));}):_0xd66166['push'](encodeURIComponent(_0xc43f)+'='+encodeURIComponent(_0x311c09));return _0xd66166['length']?'&'+_0xd66166['join']('&'):'';}function Ct(_0x41b36e){const _0x180731={};return _0x41b36e['replace'](/^\?/,'')['split']('&')['forEach'](_0x1399fc=>{if(_0x1399fc){const [_0x1b4231,_0x575c4c]=_0x1399fc['split']('=');_0x180731[decodeURIComponent(_0x1b4231)]=decodeURIComponent(_0x575c4c);}}),_0x180731;}function Tt(_0x44f118){const _0x4fe163=_0x44f118['indexOf']('?');if(!_0x4fe163)return'';const _0x37027b=_0x44f118['indexOf']('#',_0x4fe163);return _0x44f118['substring'](_0x4fe163,_0x37027b>0x0?_0x37027b:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0xbbf5bc=0x1;_0xbbf5bc<this['blockSize'];++_0xbbf5bc)this['pad_'][_0xbbf5bc]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x1b9298,_0x55615f){_0x55615f||(_0x55615f=0x0);const _0x1e1ca7=this['W_'];if(typeof _0x1b9298=='string'){for(let _0x417525=0x0;_0x417525<0x10;_0x417525++)_0x1e1ca7[_0x417525]=_0x1b9298['charCodeAt'](_0x55615f)<<0x18|_0x1b9298['charCodeAt'](_0x55615f+0x1)<<0x10|_0x1b9298['charCodeAt'](_0x55615f+0x2)<<0x8|_0x1b9298['charCodeAt'](_0x55615f+0x3),_0x55615f+=0x4;}else{for(let _0x57e22e=0x0;_0x57e22e<0x10;_0x57e22e++)_0x1e1ca7[_0x57e22e]=_0x1b9298[_0x55615f]<<0x18|_0x1b9298[_0x55615f+0x1]<<0x10|_0x1b9298[_0x55615f+0x2]<<0x8|_0x1b9298[_0x55615f+0x3],_0x55615f+=0x4;}for(let _0x9d1709=0x10;_0x9d1709<0x50;_0x9d1709++){const _0x9f9223=_0x1e1ca7[_0x9d1709-0x3]^_0x1e1ca7[_0x9d1709-0x8]^_0x1e1ca7[_0x9d1709-0xe]^_0x1e1ca7[_0x9d1709-0x10];_0x1e1ca7[_0x9d1709]=(_0x9f9223<<0x1|_0x9f9223>>>0x1f)&0xffffffff;}let _0x3f3c1a=this['chain_'][0x0],_0x24b8c3=this['chain_'][0x1],_0x5a865b=this['chain_'][0x2],_0x4179d2=this['chain_'][0x3],_0xf39fba=this['chain_'][0x4],_0x347a62,_0x28d991;for(let _0x3f2980=0x0;_0x3f2980<0x50;_0x3f2980++){_0x3f2980<0x28?_0x3f2980<0x14?(_0x347a62=_0x4179d2^_0x24b8c3&(_0x5a865b^_0x4179d2),_0x28d991=0x5a827999):(_0x347a62=_0x24b8c3^_0x5a865b^_0x4179d2,_0x28d991=0x6ed9eba1):_0x3f2980<0x3c?(_0x347a62=_0x24b8c3&_0x5a865b|_0x4179d2&(_0x24b8c3|_0x5a865b),_0x28d991=0x8f1bbcdc):(_0x347a62=_0x24b8c3^_0x5a865b^_0x4179d2,_0x28d991=0xca62c1d6);const _0x1f127d=(_0x3f3c1a<<0x5|_0x3f3c1a>>>0x1b)+_0x347a62+_0xf39fba+_0x28d991+_0x1e1ca7[_0x3f2980]&0xffffffff;_0xf39fba=_0x4179d2,_0x4179d2=_0x5a865b,_0x5a865b=(_0x24b8c3<<0x1e|_0x24b8c3>>>0x2)&0xffffffff,_0x24b8c3=_0x3f3c1a,_0x3f3c1a=_0x1f127d;}this['chain_'][0x0]=this['chain_'][0x0]+_0x3f3c1a&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x24b8c3&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x5a865b&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x4179d2&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0xf39fba&0xffffffff;}['update'](_0x5e69f2,_0x22fbcb){if(_0x5e69f2==null)return;_0x22fbcb===void 0x0&&(_0x22fbcb=_0x5e69f2['length']);const _0x5a1ac3=_0x22fbcb-this['blockSize'];let _0x4f83b4=0x0;const _0x5df62f=this['buf_'];let _0x1c2181=this['inbuf_'];for(;_0x4f83b4<_0x22fbcb;){if(_0x1c2181===0x0){for(;_0x4f83b4<=_0x5a1ac3;)this['compress_'](_0x5e69f2,_0x4f83b4),_0x4f83b4+=this['blockSize'];}if(typeof _0x5e69f2=='string'){for(;_0x4f83b4<_0x22fbcb;)if(_0x5df62f[_0x1c2181]=_0x5e69f2['charCodeAt'](_0x4f83b4),++_0x1c2181,++_0x4f83b4,_0x1c2181===this['blockSize']){this['compress_'](_0x5df62f),_0x1c2181=0x0;break;}}else{for(;_0x4f83b4<_0x22fbcb;)if(_0x5df62f[_0x1c2181]=_0x5e69f2[_0x4f83b4],++_0x1c2181,++_0x4f83b4,_0x1c2181===this['blockSize']){this['compress_'](_0x5df62f),_0x1c2181=0x0;break;}}}this['inbuf_']=_0x1c2181,this['total_']+=_0x22fbcb;}['digest'](){const _0x12ff3f=[];let _0x4c960c=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x44da49=this['blockSize']-0x1;_0x44da49>=0x38;_0x44da49--)this['buf_'][_0x44da49]=_0x4c960c&0xff,_0x4c960c/=0x100;this['compress_'](this['buf_']);let _0x33d351=0x0;for(let _0x44832d=0x0;_0x44832d<0x5;_0x44832d++)for(let _0x25fac4=0x18;_0x25fac4>=0x0;_0x25fac4-=0x8)_0x12ff3f[_0x33d351]=this['chain_'][_0x44832d]>>_0x25fac4&0xff,++_0x33d351;return _0x12ff3f;}}function Tc(_0x16938a,_0x3dbe1d){const _0xcdc4cb=new Sc(_0x16938a,_0x3dbe1d);return _0xcdc4cb['subscribe']['bind'](_0xcdc4cb);}class Sc{constructor(_0x44155c,_0x26a2e0){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x26a2e0,this['task']['then'](()=>{_0x44155c(this);})['catch'](_0x350591=>{this['error'](_0x350591);});}['next'](_0x2b66eb){this['forEachObserver'](_0x1c0d0c=>{_0x1c0d0c['next'](_0x2b66eb);});}['error'](_0x4ec861){this['forEachObserver'](_0x1688ad=>{_0x1688ad['error'](_0x4ec861);}),this['close'](_0x4ec861);}['complete'](){this['forEachObserver'](_0x166efb=>{_0x166efb['complete']();}),this['close']();}['subscribe'](_0x3ca1e1,_0x230539,_0x40544e){let _0x61d250;if(_0x3ca1e1===void 0x0&&_0x230539===void 0x0&&_0x40544e===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x3ca1e1,['next','error','complete'])?_0x61d250=_0x3ca1e1:_0x61d250={'next':_0x3ca1e1,'error':_0x230539,'complete':_0x40544e},_0x61d250['next']===void 0x0&&(_0x61d250['next']=ti),_0x61d250['error']===void 0x0&&(_0x61d250['error']=ti),_0x61d250['complete']===void 0x0&&(_0x61d250['complete']=ti);const _0x5ad4a1=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x61d250['error'](this['finalError']):_0x61d250['complete']();}catch{}}),this['observers']['push'](_0x61d250),_0x5ad4a1;}['unsubscribeOne'](_0x597a3b){this['observers']===void 0x0||this['observers'][_0x597a3b]===void 0x0||(delete this['observers'][_0x597a3b],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x3de041){if(!this['finalized']){for(let _0x4a31e7=0x0;_0x4a31e7<this['observers']['length'];_0x4a31e7++)this['sendOne'](_0x4a31e7,_0x3de041);}}['sendOne'](_0x227b41,_0x4d505e){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x227b41]!==void 0x0)try{_0x4d505e(this['observers'][_0x227b41]);}catch(_0x1a81d4){typeof console<'u'&&console['error']&&console['error'](_0x1a81d4);}});}['close'](_0x59c590){this['finalized']||(this['finalized']=!0x0,_0x59c590!==void 0x0&&(this['finalError']=_0x59c590),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x412982,_0x59faaf){if(typeof _0x412982!='object'||_0x412982===null)return!0x1;for(const _0x34da03 of _0x59faaf)if(_0x34da03 in _0x412982&&typeof _0x412982[_0x34da03]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x58f5e9,_0x14ac9f){return _0x58f5e9+'\x20failed:\x20'+_0x14ac9f+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x2c7c58){const _0x1239b0=[];let _0x5074b1=0x0;for(let _0x16b1a3=0x0;_0x16b1a3<_0x2c7c58['length'];_0x16b1a3++){let _0x412749=_0x2c7c58['charCodeAt'](_0x16b1a3);if(_0x412749>=0xd800&&_0x412749<=0xdbff){const _0x3e5a39=_0x412749-0xd800;_0x16b1a3++,f(_0x16b1a3<_0x2c7c58['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x62d5bb=_0x2c7c58['charCodeAt'](_0x16b1a3)-0xdc00;_0x412749=0x10000+(_0x3e5a39<<0xa)+_0x62d5bb;}_0x412749<0x80?_0x1239b0[_0x5074b1++]=_0x412749:_0x412749<0x800?(_0x1239b0[_0x5074b1++]=_0x412749>>0x6|0xc0,_0x1239b0[_0x5074b1++]=_0x412749&0x3f|0x80):_0x412749<0x10000?(_0x1239b0[_0x5074b1++]=_0x412749>>0xc|0xe0,_0x1239b0[_0x5074b1++]=_0x412749>>0x6&0x3f|0x80,_0x1239b0[_0x5074b1++]=_0x412749&0x3f|0x80):(_0x1239b0[_0x5074b1++]=_0x412749>>0x12|0xf0,_0x1239b0[_0x5074b1++]=_0x412749>>0xc&0x3f|0x80,_0x1239b0[_0x5074b1++]=_0x412749>>0x6&0x3f|0x80,_0x1239b0[_0x5074b1++]=_0x412749&0x3f|0x80);}return _0x1239b0;},Ln=function(_0x27a4ed){let _0x3a10d1=0x0;for(let _0x56872c=0x0;_0x56872c<_0x27a4ed['length'];_0x56872c++){const _0x5af071=_0x27a4ed['charCodeAt'](_0x56872c);_0x5af071<0x80?_0x3a10d1++:_0x5af071<0x800?_0x3a10d1+=0x2:_0x5af071>=0xd800&&_0x5af071<=0xdbff?(_0x3a10d1+=0x4,_0x56872c++):_0x3a10d1+=0x3;}return _0x3a10d1;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x2c7d25){return _0x2c7d25&&_0x2c7d25['_delegate']?_0x2c7d25['_delegate']:_0x2c7d25;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x4a7bc3){try{return(_0x4a7bc3['startsWith']('http://')||_0x4a7bc3['startsWith']('https://')?new URL(_0x4a7bc3)['hostname']:_0x4a7bc3)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x2a50ad){return(await fetch(_0x2a50ad,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x22fd7f,_0x118acf,_0x106366){this['name']=_0x22fd7f,this['instanceFactory']=_0x118acf,this['type']=_0x106366,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x268692){return this['instantiationMode']=_0x268692,this;}['setMultipleInstances'](_0x2870f0){return this['multipleInstances']=_0x2870f0,this;}['setServiceProps'](_0x5ca03a){return this['serviceProps']=_0x5ca03a,this;}['setInstanceCreatedCallback'](_0x51a5b2){return this['onInstanceCreated']=_0x51a5b2,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0xce5bcd,_0x76119c){this['name']=_0xce5bcd,this['container']=_0x76119c,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x2a6a4c){const _0x2555f8=this['normalizeInstanceIdentifier'](_0x2a6a4c);if(!this['instancesDeferred']['has'](_0x2555f8)){const _0x31ba95=new H();if(this['instancesDeferred']['set'](_0x2555f8,_0x31ba95),this['isInitialized'](_0x2555f8)||this['shouldAutoInitialize']())try{const _0x43778f=this['getOrInitializeService']({'instanceIdentifier':_0x2555f8});_0x43778f&&_0x31ba95['resolve'](_0x43778f);}catch{}}return this['instancesDeferred']['get'](_0x2555f8)['promise'];}['getImmediate'](_0x54be06){const _0x4d9480=this['normalizeInstanceIdentifier'](_0x54be06==null?void 0x0:_0x54be06['identifier']),_0x4f9860=(_0x54be06==null?void 0x0:_0x54be06['optional'])??!0x1;if(this['isInitialized'](_0x4d9480)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x4d9480});}catch(_0x24b4e1){if(_0x4f9860)return null;throw _0x24b4e1;}else{if(_0x4f9860)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x2ee276){if(_0x2ee276['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x2ee276['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x2ee276,!!this['shouldAutoInitialize']()){if(Pc(_0x2ee276))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x214c98,_0x430795]of this['instancesDeferred']['entries']()){const _0x5d6680=this['normalizeInstanceIdentifier'](_0x214c98);try{const _0x26913e=this['getOrInitializeService']({'instanceIdentifier':_0x5d6680});_0x430795['resolve'](_0x26913e);}catch{}}}}['clearInstance'](_0x1c11d1=Ne){this['instancesDeferred']['delete'](_0x1c11d1),this['instancesOptions']['delete'](_0x1c11d1),this['instances']['delete'](_0x1c11d1);}async['delete'](){const _0x1e8f61=Array['from'](this['instances']['values']());await Promise['all']([..._0x1e8f61['filter'](_0x30c743=>'INTERNAL'in _0x30c743)['map'](_0x38d30a=>_0x38d30a['INTERNAL']['delete']()),..._0x1e8f61['filter'](_0x558629=>'_delete'in _0x558629)['map'](_0x1218cc=>_0x1218cc['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x185987=Ne){return this['instances']['has'](_0x185987);}['getOptions'](_0x5b850e=Ne){return this['instancesOptions']['get'](_0x5b850e)||{};}['initialize'](_0x3d3e0a={}){const {options:_0x75417a={}}=_0x3d3e0a,_0x193755=this['normalizeInstanceIdentifier'](_0x3d3e0a['instanceIdentifier']);if(this['isInitialized'](_0x193755))throw Error(this['name']+'('+_0x193755+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x1179f1=this['getOrInitializeService']({'instanceIdentifier':_0x193755,'options':_0x75417a});for(const [_0x1ac13b,_0x488726]of this['instancesDeferred']['entries']()){const _0xcc471b=this['normalizeInstanceIdentifier'](_0x1ac13b);_0x193755===_0xcc471b&&_0x488726['resolve'](_0x1179f1);}return _0x1179f1;}['onInit'](_0x4217f7,_0x495edf){const _0x4b24e9=this['normalizeInstanceIdentifier'](_0x495edf),_0xa53262=this['onInitCallbacks']['get'](_0x4b24e9)??new Set();_0xa53262['add'](_0x4217f7),this['onInitCallbacks']['set'](_0x4b24e9,_0xa53262);const _0x391822=this['instances']['get'](_0x4b24e9);return _0x391822&&_0x4217f7(_0x391822,_0x4b24e9),()=>{_0xa53262['delete'](_0x4217f7);};}['invokeOnInitCallbacks'](_0x756fa2,_0x281ccc){const _0x25388e=this['onInitCallbacks']['get'](_0x281ccc);if(_0x25388e){for(const _0x2fe5cc of _0x25388e)try{_0x2fe5cc(_0x756fa2,_0x281ccc);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x2ecfc7,options:_0x2003de={}}){let _0x5528ed=this['instances']['get'](_0x2ecfc7);if(!_0x5528ed&&this['component']&&(_0x5528ed=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x2ecfc7),'options':_0x2003de}),this['instances']['set'](_0x2ecfc7,_0x5528ed),this['instancesOptions']['set'](_0x2ecfc7,_0x2003de),this['invokeOnInitCallbacks'](_0x5528ed,_0x2ecfc7),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x2ecfc7,_0x5528ed);}catch{}return _0x5528ed||null;}['normalizeInstanceIdentifier'](_0x88e5d3=Ne){return this['component']?this['component']['multipleInstances']?_0x88e5d3:Ne:_0x88e5d3;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x2fbabe){return _0x2fbabe===Ne?void 0x0:_0x2fbabe;}function Pc(_0x540b8a){return _0x540b8a['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x2737fa){this['name']=_0x2737fa,this['providers']=new Map();}['addComponent'](_0xc235c7){const _0x143fab=this['getProvider'](_0xc235c7['name']);if(_0x143fab['isComponentSet']())throw new Error('Component\x20'+_0xc235c7['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x143fab['setComponent'](_0xc235c7);}['addOrOverwriteComponent'](_0x28e9a4){this['getProvider'](_0x28e9a4['name'])['isComponentSet']()&&this['providers']['delete'](_0x28e9a4['name']),this['addComponent'](_0x28e9a4);}['getProvider'](_0x540590){if(this['providers']['has'](_0x540590))return this['providers']['get'](_0x540590);const _0x390da8=new Ac(_0x540590,this);return this['providers']['set'](_0x540590,_0x390da8),_0x390da8;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x51f4d0){_0x51f4d0[_0x51f4d0['DEBUG']=0x0]='DEBUG',_0x51f4d0[_0x51f4d0['VERBOSE']=0x1]='VERBOSE',_0x51f4d0[_0x51f4d0['INFO']=0x2]='INFO',_0x51f4d0[_0x51f4d0['WARN']=0x3]='WARN',_0x51f4d0[_0x51f4d0['ERROR']=0x4]='ERROR',_0x51f4d0[_0x51f4d0['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x5f2ee9,_0x425910,..._0x29e897)=>{if(_0x425910<_0x5f2ee9['logLevel'])return;const _0x22acea=new Date()['toISOString'](),_0x106d5e=Mc[_0x425910];if(_0x106d5e)console[_0x106d5e]('['+_0x22acea+']\x20\x20'+_0x5f2ee9['name']+':',..._0x29e897);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x425910+')');};class Bi{constructor(_0x34b955){this['name']=_0x34b955,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x2d632a){if(!(_0x2d632a in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x2d632a+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x2d632a;}['setLogLevel'](_0x2f2a74){this['_logLevel']=typeof _0x2f2a74=='string'?Oc[_0x2f2a74]:_0x2f2a74;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x3cf4f4){if(typeof _0x3cf4f4!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x3cf4f4;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x1f78f5){this['_userLogHandler']=_0x1f78f5;}['debug'](..._0x1437dd){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x1437dd),this['_logHandler'](this,T['DEBUG'],..._0x1437dd);}['log'](..._0xe61f05){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0xe61f05),this['_logHandler'](this,T['VERBOSE'],..._0xe61f05);}['info'](..._0x3c8391){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x3c8391),this['_logHandler'](this,T['INFO'],..._0x3c8391);}['warn'](..._0x46bc52){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x46bc52),this['_logHandler'](this,T['WARN'],..._0x46bc52);}['error'](..._0x8a0334){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x8a0334),this['_logHandler'](this,T['ERROR'],..._0x8a0334);}}const xc=(_0x22b49d,_0x3c280b)=>_0x3c280b['some'](_0x5ad0b4=>_0x22b49d instanceof _0x5ad0b4);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x26be0d){const _0x2f181c=new Promise((_0x45e1f9,_0x39dd4b)=>{const _0x34a515=()=>{_0x26be0d['removeEventListener']('success',_0x59d412),_0x26be0d['removeEventListener']('error',_0x554896);},_0x59d412=()=>{_0x45e1f9(ge(_0x26be0d['result'])),_0x34a515();},_0x554896=()=>{_0x39dd4b(_0x26be0d['error']),_0x34a515();};_0x26be0d['addEventListener']('success',_0x59d412),_0x26be0d['addEventListener']('error',_0x554896);});return _0x2f181c['then'](_0x492c49=>{_0x492c49 instanceof IDBCursor&&Jr['set'](_0x492c49,_0x26be0d);})['catch'](()=>{}),Vi['set'](_0x2f181c,_0x26be0d),_0x2f181c;}function Bc(_0x1a9d82){if(_i['has'](_0x1a9d82))return;const _0xad1aec=new Promise((_0x4d3401,_0x31f092)=>{const _0x82205f=()=>{_0x1a9d82['removeEventListener']('complete',_0x2fc46b),_0x1a9d82['removeEventListener']('error',_0x26f986),_0x1a9d82['removeEventListener']('abort',_0x26f986);},_0x2fc46b=()=>{_0x4d3401(),_0x82205f();},_0x26f986=()=>{_0x31f092(_0x1a9d82['error']||new DOMException('AbortError','AbortError')),_0x82205f();};_0x1a9d82['addEventListener']('complete',_0x2fc46b),_0x1a9d82['addEventListener']('error',_0x26f986),_0x1a9d82['addEventListener']('abort',_0x26f986);});_i['set'](_0x1a9d82,_0xad1aec);}let gi={'get'(_0x34120e,_0x217e42,_0x2c190f){if(_0x34120e instanceof IDBTransaction){if(_0x217e42==='done')return _i['get'](_0x34120e);if(_0x217e42==='objectStoreNames')return _0x34120e['objectStoreNames']||Xr['get'](_0x34120e);if(_0x217e42==='store')return _0x2c190f['objectStoreNames'][0x1]?void 0x0:_0x2c190f['objectStore'](_0x2c190f['objectStoreNames'][0x0]);}return ge(_0x34120e[_0x217e42]);},'set'(_0x3dd3d2,_0x27b300,_0x3b7b52){return _0x3dd3d2[_0x27b300]=_0x3b7b52,!0x0;},'has'(_0x5732ba,_0x487138){return _0x5732ba instanceof IDBTransaction&&(_0x487138==='done'||_0x487138==='store')?!0x0:_0x487138 in _0x5732ba;}};function Vc(_0x5be802){gi=_0x5be802(gi);}function Hc(_0x500afa){return _0x500afa===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x48e461,..._0x300e7c){const _0xd227f4=_0x500afa['call'](ii(this),_0x48e461,..._0x300e7c);return Xr['set'](_0xd227f4,_0x48e461['sort']?_0x48e461['sort']():[_0x48e461]),ge(_0xd227f4);}:Uc()['includes'](_0x500afa)?function(..._0x3b6333){return _0x500afa['apply'](ii(this),_0x3b6333),ge(Jr['get'](this));}:function(..._0x47d47d){return ge(_0x500afa['apply'](ii(this),_0x47d47d));};}function $c(_0x4a57f){return typeof _0x4a57f=='function'?Hc(_0x4a57f):(_0x4a57f instanceof IDBTransaction&&Bc(_0x4a57f),xc(_0x4a57f,Fc())?new Proxy(_0x4a57f,gi):_0x4a57f);}function ge(_0x20a23d){if(_0x20a23d instanceof IDBRequest)return Wc(_0x20a23d);if(ni['has'](_0x20a23d))return ni['get'](_0x20a23d);const _0x38f3ec=$c(_0x20a23d);return _0x38f3ec!==_0x20a23d&&(ni['set'](_0x20a23d,_0x38f3ec),Vi['set'](_0x38f3ec,_0x20a23d)),_0x38f3ec;}const ii=_0x18b16f=>Vi['get'](_0x18b16f);function Gc(_0x58bab9,_0x582bc8,{blocked:_0x378a94,upgrade:_0x3b61e1,blocking:_0x433a34,terminated:_0x532ce0}={}){const _0x577a25=indexedDB['open'](_0x58bab9,_0x582bc8),_0x4e872a=ge(_0x577a25);return _0x3b61e1&&_0x577a25['addEventListener']('upgradeneeded',_0x4f8b89=>{_0x3b61e1(ge(_0x577a25['result']),_0x4f8b89['oldVersion'],_0x4f8b89['newVersion'],ge(_0x577a25['transaction']),_0x4f8b89);}),_0x378a94&&_0x577a25['addEventListener']('blocked',_0x5d5e59=>_0x378a94(_0x5d5e59['oldVersion'],_0x5d5e59['newVersion'],_0x5d5e59)),_0x4e872a['then'](_0x27b400=>{_0x532ce0&&_0x27b400['addEventListener']('close',()=>_0x532ce0()),_0x433a34&&_0x27b400['addEventListener']('versionchange',_0x267be3=>_0x433a34(_0x267be3['oldVersion'],_0x267be3['newVersion'],_0x267be3));})['catch'](()=>{}),_0x4e872a;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x4bfc91,_0x23a42f){if(!(_0x4bfc91 instanceof IDBDatabase&&!(_0x23a42f in _0x4bfc91)&&typeof _0x23a42f=='string'))return;if(si['get'](_0x23a42f))return si['get'](_0x23a42f);const _0x3f6d57=_0x23a42f['replace'](/FromIndex$/,''),_0x324b7b=_0x23a42f!==_0x3f6d57,_0xe49e9e=zc['includes'](_0x3f6d57);if(!(_0x3f6d57 in(_0x324b7b?IDBIndex:IDBObjectStore)['prototype'])||!(_0xe49e9e||qc['includes'](_0x3f6d57)))return;const _0x31c126=async function(_0x360c42,..._0x511839){const _0x54dae5=this['transaction'](_0x360c42,_0xe49e9e?'readwrite':'readonly');let _0x31670c=_0x54dae5['store'];return _0x324b7b&&(_0x31670c=_0x31670c['index'](_0x511839['shift']())),(await Promise['all']([_0x31670c[_0x3f6d57](..._0x511839),_0xe49e9e&&_0x54dae5['done']]))[0x0];};return si['set'](_0x23a42f,_0x31c126),_0x31c126;}Vc(_0x4bfcf0=>({..._0x4bfcf0,'get':(_0x2a9882,_0x12c1f4,_0x4e28c2)=>Ms(_0x2a9882,_0x12c1f4)||_0x4bfcf0['get'](_0x2a9882,_0x12c1f4,_0x4e28c2),'has':(_0x11e20c,_0x34497e)=>!!Ms(_0x11e20c,_0x34497e)||_0x4bfcf0['has'](_0x11e20c,_0x34497e)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x58dbff){this['container']=_0x58dbff;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x1abe63=>{if(Kc(_0x1abe63)){const _0xcb807b=_0x1abe63['getImmediate']();return _0xcb807b['library']+'/'+_0xcb807b['version'];}else return null;})['filter'](_0x15e965=>_0x15e965)['join']('\x20');}}function Kc(_0x2b2686){const _0x300cdb=_0x2b2686['getComponent']();return(_0x300cdb==null?void 0x0:_0x300cdb['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x20df05,_0x4172e8){try{_0x20df05['container']['addComponent'](_0x4172e8);}catch(_0x4b146b){oe['debug']('Component\x20'+_0x4172e8['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x20df05['name'],_0x4b146b);}}function st(_0x2bb3fd){const _0x4c6c7b=_0x2bb3fd['name'];if(Ei['has'](_0x4c6c7b))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x4c6c7b+'.'),!0x1;Ei['set'](_0x4c6c7b,_0x2bb3fd);for(const _0x3cba71 of Ue['values']())xs(_0x3cba71,_0x2bb3fd);for(const _0x2cd44b of vi['values']())xs(_0x2cd44b,_0x2bb3fd);return!0x0;}function Hi(_0x2d8350,_0x22d062){const _0x1f27c4=_0x2d8350['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x1f27c4&&_0x1f27c4['triggerHeartbeat'](),_0x2d8350['container']['getProvider'](_0x22d062);}function $(_0x14e09f){return _0x14e09f==null?!0x1:_0x14e09f['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0xe4f426,_0x5b1829,_0x3d7751){this['_isDeleted']=!0x1,this['_options']={..._0xe4f426},this['_config']={..._0x5b1829},this['_name']=_0x5b1829['name'],this['_automaticDataCollectionEnabled']=_0x5b1829['automaticDataCollectionEnabled'],this['_container']=_0x3d7751,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x59c244){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x59c244;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x12cc15){this['_isDeleted']=_0x12cc15;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x32e22f,_0x206c53={}){let _0x40cf10=_0x32e22f;typeof _0x206c53!='object'&&(_0x206c53={'name':_0x206c53});const _0x565270={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x206c53},_0x5c0276=_0x565270['name'];if(typeof _0x5c0276!='string'||!_0x5c0276)throw me['create']('bad-app-name',{'appName':String(_0x5c0276)});if(_0x40cf10||(_0x40cf10=zr()),!_0x40cf10)throw me['create']('no-options');const _0x3e3e4c=Ue['get'](_0x5c0276);if(_0x3e3e4c){if(xe(_0x40cf10,_0x3e3e4c['options'])&&xe(_0x565270,_0x3e3e4c['config']))return _0x3e3e4c;throw me['create']('duplicate-app',{'appName':_0x5c0276});}const _0x220841=new Nc(_0x5c0276);for(const _0x8450fb of Ei['values']())_0x220841['addComponent'](_0x8450fb);const _0x1d2eef=new Tl(_0x40cf10,_0x565270,_0x220841);return Ue['set'](_0x5c0276,_0x1d2eef),_0x1d2eef;}function Zr(_0x17e412=yi){const _0x4bdebd=Ue['get'](_0x17e412);if(!_0x4bdebd&&_0x17e412===yi&&zr())return Sl();if(!_0x4bdebd)throw me['create']('no-app',{'appName':_0x17e412});return _0x4bdebd;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x8c3228){let _0x3ed961=!0x1;const _0x4bd346=_0x8c3228['name'];Ue['has'](_0x4bd346)?(_0x3ed961=!0x0,Ue['delete'](_0x4bd346)):vi['has'](_0x4bd346)&&_0x8c3228['decRefCount']()<=0x0&&(vi['delete'](_0x4bd346),_0x3ed961=!0x0),_0x3ed961&&(await Promise['all'](_0x8c3228['container']['getProviders']()['map'](_0x148dc2=>_0x148dc2['delete']())),_0x8c3228['isDeleted']=!0x0);}function ye(_0x216895,_0x330cd3,_0x3d8d15){let _0x12c4f9=wl[_0x216895]??_0x216895;_0x3d8d15&&(_0x12c4f9+='-'+_0x3d8d15);const _0x5de3bb=_0x12c4f9['match'](/\s|\//),_0x579429=_0x330cd3['match'](/\s|\//);if(_0x5de3bb||_0x579429){const _0x34d021=['Unable\x20to\x20register\x20library\x20\x22'+_0x12c4f9+'\x22\x20with\x20version\x20\x22'+_0x330cd3+'\x22:'];_0x5de3bb&&_0x34d021['push']('library\x20name\x20\x22'+_0x12c4f9+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x5de3bb&&_0x579429&&_0x34d021['push']('and'),_0x579429&&_0x34d021['push']('version\x20name\x20\x22'+_0x330cd3+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x34d021['join']('\x20'));return;}st(new Fe(_0x12c4f9+'-version',()=>({'library':_0x12c4f9,'version':_0x330cd3}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x3722e4,_0x3ca2cf)=>{switch(_0x3ca2cf){case 0x0:try{_0x3722e4['createObjectStore'](Ot);}catch(_0x560f99){console['warn'](_0x560f99);}}}})['catch'](_0x28e4d4=>{throw me['create']('idb-open',{'originalErrorMessage':_0x28e4d4['message']});})),ri;}async function Al(_0x3bea43){try{const _0x2cd230=(await eo())['transaction'](Ot),_0x1ffc79=await _0x2cd230['objectStore'](Ot)['get'](to(_0x3bea43));return await _0x2cd230['done'],_0x1ffc79;}catch(_0x407640){if(_0x407640 instanceof Re)oe['warn'](_0x407640['message']);else{const _0x281f21=me['create']('idb-get',{'originalErrorMessage':_0x407640==null?void 0x0:_0x407640['message']});oe['warn'](_0x281f21['message']);}}}async function Fs(_0x1a11e4,_0x118a83){try{const _0x5007ce=(await eo())['transaction'](Ot,'readwrite');await _0x5007ce['objectStore'](Ot)['put'](_0x118a83,to(_0x1a11e4)),await _0x5007ce['done'];}catch(_0x2b7a8c){if(_0x2b7a8c instanceof Re)oe['warn'](_0x2b7a8c['message']);else{const _0x53b851=me['create']('idb-set',{'originalErrorMessage':_0x2b7a8c==null?void 0x0:_0x2b7a8c['message']});oe['warn'](_0x53b851['message']);}}}function to(_0x1d212e){return _0x1d212e['name']+'!'+_0x1d212e['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x155fa4){this['container']=_0x155fa4,this['_heartbeatsCache']=null;const _0x3fb8eb=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x3fb8eb),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x2ab49e=>(this['_heartbeatsCache']=_0x2ab49e,_0x2ab49e));}async['triggerHeartbeat'](){var _0x13bde7,_0x590ce0;try{const _0x39240a=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x1244eb=Us();if(((_0x13bde7=this['_heartbeatsCache'])==null?void 0x0:_0x13bde7['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x590ce0=this['_heartbeatsCache'])==null?void 0x0:_0x590ce0['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x1244eb||this['_heartbeatsCache']['heartbeats']['some'](_0x527b90=>_0x527b90['date']===_0x1244eb))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x1244eb,'agent':_0x39240a}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x2c5d26=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x2c5d26,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x2e1fc0){oe['warn'](_0x2e1fc0);}}async['getHeartbeatsHeader'](){var _0x34f00f;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x34f00f=this['_heartbeatsCache'])==null?void 0x0:_0x34f00f['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x2e9702=Us(),{heartbeatsToSend:_0x47f620,unsentEntries:_0x203d00}=Ol(this['_heartbeatsCache']['heartbeats']),_0x37c3ed=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x47f620}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x2e9702,_0x203d00['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x203d00,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x37c3ed;}catch(_0x9b5126){return oe['warn'](_0x9b5126),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x5233ad,_0x318bfb=kl){const _0xf549af=[];let _0x2125f3=_0x5233ad['slice']();for(const _0x4399c7 of _0x5233ad){const _0x349bd6=_0xf549af['find'](_0x5c0d5e=>_0x5c0d5e['agent']===_0x4399c7['agent']);if(_0x349bd6){if(_0x349bd6['dates']['push'](_0x4399c7['date']),Ws(_0xf549af)>_0x318bfb){_0x349bd6['dates']['pop']();break;}}else{if(_0xf549af['push']({'agent':_0x4399c7['agent'],'dates':[_0x4399c7['date']]}),Ws(_0xf549af)>_0x318bfb){_0xf549af['pop']();break;}}_0x2125f3=_0x2125f3['slice'](0x1);}return{'heartbeatsToSend':_0xf549af,'unsentEntries':_0x2125f3};}class Dl{constructor(_0x558553){this['app']=_0x558553,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x198cee=await Al(this['app']);return _0x198cee!=null&&_0x198cee['heartbeats']?_0x198cee:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x4dbd35){if(await this['_canUseIndexedDBPromise']){const _0x18cbcd=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x4dbd35['lastSentHeartbeatDate']??_0x18cbcd['lastSentHeartbeatDate'],'heartbeats':_0x4dbd35['heartbeats']});}else return;}async['add'](_0x495c25){if(await this['_canUseIndexedDBPromise']){const _0x150524=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x495c25['lastSentHeartbeatDate']??_0x150524['lastSentHeartbeatDate'],'heartbeats':[..._0x150524['heartbeats'],..._0x495c25['heartbeats']]});}else return;}}function Ws(_0x3b60d4){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x3b60d4}))['length'];}function Ml(_0x5da706){if(_0x5da706['length']===0x0)return-0x1;let _0x1ea1ab=0x0,_0x27a212=_0x5da706[0x0]['date'];for(let _0x78339c=0x1;_0x78339c<_0x5da706['length'];_0x78339c++)_0x5da706[_0x78339c]['date']<_0x27a212&&(_0x27a212=_0x5da706[_0x78339c]['date'],_0x1ea1ab=_0x78339c);return _0x1ea1ab;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x4078b2){st(new Fe('platform-logger',_0x39d2b7=>new jc(_0x39d2b7),'PRIVATE')),st(new Fe('heartbeat',_0x3542a2=>new Nl(_0x3542a2),'PRIVATE')),ye(mi,Ls,_0x4078b2),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x2b9186){no=_0x2b9186;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x2cccc7){this['domStorage_']=_0x2cccc7,this['prefix_']='firebase:';}['set'](_0x59f3a7,_0x4cdfe6){_0x4cdfe6==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x59f3a7)):this['domStorage_']['setItem'](this['prefixedName_'](_0x59f3a7),O(_0x4cdfe6));}['get'](_0x2e1f11){const _0x30ca24=this['domStorage_']['getItem'](this['prefixedName_'](_0x2e1f11));return _0x30ca24==null?null:Nt(_0x30ca24);}['remove'](_0x581afb){this['domStorage_']['removeItem'](this['prefixedName_'](_0x581afb));}['prefixedName_'](_0x38e94f){return this['prefix_']+_0x38e94f;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x37d069,_0x1a6f56){_0x1a6f56==null?delete this['cache_'][_0x37d069]:this['cache_'][_0x37d069]=_0x1a6f56;}['get'](_0x376365){return Q(this['cache_'],_0x376365)?this['cache_'][_0x376365]:null;}['remove'](_0x4f3aae){delete this['cache_'][_0x4f3aae];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x6c1006){try{if(typeof window<'u'&&typeof window[_0x6c1006]<'u'){const _0x3c3606=window[_0x6c1006];return _0x3c3606['setItem']('firebase:sentinel','cache'),_0x3c3606['removeItem']('firebase:sentinel'),new Wl(_0x3c3606);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0xcfa079=0x1;return function(){return _0xcfa079++;};}()),ro=function(_0x5cb8d1){const _0x830050=Rc(_0x5cb8d1),_0x2d26d0=new Cc();_0x2d26d0['update'](_0x830050);const _0xdb1ff5=_0x2d26d0['digest']();return Fi['encodeByteArray'](_0xdb1ff5);},zt=function(..._0x2c9949){let _0x4d4713='';for(let _0x1c6244=0x0;_0x1c6244<_0x2c9949['length'];_0x1c6244++){const _0x792f01=_0x2c9949[_0x1c6244];Array['isArray'](_0x792f01)||_0x792f01&&typeof _0x792f01=='object'&&typeof _0x792f01['length']=='number'?_0x4d4713+=zt['apply'](null,_0x792f01):typeof _0x792f01=='object'?_0x4d4713+=O(_0x792f01):_0x4d4713+=_0x792f01,_0x4d4713+='\x20';}return _0x4d4713;};let St=null,$s=!0x0;const Hl=function(_0x3687e9,_0x36dc14){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x178377){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x32be0e=zt['apply'](null,_0x178377);St(_0x32be0e);}},jt=function(_0x1ae1c9){return function(..._0x1c40e7){L(_0x1ae1c9,..._0x1c40e7);};},Ii=function(..._0x1d67c8){const _0xd60db8='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x1d67c8);Ze['error'](_0xd60db8);},ae=function(..._0x2183a0){const _0x586758='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x2183a0);throw Ze['error'](_0x586758),new Error(_0x586758);},U=function(..._0x2aedef){const _0x233219='FIREBASE\x20WARNING:\x20'+zt(..._0x2aedef);Ze['warn'](_0x233219);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x589513){return typeof _0x589513=='number'&&(_0x589513!==_0x589513||_0x589513===Number['POSITIVE_INFINITY']||_0x589513===Number['NEGATIVE_INFINITY']);},Gl=function(_0x28633a){if(document['readyState']==='complete')_0x28633a();else{let _0x36976e=!0x1;const _0x5f54fc=function(){if(!document['body']){setTimeout(_0x5f54fc,Math['floor'](0xa));return;}_0x36976e||(_0x36976e=!0x0,_0x28633a());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x5f54fc,!0x1),window['addEventListener']('load',_0x5f54fc,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x5f54fc();}),window['attachEvent']('onload',_0x5f54fc));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x5906bb,_0x136741){if(_0x5906bb===_0x136741)return 0x0;if(_0x5906bb===We||_0x136741===we)return-0x1;if(_0x136741===We||_0x5906bb===we)return 0x1;{const _0x1e409c=Gs(_0x5906bb),_0x1e4d0a=Gs(_0x136741);return _0x1e409c!==null?_0x1e4d0a!==null?_0x1e409c-_0x1e4d0a===0x0?_0x5906bb['length']-_0x136741['length']:_0x1e409c-_0x1e4d0a:-0x1:_0x1e4d0a!==null?0x1:_0x5906bb<_0x136741?-0x1:0x1;}},ql=function(_0x48770b,_0x3e6021){return _0x48770b===_0x3e6021?0x0:_0x48770b<_0x3e6021?-0x1:0x1;},vt=function(_0x4ea32d,_0x51c89d){if(_0x51c89d&&_0x4ea32d in _0x51c89d)return _0x51c89d[_0x4ea32d];throw new Error('Missing\x20required\x20key\x20('+_0x4ea32d+')\x20in\x20object:\x20'+O(_0x51c89d));},$i=function(_0x2ed755){if(typeof _0x2ed755!='object'||_0x2ed755===null)return O(_0x2ed755);const _0x1275ea=[];for(const _0x52e060 in _0x2ed755)_0x1275ea['push'](_0x52e060);_0x1275ea['sort']();let _0x49979b='{';for(let _0x339af9=0x0;_0x339af9<_0x1275ea['length'];_0x339af9++)_0x339af9!==0x0&&(_0x49979b+=','),_0x49979b+=O(_0x1275ea[_0x339af9]),_0x49979b+=':',_0x49979b+=$i(_0x2ed755[_0x1275ea[_0x339af9]]);return _0x49979b+='}',_0x49979b;},oo=function(_0x2fb133,_0x47f43e){const _0x5bde15=_0x2fb133['length'];if(_0x5bde15<=_0x47f43e)return[_0x2fb133];const _0xdff45e=[];for(let _0x7af5fd=0x0;_0x7af5fd<_0x5bde15;_0x7af5fd+=_0x47f43e)_0x7af5fd+_0x47f43e>_0x5bde15?_0xdff45e['push'](_0x2fb133['substring'](_0x7af5fd,_0x5bde15)):_0xdff45e['push'](_0x2fb133['substring'](_0x7af5fd,_0x7af5fd+_0x47f43e));return _0xdff45e;};function x(_0x23e948,_0x576839){for(const _0x28d035 in _0x23e948)_0x23e948['hasOwnProperty'](_0x28d035)&&_0x576839(_0x28d035,_0x23e948[_0x28d035]);}const ao=function(_0x51e86a){f(!xn(_0x51e86a),'Invalid\x20JSON\x20number');const _0xeb71ea=0xb,_0x2f7879=0x34,_0x2fb78f=(0x1<<_0xeb71ea-0x1)-0x1;let _0x750211,_0x1aa74f,_0x26ac0d,_0x12beb4,_0x1fa946;_0x51e86a===0x0?(_0x1aa74f=0x0,_0x26ac0d=0x0,_0x750211=0x1/_0x51e86a===-0x1/0x0?0x1:0x0):(_0x750211=_0x51e86a<0x0,_0x51e86a=Math['abs'](_0x51e86a),_0x51e86a>=Math['pow'](0x2,0x1-_0x2fb78f)?(_0x12beb4=Math['min'](Math['floor'](Math['log'](_0x51e86a)/Math['LN2']),_0x2fb78f),_0x1aa74f=_0x12beb4+_0x2fb78f,_0x26ac0d=Math['round'](_0x51e86a*Math['pow'](0x2,_0x2f7879-_0x12beb4)-Math['pow'](0x2,_0x2f7879))):(_0x1aa74f=0x0,_0x26ac0d=Math['round'](_0x51e86a/Math['pow'](0x2,0x1-_0x2fb78f-_0x2f7879))));const _0x11158f=[];for(_0x1fa946=_0x2f7879;_0x1fa946;_0x1fa946-=0x1)_0x11158f['push'](_0x26ac0d%0x2?0x1:0x0),_0x26ac0d=Math['floor'](_0x26ac0d/0x2);for(_0x1fa946=_0xeb71ea;_0x1fa946;_0x1fa946-=0x1)_0x11158f['push'](_0x1aa74f%0x2?0x1:0x0),_0x1aa74f=Math['floor'](_0x1aa74f/0x2);_0x11158f['push'](_0x750211?0x1:0x0),_0x11158f['reverse']();const _0x25bd3a=_0x11158f['join']('');let _0x1eface='';for(_0x1fa946=0x0;_0x1fa946<0x40;_0x1fa946+=0x8){let _0x304a1f=parseInt(_0x25bd3a['substr'](_0x1fa946,0x8),0x2)['toString'](0x10);_0x304a1f['length']===0x1&&(_0x304a1f='0'+_0x304a1f),_0x1eface=_0x1eface+_0x304a1f;}return _0x1eface['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x35c683,_0x726770){let _0x58d61f='Unknown\x20Error';_0x35c683==='too_big'?_0x58d61f='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x35c683==='permission_denied'?_0x58d61f='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x35c683==='unavailable'&&(_0x58d61f='The\x20service\x20is\x20unavailable');const _0x11687f=new Error(_0x35c683+'\x20at\x20'+_0x726770['_path']['toString']()+':\x20'+_0x58d61f);return _0x11687f['code']=_0x35c683['toUpperCase'](),_0x11687f;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x2687ce){if(Yl['test'](_0x2687ce)){const _0x2256bf=Number(_0x2687ce);if(_0x2256bf>=Ql&&_0x2256bf<=Jl)return _0x2256bf;}return null;},ft=function(_0x170bbd){try{_0x170bbd();}catch(_0x2f1046){setTimeout(()=>{const _0x31080c=_0x2f1046['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x31080c),_0x2f1046;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x43decf,_0x381cdb){const _0x44edae=setTimeout(_0x43decf,_0x381cdb);return typeof _0x44edae=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x44edae):typeof _0x44edae=='object'&&_0x44edae['unref']&&_0x44edae['unref'](),_0x44edae;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x506247,_0x496b9d){this['appCheckProvider']=_0x496b9d,this['appName']=_0x506247['name'],$(_0x506247)&&_0x506247['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x506247['settings']['appCheckToken']),this['appCheck']=_0x496b9d==null?void 0x0:_0x496b9d['getImmediate']({'optional':!0x0}),this['appCheck']||_0x496b9d==null||_0x496b9d['get']()['then'](_0x47e4f0=>this['appCheck']=_0x47e4f0);}['getToken'](_0x12c958){if(this['serverAppAppCheckToken']){if(_0x12c958)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x12c958):new Promise((_0x5b24fd,_0x355cc4)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x12c958)['then'](_0x5b24fd,_0x355cc4):_0x5b24fd(null);},0x0);});}['addTokenChangeListener'](_0x452b1b){var _0x503d59;(_0x503d59=this['appCheckProvider'])==null||_0x503d59['get']()['then'](_0x524b00=>_0x524b00['addTokenListener'](_0x452b1b));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x44e4f9,_0x3717eb,_0x273be7){this['appName_']=_0x44e4f9,this['firebaseOptions_']=_0x3717eb,this['authProvider_']=_0x273be7,this['auth_']=null,this['auth_']=_0x273be7['getImmediate']({'optional':!0x0}),this['auth_']||_0x273be7['onInit'](_0x1ca6c8=>this['auth_']=_0x1ca6c8);}['getToken'](_0x245869){return this['auth_']?this['auth_']['getToken'](_0x245869)['catch'](_0x167169=>_0x167169&&_0x167169['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x167169)):new Promise((_0x2f7dd4,_0x78a228)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x245869)['then'](_0x2f7dd4,_0x78a228):_0x2f7dd4(null);},0x0);});}['addTokenChangeListener'](_0x32d56b){this['auth_']?this['auth_']['addAuthTokenListener'](_0x32d56b):this['authProvider_']['get']()['then'](_0x266826=>_0x266826['addAuthTokenListener'](_0x32d56b));}['removeTokenChangeListener'](_0x2a16b1){this['authProvider_']['get']()['then'](_0x3cf393=>_0x3cf393['removeAuthTokenListener'](_0x2a16b1));}['notifyForInvalidToken'](){let _0x4b82d1='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x4b82d1+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x4b82d1+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x4b82d1+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x4b82d1);}}class an{constructor(_0x3708dc){this['accessToken']=_0x3708dc;}['getToken'](_0x2739ca){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x5ac6ee){_0x5ac6ee(this['accessToken']);}['removeTokenChangeListener'](_0x4c360f){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x4664f8,_0x3797e9,_0x17288c,_0x526f6c,_0x5dc6b3=!0x1,_0x38ac30='',_0x343ff7=!0x1,_0x3d9e63=!0x1,_0x531194=null){this['secure']=_0x3797e9,this['namespace']=_0x17288c,this['webSocketOnly']=_0x526f6c,this['nodeAdmin']=_0x5dc6b3,this['persistenceKey']=_0x38ac30,this['includeNamespaceInQueryParams']=_0x343ff7,this['isUsingEmulator']=_0x3d9e63,this['emulatorOptions']=_0x531194,this['_host']=_0x4664f8['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x4664f8)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x54a3d4){_0x54a3d4!==this['internalHost']&&(this['internalHost']=_0x54a3d4,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x3fdb2f=this['toURLString']();return this['persistenceKey']&&(_0x3fdb2f+='<'+this['persistenceKey']+'>'),_0x3fdb2f;}['toURLString'](){const _0x418a74=this['secure']?'https://':'http://',_0x540972=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x418a74+this['host']+'/'+_0x540972;}}function th(_0x2c7439){return _0x2c7439['host']!==_0x2c7439['internalHost']||_0x2c7439['isCustomHost']()||_0x2c7439['includeNamespaceInQueryParams'];}function vo(_0x412b87,_0x166db9,_0x4387fd){f(typeof _0x166db9=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x4387fd=='object','typeof\x20params\x20must\x20==\x20object');let _0xf3e2c5;if(_0x166db9===go)_0xf3e2c5=(_0x412b87['secure']?'wss://':'ws://')+_0x412b87['internalHost']+'/.ws?';else{if(_0x166db9===mo)_0xf3e2c5=(_0x412b87['secure']?'https://':'http://')+_0x412b87['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x166db9);}th(_0x412b87)&&(_0x4387fd['ns']=_0x412b87['namespace']);const _0x1ab554=[];return x(_0x4387fd,(_0x7cfb05,_0x700ef2)=>{_0x1ab554['push'](_0x7cfb05+'='+_0x700ef2);}),_0xf3e2c5+_0x1ab554['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x2da1ff,_0x2e8bc0=0x1){Q(this['counters_'],_0x2da1ff)||(this['counters_'][_0x2da1ff]=0x0),this['counters_'][_0x2da1ff]+=_0x2e8bc0;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x41973f){const _0x361bbc=_0x41973f['toString']();return oi[_0x361bbc]||(oi[_0x361bbc]=new nh()),oi[_0x361bbc];}function ih(_0x397efc,_0x28d85e){const _0x2b8854=_0x397efc['toString']();return ai[_0x2b8854]||(ai[_0x2b8854]=_0x28d85e()),ai[_0x2b8854];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0xe8b5ae){this['onMessage_']=_0xe8b5ae,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x779bd6,_0x1d4791){this['closeAfterResponse']=_0x779bd6,this['onClose']=_0x1d4791,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x5c7711,_0x37f79f){for(this['pendingResponses'][_0x5c7711]=_0x37f79f;this['pendingResponses'][this['currentResponseNum']];){const _0xd56948=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x46a5c4=0x0;_0x46a5c4<_0xd56948['length'];++_0x46a5c4)_0xd56948[_0x46a5c4]&&ft(()=>{this['onMessage_'](_0xd56948[_0x46a5c4]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x75e235,_0x34b08a,_0xb97055,_0x363ae4,_0xd1fa3,_0x1ba878,_0x2fb277){this['connId']=_0x75e235,this['repoInfo']=_0x34b08a,this['applicationId']=_0xb97055,this['appCheckToken']=_0x363ae4,this['authToken']=_0xd1fa3,this['transportSessionId']=_0x1ba878,this['lastSessionId']=_0x2fb277,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x75e235),this['stats_']=qi(_0x34b08a),this['urlFn']=_0x57bb52=>(this['appCheckToken']&&(_0x57bb52[wi]=this['appCheckToken']),vo(_0x34b08a,mo,_0x57bb52));}['open'](_0x286cf8,_0x202c11){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x202c11,this['myPacketOrderer']=new sh(_0x286cf8),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x5c41fd)=>{const [_0x56cdf9,_0x5b8b49,_0x555086,_0x5c36df,_0x5793df]=_0x5c41fd;if(this['incrementIncomingBytes_'](_0x5c41fd),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x56cdf9===qs)this['id']=_0x5b8b49,this['password']=_0x555086;else{if(_0x56cdf9===rh)_0x5b8b49?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x5b8b49,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x56cdf9);}}},(..._0x13c5d9)=>{const [_0x2a9914,_0xc21e0b]=_0x13c5d9;this['incrementIncomingBytes_'](_0x13c5d9),this['myPacketOrderer']['handleResponse'](_0x2a9914,_0xc21e0b);},()=>{this['onClosed_']();},this['urlFn']);const _0x234eed={};_0x234eed[qs]='t',_0x234eed[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x234eed[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x234eed[co]=Gi,this['transportSessionId']&&(_0x234eed[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x234eed[po]=this['lastSessionId']),this['applicationId']&&(_0x234eed[_o]=this['applicationId']),this['appCheckToken']&&(_0x234eed[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x234eed[ho]=uo);const _0x1cd774=this['urlFn'](_0x234eed);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x1cd774),this['scriptTagHolder']['addTag'](_0x1cd774,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x3893ce){const _0x1a1f8c=O(_0x3893ce);this['bytesSent']+=_0x1a1f8c['length'],this['stats_']['incrementCounter']('bytes_sent',_0x1a1f8c['length']);const _0x54ca84=$r(_0x1a1f8c),_0x262b67=oo(_0x54ca84,fh);for(let _0x478168=0x0;_0x478168<_0x262b67['length'];_0x478168++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x262b67['length'],_0x262b67[_0x478168]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x5159b7,_0x53dd3c){this['myDisconnFrame']=document['createElement']('iframe');const _0x116c24={};_0x116c24[dh]='t',_0x116c24[Eo]=_0x5159b7,_0x116c24[Io]=_0x53dd3c,this['myDisconnFrame']['src']=this['urlFn'](_0x116c24),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0xd02b29){const _0x1d9833=O(_0xd02b29)['length'];this['bytesReceived']+=_0x1d9833,this['stats_']['incrementCounter']('bytes_received',_0x1d9833);}}class zi{constructor(_0x5e8029,_0x36c295,_0xb960cf,_0x29bc53){this['onDisconnect']=_0xb960cf,this['urlFn']=_0x29bc53,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x5e8029,window[ah+this['uniqueCallbackIdentifier']]=_0x36c295,this['myIFrame']=zi['createIFrame_']();let _0x43dab9='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x43dab9='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x3c998d='<html><body>'+_0x43dab9+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x3c998d),this['myIFrame']['doc']['close']();}catch(_0x21d5e8){L('frame\x20writing\x20exception'),_0x21d5e8['stack']&&L(_0x21d5e8['stack']),L(_0x21d5e8);}}}static['createIFrame_'](){const _0x87c453=document['createElement']('iframe');if(_0x87c453['style']['display']='none',document['body']){document['body']['appendChild'](_0x87c453);try{_0x87c453['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x4e407e=document['domain'];_0x87c453['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x4e407e+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x87c453['contentDocument']?_0x87c453['doc']=_0x87c453['contentDocument']:_0x87c453['contentWindow']?_0x87c453['doc']=_0x87c453['contentWindow']['document']:_0x87c453['document']&&(_0x87c453['doc']=_0x87c453['document']),_0x87c453;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x164052=this['onDisconnect'];_0x164052&&(this['onDisconnect']=null,_0x164052());}['startLongPoll'](_0x45ca09,_0x10deb9){for(this['myID']=_0x45ca09,this['myPW']=_0x10deb9,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x2e3622={};_0x2e3622[Eo]=this['myID'],_0x2e3622[Io]=this['myPW'],_0x2e3622[wo]=this['currentSerial'];let _0x1d6e02=this['urlFn'](_0x2e3622),_0x2426c2='',_0x50f439=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x2426c2['length']<=Co;){const _0xf56db3=this['pendingSegs']['shift']();_0x2426c2=_0x2426c2+'&'+lh+_0x50f439+'='+_0xf56db3['seg']+'&'+hh+_0x50f439+'='+_0xf56db3['ts']+'&'+uh+_0x50f439+'='+_0xf56db3['d'],_0x50f439++;}return _0x1d6e02=_0x1d6e02+_0x2426c2,this['addLongPollTag_'](_0x1d6e02,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x32ad12,_0x414332,_0x4b72ba){this['pendingSegs']['push']({'seg':_0x32ad12,'ts':_0x414332,'d':_0x4b72ba}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x1a0ac5,_0x4ff5bd){this['outstandingRequests']['add'](_0x4ff5bd);const _0x3398b2=()=>{this['outstandingRequests']['delete'](_0x4ff5bd),this['newRequest_']();},_0x36c464=setTimeout(_0x3398b2,Math['floor'](ph)),_0x1522e2=()=>{clearTimeout(_0x36c464),_0x3398b2();};this['addTag'](_0x1a0ac5,_0x1522e2);}['addTag'](_0x56e223,_0x2a52d5){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x3d6c28=this['myIFrame']['doc']['createElement']('script');_0x3d6c28['type']='text/javascript',_0x3d6c28['async']=!0x0,_0x3d6c28['src']=_0x56e223,_0x3d6c28['onload']=_0x3d6c28['onreadystatechange']=function(){const _0x35c058=_0x3d6c28['readyState'];(!_0x35c058||_0x35c058==='loaded'||_0x35c058==='complete')&&(_0x3d6c28['onload']=_0x3d6c28['onreadystatechange']=null,_0x3d6c28['parentNode']&&_0x3d6c28['parentNode']['removeChild'](_0x3d6c28),_0x2a52d5());},_0x3d6c28['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x56e223),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x3d6c28);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x249a90,_0x3fca0a,_0x23f832,_0x3c7209,_0xa306be,_0x4af682,_0x2aa48c){this['connId']=_0x249a90,this['applicationId']=_0x23f832,this['appCheckToken']=_0x3c7209,this['authToken']=_0xa306be,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x3fca0a),this['connURL']=q['connectionURL_'](_0x3fca0a,_0x4af682,_0x2aa48c,_0x3c7209,_0x23f832),this['nodeAdmin']=_0x3fca0a['nodeAdmin'];}static['connectionURL_'](_0x1d774d,_0x29c79b,_0xd691a0,_0x4b06c6,_0x1b728e){const _0x503c8d={};return _0x503c8d[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x503c8d[ho]=uo),_0x29c79b&&(_0x503c8d[lo]=_0x29c79b),_0xd691a0&&(_0x503c8d[po]=_0xd691a0),_0x4b06c6&&(_0x503c8d[wi]=_0x4b06c6),_0x1b728e&&(_0x503c8d[_o]=_0x1b728e),vo(_0x1d774d,go,_0x503c8d);}['open'](_0x1466e0,_0x4e9571){this['onDisconnect']=_0x4e9571,this['onMessage']=_0x1466e0,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x4d5748;_c(),this['mySock']=new gn(this['connURL'],[],_0x4d5748);}catch(_0x512b1d){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x5b632b=_0x512b1d['message']||_0x512b1d['data'];_0x5b632b&&this['log_'](_0x5b632b),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x46730e=>{this['handleIncomingFrame'](_0x46730e);},this['mySock']['onerror']=_0x21defb=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x53d67f=_0x21defb['message']||_0x21defb['data'];_0x53d67f&&this['log_'](_0x53d67f),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x3e6e33=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x579a8d=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x131b6d=navigator['userAgent']['match'](_0x579a8d);_0x131b6d&&_0x131b6d['length']>0x1&&parseFloat(_0x131b6d[0x1])<4.4&&(_0x3e6e33=!0x0);}return!_0x3e6e33&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x4fff86){if(this['frames']['push'](_0x4fff86),this['frames']['length']===this['totalFrames']){const _0x564859=this['frames']['join']('');this['frames']=null;const _0x4ef84b=Nt(_0x564859);this['onMessage'](_0x4ef84b);}}['handleNewFrameCount_'](_0x2329a7){this['totalFrames']=_0x2329a7,this['frames']=[];}['extractFrameCount_'](_0x4681be){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x4681be['length']<=0x6){const _0xb6dd6d=Number(_0x4681be);if(!isNaN(_0xb6dd6d))return this['handleNewFrameCount_'](_0xb6dd6d),null;}return this['handleNewFrameCount_'](0x1),_0x4681be;}['handleIncomingFrame'](_0x3a3b8f){if(this['mySock']===null)return;const _0x5a9b89=_0x3a3b8f['data'];if(this['bytesReceived']+=_0x5a9b89['length'],this['stats_']['incrementCounter']('bytes_received',_0x5a9b89['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x5a9b89);else{const _0x1525f2=this['extractFrameCount_'](_0x5a9b89);_0x1525f2!==null&&this['appendFrame_'](_0x1525f2);}}['send'](_0x319177){this['resetKeepAlive']();const _0xc2c2a2=O(_0x319177);this['bytesSent']+=_0xc2c2a2['length'],this['stats_']['incrementCounter']('bytes_sent',_0xc2c2a2['length']);const _0x365297=oo(_0xc2c2a2,gh);_0x365297['length']>0x1&&this['sendString_'](String(_0x365297['length']));for(let _0x523cd7=0x0;_0x523cd7<_0x365297['length'];_0x523cd7++)this['sendString_'](_0x365297[_0x523cd7]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x33e70f){try{this['mySock']['send'](_0x33e70f);}catch(_0x244dfb){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x244dfb['message']||_0x244dfb['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x2eaa5d){this['initTransports_'](_0x2eaa5d);}['initTransports_'](_0x1f67c2){const _0xebf0af=q&&q['isAvailable']();let _0x5ecaf7=_0xebf0af&&!q['previouslyFailed']();if(_0x1f67c2['webSocketOnly']&&(_0xebf0af||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x5ecaf7=!0x0),_0x5ecaf7)this['transports_']=[q];else{const _0x30304e=this['transports_']=[];for(const _0x413f4c of Dt['ALL_TRANSPORTS'])_0x413f4c&&_0x413f4c['isAvailable']()&&_0x30304e['push'](_0x413f4c);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x47d448,_0x1254ef,_0x3e6ac6,_0x5f0a38,_0x2e432d,_0x33d6e7,_0x2a3e77,_0x393a6b,_0x24136c,_0x46096d){this['id']=_0x47d448,this['repoInfo_']=_0x1254ef,this['applicationId_']=_0x3e6ac6,this['appCheckToken_']=_0x5f0a38,this['authToken_']=_0x2e432d,this['onMessage_']=_0x33d6e7,this['onReady_']=_0x2a3e77,this['onDisconnect_']=_0x393a6b,this['onKill_']=_0x24136c,this['lastSessionId']=_0x46096d,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x1254ef),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x122f0e=this['transportManager_']['initialTransport']();this['conn_']=new _0x122f0e(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x122f0e['responsesRequiredToBeHealthy']||0x0;const _0x1f5b57=this['connReceiver_'](this['conn_']),_0x374440=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x1f5b57,_0x374440);},Math['floor'](0x0));const _0x38d1c8=_0x122f0e['healthyTimeout']||0x0;_0x38d1c8>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x38d1c8)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0xfe1269){return _0x354b15=>{_0xfe1269===this['conn_']?this['onConnectionLost_'](_0x354b15):_0xfe1269===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x46a08c){return _0xd3daa9=>{this['state_']!==0x2&&(_0x46a08c===this['rx_']?this['onPrimaryMessageReceived_'](_0xd3daa9):_0x46a08c===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0xd3daa9):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x554045){const _0x3595e1={'t':'d','d':_0x554045};this['sendData_'](_0x3595e1);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0xc81851){if(ci in _0xc81851){const _0x15497c=_0xc81851[ci];_0x15497c===Ys?this['upgradeIfSecondaryHealthy_']():_0x15497c===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x15497c===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x346bc0){const _0x3bede3=vt('t',_0x346bc0),_0x5dbeec=vt('d',_0x346bc0);if(_0x3bede3==='c')this['onSecondaryControl_'](_0x5dbeec);else{if(_0x3bede3==='d')this['pendingDataMessages']['push'](_0x5dbeec);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x3bede3);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x5bbf6a){const _0x3cfe55=vt('t',_0x5bbf6a),_0x514e9e=vt('d',_0x5bbf6a);_0x3cfe55==='c'?this['onControl_'](_0x514e9e):_0x3cfe55==='d'&&this['onDataMessage_'](_0x514e9e);}['onDataMessage_'](_0x582bb6){this['onPrimaryResponse_'](),this['onMessage_'](_0x582bb6);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x42d496){const _0x21e081=vt(ci,_0x42d496);if(zs in _0x42d496){const _0x4c2b9d=_0x42d496[zs];if(_0x21e081===Th){const _0x273c44={..._0x4c2b9d};this['repoInfo_']['isUsingEmulator']&&(_0x273c44['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x273c44);}else{if(_0x21e081===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x3cdfb4=0x0;_0x3cdfb4<this['pendingDataMessages']['length'];++_0x3cdfb4)this['onDataMessage_'](this['pendingDataMessages'][_0x3cdfb4]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x21e081===wh?this['onConnectionShutdown_'](_0x4c2b9d):_0x21e081===js?this['onReset_'](_0x4c2b9d):_0x21e081===Ch?Ii('Server\x20Error:\x20'+_0x4c2b9d):_0x21e081===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x21e081);}}}['onHandshake_'](_0x60795a){const _0x5c66cf=_0x60795a['ts'],_0x2dbfa9=_0x60795a['v'],_0x45727a=_0x60795a['h'];this['sessionId']=_0x60795a['s'],this['repoInfo_']['host']=_0x45727a,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x5c66cf),Gi!==_0x2dbfa9&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x153ce9=this['transportManager_']['upgradeTransport']();_0x153ce9&&this['startUpgrade_'](_0x153ce9);}['startUpgrade_'](_0x9ed7d2){this['secondaryConn_']=new _0x9ed7d2(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x9ed7d2['responsesRequiredToBeHealthy']||0x0;const _0x7bb2c=this['connReceiver_'](this['secondaryConn_']),_0x58c19d=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x7bb2c,_0x58c19d),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x477822){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x477822),this['repoInfo_']['host']=_0x477822,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x405366,_0x53dfac){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x405366,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x53dfac,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x9b8898=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x9b8898||this['rx_']===_0x9b8898)&&this['close']();}['onConnectionLost_'](_0x5c6cb9){this['conn_']=null,!_0x5c6cb9&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x211dd1){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x211dd1),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x4c458){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x4c458);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x21757e,_0x15b510,_0x1e729c,_0x3f73b8){}['merge'](_0x261d61,_0x2883c5,_0x513c26,_0x3cd951){}['refreshAuthToken'](_0x249b21){}['refreshAppCheckToken'](_0xd1e495){}['onDisconnectPut'](_0x18b7e0,_0x32481d,_0x83a039){}['onDisconnectMerge'](_0x237990,_0x3dc620,_0x5e2ba3){}['onDisconnectCancel'](_0x47b253,_0x59d293){}['reportStats'](_0x559ed4){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x1312d0){this['allowedEvents_']=_0x1312d0,this['listeners_']={},f(Array['isArray'](_0x1312d0)&&_0x1312d0['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x3a4aba,..._0x13a6fb){if(Array['isArray'](this['listeners_'][_0x3a4aba])){const _0x5928dc=[...this['listeners_'][_0x3a4aba]];for(let _0xe54069=0x0;_0xe54069<_0x5928dc['length'];_0xe54069++)_0x5928dc[_0xe54069]['callback']['apply'](_0x5928dc[_0xe54069]['context'],_0x13a6fb);}}['on'](_0x123ff2,_0xcca00b,_0x3c564b){this['validateEventType_'](_0x123ff2),this['listeners_'][_0x123ff2]=this['listeners_'][_0x123ff2]||[],this['listeners_'][_0x123ff2]['push']({'callback':_0xcca00b,'context':_0x3c564b});const _0x4e068b=this['getInitialEvent'](_0x123ff2);_0x4e068b&&_0xcca00b['apply'](_0x3c564b,_0x4e068b);}['off'](_0x2151d,_0x1702cb,_0xde9d92){this['validateEventType_'](_0x2151d);const _0xe3cfd2=this['listeners_'][_0x2151d]||[];for(let _0x23b9e4=0x0;_0x23b9e4<_0xe3cfd2['length'];_0x23b9e4++)if(_0xe3cfd2[_0x23b9e4]['callback']===_0x1702cb&&(!_0xde9d92||_0xde9d92===_0xe3cfd2[_0x23b9e4]['context'])){_0xe3cfd2['splice'](_0x23b9e4,0x1);return;}}['validateEventType_'](_0x23a5e1){f(this['allowedEvents_']['find'](_0x2261ba=>_0x2261ba===_0x23a5e1),'Unknown\x20event:\x20'+_0x23a5e1);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x2cc64f){return f(_0x2cc64f==='online','Unknown\x20event\x20type:\x20'+_0x2cc64f),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x19f4b2,_0x20818f){if(_0x20818f===void 0x0){this['pieces_']=_0x19f4b2['split']('/');let _0x2eeb7d=0x0;for(let _0x113ccb=0x0;_0x113ccb<this['pieces_']['length'];_0x113ccb++)this['pieces_'][_0x113ccb]['length']>0x0&&(this['pieces_'][_0x2eeb7d]=this['pieces_'][_0x113ccb],_0x2eeb7d++);this['pieces_']['length']=_0x2eeb7d,this['pieceNum_']=0x0;}else this['pieces_']=_0x19f4b2,this['pieceNum_']=_0x20818f;}['toString'](){let _0x213948='';for(let _0x44d60b=this['pieceNum_'];_0x44d60b<this['pieces_']['length'];_0x44d60b++)this['pieces_'][_0x44d60b]!==''&&(_0x213948+='/'+this['pieces_'][_0x44d60b]);return _0x213948||'/';}}function w(){return new C('');}function y(_0x3e0894){return _0x3e0894['pieceNum_']>=_0x3e0894['pieces_']['length']?null:_0x3e0894['pieces_'][_0x3e0894['pieceNum_']];}function Ce(_0x108df7){return _0x108df7['pieces_']['length']-_0x108df7['pieceNum_'];}function S(_0x1a9d89){let _0x307e65=_0x1a9d89['pieceNum_'];return _0x307e65<_0x1a9d89['pieces_']['length']&&_0x307e65++,new C(_0x1a9d89['pieces_'],_0x307e65);}function ji(_0x52803a){return _0x52803a['pieceNum_']<_0x52803a['pieces_']['length']?_0x52803a['pieces_'][_0x52803a['pieces_']['length']-0x1]:null;}function bh(_0x53d8cd){let _0x149761='';for(let _0x1c1e0b=_0x53d8cd['pieceNum_'];_0x1c1e0b<_0x53d8cd['pieces_']['length'];_0x1c1e0b++)_0x53d8cd['pieces_'][_0x1c1e0b]!==''&&(_0x149761+='/'+encodeURIComponent(String(_0x53d8cd['pieces_'][_0x1c1e0b])));return _0x149761||'/';}function Mt(_0x463251,_0x1e2704=0x0){return _0x463251['pieces_']['slice'](_0x463251['pieceNum_']+_0x1e2704);}function Ro(_0x380c4d){if(_0x380c4d['pieceNum_']>=_0x380c4d['pieces_']['length'])return null;const _0x540476=[];for(let _0x1c03cb=_0x380c4d['pieceNum_'];_0x1c03cb<_0x380c4d['pieces_']['length']-0x1;_0x1c03cb++)_0x540476['push'](_0x380c4d['pieces_'][_0x1c03cb]);return new C(_0x540476,0x0);}function k(_0x5c94e3,_0x2ae9fe){const _0x2c3cec=[];for(let _0x1c69dc=_0x5c94e3['pieceNum_'];_0x1c69dc<_0x5c94e3['pieces_']['length'];_0x1c69dc++)_0x2c3cec['push'](_0x5c94e3['pieces_'][_0x1c69dc]);if(_0x2ae9fe instanceof C){for(let _0x4f0667=_0x2ae9fe['pieceNum_'];_0x4f0667<_0x2ae9fe['pieces_']['length'];_0x4f0667++)_0x2c3cec['push'](_0x2ae9fe['pieces_'][_0x4f0667]);}else{const _0x357827=_0x2ae9fe['split']('/');for(let _0x127d32=0x0;_0x127d32<_0x357827['length'];_0x127d32++)_0x357827[_0x127d32]['length']>0x0&&_0x2c3cec['push'](_0x357827[_0x127d32]);}return new C(_0x2c3cec,0x0);}function v(_0x21cfe4){return _0x21cfe4['pieceNum_']>=_0x21cfe4['pieces_']['length'];}function F(_0xf4b542,_0x59a0bd){const _0xb1d5d2=y(_0xf4b542),_0x1f5bd9=y(_0x59a0bd);if(_0xb1d5d2===null)return _0x59a0bd;if(_0xb1d5d2===_0x1f5bd9)return F(S(_0xf4b542),S(_0x59a0bd));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x59a0bd+')\x20is\x20not\x20within\x20outerPath\x20('+_0xf4b542+')');}function Rh(_0x53421c,_0x5b690a){const _0x11c71c=Mt(_0x53421c,0x0),_0x2a0737=Mt(_0x5b690a,0x0);for(let _0xcf32a7=0x0;_0xcf32a7<_0x11c71c['length']&&_0xcf32a7<_0x2a0737['length'];_0xcf32a7++){const _0x438150=qe(_0x11c71c[_0xcf32a7],_0x2a0737[_0xcf32a7]);if(_0x438150!==0x0)return _0x438150;}return _0x11c71c['length']===_0x2a0737['length']?0x0:_0x11c71c['length']<_0x2a0737['length']?-0x1:0x1;}function Ki(_0xfd1859,_0x5a91bc){if(Ce(_0xfd1859)!==Ce(_0x5a91bc))return!0x1;for(let _0x4896ae=_0xfd1859['pieceNum_'],_0x16e657=_0x5a91bc['pieceNum_'];_0x4896ae<=_0xfd1859['pieces_']['length'];_0x4896ae++,_0x16e657++)if(_0xfd1859['pieces_'][_0x4896ae]!==_0x5a91bc['pieces_'][_0x16e657])return!0x1;return!0x0;}function G(_0x547b10,_0x3b7b59){let _0xad4002=_0x547b10['pieceNum_'],_0x3a35af=_0x3b7b59['pieceNum_'];if(Ce(_0x547b10)>Ce(_0x3b7b59))return!0x1;for(;_0xad4002<_0x547b10['pieces_']['length'];){if(_0x547b10['pieces_'][_0xad4002]!==_0x3b7b59['pieces_'][_0x3a35af])return!0x1;++_0xad4002,++_0x3a35af;}return!0x0;}class Ah{constructor(_0x45e67b,_0x5d11e0){this['errorPrefix_']=_0x5d11e0,this['parts_']=Mt(_0x45e67b,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0xea22b5=0x0;_0xea22b5<this['parts_']['length'];_0xea22b5++)this['byteLength_']+=Ln(this['parts_'][_0xea22b5]);Ao(this);}}function kh(_0x319fd1,_0x5b3ac9){_0x319fd1['parts_']['length']>0x0&&(_0x319fd1['byteLength_']+=0x1),_0x319fd1['parts_']['push'](_0x5b3ac9),_0x319fd1['byteLength_']+=Ln(_0x5b3ac9),Ao(_0x319fd1);}function Ph(_0x16fa58){const _0x61bffb=_0x16fa58['parts_']['pop']();_0x16fa58['byteLength_']-=Ln(_0x61bffb),_0x16fa58['parts_']['length']>0x0&&(_0x16fa58['byteLength_']-=0x1);}function Ao(_0x366cea){if(_0x366cea['byteLength_']>Zs)throw new Error(_0x366cea['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x366cea['byteLength_']+').');if(_0x366cea['parts_']['length']>Xs)throw new Error(_0x366cea['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x366cea));}function Oe(_0x128497){return _0x128497['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x128497['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x40ba6c,_0x51d6b7;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x51d6b7='visibilitychange',_0x40ba6c='hidden'):typeof document['mozHidden']<'u'?(_0x51d6b7='mozvisibilitychange',_0x40ba6c='mozHidden'):typeof document['msHidden']<'u'?(_0x51d6b7='msvisibilitychange',_0x40ba6c='msHidden'):typeof document['webkitHidden']<'u'&&(_0x51d6b7='webkitvisibilitychange',_0x40ba6c='webkitHidden')),this['visible_']=!0x0,_0x51d6b7&&document['addEventListener'](_0x51d6b7,()=>{const _0x265bdc=!document[_0x40ba6c];_0x265bdc!==this['visible_']&&(this['visible_']=_0x265bdc,this['trigger']('visible',_0x265bdc));},!0x1);}['getInitialEvent'](_0x257e15){return f(_0x257e15==='visible','Unknown\x20event\x20type:\x20'+_0x257e15),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x478b49,_0xd917c4,_0x3b2880,_0x4c0b41,_0x1d6724,_0x434af3,_0x167cb7,_0x46b596){if(super(),this['repoInfo_']=_0x478b49,this['applicationId_']=_0xd917c4,this['onDataUpdate_']=_0x3b2880,this['onConnectStatus_']=_0x4c0b41,this['onServerInfoUpdate_']=_0x1d6724,this['authTokenProvider_']=_0x434af3,this['appCheckTokenProvider_']=_0x167cb7,this['authOverride_']=_0x46b596,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x46b596)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x478b49['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x4e053e,_0x1ca166,_0x3ad864){const _0x44eb08=++this['requestNumber_'],_0x469857={'r':_0x44eb08,'a':_0x4e053e,'b':_0x1ca166};this['log_'](O(_0x469857)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x469857),_0x3ad864&&(this['requestCBHash_'][_0x44eb08]=_0x3ad864);}['get'](_0x363888){this['initConnection_']();const _0x42e17a=new H(),_0x45db15={'action':'g','request':{'p':_0x363888['_path']['toString'](),'q':_0x363888['_queryObject']},'onComplete':_0x1c5b54=>{const _0x2043a9=_0x1c5b54['d'];_0x1c5b54['s']==='ok'?_0x42e17a['resolve'](_0x2043a9):_0x42e17a['reject'](_0x2043a9);}};this['outstandingGets_']['push'](_0x45db15),this['outstandingGetCount_']++;const _0x55fcc3=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x55fcc3),_0x42e17a['promise'];}['listen'](_0x1ed805,_0x440f9e,_0x446db7,_0x33d765){this['initConnection_']();const _0x4a2774=_0x1ed805['_queryIdentifier'],_0x4c054b=_0x1ed805['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x4c054b+'\x20'+_0x4a2774),this['listens']['has'](_0x4c054b)||this['listens']['set'](_0x4c054b,new Map()),f(_0x1ed805['_queryParams']['isDefault']()||!_0x1ed805['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x4c054b)['has'](_0x4a2774),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x346e9e={'onComplete':_0x33d765,'hashFn':_0x440f9e,'query':_0x1ed805,'tag':_0x446db7};this['listens']['get'](_0x4c054b)['set'](_0x4a2774,_0x346e9e),this['connected_']&&this['sendListen_'](_0x346e9e);}['sendGet_'](_0x284f8a){const _0x43860a=this['outstandingGets_'][_0x284f8a];this['sendRequest']('g',_0x43860a['request'],_0x3ba00d=>{delete this['outstandingGets_'][_0x284f8a],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x43860a['onComplete']&&_0x43860a['onComplete'](_0x3ba00d);});}['sendListen_'](_0x25ed3a){const _0xfe6915=_0x25ed3a['query'],_0x1b023b=_0xfe6915['_path']['toString'](),_0x114a16=_0xfe6915['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x1b023b+'\x20for\x20'+_0x114a16);const _0x3feb72={'p':_0x1b023b},_0x468cae='q';_0x25ed3a['tag']&&(_0x3feb72['q']=_0xfe6915['_queryObject'],_0x3feb72['t']=_0x25ed3a['tag']),_0x3feb72['h']=_0x25ed3a['hashFn'](),this['sendRequest'](_0x468cae,_0x3feb72,_0x16a83a=>{const _0x3665e6=_0x16a83a['d'],_0xd12aef=_0x16a83a['s'];se['warnOnListenWarnings_'](_0x3665e6,_0xfe6915),(this['listens']['get'](_0x1b023b)&&this['listens']['get'](_0x1b023b)['get'](_0x114a16))===_0x25ed3a&&(this['log_']('listen\x20response',_0x16a83a),_0xd12aef!=='ok'&&this['removeListen_'](_0x1b023b,_0x114a16),_0x25ed3a['onComplete']&&_0x25ed3a['onComplete'](_0xd12aef,_0x3665e6));});}static['warnOnListenWarnings_'](_0x22741f,_0x572223){if(_0x22741f&&typeof _0x22741f=='object'&&Q(_0x22741f,'w')){const _0x5f3f98=Le(_0x22741f,'w');if(Array['isArray'](_0x5f3f98)&&~_0x5f3f98['indexOf']('no_index')){const _0x1d9915='\x22.indexOn\x22:\x20\x22'+_0x572223['_queryParams']['getIndex']()['toString']()+'\x22',_0x37b649=_0x572223['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x1d9915+'\x20at\x20'+_0x37b649+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x3c08f1){this['authToken_']=_0x3c08f1,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x3c08f1);}['reduceReconnectDelayIfAdminCredential_'](_0x5a0d72){(_0x5a0d72&&_0x5a0d72['length']===0x28||wc(_0x5a0d72))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x53159){this['appCheckToken_']=_0x53159,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x5503e4=this['authToken_'],_0x59fc54=Ic(_0x5503e4)?'auth':'gauth',_0x5b613c={'cred':_0x5503e4};this['authOverride_']===null?_0x5b613c['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x5b613c['authvar']=this['authOverride_']),this['sendRequest'](_0x59fc54,_0x5b613c,_0x15e0d5=>{const _0x53aa6f=_0x15e0d5['s'],_0x257e42=_0x15e0d5['d']||'error';this['authToken_']===_0x5503e4&&(_0x53aa6f==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x53aa6f,_0x257e42));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x2d80cc=>{const _0x333d4a=_0x2d80cc['s'],_0x3a544a=_0x2d80cc['d']||'error';_0x333d4a==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x333d4a,_0x3a544a);});}['unlisten'](_0x2b9e52,_0x392d8d){const _0x109285=_0x2b9e52['_path']['toString'](),_0x3979b9=_0x2b9e52['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x109285+'\x20'+_0x3979b9),f(_0x2b9e52['_queryParams']['isDefault']()||!_0x2b9e52['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x109285,_0x3979b9)&&this['connected_']&&this['sendUnlisten_'](_0x109285,_0x3979b9,_0x2b9e52['_queryObject'],_0x392d8d);}['sendUnlisten_'](_0x4b9422,_0x3d71b3,_0x8500e1,_0xdf421d){this['log_']('Unlisten\x20on\x20'+_0x4b9422+'\x20for\x20'+_0x3d71b3);const _0x5f199b={'p':_0x4b9422},_0x41a011='n';_0xdf421d&&(_0x5f199b['q']=_0x8500e1,_0x5f199b['t']=_0xdf421d),this['sendRequest'](_0x41a011,_0x5f199b);}['onDisconnectPut'](_0x55188e,_0x409bc0,_0x5caab4){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x55188e,_0x409bc0,_0x5caab4):this['onDisconnectRequestQueue_']['push']({'pathString':_0x55188e,'action':'o','data':_0x409bc0,'onComplete':_0x5caab4});}['onDisconnectMerge'](_0x464bcb,_0xc87ef0,_0x2f8ad4){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x464bcb,_0xc87ef0,_0x2f8ad4):this['onDisconnectRequestQueue_']['push']({'pathString':_0x464bcb,'action':'om','data':_0xc87ef0,'onComplete':_0x2f8ad4});}['onDisconnectCancel'](_0x3dbe82,_0x5accd2){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x3dbe82,null,_0x5accd2):this['onDisconnectRequestQueue_']['push']({'pathString':_0x3dbe82,'action':'oc','data':null,'onComplete':_0x5accd2});}['sendOnDisconnect_'](_0xb7a6cc,_0x548560,_0x27e8dc,_0x2ae653){const _0x1e7483={'p':_0x548560,'d':_0x27e8dc};this['log_']('onDisconnect\x20'+_0xb7a6cc,_0x1e7483),this['sendRequest'](_0xb7a6cc,_0x1e7483,_0x2bbfd2=>{_0x2ae653&&setTimeout(()=>{_0x2ae653(_0x2bbfd2['s'],_0x2bbfd2['d']);},Math['floor'](0x0));});}['put'](_0x1e03c6,_0x5ae76f,_0x4bdae5,_0x4753ad){this['putInternal']('p',_0x1e03c6,_0x5ae76f,_0x4bdae5,_0x4753ad);}['merge'](_0x31aeba,_0x1f5a9f,_0x3c0fde,_0x5c54e0){this['putInternal']('m',_0x31aeba,_0x1f5a9f,_0x3c0fde,_0x5c54e0);}['putInternal'](_0x14bc9c,_0x249c78,_0xb113c3,_0x1daaeb,_0xa02eb6){this['initConnection_']();const _0x57964e={'p':_0x249c78,'d':_0xb113c3};_0xa02eb6!==void 0x0&&(_0x57964e['h']=_0xa02eb6),this['outstandingPuts_']['push']({'action':_0x14bc9c,'request':_0x57964e,'onComplete':_0x1daaeb}),this['outstandingPutCount_']++;const _0x4b9345=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x4b9345):this['log_']('Buffering\x20put:\x20'+_0x249c78);}['sendPut_'](_0x533e2b){const _0x126aa6=this['outstandingPuts_'][_0x533e2b]['action'],_0x1d81be=this['outstandingPuts_'][_0x533e2b]['request'],_0x2d7909=this['outstandingPuts_'][_0x533e2b]['onComplete'];this['outstandingPuts_'][_0x533e2b]['queued']=this['connected_'],this['sendRequest'](_0x126aa6,_0x1d81be,_0x2755e7=>{this['log_'](_0x126aa6+'\x20response',_0x2755e7),delete this['outstandingPuts_'][_0x533e2b],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x2d7909&&_0x2d7909(_0x2755e7['s'],_0x2755e7['d']);});}['reportStats'](_0x4cb67d){if(this['connected_']){const _0x8c7e7e={'c':_0x4cb67d};this['log_']('reportStats',_0x8c7e7e),this['sendRequest']('s',_0x8c7e7e,_0x5ebc3f=>{if(_0x5ebc3f['s']!=='ok'){const _0x35a4e2=_0x5ebc3f['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x35a4e2);}});}}['onDataMessage_'](_0x12b177){if('r'in _0x12b177){this['log_']('from\x20server:\x20'+O(_0x12b177));const _0x7258b4=_0x12b177['r'],_0x22634b=this['requestCBHash_'][_0x7258b4];_0x22634b&&(delete this['requestCBHash_'][_0x7258b4],_0x22634b(_0x12b177['b']));}else{if('error'in _0x12b177)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x12b177['error'];'a'in _0x12b177&&this['onDataPush_'](_0x12b177['a'],_0x12b177['b']);}}['onDataPush_'](_0x181000,_0x19b776){this['log_']('handleServerMessage',_0x181000,_0x19b776),_0x181000==='d'?this['onDataUpdate_'](_0x19b776['p'],_0x19b776['d'],!0x1,_0x19b776['t']):_0x181000==='m'?this['onDataUpdate_'](_0x19b776['p'],_0x19b776['d'],!0x0,_0x19b776['t']):_0x181000==='c'?this['onListenRevoked_'](_0x19b776['p'],_0x19b776['q']):_0x181000==='ac'?this['onAuthRevoked_'](_0x19b776['s'],_0x19b776['d']):_0x181000==='apc'?this['onAppCheckRevoked_'](_0x19b776['s'],_0x19b776['d']):_0x181000==='sd'?this['onSecurityDebugPacket_'](_0x19b776):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x181000)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x244f5f,_0x5439d6){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x244f5f),this['lastSessionId']=_0x5439d6,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x4f11db){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x4f11db));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x30b4f8){_0x30b4f8&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x30b4f8;}['onOnline_'](_0x2e32ef){_0x2e32ef?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x5b7d4a=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x591a31=Math['max'](0x0,this['reconnectDelay_']-_0x5b7d4a);_0x591a31=Math['random']()*_0x591a31,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x591a31+'ms'),this['scheduleConnect_'](_0x591a31),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x51ab29=this['onDataMessage_']['bind'](this),_0x56d5e1=this['onReady_']['bind'](this),_0x1ee600=this['onRealtimeDisconnect_']['bind'](this),_0x1fba78=this['id']+':'+se['nextConnectionId_']++,_0x5ae21a=this['lastSessionId'];let _0x23c9e2=!0x1,_0x3c1a5d=null;const _0x35f6ad=function(){_0x3c1a5d?_0x3c1a5d['close']():(_0x23c9e2=!0x0,_0x1ee600());},_0x82e148=function(_0x335391){f(_0x3c1a5d,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x3c1a5d['sendRequest'](_0x335391);};this['realtime_']={'close':_0x35f6ad,'sendRequest':_0x82e148};const _0x17ef21=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x7a94a,_0x3e41da]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x17ef21),this['appCheckTokenProvider_']['getToken'](_0x17ef21)]);_0x23c9e2?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x7a94a&&_0x7a94a['accessToken'],this['appCheckToken_']=_0x3e41da&&_0x3e41da['token'],_0x3c1a5d=new Sh(_0x1fba78,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x51ab29,_0x56d5e1,_0x1ee600,_0x4e0bea=>{U(_0x4e0bea+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x5ae21a));}catch(_0x26e6dc){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x26e6dc),_0x23c9e2||(this['repoInfo_']['nodeAdmin']&&U(_0x26e6dc),_0x35f6ad());}}}['interrupt'](_0x368edd){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x368edd),this['interruptReasons_'][_0x368edd]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0xa82290){L('Resuming\x20connection\x20for\x20reason:\x20'+_0xa82290),delete this['interruptReasons_'][_0xa82290],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x28b72d){const _0x22bda0=_0x28b72d-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x22bda0});}['cancelSentTransactions_'](){for(let _0x24c836=0x0;_0x24c836<this['outstandingPuts_']['length'];_0x24c836++){const _0x2c4eab=this['outstandingPuts_'][_0x24c836];_0x2c4eab&&'h'in _0x2c4eab['request']&&_0x2c4eab['queued']&&(_0x2c4eab['onComplete']&&_0x2c4eab['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x24c836],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x1bb27a,_0x71d0c0){let _0x28ef5a;_0x71d0c0?_0x28ef5a=_0x71d0c0['map'](_0x49b65a=>$i(_0x49b65a))['join']('$'):_0x28ef5a='default';const _0x1e681d=this['removeListen_'](_0x1bb27a,_0x28ef5a);_0x1e681d&&_0x1e681d['onComplete']&&_0x1e681d['onComplete']('permission_denied');}['removeListen_'](_0x104a15,_0x2fe421){const _0x58a2e8=new C(_0x104a15)['toString']();let _0x3faf60;if(this['listens']['has'](_0x58a2e8)){const _0x5615fc=this['listens']['get'](_0x58a2e8);_0x3faf60=_0x5615fc['get'](_0x2fe421),_0x5615fc['delete'](_0x2fe421),_0x5615fc['size']===0x0&&this['listens']['delete'](_0x58a2e8);}else _0x3faf60=void 0x0;return _0x3faf60;}['onAuthRevoked_'](_0x51c9a0,_0x245735){L('Auth\x20token\x20revoked:\x20'+_0x51c9a0+'/'+_0x245735),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x51c9a0==='invalid_token'||_0x51c9a0==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x5b0cf7,_0x2e8900){L('App\x20check\x20token\x20revoked:\x20'+_0x5b0cf7+'/'+_0x2e8900),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x5b0cf7==='invalid_token'||_0x5b0cf7==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x36f4af){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x36f4af):'msg'in _0x36f4af&&console['log']('FIREBASE:\x20'+_0x36f4af['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x1371c7 of this['listens']['values']())for(const _0x32cc08 of _0x1371c7['values']())this['sendListen_'](_0x32cc08);for(let _0x614a8c=0x0;_0x614a8c<this['outstandingPuts_']['length'];_0x614a8c++)this['outstandingPuts_'][_0x614a8c]&&this['sendPut_'](_0x614a8c);for(;this['onDisconnectRequestQueue_']['length'];){const _0x4cdbab=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x4cdbab['action'],_0x4cdbab['pathString'],_0x4cdbab['data'],_0x4cdbab['onComplete']);}for(let _0x242231=0x0;_0x242231<this['outstandingGets_']['length'];_0x242231++)this['outstandingGets_'][_0x242231]&&this['sendGet_'](_0x242231);}['sendConnectStats_'](){const _0x52a1ce={};let _0x5f31e8='js';_0x52a1ce['sdk.'+_0x5f31e8+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x52a1ce['framework.cordova']=0x1:Kr()&&(_0x52a1ce['framework.reactnative']=0x1),this['reportStats'](_0x52a1ce);}['shouldReconnect_'](){const _0x277990=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x277990;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x54b4cd,_0x17337e){this['name']=_0x54b4cd,this['node']=_0x17337e;}static['Wrap'](_0x157d77,_0x4a246a){return new E(_0x157d77,_0x4a246a);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x27cf8b,_0x3fb0bb){const _0x469a10=new E(We,_0x27cf8b),_0x1386b7=new E(We,_0x3fb0bb);return this['compare'](_0x469a10,_0x1386b7)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x5a0ef8){sn=_0x5a0ef8;}['compare'](_0x9033d0,_0x12ff21){return qe(_0x9033d0['name'],_0x12ff21['name']);}['isDefinedOn'](_0x569984){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x3db261,_0x33edbb){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x74b880,_0x50a195){return f(typeof _0x74b880=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x74b880,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x26fe19,_0x2ac9c7,_0xdea439,_0x27c3ad,_0x37519a=null){this['isReverse_']=_0x27c3ad,this['resultGenerator_']=_0x37519a,this['nodeStack_']=[];let _0x2173e2=0x1;for(;!_0x26fe19['isEmpty']();)if(_0x26fe19=_0x26fe19,_0x2173e2=_0x2ac9c7?_0xdea439(_0x26fe19['key'],_0x2ac9c7):0x1,_0x27c3ad&&(_0x2173e2*=-0x1),_0x2173e2<0x0)this['isReverse_']?_0x26fe19=_0x26fe19['left']:_0x26fe19=_0x26fe19['right'];else{if(_0x2173e2===0x0){this['nodeStack_']['push'](_0x26fe19);break;}else this['nodeStack_']['push'](_0x26fe19),this['isReverse_']?_0x26fe19=_0x26fe19['right']:_0x26fe19=_0x26fe19['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x17795d=this['nodeStack_']['pop'](),_0x3e3053;if(this['resultGenerator_']?_0x3e3053=this['resultGenerator_'](_0x17795d['key'],_0x17795d['value']):_0x3e3053={'key':_0x17795d['key'],'value':_0x17795d['value']},this['isReverse_']){for(_0x17795d=_0x17795d['left'];!_0x17795d['isEmpty']();)this['nodeStack_']['push'](_0x17795d),_0x17795d=_0x17795d['right'];}else{for(_0x17795d=_0x17795d['right'];!_0x17795d['isEmpty']();)this['nodeStack_']['push'](_0x17795d),_0x17795d=_0x17795d['left'];}return _0x3e3053;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x20828b=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x20828b['key'],_0x20828b['value']):{'key':_0x20828b['key'],'value':_0x20828b['value']};}}class M{constructor(_0x1af917,_0x5cdb37,_0x5a2938,_0x415cf8,_0x5ef080){this['key']=_0x1af917,this['value']=_0x5cdb37,this['color']=_0x5a2938??M['RED'],this['left']=_0x415cf8??B['EMPTY_NODE'],this['right']=_0x5ef080??B['EMPTY_NODE'];}['copy'](_0x621613,_0xb8907b,_0x1b3d0b,_0x4e6a19,_0x1d6fbf){return new M(_0x621613??this['key'],_0xb8907b??this['value'],_0x1b3d0b??this['color'],_0x4e6a19??this['left'],_0x1d6fbf??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x233cbc){return this['left']['inorderTraversal'](_0x233cbc)||!!_0x233cbc(this['key'],this['value'])||this['right']['inorderTraversal'](_0x233cbc);}['reverseTraversal'](_0x130a97){return this['right']['reverseTraversal'](_0x130a97)||_0x130a97(this['key'],this['value'])||this['left']['reverseTraversal'](_0x130a97);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x247482,_0x5eda6a,_0xbfcf4b){let _0x252b28=this;const _0x5d1578=_0xbfcf4b(_0x247482,_0x252b28['key']);return _0x5d1578<0x0?_0x252b28=_0x252b28['copy'](null,null,null,_0x252b28['left']['insert'](_0x247482,_0x5eda6a,_0xbfcf4b),null):_0x5d1578===0x0?_0x252b28=_0x252b28['copy'](null,_0x5eda6a,null,null,null):_0x252b28=_0x252b28['copy'](null,null,null,null,_0x252b28['right']['insert'](_0x247482,_0x5eda6a,_0xbfcf4b)),_0x252b28['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x2b4af6=this;return!_0x2b4af6['left']['isRed_']()&&!_0x2b4af6['left']['left']['isRed_']()&&(_0x2b4af6=_0x2b4af6['moveRedLeft_']()),_0x2b4af6=_0x2b4af6['copy'](null,null,null,_0x2b4af6['left']['removeMin_'](),null),_0x2b4af6['fixUp_']();}['remove'](_0x4ee548,_0xc9b6b8){let _0x24135c,_0xd85795;if(_0x24135c=this,_0xc9b6b8(_0x4ee548,_0x24135c['key'])<0x0)!_0x24135c['left']['isEmpty']()&&!_0x24135c['left']['isRed_']()&&!_0x24135c['left']['left']['isRed_']()&&(_0x24135c=_0x24135c['moveRedLeft_']()),_0x24135c=_0x24135c['copy'](null,null,null,_0x24135c['left']['remove'](_0x4ee548,_0xc9b6b8),null);else{if(_0x24135c['left']['isRed_']()&&(_0x24135c=_0x24135c['rotateRight_']()),!_0x24135c['right']['isEmpty']()&&!_0x24135c['right']['isRed_']()&&!_0x24135c['right']['left']['isRed_']()&&(_0x24135c=_0x24135c['moveRedRight_']()),_0xc9b6b8(_0x4ee548,_0x24135c['key'])===0x0){if(_0x24135c['right']['isEmpty']())return B['EMPTY_NODE'];_0xd85795=_0x24135c['right']['min_'](),_0x24135c=_0x24135c['copy'](_0xd85795['key'],_0xd85795['value'],null,null,_0x24135c['right']['removeMin_']());}_0x24135c=_0x24135c['copy'](null,null,null,null,_0x24135c['right']['remove'](_0x4ee548,_0xc9b6b8));}return _0x24135c['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x2cf757=this;return _0x2cf757['right']['isRed_']()&&!_0x2cf757['left']['isRed_']()&&(_0x2cf757=_0x2cf757['rotateLeft_']()),_0x2cf757['left']['isRed_']()&&_0x2cf757['left']['left']['isRed_']()&&(_0x2cf757=_0x2cf757['rotateRight_']()),_0x2cf757['left']['isRed_']()&&_0x2cf757['right']['isRed_']()&&(_0x2cf757=_0x2cf757['colorFlip_']()),_0x2cf757;}['moveRedLeft_'](){let _0xe8e035=this['colorFlip_']();return _0xe8e035['right']['left']['isRed_']()&&(_0xe8e035=_0xe8e035['copy'](null,null,null,null,_0xe8e035['right']['rotateRight_']()),_0xe8e035=_0xe8e035['rotateLeft_'](),_0xe8e035=_0xe8e035['colorFlip_']()),_0xe8e035;}['moveRedRight_'](){let _0x4bb184=this['colorFlip_']();return _0x4bb184['left']['left']['isRed_']()&&(_0x4bb184=_0x4bb184['rotateRight_'](),_0x4bb184=_0x4bb184['colorFlip_']()),_0x4bb184;}['rotateLeft_'](){const _0xcdf100=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0xcdf100,null);}['rotateRight_'](){const _0x328814=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x328814);}['colorFlip_'](){const _0x205035=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x5ca9cb=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x205035,_0x5ca9cb);}['checkMaxDepth_'](){const _0x396096=this['check_']();return Math['pow'](0x2,_0x396096)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x2e4be6=this['left']['check_']();if(_0x2e4be6!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x2e4be6+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x165eb8,_0xac5a75,_0xbb775c,_0x24295b,_0x2e75f4){return this;}['insert'](_0x321762,_0x32af02,_0x5e7475){return new M(_0x321762,_0x32af02,null);}['remove'](_0x13f251,_0x385463){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x56f41c){return!0x1;}['reverseTraversal'](_0x55fc17){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x55e367,_0x3ebdc1=B['EMPTY_NODE']){this['comparator_']=_0x55e367,this['root_']=_0x3ebdc1;}['insert'](_0xab91c1,_0xd11f7){return new B(this['comparator_'],this['root_']['insert'](_0xab91c1,_0xd11f7,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0xb58805){return new B(this['comparator_'],this['root_']['remove'](_0xb58805,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x2396ab){let _0x5b993d,_0x29916d=this['root_'];for(;!_0x29916d['isEmpty']();){if(_0x5b993d=this['comparator_'](_0x2396ab,_0x29916d['key']),_0x5b993d===0x0)return _0x29916d['value'];_0x5b993d<0x0?_0x29916d=_0x29916d['left']:_0x5b993d>0x0&&(_0x29916d=_0x29916d['right']);}return null;}['getPredecessorKey'](_0x285644){let _0x30f8d5,_0x564482=this['root_'],_0x4e6960=null;for(;!_0x564482['isEmpty']();)if(_0x30f8d5=this['comparator_'](_0x285644,_0x564482['key']),_0x30f8d5===0x0){if(_0x564482['left']['isEmpty']())return _0x4e6960?_0x4e6960['key']:null;for(_0x564482=_0x564482['left'];!_0x564482['right']['isEmpty']();)_0x564482=_0x564482['right'];return _0x564482['key'];}else _0x30f8d5<0x0?_0x564482=_0x564482['left']:_0x30f8d5>0x0&&(_0x4e6960=_0x564482,_0x564482=_0x564482['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x388a92){return this['root_']['inorderTraversal'](_0x388a92);}['reverseTraversal'](_0x1a06b7){return this['root_']['reverseTraversal'](_0x1a06b7);}['getIterator'](_0x38576e){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x38576e);}['getIteratorFrom'](_0x458550,_0x5d51f3){return new rn(this['root_'],_0x458550,this['comparator_'],!0x1,_0x5d51f3);}['getReverseIteratorFrom'](_0x3c7828,_0x2989b4){return new rn(this['root_'],_0x3c7828,this['comparator_'],!0x0,_0x2989b4);}['getReverseIterator'](_0x419047){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x419047);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x10bd46,_0x401132){return qe(_0x10bd46['name'],_0x401132['name']);}function Qi(_0x3fbdbd,_0x4951e5){return qe(_0x3fbdbd,_0x4951e5);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x3027ef){Ci=_0x3027ef;}const Po=function(_0x145253){return typeof _0x145253=='number'?'number:'+ao(_0x145253):'string:'+_0x145253;},No=function(_0x1acf7a){if(_0x1acf7a['isLeafNode']()){const _0x5e7c3a=_0x1acf7a['val']();f(typeof _0x5e7c3a=='string'||typeof _0x5e7c3a=='number'||typeof _0x5e7c3a=='object'&&Q(_0x5e7c3a,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x1acf7a===Ci||_0x1acf7a['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x1acf7a===Ci||_0x1acf7a['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x47d458){nr=_0x47d458;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x10782d,_0x4c63b9=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x10782d,this['priorityNode_']=_0x4c63b9,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x162836){return new D(this['value_'],_0x162836);}['getImmediateChild'](_0x1f1fd4){return _0x1f1fd4==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x358dd5){return v(_0x358dd5)?this:y(_0x358dd5)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x2e0829,_0xa5804f){return null;}['updateImmediateChild'](_0x2a73ce,_0x37c9eb){return _0x2a73ce==='.priority'?this['updatePriority'](_0x37c9eb):_0x37c9eb['isEmpty']()&&_0x2a73ce!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x2a73ce,_0x37c9eb)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x98dd2d,_0x599633){const _0x2e0a0f=y(_0x98dd2d);return _0x2e0a0f===null?_0x599633:_0x599633['isEmpty']()&&_0x2e0a0f!=='.priority'?this:(f(_0x2e0a0f!=='.priority'||Ce(_0x98dd2d)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x2e0a0f,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x98dd2d),_0x599633)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x454c2e,_0x2cca77){return!0x1;}['val'](_0x55bb6e){return _0x55bb6e&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x52766c='';this['priorityNode_']['isEmpty']()||(_0x52766c+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x9ed5da=typeof this['value_'];_0x52766c+=_0x9ed5da+':',_0x9ed5da==='number'?_0x52766c+=ao(this['value_']):_0x52766c+=this['value_'],this['lazyHash_']=ro(_0x52766c);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x5638fe){return _0x5638fe===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x5638fe instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x5638fe['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x5638fe));}['compareToLeafNode_'](_0x4b5c66){const _0x483c06=typeof _0x4b5c66['value_'],_0x13c8ec=typeof this['value_'],_0x181941=D['VALUE_TYPE_ORDER']['indexOf'](_0x483c06),_0x30c505=D['VALUE_TYPE_ORDER']['indexOf'](_0x13c8ec);return f(_0x181941>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x483c06),f(_0x30c505>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x13c8ec),_0x181941===_0x30c505?_0x13c8ec==='object'?0x0:this['value_']<_0x4b5c66['value_']?-0x1:this['value_']===_0x4b5c66['value_']?0x0:0x1:_0x30c505-_0x181941;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x220522){if(_0x220522===this)return!0x0;if(_0x220522['isLeafNode']()){const _0x2c15c0=_0x220522;return this['value_']===_0x2c15c0['value_']&&this['priorityNode_']['equals'](_0x2c15c0['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x3a72b1){Oo=_0x3a72b1;}function Wh(_0x3e3b75){Do=_0x3e3b75;}class Bh extends Fn{['compare'](_0x2bea71,_0x56d27c){const _0x37342c=_0x2bea71['node']['getPriority'](),_0x1b1210=_0x56d27c['node']['getPriority'](),_0x9efdab=_0x37342c['compareTo'](_0x1b1210);return _0x9efdab===0x0?qe(_0x2bea71['name'],_0x56d27c['name']):_0x9efdab;}['isDefinedOn'](_0x18cd4f){return!_0x18cd4f['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x2746ee,_0x569ef8){return!_0x2746ee['getPriority']()['equals'](_0x569ef8['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x45da8b,_0x3b1164){const _0x4be4c7=Oo(_0x45da8b);return new E(_0x3b1164,new D('[PRIORITY-POST]',_0x4be4c7));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x190c9c){const _0x47a47b=_0x1b00b4=>parseInt(Math['log'](_0x1b00b4)/Vh,0xa),_0x45ada1=_0x1658d7=>parseInt(Array(_0x1658d7+0x1)['join']('1'),0x2);this['count']=_0x47a47b(_0x190c9c+0x1),this['current_']=this['count']-0x1;const _0x290ba4=_0x45ada1(this['count']);this['bits_']=_0x190c9c+0x1&_0x290ba4;}['nextBitIsOne'](){const _0x5e3004=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x5e3004;}}const yn=function(_0x50207f,_0x44d2f4,_0x5d8094,_0x1aa7c2){_0x50207f['sort'](_0x44d2f4);const _0xc5c71a=function(_0x29c81f,_0x4aea47){const _0x4007a5=_0x4aea47-_0x29c81f;let _0x242acb,_0x1b227d;if(_0x4007a5===0x0)return null;if(_0x4007a5===0x1)return _0x242acb=_0x50207f[_0x29c81f],_0x1b227d=_0x5d8094?_0x5d8094(_0x242acb):_0x242acb,new M(_0x1b227d,_0x242acb['node'],M['BLACK'],null,null);{const _0x4e5630=parseInt(_0x4007a5/0x2,0xa)+_0x29c81f,_0x2a14d7=_0xc5c71a(_0x29c81f,_0x4e5630),_0x1a5a16=_0xc5c71a(_0x4e5630+0x1,_0x4aea47);return _0x242acb=_0x50207f[_0x4e5630],_0x1b227d=_0x5d8094?_0x5d8094(_0x242acb):_0x242acb,new M(_0x1b227d,_0x242acb['node'],M['BLACK'],_0x2a14d7,_0x1a5a16);}},_0x4509f7=function(_0x5e2175){let _0x1ba646=null,_0x1a0ece=null,_0x5b45c1=_0x50207f['length'];const _0x43ff2d=function(_0x33fca9,_0x2c6856){const _0x40b680=_0x5b45c1-_0x33fca9,_0x31a3c6=_0x5b45c1;_0x5b45c1-=_0x33fca9;const _0x1587cf=_0xc5c71a(_0x40b680+0x1,_0x31a3c6),_0xd2cc21=_0x50207f[_0x40b680],_0x4a4a56=_0x5d8094?_0x5d8094(_0xd2cc21):_0xd2cc21;_0x50ae7e(new M(_0x4a4a56,_0xd2cc21['node'],_0x2c6856,null,_0x1587cf));},_0x50ae7e=function(_0x20bda8){_0x1ba646?(_0x1ba646['left']=_0x20bda8,_0x1ba646=_0x20bda8):(_0x1a0ece=_0x20bda8,_0x1ba646=_0x20bda8);};for(let _0x34263d=0x0;_0x34263d<_0x5e2175['count'];++_0x34263d){const _0x48473f=_0x5e2175['nextBitIsOne'](),_0xbbf3f8=Math['pow'](0x2,_0x5e2175['count']-(_0x34263d+0x1));_0x48473f?_0x43ff2d(_0xbbf3f8,M['BLACK']):(_0x43ff2d(_0xbbf3f8,M['BLACK']),_0x43ff2d(_0xbbf3f8,M['RED']));}return _0x1a0ece;},_0x4431b9=new Hh(_0x50207f['length']),_0x3f1640=_0x4509f7(_0x4431b9);return new B(_0x1aa7c2||_0x44d2f4,_0x3f1640);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x21465f,_0x10476d){this['indexes_']=_0x21465f,this['indexSet_']=_0x10476d;}['get'](_0x4bfef3){const _0x4f0de9=Le(this['indexes_'],_0x4bfef3);if(!_0x4f0de9)throw new Error('No\x20index\x20defined\x20for\x20'+_0x4bfef3);return _0x4f0de9 instanceof B?_0x4f0de9:null;}['hasIndex'](_0x4d2446){return Q(this['indexSet_'],_0x4d2446['toString']());}['addIndex'](_0x416bf2,_0x173bdb){f(_0x416bf2!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x12b188=[];let _0x2be2c6=!0x1;const _0x2065e2=_0x173bdb['getIterator'](E['Wrap']);let _0x10407a=_0x2065e2['getNext']();for(;_0x10407a;)_0x2be2c6=_0x2be2c6||_0x416bf2['isDefinedOn'](_0x10407a['node']),_0x12b188['push'](_0x10407a),_0x10407a=_0x2065e2['getNext']();let _0x5cfb5b;_0x2be2c6?_0x5cfb5b=yn(_0x12b188,_0x416bf2['getCompare']()):_0x5cfb5b=Qe;const _0x5f0d66=_0x416bf2['toString'](),_0x2ccf73={...this['indexSet_']};_0x2ccf73[_0x5f0d66]=_0x416bf2;const _0x20f7ec={...this['indexes_']};return _0x20f7ec[_0x5f0d66]=_0x5cfb5b,new te(_0x20f7ec,_0x2ccf73);}['addToIndexes'](_0x126893,_0x316409){const _0x4d6b17=_n(this['indexes_'],(_0x165de6,_0x185ba1)=>{const _0x28299d=Le(this['indexSet_'],_0x185ba1);if(f(_0x28299d,'Missing\x20index\x20implementation\x20for\x20'+_0x185ba1),_0x165de6===Qe){if(_0x28299d['isDefinedOn'](_0x126893['node'])){const _0x2d11bc=[],_0x40bd58=_0x316409['getIterator'](E['Wrap']);let _0x28417f=_0x40bd58['getNext']();for(;_0x28417f;)_0x28417f['name']!==_0x126893['name']&&_0x2d11bc['push'](_0x28417f),_0x28417f=_0x40bd58['getNext']();return _0x2d11bc['push'](_0x126893),yn(_0x2d11bc,_0x28299d['getCompare']());}else return Qe;}else{const _0x333fda=_0x316409['get'](_0x126893['name']);let _0x4c0ec=_0x165de6;return _0x333fda&&(_0x4c0ec=_0x4c0ec['remove'](new E(_0x126893['name'],_0x333fda))),_0x4c0ec['insert'](_0x126893,_0x126893['node']);}});return new te(_0x4d6b17,this['indexSet_']);}['removeFromIndexes'](_0x29bba4,_0x56c571){const _0x249c1d=_n(this['indexes_'],_0x207257=>{if(_0x207257===Qe)return _0x207257;{const _0x54cdd2=_0x56c571['get'](_0x29bba4['name']);return _0x54cdd2?_0x207257['remove'](new E(_0x29bba4['name'],_0x54cdd2)):_0x207257;}});return new te(_0x249c1d,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x415100,_0x285be3,_0x4ccf28){this['children_']=_0x415100,this['priorityNode_']=_0x285be3,this['indexMap_']=_0x4ccf28,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0xff7cb3){return this['children_']['isEmpty']()?this:new g(this['children_'],_0xff7cb3,this['indexMap_']);}['getImmediateChild'](_0xe8446d){if(_0xe8446d==='.priority')return this['getPriority']();{const _0x1c6a4b=this['children_']['get'](_0xe8446d);return _0x1c6a4b===null?It:_0x1c6a4b;}}['getChild'](_0xca0c3f){const _0x5de3f5=y(_0xca0c3f);return _0x5de3f5===null?this:this['getImmediateChild'](_0x5de3f5)['getChild'](S(_0xca0c3f));}['hasChild'](_0xb93d19){return this['children_']['get'](_0xb93d19)!==null;}['updateImmediateChild'](_0x1fd391,_0x2bf2cf){if(f(_0x2bf2cf,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x1fd391==='.priority')return this['updatePriority'](_0x2bf2cf);{const _0x392ae6=new E(_0x1fd391,_0x2bf2cf);let _0x3cc556,_0x46ec34;_0x2bf2cf['isEmpty']()?(_0x3cc556=this['children_']['remove'](_0x1fd391),_0x46ec34=this['indexMap_']['removeFromIndexes'](_0x392ae6,this['children_'])):(_0x3cc556=this['children_']['insert'](_0x1fd391,_0x2bf2cf),_0x46ec34=this['indexMap_']['addToIndexes'](_0x392ae6,this['children_']));const _0x20b593=_0x3cc556['isEmpty']()?It:this['priorityNode_'];return new g(_0x3cc556,_0x20b593,_0x46ec34);}}['updateChild'](_0x2b52fb,_0x5437d9){const _0xfc632=y(_0x2b52fb);if(_0xfc632===null)return _0x5437d9;{f(y(_0x2b52fb)!=='.priority'||Ce(_0x2b52fb)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x2b606c=this['getImmediateChild'](_0xfc632)['updateChild'](S(_0x2b52fb),_0x5437d9);return this['updateImmediateChild'](_0xfc632,_0x2b606c);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x2e4255){if(this['isEmpty']())return null;const _0x5b57a5={};let _0x5ea5bf=0x0,_0x380671=0x0,_0x57f3b9=!0x0;if(this['forEachChild'](R,(_0xb0dfd0,_0x3e37c8)=>{_0x5b57a5[_0xb0dfd0]=_0x3e37c8['val'](_0x2e4255),_0x5ea5bf++,_0x57f3b9&&g['INTEGER_REGEXP_']['test'](_0xb0dfd0)?_0x380671=Math['max'](_0x380671,Number(_0xb0dfd0)):_0x57f3b9=!0x1;}),!_0x2e4255&&_0x57f3b9&&_0x380671<0x2*_0x5ea5bf){const _0x134d5e=[];for(const _0xf429c5 in _0x5b57a5)_0x134d5e[_0xf429c5]=_0x5b57a5[_0xf429c5];return _0x134d5e;}else return _0x2e4255&&!this['getPriority']()['isEmpty']()&&(_0x5b57a5['.priority']=this['getPriority']()['val']()),_0x5b57a5;}['hash'](){if(this['lazyHash_']===null){let _0x4b9935='';this['getPriority']()['isEmpty']()||(_0x4b9935+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0xe3faf1,_0x395665)=>{const _0x3b6aa4=_0x395665['hash']();_0x3b6aa4!==''&&(_0x4b9935+=':'+_0xe3faf1+':'+_0x3b6aa4);}),this['lazyHash_']=_0x4b9935===''?'':ro(_0x4b9935);}return this['lazyHash_'];}['getPredecessorChildName'](_0xfc5107,_0x63be0a,_0x1f78b9){const _0x58d9eb=this['resolveIndex_'](_0x1f78b9);if(_0x58d9eb){const _0x4ae213=_0x58d9eb['getPredecessorKey'](new E(_0xfc5107,_0x63be0a));return _0x4ae213?_0x4ae213['name']:null;}else return this['children_']['getPredecessorKey'](_0xfc5107);}['getFirstChildName'](_0x547aab){const _0x207a92=this['resolveIndex_'](_0x547aab);if(_0x207a92){const _0x375ea5=_0x207a92['minKey']();return _0x375ea5&&_0x375ea5['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x49c49a){const _0x109ac3=this['getFirstChildName'](_0x49c49a);return _0x109ac3?new E(_0x109ac3,this['children_']['get'](_0x109ac3)):null;}['getLastChildName'](_0x574926){const _0x1cb52d=this['resolveIndex_'](_0x574926);if(_0x1cb52d){const _0x1bc5f1=_0x1cb52d['maxKey']();return _0x1bc5f1&&_0x1bc5f1['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x53bcb0){const _0x142259=this['getLastChildName'](_0x53bcb0);return _0x142259?new E(_0x142259,this['children_']['get'](_0x142259)):null;}['forEachChild'](_0x3b3a52,_0x36dfa8){const _0x514125=this['resolveIndex_'](_0x3b3a52);return _0x514125?_0x514125['inorderTraversal'](_0x266be2=>_0x36dfa8(_0x266be2['name'],_0x266be2['node'])):this['children_']['inorderTraversal'](_0x36dfa8);}['getIterator'](_0x4ba356){return this['getIteratorFrom'](_0x4ba356['minPost'](),_0x4ba356);}['getIteratorFrom'](_0x4fd1bf,_0x540c5a){const _0xf2b8fa=this['resolveIndex_'](_0x540c5a);if(_0xf2b8fa)return _0xf2b8fa['getIteratorFrom'](_0x4fd1bf,_0x1cea38=>_0x1cea38);{const _0x3bfae0=this['children_']['getIteratorFrom'](_0x4fd1bf['name'],E['Wrap']);let _0x4b6e54=_0x3bfae0['peek']();for(;_0x4b6e54!=null&&_0x540c5a['compare'](_0x4b6e54,_0x4fd1bf)<0x0;)_0x3bfae0['getNext'](),_0x4b6e54=_0x3bfae0['peek']();return _0x3bfae0;}}['getReverseIterator'](_0x21d520){return this['getReverseIteratorFrom'](_0x21d520['maxPost'](),_0x21d520);}['getReverseIteratorFrom'](_0x45838c,_0xb779f3){const _0x44f045=this['resolveIndex_'](_0xb779f3);if(_0x44f045)return _0x44f045['getReverseIteratorFrom'](_0x45838c,_0x5f576d=>_0x5f576d);{const _0x12d46b=this['children_']['getReverseIteratorFrom'](_0x45838c['name'],E['Wrap']);let _0x46cd80=_0x12d46b['peek']();for(;_0x46cd80!=null&&_0xb779f3['compare'](_0x46cd80,_0x45838c)>0x0;)_0x12d46b['getNext'](),_0x46cd80=_0x12d46b['peek']();return _0x12d46b;}}['compareTo'](_0x561775){return this['isEmpty']()?_0x561775['isEmpty']()?0x0:-0x1:_0x561775['isLeafNode']()||_0x561775['isEmpty']()?0x1:_0x561775===Kt?-0x1:0x0;}['withIndex'](_0x46092d){if(_0x46092d===ve||this['indexMap_']['hasIndex'](_0x46092d))return this;{const _0x6c731b=this['indexMap_']['addIndex'](_0x46092d,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x6c731b);}}['isIndexed'](_0x36a5c1){return _0x36a5c1===ve||this['indexMap_']['hasIndex'](_0x36a5c1);}['equals'](_0x3c9024){if(_0x3c9024===this)return!0x0;if(_0x3c9024['isLeafNode']())return!0x1;{const _0x57cdb6=_0x3c9024;if(this['getPriority']()['equals'](_0x57cdb6['getPriority']())){if(this['children_']['count']()===_0x57cdb6['children_']['count']()){const _0x304fd2=this['getIterator'](R),_0x5a84ed=_0x57cdb6['getIterator'](R);let _0x588c05=_0x304fd2['getNext'](),_0xea52e9=_0x5a84ed['getNext']();for(;_0x588c05&&_0xea52e9;){if(_0x588c05['name']!==_0xea52e9['name']||!_0x588c05['node']['equals'](_0xea52e9['node']))return!0x1;_0x588c05=_0x304fd2['getNext'](),_0xea52e9=_0x5a84ed['getNext']();}return _0x588c05===null&&_0xea52e9===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x5632a2){return _0x5632a2===ve?null:this['indexMap_']['get'](_0x5632a2['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x350d63){return _0x350d63===this?0x0:0x1;}['equals'](_0x5b600c){return _0x5b600c===this;}['getPriority'](){return this;}['getImmediateChild'](_0x377e4a){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x43ef58,_0x33ae4f=null){if(_0x43ef58===null)return g['EMPTY_NODE'];if(typeof _0x43ef58=='object'&&'.priority'in _0x43ef58&&(_0x33ae4f=_0x43ef58['.priority']),f(_0x33ae4f===null||typeof _0x33ae4f=='string'||typeof _0x33ae4f=='number'||typeof _0x33ae4f=='object'&&'.sv'in _0x33ae4f,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x33ae4f),typeof _0x43ef58=='object'&&'.value'in _0x43ef58&&_0x43ef58['.value']!==null&&(_0x43ef58=_0x43ef58['.value']),typeof _0x43ef58!='object'||'.sv'in _0x43ef58){const _0x30764d=_0x43ef58;return new D(_0x30764d,A(_0x33ae4f));}if(!(_0x43ef58 instanceof Array)&&Gh){const _0x4b3bbd=[];let _0x2dc572=!0x1;if(x(_0x43ef58,(_0x563096,_0x39cf44)=>{if(_0x563096['substring'](0x0,0x1)!=='.'){const _0xf4b74f=A(_0x39cf44);_0xf4b74f['isEmpty']()||(_0x2dc572=_0x2dc572||!_0xf4b74f['getPriority']()['isEmpty'](),_0x4b3bbd['push'](new E(_0x563096,_0xf4b74f)));}}),_0x4b3bbd['length']===0x0)return g['EMPTY_NODE'];const _0xf037a3=yn(_0x4b3bbd,xh,_0xe0823b=>_0xe0823b['name'],Qi);if(_0x2dc572){const _0x30168a=yn(_0x4b3bbd,R['getCompare']());return new g(_0xf037a3,A(_0x33ae4f),new te({'.priority':_0x30168a},{'.priority':R}));}else return new g(_0xf037a3,A(_0x33ae4f),te['Default']);}else{let _0xfb837a=g['EMPTY_NODE'];return x(_0x43ef58,(_0x248d37,_0x5768d7)=>{if(Q(_0x43ef58,_0x248d37)&&_0x248d37['substring'](0x0,0x1)!=='.'){const _0x497f21=A(_0x5768d7);(_0x497f21['isLeafNode']()||!_0x497f21['isEmpty']())&&(_0xfb837a=_0xfb837a['updateImmediateChild'](_0x248d37,_0x497f21));}}),_0xfb837a['updatePriority'](A(_0x33ae4f));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x50b652){super(),this['indexPath_']=_0x50b652,f(!v(_0x50b652)&&y(_0x50b652)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x308a75){return _0x308a75['getChild'](this['indexPath_']);}['isDefinedOn'](_0x487432){return!_0x487432['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x48ec68,_0x5b3458){const _0x15bc63=this['extractChild'](_0x48ec68['node']),_0x5a939d=this['extractChild'](_0x5b3458['node']),_0xf298=_0x15bc63['compareTo'](_0x5a939d);return _0xf298===0x0?qe(_0x48ec68['name'],_0x5b3458['name']):_0xf298;}['makePost'](_0xda2f42,_0x488637){const _0x1ff824=A(_0xda2f42),_0x311b1c=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x1ff824);return new E(_0x488637,_0x311b1c);}['maxPost'](){const _0x33b92=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x33b92);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x2ac171,_0xe7161){const _0x33e2c9=_0x2ac171['node']['compareTo'](_0xe7161['node']);return _0x33e2c9===0x0?qe(_0x2ac171['name'],_0xe7161['name']):_0x33e2c9;}['isDefinedOn'](_0x5a1925){return!0x0;}['indexedValueChanged'](_0x37aba4,_0x3e74b8){return!_0x37aba4['equals'](_0x3e74b8);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x19336c,_0x5bb4cb){const _0x280a01=A(_0x19336c);return new E(_0x5bb4cb,_0x280a01);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x25b002){return{'type':'value','snapshotNode':_0x25b002};}function rt(_0x3b5f41,_0x47b90d){return{'type':'child_added','snapshotNode':_0x47b90d,'childName':_0x3b5f41};}function Lt(_0x27d284,_0x3c87c9){return{'type':'child_removed','snapshotNode':_0x3c87c9,'childName':_0x27d284};}function xt(_0x243650,_0x1b3bc5,_0x3fd065){return{'type':'child_changed','snapshotNode':_0x1b3bc5,'childName':_0x243650,'oldSnap':_0x3fd065};}function zh(_0xb19f09,_0xc11591){return{'type':'child_moved','snapshotNode':_0xc11591,'childName':_0xb19f09};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x471a1e){this['index_']=_0x471a1e;}['updateChild'](_0xdc7fde,_0x59b5ab,_0x29b875,_0x3f7c5c,_0xcf5017,_0x1d33e9){f(_0xdc7fde['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x27f93b=_0xdc7fde['getImmediateChild'](_0x59b5ab);return _0x27f93b['getChild'](_0x3f7c5c)['equals'](_0x29b875['getChild'](_0x3f7c5c))&&_0x27f93b['isEmpty']()===_0x29b875['isEmpty']()||(_0x1d33e9!=null&&(_0x29b875['isEmpty']()?_0xdc7fde['hasChild'](_0x59b5ab)?_0x1d33e9['trackChildChange'](Lt(_0x59b5ab,_0x27f93b)):f(_0xdc7fde['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x27f93b['isEmpty']()?_0x1d33e9['trackChildChange'](rt(_0x59b5ab,_0x29b875)):_0x1d33e9['trackChildChange'](xt(_0x59b5ab,_0x29b875,_0x27f93b))),_0xdc7fde['isLeafNode']()&&_0x29b875['isEmpty']())?_0xdc7fde:_0xdc7fde['updateImmediateChild'](_0x59b5ab,_0x29b875)['withIndex'](this['index_']);}['updateFullNode'](_0x22111c,_0x3e9d2a,_0x55ec44){return _0x55ec44!=null&&(_0x22111c['isLeafNode']()||_0x22111c['forEachChild'](R,(_0x101991,_0x533405)=>{_0x3e9d2a['hasChild'](_0x101991)||_0x55ec44['trackChildChange'](Lt(_0x101991,_0x533405));}),_0x3e9d2a['isLeafNode']()||_0x3e9d2a['forEachChild'](R,(_0x2343c3,_0x2ea030)=>{if(_0x22111c['hasChild'](_0x2343c3)){const _0x32e4dc=_0x22111c['getImmediateChild'](_0x2343c3);_0x32e4dc['equals'](_0x2ea030)||_0x55ec44['trackChildChange'](xt(_0x2343c3,_0x2ea030,_0x32e4dc));}else _0x55ec44['trackChildChange'](rt(_0x2343c3,_0x2ea030));})),_0x3e9d2a['withIndex'](this['index_']);}['updatePriority'](_0x31f85f,_0x724fdd){return _0x31f85f['isEmpty']()?g['EMPTY_NODE']:_0x31f85f['updatePriority'](_0x724fdd);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x394adc){this['indexedFilter_']=new Xi(_0x394adc['getIndex']()),this['index_']=_0x394adc['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x394adc),this['endPost_']=Ft['getEndPost_'](_0x394adc),this['startIsInclusive_']=!_0x394adc['startAfterSet_'],this['endIsInclusive_']=!_0x394adc['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x37e179){const _0x272173=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x37e179)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x37e179)<0x0,_0x384f40=this['endIsInclusive_']?this['index_']['compare'](_0x37e179,this['getEndPost']())<=0x0:this['index_']['compare'](_0x37e179,this['getEndPost']())<0x0;return _0x272173&&_0x384f40;}['updateChild'](_0x1a8fa6,_0x904077,_0x575b58,_0x313419,_0x509c3a,_0x43248e){return this['matches'](new E(_0x904077,_0x575b58))||(_0x575b58=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x1a8fa6,_0x904077,_0x575b58,_0x313419,_0x509c3a,_0x43248e);}['updateFullNode'](_0x5b4a7b,_0x27bb10,_0x935b69){_0x27bb10['isLeafNode']()&&(_0x27bb10=g['EMPTY_NODE']);let _0xeb91b3=_0x27bb10['withIndex'](this['index_']);_0xeb91b3=_0xeb91b3['updatePriority'](g['EMPTY_NODE']);const _0x2945de=this;return _0x27bb10['forEachChild'](R,(_0x10db85,_0x5d31c2)=>{_0x2945de['matches'](new E(_0x10db85,_0x5d31c2))||(_0xeb91b3=_0xeb91b3['updateImmediateChild'](_0x10db85,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x5b4a7b,_0xeb91b3,_0x935b69);}['updatePriority'](_0x53095d,_0x29fa11){return _0x53095d;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x4feb47){if(_0x4feb47['hasStart']()){const _0x5c07c0=_0x4feb47['getIndexStartName']();return _0x4feb47['getIndex']()['makePost'](_0x4feb47['getIndexStartValue'](),_0x5c07c0);}else return _0x4feb47['getIndex']()['minPost']();}static['getEndPost_'](_0x348377){if(_0x348377['hasEnd']()){const _0x44a51a=_0x348377['getIndexEndName']();return _0x348377['getIndex']()['makePost'](_0x348377['getIndexEndValue'](),_0x44a51a);}else return _0x348377['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0xc763ac){this['withinDirectionalStart']=_0x5dc13a=>this['reverse_']?this['withinEndPost'](_0x5dc13a):this['withinStartPost'](_0x5dc13a),this['withinDirectionalEnd']=_0x27d0a2=>this['reverse_']?this['withinStartPost'](_0x27d0a2):this['withinEndPost'](_0x27d0a2),this['withinStartPost']=_0x22422b=>{const _0x5e5e58=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x22422b);return this['startIsInclusive_']?_0x5e5e58<=0x0:_0x5e5e58<0x0;},this['withinEndPost']=_0x231c41=>{const _0x1f4db6=this['index_']['compare'](_0x231c41,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x1f4db6<=0x0:_0x1f4db6<0x0;},this['rangedFilter_']=new Ft(_0xc763ac),this['index_']=_0xc763ac['getIndex'](),this['limit_']=_0xc763ac['getLimit'](),this['reverse_']=!_0xc763ac['isViewFromLeft'](),this['startIsInclusive_']=!_0xc763ac['startAfterSet_'],this['endIsInclusive_']=!_0xc763ac['endBeforeSet_'];}['updateChild'](_0x8d04c4,_0x25a8e8,_0xf93f14,_0x2f0c34,_0xbc32b0,_0x5b6195){return this['rangedFilter_']['matches'](new E(_0x25a8e8,_0xf93f14))||(_0xf93f14=g['EMPTY_NODE']),_0x8d04c4['getImmediateChild'](_0x25a8e8)['equals'](_0xf93f14)?_0x8d04c4:_0x8d04c4['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x8d04c4,_0x25a8e8,_0xf93f14,_0x2f0c34,_0xbc32b0,_0x5b6195):this['fullLimitUpdateChild_'](_0x8d04c4,_0x25a8e8,_0xf93f14,_0xbc32b0,_0x5b6195);}['updateFullNode'](_0x1f2231,_0x310a70,_0x55e83f){let _0x364abe;if(_0x310a70['isLeafNode']()||_0x310a70['isEmpty']())_0x364abe=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x310a70['numChildren']()&&_0x310a70['isIndexed'](this['index_'])){_0x364abe=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x48a2fc;this['reverse_']?_0x48a2fc=_0x310a70['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x48a2fc=_0x310a70['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x1e81d8=0x0;for(;_0x48a2fc['hasNext']()&&_0x1e81d8<this['limit_'];){const _0x1b482d=_0x48a2fc['getNext']();if(this['withinDirectionalStart'](_0x1b482d)){if(this['withinDirectionalEnd'](_0x1b482d))_0x364abe=_0x364abe['updateImmediateChild'](_0x1b482d['name'],_0x1b482d['node']),_0x1e81d8++;else break;}else continue;}}else{_0x364abe=_0x310a70['withIndex'](this['index_']),_0x364abe=_0x364abe['updatePriority'](g['EMPTY_NODE']);let _0x3a0a42;this['reverse_']?_0x3a0a42=_0x364abe['getReverseIterator'](this['index_']):_0x3a0a42=_0x364abe['getIterator'](this['index_']);let _0x4e3ebc=0x0;for(;_0x3a0a42['hasNext']();){const _0xcc69ae=_0x3a0a42['getNext']();_0x4e3ebc<this['limit_']&&this['withinDirectionalStart'](_0xcc69ae)&&this['withinDirectionalEnd'](_0xcc69ae)?_0x4e3ebc++:_0x364abe=_0x364abe['updateImmediateChild'](_0xcc69ae['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x1f2231,_0x364abe,_0x55e83f);}['updatePriority'](_0xbf3105,_0x5e4226){return _0xbf3105;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x4e394a,_0x38f17b,_0x381b77,_0x608137,_0x42e103){let _0x3b5a8b;if(this['reverse_']){const _0x37f4bb=this['index_']['getCompare']();_0x3b5a8b=(_0x12a3bb,_0x2a94d7)=>_0x37f4bb(_0x2a94d7,_0x12a3bb);}else _0x3b5a8b=this['index_']['getCompare']();const _0x548052=_0x4e394a;f(_0x548052['numChildren']()===this['limit_'],'');const _0x213f65=new E(_0x38f17b,_0x381b77),_0x22273a=this['reverse_']?_0x548052['getFirstChild'](this['index_']):_0x548052['getLastChild'](this['index_']),_0x43895c=this['rangedFilter_']['matches'](_0x213f65);if(_0x548052['hasChild'](_0x38f17b)){const _0x54b67e=_0x548052['getImmediateChild'](_0x38f17b);let _0x3f6d75=_0x608137['getChildAfterChild'](this['index_'],_0x22273a,this['reverse_']);for(;_0x3f6d75!=null&&(_0x3f6d75['name']===_0x38f17b||_0x548052['hasChild'](_0x3f6d75['name']));)_0x3f6d75=_0x608137['getChildAfterChild'](this['index_'],_0x3f6d75,this['reverse_']);const _0x3323f3=_0x3f6d75==null?0x1:_0x3b5a8b(_0x3f6d75,_0x213f65);if(_0x43895c&&!_0x381b77['isEmpty']()&&_0x3323f3>=0x0)return _0x42e103!=null&&_0x42e103['trackChildChange'](xt(_0x38f17b,_0x381b77,_0x54b67e)),_0x548052['updateImmediateChild'](_0x38f17b,_0x381b77);{_0x42e103!=null&&_0x42e103['trackChildChange'](Lt(_0x38f17b,_0x54b67e));const _0x5eaae7=_0x548052['updateImmediateChild'](_0x38f17b,g['EMPTY_NODE']);return _0x3f6d75!=null&&this['rangedFilter_']['matches'](_0x3f6d75)?(_0x42e103!=null&&_0x42e103['trackChildChange'](rt(_0x3f6d75['name'],_0x3f6d75['node'])),_0x5eaae7['updateImmediateChild'](_0x3f6d75['name'],_0x3f6d75['node'])):_0x5eaae7;}}else return _0x381b77['isEmpty']()?_0x4e394a:_0x43895c&&_0x3b5a8b(_0x22273a,_0x213f65)>=0x0?(_0x42e103!=null&&(_0x42e103['trackChildChange'](Lt(_0x22273a['name'],_0x22273a['node'])),_0x42e103['trackChildChange'](rt(_0x38f17b,_0x381b77))),_0x548052['updateImmediateChild'](_0x38f17b,_0x381b77)['updateImmediateChild'](_0x22273a['name'],g['EMPTY_NODE'])):_0x4e394a;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x367c30=new Zi();return _0x367c30['limitSet_']=this['limitSet_'],_0x367c30['limit_']=this['limit_'],_0x367c30['startSet_']=this['startSet_'],_0x367c30['startAfterSet_']=this['startAfterSet_'],_0x367c30['indexStartValue_']=this['indexStartValue_'],_0x367c30['startNameSet_']=this['startNameSet_'],_0x367c30['indexStartName_']=this['indexStartName_'],_0x367c30['endSet_']=this['endSet_'],_0x367c30['endBeforeSet_']=this['endBeforeSet_'],_0x367c30['indexEndValue_']=this['indexEndValue_'],_0x367c30['endNameSet_']=this['endNameSet_'],_0x367c30['indexEndName_']=this['indexEndName_'],_0x367c30['index_']=this['index_'],_0x367c30['viewFrom_']=this['viewFrom_'],_0x367c30;}}function Kh(_0x5830e5){return _0x5830e5['loadsAllData']()?new Xi(_0x5830e5['getIndex']()):_0x5830e5['hasLimit']()?new jh(_0x5830e5):new Ft(_0x5830e5);}function Yh(_0x4ba6c2,_0x45067d){const _0x2c3efa=_0x4ba6c2['copy']();return _0x2c3efa['limitSet_']=!0x0,_0x2c3efa['limit_']=_0x45067d,_0x2c3efa['viewFrom_']='l',_0x2c3efa;}function Qh(_0x374e6c,_0x1c5352,_0xcc2c95){const _0x538057=_0x374e6c['copy']();return _0x538057['startSet_']=!0x0,_0x1c5352===void 0x0&&(_0x1c5352=null),_0x538057['indexStartValue_']=_0x1c5352,_0xcc2c95!=null?(_0x538057['startNameSet_']=!0x0,_0x538057['indexStartName_']=_0xcc2c95):(_0x538057['startNameSet_']=!0x1,_0x538057['indexStartName_']=''),_0x538057;}function Jh(_0x5802af,_0x3cd568,_0x59e497){const _0x1dc010=_0x5802af['copy']();return _0x1dc010['endSet_']=!0x0,_0x3cd568===void 0x0&&(_0x3cd568=null),_0x1dc010['indexEndValue_']=_0x3cd568,_0x59e497!==void 0x0?(_0x1dc010['endNameSet_']=!0x0,_0x1dc010['indexEndName_']=_0x59e497):(_0x1dc010['endNameSet_']=!0x1,_0x1dc010['indexEndName_']=''),_0x1dc010;}function xo(_0x799146,_0x3a7633){const _0x169a39=_0x799146['copy']();return _0x169a39['index_']=_0x3a7633,_0x169a39;}function ir(_0x33a852){const _0x2fcc04={};if(_0x33a852['isDefault']())return _0x2fcc04;let _0x4efba4;if(_0x33a852['index_']===R?_0x4efba4='$priority':_0x33a852['index_']===Mo?_0x4efba4='$value':_0x33a852['index_']===ve?_0x4efba4='$key':(f(_0x33a852['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x4efba4=_0x33a852['index_']['toString']()),_0x2fcc04['orderBy']=O(_0x4efba4),_0x33a852['startSet_']){const _0x5d9b65=_0x33a852['startAfterSet_']?'startAfter':'startAt';_0x2fcc04[_0x5d9b65]=O(_0x33a852['indexStartValue_']),_0x33a852['startNameSet_']&&(_0x2fcc04[_0x5d9b65]+=','+O(_0x33a852['indexStartName_']));}if(_0x33a852['endSet_']){const _0xffefdf=_0x33a852['endBeforeSet_']?'endBefore':'endAt';_0x2fcc04[_0xffefdf]=O(_0x33a852['indexEndValue_']),_0x33a852['endNameSet_']&&(_0x2fcc04[_0xffefdf]+=','+O(_0x33a852['indexEndName_']));}return _0x33a852['limitSet_']&&(_0x33a852['isViewFromLeft']()?_0x2fcc04['limitToFirst']=_0x33a852['limit_']:_0x2fcc04['limitToLast']=_0x33a852['limit_']),_0x2fcc04;}function sr(_0x424574){const _0xf8cd3={};if(_0x424574['startSet_']&&(_0xf8cd3['sp']=_0x424574['indexStartValue_'],_0x424574['startNameSet_']&&(_0xf8cd3['sn']=_0x424574['indexStartName_']),_0xf8cd3['sin']=!_0x424574['startAfterSet_']),_0x424574['endSet_']&&(_0xf8cd3['ep']=_0x424574['indexEndValue_'],_0x424574['endNameSet_']&&(_0xf8cd3['en']=_0x424574['indexEndName_']),_0xf8cd3['ein']=!_0x424574['endBeforeSet_']),_0x424574['limitSet_']){_0xf8cd3['l']=_0x424574['limit_'];let _0x47d457=_0x424574['viewFrom_'];_0x47d457===''&&(_0x424574['isViewFromLeft']()?_0x47d457='l':_0x47d457='r'),_0xf8cd3['vf']=_0x47d457;}return _0x424574['index_']!==R&&(_0xf8cd3['i']=_0x424574['index_']['toString']()),_0xf8cd3;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x3738ce){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x1233a4,_0x79104c){return _0x79104c!==void 0x0?'tag$'+_0x79104c:(f(_0x1233a4['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x1233a4['_path']['toString']());}constructor(_0x4969f5,_0x36f129,_0x12d324,_0x1d0b0d){super(),this['repoInfo_']=_0x4969f5,this['onDataUpdate_']=_0x36f129,this['authTokenProvider_']=_0x12d324,this['appCheckTokenProvider_']=_0x1d0b0d,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x1ea3a9,_0x5a22cf,_0x5f2558,_0x406aa1){const _0x76298e=_0x1ea3a9['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x76298e+'\x20'+_0x1ea3a9['_queryIdentifier']);const _0x2653b8=vn['getListenId_'](_0x1ea3a9,_0x5f2558),_0x57f67d={};this['listens_'][_0x2653b8]=_0x57f67d;const _0x22625b=ir(_0x1ea3a9['_queryParams']);this['restRequest_'](_0x76298e+'.json',_0x22625b,(_0x21aebf,_0x1b9fea)=>{let _0x18834c=_0x1b9fea;if(_0x21aebf===0x194&&(_0x18834c=null,_0x21aebf=null),_0x21aebf===null&&this['onDataUpdate_'](_0x76298e,_0x18834c,!0x1,_0x5f2558),Le(this['listens_'],_0x2653b8)===_0x57f67d){let _0x49e8af;_0x21aebf?_0x21aebf===0x191?_0x49e8af='permission_denied':_0x49e8af='rest_error:'+_0x21aebf:_0x49e8af='ok',_0x406aa1(_0x49e8af,null);}});}['unlisten'](_0x15b80a,_0x3ef5fd){const _0x3393c3=vn['getListenId_'](_0x15b80a,_0x3ef5fd);delete this['listens_'][_0x3393c3];}['get'](_0x2c23bf){const _0x313a53=ir(_0x2c23bf['_queryParams']),_0x1e3816=_0x2c23bf['_path']['toString'](),_0x505d7c=new H();return this['restRequest_'](_0x1e3816+'.json',_0x313a53,(_0x27ca16,_0x1ce717)=>{let _0x3dcfd0=_0x1ce717;_0x27ca16===0x194&&(_0x3dcfd0=null,_0x27ca16=null),_0x27ca16===null?(this['onDataUpdate_'](_0x1e3816,_0x3dcfd0,!0x1,null),_0x505d7c['resolve'](_0x3dcfd0)):_0x505d7c['reject'](new Error(_0x3dcfd0));}),_0x505d7c['promise'];}['refreshAuthToken'](_0x204988){}['restRequest_'](_0x1fd6df,_0x1389cd={},_0x2c78ed){return _0x1389cd['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x3c54e7,_0x4e820a])=>{_0x3c54e7&&_0x3c54e7['accessToken']&&(_0x1389cd['auth']=_0x3c54e7['accessToken']),_0x4e820a&&_0x4e820a['token']&&(_0x1389cd['ac']=_0x4e820a['token']);const _0x5d4c29=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x1fd6df+'?ns='+this['repoInfo_']['namespace']+ut(_0x1389cd);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x5d4c29);const _0x339eaa=new XMLHttpRequest();_0x339eaa['onreadystatechange']=()=>{if(_0x2c78ed&&_0x339eaa['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x5d4c29+'\x20received.\x20status:',_0x339eaa['status'],'response:',_0x339eaa['responseText']);let _0x2bdbb4=null;if(_0x339eaa['status']>=0xc8&&_0x339eaa['status']<0x12c){try{_0x2bdbb4=Nt(_0x339eaa['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x5d4c29+':\x20'+_0x339eaa['responseText']);}_0x2c78ed(null,_0x2bdbb4);}else _0x339eaa['status']!==0x191&&_0x339eaa['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x5d4c29+'\x20Status:\x20'+_0x339eaa['status']),_0x2c78ed(_0x339eaa['status']);_0x2c78ed=null;}},_0x339eaa['open']('GET',_0x5d4c29,!0x0),_0x339eaa['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x24004d){return this['rootNode_']['getChild'](_0x24004d);}['updateSnapshot'](_0x3838a3,_0x441ff1){this['rootNode_']=this['rootNode_']['updateChild'](_0x3838a3,_0x441ff1);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x2c17aa,_0x8e0f4f,_0x1b6e75){if(v(_0x8e0f4f))_0x2c17aa['value']=_0x1b6e75,_0x2c17aa['children']['clear']();else{if(_0x2c17aa['value']!==null)_0x2c17aa['value']=_0x2c17aa['value']['updateChild'](_0x8e0f4f,_0x1b6e75);else{const _0x3aae42=y(_0x8e0f4f);_0x2c17aa['children']['has'](_0x3aae42)||_0x2c17aa['children']['set'](_0x3aae42,En());const _0x16a7d9=_0x2c17aa['children']['get'](_0x3aae42);_0x8e0f4f=S(_0x8e0f4f),pt(_0x16a7d9,_0x8e0f4f,_0x1b6e75);}}}function Ti(_0x1363d8,_0xff055d){if(v(_0xff055d))return _0x1363d8['value']=null,_0x1363d8['children']['clear'](),!0x0;if(_0x1363d8['value']!==null){if(_0x1363d8['value']['isLeafNode']())return!0x1;{const _0x4ab959=_0x1363d8['value'];return _0x1363d8['value']=null,_0x4ab959['forEachChild'](R,(_0x1fb5ee,_0x1dcd7f)=>{pt(_0x1363d8,new C(_0x1fb5ee),_0x1dcd7f);}),Ti(_0x1363d8,_0xff055d);}}else{if(_0x1363d8['children']['size']>0x0){const _0x585e32=y(_0xff055d);return _0xff055d=S(_0xff055d),_0x1363d8['children']['has'](_0x585e32)&&Ti(_0x1363d8['children']['get'](_0x585e32),_0xff055d)&&_0x1363d8['children']['delete'](_0x585e32),_0x1363d8['children']['size']===0x0;}else return!0x0;}}function Si(_0x5c0312,_0x4c152f,_0x130022){_0x5c0312['value']!==null?_0x130022(_0x4c152f,_0x5c0312['value']):Zh(_0x5c0312,(_0x5aeeaa,_0x2936b9)=>{const _0x17a14c=new C(_0x4c152f['toString']()+'/'+_0x5aeeaa);Si(_0x2936b9,_0x17a14c,_0x130022);});}function Zh(_0x111f93,_0x1fe2a2){_0x111f93['children']['forEach']((_0x3150c3,_0x10ffb6)=>{_0x1fe2a2(_0x10ffb6,_0x3150c3);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x37ad4b){this['collection_']=_0x37ad4b,this['last_']=null;}['get'](){const _0x3ae572=this['collection_']['get'](),_0x13ae7e={..._0x3ae572};return this['last_']&&x(this['last_'],(_0x3f30cd,_0x4ac865)=>{_0x13ae7e[_0x3f30cd]=_0x13ae7e[_0x3f30cd]-_0x4ac865;}),this['last_']=_0x3ae572,_0x13ae7e;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x152008,_0x391fc9){this['server_']=_0x391fc9,this['statsToReport_']={},this['statsListener_']=new eu(_0x152008);const _0x5e844f=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x5e844f));}['reportStats_'](){const _0xa2614e=this['statsListener_']['get'](),_0x6ae7e3={};let _0x5a730a=!0x1;x(_0xa2614e,(_0x194042,_0x53b6eb)=>{_0x53b6eb>0x0&&Q(this['statsToReport_'],_0x194042)&&(_0x6ae7e3[_0x194042]=_0x53b6eb,_0x5a730a=!0x0);}),_0x5a730a&&this['server_']['reportStats'](_0x6ae7e3),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x385ad9){_0x385ad9[_0x385ad9['OVERWRITE']=0x0]='OVERWRITE',_0x385ad9[_0x385ad9['MERGE']=0x1]='MERGE',_0x385ad9[_0x385ad9['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x385ad9[_0x385ad9['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x2b1a2c){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x2b1a2c,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x4d6ac7,_0x42d8e8,_0x2ab039){this['path']=_0x4d6ac7,this['affectedTree']=_0x42d8e8,this['revert']=_0x2ab039,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x87a713){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x32c10e=this['affectedTree']['subtree'](new C(_0x87a713));return new In(w(),_0x32c10e,this['revert']);}}else return f(y(this['path'])===_0x87a713,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x412d30,_0xbf6928){this['source']=_0x412d30,this['path']=_0xbf6928,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x5bd56b){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0xf002ea,_0x348f9e,_0x48fba3){this['source']=_0xf002ea,this['path']=_0x348f9e,this['snap']=_0x48fba3,this['type']=z['OVERWRITE'];}['operationForChild'](_0xaeea3c){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0xaeea3c)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x278d8a,_0xa47db8,_0x329b4d){this['source']=_0x278d8a,this['path']=_0xa47db8,this['children']=_0x329b4d,this['type']=z['MERGE'];}['operationForChild'](_0x3b0b91){if(v(this['path'])){const _0x1b551d=this['children']['subtree'](new C(_0x3b0b91));return _0x1b551d['isEmpty']()?null:_0x1b551d['value']?new Be(this['source'],w(),_0x1b551d['value']):new ot(this['source'],w(),_0x1b551d);}else return f(y(this['path'])===_0x3b0b91,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x7cad29,_0x500548,_0x5127e0){this['node_']=_0x7cad29,this['fullyInitialized_']=_0x500548,this['filtered_']=_0x5127e0;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x403418){if(v(_0x403418))return this['isFullyInitialized']()&&!this['filtered_'];const _0x1c2bc1=y(_0x403418);return this['isCompleteForChild'](_0x1c2bc1);}['isCompleteForChild'](_0x2f3ea6){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x2f3ea6);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x557eeb){this['query_']=_0x557eeb,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0xf3cac5,_0x227302,_0x591691,_0x42de70){const _0x412dae=[],_0x30bbcf=[];return _0x227302['forEach'](_0x1d7836=>{_0x1d7836['type']==='child_changed'&&_0xf3cac5['index_']['indexedValueChanged'](_0x1d7836['oldSnap'],_0x1d7836['snapshotNode'])&&_0x30bbcf['push'](zh(_0x1d7836['childName'],_0x1d7836['snapshotNode']));}),wt(_0xf3cac5,_0x412dae,'child_removed',_0x227302,_0x42de70,_0x591691),wt(_0xf3cac5,_0x412dae,'child_added',_0x227302,_0x42de70,_0x591691),wt(_0xf3cac5,_0x412dae,'child_moved',_0x30bbcf,_0x42de70,_0x591691),wt(_0xf3cac5,_0x412dae,'child_changed',_0x227302,_0x42de70,_0x591691),wt(_0xf3cac5,_0x412dae,'value',_0x227302,_0x42de70,_0x591691),_0x412dae;}function wt(_0x30970c,_0x12bfdb,_0x4c3ddc,_0x3df24a,_0x176627,_0x139669){const _0x375d74=_0x3df24a['filter'](_0x545914=>_0x545914['type']===_0x4c3ddc);_0x375d74['sort']((_0x5d4941,_0x10ba9f)=>au(_0x30970c,_0x5d4941,_0x10ba9f)),_0x375d74['forEach'](_0x30853e=>{const _0x3fb4ee=ou(_0x30970c,_0x30853e,_0x139669);_0x176627['forEach'](_0x3a8da2=>{_0x3a8da2['respondsTo'](_0x30853e['type'])&&_0x12bfdb['push'](_0x3a8da2['createEvent'](_0x3fb4ee,_0x30970c['query_']));});});}function ou(_0x2f06a1,_0x5fafc8,_0xf53aa3){return _0x5fafc8['type']==='value'||_0x5fafc8['type']==='child_removed'||(_0x5fafc8['prevName']=_0xf53aa3['getPredecessorChildName'](_0x5fafc8['childName'],_0x5fafc8['snapshotNode'],_0x2f06a1['index_'])),_0x5fafc8;}function au(_0x3dbe02,_0x3e5ab5,_0x33e86b){if(_0x3e5ab5['childName']==null||_0x33e86b['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x256942=new E(_0x3e5ab5['childName'],_0x3e5ab5['snapshotNode']),_0x25abc5=new E(_0x33e86b['childName'],_0x33e86b['snapshotNode']);return _0x3dbe02['index_']['compare'](_0x256942,_0x25abc5);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x546587,_0x101ce2){return{'eventCache':_0x546587,'serverCache':_0x101ce2};}function Rt(_0xd1bedf,_0x45b64a,_0x498e5e,_0x4c0a6b){return Un(new Te(_0x45b64a,_0x498e5e,_0x4c0a6b),_0xd1bedf['serverCache']);}function Fo(_0x5431eb,_0x5ac187,_0xccbc30,_0x29d88e){return Un(_0x5431eb['eventCache'],new Te(_0x5ac187,_0xccbc30,_0x29d88e));}function wn(_0x3cbe35){return _0x3cbe35['eventCache']['isFullyInitialized']()?_0x3cbe35['eventCache']['getNode']():null;}function Ve(_0x29a251){return _0x29a251['serverCache']['isFullyInitialized']()?_0x29a251['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0xfd5623){let _0x62f0d3=new b(null);return x(_0xfd5623,(_0x4ea8e9,_0x46b8eb)=>{_0x62f0d3=_0x62f0d3['set'](new C(_0x4ea8e9),_0x46b8eb);}),_0x62f0d3;}constructor(_0x340341,_0x74ff89=cu()){this['value']=_0x340341,this['children']=_0x74ff89;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x210619,_0x5b1ca5){if(this['value']!=null&&_0x5b1ca5(this['value']))return{'path':w(),'value':this['value']};if(v(_0x210619))return null;{const _0x54fbab=y(_0x210619),_0x199d6d=this['children']['get'](_0x54fbab);if(_0x199d6d!==null){const _0x3f164b=_0x199d6d['findRootMostMatchingPathAndValue'](S(_0x210619),_0x5b1ca5);return _0x3f164b!=null?{'path':k(new C(_0x54fbab),_0x3f164b['path']),'value':_0x3f164b['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x5ed9eb){return this['findRootMostMatchingPathAndValue'](_0x5ed9eb,()=>!0x0);}['subtree'](_0x4ca3d3){if(v(_0x4ca3d3))return this;{const _0x14142f=y(_0x4ca3d3),_0x6d16f1=this['children']['get'](_0x14142f);return _0x6d16f1!==null?_0x6d16f1['subtree'](S(_0x4ca3d3)):new b(null);}}['set'](_0x18282f,_0x4a043a){if(v(_0x18282f))return new b(_0x4a043a,this['children']);{const _0x236bf6=y(_0x18282f),_0x18a465=(this['children']['get'](_0x236bf6)||new b(null))['set'](S(_0x18282f),_0x4a043a),_0x3383c9=this['children']['insert'](_0x236bf6,_0x18a465);return new b(this['value'],_0x3383c9);}}['remove'](_0x3d5f0b){if(v(_0x3d5f0b))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0xb1ec52=y(_0x3d5f0b),_0x18bdb1=this['children']['get'](_0xb1ec52);if(_0x18bdb1){const _0x45edf3=_0x18bdb1['remove'](S(_0x3d5f0b));let _0x34cea3;return _0x45edf3['isEmpty']()?_0x34cea3=this['children']['remove'](_0xb1ec52):_0x34cea3=this['children']['insert'](_0xb1ec52,_0x45edf3),this['value']===null&&_0x34cea3['isEmpty']()?new b(null):new b(this['value'],_0x34cea3);}else return this;}}['get'](_0x17204a){if(v(_0x17204a))return this['value'];{const _0x4c3970=y(_0x17204a),_0x58990f=this['children']['get'](_0x4c3970);return _0x58990f?_0x58990f['get'](S(_0x17204a)):null;}}['setTree'](_0x341271,_0x420fd0){if(v(_0x341271))return _0x420fd0;{const _0x27469d=y(_0x341271),_0x30eb47=(this['children']['get'](_0x27469d)||new b(null))['setTree'](S(_0x341271),_0x420fd0);let _0x6e7c8d;return _0x30eb47['isEmpty']()?_0x6e7c8d=this['children']['remove'](_0x27469d):_0x6e7c8d=this['children']['insert'](_0x27469d,_0x30eb47),new b(this['value'],_0x6e7c8d);}}['fold'](_0x5b2a18){return this['fold_'](w(),_0x5b2a18);}['fold_'](_0x425491,_0x105fe7){const _0x4be98f={};return this['children']['inorderTraversal']((_0x3af916,_0x3b1d12)=>{_0x4be98f[_0x3af916]=_0x3b1d12['fold_'](k(_0x425491,_0x3af916),_0x105fe7);}),_0x105fe7(_0x425491,this['value'],_0x4be98f);}['findOnPath'](_0x2a4952,_0x22e58a){return this['findOnPath_'](_0x2a4952,w(),_0x22e58a);}['findOnPath_'](_0x4ae4c0,_0x2d7e2b,_0xec6660){const _0x395b0c=this['value']?_0xec6660(_0x2d7e2b,this['value']):!0x1;if(_0x395b0c)return _0x395b0c;if(v(_0x4ae4c0))return null;{const _0x291898=y(_0x4ae4c0),_0x4c1fa5=this['children']['get'](_0x291898);return _0x4c1fa5?_0x4c1fa5['findOnPath_'](S(_0x4ae4c0),k(_0x2d7e2b,_0x291898),_0xec6660):null;}}['foreachOnPath'](_0x4a6ce9,_0x5c3b38){return this['foreachOnPath_'](_0x4a6ce9,w(),_0x5c3b38);}['foreachOnPath_'](_0x141274,_0x453b18,_0x9995a1){if(v(_0x141274))return this;{this['value']&&_0x9995a1(_0x453b18,this['value']);const _0x1446a6=y(_0x141274),_0x46adf4=this['children']['get'](_0x1446a6);return _0x46adf4?_0x46adf4['foreachOnPath_'](S(_0x141274),k(_0x453b18,_0x1446a6),_0x9995a1):new b(null);}}['foreach'](_0x3fa30f){this['foreach_'](w(),_0x3fa30f);}['foreach_'](_0x3ca0ac,_0x1aaeac){this['children']['inorderTraversal']((_0x3e1f0c,_0x160a61)=>{_0x160a61['foreach_'](k(_0x3ca0ac,_0x3e1f0c),_0x1aaeac);}),this['value']&&_0x1aaeac(_0x3ca0ac,this['value']);}['foreachChild'](_0x4bb293){this['children']['inorderTraversal']((_0x436474,_0x2a39d6)=>{_0x2a39d6['value']&&_0x4bb293(_0x436474,_0x2a39d6['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x42d800){this['writeTree_']=_0x42d800;}static['empty'](){return new K(new b(null));}}function At(_0x56694d,_0x3d138a,_0x2ac12c){if(v(_0x3d138a))return new K(new b(_0x2ac12c));{const _0x51cfcf=_0x56694d['writeTree_']['findRootMostValueAndPath'](_0x3d138a);if(_0x51cfcf!=null){const _0x205747=_0x51cfcf['path'];let _0x4304cf=_0x51cfcf['value'];const _0x19b3f8=F(_0x205747,_0x3d138a);return _0x4304cf=_0x4304cf['updateChild'](_0x19b3f8,_0x2ac12c),new K(_0x56694d['writeTree_']['set'](_0x205747,_0x4304cf));}else{const _0x275d8b=new b(_0x2ac12c),_0x19d68d=_0x56694d['writeTree_']['setTree'](_0x3d138a,_0x275d8b);return new K(_0x19d68d);}}}function bi(_0x53a5a7,_0x2bfbac,_0x585ccb){let _0x47414c=_0x53a5a7;return x(_0x585ccb,(_0xa799f7,_0x20eef0)=>{_0x47414c=At(_0x47414c,k(_0x2bfbac,_0xa799f7),_0x20eef0);}),_0x47414c;}function or(_0x508ece,_0x3b901c){if(v(_0x3b901c))return K['empty']();{const _0x3478d3=_0x508ece['writeTree_']['setTree'](_0x3b901c,new b(null));return new K(_0x3478d3);}}function Ri(_0x37d2fb,_0x4c53df){return ze(_0x37d2fb,_0x4c53df)!=null;}function ze(_0x36efea,_0x252fa0){const _0x1b806e=_0x36efea['writeTree_']['findRootMostValueAndPath'](_0x252fa0);return _0x1b806e!=null?_0x36efea['writeTree_']['get'](_0x1b806e['path'])['getChild'](F(_0x1b806e['path'],_0x252fa0)):null;}function ar(_0x19178){const _0x64a7b0=[],_0x25cce8=_0x19178['writeTree_']['value'];return _0x25cce8!=null?_0x25cce8['isLeafNode']()||_0x25cce8['forEachChild'](R,(_0x4cde6c,_0x3b19e2)=>{_0x64a7b0['push'](new E(_0x4cde6c,_0x3b19e2));}):_0x19178['writeTree_']['children']['inorderTraversal']((_0x55f6df,_0x369e5a)=>{_0x369e5a['value']!=null&&_0x64a7b0['push'](new E(_0x55f6df,_0x369e5a['value']));}),_0x64a7b0;}function Ee(_0x472f9a,_0x4b5ef9){if(v(_0x4b5ef9))return _0x472f9a;{const _0x3de27d=ze(_0x472f9a,_0x4b5ef9);return _0x3de27d!=null?new K(new b(_0x3de27d)):new K(_0x472f9a['writeTree_']['subtree'](_0x4b5ef9));}}function Ai(_0x93f7d8){return _0x93f7d8['writeTree_']['isEmpty']();}function at(_0xf9b5c1,_0x473470){return Uo(w(),_0xf9b5c1['writeTree_'],_0x473470);}function Uo(_0x49b61f,_0x378b90,_0x1a6159){if(_0x378b90['value']!=null)return _0x1a6159['updateChild'](_0x49b61f,_0x378b90['value']);{let _0x29bca1=null;return _0x378b90['children']['inorderTraversal']((_0x4f8699,_0x37e8fc)=>{_0x4f8699==='.priority'?(f(_0x37e8fc['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x29bca1=_0x37e8fc['value']):_0x1a6159=Uo(k(_0x49b61f,_0x4f8699),_0x37e8fc,_0x1a6159);}),!_0x1a6159['getChild'](_0x49b61f)['isEmpty']()&&_0x29bca1!==null&&(_0x1a6159=_0x1a6159['updateChild'](k(_0x49b61f,'.priority'),_0x29bca1)),_0x1a6159;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x28c3ca,_0x5cb468){return Ho(_0x5cb468,_0x28c3ca);}function lu(_0x476431,_0x3cb95c,_0x308713,_0x4597cf,_0x29abb4){f(_0x4597cf>_0x476431['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x29abb4===void 0x0&&(_0x29abb4=!0x0),_0x476431['allWrites']['push']({'path':_0x3cb95c,'snap':_0x308713,'writeId':_0x4597cf,'visible':_0x29abb4}),_0x29abb4&&(_0x476431['visibleWrites']=At(_0x476431['visibleWrites'],_0x3cb95c,_0x308713)),_0x476431['lastWriteId']=_0x4597cf;}function hu(_0x573779,_0x5b907c,_0x52a8ac,_0x516200){f(_0x516200>_0x573779['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x573779['allWrites']['push']({'path':_0x5b907c,'children':_0x52a8ac,'writeId':_0x516200,'visible':!0x0}),_0x573779['visibleWrites']=bi(_0x573779['visibleWrites'],_0x5b907c,_0x52a8ac),_0x573779['lastWriteId']=_0x516200;}function uu(_0x133e8a,_0x50c3a2){for(let _0x497c98=0x0;_0x497c98<_0x133e8a['allWrites']['length'];_0x497c98++){const _0x503c1c=_0x133e8a['allWrites'][_0x497c98];if(_0x503c1c['writeId']===_0x50c3a2)return _0x503c1c;}return null;}function du(_0x486ebe,_0x3a96b6){const _0x1f1794=_0x486ebe['allWrites']['findIndex'](_0x3a6bd9=>_0x3a6bd9['writeId']===_0x3a96b6);f(_0x1f1794>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x28d8d5=_0x486ebe['allWrites'][_0x1f1794];_0x486ebe['allWrites']['splice'](_0x1f1794,0x1);let _0x30fad6=_0x28d8d5['visible'],_0x5218a7=!0x1,_0x3a5282=_0x486ebe['allWrites']['length']-0x1;for(;_0x30fad6&&_0x3a5282>=0x0;){const _0x51e7cf=_0x486ebe['allWrites'][_0x3a5282];_0x51e7cf['visible']&&(_0x3a5282>=_0x1f1794&&fu(_0x51e7cf,_0x28d8d5['path'])?_0x30fad6=!0x1:G(_0x28d8d5['path'],_0x51e7cf['path'])&&(_0x5218a7=!0x0)),_0x3a5282--;}if(_0x30fad6){if(_0x5218a7)return pu(_0x486ebe),!0x0;if(_0x28d8d5['snap'])_0x486ebe['visibleWrites']=or(_0x486ebe['visibleWrites'],_0x28d8d5['path']);else{const _0x4ae62f=_0x28d8d5['children'];x(_0x4ae62f,_0x97c71f=>{_0x486ebe['visibleWrites']=or(_0x486ebe['visibleWrites'],k(_0x28d8d5['path'],_0x97c71f));});}return!0x0;}else return!0x1;}function fu(_0x2e50dc,_0x4c7ebc){if(_0x2e50dc['snap'])return G(_0x2e50dc['path'],_0x4c7ebc);for(const _0x55b72a in _0x2e50dc['children'])if(_0x2e50dc['children']['hasOwnProperty'](_0x55b72a)&&G(k(_0x2e50dc['path'],_0x55b72a),_0x4c7ebc))return!0x0;return!0x1;}function pu(_0xfd3384){_0xfd3384['visibleWrites']=Wo(_0xfd3384['allWrites'],_u,w()),_0xfd3384['allWrites']['length']>0x0?_0xfd3384['lastWriteId']=_0xfd3384['allWrites'][_0xfd3384['allWrites']['length']-0x1]['writeId']:_0xfd3384['lastWriteId']=-0x1;}function _u(_0x26934b){return _0x26934b['visible'];}function Wo(_0x1380d6,_0x1433fb,_0x394a2c){let _0x3ab72f=K['empty']();for(let _0x36c3dd=0x0;_0x36c3dd<_0x1380d6['length'];++_0x36c3dd){const _0x373b2e=_0x1380d6[_0x36c3dd];if(_0x1433fb(_0x373b2e)){const _0x372655=_0x373b2e['path'];let _0x32c06c;if(_0x373b2e['snap'])G(_0x394a2c,_0x372655)?(_0x32c06c=F(_0x394a2c,_0x372655),_0x3ab72f=At(_0x3ab72f,_0x32c06c,_0x373b2e['snap'])):G(_0x372655,_0x394a2c)&&(_0x32c06c=F(_0x372655,_0x394a2c),_0x3ab72f=At(_0x3ab72f,w(),_0x373b2e['snap']['getChild'](_0x32c06c)));else{if(_0x373b2e['children']){if(G(_0x394a2c,_0x372655))_0x32c06c=F(_0x394a2c,_0x372655),_0x3ab72f=bi(_0x3ab72f,_0x32c06c,_0x373b2e['children']);else{if(G(_0x372655,_0x394a2c)){if(_0x32c06c=F(_0x372655,_0x394a2c),v(_0x32c06c))_0x3ab72f=bi(_0x3ab72f,w(),_0x373b2e['children']);else{const _0x1cd03e=Le(_0x373b2e['children'],y(_0x32c06c));if(_0x1cd03e){const _0x84e5b2=_0x1cd03e['getChild'](S(_0x32c06c));_0x3ab72f=At(_0x3ab72f,w(),_0x84e5b2);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x3ab72f;}function Bo(_0x58163b,_0x383179,_0x39856a,_0x1d647d,_0x4a426b){if(!_0x1d647d&&!_0x4a426b){const _0xa4e49d=ze(_0x58163b['visibleWrites'],_0x383179);if(_0xa4e49d!=null)return _0xa4e49d;{const _0x5099b2=Ee(_0x58163b['visibleWrites'],_0x383179);if(Ai(_0x5099b2))return _0x39856a;if(_0x39856a==null&&!Ri(_0x5099b2,w()))return null;{const _0x15a863=_0x39856a||g['EMPTY_NODE'];return at(_0x5099b2,_0x15a863);}}}else{const _0x39bcea=Ee(_0x58163b['visibleWrites'],_0x383179);if(!_0x4a426b&&Ai(_0x39bcea))return _0x39856a;if(!_0x4a426b&&_0x39856a==null&&!Ri(_0x39bcea,w()))return null;{const _0x19e63c=function(_0x317af7){return(_0x317af7['visible']||_0x4a426b)&&(!_0x1d647d||!~_0x1d647d['indexOf'](_0x317af7['writeId']))&&(G(_0x317af7['path'],_0x383179)||G(_0x383179,_0x317af7['path']));},_0x1514b0=Wo(_0x58163b['allWrites'],_0x19e63c,_0x383179),_0x367166=_0x39856a||g['EMPTY_NODE'];return at(_0x1514b0,_0x367166);}}}function gu(_0x11ba3a,_0x9554f2,_0x770457){let _0x28be3c=g['EMPTY_NODE'];const _0x253822=ze(_0x11ba3a['visibleWrites'],_0x9554f2);if(_0x253822)return _0x253822['isLeafNode']()||_0x253822['forEachChild'](R,(_0x234600,_0x3129a8)=>{_0x28be3c=_0x28be3c['updateImmediateChild'](_0x234600,_0x3129a8);}),_0x28be3c;if(_0x770457){const _0x5c58fd=Ee(_0x11ba3a['visibleWrites'],_0x9554f2);return _0x770457['forEachChild'](R,(_0x3807c3,_0x42e57e)=>{const _0xe8c0c5=at(Ee(_0x5c58fd,new C(_0x3807c3)),_0x42e57e);_0x28be3c=_0x28be3c['updateImmediateChild'](_0x3807c3,_0xe8c0c5);}),ar(_0x5c58fd)['forEach'](_0x3235b3=>{_0x28be3c=_0x28be3c['updateImmediateChild'](_0x3235b3['name'],_0x3235b3['node']);}),_0x28be3c;}else{const _0x1ba84f=Ee(_0x11ba3a['visibleWrites'],_0x9554f2);return ar(_0x1ba84f)['forEach'](_0x14f670=>{_0x28be3c=_0x28be3c['updateImmediateChild'](_0x14f670['name'],_0x14f670['node']);}),_0x28be3c;}}function mu(_0x1e969c,_0x395298,_0x74ba69,_0x54c877,_0x430a09){f(_0x54c877||_0x430a09,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x8aeb3e=k(_0x395298,_0x74ba69);if(Ri(_0x1e969c['visibleWrites'],_0x8aeb3e))return null;{const _0x2f9ddc=Ee(_0x1e969c['visibleWrites'],_0x8aeb3e);return Ai(_0x2f9ddc)?_0x430a09['getChild'](_0x74ba69):at(_0x2f9ddc,_0x430a09['getChild'](_0x74ba69));}}function yu(_0x791614,_0x137681,_0x20b3ca,_0x114786){const _0x335ae8=k(_0x137681,_0x20b3ca),_0x2300fd=ze(_0x791614['visibleWrites'],_0x335ae8);if(_0x2300fd!=null)return _0x2300fd;if(_0x114786['isCompleteForChild'](_0x20b3ca)){const _0x4782fc=Ee(_0x791614['visibleWrites'],_0x335ae8);return at(_0x4782fc,_0x114786['getNode']()['getImmediateChild'](_0x20b3ca));}else return null;}function vu(_0x4805fc,_0x56c526){return ze(_0x4805fc['visibleWrites'],_0x56c526);}function Eu(_0xd17f9,_0x3eecc1,_0x2ec28b,_0x416086,_0x304bbf,_0x3b324d,_0x4e158b){let _0x1aef15;const _0x5b9ce7=Ee(_0xd17f9['visibleWrites'],_0x3eecc1),_0x33e30e=ze(_0x5b9ce7,w());if(_0x33e30e!=null)_0x1aef15=_0x33e30e;else{if(_0x2ec28b!=null)_0x1aef15=at(_0x5b9ce7,_0x2ec28b);else return[];}if(_0x1aef15=_0x1aef15['withIndex'](_0x4e158b),!_0x1aef15['isEmpty']()&&!_0x1aef15['isLeafNode']()){const _0x28e84c=[],_0x2302da=_0x4e158b['getCompare'](),_0x39425e=_0x3b324d?_0x1aef15['getReverseIteratorFrom'](_0x416086,_0x4e158b):_0x1aef15['getIteratorFrom'](_0x416086,_0x4e158b);let _0x5a1e2b=_0x39425e['getNext']();for(;_0x5a1e2b&&_0x28e84c['length']<_0x304bbf;)_0x2302da(_0x5a1e2b,_0x416086)!==0x0&&_0x28e84c['push'](_0x5a1e2b),_0x5a1e2b=_0x39425e['getNext']();return _0x28e84c;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x558437,_0x96439c,_0x378295,_0x16d3ea){return Bo(_0x558437['writeTree'],_0x558437['treePath'],_0x96439c,_0x378295,_0x16d3ea);}function is(_0xa9b7,_0x46c9d1){return gu(_0xa9b7['writeTree'],_0xa9b7['treePath'],_0x46c9d1);}function cr(_0x8d4fd9,_0x285499,_0x3090a1,_0x4e08bd){return mu(_0x8d4fd9['writeTree'],_0x8d4fd9['treePath'],_0x285499,_0x3090a1,_0x4e08bd);}function Tn(_0x4c9e94,_0x18dd21){return vu(_0x4c9e94['writeTree'],k(_0x4c9e94['treePath'],_0x18dd21));}function wu(_0x99d46f,_0x35ed6c,_0x30485f,_0x24474b,_0x47a9c4,_0x66a0a8){return Eu(_0x99d46f['writeTree'],_0x99d46f['treePath'],_0x35ed6c,_0x30485f,_0x24474b,_0x47a9c4,_0x66a0a8);}function ss(_0x147700,_0x1b34b0,_0x58125){return yu(_0x147700['writeTree'],_0x147700['treePath'],_0x1b34b0,_0x58125);}function Vo(_0x28dfc7,_0x5176b2){return Ho(k(_0x28dfc7['treePath'],_0x5176b2),_0x28dfc7['writeTree']);}function Ho(_0x2e2157,_0x8d04eb){return{'treePath':_0x2e2157,'writeTree':_0x8d04eb};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x48bce4){const _0x19a7a7=_0x48bce4['type'],_0x43db0e=_0x48bce4['childName'];f(_0x19a7a7==='child_added'||_0x19a7a7==='child_changed'||_0x19a7a7==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x43db0e!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x3f0fe6=this['changeMap']['get'](_0x43db0e);if(_0x3f0fe6){const _0x2e9f00=_0x3f0fe6['type'];if(_0x19a7a7==='child_added'&&_0x2e9f00==='child_removed')this['changeMap']['set'](_0x43db0e,xt(_0x43db0e,_0x48bce4['snapshotNode'],_0x3f0fe6['snapshotNode']));else{if(_0x19a7a7==='child_removed'&&_0x2e9f00==='child_added')this['changeMap']['delete'](_0x43db0e);else{if(_0x19a7a7==='child_removed'&&_0x2e9f00==='child_changed')this['changeMap']['set'](_0x43db0e,Lt(_0x43db0e,_0x3f0fe6['oldSnap']));else{if(_0x19a7a7==='child_changed'&&_0x2e9f00==='child_added')this['changeMap']['set'](_0x43db0e,rt(_0x43db0e,_0x48bce4['snapshotNode']));else{if(_0x19a7a7==='child_changed'&&_0x2e9f00==='child_changed')this['changeMap']['set'](_0x43db0e,xt(_0x43db0e,_0x48bce4['snapshotNode'],_0x3f0fe6['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x48bce4+'\x20occurred\x20after\x20'+_0x3f0fe6);}}}}}else this['changeMap']['set'](_0x43db0e,_0x48bce4);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x3d8fd8){return null;}['getChildAfterChild'](_0x12cfc9,_0x563cac,_0x375ae9){return null;}}const $o=new Tu();class rs{constructor(_0xec107e,_0x5db698,_0x483bf7=null){this['writes_']=_0xec107e,this['viewCache_']=_0x5db698,this['optCompleteServerCache_']=_0x483bf7;}['getCompleteChild'](_0x21c90d){const _0x4a0b2e=this['viewCache_']['eventCache'];if(_0x4a0b2e['isCompleteForChild'](_0x21c90d))return _0x4a0b2e['getNode']()['getImmediateChild'](_0x21c90d);{const _0x1af3b9=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x21c90d,_0x1af3b9);}}['getChildAfterChild'](_0x392337,_0x12be67,_0x59c418){const _0xf67097=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x2f0e7b=wu(this['writes_'],_0xf67097,_0x12be67,0x1,_0x59c418,_0x392337);return _0x2f0e7b['length']===0x0?null:_0x2f0e7b[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x30333f){return{'filter':_0x30333f};}function bu(_0xbc7e81,_0x3428f0){f(_0x3428f0['eventCache']['getNode']()['isIndexed'](_0xbc7e81['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x3428f0['serverCache']['getNode']()['isIndexed'](_0xbc7e81['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x2ad430,_0x1188da,_0x226921,_0x4fbdc6,_0x34d9db){const _0xf24aeb=new Cu();let _0x2d10f8,_0x571074;if(_0x226921['type']===z['OVERWRITE']){const _0x516e74=_0x226921;_0x516e74['source']['fromUser']?_0x2d10f8=ki(_0x2ad430,_0x1188da,_0x516e74['path'],_0x516e74['snap'],_0x4fbdc6,_0x34d9db,_0xf24aeb):(f(_0x516e74['source']['fromServer'],'Unknown\x20source.'),_0x571074=_0x516e74['source']['tagged']||_0x1188da['serverCache']['isFiltered']()&&!v(_0x516e74['path']),_0x2d10f8=Sn(_0x2ad430,_0x1188da,_0x516e74['path'],_0x516e74['snap'],_0x4fbdc6,_0x34d9db,_0x571074,_0xf24aeb));}else{if(_0x226921['type']===z['MERGE']){const _0x3bfb2f=_0x226921;_0x3bfb2f['source']['fromUser']?_0x2d10f8=ku(_0x2ad430,_0x1188da,_0x3bfb2f['path'],_0x3bfb2f['children'],_0x4fbdc6,_0x34d9db,_0xf24aeb):(f(_0x3bfb2f['source']['fromServer'],'Unknown\x20source.'),_0x571074=_0x3bfb2f['source']['tagged']||_0x1188da['serverCache']['isFiltered'](),_0x2d10f8=Pi(_0x2ad430,_0x1188da,_0x3bfb2f['path'],_0x3bfb2f['children'],_0x4fbdc6,_0x34d9db,_0x571074,_0xf24aeb));}else{if(_0x226921['type']===z['ACK_USER_WRITE']){const _0x2b571a=_0x226921;_0x2b571a['revert']?_0x2d10f8=Ou(_0x2ad430,_0x1188da,_0x2b571a['path'],_0x4fbdc6,_0x34d9db,_0xf24aeb):_0x2d10f8=Pu(_0x2ad430,_0x1188da,_0x2b571a['path'],_0x2b571a['affectedTree'],_0x4fbdc6,_0x34d9db,_0xf24aeb);}else{if(_0x226921['type']===z['LISTEN_COMPLETE'])_0x2d10f8=Nu(_0x2ad430,_0x1188da,_0x226921['path'],_0x4fbdc6,_0xf24aeb);else throw ht('Unknown\x20operation\x20type:\x20'+_0x226921['type']);}}}const _0x513de8=_0xf24aeb['getChanges']();return Au(_0x1188da,_0x2d10f8,_0x513de8),{'viewCache':_0x2d10f8,'changes':_0x513de8};}function Au(_0xea0be,_0x4d9ee9,_0x2a80d6){const _0x181150=_0x4d9ee9['eventCache'];if(_0x181150['isFullyInitialized']()){const _0x2792fb=_0x181150['getNode']()['isLeafNode']()||_0x181150['getNode']()['isEmpty'](),_0x2a8630=wn(_0xea0be);(_0x2a80d6['length']>0x0||!_0xea0be['eventCache']['isFullyInitialized']()||_0x2792fb&&!_0x181150['getNode']()['equals'](_0x2a8630)||!_0x181150['getNode']()['getPriority']()['equals'](_0x2a8630['getPriority']()))&&_0x2a80d6['push'](Lo(wn(_0x4d9ee9)));}}function Go(_0x445418,_0x41f2e0,_0x514d6e,_0x3dff0f,_0x121f29,_0x4fa442){const _0x8edec6=_0x41f2e0['eventCache'];if(Tn(_0x3dff0f,_0x514d6e)!=null)return _0x41f2e0;{let _0x4ef913,_0x4f9e16;if(v(_0x514d6e)){if(f(_0x41f2e0['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x41f2e0['serverCache']['isFiltered']()){const _0x310106=Ve(_0x41f2e0),_0x3ab9fc=_0x310106 instanceof g?_0x310106:g['EMPTY_NODE'],_0x55c56d=is(_0x3dff0f,_0x3ab9fc);_0x4ef913=_0x445418['filter']['updateFullNode'](_0x41f2e0['eventCache']['getNode'](),_0x55c56d,_0x4fa442);}else{const _0x1a539=Cn(_0x3dff0f,Ve(_0x41f2e0));_0x4ef913=_0x445418['filter']['updateFullNode'](_0x41f2e0['eventCache']['getNode'](),_0x1a539,_0x4fa442);}}else{const _0x5903e9=y(_0x514d6e);if(_0x5903e9==='.priority'){f(Ce(_0x514d6e)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0xda6ec7=_0x8edec6['getNode']();_0x4f9e16=_0x41f2e0['serverCache']['getNode']();const _0x512729=cr(_0x3dff0f,_0x514d6e,_0xda6ec7,_0x4f9e16);_0x512729!=null?_0x4ef913=_0x445418['filter']['updatePriority'](_0xda6ec7,_0x512729):_0x4ef913=_0x8edec6['getNode']();}else{const _0x48789c=S(_0x514d6e);let _0x51e68a;if(_0x8edec6['isCompleteForChild'](_0x5903e9)){_0x4f9e16=_0x41f2e0['serverCache']['getNode']();const _0x389590=cr(_0x3dff0f,_0x514d6e,_0x8edec6['getNode'](),_0x4f9e16);_0x389590!=null?_0x51e68a=_0x8edec6['getNode']()['getImmediateChild'](_0x5903e9)['updateChild'](_0x48789c,_0x389590):_0x51e68a=_0x8edec6['getNode']()['getImmediateChild'](_0x5903e9);}else _0x51e68a=ss(_0x3dff0f,_0x5903e9,_0x41f2e0['serverCache']);_0x51e68a!=null?_0x4ef913=_0x445418['filter']['updateChild'](_0x8edec6['getNode'](),_0x5903e9,_0x51e68a,_0x48789c,_0x121f29,_0x4fa442):_0x4ef913=_0x8edec6['getNode']();}}return Rt(_0x41f2e0,_0x4ef913,_0x8edec6['isFullyInitialized']()||v(_0x514d6e),_0x445418['filter']['filtersNodes']());}}function Sn(_0x1ab792,_0x33a819,_0x35175c,_0x1a903d,_0x5da63e,_0x162ed7,_0x1edb1f,_0x26eaa3){const _0x2c6baa=_0x33a819['serverCache'];let _0x3bb464;const _0x41ad77=_0x1edb1f?_0x1ab792['filter']:_0x1ab792['filter']['getIndexedFilter']();if(v(_0x35175c))_0x3bb464=_0x41ad77['updateFullNode'](_0x2c6baa['getNode'](),_0x1a903d,null);else{if(_0x41ad77['filtersNodes']()&&!_0x2c6baa['isFiltered']()){const _0x17725a=_0x2c6baa['getNode']()['updateChild'](_0x35175c,_0x1a903d);_0x3bb464=_0x41ad77['updateFullNode'](_0x2c6baa['getNode'](),_0x17725a,null);}else{const _0xd0c4ef=y(_0x35175c);if(!_0x2c6baa['isCompleteForPath'](_0x35175c)&&Ce(_0x35175c)>0x1)return _0x33a819;const _0xadf59d=S(_0x35175c),_0x2cecc8=_0x2c6baa['getNode']()['getImmediateChild'](_0xd0c4ef)['updateChild'](_0xadf59d,_0x1a903d);_0xd0c4ef==='.priority'?_0x3bb464=_0x41ad77['updatePriority'](_0x2c6baa['getNode'](),_0x2cecc8):_0x3bb464=_0x41ad77['updateChild'](_0x2c6baa['getNode'](),_0xd0c4ef,_0x2cecc8,_0xadf59d,$o,null);}}const _0xc9715=Fo(_0x33a819,_0x3bb464,_0x2c6baa['isFullyInitialized']()||v(_0x35175c),_0x41ad77['filtersNodes']()),_0xb6e323=new rs(_0x5da63e,_0xc9715,_0x162ed7);return Go(_0x1ab792,_0xc9715,_0x35175c,_0x5da63e,_0xb6e323,_0x26eaa3);}function ki(_0x290bcd,_0x37a0d7,_0x54318d,_0x566747,_0x197534,_0x4bdae2,_0x407476){const _0x240405=_0x37a0d7['eventCache'];let _0x2e4cb3,_0x122ff8;const _0x5d21f9=new rs(_0x197534,_0x37a0d7,_0x4bdae2);if(v(_0x54318d))_0x122ff8=_0x290bcd['filter']['updateFullNode'](_0x37a0d7['eventCache']['getNode'](),_0x566747,_0x407476),_0x2e4cb3=Rt(_0x37a0d7,_0x122ff8,!0x0,_0x290bcd['filter']['filtersNodes']());else{const _0x43ae4e=y(_0x54318d);if(_0x43ae4e==='.priority')_0x122ff8=_0x290bcd['filter']['updatePriority'](_0x37a0d7['eventCache']['getNode'](),_0x566747),_0x2e4cb3=Rt(_0x37a0d7,_0x122ff8,_0x240405['isFullyInitialized'](),_0x240405['isFiltered']());else{const _0x7b1692=S(_0x54318d),_0x68c604=_0x240405['getNode']()['getImmediateChild'](_0x43ae4e);let _0x19efda;if(v(_0x7b1692))_0x19efda=_0x566747;else{const _0x29a024=_0x5d21f9['getCompleteChild'](_0x43ae4e);_0x29a024!=null?ji(_0x7b1692)==='.priority'&&_0x29a024['getChild'](Ro(_0x7b1692))['isEmpty']()?_0x19efda=_0x29a024:_0x19efda=_0x29a024['updateChild'](_0x7b1692,_0x566747):_0x19efda=g['EMPTY_NODE'];}if(_0x68c604['equals'](_0x19efda))_0x2e4cb3=_0x37a0d7;else{const _0xdd87d8=_0x290bcd['filter']['updateChild'](_0x240405['getNode'](),_0x43ae4e,_0x19efda,_0x7b1692,_0x5d21f9,_0x407476);_0x2e4cb3=Rt(_0x37a0d7,_0xdd87d8,_0x240405['isFullyInitialized'](),_0x290bcd['filter']['filtersNodes']());}}}return _0x2e4cb3;}function lr(_0x33d8ff,_0xbb5e61){return _0x33d8ff['eventCache']['isCompleteForChild'](_0xbb5e61);}function ku(_0x522c14,_0x1fdf20,_0xa85aba,_0x1689ff,_0x5e0b58,_0x353e7e,_0x10259a){let _0x510504=_0x1fdf20;return _0x1689ff['foreach']((_0x31b900,_0x1d9885)=>{const _0x3dcf0f=k(_0xa85aba,_0x31b900);lr(_0x1fdf20,y(_0x3dcf0f))&&(_0x510504=ki(_0x522c14,_0x510504,_0x3dcf0f,_0x1d9885,_0x5e0b58,_0x353e7e,_0x10259a));}),_0x1689ff['foreach']((_0x383552,_0x1e6942)=>{const _0x42e0a9=k(_0xa85aba,_0x383552);lr(_0x1fdf20,y(_0x42e0a9))||(_0x510504=ki(_0x522c14,_0x510504,_0x42e0a9,_0x1e6942,_0x5e0b58,_0x353e7e,_0x10259a));}),_0x510504;}function hr(_0x32ffb8,_0x12fa72,_0x27bf03){return _0x27bf03['foreach']((_0x5edf18,_0x11ead5)=>{_0x12fa72=_0x12fa72['updateChild'](_0x5edf18,_0x11ead5);}),_0x12fa72;}function Pi(_0x37b86c,_0x369dcf,_0x28ce37,_0x5dfc02,_0x46e50d,_0x227df8,_0x4d11da,_0x5e87bb){if(_0x369dcf['serverCache']['getNode']()['isEmpty']()&&!_0x369dcf['serverCache']['isFullyInitialized']())return _0x369dcf;let _0x5d7d21=_0x369dcf,_0x254918;v(_0x28ce37)?_0x254918=_0x5dfc02:_0x254918=new b(null)['setTree'](_0x28ce37,_0x5dfc02);const _0x35fe1a=_0x369dcf['serverCache']['getNode']();return _0x254918['children']['inorderTraversal']((_0x1b122c,_0x470d75)=>{if(_0x35fe1a['hasChild'](_0x1b122c)){const _0x15d4d3=_0x369dcf['serverCache']['getNode']()['getImmediateChild'](_0x1b122c),_0x26648a=hr(_0x37b86c,_0x15d4d3,_0x470d75);_0x5d7d21=Sn(_0x37b86c,_0x5d7d21,new C(_0x1b122c),_0x26648a,_0x46e50d,_0x227df8,_0x4d11da,_0x5e87bb);}}),_0x254918['children']['inorderTraversal']((_0xf39f16,_0x24855b)=>{const _0x256a85=!_0x369dcf['serverCache']['isCompleteForChild'](_0xf39f16)&&_0x24855b['value']===null;if(!_0x35fe1a['hasChild'](_0xf39f16)&&!_0x256a85){const _0x54a54e=_0x369dcf['serverCache']['getNode']()['getImmediateChild'](_0xf39f16),_0x2b06db=hr(_0x37b86c,_0x54a54e,_0x24855b);_0x5d7d21=Sn(_0x37b86c,_0x5d7d21,new C(_0xf39f16),_0x2b06db,_0x46e50d,_0x227df8,_0x4d11da,_0x5e87bb);}}),_0x5d7d21;}function Pu(_0xe05833,_0x4306f6,_0x25375d,_0x256435,_0x316be3,_0x5358d7,_0x3b8b8e){if(Tn(_0x316be3,_0x25375d)!=null)return _0x4306f6;const _0x21fb19=_0x4306f6['serverCache']['isFiltered'](),_0x291e6c=_0x4306f6['serverCache'];if(_0x256435['value']!=null){if(v(_0x25375d)&&_0x291e6c['isFullyInitialized']()||_0x291e6c['isCompleteForPath'](_0x25375d))return Sn(_0xe05833,_0x4306f6,_0x25375d,_0x291e6c['getNode']()['getChild'](_0x25375d),_0x316be3,_0x5358d7,_0x21fb19,_0x3b8b8e);if(v(_0x25375d)){let _0x59bbf2=new b(null);return _0x291e6c['getNode']()['forEachChild'](ve,(_0x41f136,_0x532326)=>{_0x59bbf2=_0x59bbf2['set'](new C(_0x41f136),_0x532326);}),Pi(_0xe05833,_0x4306f6,_0x25375d,_0x59bbf2,_0x316be3,_0x5358d7,_0x21fb19,_0x3b8b8e);}else return _0x4306f6;}else{let _0x3c4dde=new b(null);return _0x256435['foreach']((_0x31b5b7,_0x1fc859)=>{const _0x290b65=k(_0x25375d,_0x31b5b7);_0x291e6c['isCompleteForPath'](_0x290b65)&&(_0x3c4dde=_0x3c4dde['set'](_0x31b5b7,_0x291e6c['getNode']()['getChild'](_0x290b65)));}),Pi(_0xe05833,_0x4306f6,_0x25375d,_0x3c4dde,_0x316be3,_0x5358d7,_0x21fb19,_0x3b8b8e);}}function Nu(_0x396f60,_0x3c02ba,_0x36bf88,_0x18c5b5,_0x528372){const _0x41cb35=_0x3c02ba['serverCache'],_0x4c458e=Fo(_0x3c02ba,_0x41cb35['getNode'](),_0x41cb35['isFullyInitialized']()||v(_0x36bf88),_0x41cb35['isFiltered']());return Go(_0x396f60,_0x4c458e,_0x36bf88,_0x18c5b5,$o,_0x528372);}function Ou(_0x3f2c47,_0x333984,_0x5d3183,_0x1848a8,_0x27089b,_0x5ae194){let _0x2fad82;if(Tn(_0x1848a8,_0x5d3183)!=null)return _0x333984;{const _0x2e794f=new rs(_0x1848a8,_0x333984,_0x27089b),_0x3fe230=_0x333984['eventCache']['getNode']();let _0x2ce2ef;if(v(_0x5d3183)||y(_0x5d3183)==='.priority'){let _0x20c112;if(_0x333984['serverCache']['isFullyInitialized']())_0x20c112=Cn(_0x1848a8,Ve(_0x333984));else{const _0x337979=_0x333984['serverCache']['getNode']();f(_0x337979 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x20c112=is(_0x1848a8,_0x337979);}_0x20c112=_0x20c112,_0x2ce2ef=_0x3f2c47['filter']['updateFullNode'](_0x3fe230,_0x20c112,_0x5ae194);}else{const _0x2b6cef=y(_0x5d3183);let _0x32ea79=ss(_0x1848a8,_0x2b6cef,_0x333984['serverCache']);_0x32ea79==null&&_0x333984['serverCache']['isCompleteForChild'](_0x2b6cef)&&(_0x32ea79=_0x3fe230['getImmediateChild'](_0x2b6cef)),_0x32ea79!=null?_0x2ce2ef=_0x3f2c47['filter']['updateChild'](_0x3fe230,_0x2b6cef,_0x32ea79,S(_0x5d3183),_0x2e794f,_0x5ae194):_0x333984['eventCache']['getNode']()['hasChild'](_0x2b6cef)?_0x2ce2ef=_0x3f2c47['filter']['updateChild'](_0x3fe230,_0x2b6cef,g['EMPTY_NODE'],S(_0x5d3183),_0x2e794f,_0x5ae194):_0x2ce2ef=_0x3fe230,_0x2ce2ef['isEmpty']()&&_0x333984['serverCache']['isFullyInitialized']()&&(_0x2fad82=Cn(_0x1848a8,Ve(_0x333984)),_0x2fad82['isLeafNode']()&&(_0x2ce2ef=_0x3f2c47['filter']['updateFullNode'](_0x2ce2ef,_0x2fad82,_0x5ae194)));}return _0x2fad82=_0x333984['serverCache']['isFullyInitialized']()||Tn(_0x1848a8,w())!=null,Rt(_0x333984,_0x2ce2ef,_0x2fad82,_0x3f2c47['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x3b1057,_0x215b0e){this['query_']=_0x3b1057,this['eventRegistrations_']=[];const _0x5389d5=this['query_']['_queryParams'],_0x28d430=new Xi(_0x5389d5['getIndex']()),_0x435437=Kh(_0x5389d5);this['processor_']=Su(_0x435437);const _0x567950=_0x215b0e['serverCache'],_0x5d3702=_0x215b0e['eventCache'],_0x4dfd14=_0x28d430['updateFullNode'](g['EMPTY_NODE'],_0x567950['getNode'](),null),_0x234ce4=_0x435437['updateFullNode'](g['EMPTY_NODE'],_0x5d3702['getNode'](),null),_0x938676=new Te(_0x4dfd14,_0x567950['isFullyInitialized'](),_0x28d430['filtersNodes']()),_0x1b5d18=new Te(_0x234ce4,_0x5d3702['isFullyInitialized'](),_0x435437['filtersNodes']());this['viewCache_']=Un(_0x1b5d18,_0x938676),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x2f3fcc){return _0x2f3fcc['viewCache_']['serverCache']['getNode']();}function Lu(_0x3f94e2){return wn(_0x3f94e2['viewCache_']);}function xu(_0x2ee9fe,_0x30d701){const _0x54c979=Ve(_0x2ee9fe['viewCache_']);return _0x54c979&&(_0x2ee9fe['query']['_queryParams']['loadsAllData']()||!v(_0x30d701)&&!_0x54c979['getImmediateChild'](y(_0x30d701))['isEmpty']())?_0x54c979['getChild'](_0x30d701):null;}function ur(_0x15d7be){return _0x15d7be['eventRegistrations_']['length']===0x0;}function Fu(_0x45dc3c,_0x2fffd1){_0x45dc3c['eventRegistrations_']['push'](_0x2fffd1);}function dr(_0x546297,_0x23fead,_0x53fefd){const _0x28e4aa=[];if(_0x53fefd){f(_0x23fead==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x2e7b58=_0x546297['query']['_path'];_0x546297['eventRegistrations_']['forEach'](_0x2efa54=>{const _0x1022b5=_0x2efa54['createCancelEvent'](_0x53fefd,_0x2e7b58);_0x1022b5&&_0x28e4aa['push'](_0x1022b5);});}if(_0x23fead){let _0x1b18a8=[];for(let _0x171520=0x0;_0x171520<_0x546297['eventRegistrations_']['length'];++_0x171520){const _0x3b28c5=_0x546297['eventRegistrations_'][_0x171520];if(!_0x3b28c5['matches'](_0x23fead))_0x1b18a8['push'](_0x3b28c5);else{if(_0x23fead['hasAnyCallback']()){_0x1b18a8=_0x1b18a8['concat'](_0x546297['eventRegistrations_']['slice'](_0x171520+0x1));break;}}}_0x546297['eventRegistrations_']=_0x1b18a8;}else _0x546297['eventRegistrations_']=[];return _0x28e4aa;}function fr(_0x588a7d,_0x37d8a9,_0xebcc91,_0xff8e73){_0x37d8a9['type']===z['MERGE']&&_0x37d8a9['source']['queryId']!==null&&(f(Ve(_0x588a7d['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x588a7d['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x397938=_0x588a7d['viewCache_'],_0x2fba2e=Ru(_0x588a7d['processor_'],_0x397938,_0x37d8a9,_0xebcc91,_0xff8e73);return bu(_0x588a7d['processor_'],_0x2fba2e['viewCache']),f(_0x2fba2e['viewCache']['serverCache']['isFullyInitialized']()||!_0x397938['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x588a7d['viewCache_']=_0x2fba2e['viewCache'],qo(_0x588a7d,_0x2fba2e['changes'],_0x2fba2e['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x2d9983,_0x467a12){const _0x5d4d45=_0x2d9983['viewCache_']['eventCache'],_0x1b0c1e=[];return _0x5d4d45['getNode']()['isLeafNode']()||_0x5d4d45['getNode']()['forEachChild'](R,(_0x26db99,_0x10e6ad)=>{_0x1b0c1e['push'](rt(_0x26db99,_0x10e6ad));}),_0x5d4d45['isFullyInitialized']()&&_0x1b0c1e['push'](Lo(_0x5d4d45['getNode']())),qo(_0x2d9983,_0x1b0c1e,_0x5d4d45['getNode'](),_0x467a12);}function qo(_0x322226,_0x47fa26,_0x14407c,_0x5234b6){const _0x4cda78=_0x5234b6?[_0x5234b6]:_0x322226['eventRegistrations_'];return ru(_0x322226['eventGenerator_'],_0x47fa26,_0x14407c,_0x4cda78);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x1c81da){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x1c81da;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x9d2de4){return _0x9d2de4['views']['size']===0x0;}function os(_0x285692,_0x205e1b,_0x3a6696,_0x1d1bc5){const _0x9cf642=_0x205e1b['source']['queryId'];if(_0x9cf642!==null){const _0x103366=_0x285692['views']['get'](_0x9cf642);return f(_0x103366!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x103366,_0x205e1b,_0x3a6696,_0x1d1bc5);}else{let _0x50e9e1=[];for(const _0xee8f73 of _0x285692['views']['values']())_0x50e9e1=_0x50e9e1['concat'](fr(_0xee8f73,_0x205e1b,_0x3a6696,_0x1d1bc5));return _0x50e9e1;}}function jo(_0x4d86f3,_0x2f08ff,_0x287562,_0x30c88d,_0x4de9ff){const _0x209b28=_0x2f08ff['_queryIdentifier'],_0x573acb=_0x4d86f3['views']['get'](_0x209b28);if(!_0x573acb){let _0x27e51f=Cn(_0x287562,_0x4de9ff?_0x30c88d:null),_0x228124=!0x1;_0x27e51f?_0x228124=!0x0:_0x30c88d instanceof g?(_0x27e51f=is(_0x287562,_0x30c88d),_0x228124=!0x1):(_0x27e51f=g['EMPTY_NODE'],_0x228124=!0x1);const _0x53e045=Un(new Te(_0x27e51f,_0x228124,!0x1),new Te(_0x30c88d,_0x4de9ff,!0x1));return new Du(_0x2f08ff,_0x53e045);}return _0x573acb;}function Hu(_0x5254e8,_0x3e648d,_0x202152,_0x3580cd,_0x219826,_0x1f424a){const _0x4d4dfd=jo(_0x5254e8,_0x3e648d,_0x3580cd,_0x219826,_0x1f424a);return _0x5254e8['views']['has'](_0x3e648d['_queryIdentifier'])||_0x5254e8['views']['set'](_0x3e648d['_queryIdentifier'],_0x4d4dfd),Fu(_0x4d4dfd,_0x202152),Uu(_0x4d4dfd,_0x202152);}function $u(_0x4aa761,_0x5ab9f7,_0x1d92e0,_0x1008af){const _0x16c0ad=_0x5ab9f7['_queryIdentifier'],_0x5861e6=[];let _0x8ca212=[];const _0x54cd55=Se(_0x4aa761);if(_0x16c0ad==='default'){for(const [_0x488a2b,_0x1cacba]of _0x4aa761['views']['entries']())_0x8ca212=_0x8ca212['concat'](dr(_0x1cacba,_0x1d92e0,_0x1008af)),ur(_0x1cacba)&&(_0x4aa761['views']['delete'](_0x488a2b),_0x1cacba['query']['_queryParams']['loadsAllData']()||_0x5861e6['push'](_0x1cacba['query']));}else{const _0xa3e7bc=_0x4aa761['views']['get'](_0x16c0ad);_0xa3e7bc&&(_0x8ca212=_0x8ca212['concat'](dr(_0xa3e7bc,_0x1d92e0,_0x1008af)),ur(_0xa3e7bc)&&(_0x4aa761['views']['delete'](_0x16c0ad),_0xa3e7bc['query']['_queryParams']['loadsAllData']()||_0x5861e6['push'](_0xa3e7bc['query'])));}return _0x54cd55&&!Se(_0x4aa761)&&_0x5861e6['push'](new(Bu())(_0x5ab9f7['_repo'],_0x5ab9f7['_path'])),{'removed':_0x5861e6,'events':_0x8ca212};}function Ko(_0x5215ea){const _0x46e36=[];for(const _0x213944 of _0x5215ea['views']['values']())_0x213944['query']['_queryParams']['loadsAllData']()||_0x46e36['push'](_0x213944);return _0x46e36;}function Ie(_0x2c66a6,_0x3f680e){let _0x12232b=null;for(const _0x369570 of _0x2c66a6['views']['values']())_0x12232b=_0x12232b||xu(_0x369570,_0x3f680e);return _0x12232b;}function Yo(_0x1d1c93,_0x15a0f9){if(_0x15a0f9['_queryParams']['loadsAllData']())return Bn(_0x1d1c93);{const _0x4346a6=_0x15a0f9['_queryIdentifier'];return _0x1d1c93['views']['get'](_0x4346a6);}}function Qo(_0x2a705e,_0x2b83f6){return Yo(_0x2a705e,_0x2b83f6)!=null;}function Se(_0x488ff1){return Bn(_0x488ff1)!=null;}function Bn(_0x15444b){for(const _0x9f1487 of _0x15444b['views']['values']())if(_0x9f1487['query']['_queryParams']['loadsAllData']())return _0x9f1487;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0xc736fa){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0xc736fa;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x2e551f){this['listenProvider_']=_0x2e551f,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x357f9e,_0x56e0fe,_0x9a3917,_0x13cecf,_0x4ef1b3){return lu(_0x357f9e['pendingWriteTree_'],_0x56e0fe,_0x9a3917,_0x13cecf,_0x4ef1b3),_0x4ef1b3?_t(_0x357f9e,new Be(es(),_0x56e0fe,_0x9a3917)):[];}function ju(_0xffc267,_0x25080c,_0x3e2ac2,_0x437883){hu(_0xffc267['pendingWriteTree_'],_0x25080c,_0x3e2ac2,_0x437883);const _0x3c7f63=b['fromObject'](_0x3e2ac2);return _t(_0xffc267,new ot(es(),_0x25080c,_0x3c7f63));}function _e(_0x18579c,_0x4fd03a,_0x8e1975=!0x1){const _0x54b0d8=uu(_0x18579c['pendingWriteTree_'],_0x4fd03a);if(du(_0x18579c['pendingWriteTree_'],_0x4fd03a)){let _0x3489ac=new b(null);return _0x54b0d8['snap']!=null?_0x3489ac=_0x3489ac['set'](w(),!0x0):x(_0x54b0d8['children'],_0x4e0387=>{_0x3489ac=_0x3489ac['set'](new C(_0x4e0387),!0x0);}),_t(_0x18579c,new In(_0x54b0d8['path'],_0x3489ac,_0x8e1975));}else return[];}function Yt(_0x4ee1b8,_0x5904c6,_0x7ebf14){return _t(_0x4ee1b8,new Be(ts(),_0x5904c6,_0x7ebf14));}function Ku(_0x13fd6d,_0x5cd0a3,_0x17c3dc){const _0x58a67f=b['fromObject'](_0x17c3dc);return _t(_0x13fd6d,new ot(ts(),_0x5cd0a3,_0x58a67f));}function Yu(_0x3687f9,_0x13bc2f){return _t(_0x3687f9,new Ut(ts(),_0x13bc2f));}function Qu(_0x3dc3f1,_0x4ffb27,_0x369b68){const _0x1a64f9=cs(_0x3dc3f1,_0x369b68);if(_0x1a64f9){const _0x57064c=ls(_0x1a64f9),_0x324aa8=_0x57064c['path'],_0x2ed581=_0x57064c['queryId'],_0x534dc3=F(_0x324aa8,_0x4ffb27),_0x30a9cd=new Ut(ns(_0x2ed581),_0x534dc3);return hs(_0x3dc3f1,_0x324aa8,_0x30a9cd);}else return[];}function An(_0x30d0b6,_0x4e60d6,_0x4c14cb,_0x249c2b,_0x3f0bff=!0x1){const _0x53419c=_0x4e60d6['_path'],_0x458176=_0x30d0b6['syncPointTree_']['get'](_0x53419c);let _0x4e05e9=[];if(_0x458176&&(_0x4e60d6['_queryIdentifier']==='default'||Qo(_0x458176,_0x4e60d6))){const _0x3f315c=$u(_0x458176,_0x4e60d6,_0x4c14cb,_0x249c2b);Vu(_0x458176)&&(_0x30d0b6['syncPointTree_']=_0x30d0b6['syncPointTree_']['remove'](_0x53419c));const _0x2e2e47=_0x3f315c['removed'];if(_0x4e05e9=_0x3f315c['events'],!_0x3f0bff){const _0xd2669a=_0x2e2e47['findIndex'](_0x3a1284=>_0x3a1284['_queryParams']['loadsAllData']())!==-0x1,_0x1e851a=_0x30d0b6['syncPointTree_']['findOnPath'](_0x53419c,(_0x4180c0,_0x11a0ec)=>Se(_0x11a0ec));if(_0xd2669a&&!_0x1e851a){const _0x57c34c=_0x30d0b6['syncPointTree_']['subtree'](_0x53419c);if(!_0x57c34c['isEmpty']()){const _0x32a85a=Zu(_0x57c34c);for(let _0x4c6387=0x0;_0x4c6387<_0x32a85a['length'];++_0x4c6387){const _0x52075b=_0x32a85a[_0x4c6387],_0x471b84=_0x52075b['query'],_0x41ed42=ea(_0x30d0b6,_0x52075b);_0x30d0b6['listenProvider_']['startListening'](kt(_0x471b84),Wt(_0x30d0b6,_0x471b84),_0x41ed42['hashFn'],_0x41ed42['onComplete']);}}}!_0x1e851a&&_0x2e2e47['length']>0x0&&!_0x249c2b&&(_0xd2669a?_0x30d0b6['listenProvider_']['stopListening'](kt(_0x4e60d6),null):_0x2e2e47['forEach'](_0x2fc4bc=>{const _0x1c8b50=_0x30d0b6['queryToTagMap']['get'](Hn(_0x2fc4bc));_0x30d0b6['listenProvider_']['stopListening'](kt(_0x2fc4bc),_0x1c8b50);}));}ed(_0x30d0b6,_0x2e2e47);}return _0x4e05e9;}function Jo(_0x19b9ae,_0x305c74,_0x571151,_0x4991f0){const _0x5ebff5=cs(_0x19b9ae,_0x4991f0);if(_0x5ebff5!=null){const _0x3f2e46=ls(_0x5ebff5),_0x26581c=_0x3f2e46['path'],_0x1ae83a=_0x3f2e46['queryId'],_0x2956a4=F(_0x26581c,_0x305c74),_0x25cf3c=new Be(ns(_0x1ae83a),_0x2956a4,_0x571151);return hs(_0x19b9ae,_0x26581c,_0x25cf3c);}else return[];}function Ju(_0x7cbe11,_0xf67ff,_0x11ed27,_0x1514e0){const _0x108a1d=cs(_0x7cbe11,_0x1514e0);if(_0x108a1d){const _0xc8021a=ls(_0x108a1d),_0x579c58=_0xc8021a['path'],_0x447f28=_0xc8021a['queryId'],_0x19d1cf=F(_0x579c58,_0xf67ff),_0x1af394=b['fromObject'](_0x11ed27),_0x2a069e=new ot(ns(_0x447f28),_0x19d1cf,_0x1af394);return hs(_0x7cbe11,_0x579c58,_0x2a069e);}else return[];}function Ni(_0x2f80b4,_0x160b79,_0x29f428,_0x32d18a=!0x1){const _0x3bf0f9=_0x160b79['_path'];let _0x5eb28b=null,_0xbf6a62=!0x1;_0x2f80b4['syncPointTree_']['foreachOnPath'](_0x3bf0f9,(_0x26bd66,_0x6a4144)=>{const _0x19bd0f=F(_0x26bd66,_0x3bf0f9);_0x5eb28b=_0x5eb28b||Ie(_0x6a4144,_0x19bd0f),_0xbf6a62=_0xbf6a62||Se(_0x6a4144);});let _0x4db1f1=_0x2f80b4['syncPointTree_']['get'](_0x3bf0f9);_0x4db1f1?(_0xbf6a62=_0xbf6a62||Se(_0x4db1f1),_0x5eb28b=_0x5eb28b||Ie(_0x4db1f1,w())):(_0x4db1f1=new zo(),_0x2f80b4['syncPointTree_']=_0x2f80b4['syncPointTree_']['set'](_0x3bf0f9,_0x4db1f1));let _0x29ac8c;_0x5eb28b!=null?_0x29ac8c=!0x0:(_0x29ac8c=!0x1,_0x5eb28b=g['EMPTY_NODE'],_0x2f80b4['syncPointTree_']['subtree'](_0x3bf0f9)['foreachChild']((_0x222338,_0x4524e9)=>{const _0x500d91=Ie(_0x4524e9,w());_0x500d91&&(_0x5eb28b=_0x5eb28b['updateImmediateChild'](_0x222338,_0x500d91));}));const _0x2bf076=Qo(_0x4db1f1,_0x160b79);if(!_0x2bf076&&!_0x160b79['_queryParams']['loadsAllData']()){const _0x53985a=Hn(_0x160b79);f(!_0x2f80b4['queryToTagMap']['has'](_0x53985a),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x16cf1d=td();_0x2f80b4['queryToTagMap']['set'](_0x53985a,_0x16cf1d),_0x2f80b4['tagToQueryMap']['set'](_0x16cf1d,_0x53985a);}const _0x2de384=Wn(_0x2f80b4['pendingWriteTree_'],_0x3bf0f9);let _0x2105d5=Hu(_0x4db1f1,_0x160b79,_0x29f428,_0x2de384,_0x5eb28b,_0x29ac8c);if(!_0x2bf076&&!_0xbf6a62&&!_0x32d18a){const _0x3583b3=Yo(_0x4db1f1,_0x160b79);_0x2105d5=_0x2105d5['concat'](nd(_0x2f80b4,_0x160b79,_0x3583b3));}return _0x2105d5;}function Vn(_0x44c367,_0x4a9ab5,_0x450e1e){const _0x11b5bf=_0x44c367['pendingWriteTree_'],_0x42a623=_0x44c367['syncPointTree_']['findOnPath'](_0x4a9ab5,(_0x175623,_0x46e013)=>{const _0x358a01=F(_0x175623,_0x4a9ab5),_0x5075e7=Ie(_0x46e013,_0x358a01);if(_0x5075e7)return _0x5075e7;});return Bo(_0x11b5bf,_0x4a9ab5,_0x42a623,_0x450e1e,!0x0);}function Xu(_0x331519,_0x123f4d){const _0x4fbc97=_0x123f4d['_path'];let _0x4cb480=null;_0x331519['syncPointTree_']['foreachOnPath'](_0x4fbc97,(_0x4c3074,_0x28394a)=>{const _0x3edb0f=F(_0x4c3074,_0x4fbc97);_0x4cb480=_0x4cb480||Ie(_0x28394a,_0x3edb0f);});let _0x4d246a=_0x331519['syncPointTree_']['get'](_0x4fbc97);_0x4d246a?_0x4cb480=_0x4cb480||Ie(_0x4d246a,w()):(_0x4d246a=new zo(),_0x331519['syncPointTree_']=_0x331519['syncPointTree_']['set'](_0x4fbc97,_0x4d246a));const _0x54a7ff=_0x4cb480!=null,_0x8fe780=_0x54a7ff?new Te(_0x4cb480,!0x0,!0x1):null,_0x4eee4d=Wn(_0x331519['pendingWriteTree_'],_0x123f4d['_path']),_0x125b2b=jo(_0x4d246a,_0x123f4d,_0x4eee4d,_0x54a7ff?_0x8fe780['getNode']():g['EMPTY_NODE'],_0x54a7ff);return Lu(_0x125b2b);}function _t(_0x126d57,_0x41ff14){return Xo(_0x41ff14,_0x126d57['syncPointTree_'],null,Wn(_0x126d57['pendingWriteTree_'],w()));}function Xo(_0x1bf397,_0x52d4a9,_0x2a4203,_0xb6a69b){if(v(_0x1bf397['path']))return Zo(_0x1bf397,_0x52d4a9,_0x2a4203,_0xb6a69b);{const _0x2e25e5=_0x52d4a9['get'](w());_0x2a4203==null&&_0x2e25e5!=null&&(_0x2a4203=Ie(_0x2e25e5,w()));let _0x45f462=[];const _0x30bb7b=y(_0x1bf397['path']),_0x484cf3=_0x1bf397['operationForChild'](_0x30bb7b),_0x4ffcde=_0x52d4a9['children']['get'](_0x30bb7b);if(_0x4ffcde&&_0x484cf3){const _0x1ba88c=_0x2a4203?_0x2a4203['getImmediateChild'](_0x30bb7b):null,_0x1c8211=Vo(_0xb6a69b,_0x30bb7b);_0x45f462=_0x45f462['concat'](Xo(_0x484cf3,_0x4ffcde,_0x1ba88c,_0x1c8211));}return _0x2e25e5&&(_0x45f462=_0x45f462['concat'](os(_0x2e25e5,_0x1bf397,_0xb6a69b,_0x2a4203))),_0x45f462;}}function Zo(_0x146ecb,_0x452863,_0x43eecd,_0x2b8ea4){const _0x25a2f2=_0x452863['get'](w());_0x43eecd==null&&_0x25a2f2!=null&&(_0x43eecd=Ie(_0x25a2f2,w()));let _0x297d59=[];return _0x452863['children']['inorderTraversal']((_0x49aba8,_0xad86d0)=>{const _0x1635a7=_0x43eecd?_0x43eecd['getImmediateChild'](_0x49aba8):null,_0x420c4a=Vo(_0x2b8ea4,_0x49aba8),_0x47f221=_0x146ecb['operationForChild'](_0x49aba8);_0x47f221&&(_0x297d59=_0x297d59['concat'](Zo(_0x47f221,_0xad86d0,_0x1635a7,_0x420c4a)));}),_0x25a2f2&&(_0x297d59=_0x297d59['concat'](os(_0x25a2f2,_0x146ecb,_0x2b8ea4,_0x43eecd))),_0x297d59;}function ea(_0x4bb2ab,_0x81c89f){const _0x2ee07b=_0x81c89f['query'],_0x8d2a5f=Wt(_0x4bb2ab,_0x2ee07b);return{'hashFn':()=>(Mu(_0x81c89f)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x5200c2=>{if(_0x5200c2==='ok')return _0x8d2a5f?Qu(_0x4bb2ab,_0x2ee07b['_path'],_0x8d2a5f):Yu(_0x4bb2ab,_0x2ee07b['_path']);{const _0x2e8291=Kl(_0x5200c2,_0x2ee07b);return An(_0x4bb2ab,_0x2ee07b,null,_0x2e8291);}}};}function Wt(_0x4f0522,_0x49085e){const _0x277677=Hn(_0x49085e);return _0x4f0522['queryToTagMap']['get'](_0x277677);}function Hn(_0x5526fa){return _0x5526fa['_path']['toString']()+'$'+_0x5526fa['_queryIdentifier'];}function cs(_0x1f9d71,_0x249a10){return _0x1f9d71['tagToQueryMap']['get'](_0x249a10);}function ls(_0x5f1db0){const _0x51648d=_0x5f1db0['indexOf']('$');return f(_0x51648d!==-0x1&&_0x51648d<_0x5f1db0['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x5f1db0['substr'](_0x51648d+0x1),'path':new C(_0x5f1db0['substr'](0x0,_0x51648d))};}function hs(_0x3c5939,_0x47da58,_0x4dcfc9){const _0x2efd23=_0x3c5939['syncPointTree_']['get'](_0x47da58);f(_0x2efd23,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x28bce4=Wn(_0x3c5939['pendingWriteTree_'],_0x47da58);return os(_0x2efd23,_0x4dcfc9,_0x28bce4,null);}function Zu(_0x51f8af){return _0x51f8af['fold']((_0xc5e400,_0x38174d,_0x24e5e9)=>{if(_0x38174d&&Se(_0x38174d))return[Bn(_0x38174d)];{let _0x42a3ed=[];return _0x38174d&&(_0x42a3ed=Ko(_0x38174d)),x(_0x24e5e9,(_0x39fb34,_0x4b4b55)=>{_0x42a3ed=_0x42a3ed['concat'](_0x4b4b55);}),_0x42a3ed;}});}function kt(_0x2a8587){return _0x2a8587['_queryParams']['loadsAllData']()&&!_0x2a8587['_queryParams']['isDefault']()?new(qu())(_0x2a8587['_repo'],_0x2a8587['_path']):_0x2a8587;}function ed(_0xd8ff79,_0x3203c6){for(let _0x4fddc4=0x0;_0x4fddc4<_0x3203c6['length'];++_0x4fddc4){const _0x443a28=_0x3203c6[_0x4fddc4];if(!_0x443a28['_queryParams']['loadsAllData']()){const _0x4a8436=Hn(_0x443a28),_0x48cdbf=_0xd8ff79['queryToTagMap']['get'](_0x4a8436);_0xd8ff79['queryToTagMap']['delete'](_0x4a8436),_0xd8ff79['tagToQueryMap']['delete'](_0x48cdbf);}}}function td(){return zu++;}function nd(_0x4018ae,_0x1a6702,_0x3a7bea){const _0x5875b8=_0x1a6702['_path'],_0x73d4e0=Wt(_0x4018ae,_0x1a6702),_0x4ea72f=ea(_0x4018ae,_0x3a7bea),_0x4dcede=_0x4018ae['listenProvider_']['startListening'](kt(_0x1a6702),_0x73d4e0,_0x4ea72f['hashFn'],_0x4ea72f['onComplete']),_0x580d26=_0x4018ae['syncPointTree_']['subtree'](_0x5875b8);if(_0x73d4e0)f(!Se(_0x580d26['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x2d9950=_0x580d26['fold']((_0x4349b3,_0x4cf4cd,_0x28a304)=>{if(!v(_0x4349b3)&&_0x4cf4cd&&Se(_0x4cf4cd))return[Bn(_0x4cf4cd)['query']];{let _0x508570=[];return _0x4cf4cd&&(_0x508570=_0x508570['concat'](Ko(_0x4cf4cd)['map'](_0x22cfe3=>_0x22cfe3['query']))),x(_0x28a304,(_0x541574,_0x160ca4)=>{_0x508570=_0x508570['concat'](_0x160ca4);}),_0x508570;}});for(let _0x4e330f=0x0;_0x4e330f<_0x2d9950['length'];++_0x4e330f){const _0x1461d9=_0x2d9950[_0x4e330f];_0x4018ae['listenProvider_']['stopListening'](kt(_0x1461d9),Wt(_0x4018ae,_0x1461d9));}}return _0x4dcede;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x227dc1){this['node_']=_0x227dc1;}['getImmediateChild'](_0x1629f7){const _0x4cba83=this['node_']['getImmediateChild'](_0x1629f7);return new us(_0x4cba83);}['node'](){return this['node_'];}}class ds{constructor(_0x26d991,_0x3c30af){this['syncTree_']=_0x26d991,this['path_']=_0x3c30af;}['getImmediateChild'](_0x37a1ee){const _0x4f9963=k(this['path_'],_0x37a1ee);return new ds(this['syncTree_'],_0x4f9963);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x427a10){return _0x427a10=_0x427a10||{},_0x427a10['timestamp']=_0x427a10['timestamp']||new Date()['getTime'](),_0x427a10;},_r=function(_0x38cdde,_0x29ae08,_0x1476f1){if(!_0x38cdde||typeof _0x38cdde!='object')return _0x38cdde;if(f('.sv'in _0x38cdde,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x38cdde['.sv']=='string')return sd(_0x38cdde['.sv'],_0x29ae08,_0x1476f1);if(typeof _0x38cdde['.sv']=='object')return rd(_0x38cdde['.sv'],_0x29ae08);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x38cdde,null,0x2));},sd=function(_0x448693,_0x3a6715,_0x5809a){switch(_0x448693){case'timestamp':return _0x5809a['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x448693);}},rd=function(_0x2b81d3,_0x34bd02,_0x4ff3a1){_0x2b81d3['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x2b81d3,null,0x2));const _0x36780b=_0x2b81d3['increment'];typeof _0x36780b!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x36780b);const _0x308fd9=_0x34bd02['node']();if(f(_0x308fd9!==null&&typeof _0x308fd9<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x308fd9['isLeafNode']())return _0x36780b;const _0x287f0b=_0x308fd9['getValue']();return typeof _0x287f0b!='number'?_0x36780b:_0x287f0b+_0x36780b;},ta=function(_0x480cc5,_0x880c13,_0x286e6c,_0x2b839e){return ps(_0x880c13,new ds(_0x286e6c,_0x480cc5),_0x2b839e);},fs=function(_0x456f17,_0x569489,_0x28322d){return ps(_0x456f17,new us(_0x569489),_0x28322d);};function ps(_0x3995a5,_0x3c68ba,_0x27987e){const _0x2511db=_0x3995a5['getPriority']()['val'](),_0x1228ea=_r(_0x2511db,_0x3c68ba['getImmediateChild']('.priority'),_0x27987e);let _0x5221c7;if(_0x3995a5['isLeafNode']()){const _0x579ffa=_0x3995a5,_0x4612b3=_r(_0x579ffa['getValue'](),_0x3c68ba,_0x27987e);return _0x4612b3!==_0x579ffa['getValue']()||_0x1228ea!==_0x579ffa['getPriority']()['val']()?new D(_0x4612b3,A(_0x1228ea)):_0x3995a5;}else{const _0x178aea=_0x3995a5;return _0x5221c7=_0x178aea,_0x1228ea!==_0x178aea['getPriority']()['val']()&&(_0x5221c7=_0x5221c7['updatePriority'](new D(_0x1228ea))),_0x178aea['forEachChild'](R,(_0x278189,_0x10c515)=>{const _0xcd48b6=ps(_0x10c515,_0x3c68ba['getImmediateChild'](_0x278189),_0x27987e);_0xcd48b6!==_0x10c515&&(_0x5221c7=_0x5221c7['updateImmediateChild'](_0x278189,_0xcd48b6));}),_0x5221c7;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x2d83b3='',_0x31034a=null,_0x41ef01={'children':{},'childCount':0x0}){this['name']=_0x2d83b3,this['parent']=_0x31034a,this['node']=_0x41ef01;}}function $n(_0x14e575,_0x475580){let _0x5497ab=_0x475580 instanceof C?_0x475580:new C(_0x475580),_0x50edf1=_0x14e575,_0x2c8a83=y(_0x5497ab);for(;_0x2c8a83!==null;){const _0x48746d=Le(_0x50edf1['node']['children'],_0x2c8a83)||{'children':{},'childCount':0x0};_0x50edf1=new _s(_0x2c8a83,_0x50edf1,_0x48746d),_0x5497ab=S(_0x5497ab),_0x2c8a83=y(_0x5497ab);}return _0x50edf1;}function je(_0x58a895){return _0x58a895['node']['value'];}function gs(_0x415c94,_0x1793f2){_0x415c94['node']['value']=_0x1793f2,Oi(_0x415c94);}function na(_0x105ed4){return _0x105ed4['node']['childCount']>0x0;}function od(_0x31d68d){return je(_0x31d68d)===void 0x0&&!na(_0x31d68d);}function Gn(_0x5650e2,_0x358228){x(_0x5650e2['node']['children'],(_0x3056b9,_0x414271)=>{_0x358228(new _s(_0x3056b9,_0x5650e2,_0x414271));});}function ia(_0x2955b5,_0x36ba28,_0x193889,_0x354b94){_0x193889&&_0x36ba28(_0x2955b5),Gn(_0x2955b5,_0x8f0ff4=>{ia(_0x8f0ff4,_0x36ba28,!0x0);});}function ad(_0x481832,_0x2010a4,_0x94acb4){let _0x4de99b=_0x481832['parent'];for(;_0x4de99b!==null;){if(_0x2010a4(_0x4de99b))return!0x0;_0x4de99b=_0x4de99b['parent'];}return!0x1;}function Qt(_0x494cab){return new C(_0x494cab['parent']===null?_0x494cab['name']:Qt(_0x494cab['parent'])+'/'+_0x494cab['name']);}function Oi(_0x119260){_0x119260['parent']!==null&&cd(_0x119260['parent'],_0x119260['name'],_0x119260);}function cd(_0xbbbad1,_0x1244fa,_0x1fc7ad){const _0xc30a63=od(_0x1fc7ad),_0x58e7c4=Q(_0xbbbad1['node']['children'],_0x1244fa);_0xc30a63&&_0x58e7c4?(delete _0xbbbad1['node']['children'][_0x1244fa],_0xbbbad1['node']['childCount']--,Oi(_0xbbbad1)):!_0xc30a63&&!_0x58e7c4&&(_0xbbbad1['node']['children'][_0x1244fa]=_0x1fc7ad['node'],_0xbbbad1['node']['childCount']++,Oi(_0xbbbad1));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x10e16a){return typeof _0x10e16a=='string'&&_0x10e16a['length']!==0x0&&!ld['test'](_0x10e16a);},sa=function(_0x5915de){return typeof _0x5915de=='string'&&_0x5915de['length']!==0x0&&!hd['test'](_0x5915de);},ud=function(_0x526787){return _0x526787&&(_0x526787=_0x526787['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x526787);},Bt=function(_0x25a4ab){return _0x25a4ab===null||typeof _0x25a4ab=='string'||typeof _0x25a4ab=='number'&&!xn(_0x25a4ab)||_0x25a4ab&&typeof _0x25a4ab=='object'&&Q(_0x25a4ab,'.sv');},He=function(_0x538244,_0x526bd6,_0x339b2e,_0xaf39a0){_0xaf39a0&&_0x526bd6===void 0x0||Jt(it(_0x538244,'value'),_0x526bd6,_0x339b2e);},Jt=function(_0x39dec3,_0x2147a1,_0x3fd331){const _0x2b4d81=_0x3fd331 instanceof C?new Ah(_0x3fd331,_0x39dec3):_0x3fd331;if(_0x2147a1===void 0x0)throw new Error(_0x39dec3+'contains\x20undefined\x20'+Oe(_0x2b4d81));if(typeof _0x2147a1=='function')throw new Error(_0x39dec3+'contains\x20a\x20function\x20'+Oe(_0x2b4d81)+'\x20with\x20contents\x20=\x20'+_0x2147a1['toString']());if(xn(_0x2147a1))throw new Error(_0x39dec3+'contains\x20'+_0x2147a1['toString']()+'\x20'+Oe(_0x2b4d81));if(typeof _0x2147a1=='string'&&_0x2147a1['length']>ui/0x3&&Ln(_0x2147a1)>ui)throw new Error(_0x39dec3+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x2b4d81)+'\x20(\x27'+_0x2147a1['substring'](0x0,0x32)+'...\x27)');if(_0x2147a1&&typeof _0x2147a1=='object'){let _0x1136f1=!0x1,_0x2928da=!0x1;if(x(_0x2147a1,(_0x5b4543,_0x5acff6)=>{if(_0x5b4543==='.value')_0x1136f1=!0x0;else{if(_0x5b4543!=='.priority'&&_0x5b4543!=='.sv'&&(_0x2928da=!0x0,!ms(_0x5b4543)))throw new Error(_0x39dec3+'\x20contains\x20an\x20invalid\x20key\x20('+_0x5b4543+')\x20'+Oe(_0x2b4d81)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x2b4d81,_0x5b4543),Jt(_0x39dec3,_0x5acff6,_0x2b4d81),Ph(_0x2b4d81);}),_0x1136f1&&_0x2928da)throw new Error(_0x39dec3+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x2b4d81)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x49b767,_0x4993f0){let _0x43dae5,_0x344744;for(_0x43dae5=0x0;_0x43dae5<_0x4993f0['length'];_0x43dae5++){_0x344744=_0x4993f0[_0x43dae5];const _0x1f8d95=Mt(_0x344744);for(let _0x56084e=0x0;_0x56084e<_0x1f8d95['length'];_0x56084e++)if(!(_0x1f8d95[_0x56084e]==='.priority'&&_0x56084e===_0x1f8d95['length']-0x1)){if(!ms(_0x1f8d95[_0x56084e]))throw new Error(_0x49b767+'contains\x20an\x20invalid\x20key\x20('+_0x1f8d95[_0x56084e]+')\x20in\x20path\x20'+_0x344744['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x4993f0['sort'](Rh);let _0x433f81=null;for(_0x43dae5=0x0;_0x43dae5<_0x4993f0['length'];_0x43dae5++){if(_0x344744=_0x4993f0[_0x43dae5],_0x433f81!==null&&G(_0x433f81,_0x344744))throw new Error(_0x49b767+'contains\x20a\x20path\x20'+_0x433f81['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x344744['toString']());_0x433f81=_0x344744;}},ra=function(_0x599466,_0x47e888,_0xa69603,_0x142822){const _0x194194=it(_0x599466,'values');if(!(_0x47e888&&typeof _0x47e888=='object')||Array['isArray'](_0x47e888))throw new Error(_0x194194+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0xde206=[];x(_0x47e888,(_0x43aa61,_0x2886d0)=>{const _0x15ab92=new C(_0x43aa61);if(Jt(_0x194194,_0x2886d0,k(_0xa69603,_0x15ab92)),ji(_0x15ab92)==='.priority'&&!Bt(_0x2886d0))throw new Error(_0x194194+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x15ab92['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0xde206['push'](_0x15ab92);}),dd(_0x194194,_0xde206);},fd=function(_0x38fdae,_0x3df978,_0x2942be){if(xn(_0x3df978))throw new Error(it(_0x38fdae,'priority')+'is\x20'+_0x3df978['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x3df978))throw new Error(it(_0x38fdae,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x1f7d6c,_0x362da1,_0x5ebe26,_0x4a1b9b){if(!sa(_0x5ebe26))throw new Error(it(_0x1f7d6c,_0x362da1)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x5ebe26+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x198e0f,_0x2a76a9,_0x259c65,_0x21e508){_0x259c65&&(_0x259c65=_0x259c65['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x198e0f,_0x2a76a9,_0x259c65);},Me=function(_0x2d094e,_0xa2ee67){if(y(_0xa2ee67)==='.info')throw new Error(_0x2d094e+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x29a334,_0x5a5fe6){const _0x507f46=_0x5a5fe6['path']['toString']();if(typeof _0x5a5fe6['repoInfo']['host']!='string'||_0x5a5fe6['repoInfo']['host']['length']===0x0||!ms(_0x5a5fe6['repoInfo']['namespace'])&&_0x5a5fe6['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x507f46['length']!==0x0&&!ud(_0x507f46))throw new Error(it(_0x29a334,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x43d95a,_0x3e4c6c){let _0x560a3c=null;for(let _0x5eaecb=0x0;_0x5eaecb<_0x3e4c6c['length'];_0x5eaecb++){const _0x356601=_0x3e4c6c[_0x5eaecb],_0x3f828a=_0x356601['getPath']();_0x560a3c!==null&&!Ki(_0x3f828a,_0x560a3c['path'])&&(_0x43d95a['eventLists_']['push'](_0x560a3c),_0x560a3c=null),_0x560a3c===null&&(_0x560a3c={'events':[],'path':_0x3f828a}),_0x560a3c['events']['push'](_0x356601);}_0x560a3c&&_0x43d95a['eventLists_']['push'](_0x560a3c);}function oa(_0x34e15a,_0x1261ee,_0x369546){qn(_0x34e15a,_0x369546),aa(_0x34e15a,_0x2d282e=>Ki(_0x2d282e,_0x1261ee));}function V(_0x140fd6,_0x128c4e,_0xbb41b9){qn(_0x140fd6,_0xbb41b9),aa(_0x140fd6,_0x2beb2c=>G(_0x2beb2c,_0x128c4e)||G(_0x128c4e,_0x2beb2c));}function aa(_0xa4d20,_0x4e34fa){_0xa4d20['recursionDepth_']++;let _0x5284ea=!0x0;for(let _0x2c2838=0x0;_0x2c2838<_0xa4d20['eventLists_']['length'];_0x2c2838++){const _0x2fec80=_0xa4d20['eventLists_'][_0x2c2838];if(_0x2fec80){const _0x21aff1=_0x2fec80['path'];_0x4e34fa(_0x21aff1)?(md(_0xa4d20['eventLists_'][_0x2c2838]),_0xa4d20['eventLists_'][_0x2c2838]=null):_0x5284ea=!0x1;}}_0x5284ea&&(_0xa4d20['eventLists_']=[]),_0xa4d20['recursionDepth_']--;}function md(_0x2c8a8a){for(let _0x14edb4=0x0;_0x14edb4<_0x2c8a8a['events']['length'];_0x14edb4++){const _0x18685c=_0x2c8a8a['events'][_0x14edb4];if(_0x18685c!==null){_0x2c8a8a['events'][_0x14edb4]=null;const _0x4dc6be=_0x18685c['getEventRunner']();St&&L('event:\x20'+_0x18685c['toString']()),ft(_0x4dc6be);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x2512b9,_0x544034,_0x316e6e,_0x4fa10c){this['repoInfo_']=_0x2512b9,this['forceRestClient_']=_0x544034,this['authTokenProvider_']=_0x316e6e,this['appCheckProvider_']=_0x4fa10c,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x2a57ce,_0x34e795,_0x505033){if(_0x2a57ce['stats_']=qi(_0x2a57ce['repoInfo_']),_0x2a57ce['forceRestClient_']||Xl())_0x2a57ce['server_']=new vn(_0x2a57ce['repoInfo_'],(_0x130d88,_0x58c71a,_0x7841d7,_0x703f87)=>{gr(_0x2a57ce,_0x130d88,_0x58c71a,_0x7841d7,_0x703f87);},_0x2a57ce['authTokenProvider_'],_0x2a57ce['appCheckProvider_']),setTimeout(()=>mr(_0x2a57ce,!0x0),0x0);else{if(typeof _0x505033<'u'&&_0x505033!==null){if(typeof _0x505033!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x505033);}catch(_0x20a554){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x20a554);}}_0x2a57ce['persistentConnection_']=new se(_0x2a57ce['repoInfo_'],_0x34e795,(_0x17d4b0,_0x14bb1a,_0x5d2dff,_0x28863e)=>{gr(_0x2a57ce,_0x17d4b0,_0x14bb1a,_0x5d2dff,_0x28863e);},_0x23df91=>{mr(_0x2a57ce,_0x23df91);},_0x2380b3=>{Id(_0x2a57ce,_0x2380b3);},_0x2a57ce['authTokenProvider_'],_0x2a57ce['appCheckProvider_'],_0x505033),_0x2a57ce['server_']=_0x2a57ce['persistentConnection_'];}_0x2a57ce['authTokenProvider_']['addTokenChangeListener'](_0x5b8908=>{_0x2a57ce['server_']['refreshAuthToken'](_0x5b8908);}),_0x2a57ce['appCheckProvider_']['addTokenChangeListener'](_0x237c69=>{_0x2a57ce['server_']['refreshAppCheckToken'](_0x237c69['token']);}),_0x2a57ce['statsReporter_']=ih(_0x2a57ce['repoInfo_'],()=>new iu(_0x2a57ce['stats_'],_0x2a57ce['server_'])),_0x2a57ce['infoData_']=new Xh(),_0x2a57ce['infoSyncTree_']=new pr({'startListening':(_0x5a14f0,_0x41f88a,_0x41ec8e,_0x19668f)=>{let _0x4a0af6=[];const _0x219652=_0x2a57ce['infoData_']['getNode'](_0x5a14f0['_path']);return _0x219652['isEmpty']()||(_0x4a0af6=Yt(_0x2a57ce['infoSyncTree_'],_0x5a14f0['_path'],_0x219652),setTimeout(()=>{_0x19668f('ok');},0x0)),_0x4a0af6;},'stopListening':()=>{}}),vs(_0x2a57ce,'connected',!0x1),_0x2a57ce['serverSyncTree_']=new pr({'startListening':(_0x5c27b9,_0x7f9d1e,_0x54a723,_0x88a8c2)=>(_0x2a57ce['server_']['listen'](_0x5c27b9,_0x54a723,_0x7f9d1e,(_0x10beaf,_0xfd3524)=>{const _0x5b1f80=_0x88a8c2(_0x10beaf,_0xfd3524);V(_0x2a57ce['eventQueue_'],_0x5c27b9['_path'],_0x5b1f80);}),[]),'stopListening':(_0x2a140d,_0x37921c)=>{_0x2a57ce['server_']['unlisten'](_0x2a140d,_0x37921c);}});}function la(_0x4ff577){const _0x5859c6=_0x4ff577['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x5859c6;}function Xt(_0x2715d7){return id({'timestamp':la(_0x2715d7)});}function gr(_0x2f9554,_0x23aa03,_0x3fec1f,_0x2d59b6,_0xf78e8e){_0x2f9554['dataUpdateCount']++;const _0xd8a7bc=new C(_0x23aa03);_0x3fec1f=_0x2f9554['interceptServerDataCallback_']?_0x2f9554['interceptServerDataCallback_'](_0x23aa03,_0x3fec1f):_0x3fec1f;let _0x57bdef=[];if(_0xf78e8e){if(_0x2d59b6){const _0x2a10ba=_n(_0x3fec1f,_0x395215=>A(_0x395215));_0x57bdef=Ju(_0x2f9554['serverSyncTree_'],_0xd8a7bc,_0x2a10ba,_0xf78e8e);}else{const _0x57fc55=A(_0x3fec1f);_0x57bdef=Jo(_0x2f9554['serverSyncTree_'],_0xd8a7bc,_0x57fc55,_0xf78e8e);}}else{if(_0x2d59b6){const _0x70cc5d=_n(_0x3fec1f,_0x5aedca=>A(_0x5aedca));_0x57bdef=Ku(_0x2f9554['serverSyncTree_'],_0xd8a7bc,_0x70cc5d);}else{const _0x391de8=A(_0x3fec1f);_0x57bdef=Yt(_0x2f9554['serverSyncTree_'],_0xd8a7bc,_0x391de8);}}let _0x5a333f=_0xd8a7bc;_0x57bdef['length']>0x0&&(_0x5a333f=ct(_0x2f9554,_0xd8a7bc)),V(_0x2f9554['eventQueue_'],_0x5a333f,_0x57bdef);}function mr(_0x206114,_0x480dfd){vs(_0x206114,'connected',_0x480dfd),_0x480dfd===!0x1&&Sd(_0x206114);}function Id(_0x778c53,_0x41d350){x(_0x41d350,(_0x4aaeed,_0x1a5d12)=>{vs(_0x778c53,_0x4aaeed,_0x1a5d12);});}function vs(_0xfddfb7,_0x540900,_0x2c769c){const _0x47c94d=new C('/.info/'+_0x540900),_0x587ed6=A(_0x2c769c);_0xfddfb7['infoData_']['updateSnapshot'](_0x47c94d,_0x587ed6);const _0x311666=Yt(_0xfddfb7['infoSyncTree_'],_0x47c94d,_0x587ed6);V(_0xfddfb7['eventQueue_'],_0x47c94d,_0x311666);}function zn(_0x4818b0){return _0x4818b0['nextWriteId_']++;}function wd(_0x52cd3a,_0x1ba220,_0x5efb12){const _0x13f8ba=Xu(_0x52cd3a['serverSyncTree_'],_0x1ba220);return _0x13f8ba!=null?Promise['resolve'](_0x13f8ba):_0x52cd3a['server_']['get'](_0x1ba220)['then'](_0x3269d5=>{const _0x4265ba=A(_0x3269d5)['withIndex'](_0x1ba220['_queryParams']['getIndex']());Ni(_0x52cd3a['serverSyncTree_'],_0x1ba220,_0x5efb12,!0x0);let _0x3ad926;if(_0x1ba220['_queryParams']['loadsAllData']())_0x3ad926=Yt(_0x52cd3a['serverSyncTree_'],_0x1ba220['_path'],_0x4265ba);else{const _0x5550a3=Wt(_0x52cd3a['serverSyncTree_'],_0x1ba220);_0x3ad926=Jo(_0x52cd3a['serverSyncTree_'],_0x1ba220['_path'],_0x4265ba,_0x5550a3);}return V(_0x52cd3a['eventQueue_'],_0x1ba220['_path'],_0x3ad926),An(_0x52cd3a['serverSyncTree_'],_0x1ba220,_0x5efb12,null,!0x0),_0x4265ba;},_0x3d3e94=>(gt(_0x52cd3a,'get\x20for\x20query\x20'+O(_0x1ba220)+'\x20failed:\x20'+_0x3d3e94),Promise['reject'](new Error(_0x3d3e94))));}function Cd(_0x40c550,_0x353222,_0x2619bb,_0x5baaac,_0x5d07f4){gt(_0x40c550,'set',{'path':_0x353222['toString'](),'value':_0x2619bb,'priority':_0x5baaac});const _0x31c33c=Xt(_0x40c550),_0xa9e17e=A(_0x2619bb,_0x5baaac),_0x549553=Vn(_0x40c550['serverSyncTree_'],_0x353222),_0x444736=fs(_0xa9e17e,_0x549553,_0x31c33c),_0x21ed24=zn(_0x40c550),_0xb9cd9a=as(_0x40c550['serverSyncTree_'],_0x353222,_0x444736,_0x21ed24,!0x0);qn(_0x40c550['eventQueue_'],_0xb9cd9a),_0x40c550['server_']['put'](_0x353222['toString'](),_0xa9e17e['val'](!0x0),(_0x3ce6ff,_0x4bf5c5)=>{const _0x3c8309=_0x3ce6ff==='ok';_0x3c8309||U('set\x20at\x20'+_0x353222+'\x20failed:\x20'+_0x3ce6ff);const _0x30ee47=_e(_0x40c550['serverSyncTree_'],_0x21ed24,!_0x3c8309);V(_0x40c550['eventQueue_'],_0x353222,_0x30ee47),be(_0x40c550,_0x5d07f4,_0x3ce6ff,_0x4bf5c5);});const _0x1c1295=Is(_0x40c550,_0x353222);ct(_0x40c550,_0x1c1295),V(_0x40c550['eventQueue_'],_0x1c1295,[]);}function Td(_0x595cbb,_0x499a9d,_0x4cdc9e,_0x3691c4){gt(_0x595cbb,'update',{'path':_0x499a9d['toString'](),'value':_0x4cdc9e});let _0x3f231e=!0x0;const _0xa81183=Xt(_0x595cbb),_0x57be44={};if(x(_0x4cdc9e,(_0x3b87df,_0x2de331)=>{_0x3f231e=!0x1,_0x57be44[_0x3b87df]=ta(k(_0x499a9d,_0x3b87df),A(_0x2de331),_0x595cbb['serverSyncTree_'],_0xa81183);}),_0x3f231e)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x595cbb,_0x3691c4,'ok',void 0x0);else{const _0x2d8d59=zn(_0x595cbb),_0x9310e7=ju(_0x595cbb['serverSyncTree_'],_0x499a9d,_0x57be44,_0x2d8d59);qn(_0x595cbb['eventQueue_'],_0x9310e7),_0x595cbb['server_']['merge'](_0x499a9d['toString'](),_0x4cdc9e,(_0x9fcc99,_0x593462)=>{const _0x3f8c90=_0x9fcc99==='ok';_0x3f8c90||U('update\x20at\x20'+_0x499a9d+'\x20failed:\x20'+_0x9fcc99);const _0x486326=_e(_0x595cbb['serverSyncTree_'],_0x2d8d59,!_0x3f8c90),_0x37c251=_0x486326['length']>0x0?ct(_0x595cbb,_0x499a9d):_0x499a9d;V(_0x595cbb['eventQueue_'],_0x37c251,_0x486326),be(_0x595cbb,_0x3691c4,_0x9fcc99,_0x593462);}),x(_0x4cdc9e,_0x4e2a25=>{const _0x612841=Is(_0x595cbb,k(_0x499a9d,_0x4e2a25));ct(_0x595cbb,_0x612841);}),V(_0x595cbb['eventQueue_'],_0x499a9d,[]);}}function Sd(_0x4f6fbe){gt(_0x4f6fbe,'onDisconnectEvents');const _0x3f050b=Xt(_0x4f6fbe),_0x1d08a0=En();Si(_0x4f6fbe['onDisconnect_'],w(),(_0x430343,_0x3089d1)=>{const _0x1ee0b7=ta(_0x430343,_0x3089d1,_0x4f6fbe['serverSyncTree_'],_0x3f050b);pt(_0x1d08a0,_0x430343,_0x1ee0b7);});let _0x59214e=[];Si(_0x1d08a0,w(),(_0x50cd73,_0x446869)=>{_0x59214e=_0x59214e['concat'](Yt(_0x4f6fbe['serverSyncTree_'],_0x50cd73,_0x446869));const _0x4058e0=Is(_0x4f6fbe,_0x50cd73);ct(_0x4f6fbe,_0x4058e0);}),_0x4f6fbe['onDisconnect_']=En(),V(_0x4f6fbe['eventQueue_'],w(),_0x59214e);}function bd(_0x22402a,_0xc3aadf,_0x53ee47){_0x22402a['server_']['onDisconnectCancel'](_0xc3aadf['toString'](),(_0x2c9f71,_0x3cdf34)=>{_0x2c9f71==='ok'&&Ti(_0x22402a['onDisconnect_'],_0xc3aadf),be(_0x22402a,_0x53ee47,_0x2c9f71,_0x3cdf34);});}function yr(_0x472e12,_0x2e06e4,_0x58cfb1,_0x1d3955){const _0x218f03=A(_0x58cfb1);_0x472e12['server_']['onDisconnectPut'](_0x2e06e4['toString'](),_0x218f03['val'](!0x0),(_0x297573,_0x46d9e2)=>{_0x297573==='ok'&&pt(_0x472e12['onDisconnect_'],_0x2e06e4,_0x218f03),be(_0x472e12,_0x1d3955,_0x297573,_0x46d9e2);});}function Rd(_0x22f9bf,_0x289475,_0x3a6b03,_0x33b4dd,_0x556ed7){const _0x5b4c0e=A(_0x3a6b03,_0x33b4dd);_0x22f9bf['server_']['onDisconnectPut'](_0x289475['toString'](),_0x5b4c0e['val'](!0x0),(_0x65b7cf,_0x3d8333)=>{_0x65b7cf==='ok'&&pt(_0x22f9bf['onDisconnect_'],_0x289475,_0x5b4c0e),be(_0x22f9bf,_0x556ed7,_0x65b7cf,_0x3d8333);});}function Ad(_0x1845bf,_0x163324,_0x2c81b8,_0x19c297){if(pn(_0x2c81b8)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x1845bf,_0x19c297,'ok',void 0x0);return;}_0x1845bf['server_']['onDisconnectMerge'](_0x163324['toString'](),_0x2c81b8,(_0x21ebca,_0x3d6b75)=>{_0x21ebca==='ok'&&x(_0x2c81b8,(_0x1eb24b,_0x75ccee)=>{const _0xc48a05=A(_0x75ccee);pt(_0x1845bf['onDisconnect_'],k(_0x163324,_0x1eb24b),_0xc48a05);}),be(_0x1845bf,_0x19c297,_0x21ebca,_0x3d6b75);});}function kd(_0x37407b,_0x658d39,_0x3a1a3b){let _0x82f95;y(_0x658d39['_path'])==='.info'?_0x82f95=Ni(_0x37407b['infoSyncTree_'],_0x658d39,_0x3a1a3b):_0x82f95=Ni(_0x37407b['serverSyncTree_'],_0x658d39,_0x3a1a3b),oa(_0x37407b['eventQueue_'],_0x658d39['_path'],_0x82f95);}function Pd(_0x47fa9e,_0x518346,_0x5690c2){let _0x9c0751;y(_0x518346['_path'])==='.info'?_0x9c0751=An(_0x47fa9e['infoSyncTree_'],_0x518346,_0x5690c2):_0x9c0751=An(_0x47fa9e['serverSyncTree_'],_0x518346,_0x5690c2),oa(_0x47fa9e['eventQueue_'],_0x518346['_path'],_0x9c0751);}function ha(_0x332b1d){_0x332b1d['persistentConnection_']&&_0x332b1d['persistentConnection_']['interrupt'](ca);}function Nd(_0x29b3e1){_0x29b3e1['persistentConnection_']&&_0x29b3e1['persistentConnection_']['resume'](ca);}function gt(_0x25a7be,..._0x4ce55d){let _0x493b6d='';_0x25a7be['persistentConnection_']&&(_0x493b6d=_0x25a7be['persistentConnection_']['id']+':'),L(_0x493b6d,..._0x4ce55d);}function be(_0x3c7524,_0x43affd,_0x513518,_0x2e268c){_0x43affd&&ft(()=>{if(_0x513518==='ok')_0x43affd(null);else{const _0x55d4a0=(_0x513518||'error')['toUpperCase']();let _0xd8a5cf=_0x55d4a0;_0x2e268c&&(_0xd8a5cf+=':\x20'+_0x2e268c);const _0xd97abe=new Error(_0xd8a5cf);_0xd97abe['code']=_0x55d4a0,_0x43affd(_0xd97abe);}});}function Od(_0x72d50d,_0x24a9c5,_0x457fd7,_0x549158,_0x46f1b3,_0x394294){gt(_0x72d50d,'transaction\x20on\x20'+_0x24a9c5);const _0x543ff9={'path':_0x24a9c5,'update':_0x457fd7,'onComplete':_0x549158,'status':null,'order':so(),'applyLocally':_0x394294,'retryCount':0x0,'unwatcher':_0x46f1b3,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x286655=Es(_0x72d50d,_0x24a9c5,void 0x0);_0x543ff9['currentInputSnapshot']=_0x286655;const _0x9adbd3=_0x543ff9['update'](_0x286655['val']());if(_0x9adbd3===void 0x0)_0x543ff9['unwatcher'](),_0x543ff9['currentOutputSnapshotRaw']=null,_0x543ff9['currentOutputSnapshotResolved']=null,_0x543ff9['onComplete']&&_0x543ff9['onComplete'](null,!0x1,_0x543ff9['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x9adbd3,_0x543ff9['path']),_0x543ff9['status']=0x0;const _0x4d7f85=$n(_0x72d50d['transactionQueueTree_'],_0x24a9c5),_0x4e8c10=je(_0x4d7f85)||[];_0x4e8c10['push'](_0x543ff9),gs(_0x4d7f85,_0x4e8c10);let _0x26f789;typeof _0x9adbd3=='object'&&_0x9adbd3!==null&&Q(_0x9adbd3,'.priority')?(_0x26f789=Le(_0x9adbd3,'.priority'),f(Bt(_0x26f789),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x26f789=(Vn(_0x72d50d['serverSyncTree_'],_0x24a9c5)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x3fb0a6=Xt(_0x72d50d),_0x5945fc=A(_0x9adbd3,_0x26f789),_0x4a80f7=fs(_0x5945fc,_0x286655,_0x3fb0a6);_0x543ff9['currentOutputSnapshotRaw']=_0x5945fc,_0x543ff9['currentOutputSnapshotResolved']=_0x4a80f7,_0x543ff9['currentWriteId']=zn(_0x72d50d);const _0x23f4ab=as(_0x72d50d['serverSyncTree_'],_0x24a9c5,_0x4a80f7,_0x543ff9['currentWriteId'],_0x543ff9['applyLocally']);V(_0x72d50d['eventQueue_'],_0x24a9c5,_0x23f4ab),jn(_0x72d50d,_0x72d50d['transactionQueueTree_']);}}function Es(_0x112705,_0x29f377,_0x15d74a){return Vn(_0x112705['serverSyncTree_'],_0x29f377,_0x15d74a)||g['EMPTY_NODE'];}function jn(_0x412d77,_0x46e332=_0x412d77['transactionQueueTree_']){if(_0x46e332||Kn(_0x412d77,_0x46e332),je(_0x46e332)){const _0x16cf07=da(_0x412d77,_0x46e332);f(_0x16cf07['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x16cf07['every'](_0x2c1960=>_0x2c1960['status']===0x0)&&Dd(_0x412d77,Qt(_0x46e332),_0x16cf07);}else na(_0x46e332)&&Gn(_0x46e332,_0x217ed0=>{jn(_0x412d77,_0x217ed0);});}function Dd(_0x1773d1,_0x4f4807,_0x23b403){const _0x35b6c7=_0x23b403['map'](_0x533c60=>_0x533c60['currentWriteId']),_0x170cb9=Es(_0x1773d1,_0x4f4807,_0x35b6c7);let _0x3ff01f=_0x170cb9;const _0x30a56b=_0x170cb9['hash']();for(let _0x2d28f9=0x0;_0x2d28f9<_0x23b403['length'];_0x2d28f9++){const _0x52453f=_0x23b403[_0x2d28f9];f(_0x52453f['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x52453f['status']=0x1,_0x52453f['retryCount']++;const _0x1c3e42=F(_0x4f4807,_0x52453f['path']);_0x3ff01f=_0x3ff01f['updateChild'](_0x1c3e42,_0x52453f['currentOutputSnapshotRaw']);}const _0xc45606=_0x3ff01f['val'](!0x0),_0x499371=_0x4f4807;_0x1773d1['server_']['put'](_0x499371['toString'](),_0xc45606,_0x5bc826=>{gt(_0x1773d1,'transaction\x20put\x20response',{'path':_0x499371['toString'](),'status':_0x5bc826});let _0x1664b9=[];if(_0x5bc826==='ok'){const _0x1e49b2=[];for(let _0x58571c=0x0;_0x58571c<_0x23b403['length'];_0x58571c++)_0x23b403[_0x58571c]['status']=0x2,_0x1664b9=_0x1664b9['concat'](_e(_0x1773d1['serverSyncTree_'],_0x23b403[_0x58571c]['currentWriteId'])),_0x23b403[_0x58571c]['onComplete']&&_0x1e49b2['push'](()=>_0x23b403[_0x58571c]['onComplete'](null,!0x0,_0x23b403[_0x58571c]['currentOutputSnapshotResolved'])),_0x23b403[_0x58571c]['unwatcher']();Kn(_0x1773d1,$n(_0x1773d1['transactionQueueTree_'],_0x4f4807)),jn(_0x1773d1,_0x1773d1['transactionQueueTree_']),V(_0x1773d1['eventQueue_'],_0x4f4807,_0x1664b9);for(let _0x216867=0x0;_0x216867<_0x1e49b2['length'];_0x216867++)ft(_0x1e49b2[_0x216867]);}else{if(_0x5bc826==='datastale'){for(let _0x51d11b=0x0;_0x51d11b<_0x23b403['length'];_0x51d11b++)_0x23b403[_0x51d11b]['status']===0x3?_0x23b403[_0x51d11b]['status']=0x4:_0x23b403[_0x51d11b]['status']=0x0;}else{U('transaction\x20at\x20'+_0x499371['toString']()+'\x20failed:\x20'+_0x5bc826);for(let _0x6031d8=0x0;_0x6031d8<_0x23b403['length'];_0x6031d8++)_0x23b403[_0x6031d8]['status']=0x4,_0x23b403[_0x6031d8]['abortReason']=_0x5bc826;}ct(_0x1773d1,_0x4f4807);}},_0x30a56b);}function ct(_0x4484d1,_0x5c0f8b){const _0x31d207=ua(_0x4484d1,_0x5c0f8b),_0x565de1=Qt(_0x31d207),_0x562b7f=da(_0x4484d1,_0x31d207);return Md(_0x4484d1,_0x562b7f,_0x565de1),_0x565de1;}function Md(_0x40c71b,_0x54278f,_0x10e6e5){if(_0x54278f['length']===0x0)return;const _0x18532b=[];let _0x1dd6f1=[];const _0x1516dc=_0x54278f['filter'](_0x54783d=>_0x54783d['status']===0x0)['map'](_0x16d635=>_0x16d635['currentWriteId']);for(let _0x5ecaaa=0x0;_0x5ecaaa<_0x54278f['length'];_0x5ecaaa++){const _0x11cfa4=_0x54278f[_0x5ecaaa],_0x3c4645=F(_0x10e6e5,_0x11cfa4['path']);let _0x3a312a=!0x1,_0x488288;if(f(_0x3c4645!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x11cfa4['status']===0x4)_0x3a312a=!0x0,_0x488288=_0x11cfa4['abortReason'],_0x1dd6f1=_0x1dd6f1['concat'](_e(_0x40c71b['serverSyncTree_'],_0x11cfa4['currentWriteId'],!0x0));else{if(_0x11cfa4['status']===0x0){if(_0x11cfa4['retryCount']>=yd)_0x3a312a=!0x0,_0x488288='maxretry',_0x1dd6f1=_0x1dd6f1['concat'](_e(_0x40c71b['serverSyncTree_'],_0x11cfa4['currentWriteId'],!0x0));else{const _0x2e0d1e=Es(_0x40c71b,_0x11cfa4['path'],_0x1516dc);_0x11cfa4['currentInputSnapshot']=_0x2e0d1e;const _0x4e9e10=_0x54278f[_0x5ecaaa]['update'](_0x2e0d1e['val']());if(_0x4e9e10!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x4e9e10,_0x11cfa4['path']);let _0x249746=A(_0x4e9e10);typeof _0x4e9e10=='object'&&_0x4e9e10!=null&&Q(_0x4e9e10,'.priority')||(_0x249746=_0x249746['updatePriority'](_0x2e0d1e['getPriority']()));const _0x30998f=_0x11cfa4['currentWriteId'],_0x32531e=Xt(_0x40c71b),_0x5c09ae=fs(_0x249746,_0x2e0d1e,_0x32531e);_0x11cfa4['currentOutputSnapshotRaw']=_0x249746,_0x11cfa4['currentOutputSnapshotResolved']=_0x5c09ae,_0x11cfa4['currentWriteId']=zn(_0x40c71b),_0x1516dc['splice'](_0x1516dc['indexOf'](_0x30998f),0x1),_0x1dd6f1=_0x1dd6f1['concat'](as(_0x40c71b['serverSyncTree_'],_0x11cfa4['path'],_0x5c09ae,_0x11cfa4['currentWriteId'],_0x11cfa4['applyLocally'])),_0x1dd6f1=_0x1dd6f1['concat'](_e(_0x40c71b['serverSyncTree_'],_0x30998f,!0x0));}else _0x3a312a=!0x0,_0x488288='nodata',_0x1dd6f1=_0x1dd6f1['concat'](_e(_0x40c71b['serverSyncTree_'],_0x11cfa4['currentWriteId'],!0x0));}}}V(_0x40c71b['eventQueue_'],_0x10e6e5,_0x1dd6f1),_0x1dd6f1=[],_0x3a312a&&(_0x54278f[_0x5ecaaa]['status']=0x2,function(_0x117e7b){setTimeout(_0x117e7b,Math['floor'](0x0));}(_0x54278f[_0x5ecaaa]['unwatcher']),_0x54278f[_0x5ecaaa]['onComplete']&&(_0x488288==='nodata'?_0x18532b['push'](()=>_0x54278f[_0x5ecaaa]['onComplete'](null,!0x1,_0x54278f[_0x5ecaaa]['currentInputSnapshot'])):_0x18532b['push'](()=>_0x54278f[_0x5ecaaa]['onComplete'](new Error(_0x488288),!0x1,null))));}Kn(_0x40c71b,_0x40c71b['transactionQueueTree_']);for(let _0x45c878=0x0;_0x45c878<_0x18532b['length'];_0x45c878++)ft(_0x18532b[_0x45c878]);jn(_0x40c71b,_0x40c71b['transactionQueueTree_']);}function ua(_0x57c9b4,_0x349e59){let _0x27119b,_0x264c88=_0x57c9b4['transactionQueueTree_'];for(_0x27119b=y(_0x349e59);_0x27119b!==null&&je(_0x264c88)===void 0x0;)_0x264c88=$n(_0x264c88,_0x27119b),_0x349e59=S(_0x349e59),_0x27119b=y(_0x349e59);return _0x264c88;}function da(_0x2bb3ae,_0x397648){const _0x37db8f=[];return fa(_0x2bb3ae,_0x397648,_0x37db8f),_0x37db8f['sort']((_0x5573f2,_0x14f490)=>_0x5573f2['order']-_0x14f490['order']),_0x37db8f;}function fa(_0x8f35ce,_0x4b61d8,_0x3dd34a){const _0x2a3de1=je(_0x4b61d8);if(_0x2a3de1){for(let _0x223fd2=0x0;_0x223fd2<_0x2a3de1['length'];_0x223fd2++)_0x3dd34a['push'](_0x2a3de1[_0x223fd2]);}Gn(_0x4b61d8,_0x4cdbc3=>{fa(_0x8f35ce,_0x4cdbc3,_0x3dd34a);});}function Kn(_0x4fb04e,_0x4904c6){const _0x26cac7=je(_0x4904c6);if(_0x26cac7){let _0x42dacb=0x0;for(let _0x9bca66=0x0;_0x9bca66<_0x26cac7['length'];_0x9bca66++)_0x26cac7[_0x9bca66]['status']!==0x2&&(_0x26cac7[_0x42dacb]=_0x26cac7[_0x9bca66],_0x42dacb++);_0x26cac7['length']=_0x42dacb,gs(_0x4904c6,_0x26cac7['length']>0x0?_0x26cac7:void 0x0);}Gn(_0x4904c6,_0x3b8843=>{Kn(_0x4fb04e,_0x3b8843);});}function Is(_0x327fc4,_0x13ea30){const _0x52f153=Qt(ua(_0x327fc4,_0x13ea30)),_0x113ce0=$n(_0x327fc4['transactionQueueTree_'],_0x13ea30);return ad(_0x113ce0,_0x20dd2b=>{di(_0x327fc4,_0x20dd2b);}),di(_0x327fc4,_0x113ce0),ia(_0x113ce0,_0x17c081=>{di(_0x327fc4,_0x17c081);}),_0x52f153;}function di(_0x193e3b,_0x4c1b06){const _0x162430=je(_0x4c1b06);if(_0x162430){const _0xca7375=[];let _0x37dfb1=[],_0x227fa4=-0x1;for(let _0x35e4db=0x0;_0x35e4db<_0x162430['length'];_0x35e4db++)_0x162430[_0x35e4db]['status']===0x3||(_0x162430[_0x35e4db]['status']===0x1?(f(_0x227fa4===_0x35e4db-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x227fa4=_0x35e4db,_0x162430[_0x35e4db]['status']=0x3,_0x162430[_0x35e4db]['abortReason']='set'):(f(_0x162430[_0x35e4db]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x162430[_0x35e4db]['unwatcher'](),_0x37dfb1=_0x37dfb1['concat'](_e(_0x193e3b['serverSyncTree_'],_0x162430[_0x35e4db]['currentWriteId'],!0x0)),_0x162430[_0x35e4db]['onComplete']&&_0xca7375['push'](_0x162430[_0x35e4db]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x227fa4===-0x1?gs(_0x4c1b06,void 0x0):_0x162430['length']=_0x227fa4+0x1,V(_0x193e3b['eventQueue_'],Qt(_0x4c1b06),_0x37dfb1);for(let _0x4c6a1a=0x0;_0x4c6a1a<_0xca7375['length'];_0x4c6a1a++)ft(_0xca7375[_0x4c6a1a]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x4363c5){let _0x5071cf='';const _0x132a25=_0x4363c5['split']('/');for(let _0x4a9929=0x0;_0x4a9929<_0x132a25['length'];_0x4a9929++)if(_0x132a25[_0x4a9929]['length']>0x0){let _0x1c816a=_0x132a25[_0x4a9929];try{_0x1c816a=decodeURIComponent(_0x1c816a['replace'](/\+/g,'\x20'));}catch{}_0x5071cf+='/'+_0x1c816a;}return _0x5071cf;}function xd(_0x325135){const _0x44cf2b={};_0x325135['charAt'](0x0)==='?'&&(_0x325135=_0x325135['substring'](0x1));for(const _0xc8b69b of _0x325135['split']('&')){if(_0xc8b69b['length']===0x0)continue;const _0x5253af=_0xc8b69b['split']('=');_0x5253af['length']===0x2?_0x44cf2b[decodeURIComponent(_0x5253af[0x0])]=decodeURIComponent(_0x5253af[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0xc8b69b+'\x27\x20in\x20query\x20\x27'+_0x325135+'\x27');}return _0x44cf2b;}const vr=function(_0x34547e,_0x5b3377){const _0x1857d5=Fd(_0x34547e),_0x2737e1=_0x1857d5['namespace'];_0x1857d5['domain']==='firebase.com'&&ae(_0x1857d5['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x2737e1||_0x2737e1==='undefined')&&_0x1857d5['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x1857d5['secure']||$l();const _0x4ded4d=_0x1857d5['scheme']==='ws'||_0x1857d5['scheme']==='wss';return{'repoInfo':new yo(_0x1857d5['host'],_0x1857d5['secure'],_0x2737e1,_0x4ded4d,_0x5b3377,'',_0x2737e1!==_0x1857d5['subdomain']),'path':new C(_0x1857d5['pathString'])};},Fd=function(_0x38dcb0){let _0x3cd1f9='',_0x1c87e4='',_0x2c6a3a='',_0x530600='',_0x5a0ca0='',_0x8aca55=!0x0,_0x5ca82d='https',_0x3719f8=0x1bb;if(typeof _0x38dcb0=='string'){let _0x540cb4=_0x38dcb0['indexOf']('//');_0x540cb4>=0x0&&(_0x5ca82d=_0x38dcb0['substring'](0x0,_0x540cb4-0x1),_0x38dcb0=_0x38dcb0['substring'](_0x540cb4+0x2));let _0x1510c6=_0x38dcb0['indexOf']('/');_0x1510c6===-0x1&&(_0x1510c6=_0x38dcb0['length']);let _0xd24e23=_0x38dcb0['indexOf']('?');_0xd24e23===-0x1&&(_0xd24e23=_0x38dcb0['length']),_0x3cd1f9=_0x38dcb0['substring'](0x0,Math['min'](_0x1510c6,_0xd24e23)),_0x1510c6<_0xd24e23&&(_0x530600=Ld(_0x38dcb0['substring'](_0x1510c6,_0xd24e23)));const _0x345e86=xd(_0x38dcb0['substring'](Math['min'](_0x38dcb0['length'],_0xd24e23)));_0x540cb4=_0x3cd1f9['indexOf'](':'),_0x540cb4>=0x0?(_0x8aca55=_0x5ca82d==='https'||_0x5ca82d==='wss',_0x3719f8=parseInt(_0x3cd1f9['substring'](_0x540cb4+0x1),0xa)):_0x540cb4=_0x3cd1f9['length'];const _0x3a1b1f=_0x3cd1f9['slice'](0x0,_0x540cb4);if(_0x3a1b1f['toLowerCase']()==='localhost')_0x1c87e4='localhost';else{if(_0x3a1b1f['split']('.')['length']<=0x2)_0x1c87e4=_0x3a1b1f;else{const _0x1eba8d=_0x3cd1f9['indexOf']('.');_0x2c6a3a=_0x3cd1f9['substring'](0x0,_0x1eba8d)['toLowerCase'](),_0x1c87e4=_0x3cd1f9['substring'](_0x1eba8d+0x1),_0x5a0ca0=_0x2c6a3a;}}'ns'in _0x345e86&&(_0x5a0ca0=_0x345e86['ns']);}return{'host':_0x3cd1f9,'port':_0x3719f8,'domain':_0x1c87e4,'subdomain':_0x2c6a3a,'secure':_0x8aca55,'scheme':_0x5ca82d,'pathString':_0x530600,'namespace':_0x5a0ca0};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x3a3715=0x0;const _0x589fcd=[];return function(_0x2d5dd1){const _0x479664=_0x2d5dd1===_0x3a3715;_0x3a3715=_0x2d5dd1;let _0xa92135;const _0x5eb983=new Array(0x8);for(_0xa92135=0x7;_0xa92135>=0x0;_0xa92135--)_0x5eb983[_0xa92135]=Er['charAt'](_0x2d5dd1%0x40),_0x2d5dd1=Math['floor'](_0x2d5dd1/0x40);f(_0x2d5dd1===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x392d37=_0x5eb983['join']('');if(_0x479664){for(_0xa92135=0xb;_0xa92135>=0x0&&_0x589fcd[_0xa92135]===0x3f;_0xa92135--)_0x589fcd[_0xa92135]=0x0;_0x589fcd[_0xa92135]++;}else{for(_0xa92135=0x0;_0xa92135<0xc;_0xa92135++)_0x589fcd[_0xa92135]=Math['floor'](Math['random']()*0x40);}for(_0xa92135=0x0;_0xa92135<0xc;_0xa92135++)_0x392d37+=Er['charAt'](_0x589fcd[_0xa92135]);return f(_0x392d37['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x392d37;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0xe88da2,_0x24a28c,_0xdb09b7,_0x3166b3){this['eventType']=_0xe88da2,this['eventRegistration']=_0x24a28c,this['snapshot']=_0xdb09b7,this['prevName']=_0x3166b3;}['getPath'](){const _0x4b67b0=this['snapshot']['ref'];return this['eventType']==='value'?_0x4b67b0['_path']:_0x4b67b0['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x19c248,_0x60ae22,_0x39cdde){this['eventRegistration']=_0x19c248,this['error']=_0x60ae22,this['path']=_0x39cdde;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x4f6967,_0xbfdaa9){this['snapshotCallback']=_0x4f6967,this['cancelCallback']=_0xbfdaa9;}['onValue'](_0x3531a6,_0x1c7691){this['snapshotCallback']['call'](null,_0x3531a6,_0x1c7691);}['onCancel'](_0xa3d011){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0xa3d011);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x319bc3){return this['snapshotCallback']===_0x319bc3['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x319bc3['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x319bc3['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x4300e6,_0x2110a5){this['_repo']=_0x4300e6,this['_path']=_0x2110a5;}['cancel'](){const _0x1505db=new H();return bd(this['_repo'],this['_path'],_0x1505db['wrapCallback'](()=>{})),_0x1505db['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x32ee8a=new H();return yr(this['_repo'],this['_path'],null,_0x32ee8a['wrapCallback'](()=>{})),_0x32ee8a['promise'];}['set'](_0x68882){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x68882,this['_path'],!0x1);const _0x4d5cd3=new H();return yr(this['_repo'],this['_path'],_0x68882,_0x4d5cd3['wrapCallback'](()=>{})),_0x4d5cd3['promise'];}['setWithPriority'](_0x5af9e6,_0x4aab2c){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x5af9e6,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x4aab2c);const _0x159c32=new H();return Rd(this['_repo'],this['_path'],_0x5af9e6,_0x4aab2c,_0x159c32['wrapCallback'](()=>{})),_0x159c32['promise'];}['update'](_0x5c55ac){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x5c55ac,this['_path']);const _0x591ca8=new H();return Ad(this['_repo'],this['_path'],_0x5c55ac,_0x591ca8['wrapCallback'](()=>{})),_0x591ca8['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x4d3eb6,_0x4e977c,_0x4b80a9,_0x10773a){this['_repo']=_0x4d3eb6,this['_path']=_0x4e977c,this['_queryParams']=_0x4b80a9,this['_orderByCalled']=_0x10773a;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x45ca6e=sr(this['_queryParams']),_0x511d45=$i(_0x45ca6e);return _0x511d45==='{}'?'default':_0x511d45;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x2ab43f){if(_0x2ab43f=P(_0x2ab43f),!(_0x2ab43f instanceof Ae))return!0x1;const _0x1445e5=this['_repo']===_0x2ab43f['_repo'],_0x5969eb=Ki(this['_path'],_0x2ab43f['_path']),_0x38c8b6=this['_queryIdentifier']===_0x2ab43f['_queryIdentifier'];return _0x1445e5&&_0x5969eb&&_0x38c8b6;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x3e0483,_0x585be1){if(_0x3e0483['_orderByCalled']===!0x0)throw new Error(_0x585be1+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x4af146){let _0x124df0=null,_0x58946b=null;if(_0x4af146['hasStart']()&&(_0x124df0=_0x4af146['getIndexStartValue']()),_0x4af146['hasEnd']()&&(_0x58946b=_0x4af146['getIndexEndValue']()),_0x4af146['getIndex']()===ve){const _0x1c72b5='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x4383aa='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x4af146['hasStart']()){if(_0x4af146['getIndexStartName']()!==We)throw new Error(_0x1c72b5);if(typeof _0x124df0!='string')throw new Error(_0x4383aa);}if(_0x4af146['hasEnd']()){if(_0x4af146['getIndexEndName']()!==we)throw new Error(_0x1c72b5);if(typeof _0x58946b!='string')throw new Error(_0x4383aa);}}else{if(_0x4af146['getIndex']()===R){if(_0x124df0!=null&&!Bt(_0x124df0)||_0x58946b!=null&&!Bt(_0x58946b))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x4af146['getIndex']()instanceof Ji||_0x4af146['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x124df0!=null&&typeof _0x124df0=='object'||_0x58946b!=null&&typeof _0x58946b=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x4fc2a2){if(_0x4fc2a2['hasStart']()&&_0x4fc2a2['hasEnd']()&&_0x4fc2a2['hasLimit']()&&!_0x4fc2a2['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x2bb0d5,_0x10a3a8){super(_0x2bb0d5,_0x10a3a8,new Zi(),!0x1);}get['parent'](){const _0xb4f66c=Ro(this['_path']);return _0xb4f66c===null?null:new ee(this['_repo'],_0xb4f66c);}get['root'](){let _0x337bca=this;for(;_0x337bca['parent']!==null;)_0x337bca=_0x337bca['parent'];return _0x337bca;}}class lt{constructor(_0x5de77e,_0x7c4b73,_0x30dde0){this['_node']=_0x5de77e,this['ref']=_0x7c4b73,this['_index']=_0x30dde0;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x3982a8){const _0x3772eb=new C(_0x3982a8),_0x23444a=Vt(this['ref'],_0x3982a8);return new lt(this['_node']['getChild'](_0x3772eb),_0x23444a,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x56b976){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x3f3ec3,_0x463023)=>_0x56b976(new lt(_0x463023,Vt(this['ref'],_0x3f3ec3),R)));}['hasChild'](_0x84f210){const _0x156c69=new C(_0x84f210);return!this['_node']['getChild'](_0x156c69)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x1a9df2,_0x449014){return _0x1a9df2=P(_0x1a9df2),_0x1a9df2['_checkNotDeleted']('ref'),_0x449014!==void 0x0?Vt(_0x1a9df2['_root'],_0x449014):_0x1a9df2['_root'];}function Vt(_0x4d47d8,_0x43ce52){return _0x4d47d8=P(_0x4d47d8),y(_0x4d47d8['_path'])===null?pd('child','path',_0x43ce52):ys('child','path',_0x43ce52),new ee(_0x4d47d8['_repo'],k(_0x4d47d8['_path'],_0x43ce52));}function v_(_0x1a638a){return _0x1a638a=P(_0x1a638a),new Vd(_0x1a638a['_repo'],_0x1a638a['_path']);}function E_(_0x2b7440,_0x109f35){_0x2b7440=P(_0x2b7440),Me('push',_0x2b7440['_path']),He('push',_0x109f35,_0x2b7440['_path'],!0x0);const _0xc4e687=la(_0x2b7440['_repo']),_0x59eab7=Ud(_0xc4e687),_0x3585e8=Vt(_0x2b7440,_0x59eab7),_0x8f39fb=Vt(_0x2b7440,_0x59eab7);let _0x4de4e6;return _0x109f35!=null?_0x4de4e6=Hd(_0x8f39fb,_0x109f35)['then'](()=>_0x8f39fb):_0x4de4e6=Promise['resolve'](_0x8f39fb),_0x3585e8['then']=_0x4de4e6['then']['bind'](_0x4de4e6),_0x3585e8['catch']=_0x4de4e6['then']['bind'](_0x4de4e6,void 0x0),_0x3585e8;}function Hd(_0x26051c,_0x1d2bae){_0x26051c=P(_0x26051c),Me('set',_0x26051c['_path']),He('set',_0x1d2bae,_0x26051c['_path'],!0x1);const _0x3dd134=new H();return Cd(_0x26051c['_repo'],_0x26051c['_path'],_0x1d2bae,null,_0x3dd134['wrapCallback'](()=>{})),_0x3dd134['promise'];}function I_(_0xfa6daa,_0x2c2464){ra('update',_0x2c2464,_0xfa6daa['_path']);const _0x24784a=new H();return Td(_0xfa6daa['_repo'],_0xfa6daa['_path'],_0x2c2464,_0x24784a['wrapCallback'](()=>{})),_0x24784a['promise'];}function w_(_0x1b5f92){_0x1b5f92=P(_0x1b5f92);const _0xedc8b2=new pa(()=>{}),_0x3ba994=new Qn(_0xedc8b2);return wd(_0x1b5f92['_repo'],_0x1b5f92,_0x3ba994)['then'](_0x48e682=>new lt(_0x48e682,new ee(_0x1b5f92['_repo'],_0x1b5f92['_path']),_0x1b5f92['_queryParams']['getIndex']()));}class Qn{constructor(_0x1a76e0){this['callbackContext']=_0x1a76e0;}['respondsTo'](_0x49a268){return _0x49a268==='value';}['createEvent'](_0x48e5eb,_0x1773f3){const _0x509c14=_0x1773f3['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x48e5eb['snapshotNode'],new ee(_0x1773f3['_repo'],_0x1773f3['_path']),_0x509c14));}['getEventRunner'](_0x17dca7){return _0x17dca7['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x17dca7['error']):()=>this['callbackContext']['onValue'](_0x17dca7['snapshot'],null);}['createCancelEvent'](_0x118615,_0x17c25e){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x118615,_0x17c25e):null;}['matches'](_0x25fbbb){return _0x25fbbb instanceof Qn?!_0x25fbbb['callbackContext']||!this['callbackContext']?!0x0:_0x25fbbb['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x1a74fc,_0xe39d6e,_0x45c7c4,_0x29c342,_0x2a6054){const _0x2fbbdd=new pa(_0x45c7c4,void 0x0),_0x5db4f2=new Qn(_0x2fbbdd);return kd(_0x1a74fc['_repo'],_0x1a74fc,_0x5db4f2),()=>Pd(_0x1a74fc['_repo'],_0x1a74fc,_0x5db4f2);}function Gd(_0x277e1f,_0x3fbc21,_0x58df6c,_0x1ccc72){return $d(_0x277e1f,'value',_0x3fbc21);}class mt{}class ma extends mt{constructor(_0x2e77e3,_0x3db5e1){super(),this['_value']=_0x2e77e3,this['_key']=_0x3db5e1,this['type']='endAt';}['_apply'](_0x3e52af){He('endAt',this['_value'],_0x3e52af['_path'],!0x0);const _0x42b38f=Jh(_0x3e52af['_queryParams'],this['_value'],this['_key']);if(ga(_0x42b38f),Yn(_0x42b38f),_0x3e52af['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x3e52af['_repo'],_0x3e52af['_path'],_0x42b38f,_0x3e52af['_orderByCalled']);}}function C_(_0x38c160,_0x4d5338){return new ma(_0x38c160,_0x4d5338);}class ya extends mt{constructor(_0x2ba889,_0x42965a){super(),this['_value']=_0x2ba889,this['_key']=_0x42965a,this['type']='startAt';}['_apply'](_0x57089e){He('startAt',this['_value'],_0x57089e['_path'],!0x0);const _0x39f4a0=Qh(_0x57089e['_queryParams'],this['_value'],this['_key']);if(ga(_0x39f4a0),Yn(_0x39f4a0),_0x57089e['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x57089e['_repo'],_0x57089e['_path'],_0x39f4a0,_0x57089e['_orderByCalled']);}}function T_(_0x3480aa=null,_0x4239d2){return new ya(_0x3480aa,_0x4239d2);}class qd extends mt{constructor(_0x203e5f){super(),this['_limit']=_0x203e5f,this['type']='limitToFirst';}['_apply'](_0x4a1422){if(_0x4a1422['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x4a1422['_repo'],_0x4a1422['_path'],Yh(_0x4a1422['_queryParams'],this['_limit']),_0x4a1422['_orderByCalled']);}}function S_(_0x5d6c73){if(Math['floor'](_0x5d6c73)!==_0x5d6c73||_0x5d6c73<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x5d6c73);}class zd extends mt{constructor(_0x58538e){super(),this['_path']=_0x58538e,this['type']='orderByChild';}['_apply'](_0x5a4bd7){_a(_0x5a4bd7,'orderByChild');const _0xbb9e88=new C(this['_path']);if(v(_0xbb9e88))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x1317e1=new Ji(_0xbb9e88),_0x427032=xo(_0x5a4bd7['_queryParams'],_0x1317e1);return Yn(_0x427032),new Ae(_0x5a4bd7['_repo'],_0x5a4bd7['_path'],_0x427032,!0x0);}}function b_(_0x44970c){if(_0x44970c==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x44970c==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x44970c==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x44970c),new zd(_0x44970c);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x1988f6){_a(_0x1988f6,'orderByKey');const _0x3eb525=xo(_0x1988f6['_queryParams'],ve);return Yn(_0x3eb525),new Ae(_0x1988f6['_repo'],_0x1988f6['_path'],_0x3eb525,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x181f8c,_0x46115a){super(),this['_value']=_0x181f8c,this['_key']=_0x46115a,this['type']='equalTo';}['_apply'](_0x4f57ea){if(He('equalTo',this['_value'],_0x4f57ea['_path'],!0x1),_0x4f57ea['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x4f57ea['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x4f57ea));}}function A_(_0x59d9fe,_0x5978f2){return new Kd(_0x59d9fe,_0x5978f2);}function k_(_0x5a2803,..._0x11a01c){let _0x3884c8=P(_0x5a2803);for(const _0x595df5 of _0x11a01c)_0x3884c8=_0x595df5['_apply'](_0x3884c8);return _0x3884c8;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x30af09,_0x2fbf3c,_0x16ee4f,_0x4db058){const _0x248b5f=_0x2fbf3c['lastIndexOf'](':'),_0x217055=_0x2fbf3c['substring'](0x0,_0x248b5f),_0x3f06f6=qt(_0x217055);_0x30af09['repoInfo_']=new yo(_0x2fbf3c,_0x3f06f6,_0x30af09['repoInfo_']['namespace'],_0x30af09['repoInfo_']['webSocketOnly'],_0x30af09['repoInfo_']['nodeAdmin'],_0x30af09['repoInfo_']['persistenceKey'],_0x30af09['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x16ee4f),_0x4db058&&(_0x30af09['authTokenProvider_']=_0x4db058);}function Xd(_0x1ad363,_0x9abb63,_0x367c56,_0x5596be,_0x5092bb){let _0x3d7707=_0x5596be||_0x1ad363['options']['databaseURL'];_0x3d7707===void 0x0&&(_0x1ad363['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x1ad363['options']['projectId']),_0x3d7707=_0x1ad363['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x4a374d=vr(_0x3d7707,_0x5092bb),_0x3c2dac=_0x4a374d['repoInfo'],_0x51bc6c;typeof process<'u'&&Bs&&(_0x51bc6c=Bs[Yd]),_0x51bc6c?(_0x3d7707='http://'+_0x51bc6c+'?ns='+_0x3c2dac['namespace'],_0x4a374d=vr(_0x3d7707,_0x5092bb),_0x3c2dac=_0x4a374d['repoInfo']):_0x4a374d['repoInfo']['secure'];const _0x7a390=new eh(_0x1ad363['name'],_0x1ad363['options'],_0x9abb63);_d('Invalid\x20Firebase\x20Database\x20URL',_0x4a374d),v(_0x4a374d['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x436376=ef(_0x3c2dac,_0x1ad363,_0x7a390,new Zl(_0x1ad363,_0x367c56));return new tf(_0x436376,_0x1ad363);}function Zd(_0x1c26ee,_0x725158){const _0xd6dd96=Di[_0x725158];(!_0xd6dd96||_0xd6dd96[_0x1c26ee['key']]!==_0x1c26ee)&&ae('Database\x20'+_0x725158+'('+_0x1c26ee['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x1c26ee),delete _0xd6dd96[_0x1c26ee['key']];}function ef(_0x3fb9fa,_0x3c5442,_0x2f203e,_0x54425c){let _0x2dc493=Di[_0x3c5442['name']];_0x2dc493||(_0x2dc493={},Di[_0x3c5442['name']]=_0x2dc493);let _0x41f72e=_0x2dc493[_0x3fb9fa['toURLString']()];return _0x41f72e&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x41f72e=new vd(_0x3fb9fa,Qd,_0x2f203e,_0x54425c),_0x2dc493[_0x3fb9fa['toURLString']()]=_0x41f72e,_0x41f72e;}class tf{constructor(_0x4094b2,_0x384312){this['_repoInternal']=_0x4094b2,this['app']=_0x384312,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x4ad3c0){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x4ad3c0+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x3098da=Zr(),_0x3dbd44){const _0x54511d=Hi(_0x3098da,'database')['getImmediate']({'identifier':_0x3dbd44});if(!_0x54511d['_instanceStarted']){const _0x1160f7=hc('database');_0x1160f7&&nf(_0x54511d,..._0x1160f7);}return _0x54511d;}function nf(_0x324dd4,_0x4371ee,_0x529152,_0x16f81d={}){_0x324dd4=P(_0x324dd4),_0x324dd4['_checkNotDeleted']('useEmulator');const _0x2be8ce=_0x4371ee+':'+_0x529152,_0x4d7091=_0x324dd4['_repoInternal'];if(_0x324dd4['_instanceStarted']){if(_0x2be8ce===_0x324dd4['_repoInternal']['repoInfo_']['host']&&xe(_0x16f81d,_0x4d7091['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x405417;if(_0x4d7091['repoInfo_']['nodeAdmin'])_0x16f81d['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x405417=new an(an['OWNER']);else{if(_0x16f81d['mockUserToken']){const _0x1ec284=typeof _0x16f81d['mockUserToken']=='string'?_0x16f81d['mockUserToken']:uc(_0x16f81d['mockUserToken'],_0x324dd4['app']['options']['projectId']);_0x405417=new an(_0x1ec284);}}qt(_0x4371ee)&&Qr(_0x4371ee),Jd(_0x4d7091,_0x2be8ce,_0x16f81d,_0x405417);}function N_(_0x2f0b8d){_0x2f0b8d=P(_0x2f0b8d),_0x2f0b8d['_checkNotDeleted']('goOffline'),ha(_0x2f0b8d['_repo']);}function O_(_0x4314a8){_0x4314a8=P(_0x4314a8),_0x4314a8['_checkNotDeleted']('goOnline'),Nd(_0x4314a8['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x300896){Ul(dt),st(new Fe('database',(_0x17fd37,{instanceIdentifier:_0x3a08e7})=>{const _0x5c4735=_0x17fd37['getProvider']('app')['getImmediate'](),_0xede829=_0x17fd37['getProvider']('auth-internal'),_0x33f2b2=_0x17fd37['getProvider']('app-check-internal');return Xd(_0x5c4735,_0xede829,_0x33f2b2,_0x3a08e7);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x300896),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x1ae3ae,_0x75dbe2){this['committed']=_0x1ae3ae,this['snapshot']=_0x75dbe2;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x54b570,_0x4ab62b,_0x13a267){if(_0x54b570=P(_0x54b570),Me('Reference.transaction',_0x54b570['_path']),_0x54b570['key']==='.length'||_0x54b570['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x54b570['key']+'\x20is\x20a\x20read-only\x20object.';const _0x51635a=!0x0,_0x5d40c7=new H(),_0x361892=(_0x587510,_0x4d6654,_0x9e8f75)=>{let _0x747c7f=null;_0x587510?_0x5d40c7['reject'](_0x587510):(_0x747c7f=new lt(_0x9e8f75,new ee(_0x54b570['_repo'],_0x54b570['_path']),R),_0x5d40c7['resolve'](new of(_0x4d6654,_0x747c7f)));},_0x5934a1=Gd(_0x54b570,()=>{});return Od(_0x54b570['_repo'],_0x54b570['_path'],_0x4ab62b,_0x361892,_0x5934a1,_0x51635a),_0x5d40c7['promise'];}se['prototype']['simpleListen']=function(_0x5db68e,_0x48c529){this['sendRequest']('q',{'p':_0x5db68e},_0x48c529);},se['prototype']['echo']=function(_0x18631b,_0x1aaa30){this['sendRequest']('echo',{'d':_0x18631b},_0x1aaa30);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x462e26,..._0x47db5e){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x462e26,..._0x47db5e);}function cn(_0x3d5f35,..._0x261df5){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x3d5f35,..._0x261df5);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x467282,..._0x593975){throw ws(_0x467282,..._0x593975);}function X(_0x3306f8,..._0x17dc4e){return ws(_0x3306f8,..._0x17dc4e);}function Ia(_0x27d17e,_0xde4c48,_0x5e8154){const _0x55c25f={...af(),[_0xde4c48]:_0x5e8154};return new Gt('auth','Firebase',_0x55c25f)['create'](_0xde4c48,{'appName':_0x27d17e['name']});}function re(_0x2cb492){return Ia(_0x2cb492,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x26818d,..._0x4b11a3){if(typeof _0x26818d!='string'){const _0x3c61e5=_0x4b11a3[0x0],_0xc0e965=[..._0x4b11a3['slice'](0x1)];return _0xc0e965[0x0]&&(_0xc0e965[0x0]['appName']=_0x26818d['name']),_0x26818d['_errorFactory']['create'](_0x3c61e5,..._0xc0e965);}return Ea['create'](_0x26818d,..._0x4b11a3);}function m(_0x13e925,_0x23a75c,..._0x2c112e){if(!_0x13e925)throw ws(_0x23a75c,..._0x2c112e);}function ne(_0x124c09){const _0x597d04='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x124c09;throw cn(_0x597d04),new Error(_0x597d04);}function ce(_0x4185f6,_0x21b426){_0x4185f6||ne(_0x21b426);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x5c5de9;return typeof self<'u'&&((_0x5c5de9=self['location'])==null?void 0x0:_0x5c5de9['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x29fb6a;return typeof self<'u'&&((_0x29fb6a=self['location'])==null?void 0x0:_0x29fb6a['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x547f13=navigator;return _0x547f13['languages']&&_0x547f13['languages'][0x0]||_0x547f13['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x5a8aa0,_0x528a91){this['shortDelay']=_0x5a8aa0,this['longDelay']=_0x528a91,ce(_0x528a91>_0x5a8aa0,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x1c629f,_0x244399){ce(_0x1c629f['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x6bb315}=_0x1c629f['emulator'];return _0x244399?''+_0x6bb315+(_0x244399['startsWith']('/')?_0x244399['slice'](0x1):_0x244399):_0x6bb315;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0xc9e9a7,_0x41b964,_0x12c6cd){this['fetchImpl']=_0xc9e9a7,_0x41b964&&(this['headersImpl']=_0x41b964),_0x12c6cd&&(this['responseImpl']=_0x12c6cd);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x599511,_0x54bdbb){return _0x599511['tenantId']&&!_0x54bdbb['tenantId']?{..._0x54bdbb,'tenantId':_0x599511['tenantId']}:_0x54bdbb;}async function Pe(_0x1edfbf,_0x224f42,_0x15cac2,_0x171b35,_0x13722b={}){return Ca(_0x1edfbf,_0x13722b,async()=>{let _0x23cdc8={},_0xbcb69e={};_0x171b35&&(_0x224f42==='GET'?_0xbcb69e=_0x171b35:_0x23cdc8={'body':JSON['stringify'](_0x171b35)});const _0x57c14a=ut({..._0xbcb69e,'key':_0x1edfbf['config']['apiKey']})['slice'](0x1),_0x4d75d4=await _0x1edfbf['_getAdditionalHeaders']();_0x4d75d4['Content-Type']='application/json',_0x1edfbf['languageCode']&&(_0x4d75d4['X-Firebase-Locale']=_0x1edfbf['languageCode']);const _0x174b6a={'method':_0x224f42,'headers':_0x4d75d4,..._0x23cdc8};return dc()||(_0x174b6a['referrerPolicy']='strict-origin-when-cross-origin'),_0x1edfbf['emulatorConfig']&&qt(_0x1edfbf['emulatorConfig']['host'])&&(_0x174b6a['credentials']='include'),wa['fetch']()(await Ta(_0x1edfbf,_0x1edfbf['config']['apiHost'],_0x15cac2,_0x57c14a),_0x174b6a);});}async function Ca(_0x32dacc,_0x519dab,_0x3bb762){_0x32dacc['_canInitEmulator']=!0x1;const _0x1330fa={...df,..._0x519dab};try{const _0x524b58=new gf(_0x32dacc),_0x29d47e=await Promise['race']([_0x3bb762(),_0x524b58['promise']]);_0x524b58['clearNetworkTimeout']();const _0x57bbd0=await _0x29d47e['json']();if('needConfirmation'in _0x57bbd0)throw on(_0x32dacc,'account-exists-with-different-credential',_0x57bbd0);if(_0x29d47e['ok']&&!('errorMessage'in _0x57bbd0))return _0x57bbd0;{const _0x31e6b5=_0x29d47e['ok']?_0x57bbd0['errorMessage']:_0x57bbd0['error']['message'],[_0x31875c,_0x3a95d4]=_0x31e6b5['split']('\x20:\x20');if(_0x31875c==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x32dacc,'credential-already-in-use',_0x57bbd0);if(_0x31875c==='EMAIL_EXISTS')throw on(_0x32dacc,'email-already-in-use',_0x57bbd0);if(_0x31875c==='USER_DISABLED')throw on(_0x32dacc,'user-disabled',_0x57bbd0);const _0x4461b5=_0x1330fa[_0x31875c]||_0x31875c['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x3a95d4)throw Ia(_0x32dacc,_0x4461b5,_0x3a95d4);Y(_0x32dacc,_0x4461b5);}}catch(_0x566d9f){if(_0x566d9f instanceof Re)throw _0x566d9f;Y(_0x32dacc,'network-request-failed',{'message':String(_0x566d9f)});}}async function en(_0x41a16e,_0x360404,_0x528f16,_0x13a43b,_0x2e9483={}){const _0x2c0c83=await Pe(_0x41a16e,_0x360404,_0x528f16,_0x13a43b,_0x2e9483);return'mfaPendingCredential'in _0x2c0c83&&Y(_0x41a16e,'multi-factor-auth-required',{'_serverResponse':_0x2c0c83}),_0x2c0c83;}async function Ta(_0x3c6eac,_0xa77aa8,_0x49e41f,_0x34a88a){const _0x3a011b=''+_0xa77aa8+_0x49e41f+'?'+_0x34a88a,_0x490368=_0x3c6eac,_0x4376e8=_0x490368['config']['emulator']?Cs(_0x3c6eac['config'],_0x3a011b):_0x3c6eac['config']['apiScheme']+'://'+_0x3a011b;return ff['includes'](_0x49e41f)&&(await _0x490368['_persistenceManagerAvailable'],_0x490368['_getPersistenceType']()==='COOKIE')?_0x490368['_getPersistence']()['_getFinalTarget'](_0x4376e8)['toString']():_0x4376e8;}function _f(_0x3ae083){switch(_0x3ae083){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x5ab2a0){this['auth']=_0x5ab2a0,this['timer']=null,this['promise']=new Promise((_0x4b8689,_0x57f47d)=>{this['timer']=setTimeout(()=>_0x57f47d(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x3f0e31,_0x186657,_0x5ad56b){const _0x31caf0={'appName':_0x3f0e31['name']};_0x5ad56b['email']&&(_0x31caf0['email']=_0x5ad56b['email']),_0x5ad56b['phoneNumber']&&(_0x31caf0['phoneNumber']=_0x5ad56b['phoneNumber']);const _0x31d052=X(_0x3f0e31,_0x186657,_0x31caf0);return _0x31d052['customData']['_tokenResponse']=_0x5ad56b,_0x31d052;}function wr(_0x243eab){return _0x243eab!==void 0x0&&_0x243eab['enterprise']!==void 0x0;}class mf{constructor(_0x320365){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x320365['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x320365['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x320365['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x124855){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x418483 of this['recaptchaEnforcementState'])if(_0x418483['provider']&&_0x418483['provider']===_0x124855)return _f(_0x418483['enforcementState']);return null;}['isProviderEnabled'](_0x5a70f2){return this['getProviderEnforcementState'](_0x5a70f2)==='ENFORCE'||this['getProviderEnforcementState'](_0x5a70f2)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x5775f0,_0x1ac6df){return Pe(_0x5775f0,'GET','/v2/recaptchaConfig',ke(_0x5775f0,_0x1ac6df));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x3b954f,_0x346dba){return Pe(_0x3b954f,'POST','/v1/accounts:delete',_0x346dba);}async function Pn(_0x3aed3f,_0x5774b6){return Pe(_0x3aed3f,'POST','/v1/accounts:lookup',_0x5774b6);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x409056){if(_0x409056)try{const _0x12938f=new Date(Number(_0x409056));if(!isNaN(_0x12938f['getTime']()))return _0x12938f['toUTCString']();}catch{}}async function Ef(_0x420b16,_0x1cb4ee=!0x1){const _0x4a53b7=P(_0x420b16),_0x45e47b=await _0x4a53b7['getIdToken'](_0x1cb4ee),_0x407bfa=Ts(_0x45e47b);m(_0x407bfa&&_0x407bfa['exp']&&_0x407bfa['auth_time']&&_0x407bfa['iat'],_0x4a53b7['auth'],'internal-error');const _0x360d73=typeof _0x407bfa['firebase']=='object'?_0x407bfa['firebase']:void 0x0,_0x350238=_0x360d73==null?void 0x0:_0x360d73['sign_in_provider'];return{'claims':_0x407bfa,'token':_0x45e47b,'authTime':Pt(fi(_0x407bfa['auth_time'])),'issuedAtTime':Pt(fi(_0x407bfa['iat'])),'expirationTime':Pt(fi(_0x407bfa['exp'])),'signInProvider':_0x350238||null,'signInSecondFactor':(_0x360d73==null?void 0x0:_0x360d73['sign_in_second_factor'])||null};}function fi(_0x663916){return Number(_0x663916)*0x3e8;}function Ts(_0x13119a){const [_0x3d4e77,_0x357ea8,_0x56485c]=_0x13119a['split']('.');if(_0x3d4e77===void 0x0||_0x357ea8===void 0x0||_0x56485c===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x288c9d=fn(_0x357ea8);return _0x288c9d?JSON['parse'](_0x288c9d):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x100200){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x100200==null?void 0x0:_0x100200['toString']()),null;}}function Cr(_0x2d7f5a){const _0x56a857=Ts(_0x2d7f5a);return m(_0x56a857,'internal-error'),m(typeof _0x56a857['exp']<'u','internal-error'),m(typeof _0x56a857['iat']<'u','internal-error'),Number(_0x56a857['exp'])-Number(_0x56a857['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x561277,_0x250088,_0x25ff02=!0x1){if(_0x25ff02)return _0x250088;try{return await _0x250088;}catch(_0x22000d){throw _0x22000d instanceof Re&&If(_0x22000d)&&_0x561277['auth']['currentUser']===_0x561277&&await _0x561277['auth']['signOut'](),_0x22000d;}}function If({code:_0x16831f}){return _0x16831f==='auth/user-disabled'||_0x16831f==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x40d96c){this['user']=_0x40d96c,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x971aa7){if(_0x971aa7){const _0x459bb9=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x459bb9;}else{this['errorBackoff']=0x7530;const _0xa7246e=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0xa7246e);}}['schedule'](_0x1080cf=!0x1){if(!this['isRunning'])return;const _0x1a7560=this['getInterval'](_0x1080cf);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x1a7560);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x2c5e24){(_0x2c5e24==null?void 0x0:_0x2c5e24['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x26ccd1,_0x339f7f){this['createdAt']=_0x26ccd1,this['lastLoginAt']=_0x339f7f,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x4ae000){this['createdAt']=_0x4ae000['createdAt'],this['lastLoginAt']=_0x4ae000['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x381f9f){var _0x39ec81;const _0x4324c1=_0x381f9f['auth'],_0x385eff=await _0x381f9f['getIdToken'](),_0x1c47d9=await Ht(_0x381f9f,Pn(_0x4324c1,{'idToken':_0x385eff}));m(_0x1c47d9==null?void 0x0:_0x1c47d9['users']['length'],_0x4324c1,'internal-error');const _0x50a2e4=_0x1c47d9['users'][0x0];_0x381f9f['_notifyReloadListener'](_0x50a2e4);const _0xf007f3=(_0x39ec81=_0x50a2e4['providerUserInfo'])!=null&&_0x39ec81['length']?Sa(_0x50a2e4['providerUserInfo']):[],_0x13a33c=Tf(_0x381f9f['providerData'],_0xf007f3),_0x424028=_0x381f9f['isAnonymous'],_0x406a54=!(_0x381f9f['email']&&_0x50a2e4['passwordHash'])&&!(_0x13a33c!=null&&_0x13a33c['length']),_0x5b8c13=_0x424028?_0x406a54:!0x1,_0x179e6a={'uid':_0x50a2e4['localId'],'displayName':_0x50a2e4['displayName']||null,'photoURL':_0x50a2e4['photoUrl']||null,'email':_0x50a2e4['email']||null,'emailVerified':_0x50a2e4['emailVerified']||!0x1,'phoneNumber':_0x50a2e4['phoneNumber']||null,'tenantId':_0x50a2e4['tenantId']||null,'providerData':_0x13a33c,'metadata':new Li(_0x50a2e4['createdAt'],_0x50a2e4['lastLoginAt']),'isAnonymous':_0x5b8c13};Object['assign'](_0x381f9f,_0x179e6a);}async function Cf(_0x2fd310){const _0x6c9a1c=P(_0x2fd310);await Nn(_0x6c9a1c),await _0x6c9a1c['auth']['_persistUserIfCurrent'](_0x6c9a1c),_0x6c9a1c['auth']['_notifyListenersIfCurrent'](_0x6c9a1c);}function Tf(_0x4514d7,_0x251727){return[..._0x4514d7['filter'](_0x5a57fc=>!_0x251727['some'](_0x32f632=>_0x32f632['providerId']===_0x5a57fc['providerId'])),..._0x251727];}function Sa(_0x8542d0){return _0x8542d0['map'](({providerId:_0x4af666,..._0x812a5})=>({'providerId':_0x4af666,'uid':_0x812a5['rawId']||'','displayName':_0x812a5['displayName']||null,'email':_0x812a5['email']||null,'phoneNumber':_0x812a5['phoneNumber']||null,'photoURL':_0x812a5['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x4b8856,_0x4705b7){const _0x41ce1a=await Ca(_0x4b8856,{},async()=>{const _0x12064b=ut({'grant_type':'refresh_token','refresh_token':_0x4705b7})['slice'](0x1),{tokenApiHost:_0x24594b,apiKey:_0xe9f813}=_0x4b8856['config'],_0x2d3e94=await Ta(_0x4b8856,_0x24594b,'/v1/token','key='+_0xe9f813),_0x1a7696=await _0x4b8856['_getAdditionalHeaders']();_0x1a7696['Content-Type']='application/x-www-form-urlencoded';const _0x522319={'method':'POST','headers':_0x1a7696,'body':_0x12064b};return _0x4b8856['emulatorConfig']&&qt(_0x4b8856['emulatorConfig']['host'])&&(_0x522319['credentials']='include'),wa['fetch']()(_0x2d3e94,_0x522319);});return{'accessToken':_0x41ce1a['access_token'],'expiresIn':_0x41ce1a['expires_in'],'refreshToken':_0x41ce1a['refresh_token']};}async function bf(_0x3f0d89,_0x2a34d4){return Pe(_0x3f0d89,'POST','/v2/accounts:revokeToken',ke(_0x3f0d89,_0x2a34d4));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x5146d3){m(_0x5146d3['idToken'],'internal-error'),m(typeof _0x5146d3['idToken']<'u','internal-error'),m(typeof _0x5146d3['refreshToken']<'u','internal-error');const _0x13858f='expiresIn'in _0x5146d3&&typeof _0x5146d3['expiresIn']<'u'?Number(_0x5146d3['expiresIn']):Cr(_0x5146d3['idToken']);this['updateTokensAndExpiration'](_0x5146d3['idToken'],_0x5146d3['refreshToken'],_0x13858f);}['updateFromIdToken'](_0x13dc46){m(_0x13dc46['length']!==0x0,'internal-error');const _0x687e99=Cr(_0x13dc46);this['updateTokensAndExpiration'](_0x13dc46,null,_0x687e99);}async['getToken'](_0x12a1ef,_0x3285d3=!0x1){return!_0x3285d3&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x12a1ef,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x12a1ef,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x3c5d69,_0x3ff877){const {accessToken:_0x4a37e2,refreshToken:_0x3fa17b,expiresIn:_0x1bb0f7}=await Sf(_0x3c5d69,_0x3ff877);this['updateTokensAndExpiration'](_0x4a37e2,_0x3fa17b,Number(_0x1bb0f7));}['updateTokensAndExpiration'](_0x3e37e2,_0x54e332,_0x391f91){this['refreshToken']=_0x54e332||null,this['accessToken']=_0x3e37e2||null,this['expirationTime']=Date['now']()+_0x391f91*0x3e8;}static['fromJSON'](_0x5e7537,_0x8f35ae){const {refreshToken:_0x5e9234,accessToken:_0xb78a3,expirationTime:_0x6e03c9}=_0x8f35ae,_0x18f8a8=new et();return _0x5e9234&&(m(typeof _0x5e9234=='string','internal-error',{'appName':_0x5e7537}),_0x18f8a8['refreshToken']=_0x5e9234),_0xb78a3&&(m(typeof _0xb78a3=='string','internal-error',{'appName':_0x5e7537}),_0x18f8a8['accessToken']=_0xb78a3),_0x6e03c9&&(m(typeof _0x6e03c9=='number','internal-error',{'appName':_0x5e7537}),_0x18f8a8['expirationTime']=_0x6e03c9),_0x18f8a8;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x5d7533){this['accessToken']=_0x5d7533['accessToken'],this['refreshToken']=_0x5d7533['refreshToken'],this['expirationTime']=_0x5d7533['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x4cd0a1,_0x482b2b){m(typeof _0x4cd0a1=='string'||typeof _0x4cd0a1>'u','internal-error',{'appName':_0x482b2b});}class j{constructor({uid:_0x434b51,auth:_0x59a31f,stsTokenManager:_0x4d5a58,..._0x2329d3}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x434b51,this['auth']=_0x59a31f,this['stsTokenManager']=_0x4d5a58,this['accessToken']=_0x4d5a58['accessToken'],this['displayName']=_0x2329d3['displayName']||null,this['email']=_0x2329d3['email']||null,this['emailVerified']=_0x2329d3['emailVerified']||!0x1,this['phoneNumber']=_0x2329d3['phoneNumber']||null,this['photoURL']=_0x2329d3['photoURL']||null,this['isAnonymous']=_0x2329d3['isAnonymous']||!0x1,this['tenantId']=_0x2329d3['tenantId']||null,this['providerData']=_0x2329d3['providerData']?[..._0x2329d3['providerData']]:[],this['metadata']=new Li(_0x2329d3['createdAt']||void 0x0,_0x2329d3['lastLoginAt']||void 0x0);}async['getIdToken'](_0x31746d){const _0x227651=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x31746d));return m(_0x227651,this['auth'],'internal-error'),this['accessToken']!==_0x227651&&(this['accessToken']=_0x227651,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x227651;}['getIdTokenResult'](_0x4d4b15){return Ef(this,_0x4d4b15);}['reload'](){return Cf(this);}['_assign'](_0x539892){this!==_0x539892&&(m(this['uid']===_0x539892['uid'],this['auth'],'internal-error'),this['displayName']=_0x539892['displayName'],this['photoURL']=_0x539892['photoURL'],this['email']=_0x539892['email'],this['emailVerified']=_0x539892['emailVerified'],this['phoneNumber']=_0x539892['phoneNumber'],this['isAnonymous']=_0x539892['isAnonymous'],this['tenantId']=_0x539892['tenantId'],this['providerData']=_0x539892['providerData']['map'](_0x2b5144=>({..._0x2b5144})),this['metadata']['_copy'](_0x539892['metadata']),this['stsTokenManager']['_assign'](_0x539892['stsTokenManager']));}['_clone'](_0x4e9e4b){const _0x4d843f=new j({...this,'auth':_0x4e9e4b,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x4d843f['metadata']['_copy'](this['metadata']),_0x4d843f;}['_onReload'](_0x95f5b6){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x95f5b6,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x3de64e){this['reloadListener']?this['reloadListener'](_0x3de64e):this['reloadUserInfo']=_0x3de64e;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x310a6e,_0x17a0ed=!0x1){let _0xb86ba1=!0x1;_0x310a6e['idToken']&&_0x310a6e['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x310a6e),_0xb86ba1=!0x0),_0x17a0ed&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0xb86ba1&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x58d29a=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x58d29a})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x576af7=>({..._0x576af7})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x5e64ee,_0x176617){const _0x374724=_0x176617['displayName']??void 0x0,_0x4c378a=_0x176617['email']??void 0x0,_0x5908b8=_0x176617['phoneNumber']??void 0x0,_0x235db6=_0x176617['photoURL']??void 0x0,_0x1d807d=_0x176617['tenantId']??void 0x0,_0x435fa0=_0x176617['_redirectEventId']??void 0x0,_0x3350e1=_0x176617['createdAt']??void 0x0,_0x39ace4=_0x176617['lastLoginAt']??void 0x0,{uid:_0xbdb25a,emailVerified:_0x33fae8,isAnonymous:_0x1b8b29,providerData:_0x25f8bb,stsTokenManager:_0x2c4ca0}=_0x176617;m(_0xbdb25a&&_0x2c4ca0,_0x5e64ee,'internal-error');const _0x37401b=et['fromJSON'](this['name'],_0x2c4ca0);m(typeof _0xbdb25a=='string',_0x5e64ee,'internal-error'),le(_0x374724,_0x5e64ee['name']),le(_0x4c378a,_0x5e64ee['name']),m(typeof _0x33fae8=='boolean',_0x5e64ee,'internal-error'),m(typeof _0x1b8b29=='boolean',_0x5e64ee,'internal-error'),le(_0x5908b8,_0x5e64ee['name']),le(_0x235db6,_0x5e64ee['name']),le(_0x1d807d,_0x5e64ee['name']),le(_0x435fa0,_0x5e64ee['name']),le(_0x3350e1,_0x5e64ee['name']),le(_0x39ace4,_0x5e64ee['name']);const _0x17496c=new j({'uid':_0xbdb25a,'auth':_0x5e64ee,'email':_0x4c378a,'emailVerified':_0x33fae8,'displayName':_0x374724,'isAnonymous':_0x1b8b29,'photoURL':_0x235db6,'phoneNumber':_0x5908b8,'tenantId':_0x1d807d,'stsTokenManager':_0x37401b,'createdAt':_0x3350e1,'lastLoginAt':_0x39ace4});return _0x25f8bb&&Array['isArray'](_0x25f8bb)&&(_0x17496c['providerData']=_0x25f8bb['map'](_0x2f1723=>({..._0x2f1723}))),_0x435fa0&&(_0x17496c['_redirectEventId']=_0x435fa0),_0x17496c;}static async['_fromIdTokenResponse'](_0x10b3ff,_0x20ebdc,_0x5a15ef=!0x1){const _0x3b0f58=new et();_0x3b0f58['updateFromServerResponse'](_0x20ebdc);const _0x292c22=new j({'uid':_0x20ebdc['localId'],'auth':_0x10b3ff,'stsTokenManager':_0x3b0f58,'isAnonymous':_0x5a15ef});return await Nn(_0x292c22),_0x292c22;}static async['_fromGetAccountInfoResponse'](_0x24dc0e,_0x5af70b,_0x3f11fa){const _0x45d834=_0x5af70b['users'][0x0];m(_0x45d834['localId']!==void 0x0,'internal-error');const _0x46b0b1=_0x45d834['providerUserInfo']!==void 0x0?Sa(_0x45d834['providerUserInfo']):[],_0x3c25f4=!(_0x45d834['email']&&_0x45d834['passwordHash'])&&!(_0x46b0b1!=null&&_0x46b0b1['length']),_0x17bcae=new et();_0x17bcae['updateFromIdToken'](_0x3f11fa);const _0x5a9a89=new j({'uid':_0x45d834['localId'],'auth':_0x24dc0e,'stsTokenManager':_0x17bcae,'isAnonymous':_0x3c25f4}),_0x95fc49={'uid':_0x45d834['localId'],'displayName':_0x45d834['displayName']||null,'photoURL':_0x45d834['photoUrl']||null,'email':_0x45d834['email']||null,'emailVerified':_0x45d834['emailVerified']||!0x1,'phoneNumber':_0x45d834['phoneNumber']||null,'tenantId':_0x45d834['tenantId']||null,'providerData':_0x46b0b1,'metadata':new Li(_0x45d834['createdAt'],_0x45d834['lastLoginAt']),'isAnonymous':!(_0x45d834['email']&&_0x45d834['passwordHash'])&&!(_0x46b0b1!=null&&_0x46b0b1['length'])};return Object['assign'](_0x5a9a89,_0x95fc49),_0x5a9a89;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x2e3caa){ce(_0x2e3caa instanceof Function,'Expected\x20a\x20class\x20definition');let _0x2d2125=Tr['get'](_0x2e3caa);return _0x2d2125?(ce(_0x2d2125 instanceof _0x2e3caa,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x2d2125):(_0x2d2125=new _0x2e3caa(),Tr['set'](_0x2e3caa,_0x2d2125),_0x2d2125);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x31b60d,_0x2a7918){this['storage'][_0x31b60d]=_0x2a7918;}async['_get'](_0x3635ac){const _0x53c1d9=this['storage'][_0x3635ac];return _0x53c1d9===void 0x0?null:_0x53c1d9;}async['_remove'](_0x16847e){delete this['storage'][_0x16847e];}['_addListener'](_0x5b5f71,_0x2405cd){}['_removeListener'](_0x3d8bba,_0xf1c037){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x105991,_0x1e723d,_0x10a890){return'firebase:'+_0x105991+':'+_0x1e723d+':'+_0x10a890;}class tt{constructor(_0x48c545,_0x4f7515,_0x3bce3c){this['persistence']=_0x48c545,this['auth']=_0x4f7515,this['userKey']=_0x3bce3c;const {config:_0x2b07d3,name:_0x5dd851}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x2b07d3['apiKey'],_0x5dd851),this['fullPersistenceKey']=ln('persistence',_0x2b07d3['apiKey'],_0x5dd851),this['boundEventHandler']=_0x4f7515['_onStorageEvent']['bind'](_0x4f7515),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x1d4a11){return this['persistence']['_set'](this['fullUserKey'],_0x1d4a11['toJSON']());}async['getCurrentUser'](){const _0x5c69a1=await this['persistence']['_get'](this['fullUserKey']);if(!_0x5c69a1)return null;if(typeof _0x5c69a1=='string'){const _0x59583e=await Pn(this['auth'],{'idToken':_0x5c69a1})['catch'](()=>{});return _0x59583e?j['_fromGetAccountInfoResponse'](this['auth'],_0x59583e,_0x5c69a1):null;}return j['_fromJSON'](this['auth'],_0x5c69a1);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x1fe130){if(this['persistence']===_0x1fe130)return;const _0x1d6ccd=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x1fe130,_0x1d6ccd)return this['setCurrentUser'](_0x1d6ccd);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x1e4f35,_0x4637c8,_0x5e5686='authUser'){if(!_0x4637c8['length'])return new tt(ie(Sr),_0x1e4f35,_0x5e5686);const _0x2235cc=(await Promise['all'](_0x4637c8['map'](async _0x1fa0f5=>{if(await _0x1fa0f5['_isAvailable']())return _0x1fa0f5;})))['filter'](_0x1fd665=>_0x1fd665);let _0x90d69a=_0x2235cc[0x0]||ie(Sr);const _0x2e0d28=ln(_0x5e5686,_0x1e4f35['config']['apiKey'],_0x1e4f35['name']);let _0x3b710d=null;for(const _0x2a0022 of _0x4637c8)try{const _0x13fa16=await _0x2a0022['_get'](_0x2e0d28);if(_0x13fa16){let _0x204ed8;if(typeof _0x13fa16=='string'){const _0x172de0=await Pn(_0x1e4f35,{'idToken':_0x13fa16})['catch'](()=>{});if(!_0x172de0)break;_0x204ed8=await j['_fromGetAccountInfoResponse'](_0x1e4f35,_0x172de0,_0x13fa16);}else _0x204ed8=j['_fromJSON'](_0x1e4f35,_0x13fa16);_0x2a0022!==_0x90d69a&&(_0x3b710d=_0x204ed8),_0x90d69a=_0x2a0022;break;}}catch{}const _0x4943f7=_0x2235cc['filter'](_0x3512f6=>_0x3512f6['_shouldAllowMigration']);return!_0x90d69a['_shouldAllowMigration']||!_0x4943f7['length']?new tt(_0x90d69a,_0x1e4f35,_0x5e5686):(_0x90d69a=_0x4943f7[0x0],_0x3b710d&&await _0x90d69a['_set'](_0x2e0d28,_0x3b710d['toJSON']()),await Promise['all'](_0x4637c8['map'](async _0x28b86f=>{if(_0x28b86f!==_0x90d69a)try{await _0x28b86f['_remove'](_0x2e0d28);}catch{}})),new tt(_0x90d69a,_0x1e4f35,_0x5e5686));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x2416c6){const _0x362930=_0x2416c6['toLowerCase']();if(_0x362930['includes']('opera/')||_0x362930['includes']('opr/')||_0x362930['includes']('opios/'))return'Opera';if(Pa(_0x362930))return'IEMobile';if(_0x362930['includes']('msie')||_0x362930['includes']('trident/'))return'IE';if(_0x362930['includes']('edge/'))return'Edge';if(Ra(_0x362930))return'Firefox';if(_0x362930['includes']('silk/'))return'Silk';if(Oa(_0x362930))return'Blackberry';if(Da(_0x362930))return'Webos';if(Aa(_0x362930))return'Safari';if((_0x362930['includes']('chrome/')||ka(_0x362930))&&!_0x362930['includes']('edge/'))return'Chrome';if(Na(_0x362930))return'Android';{const _0x1941a9=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0xa93549=_0x2416c6['match'](_0x1941a9);if((_0xa93549==null?void 0x0:_0xa93549['length'])===0x2)return _0xa93549[0x1];}return'Other';}function Ra(_0x325fae=W()){return/firefox\//i['test'](_0x325fae);}function Aa(_0x146581=W()){const _0x2d931c=_0x146581['toLowerCase']();return _0x2d931c['includes']('safari/')&&!_0x2d931c['includes']('chrome/')&&!_0x2d931c['includes']('crios/')&&!_0x2d931c['includes']('android');}function ka(_0x52cbae=W()){return/crios\//i['test'](_0x52cbae);}function Pa(_0x2d7a38=W()){return/iemobile/i['test'](_0x2d7a38);}function Na(_0x1010a1=W()){return/android/i['test'](_0x1010a1);}function Oa(_0x22f68c=W()){return/blackberry/i['test'](_0x22f68c);}function Da(_0x57b328=W()){return/webos/i['test'](_0x57b328);}function Ss(_0x1bf914=W()){return/iphone|ipad|ipod/i['test'](_0x1bf914)||/macintosh/i['test'](_0x1bf914)&&/mobile/i['test'](_0x1bf914);}function Rf(_0x2855a0=W()){var _0x1f52c7;return Ss(_0x2855a0)&&!!((_0x1f52c7=window['navigator'])!=null&&_0x1f52c7['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x41ad5f=W()){return Ss(_0x41ad5f)||Na(_0x41ad5f)||Da(_0x41ad5f)||Oa(_0x41ad5f)||/windows phone/i['test'](_0x41ad5f)||Pa(_0x41ad5f);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x3e2e74,_0x34fc2a=[]){let _0x2b34d1;switch(_0x3e2e74){case'Browser':_0x2b34d1=br(W());break;case'Worker':_0x2b34d1=br(W())+'-'+_0x3e2e74;break;default:_0x2b34d1=_0x3e2e74;}const _0x2954e8=_0x34fc2a['length']?_0x34fc2a['join'](','):'FirebaseCore-web';return _0x2b34d1+'/JsCore/'+dt+'/'+_0x2954e8;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x27e5e3){this['auth']=_0x27e5e3,this['queue']=[];}['pushCallback'](_0x3839c6,_0x3a3290){const _0x4aa6ee=_0x3028f6=>new Promise((_0x16ebd5,_0x96a4fa)=>{try{const _0x4db9c9=_0x3839c6(_0x3028f6);_0x16ebd5(_0x4db9c9);}catch(_0x2a7bcb){_0x96a4fa(_0x2a7bcb);}});_0x4aa6ee['onAbort']=_0x3a3290,this['queue']['push'](_0x4aa6ee);const _0x1d72a7=this['queue']['length']-0x1;return()=>{this['queue'][_0x1d72a7]=()=>Promise['resolve']();};}async['runMiddleware'](_0x1f65ce){if(this['auth']['currentUser']===_0x1f65ce)return;const _0x3e339b=[];try{for(const _0x1593fe of this['queue'])await _0x1593fe(_0x1f65ce),_0x1593fe['onAbort']&&_0x3e339b['push'](_0x1593fe['onAbort']);}catch(_0x44b86a){_0x3e339b['reverse']();for(const _0x1133c8 of _0x3e339b)try{_0x1133c8();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x44b86a==null?void 0x0:_0x44b86a['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x5b9c9e,_0x394cff={}){return Pe(_0x5b9c9e,'GET','/v2/passwordPolicy',ke(_0x5b9c9e,_0x394cff));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x2e28ad){var _0x128643;const _0x2c5a7a=_0x2e28ad['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x2c5a7a['minPasswordLength']??Nf,_0x2c5a7a['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x2c5a7a['maxPasswordLength']),_0x2c5a7a['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x2c5a7a['containsLowercaseCharacter']),_0x2c5a7a['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x2c5a7a['containsUppercaseCharacter']),_0x2c5a7a['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x2c5a7a['containsNumericCharacter']),_0x2c5a7a['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x2c5a7a['containsNonAlphanumericCharacter']),this['enforcementState']=_0x2e28ad['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x128643=_0x2e28ad['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x128643['join'](''))??'',this['forceUpgradeOnSignin']=_0x2e28ad['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x2e28ad['schemaVersion'];}['validatePassword'](_0x36c68c){const _0x212259={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x36c68c,_0x212259),this['validatePasswordCharacterOptions'](_0x36c68c,_0x212259),_0x212259['isValid']&&(_0x212259['isValid']=_0x212259['meetsMinPasswordLength']??!0x0),_0x212259['isValid']&&(_0x212259['isValid']=_0x212259['meetsMaxPasswordLength']??!0x0),_0x212259['isValid']&&(_0x212259['isValid']=_0x212259['containsLowercaseLetter']??!0x0),_0x212259['isValid']&&(_0x212259['isValid']=_0x212259['containsUppercaseLetter']??!0x0),_0x212259['isValid']&&(_0x212259['isValid']=_0x212259['containsNumericCharacter']??!0x0),_0x212259['isValid']&&(_0x212259['isValid']=_0x212259['containsNonAlphanumericCharacter']??!0x0),_0x212259;}['validatePasswordLengthOptions'](_0x31fad6,_0x21d7a6){const _0x31d782=this['customStrengthOptions']['minPasswordLength'],_0x340675=this['customStrengthOptions']['maxPasswordLength'];_0x31d782&&(_0x21d7a6['meetsMinPasswordLength']=_0x31fad6['length']>=_0x31d782),_0x340675&&(_0x21d7a6['meetsMaxPasswordLength']=_0x31fad6['length']<=_0x340675);}['validatePasswordCharacterOptions'](_0x1419a6,_0x50f9e9){this['updatePasswordCharacterOptionsStatuses'](_0x50f9e9,!0x1,!0x1,!0x1,!0x1);let _0x59df9d;for(let _0x3138ef=0x0;_0x3138ef<_0x1419a6['length'];_0x3138ef++)_0x59df9d=_0x1419a6['charAt'](_0x3138ef),this['updatePasswordCharacterOptionsStatuses'](_0x50f9e9,_0x59df9d>='a'&&_0x59df9d<='z',_0x59df9d>='A'&&_0x59df9d<='Z',_0x59df9d>='0'&&_0x59df9d<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x59df9d));}['updatePasswordCharacterOptionsStatuses'](_0x51a251,_0x471857,_0x287868,_0x5011fd,_0x275e11){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x51a251['containsLowercaseLetter']||(_0x51a251['containsLowercaseLetter']=_0x471857)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x51a251['containsUppercaseLetter']||(_0x51a251['containsUppercaseLetter']=_0x287868)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x51a251['containsNumericCharacter']||(_0x51a251['containsNumericCharacter']=_0x5011fd)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x51a251['containsNonAlphanumericCharacter']||(_0x51a251['containsNonAlphanumericCharacter']=_0x275e11));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x546c7e,_0x468da6,_0x73738e,_0x344bc6){this['app']=_0x546c7e,this['heartbeatServiceProvider']=_0x468da6,this['appCheckServiceProvider']=_0x73738e,this['config']=_0x344bc6,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x546c7e['name'],this['clientVersion']=_0x344bc6['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x519f1c=>this['_resolvePersistenceManagerAvailable']=_0x519f1c);}['_initializeWithPersistence'](_0x4b8cc4,_0x2bb3d2){return _0x2bb3d2&&(this['_popupRedirectResolver']=ie(_0x2bb3d2)),this['_initializationPromise']=this['queue'](async()=>{var _0x42cff8,_0x39ff0d,_0x204f10;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x4b8cc4),(_0x42cff8=this['_resolvePersistenceManagerAvailable'])==null||_0x42cff8['call'](this),!this['_deleted'])){if((_0x39ff0d=this['_popupRedirectResolver'])!=null&&_0x39ff0d['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x2bb3d2),this['lastNotifiedUid']=((_0x204f10=this['currentUser'])==null?void 0x0:_0x204f10['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x3d2f0b=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x3d2f0b)){if(this['currentUser']&&_0x3d2f0b&&this['currentUser']['uid']===_0x3d2f0b['uid']){this['_currentUser']['_assign'](_0x3d2f0b),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x3d2f0b,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x2f5c32){try{const _0x410866=await Pn(this,{'idToken':_0x2f5c32}),_0x3b5a8f=await j['_fromGetAccountInfoResponse'](this,_0x410866,_0x2f5c32);await this['directlySetCurrentUser'](_0x3b5a8f);}catch(_0x2f0b91){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x2f0b91),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x357644){var _0xde77d9;if($(this['app'])){const _0x524570=this['app']['settings']['authIdToken'];return _0x524570?new Promise(_0x4ca620=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x524570)['then'](_0x4ca620,_0x4ca620));}):this['directlySetCurrentUser'](null);}const _0x826536=await this['assertedPersistence']['getCurrentUser']();let _0x565c50=_0x826536,_0x420b78=!0x1;if(_0x357644&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x317fb9=(_0xde77d9=this['redirectUser'])==null?void 0x0:_0xde77d9['_redirectEventId'],_0x5ea334=_0x565c50==null?void 0x0:_0x565c50['_redirectEventId'],_0x32608e=await this['tryRedirectSignIn'](_0x357644);(!_0x317fb9||_0x317fb9===_0x5ea334)&&(_0x32608e!=null&&_0x32608e['user'])&&(_0x565c50=_0x32608e['user'],_0x420b78=!0x0);}if(!_0x565c50)return this['directlySetCurrentUser'](null);if(!_0x565c50['_redirectEventId']){if(_0x420b78)try{await this['beforeStateQueue']['runMiddleware'](_0x565c50);}catch(_0x1f9387){_0x565c50=_0x826536,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x1f9387));}return _0x565c50?this['reloadAndSetCurrentUserOrClear'](_0x565c50):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x565c50['_redirectEventId']?this['directlySetCurrentUser'](_0x565c50):this['reloadAndSetCurrentUserOrClear'](_0x565c50);}async['tryRedirectSignIn'](_0x4712fc){let _0x4ca0e1=null;try{_0x4ca0e1=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x4712fc,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x4ca0e1;}async['reloadAndSetCurrentUserOrClear'](_0x196aaa){try{await Nn(_0x196aaa);}catch(_0x248b64){if((_0x248b64==null?void 0x0:_0x248b64['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x196aaa);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x3ed031){if($(this['app']))return Promise['reject'](re(this));const _0x20979a=_0x3ed031?P(_0x3ed031):null;return _0x20979a&&m(_0x20979a['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x20979a&&_0x20979a['_clone'](this));}async['_updateCurrentUser'](_0x232fcf,_0x5019fc=!0x1){if(!this['_deleted'])return _0x232fcf&&m(this['tenantId']===_0x232fcf['tenantId'],this,'tenant-id-mismatch'),_0x5019fc||await this['beforeStateQueue']['runMiddleware'](_0x232fcf),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x232fcf),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x17a65d){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x17a65d));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x8eefad){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x59acdb=this['_getPasswordPolicyInternal']();return _0x59acdb['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x59acdb['validatePassword'](_0x8eefad);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x39d896=await Pf(this),_0x1994aa=new Of(_0x39d896);this['tenantId']===null?this['_projectPasswordPolicy']=_0x1994aa:this['_tenantPasswordPolicies'][this['tenantId']]=_0x1994aa;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0xc507ed){this['_errorFactory']=new Gt('auth','Firebase',_0xc507ed());}['onAuthStateChanged'](_0x21994d,_0x3acad4,_0x325bbb){return this['registerStateListener'](this['authStateSubscription'],_0x21994d,_0x3acad4,_0x325bbb);}['beforeAuthStateChanged'](_0x26d9da,_0x397126){return this['beforeStateQueue']['pushCallback'](_0x26d9da,_0x397126);}['onIdTokenChanged'](_0x515af8,_0x1f686c,_0x399cb0){return this['registerStateListener'](this['idTokenSubscription'],_0x515af8,_0x1f686c,_0x399cb0);}['authStateReady'](){return new Promise((_0x42b5e7,_0x54ce68)=>{if(this['currentUser'])_0x42b5e7();else{const _0x4937ac=this['onAuthStateChanged'](()=>{_0x4937ac(),_0x42b5e7();},_0x54ce68);}});}async['revokeAccessToken'](_0x9a6f0c){if(this['currentUser']){const _0x194002=await this['currentUser']['getIdToken'](),_0x7b2268={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x9a6f0c,'idToken':_0x194002};this['tenantId']!=null&&(_0x7b2268['tenantId']=this['tenantId']),await bf(this,_0x7b2268);}}['toJSON'](){var _0x69359f;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x69359f=this['_currentUser'])==null?void 0x0:_0x69359f['toJSON']()};}async['_setRedirectUser'](_0x5e57ea,_0x416721){const _0x46e65c=await this['getOrInitRedirectPersistenceManager'](_0x416721);return _0x5e57ea===null?_0x46e65c['removeCurrentUser']():_0x46e65c['setCurrentUser'](_0x5e57ea);}async['getOrInitRedirectPersistenceManager'](_0x3a0efa){if(!this['redirectPersistenceManager']){const _0x174dba=_0x3a0efa&&ie(_0x3a0efa)||this['_popupRedirectResolver'];m(_0x174dba,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x174dba['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x24952c){var _0x5d87de,_0x5072ca;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x5d87de=this['_currentUser'])==null?void 0x0:_0x5d87de['_redirectEventId'])===_0x24952c?this['_currentUser']:((_0x5072ca=this['redirectUser'])==null?void 0x0:_0x5072ca['_redirectEventId'])===_0x24952c?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x271183){if(_0x271183===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x271183));}['_notifyListenersIfCurrent'](_0x376e40){_0x376e40===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x5e3977;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0xff1e80=((_0x5e3977=this['currentUser'])==null?void 0x0:_0x5e3977['uid'])??null;this['lastNotifiedUid']!==_0xff1e80&&(this['lastNotifiedUid']=_0xff1e80,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x214dad,_0x7b276,_0x526d7c,_0x57d0fc){if(this['_deleted'])return()=>{};const _0x247dfe=typeof _0x7b276=='function'?_0x7b276:_0x7b276['next']['bind'](_0x7b276);let _0x3a629c=!0x1;const _0x118292=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x118292,this,'internal-error'),_0x118292['then'](()=>{_0x3a629c||_0x247dfe(this['currentUser']);}),typeof _0x7b276=='function'){const _0x144c88=_0x214dad['addObserver'](_0x7b276,_0x526d7c,_0x57d0fc);return()=>{_0x3a629c=!0x0,_0x144c88();};}else{const _0x2bebcc=_0x214dad['addObserver'](_0x7b276);return()=>{_0x3a629c=!0x0,_0x2bebcc();};}}async['directlySetCurrentUser'](_0x4bb7c7){this['currentUser']&&this['currentUser']!==_0x4bb7c7&&this['_currentUser']['_stopProactiveRefresh'](),_0x4bb7c7&&this['isProactiveRefreshEnabled']&&_0x4bb7c7['_startProactiveRefresh'](),this['currentUser']=_0x4bb7c7,_0x4bb7c7?await this['assertedPersistence']['setCurrentUser'](_0x4bb7c7):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x12bd3c){return this['operations']=this['operations']['then'](_0x12bd3c,_0x12bd3c),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x22f79e){!_0x22f79e||this['frameworks']['includes'](_0x22f79e)||(this['frameworks']['push'](_0x22f79e),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x1ee9f2;const _0x56126c={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x56126c['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x43d6a3=await((_0x1ee9f2=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x1ee9f2['getHeartbeatsHeader']());_0x43d6a3&&(_0x56126c['X-Firebase-Client']=_0x43d6a3);const _0x2a25ab=await this['_getAppCheckToken']();return _0x2a25ab&&(_0x56126c['X-Firebase-AppCheck']=_0x2a25ab),_0x56126c;}async['_getAppCheckToken'](){var _0x445764;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x303910=await((_0x445764=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x445764['getToken']());return _0x303910!=null&&_0x303910['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x303910['error']),_0x303910==null?void 0x0:_0x303910['token'];}}function Ke(_0x3337a5){return P(_0x3337a5);}class Rr{constructor(_0xb5136c){this['auth']=_0xb5136c,this['observer']=null,this['addObserver']=Tc(_0x57a808=>this['observer']=_0x57a808);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x5d8677){Jn=_0x5d8677;}function xa(_0x288928){return Jn['loadJS'](_0x288928);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x3a0cba){return'__'+_0x3a0cba+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x541f8a){_0x541f8a();}['execute'](_0x5c4a2e,_0x970ee6){return Promise['resolve']('token');}['render'](_0x416ccf,_0x2c7ca5){return'';}}class Wf{['ready'](_0x3fa129){_0x3fa129();}['execute'](_0xbbb0a4,_0x3ba01c){return Promise['resolve']('token');}['render'](_0x3c448a,_0x41ef1e){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x18e0c6){this['type']=Bf,this['auth']=Ke(_0x18e0c6);}async['verify'](_0x56014b='verify',_0x429f18=!0x1){async function _0x22524d(_0x418efa){if(!_0x429f18){if(_0x418efa['tenantId']==null&&_0x418efa['_agentRecaptchaConfig']!=null)return _0x418efa['_agentRecaptchaConfig']['siteKey'];if(_0x418efa['tenantId']!=null&&_0x418efa['_tenantRecaptchaConfigs'][_0x418efa['tenantId']]!==void 0x0)return _0x418efa['_tenantRecaptchaConfigs'][_0x418efa['tenantId']]['siteKey'];}return new Promise(async(_0x38b753,_0x44d207)=>{yf(_0x418efa,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x4d8eee=>{if(_0x4d8eee['recaptchaKey']===void 0x0)_0x44d207(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x2bf093=new mf(_0x4d8eee);return _0x418efa['tenantId']==null?_0x418efa['_agentRecaptchaConfig']=_0x2bf093:_0x418efa['_tenantRecaptchaConfigs'][_0x418efa['tenantId']]=_0x2bf093,_0x38b753(_0x2bf093['siteKey']);}})['catch'](_0x146c9e=>{_0x44d207(_0x146c9e);});});}function _0x1d2897(_0x292ac4,_0x412778,_0x26cc9d){const _0x3ccf98=window['grecaptcha'];wr(_0x3ccf98)?_0x3ccf98['enterprise']['ready'](()=>{_0x3ccf98['enterprise']['execute'](_0x292ac4,{'action':_0x56014b})['then'](_0x4b41a4=>{_0x412778(_0x4b41a4);})['catch'](()=>{_0x412778(Fa);});}):_0x26cc9d(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x27d5ac,_0x21bd81)=>{_0x22524d(this['auth'])['then'](async _0xb941e9=>{if(!_0x429f18&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x1d2897(_0xb941e9,_0x27d5ac,_0x21bd81);else{if(typeof window>'u'){_0x21bd81(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x50ecc7=Lf();_0x50ecc7['length']!==0x0&&(_0x50ecc7+=_0xb941e9+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x38c0c1;(_0x38c0c1=he['scriptInjectionDeferred'])==null||_0x38c0c1['resolve']();},xa(_0x50ecc7)['then'](()=>{var _0x42a751;return(_0x42a751=he['scriptInjectionDeferred'])==null?void 0x0:_0x42a751['promise'];})['then'](()=>{_0x1d2897(_0xb941e9,_0x27d5ac,_0x21bd81);})['catch'](_0x429feb=>{_0x21bd81(_0x429feb);});}})['catch'](_0x3ea87f=>{_0x21bd81(_0x3ea87f);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x4ec66c,_0x7a4b2a,_0x45e5f2,_0x18b835=!0x1,_0x2f551a=!0x1){const _0x5a1ccb=new he(_0x4ec66c);let _0x2a3a53;if(_0x2f551a)_0x2a3a53=Fa;else try{_0x2a3a53=await _0x5a1ccb['verify'](_0x45e5f2);}catch{_0x2a3a53=await _0x5a1ccb['verify'](_0x45e5f2,!0x0);}const _0x56d331={..._0x7a4b2a};if(_0x45e5f2==='mfaSmsEnrollment'||_0x45e5f2==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x56d331){const _0xa0f120=_0x56d331['phoneEnrollmentInfo']['phoneNumber'],_0x29a582=_0x56d331['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x56d331,{'phoneEnrollmentInfo':{'phoneNumber':_0xa0f120,'recaptchaToken':_0x29a582,'captchaResponse':_0x2a3a53,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x56d331){const _0x544927=_0x56d331['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x56d331,{'phoneSignInInfo':{'recaptchaToken':_0x544927,'captchaResponse':_0x2a3a53,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x56d331;}return _0x18b835?Object['assign'](_0x56d331,{'captchaResp':_0x2a3a53}):Object['assign'](_0x56d331,{'captchaResponse':_0x2a3a53}),Object['assign'](_0x56d331,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x56d331,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x56d331;}async function xi(_0x4dbe0f,_0x3e9a4b,_0x443169,_0x14d5a1,_0x1675cd){var _0xb31ee8;if((_0xb31ee8=_0x4dbe0f['_getRecaptchaConfig']())!=null&&_0xb31ee8['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x56e6cd=await kr(_0x4dbe0f,_0x3e9a4b,_0x443169,_0x443169==='getOobCode');return _0x14d5a1(_0x4dbe0f,_0x56e6cd);}else return _0x14d5a1(_0x4dbe0f,_0x3e9a4b)['catch'](async _0x3342f9=>{if(_0x3342f9['code']==='auth/missing-recaptcha-token'){console['log'](_0x443169+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x485543=await kr(_0x4dbe0f,_0x3e9a4b,_0x443169,_0x443169==='getOobCode');return _0x14d5a1(_0x4dbe0f,_0x485543);}else return Promise['reject'](_0x3342f9);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x4b5ec5,_0x5d85ee){const _0x3441b4=Hi(_0x4b5ec5,'auth');if(_0x3441b4['isInitialized']()){const _0x9a8477=_0x3441b4['getImmediate'](),_0x1a6868=_0x3441b4['getOptions']();if(xe(_0x1a6868,_0x5d85ee??{}))return _0x9a8477;Y(_0x9a8477,'already-initialized');}return _0x3441b4['initialize']({'options':_0x5d85ee});}function Hf(_0x114177,_0x25f60f){const _0x19fa3b=(_0x25f60f==null?void 0x0:_0x25f60f['persistence'])||[],_0x262a91=(Array['isArray'](_0x19fa3b)?_0x19fa3b:[_0x19fa3b])['map'](ie);_0x25f60f!=null&&_0x25f60f['errorMap']&&_0x114177['_updateErrorMap'](_0x25f60f['errorMap']),_0x114177['_initializeWithPersistence'](_0x262a91,_0x25f60f==null?void 0x0:_0x25f60f['popupRedirectResolver']);}function $f(_0x35b522,_0x2ef697,_0x507c95){const _0x42c54f=Ke(_0x35b522);m(/^https?:\/\//['test'](_0x2ef697),_0x42c54f,'invalid-emulator-scheme');const _0x217b9c=!0x1,_0x23526e=Ua(_0x2ef697),{host:_0x1abf5f,port:_0x5a293a}=Gf(_0x2ef697),_0x569f3a=_0x5a293a===null?'':':'+_0x5a293a,_0x11dedf={'url':_0x23526e+'//'+_0x1abf5f+_0x569f3a+'/'},_0x3b9de8=Object['freeze']({'host':_0x1abf5f,'port':_0x5a293a,'protocol':_0x23526e['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x217b9c})});if(!_0x42c54f['_canInitEmulator']){m(_0x42c54f['config']['emulator']&&_0x42c54f['emulatorConfig'],_0x42c54f,'emulator-config-failed'),m(xe(_0x11dedf,_0x42c54f['config']['emulator'])&&xe(_0x3b9de8,_0x42c54f['emulatorConfig']),_0x42c54f,'emulator-config-failed');return;}_0x42c54f['config']['emulator']=_0x11dedf,_0x42c54f['emulatorConfig']=_0x3b9de8,_0x42c54f['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x1abf5f)?Qr(_0x23526e+'//'+_0x1abf5f+_0x569f3a):qf();}function Ua(_0x419cfe){const _0x57c992=_0x419cfe['indexOf'](':');return _0x57c992<0x0?'':_0x419cfe['substr'](0x0,_0x57c992+0x1);}function Gf(_0x350216){const _0x576a68=Ua(_0x350216),_0xc323b6=/(\/\/)?([^?#/]+)/['exec'](_0x350216['substr'](_0x576a68['length']));if(!_0xc323b6)return{'host':'','port':null};const _0x40c9e6=_0xc323b6[0x2]['split']('@')['pop']()||'',_0x2a329e=/^(\[[^\]]+\])(:|$)/['exec'](_0x40c9e6);if(_0x2a329e){const _0x4f045a=_0x2a329e[0x1];return{'host':_0x4f045a,'port':Pr(_0x40c9e6['substr'](_0x4f045a['length']+0x1))};}else{const [_0x3a76b2,_0x3c9078]=_0x40c9e6['split'](':');return{'host':_0x3a76b2,'port':Pr(_0x3c9078)};}}function Pr(_0x3a7ad3){if(!_0x3a7ad3)return null;const _0x32cc98=Number(_0x3a7ad3);return isNaN(_0x32cc98)?null:_0x32cc98;}function qf(){function _0x136dc2(){const _0x24b31b=document['createElement']('p'),_0x49d1de=_0x24b31b['style'];_0x24b31b['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x49d1de['position']='fixed',_0x49d1de['width']='100%',_0x49d1de['backgroundColor']='#ffffff',_0x49d1de['border']='.1em\x20solid\x20#000000',_0x49d1de['color']='#b50000',_0x49d1de['bottom']='0px',_0x49d1de['left']='0px',_0x49d1de['margin']='0px',_0x49d1de['zIndex']='10000',_0x49d1de['textAlign']='center',_0x24b31b['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x24b31b);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x136dc2):_0x136dc2());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x202150,_0x3b1512){this['providerId']=_0x202150,this['signInMethod']=_0x3b1512;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x42d57a){return ne('not\x20implemented');}['_linkToIdToken'](_0x1b9233,_0x2399d9){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x347fac){return ne('not\x20implemented');}}async function zf(_0x4e332f,_0x1c2add){return Pe(_0x4e332f,'POST','/v1/accounts:signUp',_0x1c2add);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x14c9e4,_0xd73de6){return en(_0x14c9e4,'POST','/v1/accounts:signInWithPassword',ke(_0x14c9e4,_0xd73de6));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x17ea24,_0x2e94c0){return en(_0x17ea24,'POST','/v1/accounts:signInWithEmailLink',ke(_0x17ea24,_0x2e94c0));}async function Yf(_0x2d27a0,_0x3ca077){return en(_0x2d27a0,'POST','/v1/accounts:signInWithEmailLink',ke(_0x2d27a0,_0x3ca077));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x51a89f,_0x134761,_0x4c03b3,_0x10d064=null){super('password',_0x4c03b3),this['_email']=_0x51a89f,this['_password']=_0x134761,this['_tenantId']=_0x10d064;}static['_fromEmailAndPassword'](_0x1a344e,_0x2886ec){return new $t(_0x1a344e,_0x2886ec,'password');}static['_fromEmailAndCode'](_0x2bf008,_0x52afe5,_0x10bbff=null){return new $t(_0x2bf008,_0x52afe5,'emailLink',_0x10bbff);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x4a258b){const _0x445303=typeof _0x4a258b=='string'?JSON['parse'](_0x4a258b):_0x4a258b;if(_0x445303!=null&&_0x445303['email']&&(_0x445303!=null&&_0x445303['password'])){if(_0x445303['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x445303['email'],_0x445303['password']);if(_0x445303['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x445303['email'],_0x445303['password'],_0x445303['tenantId']);}return null;}async['_getIdTokenResponse'](_0x278ab7){switch(this['signInMethod']){case'password':const _0x3ea452={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x278ab7,_0x3ea452,'signInWithPassword',jf);case'emailLink':return Kf(_0x278ab7,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x278ab7,'internal-error');}}async['_linkToIdToken'](_0x66591e,_0x284a3f){switch(this['signInMethod']){case'password':const _0xe2099b={'idToken':_0x284a3f,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x66591e,_0xe2099b,'signUpPassword',zf);case'emailLink':return Yf(_0x66591e,{'idToken':_0x284a3f,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x66591e,'internal-error');}}['_getReauthenticationResolver'](_0x11711e){return this['_getIdTokenResponse'](_0x11711e);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x2762b7,_0x55ffd7){return en(_0x2762b7,'POST','/v1/accounts:signInWithIdp',ke(_0x2762b7,_0x55ffd7));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x3e9f1d){const _0xc4a3a=new $e(_0x3e9f1d['providerId'],_0x3e9f1d['signInMethod']);return _0x3e9f1d['idToken']||_0x3e9f1d['accessToken']?(_0x3e9f1d['idToken']&&(_0xc4a3a['idToken']=_0x3e9f1d['idToken']),_0x3e9f1d['accessToken']&&(_0xc4a3a['accessToken']=_0x3e9f1d['accessToken']),_0x3e9f1d['nonce']&&!_0x3e9f1d['pendingToken']&&(_0xc4a3a['nonce']=_0x3e9f1d['nonce']),_0x3e9f1d['pendingToken']&&(_0xc4a3a['pendingToken']=_0x3e9f1d['pendingToken'])):_0x3e9f1d['oauthToken']&&_0x3e9f1d['oauthTokenSecret']?(_0xc4a3a['accessToken']=_0x3e9f1d['oauthToken'],_0xc4a3a['secret']=_0x3e9f1d['oauthTokenSecret']):Y('argument-error'),_0xc4a3a;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x594c5f){const _0x1546f9=typeof _0x594c5f=='string'?JSON['parse'](_0x594c5f):_0x594c5f,{providerId:_0x515ec6,signInMethod:_0x5e0318,..._0x48be0d}=_0x1546f9;if(!_0x515ec6||!_0x5e0318)return null;const _0x1b3dba=new $e(_0x515ec6,_0x5e0318);return _0x1b3dba['idToken']=_0x48be0d['idToken']||void 0x0,_0x1b3dba['accessToken']=_0x48be0d['accessToken']||void 0x0,_0x1b3dba['secret']=_0x48be0d['secret'],_0x1b3dba['nonce']=_0x48be0d['nonce'],_0x1b3dba['pendingToken']=_0x48be0d['pendingToken']||null,_0x1b3dba;}['_getIdTokenResponse'](_0x8be659){const _0x3888c5=this['buildRequest']();return nt(_0x8be659,_0x3888c5);}['_linkToIdToken'](_0x5e10cc,_0x1307f0){const _0x1f7f94=this['buildRequest']();return _0x1f7f94['idToken']=_0x1307f0,nt(_0x5e10cc,_0x1f7f94);}['_getReauthenticationResolver'](_0x48eaf1){const _0x181975=this['buildRequest']();return _0x181975['autoCreate']=!0x1,nt(_0x48eaf1,_0x181975);}['buildRequest'](){const _0x2c161b={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x2c161b['pendingToken']=this['pendingToken'];else{const _0x1c897f={};this['idToken']&&(_0x1c897f['id_token']=this['idToken']),this['accessToken']&&(_0x1c897f['access_token']=this['accessToken']),this['secret']&&(_0x1c897f['oauth_token_secret']=this['secret']),_0x1c897f['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x1c897f['nonce']=this['nonce']),_0x2c161b['postBody']=ut(_0x1c897f);}return _0x2c161b;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x396c08){switch(_0x396c08){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x25cac5){const _0x29bcbb=Ct(Tt(_0x25cac5))['link'],_0x52ba92=_0x29bcbb?Ct(Tt(_0x29bcbb))['deep_link_id']:null,_0x15ad82=Ct(Tt(_0x25cac5))['deep_link_id'];return(_0x15ad82?Ct(Tt(_0x15ad82))['link']:null)||_0x15ad82||_0x52ba92||_0x29bcbb||_0x25cac5;}class Rs{constructor(_0x32c66b){const _0x13b13b=Ct(Tt(_0x32c66b)),_0xc29924=_0x13b13b['apiKey']??null,_0x4f8553=_0x13b13b['oobCode']??null,_0x95dfe4=Jf(_0x13b13b['mode']??null);m(_0xc29924&&_0x4f8553&&_0x95dfe4,'argument-error'),this['apiKey']=_0xc29924,this['operation']=_0x95dfe4,this['code']=_0x4f8553,this['continueUrl']=_0x13b13b['continueUrl']??null,this['languageCode']=_0x13b13b['lang']??null,this['tenantId']=_0x13b13b['tenantId']??null;}static['parseLink'](_0x2d8cd0){const _0x38a914=Xf(_0x2d8cd0);try{return new Rs(_0x38a914);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x24c71b,_0x582a93){return $t['_fromEmailAndPassword'](_0x24c71b,_0x582a93);}static['credentialWithLink'](_0xf1178e,_0x3857c6){const _0x4e4c16=Rs['parseLink'](_0x3857c6);return m(_0x4e4c16,'argument-error'),$t['_fromEmailAndCode'](_0xf1178e,_0x4e4c16['code'],_0x4e4c16['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x29759c){this['providerId']=_0x29759c,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x274246){this['defaultLanguageCode']=_0x274246;}['setCustomParameters'](_0x696981){return this['customParameters']=_0x696981,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0xc607c6){return this['scopes']['includes'](_0xc607c6)||this['scopes']['push'](_0xc607c6),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x57dd13){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x57dd13});}static['credentialFromResult'](_0x5101ed){return ue['credentialFromTaggedObject'](_0x5101ed);}static['credentialFromError'](_0x5a937e){return ue['credentialFromTaggedObject'](_0x5a937e['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5525d7}){if(!_0x5525d7||!('oauthAccessToken'in _0x5525d7)||!_0x5525d7['oauthAccessToken'])return null;try{return ue['credential'](_0x5525d7['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x3096c3,_0x280425){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x3096c3,'accessToken':_0x280425});}static['credentialFromResult'](_0x373f68){return de['credentialFromTaggedObject'](_0x373f68);}static['credentialFromError'](_0x66b922){return de['credentialFromTaggedObject'](_0x66b922['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x57493d}){if(!_0x57493d)return null;const {oauthIdToken:_0x5aca88,oauthAccessToken:_0x5ca3e9}=_0x57493d;if(!_0x5aca88&&!_0x5ca3e9)return null;try{return de['credential'](_0x5aca88,_0x5ca3e9);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x516df2){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x516df2});}static['credentialFromResult'](_0x3b5961){return fe['credentialFromTaggedObject'](_0x3b5961);}static['credentialFromError'](_0xd4ee74){return fe['credentialFromTaggedObject'](_0xd4ee74['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1d2f39}){if(!_0x1d2f39||!('oauthAccessToken'in _0x1d2f39)||!_0x1d2f39['oauthAccessToken'])return null;try{return fe['credential'](_0x1d2f39['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x66782,_0x2b89be){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x66782,'oauthTokenSecret':_0x2b89be});}static['credentialFromResult'](_0x367dee){return pe['credentialFromTaggedObject'](_0x367dee);}static['credentialFromError'](_0x355156){return pe['credentialFromTaggedObject'](_0x355156['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0xb53510}){if(!_0xb53510)return null;const {oauthAccessToken:_0x5b2cda,oauthTokenSecret:_0x47254c}=_0xb53510;if(!_0x5b2cda||!_0x47254c)return null;try{return pe['credential'](_0x5b2cda,_0x47254c);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x5d3c2e,_0x204639){return en(_0x5d3c2e,'POST','/v1/accounts:signUp',ke(_0x5d3c2e,_0x204639));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x1f322c){this['user']=_0x1f322c['user'],this['providerId']=_0x1f322c['providerId'],this['_tokenResponse']=_0x1f322c['_tokenResponse'],this['operationType']=_0x1f322c['operationType'];}static async['_fromIdTokenResponse'](_0x5b3f1d,_0xb6738e,_0x31fa2a,_0x1f6037=!0x1){const _0x128b63=await j['_fromIdTokenResponse'](_0x5b3f1d,_0x31fa2a,_0x1f6037),_0x4d8c67=Nr(_0x31fa2a);return new Ge({'user':_0x128b63,'providerId':_0x4d8c67,'_tokenResponse':_0x31fa2a,'operationType':_0xb6738e});}static async['_forOperation'](_0x499413,_0x522d2a,_0x3ff7a0){await _0x499413['_updateTokensIfNecessary'](_0x3ff7a0,!0x0);const _0xe50112=Nr(_0x3ff7a0);return new Ge({'user':_0x499413,'providerId':_0xe50112,'_tokenResponse':_0x3ff7a0,'operationType':_0x522d2a});}}function Nr(_0x5150d6){return _0x5150d6['providerId']?_0x5150d6['providerId']:'phoneNumber'in _0x5150d6?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x4c8b65,_0x2e4052,_0x378409,_0x41719a){super(_0x2e4052['code'],_0x2e4052['message']),this['operationType']=_0x378409,this['user']=_0x41719a,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x4c8b65['name'],'tenantId':_0x4c8b65['tenantId']??void 0x0,'_serverResponse':_0x2e4052['customData']['_serverResponse'],'operationType':_0x378409};}static['_fromErrorAndOperation'](_0x163b9d,_0x3e11b2,_0x2f623d,_0x1860b8){return new On(_0x163b9d,_0x3e11b2,_0x2f623d,_0x1860b8);}}function Ba(_0x58093f,_0x52dfcc,_0x40dccd,_0x231e5d){return(_0x52dfcc==='reauthenticate'?_0x40dccd['_getReauthenticationResolver'](_0x58093f):_0x40dccd['_getIdTokenResponse'](_0x58093f))['catch'](_0x1ad2f1=>{throw _0x1ad2f1['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x58093f,_0x1ad2f1,_0x52dfcc,_0x231e5d):_0x1ad2f1;});}async function ep(_0x3b83bb,_0x1758ec,_0x2442fe=!0x1){const _0x18a4b6=await Ht(_0x3b83bb,_0x1758ec['_linkToIdToken'](_0x3b83bb['auth'],await _0x3b83bb['getIdToken']()),_0x2442fe);return Ge['_forOperation'](_0x3b83bb,'link',_0x18a4b6);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x130d31,_0x2feb87,_0x5422f0=!0x1){const {auth:_0xb90016}=_0x130d31;if($(_0xb90016['app']))return Promise['reject'](re(_0xb90016));const _0x22515a='reauthenticate';try{const _0x5ae653=await Ht(_0x130d31,Ba(_0xb90016,_0x22515a,_0x2feb87,_0x130d31),_0x5422f0);m(_0x5ae653['idToken'],_0xb90016,'internal-error');const _0x12b1f1=Ts(_0x5ae653['idToken']);m(_0x12b1f1,_0xb90016,'internal-error');const {sub:_0x138d89}=_0x12b1f1;return m(_0x130d31['uid']===_0x138d89,_0xb90016,'user-mismatch'),Ge['_forOperation'](_0x130d31,_0x22515a,_0x5ae653);}catch(_0x4c4993){throw(_0x4c4993==null?void 0x0:_0x4c4993['code'])==='auth/user-not-found'&&Y(_0xb90016,'user-mismatch'),_0x4c4993;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x23f7e2,_0x968190,_0x442c8d=!0x1){if($(_0x23f7e2['app']))return Promise['reject'](re(_0x23f7e2));const _0x14c804='signIn',_0xfabbc1=await Ba(_0x23f7e2,_0x14c804,_0x968190),_0x265c25=await Ge['_fromIdTokenResponse'](_0x23f7e2,_0x14c804,_0xfabbc1);return _0x442c8d||await _0x23f7e2['_updateCurrentUser'](_0x265c25['user']),_0x265c25;}async function np(_0x3c25b2,_0x4eb4a5){return Va(Ke(_0x3c25b2),_0x4eb4a5);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x420d19){const _0x3ca193=Ke(_0x420d19);_0x3ca193['_getPasswordPolicyInternal']()&&await _0x3ca193['_updatePasswordPolicy']();}async function L_(_0x230894,_0x46fbb4,_0x47df0e){if($(_0x230894['app']))return Promise['reject'](re(_0x230894));const _0x1000ee=Ke(_0x230894),_0x17a390=await xi(_0x1000ee,{'returnSecureToken':!0x0,'email':_0x46fbb4,'password':_0x47df0e,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x2c3945=>{throw _0x2c3945['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x230894),_0x2c3945;}),_0x1232d6=await Ge['_fromIdTokenResponse'](_0x1000ee,'signIn',_0x17a390);return await _0x1000ee['_updateCurrentUser'](_0x1232d6['user']),_0x1232d6;}function x_(_0xd8765d,_0x1fb12b,_0x92ebb8){return $(_0xd8765d['app'])?Promise['reject'](re(_0xd8765d)):np(P(_0xd8765d),yt['credential'](_0x1fb12b,_0x92ebb8))['catch'](async _0x218bf6=>{throw _0x218bf6['code']==='auth/password-does-not-meet-requirements'&&Ha(_0xd8765d),_0x218bf6;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x4e4fa7,_0x1b4708){return P(_0x4e4fa7)['setPersistence'](_0x1b4708);}function ip(_0x2dfc69,_0x25c4dc,_0x376efc,_0x2de0d2){return P(_0x2dfc69)['onIdTokenChanged'](_0x25c4dc,_0x376efc,_0x2de0d2);}function sp(_0x51ea37,_0x24241e,_0x492330){return P(_0x51ea37)['beforeAuthStateChanged'](_0x24241e,_0x492330);}function U_(_0x4c920b,_0x252922,_0x2716b3,_0x171e02){return P(_0x4c920b)['onAuthStateChanged'](_0x252922,_0x2716b3,_0x171e02);}function W_(_0x40227b){return P(_0x40227b)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x1a72c0,_0x3d4388){this['storageRetriever']=_0x1a72c0,this['type']=_0x3d4388;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x261989,_0x15391b){return this['storage']['setItem'](_0x261989,JSON['stringify'](_0x15391b)),Promise['resolve']();}['_get'](_0x183627){const _0x36dd6a=this['storage']['getItem'](_0x183627);return Promise['resolve'](_0x36dd6a?JSON['parse'](_0x36dd6a):null);}['_remove'](_0x4ee801){return this['storage']['removeItem'](_0x4ee801),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x45b42c,_0x2805f8)=>this['onStorageEvent'](_0x45b42c,_0x2805f8),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x6b4a10){for(const _0x2112ed of Object['keys'](this['listeners'])){const _0xda6e28=this['storage']['getItem'](_0x2112ed),_0x2c5d3d=this['localCache'][_0x2112ed];_0xda6e28!==_0x2c5d3d&&_0x6b4a10(_0x2112ed,_0x2c5d3d,_0xda6e28);}}['onStorageEvent'](_0xd1f84,_0x163288=!0x1){if(!_0xd1f84['key']){this['forAllChangedKeys']((_0x314659,_0xbeb9d7,_0x156882)=>{this['notifyListeners'](_0x314659,_0x156882);});return;}const _0x30acf2=_0xd1f84['key'];_0x163288?this['detachListener']():this['stopPolling']();const _0x354340=()=>{const _0x5c722a=this['storage']['getItem'](_0x30acf2);!_0x163288&&this['localCache'][_0x30acf2]===_0x5c722a||this['notifyListeners'](_0x30acf2,_0x5c722a);},_0x4a3137=this['storage']['getItem'](_0x30acf2);Af()&&_0x4a3137!==_0xd1f84['newValue']&&_0xd1f84['newValue']!==_0xd1f84['oldValue']?setTimeout(_0x354340,op):_0x354340();}['notifyListeners'](_0x193894,_0x462787){this['localCache'][_0x193894]=_0x462787;const _0x260660=this['listeners'][_0x193894];if(_0x260660){for(const _0x2146b5 of Array['from'](_0x260660))_0x2146b5(_0x462787&&JSON['parse'](_0x462787));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x19f527,_0x680210,_0x1a035b)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x19f527,'oldValue':_0x680210,'newValue':_0x1a035b}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x26c2dc,_0xc519ef){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x26c2dc]||(this['listeners'][_0x26c2dc]=new Set(),this['localCache'][_0x26c2dc]=this['storage']['getItem'](_0x26c2dc)),this['listeners'][_0x26c2dc]['add'](_0xc519ef);}['_removeListener'](_0x274729,_0x1ed8ec){this['listeners'][_0x274729]&&(this['listeners'][_0x274729]['delete'](_0x1ed8ec),this['listeners'][_0x274729]['size']===0x0&&delete this['listeners'][_0x274729]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x35f021,_0x541565){await super['_set'](_0x35f021,_0x541565),this['localCache'][_0x35f021]=JSON['stringify'](_0x541565);}async['_get'](_0x228218){const _0x53d2df=await super['_get'](_0x228218);return this['localCache'][_0x228218]=JSON['stringify'](_0x53d2df),_0x53d2df;}async['_remove'](_0x210a73){await super['_remove'](_0x210a73),delete this['localCache'][_0x210a73];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x1064b1,_0x45fd94){}['_removeListener'](_0x1ac6bb,_0x40cb52){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x26a720){return Promise['all'](_0x26a720['map'](async _0x321b0b=>{try{return{'fulfilled':!0x0,'value':await _0x321b0b};}catch(_0x1ea8fc){return{'fulfilled':!0x1,'reason':_0x1ea8fc};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x5cbeb2){this['eventTarget']=_0x5cbeb2,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x5b343f){const _0x2fd254=this['receivers']['find'](_0x5eff4f=>_0x5eff4f['isListeningto'](_0x5b343f));if(_0x2fd254)return _0x2fd254;const _0x3dccce=new Xn(_0x5b343f);return this['receivers']['push'](_0x3dccce),_0x3dccce;}['isListeningto'](_0x2bb360){return this['eventTarget']===_0x2bb360;}async['handleEvent'](_0x5cc899){const _0x45877d=_0x5cc899,{eventId:_0x2e1fce,eventType:_0x24cc38,data:_0x372854}=_0x45877d['data'],_0x398868=this['handlersMap'][_0x24cc38];if(!(_0x398868!=null&&_0x398868['size']))return;_0x45877d['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x2e1fce,'eventType':_0x24cc38});const _0x15dfaa=Array['from'](_0x398868)['map'](async _0xdebe7b=>_0xdebe7b(_0x45877d['origin'],_0x372854)),_0x3a40d4=await cp(_0x15dfaa);_0x45877d['ports'][0x0]['postMessage']({'status':'done','eventId':_0x2e1fce,'eventType':_0x24cc38,'response':_0x3a40d4});}['_subscribe'](_0x11693a,_0x229511){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x11693a]||(this['handlersMap'][_0x11693a]=new Set()),this['handlersMap'][_0x11693a]['add'](_0x229511);}['_unsubscribe'](_0x3c4557,_0x5e154c){this['handlersMap'][_0x3c4557]&&_0x5e154c&&this['handlersMap'][_0x3c4557]['delete'](_0x5e154c),(!_0x5e154c||this['handlersMap'][_0x3c4557]['size']===0x0)&&delete this['handlersMap'][_0x3c4557],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x39aaf0='',_0x2579ed=0xa){let _0x435448='';for(let _0x5cac22=0x0;_0x5cac22<_0x2579ed;_0x5cac22++)_0x435448+=Math['floor'](Math['random']()*0xa);return _0x39aaf0+_0x435448;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x1633b4){this['target']=_0x1633b4,this['handlers']=new Set();}['removeMessageHandler'](_0x42b6ae){_0x42b6ae['messageChannel']&&(_0x42b6ae['messageChannel']['port1']['removeEventListener']('message',_0x42b6ae['onMessage']),_0x42b6ae['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x42b6ae);}async['_send'](_0x4a53f3,_0x1c59c3,_0x29f81c=0x32){const _0x3c5983=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x3c5983)throw new Error('connection_unavailable');let _0x5e18ff,_0x1be7fd;return new Promise((_0x11fcfe,_0x53451a)=>{const _0x133fc3=As('',0x14);_0x3c5983['port1']['start']();const _0x56fda8=setTimeout(()=>{_0x53451a(new Error('unsupported_event'));},_0x29f81c);_0x1be7fd={'messageChannel':_0x3c5983,'onMessage'(_0x52e4dd){const _0xce30f1=_0x52e4dd;if(_0xce30f1['data']['eventId']===_0x133fc3)switch(_0xce30f1['data']['status']){case'ack':clearTimeout(_0x56fda8),_0x5e18ff=setTimeout(()=>{_0x53451a(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x5e18ff),_0x11fcfe(_0xce30f1['data']['response']);break;default:clearTimeout(_0x56fda8),clearTimeout(_0x5e18ff),_0x53451a(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x1be7fd),_0x3c5983['port1']['addEventListener']('message',_0x1be7fd['onMessage']),this['target']['postMessage']({'eventType':_0x4a53f3,'eventId':_0x133fc3,'data':_0x1c59c3},[_0x3c5983['port2']]);})['finally'](()=>{_0x1be7fd&&this['removeMessageHandler'](_0x1be7fd);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x5b7772){Z()['location']['href']=_0x5b7772;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x2dbe70;return((_0x2dbe70=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x2dbe70['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x1b59fa){this['request']=_0x1b59fa;}['toPromise'](){return new Promise((_0x465f1a,_0x320b4a)=>{this['request']['addEventListener']('success',()=>{_0x465f1a(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x320b4a(this['request']['error']);});});}}function Zn(_0x1e176a,_0x429c2c){return _0x1e176a['transaction']([Mn],_0x429c2c?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x30e277=indexedDB['deleteDatabase'](Ka);return new nn(_0x30e277)['toPromise']();}function Qa(){const _0x4ef047=indexedDB['open'](Ka,pp);return new Promise((_0x5612b4,_0x129878)=>{_0x4ef047['addEventListener']('error',()=>{_0x129878(_0x4ef047['error']);}),_0x4ef047['addEventListener']('upgradeneeded',()=>{const _0x198c1e=_0x4ef047['result'];try{_0x198c1e['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x1279bf){_0x129878(_0x1279bf);}}),_0x4ef047['addEventListener']('success',async()=>{const _0x2b8254=_0x4ef047['result'];_0x2b8254['objectStoreNames']['contains'](Mn)?_0x5612b4(_0x2b8254):(_0x2b8254['close'](),await _p(),_0x5612b4(await Qa()));});});}async function Or(_0x33c267,_0x172a45,_0x4382b9){const _0x11b0ca=Zn(_0x33c267,!0x0)['put']({[Ya]:_0x172a45,'value':_0x4382b9});return new nn(_0x11b0ca)['toPromise']();}async function gp(_0x39e6a3,_0x542362){const _0x13c966=Zn(_0x39e6a3,!0x1)['get'](_0x542362),_0x5dd7fc=await new nn(_0x13c966)['toPromise']();return _0x5dd7fc===void 0x0?null:_0x5dd7fc['value'];}function Dr(_0x23e4a6,_0x1103ac){const _0x1473c5=Zn(_0x23e4a6,!0x0)['delete'](_0x1103ac);return new nn(_0x1473c5)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x2c1aef){let _0x29bd06=0x0;for(;;)try{const _0x3ebad9=await this['_openDb']();return await _0x2c1aef(_0x3ebad9);}catch(_0x4e5297){if(_0x29bd06++>yp)throw _0x4e5297;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x5f4c9d,_0x29a683)=>({'keyProcessed':(await this['_poll']())['includes'](_0x29a683['key'])})),this['receiver']['_subscribe']('ping',async(_0x9eee61,_0x3c4866)=>['keyChanged']);}async['initializeSender'](){var _0x5d84c9,_0x1dce5f;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x3e43a0=await this['sender']['_send']('ping',{},0x320);_0x3e43a0&&(_0x5d84c9=_0x3e43a0[0x0])!=null&&_0x5d84c9['fulfilled']&&(_0x1dce5f=_0x3e43a0[0x0])!=null&&_0x1dce5f['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x49f320){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x49f320},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x53b421=>{await Or(_0x53b421,Dn,'1'),await Dr(_0x53b421,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x5af85e){this['pendingWrites']++;try{await _0x5af85e();}finally{this['pendingWrites']--;}}async['_set'](_0x383e8b,_0x2bb237){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0xe1eca=>Or(_0xe1eca,_0x383e8b,_0x2bb237)),this['localCache'][_0x383e8b]=_0x2bb237,this['notifyServiceWorker'](_0x383e8b)));}async['_get'](_0x2b0d20){const _0x3f06b6=await this['_withRetries'](_0x5020ba=>gp(_0x5020ba,_0x2b0d20));return this['localCache'][_0x2b0d20]=_0x3f06b6,_0x3f06b6;}async['_remove'](_0x13638c){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x1b786e=>Dr(_0x1b786e,_0x13638c)),delete this['localCache'][_0x13638c],this['notifyServiceWorker'](_0x13638c)));}async['_poll'](){const _0x3579dd=await this['_withRetries'](_0x4f8fa9=>{const _0x253fcc=Zn(_0x4f8fa9,!0x1)['getAll']();return new nn(_0x253fcc)['toPromise']();});if(!_0x3579dd)return[];if(this['pendingWrites']!==0x0)return[];const _0x43f85e=[],_0x13bab4=new Set();if(_0x3579dd['length']!==0x0){for(const {fbase_key:_0xcda99c,value:_0x241f0f}of _0x3579dd)_0x13bab4['add'](_0xcda99c),JSON['stringify'](this['localCache'][_0xcda99c])!==JSON['stringify'](_0x241f0f)&&(this['notifyListeners'](_0xcda99c,_0x241f0f),_0x43f85e['push'](_0xcda99c));}for(const _0x156e7d of Object['keys'](this['localCache']))this['localCache'][_0x156e7d]&&!_0x13bab4['has'](_0x156e7d)&&(this['notifyListeners'](_0x156e7d,null),_0x43f85e['push'](_0x156e7d));return _0x43f85e;}['notifyListeners'](_0x2cbb04,_0xe1056){this['localCache'][_0x2cbb04]=_0xe1056;const _0x3c144e=this['listeners'][_0x2cbb04];if(_0x3c144e){for(const _0x4807cb of Array['from'](_0x3c144e))_0x4807cb(_0xe1056);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x5572f3,_0xd578cd){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x5572f3]||(this['listeners'][_0x5572f3]=new Set(),this['_get'](_0x5572f3)),this['listeners'][_0x5572f3]['add'](_0xd578cd);}['_removeListener'](_0xde00e,_0x1b97bd){this['listeners'][_0xde00e]&&(this['listeners'][_0xde00e]['delete'](_0x1b97bd),this['listeners'][_0xde00e]['size']===0x0&&delete this['listeners'][_0xde00e]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x339897,_0x4afa34){return _0x4afa34?ie(_0x4afa34):(m(_0x339897['_popupRedirectResolver'],_0x339897,'argument-error'),_0x339897['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x2a15d2){super('custom','custom'),this['params']=_0x2a15d2;}['_getIdTokenResponse'](_0x1f90ee){return nt(_0x1f90ee,this['_buildIdpRequest']());}['_linkToIdToken'](_0x284c3d,_0x4ba57d){return nt(_0x284c3d,this['_buildIdpRequest'](_0x4ba57d));}['_getReauthenticationResolver'](_0x54827d){return nt(_0x54827d,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x1b4d24){const _0x17940c={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x1b4d24&&(_0x17940c['idToken']=_0x1b4d24),_0x17940c;}}function Ip(_0x27c247){return Va(_0x27c247['auth'],new ks(_0x27c247),_0x27c247['bypassAuthState']);}function wp(_0x2f804a){const {auth:_0xa13520,user:_0x4b526f}=_0x2f804a;return m(_0x4b526f,_0xa13520,'internal-error'),tp(_0x4b526f,new ks(_0x2f804a),_0x2f804a['bypassAuthState']);}async function Cp(_0x1671d5){const {auth:_0x2a4d08,user:_0xe489f1}=_0x1671d5;return m(_0xe489f1,_0x2a4d08,'internal-error'),ep(_0xe489f1,new ks(_0x1671d5),_0x1671d5['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x3ebebc,_0x438b71,_0x21fbfb,_0x9effc9,_0x36d116=!0x1){this['auth']=_0x3ebebc,this['resolver']=_0x21fbfb,this['user']=_0x9effc9,this['bypassAuthState']=_0x36d116,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x438b71)?_0x438b71:[_0x438b71];}['execute'](){return new Promise(async(_0x3208e3,_0x5141cf)=>{this['pendingPromise']={'resolve':_0x3208e3,'reject':_0x5141cf};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x43d566){this['reject'](_0x43d566);}});}async['onAuthEvent'](_0xe95bfa){const {urlResponse:_0x1bdaac,sessionId:_0x1b1d17,postBody:_0x3d8ef2,tenantId:_0x2dca90,error:_0x470de8,type:_0x522710}=_0xe95bfa;if(_0x470de8){this['reject'](_0x470de8);return;}const _0x123b2d={'auth':this['auth'],'requestUri':_0x1bdaac,'sessionId':_0x1b1d17,'tenantId':_0x2dca90||void 0x0,'postBody':_0x3d8ef2||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x522710)(_0x123b2d));}catch(_0x28ba98){this['reject'](_0x28ba98);}}['onError'](_0x409a79){this['reject'](_0x409a79);}['getIdpTask'](_0x55e2ff){switch(_0x55e2ff){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x17f730){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x17f730),this['unregisterAndCleanUp']();}['reject'](_0x5f1fb9){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x5f1fb9),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x39aa37,_0x278869,_0x1e16b2,_0x31c0da,_0x1b2938){super(_0x39aa37,_0x278869,_0x31c0da,_0x1b2938),this['provider']=_0x1e16b2,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x216c86=await this['execute']();return m(_0x216c86,this['auth'],'internal-error'),_0x216c86;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x3e51ae=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x3e51ae),this['authWindow']['associatedEvent']=_0x3e51ae,this['resolver']['_originValidation'](this['auth'])['catch'](_0x328923=>{this['reject'](_0x328923);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x29d242=>{_0x29d242||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0xece934;return((_0xece934=this['authWindow'])==null?void 0x0:_0xece934['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x23e254=()=>{var _0x18f496,_0xbfaf63;if((_0xbfaf63=(_0x18f496=this['authWindow'])==null?void 0x0:_0x18f496['window'])!=null&&_0xbfaf63['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x23e254,Tp['get']());};_0x23e254();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x4a88e5,_0x15264c,_0x240ed9=!0x1){super(_0x4a88e5,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x15264c,void 0x0,_0x240ed9),this['eventId']=null;}async['execute'](){let _0x3bd37f=hn['get'](this['auth']['_key']());if(!_0x3bd37f){try{const _0x1e9bc0=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x3bd37f=()=>Promise['resolve'](_0x1e9bc0);}catch(_0x1ce52e){_0x3bd37f=()=>Promise['reject'](_0x1ce52e);}hn['set'](this['auth']['_key'](),_0x3bd37f);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x3bd37f();}async['onAuthEvent'](_0x14d085){if(_0x14d085['type']==='signInViaRedirect')return super['onAuthEvent'](_0x14d085);if(_0x14d085['type']==='unknown'){this['resolve'](null);return;}if(_0x14d085['eventId']){const _0x141ee7=await this['auth']['_redirectUserForId'](_0x14d085['eventId']);if(_0x141ee7)return this['user']=_0x141ee7,super['onAuthEvent'](_0x14d085);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x1e531b,_0x10657e){const _0x10f55b=Pp(_0x10657e),_0x49b155=kp(_0x1e531b);if(!await _0x49b155['_isAvailable']())return!0x1;const _0x57fcfe=await _0x49b155['_get'](_0x10f55b)==='true';return await _0x49b155['_remove'](_0x10f55b),_0x57fcfe;}function Ap(_0x3d77c3,_0x5a4091){hn['set'](_0x3d77c3['_key'](),_0x5a4091);}function kp(_0x58134f){return ie(_0x58134f['_redirectPersistence']);}function Pp(_0x14a959){return ln(Sp,_0x14a959['config']['apiKey'],_0x14a959['name']);}async function Np(_0x54e098,_0x26067f,_0x5bc6a1=!0x1){if($(_0x54e098['app']))return Promise['reject'](re(_0x54e098));const _0x7de2da=Ke(_0x54e098),_0x2d7162=Ep(_0x7de2da,_0x26067f),_0x576224=await new bp(_0x7de2da,_0x2d7162,_0x5bc6a1)['execute']();return _0x576224&&!_0x5bc6a1&&(delete _0x576224['user']['_redirectEventId'],await _0x7de2da['_persistUserIfCurrent'](_0x576224['user']),await _0x7de2da['_setRedirectUser'](null,_0x26067f)),_0x576224;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0xaef1fa){this['auth']=_0xaef1fa,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0xb23ba3){this['consumers']['add'](_0xb23ba3),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0xb23ba3)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0xb23ba3),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x14db76){this['consumers']['delete'](_0x14db76);}['onEvent'](_0x3b0e11){if(this['hasEventBeenHandled'](_0x3b0e11))return!0x1;let _0x38f05a=!0x1;return this['consumers']['forEach'](_0x32da3e=>{this['isEventForConsumer'](_0x3b0e11,_0x32da3e)&&(_0x38f05a=!0x0,this['sendToConsumer'](_0x3b0e11,_0x32da3e),this['saveEventToCache'](_0x3b0e11));}),this['hasHandledPotentialRedirect']||!Mp(_0x3b0e11)||(this['hasHandledPotentialRedirect']=!0x0,_0x38f05a||(this['queuedRedirectEvent']=_0x3b0e11,_0x38f05a=!0x0)),_0x38f05a;}['sendToConsumer'](_0x3c18df,_0x26f1d8){var _0x311d09;if(_0x3c18df['error']&&!Za(_0x3c18df)){const _0x2d2f2b=((_0x311d09=_0x3c18df['error']['code'])==null?void 0x0:_0x311d09['split']('auth/')[0x1])||'internal-error';_0x26f1d8['onError'](X(this['auth'],_0x2d2f2b));}else _0x26f1d8['onAuthEvent'](_0x3c18df);}['isEventForConsumer'](_0x3177e9,_0x2956ec){const _0x117e02=_0x2956ec['eventId']===null||!!_0x3177e9['eventId']&&_0x3177e9['eventId']===_0x2956ec['eventId'];return _0x2956ec['filter']['includes'](_0x3177e9['type'])&&_0x117e02;}['hasEventBeenHandled'](_0x859322){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x859322));}['saveEventToCache'](_0x571a88){this['cachedEventUids']['add'](Mr(_0x571a88)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x17525f){return[_0x17525f['type'],_0x17525f['eventId'],_0x17525f['sessionId'],_0x17525f['tenantId']]['filter'](_0x54c0a8=>_0x54c0a8)['join']('-');}function Za({type:_0x4d2b70,error:_0x45e62c}){return _0x4d2b70==='unknown'&&(_0x45e62c==null?void 0x0:_0x45e62c['code'])==='auth/no-auth-event';}function Mp(_0x486188){switch(_0x486188['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x486188);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x1c7df8,_0x44cac4={}){return Pe(_0x1c7df8,'GET','/v1/projects',_0x44cac4);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x37003a){if(_0x37003a['config']['emulator'])return;const {authorizedDomains:_0x1a1f98}=await Lp(_0x37003a);for(const _0x544bbc of _0x1a1f98)try{if(Wp(_0x544bbc))return;}catch{}Y(_0x37003a,'unauthorized-domain');}function Wp(_0x5020fb){const _0xc411ce=Mi(),{protocol:_0x355617,hostname:_0x54db73}=new URL(_0xc411ce);if(_0x5020fb['startsWith']('chrome-extension://')){const _0xb59cd3=new URL(_0x5020fb);return _0xb59cd3['hostname']===''&&_0x54db73===''?_0x355617==='chrome-extension:'&&_0x5020fb['replace']('chrome-extension://','')===_0xc411ce['replace']('chrome-extension://',''):_0x355617==='chrome-extension:'&&_0xb59cd3['hostname']===_0x54db73;}if(!Fp['test'](_0x355617))return!0x1;if(xp['test'](_0x5020fb))return _0x54db73===_0x5020fb;const _0x31ba96=_0x5020fb['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x31ba96+'|'+_0x31ba96+')$','i')['test'](_0x54db73);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x5b375f=Z()['___jsl'];if(_0x5b375f!=null&&_0x5b375f['H']){for(const _0x46553f of Object['keys'](_0x5b375f['H']))if(_0x5b375f['H'][_0x46553f]['r']=_0x5b375f['H'][_0x46553f]['r']||[],_0x5b375f['H'][_0x46553f]['L']=_0x5b375f['H'][_0x46553f]['L']||[],_0x5b375f['H'][_0x46553f]['r']=[..._0x5b375f['H'][_0x46553f]['L']],_0x5b375f['CP']){for(let _0x5b28ac=0x0;_0x5b28ac<_0x5b375f['CP']['length'];_0x5b28ac++)_0x5b375f['CP'][_0x5b28ac]=null;}}}function Vp(_0x1b6e2e){return new Promise((_0x260e7b,_0x4d77a4)=>{var _0xc66669,_0x4498d8,_0x164507;function _0xf40288(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x260e7b(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x4d77a4(X(_0x1b6e2e,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x4498d8=(_0xc66669=Z()['gapi'])==null?void 0x0:_0xc66669['iframes'])!=null&&_0x4498d8['Iframe'])_0x260e7b(gapi['iframes']['getContext']());else{if((_0x164507=Z()['gapi'])!=null&&_0x164507['load'])_0xf40288();else{const _0x12a305=Ff('iframefcb');return Z()[_0x12a305]=()=>{gapi['load']?_0xf40288():_0x4d77a4(X(_0x1b6e2e,'network-request-failed'));},xa(xf()+'?onload='+_0x12a305)['catch'](_0xc5b9d1=>_0x4d77a4(_0xc5b9d1));}}})['catch'](_0x915012=>{throw un=null,_0x915012;});}let un=null;function Hp(_0x2d7235){return un=un||Vp(_0x2d7235),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x1951e3){const _0x12e898=_0x1951e3['config'];m(_0x12e898['authDomain'],_0x1951e3,'auth-domain-config-required');const _0x2da8b9=_0x12e898['emulator']?Cs(_0x12e898,qp):'https://'+_0x1951e3['config']['authDomain']+'/'+Gp,_0x4ca056={'apiKey':_0x12e898['apiKey'],'appName':_0x1951e3['name'],'v':dt},_0x59afc8=jp['get'](_0x1951e3['config']['apiHost']);_0x59afc8&&(_0x4ca056['eid']=_0x59afc8);const _0x56241d=_0x1951e3['_getFrameworks']();return _0x56241d['length']&&(_0x4ca056['fw']=_0x56241d['join'](',')),_0x2da8b9+'?'+ut(_0x4ca056)['slice'](0x1);}async function Yp(_0x40fdf1){const _0x13bbe6=await Hp(_0x40fdf1),_0xa2a1a=Z()['gapi'];return m(_0xa2a1a,_0x40fdf1,'internal-error'),_0x13bbe6['open']({'where':document['body'],'url':Kp(_0x40fdf1),'messageHandlersFilter':_0xa2a1a['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x499b49=>new Promise(async(_0x1bb75f,_0x52b984)=>{await _0x499b49['restyle']({'setHideOnLeave':!0x1});const _0xc35047=X(_0x40fdf1,'network-request-failed'),_0x39c85e=Z()['setTimeout'](()=>{_0x52b984(_0xc35047);},$p['get']());function _0x22c185(){Z()['clearTimeout'](_0x39c85e),_0x1bb75f(_0x499b49);}_0x499b49['ping'](_0x22c185)['then'](_0x22c185,()=>{_0x52b984(_0xc35047);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x5aa193){this['window']=_0x5aa193,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x3de036,_0x12ee96,_0x306a72,_0x4747ee=Jp,_0x5ca38f=Xp){const _0x2c7b5d=Math['max']((window['screen']['availHeight']-_0x5ca38f)/0x2,0x0)['toString'](),_0x5b9e11=Math['max']((window['screen']['availWidth']-_0x4747ee)/0x2,0x0)['toString']();let _0x3894d3='';const _0xe7d46e={...Qp,'width':_0x4747ee['toString'](),'height':_0x5ca38f['toString'](),'top':_0x2c7b5d,'left':_0x5b9e11},_0x503b7a=W()['toLowerCase']();_0x306a72&&(_0x3894d3=ka(_0x503b7a)?Zp:_0x306a72),Ra(_0x503b7a)&&(_0x12ee96=_0x12ee96||e_,_0xe7d46e['scrollbars']='yes');const _0x138c60=Object['entries'](_0xe7d46e)['reduce']((_0x3b4841,[_0x164d3c,_0x38e6eb])=>''+_0x3b4841+_0x164d3c+'='+_0x38e6eb+',','');if(Rf(_0x503b7a)&&_0x3894d3!=='_self')return n_(_0x12ee96||'',_0x3894d3),new xr(null);const _0x5425a0=window['open'](_0x12ee96||'',_0x3894d3,_0x138c60);m(_0x5425a0,_0x3de036,'popup-blocked');try{_0x5425a0['focus']();}catch{}return new xr(_0x5425a0);}function n_(_0x1808f2,_0x4e0cc1){const _0xc321f8=document['createElement']('a');_0xc321f8['href']=_0x1808f2,_0xc321f8['target']=_0x4e0cc1;const _0x3e2436=document['createEvent']('MouseEvent');_0x3e2436['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0xc321f8['dispatchEvent'](_0x3e2436);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x43629a,_0x4aa5f0,_0x4a1f70,_0x44696f,_0x31313f,_0x53dcd4){m(_0x43629a['config']['authDomain'],_0x43629a,'auth-domain-config-required'),m(_0x43629a['config']['apiKey'],_0x43629a,'invalid-api-key');const _0x2b9613={'apiKey':_0x43629a['config']['apiKey'],'appName':_0x43629a['name'],'authType':_0x4a1f70,'redirectUrl':_0x44696f,'v':dt,'eventId':_0x31313f};if(_0x4aa5f0 instanceof Wa){_0x4aa5f0['setDefaultLanguage'](_0x43629a['languageCode']),_0x2b9613['providerId']=_0x4aa5f0['providerId']||'',pn(_0x4aa5f0['getCustomParameters']())||(_0x2b9613['customParameters']=JSON['stringify'](_0x4aa5f0['getCustomParameters']()));for(const [_0x128655,_0x49ed04]of Object['entries']({}))_0x2b9613[_0x128655]=_0x49ed04;}if(_0x4aa5f0 instanceof tn){const _0x261511=_0x4aa5f0['getScopes']()['filter'](_0x3981d6=>_0x3981d6!=='');_0x261511['length']>0x0&&(_0x2b9613['scopes']=_0x261511['join'](','));}_0x43629a['tenantId']&&(_0x2b9613['tid']=_0x43629a['tenantId']);const _0x1ee46d=_0x2b9613;for(const _0xb73e of Object['keys'](_0x1ee46d))_0x1ee46d[_0xb73e]===void 0x0&&delete _0x1ee46d[_0xb73e];const _0x40b58f=await _0x43629a['_getAppCheckToken'](),_0x2e1dbe=_0x40b58f?'#'+r_+'='+encodeURIComponent(_0x40b58f):'';return o_(_0x43629a)+'?'+ut(_0x1ee46d)['slice'](0x1)+_0x2e1dbe;}function o_({config:_0x5adf0c}){return _0x5adf0c['emulator']?Cs(_0x5adf0c,s_):'https://'+_0x5adf0c['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x3e061a,_0x4492e5,_0x10f579,_0x43d305){var _0x59e675;ce((_0x59e675=this['eventManagers'][_0x3e061a['_key']()])==null?void 0x0:_0x59e675['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x4e47a1=await Fr(_0x3e061a,_0x4492e5,_0x10f579,Mi(),_0x43d305);return t_(_0x3e061a,_0x4e47a1,As());}async['_openRedirect'](_0x176441,_0xeb85cf,_0x47c5b6,_0x3f6ea3){await this['_originValidation'](_0x176441);const _0x40f29e=await Fr(_0x176441,_0xeb85cf,_0x47c5b6,Mi(),_0x3f6ea3);return hp(_0x40f29e),new Promise(()=>{});}['_initialize'](_0x5f328){const _0x4bccfe=_0x5f328['_key']();if(this['eventManagers'][_0x4bccfe]){const {manager:_0xc9d823,promise:_0x351607}=this['eventManagers'][_0x4bccfe];return _0xc9d823?Promise['resolve'](_0xc9d823):(ce(_0x351607,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x351607);}const _0x8de3e2=this['initAndGetManager'](_0x5f328);return this['eventManagers'][_0x4bccfe]={'promise':_0x8de3e2},_0x8de3e2['catch'](()=>{delete this['eventManagers'][_0x4bccfe];}),_0x8de3e2;}async['initAndGetManager'](_0x1932c9){const _0x1027d1=await Yp(_0x1932c9),_0x2f639f=new Dp(_0x1932c9);return _0x1027d1['register']('authEvent',_0x1b5c41=>(m(_0x1b5c41==null?void 0x0:_0x1b5c41['authEvent'],_0x1932c9,'invalid-auth-event'),{'status':_0x2f639f['onEvent'](_0x1b5c41['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x1932c9['_key']()]={'manager':_0x2f639f},this['iframes'][_0x1932c9['_key']()]=_0x1027d1,_0x2f639f;}['_isIframeWebStorageSupported'](_0x210ad6,_0x20305f){this['iframes'][_0x210ad6['_key']()]['send'](pi,{'type':pi},_0x14ce10=>{var _0x3af607;const _0x10b1d4=(_0x3af607=_0x14ce10==null?void 0x0:_0x14ce10[0x0])==null?void 0x0:_0x3af607[pi];_0x10b1d4!==void 0x0&&_0x20305f(!!_0x10b1d4),Y(_0x210ad6,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x40d966){const _0x463795=_0x40d966['_key']();return this['originValidationPromises'][_0x463795]||(this['originValidationPromises'][_0x463795]=Up(_0x40d966)),this['originValidationPromises'][_0x463795];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x2a5da6){this['auth']=_0x2a5da6,this['internalListeners']=new Map();}['getUid'](){var _0x3109d2;return this['assertAuthConfigured'](),((_0x3109d2=this['auth']['currentUser'])==null?void 0x0:_0x3109d2['uid'])||null;}async['getToken'](_0x1a5df2){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x1a5df2)}:null;}['addAuthTokenListener'](_0x5f59df){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x5f59df))return;const _0x44f195=this['auth']['onIdTokenChanged'](_0x348a9d=>{_0x5f59df((_0x348a9d==null?void 0x0:_0x348a9d['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x5f59df,_0x44f195),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0xafb3dc){this['assertAuthConfigured']();const _0x229821=this['internalListeners']['get'](_0xafb3dc);_0x229821&&(this['internalListeners']['delete'](_0xafb3dc),_0x229821(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x3466ac){switch(_0x3466ac){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x1a9e91){st(new Fe('auth',(_0x41d400,{options:_0x3dcc35})=>{const _0x534981=_0x41d400['getProvider']('app')['getImmediate'](),_0x3ca7b0=_0x41d400['getProvider']('heartbeat'),_0x521acc=_0x41d400['getProvider']('app-check-internal'),{apiKey:_0x2cd1d1,authDomain:_0x22d029}=_0x534981['options'];m(_0x2cd1d1&&!_0x2cd1d1['includes'](':'),'invalid-api-key',{'appName':_0x534981['name']});const _0x558085={'apiKey':_0x2cd1d1,'authDomain':_0x22d029,'clientPlatform':_0x1a9e91,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x1a9e91)},_0x3d681a=new Df(_0x534981,_0x3ca7b0,_0x521acc,_0x558085);return Hf(_0x3d681a,_0x3dcc35),_0x3d681a;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x1526dd,_0x286e8e,_0x22c501)=>{_0x1526dd['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x339b39=>{const _0x51818f=Ke(_0x339b39['getProvider']('auth')['getImmediate']());return(_0x1a4316=>new l_(_0x1a4316))(_0x51818f);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x1a9e91)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x7b775a=>async _0x5ee6e5=>{const _0x2f8fbd=_0x5ee6e5&&await _0x5ee6e5['getIdTokenResult'](),_0x506164=_0x2f8fbd&&(new Date()['getTime']()-Date['parse'](_0x2f8fbd['issuedAtTime']))/0x3e8;if(_0x506164&&_0x506164>f_)return;const _0x39cee9=_0x2f8fbd==null?void 0x0:_0x2f8fbd['token'];Br!==_0x39cee9&&(Br=_0x39cee9,await fetch(_0x7b775a,{'method':_0x39cee9?'POST':'DELETE','headers':_0x39cee9?{'Authorization':'Bearer\x20'+_0x39cee9}:{}}));};function B_(_0xaab9f1=Zr()){const _0x5b5a8a=Hi(_0xaab9f1,'auth');if(_0x5b5a8a['isInitialized']())return _0x5b5a8a['getImmediate']();const _0x1bac3a=Vf(_0xaab9f1,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x40afc7=jr('authTokenSyncURL');if(_0x40afc7&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x56794f=new URL(_0x40afc7,location['origin']);if(location['origin']===_0x56794f['origin']){const _0x463de1=p_(_0x56794f['toString']());sp(_0x1bac3a,_0x463de1,()=>_0x463de1(_0x1bac3a['currentUser'])),ip(_0x1bac3a,_0x24933c=>_0x463de1(_0x24933c));}}const _0x8a0232=qr('auth');return _0x8a0232&&$f(_0x1bac3a,'http://'+_0x8a0232),_0x1bac3a;}function __(){var _0x18d1bb;return((_0x18d1bb=document['getElementsByTagName']('head'))==null?void 0x0:_0x18d1bb[0x0])??document;}Mf({'loadJS'(_0x38a630){return new Promise((_0x1615d6,_0xe967e4)=>{const _0x4376b4=document['createElement']('script');_0x4376b4['setAttribute']('src',_0x38a630),_0x4376b4['onload']=_0x1615d6,_0x4376b4['onerror']=_0xc44c4b=>{const _0x221b50=X('internal-error');_0x221b50['customData']=_0xc44c4b,_0xe967e4(_0x221b50);},_0x4376b4['type']='text/javascript',_0x4376b4['charset']='UTF-8',__()['appendChild'](_0x4376b4);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{Gd as A,Vt as B,N_ as C,U_ as D,O_ as E,M_ as a,C_ as b,B_ as c,L_ as d,A_ as e,W_ as f,w_ as g,m_ as h,Sl as i,Hd as j,R_ as k,S_ as l,g_ as m,P_ as n,b_ as o,E_ as p,k_ as q,y_ as r,T_ as s,F_ as t,I_ as u,ap as v,Zr as w,x_ as x,v_ as y,D_ as z};