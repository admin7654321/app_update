const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x33952f,_0x33caf5){if(!_0x33952f)throw ht(_0x33caf5);},ht=function(_0x2330a5){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x2330a5);},Hr=function(_0x4ebabe){const _0x558a46=[];let _0xa7f080=0x0;for(let _0x51423b=0x0;_0x51423b<_0x4ebabe['length'];_0x51423b++){let _0x15c415=_0x4ebabe['charCodeAt'](_0x51423b);_0x15c415<0x80?_0x558a46[_0xa7f080++]=_0x15c415:_0x15c415<0x800?(_0x558a46[_0xa7f080++]=_0x15c415>>0x6|0xc0,_0x558a46[_0xa7f080++]=_0x15c415&0x3f|0x80):(_0x15c415&0xfc00)===0xd800&&_0x51423b+0x1<_0x4ebabe['length']&&(_0x4ebabe['charCodeAt'](_0x51423b+0x1)&0xfc00)===0xdc00?(_0x15c415=0x10000+((_0x15c415&0x3ff)<<0xa)+(_0x4ebabe['charCodeAt'](++_0x51423b)&0x3ff),_0x558a46[_0xa7f080++]=_0x15c415>>0x12|0xf0,_0x558a46[_0xa7f080++]=_0x15c415>>0xc&0x3f|0x80,_0x558a46[_0xa7f080++]=_0x15c415>>0x6&0x3f|0x80,_0x558a46[_0xa7f080++]=_0x15c415&0x3f|0x80):(_0x558a46[_0xa7f080++]=_0x15c415>>0xc|0xe0,_0x558a46[_0xa7f080++]=_0x15c415>>0x6&0x3f|0x80,_0x558a46[_0xa7f080++]=_0x15c415&0x3f|0x80);}return _0x558a46;},nc=function(_0x5eb4ef){const _0x35cfc5=[];let _0x4a5a14=0x0,_0x3b4c4c=0x0;for(;_0x4a5a14<_0x5eb4ef['length'];){const _0x4b3322=_0x5eb4ef[_0x4a5a14++];if(_0x4b3322<0x80)_0x35cfc5[_0x3b4c4c++]=String['fromCharCode'](_0x4b3322);else{if(_0x4b3322>0xbf&&_0x4b3322<0xe0){const _0x5d694d=_0x5eb4ef[_0x4a5a14++];_0x35cfc5[_0x3b4c4c++]=String['fromCharCode']((_0x4b3322&0x1f)<<0x6|_0x5d694d&0x3f);}else{if(_0x4b3322>0xef&&_0x4b3322<0x16d){const _0x28b835=_0x5eb4ef[_0x4a5a14++],_0x71c37d=_0x5eb4ef[_0x4a5a14++],_0x1f4948=_0x5eb4ef[_0x4a5a14++],_0x2541e1=((_0x4b3322&0x7)<<0x12|(_0x28b835&0x3f)<<0xc|(_0x71c37d&0x3f)<<0x6|_0x1f4948&0x3f)-0x10000;_0x35cfc5[_0x3b4c4c++]=String['fromCharCode'](0xd800+(_0x2541e1>>0xa)),_0x35cfc5[_0x3b4c4c++]=String['fromCharCode'](0xdc00+(_0x2541e1&0x3ff));}else{const _0xe6f8bd=_0x5eb4ef[_0x4a5a14++],_0x5b78b8=_0x5eb4ef[_0x4a5a14++];_0x35cfc5[_0x3b4c4c++]=String['fromCharCode']((_0x4b3322&0xf)<<0xc|(_0xe6f8bd&0x3f)<<0x6|_0x5b78b8&0x3f);}}}}return _0x35cfc5['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x2894e4,_0x2e3f89){if(!Array['isArray'](_0x2894e4))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x109d26=_0x2e3f89?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x4500eb=[];for(let _0x22cf14=0x0;_0x22cf14<_0x2894e4['length'];_0x22cf14+=0x3){const _0x595b87=_0x2894e4[_0x22cf14],_0x24e2c7=_0x22cf14+0x1<_0x2894e4['length'],_0x440fb9=_0x24e2c7?_0x2894e4[_0x22cf14+0x1]:0x0,_0x3a9d89=_0x22cf14+0x2<_0x2894e4['length'],_0x26fa9e=_0x3a9d89?_0x2894e4[_0x22cf14+0x2]:0x0,_0x56cc68=_0x595b87>>0x2,_0x12f2ac=(_0x595b87&0x3)<<0x4|_0x440fb9>>0x4;let _0x313f8b=(_0x440fb9&0xf)<<0x2|_0x26fa9e>>0x6,_0x10584c=_0x26fa9e&0x3f;_0x3a9d89||(_0x10584c=0x40,_0x24e2c7||(_0x313f8b=0x40)),_0x4500eb['push'](_0x109d26[_0x56cc68],_0x109d26[_0x12f2ac],_0x109d26[_0x313f8b],_0x109d26[_0x10584c]);}return _0x4500eb['join']('');},'encodeString'(_0x3ad3eb,_0x3b9a5e){return this['HAS_NATIVE_SUPPORT']&&!_0x3b9a5e?btoa(_0x3ad3eb):this['encodeByteArray'](Hr(_0x3ad3eb),_0x3b9a5e);},'decodeString'(_0x14c2da,_0x39adf){return this['HAS_NATIVE_SUPPORT']&&!_0x39adf?atob(_0x14c2da):nc(this['decodeStringToByteArray'](_0x14c2da,_0x39adf));},'decodeStringToByteArray'(_0x5dd903,_0x546e48){this['init_']();const _0x296f07=_0x546e48?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x55a245=[];for(let _0x4604da=0x0;_0x4604da<_0x5dd903['length'];){const _0x6a8bee=_0x296f07[_0x5dd903['charAt'](_0x4604da++)],_0x379c96=_0x4604da<_0x5dd903['length']?_0x296f07[_0x5dd903['charAt'](_0x4604da)]:0x0;++_0x4604da;const _0x5df35e=_0x4604da<_0x5dd903['length']?_0x296f07[_0x5dd903['charAt'](_0x4604da)]:0x40;++_0x4604da;const _0x21f60d=_0x4604da<_0x5dd903['length']?_0x296f07[_0x5dd903['charAt'](_0x4604da)]:0x40;if(++_0x4604da,_0x6a8bee==null||_0x379c96==null||_0x5df35e==null||_0x21f60d==null)throw new ic();const _0x2d8b7b=_0x6a8bee<<0x2|_0x379c96>>0x4;if(_0x55a245['push'](_0x2d8b7b),_0x5df35e!==0x40){const _0x54adb4=_0x379c96<<0x4&0xf0|_0x5df35e>>0x2;if(_0x55a245['push'](_0x54adb4),_0x21f60d!==0x40){const _0x9c5e9d=_0x5df35e<<0x6&0xc0|_0x21f60d;_0x55a245['push'](_0x9c5e9d);}}}return _0x55a245;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x12f658=0x0;_0x12f658<this['ENCODED_VALS']['length'];_0x12f658++)this['byteToCharMap_'][_0x12f658]=this['ENCODED_VALS']['charAt'](_0x12f658),this['charToByteMap_'][this['byteToCharMap_'][_0x12f658]]=_0x12f658,this['byteToCharMapWebSafe_'][_0x12f658]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x12f658),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x12f658]]=_0x12f658,_0x12f658>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x12f658)]=_0x12f658,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x12f658)]=_0x12f658);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x491d96){const _0x5b418f=Hr(_0x491d96);return Fi['encodeByteArray'](_0x5b418f,!0x0);},dn=function(_0x47119f){return $r(_0x47119f)['replace'](/\./g,'');},fn=function(_0x210926){try{return Fi['decodeString'](_0x210926,!0x0);}catch(_0x5405c7){console['error']('base64Decode\x20failed:\x20',_0x5405c7);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x51fb39){return Gr(void 0x0,_0x51fb39);}function Gr(_0x381f41,_0x7b0cb0){if(!(_0x7b0cb0 instanceof Object))return _0x7b0cb0;switch(_0x7b0cb0['constructor']){case Date:const _0x36ef04=_0x7b0cb0;return new Date(_0x36ef04['getTime']());case Object:_0x381f41===void 0x0&&(_0x381f41={});break;case Array:_0x381f41=[];break;default:return _0x7b0cb0;}for(const _0x432612 in _0x7b0cb0)!_0x7b0cb0['hasOwnProperty'](_0x432612)||!rc(_0x432612)||(_0x381f41[_0x432612]=Gr(_0x381f41[_0x432612],_0x7b0cb0[_0x432612]));return _0x381f41;}function rc(_0x386647){return _0x386647!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x50a176=Ps['__FIREBASE_DEFAULTS__'];if(_0x50a176)return JSON['parse'](_0x50a176);},lc=()=>{if(typeof document>'u')return;let _0x2e1de6;try{_0x2e1de6=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x551915=_0x2e1de6&&fn(_0x2e1de6[0x1]);return _0x551915&&JSON['parse'](_0x551915);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x3bad2b){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x3bad2b);return;}},qr=_0x174af8=>{var _0x546c66,_0x16935a;return(_0x16935a=(_0x546c66=Ui())==null?void 0x0:_0x546c66['emulatorHosts'])==null?void 0x0:_0x16935a[_0x174af8];},hc=_0x3c8bcd=>{const _0x4c651c=qr(_0x3c8bcd);if(!_0x4c651c)return;const _0x5809da=_0x4c651c['lastIndexOf'](':');if(_0x5809da<=0x0||_0x5809da+0x1===_0x4c651c['length'])throw new Error('Invalid\x20host\x20'+_0x4c651c+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x955146=parseInt(_0x4c651c['substring'](_0x5809da+0x1),0xa);return _0x4c651c[0x0]==='['?[_0x4c651c['substring'](0x1,_0x5809da-0x1),_0x955146]:[_0x4c651c['substring'](0x0,_0x5809da),_0x955146];},zr=()=>{var _0x10667d;return(_0x10667d=Ui())==null?void 0x0:_0x10667d['config'];},jr=_0x1aee6d=>{var _0xb13238;return(_0xb13238=Ui())==null?void 0x0:_0xb13238['_'+_0x1aee6d];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x3a322b,_0xc4c09a)=>{this['resolve']=_0x3a322b,this['reject']=_0xc4c09a;});}['wrapCallback'](_0xdc1f74){return(_0x4f92f9,_0x50a0e0)=>{_0x4f92f9?this['reject'](_0x4f92f9):this['resolve'](_0x50a0e0),typeof _0xdc1f74=='function'&&(this['promise']['catch'](()=>{}),_0xdc1f74['length']===0x1?_0xdc1f74(_0x4f92f9):_0xdc1f74(_0x4f92f9,_0x50a0e0));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x484a83,_0x2a91cb){if(_0x484a83['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x45446f={'alg':'none','type':'JWT'},_0x4a1e95=_0x2a91cb||'demo-project',_0x2635aa=_0x484a83['iat']||0x0,_0x176c23=_0x484a83['sub']||_0x484a83['user_id'];if(!_0x176c23)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x370970={'iss':'https://securetoken.google.com/'+_0x4a1e95,'aud':_0x4a1e95,'iat':_0x2635aa,'exp':_0x2635aa+0xe10,'auth_time':_0x2635aa,'sub':_0x176c23,'user_id':_0x176c23,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x484a83};return[dn(JSON['stringify'](_0x45446f)),dn(JSON['stringify'](_0x370970)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x4f9783=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x4f9783=='object'&&_0x4f9783['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x4f4f91=W();return _0x4f4f91['indexOf']('MSIE\x20')>=0x0||_0x4f4f91['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x5887ac,_0x4e475c)=>{try{let _0x75797f=!0x0;const _0x248be1='validate-browser-context-for-indexeddb-analytics-module',_0x491e98=self['indexedDB']['open'](_0x248be1);_0x491e98['onsuccess']=()=>{_0x491e98['result']['close'](),_0x75797f||self['indexedDB']['deleteDatabase'](_0x248be1),_0x5887ac(!0x0);},_0x491e98['onupgradeneeded']=()=>{_0x75797f=!0x1;},_0x491e98['onerror']=()=>{var _0x1d141e;_0x4e475c(((_0x1d141e=_0x491e98['error'])==null?void 0x0:_0x1d141e['message'])||'');};}catch(_0x3f7715){_0x4e475c(_0x3f7715);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x55222b,_0x24ae0e,_0x394719){super(_0x24ae0e),this['code']=_0x55222b,this['customData']=_0x394719,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0xe94305,_0x160eba,_0x15b94c){this['service']=_0xe94305,this['serviceName']=_0x160eba,this['errors']=_0x15b94c;}['create'](_0x305616,..._0x346ad6){const _0x28fd91=_0x346ad6[0x0]||{},_0x2d1ed1=this['service']+'/'+_0x305616,_0x4fa4bf=this['errors'][_0x305616],_0x5cb7f2=_0x4fa4bf?vc(_0x4fa4bf,_0x28fd91):'Error',_0xabae6f=this['serviceName']+':\x20'+_0x5cb7f2+'\x20('+_0x2d1ed1+').';return new Re(_0x2d1ed1,_0xabae6f,_0x28fd91);}}function vc(_0x303c16,_0xaa2b82){return _0x303c16['replace'](Ec,(_0x54ecb1,_0x5b8885)=>{const _0x4d170f=_0xaa2b82[_0x5b8885];return _0x4d170f!=null?String(_0x4d170f):'<'+_0x5b8885+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x2df6be){return JSON['parse'](_0x2df6be);}function O(_0x1779cf){return JSON['stringify'](_0x1779cf);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x2d63a7){let _0x3f09bb={},_0x52c646={},_0x270a31={},_0x135779='';try{const _0x5ea1b0=_0x2d63a7['split']('.');_0x3f09bb=Nt(fn(_0x5ea1b0[0x0])||''),_0x52c646=Nt(fn(_0x5ea1b0[0x1])||''),_0x135779=_0x5ea1b0[0x2],_0x270a31=_0x52c646['d']||{},delete _0x52c646['d'];}catch{}return{'header':_0x3f09bb,'claims':_0x52c646,'data':_0x270a31,'signature':_0x135779};},Ic=function(_0x1354c3){const _0x2b3998=Yr(_0x1354c3),_0x2c5cf0=_0x2b3998['claims'];return!!_0x2c5cf0&&typeof _0x2c5cf0=='object'&&_0x2c5cf0['hasOwnProperty']('iat');},wc=function(_0x459787){const _0x13ce72=Yr(_0x459787)['claims'];return typeof _0x13ce72=='object'&&_0x13ce72['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x18ba27,_0x5e4c33){return Object['prototype']['hasOwnProperty']['call'](_0x18ba27,_0x5e4c33);}function Le(_0x3df256,_0x3813e1){if(Object['prototype']['hasOwnProperty']['call'](_0x3df256,_0x3813e1))return _0x3df256[_0x3813e1];}function pn(_0x3ed24d){for(const _0x5bb9d0 in _0x3ed24d)if(Object['prototype']['hasOwnProperty']['call'](_0x3ed24d,_0x5bb9d0))return!0x1;return!0x0;}function _n(_0x3a6532,_0x2b0524,_0x4d31d8){const _0x7a080={};for(const _0x3323cf in _0x3a6532)Object['prototype']['hasOwnProperty']['call'](_0x3a6532,_0x3323cf)&&(_0x7a080[_0x3323cf]=_0x2b0524['call'](_0x4d31d8,_0x3a6532[_0x3323cf],_0x3323cf,_0x3a6532));return _0x7a080;}function xe(_0x2d7556,_0x4e3ec6){if(_0x2d7556===_0x4e3ec6)return!0x0;const _0x53cbd3=Object['keys'](_0x2d7556),_0x257b76=Object['keys'](_0x4e3ec6);for(const _0x38e43f of _0x53cbd3){if(!_0x257b76['includes'](_0x38e43f))return!0x1;const _0x2983cd=_0x2d7556[_0x38e43f],_0x590250=_0x4e3ec6[_0x38e43f];if(Ns(_0x2983cd)&&Ns(_0x590250)){if(!xe(_0x2983cd,_0x590250))return!0x1;}else{if(_0x2983cd!==_0x590250)return!0x1;}}for(const _0x587f05 of _0x257b76)if(!_0x53cbd3['includes'](_0x587f05))return!0x1;return!0x0;}function Ns(_0x280158){return _0x280158!==null&&typeof _0x280158=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x5bddf7){const _0x27a4be=[];for(const [_0x1e2564,_0x33b7f3]of Object['entries'](_0x5bddf7))Array['isArray'](_0x33b7f3)?_0x33b7f3['forEach'](_0xba77cc=>{_0x27a4be['push'](encodeURIComponent(_0x1e2564)+'='+encodeURIComponent(_0xba77cc));}):_0x27a4be['push'](encodeURIComponent(_0x1e2564)+'='+encodeURIComponent(_0x33b7f3));return _0x27a4be['length']?'&'+_0x27a4be['join']('&'):'';}function Ct(_0x144693){const _0xcfb1d7={};return _0x144693['replace'](/^\?/,'')['split']('&')['forEach'](_0x2a276b=>{if(_0x2a276b){const [_0x176609,_0x2b9768]=_0x2a276b['split']('=');_0xcfb1d7[decodeURIComponent(_0x176609)]=decodeURIComponent(_0x2b9768);}}),_0xcfb1d7;}function Tt(_0x425464){const _0x4fd88c=_0x425464['indexOf']('?');if(!_0x4fd88c)return'';const _0x31f7be=_0x425464['indexOf']('#',_0x4fd88c);return _0x425464['substring'](_0x4fd88c,_0x31f7be>0x0?_0x31f7be:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x9acb5b=0x1;_0x9acb5b<this['blockSize'];++_0x9acb5b)this['pad_'][_0x9acb5b]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x469e5e,_0x44beef){_0x44beef||(_0x44beef=0x0);const _0x25fd19=this['W_'];if(typeof _0x469e5e=='string'){for(let _0x87d4f1=0x0;_0x87d4f1<0x10;_0x87d4f1++)_0x25fd19[_0x87d4f1]=_0x469e5e['charCodeAt'](_0x44beef)<<0x18|_0x469e5e['charCodeAt'](_0x44beef+0x1)<<0x10|_0x469e5e['charCodeAt'](_0x44beef+0x2)<<0x8|_0x469e5e['charCodeAt'](_0x44beef+0x3),_0x44beef+=0x4;}else{for(let _0x3fe981=0x0;_0x3fe981<0x10;_0x3fe981++)_0x25fd19[_0x3fe981]=_0x469e5e[_0x44beef]<<0x18|_0x469e5e[_0x44beef+0x1]<<0x10|_0x469e5e[_0x44beef+0x2]<<0x8|_0x469e5e[_0x44beef+0x3],_0x44beef+=0x4;}for(let _0x5706a3=0x10;_0x5706a3<0x50;_0x5706a3++){const _0x594b98=_0x25fd19[_0x5706a3-0x3]^_0x25fd19[_0x5706a3-0x8]^_0x25fd19[_0x5706a3-0xe]^_0x25fd19[_0x5706a3-0x10];_0x25fd19[_0x5706a3]=(_0x594b98<<0x1|_0x594b98>>>0x1f)&0xffffffff;}let _0x4f2a0c=this['chain_'][0x0],_0x4352af=this['chain_'][0x1],_0x2d4395=this['chain_'][0x2],_0x4cab02=this['chain_'][0x3],_0x2d3047=this['chain_'][0x4],_0x3af2a0,_0x43648a;for(let _0x2e6bb9=0x0;_0x2e6bb9<0x50;_0x2e6bb9++){_0x2e6bb9<0x28?_0x2e6bb9<0x14?(_0x3af2a0=_0x4cab02^_0x4352af&(_0x2d4395^_0x4cab02),_0x43648a=0x5a827999):(_0x3af2a0=_0x4352af^_0x2d4395^_0x4cab02,_0x43648a=0x6ed9eba1):_0x2e6bb9<0x3c?(_0x3af2a0=_0x4352af&_0x2d4395|_0x4cab02&(_0x4352af|_0x2d4395),_0x43648a=0x8f1bbcdc):(_0x3af2a0=_0x4352af^_0x2d4395^_0x4cab02,_0x43648a=0xca62c1d6);const _0x422b82=(_0x4f2a0c<<0x5|_0x4f2a0c>>>0x1b)+_0x3af2a0+_0x2d3047+_0x43648a+_0x25fd19[_0x2e6bb9]&0xffffffff;_0x2d3047=_0x4cab02,_0x4cab02=_0x2d4395,_0x2d4395=(_0x4352af<<0x1e|_0x4352af>>>0x2)&0xffffffff,_0x4352af=_0x4f2a0c,_0x4f2a0c=_0x422b82;}this['chain_'][0x0]=this['chain_'][0x0]+_0x4f2a0c&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x4352af&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x2d4395&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x4cab02&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x2d3047&0xffffffff;}['update'](_0x21ff17,_0x2e1ae6){if(_0x21ff17==null)return;_0x2e1ae6===void 0x0&&(_0x2e1ae6=_0x21ff17['length']);const _0xcbc9e0=_0x2e1ae6-this['blockSize'];let _0x2c88df=0x0;const _0x283559=this['buf_'];let _0x522826=this['inbuf_'];for(;_0x2c88df<_0x2e1ae6;){if(_0x522826===0x0){for(;_0x2c88df<=_0xcbc9e0;)this['compress_'](_0x21ff17,_0x2c88df),_0x2c88df+=this['blockSize'];}if(typeof _0x21ff17=='string'){for(;_0x2c88df<_0x2e1ae6;)if(_0x283559[_0x522826]=_0x21ff17['charCodeAt'](_0x2c88df),++_0x522826,++_0x2c88df,_0x522826===this['blockSize']){this['compress_'](_0x283559),_0x522826=0x0;break;}}else{for(;_0x2c88df<_0x2e1ae6;)if(_0x283559[_0x522826]=_0x21ff17[_0x2c88df],++_0x522826,++_0x2c88df,_0x522826===this['blockSize']){this['compress_'](_0x283559),_0x522826=0x0;break;}}}this['inbuf_']=_0x522826,this['total_']+=_0x2e1ae6;}['digest'](){const _0x169ba6=[];let _0x3acdf9=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x2d61e1=this['blockSize']-0x1;_0x2d61e1>=0x38;_0x2d61e1--)this['buf_'][_0x2d61e1]=_0x3acdf9&0xff,_0x3acdf9/=0x100;this['compress_'](this['buf_']);let _0x30c6bd=0x0;for(let _0x15b4d9=0x0;_0x15b4d9<0x5;_0x15b4d9++)for(let _0x15e980=0x18;_0x15e980>=0x0;_0x15e980-=0x8)_0x169ba6[_0x30c6bd]=this['chain_'][_0x15b4d9]>>_0x15e980&0xff,++_0x30c6bd;return _0x169ba6;}}function Tc(_0x10d554,_0x5e838d){const _0xa8677d=new Sc(_0x10d554,_0x5e838d);return _0xa8677d['subscribe']['bind'](_0xa8677d);}class Sc{constructor(_0x435e92,_0x4dfb16){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x4dfb16,this['task']['then'](()=>{_0x435e92(this);})['catch'](_0x4dd72e=>{this['error'](_0x4dd72e);});}['next'](_0xbddb3){this['forEachObserver'](_0x1c9ae5=>{_0x1c9ae5['next'](_0xbddb3);});}['error'](_0x10719a){this['forEachObserver'](_0x4168f9=>{_0x4168f9['error'](_0x10719a);}),this['close'](_0x10719a);}['complete'](){this['forEachObserver'](_0x43b270=>{_0x43b270['complete']();}),this['close']();}['subscribe'](_0x42892b,_0x5f2e50,_0x211e8b){let _0x31fc2d;if(_0x42892b===void 0x0&&_0x5f2e50===void 0x0&&_0x211e8b===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x42892b,['next','error','complete'])?_0x31fc2d=_0x42892b:_0x31fc2d={'next':_0x42892b,'error':_0x5f2e50,'complete':_0x211e8b},_0x31fc2d['next']===void 0x0&&(_0x31fc2d['next']=ti),_0x31fc2d['error']===void 0x0&&(_0x31fc2d['error']=ti),_0x31fc2d['complete']===void 0x0&&(_0x31fc2d['complete']=ti);const _0x49b1b4=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x31fc2d['error'](this['finalError']):_0x31fc2d['complete']();}catch{}}),this['observers']['push'](_0x31fc2d),_0x49b1b4;}['unsubscribeOne'](_0x526e5b){this['observers']===void 0x0||this['observers'][_0x526e5b]===void 0x0||(delete this['observers'][_0x526e5b],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x43bf27){if(!this['finalized']){for(let _0x1ada38=0x0;_0x1ada38<this['observers']['length'];_0x1ada38++)this['sendOne'](_0x1ada38,_0x43bf27);}}['sendOne'](_0x279d47,_0x35b710){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x279d47]!==void 0x0)try{_0x35b710(this['observers'][_0x279d47]);}catch(_0x438c77){typeof console<'u'&&console['error']&&console['error'](_0x438c77);}});}['close'](_0x3f302c){this['finalized']||(this['finalized']=!0x0,_0x3f302c!==void 0x0&&(this['finalError']=_0x3f302c),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x431b1e,_0x229728){if(typeof _0x431b1e!='object'||_0x431b1e===null)return!0x1;for(const _0x3fb939 of _0x229728)if(_0x3fb939 in _0x431b1e&&typeof _0x431b1e[_0x3fb939]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x238b36,_0x494e0a){return _0x238b36+'\x20failed:\x20'+_0x494e0a+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x4e1771){const _0x10d4bc=[];let _0x270da8=0x0;for(let _0x12eb7a=0x0;_0x12eb7a<_0x4e1771['length'];_0x12eb7a++){let _0x588ea0=_0x4e1771['charCodeAt'](_0x12eb7a);if(_0x588ea0>=0xd800&&_0x588ea0<=0xdbff){const _0x506f8c=_0x588ea0-0xd800;_0x12eb7a++,f(_0x12eb7a<_0x4e1771['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x3655b5=_0x4e1771['charCodeAt'](_0x12eb7a)-0xdc00;_0x588ea0=0x10000+(_0x506f8c<<0xa)+_0x3655b5;}_0x588ea0<0x80?_0x10d4bc[_0x270da8++]=_0x588ea0:_0x588ea0<0x800?(_0x10d4bc[_0x270da8++]=_0x588ea0>>0x6|0xc0,_0x10d4bc[_0x270da8++]=_0x588ea0&0x3f|0x80):_0x588ea0<0x10000?(_0x10d4bc[_0x270da8++]=_0x588ea0>>0xc|0xe0,_0x10d4bc[_0x270da8++]=_0x588ea0>>0x6&0x3f|0x80,_0x10d4bc[_0x270da8++]=_0x588ea0&0x3f|0x80):(_0x10d4bc[_0x270da8++]=_0x588ea0>>0x12|0xf0,_0x10d4bc[_0x270da8++]=_0x588ea0>>0xc&0x3f|0x80,_0x10d4bc[_0x270da8++]=_0x588ea0>>0x6&0x3f|0x80,_0x10d4bc[_0x270da8++]=_0x588ea0&0x3f|0x80);}return _0x10d4bc;},Ln=function(_0x43250d){let _0x292d22=0x0;for(let _0x486227=0x0;_0x486227<_0x43250d['length'];_0x486227++){const _0x175281=_0x43250d['charCodeAt'](_0x486227);_0x175281<0x80?_0x292d22++:_0x175281<0x800?_0x292d22+=0x2:_0x175281>=0xd800&&_0x175281<=0xdbff?(_0x292d22+=0x4,_0x486227++):_0x292d22+=0x3;}return _0x292d22;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x5b454c){return _0x5b454c&&_0x5b454c['_delegate']?_0x5b454c['_delegate']:_0x5b454c;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x2ebcf0){try{return(_0x2ebcf0['startsWith']('http://')||_0x2ebcf0['startsWith']('https://')?new URL(_0x2ebcf0)['hostname']:_0x2ebcf0)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x3b4c27){return(await fetch(_0x3b4c27,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x36bbc5,_0x33e3e7,_0x129219){this['name']=_0x36bbc5,this['instanceFactory']=_0x33e3e7,this['type']=_0x129219,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x2740cb){return this['instantiationMode']=_0x2740cb,this;}['setMultipleInstances'](_0x28a52e){return this['multipleInstances']=_0x28a52e,this;}['setServiceProps'](_0x6053e8){return this['serviceProps']=_0x6053e8,this;}['setInstanceCreatedCallback'](_0x16a0b0){return this['onInstanceCreated']=_0x16a0b0,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x565a96,_0xf1668c){this['name']=_0x565a96,this['container']=_0xf1668c,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x395070){const _0x44f75a=this['normalizeInstanceIdentifier'](_0x395070);if(!this['instancesDeferred']['has'](_0x44f75a)){const _0x3f2fe5=new H();if(this['instancesDeferred']['set'](_0x44f75a,_0x3f2fe5),this['isInitialized'](_0x44f75a)||this['shouldAutoInitialize']())try{const _0x4a5eaa=this['getOrInitializeService']({'instanceIdentifier':_0x44f75a});_0x4a5eaa&&_0x3f2fe5['resolve'](_0x4a5eaa);}catch{}}return this['instancesDeferred']['get'](_0x44f75a)['promise'];}['getImmediate'](_0x216dd2){const _0x29f4b1=this['normalizeInstanceIdentifier'](_0x216dd2==null?void 0x0:_0x216dd2['identifier']),_0x42ea11=(_0x216dd2==null?void 0x0:_0x216dd2['optional'])??!0x1;if(this['isInitialized'](_0x29f4b1)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x29f4b1});}catch(_0x218a01){if(_0x42ea11)return null;throw _0x218a01;}else{if(_0x42ea11)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x123cfe){if(_0x123cfe['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x123cfe['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x123cfe,!!this['shouldAutoInitialize']()){if(Pc(_0x123cfe))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x1b39d1,_0x435eb2]of this['instancesDeferred']['entries']()){const _0x26a90b=this['normalizeInstanceIdentifier'](_0x1b39d1);try{const _0x2f07b4=this['getOrInitializeService']({'instanceIdentifier':_0x26a90b});_0x435eb2['resolve'](_0x2f07b4);}catch{}}}}['clearInstance'](_0x18ac02=Ne){this['instancesDeferred']['delete'](_0x18ac02),this['instancesOptions']['delete'](_0x18ac02),this['instances']['delete'](_0x18ac02);}async['delete'](){const _0x4a4b2e=Array['from'](this['instances']['values']());await Promise['all']([..._0x4a4b2e['filter'](_0x5cd6f8=>'INTERNAL'in _0x5cd6f8)['map'](_0x4f0fcc=>_0x4f0fcc['INTERNAL']['delete']()),..._0x4a4b2e['filter'](_0x2038af=>'_delete'in _0x2038af)['map'](_0x2de34d=>_0x2de34d['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x558d66=Ne){return this['instances']['has'](_0x558d66);}['getOptions'](_0x3a2d00=Ne){return this['instancesOptions']['get'](_0x3a2d00)||{};}['initialize'](_0x2d12ab={}){const {options:_0x391c77={}}=_0x2d12ab,_0x1e6ce4=this['normalizeInstanceIdentifier'](_0x2d12ab['instanceIdentifier']);if(this['isInitialized'](_0x1e6ce4))throw Error(this['name']+'('+_0x1e6ce4+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x204776=this['getOrInitializeService']({'instanceIdentifier':_0x1e6ce4,'options':_0x391c77});for(const [_0x4a261b,_0xb3204c]of this['instancesDeferred']['entries']()){const _0x438e39=this['normalizeInstanceIdentifier'](_0x4a261b);_0x1e6ce4===_0x438e39&&_0xb3204c['resolve'](_0x204776);}return _0x204776;}['onInit'](_0x1a8986,_0x4b5d82){const _0x3410aa=this['normalizeInstanceIdentifier'](_0x4b5d82),_0x208287=this['onInitCallbacks']['get'](_0x3410aa)??new Set();_0x208287['add'](_0x1a8986),this['onInitCallbacks']['set'](_0x3410aa,_0x208287);const _0x1f8f32=this['instances']['get'](_0x3410aa);return _0x1f8f32&&_0x1a8986(_0x1f8f32,_0x3410aa),()=>{_0x208287['delete'](_0x1a8986);};}['invokeOnInitCallbacks'](_0x442216,_0x3cc3c4){const _0x3fdab2=this['onInitCallbacks']['get'](_0x3cc3c4);if(_0x3fdab2){for(const _0x396d0e of _0x3fdab2)try{_0x396d0e(_0x442216,_0x3cc3c4);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x31a6b5,options:_0x42b4ac={}}){let _0x4118f7=this['instances']['get'](_0x31a6b5);if(!_0x4118f7&&this['component']&&(_0x4118f7=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x31a6b5),'options':_0x42b4ac}),this['instances']['set'](_0x31a6b5,_0x4118f7),this['instancesOptions']['set'](_0x31a6b5,_0x42b4ac),this['invokeOnInitCallbacks'](_0x4118f7,_0x31a6b5),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x31a6b5,_0x4118f7);}catch{}return _0x4118f7||null;}['normalizeInstanceIdentifier'](_0xfee4cd=Ne){return this['component']?this['component']['multipleInstances']?_0xfee4cd:Ne:_0xfee4cd;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x9e89d8){return _0x9e89d8===Ne?void 0x0:_0x9e89d8;}function Pc(_0x4ed1b4){return _0x4ed1b4['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x32dc72){this['name']=_0x32dc72,this['providers']=new Map();}['addComponent'](_0x12e70a){const _0x5bc66f=this['getProvider'](_0x12e70a['name']);if(_0x5bc66f['isComponentSet']())throw new Error('Component\x20'+_0x12e70a['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x5bc66f['setComponent'](_0x12e70a);}['addOrOverwriteComponent'](_0x32cc94){this['getProvider'](_0x32cc94['name'])['isComponentSet']()&&this['providers']['delete'](_0x32cc94['name']),this['addComponent'](_0x32cc94);}['getProvider'](_0x13bba1){if(this['providers']['has'](_0x13bba1))return this['providers']['get'](_0x13bba1);const _0x203a27=new Ac(_0x13bba1,this);return this['providers']['set'](_0x13bba1,_0x203a27),_0x203a27;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x6fada7){_0x6fada7[_0x6fada7['DEBUG']=0x0]='DEBUG',_0x6fada7[_0x6fada7['VERBOSE']=0x1]='VERBOSE',_0x6fada7[_0x6fada7['INFO']=0x2]='INFO',_0x6fada7[_0x6fada7['WARN']=0x3]='WARN',_0x6fada7[_0x6fada7['ERROR']=0x4]='ERROR',_0x6fada7[_0x6fada7['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x146d3e,_0x550721,..._0x3f5a77)=>{if(_0x550721<_0x146d3e['logLevel'])return;const _0x2f511c=new Date()['toISOString'](),_0x3300f8=Mc[_0x550721];if(_0x3300f8)console[_0x3300f8]('['+_0x2f511c+']\x20\x20'+_0x146d3e['name']+':',..._0x3f5a77);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x550721+')');};class Bi{constructor(_0x2dd51c){this['name']=_0x2dd51c,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x43cba8){if(!(_0x43cba8 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x43cba8+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x43cba8;}['setLogLevel'](_0x5edd61){this['_logLevel']=typeof _0x5edd61=='string'?Oc[_0x5edd61]:_0x5edd61;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x3d5a26){if(typeof _0x3d5a26!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x3d5a26;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x4ea913){this['_userLogHandler']=_0x4ea913;}['debug'](..._0x5701fa){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x5701fa),this['_logHandler'](this,T['DEBUG'],..._0x5701fa);}['log'](..._0x2de8a7){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x2de8a7),this['_logHandler'](this,T['VERBOSE'],..._0x2de8a7);}['info'](..._0x57d674){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x57d674),this['_logHandler'](this,T['INFO'],..._0x57d674);}['warn'](..._0x4081a5){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x4081a5),this['_logHandler'](this,T['WARN'],..._0x4081a5);}['error'](..._0x4dda2d){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x4dda2d),this['_logHandler'](this,T['ERROR'],..._0x4dda2d);}}const xc=(_0x58c2ba,_0x4f878f)=>_0x4f878f['some'](_0xbfa99d=>_0x58c2ba instanceof _0xbfa99d);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x1ddf86){const _0x422327=new Promise((_0x98e7b8,_0x5b1556)=>{const _0x42b5fc=()=>{_0x1ddf86['removeEventListener']('success',_0x5b9a31),_0x1ddf86['removeEventListener']('error',_0x490157);},_0x5b9a31=()=>{_0x98e7b8(ge(_0x1ddf86['result'])),_0x42b5fc();},_0x490157=()=>{_0x5b1556(_0x1ddf86['error']),_0x42b5fc();};_0x1ddf86['addEventListener']('success',_0x5b9a31),_0x1ddf86['addEventListener']('error',_0x490157);});return _0x422327['then'](_0x5a4f4f=>{_0x5a4f4f instanceof IDBCursor&&Jr['set'](_0x5a4f4f,_0x1ddf86);})['catch'](()=>{}),Vi['set'](_0x422327,_0x1ddf86),_0x422327;}function Bc(_0x74aa13){if(_i['has'](_0x74aa13))return;const _0x261a95=new Promise((_0x56528a,_0x367e01)=>{const _0x34ae5a=()=>{_0x74aa13['removeEventListener']('complete',_0x376992),_0x74aa13['removeEventListener']('error',_0x4578e9),_0x74aa13['removeEventListener']('abort',_0x4578e9);},_0x376992=()=>{_0x56528a(),_0x34ae5a();},_0x4578e9=()=>{_0x367e01(_0x74aa13['error']||new DOMException('AbortError','AbortError')),_0x34ae5a();};_0x74aa13['addEventListener']('complete',_0x376992),_0x74aa13['addEventListener']('error',_0x4578e9),_0x74aa13['addEventListener']('abort',_0x4578e9);});_i['set'](_0x74aa13,_0x261a95);}let gi={'get'(_0x399bee,_0x1602d4,_0x1bba8b){if(_0x399bee instanceof IDBTransaction){if(_0x1602d4==='done')return _i['get'](_0x399bee);if(_0x1602d4==='objectStoreNames')return _0x399bee['objectStoreNames']||Xr['get'](_0x399bee);if(_0x1602d4==='store')return _0x1bba8b['objectStoreNames'][0x1]?void 0x0:_0x1bba8b['objectStore'](_0x1bba8b['objectStoreNames'][0x0]);}return ge(_0x399bee[_0x1602d4]);},'set'(_0x2583e6,_0x37a576,_0x29cec0){return _0x2583e6[_0x37a576]=_0x29cec0,!0x0;},'has'(_0x167b93,_0x54cec3){return _0x167b93 instanceof IDBTransaction&&(_0x54cec3==='done'||_0x54cec3==='store')?!0x0:_0x54cec3 in _0x167b93;}};function Vc(_0x35ffed){gi=_0x35ffed(gi);}function Hc(_0x584a90){return _0x584a90===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x163d5b,..._0x1d4088){const _0x263533=_0x584a90['call'](ii(this),_0x163d5b,..._0x1d4088);return Xr['set'](_0x263533,_0x163d5b['sort']?_0x163d5b['sort']():[_0x163d5b]),ge(_0x263533);}:Uc()['includes'](_0x584a90)?function(..._0x56fc9f){return _0x584a90['apply'](ii(this),_0x56fc9f),ge(Jr['get'](this));}:function(..._0x1b0080){return ge(_0x584a90['apply'](ii(this),_0x1b0080));};}function $c(_0x543579){return typeof _0x543579=='function'?Hc(_0x543579):(_0x543579 instanceof IDBTransaction&&Bc(_0x543579),xc(_0x543579,Fc())?new Proxy(_0x543579,gi):_0x543579);}function ge(_0x2215c4){if(_0x2215c4 instanceof IDBRequest)return Wc(_0x2215c4);if(ni['has'](_0x2215c4))return ni['get'](_0x2215c4);const _0x2abc6b=$c(_0x2215c4);return _0x2abc6b!==_0x2215c4&&(ni['set'](_0x2215c4,_0x2abc6b),Vi['set'](_0x2abc6b,_0x2215c4)),_0x2abc6b;}const ii=_0x491e41=>Vi['get'](_0x491e41);function Gc(_0x307804,_0x314eb7,{blocked:_0x123352,upgrade:_0x3f80a4,blocking:_0x88fe0,terminated:_0x4d87b7}={}){const _0x511768=indexedDB['open'](_0x307804,_0x314eb7),_0xe21e3c=ge(_0x511768);return _0x3f80a4&&_0x511768['addEventListener']('upgradeneeded',_0x4b4ea4=>{_0x3f80a4(ge(_0x511768['result']),_0x4b4ea4['oldVersion'],_0x4b4ea4['newVersion'],ge(_0x511768['transaction']),_0x4b4ea4);}),_0x123352&&_0x511768['addEventListener']('blocked',_0x4a6ef1=>_0x123352(_0x4a6ef1['oldVersion'],_0x4a6ef1['newVersion'],_0x4a6ef1)),_0xe21e3c['then'](_0x220e3d=>{_0x4d87b7&&_0x220e3d['addEventListener']('close',()=>_0x4d87b7()),_0x88fe0&&_0x220e3d['addEventListener']('versionchange',_0x1f897e=>_0x88fe0(_0x1f897e['oldVersion'],_0x1f897e['newVersion'],_0x1f897e));})['catch'](()=>{}),_0xe21e3c;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x841cb0,_0x4ffe0a){if(!(_0x841cb0 instanceof IDBDatabase&&!(_0x4ffe0a in _0x841cb0)&&typeof _0x4ffe0a=='string'))return;if(si['get'](_0x4ffe0a))return si['get'](_0x4ffe0a);const _0x4ccba4=_0x4ffe0a['replace'](/FromIndex$/,''),_0x2ee26e=_0x4ffe0a!==_0x4ccba4,_0x3e2d1e=zc['includes'](_0x4ccba4);if(!(_0x4ccba4 in(_0x2ee26e?IDBIndex:IDBObjectStore)['prototype'])||!(_0x3e2d1e||qc['includes'](_0x4ccba4)))return;const _0x1199b5=async function(_0x36d5b1,..._0x320e45){const _0x4c6632=this['transaction'](_0x36d5b1,_0x3e2d1e?'readwrite':'readonly');let _0x38c6e2=_0x4c6632['store'];return _0x2ee26e&&(_0x38c6e2=_0x38c6e2['index'](_0x320e45['shift']())),(await Promise['all']([_0x38c6e2[_0x4ccba4](..._0x320e45),_0x3e2d1e&&_0x4c6632['done']]))[0x0];};return si['set'](_0x4ffe0a,_0x1199b5),_0x1199b5;}Vc(_0x39e2c0=>({..._0x39e2c0,'get':(_0x105e49,_0x4c80e7,_0x29ef43)=>Ms(_0x105e49,_0x4c80e7)||_0x39e2c0['get'](_0x105e49,_0x4c80e7,_0x29ef43),'has':(_0x391487,_0x4d8174)=>!!Ms(_0x391487,_0x4d8174)||_0x39e2c0['has'](_0x391487,_0x4d8174)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0xa350db){this['container']=_0xa350db;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x926b8d=>{if(Kc(_0x926b8d)){const _0x47082a=_0x926b8d['getImmediate']();return _0x47082a['library']+'/'+_0x47082a['version'];}else return null;})['filter'](_0x251a14=>_0x251a14)['join']('\x20');}}function Kc(_0x4563f3){const _0x2abcaf=_0x4563f3['getComponent']();return(_0x2abcaf==null?void 0x0:_0x2abcaf['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x1fb990,_0x137d4d){try{_0x1fb990['container']['addComponent'](_0x137d4d);}catch(_0x240207){oe['debug']('Component\x20'+_0x137d4d['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x1fb990['name'],_0x240207);}}function st(_0x53ee31){const _0x53b3ea=_0x53ee31['name'];if(Ei['has'](_0x53b3ea))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x53b3ea+'.'),!0x1;Ei['set'](_0x53b3ea,_0x53ee31);for(const _0x489504 of Ue['values']())xs(_0x489504,_0x53ee31);for(const _0x3bd660 of vi['values']())xs(_0x3bd660,_0x53ee31);return!0x0;}function Hi(_0x34da5c,_0x25808d){const _0x24d31f=_0x34da5c['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x24d31f&&_0x24d31f['triggerHeartbeat'](),_0x34da5c['container']['getProvider'](_0x25808d);}function $(_0x204ed3){return _0x204ed3==null?!0x1:_0x204ed3['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x535b08,_0x2fff1e,_0x5f3aa3){this['_isDeleted']=!0x1,this['_options']={..._0x535b08},this['_config']={..._0x2fff1e},this['_name']=_0x2fff1e['name'],this['_automaticDataCollectionEnabled']=_0x2fff1e['automaticDataCollectionEnabled'],this['_container']=_0x5f3aa3,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x4a4373){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x4a4373;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x23083b){this['_isDeleted']=_0x23083b;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x21f943,_0x30063a={}){let _0x259a2a=_0x21f943;typeof _0x30063a!='object'&&(_0x30063a={'name':_0x30063a});const _0x8d7978={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x30063a},_0xeca33e=_0x8d7978['name'];if(typeof _0xeca33e!='string'||!_0xeca33e)throw me['create']('bad-app-name',{'appName':String(_0xeca33e)});if(_0x259a2a||(_0x259a2a=zr()),!_0x259a2a)throw me['create']('no-options');const _0x5bb023=Ue['get'](_0xeca33e);if(_0x5bb023){if(xe(_0x259a2a,_0x5bb023['options'])&&xe(_0x8d7978,_0x5bb023['config']))return _0x5bb023;throw me['create']('duplicate-app',{'appName':_0xeca33e});}const _0x1c5773=new Nc(_0xeca33e);for(const _0x3fb8f4 of Ei['values']())_0x1c5773['addComponent'](_0x3fb8f4);const _0x4c2679=new Tl(_0x259a2a,_0x8d7978,_0x1c5773);return Ue['set'](_0xeca33e,_0x4c2679),_0x4c2679;}function Zr(_0x3f43a9=yi){const _0xc272d8=Ue['get'](_0x3f43a9);if(!_0xc272d8&&_0x3f43a9===yi&&zr())return Sl();if(!_0xc272d8)throw me['create']('no-app',{'appName':_0x3f43a9});return _0xc272d8;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x5665ae){let _0x321eeb=!0x1;const _0x1907f6=_0x5665ae['name'];Ue['has'](_0x1907f6)?(_0x321eeb=!0x0,Ue['delete'](_0x1907f6)):vi['has'](_0x1907f6)&&_0x5665ae['decRefCount']()<=0x0&&(vi['delete'](_0x1907f6),_0x321eeb=!0x0),_0x321eeb&&(await Promise['all'](_0x5665ae['container']['getProviders']()['map'](_0x247099=>_0x247099['delete']())),_0x5665ae['isDeleted']=!0x0);}function ye(_0x4d829d,_0x6187fb,_0x5b3991){let _0x3fd6f1=wl[_0x4d829d]??_0x4d829d;_0x5b3991&&(_0x3fd6f1+='-'+_0x5b3991);const _0x300799=_0x3fd6f1['match'](/\s|\//),_0x172ad7=_0x6187fb['match'](/\s|\//);if(_0x300799||_0x172ad7){const _0x1b24d7=['Unable\x20to\x20register\x20library\x20\x22'+_0x3fd6f1+'\x22\x20with\x20version\x20\x22'+_0x6187fb+'\x22:'];_0x300799&&_0x1b24d7['push']('library\x20name\x20\x22'+_0x3fd6f1+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x300799&&_0x172ad7&&_0x1b24d7['push']('and'),_0x172ad7&&_0x1b24d7['push']('version\x20name\x20\x22'+_0x6187fb+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x1b24d7['join']('\x20'));return;}st(new Fe(_0x3fd6f1+'-version',()=>({'library':_0x3fd6f1,'version':_0x6187fb}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x2ea4f4,_0x1a986c)=>{switch(_0x1a986c){case 0x0:try{_0x2ea4f4['createObjectStore'](Ot);}catch(_0x1c60b9){console['warn'](_0x1c60b9);}}}})['catch'](_0x5be5d9=>{throw me['create']('idb-open',{'originalErrorMessage':_0x5be5d9['message']});})),ri;}async function Al(_0x203c26){try{const _0x19f9d8=(await eo())['transaction'](Ot),_0x9ba717=await _0x19f9d8['objectStore'](Ot)['get'](to(_0x203c26));return await _0x19f9d8['done'],_0x9ba717;}catch(_0x482199){if(_0x482199 instanceof Re)oe['warn'](_0x482199['message']);else{const _0x140b61=me['create']('idb-get',{'originalErrorMessage':_0x482199==null?void 0x0:_0x482199['message']});oe['warn'](_0x140b61['message']);}}}async function Fs(_0x524937,_0x529587){try{const _0x19b6b1=(await eo())['transaction'](Ot,'readwrite');await _0x19b6b1['objectStore'](Ot)['put'](_0x529587,to(_0x524937)),await _0x19b6b1['done'];}catch(_0x3616a0){if(_0x3616a0 instanceof Re)oe['warn'](_0x3616a0['message']);else{const _0x94e9f3=me['create']('idb-set',{'originalErrorMessage':_0x3616a0==null?void 0x0:_0x3616a0['message']});oe['warn'](_0x94e9f3['message']);}}}function to(_0x34a3a4){return _0x34a3a4['name']+'!'+_0x34a3a4['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x5ac695){this['container']=_0x5ac695,this['_heartbeatsCache']=null;const _0x59c71e=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x59c71e),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x5781e3=>(this['_heartbeatsCache']=_0x5781e3,_0x5781e3));}async['triggerHeartbeat'](){var _0x46728e,_0x72d62d;try{const _0x4a1fb4=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x2e3197=Us();if(((_0x46728e=this['_heartbeatsCache'])==null?void 0x0:_0x46728e['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x72d62d=this['_heartbeatsCache'])==null?void 0x0:_0x72d62d['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x2e3197||this['_heartbeatsCache']['heartbeats']['some'](_0x5d12e2=>_0x5d12e2['date']===_0x2e3197))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x2e3197,'agent':_0x4a1fb4}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x3ab01d=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x3ab01d,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x55be2d){oe['warn'](_0x55be2d);}}async['getHeartbeatsHeader'](){var _0x21ec13;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x21ec13=this['_heartbeatsCache'])==null?void 0x0:_0x21ec13['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x5d27a3=Us(),{heartbeatsToSend:_0x523285,unsentEntries:_0x16e4d6}=Ol(this['_heartbeatsCache']['heartbeats']),_0x2a5805=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x523285}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x5d27a3,_0x16e4d6['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x16e4d6,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x2a5805;}catch(_0x3dd2e3){return oe['warn'](_0x3dd2e3),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x5a952e,_0x52b35c=kl){const _0x1aa371=[];let _0x59abd3=_0x5a952e['slice']();for(const _0x2b9012 of _0x5a952e){const _0x223195=_0x1aa371['find'](_0x3905d4=>_0x3905d4['agent']===_0x2b9012['agent']);if(_0x223195){if(_0x223195['dates']['push'](_0x2b9012['date']),Ws(_0x1aa371)>_0x52b35c){_0x223195['dates']['pop']();break;}}else{if(_0x1aa371['push']({'agent':_0x2b9012['agent'],'dates':[_0x2b9012['date']]}),Ws(_0x1aa371)>_0x52b35c){_0x1aa371['pop']();break;}}_0x59abd3=_0x59abd3['slice'](0x1);}return{'heartbeatsToSend':_0x1aa371,'unsentEntries':_0x59abd3};}class Dl{constructor(_0x290a1e){this['app']=_0x290a1e,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x3f746b=await Al(this['app']);return _0x3f746b!=null&&_0x3f746b['heartbeats']?_0x3f746b:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x32cd05){if(await this['_canUseIndexedDBPromise']){const _0x54f405=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x32cd05['lastSentHeartbeatDate']??_0x54f405['lastSentHeartbeatDate'],'heartbeats':_0x32cd05['heartbeats']});}else return;}async['add'](_0x482807){if(await this['_canUseIndexedDBPromise']){const _0x4982ac=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x482807['lastSentHeartbeatDate']??_0x4982ac['lastSentHeartbeatDate'],'heartbeats':[..._0x4982ac['heartbeats'],..._0x482807['heartbeats']]});}else return;}}function Ws(_0x3a0073){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x3a0073}))['length'];}function Ml(_0x2a73e5){if(_0x2a73e5['length']===0x0)return-0x1;let _0x44cfa4=0x0,_0x426d56=_0x2a73e5[0x0]['date'];for(let _0x4e1f7f=0x1;_0x4e1f7f<_0x2a73e5['length'];_0x4e1f7f++)_0x2a73e5[_0x4e1f7f]['date']<_0x426d56&&(_0x426d56=_0x2a73e5[_0x4e1f7f]['date'],_0x44cfa4=_0x4e1f7f);return _0x44cfa4;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x2d1f77){st(new Fe('platform-logger',_0x2799bf=>new jc(_0x2799bf),'PRIVATE')),st(new Fe('heartbeat',_0x585f4e=>new Nl(_0x585f4e),'PRIVATE')),ye(mi,Ls,_0x2d1f77),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x5e9741){no=_0x5e9741;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x276927){this['domStorage_']=_0x276927,this['prefix_']='firebase:';}['set'](_0x3a0e19,_0xb35401){_0xb35401==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x3a0e19)):this['domStorage_']['setItem'](this['prefixedName_'](_0x3a0e19),O(_0xb35401));}['get'](_0x36784c){const _0xd9001c=this['domStorage_']['getItem'](this['prefixedName_'](_0x36784c));return _0xd9001c==null?null:Nt(_0xd9001c);}['remove'](_0x4bb60f){this['domStorage_']['removeItem'](this['prefixedName_'](_0x4bb60f));}['prefixedName_'](_0x4153bd){return this['prefix_']+_0x4153bd;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x12edaf,_0x75a142){_0x75a142==null?delete this['cache_'][_0x12edaf]:this['cache_'][_0x12edaf]=_0x75a142;}['get'](_0x3d859e){return Q(this['cache_'],_0x3d859e)?this['cache_'][_0x3d859e]:null;}['remove'](_0x1abe18){delete this['cache_'][_0x1abe18];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x17855c){try{if(typeof window<'u'&&typeof window[_0x17855c]<'u'){const _0x62d7df=window[_0x17855c];return _0x62d7df['setItem']('firebase:sentinel','cache'),_0x62d7df['removeItem']('firebase:sentinel'),new Wl(_0x62d7df);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x371db9=0x1;return function(){return _0x371db9++;};}()),ro=function(_0x2ce469){const _0x42d77a=Rc(_0x2ce469),_0x462fde=new Cc();_0x462fde['update'](_0x42d77a);const _0x105093=_0x462fde['digest']();return Fi['encodeByteArray'](_0x105093);},zt=function(..._0x14f93c){let _0x36023a='';for(let _0x55ee40=0x0;_0x55ee40<_0x14f93c['length'];_0x55ee40++){const _0x5b5e49=_0x14f93c[_0x55ee40];Array['isArray'](_0x5b5e49)||_0x5b5e49&&typeof _0x5b5e49=='object'&&typeof _0x5b5e49['length']=='number'?_0x36023a+=zt['apply'](null,_0x5b5e49):typeof _0x5b5e49=='object'?_0x36023a+=O(_0x5b5e49):_0x36023a+=_0x5b5e49,_0x36023a+='\x20';}return _0x36023a;};let St=null,$s=!0x0;const Hl=function(_0x3e73e6,_0x580f58){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x26490b){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x2de71c=zt['apply'](null,_0x26490b);St(_0x2de71c);}},jt=function(_0xb22f98){return function(..._0x36341d){L(_0xb22f98,..._0x36341d);};},Ii=function(..._0x10ae1e){const _0x4be435='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x10ae1e);Ze['error'](_0x4be435);},ae=function(..._0x325aac){const _0x533a1b='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x325aac);throw Ze['error'](_0x533a1b),new Error(_0x533a1b);},U=function(..._0x2661dc){const _0x15add4='FIREBASE\x20WARNING:\x20'+zt(..._0x2661dc);Ze['warn'](_0x15add4);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x42ff58){return typeof _0x42ff58=='number'&&(_0x42ff58!==_0x42ff58||_0x42ff58===Number['POSITIVE_INFINITY']||_0x42ff58===Number['NEGATIVE_INFINITY']);},Gl=function(_0x557379){if(document['readyState']==='complete')_0x557379();else{let _0x3fd666=!0x1;const _0x4ba511=function(){if(!document['body']){setTimeout(_0x4ba511,Math['floor'](0xa));return;}_0x3fd666||(_0x3fd666=!0x0,_0x557379());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x4ba511,!0x1),window['addEventListener']('load',_0x4ba511,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x4ba511();}),window['attachEvent']('onload',_0x4ba511));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x635176,_0x5b0e5c){if(_0x635176===_0x5b0e5c)return 0x0;if(_0x635176===We||_0x5b0e5c===we)return-0x1;if(_0x5b0e5c===We||_0x635176===we)return 0x1;{const _0x4b58dc=Gs(_0x635176),_0x2c64a0=Gs(_0x5b0e5c);return _0x4b58dc!==null?_0x2c64a0!==null?_0x4b58dc-_0x2c64a0===0x0?_0x635176['length']-_0x5b0e5c['length']:_0x4b58dc-_0x2c64a0:-0x1:_0x2c64a0!==null?0x1:_0x635176<_0x5b0e5c?-0x1:0x1;}},ql=function(_0x1367f6,_0x3806c0){return _0x1367f6===_0x3806c0?0x0:_0x1367f6<_0x3806c0?-0x1:0x1;},vt=function(_0x404879,_0x765d38){if(_0x765d38&&_0x404879 in _0x765d38)return _0x765d38[_0x404879];throw new Error('Missing\x20required\x20key\x20('+_0x404879+')\x20in\x20object:\x20'+O(_0x765d38));},$i=function(_0x2e3921){if(typeof _0x2e3921!='object'||_0x2e3921===null)return O(_0x2e3921);const _0x4ae2b8=[];for(const _0x2a09fb in _0x2e3921)_0x4ae2b8['push'](_0x2a09fb);_0x4ae2b8['sort']();let _0x24ef37='{';for(let _0x1533ef=0x0;_0x1533ef<_0x4ae2b8['length'];_0x1533ef++)_0x1533ef!==0x0&&(_0x24ef37+=','),_0x24ef37+=O(_0x4ae2b8[_0x1533ef]),_0x24ef37+=':',_0x24ef37+=$i(_0x2e3921[_0x4ae2b8[_0x1533ef]]);return _0x24ef37+='}',_0x24ef37;},oo=function(_0x363f9b,_0x1a379b){const _0x1d2e68=_0x363f9b['length'];if(_0x1d2e68<=_0x1a379b)return[_0x363f9b];const _0x115fcc=[];for(let _0x2fd5c9=0x0;_0x2fd5c9<_0x1d2e68;_0x2fd5c9+=_0x1a379b)_0x2fd5c9+_0x1a379b>_0x1d2e68?_0x115fcc['push'](_0x363f9b['substring'](_0x2fd5c9,_0x1d2e68)):_0x115fcc['push'](_0x363f9b['substring'](_0x2fd5c9,_0x2fd5c9+_0x1a379b));return _0x115fcc;};function x(_0x20e7a6,_0x1b14c1){for(const _0x26bff3 in _0x20e7a6)_0x20e7a6['hasOwnProperty'](_0x26bff3)&&_0x1b14c1(_0x26bff3,_0x20e7a6[_0x26bff3]);}const ao=function(_0xb5779b){f(!xn(_0xb5779b),'Invalid\x20JSON\x20number');const _0x5d93db=0xb,_0x3d64be=0x34,_0x36a968=(0x1<<_0x5d93db-0x1)-0x1;let _0xd3bd15,_0x54362e,_0x368d08,_0x18da99,_0x35e274;_0xb5779b===0x0?(_0x54362e=0x0,_0x368d08=0x0,_0xd3bd15=0x1/_0xb5779b===-0x1/0x0?0x1:0x0):(_0xd3bd15=_0xb5779b<0x0,_0xb5779b=Math['abs'](_0xb5779b),_0xb5779b>=Math['pow'](0x2,0x1-_0x36a968)?(_0x18da99=Math['min'](Math['floor'](Math['log'](_0xb5779b)/Math['LN2']),_0x36a968),_0x54362e=_0x18da99+_0x36a968,_0x368d08=Math['round'](_0xb5779b*Math['pow'](0x2,_0x3d64be-_0x18da99)-Math['pow'](0x2,_0x3d64be))):(_0x54362e=0x0,_0x368d08=Math['round'](_0xb5779b/Math['pow'](0x2,0x1-_0x36a968-_0x3d64be))));const _0x330f07=[];for(_0x35e274=_0x3d64be;_0x35e274;_0x35e274-=0x1)_0x330f07['push'](_0x368d08%0x2?0x1:0x0),_0x368d08=Math['floor'](_0x368d08/0x2);for(_0x35e274=_0x5d93db;_0x35e274;_0x35e274-=0x1)_0x330f07['push'](_0x54362e%0x2?0x1:0x0),_0x54362e=Math['floor'](_0x54362e/0x2);_0x330f07['push'](_0xd3bd15?0x1:0x0),_0x330f07['reverse']();const _0x15bed8=_0x330f07['join']('');let _0x8bd282='';for(_0x35e274=0x0;_0x35e274<0x40;_0x35e274+=0x8){let _0x34812b=parseInt(_0x15bed8['substr'](_0x35e274,0x8),0x2)['toString'](0x10);_0x34812b['length']===0x1&&(_0x34812b='0'+_0x34812b),_0x8bd282=_0x8bd282+_0x34812b;}return _0x8bd282['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x36df3d,_0x314558){let _0x440ca8='Unknown\x20Error';_0x36df3d==='too_big'?_0x440ca8='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x36df3d==='permission_denied'?_0x440ca8='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x36df3d==='unavailable'&&(_0x440ca8='The\x20service\x20is\x20unavailable');const _0x4b6630=new Error(_0x36df3d+'\x20at\x20'+_0x314558['_path']['toString']()+':\x20'+_0x440ca8);return _0x4b6630['code']=_0x36df3d['toUpperCase'](),_0x4b6630;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x78c4d2){if(Yl['test'](_0x78c4d2)){const _0x3cad02=Number(_0x78c4d2);if(_0x3cad02>=Ql&&_0x3cad02<=Jl)return _0x3cad02;}return null;},ft=function(_0xe68e07){try{_0xe68e07();}catch(_0xc55528){setTimeout(()=>{const _0x3260c1=_0xc55528['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x3260c1),_0xc55528;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x557608,_0x502f26){const _0x53d06c=setTimeout(_0x557608,_0x502f26);return typeof _0x53d06c=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x53d06c):typeof _0x53d06c=='object'&&_0x53d06c['unref']&&_0x53d06c['unref'](),_0x53d06c;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x1fa8a7,_0x3358b1){this['appCheckProvider']=_0x3358b1,this['appName']=_0x1fa8a7['name'],$(_0x1fa8a7)&&_0x1fa8a7['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x1fa8a7['settings']['appCheckToken']),this['appCheck']=_0x3358b1==null?void 0x0:_0x3358b1['getImmediate']({'optional':!0x0}),this['appCheck']||_0x3358b1==null||_0x3358b1['get']()['then'](_0x16849b=>this['appCheck']=_0x16849b);}['getToken'](_0x3f9376){if(this['serverAppAppCheckToken']){if(_0x3f9376)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x3f9376):new Promise((_0x5a61a3,_0x12ce8b)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x3f9376)['then'](_0x5a61a3,_0x12ce8b):_0x5a61a3(null);},0x0);});}['addTokenChangeListener'](_0x143a3e){var _0x59eaaa;(_0x59eaaa=this['appCheckProvider'])==null||_0x59eaaa['get']()['then'](_0x524c3c=>_0x524c3c['addTokenListener'](_0x143a3e));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x23ba0a,_0x1975c6,_0x342cf1){this['appName_']=_0x23ba0a,this['firebaseOptions_']=_0x1975c6,this['authProvider_']=_0x342cf1,this['auth_']=null,this['auth_']=_0x342cf1['getImmediate']({'optional':!0x0}),this['auth_']||_0x342cf1['onInit'](_0x3dca2e=>this['auth_']=_0x3dca2e);}['getToken'](_0x3289b2){return this['auth_']?this['auth_']['getToken'](_0x3289b2)['catch'](_0x424537=>_0x424537&&_0x424537['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x424537)):new Promise((_0x4f7265,_0x19fa9b)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x3289b2)['then'](_0x4f7265,_0x19fa9b):_0x4f7265(null);},0x0);});}['addTokenChangeListener'](_0x297cd8){this['auth_']?this['auth_']['addAuthTokenListener'](_0x297cd8):this['authProvider_']['get']()['then'](_0x24f981=>_0x24f981['addAuthTokenListener'](_0x297cd8));}['removeTokenChangeListener'](_0x11404d){this['authProvider_']['get']()['then'](_0x80814f=>_0x80814f['removeAuthTokenListener'](_0x11404d));}['notifyForInvalidToken'](){let _0x9afcc4='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x9afcc4+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x9afcc4+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x9afcc4+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x9afcc4);}}class an{constructor(_0x273c62){this['accessToken']=_0x273c62;}['getToken'](_0x370c80){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x593c8a){_0x593c8a(this['accessToken']);}['removeTokenChangeListener'](_0x3b3ea7){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x208445,_0x3510bf,_0xc7f1e1,_0x3e59f2,_0x5159e1=!0x1,_0x35256f='',_0x5df612=!0x1,_0x55d86e=!0x1,_0x17464e=null){this['secure']=_0x3510bf,this['namespace']=_0xc7f1e1,this['webSocketOnly']=_0x3e59f2,this['nodeAdmin']=_0x5159e1,this['persistenceKey']=_0x35256f,this['includeNamespaceInQueryParams']=_0x5df612,this['isUsingEmulator']=_0x55d86e,this['emulatorOptions']=_0x17464e,this['_host']=_0x208445['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x208445)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x2a5a18){_0x2a5a18!==this['internalHost']&&(this['internalHost']=_0x2a5a18,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x5b5818=this['toURLString']();return this['persistenceKey']&&(_0x5b5818+='<'+this['persistenceKey']+'>'),_0x5b5818;}['toURLString'](){const _0x443bd4=this['secure']?'https://':'http://',_0x31653f=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x443bd4+this['host']+'/'+_0x31653f;}}function th(_0x18ef11){return _0x18ef11['host']!==_0x18ef11['internalHost']||_0x18ef11['isCustomHost']()||_0x18ef11['includeNamespaceInQueryParams'];}function vo(_0x4b2987,_0x1c214a,_0x510593){f(typeof _0x1c214a=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x510593=='object','typeof\x20params\x20must\x20==\x20object');let _0x2510a5;if(_0x1c214a===go)_0x2510a5=(_0x4b2987['secure']?'wss://':'ws://')+_0x4b2987['internalHost']+'/.ws?';else{if(_0x1c214a===mo)_0x2510a5=(_0x4b2987['secure']?'https://':'http://')+_0x4b2987['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x1c214a);}th(_0x4b2987)&&(_0x510593['ns']=_0x4b2987['namespace']);const _0x2625e1=[];return x(_0x510593,(_0x4db5a9,_0x5eca3e)=>{_0x2625e1['push'](_0x4db5a9+'='+_0x5eca3e);}),_0x2510a5+_0x2625e1['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x45307c,_0x311cf4=0x1){Q(this['counters_'],_0x45307c)||(this['counters_'][_0x45307c]=0x0),this['counters_'][_0x45307c]+=_0x311cf4;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x26496d){const _0x152f71=_0x26496d['toString']();return oi[_0x152f71]||(oi[_0x152f71]=new nh()),oi[_0x152f71];}function ih(_0x6bceb2,_0x5d7547){const _0x290af5=_0x6bceb2['toString']();return ai[_0x290af5]||(ai[_0x290af5]=_0x5d7547()),ai[_0x290af5];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x4bbc10){this['onMessage_']=_0x4bbc10,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x19c42c,_0xe67471){this['closeAfterResponse']=_0x19c42c,this['onClose']=_0xe67471,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x2a4b5d,_0x24debd){for(this['pendingResponses'][_0x2a4b5d]=_0x24debd;this['pendingResponses'][this['currentResponseNum']];){const _0x512f9e=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x15b49c=0x0;_0x15b49c<_0x512f9e['length'];++_0x15b49c)_0x512f9e[_0x15b49c]&&ft(()=>{this['onMessage_'](_0x512f9e[_0x15b49c]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x101312,_0x240130,_0x472e72,_0x24d300,_0x4c2d48,_0x1e68f6,_0x1ac8a7){this['connId']=_0x101312,this['repoInfo']=_0x240130,this['applicationId']=_0x472e72,this['appCheckToken']=_0x24d300,this['authToken']=_0x4c2d48,this['transportSessionId']=_0x1e68f6,this['lastSessionId']=_0x1ac8a7,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x101312),this['stats_']=qi(_0x240130),this['urlFn']=_0x123510=>(this['appCheckToken']&&(_0x123510[wi]=this['appCheckToken']),vo(_0x240130,mo,_0x123510));}['open'](_0x442849,_0x42ffe0){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x42ffe0,this['myPacketOrderer']=new sh(_0x442849),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x57afed)=>{const [_0x1f3943,_0x7857e2,_0x278c0c,_0x6b5c04,_0x45cbab]=_0x57afed;if(this['incrementIncomingBytes_'](_0x57afed),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x1f3943===qs)this['id']=_0x7857e2,this['password']=_0x278c0c;else{if(_0x1f3943===rh)_0x7857e2?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x7857e2,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x1f3943);}}},(..._0x4aafa5)=>{const [_0x4a5646,_0x5c91fa]=_0x4aafa5;this['incrementIncomingBytes_'](_0x4aafa5),this['myPacketOrderer']['handleResponse'](_0x4a5646,_0x5c91fa);},()=>{this['onClosed_']();},this['urlFn']);const _0x50e8ef={};_0x50e8ef[qs]='t',_0x50e8ef[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x50e8ef[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x50e8ef[co]=Gi,this['transportSessionId']&&(_0x50e8ef[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x50e8ef[po]=this['lastSessionId']),this['applicationId']&&(_0x50e8ef[_o]=this['applicationId']),this['appCheckToken']&&(_0x50e8ef[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x50e8ef[ho]=uo);const _0x2d11da=this['urlFn'](_0x50e8ef);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x2d11da),this['scriptTagHolder']['addTag'](_0x2d11da,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x2d8d0c){const _0x112029=O(_0x2d8d0c);this['bytesSent']+=_0x112029['length'],this['stats_']['incrementCounter']('bytes_sent',_0x112029['length']);const _0x244401=$r(_0x112029),_0x1ecc39=oo(_0x244401,fh);for(let _0x33fb41=0x0;_0x33fb41<_0x1ecc39['length'];_0x33fb41++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x1ecc39['length'],_0x1ecc39[_0x33fb41]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x84e07a,_0x9a722c){this['myDisconnFrame']=document['createElement']('iframe');const _0x56ccf7={};_0x56ccf7[dh]='t',_0x56ccf7[Eo]=_0x84e07a,_0x56ccf7[Io]=_0x9a722c,this['myDisconnFrame']['src']=this['urlFn'](_0x56ccf7),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x3b10f9){const _0x2c56ce=O(_0x3b10f9)['length'];this['bytesReceived']+=_0x2c56ce,this['stats_']['incrementCounter']('bytes_received',_0x2c56ce);}}class zi{constructor(_0x1b80b1,_0x139a25,_0xcf2ba7,_0x49e0a5){this['onDisconnect']=_0xcf2ba7,this['urlFn']=_0x49e0a5,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x1b80b1,window[ah+this['uniqueCallbackIdentifier']]=_0x139a25,this['myIFrame']=zi['createIFrame_']();let _0x2917c1='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x2917c1='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x4689a7='<html><body>'+_0x2917c1+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x4689a7),this['myIFrame']['doc']['close']();}catch(_0x50ad56){L('frame\x20writing\x20exception'),_0x50ad56['stack']&&L(_0x50ad56['stack']),L(_0x50ad56);}}}static['createIFrame_'](){const _0x1b0bae=document['createElement']('iframe');if(_0x1b0bae['style']['display']='none',document['body']){document['body']['appendChild'](_0x1b0bae);try{_0x1b0bae['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x13d031=document['domain'];_0x1b0bae['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x13d031+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x1b0bae['contentDocument']?_0x1b0bae['doc']=_0x1b0bae['contentDocument']:_0x1b0bae['contentWindow']?_0x1b0bae['doc']=_0x1b0bae['contentWindow']['document']:_0x1b0bae['document']&&(_0x1b0bae['doc']=_0x1b0bae['document']),_0x1b0bae;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x409646=this['onDisconnect'];_0x409646&&(this['onDisconnect']=null,_0x409646());}['startLongPoll'](_0x29100f,_0x5b4a7e){for(this['myID']=_0x29100f,this['myPW']=_0x5b4a7e,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x5e2da9={};_0x5e2da9[Eo]=this['myID'],_0x5e2da9[Io]=this['myPW'],_0x5e2da9[wo]=this['currentSerial'];let _0x59eff4=this['urlFn'](_0x5e2da9),_0x481279='',_0x179052=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x481279['length']<=Co;){const _0x480b46=this['pendingSegs']['shift']();_0x481279=_0x481279+'&'+lh+_0x179052+'='+_0x480b46['seg']+'&'+hh+_0x179052+'='+_0x480b46['ts']+'&'+uh+_0x179052+'='+_0x480b46['d'],_0x179052++;}return _0x59eff4=_0x59eff4+_0x481279,this['addLongPollTag_'](_0x59eff4,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x11df4e,_0x303ed1,_0x4ed017){this['pendingSegs']['push']({'seg':_0x11df4e,'ts':_0x303ed1,'d':_0x4ed017}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x2f08c6,_0x23656a){this['outstandingRequests']['add'](_0x23656a);const _0x2cf32e=()=>{this['outstandingRequests']['delete'](_0x23656a),this['newRequest_']();},_0x11fcca=setTimeout(_0x2cf32e,Math['floor'](ph)),_0x1fd810=()=>{clearTimeout(_0x11fcca),_0x2cf32e();};this['addTag'](_0x2f08c6,_0x1fd810);}['addTag'](_0x234ae4,_0x3d172a){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x4d8171=this['myIFrame']['doc']['createElement']('script');_0x4d8171['type']='text/javascript',_0x4d8171['async']=!0x0,_0x4d8171['src']=_0x234ae4,_0x4d8171['onload']=_0x4d8171['onreadystatechange']=function(){const _0x33eec6=_0x4d8171['readyState'];(!_0x33eec6||_0x33eec6==='loaded'||_0x33eec6==='complete')&&(_0x4d8171['onload']=_0x4d8171['onreadystatechange']=null,_0x4d8171['parentNode']&&_0x4d8171['parentNode']['removeChild'](_0x4d8171),_0x3d172a());},_0x4d8171['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x234ae4),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x4d8171);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x504a34,_0x1a74c2,_0x24e4f8,_0x3b244e,_0x1978ab,_0x427188,_0x4de5b6){this['connId']=_0x504a34,this['applicationId']=_0x24e4f8,this['appCheckToken']=_0x3b244e,this['authToken']=_0x1978ab,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x1a74c2),this['connURL']=q['connectionURL_'](_0x1a74c2,_0x427188,_0x4de5b6,_0x3b244e,_0x24e4f8),this['nodeAdmin']=_0x1a74c2['nodeAdmin'];}static['connectionURL_'](_0x56805b,_0x1e37c2,_0x4eddac,_0x2fa66e,_0x12bd0c){const _0x1b8288={};return _0x1b8288[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x1b8288[ho]=uo),_0x1e37c2&&(_0x1b8288[lo]=_0x1e37c2),_0x4eddac&&(_0x1b8288[po]=_0x4eddac),_0x2fa66e&&(_0x1b8288[wi]=_0x2fa66e),_0x12bd0c&&(_0x1b8288[_o]=_0x12bd0c),vo(_0x56805b,go,_0x1b8288);}['open'](_0x5a3da7,_0xb4dece){this['onDisconnect']=_0xb4dece,this['onMessage']=_0x5a3da7,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x4d97ff;_c(),this['mySock']=new gn(this['connURL'],[],_0x4d97ff);}catch(_0x58abad){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x19faad=_0x58abad['message']||_0x58abad['data'];_0x19faad&&this['log_'](_0x19faad),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x34284a=>{this['handleIncomingFrame'](_0x34284a);},this['mySock']['onerror']=_0x2703ba=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x3f3cdb=_0x2703ba['message']||_0x2703ba['data'];_0x3f3cdb&&this['log_'](_0x3f3cdb),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x59532a=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x11ec98=/Android ([0-9]{0,}\.[0-9]{0,})/,_0xcdf7c=navigator['userAgent']['match'](_0x11ec98);_0xcdf7c&&_0xcdf7c['length']>0x1&&parseFloat(_0xcdf7c[0x1])<4.4&&(_0x59532a=!0x0);}return!_0x59532a&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x3c66f1){if(this['frames']['push'](_0x3c66f1),this['frames']['length']===this['totalFrames']){const _0x363ea5=this['frames']['join']('');this['frames']=null;const _0x1fe1e9=Nt(_0x363ea5);this['onMessage'](_0x1fe1e9);}}['handleNewFrameCount_'](_0x2bb9ed){this['totalFrames']=_0x2bb9ed,this['frames']=[];}['extractFrameCount_'](_0x57e6b0){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x57e6b0['length']<=0x6){const _0x49215a=Number(_0x57e6b0);if(!isNaN(_0x49215a))return this['handleNewFrameCount_'](_0x49215a),null;}return this['handleNewFrameCount_'](0x1),_0x57e6b0;}['handleIncomingFrame'](_0x27f367){if(this['mySock']===null)return;const _0x4e496e=_0x27f367['data'];if(this['bytesReceived']+=_0x4e496e['length'],this['stats_']['incrementCounter']('bytes_received',_0x4e496e['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x4e496e);else{const _0x34e8a7=this['extractFrameCount_'](_0x4e496e);_0x34e8a7!==null&&this['appendFrame_'](_0x34e8a7);}}['send'](_0x4877ec){this['resetKeepAlive']();const _0x4d00c4=O(_0x4877ec);this['bytesSent']+=_0x4d00c4['length'],this['stats_']['incrementCounter']('bytes_sent',_0x4d00c4['length']);const _0x582e62=oo(_0x4d00c4,gh);_0x582e62['length']>0x1&&this['sendString_'](String(_0x582e62['length']));for(let _0x9fac91=0x0;_0x9fac91<_0x582e62['length'];_0x9fac91++)this['sendString_'](_0x582e62[_0x9fac91]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x340eac){try{this['mySock']['send'](_0x340eac);}catch(_0x397a92){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x397a92['message']||_0x397a92['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x54b9c1){this['initTransports_'](_0x54b9c1);}['initTransports_'](_0x591927){const _0x8b0a84=q&&q['isAvailable']();let _0x1dec83=_0x8b0a84&&!q['previouslyFailed']();if(_0x591927['webSocketOnly']&&(_0x8b0a84||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x1dec83=!0x0),_0x1dec83)this['transports_']=[q];else{const _0x25a4af=this['transports_']=[];for(const _0x36ed38 of Dt['ALL_TRANSPORTS'])_0x36ed38&&_0x36ed38['isAvailable']()&&_0x25a4af['push'](_0x36ed38);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x4e1476,_0x3a5632,_0x3ed72b,_0x3bb50a,_0x2a9b16,_0x44df07,_0xc69e73,_0x38e917,_0x2c528a,_0xa4373a){this['id']=_0x4e1476,this['repoInfo_']=_0x3a5632,this['applicationId_']=_0x3ed72b,this['appCheckToken_']=_0x3bb50a,this['authToken_']=_0x2a9b16,this['onMessage_']=_0x44df07,this['onReady_']=_0xc69e73,this['onDisconnect_']=_0x38e917,this['onKill_']=_0x2c528a,this['lastSessionId']=_0xa4373a,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x3a5632),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x3196b4=this['transportManager_']['initialTransport']();this['conn_']=new _0x3196b4(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x3196b4['responsesRequiredToBeHealthy']||0x0;const _0x48cbb1=this['connReceiver_'](this['conn_']),_0x2ad6ef=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x48cbb1,_0x2ad6ef);},Math['floor'](0x0));const _0x58d2cb=_0x3196b4['healthyTimeout']||0x0;_0x58d2cb>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x58d2cb)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x9f1575){return _0x25b78b=>{_0x9f1575===this['conn_']?this['onConnectionLost_'](_0x25b78b):_0x9f1575===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x3844bd){return _0x13a3a2=>{this['state_']!==0x2&&(_0x3844bd===this['rx_']?this['onPrimaryMessageReceived_'](_0x13a3a2):_0x3844bd===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x13a3a2):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x25a2f8){const _0x5d880a={'t':'d','d':_0x25a2f8};this['sendData_'](_0x5d880a);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x4f3400){if(ci in _0x4f3400){const _0x2ee0a2=_0x4f3400[ci];_0x2ee0a2===Ys?this['upgradeIfSecondaryHealthy_']():_0x2ee0a2===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x2ee0a2===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x567b31){const _0x1e3377=vt('t',_0x567b31),_0x3ccf04=vt('d',_0x567b31);if(_0x1e3377==='c')this['onSecondaryControl_'](_0x3ccf04);else{if(_0x1e3377==='d')this['pendingDataMessages']['push'](_0x3ccf04);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x1e3377);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x178b48){const _0x51de2c=vt('t',_0x178b48),_0x3af149=vt('d',_0x178b48);_0x51de2c==='c'?this['onControl_'](_0x3af149):_0x51de2c==='d'&&this['onDataMessage_'](_0x3af149);}['onDataMessage_'](_0x40c58b){this['onPrimaryResponse_'](),this['onMessage_'](_0x40c58b);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x405a09){const _0x30799e=vt(ci,_0x405a09);if(zs in _0x405a09){const _0x26fa08=_0x405a09[zs];if(_0x30799e===Th){const _0x452521={..._0x26fa08};this['repoInfo_']['isUsingEmulator']&&(_0x452521['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x452521);}else{if(_0x30799e===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x1ac39c=0x0;_0x1ac39c<this['pendingDataMessages']['length'];++_0x1ac39c)this['onDataMessage_'](this['pendingDataMessages'][_0x1ac39c]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x30799e===wh?this['onConnectionShutdown_'](_0x26fa08):_0x30799e===js?this['onReset_'](_0x26fa08):_0x30799e===Ch?Ii('Server\x20Error:\x20'+_0x26fa08):_0x30799e===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x30799e);}}}['onHandshake_'](_0x228ff3){const _0x38cf4f=_0x228ff3['ts'],_0x1335d5=_0x228ff3['v'],_0x23943d=_0x228ff3['h'];this['sessionId']=_0x228ff3['s'],this['repoInfo_']['host']=_0x23943d,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x38cf4f),Gi!==_0x1335d5&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x5c5db4=this['transportManager_']['upgradeTransport']();_0x5c5db4&&this['startUpgrade_'](_0x5c5db4);}['startUpgrade_'](_0xb0e02f){this['secondaryConn_']=new _0xb0e02f(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0xb0e02f['responsesRequiredToBeHealthy']||0x0;const _0x57baa4=this['connReceiver_'](this['secondaryConn_']),_0x5d18d3=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x57baa4,_0x5d18d3),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x34f834){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x34f834),this['repoInfo_']['host']=_0x34f834,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x514e90,_0x1dc8c3){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x514e90,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x1dc8c3,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x366c27=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x366c27||this['rx_']===_0x366c27)&&this['close']();}['onConnectionLost_'](_0x394d34){this['conn_']=null,!_0x394d34&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x480972){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x480972),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x2d2e28){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x2d2e28);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x1d4665,_0x2ad4bb,_0x3e59d8,_0x34c29b){}['merge'](_0x34fc94,_0xe761dc,_0x4eaed2,_0x19cbd3){}['refreshAuthToken'](_0x1734d2){}['refreshAppCheckToken'](_0x526ba0){}['onDisconnectPut'](_0x60941b,_0x4b73f3,_0x14a7bf){}['onDisconnectMerge'](_0x5de8d0,_0x23bb7c,_0x3c684c){}['onDisconnectCancel'](_0x3e8699,_0x12aa61){}['reportStats'](_0x28b7d9){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x3db00c){this['allowedEvents_']=_0x3db00c,this['listeners_']={},f(Array['isArray'](_0x3db00c)&&_0x3db00c['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x7a9f5d,..._0x4fa5a){if(Array['isArray'](this['listeners_'][_0x7a9f5d])){const _0x3c4143=[...this['listeners_'][_0x7a9f5d]];for(let _0x4a5463=0x0;_0x4a5463<_0x3c4143['length'];_0x4a5463++)_0x3c4143[_0x4a5463]['callback']['apply'](_0x3c4143[_0x4a5463]['context'],_0x4fa5a);}}['on'](_0x51af4e,_0x3f7b6e,_0x2fbfb8){this['validateEventType_'](_0x51af4e),this['listeners_'][_0x51af4e]=this['listeners_'][_0x51af4e]||[],this['listeners_'][_0x51af4e]['push']({'callback':_0x3f7b6e,'context':_0x2fbfb8});const _0x3142e6=this['getInitialEvent'](_0x51af4e);_0x3142e6&&_0x3f7b6e['apply'](_0x2fbfb8,_0x3142e6);}['off'](_0x5ae372,_0x183b7a,_0x3ed741){this['validateEventType_'](_0x5ae372);const _0x559fdf=this['listeners_'][_0x5ae372]||[];for(let _0x56dbf3=0x0;_0x56dbf3<_0x559fdf['length'];_0x56dbf3++)if(_0x559fdf[_0x56dbf3]['callback']===_0x183b7a&&(!_0x3ed741||_0x3ed741===_0x559fdf[_0x56dbf3]['context'])){_0x559fdf['splice'](_0x56dbf3,0x1);return;}}['validateEventType_'](_0x40f046){f(this['allowedEvents_']['find'](_0x352115=>_0x352115===_0x40f046),'Unknown\x20event:\x20'+_0x40f046);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x3af8bf){return f(_0x3af8bf==='online','Unknown\x20event\x20type:\x20'+_0x3af8bf),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x3e1ffe,_0xcaa73f){if(_0xcaa73f===void 0x0){this['pieces_']=_0x3e1ffe['split']('/');let _0xdfc03=0x0;for(let _0x13a44d=0x0;_0x13a44d<this['pieces_']['length'];_0x13a44d++)this['pieces_'][_0x13a44d]['length']>0x0&&(this['pieces_'][_0xdfc03]=this['pieces_'][_0x13a44d],_0xdfc03++);this['pieces_']['length']=_0xdfc03,this['pieceNum_']=0x0;}else this['pieces_']=_0x3e1ffe,this['pieceNum_']=_0xcaa73f;}['toString'](){let _0x44aaa5='';for(let _0x3c0800=this['pieceNum_'];_0x3c0800<this['pieces_']['length'];_0x3c0800++)this['pieces_'][_0x3c0800]!==''&&(_0x44aaa5+='/'+this['pieces_'][_0x3c0800]);return _0x44aaa5||'/';}}function w(){return new C('');}function y(_0x513379){return _0x513379['pieceNum_']>=_0x513379['pieces_']['length']?null:_0x513379['pieces_'][_0x513379['pieceNum_']];}function Ce(_0x2767c2){return _0x2767c2['pieces_']['length']-_0x2767c2['pieceNum_'];}function S(_0xf7d7e1){let _0x4c541d=_0xf7d7e1['pieceNum_'];return _0x4c541d<_0xf7d7e1['pieces_']['length']&&_0x4c541d++,new C(_0xf7d7e1['pieces_'],_0x4c541d);}function ji(_0xafb25f){return _0xafb25f['pieceNum_']<_0xafb25f['pieces_']['length']?_0xafb25f['pieces_'][_0xafb25f['pieces_']['length']-0x1]:null;}function bh(_0x30ede8){let _0xf1acd3='';for(let _0x2ee699=_0x30ede8['pieceNum_'];_0x2ee699<_0x30ede8['pieces_']['length'];_0x2ee699++)_0x30ede8['pieces_'][_0x2ee699]!==''&&(_0xf1acd3+='/'+encodeURIComponent(String(_0x30ede8['pieces_'][_0x2ee699])));return _0xf1acd3||'/';}function Mt(_0x16b747,_0x5746da=0x0){return _0x16b747['pieces_']['slice'](_0x16b747['pieceNum_']+_0x5746da);}function Ro(_0x448617){if(_0x448617['pieceNum_']>=_0x448617['pieces_']['length'])return null;const _0x1a7390=[];for(let _0x10eeb1=_0x448617['pieceNum_'];_0x10eeb1<_0x448617['pieces_']['length']-0x1;_0x10eeb1++)_0x1a7390['push'](_0x448617['pieces_'][_0x10eeb1]);return new C(_0x1a7390,0x0);}function k(_0x2d14b2,_0x597544){const _0x4ccd94=[];for(let _0x6d3deb=_0x2d14b2['pieceNum_'];_0x6d3deb<_0x2d14b2['pieces_']['length'];_0x6d3deb++)_0x4ccd94['push'](_0x2d14b2['pieces_'][_0x6d3deb]);if(_0x597544 instanceof C){for(let _0x31b9a9=_0x597544['pieceNum_'];_0x31b9a9<_0x597544['pieces_']['length'];_0x31b9a9++)_0x4ccd94['push'](_0x597544['pieces_'][_0x31b9a9]);}else{const _0x422f59=_0x597544['split']('/');for(let _0x3fa20c=0x0;_0x3fa20c<_0x422f59['length'];_0x3fa20c++)_0x422f59[_0x3fa20c]['length']>0x0&&_0x4ccd94['push'](_0x422f59[_0x3fa20c]);}return new C(_0x4ccd94,0x0);}function v(_0x592827){return _0x592827['pieceNum_']>=_0x592827['pieces_']['length'];}function F(_0x7cacd,_0xa76aa){const _0x4a4fdc=y(_0x7cacd),_0x19d807=y(_0xa76aa);if(_0x4a4fdc===null)return _0xa76aa;if(_0x4a4fdc===_0x19d807)return F(S(_0x7cacd),S(_0xa76aa));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0xa76aa+')\x20is\x20not\x20within\x20outerPath\x20('+_0x7cacd+')');}function Rh(_0x1dd422,_0x12c5d3){const _0x2f0f70=Mt(_0x1dd422,0x0),_0x48cbf4=Mt(_0x12c5d3,0x0);for(let _0x5e36d8=0x0;_0x5e36d8<_0x2f0f70['length']&&_0x5e36d8<_0x48cbf4['length'];_0x5e36d8++){const _0x8a110c=qe(_0x2f0f70[_0x5e36d8],_0x48cbf4[_0x5e36d8]);if(_0x8a110c!==0x0)return _0x8a110c;}return _0x2f0f70['length']===_0x48cbf4['length']?0x0:_0x2f0f70['length']<_0x48cbf4['length']?-0x1:0x1;}function Ki(_0x2a3cfa,_0x590c8c){if(Ce(_0x2a3cfa)!==Ce(_0x590c8c))return!0x1;for(let _0x192a0e=_0x2a3cfa['pieceNum_'],_0x2ee872=_0x590c8c['pieceNum_'];_0x192a0e<=_0x2a3cfa['pieces_']['length'];_0x192a0e++,_0x2ee872++)if(_0x2a3cfa['pieces_'][_0x192a0e]!==_0x590c8c['pieces_'][_0x2ee872])return!0x1;return!0x0;}function G(_0xad637e,_0x1412aa){let _0x5522e3=_0xad637e['pieceNum_'],_0x14ce42=_0x1412aa['pieceNum_'];if(Ce(_0xad637e)>Ce(_0x1412aa))return!0x1;for(;_0x5522e3<_0xad637e['pieces_']['length'];){if(_0xad637e['pieces_'][_0x5522e3]!==_0x1412aa['pieces_'][_0x14ce42])return!0x1;++_0x5522e3,++_0x14ce42;}return!0x0;}class Ah{constructor(_0x3dbf95,_0x37f062){this['errorPrefix_']=_0x37f062,this['parts_']=Mt(_0x3dbf95,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x1d9eff=0x0;_0x1d9eff<this['parts_']['length'];_0x1d9eff++)this['byteLength_']+=Ln(this['parts_'][_0x1d9eff]);Ao(this);}}function kh(_0xb24b67,_0x138973){_0xb24b67['parts_']['length']>0x0&&(_0xb24b67['byteLength_']+=0x1),_0xb24b67['parts_']['push'](_0x138973),_0xb24b67['byteLength_']+=Ln(_0x138973),Ao(_0xb24b67);}function Ph(_0x38fc3f){const _0x7b84d3=_0x38fc3f['parts_']['pop']();_0x38fc3f['byteLength_']-=Ln(_0x7b84d3),_0x38fc3f['parts_']['length']>0x0&&(_0x38fc3f['byteLength_']-=0x1);}function Ao(_0x321979){if(_0x321979['byteLength_']>Zs)throw new Error(_0x321979['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x321979['byteLength_']+').');if(_0x321979['parts_']['length']>Xs)throw new Error(_0x321979['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x321979));}function Oe(_0x5e1960){return _0x5e1960['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x5e1960['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x4190dd,_0x92eed6;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x92eed6='visibilitychange',_0x4190dd='hidden'):typeof document['mozHidden']<'u'?(_0x92eed6='mozvisibilitychange',_0x4190dd='mozHidden'):typeof document['msHidden']<'u'?(_0x92eed6='msvisibilitychange',_0x4190dd='msHidden'):typeof document['webkitHidden']<'u'&&(_0x92eed6='webkitvisibilitychange',_0x4190dd='webkitHidden')),this['visible_']=!0x0,_0x92eed6&&document['addEventListener'](_0x92eed6,()=>{const _0x103600=!document[_0x4190dd];_0x103600!==this['visible_']&&(this['visible_']=_0x103600,this['trigger']('visible',_0x103600));},!0x1);}['getInitialEvent'](_0x4e8289){return f(_0x4e8289==='visible','Unknown\x20event\x20type:\x20'+_0x4e8289),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x5d16bf,_0x179cd6,_0x2e3b22,_0x3c4259,_0x2cb4f8,_0x2a5bd8,_0xa5f483,_0x1f631f){if(super(),this['repoInfo_']=_0x5d16bf,this['applicationId_']=_0x179cd6,this['onDataUpdate_']=_0x2e3b22,this['onConnectStatus_']=_0x3c4259,this['onServerInfoUpdate_']=_0x2cb4f8,this['authTokenProvider_']=_0x2a5bd8,this['appCheckTokenProvider_']=_0xa5f483,this['authOverride_']=_0x1f631f,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x1f631f)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x5d16bf['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x409fe2,_0x24ce98,_0x19e7be){const _0x526609=++this['requestNumber_'],_0xc3d129={'r':_0x526609,'a':_0x409fe2,'b':_0x24ce98};this['log_'](O(_0xc3d129)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0xc3d129),_0x19e7be&&(this['requestCBHash_'][_0x526609]=_0x19e7be);}['get'](_0x4f189d){this['initConnection_']();const _0x2f25d5=new H(),_0xd89fd0={'action':'g','request':{'p':_0x4f189d['_path']['toString'](),'q':_0x4f189d['_queryObject']},'onComplete':_0x668fe5=>{const _0x549e9a=_0x668fe5['d'];_0x668fe5['s']==='ok'?_0x2f25d5['resolve'](_0x549e9a):_0x2f25d5['reject'](_0x549e9a);}};this['outstandingGets_']['push'](_0xd89fd0),this['outstandingGetCount_']++;const _0x4e30f2=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x4e30f2),_0x2f25d5['promise'];}['listen'](_0x4608da,_0x8e0249,_0x2caa89,_0x4d523d){this['initConnection_']();const _0x5284dd=_0x4608da['_queryIdentifier'],_0x4d3eeb=_0x4608da['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x4d3eeb+'\x20'+_0x5284dd),this['listens']['has'](_0x4d3eeb)||this['listens']['set'](_0x4d3eeb,new Map()),f(_0x4608da['_queryParams']['isDefault']()||!_0x4608da['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x4d3eeb)['has'](_0x5284dd),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x18a065={'onComplete':_0x4d523d,'hashFn':_0x8e0249,'query':_0x4608da,'tag':_0x2caa89};this['listens']['get'](_0x4d3eeb)['set'](_0x5284dd,_0x18a065),this['connected_']&&this['sendListen_'](_0x18a065);}['sendGet_'](_0x4bd9e4){const _0x2d7bb2=this['outstandingGets_'][_0x4bd9e4];this['sendRequest']('g',_0x2d7bb2['request'],_0x4c577c=>{delete this['outstandingGets_'][_0x4bd9e4],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x2d7bb2['onComplete']&&_0x2d7bb2['onComplete'](_0x4c577c);});}['sendListen_'](_0x22efb3){const _0xd099f0=_0x22efb3['query'],_0x1875f7=_0xd099f0['_path']['toString'](),_0x44a821=_0xd099f0['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x1875f7+'\x20for\x20'+_0x44a821);const _0x37dbad={'p':_0x1875f7},_0x3011f1='q';_0x22efb3['tag']&&(_0x37dbad['q']=_0xd099f0['_queryObject'],_0x37dbad['t']=_0x22efb3['tag']),_0x37dbad['h']=_0x22efb3['hashFn'](),this['sendRequest'](_0x3011f1,_0x37dbad,_0x1a180f=>{const _0x4f703c=_0x1a180f['d'],_0x336b21=_0x1a180f['s'];se['warnOnListenWarnings_'](_0x4f703c,_0xd099f0),(this['listens']['get'](_0x1875f7)&&this['listens']['get'](_0x1875f7)['get'](_0x44a821))===_0x22efb3&&(this['log_']('listen\x20response',_0x1a180f),_0x336b21!=='ok'&&this['removeListen_'](_0x1875f7,_0x44a821),_0x22efb3['onComplete']&&_0x22efb3['onComplete'](_0x336b21,_0x4f703c));});}static['warnOnListenWarnings_'](_0xd294c3,_0x550bbf){if(_0xd294c3&&typeof _0xd294c3=='object'&&Q(_0xd294c3,'w')){const _0x4eb95e=Le(_0xd294c3,'w');if(Array['isArray'](_0x4eb95e)&&~_0x4eb95e['indexOf']('no_index')){const _0x4fefdd='\x22.indexOn\x22:\x20\x22'+_0x550bbf['_queryParams']['getIndex']()['toString']()+'\x22',_0x47f7de=_0x550bbf['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x4fefdd+'\x20at\x20'+_0x47f7de+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x106f33){this['authToken_']=_0x106f33,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x106f33);}['reduceReconnectDelayIfAdminCredential_'](_0x1e29b0){(_0x1e29b0&&_0x1e29b0['length']===0x28||wc(_0x1e29b0))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x395a60){this['appCheckToken_']=_0x395a60,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x50ade3=this['authToken_'],_0x5bfb37=Ic(_0x50ade3)?'auth':'gauth',_0x300022={'cred':_0x50ade3};this['authOverride_']===null?_0x300022['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x300022['authvar']=this['authOverride_']),this['sendRequest'](_0x5bfb37,_0x300022,_0x3300e1=>{const _0x56bdb0=_0x3300e1['s'],_0x16dc52=_0x3300e1['d']||'error';this['authToken_']===_0x50ade3&&(_0x56bdb0==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x56bdb0,_0x16dc52));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x1ff58e=>{const _0x5d4224=_0x1ff58e['s'],_0x22f195=_0x1ff58e['d']||'error';_0x5d4224==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x5d4224,_0x22f195);});}['unlisten'](_0xc2738f,_0x4ccf50){const _0x4517ab=_0xc2738f['_path']['toString'](),_0x3857a6=_0xc2738f['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x4517ab+'\x20'+_0x3857a6),f(_0xc2738f['_queryParams']['isDefault']()||!_0xc2738f['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x4517ab,_0x3857a6)&&this['connected_']&&this['sendUnlisten_'](_0x4517ab,_0x3857a6,_0xc2738f['_queryObject'],_0x4ccf50);}['sendUnlisten_'](_0xb398e5,_0x223818,_0x1f5a25,_0xa9a4b3){this['log_']('Unlisten\x20on\x20'+_0xb398e5+'\x20for\x20'+_0x223818);const _0x1a51c9={'p':_0xb398e5},_0x523fd4='n';_0xa9a4b3&&(_0x1a51c9['q']=_0x1f5a25,_0x1a51c9['t']=_0xa9a4b3),this['sendRequest'](_0x523fd4,_0x1a51c9);}['onDisconnectPut'](_0x437ab5,_0x570711,_0x152bc4){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x437ab5,_0x570711,_0x152bc4):this['onDisconnectRequestQueue_']['push']({'pathString':_0x437ab5,'action':'o','data':_0x570711,'onComplete':_0x152bc4});}['onDisconnectMerge'](_0x31e534,_0x57d94f,_0x4a16c1){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x31e534,_0x57d94f,_0x4a16c1):this['onDisconnectRequestQueue_']['push']({'pathString':_0x31e534,'action':'om','data':_0x57d94f,'onComplete':_0x4a16c1});}['onDisconnectCancel'](_0x24012f,_0x240aa7){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x24012f,null,_0x240aa7):this['onDisconnectRequestQueue_']['push']({'pathString':_0x24012f,'action':'oc','data':null,'onComplete':_0x240aa7});}['sendOnDisconnect_'](_0x906215,_0x106471,_0x57b4e3,_0x182518){const _0x5c3e2f={'p':_0x106471,'d':_0x57b4e3};this['log_']('onDisconnect\x20'+_0x906215,_0x5c3e2f),this['sendRequest'](_0x906215,_0x5c3e2f,_0x55015d=>{_0x182518&&setTimeout(()=>{_0x182518(_0x55015d['s'],_0x55015d['d']);},Math['floor'](0x0));});}['put'](_0x214598,_0x2ac95c,_0x434b00,_0x3f7d2c){this['putInternal']('p',_0x214598,_0x2ac95c,_0x434b00,_0x3f7d2c);}['merge'](_0x3b077c,_0x437019,_0xd50fd6,_0x572b9b){this['putInternal']('m',_0x3b077c,_0x437019,_0xd50fd6,_0x572b9b);}['putInternal'](_0x3fbed1,_0x46e772,_0x39c207,_0x1f6f64,_0x3963dc){this['initConnection_']();const _0x55b67a={'p':_0x46e772,'d':_0x39c207};_0x3963dc!==void 0x0&&(_0x55b67a['h']=_0x3963dc),this['outstandingPuts_']['push']({'action':_0x3fbed1,'request':_0x55b67a,'onComplete':_0x1f6f64}),this['outstandingPutCount_']++;const _0x1e7a59=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x1e7a59):this['log_']('Buffering\x20put:\x20'+_0x46e772);}['sendPut_'](_0x4893b8){const _0x290d29=this['outstandingPuts_'][_0x4893b8]['action'],_0x220b5d=this['outstandingPuts_'][_0x4893b8]['request'],_0x4b3c75=this['outstandingPuts_'][_0x4893b8]['onComplete'];this['outstandingPuts_'][_0x4893b8]['queued']=this['connected_'],this['sendRequest'](_0x290d29,_0x220b5d,_0xf74888=>{this['log_'](_0x290d29+'\x20response',_0xf74888),delete this['outstandingPuts_'][_0x4893b8],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x4b3c75&&_0x4b3c75(_0xf74888['s'],_0xf74888['d']);});}['reportStats'](_0x430df0){if(this['connected_']){const _0x62261={'c':_0x430df0};this['log_']('reportStats',_0x62261),this['sendRequest']('s',_0x62261,_0x230639=>{if(_0x230639['s']!=='ok'){const _0x33c6b8=_0x230639['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x33c6b8);}});}}['onDataMessage_'](_0x38fcb6){if('r'in _0x38fcb6){this['log_']('from\x20server:\x20'+O(_0x38fcb6));const _0x1f045c=_0x38fcb6['r'],_0x4fbfe6=this['requestCBHash_'][_0x1f045c];_0x4fbfe6&&(delete this['requestCBHash_'][_0x1f045c],_0x4fbfe6(_0x38fcb6['b']));}else{if('error'in _0x38fcb6)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x38fcb6['error'];'a'in _0x38fcb6&&this['onDataPush_'](_0x38fcb6['a'],_0x38fcb6['b']);}}['onDataPush_'](_0x407927,_0x92e901){this['log_']('handleServerMessage',_0x407927,_0x92e901),_0x407927==='d'?this['onDataUpdate_'](_0x92e901['p'],_0x92e901['d'],!0x1,_0x92e901['t']):_0x407927==='m'?this['onDataUpdate_'](_0x92e901['p'],_0x92e901['d'],!0x0,_0x92e901['t']):_0x407927==='c'?this['onListenRevoked_'](_0x92e901['p'],_0x92e901['q']):_0x407927==='ac'?this['onAuthRevoked_'](_0x92e901['s'],_0x92e901['d']):_0x407927==='apc'?this['onAppCheckRevoked_'](_0x92e901['s'],_0x92e901['d']):_0x407927==='sd'?this['onSecurityDebugPacket_'](_0x92e901):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x407927)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x3a065d,_0x1f4360){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x3a065d),this['lastSessionId']=_0x1f4360,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x24fd67){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x24fd67));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x4140b2){_0x4140b2&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x4140b2;}['onOnline_'](_0x33d362){_0x33d362?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x1b766d=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x440e63=Math['max'](0x0,this['reconnectDelay_']-_0x1b766d);_0x440e63=Math['random']()*_0x440e63,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x440e63+'ms'),this['scheduleConnect_'](_0x440e63),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x209479=this['onDataMessage_']['bind'](this),_0x4c44c2=this['onReady_']['bind'](this),_0x1197e1=this['onRealtimeDisconnect_']['bind'](this),_0x14fb79=this['id']+':'+se['nextConnectionId_']++,_0x4d00fd=this['lastSessionId'];let _0x2489bb=!0x1,_0x2e501f=null;const _0xae60f9=function(){_0x2e501f?_0x2e501f['close']():(_0x2489bb=!0x0,_0x1197e1());},_0x4828ef=function(_0x24f857){f(_0x2e501f,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x2e501f['sendRequest'](_0x24f857);};this['realtime_']={'close':_0xae60f9,'sendRequest':_0x4828ef};const _0x3a6a61=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x5b3283,_0x267d7c]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x3a6a61),this['appCheckTokenProvider_']['getToken'](_0x3a6a61)]);_0x2489bb?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x5b3283&&_0x5b3283['accessToken'],this['appCheckToken_']=_0x267d7c&&_0x267d7c['token'],_0x2e501f=new Sh(_0x14fb79,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x209479,_0x4c44c2,_0x1197e1,_0x48206e=>{U(_0x48206e+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x4d00fd));}catch(_0x242776){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x242776),_0x2489bb||(this['repoInfo_']['nodeAdmin']&&U(_0x242776),_0xae60f9());}}}['interrupt'](_0xa49090){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0xa49090),this['interruptReasons_'][_0xa49090]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x3ad5a0){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x3ad5a0),delete this['interruptReasons_'][_0x3ad5a0],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0xd68b1b){const _0x3cabdf=_0xd68b1b-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x3cabdf});}['cancelSentTransactions_'](){for(let _0x5c93ce=0x0;_0x5c93ce<this['outstandingPuts_']['length'];_0x5c93ce++){const _0x4fe483=this['outstandingPuts_'][_0x5c93ce];_0x4fe483&&'h'in _0x4fe483['request']&&_0x4fe483['queued']&&(_0x4fe483['onComplete']&&_0x4fe483['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x5c93ce],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x5e586f,_0x573b5a){let _0x439978;_0x573b5a?_0x439978=_0x573b5a['map'](_0x85010b=>$i(_0x85010b))['join']('$'):_0x439978='default';const _0x31a411=this['removeListen_'](_0x5e586f,_0x439978);_0x31a411&&_0x31a411['onComplete']&&_0x31a411['onComplete']('permission_denied');}['removeListen_'](_0x4e5f2c,_0x4102a2){const _0x597eae=new C(_0x4e5f2c)['toString']();let _0x1234a2;if(this['listens']['has'](_0x597eae)){const _0x153030=this['listens']['get'](_0x597eae);_0x1234a2=_0x153030['get'](_0x4102a2),_0x153030['delete'](_0x4102a2),_0x153030['size']===0x0&&this['listens']['delete'](_0x597eae);}else _0x1234a2=void 0x0;return _0x1234a2;}['onAuthRevoked_'](_0x53fb48,_0x32ff7d){L('Auth\x20token\x20revoked:\x20'+_0x53fb48+'/'+_0x32ff7d),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x53fb48==='invalid_token'||_0x53fb48==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x1a48ec,_0x59906b){L('App\x20check\x20token\x20revoked:\x20'+_0x1a48ec+'/'+_0x59906b),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x1a48ec==='invalid_token'||_0x1a48ec==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x16152f){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x16152f):'msg'in _0x16152f&&console['log']('FIREBASE:\x20'+_0x16152f['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x23ae18 of this['listens']['values']())for(const _0x19db1f of _0x23ae18['values']())this['sendListen_'](_0x19db1f);for(let _0x4a9613=0x0;_0x4a9613<this['outstandingPuts_']['length'];_0x4a9613++)this['outstandingPuts_'][_0x4a9613]&&this['sendPut_'](_0x4a9613);for(;this['onDisconnectRequestQueue_']['length'];){const _0x495734=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x495734['action'],_0x495734['pathString'],_0x495734['data'],_0x495734['onComplete']);}for(let _0x3a29cf=0x0;_0x3a29cf<this['outstandingGets_']['length'];_0x3a29cf++)this['outstandingGets_'][_0x3a29cf]&&this['sendGet_'](_0x3a29cf);}['sendConnectStats_'](){const _0x259ef6={};let _0x265bd2='js';_0x259ef6['sdk.'+_0x265bd2+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x259ef6['framework.cordova']=0x1:Kr()&&(_0x259ef6['framework.reactnative']=0x1),this['reportStats'](_0x259ef6);}['shouldReconnect_'](){const _0x58f1e2=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x58f1e2;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x278a3c,_0x47183d){this['name']=_0x278a3c,this['node']=_0x47183d;}static['Wrap'](_0x41ae4c,_0x1a7d97){return new E(_0x41ae4c,_0x1a7d97);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0xbdeb01,_0x3ba587){const _0x5b7bcb=new E(We,_0xbdeb01),_0x4f1bc9=new E(We,_0x3ba587);return this['compare'](_0x5b7bcb,_0x4f1bc9)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x21cff4){sn=_0x21cff4;}['compare'](_0x4cf835,_0x42330c){return qe(_0x4cf835['name'],_0x42330c['name']);}['isDefinedOn'](_0x494a7f){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x391a73,_0x1fbc06){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x4a58c4,_0xd91593){return f(typeof _0x4a58c4=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x4a58c4,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x3a6fc0,_0x1b78a3,_0x1d614c,_0x149e91,_0x24a882=null){this['isReverse_']=_0x149e91,this['resultGenerator_']=_0x24a882,this['nodeStack_']=[];let _0x15a679=0x1;for(;!_0x3a6fc0['isEmpty']();)if(_0x3a6fc0=_0x3a6fc0,_0x15a679=_0x1b78a3?_0x1d614c(_0x3a6fc0['key'],_0x1b78a3):0x1,_0x149e91&&(_0x15a679*=-0x1),_0x15a679<0x0)this['isReverse_']?_0x3a6fc0=_0x3a6fc0['left']:_0x3a6fc0=_0x3a6fc0['right'];else{if(_0x15a679===0x0){this['nodeStack_']['push'](_0x3a6fc0);break;}else this['nodeStack_']['push'](_0x3a6fc0),this['isReverse_']?_0x3a6fc0=_0x3a6fc0['right']:_0x3a6fc0=_0x3a6fc0['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x18829d=this['nodeStack_']['pop'](),_0x89f8c1;if(this['resultGenerator_']?_0x89f8c1=this['resultGenerator_'](_0x18829d['key'],_0x18829d['value']):_0x89f8c1={'key':_0x18829d['key'],'value':_0x18829d['value']},this['isReverse_']){for(_0x18829d=_0x18829d['left'];!_0x18829d['isEmpty']();)this['nodeStack_']['push'](_0x18829d),_0x18829d=_0x18829d['right'];}else{for(_0x18829d=_0x18829d['right'];!_0x18829d['isEmpty']();)this['nodeStack_']['push'](_0x18829d),_0x18829d=_0x18829d['left'];}return _0x89f8c1;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x36c1d6=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x36c1d6['key'],_0x36c1d6['value']):{'key':_0x36c1d6['key'],'value':_0x36c1d6['value']};}}class M{constructor(_0x49ee18,_0x3830ba,_0x11e86c,_0x240b67,_0x5706cb){this['key']=_0x49ee18,this['value']=_0x3830ba,this['color']=_0x11e86c??M['RED'],this['left']=_0x240b67??B['EMPTY_NODE'],this['right']=_0x5706cb??B['EMPTY_NODE'];}['copy'](_0x39e126,_0x3eae02,_0x144ae1,_0x171eaf,_0x574852){return new M(_0x39e126??this['key'],_0x3eae02??this['value'],_0x144ae1??this['color'],_0x171eaf??this['left'],_0x574852??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x22fe5f){return this['left']['inorderTraversal'](_0x22fe5f)||!!_0x22fe5f(this['key'],this['value'])||this['right']['inorderTraversal'](_0x22fe5f);}['reverseTraversal'](_0x1bb9f3){return this['right']['reverseTraversal'](_0x1bb9f3)||_0x1bb9f3(this['key'],this['value'])||this['left']['reverseTraversal'](_0x1bb9f3);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x354f32,_0x2a32d9,_0x51a335){let _0x3c1b83=this;const _0x246062=_0x51a335(_0x354f32,_0x3c1b83['key']);return _0x246062<0x0?_0x3c1b83=_0x3c1b83['copy'](null,null,null,_0x3c1b83['left']['insert'](_0x354f32,_0x2a32d9,_0x51a335),null):_0x246062===0x0?_0x3c1b83=_0x3c1b83['copy'](null,_0x2a32d9,null,null,null):_0x3c1b83=_0x3c1b83['copy'](null,null,null,null,_0x3c1b83['right']['insert'](_0x354f32,_0x2a32d9,_0x51a335)),_0x3c1b83['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x50916c=this;return!_0x50916c['left']['isRed_']()&&!_0x50916c['left']['left']['isRed_']()&&(_0x50916c=_0x50916c['moveRedLeft_']()),_0x50916c=_0x50916c['copy'](null,null,null,_0x50916c['left']['removeMin_'](),null),_0x50916c['fixUp_']();}['remove'](_0x3a8651,_0x4ab932){let _0x48a6b1,_0x186ff8;if(_0x48a6b1=this,_0x4ab932(_0x3a8651,_0x48a6b1['key'])<0x0)!_0x48a6b1['left']['isEmpty']()&&!_0x48a6b1['left']['isRed_']()&&!_0x48a6b1['left']['left']['isRed_']()&&(_0x48a6b1=_0x48a6b1['moveRedLeft_']()),_0x48a6b1=_0x48a6b1['copy'](null,null,null,_0x48a6b1['left']['remove'](_0x3a8651,_0x4ab932),null);else{if(_0x48a6b1['left']['isRed_']()&&(_0x48a6b1=_0x48a6b1['rotateRight_']()),!_0x48a6b1['right']['isEmpty']()&&!_0x48a6b1['right']['isRed_']()&&!_0x48a6b1['right']['left']['isRed_']()&&(_0x48a6b1=_0x48a6b1['moveRedRight_']()),_0x4ab932(_0x3a8651,_0x48a6b1['key'])===0x0){if(_0x48a6b1['right']['isEmpty']())return B['EMPTY_NODE'];_0x186ff8=_0x48a6b1['right']['min_'](),_0x48a6b1=_0x48a6b1['copy'](_0x186ff8['key'],_0x186ff8['value'],null,null,_0x48a6b1['right']['removeMin_']());}_0x48a6b1=_0x48a6b1['copy'](null,null,null,null,_0x48a6b1['right']['remove'](_0x3a8651,_0x4ab932));}return _0x48a6b1['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x257b8f=this;return _0x257b8f['right']['isRed_']()&&!_0x257b8f['left']['isRed_']()&&(_0x257b8f=_0x257b8f['rotateLeft_']()),_0x257b8f['left']['isRed_']()&&_0x257b8f['left']['left']['isRed_']()&&(_0x257b8f=_0x257b8f['rotateRight_']()),_0x257b8f['left']['isRed_']()&&_0x257b8f['right']['isRed_']()&&(_0x257b8f=_0x257b8f['colorFlip_']()),_0x257b8f;}['moveRedLeft_'](){let _0x2a8574=this['colorFlip_']();return _0x2a8574['right']['left']['isRed_']()&&(_0x2a8574=_0x2a8574['copy'](null,null,null,null,_0x2a8574['right']['rotateRight_']()),_0x2a8574=_0x2a8574['rotateLeft_'](),_0x2a8574=_0x2a8574['colorFlip_']()),_0x2a8574;}['moveRedRight_'](){let _0x17d129=this['colorFlip_']();return _0x17d129['left']['left']['isRed_']()&&(_0x17d129=_0x17d129['rotateRight_'](),_0x17d129=_0x17d129['colorFlip_']()),_0x17d129;}['rotateLeft_'](){const _0x3db7a6=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x3db7a6,null);}['rotateRight_'](){const _0x367a0f=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x367a0f);}['colorFlip_'](){const _0x22e7a5=this['left']['copy'](null,null,!this['left']['color'],null,null),_0xc36bc6=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x22e7a5,_0xc36bc6);}['checkMaxDepth_'](){const _0x24e44e=this['check_']();return Math['pow'](0x2,_0x24e44e)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x398387=this['left']['check_']();if(_0x398387!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x398387+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x36074b,_0x427b56,_0x5384ce,_0x31fdd0,_0x44e700){return this;}['insert'](_0x10c976,_0x331f4a,_0x3ebce1){return new M(_0x10c976,_0x331f4a,null);}['remove'](_0x1664ab,_0x348bff){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x1c08cb){return!0x1;}['reverseTraversal'](_0x4d8835){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x462697,_0x1b1905=B['EMPTY_NODE']){this['comparator_']=_0x462697,this['root_']=_0x1b1905;}['insert'](_0x5ea5b2,_0x14de5f){return new B(this['comparator_'],this['root_']['insert'](_0x5ea5b2,_0x14de5f,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x454e44){return new B(this['comparator_'],this['root_']['remove'](_0x454e44,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x46a45d){let _0x5a7d09,_0x3d85ac=this['root_'];for(;!_0x3d85ac['isEmpty']();){if(_0x5a7d09=this['comparator_'](_0x46a45d,_0x3d85ac['key']),_0x5a7d09===0x0)return _0x3d85ac['value'];_0x5a7d09<0x0?_0x3d85ac=_0x3d85ac['left']:_0x5a7d09>0x0&&(_0x3d85ac=_0x3d85ac['right']);}return null;}['getPredecessorKey'](_0x4ad17c){let _0x4783a0,_0x58ae32=this['root_'],_0x29ea3d=null;for(;!_0x58ae32['isEmpty']();)if(_0x4783a0=this['comparator_'](_0x4ad17c,_0x58ae32['key']),_0x4783a0===0x0){if(_0x58ae32['left']['isEmpty']())return _0x29ea3d?_0x29ea3d['key']:null;for(_0x58ae32=_0x58ae32['left'];!_0x58ae32['right']['isEmpty']();)_0x58ae32=_0x58ae32['right'];return _0x58ae32['key'];}else _0x4783a0<0x0?_0x58ae32=_0x58ae32['left']:_0x4783a0>0x0&&(_0x29ea3d=_0x58ae32,_0x58ae32=_0x58ae32['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x19718e){return this['root_']['inorderTraversal'](_0x19718e);}['reverseTraversal'](_0x507b02){return this['root_']['reverseTraversal'](_0x507b02);}['getIterator'](_0x2aa5d1){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x2aa5d1);}['getIteratorFrom'](_0x2439ee,_0x2e7a4c){return new rn(this['root_'],_0x2439ee,this['comparator_'],!0x1,_0x2e7a4c);}['getReverseIteratorFrom'](_0x5d56ca,_0x5aa2ae){return new rn(this['root_'],_0x5d56ca,this['comparator_'],!0x0,_0x5aa2ae);}['getReverseIterator'](_0x46ff47){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x46ff47);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x18547e,_0x1d9ab8){return qe(_0x18547e['name'],_0x1d9ab8['name']);}function Qi(_0x464f41,_0x1ef59f){return qe(_0x464f41,_0x1ef59f);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x2c9175){Ci=_0x2c9175;}const Po=function(_0x1f49c2){return typeof _0x1f49c2=='number'?'number:'+ao(_0x1f49c2):'string:'+_0x1f49c2;},No=function(_0x4f27d7){if(_0x4f27d7['isLeafNode']()){const _0x231e21=_0x4f27d7['val']();f(typeof _0x231e21=='string'||typeof _0x231e21=='number'||typeof _0x231e21=='object'&&Q(_0x231e21,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x4f27d7===Ci||_0x4f27d7['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x4f27d7===Ci||_0x4f27d7['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x6cac88){nr=_0x6cac88;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x5e2be9,_0x4b02f4=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x5e2be9,this['priorityNode_']=_0x4b02f4,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x1b47d3){return new D(this['value_'],_0x1b47d3);}['getImmediateChild'](_0x95e406){return _0x95e406==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x1a0c33){return v(_0x1a0c33)?this:y(_0x1a0c33)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x5512a5,_0x11e0c2){return null;}['updateImmediateChild'](_0x26a2ab,_0x29e56d){return _0x26a2ab==='.priority'?this['updatePriority'](_0x29e56d):_0x29e56d['isEmpty']()&&_0x26a2ab!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x26a2ab,_0x29e56d)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x2d055f,_0x119c1e){const _0x5761ea=y(_0x2d055f);return _0x5761ea===null?_0x119c1e:_0x119c1e['isEmpty']()&&_0x5761ea!=='.priority'?this:(f(_0x5761ea!=='.priority'||Ce(_0x2d055f)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x5761ea,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x2d055f),_0x119c1e)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x5bde47,_0x594bd3){return!0x1;}['val'](_0x4a1dcc){return _0x4a1dcc&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x445ecd='';this['priorityNode_']['isEmpty']()||(_0x445ecd+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x296476=typeof this['value_'];_0x445ecd+=_0x296476+':',_0x296476==='number'?_0x445ecd+=ao(this['value_']):_0x445ecd+=this['value_'],this['lazyHash_']=ro(_0x445ecd);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x207828){return _0x207828===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x207828 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x207828['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x207828));}['compareToLeafNode_'](_0x23133a){const _0x5afe4a=typeof _0x23133a['value_'],_0x5b0cda=typeof this['value_'],_0x235742=D['VALUE_TYPE_ORDER']['indexOf'](_0x5afe4a),_0x403e68=D['VALUE_TYPE_ORDER']['indexOf'](_0x5b0cda);return f(_0x235742>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x5afe4a),f(_0x403e68>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x5b0cda),_0x235742===_0x403e68?_0x5b0cda==='object'?0x0:this['value_']<_0x23133a['value_']?-0x1:this['value_']===_0x23133a['value_']?0x0:0x1:_0x403e68-_0x235742;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x10ac5b){if(_0x10ac5b===this)return!0x0;if(_0x10ac5b['isLeafNode']()){const _0x552a59=_0x10ac5b;return this['value_']===_0x552a59['value_']&&this['priorityNode_']['equals'](_0x552a59['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x26daba){Oo=_0x26daba;}function Wh(_0x499616){Do=_0x499616;}class Bh extends Fn{['compare'](_0x2d45d7,_0x35cefa){const _0x854a6d=_0x2d45d7['node']['getPriority'](),_0xbb9b62=_0x35cefa['node']['getPriority'](),_0x4277e3=_0x854a6d['compareTo'](_0xbb9b62);return _0x4277e3===0x0?qe(_0x2d45d7['name'],_0x35cefa['name']):_0x4277e3;}['isDefinedOn'](_0x4dd1de){return!_0x4dd1de['getPriority']()['isEmpty']();}['indexedValueChanged'](_0xb79a75,_0x6c25b8){return!_0xb79a75['getPriority']()['equals'](_0x6c25b8['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x39c9d9,_0x42b6cf){const _0x2a51ac=Oo(_0x39c9d9);return new E(_0x42b6cf,new D('[PRIORITY-POST]',_0x2a51ac));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x3bd06d){const _0x5aeb89=_0x430ce2=>parseInt(Math['log'](_0x430ce2)/Vh,0xa),_0x2c66a7=_0x5adf23=>parseInt(Array(_0x5adf23+0x1)['join']('1'),0x2);this['count']=_0x5aeb89(_0x3bd06d+0x1),this['current_']=this['count']-0x1;const _0x1c5b61=_0x2c66a7(this['count']);this['bits_']=_0x3bd06d+0x1&_0x1c5b61;}['nextBitIsOne'](){const _0x545f5d=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x545f5d;}}const yn=function(_0x1be0e2,_0x1694cf,_0xdb9b4d,_0x3c9bfc){_0x1be0e2['sort'](_0x1694cf);const _0x324954=function(_0x1b374d,_0x1ec0e8){const _0x5aa41c=_0x1ec0e8-_0x1b374d;let _0x4d6c4e,_0x5d5631;if(_0x5aa41c===0x0)return null;if(_0x5aa41c===0x1)return _0x4d6c4e=_0x1be0e2[_0x1b374d],_0x5d5631=_0xdb9b4d?_0xdb9b4d(_0x4d6c4e):_0x4d6c4e,new M(_0x5d5631,_0x4d6c4e['node'],M['BLACK'],null,null);{const _0x38b105=parseInt(_0x5aa41c/0x2,0xa)+_0x1b374d,_0x5288e1=_0x324954(_0x1b374d,_0x38b105),_0xe230c8=_0x324954(_0x38b105+0x1,_0x1ec0e8);return _0x4d6c4e=_0x1be0e2[_0x38b105],_0x5d5631=_0xdb9b4d?_0xdb9b4d(_0x4d6c4e):_0x4d6c4e,new M(_0x5d5631,_0x4d6c4e['node'],M['BLACK'],_0x5288e1,_0xe230c8);}},_0x22e61a=function(_0x1c092c){let _0x2dbf9d=null,_0x3d8de8=null,_0x2e4b8e=_0x1be0e2['length'];const _0xe50dc8=function(_0x384480,_0x6173b6){const _0x1d56a0=_0x2e4b8e-_0x384480,_0xe580c5=_0x2e4b8e;_0x2e4b8e-=_0x384480;const _0x1485ba=_0x324954(_0x1d56a0+0x1,_0xe580c5),_0xc77e21=_0x1be0e2[_0x1d56a0],_0x34f6cf=_0xdb9b4d?_0xdb9b4d(_0xc77e21):_0xc77e21;_0x5eea73(new M(_0x34f6cf,_0xc77e21['node'],_0x6173b6,null,_0x1485ba));},_0x5eea73=function(_0x26b148){_0x2dbf9d?(_0x2dbf9d['left']=_0x26b148,_0x2dbf9d=_0x26b148):(_0x3d8de8=_0x26b148,_0x2dbf9d=_0x26b148);};for(let _0x585418=0x0;_0x585418<_0x1c092c['count'];++_0x585418){const _0x337ae8=_0x1c092c['nextBitIsOne'](),_0xdaeba7=Math['pow'](0x2,_0x1c092c['count']-(_0x585418+0x1));_0x337ae8?_0xe50dc8(_0xdaeba7,M['BLACK']):(_0xe50dc8(_0xdaeba7,M['BLACK']),_0xe50dc8(_0xdaeba7,M['RED']));}return _0x3d8de8;},_0x5dcaf4=new Hh(_0x1be0e2['length']),_0x286174=_0x22e61a(_0x5dcaf4);return new B(_0x3c9bfc||_0x1694cf,_0x286174);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x4f2dad,_0x1c9a2a){this['indexes_']=_0x4f2dad,this['indexSet_']=_0x1c9a2a;}['get'](_0x1b9be7){const _0x5878ef=Le(this['indexes_'],_0x1b9be7);if(!_0x5878ef)throw new Error('No\x20index\x20defined\x20for\x20'+_0x1b9be7);return _0x5878ef instanceof B?_0x5878ef:null;}['hasIndex'](_0x5c51ca){return Q(this['indexSet_'],_0x5c51ca['toString']());}['addIndex'](_0xa9a4ee,_0x2f4891){f(_0xa9a4ee!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x5d683f=[];let _0x1a0f62=!0x1;const _0x1ce23a=_0x2f4891['getIterator'](E['Wrap']);let _0x1513de=_0x1ce23a['getNext']();for(;_0x1513de;)_0x1a0f62=_0x1a0f62||_0xa9a4ee['isDefinedOn'](_0x1513de['node']),_0x5d683f['push'](_0x1513de),_0x1513de=_0x1ce23a['getNext']();let _0x45e3a1;_0x1a0f62?_0x45e3a1=yn(_0x5d683f,_0xa9a4ee['getCompare']()):_0x45e3a1=Qe;const _0x2a2e60=_0xa9a4ee['toString'](),_0x4fcbf7={...this['indexSet_']};_0x4fcbf7[_0x2a2e60]=_0xa9a4ee;const _0x138834={...this['indexes_']};return _0x138834[_0x2a2e60]=_0x45e3a1,new te(_0x138834,_0x4fcbf7);}['addToIndexes'](_0x5c7e7b,_0x15fc3a){const _0x2967a0=_n(this['indexes_'],(_0x27af73,_0x55bf27)=>{const _0x4e066c=Le(this['indexSet_'],_0x55bf27);if(f(_0x4e066c,'Missing\x20index\x20implementation\x20for\x20'+_0x55bf27),_0x27af73===Qe){if(_0x4e066c['isDefinedOn'](_0x5c7e7b['node'])){const _0x4b6fec=[],_0x53e86b=_0x15fc3a['getIterator'](E['Wrap']);let _0x432f34=_0x53e86b['getNext']();for(;_0x432f34;)_0x432f34['name']!==_0x5c7e7b['name']&&_0x4b6fec['push'](_0x432f34),_0x432f34=_0x53e86b['getNext']();return _0x4b6fec['push'](_0x5c7e7b),yn(_0x4b6fec,_0x4e066c['getCompare']());}else return Qe;}else{const _0x222e91=_0x15fc3a['get'](_0x5c7e7b['name']);let _0x3b246e=_0x27af73;return _0x222e91&&(_0x3b246e=_0x3b246e['remove'](new E(_0x5c7e7b['name'],_0x222e91))),_0x3b246e['insert'](_0x5c7e7b,_0x5c7e7b['node']);}});return new te(_0x2967a0,this['indexSet_']);}['removeFromIndexes'](_0x542144,_0xdcff33){const _0xe46de3=_n(this['indexes_'],_0x38ee4f=>{if(_0x38ee4f===Qe)return _0x38ee4f;{const _0x2eebb=_0xdcff33['get'](_0x542144['name']);return _0x2eebb?_0x38ee4f['remove'](new E(_0x542144['name'],_0x2eebb)):_0x38ee4f;}});return new te(_0xe46de3,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x4e2da1,_0x519d9c,_0x20eb45){this['children_']=_0x4e2da1,this['priorityNode_']=_0x519d9c,this['indexMap_']=_0x20eb45,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x49d20f){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x49d20f,this['indexMap_']);}['getImmediateChild'](_0x30dabd){if(_0x30dabd==='.priority')return this['getPriority']();{const _0x32a40d=this['children_']['get'](_0x30dabd);return _0x32a40d===null?It:_0x32a40d;}}['getChild'](_0xa4b109){const _0x384aac=y(_0xa4b109);return _0x384aac===null?this:this['getImmediateChild'](_0x384aac)['getChild'](S(_0xa4b109));}['hasChild'](_0x29a2d7){return this['children_']['get'](_0x29a2d7)!==null;}['updateImmediateChild'](_0x5d53d8,_0x46868c){if(f(_0x46868c,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x5d53d8==='.priority')return this['updatePriority'](_0x46868c);{const _0x53950b=new E(_0x5d53d8,_0x46868c);let _0x250cb0,_0x467ce6;_0x46868c['isEmpty']()?(_0x250cb0=this['children_']['remove'](_0x5d53d8),_0x467ce6=this['indexMap_']['removeFromIndexes'](_0x53950b,this['children_'])):(_0x250cb0=this['children_']['insert'](_0x5d53d8,_0x46868c),_0x467ce6=this['indexMap_']['addToIndexes'](_0x53950b,this['children_']));const _0x2e8277=_0x250cb0['isEmpty']()?It:this['priorityNode_'];return new g(_0x250cb0,_0x2e8277,_0x467ce6);}}['updateChild'](_0x38b4da,_0x1db64b){const _0x2e0173=y(_0x38b4da);if(_0x2e0173===null)return _0x1db64b;{f(y(_0x38b4da)!=='.priority'||Ce(_0x38b4da)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x4e188a=this['getImmediateChild'](_0x2e0173)['updateChild'](S(_0x38b4da),_0x1db64b);return this['updateImmediateChild'](_0x2e0173,_0x4e188a);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x28e63c){if(this['isEmpty']())return null;const _0x1ae926={};let _0x1ee74d=0x0,_0x5de510=0x0,_0x33ed40=!0x0;if(this['forEachChild'](R,(_0x809cd,_0x5bf4b6)=>{_0x1ae926[_0x809cd]=_0x5bf4b6['val'](_0x28e63c),_0x1ee74d++,_0x33ed40&&g['INTEGER_REGEXP_']['test'](_0x809cd)?_0x5de510=Math['max'](_0x5de510,Number(_0x809cd)):_0x33ed40=!0x1;}),!_0x28e63c&&_0x33ed40&&_0x5de510<0x2*_0x1ee74d){const _0x2981bd=[];for(const _0x382383 in _0x1ae926)_0x2981bd[_0x382383]=_0x1ae926[_0x382383];return _0x2981bd;}else return _0x28e63c&&!this['getPriority']()['isEmpty']()&&(_0x1ae926['.priority']=this['getPriority']()['val']()),_0x1ae926;}['hash'](){if(this['lazyHash_']===null){let _0x470f90='';this['getPriority']()['isEmpty']()||(_0x470f90+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x1f3828,_0x11ab39)=>{const _0x2c6f55=_0x11ab39['hash']();_0x2c6f55!==''&&(_0x470f90+=':'+_0x1f3828+':'+_0x2c6f55);}),this['lazyHash_']=_0x470f90===''?'':ro(_0x470f90);}return this['lazyHash_'];}['getPredecessorChildName'](_0x526134,_0x3cbca6,_0x131226){const _0x352a63=this['resolveIndex_'](_0x131226);if(_0x352a63){const _0x35aa6c=_0x352a63['getPredecessorKey'](new E(_0x526134,_0x3cbca6));return _0x35aa6c?_0x35aa6c['name']:null;}else return this['children_']['getPredecessorKey'](_0x526134);}['getFirstChildName'](_0x250c6a){const _0x246cc6=this['resolveIndex_'](_0x250c6a);if(_0x246cc6){const _0x47f836=_0x246cc6['minKey']();return _0x47f836&&_0x47f836['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x664b21){const _0x39c066=this['getFirstChildName'](_0x664b21);return _0x39c066?new E(_0x39c066,this['children_']['get'](_0x39c066)):null;}['getLastChildName'](_0x3f9dde){const _0x342ff5=this['resolveIndex_'](_0x3f9dde);if(_0x342ff5){const _0x26245c=_0x342ff5['maxKey']();return _0x26245c&&_0x26245c['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x3cd052){const _0x3cea12=this['getLastChildName'](_0x3cd052);return _0x3cea12?new E(_0x3cea12,this['children_']['get'](_0x3cea12)):null;}['forEachChild'](_0x31daf9,_0x521030){const _0xbdcc08=this['resolveIndex_'](_0x31daf9);return _0xbdcc08?_0xbdcc08['inorderTraversal'](_0x523f25=>_0x521030(_0x523f25['name'],_0x523f25['node'])):this['children_']['inorderTraversal'](_0x521030);}['getIterator'](_0x4406e1){return this['getIteratorFrom'](_0x4406e1['minPost'](),_0x4406e1);}['getIteratorFrom'](_0x51b14d,_0x1ec547){const _0x34c077=this['resolveIndex_'](_0x1ec547);if(_0x34c077)return _0x34c077['getIteratorFrom'](_0x51b14d,_0x59edac=>_0x59edac);{const _0x12eb00=this['children_']['getIteratorFrom'](_0x51b14d['name'],E['Wrap']);let _0x1eedd5=_0x12eb00['peek']();for(;_0x1eedd5!=null&&_0x1ec547['compare'](_0x1eedd5,_0x51b14d)<0x0;)_0x12eb00['getNext'](),_0x1eedd5=_0x12eb00['peek']();return _0x12eb00;}}['getReverseIterator'](_0x224a30){return this['getReverseIteratorFrom'](_0x224a30['maxPost'](),_0x224a30);}['getReverseIteratorFrom'](_0x15a74b,_0x1a47f6){const _0x252ccf=this['resolveIndex_'](_0x1a47f6);if(_0x252ccf)return _0x252ccf['getReverseIteratorFrom'](_0x15a74b,_0x44e58b=>_0x44e58b);{const _0x4323cf=this['children_']['getReverseIteratorFrom'](_0x15a74b['name'],E['Wrap']);let _0x308f16=_0x4323cf['peek']();for(;_0x308f16!=null&&_0x1a47f6['compare'](_0x308f16,_0x15a74b)>0x0;)_0x4323cf['getNext'](),_0x308f16=_0x4323cf['peek']();return _0x4323cf;}}['compareTo'](_0x217257){return this['isEmpty']()?_0x217257['isEmpty']()?0x0:-0x1:_0x217257['isLeafNode']()||_0x217257['isEmpty']()?0x1:_0x217257===Kt?-0x1:0x0;}['withIndex'](_0x51371d){if(_0x51371d===ve||this['indexMap_']['hasIndex'](_0x51371d))return this;{const _0x2d5d96=this['indexMap_']['addIndex'](_0x51371d,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x2d5d96);}}['isIndexed'](_0x508ee7){return _0x508ee7===ve||this['indexMap_']['hasIndex'](_0x508ee7);}['equals'](_0x3baf7b){if(_0x3baf7b===this)return!0x0;if(_0x3baf7b['isLeafNode']())return!0x1;{const _0x42355f=_0x3baf7b;if(this['getPriority']()['equals'](_0x42355f['getPriority']())){if(this['children_']['count']()===_0x42355f['children_']['count']()){const _0x4294ef=this['getIterator'](R),_0x4ccc72=_0x42355f['getIterator'](R);let _0x2ff8b3=_0x4294ef['getNext'](),_0x44c2c0=_0x4ccc72['getNext']();for(;_0x2ff8b3&&_0x44c2c0;){if(_0x2ff8b3['name']!==_0x44c2c0['name']||!_0x2ff8b3['node']['equals'](_0x44c2c0['node']))return!0x1;_0x2ff8b3=_0x4294ef['getNext'](),_0x44c2c0=_0x4ccc72['getNext']();}return _0x2ff8b3===null&&_0x44c2c0===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x127704){return _0x127704===ve?null:this['indexMap_']['get'](_0x127704['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0xa420ba){return _0xa420ba===this?0x0:0x1;}['equals'](_0x4d8df5){return _0x4d8df5===this;}['getPriority'](){return this;}['getImmediateChild'](_0x303471){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x48ace6,_0x72d33f=null){if(_0x48ace6===null)return g['EMPTY_NODE'];if(typeof _0x48ace6=='object'&&'.priority'in _0x48ace6&&(_0x72d33f=_0x48ace6['.priority']),f(_0x72d33f===null||typeof _0x72d33f=='string'||typeof _0x72d33f=='number'||typeof _0x72d33f=='object'&&'.sv'in _0x72d33f,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x72d33f),typeof _0x48ace6=='object'&&'.value'in _0x48ace6&&_0x48ace6['.value']!==null&&(_0x48ace6=_0x48ace6['.value']),typeof _0x48ace6!='object'||'.sv'in _0x48ace6){const _0x233f42=_0x48ace6;return new D(_0x233f42,A(_0x72d33f));}if(!(_0x48ace6 instanceof Array)&&Gh){const _0x439c74=[];let _0x47ae42=!0x1;if(x(_0x48ace6,(_0x5cdaf9,_0x2f7bc9)=>{if(_0x5cdaf9['substring'](0x0,0x1)!=='.'){const _0xaf906c=A(_0x2f7bc9);_0xaf906c['isEmpty']()||(_0x47ae42=_0x47ae42||!_0xaf906c['getPriority']()['isEmpty'](),_0x439c74['push'](new E(_0x5cdaf9,_0xaf906c)));}}),_0x439c74['length']===0x0)return g['EMPTY_NODE'];const _0x270c49=yn(_0x439c74,xh,_0x2dfe8f=>_0x2dfe8f['name'],Qi);if(_0x47ae42){const _0x4703d6=yn(_0x439c74,R['getCompare']());return new g(_0x270c49,A(_0x72d33f),new te({'.priority':_0x4703d6},{'.priority':R}));}else return new g(_0x270c49,A(_0x72d33f),te['Default']);}else{let _0x467c90=g['EMPTY_NODE'];return x(_0x48ace6,(_0x317fa9,_0x44048a)=>{if(Q(_0x48ace6,_0x317fa9)&&_0x317fa9['substring'](0x0,0x1)!=='.'){const _0x1a99d9=A(_0x44048a);(_0x1a99d9['isLeafNode']()||!_0x1a99d9['isEmpty']())&&(_0x467c90=_0x467c90['updateImmediateChild'](_0x317fa9,_0x1a99d9));}}),_0x467c90['updatePriority'](A(_0x72d33f));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x2f9af7){super(),this['indexPath_']=_0x2f9af7,f(!v(_0x2f9af7)&&y(_0x2f9af7)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x5426c4){return _0x5426c4['getChild'](this['indexPath_']);}['isDefinedOn'](_0x26bbd0){return!_0x26bbd0['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x2cb003,_0x475c5e){const _0x36afb5=this['extractChild'](_0x2cb003['node']),_0x37c640=this['extractChild'](_0x475c5e['node']),_0x2754b9=_0x36afb5['compareTo'](_0x37c640);return _0x2754b9===0x0?qe(_0x2cb003['name'],_0x475c5e['name']):_0x2754b9;}['makePost'](_0x1c2a8c,_0x2fa2d3){const _0x17297a=A(_0x1c2a8c),_0x55e545=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x17297a);return new E(_0x2fa2d3,_0x55e545);}['maxPost'](){const _0x4eafe4=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x4eafe4);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x8a3501,_0x443049){const _0xcb2104=_0x8a3501['node']['compareTo'](_0x443049['node']);return _0xcb2104===0x0?qe(_0x8a3501['name'],_0x443049['name']):_0xcb2104;}['isDefinedOn'](_0x4ede62){return!0x0;}['indexedValueChanged'](_0x341ec2,_0x246872){return!_0x341ec2['equals'](_0x246872);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x37e374,_0x494bb8){const _0x3389ef=A(_0x37e374);return new E(_0x494bb8,_0x3389ef);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x33be3f){return{'type':'value','snapshotNode':_0x33be3f};}function rt(_0x1c4174,_0x3103b7){return{'type':'child_added','snapshotNode':_0x3103b7,'childName':_0x1c4174};}function Lt(_0x433947,_0x3161c4){return{'type':'child_removed','snapshotNode':_0x3161c4,'childName':_0x433947};}function xt(_0x40e9f0,_0x1a30dd,_0x1a99cf){return{'type':'child_changed','snapshotNode':_0x1a30dd,'childName':_0x40e9f0,'oldSnap':_0x1a99cf};}function zh(_0x4c9b00,_0x30363f){return{'type':'child_moved','snapshotNode':_0x30363f,'childName':_0x4c9b00};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x4b4ebc){this['index_']=_0x4b4ebc;}['updateChild'](_0x4e23fe,_0x3a162f,_0x59d301,_0x773f62,_0x2a56b5,_0x235168){f(_0x4e23fe['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x3f97b5=_0x4e23fe['getImmediateChild'](_0x3a162f);return _0x3f97b5['getChild'](_0x773f62)['equals'](_0x59d301['getChild'](_0x773f62))&&_0x3f97b5['isEmpty']()===_0x59d301['isEmpty']()||(_0x235168!=null&&(_0x59d301['isEmpty']()?_0x4e23fe['hasChild'](_0x3a162f)?_0x235168['trackChildChange'](Lt(_0x3a162f,_0x3f97b5)):f(_0x4e23fe['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x3f97b5['isEmpty']()?_0x235168['trackChildChange'](rt(_0x3a162f,_0x59d301)):_0x235168['trackChildChange'](xt(_0x3a162f,_0x59d301,_0x3f97b5))),_0x4e23fe['isLeafNode']()&&_0x59d301['isEmpty']())?_0x4e23fe:_0x4e23fe['updateImmediateChild'](_0x3a162f,_0x59d301)['withIndex'](this['index_']);}['updateFullNode'](_0xf81861,_0x1c1ad4,_0x2d3b84){return _0x2d3b84!=null&&(_0xf81861['isLeafNode']()||_0xf81861['forEachChild'](R,(_0x3eb7a8,_0x319037)=>{_0x1c1ad4['hasChild'](_0x3eb7a8)||_0x2d3b84['trackChildChange'](Lt(_0x3eb7a8,_0x319037));}),_0x1c1ad4['isLeafNode']()||_0x1c1ad4['forEachChild'](R,(_0x4eadc3,_0x4a5b49)=>{if(_0xf81861['hasChild'](_0x4eadc3)){const _0x55cfcc=_0xf81861['getImmediateChild'](_0x4eadc3);_0x55cfcc['equals'](_0x4a5b49)||_0x2d3b84['trackChildChange'](xt(_0x4eadc3,_0x4a5b49,_0x55cfcc));}else _0x2d3b84['trackChildChange'](rt(_0x4eadc3,_0x4a5b49));})),_0x1c1ad4['withIndex'](this['index_']);}['updatePriority'](_0x2f52a1,_0x5a6653){return _0x2f52a1['isEmpty']()?g['EMPTY_NODE']:_0x2f52a1['updatePriority'](_0x5a6653);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x17f440){this['indexedFilter_']=new Xi(_0x17f440['getIndex']()),this['index_']=_0x17f440['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x17f440),this['endPost_']=Ft['getEndPost_'](_0x17f440),this['startIsInclusive_']=!_0x17f440['startAfterSet_'],this['endIsInclusive_']=!_0x17f440['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x3a3e1d){const _0x295a69=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x3a3e1d)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x3a3e1d)<0x0,_0xc5a2da=this['endIsInclusive_']?this['index_']['compare'](_0x3a3e1d,this['getEndPost']())<=0x0:this['index_']['compare'](_0x3a3e1d,this['getEndPost']())<0x0;return _0x295a69&&_0xc5a2da;}['updateChild'](_0x2193ea,_0x6861a4,_0x373acb,_0x1b83b1,_0x6b118d,_0x537549){return this['matches'](new E(_0x6861a4,_0x373acb))||(_0x373acb=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x2193ea,_0x6861a4,_0x373acb,_0x1b83b1,_0x6b118d,_0x537549);}['updateFullNode'](_0x1d4b44,_0x22934b,_0x5d0376){_0x22934b['isLeafNode']()&&(_0x22934b=g['EMPTY_NODE']);let _0x1d8e77=_0x22934b['withIndex'](this['index_']);_0x1d8e77=_0x1d8e77['updatePriority'](g['EMPTY_NODE']);const _0x2f8c4c=this;return _0x22934b['forEachChild'](R,(_0x390f0a,_0x55fbb9)=>{_0x2f8c4c['matches'](new E(_0x390f0a,_0x55fbb9))||(_0x1d8e77=_0x1d8e77['updateImmediateChild'](_0x390f0a,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x1d4b44,_0x1d8e77,_0x5d0376);}['updatePriority'](_0x4f07eb,_0x26bfe6){return _0x4f07eb;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x3212cc){if(_0x3212cc['hasStart']()){const _0xa3f236=_0x3212cc['getIndexStartName']();return _0x3212cc['getIndex']()['makePost'](_0x3212cc['getIndexStartValue'](),_0xa3f236);}else return _0x3212cc['getIndex']()['minPost']();}static['getEndPost_'](_0x123db4){if(_0x123db4['hasEnd']()){const _0x461fd3=_0x123db4['getIndexEndName']();return _0x123db4['getIndex']()['makePost'](_0x123db4['getIndexEndValue'](),_0x461fd3);}else return _0x123db4['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x4eb0cb){this['withinDirectionalStart']=_0x200de9=>this['reverse_']?this['withinEndPost'](_0x200de9):this['withinStartPost'](_0x200de9),this['withinDirectionalEnd']=_0x34f92b=>this['reverse_']?this['withinStartPost'](_0x34f92b):this['withinEndPost'](_0x34f92b),this['withinStartPost']=_0x5c5a06=>{const _0x221d34=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x5c5a06);return this['startIsInclusive_']?_0x221d34<=0x0:_0x221d34<0x0;},this['withinEndPost']=_0x3a244a=>{const _0x4eb1fa=this['index_']['compare'](_0x3a244a,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x4eb1fa<=0x0:_0x4eb1fa<0x0;},this['rangedFilter_']=new Ft(_0x4eb0cb),this['index_']=_0x4eb0cb['getIndex'](),this['limit_']=_0x4eb0cb['getLimit'](),this['reverse_']=!_0x4eb0cb['isViewFromLeft'](),this['startIsInclusive_']=!_0x4eb0cb['startAfterSet_'],this['endIsInclusive_']=!_0x4eb0cb['endBeforeSet_'];}['updateChild'](_0x1da8f4,_0x36c07e,_0x45dbc4,_0x20ccc4,_0x261cc5,_0x47678b){return this['rangedFilter_']['matches'](new E(_0x36c07e,_0x45dbc4))||(_0x45dbc4=g['EMPTY_NODE']),_0x1da8f4['getImmediateChild'](_0x36c07e)['equals'](_0x45dbc4)?_0x1da8f4:_0x1da8f4['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x1da8f4,_0x36c07e,_0x45dbc4,_0x20ccc4,_0x261cc5,_0x47678b):this['fullLimitUpdateChild_'](_0x1da8f4,_0x36c07e,_0x45dbc4,_0x261cc5,_0x47678b);}['updateFullNode'](_0x36cb40,_0x314282,_0x47cec3){let _0x398011;if(_0x314282['isLeafNode']()||_0x314282['isEmpty']())_0x398011=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x314282['numChildren']()&&_0x314282['isIndexed'](this['index_'])){_0x398011=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x5f8a14;this['reverse_']?_0x5f8a14=_0x314282['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x5f8a14=_0x314282['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x31172e=0x0;for(;_0x5f8a14['hasNext']()&&_0x31172e<this['limit_'];){const _0x48c817=_0x5f8a14['getNext']();if(this['withinDirectionalStart'](_0x48c817)){if(this['withinDirectionalEnd'](_0x48c817))_0x398011=_0x398011['updateImmediateChild'](_0x48c817['name'],_0x48c817['node']),_0x31172e++;else break;}else continue;}}else{_0x398011=_0x314282['withIndex'](this['index_']),_0x398011=_0x398011['updatePriority'](g['EMPTY_NODE']);let _0x3112d4;this['reverse_']?_0x3112d4=_0x398011['getReverseIterator'](this['index_']):_0x3112d4=_0x398011['getIterator'](this['index_']);let _0x5919ea=0x0;for(;_0x3112d4['hasNext']();){const _0x13e9f8=_0x3112d4['getNext']();_0x5919ea<this['limit_']&&this['withinDirectionalStart'](_0x13e9f8)&&this['withinDirectionalEnd'](_0x13e9f8)?_0x5919ea++:_0x398011=_0x398011['updateImmediateChild'](_0x13e9f8['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x36cb40,_0x398011,_0x47cec3);}['updatePriority'](_0x45e791,_0x1dbb6d){return _0x45e791;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x40e6a2,_0x5b4556,_0x222e3c,_0x5434ed,_0x1d359b){let _0x534450;if(this['reverse_']){const _0x5c56f1=this['index_']['getCompare']();_0x534450=(_0x3ca7bb,_0x1eb1cb)=>_0x5c56f1(_0x1eb1cb,_0x3ca7bb);}else _0x534450=this['index_']['getCompare']();const _0x49af64=_0x40e6a2;f(_0x49af64['numChildren']()===this['limit_'],'');const _0x32bac0=new E(_0x5b4556,_0x222e3c),_0x4f696d=this['reverse_']?_0x49af64['getFirstChild'](this['index_']):_0x49af64['getLastChild'](this['index_']),_0x58ce2c=this['rangedFilter_']['matches'](_0x32bac0);if(_0x49af64['hasChild'](_0x5b4556)){const _0x3eadeb=_0x49af64['getImmediateChild'](_0x5b4556);let _0x5977c3=_0x5434ed['getChildAfterChild'](this['index_'],_0x4f696d,this['reverse_']);for(;_0x5977c3!=null&&(_0x5977c3['name']===_0x5b4556||_0x49af64['hasChild'](_0x5977c3['name']));)_0x5977c3=_0x5434ed['getChildAfterChild'](this['index_'],_0x5977c3,this['reverse_']);const _0x1dd61=_0x5977c3==null?0x1:_0x534450(_0x5977c3,_0x32bac0);if(_0x58ce2c&&!_0x222e3c['isEmpty']()&&_0x1dd61>=0x0)return _0x1d359b!=null&&_0x1d359b['trackChildChange'](xt(_0x5b4556,_0x222e3c,_0x3eadeb)),_0x49af64['updateImmediateChild'](_0x5b4556,_0x222e3c);{_0x1d359b!=null&&_0x1d359b['trackChildChange'](Lt(_0x5b4556,_0x3eadeb));const _0x12c7dc=_0x49af64['updateImmediateChild'](_0x5b4556,g['EMPTY_NODE']);return _0x5977c3!=null&&this['rangedFilter_']['matches'](_0x5977c3)?(_0x1d359b!=null&&_0x1d359b['trackChildChange'](rt(_0x5977c3['name'],_0x5977c3['node'])),_0x12c7dc['updateImmediateChild'](_0x5977c3['name'],_0x5977c3['node'])):_0x12c7dc;}}else return _0x222e3c['isEmpty']()?_0x40e6a2:_0x58ce2c&&_0x534450(_0x4f696d,_0x32bac0)>=0x0?(_0x1d359b!=null&&(_0x1d359b['trackChildChange'](Lt(_0x4f696d['name'],_0x4f696d['node'])),_0x1d359b['trackChildChange'](rt(_0x5b4556,_0x222e3c))),_0x49af64['updateImmediateChild'](_0x5b4556,_0x222e3c)['updateImmediateChild'](_0x4f696d['name'],g['EMPTY_NODE'])):_0x40e6a2;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x15d4d6=new Zi();return _0x15d4d6['limitSet_']=this['limitSet_'],_0x15d4d6['limit_']=this['limit_'],_0x15d4d6['startSet_']=this['startSet_'],_0x15d4d6['startAfterSet_']=this['startAfterSet_'],_0x15d4d6['indexStartValue_']=this['indexStartValue_'],_0x15d4d6['startNameSet_']=this['startNameSet_'],_0x15d4d6['indexStartName_']=this['indexStartName_'],_0x15d4d6['endSet_']=this['endSet_'],_0x15d4d6['endBeforeSet_']=this['endBeforeSet_'],_0x15d4d6['indexEndValue_']=this['indexEndValue_'],_0x15d4d6['endNameSet_']=this['endNameSet_'],_0x15d4d6['indexEndName_']=this['indexEndName_'],_0x15d4d6['index_']=this['index_'],_0x15d4d6['viewFrom_']=this['viewFrom_'],_0x15d4d6;}}function Kh(_0xa9f007){return _0xa9f007['loadsAllData']()?new Xi(_0xa9f007['getIndex']()):_0xa9f007['hasLimit']()?new jh(_0xa9f007):new Ft(_0xa9f007);}function Yh(_0x5609c0,_0x1c56a2){const _0x1bcd9c=_0x5609c0['copy']();return _0x1bcd9c['limitSet_']=!0x0,_0x1bcd9c['limit_']=_0x1c56a2,_0x1bcd9c['viewFrom_']='l',_0x1bcd9c;}function Qh(_0x5dd702,_0x234e33,_0x43dc79){const _0x2f24b7=_0x5dd702['copy']();return _0x2f24b7['startSet_']=!0x0,_0x234e33===void 0x0&&(_0x234e33=null),_0x2f24b7['indexStartValue_']=_0x234e33,_0x43dc79!=null?(_0x2f24b7['startNameSet_']=!0x0,_0x2f24b7['indexStartName_']=_0x43dc79):(_0x2f24b7['startNameSet_']=!0x1,_0x2f24b7['indexStartName_']=''),_0x2f24b7;}function Jh(_0x3649b7,_0x570115,_0x2ce33b){const _0x1731b1=_0x3649b7['copy']();return _0x1731b1['endSet_']=!0x0,_0x570115===void 0x0&&(_0x570115=null),_0x1731b1['indexEndValue_']=_0x570115,_0x2ce33b!==void 0x0?(_0x1731b1['endNameSet_']=!0x0,_0x1731b1['indexEndName_']=_0x2ce33b):(_0x1731b1['endNameSet_']=!0x1,_0x1731b1['indexEndName_']=''),_0x1731b1;}function xo(_0x2970a4,_0x5836f1){const _0x230f01=_0x2970a4['copy']();return _0x230f01['index_']=_0x5836f1,_0x230f01;}function ir(_0x5287ab){const _0x1f4769={};if(_0x5287ab['isDefault']())return _0x1f4769;let _0x23666a;if(_0x5287ab['index_']===R?_0x23666a='$priority':_0x5287ab['index_']===Mo?_0x23666a='$value':_0x5287ab['index_']===ve?_0x23666a='$key':(f(_0x5287ab['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x23666a=_0x5287ab['index_']['toString']()),_0x1f4769['orderBy']=O(_0x23666a),_0x5287ab['startSet_']){const _0x545d36=_0x5287ab['startAfterSet_']?'startAfter':'startAt';_0x1f4769[_0x545d36]=O(_0x5287ab['indexStartValue_']),_0x5287ab['startNameSet_']&&(_0x1f4769[_0x545d36]+=','+O(_0x5287ab['indexStartName_']));}if(_0x5287ab['endSet_']){const _0x3a22ce=_0x5287ab['endBeforeSet_']?'endBefore':'endAt';_0x1f4769[_0x3a22ce]=O(_0x5287ab['indexEndValue_']),_0x5287ab['endNameSet_']&&(_0x1f4769[_0x3a22ce]+=','+O(_0x5287ab['indexEndName_']));}return _0x5287ab['limitSet_']&&(_0x5287ab['isViewFromLeft']()?_0x1f4769['limitToFirst']=_0x5287ab['limit_']:_0x1f4769['limitToLast']=_0x5287ab['limit_']),_0x1f4769;}function sr(_0x42362f){const _0x4a76a5={};if(_0x42362f['startSet_']&&(_0x4a76a5['sp']=_0x42362f['indexStartValue_'],_0x42362f['startNameSet_']&&(_0x4a76a5['sn']=_0x42362f['indexStartName_']),_0x4a76a5['sin']=!_0x42362f['startAfterSet_']),_0x42362f['endSet_']&&(_0x4a76a5['ep']=_0x42362f['indexEndValue_'],_0x42362f['endNameSet_']&&(_0x4a76a5['en']=_0x42362f['indexEndName_']),_0x4a76a5['ein']=!_0x42362f['endBeforeSet_']),_0x42362f['limitSet_']){_0x4a76a5['l']=_0x42362f['limit_'];let _0x472f95=_0x42362f['viewFrom_'];_0x472f95===''&&(_0x42362f['isViewFromLeft']()?_0x472f95='l':_0x472f95='r'),_0x4a76a5['vf']=_0x472f95;}return _0x42362f['index_']!==R&&(_0x4a76a5['i']=_0x42362f['index_']['toString']()),_0x4a76a5;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x13e60c){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0xe99833,_0x36c410){return _0x36c410!==void 0x0?'tag$'+_0x36c410:(f(_0xe99833['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0xe99833['_path']['toString']());}constructor(_0x40eb09,_0x552dd9,_0x2c690c,_0xcbb81b){super(),this['repoInfo_']=_0x40eb09,this['onDataUpdate_']=_0x552dd9,this['authTokenProvider_']=_0x2c690c,this['appCheckTokenProvider_']=_0xcbb81b,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x4bf9aa,_0x358fe5,_0x16cccb,_0xb61915){const _0x1f059d=_0x4bf9aa['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x1f059d+'\x20'+_0x4bf9aa['_queryIdentifier']);const _0x29f7a6=vn['getListenId_'](_0x4bf9aa,_0x16cccb),_0x4f5cca={};this['listens_'][_0x29f7a6]=_0x4f5cca;const _0x3a835d=ir(_0x4bf9aa['_queryParams']);this['restRequest_'](_0x1f059d+'.json',_0x3a835d,(_0x7b4637,_0x5c1e94)=>{let _0x20988b=_0x5c1e94;if(_0x7b4637===0x194&&(_0x20988b=null,_0x7b4637=null),_0x7b4637===null&&this['onDataUpdate_'](_0x1f059d,_0x20988b,!0x1,_0x16cccb),Le(this['listens_'],_0x29f7a6)===_0x4f5cca){let _0x593c7a;_0x7b4637?_0x7b4637===0x191?_0x593c7a='permission_denied':_0x593c7a='rest_error:'+_0x7b4637:_0x593c7a='ok',_0xb61915(_0x593c7a,null);}});}['unlisten'](_0x22b900,_0x2eaf2d){const _0x5ca56c=vn['getListenId_'](_0x22b900,_0x2eaf2d);delete this['listens_'][_0x5ca56c];}['get'](_0x5a0682){const _0x5510c3=ir(_0x5a0682['_queryParams']),_0x4f6e7=_0x5a0682['_path']['toString'](),_0xf51b0f=new H();return this['restRequest_'](_0x4f6e7+'.json',_0x5510c3,(_0x22eb95,_0x14381f)=>{let _0x43b5c2=_0x14381f;_0x22eb95===0x194&&(_0x43b5c2=null,_0x22eb95=null),_0x22eb95===null?(this['onDataUpdate_'](_0x4f6e7,_0x43b5c2,!0x1,null),_0xf51b0f['resolve'](_0x43b5c2)):_0xf51b0f['reject'](new Error(_0x43b5c2));}),_0xf51b0f['promise'];}['refreshAuthToken'](_0x5b3f43){}['restRequest_'](_0x109783,_0x340fae={},_0x18f147){return _0x340fae['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x2fe457,_0x49a47e])=>{_0x2fe457&&_0x2fe457['accessToken']&&(_0x340fae['auth']=_0x2fe457['accessToken']),_0x49a47e&&_0x49a47e['token']&&(_0x340fae['ac']=_0x49a47e['token']);const _0x4d852d=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x109783+'?ns='+this['repoInfo_']['namespace']+ut(_0x340fae);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x4d852d);const _0x3e0696=new XMLHttpRequest();_0x3e0696['onreadystatechange']=()=>{if(_0x18f147&&_0x3e0696['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x4d852d+'\x20received.\x20status:',_0x3e0696['status'],'response:',_0x3e0696['responseText']);let _0xba2d67=null;if(_0x3e0696['status']>=0xc8&&_0x3e0696['status']<0x12c){try{_0xba2d67=Nt(_0x3e0696['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x4d852d+':\x20'+_0x3e0696['responseText']);}_0x18f147(null,_0xba2d67);}else _0x3e0696['status']!==0x191&&_0x3e0696['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x4d852d+'\x20Status:\x20'+_0x3e0696['status']),_0x18f147(_0x3e0696['status']);_0x18f147=null;}},_0x3e0696['open']('GET',_0x4d852d,!0x0),_0x3e0696['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x4a487a){return this['rootNode_']['getChild'](_0x4a487a);}['updateSnapshot'](_0xb4eb48,_0x1550ba){this['rootNode_']=this['rootNode_']['updateChild'](_0xb4eb48,_0x1550ba);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x17c1bc,_0x3d3deb,_0x4d535e){if(v(_0x3d3deb))_0x17c1bc['value']=_0x4d535e,_0x17c1bc['children']['clear']();else{if(_0x17c1bc['value']!==null)_0x17c1bc['value']=_0x17c1bc['value']['updateChild'](_0x3d3deb,_0x4d535e);else{const _0x65802a=y(_0x3d3deb);_0x17c1bc['children']['has'](_0x65802a)||_0x17c1bc['children']['set'](_0x65802a,En());const _0x3c0010=_0x17c1bc['children']['get'](_0x65802a);_0x3d3deb=S(_0x3d3deb),pt(_0x3c0010,_0x3d3deb,_0x4d535e);}}}function Ti(_0x320c02,_0x30d87a){if(v(_0x30d87a))return _0x320c02['value']=null,_0x320c02['children']['clear'](),!0x0;if(_0x320c02['value']!==null){if(_0x320c02['value']['isLeafNode']())return!0x1;{const _0x2e4c30=_0x320c02['value'];return _0x320c02['value']=null,_0x2e4c30['forEachChild'](R,(_0x1cb90f,_0x48c667)=>{pt(_0x320c02,new C(_0x1cb90f),_0x48c667);}),Ti(_0x320c02,_0x30d87a);}}else{if(_0x320c02['children']['size']>0x0){const _0x6d6f8f=y(_0x30d87a);return _0x30d87a=S(_0x30d87a),_0x320c02['children']['has'](_0x6d6f8f)&&Ti(_0x320c02['children']['get'](_0x6d6f8f),_0x30d87a)&&_0x320c02['children']['delete'](_0x6d6f8f),_0x320c02['children']['size']===0x0;}else return!0x0;}}function Si(_0x18eaf5,_0x190f4c,_0x420fbe){_0x18eaf5['value']!==null?_0x420fbe(_0x190f4c,_0x18eaf5['value']):Zh(_0x18eaf5,(_0x5877c4,_0x45901a)=>{const _0x5de216=new C(_0x190f4c['toString']()+'/'+_0x5877c4);Si(_0x45901a,_0x5de216,_0x420fbe);});}function Zh(_0x1581d9,_0x4d4ade){_0x1581d9['children']['forEach']((_0x38e560,_0x58b335)=>{_0x4d4ade(_0x58b335,_0x38e560);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x4dca9f){this['collection_']=_0x4dca9f,this['last_']=null;}['get'](){const _0xb4abfe=this['collection_']['get'](),_0x2ce5bc={..._0xb4abfe};return this['last_']&&x(this['last_'],(_0x4e323e,_0x42776b)=>{_0x2ce5bc[_0x4e323e]=_0x2ce5bc[_0x4e323e]-_0x42776b;}),this['last_']=_0xb4abfe,_0x2ce5bc;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x3f1508,_0x214289){this['server_']=_0x214289,this['statsToReport_']={},this['statsListener_']=new eu(_0x3f1508);const _0x340dfc=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x340dfc));}['reportStats_'](){const _0x45a163=this['statsListener_']['get'](),_0x1e4a6e={};let _0x21fcd2=!0x1;x(_0x45a163,(_0x181be8,_0x3241b4)=>{_0x3241b4>0x0&&Q(this['statsToReport_'],_0x181be8)&&(_0x1e4a6e[_0x181be8]=_0x3241b4,_0x21fcd2=!0x0);}),_0x21fcd2&&this['server_']['reportStats'](_0x1e4a6e),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x28b82c){_0x28b82c[_0x28b82c['OVERWRITE']=0x0]='OVERWRITE',_0x28b82c[_0x28b82c['MERGE']=0x1]='MERGE',_0x28b82c[_0x28b82c['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x28b82c[_0x28b82c['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x3f1c9a){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x3f1c9a,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x2d40ea,_0x20b4d3,_0x5d5230){this['path']=_0x2d40ea,this['affectedTree']=_0x20b4d3,this['revert']=_0x5d5230,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x1c05e4){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x450390=this['affectedTree']['subtree'](new C(_0x1c05e4));return new In(w(),_0x450390,this['revert']);}}else return f(y(this['path'])===_0x1c05e4,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x426e30,_0x152fb7){this['source']=_0x426e30,this['path']=_0x152fb7,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0xd1ddb5){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0xee46bb,_0x2bec9,_0x497925){this['source']=_0xee46bb,this['path']=_0x2bec9,this['snap']=_0x497925,this['type']=z['OVERWRITE'];}['operationForChild'](_0x4b667e){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x4b667e)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x738267,_0x49f0d2,_0x20a582){this['source']=_0x738267,this['path']=_0x49f0d2,this['children']=_0x20a582,this['type']=z['MERGE'];}['operationForChild'](_0x434bf8){if(v(this['path'])){const _0x15ab87=this['children']['subtree'](new C(_0x434bf8));return _0x15ab87['isEmpty']()?null:_0x15ab87['value']?new Be(this['source'],w(),_0x15ab87['value']):new ot(this['source'],w(),_0x15ab87);}else return f(y(this['path'])===_0x434bf8,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x480b0d,_0x1618a7,_0x2e0c7a){this['node_']=_0x480b0d,this['fullyInitialized_']=_0x1618a7,this['filtered_']=_0x2e0c7a;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x1b820d){if(v(_0x1b820d))return this['isFullyInitialized']()&&!this['filtered_'];const _0x275d66=y(_0x1b820d);return this['isCompleteForChild'](_0x275d66);}['isCompleteForChild'](_0x54c70e){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x54c70e);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x4fd332){this['query_']=_0x4fd332,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x705859,_0x4c7d67,_0x1dd238,_0x5b2575){const _0x149351=[],_0x48bfb1=[];return _0x4c7d67['forEach'](_0x2cb111=>{_0x2cb111['type']==='child_changed'&&_0x705859['index_']['indexedValueChanged'](_0x2cb111['oldSnap'],_0x2cb111['snapshotNode'])&&_0x48bfb1['push'](zh(_0x2cb111['childName'],_0x2cb111['snapshotNode']));}),wt(_0x705859,_0x149351,'child_removed',_0x4c7d67,_0x5b2575,_0x1dd238),wt(_0x705859,_0x149351,'child_added',_0x4c7d67,_0x5b2575,_0x1dd238),wt(_0x705859,_0x149351,'child_moved',_0x48bfb1,_0x5b2575,_0x1dd238),wt(_0x705859,_0x149351,'child_changed',_0x4c7d67,_0x5b2575,_0x1dd238),wt(_0x705859,_0x149351,'value',_0x4c7d67,_0x5b2575,_0x1dd238),_0x149351;}function wt(_0x378d22,_0xe6c410,_0x3bcd3c,_0x4293c3,_0x3e3fc5,_0x257e52){const _0x451041=_0x4293c3['filter'](_0x45e088=>_0x45e088['type']===_0x3bcd3c);_0x451041['sort']((_0x1e7e58,_0x4e3409)=>au(_0x378d22,_0x1e7e58,_0x4e3409)),_0x451041['forEach'](_0x3a165b=>{const _0x19e199=ou(_0x378d22,_0x3a165b,_0x257e52);_0x3e3fc5['forEach'](_0x54e7d0=>{_0x54e7d0['respondsTo'](_0x3a165b['type'])&&_0xe6c410['push'](_0x54e7d0['createEvent'](_0x19e199,_0x378d22['query_']));});});}function ou(_0x55cef8,_0x20e6c1,_0x50473a){return _0x20e6c1['type']==='value'||_0x20e6c1['type']==='child_removed'||(_0x20e6c1['prevName']=_0x50473a['getPredecessorChildName'](_0x20e6c1['childName'],_0x20e6c1['snapshotNode'],_0x55cef8['index_'])),_0x20e6c1;}function au(_0x79bb4f,_0x579542,_0x28ef29){if(_0x579542['childName']==null||_0x28ef29['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0xcf9b12=new E(_0x579542['childName'],_0x579542['snapshotNode']),_0x249a04=new E(_0x28ef29['childName'],_0x28ef29['snapshotNode']);return _0x79bb4f['index_']['compare'](_0xcf9b12,_0x249a04);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x1335f0,_0x48af8e){return{'eventCache':_0x1335f0,'serverCache':_0x48af8e};}function Rt(_0x464477,_0x262f63,_0x74511c,_0xaf9fea){return Un(new Te(_0x262f63,_0x74511c,_0xaf9fea),_0x464477['serverCache']);}function Fo(_0x1200d1,_0x5b56db,_0x4d3dc3,_0x398163){return Un(_0x1200d1['eventCache'],new Te(_0x5b56db,_0x4d3dc3,_0x398163));}function wn(_0x2aed6b){return _0x2aed6b['eventCache']['isFullyInitialized']()?_0x2aed6b['eventCache']['getNode']():null;}function Ve(_0x5e52dc){return _0x5e52dc['serverCache']['isFullyInitialized']()?_0x5e52dc['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x10e024){let _0x1331d1=new b(null);return x(_0x10e024,(_0xac4bf8,_0x44c4b5)=>{_0x1331d1=_0x1331d1['set'](new C(_0xac4bf8),_0x44c4b5);}),_0x1331d1;}constructor(_0x4307ea,_0x1e79aa=cu()){this['value']=_0x4307ea,this['children']=_0x1e79aa;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0xf72e68,_0x1d096e){if(this['value']!=null&&_0x1d096e(this['value']))return{'path':w(),'value':this['value']};if(v(_0xf72e68))return null;{const _0x10d249=y(_0xf72e68),_0x4e875b=this['children']['get'](_0x10d249);if(_0x4e875b!==null){const _0x35cf1e=_0x4e875b['findRootMostMatchingPathAndValue'](S(_0xf72e68),_0x1d096e);return _0x35cf1e!=null?{'path':k(new C(_0x10d249),_0x35cf1e['path']),'value':_0x35cf1e['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0xbee86c){return this['findRootMostMatchingPathAndValue'](_0xbee86c,()=>!0x0);}['subtree'](_0x5e39a0){if(v(_0x5e39a0))return this;{const _0x181222=y(_0x5e39a0),_0x3eb2d1=this['children']['get'](_0x181222);return _0x3eb2d1!==null?_0x3eb2d1['subtree'](S(_0x5e39a0)):new b(null);}}['set'](_0xed3be,_0x4ab0f1){if(v(_0xed3be))return new b(_0x4ab0f1,this['children']);{const _0xe3a6f9=y(_0xed3be),_0x56ae56=(this['children']['get'](_0xe3a6f9)||new b(null))['set'](S(_0xed3be),_0x4ab0f1),_0x2b3ab6=this['children']['insert'](_0xe3a6f9,_0x56ae56);return new b(this['value'],_0x2b3ab6);}}['remove'](_0x1ce6a3){if(v(_0x1ce6a3))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x2bb2a1=y(_0x1ce6a3),_0xb67b34=this['children']['get'](_0x2bb2a1);if(_0xb67b34){const _0x51c836=_0xb67b34['remove'](S(_0x1ce6a3));let _0x23780f;return _0x51c836['isEmpty']()?_0x23780f=this['children']['remove'](_0x2bb2a1):_0x23780f=this['children']['insert'](_0x2bb2a1,_0x51c836),this['value']===null&&_0x23780f['isEmpty']()?new b(null):new b(this['value'],_0x23780f);}else return this;}}['get'](_0x518d88){if(v(_0x518d88))return this['value'];{const _0x359ee8=y(_0x518d88),_0x2faebd=this['children']['get'](_0x359ee8);return _0x2faebd?_0x2faebd['get'](S(_0x518d88)):null;}}['setTree'](_0x2cf526,_0x3de726){if(v(_0x2cf526))return _0x3de726;{const _0x5b7b9d=y(_0x2cf526),_0x1b5051=(this['children']['get'](_0x5b7b9d)||new b(null))['setTree'](S(_0x2cf526),_0x3de726);let _0x3b018b;return _0x1b5051['isEmpty']()?_0x3b018b=this['children']['remove'](_0x5b7b9d):_0x3b018b=this['children']['insert'](_0x5b7b9d,_0x1b5051),new b(this['value'],_0x3b018b);}}['fold'](_0x54539f){return this['fold_'](w(),_0x54539f);}['fold_'](_0x5d9121,_0x212975){const _0x1a1ba9={};return this['children']['inorderTraversal']((_0x3604ab,_0x3370d7)=>{_0x1a1ba9[_0x3604ab]=_0x3370d7['fold_'](k(_0x5d9121,_0x3604ab),_0x212975);}),_0x212975(_0x5d9121,this['value'],_0x1a1ba9);}['findOnPath'](_0x5c606d,_0x44773a){return this['findOnPath_'](_0x5c606d,w(),_0x44773a);}['findOnPath_'](_0x42b309,_0xccc744,_0x16da51){const _0x3a1c63=this['value']?_0x16da51(_0xccc744,this['value']):!0x1;if(_0x3a1c63)return _0x3a1c63;if(v(_0x42b309))return null;{const _0x4f1ca5=y(_0x42b309),_0x51c4ae=this['children']['get'](_0x4f1ca5);return _0x51c4ae?_0x51c4ae['findOnPath_'](S(_0x42b309),k(_0xccc744,_0x4f1ca5),_0x16da51):null;}}['foreachOnPath'](_0x51f3c4,_0x5d4207){return this['foreachOnPath_'](_0x51f3c4,w(),_0x5d4207);}['foreachOnPath_'](_0x4d224c,_0x2e0940,_0x514040){if(v(_0x4d224c))return this;{this['value']&&_0x514040(_0x2e0940,this['value']);const _0x35a1a0=y(_0x4d224c),_0x4bc90f=this['children']['get'](_0x35a1a0);return _0x4bc90f?_0x4bc90f['foreachOnPath_'](S(_0x4d224c),k(_0x2e0940,_0x35a1a0),_0x514040):new b(null);}}['foreach'](_0x21c206){this['foreach_'](w(),_0x21c206);}['foreach_'](_0x477ea9,_0x176300){this['children']['inorderTraversal']((_0x24b9e9,_0x4c6f4c)=>{_0x4c6f4c['foreach_'](k(_0x477ea9,_0x24b9e9),_0x176300);}),this['value']&&_0x176300(_0x477ea9,this['value']);}['foreachChild'](_0x1328ae){this['children']['inorderTraversal']((_0x10a885,_0x274e15)=>{_0x274e15['value']&&_0x1328ae(_0x10a885,_0x274e15['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x56440e){this['writeTree_']=_0x56440e;}static['empty'](){return new K(new b(null));}}function At(_0x2d5a7f,_0x45c8cd,_0x1c1c05){if(v(_0x45c8cd))return new K(new b(_0x1c1c05));{const _0x165425=_0x2d5a7f['writeTree_']['findRootMostValueAndPath'](_0x45c8cd);if(_0x165425!=null){const _0x14135c=_0x165425['path'];let _0x3f8d98=_0x165425['value'];const _0x455155=F(_0x14135c,_0x45c8cd);return _0x3f8d98=_0x3f8d98['updateChild'](_0x455155,_0x1c1c05),new K(_0x2d5a7f['writeTree_']['set'](_0x14135c,_0x3f8d98));}else{const _0x5adcd6=new b(_0x1c1c05),_0x16fbe0=_0x2d5a7f['writeTree_']['setTree'](_0x45c8cd,_0x5adcd6);return new K(_0x16fbe0);}}}function bi(_0x581f56,_0x4642d8,_0x158c44){let _0x316fb4=_0x581f56;return x(_0x158c44,(_0x5e1c88,_0x5b36fa)=>{_0x316fb4=At(_0x316fb4,k(_0x4642d8,_0x5e1c88),_0x5b36fa);}),_0x316fb4;}function or(_0x3e8c78,_0x2fd922){if(v(_0x2fd922))return K['empty']();{const _0x3a8274=_0x3e8c78['writeTree_']['setTree'](_0x2fd922,new b(null));return new K(_0x3a8274);}}function Ri(_0x5aea98,_0x1e0ecd){return ze(_0x5aea98,_0x1e0ecd)!=null;}function ze(_0x39cf66,_0x533161){const _0x39c39b=_0x39cf66['writeTree_']['findRootMostValueAndPath'](_0x533161);return _0x39c39b!=null?_0x39cf66['writeTree_']['get'](_0x39c39b['path'])['getChild'](F(_0x39c39b['path'],_0x533161)):null;}function ar(_0x113abf){const _0x52912a=[],_0x339997=_0x113abf['writeTree_']['value'];return _0x339997!=null?_0x339997['isLeafNode']()||_0x339997['forEachChild'](R,(_0x3bc0c1,_0x4adbae)=>{_0x52912a['push'](new E(_0x3bc0c1,_0x4adbae));}):_0x113abf['writeTree_']['children']['inorderTraversal']((_0x5b68fa,_0x40f5aa)=>{_0x40f5aa['value']!=null&&_0x52912a['push'](new E(_0x5b68fa,_0x40f5aa['value']));}),_0x52912a;}function Ee(_0x436688,_0x1519d3){if(v(_0x1519d3))return _0x436688;{const _0xd7f8b4=ze(_0x436688,_0x1519d3);return _0xd7f8b4!=null?new K(new b(_0xd7f8b4)):new K(_0x436688['writeTree_']['subtree'](_0x1519d3));}}function Ai(_0x2006c5){return _0x2006c5['writeTree_']['isEmpty']();}function at(_0x574ef9,_0x5adb3e){return Uo(w(),_0x574ef9['writeTree_'],_0x5adb3e);}function Uo(_0x1f3436,_0x5a0696,_0xaa575e){if(_0x5a0696['value']!=null)return _0xaa575e['updateChild'](_0x1f3436,_0x5a0696['value']);{let _0x4fb981=null;return _0x5a0696['children']['inorderTraversal']((_0x36b372,_0x796566)=>{_0x36b372==='.priority'?(f(_0x796566['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x4fb981=_0x796566['value']):_0xaa575e=Uo(k(_0x1f3436,_0x36b372),_0x796566,_0xaa575e);}),!_0xaa575e['getChild'](_0x1f3436)['isEmpty']()&&_0x4fb981!==null&&(_0xaa575e=_0xaa575e['updateChild'](k(_0x1f3436,'.priority'),_0x4fb981)),_0xaa575e;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x484ce1,_0x396a17){return Ho(_0x396a17,_0x484ce1);}function lu(_0x1d2a32,_0x2e119f,_0x3e741d,_0x5ba573,_0x3c01ce){f(_0x5ba573>_0x1d2a32['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x3c01ce===void 0x0&&(_0x3c01ce=!0x0),_0x1d2a32['allWrites']['push']({'path':_0x2e119f,'snap':_0x3e741d,'writeId':_0x5ba573,'visible':_0x3c01ce}),_0x3c01ce&&(_0x1d2a32['visibleWrites']=At(_0x1d2a32['visibleWrites'],_0x2e119f,_0x3e741d)),_0x1d2a32['lastWriteId']=_0x5ba573;}function hu(_0x56b1dd,_0x5c988d,_0x50696a,_0x5e7f4a){f(_0x5e7f4a>_0x56b1dd['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x56b1dd['allWrites']['push']({'path':_0x5c988d,'children':_0x50696a,'writeId':_0x5e7f4a,'visible':!0x0}),_0x56b1dd['visibleWrites']=bi(_0x56b1dd['visibleWrites'],_0x5c988d,_0x50696a),_0x56b1dd['lastWriteId']=_0x5e7f4a;}function uu(_0xaaacd3,_0x4808c9){for(let _0x2af065=0x0;_0x2af065<_0xaaacd3['allWrites']['length'];_0x2af065++){const _0x374ca8=_0xaaacd3['allWrites'][_0x2af065];if(_0x374ca8['writeId']===_0x4808c9)return _0x374ca8;}return null;}function du(_0xd2e292,_0x36afb8){const _0x13fbe0=_0xd2e292['allWrites']['findIndex'](_0x41c86a=>_0x41c86a['writeId']===_0x36afb8);f(_0x13fbe0>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0xc83031=_0xd2e292['allWrites'][_0x13fbe0];_0xd2e292['allWrites']['splice'](_0x13fbe0,0x1);let _0x3c4adf=_0xc83031['visible'],_0x3ff89e=!0x1,_0x41c4fb=_0xd2e292['allWrites']['length']-0x1;for(;_0x3c4adf&&_0x41c4fb>=0x0;){const _0x38746f=_0xd2e292['allWrites'][_0x41c4fb];_0x38746f['visible']&&(_0x41c4fb>=_0x13fbe0&&fu(_0x38746f,_0xc83031['path'])?_0x3c4adf=!0x1:G(_0xc83031['path'],_0x38746f['path'])&&(_0x3ff89e=!0x0)),_0x41c4fb--;}if(_0x3c4adf){if(_0x3ff89e)return pu(_0xd2e292),!0x0;if(_0xc83031['snap'])_0xd2e292['visibleWrites']=or(_0xd2e292['visibleWrites'],_0xc83031['path']);else{const _0x178ab8=_0xc83031['children'];x(_0x178ab8,_0x793347=>{_0xd2e292['visibleWrites']=or(_0xd2e292['visibleWrites'],k(_0xc83031['path'],_0x793347));});}return!0x0;}else return!0x1;}function fu(_0x13c2bf,_0x48d8e2){if(_0x13c2bf['snap'])return G(_0x13c2bf['path'],_0x48d8e2);for(const _0x1c199f in _0x13c2bf['children'])if(_0x13c2bf['children']['hasOwnProperty'](_0x1c199f)&&G(k(_0x13c2bf['path'],_0x1c199f),_0x48d8e2))return!0x0;return!0x1;}function pu(_0x616df5){_0x616df5['visibleWrites']=Wo(_0x616df5['allWrites'],_u,w()),_0x616df5['allWrites']['length']>0x0?_0x616df5['lastWriteId']=_0x616df5['allWrites'][_0x616df5['allWrites']['length']-0x1]['writeId']:_0x616df5['lastWriteId']=-0x1;}function _u(_0x24739d){return _0x24739d['visible'];}function Wo(_0x4f1081,_0x211201,_0x5bd9c4){let _0x122679=K['empty']();for(let _0x3de410=0x0;_0x3de410<_0x4f1081['length'];++_0x3de410){const _0x3be864=_0x4f1081[_0x3de410];if(_0x211201(_0x3be864)){const _0x4cbc69=_0x3be864['path'];let _0x34bc59;if(_0x3be864['snap'])G(_0x5bd9c4,_0x4cbc69)?(_0x34bc59=F(_0x5bd9c4,_0x4cbc69),_0x122679=At(_0x122679,_0x34bc59,_0x3be864['snap'])):G(_0x4cbc69,_0x5bd9c4)&&(_0x34bc59=F(_0x4cbc69,_0x5bd9c4),_0x122679=At(_0x122679,w(),_0x3be864['snap']['getChild'](_0x34bc59)));else{if(_0x3be864['children']){if(G(_0x5bd9c4,_0x4cbc69))_0x34bc59=F(_0x5bd9c4,_0x4cbc69),_0x122679=bi(_0x122679,_0x34bc59,_0x3be864['children']);else{if(G(_0x4cbc69,_0x5bd9c4)){if(_0x34bc59=F(_0x4cbc69,_0x5bd9c4),v(_0x34bc59))_0x122679=bi(_0x122679,w(),_0x3be864['children']);else{const _0xf347f6=Le(_0x3be864['children'],y(_0x34bc59));if(_0xf347f6){const _0xbc0d63=_0xf347f6['getChild'](S(_0x34bc59));_0x122679=At(_0x122679,w(),_0xbc0d63);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x122679;}function Bo(_0x43e618,_0x37d9f4,_0x47e1a2,_0x1c15e0,_0x5ece32){if(!_0x1c15e0&&!_0x5ece32){const _0x16321b=ze(_0x43e618['visibleWrites'],_0x37d9f4);if(_0x16321b!=null)return _0x16321b;{const _0x169042=Ee(_0x43e618['visibleWrites'],_0x37d9f4);if(Ai(_0x169042))return _0x47e1a2;if(_0x47e1a2==null&&!Ri(_0x169042,w()))return null;{const _0x295cd5=_0x47e1a2||g['EMPTY_NODE'];return at(_0x169042,_0x295cd5);}}}else{const _0x1b9d82=Ee(_0x43e618['visibleWrites'],_0x37d9f4);if(!_0x5ece32&&Ai(_0x1b9d82))return _0x47e1a2;if(!_0x5ece32&&_0x47e1a2==null&&!Ri(_0x1b9d82,w()))return null;{const _0x1a13f6=function(_0x46778a){return(_0x46778a['visible']||_0x5ece32)&&(!_0x1c15e0||!~_0x1c15e0['indexOf'](_0x46778a['writeId']))&&(G(_0x46778a['path'],_0x37d9f4)||G(_0x37d9f4,_0x46778a['path']));},_0x249137=Wo(_0x43e618['allWrites'],_0x1a13f6,_0x37d9f4),_0x1a3a5c=_0x47e1a2||g['EMPTY_NODE'];return at(_0x249137,_0x1a3a5c);}}}function gu(_0x5e1fbf,_0x3d1d00,_0x51e593){let _0x17a48b=g['EMPTY_NODE'];const _0x1668c4=ze(_0x5e1fbf['visibleWrites'],_0x3d1d00);if(_0x1668c4)return _0x1668c4['isLeafNode']()||_0x1668c4['forEachChild'](R,(_0x544b9d,_0x54fb9b)=>{_0x17a48b=_0x17a48b['updateImmediateChild'](_0x544b9d,_0x54fb9b);}),_0x17a48b;if(_0x51e593){const _0x312f68=Ee(_0x5e1fbf['visibleWrites'],_0x3d1d00);return _0x51e593['forEachChild'](R,(_0x4eaea0,_0x5869ff)=>{const _0x29d69e=at(Ee(_0x312f68,new C(_0x4eaea0)),_0x5869ff);_0x17a48b=_0x17a48b['updateImmediateChild'](_0x4eaea0,_0x29d69e);}),ar(_0x312f68)['forEach'](_0x15e058=>{_0x17a48b=_0x17a48b['updateImmediateChild'](_0x15e058['name'],_0x15e058['node']);}),_0x17a48b;}else{const _0x44b07d=Ee(_0x5e1fbf['visibleWrites'],_0x3d1d00);return ar(_0x44b07d)['forEach'](_0x59a980=>{_0x17a48b=_0x17a48b['updateImmediateChild'](_0x59a980['name'],_0x59a980['node']);}),_0x17a48b;}}function mu(_0x31f85f,_0x5bed9c,_0x2ec547,_0x4893d2,_0x3a0cd5){f(_0x4893d2||_0x3a0cd5,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x5ba4aa=k(_0x5bed9c,_0x2ec547);if(Ri(_0x31f85f['visibleWrites'],_0x5ba4aa))return null;{const _0x2229df=Ee(_0x31f85f['visibleWrites'],_0x5ba4aa);return Ai(_0x2229df)?_0x3a0cd5['getChild'](_0x2ec547):at(_0x2229df,_0x3a0cd5['getChild'](_0x2ec547));}}function yu(_0x14e15d,_0xb3fdae,_0x419ff2,_0x22dad6){const _0x1d3690=k(_0xb3fdae,_0x419ff2),_0x354879=ze(_0x14e15d['visibleWrites'],_0x1d3690);if(_0x354879!=null)return _0x354879;if(_0x22dad6['isCompleteForChild'](_0x419ff2)){const _0x1594e2=Ee(_0x14e15d['visibleWrites'],_0x1d3690);return at(_0x1594e2,_0x22dad6['getNode']()['getImmediateChild'](_0x419ff2));}else return null;}function vu(_0x27499a,_0x487f83){return ze(_0x27499a['visibleWrites'],_0x487f83);}function Eu(_0x13b428,_0x4fb5a3,_0x1caebd,_0x1fe072,_0x4e459e,_0x290b2c,_0xa4491f){let _0x3ba4ea;const _0x58cf5d=Ee(_0x13b428['visibleWrites'],_0x4fb5a3),_0x2e3cf2=ze(_0x58cf5d,w());if(_0x2e3cf2!=null)_0x3ba4ea=_0x2e3cf2;else{if(_0x1caebd!=null)_0x3ba4ea=at(_0x58cf5d,_0x1caebd);else return[];}if(_0x3ba4ea=_0x3ba4ea['withIndex'](_0xa4491f),!_0x3ba4ea['isEmpty']()&&!_0x3ba4ea['isLeafNode']()){const _0x3f11a6=[],_0x37b732=_0xa4491f['getCompare'](),_0x59a162=_0x290b2c?_0x3ba4ea['getReverseIteratorFrom'](_0x1fe072,_0xa4491f):_0x3ba4ea['getIteratorFrom'](_0x1fe072,_0xa4491f);let _0x16b085=_0x59a162['getNext']();for(;_0x16b085&&_0x3f11a6['length']<_0x4e459e;)_0x37b732(_0x16b085,_0x1fe072)!==0x0&&_0x3f11a6['push'](_0x16b085),_0x16b085=_0x59a162['getNext']();return _0x3f11a6;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x4abf5a,_0x4b3ae6,_0x34ea13,_0x170820){return Bo(_0x4abf5a['writeTree'],_0x4abf5a['treePath'],_0x4b3ae6,_0x34ea13,_0x170820);}function is(_0x12dc54,_0x33da71){return gu(_0x12dc54['writeTree'],_0x12dc54['treePath'],_0x33da71);}function cr(_0x474418,_0x16a121,_0x54d3cc,_0xa777e1){return mu(_0x474418['writeTree'],_0x474418['treePath'],_0x16a121,_0x54d3cc,_0xa777e1);}function Tn(_0x19cf15,_0x183d51){return vu(_0x19cf15['writeTree'],k(_0x19cf15['treePath'],_0x183d51));}function wu(_0x3bdb16,_0x370d57,_0x2cf2c7,_0x258b21,_0x10c671,_0x4eaca5){return Eu(_0x3bdb16['writeTree'],_0x3bdb16['treePath'],_0x370d57,_0x2cf2c7,_0x258b21,_0x10c671,_0x4eaca5);}function ss(_0x3fb6b7,_0x2cfc58,_0x48b68d){return yu(_0x3fb6b7['writeTree'],_0x3fb6b7['treePath'],_0x2cfc58,_0x48b68d);}function Vo(_0x2d1abd,_0x5b230a){return Ho(k(_0x2d1abd['treePath'],_0x5b230a),_0x2d1abd['writeTree']);}function Ho(_0x28041a,_0x854580){return{'treePath':_0x28041a,'writeTree':_0x854580};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x2c6fa2){const _0x3a06d7=_0x2c6fa2['type'],_0x21eff3=_0x2c6fa2['childName'];f(_0x3a06d7==='child_added'||_0x3a06d7==='child_changed'||_0x3a06d7==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x21eff3!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x57e006=this['changeMap']['get'](_0x21eff3);if(_0x57e006){const _0x7d7ecf=_0x57e006['type'];if(_0x3a06d7==='child_added'&&_0x7d7ecf==='child_removed')this['changeMap']['set'](_0x21eff3,xt(_0x21eff3,_0x2c6fa2['snapshotNode'],_0x57e006['snapshotNode']));else{if(_0x3a06d7==='child_removed'&&_0x7d7ecf==='child_added')this['changeMap']['delete'](_0x21eff3);else{if(_0x3a06d7==='child_removed'&&_0x7d7ecf==='child_changed')this['changeMap']['set'](_0x21eff3,Lt(_0x21eff3,_0x57e006['oldSnap']));else{if(_0x3a06d7==='child_changed'&&_0x7d7ecf==='child_added')this['changeMap']['set'](_0x21eff3,rt(_0x21eff3,_0x2c6fa2['snapshotNode']));else{if(_0x3a06d7==='child_changed'&&_0x7d7ecf==='child_changed')this['changeMap']['set'](_0x21eff3,xt(_0x21eff3,_0x2c6fa2['snapshotNode'],_0x57e006['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x2c6fa2+'\x20occurred\x20after\x20'+_0x57e006);}}}}}else this['changeMap']['set'](_0x21eff3,_0x2c6fa2);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x5f1015){return null;}['getChildAfterChild'](_0x57ef45,_0x2f3fb8,_0x567ac5){return null;}}const $o=new Tu();class rs{constructor(_0x551506,_0x507df3,_0x3046bd=null){this['writes_']=_0x551506,this['viewCache_']=_0x507df3,this['optCompleteServerCache_']=_0x3046bd;}['getCompleteChild'](_0xcee171){const _0x32a81e=this['viewCache_']['eventCache'];if(_0x32a81e['isCompleteForChild'](_0xcee171))return _0x32a81e['getNode']()['getImmediateChild'](_0xcee171);{const _0x2a3361=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0xcee171,_0x2a3361);}}['getChildAfterChild'](_0x313317,_0x32780e,_0xfdfcb5){const _0x346308=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x48a9fc=wu(this['writes_'],_0x346308,_0x32780e,0x1,_0xfdfcb5,_0x313317);return _0x48a9fc['length']===0x0?null:_0x48a9fc[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0xa0752e){return{'filter':_0xa0752e};}function bu(_0x309320,_0x4b7420){f(_0x4b7420['eventCache']['getNode']()['isIndexed'](_0x309320['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x4b7420['serverCache']['getNode']()['isIndexed'](_0x309320['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x539b9a,_0x42c944,_0x26c059,_0x34890a,_0x273f97){const _0x1599fa=new Cu();let _0x198166,_0x5d476e;if(_0x26c059['type']===z['OVERWRITE']){const _0x5a7419=_0x26c059;_0x5a7419['source']['fromUser']?_0x198166=ki(_0x539b9a,_0x42c944,_0x5a7419['path'],_0x5a7419['snap'],_0x34890a,_0x273f97,_0x1599fa):(f(_0x5a7419['source']['fromServer'],'Unknown\x20source.'),_0x5d476e=_0x5a7419['source']['tagged']||_0x42c944['serverCache']['isFiltered']()&&!v(_0x5a7419['path']),_0x198166=Sn(_0x539b9a,_0x42c944,_0x5a7419['path'],_0x5a7419['snap'],_0x34890a,_0x273f97,_0x5d476e,_0x1599fa));}else{if(_0x26c059['type']===z['MERGE']){const _0x149adc=_0x26c059;_0x149adc['source']['fromUser']?_0x198166=ku(_0x539b9a,_0x42c944,_0x149adc['path'],_0x149adc['children'],_0x34890a,_0x273f97,_0x1599fa):(f(_0x149adc['source']['fromServer'],'Unknown\x20source.'),_0x5d476e=_0x149adc['source']['tagged']||_0x42c944['serverCache']['isFiltered'](),_0x198166=Pi(_0x539b9a,_0x42c944,_0x149adc['path'],_0x149adc['children'],_0x34890a,_0x273f97,_0x5d476e,_0x1599fa));}else{if(_0x26c059['type']===z['ACK_USER_WRITE']){const _0x58955d=_0x26c059;_0x58955d['revert']?_0x198166=Ou(_0x539b9a,_0x42c944,_0x58955d['path'],_0x34890a,_0x273f97,_0x1599fa):_0x198166=Pu(_0x539b9a,_0x42c944,_0x58955d['path'],_0x58955d['affectedTree'],_0x34890a,_0x273f97,_0x1599fa);}else{if(_0x26c059['type']===z['LISTEN_COMPLETE'])_0x198166=Nu(_0x539b9a,_0x42c944,_0x26c059['path'],_0x34890a,_0x1599fa);else throw ht('Unknown\x20operation\x20type:\x20'+_0x26c059['type']);}}}const _0x38abdf=_0x1599fa['getChanges']();return Au(_0x42c944,_0x198166,_0x38abdf),{'viewCache':_0x198166,'changes':_0x38abdf};}function Au(_0x48c903,_0x4cb99d,_0x1e8ed6){const _0x5882aa=_0x4cb99d['eventCache'];if(_0x5882aa['isFullyInitialized']()){const _0x21d79c=_0x5882aa['getNode']()['isLeafNode']()||_0x5882aa['getNode']()['isEmpty'](),_0x1817e4=wn(_0x48c903);(_0x1e8ed6['length']>0x0||!_0x48c903['eventCache']['isFullyInitialized']()||_0x21d79c&&!_0x5882aa['getNode']()['equals'](_0x1817e4)||!_0x5882aa['getNode']()['getPriority']()['equals'](_0x1817e4['getPriority']()))&&_0x1e8ed6['push'](Lo(wn(_0x4cb99d)));}}function Go(_0x5a26c9,_0x5b8d2c,_0x52fafa,_0x20330c,_0x2cd50e,_0x44fc44){const _0x4cd1d7=_0x5b8d2c['eventCache'];if(Tn(_0x20330c,_0x52fafa)!=null)return _0x5b8d2c;{let _0x120bd9,_0xb19da9;if(v(_0x52fafa)){if(f(_0x5b8d2c['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x5b8d2c['serverCache']['isFiltered']()){const _0x180db0=Ve(_0x5b8d2c),_0x5e8cd3=_0x180db0 instanceof g?_0x180db0:g['EMPTY_NODE'],_0x5b4c2c=is(_0x20330c,_0x5e8cd3);_0x120bd9=_0x5a26c9['filter']['updateFullNode'](_0x5b8d2c['eventCache']['getNode'](),_0x5b4c2c,_0x44fc44);}else{const _0x53cb51=Cn(_0x20330c,Ve(_0x5b8d2c));_0x120bd9=_0x5a26c9['filter']['updateFullNode'](_0x5b8d2c['eventCache']['getNode'](),_0x53cb51,_0x44fc44);}}else{const _0x280cc8=y(_0x52fafa);if(_0x280cc8==='.priority'){f(Ce(_0x52fafa)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x1d778e=_0x4cd1d7['getNode']();_0xb19da9=_0x5b8d2c['serverCache']['getNode']();const _0x36e050=cr(_0x20330c,_0x52fafa,_0x1d778e,_0xb19da9);_0x36e050!=null?_0x120bd9=_0x5a26c9['filter']['updatePriority'](_0x1d778e,_0x36e050):_0x120bd9=_0x4cd1d7['getNode']();}else{const _0x1f73a3=S(_0x52fafa);let _0x4a1788;if(_0x4cd1d7['isCompleteForChild'](_0x280cc8)){_0xb19da9=_0x5b8d2c['serverCache']['getNode']();const _0x2e4bf6=cr(_0x20330c,_0x52fafa,_0x4cd1d7['getNode'](),_0xb19da9);_0x2e4bf6!=null?_0x4a1788=_0x4cd1d7['getNode']()['getImmediateChild'](_0x280cc8)['updateChild'](_0x1f73a3,_0x2e4bf6):_0x4a1788=_0x4cd1d7['getNode']()['getImmediateChild'](_0x280cc8);}else _0x4a1788=ss(_0x20330c,_0x280cc8,_0x5b8d2c['serverCache']);_0x4a1788!=null?_0x120bd9=_0x5a26c9['filter']['updateChild'](_0x4cd1d7['getNode'](),_0x280cc8,_0x4a1788,_0x1f73a3,_0x2cd50e,_0x44fc44):_0x120bd9=_0x4cd1d7['getNode']();}}return Rt(_0x5b8d2c,_0x120bd9,_0x4cd1d7['isFullyInitialized']()||v(_0x52fafa),_0x5a26c9['filter']['filtersNodes']());}}function Sn(_0x1fd2cf,_0x28fc1b,_0x273634,_0x5699e4,_0x4a1b89,_0x12a4ec,_0x5d45a9,_0x173eb7){const _0x1b3d1e=_0x28fc1b['serverCache'];let _0xecb59e;const _0x21db1c=_0x5d45a9?_0x1fd2cf['filter']:_0x1fd2cf['filter']['getIndexedFilter']();if(v(_0x273634))_0xecb59e=_0x21db1c['updateFullNode'](_0x1b3d1e['getNode'](),_0x5699e4,null);else{if(_0x21db1c['filtersNodes']()&&!_0x1b3d1e['isFiltered']()){const _0x1c02d0=_0x1b3d1e['getNode']()['updateChild'](_0x273634,_0x5699e4);_0xecb59e=_0x21db1c['updateFullNode'](_0x1b3d1e['getNode'](),_0x1c02d0,null);}else{const _0x57475a=y(_0x273634);if(!_0x1b3d1e['isCompleteForPath'](_0x273634)&&Ce(_0x273634)>0x1)return _0x28fc1b;const _0x137a3d=S(_0x273634),_0x2b4cac=_0x1b3d1e['getNode']()['getImmediateChild'](_0x57475a)['updateChild'](_0x137a3d,_0x5699e4);_0x57475a==='.priority'?_0xecb59e=_0x21db1c['updatePriority'](_0x1b3d1e['getNode'](),_0x2b4cac):_0xecb59e=_0x21db1c['updateChild'](_0x1b3d1e['getNode'](),_0x57475a,_0x2b4cac,_0x137a3d,$o,null);}}const _0x4497d0=Fo(_0x28fc1b,_0xecb59e,_0x1b3d1e['isFullyInitialized']()||v(_0x273634),_0x21db1c['filtersNodes']()),_0xdf9468=new rs(_0x4a1b89,_0x4497d0,_0x12a4ec);return Go(_0x1fd2cf,_0x4497d0,_0x273634,_0x4a1b89,_0xdf9468,_0x173eb7);}function ki(_0x48a787,_0x396c2f,_0x2ad116,_0x583416,_0xf35340,_0x24fdc4,_0x530521){const _0x5378de=_0x396c2f['eventCache'];let _0x1e6704,_0x320a09;const _0x39ca23=new rs(_0xf35340,_0x396c2f,_0x24fdc4);if(v(_0x2ad116))_0x320a09=_0x48a787['filter']['updateFullNode'](_0x396c2f['eventCache']['getNode'](),_0x583416,_0x530521),_0x1e6704=Rt(_0x396c2f,_0x320a09,!0x0,_0x48a787['filter']['filtersNodes']());else{const _0x10ffc7=y(_0x2ad116);if(_0x10ffc7==='.priority')_0x320a09=_0x48a787['filter']['updatePriority'](_0x396c2f['eventCache']['getNode'](),_0x583416),_0x1e6704=Rt(_0x396c2f,_0x320a09,_0x5378de['isFullyInitialized'](),_0x5378de['isFiltered']());else{const _0x583c8c=S(_0x2ad116),_0x1c7e3a=_0x5378de['getNode']()['getImmediateChild'](_0x10ffc7);let _0x2e26d6;if(v(_0x583c8c))_0x2e26d6=_0x583416;else{const _0x3feb0e=_0x39ca23['getCompleteChild'](_0x10ffc7);_0x3feb0e!=null?ji(_0x583c8c)==='.priority'&&_0x3feb0e['getChild'](Ro(_0x583c8c))['isEmpty']()?_0x2e26d6=_0x3feb0e:_0x2e26d6=_0x3feb0e['updateChild'](_0x583c8c,_0x583416):_0x2e26d6=g['EMPTY_NODE'];}if(_0x1c7e3a['equals'](_0x2e26d6))_0x1e6704=_0x396c2f;else{const _0x40f380=_0x48a787['filter']['updateChild'](_0x5378de['getNode'](),_0x10ffc7,_0x2e26d6,_0x583c8c,_0x39ca23,_0x530521);_0x1e6704=Rt(_0x396c2f,_0x40f380,_0x5378de['isFullyInitialized'](),_0x48a787['filter']['filtersNodes']());}}}return _0x1e6704;}function lr(_0x3cc44e,_0x1bbc54){return _0x3cc44e['eventCache']['isCompleteForChild'](_0x1bbc54);}function ku(_0x1d6865,_0x401d8c,_0x3ccd06,_0x53854f,_0x3d35e7,_0x539dff,_0x4f7e6a){let _0x1e2920=_0x401d8c;return _0x53854f['foreach']((_0x4faaf9,_0x5bae00)=>{const _0xb37e0e=k(_0x3ccd06,_0x4faaf9);lr(_0x401d8c,y(_0xb37e0e))&&(_0x1e2920=ki(_0x1d6865,_0x1e2920,_0xb37e0e,_0x5bae00,_0x3d35e7,_0x539dff,_0x4f7e6a));}),_0x53854f['foreach']((_0x5395da,_0x263aa6)=>{const _0x32a280=k(_0x3ccd06,_0x5395da);lr(_0x401d8c,y(_0x32a280))||(_0x1e2920=ki(_0x1d6865,_0x1e2920,_0x32a280,_0x263aa6,_0x3d35e7,_0x539dff,_0x4f7e6a));}),_0x1e2920;}function hr(_0x2ade9b,_0x25cb88,_0x50aa73){return _0x50aa73['foreach']((_0x13216b,_0x927d45)=>{_0x25cb88=_0x25cb88['updateChild'](_0x13216b,_0x927d45);}),_0x25cb88;}function Pi(_0xacb2e5,_0x4dec77,_0x293313,_0x49b5f9,_0x2138c8,_0x3dabcd,_0x4a54ed,_0x2d86c1){if(_0x4dec77['serverCache']['getNode']()['isEmpty']()&&!_0x4dec77['serverCache']['isFullyInitialized']())return _0x4dec77;let _0x48d780=_0x4dec77,_0x169ccb;v(_0x293313)?_0x169ccb=_0x49b5f9:_0x169ccb=new b(null)['setTree'](_0x293313,_0x49b5f9);const _0x1a0f46=_0x4dec77['serverCache']['getNode']();return _0x169ccb['children']['inorderTraversal']((_0x519b4e,_0x5dc41f)=>{if(_0x1a0f46['hasChild'](_0x519b4e)){const _0x173906=_0x4dec77['serverCache']['getNode']()['getImmediateChild'](_0x519b4e),_0x2d93ba=hr(_0xacb2e5,_0x173906,_0x5dc41f);_0x48d780=Sn(_0xacb2e5,_0x48d780,new C(_0x519b4e),_0x2d93ba,_0x2138c8,_0x3dabcd,_0x4a54ed,_0x2d86c1);}}),_0x169ccb['children']['inorderTraversal']((_0x2c0846,_0x46a2ab)=>{const _0x552799=!_0x4dec77['serverCache']['isCompleteForChild'](_0x2c0846)&&_0x46a2ab['value']===null;if(!_0x1a0f46['hasChild'](_0x2c0846)&&!_0x552799){const _0x163ba3=_0x4dec77['serverCache']['getNode']()['getImmediateChild'](_0x2c0846),_0x4f4a57=hr(_0xacb2e5,_0x163ba3,_0x46a2ab);_0x48d780=Sn(_0xacb2e5,_0x48d780,new C(_0x2c0846),_0x4f4a57,_0x2138c8,_0x3dabcd,_0x4a54ed,_0x2d86c1);}}),_0x48d780;}function Pu(_0x3daff7,_0x1c2362,_0x4a24f4,_0x1c04fd,_0x3edb6a,_0x367c7b,_0x510135){if(Tn(_0x3edb6a,_0x4a24f4)!=null)return _0x1c2362;const _0x3c3891=_0x1c2362['serverCache']['isFiltered'](),_0x27c4a7=_0x1c2362['serverCache'];if(_0x1c04fd['value']!=null){if(v(_0x4a24f4)&&_0x27c4a7['isFullyInitialized']()||_0x27c4a7['isCompleteForPath'](_0x4a24f4))return Sn(_0x3daff7,_0x1c2362,_0x4a24f4,_0x27c4a7['getNode']()['getChild'](_0x4a24f4),_0x3edb6a,_0x367c7b,_0x3c3891,_0x510135);if(v(_0x4a24f4)){let _0x17ae02=new b(null);return _0x27c4a7['getNode']()['forEachChild'](ve,(_0x5376fb,_0x5dbc5a)=>{_0x17ae02=_0x17ae02['set'](new C(_0x5376fb),_0x5dbc5a);}),Pi(_0x3daff7,_0x1c2362,_0x4a24f4,_0x17ae02,_0x3edb6a,_0x367c7b,_0x3c3891,_0x510135);}else return _0x1c2362;}else{let _0x45e8ff=new b(null);return _0x1c04fd['foreach']((_0x2159fd,_0x4c3581)=>{const _0x5dd36b=k(_0x4a24f4,_0x2159fd);_0x27c4a7['isCompleteForPath'](_0x5dd36b)&&(_0x45e8ff=_0x45e8ff['set'](_0x2159fd,_0x27c4a7['getNode']()['getChild'](_0x5dd36b)));}),Pi(_0x3daff7,_0x1c2362,_0x4a24f4,_0x45e8ff,_0x3edb6a,_0x367c7b,_0x3c3891,_0x510135);}}function Nu(_0x1c7e94,_0x29ee03,_0x38ffd8,_0x4c6c8a,_0xe2c3ab){const _0x1e78df=_0x29ee03['serverCache'],_0x631846=Fo(_0x29ee03,_0x1e78df['getNode'](),_0x1e78df['isFullyInitialized']()||v(_0x38ffd8),_0x1e78df['isFiltered']());return Go(_0x1c7e94,_0x631846,_0x38ffd8,_0x4c6c8a,$o,_0xe2c3ab);}function Ou(_0x1af5af,_0x4c970c,_0x41e83b,_0x282f16,_0x367571,_0x84ee1d){let _0x57ff44;if(Tn(_0x282f16,_0x41e83b)!=null)return _0x4c970c;{const _0x151318=new rs(_0x282f16,_0x4c970c,_0x367571),_0x17142e=_0x4c970c['eventCache']['getNode']();let _0x1cc63a;if(v(_0x41e83b)||y(_0x41e83b)==='.priority'){let _0x2247dc;if(_0x4c970c['serverCache']['isFullyInitialized']())_0x2247dc=Cn(_0x282f16,Ve(_0x4c970c));else{const _0x5286c8=_0x4c970c['serverCache']['getNode']();f(_0x5286c8 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x2247dc=is(_0x282f16,_0x5286c8);}_0x2247dc=_0x2247dc,_0x1cc63a=_0x1af5af['filter']['updateFullNode'](_0x17142e,_0x2247dc,_0x84ee1d);}else{const _0x325e7e=y(_0x41e83b);let _0x8bb22e=ss(_0x282f16,_0x325e7e,_0x4c970c['serverCache']);_0x8bb22e==null&&_0x4c970c['serverCache']['isCompleteForChild'](_0x325e7e)&&(_0x8bb22e=_0x17142e['getImmediateChild'](_0x325e7e)),_0x8bb22e!=null?_0x1cc63a=_0x1af5af['filter']['updateChild'](_0x17142e,_0x325e7e,_0x8bb22e,S(_0x41e83b),_0x151318,_0x84ee1d):_0x4c970c['eventCache']['getNode']()['hasChild'](_0x325e7e)?_0x1cc63a=_0x1af5af['filter']['updateChild'](_0x17142e,_0x325e7e,g['EMPTY_NODE'],S(_0x41e83b),_0x151318,_0x84ee1d):_0x1cc63a=_0x17142e,_0x1cc63a['isEmpty']()&&_0x4c970c['serverCache']['isFullyInitialized']()&&(_0x57ff44=Cn(_0x282f16,Ve(_0x4c970c)),_0x57ff44['isLeafNode']()&&(_0x1cc63a=_0x1af5af['filter']['updateFullNode'](_0x1cc63a,_0x57ff44,_0x84ee1d)));}return _0x57ff44=_0x4c970c['serverCache']['isFullyInitialized']()||Tn(_0x282f16,w())!=null,Rt(_0x4c970c,_0x1cc63a,_0x57ff44,_0x1af5af['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x3841d1,_0x3dbfa3){this['query_']=_0x3841d1,this['eventRegistrations_']=[];const _0x37b45f=this['query_']['_queryParams'],_0x5a537d=new Xi(_0x37b45f['getIndex']()),_0x105838=Kh(_0x37b45f);this['processor_']=Su(_0x105838);const _0x2fba1e=_0x3dbfa3['serverCache'],_0x387029=_0x3dbfa3['eventCache'],_0x1b4758=_0x5a537d['updateFullNode'](g['EMPTY_NODE'],_0x2fba1e['getNode'](),null),_0x2d9d3c=_0x105838['updateFullNode'](g['EMPTY_NODE'],_0x387029['getNode'](),null),_0x4e7d5a=new Te(_0x1b4758,_0x2fba1e['isFullyInitialized'](),_0x5a537d['filtersNodes']()),_0x14e592=new Te(_0x2d9d3c,_0x387029['isFullyInitialized'](),_0x105838['filtersNodes']());this['viewCache_']=Un(_0x14e592,_0x4e7d5a),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x43562c){return _0x43562c['viewCache_']['serverCache']['getNode']();}function Lu(_0xd941de){return wn(_0xd941de['viewCache_']);}function xu(_0x1e5e22,_0x1a5323){const _0xbd767c=Ve(_0x1e5e22['viewCache_']);return _0xbd767c&&(_0x1e5e22['query']['_queryParams']['loadsAllData']()||!v(_0x1a5323)&&!_0xbd767c['getImmediateChild'](y(_0x1a5323))['isEmpty']())?_0xbd767c['getChild'](_0x1a5323):null;}function ur(_0xa7acfb){return _0xa7acfb['eventRegistrations_']['length']===0x0;}function Fu(_0x5ace49,_0x32437d){_0x5ace49['eventRegistrations_']['push'](_0x32437d);}function dr(_0x2daabc,_0x53aba0,_0xb4dc5b){const _0x3687e6=[];if(_0xb4dc5b){f(_0x53aba0==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x310cab=_0x2daabc['query']['_path'];_0x2daabc['eventRegistrations_']['forEach'](_0x1afa46=>{const _0x39ecfc=_0x1afa46['createCancelEvent'](_0xb4dc5b,_0x310cab);_0x39ecfc&&_0x3687e6['push'](_0x39ecfc);});}if(_0x53aba0){let _0x306a50=[];for(let _0x356d3b=0x0;_0x356d3b<_0x2daabc['eventRegistrations_']['length'];++_0x356d3b){const _0x5a2ef4=_0x2daabc['eventRegistrations_'][_0x356d3b];if(!_0x5a2ef4['matches'](_0x53aba0))_0x306a50['push'](_0x5a2ef4);else{if(_0x53aba0['hasAnyCallback']()){_0x306a50=_0x306a50['concat'](_0x2daabc['eventRegistrations_']['slice'](_0x356d3b+0x1));break;}}}_0x2daabc['eventRegistrations_']=_0x306a50;}else _0x2daabc['eventRegistrations_']=[];return _0x3687e6;}function fr(_0x47ed45,_0x206a8f,_0x58bf05,_0x10e82e){_0x206a8f['type']===z['MERGE']&&_0x206a8f['source']['queryId']!==null&&(f(Ve(_0x47ed45['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x47ed45['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x47507b=_0x47ed45['viewCache_'],_0x348ce5=Ru(_0x47ed45['processor_'],_0x47507b,_0x206a8f,_0x58bf05,_0x10e82e);return bu(_0x47ed45['processor_'],_0x348ce5['viewCache']),f(_0x348ce5['viewCache']['serverCache']['isFullyInitialized']()||!_0x47507b['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x47ed45['viewCache_']=_0x348ce5['viewCache'],qo(_0x47ed45,_0x348ce5['changes'],_0x348ce5['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x25cf7d,_0x43f0a8){const _0x1576b0=_0x25cf7d['viewCache_']['eventCache'],_0x28be96=[];return _0x1576b0['getNode']()['isLeafNode']()||_0x1576b0['getNode']()['forEachChild'](R,(_0x219d45,_0x3be50a)=>{_0x28be96['push'](rt(_0x219d45,_0x3be50a));}),_0x1576b0['isFullyInitialized']()&&_0x28be96['push'](Lo(_0x1576b0['getNode']())),qo(_0x25cf7d,_0x28be96,_0x1576b0['getNode'](),_0x43f0a8);}function qo(_0x516443,_0x34d851,_0x122c59,_0x5c8e3d){const _0x29e6d2=_0x5c8e3d?[_0x5c8e3d]:_0x516443['eventRegistrations_'];return ru(_0x516443['eventGenerator_'],_0x34d851,_0x122c59,_0x29e6d2);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x71c115){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x71c115;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x8eb2d4){return _0x8eb2d4['views']['size']===0x0;}function os(_0x229983,_0x4a0205,_0x1b75bf,_0x223885){const _0x2117e6=_0x4a0205['source']['queryId'];if(_0x2117e6!==null){const _0x2fce39=_0x229983['views']['get'](_0x2117e6);return f(_0x2fce39!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x2fce39,_0x4a0205,_0x1b75bf,_0x223885);}else{let _0x35886c=[];for(const _0x5456bc of _0x229983['views']['values']())_0x35886c=_0x35886c['concat'](fr(_0x5456bc,_0x4a0205,_0x1b75bf,_0x223885));return _0x35886c;}}function jo(_0x18a719,_0xec24ca,_0x5267c3,_0x57b5ef,_0x9e05e3){const _0x6ae391=_0xec24ca['_queryIdentifier'],_0xed3fe9=_0x18a719['views']['get'](_0x6ae391);if(!_0xed3fe9){let _0x3a539e=Cn(_0x5267c3,_0x9e05e3?_0x57b5ef:null),_0x4ff36f=!0x1;_0x3a539e?_0x4ff36f=!0x0:_0x57b5ef instanceof g?(_0x3a539e=is(_0x5267c3,_0x57b5ef),_0x4ff36f=!0x1):(_0x3a539e=g['EMPTY_NODE'],_0x4ff36f=!0x1);const _0x20c957=Un(new Te(_0x3a539e,_0x4ff36f,!0x1),new Te(_0x57b5ef,_0x9e05e3,!0x1));return new Du(_0xec24ca,_0x20c957);}return _0xed3fe9;}function Hu(_0x540a66,_0x4b5882,_0x4b1096,_0x5d1fe9,_0x373b6b,_0x2d034d){const _0x248ba7=jo(_0x540a66,_0x4b5882,_0x5d1fe9,_0x373b6b,_0x2d034d);return _0x540a66['views']['has'](_0x4b5882['_queryIdentifier'])||_0x540a66['views']['set'](_0x4b5882['_queryIdentifier'],_0x248ba7),Fu(_0x248ba7,_0x4b1096),Uu(_0x248ba7,_0x4b1096);}function $u(_0x2833ba,_0xece6c1,_0x2a691a,_0x2fa38f){const _0x342e19=_0xece6c1['_queryIdentifier'],_0x5f43cf=[];let _0xbe4800=[];const _0x4a1e5a=Se(_0x2833ba);if(_0x342e19==='default'){for(const [_0x4c3d66,_0x31e9ac]of _0x2833ba['views']['entries']())_0xbe4800=_0xbe4800['concat'](dr(_0x31e9ac,_0x2a691a,_0x2fa38f)),ur(_0x31e9ac)&&(_0x2833ba['views']['delete'](_0x4c3d66),_0x31e9ac['query']['_queryParams']['loadsAllData']()||_0x5f43cf['push'](_0x31e9ac['query']));}else{const _0xf4048=_0x2833ba['views']['get'](_0x342e19);_0xf4048&&(_0xbe4800=_0xbe4800['concat'](dr(_0xf4048,_0x2a691a,_0x2fa38f)),ur(_0xf4048)&&(_0x2833ba['views']['delete'](_0x342e19),_0xf4048['query']['_queryParams']['loadsAllData']()||_0x5f43cf['push'](_0xf4048['query'])));}return _0x4a1e5a&&!Se(_0x2833ba)&&_0x5f43cf['push'](new(Bu())(_0xece6c1['_repo'],_0xece6c1['_path'])),{'removed':_0x5f43cf,'events':_0xbe4800};}function Ko(_0xf62772){const _0x238ad2=[];for(const _0x56d828 of _0xf62772['views']['values']())_0x56d828['query']['_queryParams']['loadsAllData']()||_0x238ad2['push'](_0x56d828);return _0x238ad2;}function Ie(_0x50d341,_0x40444b){let _0x3b476b=null;for(const _0x3a8397 of _0x50d341['views']['values']())_0x3b476b=_0x3b476b||xu(_0x3a8397,_0x40444b);return _0x3b476b;}function Yo(_0x5a62a7,_0x53a9c8){if(_0x53a9c8['_queryParams']['loadsAllData']())return Bn(_0x5a62a7);{const _0x2553b6=_0x53a9c8['_queryIdentifier'];return _0x5a62a7['views']['get'](_0x2553b6);}}function Qo(_0x4d05ce,_0x564f18){return Yo(_0x4d05ce,_0x564f18)!=null;}function Se(_0x1b147a){return Bn(_0x1b147a)!=null;}function Bn(_0x2bf87d){for(const _0x6e3820 of _0x2bf87d['views']['values']())if(_0x6e3820['query']['_queryParams']['loadsAllData']())return _0x6e3820;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x3bd1ad){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x3bd1ad;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x3f8e98){this['listenProvider_']=_0x3f8e98,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x3e82a9,_0x4d9fe0,_0x55f6f3,_0x2b77ae,_0x360061){return lu(_0x3e82a9['pendingWriteTree_'],_0x4d9fe0,_0x55f6f3,_0x2b77ae,_0x360061),_0x360061?_t(_0x3e82a9,new Be(es(),_0x4d9fe0,_0x55f6f3)):[];}function ju(_0x25eb6c,_0x4ad8ed,_0x3604df,_0x3d0594){hu(_0x25eb6c['pendingWriteTree_'],_0x4ad8ed,_0x3604df,_0x3d0594);const _0x307178=b['fromObject'](_0x3604df);return _t(_0x25eb6c,new ot(es(),_0x4ad8ed,_0x307178));}function _e(_0x43c2df,_0x225a71,_0x1a96b1=!0x1){const _0x129af2=uu(_0x43c2df['pendingWriteTree_'],_0x225a71);if(du(_0x43c2df['pendingWriteTree_'],_0x225a71)){let _0x499b2b=new b(null);return _0x129af2['snap']!=null?_0x499b2b=_0x499b2b['set'](w(),!0x0):x(_0x129af2['children'],_0x325320=>{_0x499b2b=_0x499b2b['set'](new C(_0x325320),!0x0);}),_t(_0x43c2df,new In(_0x129af2['path'],_0x499b2b,_0x1a96b1));}else return[];}function Yt(_0x49204b,_0xe881b,_0x257dca){return _t(_0x49204b,new Be(ts(),_0xe881b,_0x257dca));}function Ku(_0x52d188,_0x14a61d,_0x56e608){const _0x3bd080=b['fromObject'](_0x56e608);return _t(_0x52d188,new ot(ts(),_0x14a61d,_0x3bd080));}function Yu(_0x345f91,_0x187684){return _t(_0x345f91,new Ut(ts(),_0x187684));}function Qu(_0x4c3822,_0x2ca183,_0xd5de2f){const _0x13c804=cs(_0x4c3822,_0xd5de2f);if(_0x13c804){const _0x3cfe17=ls(_0x13c804),_0x7a1e6e=_0x3cfe17['path'],_0x5b9d49=_0x3cfe17['queryId'],_0x412424=F(_0x7a1e6e,_0x2ca183),_0x5c2a9f=new Ut(ns(_0x5b9d49),_0x412424);return hs(_0x4c3822,_0x7a1e6e,_0x5c2a9f);}else return[];}function An(_0x368b3b,_0x5d4fc4,_0x2b19c5,_0x3b1401,_0x41daf8=!0x1){const _0x1d6f29=_0x5d4fc4['_path'],_0x2588c9=_0x368b3b['syncPointTree_']['get'](_0x1d6f29);let _0x16308c=[];if(_0x2588c9&&(_0x5d4fc4['_queryIdentifier']==='default'||Qo(_0x2588c9,_0x5d4fc4))){const _0x9bd029=$u(_0x2588c9,_0x5d4fc4,_0x2b19c5,_0x3b1401);Vu(_0x2588c9)&&(_0x368b3b['syncPointTree_']=_0x368b3b['syncPointTree_']['remove'](_0x1d6f29));const _0x24fcc7=_0x9bd029['removed'];if(_0x16308c=_0x9bd029['events'],!_0x41daf8){const _0x4534a8=_0x24fcc7['findIndex'](_0x36084f=>_0x36084f['_queryParams']['loadsAllData']())!==-0x1,_0x52f398=_0x368b3b['syncPointTree_']['findOnPath'](_0x1d6f29,(_0x1f9663,_0x46a721)=>Se(_0x46a721));if(_0x4534a8&&!_0x52f398){const _0x3cecfa=_0x368b3b['syncPointTree_']['subtree'](_0x1d6f29);if(!_0x3cecfa['isEmpty']()){const _0x542c49=Zu(_0x3cecfa);for(let _0x589066=0x0;_0x589066<_0x542c49['length'];++_0x589066){const _0x1dd687=_0x542c49[_0x589066],_0x1d352b=_0x1dd687['query'],_0x3e7c36=ea(_0x368b3b,_0x1dd687);_0x368b3b['listenProvider_']['startListening'](kt(_0x1d352b),Wt(_0x368b3b,_0x1d352b),_0x3e7c36['hashFn'],_0x3e7c36['onComplete']);}}}!_0x52f398&&_0x24fcc7['length']>0x0&&!_0x3b1401&&(_0x4534a8?_0x368b3b['listenProvider_']['stopListening'](kt(_0x5d4fc4),null):_0x24fcc7['forEach'](_0x1198bd=>{const _0x40eee7=_0x368b3b['queryToTagMap']['get'](Hn(_0x1198bd));_0x368b3b['listenProvider_']['stopListening'](kt(_0x1198bd),_0x40eee7);}));}ed(_0x368b3b,_0x24fcc7);}return _0x16308c;}function Jo(_0x3f7609,_0x33867f,_0x35dd5a,_0x2fea7c){const _0x1f36e4=cs(_0x3f7609,_0x2fea7c);if(_0x1f36e4!=null){const _0xefe58d=ls(_0x1f36e4),_0x2bfded=_0xefe58d['path'],_0x1405ba=_0xefe58d['queryId'],_0x236e7d=F(_0x2bfded,_0x33867f),_0x30837c=new Be(ns(_0x1405ba),_0x236e7d,_0x35dd5a);return hs(_0x3f7609,_0x2bfded,_0x30837c);}else return[];}function Ju(_0x172c04,_0x450a80,_0x21798b,_0x533bde){const _0x3a4173=cs(_0x172c04,_0x533bde);if(_0x3a4173){const _0x53c5b9=ls(_0x3a4173),_0x5d28f7=_0x53c5b9['path'],_0x3e5356=_0x53c5b9['queryId'],_0x572a1a=F(_0x5d28f7,_0x450a80),_0x1f7c20=b['fromObject'](_0x21798b),_0x542e6d=new ot(ns(_0x3e5356),_0x572a1a,_0x1f7c20);return hs(_0x172c04,_0x5d28f7,_0x542e6d);}else return[];}function Ni(_0x2aa556,_0x57ef15,_0x4b1ca3,_0x2b04f4=!0x1){const _0x3de163=_0x57ef15['_path'];let _0x284c33=null,_0x159d89=!0x1;_0x2aa556['syncPointTree_']['foreachOnPath'](_0x3de163,(_0x3eb5c9,_0x256dde)=>{const _0x1c29ed=F(_0x3eb5c9,_0x3de163);_0x284c33=_0x284c33||Ie(_0x256dde,_0x1c29ed),_0x159d89=_0x159d89||Se(_0x256dde);});let _0x1cf496=_0x2aa556['syncPointTree_']['get'](_0x3de163);_0x1cf496?(_0x159d89=_0x159d89||Se(_0x1cf496),_0x284c33=_0x284c33||Ie(_0x1cf496,w())):(_0x1cf496=new zo(),_0x2aa556['syncPointTree_']=_0x2aa556['syncPointTree_']['set'](_0x3de163,_0x1cf496));let _0x2deb1f;_0x284c33!=null?_0x2deb1f=!0x0:(_0x2deb1f=!0x1,_0x284c33=g['EMPTY_NODE'],_0x2aa556['syncPointTree_']['subtree'](_0x3de163)['foreachChild']((_0x36b2bc,_0x1b8978)=>{const _0x38da09=Ie(_0x1b8978,w());_0x38da09&&(_0x284c33=_0x284c33['updateImmediateChild'](_0x36b2bc,_0x38da09));}));const _0x3da1dc=Qo(_0x1cf496,_0x57ef15);if(!_0x3da1dc&&!_0x57ef15['_queryParams']['loadsAllData']()){const _0x4f18db=Hn(_0x57ef15);f(!_0x2aa556['queryToTagMap']['has'](_0x4f18db),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x146375=td();_0x2aa556['queryToTagMap']['set'](_0x4f18db,_0x146375),_0x2aa556['tagToQueryMap']['set'](_0x146375,_0x4f18db);}const _0x1be07c=Wn(_0x2aa556['pendingWriteTree_'],_0x3de163);let _0xac5ea5=Hu(_0x1cf496,_0x57ef15,_0x4b1ca3,_0x1be07c,_0x284c33,_0x2deb1f);if(!_0x3da1dc&&!_0x159d89&&!_0x2b04f4){const _0x18a5d3=Yo(_0x1cf496,_0x57ef15);_0xac5ea5=_0xac5ea5['concat'](nd(_0x2aa556,_0x57ef15,_0x18a5d3));}return _0xac5ea5;}function Vn(_0x279d3a,_0xc8d5bc,_0x46c699){const _0x4e9e3c=_0x279d3a['pendingWriteTree_'],_0x306838=_0x279d3a['syncPointTree_']['findOnPath'](_0xc8d5bc,(_0x688409,_0x230cdd)=>{const _0x25d936=F(_0x688409,_0xc8d5bc),_0x31f0cd=Ie(_0x230cdd,_0x25d936);if(_0x31f0cd)return _0x31f0cd;});return Bo(_0x4e9e3c,_0xc8d5bc,_0x306838,_0x46c699,!0x0);}function Xu(_0x5e947d,_0x4a2888){const _0x8d447e=_0x4a2888['_path'];let _0x5694ce=null;_0x5e947d['syncPointTree_']['foreachOnPath'](_0x8d447e,(_0x1854e4,_0x5a6013)=>{const _0x4f4ec0=F(_0x1854e4,_0x8d447e);_0x5694ce=_0x5694ce||Ie(_0x5a6013,_0x4f4ec0);});let _0x30117c=_0x5e947d['syncPointTree_']['get'](_0x8d447e);_0x30117c?_0x5694ce=_0x5694ce||Ie(_0x30117c,w()):(_0x30117c=new zo(),_0x5e947d['syncPointTree_']=_0x5e947d['syncPointTree_']['set'](_0x8d447e,_0x30117c));const _0x4b782f=_0x5694ce!=null,_0x2083b9=_0x4b782f?new Te(_0x5694ce,!0x0,!0x1):null,_0x140c25=Wn(_0x5e947d['pendingWriteTree_'],_0x4a2888['_path']),_0x1035cd=jo(_0x30117c,_0x4a2888,_0x140c25,_0x4b782f?_0x2083b9['getNode']():g['EMPTY_NODE'],_0x4b782f);return Lu(_0x1035cd);}function _t(_0x59122e,_0x4e3391){return Xo(_0x4e3391,_0x59122e['syncPointTree_'],null,Wn(_0x59122e['pendingWriteTree_'],w()));}function Xo(_0x16c2fa,_0x195ebe,_0x3bcc29,_0x30f7a5){if(v(_0x16c2fa['path']))return Zo(_0x16c2fa,_0x195ebe,_0x3bcc29,_0x30f7a5);{const _0x4fccb3=_0x195ebe['get'](w());_0x3bcc29==null&&_0x4fccb3!=null&&(_0x3bcc29=Ie(_0x4fccb3,w()));let _0x3a5b44=[];const _0x87956d=y(_0x16c2fa['path']),_0x48689f=_0x16c2fa['operationForChild'](_0x87956d),_0x3b7213=_0x195ebe['children']['get'](_0x87956d);if(_0x3b7213&&_0x48689f){const _0x426224=_0x3bcc29?_0x3bcc29['getImmediateChild'](_0x87956d):null,_0x3aedbc=Vo(_0x30f7a5,_0x87956d);_0x3a5b44=_0x3a5b44['concat'](Xo(_0x48689f,_0x3b7213,_0x426224,_0x3aedbc));}return _0x4fccb3&&(_0x3a5b44=_0x3a5b44['concat'](os(_0x4fccb3,_0x16c2fa,_0x30f7a5,_0x3bcc29))),_0x3a5b44;}}function Zo(_0x498d39,_0x502d20,_0x15c4be,_0x351902){const _0x119341=_0x502d20['get'](w());_0x15c4be==null&&_0x119341!=null&&(_0x15c4be=Ie(_0x119341,w()));let _0xcd0cc1=[];return _0x502d20['children']['inorderTraversal']((_0x243181,_0x461a4b)=>{const _0x4ccdea=_0x15c4be?_0x15c4be['getImmediateChild'](_0x243181):null,_0x484bda=Vo(_0x351902,_0x243181),_0xf777c6=_0x498d39['operationForChild'](_0x243181);_0xf777c6&&(_0xcd0cc1=_0xcd0cc1['concat'](Zo(_0xf777c6,_0x461a4b,_0x4ccdea,_0x484bda)));}),_0x119341&&(_0xcd0cc1=_0xcd0cc1['concat'](os(_0x119341,_0x498d39,_0x351902,_0x15c4be))),_0xcd0cc1;}function ea(_0x2e26e1,_0x468796){const _0x5f46aa=_0x468796['query'],_0x536b97=Wt(_0x2e26e1,_0x5f46aa);return{'hashFn':()=>(Mu(_0x468796)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x3edcc7=>{if(_0x3edcc7==='ok')return _0x536b97?Qu(_0x2e26e1,_0x5f46aa['_path'],_0x536b97):Yu(_0x2e26e1,_0x5f46aa['_path']);{const _0xddbdee=Kl(_0x3edcc7,_0x5f46aa);return An(_0x2e26e1,_0x5f46aa,null,_0xddbdee);}}};}function Wt(_0x4d7085,_0x12c0b0){const _0xea32e6=Hn(_0x12c0b0);return _0x4d7085['queryToTagMap']['get'](_0xea32e6);}function Hn(_0x17f4e2){return _0x17f4e2['_path']['toString']()+'$'+_0x17f4e2['_queryIdentifier'];}function cs(_0x2b62fd,_0x1f2f0b){return _0x2b62fd['tagToQueryMap']['get'](_0x1f2f0b);}function ls(_0x5135f7){const _0x5b9d10=_0x5135f7['indexOf']('$');return f(_0x5b9d10!==-0x1&&_0x5b9d10<_0x5135f7['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x5135f7['substr'](_0x5b9d10+0x1),'path':new C(_0x5135f7['substr'](0x0,_0x5b9d10))};}function hs(_0x3399eb,_0x274497,_0x1b6d4b){const _0x35f937=_0x3399eb['syncPointTree_']['get'](_0x274497);f(_0x35f937,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x387292=Wn(_0x3399eb['pendingWriteTree_'],_0x274497);return os(_0x35f937,_0x1b6d4b,_0x387292,null);}function Zu(_0x4490c5){return _0x4490c5['fold']((_0x43604e,_0x533aab,_0x2f7162)=>{if(_0x533aab&&Se(_0x533aab))return[Bn(_0x533aab)];{let _0x18f486=[];return _0x533aab&&(_0x18f486=Ko(_0x533aab)),x(_0x2f7162,(_0x1facfb,_0x49f750)=>{_0x18f486=_0x18f486['concat'](_0x49f750);}),_0x18f486;}});}function kt(_0x3210b3){return _0x3210b3['_queryParams']['loadsAllData']()&&!_0x3210b3['_queryParams']['isDefault']()?new(qu())(_0x3210b3['_repo'],_0x3210b3['_path']):_0x3210b3;}function ed(_0x5776bf,_0x451098){for(let _0x3a2538=0x0;_0x3a2538<_0x451098['length'];++_0x3a2538){const _0x44b129=_0x451098[_0x3a2538];if(!_0x44b129['_queryParams']['loadsAllData']()){const _0x2f4633=Hn(_0x44b129),_0x352e1f=_0x5776bf['queryToTagMap']['get'](_0x2f4633);_0x5776bf['queryToTagMap']['delete'](_0x2f4633),_0x5776bf['tagToQueryMap']['delete'](_0x352e1f);}}}function td(){return zu++;}function nd(_0x3e8b2f,_0x1c07a4,_0x181aeb){const _0x47574e=_0x1c07a4['_path'],_0x1254ad=Wt(_0x3e8b2f,_0x1c07a4),_0x2886e9=ea(_0x3e8b2f,_0x181aeb),_0x13fcf4=_0x3e8b2f['listenProvider_']['startListening'](kt(_0x1c07a4),_0x1254ad,_0x2886e9['hashFn'],_0x2886e9['onComplete']),_0x362980=_0x3e8b2f['syncPointTree_']['subtree'](_0x47574e);if(_0x1254ad)f(!Se(_0x362980['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0xf0db09=_0x362980['fold']((_0x4532a8,_0x5b7ad0,_0x2ec941)=>{if(!v(_0x4532a8)&&_0x5b7ad0&&Se(_0x5b7ad0))return[Bn(_0x5b7ad0)['query']];{let _0x469e07=[];return _0x5b7ad0&&(_0x469e07=_0x469e07['concat'](Ko(_0x5b7ad0)['map'](_0x28f66f=>_0x28f66f['query']))),x(_0x2ec941,(_0x20567f,_0x489134)=>{_0x469e07=_0x469e07['concat'](_0x489134);}),_0x469e07;}});for(let _0x420579=0x0;_0x420579<_0xf0db09['length'];++_0x420579){const _0x227d78=_0xf0db09[_0x420579];_0x3e8b2f['listenProvider_']['stopListening'](kt(_0x227d78),Wt(_0x3e8b2f,_0x227d78));}}return _0x13fcf4;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x3cf530){this['node_']=_0x3cf530;}['getImmediateChild'](_0x2653f6){const _0x5d4f01=this['node_']['getImmediateChild'](_0x2653f6);return new us(_0x5d4f01);}['node'](){return this['node_'];}}class ds{constructor(_0x2f536e,_0x179df9){this['syncTree_']=_0x2f536e,this['path_']=_0x179df9;}['getImmediateChild'](_0x39964e){const _0x4b415e=k(this['path_'],_0x39964e);return new ds(this['syncTree_'],_0x4b415e);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x40acf3){return _0x40acf3=_0x40acf3||{},_0x40acf3['timestamp']=_0x40acf3['timestamp']||new Date()['getTime'](),_0x40acf3;},_r=function(_0x8f4760,_0x2f25c7,_0x1b08c4){if(!_0x8f4760||typeof _0x8f4760!='object')return _0x8f4760;if(f('.sv'in _0x8f4760,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x8f4760['.sv']=='string')return sd(_0x8f4760['.sv'],_0x2f25c7,_0x1b08c4);if(typeof _0x8f4760['.sv']=='object')return rd(_0x8f4760['.sv'],_0x2f25c7);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x8f4760,null,0x2));},sd=function(_0x517c0a,_0x127a0a,_0x3f209e){switch(_0x517c0a){case'timestamp':return _0x3f209e['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x517c0a);}},rd=function(_0x442fb5,_0x4fce3e,_0x30624a){_0x442fb5['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x442fb5,null,0x2));const _0x38bfcb=_0x442fb5['increment'];typeof _0x38bfcb!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x38bfcb);const _0x1f27bb=_0x4fce3e['node']();if(f(_0x1f27bb!==null&&typeof _0x1f27bb<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x1f27bb['isLeafNode']())return _0x38bfcb;const _0x305193=_0x1f27bb['getValue']();return typeof _0x305193!='number'?_0x38bfcb:_0x305193+_0x38bfcb;},ta=function(_0x208f54,_0x3f9738,_0x162acb,_0x3f6eb8){return ps(_0x3f9738,new ds(_0x162acb,_0x208f54),_0x3f6eb8);},fs=function(_0x5c0111,_0x2c964f,_0x10e888){return ps(_0x5c0111,new us(_0x2c964f),_0x10e888);};function ps(_0xb437cb,_0x15e44c,_0x3101a1){const _0x52abc2=_0xb437cb['getPriority']()['val'](),_0x421e47=_r(_0x52abc2,_0x15e44c['getImmediateChild']('.priority'),_0x3101a1);let _0x1f2772;if(_0xb437cb['isLeafNode']()){const _0x49e4c9=_0xb437cb,_0x298175=_r(_0x49e4c9['getValue'](),_0x15e44c,_0x3101a1);return _0x298175!==_0x49e4c9['getValue']()||_0x421e47!==_0x49e4c9['getPriority']()['val']()?new D(_0x298175,A(_0x421e47)):_0xb437cb;}else{const _0x5c94c7=_0xb437cb;return _0x1f2772=_0x5c94c7,_0x421e47!==_0x5c94c7['getPriority']()['val']()&&(_0x1f2772=_0x1f2772['updatePriority'](new D(_0x421e47))),_0x5c94c7['forEachChild'](R,(_0x2867c4,_0x562715)=>{const _0x498927=ps(_0x562715,_0x15e44c['getImmediateChild'](_0x2867c4),_0x3101a1);_0x498927!==_0x562715&&(_0x1f2772=_0x1f2772['updateImmediateChild'](_0x2867c4,_0x498927));}),_0x1f2772;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x248399='',_0x34b0dd=null,_0x328e71={'children':{},'childCount':0x0}){this['name']=_0x248399,this['parent']=_0x34b0dd,this['node']=_0x328e71;}}function $n(_0x48d2c2,_0x2cb97e){let _0x4d92a8=_0x2cb97e instanceof C?_0x2cb97e:new C(_0x2cb97e),_0x101087=_0x48d2c2,_0x309fa4=y(_0x4d92a8);for(;_0x309fa4!==null;){const _0x2e51e4=Le(_0x101087['node']['children'],_0x309fa4)||{'children':{},'childCount':0x0};_0x101087=new _s(_0x309fa4,_0x101087,_0x2e51e4),_0x4d92a8=S(_0x4d92a8),_0x309fa4=y(_0x4d92a8);}return _0x101087;}function je(_0x1fb3ac){return _0x1fb3ac['node']['value'];}function gs(_0x36c0a2,_0x2d041e){_0x36c0a2['node']['value']=_0x2d041e,Oi(_0x36c0a2);}function na(_0xbad485){return _0xbad485['node']['childCount']>0x0;}function od(_0x27d656){return je(_0x27d656)===void 0x0&&!na(_0x27d656);}function Gn(_0x5c07f3,_0x5e68bf){x(_0x5c07f3['node']['children'],(_0x288274,_0x2e4148)=>{_0x5e68bf(new _s(_0x288274,_0x5c07f3,_0x2e4148));});}function ia(_0x569e3c,_0x55ced0,_0x2f75ee,_0x36bdeb){_0x2f75ee&&_0x55ced0(_0x569e3c),Gn(_0x569e3c,_0x3c0009=>{ia(_0x3c0009,_0x55ced0,!0x0);});}function ad(_0x406300,_0x3538c8,_0x453530){let _0x1a0de9=_0x406300['parent'];for(;_0x1a0de9!==null;){if(_0x3538c8(_0x1a0de9))return!0x0;_0x1a0de9=_0x1a0de9['parent'];}return!0x1;}function Qt(_0x3a1ff1){return new C(_0x3a1ff1['parent']===null?_0x3a1ff1['name']:Qt(_0x3a1ff1['parent'])+'/'+_0x3a1ff1['name']);}function Oi(_0x571302){_0x571302['parent']!==null&&cd(_0x571302['parent'],_0x571302['name'],_0x571302);}function cd(_0x2f7adb,_0x352064,_0x165d70){const _0x5857c4=od(_0x165d70),_0x40cb9f=Q(_0x2f7adb['node']['children'],_0x352064);_0x5857c4&&_0x40cb9f?(delete _0x2f7adb['node']['children'][_0x352064],_0x2f7adb['node']['childCount']--,Oi(_0x2f7adb)):!_0x5857c4&&!_0x40cb9f&&(_0x2f7adb['node']['children'][_0x352064]=_0x165d70['node'],_0x2f7adb['node']['childCount']++,Oi(_0x2f7adb));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x366251){return typeof _0x366251=='string'&&_0x366251['length']!==0x0&&!ld['test'](_0x366251);},sa=function(_0x3141e3){return typeof _0x3141e3=='string'&&_0x3141e3['length']!==0x0&&!hd['test'](_0x3141e3);},ud=function(_0x55411f){return _0x55411f&&(_0x55411f=_0x55411f['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x55411f);},Bt=function(_0x5d0269){return _0x5d0269===null||typeof _0x5d0269=='string'||typeof _0x5d0269=='number'&&!xn(_0x5d0269)||_0x5d0269&&typeof _0x5d0269=='object'&&Q(_0x5d0269,'.sv');},He=function(_0x469b53,_0x4bf41b,_0xed0586,_0x401aaf){_0x401aaf&&_0x4bf41b===void 0x0||Jt(it(_0x469b53,'value'),_0x4bf41b,_0xed0586);},Jt=function(_0x2937ce,_0x3c4fc1,_0x5443e6){const _0xd74f44=_0x5443e6 instanceof C?new Ah(_0x5443e6,_0x2937ce):_0x5443e6;if(_0x3c4fc1===void 0x0)throw new Error(_0x2937ce+'contains\x20undefined\x20'+Oe(_0xd74f44));if(typeof _0x3c4fc1=='function')throw new Error(_0x2937ce+'contains\x20a\x20function\x20'+Oe(_0xd74f44)+'\x20with\x20contents\x20=\x20'+_0x3c4fc1['toString']());if(xn(_0x3c4fc1))throw new Error(_0x2937ce+'contains\x20'+_0x3c4fc1['toString']()+'\x20'+Oe(_0xd74f44));if(typeof _0x3c4fc1=='string'&&_0x3c4fc1['length']>ui/0x3&&Ln(_0x3c4fc1)>ui)throw new Error(_0x2937ce+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0xd74f44)+'\x20(\x27'+_0x3c4fc1['substring'](0x0,0x32)+'...\x27)');if(_0x3c4fc1&&typeof _0x3c4fc1=='object'){let _0x48c586=!0x1,_0x5f0ab9=!0x1;if(x(_0x3c4fc1,(_0xe00312,_0x1a6c5c)=>{if(_0xe00312==='.value')_0x48c586=!0x0;else{if(_0xe00312!=='.priority'&&_0xe00312!=='.sv'&&(_0x5f0ab9=!0x0,!ms(_0xe00312)))throw new Error(_0x2937ce+'\x20contains\x20an\x20invalid\x20key\x20('+_0xe00312+')\x20'+Oe(_0xd74f44)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0xd74f44,_0xe00312),Jt(_0x2937ce,_0x1a6c5c,_0xd74f44),Ph(_0xd74f44);}),_0x48c586&&_0x5f0ab9)throw new Error(_0x2937ce+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0xd74f44)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x3ae568,_0x1475cc){let _0x58d825,_0x3c70b5;for(_0x58d825=0x0;_0x58d825<_0x1475cc['length'];_0x58d825++){_0x3c70b5=_0x1475cc[_0x58d825];const _0x3267c4=Mt(_0x3c70b5);for(let _0x5ca72e=0x0;_0x5ca72e<_0x3267c4['length'];_0x5ca72e++)if(!(_0x3267c4[_0x5ca72e]==='.priority'&&_0x5ca72e===_0x3267c4['length']-0x1)){if(!ms(_0x3267c4[_0x5ca72e]))throw new Error(_0x3ae568+'contains\x20an\x20invalid\x20key\x20('+_0x3267c4[_0x5ca72e]+')\x20in\x20path\x20'+_0x3c70b5['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x1475cc['sort'](Rh);let _0x531350=null;for(_0x58d825=0x0;_0x58d825<_0x1475cc['length'];_0x58d825++){if(_0x3c70b5=_0x1475cc[_0x58d825],_0x531350!==null&&G(_0x531350,_0x3c70b5))throw new Error(_0x3ae568+'contains\x20a\x20path\x20'+_0x531350['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x3c70b5['toString']());_0x531350=_0x3c70b5;}},ra=function(_0x383295,_0x587e43,_0x561827,_0x157f13){const _0x116ceb=it(_0x383295,'values');if(!(_0x587e43&&typeof _0x587e43=='object')||Array['isArray'](_0x587e43))throw new Error(_0x116ceb+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x242959=[];x(_0x587e43,(_0x2fcadf,_0x23db7d)=>{const _0x3306e2=new C(_0x2fcadf);if(Jt(_0x116ceb,_0x23db7d,k(_0x561827,_0x3306e2)),ji(_0x3306e2)==='.priority'&&!Bt(_0x23db7d))throw new Error(_0x116ceb+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x3306e2['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x242959['push'](_0x3306e2);}),dd(_0x116ceb,_0x242959);},fd=function(_0x6ed0a,_0x2e6f62,_0x51283c){if(xn(_0x2e6f62))throw new Error(it(_0x6ed0a,'priority')+'is\x20'+_0x2e6f62['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x2e6f62))throw new Error(it(_0x6ed0a,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x40d100,_0x4759fe,_0x39a77c,_0xc7c0d){if(!sa(_0x39a77c))throw new Error(it(_0x40d100,_0x4759fe)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x39a77c+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x1f9d9d,_0x206a73,_0x549c8f,_0x5b44f8){_0x549c8f&&(_0x549c8f=_0x549c8f['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x1f9d9d,_0x206a73,_0x549c8f);},Me=function(_0x11ec97,_0x47dcf8){if(y(_0x47dcf8)==='.info')throw new Error(_0x11ec97+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x1b39ad,_0x90676b){const _0x457eb7=_0x90676b['path']['toString']();if(typeof _0x90676b['repoInfo']['host']!='string'||_0x90676b['repoInfo']['host']['length']===0x0||!ms(_0x90676b['repoInfo']['namespace'])&&_0x90676b['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x457eb7['length']!==0x0&&!ud(_0x457eb7))throw new Error(it(_0x1b39ad,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x43d88c,_0x322a9b){let _0x9ae99a=null;for(let _0x31434c=0x0;_0x31434c<_0x322a9b['length'];_0x31434c++){const _0xae4d39=_0x322a9b[_0x31434c],_0x27bce6=_0xae4d39['getPath']();_0x9ae99a!==null&&!Ki(_0x27bce6,_0x9ae99a['path'])&&(_0x43d88c['eventLists_']['push'](_0x9ae99a),_0x9ae99a=null),_0x9ae99a===null&&(_0x9ae99a={'events':[],'path':_0x27bce6}),_0x9ae99a['events']['push'](_0xae4d39);}_0x9ae99a&&_0x43d88c['eventLists_']['push'](_0x9ae99a);}function oa(_0x5e146d,_0x138a34,_0x24c6f4){qn(_0x5e146d,_0x24c6f4),aa(_0x5e146d,_0x52cb47=>Ki(_0x52cb47,_0x138a34));}function V(_0x241cb8,_0x53f1ea,_0x1f6811){qn(_0x241cb8,_0x1f6811),aa(_0x241cb8,_0x11f786=>G(_0x11f786,_0x53f1ea)||G(_0x53f1ea,_0x11f786));}function aa(_0x2ad286,_0xfd59ce){_0x2ad286['recursionDepth_']++;let _0x11c283=!0x0;for(let _0x4f0590=0x0;_0x4f0590<_0x2ad286['eventLists_']['length'];_0x4f0590++){const _0x50e82d=_0x2ad286['eventLists_'][_0x4f0590];if(_0x50e82d){const _0x6f907d=_0x50e82d['path'];_0xfd59ce(_0x6f907d)?(md(_0x2ad286['eventLists_'][_0x4f0590]),_0x2ad286['eventLists_'][_0x4f0590]=null):_0x11c283=!0x1;}}_0x11c283&&(_0x2ad286['eventLists_']=[]),_0x2ad286['recursionDepth_']--;}function md(_0x1f9d28){for(let _0x376a8d=0x0;_0x376a8d<_0x1f9d28['events']['length'];_0x376a8d++){const _0x5ec51f=_0x1f9d28['events'][_0x376a8d];if(_0x5ec51f!==null){_0x1f9d28['events'][_0x376a8d]=null;const _0xb0ea30=_0x5ec51f['getEventRunner']();St&&L('event:\x20'+_0x5ec51f['toString']()),ft(_0xb0ea30);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x38cbc6,_0x6b71ca,_0x415daf,_0xbb13a){this['repoInfo_']=_0x38cbc6,this['forceRestClient_']=_0x6b71ca,this['authTokenProvider_']=_0x415daf,this['appCheckProvider_']=_0xbb13a,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x57bcf5,_0x53e124,_0x2b7421){if(_0x57bcf5['stats_']=qi(_0x57bcf5['repoInfo_']),_0x57bcf5['forceRestClient_']||Xl())_0x57bcf5['server_']=new vn(_0x57bcf5['repoInfo_'],(_0x34241c,_0x470289,_0x1c17ea,_0x26ad13)=>{gr(_0x57bcf5,_0x34241c,_0x470289,_0x1c17ea,_0x26ad13);},_0x57bcf5['authTokenProvider_'],_0x57bcf5['appCheckProvider_']),setTimeout(()=>mr(_0x57bcf5,!0x0),0x0);else{if(typeof _0x2b7421<'u'&&_0x2b7421!==null){if(typeof _0x2b7421!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x2b7421);}catch(_0x316ba9){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x316ba9);}}_0x57bcf5['persistentConnection_']=new se(_0x57bcf5['repoInfo_'],_0x53e124,(_0x31087b,_0x4a4715,_0x3c8de7,_0x5322f1)=>{gr(_0x57bcf5,_0x31087b,_0x4a4715,_0x3c8de7,_0x5322f1);},_0x1c9f79=>{mr(_0x57bcf5,_0x1c9f79);},_0x2885b6=>{Id(_0x57bcf5,_0x2885b6);},_0x57bcf5['authTokenProvider_'],_0x57bcf5['appCheckProvider_'],_0x2b7421),_0x57bcf5['server_']=_0x57bcf5['persistentConnection_'];}_0x57bcf5['authTokenProvider_']['addTokenChangeListener'](_0x46d1e2=>{_0x57bcf5['server_']['refreshAuthToken'](_0x46d1e2);}),_0x57bcf5['appCheckProvider_']['addTokenChangeListener'](_0x574095=>{_0x57bcf5['server_']['refreshAppCheckToken'](_0x574095['token']);}),_0x57bcf5['statsReporter_']=ih(_0x57bcf5['repoInfo_'],()=>new iu(_0x57bcf5['stats_'],_0x57bcf5['server_'])),_0x57bcf5['infoData_']=new Xh(),_0x57bcf5['infoSyncTree_']=new pr({'startListening':(_0x118eea,_0x1e8b04,_0x1ddda6,_0x205222)=>{let _0x2b03a5=[];const _0x122377=_0x57bcf5['infoData_']['getNode'](_0x118eea['_path']);return _0x122377['isEmpty']()||(_0x2b03a5=Yt(_0x57bcf5['infoSyncTree_'],_0x118eea['_path'],_0x122377),setTimeout(()=>{_0x205222('ok');},0x0)),_0x2b03a5;},'stopListening':()=>{}}),vs(_0x57bcf5,'connected',!0x1),_0x57bcf5['serverSyncTree_']=new pr({'startListening':(_0x27489c,_0x4a086e,_0x72ec84,_0x2bf761)=>(_0x57bcf5['server_']['listen'](_0x27489c,_0x72ec84,_0x4a086e,(_0x70162f,_0x4b87f9)=>{const _0x4308e3=_0x2bf761(_0x70162f,_0x4b87f9);V(_0x57bcf5['eventQueue_'],_0x27489c['_path'],_0x4308e3);}),[]),'stopListening':(_0x10c9cc,_0xa0fa12)=>{_0x57bcf5['server_']['unlisten'](_0x10c9cc,_0xa0fa12);}});}function la(_0x357804){const _0x3597f2=_0x357804['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x3597f2;}function Xt(_0x228419){return id({'timestamp':la(_0x228419)});}function gr(_0x47946b,_0x31ecff,_0xd0ec3e,_0x1feb0a,_0x3d26c7){_0x47946b['dataUpdateCount']++;const _0x2fe454=new C(_0x31ecff);_0xd0ec3e=_0x47946b['interceptServerDataCallback_']?_0x47946b['interceptServerDataCallback_'](_0x31ecff,_0xd0ec3e):_0xd0ec3e;let _0x33493c=[];if(_0x3d26c7){if(_0x1feb0a){const _0x336e67=_n(_0xd0ec3e,_0xecd913=>A(_0xecd913));_0x33493c=Ju(_0x47946b['serverSyncTree_'],_0x2fe454,_0x336e67,_0x3d26c7);}else{const _0x31e231=A(_0xd0ec3e);_0x33493c=Jo(_0x47946b['serverSyncTree_'],_0x2fe454,_0x31e231,_0x3d26c7);}}else{if(_0x1feb0a){const _0x5ae29e=_n(_0xd0ec3e,_0x2bc69f=>A(_0x2bc69f));_0x33493c=Ku(_0x47946b['serverSyncTree_'],_0x2fe454,_0x5ae29e);}else{const _0x42d7ad=A(_0xd0ec3e);_0x33493c=Yt(_0x47946b['serverSyncTree_'],_0x2fe454,_0x42d7ad);}}let _0x5ec7a2=_0x2fe454;_0x33493c['length']>0x0&&(_0x5ec7a2=ct(_0x47946b,_0x2fe454)),V(_0x47946b['eventQueue_'],_0x5ec7a2,_0x33493c);}function mr(_0x55bc81,_0x2504ac){vs(_0x55bc81,'connected',_0x2504ac),_0x2504ac===!0x1&&Sd(_0x55bc81);}function Id(_0x4531f9,_0xc2c88d){x(_0xc2c88d,(_0xdec1af,_0x31554a)=>{vs(_0x4531f9,_0xdec1af,_0x31554a);});}function vs(_0x95095e,_0x342b9b,_0x98a546){const _0x32d87e=new C('/.info/'+_0x342b9b),_0x49837d=A(_0x98a546);_0x95095e['infoData_']['updateSnapshot'](_0x32d87e,_0x49837d);const _0x21d201=Yt(_0x95095e['infoSyncTree_'],_0x32d87e,_0x49837d);V(_0x95095e['eventQueue_'],_0x32d87e,_0x21d201);}function zn(_0x4963bb){return _0x4963bb['nextWriteId_']++;}function wd(_0x456fab,_0x3549c4,_0x2ba531){const _0x16da5c=Xu(_0x456fab['serverSyncTree_'],_0x3549c4);return _0x16da5c!=null?Promise['resolve'](_0x16da5c):_0x456fab['server_']['get'](_0x3549c4)['then'](_0x2d80a7=>{const _0x366471=A(_0x2d80a7)['withIndex'](_0x3549c4['_queryParams']['getIndex']());Ni(_0x456fab['serverSyncTree_'],_0x3549c4,_0x2ba531,!0x0);let _0x1b86e5;if(_0x3549c4['_queryParams']['loadsAllData']())_0x1b86e5=Yt(_0x456fab['serverSyncTree_'],_0x3549c4['_path'],_0x366471);else{const _0x176d9a=Wt(_0x456fab['serverSyncTree_'],_0x3549c4);_0x1b86e5=Jo(_0x456fab['serverSyncTree_'],_0x3549c4['_path'],_0x366471,_0x176d9a);}return V(_0x456fab['eventQueue_'],_0x3549c4['_path'],_0x1b86e5),An(_0x456fab['serverSyncTree_'],_0x3549c4,_0x2ba531,null,!0x0),_0x366471;},_0x53f0ad=>(gt(_0x456fab,'get\x20for\x20query\x20'+O(_0x3549c4)+'\x20failed:\x20'+_0x53f0ad),Promise['reject'](new Error(_0x53f0ad))));}function Cd(_0x1cd1b9,_0x491020,_0x43a022,_0xb97e22,_0x5d6ce3){gt(_0x1cd1b9,'set',{'path':_0x491020['toString'](),'value':_0x43a022,'priority':_0xb97e22});const _0x3c2a56=Xt(_0x1cd1b9),_0x282f42=A(_0x43a022,_0xb97e22),_0x3e2b7f=Vn(_0x1cd1b9['serverSyncTree_'],_0x491020),_0x16b31e=fs(_0x282f42,_0x3e2b7f,_0x3c2a56),_0x402a8f=zn(_0x1cd1b9),_0x39a296=as(_0x1cd1b9['serverSyncTree_'],_0x491020,_0x16b31e,_0x402a8f,!0x0);qn(_0x1cd1b9['eventQueue_'],_0x39a296),_0x1cd1b9['server_']['put'](_0x491020['toString'](),_0x282f42['val'](!0x0),(_0x403e4c,_0x124fcf)=>{const _0x5e114c=_0x403e4c==='ok';_0x5e114c||U('set\x20at\x20'+_0x491020+'\x20failed:\x20'+_0x403e4c);const _0x4c135f=_e(_0x1cd1b9['serverSyncTree_'],_0x402a8f,!_0x5e114c);V(_0x1cd1b9['eventQueue_'],_0x491020,_0x4c135f),be(_0x1cd1b9,_0x5d6ce3,_0x403e4c,_0x124fcf);});const _0x1f282b=Is(_0x1cd1b9,_0x491020);ct(_0x1cd1b9,_0x1f282b),V(_0x1cd1b9['eventQueue_'],_0x1f282b,[]);}function Td(_0xa52b05,_0xb15e84,_0x35aa3d,_0x3064ef){gt(_0xa52b05,'update',{'path':_0xb15e84['toString'](),'value':_0x35aa3d});let _0x5a8a9c=!0x0;const _0x3bd673=Xt(_0xa52b05),_0x22b268={};if(x(_0x35aa3d,(_0xe0608,_0xa04f48)=>{_0x5a8a9c=!0x1,_0x22b268[_0xe0608]=ta(k(_0xb15e84,_0xe0608),A(_0xa04f48),_0xa52b05['serverSyncTree_'],_0x3bd673);}),_0x5a8a9c)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0xa52b05,_0x3064ef,'ok',void 0x0);else{const _0x241220=zn(_0xa52b05),_0x76cdaf=ju(_0xa52b05['serverSyncTree_'],_0xb15e84,_0x22b268,_0x241220);qn(_0xa52b05['eventQueue_'],_0x76cdaf),_0xa52b05['server_']['merge'](_0xb15e84['toString'](),_0x35aa3d,(_0x59c470,_0x31b8fb)=>{const _0x2ebd91=_0x59c470==='ok';_0x2ebd91||U('update\x20at\x20'+_0xb15e84+'\x20failed:\x20'+_0x59c470);const _0x3214c0=_e(_0xa52b05['serverSyncTree_'],_0x241220,!_0x2ebd91),_0x2b1300=_0x3214c0['length']>0x0?ct(_0xa52b05,_0xb15e84):_0xb15e84;V(_0xa52b05['eventQueue_'],_0x2b1300,_0x3214c0),be(_0xa52b05,_0x3064ef,_0x59c470,_0x31b8fb);}),x(_0x35aa3d,_0x2fe9fd=>{const _0x3d9359=Is(_0xa52b05,k(_0xb15e84,_0x2fe9fd));ct(_0xa52b05,_0x3d9359);}),V(_0xa52b05['eventQueue_'],_0xb15e84,[]);}}function Sd(_0x1dc9ae){gt(_0x1dc9ae,'onDisconnectEvents');const _0xc5122=Xt(_0x1dc9ae),_0x53a12c=En();Si(_0x1dc9ae['onDisconnect_'],w(),(_0x3f1097,_0x2eb420)=>{const _0x3a5677=ta(_0x3f1097,_0x2eb420,_0x1dc9ae['serverSyncTree_'],_0xc5122);pt(_0x53a12c,_0x3f1097,_0x3a5677);});let _0x3b5c07=[];Si(_0x53a12c,w(),(_0x195e86,_0x303d3c)=>{_0x3b5c07=_0x3b5c07['concat'](Yt(_0x1dc9ae['serverSyncTree_'],_0x195e86,_0x303d3c));const _0x5249aa=Is(_0x1dc9ae,_0x195e86);ct(_0x1dc9ae,_0x5249aa);}),_0x1dc9ae['onDisconnect_']=En(),V(_0x1dc9ae['eventQueue_'],w(),_0x3b5c07);}function bd(_0x4c6fbf,_0x256b01,_0x24ab41){_0x4c6fbf['server_']['onDisconnectCancel'](_0x256b01['toString'](),(_0x20d3e5,_0x3fce58)=>{_0x20d3e5==='ok'&&Ti(_0x4c6fbf['onDisconnect_'],_0x256b01),be(_0x4c6fbf,_0x24ab41,_0x20d3e5,_0x3fce58);});}function yr(_0x1f7631,_0x12e5b4,_0x36e22c,_0x2f3a1c){const _0x1bf024=A(_0x36e22c);_0x1f7631['server_']['onDisconnectPut'](_0x12e5b4['toString'](),_0x1bf024['val'](!0x0),(_0x6ac57f,_0x221309)=>{_0x6ac57f==='ok'&&pt(_0x1f7631['onDisconnect_'],_0x12e5b4,_0x1bf024),be(_0x1f7631,_0x2f3a1c,_0x6ac57f,_0x221309);});}function Rd(_0x4c4f48,_0x26a62c,_0x2ef660,_0x41739c,_0x3875ab){const _0x2b9264=A(_0x2ef660,_0x41739c);_0x4c4f48['server_']['onDisconnectPut'](_0x26a62c['toString'](),_0x2b9264['val'](!0x0),(_0x18fd0d,_0x3995ec)=>{_0x18fd0d==='ok'&&pt(_0x4c4f48['onDisconnect_'],_0x26a62c,_0x2b9264),be(_0x4c4f48,_0x3875ab,_0x18fd0d,_0x3995ec);});}function Ad(_0x1055f7,_0x2d0b88,_0x420bc3,_0x48a1ac){if(pn(_0x420bc3)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x1055f7,_0x48a1ac,'ok',void 0x0);return;}_0x1055f7['server_']['onDisconnectMerge'](_0x2d0b88['toString'](),_0x420bc3,(_0x5a0880,_0x5052d5)=>{_0x5a0880==='ok'&&x(_0x420bc3,(_0xe5afdc,_0xb81c01)=>{const _0x148f2e=A(_0xb81c01);pt(_0x1055f7['onDisconnect_'],k(_0x2d0b88,_0xe5afdc),_0x148f2e);}),be(_0x1055f7,_0x48a1ac,_0x5a0880,_0x5052d5);});}function kd(_0x1379cb,_0xc8cd9b,_0x48af50){let _0x17ddae;y(_0xc8cd9b['_path'])==='.info'?_0x17ddae=Ni(_0x1379cb['infoSyncTree_'],_0xc8cd9b,_0x48af50):_0x17ddae=Ni(_0x1379cb['serverSyncTree_'],_0xc8cd9b,_0x48af50),oa(_0x1379cb['eventQueue_'],_0xc8cd9b['_path'],_0x17ddae);}function Pd(_0x1f9277,_0x995a93,_0x2a08ce){let _0x8254a6;y(_0x995a93['_path'])==='.info'?_0x8254a6=An(_0x1f9277['infoSyncTree_'],_0x995a93,_0x2a08ce):_0x8254a6=An(_0x1f9277['serverSyncTree_'],_0x995a93,_0x2a08ce),oa(_0x1f9277['eventQueue_'],_0x995a93['_path'],_0x8254a6);}function ha(_0x5f1f9f){_0x5f1f9f['persistentConnection_']&&_0x5f1f9f['persistentConnection_']['interrupt'](ca);}function Nd(_0x4c8e68){_0x4c8e68['persistentConnection_']&&_0x4c8e68['persistentConnection_']['resume'](ca);}function gt(_0x4f482b,..._0x554b50){let _0x175bee='';_0x4f482b['persistentConnection_']&&(_0x175bee=_0x4f482b['persistentConnection_']['id']+':'),L(_0x175bee,..._0x554b50);}function be(_0x49035e,_0xfc674d,_0x468728,_0x5ae19f){_0xfc674d&&ft(()=>{if(_0x468728==='ok')_0xfc674d(null);else{const _0xaa378b=(_0x468728||'error')['toUpperCase']();let _0x520473=_0xaa378b;_0x5ae19f&&(_0x520473+=':\x20'+_0x5ae19f);const _0x5606e9=new Error(_0x520473);_0x5606e9['code']=_0xaa378b,_0xfc674d(_0x5606e9);}});}function Od(_0x9ebeee,_0x2fd727,_0x1e4e18,_0x3723c2,_0x503413,_0x16c1ef){gt(_0x9ebeee,'transaction\x20on\x20'+_0x2fd727);const _0x1f1623={'path':_0x2fd727,'update':_0x1e4e18,'onComplete':_0x3723c2,'status':null,'order':so(),'applyLocally':_0x16c1ef,'retryCount':0x0,'unwatcher':_0x503413,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x3811d7=Es(_0x9ebeee,_0x2fd727,void 0x0);_0x1f1623['currentInputSnapshot']=_0x3811d7;const _0x4b2338=_0x1f1623['update'](_0x3811d7['val']());if(_0x4b2338===void 0x0)_0x1f1623['unwatcher'](),_0x1f1623['currentOutputSnapshotRaw']=null,_0x1f1623['currentOutputSnapshotResolved']=null,_0x1f1623['onComplete']&&_0x1f1623['onComplete'](null,!0x1,_0x1f1623['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x4b2338,_0x1f1623['path']),_0x1f1623['status']=0x0;const _0x42397a=$n(_0x9ebeee['transactionQueueTree_'],_0x2fd727),_0x420968=je(_0x42397a)||[];_0x420968['push'](_0x1f1623),gs(_0x42397a,_0x420968);let _0x32e419;typeof _0x4b2338=='object'&&_0x4b2338!==null&&Q(_0x4b2338,'.priority')?(_0x32e419=Le(_0x4b2338,'.priority'),f(Bt(_0x32e419),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x32e419=(Vn(_0x9ebeee['serverSyncTree_'],_0x2fd727)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x5f3ca4=Xt(_0x9ebeee),_0x5a3e74=A(_0x4b2338,_0x32e419),_0x2f6457=fs(_0x5a3e74,_0x3811d7,_0x5f3ca4);_0x1f1623['currentOutputSnapshotRaw']=_0x5a3e74,_0x1f1623['currentOutputSnapshotResolved']=_0x2f6457,_0x1f1623['currentWriteId']=zn(_0x9ebeee);const _0x4eda08=as(_0x9ebeee['serverSyncTree_'],_0x2fd727,_0x2f6457,_0x1f1623['currentWriteId'],_0x1f1623['applyLocally']);V(_0x9ebeee['eventQueue_'],_0x2fd727,_0x4eda08),jn(_0x9ebeee,_0x9ebeee['transactionQueueTree_']);}}function Es(_0x1ca20f,_0x5372e0,_0x1e08f9){return Vn(_0x1ca20f['serverSyncTree_'],_0x5372e0,_0x1e08f9)||g['EMPTY_NODE'];}function jn(_0x1d9634,_0x59361c=_0x1d9634['transactionQueueTree_']){if(_0x59361c||Kn(_0x1d9634,_0x59361c),je(_0x59361c)){const _0x137ef1=da(_0x1d9634,_0x59361c);f(_0x137ef1['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x137ef1['every'](_0x234322=>_0x234322['status']===0x0)&&Dd(_0x1d9634,Qt(_0x59361c),_0x137ef1);}else na(_0x59361c)&&Gn(_0x59361c,_0xff909d=>{jn(_0x1d9634,_0xff909d);});}function Dd(_0x439de0,_0x3a739d,_0x47a466){const _0x2aa574=_0x47a466['map'](_0x135b3d=>_0x135b3d['currentWriteId']),_0x480d0a=Es(_0x439de0,_0x3a739d,_0x2aa574);let _0x1e1bd0=_0x480d0a;const _0x47e18f=_0x480d0a['hash']();for(let _0x2e2ebd=0x0;_0x2e2ebd<_0x47a466['length'];_0x2e2ebd++){const _0x221abc=_0x47a466[_0x2e2ebd];f(_0x221abc['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x221abc['status']=0x1,_0x221abc['retryCount']++;const _0x4c0a10=F(_0x3a739d,_0x221abc['path']);_0x1e1bd0=_0x1e1bd0['updateChild'](_0x4c0a10,_0x221abc['currentOutputSnapshotRaw']);}const _0x1634ae=_0x1e1bd0['val'](!0x0),_0x9c7900=_0x3a739d;_0x439de0['server_']['put'](_0x9c7900['toString'](),_0x1634ae,_0x4d7347=>{gt(_0x439de0,'transaction\x20put\x20response',{'path':_0x9c7900['toString'](),'status':_0x4d7347});let _0x3ea077=[];if(_0x4d7347==='ok'){const _0xf5b08=[];for(let _0x4bd3a2=0x0;_0x4bd3a2<_0x47a466['length'];_0x4bd3a2++)_0x47a466[_0x4bd3a2]['status']=0x2,_0x3ea077=_0x3ea077['concat'](_e(_0x439de0['serverSyncTree_'],_0x47a466[_0x4bd3a2]['currentWriteId'])),_0x47a466[_0x4bd3a2]['onComplete']&&_0xf5b08['push'](()=>_0x47a466[_0x4bd3a2]['onComplete'](null,!0x0,_0x47a466[_0x4bd3a2]['currentOutputSnapshotResolved'])),_0x47a466[_0x4bd3a2]['unwatcher']();Kn(_0x439de0,$n(_0x439de0['transactionQueueTree_'],_0x3a739d)),jn(_0x439de0,_0x439de0['transactionQueueTree_']),V(_0x439de0['eventQueue_'],_0x3a739d,_0x3ea077);for(let _0x551e68=0x0;_0x551e68<_0xf5b08['length'];_0x551e68++)ft(_0xf5b08[_0x551e68]);}else{if(_0x4d7347==='datastale'){for(let _0xdff985=0x0;_0xdff985<_0x47a466['length'];_0xdff985++)_0x47a466[_0xdff985]['status']===0x3?_0x47a466[_0xdff985]['status']=0x4:_0x47a466[_0xdff985]['status']=0x0;}else{U('transaction\x20at\x20'+_0x9c7900['toString']()+'\x20failed:\x20'+_0x4d7347);for(let _0x5394cc=0x0;_0x5394cc<_0x47a466['length'];_0x5394cc++)_0x47a466[_0x5394cc]['status']=0x4,_0x47a466[_0x5394cc]['abortReason']=_0x4d7347;}ct(_0x439de0,_0x3a739d);}},_0x47e18f);}function ct(_0x131bfa,_0xf2e57a){const _0x2dfd38=ua(_0x131bfa,_0xf2e57a),_0x3b38da=Qt(_0x2dfd38),_0x5bf071=da(_0x131bfa,_0x2dfd38);return Md(_0x131bfa,_0x5bf071,_0x3b38da),_0x3b38da;}function Md(_0x3c162e,_0x53a2f4,_0x4af81a){if(_0x53a2f4['length']===0x0)return;const _0x36c34f=[];let _0x3c1054=[];const _0xfe8267=_0x53a2f4['filter'](_0x540400=>_0x540400['status']===0x0)['map'](_0x423700=>_0x423700['currentWriteId']);for(let _0x23e7e9=0x0;_0x23e7e9<_0x53a2f4['length'];_0x23e7e9++){const _0x111d5e=_0x53a2f4[_0x23e7e9],_0x16128e=F(_0x4af81a,_0x111d5e['path']);let _0x2c9faf=!0x1,_0x2711f7;if(f(_0x16128e!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x111d5e['status']===0x4)_0x2c9faf=!0x0,_0x2711f7=_0x111d5e['abortReason'],_0x3c1054=_0x3c1054['concat'](_e(_0x3c162e['serverSyncTree_'],_0x111d5e['currentWriteId'],!0x0));else{if(_0x111d5e['status']===0x0){if(_0x111d5e['retryCount']>=yd)_0x2c9faf=!0x0,_0x2711f7='maxretry',_0x3c1054=_0x3c1054['concat'](_e(_0x3c162e['serverSyncTree_'],_0x111d5e['currentWriteId'],!0x0));else{const _0x1baa7a=Es(_0x3c162e,_0x111d5e['path'],_0xfe8267);_0x111d5e['currentInputSnapshot']=_0x1baa7a;const _0x5736bb=_0x53a2f4[_0x23e7e9]['update'](_0x1baa7a['val']());if(_0x5736bb!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x5736bb,_0x111d5e['path']);let _0x1198ba=A(_0x5736bb);typeof _0x5736bb=='object'&&_0x5736bb!=null&&Q(_0x5736bb,'.priority')||(_0x1198ba=_0x1198ba['updatePriority'](_0x1baa7a['getPriority']()));const _0x62e8db=_0x111d5e['currentWriteId'],_0x2ee9fa=Xt(_0x3c162e),_0x2b7861=fs(_0x1198ba,_0x1baa7a,_0x2ee9fa);_0x111d5e['currentOutputSnapshotRaw']=_0x1198ba,_0x111d5e['currentOutputSnapshotResolved']=_0x2b7861,_0x111d5e['currentWriteId']=zn(_0x3c162e),_0xfe8267['splice'](_0xfe8267['indexOf'](_0x62e8db),0x1),_0x3c1054=_0x3c1054['concat'](as(_0x3c162e['serverSyncTree_'],_0x111d5e['path'],_0x2b7861,_0x111d5e['currentWriteId'],_0x111d5e['applyLocally'])),_0x3c1054=_0x3c1054['concat'](_e(_0x3c162e['serverSyncTree_'],_0x62e8db,!0x0));}else _0x2c9faf=!0x0,_0x2711f7='nodata',_0x3c1054=_0x3c1054['concat'](_e(_0x3c162e['serverSyncTree_'],_0x111d5e['currentWriteId'],!0x0));}}}V(_0x3c162e['eventQueue_'],_0x4af81a,_0x3c1054),_0x3c1054=[],_0x2c9faf&&(_0x53a2f4[_0x23e7e9]['status']=0x2,function(_0x1a0895){setTimeout(_0x1a0895,Math['floor'](0x0));}(_0x53a2f4[_0x23e7e9]['unwatcher']),_0x53a2f4[_0x23e7e9]['onComplete']&&(_0x2711f7==='nodata'?_0x36c34f['push'](()=>_0x53a2f4[_0x23e7e9]['onComplete'](null,!0x1,_0x53a2f4[_0x23e7e9]['currentInputSnapshot'])):_0x36c34f['push'](()=>_0x53a2f4[_0x23e7e9]['onComplete'](new Error(_0x2711f7),!0x1,null))));}Kn(_0x3c162e,_0x3c162e['transactionQueueTree_']);for(let _0x3b481c=0x0;_0x3b481c<_0x36c34f['length'];_0x3b481c++)ft(_0x36c34f[_0x3b481c]);jn(_0x3c162e,_0x3c162e['transactionQueueTree_']);}function ua(_0x17d3e4,_0x83e2f0){let _0x35f123,_0x3e6e60=_0x17d3e4['transactionQueueTree_'];for(_0x35f123=y(_0x83e2f0);_0x35f123!==null&&je(_0x3e6e60)===void 0x0;)_0x3e6e60=$n(_0x3e6e60,_0x35f123),_0x83e2f0=S(_0x83e2f0),_0x35f123=y(_0x83e2f0);return _0x3e6e60;}function da(_0x5ced60,_0x567c49){const _0x289c3e=[];return fa(_0x5ced60,_0x567c49,_0x289c3e),_0x289c3e['sort']((_0x51e7a0,_0x1ddadf)=>_0x51e7a0['order']-_0x1ddadf['order']),_0x289c3e;}function fa(_0x5cdb80,_0x48ca59,_0x292bcf){const _0x808e7c=je(_0x48ca59);if(_0x808e7c){for(let _0x340ae6=0x0;_0x340ae6<_0x808e7c['length'];_0x340ae6++)_0x292bcf['push'](_0x808e7c[_0x340ae6]);}Gn(_0x48ca59,_0x28b7f5=>{fa(_0x5cdb80,_0x28b7f5,_0x292bcf);});}function Kn(_0x5a6174,_0x875854){const _0x478e8f=je(_0x875854);if(_0x478e8f){let _0x3ef874=0x0;for(let _0x155e08=0x0;_0x155e08<_0x478e8f['length'];_0x155e08++)_0x478e8f[_0x155e08]['status']!==0x2&&(_0x478e8f[_0x3ef874]=_0x478e8f[_0x155e08],_0x3ef874++);_0x478e8f['length']=_0x3ef874,gs(_0x875854,_0x478e8f['length']>0x0?_0x478e8f:void 0x0);}Gn(_0x875854,_0x4c67fd=>{Kn(_0x5a6174,_0x4c67fd);});}function Is(_0x537a41,_0x4c3437){const _0x88bf6a=Qt(ua(_0x537a41,_0x4c3437)),_0xdaa7b3=$n(_0x537a41['transactionQueueTree_'],_0x4c3437);return ad(_0xdaa7b3,_0x216990=>{di(_0x537a41,_0x216990);}),di(_0x537a41,_0xdaa7b3),ia(_0xdaa7b3,_0x559fb2=>{di(_0x537a41,_0x559fb2);}),_0x88bf6a;}function di(_0x46bbd0,_0x3528ef){const _0xa5b77c=je(_0x3528ef);if(_0xa5b77c){const _0x2e1ad9=[];let _0x25e77d=[],_0x46c23b=-0x1;for(let _0x3f5b87=0x0;_0x3f5b87<_0xa5b77c['length'];_0x3f5b87++)_0xa5b77c[_0x3f5b87]['status']===0x3||(_0xa5b77c[_0x3f5b87]['status']===0x1?(f(_0x46c23b===_0x3f5b87-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x46c23b=_0x3f5b87,_0xa5b77c[_0x3f5b87]['status']=0x3,_0xa5b77c[_0x3f5b87]['abortReason']='set'):(f(_0xa5b77c[_0x3f5b87]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0xa5b77c[_0x3f5b87]['unwatcher'](),_0x25e77d=_0x25e77d['concat'](_e(_0x46bbd0['serverSyncTree_'],_0xa5b77c[_0x3f5b87]['currentWriteId'],!0x0)),_0xa5b77c[_0x3f5b87]['onComplete']&&_0x2e1ad9['push'](_0xa5b77c[_0x3f5b87]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x46c23b===-0x1?gs(_0x3528ef,void 0x0):_0xa5b77c['length']=_0x46c23b+0x1,V(_0x46bbd0['eventQueue_'],Qt(_0x3528ef),_0x25e77d);for(let _0x2cc37c=0x0;_0x2cc37c<_0x2e1ad9['length'];_0x2cc37c++)ft(_0x2e1ad9[_0x2cc37c]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x3a5495){let _0x5920b9='';const _0xb7b39b=_0x3a5495['split']('/');for(let _0x38d8e7=0x0;_0x38d8e7<_0xb7b39b['length'];_0x38d8e7++)if(_0xb7b39b[_0x38d8e7]['length']>0x0){let _0x168bed=_0xb7b39b[_0x38d8e7];try{_0x168bed=decodeURIComponent(_0x168bed['replace'](/\+/g,'\x20'));}catch{}_0x5920b9+='/'+_0x168bed;}return _0x5920b9;}function xd(_0x2cce47){const _0x2ea041={};_0x2cce47['charAt'](0x0)==='?'&&(_0x2cce47=_0x2cce47['substring'](0x1));for(const _0x53c27b of _0x2cce47['split']('&')){if(_0x53c27b['length']===0x0)continue;const _0x4e7720=_0x53c27b['split']('=');_0x4e7720['length']===0x2?_0x2ea041[decodeURIComponent(_0x4e7720[0x0])]=decodeURIComponent(_0x4e7720[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x53c27b+'\x27\x20in\x20query\x20\x27'+_0x2cce47+'\x27');}return _0x2ea041;}const vr=function(_0x47d7e1,_0x5103d5){const _0x4a3550=Fd(_0x47d7e1),_0x43f70e=_0x4a3550['namespace'];_0x4a3550['domain']==='firebase.com'&&ae(_0x4a3550['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x43f70e||_0x43f70e==='undefined')&&_0x4a3550['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x4a3550['secure']||$l();const _0x6a2046=_0x4a3550['scheme']==='ws'||_0x4a3550['scheme']==='wss';return{'repoInfo':new yo(_0x4a3550['host'],_0x4a3550['secure'],_0x43f70e,_0x6a2046,_0x5103d5,'',_0x43f70e!==_0x4a3550['subdomain']),'path':new C(_0x4a3550['pathString'])};},Fd=function(_0x2c316e){let _0x2a4753='',_0x5c5b32='',_0x5e00fb='',_0x36fe27='',_0x38d0ac='',_0x3871b6=!0x0,_0x553f94='https',_0x53df75=0x1bb;if(typeof _0x2c316e=='string'){let _0x10a5bc=_0x2c316e['indexOf']('//');_0x10a5bc>=0x0&&(_0x553f94=_0x2c316e['substring'](0x0,_0x10a5bc-0x1),_0x2c316e=_0x2c316e['substring'](_0x10a5bc+0x2));let _0x12812b=_0x2c316e['indexOf']('/');_0x12812b===-0x1&&(_0x12812b=_0x2c316e['length']);let _0xa6f1ef=_0x2c316e['indexOf']('?');_0xa6f1ef===-0x1&&(_0xa6f1ef=_0x2c316e['length']),_0x2a4753=_0x2c316e['substring'](0x0,Math['min'](_0x12812b,_0xa6f1ef)),_0x12812b<_0xa6f1ef&&(_0x36fe27=Ld(_0x2c316e['substring'](_0x12812b,_0xa6f1ef)));const _0x4e2bb2=xd(_0x2c316e['substring'](Math['min'](_0x2c316e['length'],_0xa6f1ef)));_0x10a5bc=_0x2a4753['indexOf'](':'),_0x10a5bc>=0x0?(_0x3871b6=_0x553f94==='https'||_0x553f94==='wss',_0x53df75=parseInt(_0x2a4753['substring'](_0x10a5bc+0x1),0xa)):_0x10a5bc=_0x2a4753['length'];const _0x49d997=_0x2a4753['slice'](0x0,_0x10a5bc);if(_0x49d997['toLowerCase']()==='localhost')_0x5c5b32='localhost';else{if(_0x49d997['split']('.')['length']<=0x2)_0x5c5b32=_0x49d997;else{const _0x35bb87=_0x2a4753['indexOf']('.');_0x5e00fb=_0x2a4753['substring'](0x0,_0x35bb87)['toLowerCase'](),_0x5c5b32=_0x2a4753['substring'](_0x35bb87+0x1),_0x38d0ac=_0x5e00fb;}}'ns'in _0x4e2bb2&&(_0x38d0ac=_0x4e2bb2['ns']);}return{'host':_0x2a4753,'port':_0x53df75,'domain':_0x5c5b32,'subdomain':_0x5e00fb,'secure':_0x3871b6,'scheme':_0x553f94,'pathString':_0x36fe27,'namespace':_0x38d0ac};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0xc2e6d9=0x0;const _0xf91773=[];return function(_0x1c1b1e){const _0xb63513=_0x1c1b1e===_0xc2e6d9;_0xc2e6d9=_0x1c1b1e;let _0x3da2ca;const _0x183826=new Array(0x8);for(_0x3da2ca=0x7;_0x3da2ca>=0x0;_0x3da2ca--)_0x183826[_0x3da2ca]=Er['charAt'](_0x1c1b1e%0x40),_0x1c1b1e=Math['floor'](_0x1c1b1e/0x40);f(_0x1c1b1e===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x10e85a=_0x183826['join']('');if(_0xb63513){for(_0x3da2ca=0xb;_0x3da2ca>=0x0&&_0xf91773[_0x3da2ca]===0x3f;_0x3da2ca--)_0xf91773[_0x3da2ca]=0x0;_0xf91773[_0x3da2ca]++;}else{for(_0x3da2ca=0x0;_0x3da2ca<0xc;_0x3da2ca++)_0xf91773[_0x3da2ca]=Math['floor'](Math['random']()*0x40);}for(_0x3da2ca=0x0;_0x3da2ca<0xc;_0x3da2ca++)_0x10e85a+=Er['charAt'](_0xf91773[_0x3da2ca]);return f(_0x10e85a['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x10e85a;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x4b70f4,_0x60d15c,_0x49c399,_0x384f69){this['eventType']=_0x4b70f4,this['eventRegistration']=_0x60d15c,this['snapshot']=_0x49c399,this['prevName']=_0x384f69;}['getPath'](){const _0x320e4c=this['snapshot']['ref'];return this['eventType']==='value'?_0x320e4c['_path']:_0x320e4c['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x53faea,_0x653130,_0x3f801c){this['eventRegistration']=_0x53faea,this['error']=_0x653130,this['path']=_0x3f801c;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0xb307b9,_0x4316ec){this['snapshotCallback']=_0xb307b9,this['cancelCallback']=_0x4316ec;}['onValue'](_0x3aab3d,_0xaf86bb){this['snapshotCallback']['call'](null,_0x3aab3d,_0xaf86bb);}['onCancel'](_0x4f7399){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x4f7399);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x25f3ec){return this['snapshotCallback']===_0x25f3ec['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x25f3ec['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x25f3ec['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x274c70,_0x3fcc9b){this['_repo']=_0x274c70,this['_path']=_0x3fcc9b;}['cancel'](){const _0x6afc5d=new H();return bd(this['_repo'],this['_path'],_0x6afc5d['wrapCallback'](()=>{})),_0x6afc5d['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0xb21552=new H();return yr(this['_repo'],this['_path'],null,_0xb21552['wrapCallback'](()=>{})),_0xb21552['promise'];}['set'](_0x4ffadd){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x4ffadd,this['_path'],!0x1);const _0x3aef05=new H();return yr(this['_repo'],this['_path'],_0x4ffadd,_0x3aef05['wrapCallback'](()=>{})),_0x3aef05['promise'];}['setWithPriority'](_0x456dbd,_0x3a5a15){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x456dbd,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x3a5a15);const _0x1f7839=new H();return Rd(this['_repo'],this['_path'],_0x456dbd,_0x3a5a15,_0x1f7839['wrapCallback'](()=>{})),_0x1f7839['promise'];}['update'](_0x2d252a){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x2d252a,this['_path']);const _0x1ede9f=new H();return Ad(this['_repo'],this['_path'],_0x2d252a,_0x1ede9f['wrapCallback'](()=>{})),_0x1ede9f['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x4a1f9f,_0x4f8132,_0x426b91,_0x3a9199){this['_repo']=_0x4a1f9f,this['_path']=_0x4f8132,this['_queryParams']=_0x426b91,this['_orderByCalled']=_0x3a9199;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x5675d8=sr(this['_queryParams']),_0x44979c=$i(_0x5675d8);return _0x44979c==='{}'?'default':_0x44979c;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x1ddbf4){if(_0x1ddbf4=P(_0x1ddbf4),!(_0x1ddbf4 instanceof Ae))return!0x1;const _0x1c7ec8=this['_repo']===_0x1ddbf4['_repo'],_0x347445=Ki(this['_path'],_0x1ddbf4['_path']),_0x419561=this['_queryIdentifier']===_0x1ddbf4['_queryIdentifier'];return _0x1c7ec8&&_0x347445&&_0x419561;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x34e8ef,_0x4f26e5){if(_0x34e8ef['_orderByCalled']===!0x0)throw new Error(_0x4f26e5+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x5c187f){let _0x34ffe5=null,_0x472100=null;if(_0x5c187f['hasStart']()&&(_0x34ffe5=_0x5c187f['getIndexStartValue']()),_0x5c187f['hasEnd']()&&(_0x472100=_0x5c187f['getIndexEndValue']()),_0x5c187f['getIndex']()===ve){const _0x49819c='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0xf110d5='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x5c187f['hasStart']()){if(_0x5c187f['getIndexStartName']()!==We)throw new Error(_0x49819c);if(typeof _0x34ffe5!='string')throw new Error(_0xf110d5);}if(_0x5c187f['hasEnd']()){if(_0x5c187f['getIndexEndName']()!==we)throw new Error(_0x49819c);if(typeof _0x472100!='string')throw new Error(_0xf110d5);}}else{if(_0x5c187f['getIndex']()===R){if(_0x34ffe5!=null&&!Bt(_0x34ffe5)||_0x472100!=null&&!Bt(_0x472100))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x5c187f['getIndex']()instanceof Ji||_0x5c187f['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x34ffe5!=null&&typeof _0x34ffe5=='object'||_0x472100!=null&&typeof _0x472100=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x1966be){if(_0x1966be['hasStart']()&&_0x1966be['hasEnd']()&&_0x1966be['hasLimit']()&&!_0x1966be['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x133cf1,_0x32c86e){super(_0x133cf1,_0x32c86e,new Zi(),!0x1);}get['parent'](){const _0x53eca6=Ro(this['_path']);return _0x53eca6===null?null:new ee(this['_repo'],_0x53eca6);}get['root'](){let _0x5d383c=this;for(;_0x5d383c['parent']!==null;)_0x5d383c=_0x5d383c['parent'];return _0x5d383c;}}class lt{constructor(_0x54c9cb,_0x23a101,_0x649a2f){this['_node']=_0x54c9cb,this['ref']=_0x23a101,this['_index']=_0x649a2f;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x265316){const _0x4d340a=new C(_0x265316),_0x292ffc=Vt(this['ref'],_0x265316);return new lt(this['_node']['getChild'](_0x4d340a),_0x292ffc,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x4c3e55){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x3b5e27,_0x56a67f)=>_0x4c3e55(new lt(_0x56a67f,Vt(this['ref'],_0x3b5e27),R)));}['hasChild'](_0xdad5f2){const _0x3a45a9=new C(_0xdad5f2);return!this['_node']['getChild'](_0x3a45a9)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x2c46d3,_0x36991e){return _0x2c46d3=P(_0x2c46d3),_0x2c46d3['_checkNotDeleted']('ref'),_0x36991e!==void 0x0?Vt(_0x2c46d3['_root'],_0x36991e):_0x2c46d3['_root'];}function Vt(_0x25e899,_0x2a0356){return _0x25e899=P(_0x25e899),y(_0x25e899['_path'])===null?pd('child','path',_0x2a0356):ys('child','path',_0x2a0356),new ee(_0x25e899['_repo'],k(_0x25e899['_path'],_0x2a0356));}function v_(_0x189f91){return _0x189f91=P(_0x189f91),new Vd(_0x189f91['_repo'],_0x189f91['_path']);}function E_(_0x20552b,_0x9e0191){_0x20552b=P(_0x20552b),Me('push',_0x20552b['_path']),He('push',_0x9e0191,_0x20552b['_path'],!0x0);const _0x326081=la(_0x20552b['_repo']),_0x975f3b=Ud(_0x326081),_0x2f6f05=Vt(_0x20552b,_0x975f3b),_0x1ec4fa=Vt(_0x20552b,_0x975f3b);let _0x323de5;return _0x9e0191!=null?_0x323de5=Hd(_0x1ec4fa,_0x9e0191)['then'](()=>_0x1ec4fa):_0x323de5=Promise['resolve'](_0x1ec4fa),_0x2f6f05['then']=_0x323de5['then']['bind'](_0x323de5),_0x2f6f05['catch']=_0x323de5['then']['bind'](_0x323de5,void 0x0),_0x2f6f05;}function Hd(_0xd35887,_0x52916f){_0xd35887=P(_0xd35887),Me('set',_0xd35887['_path']),He('set',_0x52916f,_0xd35887['_path'],!0x1);const _0x8bede7=new H();return Cd(_0xd35887['_repo'],_0xd35887['_path'],_0x52916f,null,_0x8bede7['wrapCallback'](()=>{})),_0x8bede7['promise'];}function I_(_0x52710b,_0x5f705a){ra('update',_0x5f705a,_0x52710b['_path']);const _0x1b0a6a=new H();return Td(_0x52710b['_repo'],_0x52710b['_path'],_0x5f705a,_0x1b0a6a['wrapCallback'](()=>{})),_0x1b0a6a['promise'];}function w_(_0x28cc40){_0x28cc40=P(_0x28cc40);const _0x4f03fa=new pa(()=>{}),_0x48cbc=new Qn(_0x4f03fa);return wd(_0x28cc40['_repo'],_0x28cc40,_0x48cbc)['then'](_0xd80b0a=>new lt(_0xd80b0a,new ee(_0x28cc40['_repo'],_0x28cc40['_path']),_0x28cc40['_queryParams']['getIndex']()));}class Qn{constructor(_0x421780){this['callbackContext']=_0x421780;}['respondsTo'](_0x359dae){return _0x359dae==='value';}['createEvent'](_0x22bc4d,_0x3c52f2){const _0x27bd67=_0x3c52f2['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x22bc4d['snapshotNode'],new ee(_0x3c52f2['_repo'],_0x3c52f2['_path']),_0x27bd67));}['getEventRunner'](_0x23d580){return _0x23d580['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x23d580['error']):()=>this['callbackContext']['onValue'](_0x23d580['snapshot'],null);}['createCancelEvent'](_0x4c6c5e,_0x19f462){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x4c6c5e,_0x19f462):null;}['matches'](_0x297137){return _0x297137 instanceof Qn?!_0x297137['callbackContext']||!this['callbackContext']?!0x0:_0x297137['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x2e2070,_0x2379a5,_0xce4db3,_0x802d7c,_0x1b08e0){const _0x4a70f1=new pa(_0xce4db3,void 0x0),_0x4e84a6=new Qn(_0x4a70f1);return kd(_0x2e2070['_repo'],_0x2e2070,_0x4e84a6),()=>Pd(_0x2e2070['_repo'],_0x2e2070,_0x4e84a6);}function Gd(_0x13f5d1,_0x142750,_0x10044f,_0x139387){return $d(_0x13f5d1,'value',_0x142750);}class mt{}class ma extends mt{constructor(_0x1302be,_0x22d812){super(),this['_value']=_0x1302be,this['_key']=_0x22d812,this['type']='endAt';}['_apply'](_0xc19422){He('endAt',this['_value'],_0xc19422['_path'],!0x0);const _0x40a5da=Jh(_0xc19422['_queryParams'],this['_value'],this['_key']);if(ga(_0x40a5da),Yn(_0x40a5da),_0xc19422['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0xc19422['_repo'],_0xc19422['_path'],_0x40a5da,_0xc19422['_orderByCalled']);}}function C_(_0x48530a,_0x7703c0){return new ma(_0x48530a,_0x7703c0);}class ya extends mt{constructor(_0x447113,_0x1bf47f){super(),this['_value']=_0x447113,this['_key']=_0x1bf47f,this['type']='startAt';}['_apply'](_0x12e889){He('startAt',this['_value'],_0x12e889['_path'],!0x0);const _0x289664=Qh(_0x12e889['_queryParams'],this['_value'],this['_key']);if(ga(_0x289664),Yn(_0x289664),_0x12e889['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x12e889['_repo'],_0x12e889['_path'],_0x289664,_0x12e889['_orderByCalled']);}}function T_(_0x185c2a=null,_0x368286){return new ya(_0x185c2a,_0x368286);}class qd extends mt{constructor(_0x834d3f){super(),this['_limit']=_0x834d3f,this['type']='limitToFirst';}['_apply'](_0x42a90a){if(_0x42a90a['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x42a90a['_repo'],_0x42a90a['_path'],Yh(_0x42a90a['_queryParams'],this['_limit']),_0x42a90a['_orderByCalled']);}}function S_(_0x282526){if(Math['floor'](_0x282526)!==_0x282526||_0x282526<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x282526);}class zd extends mt{constructor(_0x41375f){super(),this['_path']=_0x41375f,this['type']='orderByChild';}['_apply'](_0x4815bf){_a(_0x4815bf,'orderByChild');const _0x8cf7bd=new C(this['_path']);if(v(_0x8cf7bd))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x23f784=new Ji(_0x8cf7bd),_0x2c79b2=xo(_0x4815bf['_queryParams'],_0x23f784);return Yn(_0x2c79b2),new Ae(_0x4815bf['_repo'],_0x4815bf['_path'],_0x2c79b2,!0x0);}}function b_(_0x2f81a){if(_0x2f81a==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x2f81a==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x2f81a==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x2f81a),new zd(_0x2f81a);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x285d34){_a(_0x285d34,'orderByKey');const _0x5d1a37=xo(_0x285d34['_queryParams'],ve);return Yn(_0x5d1a37),new Ae(_0x285d34['_repo'],_0x285d34['_path'],_0x5d1a37,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x2b0d35,_0xf566a6){super(),this['_value']=_0x2b0d35,this['_key']=_0xf566a6,this['type']='equalTo';}['_apply'](_0xe71f7e){if(He('equalTo',this['_value'],_0xe71f7e['_path'],!0x1),_0xe71f7e['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0xe71f7e['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0xe71f7e));}}function A_(_0x2ccfcf,_0x295903){return new Kd(_0x2ccfcf,_0x295903);}function k_(_0x36097c,..._0x2fd2cb){let _0x3cd770=P(_0x36097c);for(const _0x45da1d of _0x2fd2cb)_0x3cd770=_0x45da1d['_apply'](_0x3cd770);return _0x3cd770;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x186042,_0x21b1b6,_0x271fb5,_0x379b52){const _0x3950ea=_0x21b1b6['lastIndexOf'](':'),_0x419cca=_0x21b1b6['substring'](0x0,_0x3950ea),_0x2d5c7f=qt(_0x419cca);_0x186042['repoInfo_']=new yo(_0x21b1b6,_0x2d5c7f,_0x186042['repoInfo_']['namespace'],_0x186042['repoInfo_']['webSocketOnly'],_0x186042['repoInfo_']['nodeAdmin'],_0x186042['repoInfo_']['persistenceKey'],_0x186042['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x271fb5),_0x379b52&&(_0x186042['authTokenProvider_']=_0x379b52);}function Xd(_0x124e1d,_0x321795,_0x309e5e,_0x57914e,_0x5e4643){let _0x500e95=_0x57914e||_0x124e1d['options']['databaseURL'];_0x500e95===void 0x0&&(_0x124e1d['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x124e1d['options']['projectId']),_0x500e95=_0x124e1d['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x2ee783=vr(_0x500e95,_0x5e4643),_0x167e74=_0x2ee783['repoInfo'],_0x4ed7cb;typeof process<'u'&&Bs&&(_0x4ed7cb=Bs[Yd]),_0x4ed7cb?(_0x500e95='http://'+_0x4ed7cb+'?ns='+_0x167e74['namespace'],_0x2ee783=vr(_0x500e95,_0x5e4643),_0x167e74=_0x2ee783['repoInfo']):_0x2ee783['repoInfo']['secure'];const _0x56ba0f=new eh(_0x124e1d['name'],_0x124e1d['options'],_0x321795);_d('Invalid\x20Firebase\x20Database\x20URL',_0x2ee783),v(_0x2ee783['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x4c4678=ef(_0x167e74,_0x124e1d,_0x56ba0f,new Zl(_0x124e1d,_0x309e5e));return new tf(_0x4c4678,_0x124e1d);}function Zd(_0x1a4dc8,_0xe01601){const _0x109b4d=Di[_0xe01601];(!_0x109b4d||_0x109b4d[_0x1a4dc8['key']]!==_0x1a4dc8)&&ae('Database\x20'+_0xe01601+'('+_0x1a4dc8['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x1a4dc8),delete _0x109b4d[_0x1a4dc8['key']];}function ef(_0x545e2c,_0x323c0b,_0x3b1acd,_0x3094fa){let _0x113255=Di[_0x323c0b['name']];_0x113255||(_0x113255={},Di[_0x323c0b['name']]=_0x113255);let _0x51ecca=_0x113255[_0x545e2c['toURLString']()];return _0x51ecca&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x51ecca=new vd(_0x545e2c,Qd,_0x3b1acd,_0x3094fa),_0x113255[_0x545e2c['toURLString']()]=_0x51ecca,_0x51ecca;}class tf{constructor(_0x19f77e,_0x9bd741){this['_repoInternal']=_0x19f77e,this['app']=_0x9bd741,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x2af0fd){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x2af0fd+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x2870c7=Zr(),_0x16449c){const _0x2fe962=Hi(_0x2870c7,'database')['getImmediate']({'identifier':_0x16449c});if(!_0x2fe962['_instanceStarted']){const _0x2c9f3b=hc('database');_0x2c9f3b&&nf(_0x2fe962,..._0x2c9f3b);}return _0x2fe962;}function nf(_0x4d9c7b,_0x58a57d,_0x5942e1,_0x5ed8fe={}){_0x4d9c7b=P(_0x4d9c7b),_0x4d9c7b['_checkNotDeleted']('useEmulator');const _0x321b9d=_0x58a57d+':'+_0x5942e1,_0x483f3c=_0x4d9c7b['_repoInternal'];if(_0x4d9c7b['_instanceStarted']){if(_0x321b9d===_0x4d9c7b['_repoInternal']['repoInfo_']['host']&&xe(_0x5ed8fe,_0x483f3c['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x2c149d;if(_0x483f3c['repoInfo_']['nodeAdmin'])_0x5ed8fe['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x2c149d=new an(an['OWNER']);else{if(_0x5ed8fe['mockUserToken']){const _0xb92624=typeof _0x5ed8fe['mockUserToken']=='string'?_0x5ed8fe['mockUserToken']:uc(_0x5ed8fe['mockUserToken'],_0x4d9c7b['app']['options']['projectId']);_0x2c149d=new an(_0xb92624);}}qt(_0x58a57d)&&Qr(_0x58a57d),Jd(_0x483f3c,_0x321b9d,_0x5ed8fe,_0x2c149d);}function N_(_0x3373b5){_0x3373b5=P(_0x3373b5),_0x3373b5['_checkNotDeleted']('goOffline'),ha(_0x3373b5['_repo']);}function O_(_0xb65bba){_0xb65bba=P(_0xb65bba),_0xb65bba['_checkNotDeleted']('goOnline'),Nd(_0xb65bba['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x38a647){Ul(dt),st(new Fe('database',(_0x320aaf,{instanceIdentifier:_0x34d952})=>{const _0x1aa411=_0x320aaf['getProvider']('app')['getImmediate'](),_0x450b4c=_0x320aaf['getProvider']('auth-internal'),_0x5080b0=_0x320aaf['getProvider']('app-check-internal');return Xd(_0x1aa411,_0x450b4c,_0x5080b0,_0x34d952);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x38a647),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0xfb0cbc,_0x1b3df7){this['committed']=_0xfb0cbc,this['snapshot']=_0x1b3df7;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x17141e,_0x108409,_0x43c07f){if(_0x17141e=P(_0x17141e),Me('Reference.transaction',_0x17141e['_path']),_0x17141e['key']==='.length'||_0x17141e['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x17141e['key']+'\x20is\x20a\x20read-only\x20object.';const _0x566e2e=!0x0,_0x4422a5=new H(),_0x240e1a=(_0x124136,_0x3aa258,_0xfbc489)=>{let _0x2e5768=null;_0x124136?_0x4422a5['reject'](_0x124136):(_0x2e5768=new lt(_0xfbc489,new ee(_0x17141e['_repo'],_0x17141e['_path']),R),_0x4422a5['resolve'](new of(_0x3aa258,_0x2e5768)));},_0x2277e8=Gd(_0x17141e,()=>{});return Od(_0x17141e['_repo'],_0x17141e['_path'],_0x108409,_0x240e1a,_0x2277e8,_0x566e2e),_0x4422a5['promise'];}se['prototype']['simpleListen']=function(_0x2c3bcb,_0x31ecf1){this['sendRequest']('q',{'p':_0x2c3bcb},_0x31ecf1);},se['prototype']['echo']=function(_0x22038f,_0x1acd63){this['sendRequest']('echo',{'d':_0x22038f},_0x1acd63);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x409684,..._0x36f15f){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x409684,..._0x36f15f);}function cn(_0xd927e2,..._0x46733e){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0xd927e2,..._0x46733e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x3d01c3,..._0x3a74df){throw ws(_0x3d01c3,..._0x3a74df);}function X(_0x4667df,..._0x519da3){return ws(_0x4667df,..._0x519da3);}function Ia(_0x52a40b,_0x18c0ae,_0x2bd0b7){const _0x4349e3={...af(),[_0x18c0ae]:_0x2bd0b7};return new Gt('auth','Firebase',_0x4349e3)['create'](_0x18c0ae,{'appName':_0x52a40b['name']});}function re(_0x731d39){return Ia(_0x731d39,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x82a592,..._0x13b74b){if(typeof _0x82a592!='string'){const _0xe56f45=_0x13b74b[0x0],_0x4db4d5=[..._0x13b74b['slice'](0x1)];return _0x4db4d5[0x0]&&(_0x4db4d5[0x0]['appName']=_0x82a592['name']),_0x82a592['_errorFactory']['create'](_0xe56f45,..._0x4db4d5);}return Ea['create'](_0x82a592,..._0x13b74b);}function m(_0x3fa83e,_0x36ae4e,..._0x3c705e){if(!_0x3fa83e)throw ws(_0x36ae4e,..._0x3c705e);}function ne(_0x3c0753){const _0x18f4c6='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x3c0753;throw cn(_0x18f4c6),new Error(_0x18f4c6);}function ce(_0x2c0950,_0x4b8f97){_0x2c0950||ne(_0x4b8f97);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x540049;return typeof self<'u'&&((_0x540049=self['location'])==null?void 0x0:_0x540049['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x58a245;return typeof self<'u'&&((_0x58a245=self['location'])==null?void 0x0:_0x58a245['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x37fa88=navigator;return _0x37fa88['languages']&&_0x37fa88['languages'][0x0]||_0x37fa88['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x49120f,_0x2f29f6){this['shortDelay']=_0x49120f,this['longDelay']=_0x2f29f6,ce(_0x2f29f6>_0x49120f,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0xb05e90,_0x3e7121){ce(_0xb05e90['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x76aacf}=_0xb05e90['emulator'];return _0x3e7121?''+_0x76aacf+(_0x3e7121['startsWith']('/')?_0x3e7121['slice'](0x1):_0x3e7121):_0x76aacf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x294040,_0x8029c7,_0xdc5063){this['fetchImpl']=_0x294040,_0x8029c7&&(this['headersImpl']=_0x8029c7),_0xdc5063&&(this['responseImpl']=_0xdc5063);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x2d3ce6,_0x555941){return _0x2d3ce6['tenantId']&&!_0x555941['tenantId']?{..._0x555941,'tenantId':_0x2d3ce6['tenantId']}:_0x555941;}async function Pe(_0x493b15,_0x4ddd7d,_0x3a9497,_0x1fbca3,_0x33a32a={}){return Ca(_0x493b15,_0x33a32a,async()=>{let _0x1b35f8={},_0x264234={};_0x1fbca3&&(_0x4ddd7d==='GET'?_0x264234=_0x1fbca3:_0x1b35f8={'body':JSON['stringify'](_0x1fbca3)});const _0x81dbef=ut({..._0x264234,'key':_0x493b15['config']['apiKey']})['slice'](0x1),_0x2ad491=await _0x493b15['_getAdditionalHeaders']();_0x2ad491['Content-Type']='application/json',_0x493b15['languageCode']&&(_0x2ad491['X-Firebase-Locale']=_0x493b15['languageCode']);const _0x3d502b={'method':_0x4ddd7d,'headers':_0x2ad491,..._0x1b35f8};return dc()||(_0x3d502b['referrerPolicy']='strict-origin-when-cross-origin'),_0x493b15['emulatorConfig']&&qt(_0x493b15['emulatorConfig']['host'])&&(_0x3d502b['credentials']='include'),wa['fetch']()(await Ta(_0x493b15,_0x493b15['config']['apiHost'],_0x3a9497,_0x81dbef),_0x3d502b);});}async function Ca(_0x634cc2,_0x5f5b5f,_0x1a0412){_0x634cc2['_canInitEmulator']=!0x1;const _0x1fc80b={...df,..._0x5f5b5f};try{const _0x3fcdb6=new gf(_0x634cc2),_0x51f4f7=await Promise['race']([_0x1a0412(),_0x3fcdb6['promise']]);_0x3fcdb6['clearNetworkTimeout']();const _0x3a892b=await _0x51f4f7['json']();if('needConfirmation'in _0x3a892b)throw on(_0x634cc2,'account-exists-with-different-credential',_0x3a892b);if(_0x51f4f7['ok']&&!('errorMessage'in _0x3a892b))return _0x3a892b;{const _0x514e4a=_0x51f4f7['ok']?_0x3a892b['errorMessage']:_0x3a892b['error']['message'],[_0x4c23c3,_0x3ff3a5]=_0x514e4a['split']('\x20:\x20');if(_0x4c23c3==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x634cc2,'credential-already-in-use',_0x3a892b);if(_0x4c23c3==='EMAIL_EXISTS')throw on(_0x634cc2,'email-already-in-use',_0x3a892b);if(_0x4c23c3==='USER_DISABLED')throw on(_0x634cc2,'user-disabled',_0x3a892b);const _0x41fc76=_0x1fc80b[_0x4c23c3]||_0x4c23c3['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x3ff3a5)throw Ia(_0x634cc2,_0x41fc76,_0x3ff3a5);Y(_0x634cc2,_0x41fc76);}}catch(_0x4b9b90){if(_0x4b9b90 instanceof Re)throw _0x4b9b90;Y(_0x634cc2,'network-request-failed',{'message':String(_0x4b9b90)});}}async function en(_0x5a80e0,_0x62fe30,_0x28c79d,_0x8da865,_0x3f82e4={}){const _0x273193=await Pe(_0x5a80e0,_0x62fe30,_0x28c79d,_0x8da865,_0x3f82e4);return'mfaPendingCredential'in _0x273193&&Y(_0x5a80e0,'multi-factor-auth-required',{'_serverResponse':_0x273193}),_0x273193;}async function Ta(_0x25c523,_0x21c8cc,_0x1c3dfc,_0x1a8d5e){const _0x243579=''+_0x21c8cc+_0x1c3dfc+'?'+_0x1a8d5e,_0x4d2907=_0x25c523,_0x4629b3=_0x4d2907['config']['emulator']?Cs(_0x25c523['config'],_0x243579):_0x25c523['config']['apiScheme']+'://'+_0x243579;return ff['includes'](_0x1c3dfc)&&(await _0x4d2907['_persistenceManagerAvailable'],_0x4d2907['_getPersistenceType']()==='COOKIE')?_0x4d2907['_getPersistence']()['_getFinalTarget'](_0x4629b3)['toString']():_0x4629b3;}function _f(_0x4c34e6){switch(_0x4c34e6){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x10847c){this['auth']=_0x10847c,this['timer']=null,this['promise']=new Promise((_0x53a0a5,_0x186202)=>{this['timer']=setTimeout(()=>_0x186202(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x1d359d,_0x18d370,_0x56d5e9){const _0x30968c={'appName':_0x1d359d['name']};_0x56d5e9['email']&&(_0x30968c['email']=_0x56d5e9['email']),_0x56d5e9['phoneNumber']&&(_0x30968c['phoneNumber']=_0x56d5e9['phoneNumber']);const _0x2c044=X(_0x1d359d,_0x18d370,_0x30968c);return _0x2c044['customData']['_tokenResponse']=_0x56d5e9,_0x2c044;}function wr(_0x1535c){return _0x1535c!==void 0x0&&_0x1535c['enterprise']!==void 0x0;}class mf{constructor(_0x4b699e){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x4b699e['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x4b699e['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x4b699e['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x135fdd){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x383d75 of this['recaptchaEnforcementState'])if(_0x383d75['provider']&&_0x383d75['provider']===_0x135fdd)return _f(_0x383d75['enforcementState']);return null;}['isProviderEnabled'](_0x171c02){return this['getProviderEnforcementState'](_0x171c02)==='ENFORCE'||this['getProviderEnforcementState'](_0x171c02)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x15cda4,_0x1b7418){return Pe(_0x15cda4,'GET','/v2/recaptchaConfig',ke(_0x15cda4,_0x1b7418));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x304f61,_0x5a5dd6){return Pe(_0x304f61,'POST','/v1/accounts:delete',_0x5a5dd6);}async function Pn(_0x172866,_0x23f751){return Pe(_0x172866,'POST','/v1/accounts:lookup',_0x23f751);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0xb5f394){if(_0xb5f394)try{const _0x245ff6=new Date(Number(_0xb5f394));if(!isNaN(_0x245ff6['getTime']()))return _0x245ff6['toUTCString']();}catch{}}async function Ef(_0x3da373,_0x366ebf=!0x1){const _0x4c502f=P(_0x3da373),_0x357040=await _0x4c502f['getIdToken'](_0x366ebf),_0x152dbe=Ts(_0x357040);m(_0x152dbe&&_0x152dbe['exp']&&_0x152dbe['auth_time']&&_0x152dbe['iat'],_0x4c502f['auth'],'internal-error');const _0x47d6dd=typeof _0x152dbe['firebase']=='object'?_0x152dbe['firebase']:void 0x0,_0x5307dd=_0x47d6dd==null?void 0x0:_0x47d6dd['sign_in_provider'];return{'claims':_0x152dbe,'token':_0x357040,'authTime':Pt(fi(_0x152dbe['auth_time'])),'issuedAtTime':Pt(fi(_0x152dbe['iat'])),'expirationTime':Pt(fi(_0x152dbe['exp'])),'signInProvider':_0x5307dd||null,'signInSecondFactor':(_0x47d6dd==null?void 0x0:_0x47d6dd['sign_in_second_factor'])||null};}function fi(_0x57fe33){return Number(_0x57fe33)*0x3e8;}function Ts(_0x51a6dd){const [_0x5e1d46,_0x5ac1c1,_0x23d64b]=_0x51a6dd['split']('.');if(_0x5e1d46===void 0x0||_0x5ac1c1===void 0x0||_0x23d64b===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x22031f=fn(_0x5ac1c1);return _0x22031f?JSON['parse'](_0x22031f):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x118bf9){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x118bf9==null?void 0x0:_0x118bf9['toString']()),null;}}function Cr(_0x222332){const _0x539d47=Ts(_0x222332);return m(_0x539d47,'internal-error'),m(typeof _0x539d47['exp']<'u','internal-error'),m(typeof _0x539d47['iat']<'u','internal-error'),Number(_0x539d47['exp'])-Number(_0x539d47['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x210b4d,_0x282b44,_0x45e112=!0x1){if(_0x45e112)return _0x282b44;try{return await _0x282b44;}catch(_0xc9e4c7){throw _0xc9e4c7 instanceof Re&&If(_0xc9e4c7)&&_0x210b4d['auth']['currentUser']===_0x210b4d&&await _0x210b4d['auth']['signOut'](),_0xc9e4c7;}}function If({code:_0x5bab95}){return _0x5bab95==='auth/user-disabled'||_0x5bab95==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x17395d){this['user']=_0x17395d,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x2c11e0){if(_0x2c11e0){const _0x2bb5cb=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x2bb5cb;}else{this['errorBackoff']=0x7530;const _0x4425a9=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x4425a9);}}['schedule'](_0x382bcd=!0x1){if(!this['isRunning'])return;const _0x5b1a0f=this['getInterval'](_0x382bcd);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x5b1a0f);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x1676d0){(_0x1676d0==null?void 0x0:_0x1676d0['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x3e618b,_0x2a7c11){this['createdAt']=_0x3e618b,this['lastLoginAt']=_0x2a7c11,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x384bd2){this['createdAt']=_0x384bd2['createdAt'],this['lastLoginAt']=_0x384bd2['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x495457){var _0x15f382;const _0x1a2b96=_0x495457['auth'],_0x28544f=await _0x495457['getIdToken'](),_0x20f910=await Ht(_0x495457,Pn(_0x1a2b96,{'idToken':_0x28544f}));m(_0x20f910==null?void 0x0:_0x20f910['users']['length'],_0x1a2b96,'internal-error');const _0x7341a4=_0x20f910['users'][0x0];_0x495457['_notifyReloadListener'](_0x7341a4);const _0x4730f8=(_0x15f382=_0x7341a4['providerUserInfo'])!=null&&_0x15f382['length']?Sa(_0x7341a4['providerUserInfo']):[],_0x51dc5b=Tf(_0x495457['providerData'],_0x4730f8),_0x509334=_0x495457['isAnonymous'],_0x2b893d=!(_0x495457['email']&&_0x7341a4['passwordHash'])&&!(_0x51dc5b!=null&&_0x51dc5b['length']),_0x504f17=_0x509334?_0x2b893d:!0x1,_0x576953={'uid':_0x7341a4['localId'],'displayName':_0x7341a4['displayName']||null,'photoURL':_0x7341a4['photoUrl']||null,'email':_0x7341a4['email']||null,'emailVerified':_0x7341a4['emailVerified']||!0x1,'phoneNumber':_0x7341a4['phoneNumber']||null,'tenantId':_0x7341a4['tenantId']||null,'providerData':_0x51dc5b,'metadata':new Li(_0x7341a4['createdAt'],_0x7341a4['lastLoginAt']),'isAnonymous':_0x504f17};Object['assign'](_0x495457,_0x576953);}async function Cf(_0x58148a){const _0x550829=P(_0x58148a);await Nn(_0x550829),await _0x550829['auth']['_persistUserIfCurrent'](_0x550829),_0x550829['auth']['_notifyListenersIfCurrent'](_0x550829);}function Tf(_0x261ac6,_0x14668d){return[..._0x261ac6['filter'](_0x1ec627=>!_0x14668d['some'](_0x4b5716=>_0x4b5716['providerId']===_0x1ec627['providerId'])),..._0x14668d];}function Sa(_0x171102){return _0x171102['map'](({providerId:_0x545797,..._0x18d92b})=>({'providerId':_0x545797,'uid':_0x18d92b['rawId']||'','displayName':_0x18d92b['displayName']||null,'email':_0x18d92b['email']||null,'phoneNumber':_0x18d92b['phoneNumber']||null,'photoURL':_0x18d92b['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x23ad85,_0x4c48bb){const _0x325b4f=await Ca(_0x23ad85,{},async()=>{const _0x22538f=ut({'grant_type':'refresh_token','refresh_token':_0x4c48bb})['slice'](0x1),{tokenApiHost:_0x1787b3,apiKey:_0x333c04}=_0x23ad85['config'],_0x211d95=await Ta(_0x23ad85,_0x1787b3,'/v1/token','key='+_0x333c04),_0x74d454=await _0x23ad85['_getAdditionalHeaders']();_0x74d454['Content-Type']='application/x-www-form-urlencoded';const _0x2187dd={'method':'POST','headers':_0x74d454,'body':_0x22538f};return _0x23ad85['emulatorConfig']&&qt(_0x23ad85['emulatorConfig']['host'])&&(_0x2187dd['credentials']='include'),wa['fetch']()(_0x211d95,_0x2187dd);});return{'accessToken':_0x325b4f['access_token'],'expiresIn':_0x325b4f['expires_in'],'refreshToken':_0x325b4f['refresh_token']};}async function bf(_0x1696dc,_0x377791){return Pe(_0x1696dc,'POST','/v2/accounts:revokeToken',ke(_0x1696dc,_0x377791));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x558638){m(_0x558638['idToken'],'internal-error'),m(typeof _0x558638['idToken']<'u','internal-error'),m(typeof _0x558638['refreshToken']<'u','internal-error');const _0x4f873f='expiresIn'in _0x558638&&typeof _0x558638['expiresIn']<'u'?Number(_0x558638['expiresIn']):Cr(_0x558638['idToken']);this['updateTokensAndExpiration'](_0x558638['idToken'],_0x558638['refreshToken'],_0x4f873f);}['updateFromIdToken'](_0x24a7f5){m(_0x24a7f5['length']!==0x0,'internal-error');const _0x28d574=Cr(_0x24a7f5);this['updateTokensAndExpiration'](_0x24a7f5,null,_0x28d574);}async['getToken'](_0xd3f2a6,_0x7a2198=!0x1){return!_0x7a2198&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0xd3f2a6,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0xd3f2a6,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x481862,_0x3a7537){const {accessToken:_0x438ad4,refreshToken:_0x452843,expiresIn:_0x56f565}=await Sf(_0x481862,_0x3a7537);this['updateTokensAndExpiration'](_0x438ad4,_0x452843,Number(_0x56f565));}['updateTokensAndExpiration'](_0x166494,_0x128c2c,_0x2d5a4c){this['refreshToken']=_0x128c2c||null,this['accessToken']=_0x166494||null,this['expirationTime']=Date['now']()+_0x2d5a4c*0x3e8;}static['fromJSON'](_0x351781,_0x548b0c){const {refreshToken:_0x15be8d,accessToken:_0x29d70b,expirationTime:_0x13cd16}=_0x548b0c,_0x56a5cc=new et();return _0x15be8d&&(m(typeof _0x15be8d=='string','internal-error',{'appName':_0x351781}),_0x56a5cc['refreshToken']=_0x15be8d),_0x29d70b&&(m(typeof _0x29d70b=='string','internal-error',{'appName':_0x351781}),_0x56a5cc['accessToken']=_0x29d70b),_0x13cd16&&(m(typeof _0x13cd16=='number','internal-error',{'appName':_0x351781}),_0x56a5cc['expirationTime']=_0x13cd16),_0x56a5cc;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x4b7f28){this['accessToken']=_0x4b7f28['accessToken'],this['refreshToken']=_0x4b7f28['refreshToken'],this['expirationTime']=_0x4b7f28['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x4c4d12,_0xabc862){m(typeof _0x4c4d12=='string'||typeof _0x4c4d12>'u','internal-error',{'appName':_0xabc862});}class j{constructor({uid:_0x5957ff,auth:_0x3cfe80,stsTokenManager:_0x36c4b5,..._0x2e145d}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x5957ff,this['auth']=_0x3cfe80,this['stsTokenManager']=_0x36c4b5,this['accessToken']=_0x36c4b5['accessToken'],this['displayName']=_0x2e145d['displayName']||null,this['email']=_0x2e145d['email']||null,this['emailVerified']=_0x2e145d['emailVerified']||!0x1,this['phoneNumber']=_0x2e145d['phoneNumber']||null,this['photoURL']=_0x2e145d['photoURL']||null,this['isAnonymous']=_0x2e145d['isAnonymous']||!0x1,this['tenantId']=_0x2e145d['tenantId']||null,this['providerData']=_0x2e145d['providerData']?[..._0x2e145d['providerData']]:[],this['metadata']=new Li(_0x2e145d['createdAt']||void 0x0,_0x2e145d['lastLoginAt']||void 0x0);}async['getIdToken'](_0x43a646){const _0x300b50=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x43a646));return m(_0x300b50,this['auth'],'internal-error'),this['accessToken']!==_0x300b50&&(this['accessToken']=_0x300b50,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x300b50;}['getIdTokenResult'](_0x27328d){return Ef(this,_0x27328d);}['reload'](){return Cf(this);}['_assign'](_0x265ada){this!==_0x265ada&&(m(this['uid']===_0x265ada['uid'],this['auth'],'internal-error'),this['displayName']=_0x265ada['displayName'],this['photoURL']=_0x265ada['photoURL'],this['email']=_0x265ada['email'],this['emailVerified']=_0x265ada['emailVerified'],this['phoneNumber']=_0x265ada['phoneNumber'],this['isAnonymous']=_0x265ada['isAnonymous'],this['tenantId']=_0x265ada['tenantId'],this['providerData']=_0x265ada['providerData']['map'](_0x51b1c1=>({..._0x51b1c1})),this['metadata']['_copy'](_0x265ada['metadata']),this['stsTokenManager']['_assign'](_0x265ada['stsTokenManager']));}['_clone'](_0x1b34e0){const _0x3bbcab=new j({...this,'auth':_0x1b34e0,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x3bbcab['metadata']['_copy'](this['metadata']),_0x3bbcab;}['_onReload'](_0x5af029){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x5af029,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x47e62a){this['reloadListener']?this['reloadListener'](_0x47e62a):this['reloadUserInfo']=_0x47e62a;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x31c58d,_0x3246af=!0x1){let _0x1eb8c1=!0x1;_0x31c58d['idToken']&&_0x31c58d['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x31c58d),_0x1eb8c1=!0x0),_0x3246af&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x1eb8c1&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x14023f=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x14023f})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0xa7e5be=>({..._0xa7e5be})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x3b7624,_0x20acaf){const _0x5ce519=_0x20acaf['displayName']??void 0x0,_0x2e5ae8=_0x20acaf['email']??void 0x0,_0x30fe40=_0x20acaf['phoneNumber']??void 0x0,_0x400210=_0x20acaf['photoURL']??void 0x0,_0x2ee125=_0x20acaf['tenantId']??void 0x0,_0x56a331=_0x20acaf['_redirectEventId']??void 0x0,_0x9b6f7d=_0x20acaf['createdAt']??void 0x0,_0x45d9ed=_0x20acaf['lastLoginAt']??void 0x0,{uid:_0xa547d1,emailVerified:_0x26e519,isAnonymous:_0xa2f7dc,providerData:_0x216ea5,stsTokenManager:_0x370111}=_0x20acaf;m(_0xa547d1&&_0x370111,_0x3b7624,'internal-error');const _0x146372=et['fromJSON'](this['name'],_0x370111);m(typeof _0xa547d1=='string',_0x3b7624,'internal-error'),le(_0x5ce519,_0x3b7624['name']),le(_0x2e5ae8,_0x3b7624['name']),m(typeof _0x26e519=='boolean',_0x3b7624,'internal-error'),m(typeof _0xa2f7dc=='boolean',_0x3b7624,'internal-error'),le(_0x30fe40,_0x3b7624['name']),le(_0x400210,_0x3b7624['name']),le(_0x2ee125,_0x3b7624['name']),le(_0x56a331,_0x3b7624['name']),le(_0x9b6f7d,_0x3b7624['name']),le(_0x45d9ed,_0x3b7624['name']);const _0x1d2b17=new j({'uid':_0xa547d1,'auth':_0x3b7624,'email':_0x2e5ae8,'emailVerified':_0x26e519,'displayName':_0x5ce519,'isAnonymous':_0xa2f7dc,'photoURL':_0x400210,'phoneNumber':_0x30fe40,'tenantId':_0x2ee125,'stsTokenManager':_0x146372,'createdAt':_0x9b6f7d,'lastLoginAt':_0x45d9ed});return _0x216ea5&&Array['isArray'](_0x216ea5)&&(_0x1d2b17['providerData']=_0x216ea5['map'](_0x18b122=>({..._0x18b122}))),_0x56a331&&(_0x1d2b17['_redirectEventId']=_0x56a331),_0x1d2b17;}static async['_fromIdTokenResponse'](_0xf485b1,_0x2966c0,_0x408563=!0x1){const _0x185b68=new et();_0x185b68['updateFromServerResponse'](_0x2966c0);const _0x48098c=new j({'uid':_0x2966c0['localId'],'auth':_0xf485b1,'stsTokenManager':_0x185b68,'isAnonymous':_0x408563});return await Nn(_0x48098c),_0x48098c;}static async['_fromGetAccountInfoResponse'](_0x1e7d0d,_0x361557,_0x5adeab){const _0xcea326=_0x361557['users'][0x0];m(_0xcea326['localId']!==void 0x0,'internal-error');const _0x21781f=_0xcea326['providerUserInfo']!==void 0x0?Sa(_0xcea326['providerUserInfo']):[],_0x373ac1=!(_0xcea326['email']&&_0xcea326['passwordHash'])&&!(_0x21781f!=null&&_0x21781f['length']),_0x2e1288=new et();_0x2e1288['updateFromIdToken'](_0x5adeab);const _0x3fa651=new j({'uid':_0xcea326['localId'],'auth':_0x1e7d0d,'stsTokenManager':_0x2e1288,'isAnonymous':_0x373ac1}),_0x2ba620={'uid':_0xcea326['localId'],'displayName':_0xcea326['displayName']||null,'photoURL':_0xcea326['photoUrl']||null,'email':_0xcea326['email']||null,'emailVerified':_0xcea326['emailVerified']||!0x1,'phoneNumber':_0xcea326['phoneNumber']||null,'tenantId':_0xcea326['tenantId']||null,'providerData':_0x21781f,'metadata':new Li(_0xcea326['createdAt'],_0xcea326['lastLoginAt']),'isAnonymous':!(_0xcea326['email']&&_0xcea326['passwordHash'])&&!(_0x21781f!=null&&_0x21781f['length'])};return Object['assign'](_0x3fa651,_0x2ba620),_0x3fa651;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x5ebf84){ce(_0x5ebf84 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x5f30c5=Tr['get'](_0x5ebf84);return _0x5f30c5?(ce(_0x5f30c5 instanceof _0x5ebf84,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x5f30c5):(_0x5f30c5=new _0x5ebf84(),Tr['set'](_0x5ebf84,_0x5f30c5),_0x5f30c5);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x46ddba,_0x1cfb5f){this['storage'][_0x46ddba]=_0x1cfb5f;}async['_get'](_0xe40911){const _0x585700=this['storage'][_0xe40911];return _0x585700===void 0x0?null:_0x585700;}async['_remove'](_0x2af717){delete this['storage'][_0x2af717];}['_addListener'](_0x16ff13,_0x15613a){}['_removeListener'](_0x5ed303,_0x11830c){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x222ee9,_0x303720,_0x2cc03c){return'firebase:'+_0x222ee9+':'+_0x303720+':'+_0x2cc03c;}class tt{constructor(_0x32cabc,_0xa2116d,_0x3ae7d2){this['persistence']=_0x32cabc,this['auth']=_0xa2116d,this['userKey']=_0x3ae7d2;const {config:_0x5e8f82,name:_0x33ef6a}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x5e8f82['apiKey'],_0x33ef6a),this['fullPersistenceKey']=ln('persistence',_0x5e8f82['apiKey'],_0x33ef6a),this['boundEventHandler']=_0xa2116d['_onStorageEvent']['bind'](_0xa2116d),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x235d67){return this['persistence']['_set'](this['fullUserKey'],_0x235d67['toJSON']());}async['getCurrentUser'](){const _0x7b7e74=await this['persistence']['_get'](this['fullUserKey']);if(!_0x7b7e74)return null;if(typeof _0x7b7e74=='string'){const _0x43630c=await Pn(this['auth'],{'idToken':_0x7b7e74})['catch'](()=>{});return _0x43630c?j['_fromGetAccountInfoResponse'](this['auth'],_0x43630c,_0x7b7e74):null;}return j['_fromJSON'](this['auth'],_0x7b7e74);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x2cc993){if(this['persistence']===_0x2cc993)return;const _0x41a524=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x2cc993,_0x41a524)return this['setCurrentUser'](_0x41a524);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x38d0d5,_0x1b497e,_0x16e156='authUser'){if(!_0x1b497e['length'])return new tt(ie(Sr),_0x38d0d5,_0x16e156);const _0x3bc87e=(await Promise['all'](_0x1b497e['map'](async _0x4d678d=>{if(await _0x4d678d['_isAvailable']())return _0x4d678d;})))['filter'](_0x382d49=>_0x382d49);let _0x4ec7e4=_0x3bc87e[0x0]||ie(Sr);const _0x38f4f3=ln(_0x16e156,_0x38d0d5['config']['apiKey'],_0x38d0d5['name']);let _0x63d6b2=null;for(const _0x935619 of _0x1b497e)try{const _0x216a6f=await _0x935619['_get'](_0x38f4f3);if(_0x216a6f){let _0x654f8f;if(typeof _0x216a6f=='string'){const _0x53c676=await Pn(_0x38d0d5,{'idToken':_0x216a6f})['catch'](()=>{});if(!_0x53c676)break;_0x654f8f=await j['_fromGetAccountInfoResponse'](_0x38d0d5,_0x53c676,_0x216a6f);}else _0x654f8f=j['_fromJSON'](_0x38d0d5,_0x216a6f);_0x935619!==_0x4ec7e4&&(_0x63d6b2=_0x654f8f),_0x4ec7e4=_0x935619;break;}}catch{}const _0x5b813e=_0x3bc87e['filter'](_0x3decad=>_0x3decad['_shouldAllowMigration']);return!_0x4ec7e4['_shouldAllowMigration']||!_0x5b813e['length']?new tt(_0x4ec7e4,_0x38d0d5,_0x16e156):(_0x4ec7e4=_0x5b813e[0x0],_0x63d6b2&&await _0x4ec7e4['_set'](_0x38f4f3,_0x63d6b2['toJSON']()),await Promise['all'](_0x1b497e['map'](async _0x1686c5=>{if(_0x1686c5!==_0x4ec7e4)try{await _0x1686c5['_remove'](_0x38f4f3);}catch{}})),new tt(_0x4ec7e4,_0x38d0d5,_0x16e156));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x1309a6){const _0x39f130=_0x1309a6['toLowerCase']();if(_0x39f130['includes']('opera/')||_0x39f130['includes']('opr/')||_0x39f130['includes']('opios/'))return'Opera';if(Pa(_0x39f130))return'IEMobile';if(_0x39f130['includes']('msie')||_0x39f130['includes']('trident/'))return'IE';if(_0x39f130['includes']('edge/'))return'Edge';if(Ra(_0x39f130))return'Firefox';if(_0x39f130['includes']('silk/'))return'Silk';if(Oa(_0x39f130))return'Blackberry';if(Da(_0x39f130))return'Webos';if(Aa(_0x39f130))return'Safari';if((_0x39f130['includes']('chrome/')||ka(_0x39f130))&&!_0x39f130['includes']('edge/'))return'Chrome';if(Na(_0x39f130))return'Android';{const _0x15b5f5=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0xb1d6ce=_0x1309a6['match'](_0x15b5f5);if((_0xb1d6ce==null?void 0x0:_0xb1d6ce['length'])===0x2)return _0xb1d6ce[0x1];}return'Other';}function Ra(_0x396e8d=W()){return/firefox\//i['test'](_0x396e8d);}function Aa(_0x5da7e3=W()){const _0x268937=_0x5da7e3['toLowerCase']();return _0x268937['includes']('safari/')&&!_0x268937['includes']('chrome/')&&!_0x268937['includes']('crios/')&&!_0x268937['includes']('android');}function ka(_0x259ff4=W()){return/crios\//i['test'](_0x259ff4);}function Pa(_0x168187=W()){return/iemobile/i['test'](_0x168187);}function Na(_0x319c32=W()){return/android/i['test'](_0x319c32);}function Oa(_0x1ebeff=W()){return/blackberry/i['test'](_0x1ebeff);}function Da(_0x5967ac=W()){return/webos/i['test'](_0x5967ac);}function Ss(_0x4430b8=W()){return/iphone|ipad|ipod/i['test'](_0x4430b8)||/macintosh/i['test'](_0x4430b8)&&/mobile/i['test'](_0x4430b8);}function Rf(_0x6f6c19=W()){var _0x29b3a6;return Ss(_0x6f6c19)&&!!((_0x29b3a6=window['navigator'])!=null&&_0x29b3a6['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x2c243d=W()){return Ss(_0x2c243d)||Na(_0x2c243d)||Da(_0x2c243d)||Oa(_0x2c243d)||/windows phone/i['test'](_0x2c243d)||Pa(_0x2c243d);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x50c6c5,_0x35bc1b=[]){let _0x5d3e17;switch(_0x50c6c5){case'Browser':_0x5d3e17=br(W());break;case'Worker':_0x5d3e17=br(W())+'-'+_0x50c6c5;break;default:_0x5d3e17=_0x50c6c5;}const _0x2456ef=_0x35bc1b['length']?_0x35bc1b['join'](','):'FirebaseCore-web';return _0x5d3e17+'/JsCore/'+dt+'/'+_0x2456ef;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x13799f){this['auth']=_0x13799f,this['queue']=[];}['pushCallback'](_0x204300,_0x28c58b){const _0x5d99be=_0x13b1ba=>new Promise((_0x11346a,_0x152e56)=>{try{const _0x3e6f9b=_0x204300(_0x13b1ba);_0x11346a(_0x3e6f9b);}catch(_0x1eaffa){_0x152e56(_0x1eaffa);}});_0x5d99be['onAbort']=_0x28c58b,this['queue']['push'](_0x5d99be);const _0x519c7b=this['queue']['length']-0x1;return()=>{this['queue'][_0x519c7b]=()=>Promise['resolve']();};}async['runMiddleware'](_0x1b954b){if(this['auth']['currentUser']===_0x1b954b)return;const _0x592446=[];try{for(const _0x325ae1 of this['queue'])await _0x325ae1(_0x1b954b),_0x325ae1['onAbort']&&_0x592446['push'](_0x325ae1['onAbort']);}catch(_0x23f147){_0x592446['reverse']();for(const _0x4c7e10 of _0x592446)try{_0x4c7e10();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x23f147==null?void 0x0:_0x23f147['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x5eb702,_0x3d7d51={}){return Pe(_0x5eb702,'GET','/v2/passwordPolicy',ke(_0x5eb702,_0x3d7d51));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x5dc320){var _0x52f004;const _0x56b11c=_0x5dc320['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x56b11c['minPasswordLength']??Nf,_0x56b11c['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x56b11c['maxPasswordLength']),_0x56b11c['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x56b11c['containsLowercaseCharacter']),_0x56b11c['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x56b11c['containsUppercaseCharacter']),_0x56b11c['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x56b11c['containsNumericCharacter']),_0x56b11c['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x56b11c['containsNonAlphanumericCharacter']),this['enforcementState']=_0x5dc320['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x52f004=_0x5dc320['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x52f004['join'](''))??'',this['forceUpgradeOnSignin']=_0x5dc320['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x5dc320['schemaVersion'];}['validatePassword'](_0x2080e0){const _0x297848={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x2080e0,_0x297848),this['validatePasswordCharacterOptions'](_0x2080e0,_0x297848),_0x297848['isValid']&&(_0x297848['isValid']=_0x297848['meetsMinPasswordLength']??!0x0),_0x297848['isValid']&&(_0x297848['isValid']=_0x297848['meetsMaxPasswordLength']??!0x0),_0x297848['isValid']&&(_0x297848['isValid']=_0x297848['containsLowercaseLetter']??!0x0),_0x297848['isValid']&&(_0x297848['isValid']=_0x297848['containsUppercaseLetter']??!0x0),_0x297848['isValid']&&(_0x297848['isValid']=_0x297848['containsNumericCharacter']??!0x0),_0x297848['isValid']&&(_0x297848['isValid']=_0x297848['containsNonAlphanumericCharacter']??!0x0),_0x297848;}['validatePasswordLengthOptions'](_0x405c8a,_0xb574c5){const _0x31d2a7=this['customStrengthOptions']['minPasswordLength'],_0x477c55=this['customStrengthOptions']['maxPasswordLength'];_0x31d2a7&&(_0xb574c5['meetsMinPasswordLength']=_0x405c8a['length']>=_0x31d2a7),_0x477c55&&(_0xb574c5['meetsMaxPasswordLength']=_0x405c8a['length']<=_0x477c55);}['validatePasswordCharacterOptions'](_0x578674,_0x210cee){this['updatePasswordCharacterOptionsStatuses'](_0x210cee,!0x1,!0x1,!0x1,!0x1);let _0x8a299f;for(let _0x40b369=0x0;_0x40b369<_0x578674['length'];_0x40b369++)_0x8a299f=_0x578674['charAt'](_0x40b369),this['updatePasswordCharacterOptionsStatuses'](_0x210cee,_0x8a299f>='a'&&_0x8a299f<='z',_0x8a299f>='A'&&_0x8a299f<='Z',_0x8a299f>='0'&&_0x8a299f<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x8a299f));}['updatePasswordCharacterOptionsStatuses'](_0x385b93,_0x5f5966,_0x184cbc,_0xa0812b,_0x5a2399){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x385b93['containsLowercaseLetter']||(_0x385b93['containsLowercaseLetter']=_0x5f5966)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x385b93['containsUppercaseLetter']||(_0x385b93['containsUppercaseLetter']=_0x184cbc)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x385b93['containsNumericCharacter']||(_0x385b93['containsNumericCharacter']=_0xa0812b)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x385b93['containsNonAlphanumericCharacter']||(_0x385b93['containsNonAlphanumericCharacter']=_0x5a2399));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0xccd870,_0x1e8805,_0x2af3f4,_0x1d61e2){this['app']=_0xccd870,this['heartbeatServiceProvider']=_0x1e8805,this['appCheckServiceProvider']=_0x2af3f4,this['config']=_0x1d61e2,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0xccd870['name'],this['clientVersion']=_0x1d61e2['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x55b5b7=>this['_resolvePersistenceManagerAvailable']=_0x55b5b7);}['_initializeWithPersistence'](_0x54b52f,_0x458562){return _0x458562&&(this['_popupRedirectResolver']=ie(_0x458562)),this['_initializationPromise']=this['queue'](async()=>{var _0x5674b3,_0x1122fa,_0x286864;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x54b52f),(_0x5674b3=this['_resolvePersistenceManagerAvailable'])==null||_0x5674b3['call'](this),!this['_deleted'])){if((_0x1122fa=this['_popupRedirectResolver'])!=null&&_0x1122fa['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x458562),this['lastNotifiedUid']=((_0x286864=this['currentUser'])==null?void 0x0:_0x286864['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x4feaec=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x4feaec)){if(this['currentUser']&&_0x4feaec&&this['currentUser']['uid']===_0x4feaec['uid']){this['_currentUser']['_assign'](_0x4feaec),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x4feaec,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x3b39f2){try{const _0x47f2ac=await Pn(this,{'idToken':_0x3b39f2}),_0x2e6a37=await j['_fromGetAccountInfoResponse'](this,_0x47f2ac,_0x3b39f2);await this['directlySetCurrentUser'](_0x2e6a37);}catch(_0x5b3c96){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x5b3c96),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x3efc9a){var _0x3543b4;if($(this['app'])){const _0x476b3a=this['app']['settings']['authIdToken'];return _0x476b3a?new Promise(_0x4413e8=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x476b3a)['then'](_0x4413e8,_0x4413e8));}):this['directlySetCurrentUser'](null);}const _0x2de8a4=await this['assertedPersistence']['getCurrentUser']();let _0x2e0e88=_0x2de8a4,_0x13f595=!0x1;if(_0x3efc9a&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x58384c=(_0x3543b4=this['redirectUser'])==null?void 0x0:_0x3543b4['_redirectEventId'],_0x4fc1e0=_0x2e0e88==null?void 0x0:_0x2e0e88['_redirectEventId'],_0x47c81a=await this['tryRedirectSignIn'](_0x3efc9a);(!_0x58384c||_0x58384c===_0x4fc1e0)&&(_0x47c81a!=null&&_0x47c81a['user'])&&(_0x2e0e88=_0x47c81a['user'],_0x13f595=!0x0);}if(!_0x2e0e88)return this['directlySetCurrentUser'](null);if(!_0x2e0e88['_redirectEventId']){if(_0x13f595)try{await this['beforeStateQueue']['runMiddleware'](_0x2e0e88);}catch(_0x4ed9fe){_0x2e0e88=_0x2de8a4,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x4ed9fe));}return _0x2e0e88?this['reloadAndSetCurrentUserOrClear'](_0x2e0e88):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x2e0e88['_redirectEventId']?this['directlySetCurrentUser'](_0x2e0e88):this['reloadAndSetCurrentUserOrClear'](_0x2e0e88);}async['tryRedirectSignIn'](_0x3cd933){let _0x523d28=null;try{_0x523d28=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x3cd933,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x523d28;}async['reloadAndSetCurrentUserOrClear'](_0x3f29c5){try{await Nn(_0x3f29c5);}catch(_0x4bf214){if((_0x4bf214==null?void 0x0:_0x4bf214['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x3f29c5);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x1eae72){if($(this['app']))return Promise['reject'](re(this));const _0x4fbf2f=_0x1eae72?P(_0x1eae72):null;return _0x4fbf2f&&m(_0x4fbf2f['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x4fbf2f&&_0x4fbf2f['_clone'](this));}async['_updateCurrentUser'](_0x561595,_0x287f32=!0x1){if(!this['_deleted'])return _0x561595&&m(this['tenantId']===_0x561595['tenantId'],this,'tenant-id-mismatch'),_0x287f32||await this['beforeStateQueue']['runMiddleware'](_0x561595),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x561595),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x2f2d01){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x2f2d01));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x186e6a){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x2dcc0a=this['_getPasswordPolicyInternal']();return _0x2dcc0a['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x2dcc0a['validatePassword'](_0x186e6a);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x3ac019=await Pf(this),_0x12c5ed=new Of(_0x3ac019);this['tenantId']===null?this['_projectPasswordPolicy']=_0x12c5ed:this['_tenantPasswordPolicies'][this['tenantId']]=_0x12c5ed;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0xf43fc9){this['_errorFactory']=new Gt('auth','Firebase',_0xf43fc9());}['onAuthStateChanged'](_0x52de0f,_0x57a736,_0x289517){return this['registerStateListener'](this['authStateSubscription'],_0x52de0f,_0x57a736,_0x289517);}['beforeAuthStateChanged'](_0x498f13,_0x8bfa18){return this['beforeStateQueue']['pushCallback'](_0x498f13,_0x8bfa18);}['onIdTokenChanged'](_0x9e8e3e,_0x8367d9,_0x5ecf0e){return this['registerStateListener'](this['idTokenSubscription'],_0x9e8e3e,_0x8367d9,_0x5ecf0e);}['authStateReady'](){return new Promise((_0x285eb7,_0x55af6c)=>{if(this['currentUser'])_0x285eb7();else{const _0x1d591f=this['onAuthStateChanged'](()=>{_0x1d591f(),_0x285eb7();},_0x55af6c);}});}async['revokeAccessToken'](_0x2ccc30){if(this['currentUser']){const _0xf9dc41=await this['currentUser']['getIdToken'](),_0x3740eb={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x2ccc30,'idToken':_0xf9dc41};this['tenantId']!=null&&(_0x3740eb['tenantId']=this['tenantId']),await bf(this,_0x3740eb);}}['toJSON'](){var _0x5ab34a;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x5ab34a=this['_currentUser'])==null?void 0x0:_0x5ab34a['toJSON']()};}async['_setRedirectUser'](_0x3474ba,_0x41bfc8){const _0x5bbad7=await this['getOrInitRedirectPersistenceManager'](_0x41bfc8);return _0x3474ba===null?_0x5bbad7['removeCurrentUser']():_0x5bbad7['setCurrentUser'](_0x3474ba);}async['getOrInitRedirectPersistenceManager'](_0x58176b){if(!this['redirectPersistenceManager']){const _0x5efb8c=_0x58176b&&ie(_0x58176b)||this['_popupRedirectResolver'];m(_0x5efb8c,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x5efb8c['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x50e010){var _0x39cd73,_0x4a360c;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x39cd73=this['_currentUser'])==null?void 0x0:_0x39cd73['_redirectEventId'])===_0x50e010?this['_currentUser']:((_0x4a360c=this['redirectUser'])==null?void 0x0:_0x4a360c['_redirectEventId'])===_0x50e010?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x1005ac){if(_0x1005ac===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x1005ac));}['_notifyListenersIfCurrent'](_0x5f12d7){_0x5f12d7===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x53841c;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x50c1ee=((_0x53841c=this['currentUser'])==null?void 0x0:_0x53841c['uid'])??null;this['lastNotifiedUid']!==_0x50c1ee&&(this['lastNotifiedUid']=_0x50c1ee,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x10dc0e,_0x5be172,_0x352457,_0x225acc){if(this['_deleted'])return()=>{};const _0x474965=typeof _0x5be172=='function'?_0x5be172:_0x5be172['next']['bind'](_0x5be172);let _0x1a0f9b=!0x1;const _0x3e6ba3=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x3e6ba3,this,'internal-error'),_0x3e6ba3['then'](()=>{_0x1a0f9b||_0x474965(this['currentUser']);}),typeof _0x5be172=='function'){const _0x403a19=_0x10dc0e['addObserver'](_0x5be172,_0x352457,_0x225acc);return()=>{_0x1a0f9b=!0x0,_0x403a19();};}else{const _0x2572f6=_0x10dc0e['addObserver'](_0x5be172);return()=>{_0x1a0f9b=!0x0,_0x2572f6();};}}async['directlySetCurrentUser'](_0x5a27e0){this['currentUser']&&this['currentUser']!==_0x5a27e0&&this['_currentUser']['_stopProactiveRefresh'](),_0x5a27e0&&this['isProactiveRefreshEnabled']&&_0x5a27e0['_startProactiveRefresh'](),this['currentUser']=_0x5a27e0,_0x5a27e0?await this['assertedPersistence']['setCurrentUser'](_0x5a27e0):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x30903e){return this['operations']=this['operations']['then'](_0x30903e,_0x30903e),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x368680){!_0x368680||this['frameworks']['includes'](_0x368680)||(this['frameworks']['push'](_0x368680),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x36d324;const _0x34d39b={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x34d39b['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x51d3b2=await((_0x36d324=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x36d324['getHeartbeatsHeader']());_0x51d3b2&&(_0x34d39b['X-Firebase-Client']=_0x51d3b2);const _0x45b150=await this['_getAppCheckToken']();return _0x45b150&&(_0x34d39b['X-Firebase-AppCheck']=_0x45b150),_0x34d39b;}async['_getAppCheckToken'](){var _0x5c3ea9;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x991902=await((_0x5c3ea9=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x5c3ea9['getToken']());return _0x991902!=null&&_0x991902['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x991902['error']),_0x991902==null?void 0x0:_0x991902['token'];}}function Ke(_0x22dc98){return P(_0x22dc98);}class Rr{constructor(_0x2bafca){this['auth']=_0x2bafca,this['observer']=null,this['addObserver']=Tc(_0x3ab278=>this['observer']=_0x3ab278);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x45e991){Jn=_0x45e991;}function xa(_0x45a84d){return Jn['loadJS'](_0x45a84d);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x31a3d4){return'__'+_0x31a3d4+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x3fca0a){_0x3fca0a();}['execute'](_0x580a67,_0x15a8b2){return Promise['resolve']('token');}['render'](_0x452fe7,_0x118ce5){return'';}}class Wf{['ready'](_0x363d8b){_0x363d8b();}['execute'](_0x47963d,_0x517b90){return Promise['resolve']('token');}['render'](_0x393864,_0xa40a80){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0xd36a95){this['type']=Bf,this['auth']=Ke(_0xd36a95);}async['verify'](_0x238a44='verify',_0x27639c=!0x1){async function _0x48dc98(_0x35d389){if(!_0x27639c){if(_0x35d389['tenantId']==null&&_0x35d389['_agentRecaptchaConfig']!=null)return _0x35d389['_agentRecaptchaConfig']['siteKey'];if(_0x35d389['tenantId']!=null&&_0x35d389['_tenantRecaptchaConfigs'][_0x35d389['tenantId']]!==void 0x0)return _0x35d389['_tenantRecaptchaConfigs'][_0x35d389['tenantId']]['siteKey'];}return new Promise(async(_0x2c96d5,_0x550ec0)=>{yf(_0x35d389,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x2b7f19=>{if(_0x2b7f19['recaptchaKey']===void 0x0)_0x550ec0(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x43693f=new mf(_0x2b7f19);return _0x35d389['tenantId']==null?_0x35d389['_agentRecaptchaConfig']=_0x43693f:_0x35d389['_tenantRecaptchaConfigs'][_0x35d389['tenantId']]=_0x43693f,_0x2c96d5(_0x43693f['siteKey']);}})['catch'](_0x172262=>{_0x550ec0(_0x172262);});});}function _0x42b7e8(_0x384aa8,_0x53b77f,_0x455afc){const _0x563d39=window['grecaptcha'];wr(_0x563d39)?_0x563d39['enterprise']['ready'](()=>{_0x563d39['enterprise']['execute'](_0x384aa8,{'action':_0x238a44})['then'](_0x49d160=>{_0x53b77f(_0x49d160);})['catch'](()=>{_0x53b77f(Fa);});}):_0x455afc(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x3142b2,_0x4c36de)=>{_0x48dc98(this['auth'])['then'](async _0x4d828d=>{if(!_0x27639c&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x42b7e8(_0x4d828d,_0x3142b2,_0x4c36de);else{if(typeof window>'u'){_0x4c36de(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x5a27a9=Lf();_0x5a27a9['length']!==0x0&&(_0x5a27a9+=_0x4d828d+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x504dfc;(_0x504dfc=he['scriptInjectionDeferred'])==null||_0x504dfc['resolve']();},xa(_0x5a27a9)['then'](()=>{var _0x3ed530;return(_0x3ed530=he['scriptInjectionDeferred'])==null?void 0x0:_0x3ed530['promise'];})['then'](()=>{_0x42b7e8(_0x4d828d,_0x3142b2,_0x4c36de);})['catch'](_0x5a261b=>{_0x4c36de(_0x5a261b);});}})['catch'](_0x29d406=>{_0x4c36de(_0x29d406);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x82e87d,_0x16305c,_0x547e1d,_0x3f72cd=!0x1,_0xfac078=!0x1){const _0x33b21d=new he(_0x82e87d);let _0x1f9988;if(_0xfac078)_0x1f9988=Fa;else try{_0x1f9988=await _0x33b21d['verify'](_0x547e1d);}catch{_0x1f9988=await _0x33b21d['verify'](_0x547e1d,!0x0);}const _0x45e5a2={..._0x16305c};if(_0x547e1d==='mfaSmsEnrollment'||_0x547e1d==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x45e5a2){const _0x36a297=_0x45e5a2['phoneEnrollmentInfo']['phoneNumber'],_0x2488cd=_0x45e5a2['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x45e5a2,{'phoneEnrollmentInfo':{'phoneNumber':_0x36a297,'recaptchaToken':_0x2488cd,'captchaResponse':_0x1f9988,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x45e5a2){const _0x2af69a=_0x45e5a2['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x45e5a2,{'phoneSignInInfo':{'recaptchaToken':_0x2af69a,'captchaResponse':_0x1f9988,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x45e5a2;}return _0x3f72cd?Object['assign'](_0x45e5a2,{'captchaResp':_0x1f9988}):Object['assign'](_0x45e5a2,{'captchaResponse':_0x1f9988}),Object['assign'](_0x45e5a2,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x45e5a2,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x45e5a2;}async function xi(_0x50a783,_0x265662,_0x806534,_0xe344ff,_0x458589){var _0x82b792;if((_0x82b792=_0x50a783['_getRecaptchaConfig']())!=null&&_0x82b792['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x322aff=await kr(_0x50a783,_0x265662,_0x806534,_0x806534==='getOobCode');return _0xe344ff(_0x50a783,_0x322aff);}else return _0xe344ff(_0x50a783,_0x265662)['catch'](async _0x32d6ca=>{if(_0x32d6ca['code']==='auth/missing-recaptcha-token'){console['log'](_0x806534+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x5c40ea=await kr(_0x50a783,_0x265662,_0x806534,_0x806534==='getOobCode');return _0xe344ff(_0x50a783,_0x5c40ea);}else return Promise['reject'](_0x32d6ca);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x1c57b1,_0x4677a4){const _0x23b6d9=Hi(_0x1c57b1,'auth');if(_0x23b6d9['isInitialized']()){const _0x25cb7b=_0x23b6d9['getImmediate'](),_0x5006d9=_0x23b6d9['getOptions']();if(xe(_0x5006d9,_0x4677a4??{}))return _0x25cb7b;Y(_0x25cb7b,'already-initialized');}return _0x23b6d9['initialize']({'options':_0x4677a4});}function Hf(_0x3373ce,_0x22a712){const _0x28d759=(_0x22a712==null?void 0x0:_0x22a712['persistence'])||[],_0x33756a=(Array['isArray'](_0x28d759)?_0x28d759:[_0x28d759])['map'](ie);_0x22a712!=null&&_0x22a712['errorMap']&&_0x3373ce['_updateErrorMap'](_0x22a712['errorMap']),_0x3373ce['_initializeWithPersistence'](_0x33756a,_0x22a712==null?void 0x0:_0x22a712['popupRedirectResolver']);}function $f(_0x5ceec8,_0x1c1a45,_0x199d0b){const _0x428471=Ke(_0x5ceec8);m(/^https?:\/\//['test'](_0x1c1a45),_0x428471,'invalid-emulator-scheme');const _0x38ca59=!0x1,_0x5e0b93=Ua(_0x1c1a45),{host:_0x4b3ae9,port:_0x1b23b5}=Gf(_0x1c1a45),_0x1b3d6f=_0x1b23b5===null?'':':'+_0x1b23b5,_0xa033f6={'url':_0x5e0b93+'//'+_0x4b3ae9+_0x1b3d6f+'/'},_0x4e68ee=Object['freeze']({'host':_0x4b3ae9,'port':_0x1b23b5,'protocol':_0x5e0b93['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x38ca59})});if(!_0x428471['_canInitEmulator']){m(_0x428471['config']['emulator']&&_0x428471['emulatorConfig'],_0x428471,'emulator-config-failed'),m(xe(_0xa033f6,_0x428471['config']['emulator'])&&xe(_0x4e68ee,_0x428471['emulatorConfig']),_0x428471,'emulator-config-failed');return;}_0x428471['config']['emulator']=_0xa033f6,_0x428471['emulatorConfig']=_0x4e68ee,_0x428471['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x4b3ae9)?Qr(_0x5e0b93+'//'+_0x4b3ae9+_0x1b3d6f):qf();}function Ua(_0x133767){const _0x50aa38=_0x133767['indexOf'](':');return _0x50aa38<0x0?'':_0x133767['substr'](0x0,_0x50aa38+0x1);}function Gf(_0x580d81){const _0x1aa544=Ua(_0x580d81),_0x1f4a82=/(\/\/)?([^?#/]+)/['exec'](_0x580d81['substr'](_0x1aa544['length']));if(!_0x1f4a82)return{'host':'','port':null};const _0x4ab38=_0x1f4a82[0x2]['split']('@')['pop']()||'',_0x2e83f6=/^(\[[^\]]+\])(:|$)/['exec'](_0x4ab38);if(_0x2e83f6){const _0x551faa=_0x2e83f6[0x1];return{'host':_0x551faa,'port':Pr(_0x4ab38['substr'](_0x551faa['length']+0x1))};}else{const [_0x45048a,_0xbc1989]=_0x4ab38['split'](':');return{'host':_0x45048a,'port':Pr(_0xbc1989)};}}function Pr(_0x419a28){if(!_0x419a28)return null;const _0x11e175=Number(_0x419a28);return isNaN(_0x11e175)?null:_0x11e175;}function qf(){function _0xdcc802(){const _0x55bc4c=document['createElement']('p'),_0x2b7584=_0x55bc4c['style'];_0x55bc4c['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x2b7584['position']='fixed',_0x2b7584['width']='100%',_0x2b7584['backgroundColor']='#ffffff',_0x2b7584['border']='.1em\x20solid\x20#000000',_0x2b7584['color']='#b50000',_0x2b7584['bottom']='0px',_0x2b7584['left']='0px',_0x2b7584['margin']='0px',_0x2b7584['zIndex']='10000',_0x2b7584['textAlign']='center',_0x55bc4c['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x55bc4c);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0xdcc802):_0xdcc802());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0xafbb8c,_0x3b6ac3){this['providerId']=_0xafbb8c,this['signInMethod']=_0x3b6ac3;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x3e8ed5){return ne('not\x20implemented');}['_linkToIdToken'](_0x2ad47a,_0x597cea){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x210b03){return ne('not\x20implemented');}}async function zf(_0x1baead,_0x798917){return Pe(_0x1baead,'POST','/v1/accounts:signUp',_0x798917);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x516f87,_0x11f9c4){return en(_0x516f87,'POST','/v1/accounts:signInWithPassword',ke(_0x516f87,_0x11f9c4));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x17ebe6,_0x442ced){return en(_0x17ebe6,'POST','/v1/accounts:signInWithEmailLink',ke(_0x17ebe6,_0x442ced));}async function Yf(_0x469f48,_0x43fd7d){return en(_0x469f48,'POST','/v1/accounts:signInWithEmailLink',ke(_0x469f48,_0x43fd7d));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x4973c2,_0x4c6b95,_0x2faf97,_0x418465=null){super('password',_0x2faf97),this['_email']=_0x4973c2,this['_password']=_0x4c6b95,this['_tenantId']=_0x418465;}static['_fromEmailAndPassword'](_0x153090,_0x2e8f42){return new $t(_0x153090,_0x2e8f42,'password');}static['_fromEmailAndCode'](_0x2eec36,_0xa74190,_0x1a178d=null){return new $t(_0x2eec36,_0xa74190,'emailLink',_0x1a178d);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x5f8287){const _0x533164=typeof _0x5f8287=='string'?JSON['parse'](_0x5f8287):_0x5f8287;if(_0x533164!=null&&_0x533164['email']&&(_0x533164!=null&&_0x533164['password'])){if(_0x533164['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x533164['email'],_0x533164['password']);if(_0x533164['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x533164['email'],_0x533164['password'],_0x533164['tenantId']);}return null;}async['_getIdTokenResponse'](_0x59feac){switch(this['signInMethod']){case'password':const _0x2f0f26={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x59feac,_0x2f0f26,'signInWithPassword',jf);case'emailLink':return Kf(_0x59feac,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x59feac,'internal-error');}}async['_linkToIdToken'](_0x475c00,_0x3d900c){switch(this['signInMethod']){case'password':const _0x44cbb2={'idToken':_0x3d900c,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x475c00,_0x44cbb2,'signUpPassword',zf);case'emailLink':return Yf(_0x475c00,{'idToken':_0x3d900c,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x475c00,'internal-error');}}['_getReauthenticationResolver'](_0x514bab){return this['_getIdTokenResponse'](_0x514bab);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x31165b,_0x30ff64){return en(_0x31165b,'POST','/v1/accounts:signInWithIdp',ke(_0x31165b,_0x30ff64));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x18dc5a){const _0x33ceea=new $e(_0x18dc5a['providerId'],_0x18dc5a['signInMethod']);return _0x18dc5a['idToken']||_0x18dc5a['accessToken']?(_0x18dc5a['idToken']&&(_0x33ceea['idToken']=_0x18dc5a['idToken']),_0x18dc5a['accessToken']&&(_0x33ceea['accessToken']=_0x18dc5a['accessToken']),_0x18dc5a['nonce']&&!_0x18dc5a['pendingToken']&&(_0x33ceea['nonce']=_0x18dc5a['nonce']),_0x18dc5a['pendingToken']&&(_0x33ceea['pendingToken']=_0x18dc5a['pendingToken'])):_0x18dc5a['oauthToken']&&_0x18dc5a['oauthTokenSecret']?(_0x33ceea['accessToken']=_0x18dc5a['oauthToken'],_0x33ceea['secret']=_0x18dc5a['oauthTokenSecret']):Y('argument-error'),_0x33ceea;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0xde50e1){const _0x18b2b7=typeof _0xde50e1=='string'?JSON['parse'](_0xde50e1):_0xde50e1,{providerId:_0x146d7a,signInMethod:_0x30365d,..._0x3bec78}=_0x18b2b7;if(!_0x146d7a||!_0x30365d)return null;const _0x4ae749=new $e(_0x146d7a,_0x30365d);return _0x4ae749['idToken']=_0x3bec78['idToken']||void 0x0,_0x4ae749['accessToken']=_0x3bec78['accessToken']||void 0x0,_0x4ae749['secret']=_0x3bec78['secret'],_0x4ae749['nonce']=_0x3bec78['nonce'],_0x4ae749['pendingToken']=_0x3bec78['pendingToken']||null,_0x4ae749;}['_getIdTokenResponse'](_0x193626){const _0x5d821a=this['buildRequest']();return nt(_0x193626,_0x5d821a);}['_linkToIdToken'](_0x30def2,_0x52e50f){const _0x252d17=this['buildRequest']();return _0x252d17['idToken']=_0x52e50f,nt(_0x30def2,_0x252d17);}['_getReauthenticationResolver'](_0x2d0e8e){const _0x3eda80=this['buildRequest']();return _0x3eda80['autoCreate']=!0x1,nt(_0x2d0e8e,_0x3eda80);}['buildRequest'](){const _0x1ea506={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x1ea506['pendingToken']=this['pendingToken'];else{const _0x37d776={};this['idToken']&&(_0x37d776['id_token']=this['idToken']),this['accessToken']&&(_0x37d776['access_token']=this['accessToken']),this['secret']&&(_0x37d776['oauth_token_secret']=this['secret']),_0x37d776['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x37d776['nonce']=this['nonce']),_0x1ea506['postBody']=ut(_0x37d776);}return _0x1ea506;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x3a5ff3){switch(_0x3a5ff3){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x1a7c12){const _0x59f6a6=Ct(Tt(_0x1a7c12))['link'],_0x551d5f=_0x59f6a6?Ct(Tt(_0x59f6a6))['deep_link_id']:null,_0x4eb530=Ct(Tt(_0x1a7c12))['deep_link_id'];return(_0x4eb530?Ct(Tt(_0x4eb530))['link']:null)||_0x4eb530||_0x551d5f||_0x59f6a6||_0x1a7c12;}class Rs{constructor(_0x1fdd7f){const _0x20f055=Ct(Tt(_0x1fdd7f)),_0x42b37c=_0x20f055['apiKey']??null,_0x5ac598=_0x20f055['oobCode']??null,_0x16a794=Jf(_0x20f055['mode']??null);m(_0x42b37c&&_0x5ac598&&_0x16a794,'argument-error'),this['apiKey']=_0x42b37c,this['operation']=_0x16a794,this['code']=_0x5ac598,this['continueUrl']=_0x20f055['continueUrl']??null,this['languageCode']=_0x20f055['lang']??null,this['tenantId']=_0x20f055['tenantId']??null;}static['parseLink'](_0x79da0a){const _0x30f63b=Xf(_0x79da0a);try{return new Rs(_0x30f63b);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x166d8f,_0xeffe79){return $t['_fromEmailAndPassword'](_0x166d8f,_0xeffe79);}static['credentialWithLink'](_0xcef67b,_0x43b904){const _0x462bb8=Rs['parseLink'](_0x43b904);return m(_0x462bb8,'argument-error'),$t['_fromEmailAndCode'](_0xcef67b,_0x462bb8['code'],_0x462bb8['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x2b39e1){this['providerId']=_0x2b39e1,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x56bec7){this['defaultLanguageCode']=_0x56bec7;}['setCustomParameters'](_0x484d1f){return this['customParameters']=_0x484d1f,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x84532){return this['scopes']['includes'](_0x84532)||this['scopes']['push'](_0x84532),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x3e61d8){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x3e61d8});}static['credentialFromResult'](_0x44ef58){return ue['credentialFromTaggedObject'](_0x44ef58);}static['credentialFromError'](_0x359caa){return ue['credentialFromTaggedObject'](_0x359caa['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x53cbdb}){if(!_0x53cbdb||!('oauthAccessToken'in _0x53cbdb)||!_0x53cbdb['oauthAccessToken'])return null;try{return ue['credential'](_0x53cbdb['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x106e63,_0xb9b06c){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x106e63,'accessToken':_0xb9b06c});}static['credentialFromResult'](_0x2bf0bc){return de['credentialFromTaggedObject'](_0x2bf0bc);}static['credentialFromError'](_0xd0abee){return de['credentialFromTaggedObject'](_0xd0abee['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x47966e}){if(!_0x47966e)return null;const {oauthIdToken:_0x563810,oauthAccessToken:_0x59db48}=_0x47966e;if(!_0x563810&&!_0x59db48)return null;try{return de['credential'](_0x563810,_0x59db48);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x5673c0){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x5673c0});}static['credentialFromResult'](_0x2fc748){return fe['credentialFromTaggedObject'](_0x2fc748);}static['credentialFromError'](_0xe27518){return fe['credentialFromTaggedObject'](_0xe27518['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x218876}){if(!_0x218876||!('oauthAccessToken'in _0x218876)||!_0x218876['oauthAccessToken'])return null;try{return fe['credential'](_0x218876['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x172921,_0x278a26){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x172921,'oauthTokenSecret':_0x278a26});}static['credentialFromResult'](_0x38f764){return pe['credentialFromTaggedObject'](_0x38f764);}static['credentialFromError'](_0x2756d4){return pe['credentialFromTaggedObject'](_0x2756d4['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x184a74}){if(!_0x184a74)return null;const {oauthAccessToken:_0x5d8d9a,oauthTokenSecret:_0x3e41bc}=_0x184a74;if(!_0x5d8d9a||!_0x3e41bc)return null;try{return pe['credential'](_0x5d8d9a,_0x3e41bc);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x1f0a9e,_0x205e46){return en(_0x1f0a9e,'POST','/v1/accounts:signUp',ke(_0x1f0a9e,_0x205e46));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x2e20a3){this['user']=_0x2e20a3['user'],this['providerId']=_0x2e20a3['providerId'],this['_tokenResponse']=_0x2e20a3['_tokenResponse'],this['operationType']=_0x2e20a3['operationType'];}static async['_fromIdTokenResponse'](_0x12258a,_0x38f090,_0x5d6d10,_0x4399b0=!0x1){const _0x55bcff=await j['_fromIdTokenResponse'](_0x12258a,_0x5d6d10,_0x4399b0),_0x240fca=Nr(_0x5d6d10);return new Ge({'user':_0x55bcff,'providerId':_0x240fca,'_tokenResponse':_0x5d6d10,'operationType':_0x38f090});}static async['_forOperation'](_0x1d940f,_0x530246,_0x593378){await _0x1d940f['_updateTokensIfNecessary'](_0x593378,!0x0);const _0x3d6340=Nr(_0x593378);return new Ge({'user':_0x1d940f,'providerId':_0x3d6340,'_tokenResponse':_0x593378,'operationType':_0x530246});}}function Nr(_0xb7911e){return _0xb7911e['providerId']?_0xb7911e['providerId']:'phoneNumber'in _0xb7911e?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x5b4cb9,_0x169a09,_0x1dd8b2,_0x276579){super(_0x169a09['code'],_0x169a09['message']),this['operationType']=_0x1dd8b2,this['user']=_0x276579,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x5b4cb9['name'],'tenantId':_0x5b4cb9['tenantId']??void 0x0,'_serverResponse':_0x169a09['customData']['_serverResponse'],'operationType':_0x1dd8b2};}static['_fromErrorAndOperation'](_0x1c1cc7,_0x5cffaa,_0xbf391a,_0x172323){return new On(_0x1c1cc7,_0x5cffaa,_0xbf391a,_0x172323);}}function Ba(_0x1c37bf,_0x104ef5,_0x2e84ad,_0xa517f1){return(_0x104ef5==='reauthenticate'?_0x2e84ad['_getReauthenticationResolver'](_0x1c37bf):_0x2e84ad['_getIdTokenResponse'](_0x1c37bf))['catch'](_0x24bf1d=>{throw _0x24bf1d['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x1c37bf,_0x24bf1d,_0x104ef5,_0xa517f1):_0x24bf1d;});}async function ep(_0xc0895,_0x50943f,_0x1294d6=!0x1){const _0xee92d5=await Ht(_0xc0895,_0x50943f['_linkToIdToken'](_0xc0895['auth'],await _0xc0895['getIdToken']()),_0x1294d6);return Ge['_forOperation'](_0xc0895,'link',_0xee92d5);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x1f02cc,_0x3d755f,_0x24dc3c=!0x1){const {auth:_0x555b84}=_0x1f02cc;if($(_0x555b84['app']))return Promise['reject'](re(_0x555b84));const _0x31ab9c='reauthenticate';try{const _0x5125ac=await Ht(_0x1f02cc,Ba(_0x555b84,_0x31ab9c,_0x3d755f,_0x1f02cc),_0x24dc3c);m(_0x5125ac['idToken'],_0x555b84,'internal-error');const _0x2ee40e=Ts(_0x5125ac['idToken']);m(_0x2ee40e,_0x555b84,'internal-error');const {sub:_0x39b270}=_0x2ee40e;return m(_0x1f02cc['uid']===_0x39b270,_0x555b84,'user-mismatch'),Ge['_forOperation'](_0x1f02cc,_0x31ab9c,_0x5125ac);}catch(_0x42f0e6){throw(_0x42f0e6==null?void 0x0:_0x42f0e6['code'])==='auth/user-not-found'&&Y(_0x555b84,'user-mismatch'),_0x42f0e6;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x544622,_0x6ac7db,_0x2c05de=!0x1){if($(_0x544622['app']))return Promise['reject'](re(_0x544622));const _0x8144d='signIn',_0x2d1ea1=await Ba(_0x544622,_0x8144d,_0x6ac7db),_0x4820c2=await Ge['_fromIdTokenResponse'](_0x544622,_0x8144d,_0x2d1ea1);return _0x2c05de||await _0x544622['_updateCurrentUser'](_0x4820c2['user']),_0x4820c2;}async function np(_0x548889,_0x3327b3){return Va(Ke(_0x548889),_0x3327b3);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x114d2){const _0x2a93fd=Ke(_0x114d2);_0x2a93fd['_getPasswordPolicyInternal']()&&await _0x2a93fd['_updatePasswordPolicy']();}async function L_(_0x33f441,_0x1dd06f,_0x14cb97){if($(_0x33f441['app']))return Promise['reject'](re(_0x33f441));const _0x1a8590=Ke(_0x33f441),_0x4c50a8=await xi(_0x1a8590,{'returnSecureToken':!0x0,'email':_0x1dd06f,'password':_0x14cb97,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x18aeff=>{throw _0x18aeff['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x33f441),_0x18aeff;}),_0x191d17=await Ge['_fromIdTokenResponse'](_0x1a8590,'signIn',_0x4c50a8);return await _0x1a8590['_updateCurrentUser'](_0x191d17['user']),_0x191d17;}function x_(_0x27c768,_0x18b83b,_0x570a72){return $(_0x27c768['app'])?Promise['reject'](re(_0x27c768)):np(P(_0x27c768),yt['credential'](_0x18b83b,_0x570a72))['catch'](async _0x3dff91=>{throw _0x3dff91['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x27c768),_0x3dff91;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x1c9f68,_0x5e6c82){return P(_0x1c9f68)['setPersistence'](_0x5e6c82);}function ip(_0x9094e1,_0x46465c,_0x532ab2,_0x9c3c8){return P(_0x9094e1)['onIdTokenChanged'](_0x46465c,_0x532ab2,_0x9c3c8);}function sp(_0x2c6e48,_0x435906,_0x35f1af){return P(_0x2c6e48)['beforeAuthStateChanged'](_0x435906,_0x35f1af);}function U_(_0xc0b6d8,_0x1f0ce2,_0x490c48,_0x4836aa){return P(_0xc0b6d8)['onAuthStateChanged'](_0x1f0ce2,_0x490c48,_0x4836aa);}function W_(_0x3db078){return P(_0x3db078)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x2e4eff,_0x15cd48){this['storageRetriever']=_0x2e4eff,this['type']=_0x15cd48;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x5e8daf,_0x1f8664){return this['storage']['setItem'](_0x5e8daf,JSON['stringify'](_0x1f8664)),Promise['resolve']();}['_get'](_0x5977d2){const _0x38bc7e=this['storage']['getItem'](_0x5977d2);return Promise['resolve'](_0x38bc7e?JSON['parse'](_0x38bc7e):null);}['_remove'](_0x46e4f0){return this['storage']['removeItem'](_0x46e4f0),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x5e5048,_0xc19da1)=>this['onStorageEvent'](_0x5e5048,_0xc19da1),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x556fe2){for(const _0x51b1f5 of Object['keys'](this['listeners'])){const _0x5917ef=this['storage']['getItem'](_0x51b1f5),_0x7d201f=this['localCache'][_0x51b1f5];_0x5917ef!==_0x7d201f&&_0x556fe2(_0x51b1f5,_0x7d201f,_0x5917ef);}}['onStorageEvent'](_0x5e9ac9,_0x55f8ee=!0x1){if(!_0x5e9ac9['key']){this['forAllChangedKeys']((_0x19ee1d,_0x427ea1,_0x45efb1)=>{this['notifyListeners'](_0x19ee1d,_0x45efb1);});return;}const _0x3c5629=_0x5e9ac9['key'];_0x55f8ee?this['detachListener']():this['stopPolling']();const _0x16102d=()=>{const _0x55b479=this['storage']['getItem'](_0x3c5629);!_0x55f8ee&&this['localCache'][_0x3c5629]===_0x55b479||this['notifyListeners'](_0x3c5629,_0x55b479);},_0x29c890=this['storage']['getItem'](_0x3c5629);Af()&&_0x29c890!==_0x5e9ac9['newValue']&&_0x5e9ac9['newValue']!==_0x5e9ac9['oldValue']?setTimeout(_0x16102d,op):_0x16102d();}['notifyListeners'](_0x6f9155,_0x27717f){this['localCache'][_0x6f9155]=_0x27717f;const _0x38c43b=this['listeners'][_0x6f9155];if(_0x38c43b){for(const _0xd137ca of Array['from'](_0x38c43b))_0xd137ca(_0x27717f&&JSON['parse'](_0x27717f));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x498780,_0xef6422,_0x5643da)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x498780,'oldValue':_0xef6422,'newValue':_0x5643da}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x4d06f7,_0x4f60a8){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x4d06f7]||(this['listeners'][_0x4d06f7]=new Set(),this['localCache'][_0x4d06f7]=this['storage']['getItem'](_0x4d06f7)),this['listeners'][_0x4d06f7]['add'](_0x4f60a8);}['_removeListener'](_0x4fc330,_0x2f57ca){this['listeners'][_0x4fc330]&&(this['listeners'][_0x4fc330]['delete'](_0x2f57ca),this['listeners'][_0x4fc330]['size']===0x0&&delete this['listeners'][_0x4fc330]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x3f954d,_0x36c8d0){await super['_set'](_0x3f954d,_0x36c8d0),this['localCache'][_0x3f954d]=JSON['stringify'](_0x36c8d0);}async['_get'](_0x3e0819){const _0x260583=await super['_get'](_0x3e0819);return this['localCache'][_0x3e0819]=JSON['stringify'](_0x260583),_0x260583;}async['_remove'](_0x3ad565){await super['_remove'](_0x3ad565),delete this['localCache'][_0x3ad565];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x524199,_0x3c3a1c){}['_removeListener'](_0x2419e1,_0x96ed7a){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x2f074c){return Promise['all'](_0x2f074c['map'](async _0x46240f=>{try{return{'fulfilled':!0x0,'value':await _0x46240f};}catch(_0xfc8503){return{'fulfilled':!0x1,'reason':_0xfc8503};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x53f10f){this['eventTarget']=_0x53f10f,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x514485){const _0x110004=this['receivers']['find'](_0x148aee=>_0x148aee['isListeningto'](_0x514485));if(_0x110004)return _0x110004;const _0x165c14=new Xn(_0x514485);return this['receivers']['push'](_0x165c14),_0x165c14;}['isListeningto'](_0x5446d1){return this['eventTarget']===_0x5446d1;}async['handleEvent'](_0x1c6423){const _0x4afea7=_0x1c6423,{eventId:_0x4bb2bc,eventType:_0x370915,data:_0x324328}=_0x4afea7['data'],_0x16ff5a=this['handlersMap'][_0x370915];if(!(_0x16ff5a!=null&&_0x16ff5a['size']))return;_0x4afea7['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x4bb2bc,'eventType':_0x370915});const _0x5e1831=Array['from'](_0x16ff5a)['map'](async _0x2a8354=>_0x2a8354(_0x4afea7['origin'],_0x324328)),_0x501396=await cp(_0x5e1831);_0x4afea7['ports'][0x0]['postMessage']({'status':'done','eventId':_0x4bb2bc,'eventType':_0x370915,'response':_0x501396});}['_subscribe'](_0x3e96e,_0x8dc923){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x3e96e]||(this['handlersMap'][_0x3e96e]=new Set()),this['handlersMap'][_0x3e96e]['add'](_0x8dc923);}['_unsubscribe'](_0x5829bb,_0x337dfb){this['handlersMap'][_0x5829bb]&&_0x337dfb&&this['handlersMap'][_0x5829bb]['delete'](_0x337dfb),(!_0x337dfb||this['handlersMap'][_0x5829bb]['size']===0x0)&&delete this['handlersMap'][_0x5829bb],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x3d9e7e='',_0x2ef25b=0xa){let _0xe8ce0c='';for(let _0x17f290=0x0;_0x17f290<_0x2ef25b;_0x17f290++)_0xe8ce0c+=Math['floor'](Math['random']()*0xa);return _0x3d9e7e+_0xe8ce0c;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x97c73a){this['target']=_0x97c73a,this['handlers']=new Set();}['removeMessageHandler'](_0x1e3354){_0x1e3354['messageChannel']&&(_0x1e3354['messageChannel']['port1']['removeEventListener']('message',_0x1e3354['onMessage']),_0x1e3354['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x1e3354);}async['_send'](_0x8b4f88,_0x5ee3b7,_0x58d8b3=0x32){const _0x244373=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x244373)throw new Error('connection_unavailable');let _0x3a60a1,_0xb65618;return new Promise((_0x287ce2,_0x649d6a)=>{const _0x38c67f=As('',0x14);_0x244373['port1']['start']();const _0x14d22c=setTimeout(()=>{_0x649d6a(new Error('unsupported_event'));},_0x58d8b3);_0xb65618={'messageChannel':_0x244373,'onMessage'(_0x2e5704){const _0x4063f0=_0x2e5704;if(_0x4063f0['data']['eventId']===_0x38c67f)switch(_0x4063f0['data']['status']){case'ack':clearTimeout(_0x14d22c),_0x3a60a1=setTimeout(()=>{_0x649d6a(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x3a60a1),_0x287ce2(_0x4063f0['data']['response']);break;default:clearTimeout(_0x14d22c),clearTimeout(_0x3a60a1),_0x649d6a(new Error('invalid_response'));break;}}},this['handlers']['add'](_0xb65618),_0x244373['port1']['addEventListener']('message',_0xb65618['onMessage']),this['target']['postMessage']({'eventType':_0x8b4f88,'eventId':_0x38c67f,'data':_0x5ee3b7},[_0x244373['port2']]);})['finally'](()=>{_0xb65618&&this['removeMessageHandler'](_0xb65618);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x2c1e4f){Z()['location']['href']=_0x2c1e4f;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x5f33de;return((_0x5f33de=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x5f33de['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x1b75ea){this['request']=_0x1b75ea;}['toPromise'](){return new Promise((_0x1abda5,_0x41cd87)=>{this['request']['addEventListener']('success',()=>{_0x1abda5(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x41cd87(this['request']['error']);});});}}function Zn(_0x2b5fa6,_0x18a3e9){return _0x2b5fa6['transaction']([Mn],_0x18a3e9?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x3238a9=indexedDB['deleteDatabase'](Ka);return new nn(_0x3238a9)['toPromise']();}function Qa(){const _0x4ad531=indexedDB['open'](Ka,pp);return new Promise((_0x19e300,_0x2f545c)=>{_0x4ad531['addEventListener']('error',()=>{_0x2f545c(_0x4ad531['error']);}),_0x4ad531['addEventListener']('upgradeneeded',()=>{const _0x541d69=_0x4ad531['result'];try{_0x541d69['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x2fa50d){_0x2f545c(_0x2fa50d);}}),_0x4ad531['addEventListener']('success',async()=>{const _0x31c410=_0x4ad531['result'];_0x31c410['objectStoreNames']['contains'](Mn)?_0x19e300(_0x31c410):(_0x31c410['close'](),await _p(),_0x19e300(await Qa()));});});}async function Or(_0x4dc5d0,_0x21acd8,_0x56ec92){const _0x129bb2=Zn(_0x4dc5d0,!0x0)['put']({[Ya]:_0x21acd8,'value':_0x56ec92});return new nn(_0x129bb2)['toPromise']();}async function gp(_0x1068ea,_0x19715d){const _0x87e211=Zn(_0x1068ea,!0x1)['get'](_0x19715d),_0x12e409=await new nn(_0x87e211)['toPromise']();return _0x12e409===void 0x0?null:_0x12e409['value'];}function Dr(_0x3a4a28,_0x5ea0f6){const _0x592a89=Zn(_0x3a4a28,!0x0)['delete'](_0x5ea0f6);return new nn(_0x592a89)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x44386a){let _0x20b285=0x0;for(;;)try{const _0x30b613=await this['_openDb']();return await _0x44386a(_0x30b613);}catch(_0xa49974){if(_0x20b285++>yp)throw _0xa49974;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x6792ec,_0x5187fb)=>({'keyProcessed':(await this['_poll']())['includes'](_0x5187fb['key'])})),this['receiver']['_subscribe']('ping',async(_0x542d0d,_0x356de8)=>['keyChanged']);}async['initializeSender'](){var _0x4b98ca,_0x4f9ba1;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x483723=await this['sender']['_send']('ping',{},0x320);_0x483723&&(_0x4b98ca=_0x483723[0x0])!=null&&_0x4b98ca['fulfilled']&&(_0x4f9ba1=_0x483723[0x0])!=null&&_0x4f9ba1['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x4b0983){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x4b0983},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x28e658=>{await Or(_0x28e658,Dn,'1'),await Dr(_0x28e658,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x421101){this['pendingWrites']++;try{await _0x421101();}finally{this['pendingWrites']--;}}async['_set'](_0x3ce1df,_0x2ce6c5){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x3e15e3=>Or(_0x3e15e3,_0x3ce1df,_0x2ce6c5)),this['localCache'][_0x3ce1df]=_0x2ce6c5,this['notifyServiceWorker'](_0x3ce1df)));}async['_get'](_0x418e0c){const _0x5b578f=await this['_withRetries'](_0x53f8c6=>gp(_0x53f8c6,_0x418e0c));return this['localCache'][_0x418e0c]=_0x5b578f,_0x5b578f;}async['_remove'](_0x153328){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x5a09f1=>Dr(_0x5a09f1,_0x153328)),delete this['localCache'][_0x153328],this['notifyServiceWorker'](_0x153328)));}async['_poll'](){const _0x19337a=await this['_withRetries'](_0x19c42e=>{const _0x21cc56=Zn(_0x19c42e,!0x1)['getAll']();return new nn(_0x21cc56)['toPromise']();});if(!_0x19337a)return[];if(this['pendingWrites']!==0x0)return[];const _0x1d134c=[],_0x36ea91=new Set();if(_0x19337a['length']!==0x0){for(const {fbase_key:_0x2892f8,value:_0xf1fe4}of _0x19337a)_0x36ea91['add'](_0x2892f8),JSON['stringify'](this['localCache'][_0x2892f8])!==JSON['stringify'](_0xf1fe4)&&(this['notifyListeners'](_0x2892f8,_0xf1fe4),_0x1d134c['push'](_0x2892f8));}for(const _0xb09090 of Object['keys'](this['localCache']))this['localCache'][_0xb09090]&&!_0x36ea91['has'](_0xb09090)&&(this['notifyListeners'](_0xb09090,null),_0x1d134c['push'](_0xb09090));return _0x1d134c;}['notifyListeners'](_0x75dd55,_0x5c012b){this['localCache'][_0x75dd55]=_0x5c012b;const _0x3edb00=this['listeners'][_0x75dd55];if(_0x3edb00){for(const _0x132ba7 of Array['from'](_0x3edb00))_0x132ba7(_0x5c012b);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x1ac5a2,_0xe47c59){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x1ac5a2]||(this['listeners'][_0x1ac5a2]=new Set(),this['_get'](_0x1ac5a2)),this['listeners'][_0x1ac5a2]['add'](_0xe47c59);}['_removeListener'](_0x257924,_0x2b3bbb){this['listeners'][_0x257924]&&(this['listeners'][_0x257924]['delete'](_0x2b3bbb),this['listeners'][_0x257924]['size']===0x0&&delete this['listeners'][_0x257924]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x3ed29f,_0x227740){return _0x227740?ie(_0x227740):(m(_0x3ed29f['_popupRedirectResolver'],_0x3ed29f,'argument-error'),_0x3ed29f['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x338b82){super('custom','custom'),this['params']=_0x338b82;}['_getIdTokenResponse'](_0x4c6f6e){return nt(_0x4c6f6e,this['_buildIdpRequest']());}['_linkToIdToken'](_0x4487d7,_0x2eb333){return nt(_0x4487d7,this['_buildIdpRequest'](_0x2eb333));}['_getReauthenticationResolver'](_0x51d253){return nt(_0x51d253,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x2ba13f){const _0x59c4d5={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x2ba13f&&(_0x59c4d5['idToken']=_0x2ba13f),_0x59c4d5;}}function Ip(_0x2c6e46){return Va(_0x2c6e46['auth'],new ks(_0x2c6e46),_0x2c6e46['bypassAuthState']);}function wp(_0x2421ea){const {auth:_0x4369b6,user:_0x2aabb2}=_0x2421ea;return m(_0x2aabb2,_0x4369b6,'internal-error'),tp(_0x2aabb2,new ks(_0x2421ea),_0x2421ea['bypassAuthState']);}async function Cp(_0x58266b){const {auth:_0x377e98,user:_0x269a0d}=_0x58266b;return m(_0x269a0d,_0x377e98,'internal-error'),ep(_0x269a0d,new ks(_0x58266b),_0x58266b['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x234523,_0x51bc37,_0x5156bf,_0x50c4b5,_0x110c74=!0x1){this['auth']=_0x234523,this['resolver']=_0x5156bf,this['user']=_0x50c4b5,this['bypassAuthState']=_0x110c74,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x51bc37)?_0x51bc37:[_0x51bc37];}['execute'](){return new Promise(async(_0x35288d,_0x174daf)=>{this['pendingPromise']={'resolve':_0x35288d,'reject':_0x174daf};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x33094b){this['reject'](_0x33094b);}});}async['onAuthEvent'](_0xed1e6b){const {urlResponse:_0x31baaa,sessionId:_0x3f8d1c,postBody:_0xfeb933,tenantId:_0x20ec3e,error:_0x203d76,type:_0x361611}=_0xed1e6b;if(_0x203d76){this['reject'](_0x203d76);return;}const _0x5f118a={'auth':this['auth'],'requestUri':_0x31baaa,'sessionId':_0x3f8d1c,'tenantId':_0x20ec3e||void 0x0,'postBody':_0xfeb933||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x361611)(_0x5f118a));}catch(_0x45ab53){this['reject'](_0x45ab53);}}['onError'](_0x5f3982){this['reject'](_0x5f3982);}['getIdpTask'](_0xdd70b5){switch(_0xdd70b5){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x1c563f){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x1c563f),this['unregisterAndCleanUp']();}['reject'](_0x3ddba7){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x3ddba7),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x5c5c29,_0x88f458,_0x4638aa,_0x5368a4,_0x2648e9){super(_0x5c5c29,_0x88f458,_0x5368a4,_0x2648e9),this['provider']=_0x4638aa,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x1e89f4=await this['execute']();return m(_0x1e89f4,this['auth'],'internal-error'),_0x1e89f4;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x525fbe=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x525fbe),this['authWindow']['associatedEvent']=_0x525fbe,this['resolver']['_originValidation'](this['auth'])['catch'](_0x1e2eae=>{this['reject'](_0x1e2eae);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x3e3f6d=>{_0x3e3f6d||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0xc4b627;return((_0xc4b627=this['authWindow'])==null?void 0x0:_0xc4b627['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x236166=()=>{var _0x5948eb,_0x3ac83d;if((_0x3ac83d=(_0x5948eb=this['authWindow'])==null?void 0x0:_0x5948eb['window'])!=null&&_0x3ac83d['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x236166,Tp['get']());};_0x236166();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x30aca9,_0x5ee359,_0x47a941=!0x1){super(_0x30aca9,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x5ee359,void 0x0,_0x47a941),this['eventId']=null;}async['execute'](){let _0x45ad51=hn['get'](this['auth']['_key']());if(!_0x45ad51){try{const _0x4c361=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x45ad51=()=>Promise['resolve'](_0x4c361);}catch(_0x265e4e){_0x45ad51=()=>Promise['reject'](_0x265e4e);}hn['set'](this['auth']['_key'](),_0x45ad51);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x45ad51();}async['onAuthEvent'](_0x220b16){if(_0x220b16['type']==='signInViaRedirect')return super['onAuthEvent'](_0x220b16);if(_0x220b16['type']==='unknown'){this['resolve'](null);return;}if(_0x220b16['eventId']){const _0x384a90=await this['auth']['_redirectUserForId'](_0x220b16['eventId']);if(_0x384a90)return this['user']=_0x384a90,super['onAuthEvent'](_0x220b16);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x5da308,_0x2f291f){const _0x4cf568=Pp(_0x2f291f),_0x13949f=kp(_0x5da308);if(!await _0x13949f['_isAvailable']())return!0x1;const _0x643ad9=await _0x13949f['_get'](_0x4cf568)==='true';return await _0x13949f['_remove'](_0x4cf568),_0x643ad9;}function Ap(_0x1e7219,_0x33fd2b){hn['set'](_0x1e7219['_key'](),_0x33fd2b);}function kp(_0x23b122){return ie(_0x23b122['_redirectPersistence']);}function Pp(_0x163faa){return ln(Sp,_0x163faa['config']['apiKey'],_0x163faa['name']);}async function Np(_0x537688,_0x57f730,_0x5e350a=!0x1){if($(_0x537688['app']))return Promise['reject'](re(_0x537688));const _0x19b10e=Ke(_0x537688),_0x16181b=Ep(_0x19b10e,_0x57f730),_0x2eb55b=await new bp(_0x19b10e,_0x16181b,_0x5e350a)['execute']();return _0x2eb55b&&!_0x5e350a&&(delete _0x2eb55b['user']['_redirectEventId'],await _0x19b10e['_persistUserIfCurrent'](_0x2eb55b['user']),await _0x19b10e['_setRedirectUser'](null,_0x57f730)),_0x2eb55b;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x279475){this['auth']=_0x279475,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x455bce){this['consumers']['add'](_0x455bce),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x455bce)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x455bce),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x5d416f){this['consumers']['delete'](_0x5d416f);}['onEvent'](_0x259c13){if(this['hasEventBeenHandled'](_0x259c13))return!0x1;let _0x1ea7be=!0x1;return this['consumers']['forEach'](_0x11b261=>{this['isEventForConsumer'](_0x259c13,_0x11b261)&&(_0x1ea7be=!0x0,this['sendToConsumer'](_0x259c13,_0x11b261),this['saveEventToCache'](_0x259c13));}),this['hasHandledPotentialRedirect']||!Mp(_0x259c13)||(this['hasHandledPotentialRedirect']=!0x0,_0x1ea7be||(this['queuedRedirectEvent']=_0x259c13,_0x1ea7be=!0x0)),_0x1ea7be;}['sendToConsumer'](_0x1e975b,_0x17150a){var _0xc240c1;if(_0x1e975b['error']&&!Za(_0x1e975b)){const _0x2d9c95=((_0xc240c1=_0x1e975b['error']['code'])==null?void 0x0:_0xc240c1['split']('auth/')[0x1])||'internal-error';_0x17150a['onError'](X(this['auth'],_0x2d9c95));}else _0x17150a['onAuthEvent'](_0x1e975b);}['isEventForConsumer'](_0xf5a189,_0x4cbfdf){const _0x386f9f=_0x4cbfdf['eventId']===null||!!_0xf5a189['eventId']&&_0xf5a189['eventId']===_0x4cbfdf['eventId'];return _0x4cbfdf['filter']['includes'](_0xf5a189['type'])&&_0x386f9f;}['hasEventBeenHandled'](_0x2b9bbc){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x2b9bbc));}['saveEventToCache'](_0x56863e){this['cachedEventUids']['add'](Mr(_0x56863e)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x409d56){return[_0x409d56['type'],_0x409d56['eventId'],_0x409d56['sessionId'],_0x409d56['tenantId']]['filter'](_0x513a8a=>_0x513a8a)['join']('-');}function Za({type:_0x2c85a0,error:_0x273a05}){return _0x2c85a0==='unknown'&&(_0x273a05==null?void 0x0:_0x273a05['code'])==='auth/no-auth-event';}function Mp(_0x1c60cc){switch(_0x1c60cc['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x1c60cc);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x8589dd,_0x397430={}){return Pe(_0x8589dd,'GET','/v1/projects',_0x397430);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x5bc9ca){if(_0x5bc9ca['config']['emulator'])return;const {authorizedDomains:_0x14f240}=await Lp(_0x5bc9ca);for(const _0x522f8d of _0x14f240)try{if(Wp(_0x522f8d))return;}catch{}Y(_0x5bc9ca,'unauthorized-domain');}function Wp(_0x2cf93b){const _0x1cf59c=Mi(),{protocol:_0x2f743f,hostname:_0x4887bc}=new URL(_0x1cf59c);if(_0x2cf93b['startsWith']('chrome-extension://')){const _0x5e552d=new URL(_0x2cf93b);return _0x5e552d['hostname']===''&&_0x4887bc===''?_0x2f743f==='chrome-extension:'&&_0x2cf93b['replace']('chrome-extension://','')===_0x1cf59c['replace']('chrome-extension://',''):_0x2f743f==='chrome-extension:'&&_0x5e552d['hostname']===_0x4887bc;}if(!Fp['test'](_0x2f743f))return!0x1;if(xp['test'](_0x2cf93b))return _0x4887bc===_0x2cf93b;const _0x1dded2=_0x2cf93b['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x1dded2+'|'+_0x1dded2+')$','i')['test'](_0x4887bc);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x586775=Z()['___jsl'];if(_0x586775!=null&&_0x586775['H']){for(const _0x17d92f of Object['keys'](_0x586775['H']))if(_0x586775['H'][_0x17d92f]['r']=_0x586775['H'][_0x17d92f]['r']||[],_0x586775['H'][_0x17d92f]['L']=_0x586775['H'][_0x17d92f]['L']||[],_0x586775['H'][_0x17d92f]['r']=[..._0x586775['H'][_0x17d92f]['L']],_0x586775['CP']){for(let _0x2ee287=0x0;_0x2ee287<_0x586775['CP']['length'];_0x2ee287++)_0x586775['CP'][_0x2ee287]=null;}}}function Vp(_0x5d4ee9){return new Promise((_0x399d4a,_0x4212ee)=>{var _0x3f9991,_0xbab977,_0x1e8c2d;function _0x1f7207(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x399d4a(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x4212ee(X(_0x5d4ee9,'network-request-failed'));},'timeout':Bp['get']()});}if((_0xbab977=(_0x3f9991=Z()['gapi'])==null?void 0x0:_0x3f9991['iframes'])!=null&&_0xbab977['Iframe'])_0x399d4a(gapi['iframes']['getContext']());else{if((_0x1e8c2d=Z()['gapi'])!=null&&_0x1e8c2d['load'])_0x1f7207();else{const _0x2fed26=Ff('iframefcb');return Z()[_0x2fed26]=()=>{gapi['load']?_0x1f7207():_0x4212ee(X(_0x5d4ee9,'network-request-failed'));},xa(xf()+'?onload='+_0x2fed26)['catch'](_0x9461d3=>_0x4212ee(_0x9461d3));}}})['catch'](_0x189eff=>{throw un=null,_0x189eff;});}let un=null;function Hp(_0x1dfade){return un=un||Vp(_0x1dfade),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x51696b){const _0x290ac3=_0x51696b['config'];m(_0x290ac3['authDomain'],_0x51696b,'auth-domain-config-required');const _0xac6488=_0x290ac3['emulator']?Cs(_0x290ac3,qp):'https://'+_0x51696b['config']['authDomain']+'/'+Gp,_0x4b2aaa={'apiKey':_0x290ac3['apiKey'],'appName':_0x51696b['name'],'v':dt},_0x4cebcd=jp['get'](_0x51696b['config']['apiHost']);_0x4cebcd&&(_0x4b2aaa['eid']=_0x4cebcd);const _0x530650=_0x51696b['_getFrameworks']();return _0x530650['length']&&(_0x4b2aaa['fw']=_0x530650['join'](',')),_0xac6488+'?'+ut(_0x4b2aaa)['slice'](0x1);}async function Yp(_0x37db95){const _0x8736ef=await Hp(_0x37db95),_0x32aead=Z()['gapi'];return m(_0x32aead,_0x37db95,'internal-error'),_0x8736ef['open']({'where':document['body'],'url':Kp(_0x37db95),'messageHandlersFilter':_0x32aead['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x2c780d=>new Promise(async(_0x5d6025,_0x120373)=>{await _0x2c780d['restyle']({'setHideOnLeave':!0x1});const _0xa408cc=X(_0x37db95,'network-request-failed'),_0x3d09bb=Z()['setTimeout'](()=>{_0x120373(_0xa408cc);},$p['get']());function _0x45f318(){Z()['clearTimeout'](_0x3d09bb),_0x5d6025(_0x2c780d);}_0x2c780d['ping'](_0x45f318)['then'](_0x45f318,()=>{_0x120373(_0xa408cc);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x35cb3d){this['window']=_0x35cb3d,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x507593,_0x323657,_0x1faebc,_0x322483=Jp,_0x5e52b0=Xp){const _0xf7f0bc=Math['max']((window['screen']['availHeight']-_0x5e52b0)/0x2,0x0)['toString'](),_0x4d4f57=Math['max']((window['screen']['availWidth']-_0x322483)/0x2,0x0)['toString']();let _0x3b0f4a='';const _0x43f8cf={...Qp,'width':_0x322483['toString'](),'height':_0x5e52b0['toString'](),'top':_0xf7f0bc,'left':_0x4d4f57},_0x42e931=W()['toLowerCase']();_0x1faebc&&(_0x3b0f4a=ka(_0x42e931)?Zp:_0x1faebc),Ra(_0x42e931)&&(_0x323657=_0x323657||e_,_0x43f8cf['scrollbars']='yes');const _0x1607b1=Object['entries'](_0x43f8cf)['reduce']((_0x34c3fc,[_0x1755ce,_0x31e399])=>''+_0x34c3fc+_0x1755ce+'='+_0x31e399+',','');if(Rf(_0x42e931)&&_0x3b0f4a!=='_self')return n_(_0x323657||'',_0x3b0f4a),new xr(null);const _0x263fe4=window['open'](_0x323657||'',_0x3b0f4a,_0x1607b1);m(_0x263fe4,_0x507593,'popup-blocked');try{_0x263fe4['focus']();}catch{}return new xr(_0x263fe4);}function n_(_0x150b12,_0x3871d6){const _0x351aa8=document['createElement']('a');_0x351aa8['href']=_0x150b12,_0x351aa8['target']=_0x3871d6;const _0x3f55b9=document['createEvent']('MouseEvent');_0x3f55b9['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x351aa8['dispatchEvent'](_0x3f55b9);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x1d9876,_0x292a7a,_0x4984c6,_0x42d96a,_0x29d287,_0x109c33){m(_0x1d9876['config']['authDomain'],_0x1d9876,'auth-domain-config-required'),m(_0x1d9876['config']['apiKey'],_0x1d9876,'invalid-api-key');const _0x4d712d={'apiKey':_0x1d9876['config']['apiKey'],'appName':_0x1d9876['name'],'authType':_0x4984c6,'redirectUrl':_0x42d96a,'v':dt,'eventId':_0x29d287};if(_0x292a7a instanceof Wa){_0x292a7a['setDefaultLanguage'](_0x1d9876['languageCode']),_0x4d712d['providerId']=_0x292a7a['providerId']||'',pn(_0x292a7a['getCustomParameters']())||(_0x4d712d['customParameters']=JSON['stringify'](_0x292a7a['getCustomParameters']()));for(const [_0x176218,_0x1afff1]of Object['entries']({}))_0x4d712d[_0x176218]=_0x1afff1;}if(_0x292a7a instanceof tn){const _0x41e72b=_0x292a7a['getScopes']()['filter'](_0x1d122f=>_0x1d122f!=='');_0x41e72b['length']>0x0&&(_0x4d712d['scopes']=_0x41e72b['join'](','));}_0x1d9876['tenantId']&&(_0x4d712d['tid']=_0x1d9876['tenantId']);const _0x31369d=_0x4d712d;for(const _0x15ee1c of Object['keys'](_0x31369d))_0x31369d[_0x15ee1c]===void 0x0&&delete _0x31369d[_0x15ee1c];const _0x10b62d=await _0x1d9876['_getAppCheckToken'](),_0x3ebd49=_0x10b62d?'#'+r_+'='+encodeURIComponent(_0x10b62d):'';return o_(_0x1d9876)+'?'+ut(_0x31369d)['slice'](0x1)+_0x3ebd49;}function o_({config:_0x598854}){return _0x598854['emulator']?Cs(_0x598854,s_):'https://'+_0x598854['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x3173f8,_0x5aed47,_0x39ac1f,_0x46d440){var _0x1bb7e2;ce((_0x1bb7e2=this['eventManagers'][_0x3173f8['_key']()])==null?void 0x0:_0x1bb7e2['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x2e32a7=await Fr(_0x3173f8,_0x5aed47,_0x39ac1f,Mi(),_0x46d440);return t_(_0x3173f8,_0x2e32a7,As());}async['_openRedirect'](_0x2bf2f3,_0x4ecc6f,_0x51400b,_0x40e556){await this['_originValidation'](_0x2bf2f3);const _0x5caec0=await Fr(_0x2bf2f3,_0x4ecc6f,_0x51400b,Mi(),_0x40e556);return hp(_0x5caec0),new Promise(()=>{});}['_initialize'](_0x1a6b5e){const _0x1e9bb1=_0x1a6b5e['_key']();if(this['eventManagers'][_0x1e9bb1]){const {manager:_0xc782a8,promise:_0x1d6502}=this['eventManagers'][_0x1e9bb1];return _0xc782a8?Promise['resolve'](_0xc782a8):(ce(_0x1d6502,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x1d6502);}const _0x36bb07=this['initAndGetManager'](_0x1a6b5e);return this['eventManagers'][_0x1e9bb1]={'promise':_0x36bb07},_0x36bb07['catch'](()=>{delete this['eventManagers'][_0x1e9bb1];}),_0x36bb07;}async['initAndGetManager'](_0x34efb1){const _0x3d7d62=await Yp(_0x34efb1),_0x2801e8=new Dp(_0x34efb1);return _0x3d7d62['register']('authEvent',_0x31e615=>(m(_0x31e615==null?void 0x0:_0x31e615['authEvent'],_0x34efb1,'invalid-auth-event'),{'status':_0x2801e8['onEvent'](_0x31e615['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x34efb1['_key']()]={'manager':_0x2801e8},this['iframes'][_0x34efb1['_key']()]=_0x3d7d62,_0x2801e8;}['_isIframeWebStorageSupported'](_0x20c635,_0x39f394){this['iframes'][_0x20c635['_key']()]['send'](pi,{'type':pi},_0x2c8b7f=>{var _0x1b30d1;const _0x581b3e=(_0x1b30d1=_0x2c8b7f==null?void 0x0:_0x2c8b7f[0x0])==null?void 0x0:_0x1b30d1[pi];_0x581b3e!==void 0x0&&_0x39f394(!!_0x581b3e),Y(_0x20c635,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x528bc9){const _0x237290=_0x528bc9['_key']();return this['originValidationPromises'][_0x237290]||(this['originValidationPromises'][_0x237290]=Up(_0x528bc9)),this['originValidationPromises'][_0x237290];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x2c10d2){this['auth']=_0x2c10d2,this['internalListeners']=new Map();}['getUid'](){var _0x58ad4b;return this['assertAuthConfigured'](),((_0x58ad4b=this['auth']['currentUser'])==null?void 0x0:_0x58ad4b['uid'])||null;}async['getToken'](_0x2f3c30){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x2f3c30)}:null;}['addAuthTokenListener'](_0x2f56cb){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x2f56cb))return;const _0x37488e=this['auth']['onIdTokenChanged'](_0x9088c4=>{_0x2f56cb((_0x9088c4==null?void 0x0:_0x9088c4['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x2f56cb,_0x37488e),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x4afd54){this['assertAuthConfigured']();const _0x5efeed=this['internalListeners']['get'](_0x4afd54);_0x5efeed&&(this['internalListeners']['delete'](_0x4afd54),_0x5efeed(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x5d2f83){switch(_0x5d2f83){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x10bbe5){st(new Fe('auth',(_0x563890,{options:_0x46f9c9})=>{const _0xcbf455=_0x563890['getProvider']('app')['getImmediate'](),_0x12c23e=_0x563890['getProvider']('heartbeat'),_0x3b65fa=_0x563890['getProvider']('app-check-internal'),{apiKey:_0x4c6bba,authDomain:_0x39ece0}=_0xcbf455['options'];m(_0x4c6bba&&!_0x4c6bba['includes'](':'),'invalid-api-key',{'appName':_0xcbf455['name']});const _0xf192ec={'apiKey':_0x4c6bba,'authDomain':_0x39ece0,'clientPlatform':_0x10bbe5,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x10bbe5)},_0x57b064=new Df(_0xcbf455,_0x12c23e,_0x3b65fa,_0xf192ec);return Hf(_0x57b064,_0x46f9c9),_0x57b064;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x393eb4,_0x57ec42,_0x16789c)=>{_0x393eb4['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x4c0da7=>{const _0x31e1ef=Ke(_0x4c0da7['getProvider']('auth')['getImmediate']());return(_0x547e45=>new l_(_0x547e45))(_0x31e1ef);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x10bbe5)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x152cbb=>async _0x313c12=>{const _0x35addb=_0x313c12&&await _0x313c12['getIdTokenResult'](),_0x90a80e=_0x35addb&&(new Date()['getTime']()-Date['parse'](_0x35addb['issuedAtTime']))/0x3e8;if(_0x90a80e&&_0x90a80e>f_)return;const _0x4bca3e=_0x35addb==null?void 0x0:_0x35addb['token'];Br!==_0x4bca3e&&(Br=_0x4bca3e,await fetch(_0x152cbb,{'method':_0x4bca3e?'POST':'DELETE','headers':_0x4bca3e?{'Authorization':'Bearer\x20'+_0x4bca3e}:{}}));};function B_(_0x5080e1=Zr()){const _0x42f93a=Hi(_0x5080e1,'auth');if(_0x42f93a['isInitialized']())return _0x42f93a['getImmediate']();const _0x193941=Vf(_0x5080e1,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0xf8e033=jr('authTokenSyncURL');if(_0xf8e033&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x1f8e93=new URL(_0xf8e033,location['origin']);if(location['origin']===_0x1f8e93['origin']){const _0xbbda13=p_(_0x1f8e93['toString']());sp(_0x193941,_0xbbda13,()=>_0xbbda13(_0x193941['currentUser'])),ip(_0x193941,_0x39babc=>_0xbbda13(_0x39babc));}}const _0x113cbb=qr('auth');return _0x113cbb&&$f(_0x193941,'http://'+_0x113cbb),_0x193941;}function __(){var _0x2cbb90;return((_0x2cbb90=document['getElementsByTagName']('head'))==null?void 0x0:_0x2cbb90[0x0])??document;}Mf({'loadJS'(_0x1660f1){return new Promise((_0x41db6f,_0x4eac07)=>{const _0x234eff=document['createElement']('script');_0x234eff['setAttribute']('src',_0x1660f1),_0x234eff['onload']=_0x41db6f,_0x234eff['onerror']=_0x4da702=>{const _0xc0fe9f=X('internal-error');_0xc0fe9f['customData']=_0x4da702,_0x4eac07(_0xc0fe9f);},_0x234eff['type']='text/javascript',_0x234eff['charset']='UTF-8',__()['appendChild'](_0x234eff);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{Gd as A,Vt as B,N_ as C,U_ as D,O_ as E,M_ as a,C_ as b,B_ as c,L_ as d,A_ as e,W_ as f,w_ as g,m_ as h,Sl as i,Hd as j,R_ as k,S_ as l,g_ as m,P_ as n,b_ as o,E_ as p,k_ as q,y_ as r,T_ as s,F_ as t,I_ as u,ap as v,Zr as w,x_ as x,v_ as y,D_ as z};