const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x5e40f8,_0x48837c){if(!_0x5e40f8)throw ht(_0x48837c);},ht=function(_0x4e4f9c){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x4e4f9c);},Hr=function(_0x21b7f7){const _0x479710=[];let _0x3764d0=0x0;for(let _0xe19af0=0x0;_0xe19af0<_0x21b7f7['length'];_0xe19af0++){let _0x31186e=_0x21b7f7['charCodeAt'](_0xe19af0);_0x31186e<0x80?_0x479710[_0x3764d0++]=_0x31186e:_0x31186e<0x800?(_0x479710[_0x3764d0++]=_0x31186e>>0x6|0xc0,_0x479710[_0x3764d0++]=_0x31186e&0x3f|0x80):(_0x31186e&0xfc00)===0xd800&&_0xe19af0+0x1<_0x21b7f7['length']&&(_0x21b7f7['charCodeAt'](_0xe19af0+0x1)&0xfc00)===0xdc00?(_0x31186e=0x10000+((_0x31186e&0x3ff)<<0xa)+(_0x21b7f7['charCodeAt'](++_0xe19af0)&0x3ff),_0x479710[_0x3764d0++]=_0x31186e>>0x12|0xf0,_0x479710[_0x3764d0++]=_0x31186e>>0xc&0x3f|0x80,_0x479710[_0x3764d0++]=_0x31186e>>0x6&0x3f|0x80,_0x479710[_0x3764d0++]=_0x31186e&0x3f|0x80):(_0x479710[_0x3764d0++]=_0x31186e>>0xc|0xe0,_0x479710[_0x3764d0++]=_0x31186e>>0x6&0x3f|0x80,_0x479710[_0x3764d0++]=_0x31186e&0x3f|0x80);}return _0x479710;},nc=function(_0x5bdfe2){const _0x1bef60=[];let _0x580eaa=0x0,_0x257171=0x0;for(;_0x580eaa<_0x5bdfe2['length'];){const _0x534f3a=_0x5bdfe2[_0x580eaa++];if(_0x534f3a<0x80)_0x1bef60[_0x257171++]=String['fromCharCode'](_0x534f3a);else{if(_0x534f3a>0xbf&&_0x534f3a<0xe0){const _0x2cbf19=_0x5bdfe2[_0x580eaa++];_0x1bef60[_0x257171++]=String['fromCharCode']((_0x534f3a&0x1f)<<0x6|_0x2cbf19&0x3f);}else{if(_0x534f3a>0xef&&_0x534f3a<0x16d){const _0xeb922e=_0x5bdfe2[_0x580eaa++],_0x3d8fb6=_0x5bdfe2[_0x580eaa++],_0x2cb602=_0x5bdfe2[_0x580eaa++],_0x5176d3=((_0x534f3a&0x7)<<0x12|(_0xeb922e&0x3f)<<0xc|(_0x3d8fb6&0x3f)<<0x6|_0x2cb602&0x3f)-0x10000;_0x1bef60[_0x257171++]=String['fromCharCode'](0xd800+(_0x5176d3>>0xa)),_0x1bef60[_0x257171++]=String['fromCharCode'](0xdc00+(_0x5176d3&0x3ff));}else{const _0xe88575=_0x5bdfe2[_0x580eaa++],_0x52d57a=_0x5bdfe2[_0x580eaa++];_0x1bef60[_0x257171++]=String['fromCharCode']((_0x534f3a&0xf)<<0xc|(_0xe88575&0x3f)<<0x6|_0x52d57a&0x3f);}}}}return _0x1bef60['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x28efcd,_0x26106f){if(!Array['isArray'](_0x28efcd))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x3a2507=_0x26106f?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x23d194=[];for(let _0x17175d=0x0;_0x17175d<_0x28efcd['length'];_0x17175d+=0x3){const _0x520178=_0x28efcd[_0x17175d],_0x4780ff=_0x17175d+0x1<_0x28efcd['length'],_0x34a21c=_0x4780ff?_0x28efcd[_0x17175d+0x1]:0x0,_0x1999fe=_0x17175d+0x2<_0x28efcd['length'],_0x11ece1=_0x1999fe?_0x28efcd[_0x17175d+0x2]:0x0,_0x26b320=_0x520178>>0x2,_0x158094=(_0x520178&0x3)<<0x4|_0x34a21c>>0x4;let _0x417733=(_0x34a21c&0xf)<<0x2|_0x11ece1>>0x6,_0x4f00a2=_0x11ece1&0x3f;_0x1999fe||(_0x4f00a2=0x40,_0x4780ff||(_0x417733=0x40)),_0x23d194['push'](_0x3a2507[_0x26b320],_0x3a2507[_0x158094],_0x3a2507[_0x417733],_0x3a2507[_0x4f00a2]);}return _0x23d194['join']('');},'encodeString'(_0x45d338,_0x50a1d4){return this['HAS_NATIVE_SUPPORT']&&!_0x50a1d4?btoa(_0x45d338):this['encodeByteArray'](Hr(_0x45d338),_0x50a1d4);},'decodeString'(_0x3422de,_0x1bf7ec){return this['HAS_NATIVE_SUPPORT']&&!_0x1bf7ec?atob(_0x3422de):nc(this['decodeStringToByteArray'](_0x3422de,_0x1bf7ec));},'decodeStringToByteArray'(_0x39f69e,_0x4f8c4c){this['init_']();const _0x45f0d3=_0x4f8c4c?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x3ed0fd=[];for(let _0xf6dff0=0x0;_0xf6dff0<_0x39f69e['length'];){const _0x5bd4d1=_0x45f0d3[_0x39f69e['charAt'](_0xf6dff0++)],_0x5bbcce=_0xf6dff0<_0x39f69e['length']?_0x45f0d3[_0x39f69e['charAt'](_0xf6dff0)]:0x0;++_0xf6dff0;const _0x1675fc=_0xf6dff0<_0x39f69e['length']?_0x45f0d3[_0x39f69e['charAt'](_0xf6dff0)]:0x40;++_0xf6dff0;const _0x22736b=_0xf6dff0<_0x39f69e['length']?_0x45f0d3[_0x39f69e['charAt'](_0xf6dff0)]:0x40;if(++_0xf6dff0,_0x5bd4d1==null||_0x5bbcce==null||_0x1675fc==null||_0x22736b==null)throw new ic();const _0x326153=_0x5bd4d1<<0x2|_0x5bbcce>>0x4;if(_0x3ed0fd['push'](_0x326153),_0x1675fc!==0x40){const _0x1ca042=_0x5bbcce<<0x4&0xf0|_0x1675fc>>0x2;if(_0x3ed0fd['push'](_0x1ca042),_0x22736b!==0x40){const _0x40624b=_0x1675fc<<0x6&0xc0|_0x22736b;_0x3ed0fd['push'](_0x40624b);}}}return _0x3ed0fd;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x257dba=0x0;_0x257dba<this['ENCODED_VALS']['length'];_0x257dba++)this['byteToCharMap_'][_0x257dba]=this['ENCODED_VALS']['charAt'](_0x257dba),this['charToByteMap_'][this['byteToCharMap_'][_0x257dba]]=_0x257dba,this['byteToCharMapWebSafe_'][_0x257dba]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x257dba),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x257dba]]=_0x257dba,_0x257dba>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x257dba)]=_0x257dba,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x257dba)]=_0x257dba);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x34c6b1){const _0x1ed2ad=Hr(_0x34c6b1);return Fi['encodeByteArray'](_0x1ed2ad,!0x0);},dn=function(_0x5f3499){return $r(_0x5f3499)['replace'](/\./g,'');},fn=function(_0x4faec8){try{return Fi['decodeString'](_0x4faec8,!0x0);}catch(_0x552983){console['error']('base64Decode\x20failed:\x20',_0x552983);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x586adf){return Gr(void 0x0,_0x586adf);}function Gr(_0x25d0d2,_0x41f972){if(!(_0x41f972 instanceof Object))return _0x41f972;switch(_0x41f972['constructor']){case Date:const _0x5bec8a=_0x41f972;return new Date(_0x5bec8a['getTime']());case Object:_0x25d0d2===void 0x0&&(_0x25d0d2={});break;case Array:_0x25d0d2=[];break;default:return _0x41f972;}for(const _0x31ff64 in _0x41f972)!_0x41f972['hasOwnProperty'](_0x31ff64)||!rc(_0x31ff64)||(_0x25d0d2[_0x31ff64]=Gr(_0x25d0d2[_0x31ff64],_0x41f972[_0x31ff64]));return _0x25d0d2;}function rc(_0x3e2bbe){return _0x3e2bbe!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x160027=Ps['__FIREBASE_DEFAULTS__'];if(_0x160027)return JSON['parse'](_0x160027);},lc=()=>{if(typeof document>'u')return;let _0x427f43;try{_0x427f43=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x314c9c=_0x427f43&&fn(_0x427f43[0x1]);return _0x314c9c&&JSON['parse'](_0x314c9c);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x3e2138){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x3e2138);return;}},qr=_0xfeacf2=>{var _0xe79172,_0x4b9253;return(_0x4b9253=(_0xe79172=Ui())==null?void 0x0:_0xe79172['emulatorHosts'])==null?void 0x0:_0x4b9253[_0xfeacf2];},hc=_0x4c8355=>{const _0x3a53e3=qr(_0x4c8355);if(!_0x3a53e3)return;const _0x2c89e4=_0x3a53e3['lastIndexOf'](':');if(_0x2c89e4<=0x0||_0x2c89e4+0x1===_0x3a53e3['length'])throw new Error('Invalid\x20host\x20'+_0x3a53e3+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x185a39=parseInt(_0x3a53e3['substring'](_0x2c89e4+0x1),0xa);return _0x3a53e3[0x0]==='['?[_0x3a53e3['substring'](0x1,_0x2c89e4-0x1),_0x185a39]:[_0x3a53e3['substring'](0x0,_0x2c89e4),_0x185a39];},zr=()=>{var _0xc3d17;return(_0xc3d17=Ui())==null?void 0x0:_0xc3d17['config'];},jr=_0x253f2f=>{var _0x5479fb;return(_0x5479fb=Ui())==null?void 0x0:_0x5479fb['_'+_0x253f2f];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x38a4a7,_0x26173e)=>{this['resolve']=_0x38a4a7,this['reject']=_0x26173e;});}['wrapCallback'](_0x10d7fc){return(_0x18ed66,_0x431150)=>{_0x18ed66?this['reject'](_0x18ed66):this['resolve'](_0x431150),typeof _0x10d7fc=='function'&&(this['promise']['catch'](()=>{}),_0x10d7fc['length']===0x1?_0x10d7fc(_0x18ed66):_0x10d7fc(_0x18ed66,_0x431150));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0xd637b8,_0x5db006){if(_0xd637b8['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x11d1cf={'alg':'none','type':'JWT'},_0x58acc0=_0x5db006||'demo-project',_0x4867a7=_0xd637b8['iat']||0x0,_0x22ff0c=_0xd637b8['sub']||_0xd637b8['user_id'];if(!_0x22ff0c)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x278206={'iss':'https://securetoken.google.com/'+_0x58acc0,'aud':_0x58acc0,'iat':_0x4867a7,'exp':_0x4867a7+0xe10,'auth_time':_0x4867a7,'sub':_0x22ff0c,'user_id':_0x22ff0c,'firebase':{'sign_in_provider':'custom','identities':{}},..._0xd637b8};return[dn(JSON['stringify'](_0x11d1cf)),dn(JSON['stringify'](_0x278206)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x34a8b1=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x34a8b1=='object'&&_0x34a8b1['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x18aa58=W();return _0x18aa58['indexOf']('MSIE\x20')>=0x0||_0x18aa58['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0xb92fb4,_0x3a2052)=>{try{let _0x432a57=!0x0;const _0x2448de='validate-browser-context-for-indexeddb-analytics-module',_0x43dc0d=self['indexedDB']['open'](_0x2448de);_0x43dc0d['onsuccess']=()=>{_0x43dc0d['result']['close'](),_0x432a57||self['indexedDB']['deleteDatabase'](_0x2448de),_0xb92fb4(!0x0);},_0x43dc0d['onupgradeneeded']=()=>{_0x432a57=!0x1;},_0x43dc0d['onerror']=()=>{var _0x1d861f;_0x3a2052(((_0x1d861f=_0x43dc0d['error'])==null?void 0x0:_0x1d861f['message'])||'');};}catch(_0x2d6b29){_0x3a2052(_0x2d6b29);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x1e1946,_0x39d0d5,_0x5c4c20){super(_0x39d0d5),this['code']=_0x1e1946,this['customData']=_0x5c4c20,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x4be13a,_0x33cf93,_0x58af52){this['service']=_0x4be13a,this['serviceName']=_0x33cf93,this['errors']=_0x58af52;}['create'](_0x50f3b7,..._0x187e28){const _0x34a64d=_0x187e28[0x0]||{},_0x3f930a=this['service']+'/'+_0x50f3b7,_0x53459e=this['errors'][_0x50f3b7],_0x47c6a2=_0x53459e?vc(_0x53459e,_0x34a64d):'Error',_0x3d9548=this['serviceName']+':\x20'+_0x47c6a2+'\x20('+_0x3f930a+').';return new Re(_0x3f930a,_0x3d9548,_0x34a64d);}}function vc(_0x5a96fd,_0x441122){return _0x5a96fd['replace'](Ec,(_0x5966aa,_0x4b0ba1)=>{const _0x452be9=_0x441122[_0x4b0ba1];return _0x452be9!=null?String(_0x452be9):'<'+_0x4b0ba1+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x1ffbbe){return JSON['parse'](_0x1ffbbe);}function O(_0x391176){return JSON['stringify'](_0x391176);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x16b628){let _0x4ce52d={},_0x2b1531={},_0x2fb9c3={},_0x24077d='';try{const _0x5a631b=_0x16b628['split']('.');_0x4ce52d=Nt(fn(_0x5a631b[0x0])||''),_0x2b1531=Nt(fn(_0x5a631b[0x1])||''),_0x24077d=_0x5a631b[0x2],_0x2fb9c3=_0x2b1531['d']||{},delete _0x2b1531['d'];}catch{}return{'header':_0x4ce52d,'claims':_0x2b1531,'data':_0x2fb9c3,'signature':_0x24077d};},Ic=function(_0x4a4b4e){const _0x266c2c=Yr(_0x4a4b4e),_0x47f958=_0x266c2c['claims'];return!!_0x47f958&&typeof _0x47f958=='object'&&_0x47f958['hasOwnProperty']('iat');},wc=function(_0x28552d){const _0x43e78e=Yr(_0x28552d)['claims'];return typeof _0x43e78e=='object'&&_0x43e78e['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x5bc771,_0x5598a8){return Object['prototype']['hasOwnProperty']['call'](_0x5bc771,_0x5598a8);}function Le(_0x517284,_0x12096a){if(Object['prototype']['hasOwnProperty']['call'](_0x517284,_0x12096a))return _0x517284[_0x12096a];}function pn(_0x292650){for(const _0x248a7f in _0x292650)if(Object['prototype']['hasOwnProperty']['call'](_0x292650,_0x248a7f))return!0x1;return!0x0;}function _n(_0x13ace8,_0x5af613,_0x46c383){const _0x2d8278={};for(const _0x26ee67 in _0x13ace8)Object['prototype']['hasOwnProperty']['call'](_0x13ace8,_0x26ee67)&&(_0x2d8278[_0x26ee67]=_0x5af613['call'](_0x46c383,_0x13ace8[_0x26ee67],_0x26ee67,_0x13ace8));return _0x2d8278;}function xe(_0x1bfcd5,_0x2cb00d){if(_0x1bfcd5===_0x2cb00d)return!0x0;const _0x2c9a6a=Object['keys'](_0x1bfcd5),_0x2cfd5f=Object['keys'](_0x2cb00d);for(const _0x46eb1d of _0x2c9a6a){if(!_0x2cfd5f['includes'](_0x46eb1d))return!0x1;const _0x492151=_0x1bfcd5[_0x46eb1d],_0x4b28b1=_0x2cb00d[_0x46eb1d];if(Ns(_0x492151)&&Ns(_0x4b28b1)){if(!xe(_0x492151,_0x4b28b1))return!0x1;}else{if(_0x492151!==_0x4b28b1)return!0x1;}}for(const _0x1c0694 of _0x2cfd5f)if(!_0x2c9a6a['includes'](_0x1c0694))return!0x1;return!0x0;}function Ns(_0x5b2015){return _0x5b2015!==null&&typeof _0x5b2015=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x5b43d3){const _0x506455=[];for(const [_0x2f3bef,_0x3bf528]of Object['entries'](_0x5b43d3))Array['isArray'](_0x3bf528)?_0x3bf528['forEach'](_0x43092e=>{_0x506455['push'](encodeURIComponent(_0x2f3bef)+'='+encodeURIComponent(_0x43092e));}):_0x506455['push'](encodeURIComponent(_0x2f3bef)+'='+encodeURIComponent(_0x3bf528));return _0x506455['length']?'&'+_0x506455['join']('&'):'';}function Ct(_0x41e63b){const _0x546154={};return _0x41e63b['replace'](/^\?/,'')['split']('&')['forEach'](_0x503ee7=>{if(_0x503ee7){const [_0x3f3511,_0x4f84ab]=_0x503ee7['split']('=');_0x546154[decodeURIComponent(_0x3f3511)]=decodeURIComponent(_0x4f84ab);}}),_0x546154;}function Tt(_0x3fd230){const _0x3d95dd=_0x3fd230['indexOf']('?');if(!_0x3d95dd)return'';const _0x3ae847=_0x3fd230['indexOf']('#',_0x3d95dd);return _0x3fd230['substring'](_0x3d95dd,_0x3ae847>0x0?_0x3ae847:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0xc37a6a=0x1;_0xc37a6a<this['blockSize'];++_0xc37a6a)this['pad_'][_0xc37a6a]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x467b73,_0x259cdf){_0x259cdf||(_0x259cdf=0x0);const _0x45361f=this['W_'];if(typeof _0x467b73=='string'){for(let _0x2add90=0x0;_0x2add90<0x10;_0x2add90++)_0x45361f[_0x2add90]=_0x467b73['charCodeAt'](_0x259cdf)<<0x18|_0x467b73['charCodeAt'](_0x259cdf+0x1)<<0x10|_0x467b73['charCodeAt'](_0x259cdf+0x2)<<0x8|_0x467b73['charCodeAt'](_0x259cdf+0x3),_0x259cdf+=0x4;}else{for(let _0x4abdde=0x0;_0x4abdde<0x10;_0x4abdde++)_0x45361f[_0x4abdde]=_0x467b73[_0x259cdf]<<0x18|_0x467b73[_0x259cdf+0x1]<<0x10|_0x467b73[_0x259cdf+0x2]<<0x8|_0x467b73[_0x259cdf+0x3],_0x259cdf+=0x4;}for(let _0x98f320=0x10;_0x98f320<0x50;_0x98f320++){const _0x2e521d=_0x45361f[_0x98f320-0x3]^_0x45361f[_0x98f320-0x8]^_0x45361f[_0x98f320-0xe]^_0x45361f[_0x98f320-0x10];_0x45361f[_0x98f320]=(_0x2e521d<<0x1|_0x2e521d>>>0x1f)&0xffffffff;}let _0x49b7f2=this['chain_'][0x0],_0x495db8=this['chain_'][0x1],_0x4381a5=this['chain_'][0x2],_0x5a8666=this['chain_'][0x3],_0x2c6d8a=this['chain_'][0x4],_0x114973,_0x22e6b6;for(let _0x23cead=0x0;_0x23cead<0x50;_0x23cead++){_0x23cead<0x28?_0x23cead<0x14?(_0x114973=_0x5a8666^_0x495db8&(_0x4381a5^_0x5a8666),_0x22e6b6=0x5a827999):(_0x114973=_0x495db8^_0x4381a5^_0x5a8666,_0x22e6b6=0x6ed9eba1):_0x23cead<0x3c?(_0x114973=_0x495db8&_0x4381a5|_0x5a8666&(_0x495db8|_0x4381a5),_0x22e6b6=0x8f1bbcdc):(_0x114973=_0x495db8^_0x4381a5^_0x5a8666,_0x22e6b6=0xca62c1d6);const _0x1cfa61=(_0x49b7f2<<0x5|_0x49b7f2>>>0x1b)+_0x114973+_0x2c6d8a+_0x22e6b6+_0x45361f[_0x23cead]&0xffffffff;_0x2c6d8a=_0x5a8666,_0x5a8666=_0x4381a5,_0x4381a5=(_0x495db8<<0x1e|_0x495db8>>>0x2)&0xffffffff,_0x495db8=_0x49b7f2,_0x49b7f2=_0x1cfa61;}this['chain_'][0x0]=this['chain_'][0x0]+_0x49b7f2&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x495db8&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x4381a5&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x5a8666&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x2c6d8a&0xffffffff;}['update'](_0x1f1542,_0x34b3b9){if(_0x1f1542==null)return;_0x34b3b9===void 0x0&&(_0x34b3b9=_0x1f1542['length']);const _0x44ff0d=_0x34b3b9-this['blockSize'];let _0x536e7c=0x0;const _0x1fc94f=this['buf_'];let _0x5273a1=this['inbuf_'];for(;_0x536e7c<_0x34b3b9;){if(_0x5273a1===0x0){for(;_0x536e7c<=_0x44ff0d;)this['compress_'](_0x1f1542,_0x536e7c),_0x536e7c+=this['blockSize'];}if(typeof _0x1f1542=='string'){for(;_0x536e7c<_0x34b3b9;)if(_0x1fc94f[_0x5273a1]=_0x1f1542['charCodeAt'](_0x536e7c),++_0x5273a1,++_0x536e7c,_0x5273a1===this['blockSize']){this['compress_'](_0x1fc94f),_0x5273a1=0x0;break;}}else{for(;_0x536e7c<_0x34b3b9;)if(_0x1fc94f[_0x5273a1]=_0x1f1542[_0x536e7c],++_0x5273a1,++_0x536e7c,_0x5273a1===this['blockSize']){this['compress_'](_0x1fc94f),_0x5273a1=0x0;break;}}}this['inbuf_']=_0x5273a1,this['total_']+=_0x34b3b9;}['digest'](){const _0x190c40=[];let _0x237139=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x4f25f6=this['blockSize']-0x1;_0x4f25f6>=0x38;_0x4f25f6--)this['buf_'][_0x4f25f6]=_0x237139&0xff,_0x237139/=0x100;this['compress_'](this['buf_']);let _0x1493b5=0x0;for(let _0x5cb6fd=0x0;_0x5cb6fd<0x5;_0x5cb6fd++)for(let _0x499ca9=0x18;_0x499ca9>=0x0;_0x499ca9-=0x8)_0x190c40[_0x1493b5]=this['chain_'][_0x5cb6fd]>>_0x499ca9&0xff,++_0x1493b5;return _0x190c40;}}function Tc(_0x16fa76,_0x2f60e6){const _0x4876eb=new Sc(_0x16fa76,_0x2f60e6);return _0x4876eb['subscribe']['bind'](_0x4876eb);}class Sc{constructor(_0x56f4f5,_0x4a8787){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x4a8787,this['task']['then'](()=>{_0x56f4f5(this);})['catch'](_0x481838=>{this['error'](_0x481838);});}['next'](_0x3f638d){this['forEachObserver'](_0x3e6972=>{_0x3e6972['next'](_0x3f638d);});}['error'](_0x636025){this['forEachObserver'](_0x2d99cf=>{_0x2d99cf['error'](_0x636025);}),this['close'](_0x636025);}['complete'](){this['forEachObserver'](_0x100c4d=>{_0x100c4d['complete']();}),this['close']();}['subscribe'](_0x41c626,_0x2839cc,_0x3e5495){let _0x4428f0;if(_0x41c626===void 0x0&&_0x2839cc===void 0x0&&_0x3e5495===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x41c626,['next','error','complete'])?_0x4428f0=_0x41c626:_0x4428f0={'next':_0x41c626,'error':_0x2839cc,'complete':_0x3e5495},_0x4428f0['next']===void 0x0&&(_0x4428f0['next']=ti),_0x4428f0['error']===void 0x0&&(_0x4428f0['error']=ti),_0x4428f0['complete']===void 0x0&&(_0x4428f0['complete']=ti);const _0x5608ce=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x4428f0['error'](this['finalError']):_0x4428f0['complete']();}catch{}}),this['observers']['push'](_0x4428f0),_0x5608ce;}['unsubscribeOne'](_0x28a331){this['observers']===void 0x0||this['observers'][_0x28a331]===void 0x0||(delete this['observers'][_0x28a331],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x2951d){if(!this['finalized']){for(let _0x2f4d2d=0x0;_0x2f4d2d<this['observers']['length'];_0x2f4d2d++)this['sendOne'](_0x2f4d2d,_0x2951d);}}['sendOne'](_0x19ec89,_0x394e1b){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x19ec89]!==void 0x0)try{_0x394e1b(this['observers'][_0x19ec89]);}catch(_0x253522){typeof console<'u'&&console['error']&&console['error'](_0x253522);}});}['close'](_0x179b35){this['finalized']||(this['finalized']=!0x0,_0x179b35!==void 0x0&&(this['finalError']=_0x179b35),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x44254e,_0x208d3a){if(typeof _0x44254e!='object'||_0x44254e===null)return!0x1;for(const _0x2b7e1f of _0x208d3a)if(_0x2b7e1f in _0x44254e&&typeof _0x44254e[_0x2b7e1f]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x55c528,_0x47a191){return _0x55c528+'\x20failed:\x20'+_0x47a191+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x52bc5a){const _0x30469f=[];let _0xf95c25=0x0;for(let _0x24a20d=0x0;_0x24a20d<_0x52bc5a['length'];_0x24a20d++){let _0x51be6b=_0x52bc5a['charCodeAt'](_0x24a20d);if(_0x51be6b>=0xd800&&_0x51be6b<=0xdbff){const _0x4edd95=_0x51be6b-0xd800;_0x24a20d++,f(_0x24a20d<_0x52bc5a['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x292fa0=_0x52bc5a['charCodeAt'](_0x24a20d)-0xdc00;_0x51be6b=0x10000+(_0x4edd95<<0xa)+_0x292fa0;}_0x51be6b<0x80?_0x30469f[_0xf95c25++]=_0x51be6b:_0x51be6b<0x800?(_0x30469f[_0xf95c25++]=_0x51be6b>>0x6|0xc0,_0x30469f[_0xf95c25++]=_0x51be6b&0x3f|0x80):_0x51be6b<0x10000?(_0x30469f[_0xf95c25++]=_0x51be6b>>0xc|0xe0,_0x30469f[_0xf95c25++]=_0x51be6b>>0x6&0x3f|0x80,_0x30469f[_0xf95c25++]=_0x51be6b&0x3f|0x80):(_0x30469f[_0xf95c25++]=_0x51be6b>>0x12|0xf0,_0x30469f[_0xf95c25++]=_0x51be6b>>0xc&0x3f|0x80,_0x30469f[_0xf95c25++]=_0x51be6b>>0x6&0x3f|0x80,_0x30469f[_0xf95c25++]=_0x51be6b&0x3f|0x80);}return _0x30469f;},Ln=function(_0xa20fb0){let _0x33f51d=0x0;for(let _0x575cfd=0x0;_0x575cfd<_0xa20fb0['length'];_0x575cfd++){const _0x1b5d9e=_0xa20fb0['charCodeAt'](_0x575cfd);_0x1b5d9e<0x80?_0x33f51d++:_0x1b5d9e<0x800?_0x33f51d+=0x2:_0x1b5d9e>=0xd800&&_0x1b5d9e<=0xdbff?(_0x33f51d+=0x4,_0x575cfd++):_0x33f51d+=0x3;}return _0x33f51d;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x41595c){return _0x41595c&&_0x41595c['_delegate']?_0x41595c['_delegate']:_0x41595c;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x5405f6){try{return(_0x5405f6['startsWith']('http://')||_0x5405f6['startsWith']('https://')?new URL(_0x5405f6)['hostname']:_0x5405f6)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x265b0d){return(await fetch(_0x265b0d,{'credentials':'include'}))['ok'];}class Fe{constructor(_0xbb04b1,_0x37aab3,_0x3796fa){this['name']=_0xbb04b1,this['instanceFactory']=_0x37aab3,this['type']=_0x3796fa,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x1767b4){return this['instantiationMode']=_0x1767b4,this;}['setMultipleInstances'](_0x4b5cee){return this['multipleInstances']=_0x4b5cee,this;}['setServiceProps'](_0x389136){return this['serviceProps']=_0x389136,this;}['setInstanceCreatedCallback'](_0x56cc40){return this['onInstanceCreated']=_0x56cc40,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x41115b,_0x1fa520){this['name']=_0x41115b,this['container']=_0x1fa520,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x19cd04){const _0x5113e0=this['normalizeInstanceIdentifier'](_0x19cd04);if(!this['instancesDeferred']['has'](_0x5113e0)){const _0x3c0a91=new H();if(this['instancesDeferred']['set'](_0x5113e0,_0x3c0a91),this['isInitialized'](_0x5113e0)||this['shouldAutoInitialize']())try{const _0x56723e=this['getOrInitializeService']({'instanceIdentifier':_0x5113e0});_0x56723e&&_0x3c0a91['resolve'](_0x56723e);}catch{}}return this['instancesDeferred']['get'](_0x5113e0)['promise'];}['getImmediate'](_0x5dd434){const _0x4c398f=this['normalizeInstanceIdentifier'](_0x5dd434==null?void 0x0:_0x5dd434['identifier']),_0x576342=(_0x5dd434==null?void 0x0:_0x5dd434['optional'])??!0x1;if(this['isInitialized'](_0x4c398f)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x4c398f});}catch(_0x5c3639){if(_0x576342)return null;throw _0x5c3639;}else{if(_0x576342)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x806d0b){if(_0x806d0b['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x806d0b['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x806d0b,!!this['shouldAutoInitialize']()){if(Pc(_0x806d0b))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x199ee8,_0x56a6ea]of this['instancesDeferred']['entries']()){const _0x11171c=this['normalizeInstanceIdentifier'](_0x199ee8);try{const _0x2906d2=this['getOrInitializeService']({'instanceIdentifier':_0x11171c});_0x56a6ea['resolve'](_0x2906d2);}catch{}}}}['clearInstance'](_0x504a60=Ne){this['instancesDeferred']['delete'](_0x504a60),this['instancesOptions']['delete'](_0x504a60),this['instances']['delete'](_0x504a60);}async['delete'](){const _0x260b8a=Array['from'](this['instances']['values']());await Promise['all']([..._0x260b8a['filter'](_0x22ab55=>'INTERNAL'in _0x22ab55)['map'](_0x25c7e5=>_0x25c7e5['INTERNAL']['delete']()),..._0x260b8a['filter'](_0x5c764f=>'_delete'in _0x5c764f)['map'](_0x2f42d8=>_0x2f42d8['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x7ac2c8=Ne){return this['instances']['has'](_0x7ac2c8);}['getOptions'](_0x5b7b0d=Ne){return this['instancesOptions']['get'](_0x5b7b0d)||{};}['initialize'](_0x183865={}){const {options:_0x2720c5={}}=_0x183865,_0x5a8b27=this['normalizeInstanceIdentifier'](_0x183865['instanceIdentifier']);if(this['isInitialized'](_0x5a8b27))throw Error(this['name']+'('+_0x5a8b27+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x1c7a41=this['getOrInitializeService']({'instanceIdentifier':_0x5a8b27,'options':_0x2720c5});for(const [_0x1360d5,_0x1e863b]of this['instancesDeferred']['entries']()){const _0x178403=this['normalizeInstanceIdentifier'](_0x1360d5);_0x5a8b27===_0x178403&&_0x1e863b['resolve'](_0x1c7a41);}return _0x1c7a41;}['onInit'](_0xdc1138,_0x5a18fd){const _0x28d2d8=this['normalizeInstanceIdentifier'](_0x5a18fd),_0x228f53=this['onInitCallbacks']['get'](_0x28d2d8)??new Set();_0x228f53['add'](_0xdc1138),this['onInitCallbacks']['set'](_0x28d2d8,_0x228f53);const _0x4dae6e=this['instances']['get'](_0x28d2d8);return _0x4dae6e&&_0xdc1138(_0x4dae6e,_0x28d2d8),()=>{_0x228f53['delete'](_0xdc1138);};}['invokeOnInitCallbacks'](_0x22fd16,_0x1edd5f){const _0xd7ad2=this['onInitCallbacks']['get'](_0x1edd5f);if(_0xd7ad2){for(const _0x1b7526 of _0xd7ad2)try{_0x1b7526(_0x22fd16,_0x1edd5f);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x74bb06,options:_0x2427a3={}}){let _0x3d8a56=this['instances']['get'](_0x74bb06);if(!_0x3d8a56&&this['component']&&(_0x3d8a56=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x74bb06),'options':_0x2427a3}),this['instances']['set'](_0x74bb06,_0x3d8a56),this['instancesOptions']['set'](_0x74bb06,_0x2427a3),this['invokeOnInitCallbacks'](_0x3d8a56,_0x74bb06),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x74bb06,_0x3d8a56);}catch{}return _0x3d8a56||null;}['normalizeInstanceIdentifier'](_0x56eff7=Ne){return this['component']?this['component']['multipleInstances']?_0x56eff7:Ne:_0x56eff7;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x48e37e){return _0x48e37e===Ne?void 0x0:_0x48e37e;}function Pc(_0x2d2d70){return _0x2d2d70['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x36f257){this['name']=_0x36f257,this['providers']=new Map();}['addComponent'](_0x43eddc){const _0x1570cc=this['getProvider'](_0x43eddc['name']);if(_0x1570cc['isComponentSet']())throw new Error('Component\x20'+_0x43eddc['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x1570cc['setComponent'](_0x43eddc);}['addOrOverwriteComponent'](_0x3fc875){this['getProvider'](_0x3fc875['name'])['isComponentSet']()&&this['providers']['delete'](_0x3fc875['name']),this['addComponent'](_0x3fc875);}['getProvider'](_0x1dca68){if(this['providers']['has'](_0x1dca68))return this['providers']['get'](_0x1dca68);const _0x4e10f9=new Ac(_0x1dca68,this);return this['providers']['set'](_0x1dca68,_0x4e10f9),_0x4e10f9;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x53e5aa){_0x53e5aa[_0x53e5aa['DEBUG']=0x0]='DEBUG',_0x53e5aa[_0x53e5aa['VERBOSE']=0x1]='VERBOSE',_0x53e5aa[_0x53e5aa['INFO']=0x2]='INFO',_0x53e5aa[_0x53e5aa['WARN']=0x3]='WARN',_0x53e5aa[_0x53e5aa['ERROR']=0x4]='ERROR',_0x53e5aa[_0x53e5aa['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0xfd32bf,_0x1d11cd,..._0x14bd25)=>{if(_0x1d11cd<_0xfd32bf['logLevel'])return;const _0xf7e8ef=new Date()['toISOString'](),_0x132e1b=Mc[_0x1d11cd];if(_0x132e1b)console[_0x132e1b]('['+_0xf7e8ef+']\x20\x20'+_0xfd32bf['name']+':',..._0x14bd25);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x1d11cd+')');};class Bi{constructor(_0x50082b){this['name']=_0x50082b,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x6f199f){if(!(_0x6f199f in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x6f199f+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x6f199f;}['setLogLevel'](_0x29389a){this['_logLevel']=typeof _0x29389a=='string'?Oc[_0x29389a]:_0x29389a;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x46737b){if(typeof _0x46737b!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x46737b;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x262e7d){this['_userLogHandler']=_0x262e7d;}['debug'](..._0xcb2738){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0xcb2738),this['_logHandler'](this,T['DEBUG'],..._0xcb2738);}['log'](..._0x408e06){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x408e06),this['_logHandler'](this,T['VERBOSE'],..._0x408e06);}['info'](..._0x2c1472){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x2c1472),this['_logHandler'](this,T['INFO'],..._0x2c1472);}['warn'](..._0x4cbe26){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x4cbe26),this['_logHandler'](this,T['WARN'],..._0x4cbe26);}['error'](..._0x18e295){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x18e295),this['_logHandler'](this,T['ERROR'],..._0x18e295);}}const xc=(_0x1c9f1a,_0x51b1aa)=>_0x51b1aa['some'](_0x397843=>_0x1c9f1a instanceof _0x397843);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x3a1a19){const _0xb127da=new Promise((_0x3e34cc,_0x1d8ff8)=>{const _0x54a428=()=>{_0x3a1a19['removeEventListener']('success',_0x19f2c5),_0x3a1a19['removeEventListener']('error',_0x2d3498);},_0x19f2c5=()=>{_0x3e34cc(ge(_0x3a1a19['result'])),_0x54a428();},_0x2d3498=()=>{_0x1d8ff8(_0x3a1a19['error']),_0x54a428();};_0x3a1a19['addEventListener']('success',_0x19f2c5),_0x3a1a19['addEventListener']('error',_0x2d3498);});return _0xb127da['then'](_0x3f151d=>{_0x3f151d instanceof IDBCursor&&Jr['set'](_0x3f151d,_0x3a1a19);})['catch'](()=>{}),Vi['set'](_0xb127da,_0x3a1a19),_0xb127da;}function Bc(_0x2fa015){if(_i['has'](_0x2fa015))return;const _0xdbdc7=new Promise((_0x4780cf,_0x2e9149)=>{const _0x11a7c0=()=>{_0x2fa015['removeEventListener']('complete',_0x425a1f),_0x2fa015['removeEventListener']('error',_0x5b680f),_0x2fa015['removeEventListener']('abort',_0x5b680f);},_0x425a1f=()=>{_0x4780cf(),_0x11a7c0();},_0x5b680f=()=>{_0x2e9149(_0x2fa015['error']||new DOMException('AbortError','AbortError')),_0x11a7c0();};_0x2fa015['addEventListener']('complete',_0x425a1f),_0x2fa015['addEventListener']('error',_0x5b680f),_0x2fa015['addEventListener']('abort',_0x5b680f);});_i['set'](_0x2fa015,_0xdbdc7);}let gi={'get'(_0x509413,_0x27120c,_0x294d7c){if(_0x509413 instanceof IDBTransaction){if(_0x27120c==='done')return _i['get'](_0x509413);if(_0x27120c==='objectStoreNames')return _0x509413['objectStoreNames']||Xr['get'](_0x509413);if(_0x27120c==='store')return _0x294d7c['objectStoreNames'][0x1]?void 0x0:_0x294d7c['objectStore'](_0x294d7c['objectStoreNames'][0x0]);}return ge(_0x509413[_0x27120c]);},'set'(_0x1f4a98,_0x5cf3dd,_0x22b789){return _0x1f4a98[_0x5cf3dd]=_0x22b789,!0x0;},'has'(_0x1b36ad,_0x5963e6){return _0x1b36ad instanceof IDBTransaction&&(_0x5963e6==='done'||_0x5963e6==='store')?!0x0:_0x5963e6 in _0x1b36ad;}};function Vc(_0x5a7ee5){gi=_0x5a7ee5(gi);}function Hc(_0xe4b9d7){return _0xe4b9d7===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x4bef95,..._0x43cc76){const _0x965bd8=_0xe4b9d7['call'](ii(this),_0x4bef95,..._0x43cc76);return Xr['set'](_0x965bd8,_0x4bef95['sort']?_0x4bef95['sort']():[_0x4bef95]),ge(_0x965bd8);}:Uc()['includes'](_0xe4b9d7)?function(..._0x436e29){return _0xe4b9d7['apply'](ii(this),_0x436e29),ge(Jr['get'](this));}:function(..._0x514043){return ge(_0xe4b9d7['apply'](ii(this),_0x514043));};}function $c(_0x3e9fe1){return typeof _0x3e9fe1=='function'?Hc(_0x3e9fe1):(_0x3e9fe1 instanceof IDBTransaction&&Bc(_0x3e9fe1),xc(_0x3e9fe1,Fc())?new Proxy(_0x3e9fe1,gi):_0x3e9fe1);}function ge(_0x43250e){if(_0x43250e instanceof IDBRequest)return Wc(_0x43250e);if(ni['has'](_0x43250e))return ni['get'](_0x43250e);const _0x1b5dcc=$c(_0x43250e);return _0x1b5dcc!==_0x43250e&&(ni['set'](_0x43250e,_0x1b5dcc),Vi['set'](_0x1b5dcc,_0x43250e)),_0x1b5dcc;}const ii=_0x8b50e4=>Vi['get'](_0x8b50e4);function Gc(_0x4785ba,_0x5e9de6,{blocked:_0x2c4114,upgrade:_0x1b49b9,blocking:_0x4f08e3,terminated:_0x305fb5}={}){const _0x1c3d59=indexedDB['open'](_0x4785ba,_0x5e9de6),_0x129a21=ge(_0x1c3d59);return _0x1b49b9&&_0x1c3d59['addEventListener']('upgradeneeded',_0x4a7eed=>{_0x1b49b9(ge(_0x1c3d59['result']),_0x4a7eed['oldVersion'],_0x4a7eed['newVersion'],ge(_0x1c3d59['transaction']),_0x4a7eed);}),_0x2c4114&&_0x1c3d59['addEventListener']('blocked',_0x3231e=>_0x2c4114(_0x3231e['oldVersion'],_0x3231e['newVersion'],_0x3231e)),_0x129a21['then'](_0x4cb123=>{_0x305fb5&&_0x4cb123['addEventListener']('close',()=>_0x305fb5()),_0x4f08e3&&_0x4cb123['addEventListener']('versionchange',_0x4b6349=>_0x4f08e3(_0x4b6349['oldVersion'],_0x4b6349['newVersion'],_0x4b6349));})['catch'](()=>{}),_0x129a21;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x997de8,_0x204ee0){if(!(_0x997de8 instanceof IDBDatabase&&!(_0x204ee0 in _0x997de8)&&typeof _0x204ee0=='string'))return;if(si['get'](_0x204ee0))return si['get'](_0x204ee0);const _0x12c244=_0x204ee0['replace'](/FromIndex$/,''),_0x5a6d2f=_0x204ee0!==_0x12c244,_0x5522af=zc['includes'](_0x12c244);if(!(_0x12c244 in(_0x5a6d2f?IDBIndex:IDBObjectStore)['prototype'])||!(_0x5522af||qc['includes'](_0x12c244)))return;const _0x3f318e=async function(_0x307aca,..._0x1dfc94){const _0x32ae8d=this['transaction'](_0x307aca,_0x5522af?'readwrite':'readonly');let _0x38d41d=_0x32ae8d['store'];return _0x5a6d2f&&(_0x38d41d=_0x38d41d['index'](_0x1dfc94['shift']())),(await Promise['all']([_0x38d41d[_0x12c244](..._0x1dfc94),_0x5522af&&_0x32ae8d['done']]))[0x0];};return si['set'](_0x204ee0,_0x3f318e),_0x3f318e;}Vc(_0x12795c=>({..._0x12795c,'get':(_0x497656,_0x17767f,_0x2ebc76)=>Ms(_0x497656,_0x17767f)||_0x12795c['get'](_0x497656,_0x17767f,_0x2ebc76),'has':(_0x17b445,_0x52de34)=>!!Ms(_0x17b445,_0x52de34)||_0x12795c['has'](_0x17b445,_0x52de34)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x136c83){this['container']=_0x136c83;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x11e9a9=>{if(Kc(_0x11e9a9)){const _0x18f285=_0x11e9a9['getImmediate']();return _0x18f285['library']+'/'+_0x18f285['version'];}else return null;})['filter'](_0x205f8b=>_0x205f8b)['join']('\x20');}}function Kc(_0xfacdc1){const _0x5641dc=_0xfacdc1['getComponent']();return(_0x5641dc==null?void 0x0:_0x5641dc['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x3be11c,_0x12fbe1){try{_0x3be11c['container']['addComponent'](_0x12fbe1);}catch(_0x287807){oe['debug']('Component\x20'+_0x12fbe1['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x3be11c['name'],_0x287807);}}function st(_0x4ef591){const _0x15e466=_0x4ef591['name'];if(Ei['has'](_0x15e466))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x15e466+'.'),!0x1;Ei['set'](_0x15e466,_0x4ef591);for(const _0x436a8f of Ue['values']())xs(_0x436a8f,_0x4ef591);for(const _0x56f8b1 of vi['values']())xs(_0x56f8b1,_0x4ef591);return!0x0;}function Hi(_0x52b6fb,_0x4e8553){const _0x1f4c33=_0x52b6fb['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x1f4c33&&_0x1f4c33['triggerHeartbeat'](),_0x52b6fb['container']['getProvider'](_0x4e8553);}function $(_0x23e975){return _0x23e975==null?!0x1:_0x23e975['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x35be2b,_0x3e0be4,_0x340c91){this['_isDeleted']=!0x1,this['_options']={..._0x35be2b},this['_config']={..._0x3e0be4},this['_name']=_0x3e0be4['name'],this['_automaticDataCollectionEnabled']=_0x3e0be4['automaticDataCollectionEnabled'],this['_container']=_0x340c91,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x2f4a14){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x2f4a14;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x5c18c9){this['_isDeleted']=_0x5c18c9;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x5d501b,_0x40d2d6={}){let _0x4d7e2f=_0x5d501b;typeof _0x40d2d6!='object'&&(_0x40d2d6={'name':_0x40d2d6});const _0x4c8763={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x40d2d6},_0x5d398b=_0x4c8763['name'];if(typeof _0x5d398b!='string'||!_0x5d398b)throw me['create']('bad-app-name',{'appName':String(_0x5d398b)});if(_0x4d7e2f||(_0x4d7e2f=zr()),!_0x4d7e2f)throw me['create']('no-options');const _0x5c48d8=Ue['get'](_0x5d398b);if(_0x5c48d8){if(xe(_0x4d7e2f,_0x5c48d8['options'])&&xe(_0x4c8763,_0x5c48d8['config']))return _0x5c48d8;throw me['create']('duplicate-app',{'appName':_0x5d398b});}const _0x58cb8b=new Nc(_0x5d398b);for(const _0x4fe6ad of Ei['values']())_0x58cb8b['addComponent'](_0x4fe6ad);const _0x2a24b8=new Tl(_0x4d7e2f,_0x4c8763,_0x58cb8b);return Ue['set'](_0x5d398b,_0x2a24b8),_0x2a24b8;}function Zr(_0x507b6d=yi){const _0xf171f9=Ue['get'](_0x507b6d);if(!_0xf171f9&&_0x507b6d===yi&&zr())return Sl();if(!_0xf171f9)throw me['create']('no-app',{'appName':_0x507b6d});return _0xf171f9;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x4e98b2){let _0x5d56c5=!0x1;const _0x511db4=_0x4e98b2['name'];Ue['has'](_0x511db4)?(_0x5d56c5=!0x0,Ue['delete'](_0x511db4)):vi['has'](_0x511db4)&&_0x4e98b2['decRefCount']()<=0x0&&(vi['delete'](_0x511db4),_0x5d56c5=!0x0),_0x5d56c5&&(await Promise['all'](_0x4e98b2['container']['getProviders']()['map'](_0x773b8d=>_0x773b8d['delete']())),_0x4e98b2['isDeleted']=!0x0);}function ye(_0x473d61,_0x2cc17f,_0xee2fdc){let _0x324055=wl[_0x473d61]??_0x473d61;_0xee2fdc&&(_0x324055+='-'+_0xee2fdc);const _0xa29fd7=_0x324055['match'](/\s|\//),_0xbdfb89=_0x2cc17f['match'](/\s|\//);if(_0xa29fd7||_0xbdfb89){const _0x514508=['Unable\x20to\x20register\x20library\x20\x22'+_0x324055+'\x22\x20with\x20version\x20\x22'+_0x2cc17f+'\x22:'];_0xa29fd7&&_0x514508['push']('library\x20name\x20\x22'+_0x324055+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0xa29fd7&&_0xbdfb89&&_0x514508['push']('and'),_0xbdfb89&&_0x514508['push']('version\x20name\x20\x22'+_0x2cc17f+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x514508['join']('\x20'));return;}st(new Fe(_0x324055+'-version',()=>({'library':_0x324055,'version':_0x2cc17f}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x40812a,_0xb583db)=>{switch(_0xb583db){case 0x0:try{_0x40812a['createObjectStore'](Ot);}catch(_0x4bd16a){console['warn'](_0x4bd16a);}}}})['catch'](_0x43b48f=>{throw me['create']('idb-open',{'originalErrorMessage':_0x43b48f['message']});})),ri;}async function Al(_0x457f22){try{const _0x36bdfc=(await eo())['transaction'](Ot),_0x5c07f4=await _0x36bdfc['objectStore'](Ot)['get'](to(_0x457f22));return await _0x36bdfc['done'],_0x5c07f4;}catch(_0x30cfe8){if(_0x30cfe8 instanceof Re)oe['warn'](_0x30cfe8['message']);else{const _0x5a8707=me['create']('idb-get',{'originalErrorMessage':_0x30cfe8==null?void 0x0:_0x30cfe8['message']});oe['warn'](_0x5a8707['message']);}}}async function Fs(_0x458a38,_0x521fde){try{const _0x3a7949=(await eo())['transaction'](Ot,'readwrite');await _0x3a7949['objectStore'](Ot)['put'](_0x521fde,to(_0x458a38)),await _0x3a7949['done'];}catch(_0x1d6e54){if(_0x1d6e54 instanceof Re)oe['warn'](_0x1d6e54['message']);else{const _0x4d35e6=me['create']('idb-set',{'originalErrorMessage':_0x1d6e54==null?void 0x0:_0x1d6e54['message']});oe['warn'](_0x4d35e6['message']);}}}function to(_0x12d222){return _0x12d222['name']+'!'+_0x12d222['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x2e4353){this['container']=_0x2e4353,this['_heartbeatsCache']=null;const _0x322828=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x322828),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x2a1e44=>(this['_heartbeatsCache']=_0x2a1e44,_0x2a1e44));}async['triggerHeartbeat'](){var _0x54f7ac,_0x21d0a6;try{const _0x5f090e=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x51bfc1=Us();if(((_0x54f7ac=this['_heartbeatsCache'])==null?void 0x0:_0x54f7ac['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x21d0a6=this['_heartbeatsCache'])==null?void 0x0:_0x21d0a6['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x51bfc1||this['_heartbeatsCache']['heartbeats']['some'](_0x507b58=>_0x507b58['date']===_0x51bfc1))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x51bfc1,'agent':_0x5f090e}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x46e03a=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x46e03a,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x2cb571){oe['warn'](_0x2cb571);}}async['getHeartbeatsHeader'](){var _0x4e8507;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x4e8507=this['_heartbeatsCache'])==null?void 0x0:_0x4e8507['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0xf5dea0=Us(),{heartbeatsToSend:_0x2e3ad0,unsentEntries:_0x34471d}=Ol(this['_heartbeatsCache']['heartbeats']),_0x55b944=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x2e3ad0}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0xf5dea0,_0x34471d['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x34471d,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x55b944;}catch(_0x414d68){return oe['warn'](_0x414d68),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x2ebaf2,_0x5a0d2e=kl){const _0x50ac61=[];let _0x124edc=_0x2ebaf2['slice']();for(const _0x3b688d of _0x2ebaf2){const _0x4caffb=_0x50ac61['find'](_0x16d366=>_0x16d366['agent']===_0x3b688d['agent']);if(_0x4caffb){if(_0x4caffb['dates']['push'](_0x3b688d['date']),Ws(_0x50ac61)>_0x5a0d2e){_0x4caffb['dates']['pop']();break;}}else{if(_0x50ac61['push']({'agent':_0x3b688d['agent'],'dates':[_0x3b688d['date']]}),Ws(_0x50ac61)>_0x5a0d2e){_0x50ac61['pop']();break;}}_0x124edc=_0x124edc['slice'](0x1);}return{'heartbeatsToSend':_0x50ac61,'unsentEntries':_0x124edc};}class Dl{constructor(_0x15550f){this['app']=_0x15550f,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x3d4211=await Al(this['app']);return _0x3d4211!=null&&_0x3d4211['heartbeats']?_0x3d4211:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x571379){if(await this['_canUseIndexedDBPromise']){const _0x4443b9=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x571379['lastSentHeartbeatDate']??_0x4443b9['lastSentHeartbeatDate'],'heartbeats':_0x571379['heartbeats']});}else return;}async['add'](_0x5413fa){if(await this['_canUseIndexedDBPromise']){const _0x3b33c9=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x5413fa['lastSentHeartbeatDate']??_0x3b33c9['lastSentHeartbeatDate'],'heartbeats':[..._0x3b33c9['heartbeats'],..._0x5413fa['heartbeats']]});}else return;}}function Ws(_0x1e491c){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x1e491c}))['length'];}function Ml(_0xfab931){if(_0xfab931['length']===0x0)return-0x1;let _0x4e4c71=0x0,_0x314ebf=_0xfab931[0x0]['date'];for(let _0x2600e7=0x1;_0x2600e7<_0xfab931['length'];_0x2600e7++)_0xfab931[_0x2600e7]['date']<_0x314ebf&&(_0x314ebf=_0xfab931[_0x2600e7]['date'],_0x4e4c71=_0x2600e7);return _0x4e4c71;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x446ac7){st(new Fe('platform-logger',_0xe2e274=>new jc(_0xe2e274),'PRIVATE')),st(new Fe('heartbeat',_0x3bf13e=>new Nl(_0x3bf13e),'PRIVATE')),ye(mi,Ls,_0x446ac7),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x2810ea){no=_0x2810ea;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x522afe){this['domStorage_']=_0x522afe,this['prefix_']='firebase:';}['set'](_0x3ed603,_0x683043){_0x683043==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x3ed603)):this['domStorage_']['setItem'](this['prefixedName_'](_0x3ed603),O(_0x683043));}['get'](_0x3034ed){const _0x6ce309=this['domStorage_']['getItem'](this['prefixedName_'](_0x3034ed));return _0x6ce309==null?null:Nt(_0x6ce309);}['remove'](_0x5ecfa7){this['domStorage_']['removeItem'](this['prefixedName_'](_0x5ecfa7));}['prefixedName_'](_0x2995b2){return this['prefix_']+_0x2995b2;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x1bb8dc,_0x53a98f){_0x53a98f==null?delete this['cache_'][_0x1bb8dc]:this['cache_'][_0x1bb8dc]=_0x53a98f;}['get'](_0x40a808){return Q(this['cache_'],_0x40a808)?this['cache_'][_0x40a808]:null;}['remove'](_0x32dd37){delete this['cache_'][_0x32dd37];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0xe33cb1){try{if(typeof window<'u'&&typeof window[_0xe33cb1]<'u'){const _0x29f1e4=window[_0xe33cb1];return _0x29f1e4['setItem']('firebase:sentinel','cache'),_0x29f1e4['removeItem']('firebase:sentinel'),new Wl(_0x29f1e4);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x561284=0x1;return function(){return _0x561284++;};}()),ro=function(_0x2814af){const _0x54dc7f=Rc(_0x2814af),_0x44de9c=new Cc();_0x44de9c['update'](_0x54dc7f);const _0xdbc0f0=_0x44de9c['digest']();return Fi['encodeByteArray'](_0xdbc0f0);},zt=function(..._0x40b29f){let _0x1d33b1='';for(let _0xf4e9e3=0x0;_0xf4e9e3<_0x40b29f['length'];_0xf4e9e3++){const _0x71091e=_0x40b29f[_0xf4e9e3];Array['isArray'](_0x71091e)||_0x71091e&&typeof _0x71091e=='object'&&typeof _0x71091e['length']=='number'?_0x1d33b1+=zt['apply'](null,_0x71091e):typeof _0x71091e=='object'?_0x1d33b1+=O(_0x71091e):_0x1d33b1+=_0x71091e,_0x1d33b1+='\x20';}return _0x1d33b1;};let St=null,$s=!0x0;const Hl=function(_0x41368c,_0xce3318){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x421dbc){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x1a7709=zt['apply'](null,_0x421dbc);St(_0x1a7709);}},jt=function(_0x5d9eae){return function(..._0x205c3a){L(_0x5d9eae,..._0x205c3a);};},Ii=function(..._0x34c902){const _0x44ef9c='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x34c902);Ze['error'](_0x44ef9c);},ae=function(..._0x415d82){const _0x2f1f2c='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x415d82);throw Ze['error'](_0x2f1f2c),new Error(_0x2f1f2c);},U=function(..._0x8d4922){const _0x27ed83='FIREBASE\x20WARNING:\x20'+zt(..._0x8d4922);Ze['warn'](_0x27ed83);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x339cf7){return typeof _0x339cf7=='number'&&(_0x339cf7!==_0x339cf7||_0x339cf7===Number['POSITIVE_INFINITY']||_0x339cf7===Number['NEGATIVE_INFINITY']);},Gl=function(_0x55dd0c){if(document['readyState']==='complete')_0x55dd0c();else{let _0x3ff980=!0x1;const _0x5b1811=function(){if(!document['body']){setTimeout(_0x5b1811,Math['floor'](0xa));return;}_0x3ff980||(_0x3ff980=!0x0,_0x55dd0c());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x5b1811,!0x1),window['addEventListener']('load',_0x5b1811,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x5b1811();}),window['attachEvent']('onload',_0x5b1811));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x1e2dec,_0x22c4ee){if(_0x1e2dec===_0x22c4ee)return 0x0;if(_0x1e2dec===We||_0x22c4ee===we)return-0x1;if(_0x22c4ee===We||_0x1e2dec===we)return 0x1;{const _0x184056=Gs(_0x1e2dec),_0x55f0b3=Gs(_0x22c4ee);return _0x184056!==null?_0x55f0b3!==null?_0x184056-_0x55f0b3===0x0?_0x1e2dec['length']-_0x22c4ee['length']:_0x184056-_0x55f0b3:-0x1:_0x55f0b3!==null?0x1:_0x1e2dec<_0x22c4ee?-0x1:0x1;}},ql=function(_0x1dd4db,_0x22020b){return _0x1dd4db===_0x22020b?0x0:_0x1dd4db<_0x22020b?-0x1:0x1;},vt=function(_0x537d5b,_0x1e69c4){if(_0x1e69c4&&_0x537d5b in _0x1e69c4)return _0x1e69c4[_0x537d5b];throw new Error('Missing\x20required\x20key\x20('+_0x537d5b+')\x20in\x20object:\x20'+O(_0x1e69c4));},$i=function(_0xe6e215){if(typeof _0xe6e215!='object'||_0xe6e215===null)return O(_0xe6e215);const _0x5b7293=[];for(const _0x45ea3b in _0xe6e215)_0x5b7293['push'](_0x45ea3b);_0x5b7293['sort']();let _0x3c55cd='{';for(let _0x1631ee=0x0;_0x1631ee<_0x5b7293['length'];_0x1631ee++)_0x1631ee!==0x0&&(_0x3c55cd+=','),_0x3c55cd+=O(_0x5b7293[_0x1631ee]),_0x3c55cd+=':',_0x3c55cd+=$i(_0xe6e215[_0x5b7293[_0x1631ee]]);return _0x3c55cd+='}',_0x3c55cd;},oo=function(_0xcee9ce,_0x10e81a){const _0x311031=_0xcee9ce['length'];if(_0x311031<=_0x10e81a)return[_0xcee9ce];const _0x2caf05=[];for(let _0x408c84=0x0;_0x408c84<_0x311031;_0x408c84+=_0x10e81a)_0x408c84+_0x10e81a>_0x311031?_0x2caf05['push'](_0xcee9ce['substring'](_0x408c84,_0x311031)):_0x2caf05['push'](_0xcee9ce['substring'](_0x408c84,_0x408c84+_0x10e81a));return _0x2caf05;};function x(_0x2e6672,_0x2c2fea){for(const _0x4e56ba in _0x2e6672)_0x2e6672['hasOwnProperty'](_0x4e56ba)&&_0x2c2fea(_0x4e56ba,_0x2e6672[_0x4e56ba]);}const ao=function(_0x532db5){f(!xn(_0x532db5),'Invalid\x20JSON\x20number');const _0x343371=0xb,_0x2f9380=0x34,_0x1cb412=(0x1<<_0x343371-0x1)-0x1;let _0x1cc14e,_0x506b94,_0x314c9f,_0x2d2c9b,_0x28d251;_0x532db5===0x0?(_0x506b94=0x0,_0x314c9f=0x0,_0x1cc14e=0x1/_0x532db5===-0x1/0x0?0x1:0x0):(_0x1cc14e=_0x532db5<0x0,_0x532db5=Math['abs'](_0x532db5),_0x532db5>=Math['pow'](0x2,0x1-_0x1cb412)?(_0x2d2c9b=Math['min'](Math['floor'](Math['log'](_0x532db5)/Math['LN2']),_0x1cb412),_0x506b94=_0x2d2c9b+_0x1cb412,_0x314c9f=Math['round'](_0x532db5*Math['pow'](0x2,_0x2f9380-_0x2d2c9b)-Math['pow'](0x2,_0x2f9380))):(_0x506b94=0x0,_0x314c9f=Math['round'](_0x532db5/Math['pow'](0x2,0x1-_0x1cb412-_0x2f9380))));const _0x5dac7a=[];for(_0x28d251=_0x2f9380;_0x28d251;_0x28d251-=0x1)_0x5dac7a['push'](_0x314c9f%0x2?0x1:0x0),_0x314c9f=Math['floor'](_0x314c9f/0x2);for(_0x28d251=_0x343371;_0x28d251;_0x28d251-=0x1)_0x5dac7a['push'](_0x506b94%0x2?0x1:0x0),_0x506b94=Math['floor'](_0x506b94/0x2);_0x5dac7a['push'](_0x1cc14e?0x1:0x0),_0x5dac7a['reverse']();const _0x25b69f=_0x5dac7a['join']('');let _0x73cdf3='';for(_0x28d251=0x0;_0x28d251<0x40;_0x28d251+=0x8){let _0x39fb79=parseInt(_0x25b69f['substr'](_0x28d251,0x8),0x2)['toString'](0x10);_0x39fb79['length']===0x1&&(_0x39fb79='0'+_0x39fb79),_0x73cdf3=_0x73cdf3+_0x39fb79;}return _0x73cdf3['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0xce3071,_0x17ab97){let _0x2c4b51='Unknown\x20Error';_0xce3071==='too_big'?_0x2c4b51='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0xce3071==='permission_denied'?_0x2c4b51='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0xce3071==='unavailable'&&(_0x2c4b51='The\x20service\x20is\x20unavailable');const _0x35480c=new Error(_0xce3071+'\x20at\x20'+_0x17ab97['_path']['toString']()+':\x20'+_0x2c4b51);return _0x35480c['code']=_0xce3071['toUpperCase'](),_0x35480c;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x520584){if(Yl['test'](_0x520584)){const _0x430424=Number(_0x520584);if(_0x430424>=Ql&&_0x430424<=Jl)return _0x430424;}return null;},ft=function(_0x593d1e){try{_0x593d1e();}catch(_0x2d4bde){setTimeout(()=>{const _0x4033cd=_0x2d4bde['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x4033cd),_0x2d4bde;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0xe7a614,_0x107f72){const _0x3c26f9=setTimeout(_0xe7a614,_0x107f72);return typeof _0x3c26f9=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x3c26f9):typeof _0x3c26f9=='object'&&_0x3c26f9['unref']&&_0x3c26f9['unref'](),_0x3c26f9;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x48b8a1,_0x19a84d){this['appCheckProvider']=_0x19a84d,this['appName']=_0x48b8a1['name'],$(_0x48b8a1)&&_0x48b8a1['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x48b8a1['settings']['appCheckToken']),this['appCheck']=_0x19a84d==null?void 0x0:_0x19a84d['getImmediate']({'optional':!0x0}),this['appCheck']||_0x19a84d==null||_0x19a84d['get']()['then'](_0x188308=>this['appCheck']=_0x188308);}['getToken'](_0x333a2e){if(this['serverAppAppCheckToken']){if(_0x333a2e)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x333a2e):new Promise((_0x2a6acc,_0x2191af)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x333a2e)['then'](_0x2a6acc,_0x2191af):_0x2a6acc(null);},0x0);});}['addTokenChangeListener'](_0x103417){var _0x5c927a;(_0x5c927a=this['appCheckProvider'])==null||_0x5c927a['get']()['then'](_0x1ad000=>_0x1ad000['addTokenListener'](_0x103417));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x1946dc,_0x1325c3,_0x476b27){this['appName_']=_0x1946dc,this['firebaseOptions_']=_0x1325c3,this['authProvider_']=_0x476b27,this['auth_']=null,this['auth_']=_0x476b27['getImmediate']({'optional':!0x0}),this['auth_']||_0x476b27['onInit'](_0x4103d6=>this['auth_']=_0x4103d6);}['getToken'](_0x42babd){return this['auth_']?this['auth_']['getToken'](_0x42babd)['catch'](_0x2d9057=>_0x2d9057&&_0x2d9057['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x2d9057)):new Promise((_0x2c7e74,_0x4d4971)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x42babd)['then'](_0x2c7e74,_0x4d4971):_0x2c7e74(null);},0x0);});}['addTokenChangeListener'](_0x49a97a){this['auth_']?this['auth_']['addAuthTokenListener'](_0x49a97a):this['authProvider_']['get']()['then'](_0x59eb47=>_0x59eb47['addAuthTokenListener'](_0x49a97a));}['removeTokenChangeListener'](_0x2a9e90){this['authProvider_']['get']()['then'](_0x4c37d1=>_0x4c37d1['removeAuthTokenListener'](_0x2a9e90));}['notifyForInvalidToken'](){let _0x5de13f='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x5de13f+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x5de13f+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x5de13f+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x5de13f);}}class an{constructor(_0x5bf9b5){this['accessToken']=_0x5bf9b5;}['getToken'](_0x116b9e){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x5c665a){_0x5c665a(this['accessToken']);}['removeTokenChangeListener'](_0x32336b){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x17662b,_0x18ea9c,_0x49058c,_0x1e886b,_0x34fe30=!0x1,_0x518a63='',_0x1db98a=!0x1,_0x3e4c1b=!0x1,_0x5b5a28=null){this['secure']=_0x18ea9c,this['namespace']=_0x49058c,this['webSocketOnly']=_0x1e886b,this['nodeAdmin']=_0x34fe30,this['persistenceKey']=_0x518a63,this['includeNamespaceInQueryParams']=_0x1db98a,this['isUsingEmulator']=_0x3e4c1b,this['emulatorOptions']=_0x5b5a28,this['_host']=_0x17662b['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x17662b)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x2d2c49){_0x2d2c49!==this['internalHost']&&(this['internalHost']=_0x2d2c49,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x5cc5d8=this['toURLString']();return this['persistenceKey']&&(_0x5cc5d8+='<'+this['persistenceKey']+'>'),_0x5cc5d8;}['toURLString'](){const _0x4330b0=this['secure']?'https://':'http://',_0x27e242=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x4330b0+this['host']+'/'+_0x27e242;}}function th(_0x49168e){return _0x49168e['host']!==_0x49168e['internalHost']||_0x49168e['isCustomHost']()||_0x49168e['includeNamespaceInQueryParams'];}function vo(_0x4c156f,_0x28fffd,_0x115bf3){f(typeof _0x28fffd=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x115bf3=='object','typeof\x20params\x20must\x20==\x20object');let _0x40a620;if(_0x28fffd===go)_0x40a620=(_0x4c156f['secure']?'wss://':'ws://')+_0x4c156f['internalHost']+'/.ws?';else{if(_0x28fffd===mo)_0x40a620=(_0x4c156f['secure']?'https://':'http://')+_0x4c156f['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x28fffd);}th(_0x4c156f)&&(_0x115bf3['ns']=_0x4c156f['namespace']);const _0x7d0fd3=[];return x(_0x115bf3,(_0x200cc9,_0x35bb7d)=>{_0x7d0fd3['push'](_0x200cc9+'='+_0x35bb7d);}),_0x40a620+_0x7d0fd3['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x9d34a7,_0x405d76=0x1){Q(this['counters_'],_0x9d34a7)||(this['counters_'][_0x9d34a7]=0x0),this['counters_'][_0x9d34a7]+=_0x405d76;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x33854b){const _0x1dbb77=_0x33854b['toString']();return oi[_0x1dbb77]||(oi[_0x1dbb77]=new nh()),oi[_0x1dbb77];}function ih(_0x28cb5f,_0x21f190){const _0x5239b6=_0x28cb5f['toString']();return ai[_0x5239b6]||(ai[_0x5239b6]=_0x21f190()),ai[_0x5239b6];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x4cb92a){this['onMessage_']=_0x4cb92a,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x114240,_0x5113df){this['closeAfterResponse']=_0x114240,this['onClose']=_0x5113df,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x9d7f62,_0x2cf00e){for(this['pendingResponses'][_0x9d7f62]=_0x2cf00e;this['pendingResponses'][this['currentResponseNum']];){const _0x3111da=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x1361b0=0x0;_0x1361b0<_0x3111da['length'];++_0x1361b0)_0x3111da[_0x1361b0]&&ft(()=>{this['onMessage_'](_0x3111da[_0x1361b0]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x12fb49,_0x54d7cf,_0x45127d,_0x2b2e8b,_0x528803,_0x20de1a,_0x25e8e1){this['connId']=_0x12fb49,this['repoInfo']=_0x54d7cf,this['applicationId']=_0x45127d,this['appCheckToken']=_0x2b2e8b,this['authToken']=_0x528803,this['transportSessionId']=_0x20de1a,this['lastSessionId']=_0x25e8e1,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x12fb49),this['stats_']=qi(_0x54d7cf),this['urlFn']=_0x11d88b=>(this['appCheckToken']&&(_0x11d88b[wi]=this['appCheckToken']),vo(_0x54d7cf,mo,_0x11d88b));}['open'](_0x37a8bd,_0x5cd6e3){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x5cd6e3,this['myPacketOrderer']=new sh(_0x37a8bd),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x3fd3a0)=>{const [_0x2f5014,_0x27c945,_0x5ec714,_0x345b91,_0x89c66d]=_0x3fd3a0;if(this['incrementIncomingBytes_'](_0x3fd3a0),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x2f5014===qs)this['id']=_0x27c945,this['password']=_0x5ec714;else{if(_0x2f5014===rh)_0x27c945?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x27c945,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x2f5014);}}},(..._0x1e3b2d)=>{const [_0x4474a8,_0x41b71e]=_0x1e3b2d;this['incrementIncomingBytes_'](_0x1e3b2d),this['myPacketOrderer']['handleResponse'](_0x4474a8,_0x41b71e);},()=>{this['onClosed_']();},this['urlFn']);const _0x28712b={};_0x28712b[qs]='t',_0x28712b[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x28712b[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x28712b[co]=Gi,this['transportSessionId']&&(_0x28712b[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x28712b[po]=this['lastSessionId']),this['applicationId']&&(_0x28712b[_o]=this['applicationId']),this['appCheckToken']&&(_0x28712b[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x28712b[ho]=uo);const _0x1b7d1c=this['urlFn'](_0x28712b);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x1b7d1c),this['scriptTagHolder']['addTag'](_0x1b7d1c,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0xbf76ff){const _0x2e5d56=O(_0xbf76ff);this['bytesSent']+=_0x2e5d56['length'],this['stats_']['incrementCounter']('bytes_sent',_0x2e5d56['length']);const _0x11df1f=$r(_0x2e5d56),_0x1683a9=oo(_0x11df1f,fh);for(let _0x55b733=0x0;_0x55b733<_0x1683a9['length'];_0x55b733++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x1683a9['length'],_0x1683a9[_0x55b733]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x1e9084,_0x473601){this['myDisconnFrame']=document['createElement']('iframe');const _0x273ef2={};_0x273ef2[dh]='t',_0x273ef2[Eo]=_0x1e9084,_0x273ef2[Io]=_0x473601,this['myDisconnFrame']['src']=this['urlFn'](_0x273ef2),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x26043a){const _0x26739c=O(_0x26043a)['length'];this['bytesReceived']+=_0x26739c,this['stats_']['incrementCounter']('bytes_received',_0x26739c);}}class zi{constructor(_0x2ffbca,_0x129446,_0x2f915b,_0x5d5390){this['onDisconnect']=_0x2f915b,this['urlFn']=_0x5d5390,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x2ffbca,window[ah+this['uniqueCallbackIdentifier']]=_0x129446,this['myIFrame']=zi['createIFrame_']();let _0x1d6356='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x1d6356='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x9da3b8='<html><body>'+_0x1d6356+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x9da3b8),this['myIFrame']['doc']['close']();}catch(_0x3c3dd3){L('frame\x20writing\x20exception'),_0x3c3dd3['stack']&&L(_0x3c3dd3['stack']),L(_0x3c3dd3);}}}static['createIFrame_'](){const _0x4e7118=document['createElement']('iframe');if(_0x4e7118['style']['display']='none',document['body']){document['body']['appendChild'](_0x4e7118);try{_0x4e7118['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x581d91=document['domain'];_0x4e7118['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x581d91+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x4e7118['contentDocument']?_0x4e7118['doc']=_0x4e7118['contentDocument']:_0x4e7118['contentWindow']?_0x4e7118['doc']=_0x4e7118['contentWindow']['document']:_0x4e7118['document']&&(_0x4e7118['doc']=_0x4e7118['document']),_0x4e7118;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x3e053f=this['onDisconnect'];_0x3e053f&&(this['onDisconnect']=null,_0x3e053f());}['startLongPoll'](_0x6d1836,_0x2e93c9){for(this['myID']=_0x6d1836,this['myPW']=_0x2e93c9,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x469f36={};_0x469f36[Eo]=this['myID'],_0x469f36[Io]=this['myPW'],_0x469f36[wo]=this['currentSerial'];let _0x30b30f=this['urlFn'](_0x469f36),_0x5f19bf='',_0x106c33=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x5f19bf['length']<=Co;){const _0x2c6a5d=this['pendingSegs']['shift']();_0x5f19bf=_0x5f19bf+'&'+lh+_0x106c33+'='+_0x2c6a5d['seg']+'&'+hh+_0x106c33+'='+_0x2c6a5d['ts']+'&'+uh+_0x106c33+'='+_0x2c6a5d['d'],_0x106c33++;}return _0x30b30f=_0x30b30f+_0x5f19bf,this['addLongPollTag_'](_0x30b30f,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x302d9f,_0x261c11,_0x3e9b67){this['pendingSegs']['push']({'seg':_0x302d9f,'ts':_0x261c11,'d':_0x3e9b67}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x2be187,_0x2db4fa){this['outstandingRequests']['add'](_0x2db4fa);const _0x2842f0=()=>{this['outstandingRequests']['delete'](_0x2db4fa),this['newRequest_']();},_0x124c11=setTimeout(_0x2842f0,Math['floor'](ph)),_0x112df7=()=>{clearTimeout(_0x124c11),_0x2842f0();};this['addTag'](_0x2be187,_0x112df7);}['addTag'](_0x327158,_0x454784){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x16fc16=this['myIFrame']['doc']['createElement']('script');_0x16fc16['type']='text/javascript',_0x16fc16['async']=!0x0,_0x16fc16['src']=_0x327158,_0x16fc16['onload']=_0x16fc16['onreadystatechange']=function(){const _0x4201df=_0x16fc16['readyState'];(!_0x4201df||_0x4201df==='loaded'||_0x4201df==='complete')&&(_0x16fc16['onload']=_0x16fc16['onreadystatechange']=null,_0x16fc16['parentNode']&&_0x16fc16['parentNode']['removeChild'](_0x16fc16),_0x454784());},_0x16fc16['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x327158),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x16fc16);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x44dea8,_0x474229,_0x5df25a,_0x1e6028,_0x38b462,_0x233801,_0x2370b1){this['connId']=_0x44dea8,this['applicationId']=_0x5df25a,this['appCheckToken']=_0x1e6028,this['authToken']=_0x38b462,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x474229),this['connURL']=q['connectionURL_'](_0x474229,_0x233801,_0x2370b1,_0x1e6028,_0x5df25a),this['nodeAdmin']=_0x474229['nodeAdmin'];}static['connectionURL_'](_0x58134b,_0x364193,_0x7200,_0xe364de,_0x1930c8){const _0x3a6d5b={};return _0x3a6d5b[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x3a6d5b[ho]=uo),_0x364193&&(_0x3a6d5b[lo]=_0x364193),_0x7200&&(_0x3a6d5b[po]=_0x7200),_0xe364de&&(_0x3a6d5b[wi]=_0xe364de),_0x1930c8&&(_0x3a6d5b[_o]=_0x1930c8),vo(_0x58134b,go,_0x3a6d5b);}['open'](_0x41c0e5,_0x5ae121){this['onDisconnect']=_0x5ae121,this['onMessage']=_0x41c0e5,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x531336;_c(),this['mySock']=new gn(this['connURL'],[],_0x531336);}catch(_0x58cda9){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x4fdb5c=_0x58cda9['message']||_0x58cda9['data'];_0x4fdb5c&&this['log_'](_0x4fdb5c),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x2b0c22=>{this['handleIncomingFrame'](_0x2b0c22);},this['mySock']['onerror']=_0x3c0307=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x43cc73=_0x3c0307['message']||_0x3c0307['data'];_0x43cc73&&this['log_'](_0x43cc73),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x504cd5=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x2c4e96=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x4f530b=navigator['userAgent']['match'](_0x2c4e96);_0x4f530b&&_0x4f530b['length']>0x1&&parseFloat(_0x4f530b[0x1])<4.4&&(_0x504cd5=!0x0);}return!_0x504cd5&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x286a39){if(this['frames']['push'](_0x286a39),this['frames']['length']===this['totalFrames']){const _0xe595e3=this['frames']['join']('');this['frames']=null;const _0x2249fc=Nt(_0xe595e3);this['onMessage'](_0x2249fc);}}['handleNewFrameCount_'](_0x4ae5f8){this['totalFrames']=_0x4ae5f8,this['frames']=[];}['extractFrameCount_'](_0x105835){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x105835['length']<=0x6){const _0x7dc734=Number(_0x105835);if(!isNaN(_0x7dc734))return this['handleNewFrameCount_'](_0x7dc734),null;}return this['handleNewFrameCount_'](0x1),_0x105835;}['handleIncomingFrame'](_0x2ddcfd){if(this['mySock']===null)return;const _0x562aa8=_0x2ddcfd['data'];if(this['bytesReceived']+=_0x562aa8['length'],this['stats_']['incrementCounter']('bytes_received',_0x562aa8['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x562aa8);else{const _0x277914=this['extractFrameCount_'](_0x562aa8);_0x277914!==null&&this['appendFrame_'](_0x277914);}}['send'](_0x5dc9f5){this['resetKeepAlive']();const _0x198eb9=O(_0x5dc9f5);this['bytesSent']+=_0x198eb9['length'],this['stats_']['incrementCounter']('bytes_sent',_0x198eb9['length']);const _0x277e49=oo(_0x198eb9,gh);_0x277e49['length']>0x1&&this['sendString_'](String(_0x277e49['length']));for(let _0x168f45=0x0;_0x168f45<_0x277e49['length'];_0x168f45++)this['sendString_'](_0x277e49[_0x168f45]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x4a2a67){try{this['mySock']['send'](_0x4a2a67);}catch(_0x3b9276){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x3b9276['message']||_0x3b9276['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x4b2acb){this['initTransports_'](_0x4b2acb);}['initTransports_'](_0x904187){const _0x5145b=q&&q['isAvailable']();let _0x481586=_0x5145b&&!q['previouslyFailed']();if(_0x904187['webSocketOnly']&&(_0x5145b||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x481586=!0x0),_0x481586)this['transports_']=[q];else{const _0x37ddef=this['transports_']=[];for(const _0x4e2509 of Dt['ALL_TRANSPORTS'])_0x4e2509&&_0x4e2509['isAvailable']()&&_0x37ddef['push'](_0x4e2509);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x3eaf25,_0x3ca523,_0x45b520,_0x117c10,_0x2686a0,_0x5dcfb5,_0x9e2a3d,_0x1c6b94,_0x4e211b,_0x61fa4a){this['id']=_0x3eaf25,this['repoInfo_']=_0x3ca523,this['applicationId_']=_0x45b520,this['appCheckToken_']=_0x117c10,this['authToken_']=_0x2686a0,this['onMessage_']=_0x5dcfb5,this['onReady_']=_0x9e2a3d,this['onDisconnect_']=_0x1c6b94,this['onKill_']=_0x4e211b,this['lastSessionId']=_0x61fa4a,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x3ca523),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x264ba3=this['transportManager_']['initialTransport']();this['conn_']=new _0x264ba3(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x264ba3['responsesRequiredToBeHealthy']||0x0;const _0x13acfe=this['connReceiver_'](this['conn_']),_0x77e22b=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x13acfe,_0x77e22b);},Math['floor'](0x0));const _0x4c77b2=_0x264ba3['healthyTimeout']||0x0;_0x4c77b2>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x4c77b2)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x8987f8){return _0x58c8e1=>{_0x8987f8===this['conn_']?this['onConnectionLost_'](_0x58c8e1):_0x8987f8===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x2e75fa){return _0x29ed38=>{this['state_']!==0x2&&(_0x2e75fa===this['rx_']?this['onPrimaryMessageReceived_'](_0x29ed38):_0x2e75fa===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x29ed38):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x278a3a){const _0x3f4f2a={'t':'d','d':_0x278a3a};this['sendData_'](_0x3f4f2a);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x590be4){if(ci in _0x590be4){const _0x19cc34=_0x590be4[ci];_0x19cc34===Ys?this['upgradeIfSecondaryHealthy_']():_0x19cc34===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x19cc34===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x48d2b2){const _0x541b57=vt('t',_0x48d2b2),_0x3c3929=vt('d',_0x48d2b2);if(_0x541b57==='c')this['onSecondaryControl_'](_0x3c3929);else{if(_0x541b57==='d')this['pendingDataMessages']['push'](_0x3c3929);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x541b57);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x5dd6bf){const _0x58bcdc=vt('t',_0x5dd6bf),_0x1c3605=vt('d',_0x5dd6bf);_0x58bcdc==='c'?this['onControl_'](_0x1c3605):_0x58bcdc==='d'&&this['onDataMessage_'](_0x1c3605);}['onDataMessage_'](_0x250759){this['onPrimaryResponse_'](),this['onMessage_'](_0x250759);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x5c696c){const _0xccdf8b=vt(ci,_0x5c696c);if(zs in _0x5c696c){const _0x51f601=_0x5c696c[zs];if(_0xccdf8b===Th){const _0x3fea7d={..._0x51f601};this['repoInfo_']['isUsingEmulator']&&(_0x3fea7d['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x3fea7d);}else{if(_0xccdf8b===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x5752bf=0x0;_0x5752bf<this['pendingDataMessages']['length'];++_0x5752bf)this['onDataMessage_'](this['pendingDataMessages'][_0x5752bf]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0xccdf8b===wh?this['onConnectionShutdown_'](_0x51f601):_0xccdf8b===js?this['onReset_'](_0x51f601):_0xccdf8b===Ch?Ii('Server\x20Error:\x20'+_0x51f601):_0xccdf8b===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0xccdf8b);}}}['onHandshake_'](_0x59c03e){const _0x5514b2=_0x59c03e['ts'],_0x2b7db8=_0x59c03e['v'],_0x4d3dc5=_0x59c03e['h'];this['sessionId']=_0x59c03e['s'],this['repoInfo_']['host']=_0x4d3dc5,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x5514b2),Gi!==_0x2b7db8&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x4d110f=this['transportManager_']['upgradeTransport']();_0x4d110f&&this['startUpgrade_'](_0x4d110f);}['startUpgrade_'](_0x6d3472){this['secondaryConn_']=new _0x6d3472(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x6d3472['responsesRequiredToBeHealthy']||0x0;const _0x406188=this['connReceiver_'](this['secondaryConn_']),_0x16121f=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x406188,_0x16121f),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x19b5da){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x19b5da),this['repoInfo_']['host']=_0x19b5da,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x9f6bda,_0x45e918){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x9f6bda,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x45e918,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x2d63f5=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x2d63f5||this['rx_']===_0x2d63f5)&&this['close']();}['onConnectionLost_'](_0x52f7b6){this['conn_']=null,!_0x52f7b6&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x297d74){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x297d74),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x3e14b1){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x3e14b1);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x452967,_0x21295e,_0x41503d,_0xca3cf1){}['merge'](_0x48055d,_0x400205,_0x1cbd60,_0x2bb2fe){}['refreshAuthToken'](_0x1eeab6){}['refreshAppCheckToken'](_0x22f772){}['onDisconnectPut'](_0x2697ea,_0x281cf6,_0x4f28a2){}['onDisconnectMerge'](_0x1f624d,_0x160749,_0x25de62){}['onDisconnectCancel'](_0x34cde8,_0x4e3a7f){}['reportStats'](_0x37ee05){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x1a8ac5){this['allowedEvents_']=_0x1a8ac5,this['listeners_']={},f(Array['isArray'](_0x1a8ac5)&&_0x1a8ac5['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x14e620,..._0x275788){if(Array['isArray'](this['listeners_'][_0x14e620])){const _0x4157a4=[...this['listeners_'][_0x14e620]];for(let _0x327739=0x0;_0x327739<_0x4157a4['length'];_0x327739++)_0x4157a4[_0x327739]['callback']['apply'](_0x4157a4[_0x327739]['context'],_0x275788);}}['on'](_0x343f5a,_0x211248,_0xebd81c){this['validateEventType_'](_0x343f5a),this['listeners_'][_0x343f5a]=this['listeners_'][_0x343f5a]||[],this['listeners_'][_0x343f5a]['push']({'callback':_0x211248,'context':_0xebd81c});const _0x435939=this['getInitialEvent'](_0x343f5a);_0x435939&&_0x211248['apply'](_0xebd81c,_0x435939);}['off'](_0x52de96,_0x149fa8,_0x5b5004){this['validateEventType_'](_0x52de96);const _0xb6f13f=this['listeners_'][_0x52de96]||[];for(let _0x504f83=0x0;_0x504f83<_0xb6f13f['length'];_0x504f83++)if(_0xb6f13f[_0x504f83]['callback']===_0x149fa8&&(!_0x5b5004||_0x5b5004===_0xb6f13f[_0x504f83]['context'])){_0xb6f13f['splice'](_0x504f83,0x1);return;}}['validateEventType_'](_0x26c840){f(this['allowedEvents_']['find'](_0x2c070c=>_0x2c070c===_0x26c840),'Unknown\x20event:\x20'+_0x26c840);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x1350dd){return f(_0x1350dd==='online','Unknown\x20event\x20type:\x20'+_0x1350dd),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x2e2be4,_0x52f8e4){if(_0x52f8e4===void 0x0){this['pieces_']=_0x2e2be4['split']('/');let _0x572e41=0x0;for(let _0x1fbc8d=0x0;_0x1fbc8d<this['pieces_']['length'];_0x1fbc8d++)this['pieces_'][_0x1fbc8d]['length']>0x0&&(this['pieces_'][_0x572e41]=this['pieces_'][_0x1fbc8d],_0x572e41++);this['pieces_']['length']=_0x572e41,this['pieceNum_']=0x0;}else this['pieces_']=_0x2e2be4,this['pieceNum_']=_0x52f8e4;}['toString'](){let _0xa5f2f0='';for(let _0x1508e6=this['pieceNum_'];_0x1508e6<this['pieces_']['length'];_0x1508e6++)this['pieces_'][_0x1508e6]!==''&&(_0xa5f2f0+='/'+this['pieces_'][_0x1508e6]);return _0xa5f2f0||'/';}}function w(){return new C('');}function y(_0x2812ec){return _0x2812ec['pieceNum_']>=_0x2812ec['pieces_']['length']?null:_0x2812ec['pieces_'][_0x2812ec['pieceNum_']];}function Ce(_0x153836){return _0x153836['pieces_']['length']-_0x153836['pieceNum_'];}function S(_0x5976cc){let _0x286d47=_0x5976cc['pieceNum_'];return _0x286d47<_0x5976cc['pieces_']['length']&&_0x286d47++,new C(_0x5976cc['pieces_'],_0x286d47);}function ji(_0xcfb1ca){return _0xcfb1ca['pieceNum_']<_0xcfb1ca['pieces_']['length']?_0xcfb1ca['pieces_'][_0xcfb1ca['pieces_']['length']-0x1]:null;}function bh(_0x261575){let _0x14c190='';for(let _0x4c501a=_0x261575['pieceNum_'];_0x4c501a<_0x261575['pieces_']['length'];_0x4c501a++)_0x261575['pieces_'][_0x4c501a]!==''&&(_0x14c190+='/'+encodeURIComponent(String(_0x261575['pieces_'][_0x4c501a])));return _0x14c190||'/';}function Mt(_0x42ecf8,_0x29fa7d=0x0){return _0x42ecf8['pieces_']['slice'](_0x42ecf8['pieceNum_']+_0x29fa7d);}function Ro(_0xb5ce54){if(_0xb5ce54['pieceNum_']>=_0xb5ce54['pieces_']['length'])return null;const _0x43d3b5=[];for(let _0x4d359e=_0xb5ce54['pieceNum_'];_0x4d359e<_0xb5ce54['pieces_']['length']-0x1;_0x4d359e++)_0x43d3b5['push'](_0xb5ce54['pieces_'][_0x4d359e]);return new C(_0x43d3b5,0x0);}function k(_0x21f36b,_0x563351){const _0x532c28=[];for(let _0x2b4ffb=_0x21f36b['pieceNum_'];_0x2b4ffb<_0x21f36b['pieces_']['length'];_0x2b4ffb++)_0x532c28['push'](_0x21f36b['pieces_'][_0x2b4ffb]);if(_0x563351 instanceof C){for(let _0x273fd5=_0x563351['pieceNum_'];_0x273fd5<_0x563351['pieces_']['length'];_0x273fd5++)_0x532c28['push'](_0x563351['pieces_'][_0x273fd5]);}else{const _0x5dc190=_0x563351['split']('/');for(let _0x39634f=0x0;_0x39634f<_0x5dc190['length'];_0x39634f++)_0x5dc190[_0x39634f]['length']>0x0&&_0x532c28['push'](_0x5dc190[_0x39634f]);}return new C(_0x532c28,0x0);}function v(_0x22b349){return _0x22b349['pieceNum_']>=_0x22b349['pieces_']['length'];}function F(_0x2540e7,_0x5ba728){const _0x3530d9=y(_0x2540e7),_0x24b56d=y(_0x5ba728);if(_0x3530d9===null)return _0x5ba728;if(_0x3530d9===_0x24b56d)return F(S(_0x2540e7),S(_0x5ba728));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x5ba728+')\x20is\x20not\x20within\x20outerPath\x20('+_0x2540e7+')');}function Rh(_0xb7974b,_0x3de77c){const _0x3d5059=Mt(_0xb7974b,0x0),_0xb823a7=Mt(_0x3de77c,0x0);for(let _0x334d32=0x0;_0x334d32<_0x3d5059['length']&&_0x334d32<_0xb823a7['length'];_0x334d32++){const _0x4010c0=qe(_0x3d5059[_0x334d32],_0xb823a7[_0x334d32]);if(_0x4010c0!==0x0)return _0x4010c0;}return _0x3d5059['length']===_0xb823a7['length']?0x0:_0x3d5059['length']<_0xb823a7['length']?-0x1:0x1;}function Ki(_0x1d1563,_0x112fa0){if(Ce(_0x1d1563)!==Ce(_0x112fa0))return!0x1;for(let _0x42a5e5=_0x1d1563['pieceNum_'],_0x1e3aac=_0x112fa0['pieceNum_'];_0x42a5e5<=_0x1d1563['pieces_']['length'];_0x42a5e5++,_0x1e3aac++)if(_0x1d1563['pieces_'][_0x42a5e5]!==_0x112fa0['pieces_'][_0x1e3aac])return!0x1;return!0x0;}function G(_0x5fb383,_0x296f42){let _0x1ef5eb=_0x5fb383['pieceNum_'],_0x4a1a30=_0x296f42['pieceNum_'];if(Ce(_0x5fb383)>Ce(_0x296f42))return!0x1;for(;_0x1ef5eb<_0x5fb383['pieces_']['length'];){if(_0x5fb383['pieces_'][_0x1ef5eb]!==_0x296f42['pieces_'][_0x4a1a30])return!0x1;++_0x1ef5eb,++_0x4a1a30;}return!0x0;}class Ah{constructor(_0x3a388f,_0x2ba0f8){this['errorPrefix_']=_0x2ba0f8,this['parts_']=Mt(_0x3a388f,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x337c36=0x0;_0x337c36<this['parts_']['length'];_0x337c36++)this['byteLength_']+=Ln(this['parts_'][_0x337c36]);Ao(this);}}function kh(_0x4f0c4d,_0x235af6){_0x4f0c4d['parts_']['length']>0x0&&(_0x4f0c4d['byteLength_']+=0x1),_0x4f0c4d['parts_']['push'](_0x235af6),_0x4f0c4d['byteLength_']+=Ln(_0x235af6),Ao(_0x4f0c4d);}function Ph(_0x3295e3){const _0x4710eb=_0x3295e3['parts_']['pop']();_0x3295e3['byteLength_']-=Ln(_0x4710eb),_0x3295e3['parts_']['length']>0x0&&(_0x3295e3['byteLength_']-=0x1);}function Ao(_0x8b5d70){if(_0x8b5d70['byteLength_']>Zs)throw new Error(_0x8b5d70['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x8b5d70['byteLength_']+').');if(_0x8b5d70['parts_']['length']>Xs)throw new Error(_0x8b5d70['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x8b5d70));}function Oe(_0x5d9a1d){return _0x5d9a1d['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x5d9a1d['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x5417d3,_0x353dd6;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x353dd6='visibilitychange',_0x5417d3='hidden'):typeof document['mozHidden']<'u'?(_0x353dd6='mozvisibilitychange',_0x5417d3='mozHidden'):typeof document['msHidden']<'u'?(_0x353dd6='msvisibilitychange',_0x5417d3='msHidden'):typeof document['webkitHidden']<'u'&&(_0x353dd6='webkitvisibilitychange',_0x5417d3='webkitHidden')),this['visible_']=!0x0,_0x353dd6&&document['addEventListener'](_0x353dd6,()=>{const _0x5c52a9=!document[_0x5417d3];_0x5c52a9!==this['visible_']&&(this['visible_']=_0x5c52a9,this['trigger']('visible',_0x5c52a9));},!0x1);}['getInitialEvent'](_0xaa1389){return f(_0xaa1389==='visible','Unknown\x20event\x20type:\x20'+_0xaa1389),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x9ba51f,_0x355544,_0x4f2798,_0x3cff27,_0x5cea31,_0x4cc5fe,_0x4e4387,_0x575228){if(super(),this['repoInfo_']=_0x9ba51f,this['applicationId_']=_0x355544,this['onDataUpdate_']=_0x4f2798,this['onConnectStatus_']=_0x3cff27,this['onServerInfoUpdate_']=_0x5cea31,this['authTokenProvider_']=_0x4cc5fe,this['appCheckTokenProvider_']=_0x4e4387,this['authOverride_']=_0x575228,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x575228)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x9ba51f['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x4c1a44,_0x5ca663,_0x12e0b9){const _0x4d57c2=++this['requestNumber_'],_0x530329={'r':_0x4d57c2,'a':_0x4c1a44,'b':_0x5ca663};this['log_'](O(_0x530329)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x530329),_0x12e0b9&&(this['requestCBHash_'][_0x4d57c2]=_0x12e0b9);}['get'](_0x27c08b){this['initConnection_']();const _0x571156=new H(),_0x681a37={'action':'g','request':{'p':_0x27c08b['_path']['toString'](),'q':_0x27c08b['_queryObject']},'onComplete':_0x61de76=>{const _0x37fe75=_0x61de76['d'];_0x61de76['s']==='ok'?_0x571156['resolve'](_0x37fe75):_0x571156['reject'](_0x37fe75);}};this['outstandingGets_']['push'](_0x681a37),this['outstandingGetCount_']++;const _0x22f8ad=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x22f8ad),_0x571156['promise'];}['listen'](_0x225b59,_0x398358,_0x449b0c,_0x5a50c6){this['initConnection_']();const _0x26cc35=_0x225b59['_queryIdentifier'],_0x1f6fc4=_0x225b59['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x1f6fc4+'\x20'+_0x26cc35),this['listens']['has'](_0x1f6fc4)||this['listens']['set'](_0x1f6fc4,new Map()),f(_0x225b59['_queryParams']['isDefault']()||!_0x225b59['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x1f6fc4)['has'](_0x26cc35),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x35796c={'onComplete':_0x5a50c6,'hashFn':_0x398358,'query':_0x225b59,'tag':_0x449b0c};this['listens']['get'](_0x1f6fc4)['set'](_0x26cc35,_0x35796c),this['connected_']&&this['sendListen_'](_0x35796c);}['sendGet_'](_0x71efcf){const _0x28a7aa=this['outstandingGets_'][_0x71efcf];this['sendRequest']('g',_0x28a7aa['request'],_0x2789ae=>{delete this['outstandingGets_'][_0x71efcf],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x28a7aa['onComplete']&&_0x28a7aa['onComplete'](_0x2789ae);});}['sendListen_'](_0x553b9c){const _0x511df6=_0x553b9c['query'],_0x43f099=_0x511df6['_path']['toString'](),_0x3f2eac=_0x511df6['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x43f099+'\x20for\x20'+_0x3f2eac);const _0x29dcec={'p':_0x43f099},_0x2f7e91='q';_0x553b9c['tag']&&(_0x29dcec['q']=_0x511df6['_queryObject'],_0x29dcec['t']=_0x553b9c['tag']),_0x29dcec['h']=_0x553b9c['hashFn'](),this['sendRequest'](_0x2f7e91,_0x29dcec,_0x252c94=>{const _0x2e8768=_0x252c94['d'],_0x22b8e0=_0x252c94['s'];se['warnOnListenWarnings_'](_0x2e8768,_0x511df6),(this['listens']['get'](_0x43f099)&&this['listens']['get'](_0x43f099)['get'](_0x3f2eac))===_0x553b9c&&(this['log_']('listen\x20response',_0x252c94),_0x22b8e0!=='ok'&&this['removeListen_'](_0x43f099,_0x3f2eac),_0x553b9c['onComplete']&&_0x553b9c['onComplete'](_0x22b8e0,_0x2e8768));});}static['warnOnListenWarnings_'](_0x1e0f31,_0x1a5907){if(_0x1e0f31&&typeof _0x1e0f31=='object'&&Q(_0x1e0f31,'w')){const _0x22f16d=Le(_0x1e0f31,'w');if(Array['isArray'](_0x22f16d)&&~_0x22f16d['indexOf']('no_index')){const _0x4edb67='\x22.indexOn\x22:\x20\x22'+_0x1a5907['_queryParams']['getIndex']()['toString']()+'\x22',_0x3418ad=_0x1a5907['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x4edb67+'\x20at\x20'+_0x3418ad+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0xfc2757){this['authToken_']=_0xfc2757,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0xfc2757);}['reduceReconnectDelayIfAdminCredential_'](_0x392e21){(_0x392e21&&_0x392e21['length']===0x28||wc(_0x392e21))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x56f74f){this['appCheckToken_']=_0x56f74f,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x44d09e=this['authToken_'],_0x2dbf77=Ic(_0x44d09e)?'auth':'gauth',_0x4175b6={'cred':_0x44d09e};this['authOverride_']===null?_0x4175b6['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x4175b6['authvar']=this['authOverride_']),this['sendRequest'](_0x2dbf77,_0x4175b6,_0x442485=>{const _0x55f613=_0x442485['s'],_0x3f002e=_0x442485['d']||'error';this['authToken_']===_0x44d09e&&(_0x55f613==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x55f613,_0x3f002e));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x4b7f02=>{const _0x23fb90=_0x4b7f02['s'],_0x53b174=_0x4b7f02['d']||'error';_0x23fb90==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x23fb90,_0x53b174);});}['unlisten'](_0x55e3a6,_0x51c418){const _0x1533c2=_0x55e3a6['_path']['toString'](),_0x59e945=_0x55e3a6['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x1533c2+'\x20'+_0x59e945),f(_0x55e3a6['_queryParams']['isDefault']()||!_0x55e3a6['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x1533c2,_0x59e945)&&this['connected_']&&this['sendUnlisten_'](_0x1533c2,_0x59e945,_0x55e3a6['_queryObject'],_0x51c418);}['sendUnlisten_'](_0x14d0b7,_0x4f0b83,_0x2e48e8,_0x4630e0){this['log_']('Unlisten\x20on\x20'+_0x14d0b7+'\x20for\x20'+_0x4f0b83);const _0x13f780={'p':_0x14d0b7},_0x214b84='n';_0x4630e0&&(_0x13f780['q']=_0x2e48e8,_0x13f780['t']=_0x4630e0),this['sendRequest'](_0x214b84,_0x13f780);}['onDisconnectPut'](_0xbe3ab8,_0x30b3b1,_0x417ee1){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0xbe3ab8,_0x30b3b1,_0x417ee1):this['onDisconnectRequestQueue_']['push']({'pathString':_0xbe3ab8,'action':'o','data':_0x30b3b1,'onComplete':_0x417ee1});}['onDisconnectMerge'](_0x22e229,_0x25d05e,_0x3cf5a1){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x22e229,_0x25d05e,_0x3cf5a1):this['onDisconnectRequestQueue_']['push']({'pathString':_0x22e229,'action':'om','data':_0x25d05e,'onComplete':_0x3cf5a1});}['onDisconnectCancel'](_0x95c0b7,_0x4a7c7b){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x95c0b7,null,_0x4a7c7b):this['onDisconnectRequestQueue_']['push']({'pathString':_0x95c0b7,'action':'oc','data':null,'onComplete':_0x4a7c7b});}['sendOnDisconnect_'](_0x5089ee,_0x333910,_0x4e9c67,_0x476f60){const _0x4da15a={'p':_0x333910,'d':_0x4e9c67};this['log_']('onDisconnect\x20'+_0x5089ee,_0x4da15a),this['sendRequest'](_0x5089ee,_0x4da15a,_0x1f535a=>{_0x476f60&&setTimeout(()=>{_0x476f60(_0x1f535a['s'],_0x1f535a['d']);},Math['floor'](0x0));});}['put'](_0x42c0ac,_0x29474a,_0x35d26f,_0x589d66){this['putInternal']('p',_0x42c0ac,_0x29474a,_0x35d26f,_0x589d66);}['merge'](_0x4d9b22,_0x31e490,_0x45c4d7,_0x4d6ed3){this['putInternal']('m',_0x4d9b22,_0x31e490,_0x45c4d7,_0x4d6ed3);}['putInternal'](_0x4f03f3,_0x32cecb,_0xee2fd4,_0x3b5bae,_0x54a9b8){this['initConnection_']();const _0x5aefcb={'p':_0x32cecb,'d':_0xee2fd4};_0x54a9b8!==void 0x0&&(_0x5aefcb['h']=_0x54a9b8),this['outstandingPuts_']['push']({'action':_0x4f03f3,'request':_0x5aefcb,'onComplete':_0x3b5bae}),this['outstandingPutCount_']++;const _0xaab318=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0xaab318):this['log_']('Buffering\x20put:\x20'+_0x32cecb);}['sendPut_'](_0x20e329){const _0x45946f=this['outstandingPuts_'][_0x20e329]['action'],_0x1ee746=this['outstandingPuts_'][_0x20e329]['request'],_0x314c36=this['outstandingPuts_'][_0x20e329]['onComplete'];this['outstandingPuts_'][_0x20e329]['queued']=this['connected_'],this['sendRequest'](_0x45946f,_0x1ee746,_0x19ff09=>{this['log_'](_0x45946f+'\x20response',_0x19ff09),delete this['outstandingPuts_'][_0x20e329],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x314c36&&_0x314c36(_0x19ff09['s'],_0x19ff09['d']);});}['reportStats'](_0x242882){if(this['connected_']){const _0x21258c={'c':_0x242882};this['log_']('reportStats',_0x21258c),this['sendRequest']('s',_0x21258c,_0x31c42b=>{if(_0x31c42b['s']!=='ok'){const _0x148ae1=_0x31c42b['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x148ae1);}});}}['onDataMessage_'](_0x53b241){if('r'in _0x53b241){this['log_']('from\x20server:\x20'+O(_0x53b241));const _0x700693=_0x53b241['r'],_0x5bc350=this['requestCBHash_'][_0x700693];_0x5bc350&&(delete this['requestCBHash_'][_0x700693],_0x5bc350(_0x53b241['b']));}else{if('error'in _0x53b241)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x53b241['error'];'a'in _0x53b241&&this['onDataPush_'](_0x53b241['a'],_0x53b241['b']);}}['onDataPush_'](_0x32c1d9,_0x2e862c){this['log_']('handleServerMessage',_0x32c1d9,_0x2e862c),_0x32c1d9==='d'?this['onDataUpdate_'](_0x2e862c['p'],_0x2e862c['d'],!0x1,_0x2e862c['t']):_0x32c1d9==='m'?this['onDataUpdate_'](_0x2e862c['p'],_0x2e862c['d'],!0x0,_0x2e862c['t']):_0x32c1d9==='c'?this['onListenRevoked_'](_0x2e862c['p'],_0x2e862c['q']):_0x32c1d9==='ac'?this['onAuthRevoked_'](_0x2e862c['s'],_0x2e862c['d']):_0x32c1d9==='apc'?this['onAppCheckRevoked_'](_0x2e862c['s'],_0x2e862c['d']):_0x32c1d9==='sd'?this['onSecurityDebugPacket_'](_0x2e862c):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x32c1d9)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x2d3703,_0x4db0d6){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x2d3703),this['lastSessionId']=_0x4db0d6,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x41fc62){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x41fc62));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x2ba6a5){_0x2ba6a5&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x2ba6a5;}['onOnline_'](_0x49ee7f){_0x49ee7f?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x2d3f4c=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x141fb9=Math['max'](0x0,this['reconnectDelay_']-_0x2d3f4c);_0x141fb9=Math['random']()*_0x141fb9,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x141fb9+'ms'),this['scheduleConnect_'](_0x141fb9),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x3c6197=this['onDataMessage_']['bind'](this),_0x26b28d=this['onReady_']['bind'](this),_0x459d79=this['onRealtimeDisconnect_']['bind'](this),_0x3b2b85=this['id']+':'+se['nextConnectionId_']++,_0x4ce82d=this['lastSessionId'];let _0x28f92c=!0x1,_0x239be7=null;const _0x1fa9b7=function(){_0x239be7?_0x239be7['close']():(_0x28f92c=!0x0,_0x459d79());},_0x4907ef=function(_0x564b81){f(_0x239be7,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x239be7['sendRequest'](_0x564b81);};this['realtime_']={'close':_0x1fa9b7,'sendRequest':_0x4907ef};const _0x322a10=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x1d2437,_0x5ca40b]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x322a10),this['appCheckTokenProvider_']['getToken'](_0x322a10)]);_0x28f92c?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x1d2437&&_0x1d2437['accessToken'],this['appCheckToken_']=_0x5ca40b&&_0x5ca40b['token'],_0x239be7=new Sh(_0x3b2b85,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x3c6197,_0x26b28d,_0x459d79,_0x4b1787=>{U(_0x4b1787+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x4ce82d));}catch(_0x4511aa){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x4511aa),_0x28f92c||(this['repoInfo_']['nodeAdmin']&&U(_0x4511aa),_0x1fa9b7());}}}['interrupt'](_0x203bab){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x203bab),this['interruptReasons_'][_0x203bab]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x4ea372){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x4ea372),delete this['interruptReasons_'][_0x4ea372],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x8fcc1f){const _0x549dec=_0x8fcc1f-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x549dec});}['cancelSentTransactions_'](){for(let _0x1ea4e8=0x0;_0x1ea4e8<this['outstandingPuts_']['length'];_0x1ea4e8++){const _0xddfa3f=this['outstandingPuts_'][_0x1ea4e8];_0xddfa3f&&'h'in _0xddfa3f['request']&&_0xddfa3f['queued']&&(_0xddfa3f['onComplete']&&_0xddfa3f['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x1ea4e8],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x477110,_0x23626b){let _0x55a9c3;_0x23626b?_0x55a9c3=_0x23626b['map'](_0x498ab8=>$i(_0x498ab8))['join']('$'):_0x55a9c3='default';const _0x30758f=this['removeListen_'](_0x477110,_0x55a9c3);_0x30758f&&_0x30758f['onComplete']&&_0x30758f['onComplete']('permission_denied');}['removeListen_'](_0x44704f,_0x5cba03){const _0x22ae6d=new C(_0x44704f)['toString']();let _0x16c9a5;if(this['listens']['has'](_0x22ae6d)){const _0x742b72=this['listens']['get'](_0x22ae6d);_0x16c9a5=_0x742b72['get'](_0x5cba03),_0x742b72['delete'](_0x5cba03),_0x742b72['size']===0x0&&this['listens']['delete'](_0x22ae6d);}else _0x16c9a5=void 0x0;return _0x16c9a5;}['onAuthRevoked_'](_0x335aae,_0x4d8164){L('Auth\x20token\x20revoked:\x20'+_0x335aae+'/'+_0x4d8164),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x335aae==='invalid_token'||_0x335aae==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x5732b4,_0x1a600b){L('App\x20check\x20token\x20revoked:\x20'+_0x5732b4+'/'+_0x1a600b),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x5732b4==='invalid_token'||_0x5732b4==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0xb29c12){this['securityDebugCallback_']?this['securityDebugCallback_'](_0xb29c12):'msg'in _0xb29c12&&console['log']('FIREBASE:\x20'+_0xb29c12['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x3d887b of this['listens']['values']())for(const _0xd14a5b of _0x3d887b['values']())this['sendListen_'](_0xd14a5b);for(let _0x5de3ab=0x0;_0x5de3ab<this['outstandingPuts_']['length'];_0x5de3ab++)this['outstandingPuts_'][_0x5de3ab]&&this['sendPut_'](_0x5de3ab);for(;this['onDisconnectRequestQueue_']['length'];){const _0x2ad1e2=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x2ad1e2['action'],_0x2ad1e2['pathString'],_0x2ad1e2['data'],_0x2ad1e2['onComplete']);}for(let _0x439e57=0x0;_0x439e57<this['outstandingGets_']['length'];_0x439e57++)this['outstandingGets_'][_0x439e57]&&this['sendGet_'](_0x439e57);}['sendConnectStats_'](){const _0x43d7a2={};let _0x577b0b='js';_0x43d7a2['sdk.'+_0x577b0b+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x43d7a2['framework.cordova']=0x1:Kr()&&(_0x43d7a2['framework.reactnative']=0x1),this['reportStats'](_0x43d7a2);}['shouldReconnect_'](){const _0x22486c=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x22486c;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x53cc41,_0x28247d){this['name']=_0x53cc41,this['node']=_0x28247d;}static['Wrap'](_0x97ea04,_0x202b6e){return new E(_0x97ea04,_0x202b6e);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x466b23,_0x4ab0d4){const _0x1393e9=new E(We,_0x466b23),_0x4151ee=new E(We,_0x4ab0d4);return this['compare'](_0x1393e9,_0x4151ee)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x5d9a5a){sn=_0x5d9a5a;}['compare'](_0xf2d1e9,_0x228c17){return qe(_0xf2d1e9['name'],_0x228c17['name']);}['isDefinedOn'](_0x325aa1){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x5d49a8,_0x3a887){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0xcf6174,_0x4397d0){return f(typeof _0xcf6174=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0xcf6174,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x5e5014,_0x112b46,_0x5af4f9,_0x3894c1,_0x4bea42=null){this['isReverse_']=_0x3894c1,this['resultGenerator_']=_0x4bea42,this['nodeStack_']=[];let _0x10744d=0x1;for(;!_0x5e5014['isEmpty']();)if(_0x5e5014=_0x5e5014,_0x10744d=_0x112b46?_0x5af4f9(_0x5e5014['key'],_0x112b46):0x1,_0x3894c1&&(_0x10744d*=-0x1),_0x10744d<0x0)this['isReverse_']?_0x5e5014=_0x5e5014['left']:_0x5e5014=_0x5e5014['right'];else{if(_0x10744d===0x0){this['nodeStack_']['push'](_0x5e5014);break;}else this['nodeStack_']['push'](_0x5e5014),this['isReverse_']?_0x5e5014=_0x5e5014['right']:_0x5e5014=_0x5e5014['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x24989a=this['nodeStack_']['pop'](),_0x17b6e5;if(this['resultGenerator_']?_0x17b6e5=this['resultGenerator_'](_0x24989a['key'],_0x24989a['value']):_0x17b6e5={'key':_0x24989a['key'],'value':_0x24989a['value']},this['isReverse_']){for(_0x24989a=_0x24989a['left'];!_0x24989a['isEmpty']();)this['nodeStack_']['push'](_0x24989a),_0x24989a=_0x24989a['right'];}else{for(_0x24989a=_0x24989a['right'];!_0x24989a['isEmpty']();)this['nodeStack_']['push'](_0x24989a),_0x24989a=_0x24989a['left'];}return _0x17b6e5;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x379162=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x379162['key'],_0x379162['value']):{'key':_0x379162['key'],'value':_0x379162['value']};}}class M{constructor(_0x12727d,_0x491715,_0x3f44f8,_0x1954bb,_0x5b9ec1){this['key']=_0x12727d,this['value']=_0x491715,this['color']=_0x3f44f8??M['RED'],this['left']=_0x1954bb??B['EMPTY_NODE'],this['right']=_0x5b9ec1??B['EMPTY_NODE'];}['copy'](_0x3ac54f,_0xcb8d8d,_0x4a2470,_0x5f3eb2,_0x20f723){return new M(_0x3ac54f??this['key'],_0xcb8d8d??this['value'],_0x4a2470??this['color'],_0x5f3eb2??this['left'],_0x20f723??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x241d5c){return this['left']['inorderTraversal'](_0x241d5c)||!!_0x241d5c(this['key'],this['value'])||this['right']['inorderTraversal'](_0x241d5c);}['reverseTraversal'](_0x35675a){return this['right']['reverseTraversal'](_0x35675a)||_0x35675a(this['key'],this['value'])||this['left']['reverseTraversal'](_0x35675a);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x227c7c,_0x358bb1,_0x301bc6){let _0x318b40=this;const _0x42d579=_0x301bc6(_0x227c7c,_0x318b40['key']);return _0x42d579<0x0?_0x318b40=_0x318b40['copy'](null,null,null,_0x318b40['left']['insert'](_0x227c7c,_0x358bb1,_0x301bc6),null):_0x42d579===0x0?_0x318b40=_0x318b40['copy'](null,_0x358bb1,null,null,null):_0x318b40=_0x318b40['copy'](null,null,null,null,_0x318b40['right']['insert'](_0x227c7c,_0x358bb1,_0x301bc6)),_0x318b40['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x4778b7=this;return!_0x4778b7['left']['isRed_']()&&!_0x4778b7['left']['left']['isRed_']()&&(_0x4778b7=_0x4778b7['moveRedLeft_']()),_0x4778b7=_0x4778b7['copy'](null,null,null,_0x4778b7['left']['removeMin_'](),null),_0x4778b7['fixUp_']();}['remove'](_0x2a126a,_0x33cff0){let _0x417505,_0x56fb28;if(_0x417505=this,_0x33cff0(_0x2a126a,_0x417505['key'])<0x0)!_0x417505['left']['isEmpty']()&&!_0x417505['left']['isRed_']()&&!_0x417505['left']['left']['isRed_']()&&(_0x417505=_0x417505['moveRedLeft_']()),_0x417505=_0x417505['copy'](null,null,null,_0x417505['left']['remove'](_0x2a126a,_0x33cff0),null);else{if(_0x417505['left']['isRed_']()&&(_0x417505=_0x417505['rotateRight_']()),!_0x417505['right']['isEmpty']()&&!_0x417505['right']['isRed_']()&&!_0x417505['right']['left']['isRed_']()&&(_0x417505=_0x417505['moveRedRight_']()),_0x33cff0(_0x2a126a,_0x417505['key'])===0x0){if(_0x417505['right']['isEmpty']())return B['EMPTY_NODE'];_0x56fb28=_0x417505['right']['min_'](),_0x417505=_0x417505['copy'](_0x56fb28['key'],_0x56fb28['value'],null,null,_0x417505['right']['removeMin_']());}_0x417505=_0x417505['copy'](null,null,null,null,_0x417505['right']['remove'](_0x2a126a,_0x33cff0));}return _0x417505['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x1a3a4d=this;return _0x1a3a4d['right']['isRed_']()&&!_0x1a3a4d['left']['isRed_']()&&(_0x1a3a4d=_0x1a3a4d['rotateLeft_']()),_0x1a3a4d['left']['isRed_']()&&_0x1a3a4d['left']['left']['isRed_']()&&(_0x1a3a4d=_0x1a3a4d['rotateRight_']()),_0x1a3a4d['left']['isRed_']()&&_0x1a3a4d['right']['isRed_']()&&(_0x1a3a4d=_0x1a3a4d['colorFlip_']()),_0x1a3a4d;}['moveRedLeft_'](){let _0x4d65d2=this['colorFlip_']();return _0x4d65d2['right']['left']['isRed_']()&&(_0x4d65d2=_0x4d65d2['copy'](null,null,null,null,_0x4d65d2['right']['rotateRight_']()),_0x4d65d2=_0x4d65d2['rotateLeft_'](),_0x4d65d2=_0x4d65d2['colorFlip_']()),_0x4d65d2;}['moveRedRight_'](){let _0x21164f=this['colorFlip_']();return _0x21164f['left']['left']['isRed_']()&&(_0x21164f=_0x21164f['rotateRight_'](),_0x21164f=_0x21164f['colorFlip_']()),_0x21164f;}['rotateLeft_'](){const _0x121088=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x121088,null);}['rotateRight_'](){const _0x509c29=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x509c29);}['colorFlip_'](){const _0x2fcfa3=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x168d28=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x2fcfa3,_0x168d28);}['checkMaxDepth_'](){const _0x3b9aaf=this['check_']();return Math['pow'](0x2,_0x3b9aaf)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x17ef78=this['left']['check_']();if(_0x17ef78!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x17ef78+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x4f39b7,_0x51cbb4,_0x2f9724,_0x1e4c5b,_0x76af4d){return this;}['insert'](_0x4b5c3d,_0x5db3db,_0x566073){return new M(_0x4b5c3d,_0x5db3db,null);}['remove'](_0x12f0a8,_0x2dbda8){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x5934c3){return!0x1;}['reverseTraversal'](_0x1c5f91){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0xfc3dc,_0x2438a0=B['EMPTY_NODE']){this['comparator_']=_0xfc3dc,this['root_']=_0x2438a0;}['insert'](_0x238388,_0x1e97c2){return new B(this['comparator_'],this['root_']['insert'](_0x238388,_0x1e97c2,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0xb2c39d){return new B(this['comparator_'],this['root_']['remove'](_0xb2c39d,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x307b42){let _0x2d9dab,_0x47da8f=this['root_'];for(;!_0x47da8f['isEmpty']();){if(_0x2d9dab=this['comparator_'](_0x307b42,_0x47da8f['key']),_0x2d9dab===0x0)return _0x47da8f['value'];_0x2d9dab<0x0?_0x47da8f=_0x47da8f['left']:_0x2d9dab>0x0&&(_0x47da8f=_0x47da8f['right']);}return null;}['getPredecessorKey'](_0x31ae4d){let _0x157d31,_0x2c53c1=this['root_'],_0x1e5b7a=null;for(;!_0x2c53c1['isEmpty']();)if(_0x157d31=this['comparator_'](_0x31ae4d,_0x2c53c1['key']),_0x157d31===0x0){if(_0x2c53c1['left']['isEmpty']())return _0x1e5b7a?_0x1e5b7a['key']:null;for(_0x2c53c1=_0x2c53c1['left'];!_0x2c53c1['right']['isEmpty']();)_0x2c53c1=_0x2c53c1['right'];return _0x2c53c1['key'];}else _0x157d31<0x0?_0x2c53c1=_0x2c53c1['left']:_0x157d31>0x0&&(_0x1e5b7a=_0x2c53c1,_0x2c53c1=_0x2c53c1['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x54b542){return this['root_']['inorderTraversal'](_0x54b542);}['reverseTraversal'](_0x3a3597){return this['root_']['reverseTraversal'](_0x3a3597);}['getIterator'](_0x2ec7fa){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x2ec7fa);}['getIteratorFrom'](_0x49dd04,_0x12c3a2){return new rn(this['root_'],_0x49dd04,this['comparator_'],!0x1,_0x12c3a2);}['getReverseIteratorFrom'](_0x2ff375,_0x7191be){return new rn(this['root_'],_0x2ff375,this['comparator_'],!0x0,_0x7191be);}['getReverseIterator'](_0x2b1c06){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x2b1c06);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x1edf5d,_0x516427){return qe(_0x1edf5d['name'],_0x516427['name']);}function Qi(_0x13fde9,_0x411dce){return qe(_0x13fde9,_0x411dce);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x477ccf){Ci=_0x477ccf;}const Po=function(_0x3c856e){return typeof _0x3c856e=='number'?'number:'+ao(_0x3c856e):'string:'+_0x3c856e;},No=function(_0x301aad){if(_0x301aad['isLeafNode']()){const _0x6b68ff=_0x301aad['val']();f(typeof _0x6b68ff=='string'||typeof _0x6b68ff=='number'||typeof _0x6b68ff=='object'&&Q(_0x6b68ff,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x301aad===Ci||_0x301aad['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x301aad===Ci||_0x301aad['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x1659fa){nr=_0x1659fa;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x118f30,_0x762f0b=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x118f30,this['priorityNode_']=_0x762f0b,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x55f6a1){return new D(this['value_'],_0x55f6a1);}['getImmediateChild'](_0xc958d0){return _0xc958d0==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x30b1be){return v(_0x30b1be)?this:y(_0x30b1be)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x3a221e,_0x20e2f1){return null;}['updateImmediateChild'](_0x119375,_0x470a57){return _0x119375==='.priority'?this['updatePriority'](_0x470a57):_0x470a57['isEmpty']()&&_0x119375!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x119375,_0x470a57)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x28cd9,_0x62552a){const _0x41345d=y(_0x28cd9);return _0x41345d===null?_0x62552a:_0x62552a['isEmpty']()&&_0x41345d!=='.priority'?this:(f(_0x41345d!=='.priority'||Ce(_0x28cd9)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x41345d,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x28cd9),_0x62552a)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x1c66eb,_0x162523){return!0x1;}['val'](_0xa22ec1){return _0xa22ec1&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x5e7d3c='';this['priorityNode_']['isEmpty']()||(_0x5e7d3c+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x5ba956=typeof this['value_'];_0x5e7d3c+=_0x5ba956+':',_0x5ba956==='number'?_0x5e7d3c+=ao(this['value_']):_0x5e7d3c+=this['value_'],this['lazyHash_']=ro(_0x5e7d3c);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x15ca97){return _0x15ca97===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x15ca97 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x15ca97['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x15ca97));}['compareToLeafNode_'](_0xc7949c){const _0xde0988=typeof _0xc7949c['value_'],_0x3c6717=typeof this['value_'],_0x419f21=D['VALUE_TYPE_ORDER']['indexOf'](_0xde0988),_0x51712c=D['VALUE_TYPE_ORDER']['indexOf'](_0x3c6717);return f(_0x419f21>=0x0,'Unknown\x20leaf\x20type:\x20'+_0xde0988),f(_0x51712c>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x3c6717),_0x419f21===_0x51712c?_0x3c6717==='object'?0x0:this['value_']<_0xc7949c['value_']?-0x1:this['value_']===_0xc7949c['value_']?0x0:0x1:_0x51712c-_0x419f21;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x1bd7ad){if(_0x1bd7ad===this)return!0x0;if(_0x1bd7ad['isLeafNode']()){const _0x5a2add=_0x1bd7ad;return this['value_']===_0x5a2add['value_']&&this['priorityNode_']['equals'](_0x5a2add['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x3c2269){Oo=_0x3c2269;}function Wh(_0x138431){Do=_0x138431;}class Bh extends Fn{['compare'](_0x59431e,_0x23e0ea){const _0x1327e6=_0x59431e['node']['getPriority'](),_0x759a3c=_0x23e0ea['node']['getPriority'](),_0xde38c3=_0x1327e6['compareTo'](_0x759a3c);return _0xde38c3===0x0?qe(_0x59431e['name'],_0x23e0ea['name']):_0xde38c3;}['isDefinedOn'](_0x5ba5a9){return!_0x5ba5a9['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x4e67ce,_0x5dd4da){return!_0x4e67ce['getPriority']()['equals'](_0x5dd4da['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x4ba3c6,_0x1581a3){const _0x13f64f=Oo(_0x4ba3c6);return new E(_0x1581a3,new D('[PRIORITY-POST]',_0x13f64f));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x43edba){const _0x3c0f50=_0x1a0c1f=>parseInt(Math['log'](_0x1a0c1f)/Vh,0xa),_0x4ea1cc=_0x4669e4=>parseInt(Array(_0x4669e4+0x1)['join']('1'),0x2);this['count']=_0x3c0f50(_0x43edba+0x1),this['current_']=this['count']-0x1;const _0x41a9e3=_0x4ea1cc(this['count']);this['bits_']=_0x43edba+0x1&_0x41a9e3;}['nextBitIsOne'](){const _0x53238=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x53238;}}const yn=function(_0x2ae495,_0x1521c7,_0x27ab7a,_0x5ab7b3){_0x2ae495['sort'](_0x1521c7);const _0x41a334=function(_0x43db0d,_0x594a3d){const _0x30fc8c=_0x594a3d-_0x43db0d;let _0x3e6c67,_0x455390;if(_0x30fc8c===0x0)return null;if(_0x30fc8c===0x1)return _0x3e6c67=_0x2ae495[_0x43db0d],_0x455390=_0x27ab7a?_0x27ab7a(_0x3e6c67):_0x3e6c67,new M(_0x455390,_0x3e6c67['node'],M['BLACK'],null,null);{const _0xf4b368=parseInt(_0x30fc8c/0x2,0xa)+_0x43db0d,_0x56f2dd=_0x41a334(_0x43db0d,_0xf4b368),_0x7dd7d5=_0x41a334(_0xf4b368+0x1,_0x594a3d);return _0x3e6c67=_0x2ae495[_0xf4b368],_0x455390=_0x27ab7a?_0x27ab7a(_0x3e6c67):_0x3e6c67,new M(_0x455390,_0x3e6c67['node'],M['BLACK'],_0x56f2dd,_0x7dd7d5);}},_0x423703=function(_0x453dbd){let _0x1d7a8c=null,_0x460ec9=null,_0x56b5a2=_0x2ae495['length'];const _0x163edb=function(_0x3908b6,_0x5b167c){const _0x5c0f34=_0x56b5a2-_0x3908b6,_0x1e32e8=_0x56b5a2;_0x56b5a2-=_0x3908b6;const _0x5cef4d=_0x41a334(_0x5c0f34+0x1,_0x1e32e8),_0x1091bf=_0x2ae495[_0x5c0f34],_0x3bb572=_0x27ab7a?_0x27ab7a(_0x1091bf):_0x1091bf;_0x2cfe05(new M(_0x3bb572,_0x1091bf['node'],_0x5b167c,null,_0x5cef4d));},_0x2cfe05=function(_0x277260){_0x1d7a8c?(_0x1d7a8c['left']=_0x277260,_0x1d7a8c=_0x277260):(_0x460ec9=_0x277260,_0x1d7a8c=_0x277260);};for(let _0x5b3a05=0x0;_0x5b3a05<_0x453dbd['count'];++_0x5b3a05){const _0xc741b3=_0x453dbd['nextBitIsOne'](),_0x316c0c=Math['pow'](0x2,_0x453dbd['count']-(_0x5b3a05+0x1));_0xc741b3?_0x163edb(_0x316c0c,M['BLACK']):(_0x163edb(_0x316c0c,M['BLACK']),_0x163edb(_0x316c0c,M['RED']));}return _0x460ec9;},_0x69fea5=new Hh(_0x2ae495['length']),_0x548953=_0x423703(_0x69fea5);return new B(_0x5ab7b3||_0x1521c7,_0x548953);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x22145b,_0x51f44f){this['indexes_']=_0x22145b,this['indexSet_']=_0x51f44f;}['get'](_0x519185){const _0x867081=Le(this['indexes_'],_0x519185);if(!_0x867081)throw new Error('No\x20index\x20defined\x20for\x20'+_0x519185);return _0x867081 instanceof B?_0x867081:null;}['hasIndex'](_0x1e5eb6){return Q(this['indexSet_'],_0x1e5eb6['toString']());}['addIndex'](_0x2e3149,_0x4db7c5){f(_0x2e3149!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x2cb543=[];let _0x1bfbf7=!0x1;const _0x4a122b=_0x4db7c5['getIterator'](E['Wrap']);let _0x35c98c=_0x4a122b['getNext']();for(;_0x35c98c;)_0x1bfbf7=_0x1bfbf7||_0x2e3149['isDefinedOn'](_0x35c98c['node']),_0x2cb543['push'](_0x35c98c),_0x35c98c=_0x4a122b['getNext']();let _0x13c8f9;_0x1bfbf7?_0x13c8f9=yn(_0x2cb543,_0x2e3149['getCompare']()):_0x13c8f9=Qe;const _0x1e81f0=_0x2e3149['toString'](),_0x4acf75={...this['indexSet_']};_0x4acf75[_0x1e81f0]=_0x2e3149;const _0x219152={...this['indexes_']};return _0x219152[_0x1e81f0]=_0x13c8f9,new te(_0x219152,_0x4acf75);}['addToIndexes'](_0x490431,_0x241259){const _0x381494=_n(this['indexes_'],(_0x4fb87d,_0x187361)=>{const _0xc8eedd=Le(this['indexSet_'],_0x187361);if(f(_0xc8eedd,'Missing\x20index\x20implementation\x20for\x20'+_0x187361),_0x4fb87d===Qe){if(_0xc8eedd['isDefinedOn'](_0x490431['node'])){const _0x3b43fc=[],_0x5d4697=_0x241259['getIterator'](E['Wrap']);let _0x5e46ce=_0x5d4697['getNext']();for(;_0x5e46ce;)_0x5e46ce['name']!==_0x490431['name']&&_0x3b43fc['push'](_0x5e46ce),_0x5e46ce=_0x5d4697['getNext']();return _0x3b43fc['push'](_0x490431),yn(_0x3b43fc,_0xc8eedd['getCompare']());}else return Qe;}else{const _0x3b2f9f=_0x241259['get'](_0x490431['name']);let _0x49f028=_0x4fb87d;return _0x3b2f9f&&(_0x49f028=_0x49f028['remove'](new E(_0x490431['name'],_0x3b2f9f))),_0x49f028['insert'](_0x490431,_0x490431['node']);}});return new te(_0x381494,this['indexSet_']);}['removeFromIndexes'](_0x1cfc1d,_0x110021){const _0x5c8b5a=_n(this['indexes_'],_0x108d47=>{if(_0x108d47===Qe)return _0x108d47;{const _0x4690e0=_0x110021['get'](_0x1cfc1d['name']);return _0x4690e0?_0x108d47['remove'](new E(_0x1cfc1d['name'],_0x4690e0)):_0x108d47;}});return new te(_0x5c8b5a,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x52a42d,_0x1becb4,_0x56f006){this['children_']=_0x52a42d,this['priorityNode_']=_0x1becb4,this['indexMap_']=_0x56f006,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x1f8741){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x1f8741,this['indexMap_']);}['getImmediateChild'](_0x1358c7){if(_0x1358c7==='.priority')return this['getPriority']();{const _0xcd1f1c=this['children_']['get'](_0x1358c7);return _0xcd1f1c===null?It:_0xcd1f1c;}}['getChild'](_0x4b9ee1){const _0x179a62=y(_0x4b9ee1);return _0x179a62===null?this:this['getImmediateChild'](_0x179a62)['getChild'](S(_0x4b9ee1));}['hasChild'](_0x44c7f7){return this['children_']['get'](_0x44c7f7)!==null;}['updateImmediateChild'](_0xa45f05,_0x558bd0){if(f(_0x558bd0,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0xa45f05==='.priority')return this['updatePriority'](_0x558bd0);{const _0x2dc39e=new E(_0xa45f05,_0x558bd0);let _0x7295eb,_0xbfd442;_0x558bd0['isEmpty']()?(_0x7295eb=this['children_']['remove'](_0xa45f05),_0xbfd442=this['indexMap_']['removeFromIndexes'](_0x2dc39e,this['children_'])):(_0x7295eb=this['children_']['insert'](_0xa45f05,_0x558bd0),_0xbfd442=this['indexMap_']['addToIndexes'](_0x2dc39e,this['children_']));const _0x34ee7c=_0x7295eb['isEmpty']()?It:this['priorityNode_'];return new g(_0x7295eb,_0x34ee7c,_0xbfd442);}}['updateChild'](_0x23b88b,_0x3f2ef1){const _0x469844=y(_0x23b88b);if(_0x469844===null)return _0x3f2ef1;{f(y(_0x23b88b)!=='.priority'||Ce(_0x23b88b)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x1839cd=this['getImmediateChild'](_0x469844)['updateChild'](S(_0x23b88b),_0x3f2ef1);return this['updateImmediateChild'](_0x469844,_0x1839cd);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x5bebdb){if(this['isEmpty']())return null;const _0x3b5bfb={};let _0x475f39=0x0,_0x20246a=0x0,_0x889359=!0x0;if(this['forEachChild'](R,(_0x11dc56,_0x5262c8)=>{_0x3b5bfb[_0x11dc56]=_0x5262c8['val'](_0x5bebdb),_0x475f39++,_0x889359&&g['INTEGER_REGEXP_']['test'](_0x11dc56)?_0x20246a=Math['max'](_0x20246a,Number(_0x11dc56)):_0x889359=!0x1;}),!_0x5bebdb&&_0x889359&&_0x20246a<0x2*_0x475f39){const _0x2f5948=[];for(const _0x5cc385 in _0x3b5bfb)_0x2f5948[_0x5cc385]=_0x3b5bfb[_0x5cc385];return _0x2f5948;}else return _0x5bebdb&&!this['getPriority']()['isEmpty']()&&(_0x3b5bfb['.priority']=this['getPriority']()['val']()),_0x3b5bfb;}['hash'](){if(this['lazyHash_']===null){let _0x144ae6='';this['getPriority']()['isEmpty']()||(_0x144ae6+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x5e0c0a,_0x3a4028)=>{const _0x119a59=_0x3a4028['hash']();_0x119a59!==''&&(_0x144ae6+=':'+_0x5e0c0a+':'+_0x119a59);}),this['lazyHash_']=_0x144ae6===''?'':ro(_0x144ae6);}return this['lazyHash_'];}['getPredecessorChildName'](_0x4c71d7,_0x2184d1,_0x26daaf){const _0x2e5be4=this['resolveIndex_'](_0x26daaf);if(_0x2e5be4){const _0x59df80=_0x2e5be4['getPredecessorKey'](new E(_0x4c71d7,_0x2184d1));return _0x59df80?_0x59df80['name']:null;}else return this['children_']['getPredecessorKey'](_0x4c71d7);}['getFirstChildName'](_0x332f19){const _0xd96f51=this['resolveIndex_'](_0x332f19);if(_0xd96f51){const _0x2770c0=_0xd96f51['minKey']();return _0x2770c0&&_0x2770c0['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x328049){const _0x586cfd=this['getFirstChildName'](_0x328049);return _0x586cfd?new E(_0x586cfd,this['children_']['get'](_0x586cfd)):null;}['getLastChildName'](_0x3d2c7a){const _0x48765b=this['resolveIndex_'](_0x3d2c7a);if(_0x48765b){const _0x20af93=_0x48765b['maxKey']();return _0x20af93&&_0x20af93['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x13583f){const _0xcdb87d=this['getLastChildName'](_0x13583f);return _0xcdb87d?new E(_0xcdb87d,this['children_']['get'](_0xcdb87d)):null;}['forEachChild'](_0x305105,_0x2e6f34){const _0x4dd0fc=this['resolveIndex_'](_0x305105);return _0x4dd0fc?_0x4dd0fc['inorderTraversal'](_0x2549f6=>_0x2e6f34(_0x2549f6['name'],_0x2549f6['node'])):this['children_']['inorderTraversal'](_0x2e6f34);}['getIterator'](_0x19532e){return this['getIteratorFrom'](_0x19532e['minPost'](),_0x19532e);}['getIteratorFrom'](_0xc43623,_0x361685){const _0x241393=this['resolveIndex_'](_0x361685);if(_0x241393)return _0x241393['getIteratorFrom'](_0xc43623,_0x5de471=>_0x5de471);{const _0x2615bb=this['children_']['getIteratorFrom'](_0xc43623['name'],E['Wrap']);let _0x144dd6=_0x2615bb['peek']();for(;_0x144dd6!=null&&_0x361685['compare'](_0x144dd6,_0xc43623)<0x0;)_0x2615bb['getNext'](),_0x144dd6=_0x2615bb['peek']();return _0x2615bb;}}['getReverseIterator'](_0x4fb800){return this['getReverseIteratorFrom'](_0x4fb800['maxPost'](),_0x4fb800);}['getReverseIteratorFrom'](_0x38434d,_0x397578){const _0x224cae=this['resolveIndex_'](_0x397578);if(_0x224cae)return _0x224cae['getReverseIteratorFrom'](_0x38434d,_0x348364=>_0x348364);{const _0x44a931=this['children_']['getReverseIteratorFrom'](_0x38434d['name'],E['Wrap']);let _0x3a5697=_0x44a931['peek']();for(;_0x3a5697!=null&&_0x397578['compare'](_0x3a5697,_0x38434d)>0x0;)_0x44a931['getNext'](),_0x3a5697=_0x44a931['peek']();return _0x44a931;}}['compareTo'](_0x247efb){return this['isEmpty']()?_0x247efb['isEmpty']()?0x0:-0x1:_0x247efb['isLeafNode']()||_0x247efb['isEmpty']()?0x1:_0x247efb===Kt?-0x1:0x0;}['withIndex'](_0x45a78e){if(_0x45a78e===ve||this['indexMap_']['hasIndex'](_0x45a78e))return this;{const _0x12dee2=this['indexMap_']['addIndex'](_0x45a78e,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x12dee2);}}['isIndexed'](_0x56f50f){return _0x56f50f===ve||this['indexMap_']['hasIndex'](_0x56f50f);}['equals'](_0x54a88e){if(_0x54a88e===this)return!0x0;if(_0x54a88e['isLeafNode']())return!0x1;{const _0x892e32=_0x54a88e;if(this['getPriority']()['equals'](_0x892e32['getPriority']())){if(this['children_']['count']()===_0x892e32['children_']['count']()){const _0x4fd58e=this['getIterator'](R),_0x36ffd1=_0x892e32['getIterator'](R);let _0x47a877=_0x4fd58e['getNext'](),_0x202ee5=_0x36ffd1['getNext']();for(;_0x47a877&&_0x202ee5;){if(_0x47a877['name']!==_0x202ee5['name']||!_0x47a877['node']['equals'](_0x202ee5['node']))return!0x1;_0x47a877=_0x4fd58e['getNext'](),_0x202ee5=_0x36ffd1['getNext']();}return _0x47a877===null&&_0x202ee5===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x36d6af){return _0x36d6af===ve?null:this['indexMap_']['get'](_0x36d6af['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x523ab6){return _0x523ab6===this?0x0:0x1;}['equals'](_0x454700){return _0x454700===this;}['getPriority'](){return this;}['getImmediateChild'](_0x227883){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0xa3ddc1,_0x4d8ec9=null){if(_0xa3ddc1===null)return g['EMPTY_NODE'];if(typeof _0xa3ddc1=='object'&&'.priority'in _0xa3ddc1&&(_0x4d8ec9=_0xa3ddc1['.priority']),f(_0x4d8ec9===null||typeof _0x4d8ec9=='string'||typeof _0x4d8ec9=='number'||typeof _0x4d8ec9=='object'&&'.sv'in _0x4d8ec9,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x4d8ec9),typeof _0xa3ddc1=='object'&&'.value'in _0xa3ddc1&&_0xa3ddc1['.value']!==null&&(_0xa3ddc1=_0xa3ddc1['.value']),typeof _0xa3ddc1!='object'||'.sv'in _0xa3ddc1){const _0x168052=_0xa3ddc1;return new D(_0x168052,A(_0x4d8ec9));}if(!(_0xa3ddc1 instanceof Array)&&Gh){const _0x4f4f6c=[];let _0x3f83f4=!0x1;if(x(_0xa3ddc1,(_0x1dd2a1,_0x4f51e7)=>{if(_0x1dd2a1['substring'](0x0,0x1)!=='.'){const _0x52ba6f=A(_0x4f51e7);_0x52ba6f['isEmpty']()||(_0x3f83f4=_0x3f83f4||!_0x52ba6f['getPriority']()['isEmpty'](),_0x4f4f6c['push'](new E(_0x1dd2a1,_0x52ba6f)));}}),_0x4f4f6c['length']===0x0)return g['EMPTY_NODE'];const _0x655337=yn(_0x4f4f6c,xh,_0x5b2cd5=>_0x5b2cd5['name'],Qi);if(_0x3f83f4){const _0x2cdff8=yn(_0x4f4f6c,R['getCompare']());return new g(_0x655337,A(_0x4d8ec9),new te({'.priority':_0x2cdff8},{'.priority':R}));}else return new g(_0x655337,A(_0x4d8ec9),te['Default']);}else{let _0x356cc4=g['EMPTY_NODE'];return x(_0xa3ddc1,(_0x2d3f49,_0x4bbbe9)=>{if(Q(_0xa3ddc1,_0x2d3f49)&&_0x2d3f49['substring'](0x0,0x1)!=='.'){const _0x4a1d66=A(_0x4bbbe9);(_0x4a1d66['isLeafNode']()||!_0x4a1d66['isEmpty']())&&(_0x356cc4=_0x356cc4['updateImmediateChild'](_0x2d3f49,_0x4a1d66));}}),_0x356cc4['updatePriority'](A(_0x4d8ec9));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0xe903d9){super(),this['indexPath_']=_0xe903d9,f(!v(_0xe903d9)&&y(_0xe903d9)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x2a03f4){return _0x2a03f4['getChild'](this['indexPath_']);}['isDefinedOn'](_0x11c503){return!_0x11c503['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x378ee5,_0x78fa2e){const _0x377025=this['extractChild'](_0x378ee5['node']),_0x234582=this['extractChild'](_0x78fa2e['node']),_0x29b0da=_0x377025['compareTo'](_0x234582);return _0x29b0da===0x0?qe(_0x378ee5['name'],_0x78fa2e['name']):_0x29b0da;}['makePost'](_0x2c2c6e,_0x597331){const _0x3139ad=A(_0x2c2c6e),_0x106305=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x3139ad);return new E(_0x597331,_0x106305);}['maxPost'](){const _0x26fad6=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x26fad6);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x3bdd9c,_0x33a4ff){const _0x5a8f1d=_0x3bdd9c['node']['compareTo'](_0x33a4ff['node']);return _0x5a8f1d===0x0?qe(_0x3bdd9c['name'],_0x33a4ff['name']):_0x5a8f1d;}['isDefinedOn'](_0x2eb718){return!0x0;}['indexedValueChanged'](_0x3c9570,_0x112661){return!_0x3c9570['equals'](_0x112661);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x1610c4,_0x49dbd3){const _0x42f209=A(_0x1610c4);return new E(_0x49dbd3,_0x42f209);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x5071e8){return{'type':'value','snapshotNode':_0x5071e8};}function rt(_0x52d324,_0x8b0a3f){return{'type':'child_added','snapshotNode':_0x8b0a3f,'childName':_0x52d324};}function Lt(_0x3f2ab5,_0x458c29){return{'type':'child_removed','snapshotNode':_0x458c29,'childName':_0x3f2ab5};}function xt(_0x2d1eaf,_0x38216a,_0x35b415){return{'type':'child_changed','snapshotNode':_0x38216a,'childName':_0x2d1eaf,'oldSnap':_0x35b415};}function zh(_0x3dc5a0,_0x10f85e){return{'type':'child_moved','snapshotNode':_0x10f85e,'childName':_0x3dc5a0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x437739){this['index_']=_0x437739;}['updateChild'](_0x3c5402,_0x590d3d,_0x2f72b7,_0x497b7e,_0x5cd27b,_0x281798){f(_0x3c5402['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x4f3b89=_0x3c5402['getImmediateChild'](_0x590d3d);return _0x4f3b89['getChild'](_0x497b7e)['equals'](_0x2f72b7['getChild'](_0x497b7e))&&_0x4f3b89['isEmpty']()===_0x2f72b7['isEmpty']()||(_0x281798!=null&&(_0x2f72b7['isEmpty']()?_0x3c5402['hasChild'](_0x590d3d)?_0x281798['trackChildChange'](Lt(_0x590d3d,_0x4f3b89)):f(_0x3c5402['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x4f3b89['isEmpty']()?_0x281798['trackChildChange'](rt(_0x590d3d,_0x2f72b7)):_0x281798['trackChildChange'](xt(_0x590d3d,_0x2f72b7,_0x4f3b89))),_0x3c5402['isLeafNode']()&&_0x2f72b7['isEmpty']())?_0x3c5402:_0x3c5402['updateImmediateChild'](_0x590d3d,_0x2f72b7)['withIndex'](this['index_']);}['updateFullNode'](_0x1ed377,_0x45c8b6,_0x3847b7){return _0x3847b7!=null&&(_0x1ed377['isLeafNode']()||_0x1ed377['forEachChild'](R,(_0x239622,_0x1c7e91)=>{_0x45c8b6['hasChild'](_0x239622)||_0x3847b7['trackChildChange'](Lt(_0x239622,_0x1c7e91));}),_0x45c8b6['isLeafNode']()||_0x45c8b6['forEachChild'](R,(_0x2a4bde,_0x4ed748)=>{if(_0x1ed377['hasChild'](_0x2a4bde)){const _0x352081=_0x1ed377['getImmediateChild'](_0x2a4bde);_0x352081['equals'](_0x4ed748)||_0x3847b7['trackChildChange'](xt(_0x2a4bde,_0x4ed748,_0x352081));}else _0x3847b7['trackChildChange'](rt(_0x2a4bde,_0x4ed748));})),_0x45c8b6['withIndex'](this['index_']);}['updatePriority'](_0x26812c,_0x15f703){return _0x26812c['isEmpty']()?g['EMPTY_NODE']:_0x26812c['updatePriority'](_0x15f703);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x694111){this['indexedFilter_']=new Xi(_0x694111['getIndex']()),this['index_']=_0x694111['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x694111),this['endPost_']=Ft['getEndPost_'](_0x694111),this['startIsInclusive_']=!_0x694111['startAfterSet_'],this['endIsInclusive_']=!_0x694111['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x33db7d){const _0x545850=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x33db7d)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x33db7d)<0x0,_0x125afc=this['endIsInclusive_']?this['index_']['compare'](_0x33db7d,this['getEndPost']())<=0x0:this['index_']['compare'](_0x33db7d,this['getEndPost']())<0x0;return _0x545850&&_0x125afc;}['updateChild'](_0xc5cb2,_0x440f2e,_0x1aebfd,_0x46c3a4,_0x35901e,_0x1101bd){return this['matches'](new E(_0x440f2e,_0x1aebfd))||(_0x1aebfd=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0xc5cb2,_0x440f2e,_0x1aebfd,_0x46c3a4,_0x35901e,_0x1101bd);}['updateFullNode'](_0x1bbff7,_0x58cd80,_0x4816db){_0x58cd80['isLeafNode']()&&(_0x58cd80=g['EMPTY_NODE']);let _0x281bd8=_0x58cd80['withIndex'](this['index_']);_0x281bd8=_0x281bd8['updatePriority'](g['EMPTY_NODE']);const _0x34bf1=this;return _0x58cd80['forEachChild'](R,(_0x530576,_0x394b3e)=>{_0x34bf1['matches'](new E(_0x530576,_0x394b3e))||(_0x281bd8=_0x281bd8['updateImmediateChild'](_0x530576,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x1bbff7,_0x281bd8,_0x4816db);}['updatePriority'](_0x1791ce,_0x2dca96){return _0x1791ce;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x5a0f08){if(_0x5a0f08['hasStart']()){const _0x4569bc=_0x5a0f08['getIndexStartName']();return _0x5a0f08['getIndex']()['makePost'](_0x5a0f08['getIndexStartValue'](),_0x4569bc);}else return _0x5a0f08['getIndex']()['minPost']();}static['getEndPost_'](_0x5954f3){if(_0x5954f3['hasEnd']()){const _0x146a17=_0x5954f3['getIndexEndName']();return _0x5954f3['getIndex']()['makePost'](_0x5954f3['getIndexEndValue'](),_0x146a17);}else return _0x5954f3['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x523c50){this['withinDirectionalStart']=_0x3277db=>this['reverse_']?this['withinEndPost'](_0x3277db):this['withinStartPost'](_0x3277db),this['withinDirectionalEnd']=_0x7ec181=>this['reverse_']?this['withinStartPost'](_0x7ec181):this['withinEndPost'](_0x7ec181),this['withinStartPost']=_0x1ef009=>{const _0x2d22a9=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x1ef009);return this['startIsInclusive_']?_0x2d22a9<=0x0:_0x2d22a9<0x0;},this['withinEndPost']=_0xf57e26=>{const _0xb3092e=this['index_']['compare'](_0xf57e26,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0xb3092e<=0x0:_0xb3092e<0x0;},this['rangedFilter_']=new Ft(_0x523c50),this['index_']=_0x523c50['getIndex'](),this['limit_']=_0x523c50['getLimit'](),this['reverse_']=!_0x523c50['isViewFromLeft'](),this['startIsInclusive_']=!_0x523c50['startAfterSet_'],this['endIsInclusive_']=!_0x523c50['endBeforeSet_'];}['updateChild'](_0x27a0a7,_0x2427dd,_0x2e9e11,_0x10ff5e,_0x2ad050,_0x8f2920){return this['rangedFilter_']['matches'](new E(_0x2427dd,_0x2e9e11))||(_0x2e9e11=g['EMPTY_NODE']),_0x27a0a7['getImmediateChild'](_0x2427dd)['equals'](_0x2e9e11)?_0x27a0a7:_0x27a0a7['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x27a0a7,_0x2427dd,_0x2e9e11,_0x10ff5e,_0x2ad050,_0x8f2920):this['fullLimitUpdateChild_'](_0x27a0a7,_0x2427dd,_0x2e9e11,_0x2ad050,_0x8f2920);}['updateFullNode'](_0x7f9c8c,_0x17a63d,_0x54df60){let _0x3236b7;if(_0x17a63d['isLeafNode']()||_0x17a63d['isEmpty']())_0x3236b7=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x17a63d['numChildren']()&&_0x17a63d['isIndexed'](this['index_'])){_0x3236b7=g['EMPTY_NODE']['withIndex'](this['index_']);let _0xbe1e95;this['reverse_']?_0xbe1e95=_0x17a63d['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0xbe1e95=_0x17a63d['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x3f8745=0x0;for(;_0xbe1e95['hasNext']()&&_0x3f8745<this['limit_'];){const _0x7ad992=_0xbe1e95['getNext']();if(this['withinDirectionalStart'](_0x7ad992)){if(this['withinDirectionalEnd'](_0x7ad992))_0x3236b7=_0x3236b7['updateImmediateChild'](_0x7ad992['name'],_0x7ad992['node']),_0x3f8745++;else break;}else continue;}}else{_0x3236b7=_0x17a63d['withIndex'](this['index_']),_0x3236b7=_0x3236b7['updatePriority'](g['EMPTY_NODE']);let _0x17ec04;this['reverse_']?_0x17ec04=_0x3236b7['getReverseIterator'](this['index_']):_0x17ec04=_0x3236b7['getIterator'](this['index_']);let _0x2f8261=0x0;for(;_0x17ec04['hasNext']();){const _0x207541=_0x17ec04['getNext']();_0x2f8261<this['limit_']&&this['withinDirectionalStart'](_0x207541)&&this['withinDirectionalEnd'](_0x207541)?_0x2f8261++:_0x3236b7=_0x3236b7['updateImmediateChild'](_0x207541['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x7f9c8c,_0x3236b7,_0x54df60);}['updatePriority'](_0x57346d,_0x4763b6){return _0x57346d;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x50b5fd,_0x579ddf,_0x5e9fc3,_0x15acd2,_0x1a1053){let _0x22af62;if(this['reverse_']){const _0x1b3137=this['index_']['getCompare']();_0x22af62=(_0x9f9c2b,_0x4ff14d)=>_0x1b3137(_0x4ff14d,_0x9f9c2b);}else _0x22af62=this['index_']['getCompare']();const _0xce0cf4=_0x50b5fd;f(_0xce0cf4['numChildren']()===this['limit_'],'');const _0x43557c=new E(_0x579ddf,_0x5e9fc3),_0x34f6a1=this['reverse_']?_0xce0cf4['getFirstChild'](this['index_']):_0xce0cf4['getLastChild'](this['index_']),_0x198491=this['rangedFilter_']['matches'](_0x43557c);if(_0xce0cf4['hasChild'](_0x579ddf)){const _0x49a59a=_0xce0cf4['getImmediateChild'](_0x579ddf);let _0x394bc7=_0x15acd2['getChildAfterChild'](this['index_'],_0x34f6a1,this['reverse_']);for(;_0x394bc7!=null&&(_0x394bc7['name']===_0x579ddf||_0xce0cf4['hasChild'](_0x394bc7['name']));)_0x394bc7=_0x15acd2['getChildAfterChild'](this['index_'],_0x394bc7,this['reverse_']);const _0x34cbd3=_0x394bc7==null?0x1:_0x22af62(_0x394bc7,_0x43557c);if(_0x198491&&!_0x5e9fc3['isEmpty']()&&_0x34cbd3>=0x0)return _0x1a1053!=null&&_0x1a1053['trackChildChange'](xt(_0x579ddf,_0x5e9fc3,_0x49a59a)),_0xce0cf4['updateImmediateChild'](_0x579ddf,_0x5e9fc3);{_0x1a1053!=null&&_0x1a1053['trackChildChange'](Lt(_0x579ddf,_0x49a59a));const _0x53c5a3=_0xce0cf4['updateImmediateChild'](_0x579ddf,g['EMPTY_NODE']);return _0x394bc7!=null&&this['rangedFilter_']['matches'](_0x394bc7)?(_0x1a1053!=null&&_0x1a1053['trackChildChange'](rt(_0x394bc7['name'],_0x394bc7['node'])),_0x53c5a3['updateImmediateChild'](_0x394bc7['name'],_0x394bc7['node'])):_0x53c5a3;}}else return _0x5e9fc3['isEmpty']()?_0x50b5fd:_0x198491&&_0x22af62(_0x34f6a1,_0x43557c)>=0x0?(_0x1a1053!=null&&(_0x1a1053['trackChildChange'](Lt(_0x34f6a1['name'],_0x34f6a1['node'])),_0x1a1053['trackChildChange'](rt(_0x579ddf,_0x5e9fc3))),_0xce0cf4['updateImmediateChild'](_0x579ddf,_0x5e9fc3)['updateImmediateChild'](_0x34f6a1['name'],g['EMPTY_NODE'])):_0x50b5fd;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x18e838=new Zi();return _0x18e838['limitSet_']=this['limitSet_'],_0x18e838['limit_']=this['limit_'],_0x18e838['startSet_']=this['startSet_'],_0x18e838['startAfterSet_']=this['startAfterSet_'],_0x18e838['indexStartValue_']=this['indexStartValue_'],_0x18e838['startNameSet_']=this['startNameSet_'],_0x18e838['indexStartName_']=this['indexStartName_'],_0x18e838['endSet_']=this['endSet_'],_0x18e838['endBeforeSet_']=this['endBeforeSet_'],_0x18e838['indexEndValue_']=this['indexEndValue_'],_0x18e838['endNameSet_']=this['endNameSet_'],_0x18e838['indexEndName_']=this['indexEndName_'],_0x18e838['index_']=this['index_'],_0x18e838['viewFrom_']=this['viewFrom_'],_0x18e838;}}function Kh(_0x33e448){return _0x33e448['loadsAllData']()?new Xi(_0x33e448['getIndex']()):_0x33e448['hasLimit']()?new jh(_0x33e448):new Ft(_0x33e448);}function Yh(_0x44c2a5,_0x404e88){const _0x4390c3=_0x44c2a5['copy']();return _0x4390c3['limitSet_']=!0x0,_0x4390c3['limit_']=_0x404e88,_0x4390c3['viewFrom_']='l',_0x4390c3;}function Qh(_0x3de3d4,_0x116726,_0x2925e7){const _0x382715=_0x3de3d4['copy']();return _0x382715['startSet_']=!0x0,_0x116726===void 0x0&&(_0x116726=null),_0x382715['indexStartValue_']=_0x116726,_0x2925e7!=null?(_0x382715['startNameSet_']=!0x0,_0x382715['indexStartName_']=_0x2925e7):(_0x382715['startNameSet_']=!0x1,_0x382715['indexStartName_']=''),_0x382715;}function Jh(_0x22b87e,_0x3d4731,_0x3a1aba){const _0x51f7e2=_0x22b87e['copy']();return _0x51f7e2['endSet_']=!0x0,_0x3d4731===void 0x0&&(_0x3d4731=null),_0x51f7e2['indexEndValue_']=_0x3d4731,_0x3a1aba!==void 0x0?(_0x51f7e2['endNameSet_']=!0x0,_0x51f7e2['indexEndName_']=_0x3a1aba):(_0x51f7e2['endNameSet_']=!0x1,_0x51f7e2['indexEndName_']=''),_0x51f7e2;}function xo(_0x2d5572,_0x3ee915){const _0x32d602=_0x2d5572['copy']();return _0x32d602['index_']=_0x3ee915,_0x32d602;}function ir(_0xe68fd5){const _0x1d70bc={};if(_0xe68fd5['isDefault']())return _0x1d70bc;let _0x547de6;if(_0xe68fd5['index_']===R?_0x547de6='$priority':_0xe68fd5['index_']===Mo?_0x547de6='$value':_0xe68fd5['index_']===ve?_0x547de6='$key':(f(_0xe68fd5['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x547de6=_0xe68fd5['index_']['toString']()),_0x1d70bc['orderBy']=O(_0x547de6),_0xe68fd5['startSet_']){const _0x2d86f0=_0xe68fd5['startAfterSet_']?'startAfter':'startAt';_0x1d70bc[_0x2d86f0]=O(_0xe68fd5['indexStartValue_']),_0xe68fd5['startNameSet_']&&(_0x1d70bc[_0x2d86f0]+=','+O(_0xe68fd5['indexStartName_']));}if(_0xe68fd5['endSet_']){const _0x458e14=_0xe68fd5['endBeforeSet_']?'endBefore':'endAt';_0x1d70bc[_0x458e14]=O(_0xe68fd5['indexEndValue_']),_0xe68fd5['endNameSet_']&&(_0x1d70bc[_0x458e14]+=','+O(_0xe68fd5['indexEndName_']));}return _0xe68fd5['limitSet_']&&(_0xe68fd5['isViewFromLeft']()?_0x1d70bc['limitToFirst']=_0xe68fd5['limit_']:_0x1d70bc['limitToLast']=_0xe68fd5['limit_']),_0x1d70bc;}function sr(_0x4b72b3){const _0x5acc07={};if(_0x4b72b3['startSet_']&&(_0x5acc07['sp']=_0x4b72b3['indexStartValue_'],_0x4b72b3['startNameSet_']&&(_0x5acc07['sn']=_0x4b72b3['indexStartName_']),_0x5acc07['sin']=!_0x4b72b3['startAfterSet_']),_0x4b72b3['endSet_']&&(_0x5acc07['ep']=_0x4b72b3['indexEndValue_'],_0x4b72b3['endNameSet_']&&(_0x5acc07['en']=_0x4b72b3['indexEndName_']),_0x5acc07['ein']=!_0x4b72b3['endBeforeSet_']),_0x4b72b3['limitSet_']){_0x5acc07['l']=_0x4b72b3['limit_'];let _0x16455a=_0x4b72b3['viewFrom_'];_0x16455a===''&&(_0x4b72b3['isViewFromLeft']()?_0x16455a='l':_0x16455a='r'),_0x5acc07['vf']=_0x16455a;}return _0x4b72b3['index_']!==R&&(_0x5acc07['i']=_0x4b72b3['index_']['toString']()),_0x5acc07;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x214c0e){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x554b1f,_0x2a983e){return _0x2a983e!==void 0x0?'tag$'+_0x2a983e:(f(_0x554b1f['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x554b1f['_path']['toString']());}constructor(_0x3193a9,_0x613dfe,_0x2b3143,_0xe66c25){super(),this['repoInfo_']=_0x3193a9,this['onDataUpdate_']=_0x613dfe,this['authTokenProvider_']=_0x2b3143,this['appCheckTokenProvider_']=_0xe66c25,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x37125a,_0xbc7e31,_0x985199,_0x59d8da){const _0x4163e8=_0x37125a['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x4163e8+'\x20'+_0x37125a['_queryIdentifier']);const _0x3d83ce=vn['getListenId_'](_0x37125a,_0x985199),_0x200418={};this['listens_'][_0x3d83ce]=_0x200418;const _0x23c886=ir(_0x37125a['_queryParams']);this['restRequest_'](_0x4163e8+'.json',_0x23c886,(_0x282ab4,_0x5ce934)=>{let _0x3d2c53=_0x5ce934;if(_0x282ab4===0x194&&(_0x3d2c53=null,_0x282ab4=null),_0x282ab4===null&&this['onDataUpdate_'](_0x4163e8,_0x3d2c53,!0x1,_0x985199),Le(this['listens_'],_0x3d83ce)===_0x200418){let _0x128229;_0x282ab4?_0x282ab4===0x191?_0x128229='permission_denied':_0x128229='rest_error:'+_0x282ab4:_0x128229='ok',_0x59d8da(_0x128229,null);}});}['unlisten'](_0x2ecf08,_0x4c138d){const _0x5d7eef=vn['getListenId_'](_0x2ecf08,_0x4c138d);delete this['listens_'][_0x5d7eef];}['get'](_0x1b5d1b){const _0x4cbfd4=ir(_0x1b5d1b['_queryParams']),_0x8451d1=_0x1b5d1b['_path']['toString'](),_0x2fbbcd=new H();return this['restRequest_'](_0x8451d1+'.json',_0x4cbfd4,(_0x4fe47d,_0x2aa40f)=>{let _0x24a2a4=_0x2aa40f;_0x4fe47d===0x194&&(_0x24a2a4=null,_0x4fe47d=null),_0x4fe47d===null?(this['onDataUpdate_'](_0x8451d1,_0x24a2a4,!0x1,null),_0x2fbbcd['resolve'](_0x24a2a4)):_0x2fbbcd['reject'](new Error(_0x24a2a4));}),_0x2fbbcd['promise'];}['refreshAuthToken'](_0x46803b){}['restRequest_'](_0x35dcab,_0x5bcac5={},_0x5e662d){return _0x5bcac5['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x2be082,_0x4029db])=>{_0x2be082&&_0x2be082['accessToken']&&(_0x5bcac5['auth']=_0x2be082['accessToken']),_0x4029db&&_0x4029db['token']&&(_0x5bcac5['ac']=_0x4029db['token']);const _0x400318=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x35dcab+'?ns='+this['repoInfo_']['namespace']+ut(_0x5bcac5);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x400318);const _0x5eb85f=new XMLHttpRequest();_0x5eb85f['onreadystatechange']=()=>{if(_0x5e662d&&_0x5eb85f['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x400318+'\x20received.\x20status:',_0x5eb85f['status'],'response:',_0x5eb85f['responseText']);let _0x5ae28a=null;if(_0x5eb85f['status']>=0xc8&&_0x5eb85f['status']<0x12c){try{_0x5ae28a=Nt(_0x5eb85f['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x400318+':\x20'+_0x5eb85f['responseText']);}_0x5e662d(null,_0x5ae28a);}else _0x5eb85f['status']!==0x191&&_0x5eb85f['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x400318+'\x20Status:\x20'+_0x5eb85f['status']),_0x5e662d(_0x5eb85f['status']);_0x5e662d=null;}},_0x5eb85f['open']('GET',_0x400318,!0x0),_0x5eb85f['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0xbd28a1){return this['rootNode_']['getChild'](_0xbd28a1);}['updateSnapshot'](_0x1106b4,_0x240629){this['rootNode_']=this['rootNode_']['updateChild'](_0x1106b4,_0x240629);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x2bfd3c,_0xbb26c7,_0x12279e){if(v(_0xbb26c7))_0x2bfd3c['value']=_0x12279e,_0x2bfd3c['children']['clear']();else{if(_0x2bfd3c['value']!==null)_0x2bfd3c['value']=_0x2bfd3c['value']['updateChild'](_0xbb26c7,_0x12279e);else{const _0x1feab5=y(_0xbb26c7);_0x2bfd3c['children']['has'](_0x1feab5)||_0x2bfd3c['children']['set'](_0x1feab5,En());const _0x4c0921=_0x2bfd3c['children']['get'](_0x1feab5);_0xbb26c7=S(_0xbb26c7),pt(_0x4c0921,_0xbb26c7,_0x12279e);}}}function Ti(_0xcda8ce,_0x59cf35){if(v(_0x59cf35))return _0xcda8ce['value']=null,_0xcda8ce['children']['clear'](),!0x0;if(_0xcda8ce['value']!==null){if(_0xcda8ce['value']['isLeafNode']())return!0x1;{const _0x34b8e9=_0xcda8ce['value'];return _0xcda8ce['value']=null,_0x34b8e9['forEachChild'](R,(_0xd57399,_0x232270)=>{pt(_0xcda8ce,new C(_0xd57399),_0x232270);}),Ti(_0xcda8ce,_0x59cf35);}}else{if(_0xcda8ce['children']['size']>0x0){const _0x1eae5a=y(_0x59cf35);return _0x59cf35=S(_0x59cf35),_0xcda8ce['children']['has'](_0x1eae5a)&&Ti(_0xcda8ce['children']['get'](_0x1eae5a),_0x59cf35)&&_0xcda8ce['children']['delete'](_0x1eae5a),_0xcda8ce['children']['size']===0x0;}else return!0x0;}}function Si(_0x3484b9,_0x800303,_0x4a3e5c){_0x3484b9['value']!==null?_0x4a3e5c(_0x800303,_0x3484b9['value']):Zh(_0x3484b9,(_0x2025ba,_0xe4d9f6)=>{const _0x5a1a46=new C(_0x800303['toString']()+'/'+_0x2025ba);Si(_0xe4d9f6,_0x5a1a46,_0x4a3e5c);});}function Zh(_0x228fd0,_0x1d5469){_0x228fd0['children']['forEach']((_0x2cabd7,_0x294a62)=>{_0x1d5469(_0x294a62,_0x2cabd7);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x8d2ddf){this['collection_']=_0x8d2ddf,this['last_']=null;}['get'](){const _0x12e412=this['collection_']['get'](),_0x573041={..._0x12e412};return this['last_']&&x(this['last_'],(_0x39617b,_0x1fc89b)=>{_0x573041[_0x39617b]=_0x573041[_0x39617b]-_0x1fc89b;}),this['last_']=_0x12e412,_0x573041;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x33acd7,_0x4fd305){this['server_']=_0x4fd305,this['statsToReport_']={},this['statsListener_']=new eu(_0x33acd7);const _0x20258c=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x20258c));}['reportStats_'](){const _0x4cbaba=this['statsListener_']['get'](),_0x1b7543={};let _0x2e3aee=!0x1;x(_0x4cbaba,(_0x3bb332,_0x5666eb)=>{_0x5666eb>0x0&&Q(this['statsToReport_'],_0x3bb332)&&(_0x1b7543[_0x3bb332]=_0x5666eb,_0x2e3aee=!0x0);}),_0x2e3aee&&this['server_']['reportStats'](_0x1b7543),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0xbd386f){_0xbd386f[_0xbd386f['OVERWRITE']=0x0]='OVERWRITE',_0xbd386f[_0xbd386f['MERGE']=0x1]='MERGE',_0xbd386f[_0xbd386f['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0xbd386f[_0xbd386f['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x6d7adb){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x6d7adb,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x5d13a9,_0x4a490f,_0x284a1d){this['path']=_0x5d13a9,this['affectedTree']=_0x4a490f,this['revert']=_0x284a1d,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x5e23f3){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x17ae67=this['affectedTree']['subtree'](new C(_0x5e23f3));return new In(w(),_0x17ae67,this['revert']);}}else return f(y(this['path'])===_0x5e23f3,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x365023,_0x2b5922){this['source']=_0x365023,this['path']=_0x2b5922,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0xd673f6){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x442cb8,_0x8d509c,_0xd8e8a){this['source']=_0x442cb8,this['path']=_0x8d509c,this['snap']=_0xd8e8a,this['type']=z['OVERWRITE'];}['operationForChild'](_0x481d64){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x481d64)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x46f1e0,_0x522c0d,_0x7b9056){this['source']=_0x46f1e0,this['path']=_0x522c0d,this['children']=_0x7b9056,this['type']=z['MERGE'];}['operationForChild'](_0x588883){if(v(this['path'])){const _0x38a4fd=this['children']['subtree'](new C(_0x588883));return _0x38a4fd['isEmpty']()?null:_0x38a4fd['value']?new Be(this['source'],w(),_0x38a4fd['value']):new ot(this['source'],w(),_0x38a4fd);}else return f(y(this['path'])===_0x588883,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x190347,_0x5699f5,_0x403f17){this['node_']=_0x190347,this['fullyInitialized_']=_0x5699f5,this['filtered_']=_0x403f17;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x580c99){if(v(_0x580c99))return this['isFullyInitialized']()&&!this['filtered_'];const _0xf1c7a7=y(_0x580c99);return this['isCompleteForChild'](_0xf1c7a7);}['isCompleteForChild'](_0x2ba092){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x2ba092);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x31538b){this['query_']=_0x31538b,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x25fabd,_0x23ec1c,_0x371b60,_0x3e83d1){const _0x4b3c1d=[],_0x5beec3=[];return _0x23ec1c['forEach'](_0x3ac2a4=>{_0x3ac2a4['type']==='child_changed'&&_0x25fabd['index_']['indexedValueChanged'](_0x3ac2a4['oldSnap'],_0x3ac2a4['snapshotNode'])&&_0x5beec3['push'](zh(_0x3ac2a4['childName'],_0x3ac2a4['snapshotNode']));}),wt(_0x25fabd,_0x4b3c1d,'child_removed',_0x23ec1c,_0x3e83d1,_0x371b60),wt(_0x25fabd,_0x4b3c1d,'child_added',_0x23ec1c,_0x3e83d1,_0x371b60),wt(_0x25fabd,_0x4b3c1d,'child_moved',_0x5beec3,_0x3e83d1,_0x371b60),wt(_0x25fabd,_0x4b3c1d,'child_changed',_0x23ec1c,_0x3e83d1,_0x371b60),wt(_0x25fabd,_0x4b3c1d,'value',_0x23ec1c,_0x3e83d1,_0x371b60),_0x4b3c1d;}function wt(_0x252c92,_0x7ce87c,_0xa9e624,_0x156bf9,_0x5ea1a9,_0xe9100c){const _0x5db92d=_0x156bf9['filter'](_0x3d3703=>_0x3d3703['type']===_0xa9e624);_0x5db92d['sort']((_0x359cbe,_0x2501e0)=>au(_0x252c92,_0x359cbe,_0x2501e0)),_0x5db92d['forEach'](_0x4c0869=>{const _0x39c15c=ou(_0x252c92,_0x4c0869,_0xe9100c);_0x5ea1a9['forEach'](_0x329bcc=>{_0x329bcc['respondsTo'](_0x4c0869['type'])&&_0x7ce87c['push'](_0x329bcc['createEvent'](_0x39c15c,_0x252c92['query_']));});});}function ou(_0x5e7932,_0x3d6c99,_0x5ded68){return _0x3d6c99['type']==='value'||_0x3d6c99['type']==='child_removed'||(_0x3d6c99['prevName']=_0x5ded68['getPredecessorChildName'](_0x3d6c99['childName'],_0x3d6c99['snapshotNode'],_0x5e7932['index_'])),_0x3d6c99;}function au(_0x491bf0,_0x47cba5,_0x5f3567){if(_0x47cba5['childName']==null||_0x5f3567['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x952ed=new E(_0x47cba5['childName'],_0x47cba5['snapshotNode']),_0xadb103=new E(_0x5f3567['childName'],_0x5f3567['snapshotNode']);return _0x491bf0['index_']['compare'](_0x952ed,_0xadb103);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x352a51,_0x5b9cf9){return{'eventCache':_0x352a51,'serverCache':_0x5b9cf9};}function Rt(_0x4ab0f1,_0x2d577e,_0x12e1ea,_0x875081){return Un(new Te(_0x2d577e,_0x12e1ea,_0x875081),_0x4ab0f1['serverCache']);}function Fo(_0x67e195,_0x568ec2,_0x52e46f,_0x34c963){return Un(_0x67e195['eventCache'],new Te(_0x568ec2,_0x52e46f,_0x34c963));}function wn(_0x43a357){return _0x43a357['eventCache']['isFullyInitialized']()?_0x43a357['eventCache']['getNode']():null;}function Ve(_0x432c26){return _0x432c26['serverCache']['isFullyInitialized']()?_0x432c26['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x7ce57f){let _0x18b68e=new b(null);return x(_0x7ce57f,(_0x10e385,_0x5251af)=>{_0x18b68e=_0x18b68e['set'](new C(_0x10e385),_0x5251af);}),_0x18b68e;}constructor(_0x2a6678,_0x5dcf85=cu()){this['value']=_0x2a6678,this['children']=_0x5dcf85;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x58173a,_0x3c3088){if(this['value']!=null&&_0x3c3088(this['value']))return{'path':w(),'value':this['value']};if(v(_0x58173a))return null;{const _0x25bfb7=y(_0x58173a),_0x234656=this['children']['get'](_0x25bfb7);if(_0x234656!==null){const _0x2db4aa=_0x234656['findRootMostMatchingPathAndValue'](S(_0x58173a),_0x3c3088);return _0x2db4aa!=null?{'path':k(new C(_0x25bfb7),_0x2db4aa['path']),'value':_0x2db4aa['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x1f4dc5){return this['findRootMostMatchingPathAndValue'](_0x1f4dc5,()=>!0x0);}['subtree'](_0xa3c509){if(v(_0xa3c509))return this;{const _0x5ca16e=y(_0xa3c509),_0x4d6f0b=this['children']['get'](_0x5ca16e);return _0x4d6f0b!==null?_0x4d6f0b['subtree'](S(_0xa3c509)):new b(null);}}['set'](_0x3c8a83,_0x261a80){if(v(_0x3c8a83))return new b(_0x261a80,this['children']);{const _0x4fd360=y(_0x3c8a83),_0x246986=(this['children']['get'](_0x4fd360)||new b(null))['set'](S(_0x3c8a83),_0x261a80),_0x178388=this['children']['insert'](_0x4fd360,_0x246986);return new b(this['value'],_0x178388);}}['remove'](_0x2ccd27){if(v(_0x2ccd27))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x42d40b=y(_0x2ccd27),_0x211451=this['children']['get'](_0x42d40b);if(_0x211451){const _0x3a0703=_0x211451['remove'](S(_0x2ccd27));let _0x5466a5;return _0x3a0703['isEmpty']()?_0x5466a5=this['children']['remove'](_0x42d40b):_0x5466a5=this['children']['insert'](_0x42d40b,_0x3a0703),this['value']===null&&_0x5466a5['isEmpty']()?new b(null):new b(this['value'],_0x5466a5);}else return this;}}['get'](_0x1ca478){if(v(_0x1ca478))return this['value'];{const _0x40c9fb=y(_0x1ca478),_0x4d121d=this['children']['get'](_0x40c9fb);return _0x4d121d?_0x4d121d['get'](S(_0x1ca478)):null;}}['setTree'](_0x9d9263,_0x1cb98a){if(v(_0x9d9263))return _0x1cb98a;{const _0x4ff3d1=y(_0x9d9263),_0x36ce43=(this['children']['get'](_0x4ff3d1)||new b(null))['setTree'](S(_0x9d9263),_0x1cb98a);let _0x428e75;return _0x36ce43['isEmpty']()?_0x428e75=this['children']['remove'](_0x4ff3d1):_0x428e75=this['children']['insert'](_0x4ff3d1,_0x36ce43),new b(this['value'],_0x428e75);}}['fold'](_0xca9c40){return this['fold_'](w(),_0xca9c40);}['fold_'](_0x39f0eb,_0x2319d2){const _0x470a8b={};return this['children']['inorderTraversal']((_0x480b16,_0x23e83f)=>{_0x470a8b[_0x480b16]=_0x23e83f['fold_'](k(_0x39f0eb,_0x480b16),_0x2319d2);}),_0x2319d2(_0x39f0eb,this['value'],_0x470a8b);}['findOnPath'](_0x17344a,_0x47f735){return this['findOnPath_'](_0x17344a,w(),_0x47f735);}['findOnPath_'](_0x1a2588,_0x550d97,_0x48e714){const _0x24958e=this['value']?_0x48e714(_0x550d97,this['value']):!0x1;if(_0x24958e)return _0x24958e;if(v(_0x1a2588))return null;{const _0x41b03a=y(_0x1a2588),_0x2f6cc0=this['children']['get'](_0x41b03a);return _0x2f6cc0?_0x2f6cc0['findOnPath_'](S(_0x1a2588),k(_0x550d97,_0x41b03a),_0x48e714):null;}}['foreachOnPath'](_0x1d92c7,_0x58be9c){return this['foreachOnPath_'](_0x1d92c7,w(),_0x58be9c);}['foreachOnPath_'](_0x543790,_0x3f7335,_0x4f78f7){if(v(_0x543790))return this;{this['value']&&_0x4f78f7(_0x3f7335,this['value']);const _0x1551b2=y(_0x543790),_0x4d2619=this['children']['get'](_0x1551b2);return _0x4d2619?_0x4d2619['foreachOnPath_'](S(_0x543790),k(_0x3f7335,_0x1551b2),_0x4f78f7):new b(null);}}['foreach'](_0x58da05){this['foreach_'](w(),_0x58da05);}['foreach_'](_0x1e83bd,_0xcad75a){this['children']['inorderTraversal']((_0x124f0d,_0x2a576c)=>{_0x2a576c['foreach_'](k(_0x1e83bd,_0x124f0d),_0xcad75a);}),this['value']&&_0xcad75a(_0x1e83bd,this['value']);}['foreachChild'](_0x5e3c14){this['children']['inorderTraversal']((_0xca02f4,_0x4d21a0)=>{_0x4d21a0['value']&&_0x5e3c14(_0xca02f4,_0x4d21a0['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x4e0af3){this['writeTree_']=_0x4e0af3;}static['empty'](){return new K(new b(null));}}function At(_0x42bed4,_0x378730,_0x16b25b){if(v(_0x378730))return new K(new b(_0x16b25b));{const _0x5097d8=_0x42bed4['writeTree_']['findRootMostValueAndPath'](_0x378730);if(_0x5097d8!=null){const _0x187c6a=_0x5097d8['path'];let _0x19fd77=_0x5097d8['value'];const _0x163e94=F(_0x187c6a,_0x378730);return _0x19fd77=_0x19fd77['updateChild'](_0x163e94,_0x16b25b),new K(_0x42bed4['writeTree_']['set'](_0x187c6a,_0x19fd77));}else{const _0x36cb90=new b(_0x16b25b),_0x5e060a=_0x42bed4['writeTree_']['setTree'](_0x378730,_0x36cb90);return new K(_0x5e060a);}}}function bi(_0x18b427,_0x260d4a,_0x35f4b4){let _0x4ee531=_0x18b427;return x(_0x35f4b4,(_0x5aeeac,_0x12b7ce)=>{_0x4ee531=At(_0x4ee531,k(_0x260d4a,_0x5aeeac),_0x12b7ce);}),_0x4ee531;}function or(_0x30db8a,_0x18540d){if(v(_0x18540d))return K['empty']();{const _0x5a4156=_0x30db8a['writeTree_']['setTree'](_0x18540d,new b(null));return new K(_0x5a4156);}}function Ri(_0x4ed171,_0x5e3ece){return ze(_0x4ed171,_0x5e3ece)!=null;}function ze(_0x4052bf,_0x45ff23){const _0x35f375=_0x4052bf['writeTree_']['findRootMostValueAndPath'](_0x45ff23);return _0x35f375!=null?_0x4052bf['writeTree_']['get'](_0x35f375['path'])['getChild'](F(_0x35f375['path'],_0x45ff23)):null;}function ar(_0x57d47b){const _0x475cf1=[],_0x55823d=_0x57d47b['writeTree_']['value'];return _0x55823d!=null?_0x55823d['isLeafNode']()||_0x55823d['forEachChild'](R,(_0x2f0cd3,_0x25e8ab)=>{_0x475cf1['push'](new E(_0x2f0cd3,_0x25e8ab));}):_0x57d47b['writeTree_']['children']['inorderTraversal']((_0x481d49,_0x2a4f0f)=>{_0x2a4f0f['value']!=null&&_0x475cf1['push'](new E(_0x481d49,_0x2a4f0f['value']));}),_0x475cf1;}function Ee(_0x332835,_0x5b6a3f){if(v(_0x5b6a3f))return _0x332835;{const _0x57796d=ze(_0x332835,_0x5b6a3f);return _0x57796d!=null?new K(new b(_0x57796d)):new K(_0x332835['writeTree_']['subtree'](_0x5b6a3f));}}function Ai(_0x337e7d){return _0x337e7d['writeTree_']['isEmpty']();}function at(_0x46d120,_0x13f9fb){return Uo(w(),_0x46d120['writeTree_'],_0x13f9fb);}function Uo(_0xf52e5f,_0x46a219,_0x27f867){if(_0x46a219['value']!=null)return _0x27f867['updateChild'](_0xf52e5f,_0x46a219['value']);{let _0x121185=null;return _0x46a219['children']['inorderTraversal']((_0x43a94b,_0x3905b7)=>{_0x43a94b==='.priority'?(f(_0x3905b7['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x121185=_0x3905b7['value']):_0x27f867=Uo(k(_0xf52e5f,_0x43a94b),_0x3905b7,_0x27f867);}),!_0x27f867['getChild'](_0xf52e5f)['isEmpty']()&&_0x121185!==null&&(_0x27f867=_0x27f867['updateChild'](k(_0xf52e5f,'.priority'),_0x121185)),_0x27f867;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x2fd232,_0x356d9c){return Ho(_0x356d9c,_0x2fd232);}function lu(_0x4b5e76,_0x59cec6,_0xad4633,_0x38f768,_0x529ecf){f(_0x38f768>_0x4b5e76['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x529ecf===void 0x0&&(_0x529ecf=!0x0),_0x4b5e76['allWrites']['push']({'path':_0x59cec6,'snap':_0xad4633,'writeId':_0x38f768,'visible':_0x529ecf}),_0x529ecf&&(_0x4b5e76['visibleWrites']=At(_0x4b5e76['visibleWrites'],_0x59cec6,_0xad4633)),_0x4b5e76['lastWriteId']=_0x38f768;}function hu(_0x46861a,_0x17335e,_0x1d93fb,_0x56fba5){f(_0x56fba5>_0x46861a['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x46861a['allWrites']['push']({'path':_0x17335e,'children':_0x1d93fb,'writeId':_0x56fba5,'visible':!0x0}),_0x46861a['visibleWrites']=bi(_0x46861a['visibleWrites'],_0x17335e,_0x1d93fb),_0x46861a['lastWriteId']=_0x56fba5;}function uu(_0x1b11f0,_0x5587c4){for(let _0x4a7111=0x0;_0x4a7111<_0x1b11f0['allWrites']['length'];_0x4a7111++){const _0x363303=_0x1b11f0['allWrites'][_0x4a7111];if(_0x363303['writeId']===_0x5587c4)return _0x363303;}return null;}function du(_0x2b654c,_0x285f44){const _0x53a7b6=_0x2b654c['allWrites']['findIndex'](_0x3f8a0b=>_0x3f8a0b['writeId']===_0x285f44);f(_0x53a7b6>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x474e0d=_0x2b654c['allWrites'][_0x53a7b6];_0x2b654c['allWrites']['splice'](_0x53a7b6,0x1);let _0x5c00ed=_0x474e0d['visible'],_0x196cb0=!0x1,_0x36e9d1=_0x2b654c['allWrites']['length']-0x1;for(;_0x5c00ed&&_0x36e9d1>=0x0;){const _0x4abd2c=_0x2b654c['allWrites'][_0x36e9d1];_0x4abd2c['visible']&&(_0x36e9d1>=_0x53a7b6&&fu(_0x4abd2c,_0x474e0d['path'])?_0x5c00ed=!0x1:G(_0x474e0d['path'],_0x4abd2c['path'])&&(_0x196cb0=!0x0)),_0x36e9d1--;}if(_0x5c00ed){if(_0x196cb0)return pu(_0x2b654c),!0x0;if(_0x474e0d['snap'])_0x2b654c['visibleWrites']=or(_0x2b654c['visibleWrites'],_0x474e0d['path']);else{const _0x5a18ab=_0x474e0d['children'];x(_0x5a18ab,_0x245653=>{_0x2b654c['visibleWrites']=or(_0x2b654c['visibleWrites'],k(_0x474e0d['path'],_0x245653));});}return!0x0;}else return!0x1;}function fu(_0x4a6fb6,_0x22c16c){if(_0x4a6fb6['snap'])return G(_0x4a6fb6['path'],_0x22c16c);for(const _0x2a9308 in _0x4a6fb6['children'])if(_0x4a6fb6['children']['hasOwnProperty'](_0x2a9308)&&G(k(_0x4a6fb6['path'],_0x2a9308),_0x22c16c))return!0x0;return!0x1;}function pu(_0x3a9d83){_0x3a9d83['visibleWrites']=Wo(_0x3a9d83['allWrites'],_u,w()),_0x3a9d83['allWrites']['length']>0x0?_0x3a9d83['lastWriteId']=_0x3a9d83['allWrites'][_0x3a9d83['allWrites']['length']-0x1]['writeId']:_0x3a9d83['lastWriteId']=-0x1;}function _u(_0x5d2251){return _0x5d2251['visible'];}function Wo(_0x2a465e,_0x2d973c,_0x2f441e){let _0x3e8131=K['empty']();for(let _0x2e362c=0x0;_0x2e362c<_0x2a465e['length'];++_0x2e362c){const _0x18f464=_0x2a465e[_0x2e362c];if(_0x2d973c(_0x18f464)){const _0x42b42e=_0x18f464['path'];let _0x7d74c4;if(_0x18f464['snap'])G(_0x2f441e,_0x42b42e)?(_0x7d74c4=F(_0x2f441e,_0x42b42e),_0x3e8131=At(_0x3e8131,_0x7d74c4,_0x18f464['snap'])):G(_0x42b42e,_0x2f441e)&&(_0x7d74c4=F(_0x42b42e,_0x2f441e),_0x3e8131=At(_0x3e8131,w(),_0x18f464['snap']['getChild'](_0x7d74c4)));else{if(_0x18f464['children']){if(G(_0x2f441e,_0x42b42e))_0x7d74c4=F(_0x2f441e,_0x42b42e),_0x3e8131=bi(_0x3e8131,_0x7d74c4,_0x18f464['children']);else{if(G(_0x42b42e,_0x2f441e)){if(_0x7d74c4=F(_0x42b42e,_0x2f441e),v(_0x7d74c4))_0x3e8131=bi(_0x3e8131,w(),_0x18f464['children']);else{const _0x3527d1=Le(_0x18f464['children'],y(_0x7d74c4));if(_0x3527d1){const _0x312520=_0x3527d1['getChild'](S(_0x7d74c4));_0x3e8131=At(_0x3e8131,w(),_0x312520);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x3e8131;}function Bo(_0x1db4c3,_0x2ae0fc,_0x459444,_0x3f5fc4,_0x32b47d){if(!_0x3f5fc4&&!_0x32b47d){const _0x52fe9f=ze(_0x1db4c3['visibleWrites'],_0x2ae0fc);if(_0x52fe9f!=null)return _0x52fe9f;{const _0x4b0fdf=Ee(_0x1db4c3['visibleWrites'],_0x2ae0fc);if(Ai(_0x4b0fdf))return _0x459444;if(_0x459444==null&&!Ri(_0x4b0fdf,w()))return null;{const _0x2f8d8f=_0x459444||g['EMPTY_NODE'];return at(_0x4b0fdf,_0x2f8d8f);}}}else{const _0x1559ea=Ee(_0x1db4c3['visibleWrites'],_0x2ae0fc);if(!_0x32b47d&&Ai(_0x1559ea))return _0x459444;if(!_0x32b47d&&_0x459444==null&&!Ri(_0x1559ea,w()))return null;{const _0x5c2a40=function(_0x38937c){return(_0x38937c['visible']||_0x32b47d)&&(!_0x3f5fc4||!~_0x3f5fc4['indexOf'](_0x38937c['writeId']))&&(G(_0x38937c['path'],_0x2ae0fc)||G(_0x2ae0fc,_0x38937c['path']));},_0x524e9a=Wo(_0x1db4c3['allWrites'],_0x5c2a40,_0x2ae0fc),_0x1a26b7=_0x459444||g['EMPTY_NODE'];return at(_0x524e9a,_0x1a26b7);}}}function gu(_0x2679c6,_0x2c9ef5,_0x5d0a1a){let _0x4df2e9=g['EMPTY_NODE'];const _0x1d39e0=ze(_0x2679c6['visibleWrites'],_0x2c9ef5);if(_0x1d39e0)return _0x1d39e0['isLeafNode']()||_0x1d39e0['forEachChild'](R,(_0x303833,_0x3d3b4a)=>{_0x4df2e9=_0x4df2e9['updateImmediateChild'](_0x303833,_0x3d3b4a);}),_0x4df2e9;if(_0x5d0a1a){const _0x5eacf5=Ee(_0x2679c6['visibleWrites'],_0x2c9ef5);return _0x5d0a1a['forEachChild'](R,(_0x1af6ad,_0x4ed7ee)=>{const _0x43e895=at(Ee(_0x5eacf5,new C(_0x1af6ad)),_0x4ed7ee);_0x4df2e9=_0x4df2e9['updateImmediateChild'](_0x1af6ad,_0x43e895);}),ar(_0x5eacf5)['forEach'](_0x5d2d37=>{_0x4df2e9=_0x4df2e9['updateImmediateChild'](_0x5d2d37['name'],_0x5d2d37['node']);}),_0x4df2e9;}else{const _0x5c8ccb=Ee(_0x2679c6['visibleWrites'],_0x2c9ef5);return ar(_0x5c8ccb)['forEach'](_0x339e15=>{_0x4df2e9=_0x4df2e9['updateImmediateChild'](_0x339e15['name'],_0x339e15['node']);}),_0x4df2e9;}}function mu(_0x4b89bb,_0x4399f9,_0x34c192,_0x14db24,_0x2b20ad){f(_0x14db24||_0x2b20ad,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x54a11f=k(_0x4399f9,_0x34c192);if(Ri(_0x4b89bb['visibleWrites'],_0x54a11f))return null;{const _0x206f7a=Ee(_0x4b89bb['visibleWrites'],_0x54a11f);return Ai(_0x206f7a)?_0x2b20ad['getChild'](_0x34c192):at(_0x206f7a,_0x2b20ad['getChild'](_0x34c192));}}function yu(_0x2a41c4,_0x24ad19,_0x25d6eb,_0x461395){const _0x2dc76c=k(_0x24ad19,_0x25d6eb),_0x3778b5=ze(_0x2a41c4['visibleWrites'],_0x2dc76c);if(_0x3778b5!=null)return _0x3778b5;if(_0x461395['isCompleteForChild'](_0x25d6eb)){const _0x1fcf88=Ee(_0x2a41c4['visibleWrites'],_0x2dc76c);return at(_0x1fcf88,_0x461395['getNode']()['getImmediateChild'](_0x25d6eb));}else return null;}function vu(_0x34bdd2,_0x3502de){return ze(_0x34bdd2['visibleWrites'],_0x3502de);}function Eu(_0x3f11cd,_0x2eb7c9,_0x114ec0,_0xf64fde,_0x16ec25,_0x221acf,_0x57cd46){let _0x315e5d;const _0x3cc4a0=Ee(_0x3f11cd['visibleWrites'],_0x2eb7c9),_0x4e2565=ze(_0x3cc4a0,w());if(_0x4e2565!=null)_0x315e5d=_0x4e2565;else{if(_0x114ec0!=null)_0x315e5d=at(_0x3cc4a0,_0x114ec0);else return[];}if(_0x315e5d=_0x315e5d['withIndex'](_0x57cd46),!_0x315e5d['isEmpty']()&&!_0x315e5d['isLeafNode']()){const _0x2a738d=[],_0xbd807=_0x57cd46['getCompare'](),_0x45c9de=_0x221acf?_0x315e5d['getReverseIteratorFrom'](_0xf64fde,_0x57cd46):_0x315e5d['getIteratorFrom'](_0xf64fde,_0x57cd46);let _0x4a1cd0=_0x45c9de['getNext']();for(;_0x4a1cd0&&_0x2a738d['length']<_0x16ec25;)_0xbd807(_0x4a1cd0,_0xf64fde)!==0x0&&_0x2a738d['push'](_0x4a1cd0),_0x4a1cd0=_0x45c9de['getNext']();return _0x2a738d;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x376df1,_0x578be4,_0x493882,_0x771ad0){return Bo(_0x376df1['writeTree'],_0x376df1['treePath'],_0x578be4,_0x493882,_0x771ad0);}function is(_0x5ed547,_0x369bc0){return gu(_0x5ed547['writeTree'],_0x5ed547['treePath'],_0x369bc0);}function cr(_0x43befd,_0x25a203,_0x1f1df6,_0x2f2d64){return mu(_0x43befd['writeTree'],_0x43befd['treePath'],_0x25a203,_0x1f1df6,_0x2f2d64);}function Tn(_0x4dccc0,_0x2c0d5c){return vu(_0x4dccc0['writeTree'],k(_0x4dccc0['treePath'],_0x2c0d5c));}function wu(_0x1eb3f7,_0x49b670,_0x4a3418,_0x43c789,_0x1284bd,_0x306a6c){return Eu(_0x1eb3f7['writeTree'],_0x1eb3f7['treePath'],_0x49b670,_0x4a3418,_0x43c789,_0x1284bd,_0x306a6c);}function ss(_0x29aec8,_0x3d32f0,_0x25672b){return yu(_0x29aec8['writeTree'],_0x29aec8['treePath'],_0x3d32f0,_0x25672b);}function Vo(_0x5471e6,_0x50255e){return Ho(k(_0x5471e6['treePath'],_0x50255e),_0x5471e6['writeTree']);}function Ho(_0x1a0b93,_0x258c78){return{'treePath':_0x1a0b93,'writeTree':_0x258c78};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x184487){const _0xbca777=_0x184487['type'],_0x4f7de1=_0x184487['childName'];f(_0xbca777==='child_added'||_0xbca777==='child_changed'||_0xbca777==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x4f7de1!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x38de3d=this['changeMap']['get'](_0x4f7de1);if(_0x38de3d){const _0x22ef09=_0x38de3d['type'];if(_0xbca777==='child_added'&&_0x22ef09==='child_removed')this['changeMap']['set'](_0x4f7de1,xt(_0x4f7de1,_0x184487['snapshotNode'],_0x38de3d['snapshotNode']));else{if(_0xbca777==='child_removed'&&_0x22ef09==='child_added')this['changeMap']['delete'](_0x4f7de1);else{if(_0xbca777==='child_removed'&&_0x22ef09==='child_changed')this['changeMap']['set'](_0x4f7de1,Lt(_0x4f7de1,_0x38de3d['oldSnap']));else{if(_0xbca777==='child_changed'&&_0x22ef09==='child_added')this['changeMap']['set'](_0x4f7de1,rt(_0x4f7de1,_0x184487['snapshotNode']));else{if(_0xbca777==='child_changed'&&_0x22ef09==='child_changed')this['changeMap']['set'](_0x4f7de1,xt(_0x4f7de1,_0x184487['snapshotNode'],_0x38de3d['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x184487+'\x20occurred\x20after\x20'+_0x38de3d);}}}}}else this['changeMap']['set'](_0x4f7de1,_0x184487);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x22464a){return null;}['getChildAfterChild'](_0x4737fe,_0x5d6f2c,_0x348cf4){return null;}}const $o=new Tu();class rs{constructor(_0x410754,_0x354dab,_0x4f9215=null){this['writes_']=_0x410754,this['viewCache_']=_0x354dab,this['optCompleteServerCache_']=_0x4f9215;}['getCompleteChild'](_0x2ca1fe){const _0x102b23=this['viewCache_']['eventCache'];if(_0x102b23['isCompleteForChild'](_0x2ca1fe))return _0x102b23['getNode']()['getImmediateChild'](_0x2ca1fe);{const _0x46a739=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x2ca1fe,_0x46a739);}}['getChildAfterChild'](_0x3a20b9,_0x5035a7,_0x2c3a1f){const _0x4c9025=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x231138=wu(this['writes_'],_0x4c9025,_0x5035a7,0x1,_0x2c3a1f,_0x3a20b9);return _0x231138['length']===0x0?null:_0x231138[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x4ce4f9){return{'filter':_0x4ce4f9};}function bu(_0x10a105,_0xe45de1){f(_0xe45de1['eventCache']['getNode']()['isIndexed'](_0x10a105['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0xe45de1['serverCache']['getNode']()['isIndexed'](_0x10a105['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x529563,_0x151404,_0x46407a,_0x37d73,_0x40fe72){const _0x5a7d93=new Cu();let _0x48d230,_0x44793e;if(_0x46407a['type']===z['OVERWRITE']){const _0x394c81=_0x46407a;_0x394c81['source']['fromUser']?_0x48d230=ki(_0x529563,_0x151404,_0x394c81['path'],_0x394c81['snap'],_0x37d73,_0x40fe72,_0x5a7d93):(f(_0x394c81['source']['fromServer'],'Unknown\x20source.'),_0x44793e=_0x394c81['source']['tagged']||_0x151404['serverCache']['isFiltered']()&&!v(_0x394c81['path']),_0x48d230=Sn(_0x529563,_0x151404,_0x394c81['path'],_0x394c81['snap'],_0x37d73,_0x40fe72,_0x44793e,_0x5a7d93));}else{if(_0x46407a['type']===z['MERGE']){const _0x37683a=_0x46407a;_0x37683a['source']['fromUser']?_0x48d230=ku(_0x529563,_0x151404,_0x37683a['path'],_0x37683a['children'],_0x37d73,_0x40fe72,_0x5a7d93):(f(_0x37683a['source']['fromServer'],'Unknown\x20source.'),_0x44793e=_0x37683a['source']['tagged']||_0x151404['serverCache']['isFiltered'](),_0x48d230=Pi(_0x529563,_0x151404,_0x37683a['path'],_0x37683a['children'],_0x37d73,_0x40fe72,_0x44793e,_0x5a7d93));}else{if(_0x46407a['type']===z['ACK_USER_WRITE']){const _0x1d8bd2=_0x46407a;_0x1d8bd2['revert']?_0x48d230=Ou(_0x529563,_0x151404,_0x1d8bd2['path'],_0x37d73,_0x40fe72,_0x5a7d93):_0x48d230=Pu(_0x529563,_0x151404,_0x1d8bd2['path'],_0x1d8bd2['affectedTree'],_0x37d73,_0x40fe72,_0x5a7d93);}else{if(_0x46407a['type']===z['LISTEN_COMPLETE'])_0x48d230=Nu(_0x529563,_0x151404,_0x46407a['path'],_0x37d73,_0x5a7d93);else throw ht('Unknown\x20operation\x20type:\x20'+_0x46407a['type']);}}}const _0x313092=_0x5a7d93['getChanges']();return Au(_0x151404,_0x48d230,_0x313092),{'viewCache':_0x48d230,'changes':_0x313092};}function Au(_0x25b258,_0x5fb12c,_0x48fbfb){const _0x2bfc7e=_0x5fb12c['eventCache'];if(_0x2bfc7e['isFullyInitialized']()){const _0x14f5e1=_0x2bfc7e['getNode']()['isLeafNode']()||_0x2bfc7e['getNode']()['isEmpty'](),_0x522008=wn(_0x25b258);(_0x48fbfb['length']>0x0||!_0x25b258['eventCache']['isFullyInitialized']()||_0x14f5e1&&!_0x2bfc7e['getNode']()['equals'](_0x522008)||!_0x2bfc7e['getNode']()['getPriority']()['equals'](_0x522008['getPriority']()))&&_0x48fbfb['push'](Lo(wn(_0x5fb12c)));}}function Go(_0x9f7800,_0x3c5315,_0xd947c3,_0x56ed39,_0x3a2d3e,_0x397f01){const _0x108a15=_0x3c5315['eventCache'];if(Tn(_0x56ed39,_0xd947c3)!=null)return _0x3c5315;{let _0x32ada2,_0x41b602;if(v(_0xd947c3)){if(f(_0x3c5315['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x3c5315['serverCache']['isFiltered']()){const _0xd82856=Ve(_0x3c5315),_0x1c2070=_0xd82856 instanceof g?_0xd82856:g['EMPTY_NODE'],_0x4516d7=is(_0x56ed39,_0x1c2070);_0x32ada2=_0x9f7800['filter']['updateFullNode'](_0x3c5315['eventCache']['getNode'](),_0x4516d7,_0x397f01);}else{const _0x15009f=Cn(_0x56ed39,Ve(_0x3c5315));_0x32ada2=_0x9f7800['filter']['updateFullNode'](_0x3c5315['eventCache']['getNode'](),_0x15009f,_0x397f01);}}else{const _0x56b81e=y(_0xd947c3);if(_0x56b81e==='.priority'){f(Ce(_0xd947c3)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x5e6aec=_0x108a15['getNode']();_0x41b602=_0x3c5315['serverCache']['getNode']();const _0x2b2c6c=cr(_0x56ed39,_0xd947c3,_0x5e6aec,_0x41b602);_0x2b2c6c!=null?_0x32ada2=_0x9f7800['filter']['updatePriority'](_0x5e6aec,_0x2b2c6c):_0x32ada2=_0x108a15['getNode']();}else{const _0x5a0958=S(_0xd947c3);let _0x2e620b;if(_0x108a15['isCompleteForChild'](_0x56b81e)){_0x41b602=_0x3c5315['serverCache']['getNode']();const _0x406ad=cr(_0x56ed39,_0xd947c3,_0x108a15['getNode'](),_0x41b602);_0x406ad!=null?_0x2e620b=_0x108a15['getNode']()['getImmediateChild'](_0x56b81e)['updateChild'](_0x5a0958,_0x406ad):_0x2e620b=_0x108a15['getNode']()['getImmediateChild'](_0x56b81e);}else _0x2e620b=ss(_0x56ed39,_0x56b81e,_0x3c5315['serverCache']);_0x2e620b!=null?_0x32ada2=_0x9f7800['filter']['updateChild'](_0x108a15['getNode'](),_0x56b81e,_0x2e620b,_0x5a0958,_0x3a2d3e,_0x397f01):_0x32ada2=_0x108a15['getNode']();}}return Rt(_0x3c5315,_0x32ada2,_0x108a15['isFullyInitialized']()||v(_0xd947c3),_0x9f7800['filter']['filtersNodes']());}}function Sn(_0x6c3e03,_0x4bd8b2,_0x885c08,_0x5cb790,_0x1f9c0b,_0xbe126a,_0x2b197e,_0x57a204){const _0x1f0333=_0x4bd8b2['serverCache'];let _0xa71e9f;const _0x395a32=_0x2b197e?_0x6c3e03['filter']:_0x6c3e03['filter']['getIndexedFilter']();if(v(_0x885c08))_0xa71e9f=_0x395a32['updateFullNode'](_0x1f0333['getNode'](),_0x5cb790,null);else{if(_0x395a32['filtersNodes']()&&!_0x1f0333['isFiltered']()){const _0x32f144=_0x1f0333['getNode']()['updateChild'](_0x885c08,_0x5cb790);_0xa71e9f=_0x395a32['updateFullNode'](_0x1f0333['getNode'](),_0x32f144,null);}else{const _0x35a49f=y(_0x885c08);if(!_0x1f0333['isCompleteForPath'](_0x885c08)&&Ce(_0x885c08)>0x1)return _0x4bd8b2;const _0x4aeb02=S(_0x885c08),_0x920de0=_0x1f0333['getNode']()['getImmediateChild'](_0x35a49f)['updateChild'](_0x4aeb02,_0x5cb790);_0x35a49f==='.priority'?_0xa71e9f=_0x395a32['updatePriority'](_0x1f0333['getNode'](),_0x920de0):_0xa71e9f=_0x395a32['updateChild'](_0x1f0333['getNode'](),_0x35a49f,_0x920de0,_0x4aeb02,$o,null);}}const _0x1e4907=Fo(_0x4bd8b2,_0xa71e9f,_0x1f0333['isFullyInitialized']()||v(_0x885c08),_0x395a32['filtersNodes']()),_0x1a3053=new rs(_0x1f9c0b,_0x1e4907,_0xbe126a);return Go(_0x6c3e03,_0x1e4907,_0x885c08,_0x1f9c0b,_0x1a3053,_0x57a204);}function ki(_0x405f0f,_0x1884ec,_0x38551c,_0xf94189,_0x36dabd,_0x3f98f5,_0x16f5b2){const _0x403415=_0x1884ec['eventCache'];let _0x267ba4,_0x1afb71;const _0x237d81=new rs(_0x36dabd,_0x1884ec,_0x3f98f5);if(v(_0x38551c))_0x1afb71=_0x405f0f['filter']['updateFullNode'](_0x1884ec['eventCache']['getNode'](),_0xf94189,_0x16f5b2),_0x267ba4=Rt(_0x1884ec,_0x1afb71,!0x0,_0x405f0f['filter']['filtersNodes']());else{const _0x33c362=y(_0x38551c);if(_0x33c362==='.priority')_0x1afb71=_0x405f0f['filter']['updatePriority'](_0x1884ec['eventCache']['getNode'](),_0xf94189),_0x267ba4=Rt(_0x1884ec,_0x1afb71,_0x403415['isFullyInitialized'](),_0x403415['isFiltered']());else{const _0x4aaac4=S(_0x38551c),_0x5954cf=_0x403415['getNode']()['getImmediateChild'](_0x33c362);let _0x2f1c9e;if(v(_0x4aaac4))_0x2f1c9e=_0xf94189;else{const _0x39447b=_0x237d81['getCompleteChild'](_0x33c362);_0x39447b!=null?ji(_0x4aaac4)==='.priority'&&_0x39447b['getChild'](Ro(_0x4aaac4))['isEmpty']()?_0x2f1c9e=_0x39447b:_0x2f1c9e=_0x39447b['updateChild'](_0x4aaac4,_0xf94189):_0x2f1c9e=g['EMPTY_NODE'];}if(_0x5954cf['equals'](_0x2f1c9e))_0x267ba4=_0x1884ec;else{const _0x28b44c=_0x405f0f['filter']['updateChild'](_0x403415['getNode'](),_0x33c362,_0x2f1c9e,_0x4aaac4,_0x237d81,_0x16f5b2);_0x267ba4=Rt(_0x1884ec,_0x28b44c,_0x403415['isFullyInitialized'](),_0x405f0f['filter']['filtersNodes']());}}}return _0x267ba4;}function lr(_0x199d79,_0x415517){return _0x199d79['eventCache']['isCompleteForChild'](_0x415517);}function ku(_0x46863e,_0x2bac71,_0x137645,_0x18ca7d,_0x1b576c,_0x30044e,_0x55a9b8){let _0x2ba124=_0x2bac71;return _0x18ca7d['foreach']((_0x4787cb,_0x5c618d)=>{const _0x50bc38=k(_0x137645,_0x4787cb);lr(_0x2bac71,y(_0x50bc38))&&(_0x2ba124=ki(_0x46863e,_0x2ba124,_0x50bc38,_0x5c618d,_0x1b576c,_0x30044e,_0x55a9b8));}),_0x18ca7d['foreach']((_0x392bd1,_0x413435)=>{const _0x57bed4=k(_0x137645,_0x392bd1);lr(_0x2bac71,y(_0x57bed4))||(_0x2ba124=ki(_0x46863e,_0x2ba124,_0x57bed4,_0x413435,_0x1b576c,_0x30044e,_0x55a9b8));}),_0x2ba124;}function hr(_0x2082d8,_0x29ca23,_0x381d51){return _0x381d51['foreach']((_0x491ed0,_0xeaf0a8)=>{_0x29ca23=_0x29ca23['updateChild'](_0x491ed0,_0xeaf0a8);}),_0x29ca23;}function Pi(_0x46dca8,_0x1f9e68,_0x10afbf,_0x2958d5,_0x54733b,_0x3c22eb,_0x4e0fdb,_0xa7941d){if(_0x1f9e68['serverCache']['getNode']()['isEmpty']()&&!_0x1f9e68['serverCache']['isFullyInitialized']())return _0x1f9e68;let _0x3e0655=_0x1f9e68,_0x543585;v(_0x10afbf)?_0x543585=_0x2958d5:_0x543585=new b(null)['setTree'](_0x10afbf,_0x2958d5);const _0x2d0558=_0x1f9e68['serverCache']['getNode']();return _0x543585['children']['inorderTraversal']((_0x3f810f,_0x18841f)=>{if(_0x2d0558['hasChild'](_0x3f810f)){const _0x32b7b3=_0x1f9e68['serverCache']['getNode']()['getImmediateChild'](_0x3f810f),_0x9e9b01=hr(_0x46dca8,_0x32b7b3,_0x18841f);_0x3e0655=Sn(_0x46dca8,_0x3e0655,new C(_0x3f810f),_0x9e9b01,_0x54733b,_0x3c22eb,_0x4e0fdb,_0xa7941d);}}),_0x543585['children']['inorderTraversal']((_0x45400c,_0x1cecf8)=>{const _0x511f17=!_0x1f9e68['serverCache']['isCompleteForChild'](_0x45400c)&&_0x1cecf8['value']===null;if(!_0x2d0558['hasChild'](_0x45400c)&&!_0x511f17){const _0x1588ab=_0x1f9e68['serverCache']['getNode']()['getImmediateChild'](_0x45400c),_0x28537e=hr(_0x46dca8,_0x1588ab,_0x1cecf8);_0x3e0655=Sn(_0x46dca8,_0x3e0655,new C(_0x45400c),_0x28537e,_0x54733b,_0x3c22eb,_0x4e0fdb,_0xa7941d);}}),_0x3e0655;}function Pu(_0x5a5fd0,_0x2c5731,_0x106b02,_0x3df24f,_0x5eeacf,_0x50ed5b,_0x1e31d5){if(Tn(_0x5eeacf,_0x106b02)!=null)return _0x2c5731;const _0x391dc9=_0x2c5731['serverCache']['isFiltered'](),_0x1916be=_0x2c5731['serverCache'];if(_0x3df24f['value']!=null){if(v(_0x106b02)&&_0x1916be['isFullyInitialized']()||_0x1916be['isCompleteForPath'](_0x106b02))return Sn(_0x5a5fd0,_0x2c5731,_0x106b02,_0x1916be['getNode']()['getChild'](_0x106b02),_0x5eeacf,_0x50ed5b,_0x391dc9,_0x1e31d5);if(v(_0x106b02)){let _0x38b6fa=new b(null);return _0x1916be['getNode']()['forEachChild'](ve,(_0x3fdf20,_0x1c6cf3)=>{_0x38b6fa=_0x38b6fa['set'](new C(_0x3fdf20),_0x1c6cf3);}),Pi(_0x5a5fd0,_0x2c5731,_0x106b02,_0x38b6fa,_0x5eeacf,_0x50ed5b,_0x391dc9,_0x1e31d5);}else return _0x2c5731;}else{let _0x531f80=new b(null);return _0x3df24f['foreach']((_0x153f0d,_0x3714a5)=>{const _0x1cf8c5=k(_0x106b02,_0x153f0d);_0x1916be['isCompleteForPath'](_0x1cf8c5)&&(_0x531f80=_0x531f80['set'](_0x153f0d,_0x1916be['getNode']()['getChild'](_0x1cf8c5)));}),Pi(_0x5a5fd0,_0x2c5731,_0x106b02,_0x531f80,_0x5eeacf,_0x50ed5b,_0x391dc9,_0x1e31d5);}}function Nu(_0x4d672b,_0x4b7d5c,_0x16b208,_0x54a6d0,_0x3254a7){const _0x427db8=_0x4b7d5c['serverCache'],_0x2539dd=Fo(_0x4b7d5c,_0x427db8['getNode'](),_0x427db8['isFullyInitialized']()||v(_0x16b208),_0x427db8['isFiltered']());return Go(_0x4d672b,_0x2539dd,_0x16b208,_0x54a6d0,$o,_0x3254a7);}function Ou(_0x5ac8a6,_0x2deba6,_0x3e86b3,_0x2a58f6,_0x1f864f,_0x39c72b){let _0x3a7983;if(Tn(_0x2a58f6,_0x3e86b3)!=null)return _0x2deba6;{const _0x47fa17=new rs(_0x2a58f6,_0x2deba6,_0x1f864f),_0x3c42be=_0x2deba6['eventCache']['getNode']();let _0x2b7627;if(v(_0x3e86b3)||y(_0x3e86b3)==='.priority'){let _0x110864;if(_0x2deba6['serverCache']['isFullyInitialized']())_0x110864=Cn(_0x2a58f6,Ve(_0x2deba6));else{const _0x2f2684=_0x2deba6['serverCache']['getNode']();f(_0x2f2684 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x110864=is(_0x2a58f6,_0x2f2684);}_0x110864=_0x110864,_0x2b7627=_0x5ac8a6['filter']['updateFullNode'](_0x3c42be,_0x110864,_0x39c72b);}else{const _0x4b0c32=y(_0x3e86b3);let _0x2edcc2=ss(_0x2a58f6,_0x4b0c32,_0x2deba6['serverCache']);_0x2edcc2==null&&_0x2deba6['serverCache']['isCompleteForChild'](_0x4b0c32)&&(_0x2edcc2=_0x3c42be['getImmediateChild'](_0x4b0c32)),_0x2edcc2!=null?_0x2b7627=_0x5ac8a6['filter']['updateChild'](_0x3c42be,_0x4b0c32,_0x2edcc2,S(_0x3e86b3),_0x47fa17,_0x39c72b):_0x2deba6['eventCache']['getNode']()['hasChild'](_0x4b0c32)?_0x2b7627=_0x5ac8a6['filter']['updateChild'](_0x3c42be,_0x4b0c32,g['EMPTY_NODE'],S(_0x3e86b3),_0x47fa17,_0x39c72b):_0x2b7627=_0x3c42be,_0x2b7627['isEmpty']()&&_0x2deba6['serverCache']['isFullyInitialized']()&&(_0x3a7983=Cn(_0x2a58f6,Ve(_0x2deba6)),_0x3a7983['isLeafNode']()&&(_0x2b7627=_0x5ac8a6['filter']['updateFullNode'](_0x2b7627,_0x3a7983,_0x39c72b)));}return _0x3a7983=_0x2deba6['serverCache']['isFullyInitialized']()||Tn(_0x2a58f6,w())!=null,Rt(_0x2deba6,_0x2b7627,_0x3a7983,_0x5ac8a6['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x5c2b3b,_0x734447){this['query_']=_0x5c2b3b,this['eventRegistrations_']=[];const _0x3386ed=this['query_']['_queryParams'],_0x228913=new Xi(_0x3386ed['getIndex']()),_0x49eb35=Kh(_0x3386ed);this['processor_']=Su(_0x49eb35);const _0x34ce97=_0x734447['serverCache'],_0x4dc02e=_0x734447['eventCache'],_0x378abb=_0x228913['updateFullNode'](g['EMPTY_NODE'],_0x34ce97['getNode'](),null),_0x49007a=_0x49eb35['updateFullNode'](g['EMPTY_NODE'],_0x4dc02e['getNode'](),null),_0x4e90b4=new Te(_0x378abb,_0x34ce97['isFullyInitialized'](),_0x228913['filtersNodes']()),_0x312ecc=new Te(_0x49007a,_0x4dc02e['isFullyInitialized'](),_0x49eb35['filtersNodes']());this['viewCache_']=Un(_0x312ecc,_0x4e90b4),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x288d1d){return _0x288d1d['viewCache_']['serverCache']['getNode']();}function Lu(_0x36dff5){return wn(_0x36dff5['viewCache_']);}function xu(_0x1e4379,_0x420183){const _0x498e85=Ve(_0x1e4379['viewCache_']);return _0x498e85&&(_0x1e4379['query']['_queryParams']['loadsAllData']()||!v(_0x420183)&&!_0x498e85['getImmediateChild'](y(_0x420183))['isEmpty']())?_0x498e85['getChild'](_0x420183):null;}function ur(_0x47b448){return _0x47b448['eventRegistrations_']['length']===0x0;}function Fu(_0x44f720,_0x3888e7){_0x44f720['eventRegistrations_']['push'](_0x3888e7);}function dr(_0x4cba0b,_0x4165f4,_0x532871){const _0xb558b=[];if(_0x532871){f(_0x4165f4==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x469b3b=_0x4cba0b['query']['_path'];_0x4cba0b['eventRegistrations_']['forEach'](_0x423f9d=>{const _0xe47f70=_0x423f9d['createCancelEvent'](_0x532871,_0x469b3b);_0xe47f70&&_0xb558b['push'](_0xe47f70);});}if(_0x4165f4){let _0x7a1d5a=[];for(let _0x8d5759=0x0;_0x8d5759<_0x4cba0b['eventRegistrations_']['length'];++_0x8d5759){const _0x304258=_0x4cba0b['eventRegistrations_'][_0x8d5759];if(!_0x304258['matches'](_0x4165f4))_0x7a1d5a['push'](_0x304258);else{if(_0x4165f4['hasAnyCallback']()){_0x7a1d5a=_0x7a1d5a['concat'](_0x4cba0b['eventRegistrations_']['slice'](_0x8d5759+0x1));break;}}}_0x4cba0b['eventRegistrations_']=_0x7a1d5a;}else _0x4cba0b['eventRegistrations_']=[];return _0xb558b;}function fr(_0x58d34a,_0x2c53e3,_0x1dcae6,_0x4a14ed){_0x2c53e3['type']===z['MERGE']&&_0x2c53e3['source']['queryId']!==null&&(f(Ve(_0x58d34a['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x58d34a['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x16a012=_0x58d34a['viewCache_'],_0x2fef97=Ru(_0x58d34a['processor_'],_0x16a012,_0x2c53e3,_0x1dcae6,_0x4a14ed);return bu(_0x58d34a['processor_'],_0x2fef97['viewCache']),f(_0x2fef97['viewCache']['serverCache']['isFullyInitialized']()||!_0x16a012['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x58d34a['viewCache_']=_0x2fef97['viewCache'],qo(_0x58d34a,_0x2fef97['changes'],_0x2fef97['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x57ee83,_0xff19b1){const _0xc93210=_0x57ee83['viewCache_']['eventCache'],_0x242e62=[];return _0xc93210['getNode']()['isLeafNode']()||_0xc93210['getNode']()['forEachChild'](R,(_0x276b20,_0x1ccd4f)=>{_0x242e62['push'](rt(_0x276b20,_0x1ccd4f));}),_0xc93210['isFullyInitialized']()&&_0x242e62['push'](Lo(_0xc93210['getNode']())),qo(_0x57ee83,_0x242e62,_0xc93210['getNode'](),_0xff19b1);}function qo(_0x109db7,_0x4ba553,_0x563a74,_0x7627b6){const _0x3e69bf=_0x7627b6?[_0x7627b6]:_0x109db7['eventRegistrations_'];return ru(_0x109db7['eventGenerator_'],_0x4ba553,_0x563a74,_0x3e69bf);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0xf259f7){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0xf259f7;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x115767){return _0x115767['views']['size']===0x0;}function os(_0x554d64,_0xbcfd09,_0x33860d,_0x2719bb){const _0xc371d5=_0xbcfd09['source']['queryId'];if(_0xc371d5!==null){const _0xd3d9e2=_0x554d64['views']['get'](_0xc371d5);return f(_0xd3d9e2!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0xd3d9e2,_0xbcfd09,_0x33860d,_0x2719bb);}else{let _0x4c2fdb=[];for(const _0x35ed81 of _0x554d64['views']['values']())_0x4c2fdb=_0x4c2fdb['concat'](fr(_0x35ed81,_0xbcfd09,_0x33860d,_0x2719bb));return _0x4c2fdb;}}function jo(_0x3b866e,_0x40f619,_0x29e69d,_0x405277,_0x4b4380){const _0x19cc61=_0x40f619['_queryIdentifier'],_0x505ce6=_0x3b866e['views']['get'](_0x19cc61);if(!_0x505ce6){let _0x1c8032=Cn(_0x29e69d,_0x4b4380?_0x405277:null),_0x84482d=!0x1;_0x1c8032?_0x84482d=!0x0:_0x405277 instanceof g?(_0x1c8032=is(_0x29e69d,_0x405277),_0x84482d=!0x1):(_0x1c8032=g['EMPTY_NODE'],_0x84482d=!0x1);const _0xf2caa2=Un(new Te(_0x1c8032,_0x84482d,!0x1),new Te(_0x405277,_0x4b4380,!0x1));return new Du(_0x40f619,_0xf2caa2);}return _0x505ce6;}function Hu(_0x3f3758,_0x49d924,_0x57acbf,_0x2e090d,_0x5756de,_0x38e988){const _0x2cd710=jo(_0x3f3758,_0x49d924,_0x2e090d,_0x5756de,_0x38e988);return _0x3f3758['views']['has'](_0x49d924['_queryIdentifier'])||_0x3f3758['views']['set'](_0x49d924['_queryIdentifier'],_0x2cd710),Fu(_0x2cd710,_0x57acbf),Uu(_0x2cd710,_0x57acbf);}function $u(_0x5c8c07,_0x3b4ffc,_0x5ed84f,_0x379ba5){const _0x1a2257=_0x3b4ffc['_queryIdentifier'],_0x1ab67e=[];let _0x1c5faa=[];const _0x290d20=Se(_0x5c8c07);if(_0x1a2257==='default'){for(const [_0x251503,_0x1c71fe]of _0x5c8c07['views']['entries']())_0x1c5faa=_0x1c5faa['concat'](dr(_0x1c71fe,_0x5ed84f,_0x379ba5)),ur(_0x1c71fe)&&(_0x5c8c07['views']['delete'](_0x251503),_0x1c71fe['query']['_queryParams']['loadsAllData']()||_0x1ab67e['push'](_0x1c71fe['query']));}else{const _0x28af64=_0x5c8c07['views']['get'](_0x1a2257);_0x28af64&&(_0x1c5faa=_0x1c5faa['concat'](dr(_0x28af64,_0x5ed84f,_0x379ba5)),ur(_0x28af64)&&(_0x5c8c07['views']['delete'](_0x1a2257),_0x28af64['query']['_queryParams']['loadsAllData']()||_0x1ab67e['push'](_0x28af64['query'])));}return _0x290d20&&!Se(_0x5c8c07)&&_0x1ab67e['push'](new(Bu())(_0x3b4ffc['_repo'],_0x3b4ffc['_path'])),{'removed':_0x1ab67e,'events':_0x1c5faa};}function Ko(_0x3addc5){const _0x515948=[];for(const _0x4907b9 of _0x3addc5['views']['values']())_0x4907b9['query']['_queryParams']['loadsAllData']()||_0x515948['push'](_0x4907b9);return _0x515948;}function Ie(_0x190540,_0x5707a9){let _0x397734=null;for(const _0x11c634 of _0x190540['views']['values']())_0x397734=_0x397734||xu(_0x11c634,_0x5707a9);return _0x397734;}function Yo(_0x3b6097,_0x1947bb){if(_0x1947bb['_queryParams']['loadsAllData']())return Bn(_0x3b6097);{const _0x8776e6=_0x1947bb['_queryIdentifier'];return _0x3b6097['views']['get'](_0x8776e6);}}function Qo(_0x2453e0,_0x3516f6){return Yo(_0x2453e0,_0x3516f6)!=null;}function Se(_0x13dd46){return Bn(_0x13dd46)!=null;}function Bn(_0x46fb9b){for(const _0x455b05 of _0x46fb9b['views']['values']())if(_0x455b05['query']['_queryParams']['loadsAllData']())return _0x455b05;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x2439f6){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x2439f6;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x4af41e){this['listenProvider_']=_0x4af41e,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x11751f,_0x15d94d,_0x1936ba,_0x84c831,_0x628e49){return lu(_0x11751f['pendingWriteTree_'],_0x15d94d,_0x1936ba,_0x84c831,_0x628e49),_0x628e49?_t(_0x11751f,new Be(es(),_0x15d94d,_0x1936ba)):[];}function ju(_0x57d940,_0x5c6d8b,_0x5826f1,_0x1f51c5){hu(_0x57d940['pendingWriteTree_'],_0x5c6d8b,_0x5826f1,_0x1f51c5);const _0x4a36dd=b['fromObject'](_0x5826f1);return _t(_0x57d940,new ot(es(),_0x5c6d8b,_0x4a36dd));}function _e(_0xb7bb66,_0x1c48ab,_0x5c89b0=!0x1){const _0x407b6b=uu(_0xb7bb66['pendingWriteTree_'],_0x1c48ab);if(du(_0xb7bb66['pendingWriteTree_'],_0x1c48ab)){let _0x51b1d7=new b(null);return _0x407b6b['snap']!=null?_0x51b1d7=_0x51b1d7['set'](w(),!0x0):x(_0x407b6b['children'],_0x17dda6=>{_0x51b1d7=_0x51b1d7['set'](new C(_0x17dda6),!0x0);}),_t(_0xb7bb66,new In(_0x407b6b['path'],_0x51b1d7,_0x5c89b0));}else return[];}function Yt(_0x590ece,_0x39226b,_0x4b2369){return _t(_0x590ece,new Be(ts(),_0x39226b,_0x4b2369));}function Ku(_0x569e3c,_0x17f58a,_0x1071e0){const _0x568cb5=b['fromObject'](_0x1071e0);return _t(_0x569e3c,new ot(ts(),_0x17f58a,_0x568cb5));}function Yu(_0x2753be,_0x39715b){return _t(_0x2753be,new Ut(ts(),_0x39715b));}function Qu(_0x5a7aef,_0xededf7,_0x2349a9){const _0x48098a=cs(_0x5a7aef,_0x2349a9);if(_0x48098a){const _0x402ad3=ls(_0x48098a),_0x331a44=_0x402ad3['path'],_0x3259f7=_0x402ad3['queryId'],_0x46cfea=F(_0x331a44,_0xededf7),_0x5d3000=new Ut(ns(_0x3259f7),_0x46cfea);return hs(_0x5a7aef,_0x331a44,_0x5d3000);}else return[];}function An(_0x166f3d,_0x2359e5,_0x54a792,_0x34be1b,_0x349bc6=!0x1){const _0x5d935c=_0x2359e5['_path'],_0x218f87=_0x166f3d['syncPointTree_']['get'](_0x5d935c);let _0x1e2d7b=[];if(_0x218f87&&(_0x2359e5['_queryIdentifier']==='default'||Qo(_0x218f87,_0x2359e5))){const _0x54e7b9=$u(_0x218f87,_0x2359e5,_0x54a792,_0x34be1b);Vu(_0x218f87)&&(_0x166f3d['syncPointTree_']=_0x166f3d['syncPointTree_']['remove'](_0x5d935c));const _0x378980=_0x54e7b9['removed'];if(_0x1e2d7b=_0x54e7b9['events'],!_0x349bc6){const _0x593017=_0x378980['findIndex'](_0x5894a0=>_0x5894a0['_queryParams']['loadsAllData']())!==-0x1,_0x423e24=_0x166f3d['syncPointTree_']['findOnPath'](_0x5d935c,(_0x25c69f,_0x5a3197)=>Se(_0x5a3197));if(_0x593017&&!_0x423e24){const _0x22321a=_0x166f3d['syncPointTree_']['subtree'](_0x5d935c);if(!_0x22321a['isEmpty']()){const _0x88d063=Zu(_0x22321a);for(let _0x4a16ea=0x0;_0x4a16ea<_0x88d063['length'];++_0x4a16ea){const _0x3fab29=_0x88d063[_0x4a16ea],_0xf85174=_0x3fab29['query'],_0x4e3358=ea(_0x166f3d,_0x3fab29);_0x166f3d['listenProvider_']['startListening'](kt(_0xf85174),Wt(_0x166f3d,_0xf85174),_0x4e3358['hashFn'],_0x4e3358['onComplete']);}}}!_0x423e24&&_0x378980['length']>0x0&&!_0x34be1b&&(_0x593017?_0x166f3d['listenProvider_']['stopListening'](kt(_0x2359e5),null):_0x378980['forEach'](_0x388e24=>{const _0x31c196=_0x166f3d['queryToTagMap']['get'](Hn(_0x388e24));_0x166f3d['listenProvider_']['stopListening'](kt(_0x388e24),_0x31c196);}));}ed(_0x166f3d,_0x378980);}return _0x1e2d7b;}function Jo(_0x7fc4cb,_0x3c28de,_0x1be4e4,_0x3700f1){const _0x4e619b=cs(_0x7fc4cb,_0x3700f1);if(_0x4e619b!=null){const _0x2ae2c5=ls(_0x4e619b),_0x22d175=_0x2ae2c5['path'],_0x19aa55=_0x2ae2c5['queryId'],_0x194ef9=F(_0x22d175,_0x3c28de),_0x3b7ad7=new Be(ns(_0x19aa55),_0x194ef9,_0x1be4e4);return hs(_0x7fc4cb,_0x22d175,_0x3b7ad7);}else return[];}function Ju(_0x3d3cdf,_0x402c65,_0x124749,_0x23541){const _0x31c3eb=cs(_0x3d3cdf,_0x23541);if(_0x31c3eb){const _0x2723af=ls(_0x31c3eb),_0x2e7650=_0x2723af['path'],_0x4f7d96=_0x2723af['queryId'],_0x591178=F(_0x2e7650,_0x402c65),_0x302d54=b['fromObject'](_0x124749),_0x2c14ce=new ot(ns(_0x4f7d96),_0x591178,_0x302d54);return hs(_0x3d3cdf,_0x2e7650,_0x2c14ce);}else return[];}function Ni(_0x3e0f0e,_0x1ac85e,_0x5e1f75,_0x24c2c9=!0x1){const _0xdeef1a=_0x1ac85e['_path'];let _0x1180d3=null,_0x3e389f=!0x1;_0x3e0f0e['syncPointTree_']['foreachOnPath'](_0xdeef1a,(_0x3a8547,_0x2d9d10)=>{const _0x592060=F(_0x3a8547,_0xdeef1a);_0x1180d3=_0x1180d3||Ie(_0x2d9d10,_0x592060),_0x3e389f=_0x3e389f||Se(_0x2d9d10);});let _0x28d74a=_0x3e0f0e['syncPointTree_']['get'](_0xdeef1a);_0x28d74a?(_0x3e389f=_0x3e389f||Se(_0x28d74a),_0x1180d3=_0x1180d3||Ie(_0x28d74a,w())):(_0x28d74a=new zo(),_0x3e0f0e['syncPointTree_']=_0x3e0f0e['syncPointTree_']['set'](_0xdeef1a,_0x28d74a));let _0x511603;_0x1180d3!=null?_0x511603=!0x0:(_0x511603=!0x1,_0x1180d3=g['EMPTY_NODE'],_0x3e0f0e['syncPointTree_']['subtree'](_0xdeef1a)['foreachChild']((_0x43fb39,_0x183faa)=>{const _0x2c206a=Ie(_0x183faa,w());_0x2c206a&&(_0x1180d3=_0x1180d3['updateImmediateChild'](_0x43fb39,_0x2c206a));}));const _0x516242=Qo(_0x28d74a,_0x1ac85e);if(!_0x516242&&!_0x1ac85e['_queryParams']['loadsAllData']()){const _0x23dfff=Hn(_0x1ac85e);f(!_0x3e0f0e['queryToTagMap']['has'](_0x23dfff),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x16e618=td();_0x3e0f0e['queryToTagMap']['set'](_0x23dfff,_0x16e618),_0x3e0f0e['tagToQueryMap']['set'](_0x16e618,_0x23dfff);}const _0x5e4898=Wn(_0x3e0f0e['pendingWriteTree_'],_0xdeef1a);let _0x5bcfa6=Hu(_0x28d74a,_0x1ac85e,_0x5e1f75,_0x5e4898,_0x1180d3,_0x511603);if(!_0x516242&&!_0x3e389f&&!_0x24c2c9){const _0x16b2ce=Yo(_0x28d74a,_0x1ac85e);_0x5bcfa6=_0x5bcfa6['concat'](nd(_0x3e0f0e,_0x1ac85e,_0x16b2ce));}return _0x5bcfa6;}function Vn(_0x488eb7,_0x3a5d12,_0x10c998){const _0x4bc328=_0x488eb7['pendingWriteTree_'],_0x37db8b=_0x488eb7['syncPointTree_']['findOnPath'](_0x3a5d12,(_0x3b4a77,_0x18c732)=>{const _0x63de92=F(_0x3b4a77,_0x3a5d12),_0x259e42=Ie(_0x18c732,_0x63de92);if(_0x259e42)return _0x259e42;});return Bo(_0x4bc328,_0x3a5d12,_0x37db8b,_0x10c998,!0x0);}function Xu(_0x342d87,_0x1d508e){const _0x4802d7=_0x1d508e['_path'];let _0x49f3dc=null;_0x342d87['syncPointTree_']['foreachOnPath'](_0x4802d7,(_0x54c039,_0x370a7b)=>{const _0x1eeecb=F(_0x54c039,_0x4802d7);_0x49f3dc=_0x49f3dc||Ie(_0x370a7b,_0x1eeecb);});let _0x5e8688=_0x342d87['syncPointTree_']['get'](_0x4802d7);_0x5e8688?_0x49f3dc=_0x49f3dc||Ie(_0x5e8688,w()):(_0x5e8688=new zo(),_0x342d87['syncPointTree_']=_0x342d87['syncPointTree_']['set'](_0x4802d7,_0x5e8688));const _0x17c520=_0x49f3dc!=null,_0x2e0c4f=_0x17c520?new Te(_0x49f3dc,!0x0,!0x1):null,_0x3f3691=Wn(_0x342d87['pendingWriteTree_'],_0x1d508e['_path']),_0x48781b=jo(_0x5e8688,_0x1d508e,_0x3f3691,_0x17c520?_0x2e0c4f['getNode']():g['EMPTY_NODE'],_0x17c520);return Lu(_0x48781b);}function _t(_0x1f67ab,_0x537aab){return Xo(_0x537aab,_0x1f67ab['syncPointTree_'],null,Wn(_0x1f67ab['pendingWriteTree_'],w()));}function Xo(_0x4aee13,_0x321000,_0x326e29,_0x410f7d){if(v(_0x4aee13['path']))return Zo(_0x4aee13,_0x321000,_0x326e29,_0x410f7d);{const _0x421354=_0x321000['get'](w());_0x326e29==null&&_0x421354!=null&&(_0x326e29=Ie(_0x421354,w()));let _0x18ffec=[];const _0x5eed4d=y(_0x4aee13['path']),_0x136bf5=_0x4aee13['operationForChild'](_0x5eed4d),_0xbd322e=_0x321000['children']['get'](_0x5eed4d);if(_0xbd322e&&_0x136bf5){const _0x2e12be=_0x326e29?_0x326e29['getImmediateChild'](_0x5eed4d):null,_0x1eab93=Vo(_0x410f7d,_0x5eed4d);_0x18ffec=_0x18ffec['concat'](Xo(_0x136bf5,_0xbd322e,_0x2e12be,_0x1eab93));}return _0x421354&&(_0x18ffec=_0x18ffec['concat'](os(_0x421354,_0x4aee13,_0x410f7d,_0x326e29))),_0x18ffec;}}function Zo(_0x4bc68a,_0x531ebb,_0x3ebafd,_0x118388){const _0xf47796=_0x531ebb['get'](w());_0x3ebafd==null&&_0xf47796!=null&&(_0x3ebafd=Ie(_0xf47796,w()));let _0x5d0548=[];return _0x531ebb['children']['inorderTraversal']((_0x4114a8,_0x10937b)=>{const _0xbc82d8=_0x3ebafd?_0x3ebafd['getImmediateChild'](_0x4114a8):null,_0x5ec0a5=Vo(_0x118388,_0x4114a8),_0x4f8763=_0x4bc68a['operationForChild'](_0x4114a8);_0x4f8763&&(_0x5d0548=_0x5d0548['concat'](Zo(_0x4f8763,_0x10937b,_0xbc82d8,_0x5ec0a5)));}),_0xf47796&&(_0x5d0548=_0x5d0548['concat'](os(_0xf47796,_0x4bc68a,_0x118388,_0x3ebafd))),_0x5d0548;}function ea(_0x1c17f6,_0x560a4f){const _0x248987=_0x560a4f['query'],_0xc68ee5=Wt(_0x1c17f6,_0x248987);return{'hashFn':()=>(Mu(_0x560a4f)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x38f9c5=>{if(_0x38f9c5==='ok')return _0xc68ee5?Qu(_0x1c17f6,_0x248987['_path'],_0xc68ee5):Yu(_0x1c17f6,_0x248987['_path']);{const _0x2fe2f3=Kl(_0x38f9c5,_0x248987);return An(_0x1c17f6,_0x248987,null,_0x2fe2f3);}}};}function Wt(_0x10bfb8,_0x2275f4){const _0x28fedd=Hn(_0x2275f4);return _0x10bfb8['queryToTagMap']['get'](_0x28fedd);}function Hn(_0x5bcee3){return _0x5bcee3['_path']['toString']()+'$'+_0x5bcee3['_queryIdentifier'];}function cs(_0x2d2696,_0x262233){return _0x2d2696['tagToQueryMap']['get'](_0x262233);}function ls(_0x2af12c){const _0x367478=_0x2af12c['indexOf']('$');return f(_0x367478!==-0x1&&_0x367478<_0x2af12c['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x2af12c['substr'](_0x367478+0x1),'path':new C(_0x2af12c['substr'](0x0,_0x367478))};}function hs(_0x1cf916,_0x493497,_0x800d3c){const _0x317f4f=_0x1cf916['syncPointTree_']['get'](_0x493497);f(_0x317f4f,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x12ee2d=Wn(_0x1cf916['pendingWriteTree_'],_0x493497);return os(_0x317f4f,_0x800d3c,_0x12ee2d,null);}function Zu(_0x558799){return _0x558799['fold']((_0x1ea748,_0x1d7850,_0x1db1f8)=>{if(_0x1d7850&&Se(_0x1d7850))return[Bn(_0x1d7850)];{let _0x5e7242=[];return _0x1d7850&&(_0x5e7242=Ko(_0x1d7850)),x(_0x1db1f8,(_0x1305f4,_0x9ccf2b)=>{_0x5e7242=_0x5e7242['concat'](_0x9ccf2b);}),_0x5e7242;}});}function kt(_0xdc3ccf){return _0xdc3ccf['_queryParams']['loadsAllData']()&&!_0xdc3ccf['_queryParams']['isDefault']()?new(qu())(_0xdc3ccf['_repo'],_0xdc3ccf['_path']):_0xdc3ccf;}function ed(_0x4544ef,_0x532912){for(let _0x296477=0x0;_0x296477<_0x532912['length'];++_0x296477){const _0x4470e5=_0x532912[_0x296477];if(!_0x4470e5['_queryParams']['loadsAllData']()){const _0x252f81=Hn(_0x4470e5),_0x1419a7=_0x4544ef['queryToTagMap']['get'](_0x252f81);_0x4544ef['queryToTagMap']['delete'](_0x252f81),_0x4544ef['tagToQueryMap']['delete'](_0x1419a7);}}}function td(){return zu++;}function nd(_0x2874cf,_0x4b402b,_0x572cb0){const _0x5a9a59=_0x4b402b['_path'],_0x1dd9b9=Wt(_0x2874cf,_0x4b402b),_0x29c69b=ea(_0x2874cf,_0x572cb0),_0x31745e=_0x2874cf['listenProvider_']['startListening'](kt(_0x4b402b),_0x1dd9b9,_0x29c69b['hashFn'],_0x29c69b['onComplete']),_0x4d154f=_0x2874cf['syncPointTree_']['subtree'](_0x5a9a59);if(_0x1dd9b9)f(!Se(_0x4d154f['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x3f123d=_0x4d154f['fold']((_0x4c558a,_0x563738,_0x3d9c7b)=>{if(!v(_0x4c558a)&&_0x563738&&Se(_0x563738))return[Bn(_0x563738)['query']];{let _0x681f91=[];return _0x563738&&(_0x681f91=_0x681f91['concat'](Ko(_0x563738)['map'](_0x4f471b=>_0x4f471b['query']))),x(_0x3d9c7b,(_0x564fe,_0x5d6565)=>{_0x681f91=_0x681f91['concat'](_0x5d6565);}),_0x681f91;}});for(let _0x3d90e2=0x0;_0x3d90e2<_0x3f123d['length'];++_0x3d90e2){const _0x4788bc=_0x3f123d[_0x3d90e2];_0x2874cf['listenProvider_']['stopListening'](kt(_0x4788bc),Wt(_0x2874cf,_0x4788bc));}}return _0x31745e;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x17ba7a){this['node_']=_0x17ba7a;}['getImmediateChild'](_0x34623e){const _0x2d6f81=this['node_']['getImmediateChild'](_0x34623e);return new us(_0x2d6f81);}['node'](){return this['node_'];}}class ds{constructor(_0x39d785,_0x20db14){this['syncTree_']=_0x39d785,this['path_']=_0x20db14;}['getImmediateChild'](_0xe8a61){const _0x4f2dba=k(this['path_'],_0xe8a61);return new ds(this['syncTree_'],_0x4f2dba);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x48c1b3){return _0x48c1b3=_0x48c1b3||{},_0x48c1b3['timestamp']=_0x48c1b3['timestamp']||new Date()['getTime'](),_0x48c1b3;},_r=function(_0x352907,_0x2bf2af,_0x267643){if(!_0x352907||typeof _0x352907!='object')return _0x352907;if(f('.sv'in _0x352907,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x352907['.sv']=='string')return sd(_0x352907['.sv'],_0x2bf2af,_0x267643);if(typeof _0x352907['.sv']=='object')return rd(_0x352907['.sv'],_0x2bf2af);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x352907,null,0x2));},sd=function(_0x249608,_0x1a2954,_0x436a57){switch(_0x249608){case'timestamp':return _0x436a57['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x249608);}},rd=function(_0x458ed5,_0x3115a1,_0x52b94c){_0x458ed5['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x458ed5,null,0x2));const _0x33072e=_0x458ed5['increment'];typeof _0x33072e!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x33072e);const _0x135d0a=_0x3115a1['node']();if(f(_0x135d0a!==null&&typeof _0x135d0a<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x135d0a['isLeafNode']())return _0x33072e;const _0x37759c=_0x135d0a['getValue']();return typeof _0x37759c!='number'?_0x33072e:_0x37759c+_0x33072e;},ta=function(_0x3310b4,_0x74a4da,_0x3ce22f,_0x5beb9c){return ps(_0x74a4da,new ds(_0x3ce22f,_0x3310b4),_0x5beb9c);},fs=function(_0x942c2d,_0xdf6961,_0x1debea){return ps(_0x942c2d,new us(_0xdf6961),_0x1debea);};function ps(_0x3123d6,_0x1a125c,_0x74b38b){const _0x397d9c=_0x3123d6['getPriority']()['val'](),_0x29d9a0=_r(_0x397d9c,_0x1a125c['getImmediateChild']('.priority'),_0x74b38b);let _0x336dc7;if(_0x3123d6['isLeafNode']()){const _0x5ce425=_0x3123d6,_0x1c2c5a=_r(_0x5ce425['getValue'](),_0x1a125c,_0x74b38b);return _0x1c2c5a!==_0x5ce425['getValue']()||_0x29d9a0!==_0x5ce425['getPriority']()['val']()?new D(_0x1c2c5a,A(_0x29d9a0)):_0x3123d6;}else{const _0x132ca4=_0x3123d6;return _0x336dc7=_0x132ca4,_0x29d9a0!==_0x132ca4['getPriority']()['val']()&&(_0x336dc7=_0x336dc7['updatePriority'](new D(_0x29d9a0))),_0x132ca4['forEachChild'](R,(_0x5f28a3,_0x2deba4)=>{const _0xf0b151=ps(_0x2deba4,_0x1a125c['getImmediateChild'](_0x5f28a3),_0x74b38b);_0xf0b151!==_0x2deba4&&(_0x336dc7=_0x336dc7['updateImmediateChild'](_0x5f28a3,_0xf0b151));}),_0x336dc7;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0xf0380e='',_0x28dbee=null,_0x4101bb={'children':{},'childCount':0x0}){this['name']=_0xf0380e,this['parent']=_0x28dbee,this['node']=_0x4101bb;}}function $n(_0x2af167,_0x45a0c1){let _0x2ea0fb=_0x45a0c1 instanceof C?_0x45a0c1:new C(_0x45a0c1),_0x12de11=_0x2af167,_0x1f1235=y(_0x2ea0fb);for(;_0x1f1235!==null;){const _0x27bebf=Le(_0x12de11['node']['children'],_0x1f1235)||{'children':{},'childCount':0x0};_0x12de11=new _s(_0x1f1235,_0x12de11,_0x27bebf),_0x2ea0fb=S(_0x2ea0fb),_0x1f1235=y(_0x2ea0fb);}return _0x12de11;}function je(_0x39a2f5){return _0x39a2f5['node']['value'];}function gs(_0x450f8c,_0x85909a){_0x450f8c['node']['value']=_0x85909a,Oi(_0x450f8c);}function na(_0x548a8a){return _0x548a8a['node']['childCount']>0x0;}function od(_0xba6d25){return je(_0xba6d25)===void 0x0&&!na(_0xba6d25);}function Gn(_0x41c507,_0x1f1ea5){x(_0x41c507['node']['children'],(_0x5169e4,_0x4cd177)=>{_0x1f1ea5(new _s(_0x5169e4,_0x41c507,_0x4cd177));});}function ia(_0x38a5a1,_0x26c6ba,_0xa85104,_0x50d0dd){_0xa85104&&_0x26c6ba(_0x38a5a1),Gn(_0x38a5a1,_0x39a466=>{ia(_0x39a466,_0x26c6ba,!0x0);});}function ad(_0x26802f,_0x58e189,_0x3bb496){let _0x5cad47=_0x26802f['parent'];for(;_0x5cad47!==null;){if(_0x58e189(_0x5cad47))return!0x0;_0x5cad47=_0x5cad47['parent'];}return!0x1;}function Qt(_0x1820da){return new C(_0x1820da['parent']===null?_0x1820da['name']:Qt(_0x1820da['parent'])+'/'+_0x1820da['name']);}function Oi(_0x3b4ec0){_0x3b4ec0['parent']!==null&&cd(_0x3b4ec0['parent'],_0x3b4ec0['name'],_0x3b4ec0);}function cd(_0x29b95f,_0xccf9d3,_0x1f9cdf){const _0x425322=od(_0x1f9cdf),_0x586cf1=Q(_0x29b95f['node']['children'],_0xccf9d3);_0x425322&&_0x586cf1?(delete _0x29b95f['node']['children'][_0xccf9d3],_0x29b95f['node']['childCount']--,Oi(_0x29b95f)):!_0x425322&&!_0x586cf1&&(_0x29b95f['node']['children'][_0xccf9d3]=_0x1f9cdf['node'],_0x29b95f['node']['childCount']++,Oi(_0x29b95f));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x2cf5ee){return typeof _0x2cf5ee=='string'&&_0x2cf5ee['length']!==0x0&&!ld['test'](_0x2cf5ee);},sa=function(_0x16447d){return typeof _0x16447d=='string'&&_0x16447d['length']!==0x0&&!hd['test'](_0x16447d);},ud=function(_0x139e03){return _0x139e03&&(_0x139e03=_0x139e03['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x139e03);},Bt=function(_0xd89236){return _0xd89236===null||typeof _0xd89236=='string'||typeof _0xd89236=='number'&&!xn(_0xd89236)||_0xd89236&&typeof _0xd89236=='object'&&Q(_0xd89236,'.sv');},He=function(_0x40b84a,_0x467740,_0x555673,_0x27bc47){_0x27bc47&&_0x467740===void 0x0||Jt(it(_0x40b84a,'value'),_0x467740,_0x555673);},Jt=function(_0x45e459,_0x79aa7d,_0x49ff4b){const _0x11e50c=_0x49ff4b instanceof C?new Ah(_0x49ff4b,_0x45e459):_0x49ff4b;if(_0x79aa7d===void 0x0)throw new Error(_0x45e459+'contains\x20undefined\x20'+Oe(_0x11e50c));if(typeof _0x79aa7d=='function')throw new Error(_0x45e459+'contains\x20a\x20function\x20'+Oe(_0x11e50c)+'\x20with\x20contents\x20=\x20'+_0x79aa7d['toString']());if(xn(_0x79aa7d))throw new Error(_0x45e459+'contains\x20'+_0x79aa7d['toString']()+'\x20'+Oe(_0x11e50c));if(typeof _0x79aa7d=='string'&&_0x79aa7d['length']>ui/0x3&&Ln(_0x79aa7d)>ui)throw new Error(_0x45e459+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x11e50c)+'\x20(\x27'+_0x79aa7d['substring'](0x0,0x32)+'...\x27)');if(_0x79aa7d&&typeof _0x79aa7d=='object'){let _0x878474=!0x1,_0x3f51af=!0x1;if(x(_0x79aa7d,(_0x10182a,_0x1481c8)=>{if(_0x10182a==='.value')_0x878474=!0x0;else{if(_0x10182a!=='.priority'&&_0x10182a!=='.sv'&&(_0x3f51af=!0x0,!ms(_0x10182a)))throw new Error(_0x45e459+'\x20contains\x20an\x20invalid\x20key\x20('+_0x10182a+')\x20'+Oe(_0x11e50c)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x11e50c,_0x10182a),Jt(_0x45e459,_0x1481c8,_0x11e50c),Ph(_0x11e50c);}),_0x878474&&_0x3f51af)throw new Error(_0x45e459+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x11e50c)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x29a026,_0x538273){let _0x4cc497,_0x33cb4d;for(_0x4cc497=0x0;_0x4cc497<_0x538273['length'];_0x4cc497++){_0x33cb4d=_0x538273[_0x4cc497];const _0x527f16=Mt(_0x33cb4d);for(let _0x53bf54=0x0;_0x53bf54<_0x527f16['length'];_0x53bf54++)if(!(_0x527f16[_0x53bf54]==='.priority'&&_0x53bf54===_0x527f16['length']-0x1)){if(!ms(_0x527f16[_0x53bf54]))throw new Error(_0x29a026+'contains\x20an\x20invalid\x20key\x20('+_0x527f16[_0x53bf54]+')\x20in\x20path\x20'+_0x33cb4d['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x538273['sort'](Rh);let _0x1f1a4f=null;for(_0x4cc497=0x0;_0x4cc497<_0x538273['length'];_0x4cc497++){if(_0x33cb4d=_0x538273[_0x4cc497],_0x1f1a4f!==null&&G(_0x1f1a4f,_0x33cb4d))throw new Error(_0x29a026+'contains\x20a\x20path\x20'+_0x1f1a4f['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x33cb4d['toString']());_0x1f1a4f=_0x33cb4d;}},ra=function(_0x15873e,_0x4c37ab,_0x8e11ba,_0x88186b){const _0x1d63aa=it(_0x15873e,'values');if(!(_0x4c37ab&&typeof _0x4c37ab=='object')||Array['isArray'](_0x4c37ab))throw new Error(_0x1d63aa+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x158b05=[];x(_0x4c37ab,(_0x27171f,_0x368002)=>{const _0x15de09=new C(_0x27171f);if(Jt(_0x1d63aa,_0x368002,k(_0x8e11ba,_0x15de09)),ji(_0x15de09)==='.priority'&&!Bt(_0x368002))throw new Error(_0x1d63aa+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x15de09['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x158b05['push'](_0x15de09);}),dd(_0x1d63aa,_0x158b05);},fd=function(_0x4c8d75,_0x546f01,_0x43271e){if(xn(_0x546f01))throw new Error(it(_0x4c8d75,'priority')+'is\x20'+_0x546f01['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x546f01))throw new Error(it(_0x4c8d75,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x2c390c,_0x876d2e,_0x33244d,_0x1ae76d){if(!sa(_0x33244d))throw new Error(it(_0x2c390c,_0x876d2e)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x33244d+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0xa504cb,_0x57230b,_0x19a99d,_0x37679d){_0x19a99d&&(_0x19a99d=_0x19a99d['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0xa504cb,_0x57230b,_0x19a99d);},Me=function(_0x487f5b,_0x20d4ef){if(y(_0x20d4ef)==='.info')throw new Error(_0x487f5b+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x523188,_0x27b478){const _0x469e61=_0x27b478['path']['toString']();if(typeof _0x27b478['repoInfo']['host']!='string'||_0x27b478['repoInfo']['host']['length']===0x0||!ms(_0x27b478['repoInfo']['namespace'])&&_0x27b478['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x469e61['length']!==0x0&&!ud(_0x469e61))throw new Error(it(_0x523188,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x1a74fb,_0x4e031e){let _0x3731bf=null;for(let _0x42142b=0x0;_0x42142b<_0x4e031e['length'];_0x42142b++){const _0x34f100=_0x4e031e[_0x42142b],_0x39bb6c=_0x34f100['getPath']();_0x3731bf!==null&&!Ki(_0x39bb6c,_0x3731bf['path'])&&(_0x1a74fb['eventLists_']['push'](_0x3731bf),_0x3731bf=null),_0x3731bf===null&&(_0x3731bf={'events':[],'path':_0x39bb6c}),_0x3731bf['events']['push'](_0x34f100);}_0x3731bf&&_0x1a74fb['eventLists_']['push'](_0x3731bf);}function oa(_0x8588fa,_0x6967d0,_0x55d14d){qn(_0x8588fa,_0x55d14d),aa(_0x8588fa,_0x37814d=>Ki(_0x37814d,_0x6967d0));}function V(_0x14fa92,_0x5290f6,_0x5dad8d){qn(_0x14fa92,_0x5dad8d),aa(_0x14fa92,_0x21ec2e=>G(_0x21ec2e,_0x5290f6)||G(_0x5290f6,_0x21ec2e));}function aa(_0x1bf357,_0x2ea722){_0x1bf357['recursionDepth_']++;let _0x515344=!0x0;for(let _0x4a1009=0x0;_0x4a1009<_0x1bf357['eventLists_']['length'];_0x4a1009++){const _0xa3dbe9=_0x1bf357['eventLists_'][_0x4a1009];if(_0xa3dbe9){const _0x350a8e=_0xa3dbe9['path'];_0x2ea722(_0x350a8e)?(md(_0x1bf357['eventLists_'][_0x4a1009]),_0x1bf357['eventLists_'][_0x4a1009]=null):_0x515344=!0x1;}}_0x515344&&(_0x1bf357['eventLists_']=[]),_0x1bf357['recursionDepth_']--;}function md(_0x47cfea){for(let _0x4e016e=0x0;_0x4e016e<_0x47cfea['events']['length'];_0x4e016e++){const _0x5a8cbd=_0x47cfea['events'][_0x4e016e];if(_0x5a8cbd!==null){_0x47cfea['events'][_0x4e016e]=null;const _0x1c7ada=_0x5a8cbd['getEventRunner']();St&&L('event:\x20'+_0x5a8cbd['toString']()),ft(_0x1c7ada);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x198d3b,_0x458a78,_0x43a98,_0x3d9c29){this['repoInfo_']=_0x198d3b,this['forceRestClient_']=_0x458a78,this['authTokenProvider_']=_0x43a98,this['appCheckProvider_']=_0x3d9c29,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x18c18f,_0x6b3548,_0x2c2622){if(_0x18c18f['stats_']=qi(_0x18c18f['repoInfo_']),_0x18c18f['forceRestClient_']||Xl())_0x18c18f['server_']=new vn(_0x18c18f['repoInfo_'],(_0x5af00c,_0x2bcad1,_0x61e496,_0x1f6985)=>{gr(_0x18c18f,_0x5af00c,_0x2bcad1,_0x61e496,_0x1f6985);},_0x18c18f['authTokenProvider_'],_0x18c18f['appCheckProvider_']),setTimeout(()=>mr(_0x18c18f,!0x0),0x0);else{if(typeof _0x2c2622<'u'&&_0x2c2622!==null){if(typeof _0x2c2622!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x2c2622);}catch(_0x37eddc){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x37eddc);}}_0x18c18f['persistentConnection_']=new se(_0x18c18f['repoInfo_'],_0x6b3548,(_0x5f0316,_0x574391,_0x111df0,_0x2240c8)=>{gr(_0x18c18f,_0x5f0316,_0x574391,_0x111df0,_0x2240c8);},_0x53e89d=>{mr(_0x18c18f,_0x53e89d);},_0x33efae=>{Id(_0x18c18f,_0x33efae);},_0x18c18f['authTokenProvider_'],_0x18c18f['appCheckProvider_'],_0x2c2622),_0x18c18f['server_']=_0x18c18f['persistentConnection_'];}_0x18c18f['authTokenProvider_']['addTokenChangeListener'](_0x22b141=>{_0x18c18f['server_']['refreshAuthToken'](_0x22b141);}),_0x18c18f['appCheckProvider_']['addTokenChangeListener'](_0x16d56f=>{_0x18c18f['server_']['refreshAppCheckToken'](_0x16d56f['token']);}),_0x18c18f['statsReporter_']=ih(_0x18c18f['repoInfo_'],()=>new iu(_0x18c18f['stats_'],_0x18c18f['server_'])),_0x18c18f['infoData_']=new Xh(),_0x18c18f['infoSyncTree_']=new pr({'startListening':(_0x25ad84,_0xf40451,_0x55717b,_0x5f02b0)=>{let _0x1482b9=[];const _0x2f6ecf=_0x18c18f['infoData_']['getNode'](_0x25ad84['_path']);return _0x2f6ecf['isEmpty']()||(_0x1482b9=Yt(_0x18c18f['infoSyncTree_'],_0x25ad84['_path'],_0x2f6ecf),setTimeout(()=>{_0x5f02b0('ok');},0x0)),_0x1482b9;},'stopListening':()=>{}}),vs(_0x18c18f,'connected',!0x1),_0x18c18f['serverSyncTree_']=new pr({'startListening':(_0x29a7e8,_0x24c67d,_0x18f7b9,_0x35bec9)=>(_0x18c18f['server_']['listen'](_0x29a7e8,_0x18f7b9,_0x24c67d,(_0xa358e0,_0x46ef64)=>{const _0x216cd7=_0x35bec9(_0xa358e0,_0x46ef64);V(_0x18c18f['eventQueue_'],_0x29a7e8['_path'],_0x216cd7);}),[]),'stopListening':(_0x40cdcf,_0x480c9e)=>{_0x18c18f['server_']['unlisten'](_0x40cdcf,_0x480c9e);}});}function la(_0x544722){const _0x309f77=_0x544722['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x309f77;}function Xt(_0x1dfc8e){return id({'timestamp':la(_0x1dfc8e)});}function gr(_0x53af2b,_0x208494,_0x1f2858,_0x123d64,_0x4faf1b){_0x53af2b['dataUpdateCount']++;const _0x5cf257=new C(_0x208494);_0x1f2858=_0x53af2b['interceptServerDataCallback_']?_0x53af2b['interceptServerDataCallback_'](_0x208494,_0x1f2858):_0x1f2858;let _0x11b8e2=[];if(_0x4faf1b){if(_0x123d64){const _0x47e803=_n(_0x1f2858,_0x454ec7=>A(_0x454ec7));_0x11b8e2=Ju(_0x53af2b['serverSyncTree_'],_0x5cf257,_0x47e803,_0x4faf1b);}else{const _0x929db6=A(_0x1f2858);_0x11b8e2=Jo(_0x53af2b['serverSyncTree_'],_0x5cf257,_0x929db6,_0x4faf1b);}}else{if(_0x123d64){const _0xf0ee79=_n(_0x1f2858,_0x748de2=>A(_0x748de2));_0x11b8e2=Ku(_0x53af2b['serverSyncTree_'],_0x5cf257,_0xf0ee79);}else{const _0x5f52c5=A(_0x1f2858);_0x11b8e2=Yt(_0x53af2b['serverSyncTree_'],_0x5cf257,_0x5f52c5);}}let _0x2cf590=_0x5cf257;_0x11b8e2['length']>0x0&&(_0x2cf590=ct(_0x53af2b,_0x5cf257)),V(_0x53af2b['eventQueue_'],_0x2cf590,_0x11b8e2);}function mr(_0x443156,_0x532dfc){vs(_0x443156,'connected',_0x532dfc),_0x532dfc===!0x1&&Sd(_0x443156);}function Id(_0x596aac,_0x392223){x(_0x392223,(_0x877b,_0x323326)=>{vs(_0x596aac,_0x877b,_0x323326);});}function vs(_0xd8b51e,_0x3e3b77,_0x54c0a9){const _0x2ee89f=new C('/.info/'+_0x3e3b77),_0x374c3b=A(_0x54c0a9);_0xd8b51e['infoData_']['updateSnapshot'](_0x2ee89f,_0x374c3b);const _0x3b6e7b=Yt(_0xd8b51e['infoSyncTree_'],_0x2ee89f,_0x374c3b);V(_0xd8b51e['eventQueue_'],_0x2ee89f,_0x3b6e7b);}function zn(_0x76c2e6){return _0x76c2e6['nextWriteId_']++;}function wd(_0x187d84,_0x4cb5ee,_0x4e9479){const _0x25c5df=Xu(_0x187d84['serverSyncTree_'],_0x4cb5ee);return _0x25c5df!=null?Promise['resolve'](_0x25c5df):_0x187d84['server_']['get'](_0x4cb5ee)['then'](_0x6ff312=>{const _0xdf7b14=A(_0x6ff312)['withIndex'](_0x4cb5ee['_queryParams']['getIndex']());Ni(_0x187d84['serverSyncTree_'],_0x4cb5ee,_0x4e9479,!0x0);let _0x6ca918;if(_0x4cb5ee['_queryParams']['loadsAllData']())_0x6ca918=Yt(_0x187d84['serverSyncTree_'],_0x4cb5ee['_path'],_0xdf7b14);else{const _0x522ae2=Wt(_0x187d84['serverSyncTree_'],_0x4cb5ee);_0x6ca918=Jo(_0x187d84['serverSyncTree_'],_0x4cb5ee['_path'],_0xdf7b14,_0x522ae2);}return V(_0x187d84['eventQueue_'],_0x4cb5ee['_path'],_0x6ca918),An(_0x187d84['serverSyncTree_'],_0x4cb5ee,_0x4e9479,null,!0x0),_0xdf7b14;},_0x5f209b=>(gt(_0x187d84,'get\x20for\x20query\x20'+O(_0x4cb5ee)+'\x20failed:\x20'+_0x5f209b),Promise['reject'](new Error(_0x5f209b))));}function Cd(_0x516008,_0x20b874,_0x6b1b90,_0x1924f7,_0x2e2431){gt(_0x516008,'set',{'path':_0x20b874['toString'](),'value':_0x6b1b90,'priority':_0x1924f7});const _0x3125ee=Xt(_0x516008),_0x18b905=A(_0x6b1b90,_0x1924f7),_0x5d1a7e=Vn(_0x516008['serverSyncTree_'],_0x20b874),_0x4d2b92=fs(_0x18b905,_0x5d1a7e,_0x3125ee),_0x6ce189=zn(_0x516008),_0x678382=as(_0x516008['serverSyncTree_'],_0x20b874,_0x4d2b92,_0x6ce189,!0x0);qn(_0x516008['eventQueue_'],_0x678382),_0x516008['server_']['put'](_0x20b874['toString'](),_0x18b905['val'](!0x0),(_0x4c2a55,_0x351832)=>{const _0x52ed33=_0x4c2a55==='ok';_0x52ed33||U('set\x20at\x20'+_0x20b874+'\x20failed:\x20'+_0x4c2a55);const _0x3fbf65=_e(_0x516008['serverSyncTree_'],_0x6ce189,!_0x52ed33);V(_0x516008['eventQueue_'],_0x20b874,_0x3fbf65),be(_0x516008,_0x2e2431,_0x4c2a55,_0x351832);});const _0x99efed=Is(_0x516008,_0x20b874);ct(_0x516008,_0x99efed),V(_0x516008['eventQueue_'],_0x99efed,[]);}function Td(_0x5f0a26,_0x5b1d8c,_0xa2920e,_0x5d7b4b){gt(_0x5f0a26,'update',{'path':_0x5b1d8c['toString'](),'value':_0xa2920e});let _0x13cc3a=!0x0;const _0x54ae40=Xt(_0x5f0a26),_0x2f1a63={};if(x(_0xa2920e,(_0x528e93,_0x463f1e)=>{_0x13cc3a=!0x1,_0x2f1a63[_0x528e93]=ta(k(_0x5b1d8c,_0x528e93),A(_0x463f1e),_0x5f0a26['serverSyncTree_'],_0x54ae40);}),_0x13cc3a)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x5f0a26,_0x5d7b4b,'ok',void 0x0);else{const _0x532bf9=zn(_0x5f0a26),_0x273569=ju(_0x5f0a26['serverSyncTree_'],_0x5b1d8c,_0x2f1a63,_0x532bf9);qn(_0x5f0a26['eventQueue_'],_0x273569),_0x5f0a26['server_']['merge'](_0x5b1d8c['toString'](),_0xa2920e,(_0x397edd,_0x2fe0e7)=>{const _0xe8b8e0=_0x397edd==='ok';_0xe8b8e0||U('update\x20at\x20'+_0x5b1d8c+'\x20failed:\x20'+_0x397edd);const _0x182afd=_e(_0x5f0a26['serverSyncTree_'],_0x532bf9,!_0xe8b8e0),_0x13d273=_0x182afd['length']>0x0?ct(_0x5f0a26,_0x5b1d8c):_0x5b1d8c;V(_0x5f0a26['eventQueue_'],_0x13d273,_0x182afd),be(_0x5f0a26,_0x5d7b4b,_0x397edd,_0x2fe0e7);}),x(_0xa2920e,_0x35ba4a=>{const _0x19b9f1=Is(_0x5f0a26,k(_0x5b1d8c,_0x35ba4a));ct(_0x5f0a26,_0x19b9f1);}),V(_0x5f0a26['eventQueue_'],_0x5b1d8c,[]);}}function Sd(_0x4fa6fd){gt(_0x4fa6fd,'onDisconnectEvents');const _0x3dc102=Xt(_0x4fa6fd),_0x582afd=En();Si(_0x4fa6fd['onDisconnect_'],w(),(_0x186e26,_0x48fc26)=>{const _0x52ad10=ta(_0x186e26,_0x48fc26,_0x4fa6fd['serverSyncTree_'],_0x3dc102);pt(_0x582afd,_0x186e26,_0x52ad10);});let _0x2e743b=[];Si(_0x582afd,w(),(_0x4001c0,_0x52079c)=>{_0x2e743b=_0x2e743b['concat'](Yt(_0x4fa6fd['serverSyncTree_'],_0x4001c0,_0x52079c));const _0x125afd=Is(_0x4fa6fd,_0x4001c0);ct(_0x4fa6fd,_0x125afd);}),_0x4fa6fd['onDisconnect_']=En(),V(_0x4fa6fd['eventQueue_'],w(),_0x2e743b);}function bd(_0xb2edc1,_0x23a56c,_0x4d2eae){_0xb2edc1['server_']['onDisconnectCancel'](_0x23a56c['toString'](),(_0x1536b7,_0x5e5a78)=>{_0x1536b7==='ok'&&Ti(_0xb2edc1['onDisconnect_'],_0x23a56c),be(_0xb2edc1,_0x4d2eae,_0x1536b7,_0x5e5a78);});}function yr(_0x5ce2a6,_0x4bc54c,_0x235568,_0x1417a3){const _0x1d20d1=A(_0x235568);_0x5ce2a6['server_']['onDisconnectPut'](_0x4bc54c['toString'](),_0x1d20d1['val'](!0x0),(_0x330383,_0x5c5af1)=>{_0x330383==='ok'&&pt(_0x5ce2a6['onDisconnect_'],_0x4bc54c,_0x1d20d1),be(_0x5ce2a6,_0x1417a3,_0x330383,_0x5c5af1);});}function Rd(_0xab939c,_0x13dce4,_0x2b7168,_0x14e725,_0x1103a7){const _0x7f3140=A(_0x2b7168,_0x14e725);_0xab939c['server_']['onDisconnectPut'](_0x13dce4['toString'](),_0x7f3140['val'](!0x0),(_0x2c2df5,_0x48d730)=>{_0x2c2df5==='ok'&&pt(_0xab939c['onDisconnect_'],_0x13dce4,_0x7f3140),be(_0xab939c,_0x1103a7,_0x2c2df5,_0x48d730);});}function Ad(_0x2b795f,_0x162a0e,_0x44150b,_0x30ec5a){if(pn(_0x44150b)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x2b795f,_0x30ec5a,'ok',void 0x0);return;}_0x2b795f['server_']['onDisconnectMerge'](_0x162a0e['toString'](),_0x44150b,(_0x31b094,_0x1ce7c1)=>{_0x31b094==='ok'&&x(_0x44150b,(_0x3ad70f,_0x1579a0)=>{const _0x3f065b=A(_0x1579a0);pt(_0x2b795f['onDisconnect_'],k(_0x162a0e,_0x3ad70f),_0x3f065b);}),be(_0x2b795f,_0x30ec5a,_0x31b094,_0x1ce7c1);});}function kd(_0x188c9f,_0x25cdb1,_0x20f7e4){let _0x2b40bb;y(_0x25cdb1['_path'])==='.info'?_0x2b40bb=Ni(_0x188c9f['infoSyncTree_'],_0x25cdb1,_0x20f7e4):_0x2b40bb=Ni(_0x188c9f['serverSyncTree_'],_0x25cdb1,_0x20f7e4),oa(_0x188c9f['eventQueue_'],_0x25cdb1['_path'],_0x2b40bb);}function Pd(_0x14e38d,_0x11e1e1,_0x840546){let _0x87dc00;y(_0x11e1e1['_path'])==='.info'?_0x87dc00=An(_0x14e38d['infoSyncTree_'],_0x11e1e1,_0x840546):_0x87dc00=An(_0x14e38d['serverSyncTree_'],_0x11e1e1,_0x840546),oa(_0x14e38d['eventQueue_'],_0x11e1e1['_path'],_0x87dc00);}function ha(_0x3e0425){_0x3e0425['persistentConnection_']&&_0x3e0425['persistentConnection_']['interrupt'](ca);}function Nd(_0x2657cd){_0x2657cd['persistentConnection_']&&_0x2657cd['persistentConnection_']['resume'](ca);}function gt(_0x33e98c,..._0x4bbd54){let _0x193628='';_0x33e98c['persistentConnection_']&&(_0x193628=_0x33e98c['persistentConnection_']['id']+':'),L(_0x193628,..._0x4bbd54);}function be(_0x247b18,_0x5f2d41,_0x1f9c6c,_0x4ee5d6){_0x5f2d41&&ft(()=>{if(_0x1f9c6c==='ok')_0x5f2d41(null);else{const _0x522d69=(_0x1f9c6c||'error')['toUpperCase']();let _0x2d2724=_0x522d69;_0x4ee5d6&&(_0x2d2724+=':\x20'+_0x4ee5d6);const _0x555954=new Error(_0x2d2724);_0x555954['code']=_0x522d69,_0x5f2d41(_0x555954);}});}function Od(_0x5662d3,_0x4ab9d2,_0x49c966,_0x5ee21e,_0x41c0a7,_0x8ff0f3){gt(_0x5662d3,'transaction\x20on\x20'+_0x4ab9d2);const _0xe1d94={'path':_0x4ab9d2,'update':_0x49c966,'onComplete':_0x5ee21e,'status':null,'order':so(),'applyLocally':_0x8ff0f3,'retryCount':0x0,'unwatcher':_0x41c0a7,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x33abda=Es(_0x5662d3,_0x4ab9d2,void 0x0);_0xe1d94['currentInputSnapshot']=_0x33abda;const _0x548013=_0xe1d94['update'](_0x33abda['val']());if(_0x548013===void 0x0)_0xe1d94['unwatcher'](),_0xe1d94['currentOutputSnapshotRaw']=null,_0xe1d94['currentOutputSnapshotResolved']=null,_0xe1d94['onComplete']&&_0xe1d94['onComplete'](null,!0x1,_0xe1d94['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x548013,_0xe1d94['path']),_0xe1d94['status']=0x0;const _0x46a94c=$n(_0x5662d3['transactionQueueTree_'],_0x4ab9d2),_0x3d7568=je(_0x46a94c)||[];_0x3d7568['push'](_0xe1d94),gs(_0x46a94c,_0x3d7568);let _0x128e21;typeof _0x548013=='object'&&_0x548013!==null&&Q(_0x548013,'.priority')?(_0x128e21=Le(_0x548013,'.priority'),f(Bt(_0x128e21),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x128e21=(Vn(_0x5662d3['serverSyncTree_'],_0x4ab9d2)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x59634e=Xt(_0x5662d3),_0x2843fa=A(_0x548013,_0x128e21),_0x5cd73a=fs(_0x2843fa,_0x33abda,_0x59634e);_0xe1d94['currentOutputSnapshotRaw']=_0x2843fa,_0xe1d94['currentOutputSnapshotResolved']=_0x5cd73a,_0xe1d94['currentWriteId']=zn(_0x5662d3);const _0x2c4292=as(_0x5662d3['serverSyncTree_'],_0x4ab9d2,_0x5cd73a,_0xe1d94['currentWriteId'],_0xe1d94['applyLocally']);V(_0x5662d3['eventQueue_'],_0x4ab9d2,_0x2c4292),jn(_0x5662d3,_0x5662d3['transactionQueueTree_']);}}function Es(_0x55e1e9,_0x14a0c5,_0x5e5171){return Vn(_0x55e1e9['serverSyncTree_'],_0x14a0c5,_0x5e5171)||g['EMPTY_NODE'];}function jn(_0x2f0374,_0x3420ed=_0x2f0374['transactionQueueTree_']){if(_0x3420ed||Kn(_0x2f0374,_0x3420ed),je(_0x3420ed)){const _0x4c146a=da(_0x2f0374,_0x3420ed);f(_0x4c146a['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x4c146a['every'](_0x269cdd=>_0x269cdd['status']===0x0)&&Dd(_0x2f0374,Qt(_0x3420ed),_0x4c146a);}else na(_0x3420ed)&&Gn(_0x3420ed,_0x324bb1=>{jn(_0x2f0374,_0x324bb1);});}function Dd(_0x18e0c5,_0x3a5faa,_0x912db8){const _0x4ec53c=_0x912db8['map'](_0x574ee8=>_0x574ee8['currentWriteId']),_0x573dca=Es(_0x18e0c5,_0x3a5faa,_0x4ec53c);let _0x2c8418=_0x573dca;const _0x2d6f2c=_0x573dca['hash']();for(let _0x3e5681=0x0;_0x3e5681<_0x912db8['length'];_0x3e5681++){const _0xc5ba19=_0x912db8[_0x3e5681];f(_0xc5ba19['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0xc5ba19['status']=0x1,_0xc5ba19['retryCount']++;const _0x484931=F(_0x3a5faa,_0xc5ba19['path']);_0x2c8418=_0x2c8418['updateChild'](_0x484931,_0xc5ba19['currentOutputSnapshotRaw']);}const _0x308c58=_0x2c8418['val'](!0x0),_0xb5fa00=_0x3a5faa;_0x18e0c5['server_']['put'](_0xb5fa00['toString'](),_0x308c58,_0x2cdfff=>{gt(_0x18e0c5,'transaction\x20put\x20response',{'path':_0xb5fa00['toString'](),'status':_0x2cdfff});let _0x51ec92=[];if(_0x2cdfff==='ok'){const _0x17ae0d=[];for(let _0x560654=0x0;_0x560654<_0x912db8['length'];_0x560654++)_0x912db8[_0x560654]['status']=0x2,_0x51ec92=_0x51ec92['concat'](_e(_0x18e0c5['serverSyncTree_'],_0x912db8[_0x560654]['currentWriteId'])),_0x912db8[_0x560654]['onComplete']&&_0x17ae0d['push'](()=>_0x912db8[_0x560654]['onComplete'](null,!0x0,_0x912db8[_0x560654]['currentOutputSnapshotResolved'])),_0x912db8[_0x560654]['unwatcher']();Kn(_0x18e0c5,$n(_0x18e0c5['transactionQueueTree_'],_0x3a5faa)),jn(_0x18e0c5,_0x18e0c5['transactionQueueTree_']),V(_0x18e0c5['eventQueue_'],_0x3a5faa,_0x51ec92);for(let _0x4417d4=0x0;_0x4417d4<_0x17ae0d['length'];_0x4417d4++)ft(_0x17ae0d[_0x4417d4]);}else{if(_0x2cdfff==='datastale'){for(let _0x689ad4=0x0;_0x689ad4<_0x912db8['length'];_0x689ad4++)_0x912db8[_0x689ad4]['status']===0x3?_0x912db8[_0x689ad4]['status']=0x4:_0x912db8[_0x689ad4]['status']=0x0;}else{U('transaction\x20at\x20'+_0xb5fa00['toString']()+'\x20failed:\x20'+_0x2cdfff);for(let _0x43b688=0x0;_0x43b688<_0x912db8['length'];_0x43b688++)_0x912db8[_0x43b688]['status']=0x4,_0x912db8[_0x43b688]['abortReason']=_0x2cdfff;}ct(_0x18e0c5,_0x3a5faa);}},_0x2d6f2c);}function ct(_0x594170,_0x5b7c2b){const _0x39cd84=ua(_0x594170,_0x5b7c2b),_0x7e9388=Qt(_0x39cd84),_0x5d0d39=da(_0x594170,_0x39cd84);return Md(_0x594170,_0x5d0d39,_0x7e9388),_0x7e9388;}function Md(_0x330519,_0x147087,_0x1aa4f8){if(_0x147087['length']===0x0)return;const _0xa08f0d=[];let _0x4df427=[];const _0x43c652=_0x147087['filter'](_0x7c599e=>_0x7c599e['status']===0x0)['map'](_0x4e1248=>_0x4e1248['currentWriteId']);for(let _0x66d47d=0x0;_0x66d47d<_0x147087['length'];_0x66d47d++){const _0x3ec72e=_0x147087[_0x66d47d],_0x493ddd=F(_0x1aa4f8,_0x3ec72e['path']);let _0x3b16cc=!0x1,_0x349faa;if(f(_0x493ddd!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x3ec72e['status']===0x4)_0x3b16cc=!0x0,_0x349faa=_0x3ec72e['abortReason'],_0x4df427=_0x4df427['concat'](_e(_0x330519['serverSyncTree_'],_0x3ec72e['currentWriteId'],!0x0));else{if(_0x3ec72e['status']===0x0){if(_0x3ec72e['retryCount']>=yd)_0x3b16cc=!0x0,_0x349faa='maxretry',_0x4df427=_0x4df427['concat'](_e(_0x330519['serverSyncTree_'],_0x3ec72e['currentWriteId'],!0x0));else{const _0x1814c9=Es(_0x330519,_0x3ec72e['path'],_0x43c652);_0x3ec72e['currentInputSnapshot']=_0x1814c9;const _0x1cd5cb=_0x147087[_0x66d47d]['update'](_0x1814c9['val']());if(_0x1cd5cb!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x1cd5cb,_0x3ec72e['path']);let _0x482c98=A(_0x1cd5cb);typeof _0x1cd5cb=='object'&&_0x1cd5cb!=null&&Q(_0x1cd5cb,'.priority')||(_0x482c98=_0x482c98['updatePriority'](_0x1814c9['getPriority']()));const _0xe13d12=_0x3ec72e['currentWriteId'],_0x357329=Xt(_0x330519),_0x481ff2=fs(_0x482c98,_0x1814c9,_0x357329);_0x3ec72e['currentOutputSnapshotRaw']=_0x482c98,_0x3ec72e['currentOutputSnapshotResolved']=_0x481ff2,_0x3ec72e['currentWriteId']=zn(_0x330519),_0x43c652['splice'](_0x43c652['indexOf'](_0xe13d12),0x1),_0x4df427=_0x4df427['concat'](as(_0x330519['serverSyncTree_'],_0x3ec72e['path'],_0x481ff2,_0x3ec72e['currentWriteId'],_0x3ec72e['applyLocally'])),_0x4df427=_0x4df427['concat'](_e(_0x330519['serverSyncTree_'],_0xe13d12,!0x0));}else _0x3b16cc=!0x0,_0x349faa='nodata',_0x4df427=_0x4df427['concat'](_e(_0x330519['serverSyncTree_'],_0x3ec72e['currentWriteId'],!0x0));}}}V(_0x330519['eventQueue_'],_0x1aa4f8,_0x4df427),_0x4df427=[],_0x3b16cc&&(_0x147087[_0x66d47d]['status']=0x2,function(_0x25c062){setTimeout(_0x25c062,Math['floor'](0x0));}(_0x147087[_0x66d47d]['unwatcher']),_0x147087[_0x66d47d]['onComplete']&&(_0x349faa==='nodata'?_0xa08f0d['push'](()=>_0x147087[_0x66d47d]['onComplete'](null,!0x1,_0x147087[_0x66d47d]['currentInputSnapshot'])):_0xa08f0d['push'](()=>_0x147087[_0x66d47d]['onComplete'](new Error(_0x349faa),!0x1,null))));}Kn(_0x330519,_0x330519['transactionQueueTree_']);for(let _0x250eaa=0x0;_0x250eaa<_0xa08f0d['length'];_0x250eaa++)ft(_0xa08f0d[_0x250eaa]);jn(_0x330519,_0x330519['transactionQueueTree_']);}function ua(_0x3026a4,_0x553826){let _0x408bff,_0x59151d=_0x3026a4['transactionQueueTree_'];for(_0x408bff=y(_0x553826);_0x408bff!==null&&je(_0x59151d)===void 0x0;)_0x59151d=$n(_0x59151d,_0x408bff),_0x553826=S(_0x553826),_0x408bff=y(_0x553826);return _0x59151d;}function da(_0x2cd145,_0x27b2a4){const _0x2f9bfd=[];return fa(_0x2cd145,_0x27b2a4,_0x2f9bfd),_0x2f9bfd['sort']((_0x5152e,_0x180863)=>_0x5152e['order']-_0x180863['order']),_0x2f9bfd;}function fa(_0x4008d8,_0x437f2f,_0x21d5c5){const _0xb4afd7=je(_0x437f2f);if(_0xb4afd7){for(let _0x291eda=0x0;_0x291eda<_0xb4afd7['length'];_0x291eda++)_0x21d5c5['push'](_0xb4afd7[_0x291eda]);}Gn(_0x437f2f,_0x1f1d96=>{fa(_0x4008d8,_0x1f1d96,_0x21d5c5);});}function Kn(_0x5bda8f,_0x549152){const _0x30ebe2=je(_0x549152);if(_0x30ebe2){let _0x4c0b78=0x0;for(let _0x249a1a=0x0;_0x249a1a<_0x30ebe2['length'];_0x249a1a++)_0x30ebe2[_0x249a1a]['status']!==0x2&&(_0x30ebe2[_0x4c0b78]=_0x30ebe2[_0x249a1a],_0x4c0b78++);_0x30ebe2['length']=_0x4c0b78,gs(_0x549152,_0x30ebe2['length']>0x0?_0x30ebe2:void 0x0);}Gn(_0x549152,_0x53dae1=>{Kn(_0x5bda8f,_0x53dae1);});}function Is(_0x3d4248,_0x476c00){const _0x3426d3=Qt(ua(_0x3d4248,_0x476c00)),_0x20dd02=$n(_0x3d4248['transactionQueueTree_'],_0x476c00);return ad(_0x20dd02,_0x5465c3=>{di(_0x3d4248,_0x5465c3);}),di(_0x3d4248,_0x20dd02),ia(_0x20dd02,_0x3e2095=>{di(_0x3d4248,_0x3e2095);}),_0x3426d3;}function di(_0x1c180c,_0x50c7c0){const _0x2eeaf1=je(_0x50c7c0);if(_0x2eeaf1){const _0x2c8374=[];let _0x453c4a=[],_0x1ccc6e=-0x1;for(let _0x1b81da=0x0;_0x1b81da<_0x2eeaf1['length'];_0x1b81da++)_0x2eeaf1[_0x1b81da]['status']===0x3||(_0x2eeaf1[_0x1b81da]['status']===0x1?(f(_0x1ccc6e===_0x1b81da-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x1ccc6e=_0x1b81da,_0x2eeaf1[_0x1b81da]['status']=0x3,_0x2eeaf1[_0x1b81da]['abortReason']='set'):(f(_0x2eeaf1[_0x1b81da]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x2eeaf1[_0x1b81da]['unwatcher'](),_0x453c4a=_0x453c4a['concat'](_e(_0x1c180c['serverSyncTree_'],_0x2eeaf1[_0x1b81da]['currentWriteId'],!0x0)),_0x2eeaf1[_0x1b81da]['onComplete']&&_0x2c8374['push'](_0x2eeaf1[_0x1b81da]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x1ccc6e===-0x1?gs(_0x50c7c0,void 0x0):_0x2eeaf1['length']=_0x1ccc6e+0x1,V(_0x1c180c['eventQueue_'],Qt(_0x50c7c0),_0x453c4a);for(let _0x5d3b27=0x0;_0x5d3b27<_0x2c8374['length'];_0x5d3b27++)ft(_0x2c8374[_0x5d3b27]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x41b727){let _0x128adf='';const _0x2214f5=_0x41b727['split']('/');for(let _0x33f0a2=0x0;_0x33f0a2<_0x2214f5['length'];_0x33f0a2++)if(_0x2214f5[_0x33f0a2]['length']>0x0){let _0x53d8b7=_0x2214f5[_0x33f0a2];try{_0x53d8b7=decodeURIComponent(_0x53d8b7['replace'](/\+/g,'\x20'));}catch{}_0x128adf+='/'+_0x53d8b7;}return _0x128adf;}function xd(_0xab9d2a){const _0xc83978={};_0xab9d2a['charAt'](0x0)==='?'&&(_0xab9d2a=_0xab9d2a['substring'](0x1));for(const _0x524e79 of _0xab9d2a['split']('&')){if(_0x524e79['length']===0x0)continue;const _0x408a8d=_0x524e79['split']('=');_0x408a8d['length']===0x2?_0xc83978[decodeURIComponent(_0x408a8d[0x0])]=decodeURIComponent(_0x408a8d[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x524e79+'\x27\x20in\x20query\x20\x27'+_0xab9d2a+'\x27');}return _0xc83978;}const vr=function(_0x54534e,_0x2f7224){const _0xf8e362=Fd(_0x54534e),_0x2f5cc9=_0xf8e362['namespace'];_0xf8e362['domain']==='firebase.com'&&ae(_0xf8e362['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x2f5cc9||_0x2f5cc9==='undefined')&&_0xf8e362['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0xf8e362['secure']||$l();const _0x261e63=_0xf8e362['scheme']==='ws'||_0xf8e362['scheme']==='wss';return{'repoInfo':new yo(_0xf8e362['host'],_0xf8e362['secure'],_0x2f5cc9,_0x261e63,_0x2f7224,'',_0x2f5cc9!==_0xf8e362['subdomain']),'path':new C(_0xf8e362['pathString'])};},Fd=function(_0x5554d7){let _0xd48e69='',_0x2656cc='',_0xf3b887='',_0x33c97f='',_0x54fa23='',_0x25c5f5=!0x0,_0x1532c9='https',_0x1fd383=0x1bb;if(typeof _0x5554d7=='string'){let _0x69b121=_0x5554d7['indexOf']('//');_0x69b121>=0x0&&(_0x1532c9=_0x5554d7['substring'](0x0,_0x69b121-0x1),_0x5554d7=_0x5554d7['substring'](_0x69b121+0x2));let _0x23a753=_0x5554d7['indexOf']('/');_0x23a753===-0x1&&(_0x23a753=_0x5554d7['length']);let _0x25faae=_0x5554d7['indexOf']('?');_0x25faae===-0x1&&(_0x25faae=_0x5554d7['length']),_0xd48e69=_0x5554d7['substring'](0x0,Math['min'](_0x23a753,_0x25faae)),_0x23a753<_0x25faae&&(_0x33c97f=Ld(_0x5554d7['substring'](_0x23a753,_0x25faae)));const _0x1ee9a2=xd(_0x5554d7['substring'](Math['min'](_0x5554d7['length'],_0x25faae)));_0x69b121=_0xd48e69['indexOf'](':'),_0x69b121>=0x0?(_0x25c5f5=_0x1532c9==='https'||_0x1532c9==='wss',_0x1fd383=parseInt(_0xd48e69['substring'](_0x69b121+0x1),0xa)):_0x69b121=_0xd48e69['length'];const _0x19e81e=_0xd48e69['slice'](0x0,_0x69b121);if(_0x19e81e['toLowerCase']()==='localhost')_0x2656cc='localhost';else{if(_0x19e81e['split']('.')['length']<=0x2)_0x2656cc=_0x19e81e;else{const _0xfa9941=_0xd48e69['indexOf']('.');_0xf3b887=_0xd48e69['substring'](0x0,_0xfa9941)['toLowerCase'](),_0x2656cc=_0xd48e69['substring'](_0xfa9941+0x1),_0x54fa23=_0xf3b887;}}'ns'in _0x1ee9a2&&(_0x54fa23=_0x1ee9a2['ns']);}return{'host':_0xd48e69,'port':_0x1fd383,'domain':_0x2656cc,'subdomain':_0xf3b887,'secure':_0x25c5f5,'scheme':_0x1532c9,'pathString':_0x33c97f,'namespace':_0x54fa23};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x2f5ad3=0x0;const _0x2a1e6=[];return function(_0x3c6506){const _0x2a684b=_0x3c6506===_0x2f5ad3;_0x2f5ad3=_0x3c6506;let _0x6d1ea1;const _0x5e37bc=new Array(0x8);for(_0x6d1ea1=0x7;_0x6d1ea1>=0x0;_0x6d1ea1--)_0x5e37bc[_0x6d1ea1]=Er['charAt'](_0x3c6506%0x40),_0x3c6506=Math['floor'](_0x3c6506/0x40);f(_0x3c6506===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x419100=_0x5e37bc['join']('');if(_0x2a684b){for(_0x6d1ea1=0xb;_0x6d1ea1>=0x0&&_0x2a1e6[_0x6d1ea1]===0x3f;_0x6d1ea1--)_0x2a1e6[_0x6d1ea1]=0x0;_0x2a1e6[_0x6d1ea1]++;}else{for(_0x6d1ea1=0x0;_0x6d1ea1<0xc;_0x6d1ea1++)_0x2a1e6[_0x6d1ea1]=Math['floor'](Math['random']()*0x40);}for(_0x6d1ea1=0x0;_0x6d1ea1<0xc;_0x6d1ea1++)_0x419100+=Er['charAt'](_0x2a1e6[_0x6d1ea1]);return f(_0x419100['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x419100;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x4cda5e,_0x4c86eb,_0x39c27c,_0x2aeb85){this['eventType']=_0x4cda5e,this['eventRegistration']=_0x4c86eb,this['snapshot']=_0x39c27c,this['prevName']=_0x2aeb85;}['getPath'](){const _0x92cb21=this['snapshot']['ref'];return this['eventType']==='value'?_0x92cb21['_path']:_0x92cb21['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x3f092f,_0x224015,_0x428e59){this['eventRegistration']=_0x3f092f,this['error']=_0x224015,this['path']=_0x428e59;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x557496,_0x21343){this['snapshotCallback']=_0x557496,this['cancelCallback']=_0x21343;}['onValue'](_0x30b236,_0x1e3cdd){this['snapshotCallback']['call'](null,_0x30b236,_0x1e3cdd);}['onCancel'](_0x370381){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x370381);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x25b72d){return this['snapshotCallback']===_0x25b72d['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x25b72d['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x25b72d['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x110767,_0x266ec8){this['_repo']=_0x110767,this['_path']=_0x266ec8;}['cancel'](){const _0xc720cd=new H();return bd(this['_repo'],this['_path'],_0xc720cd['wrapCallback'](()=>{})),_0xc720cd['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x48cbbc=new H();return yr(this['_repo'],this['_path'],null,_0x48cbbc['wrapCallback'](()=>{})),_0x48cbbc['promise'];}['set'](_0x2bafb0){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x2bafb0,this['_path'],!0x1);const _0x377755=new H();return yr(this['_repo'],this['_path'],_0x2bafb0,_0x377755['wrapCallback'](()=>{})),_0x377755['promise'];}['setWithPriority'](_0x442dab,_0x4ba92f){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x442dab,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x4ba92f);const _0x3845de=new H();return Rd(this['_repo'],this['_path'],_0x442dab,_0x4ba92f,_0x3845de['wrapCallback'](()=>{})),_0x3845de['promise'];}['update'](_0x44ef1f){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x44ef1f,this['_path']);const _0x22c853=new H();return Ad(this['_repo'],this['_path'],_0x44ef1f,_0x22c853['wrapCallback'](()=>{})),_0x22c853['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x201511,_0x3dac45,_0x513be9,_0xfe2b39){this['_repo']=_0x201511,this['_path']=_0x3dac45,this['_queryParams']=_0x513be9,this['_orderByCalled']=_0xfe2b39;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0xdfc2d=sr(this['_queryParams']),_0x48fc90=$i(_0xdfc2d);return _0x48fc90==='{}'?'default':_0x48fc90;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x557199){if(_0x557199=P(_0x557199),!(_0x557199 instanceof Ae))return!0x1;const _0x4524e9=this['_repo']===_0x557199['_repo'],_0x244b2f=Ki(this['_path'],_0x557199['_path']),_0x4c6dab=this['_queryIdentifier']===_0x557199['_queryIdentifier'];return _0x4524e9&&_0x244b2f&&_0x4c6dab;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x4c42f7,_0x1c825b){if(_0x4c42f7['_orderByCalled']===!0x0)throw new Error(_0x1c825b+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x287ee2){let _0xbf802c=null,_0x936f29=null;if(_0x287ee2['hasStart']()&&(_0xbf802c=_0x287ee2['getIndexStartValue']()),_0x287ee2['hasEnd']()&&(_0x936f29=_0x287ee2['getIndexEndValue']()),_0x287ee2['getIndex']()===ve){const _0x4faf62='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x1cae1f='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x287ee2['hasStart']()){if(_0x287ee2['getIndexStartName']()!==We)throw new Error(_0x4faf62);if(typeof _0xbf802c!='string')throw new Error(_0x1cae1f);}if(_0x287ee2['hasEnd']()){if(_0x287ee2['getIndexEndName']()!==we)throw new Error(_0x4faf62);if(typeof _0x936f29!='string')throw new Error(_0x1cae1f);}}else{if(_0x287ee2['getIndex']()===R){if(_0xbf802c!=null&&!Bt(_0xbf802c)||_0x936f29!=null&&!Bt(_0x936f29))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x287ee2['getIndex']()instanceof Ji||_0x287ee2['getIndex']()===Mo,'unknown\x20index\x20type.'),_0xbf802c!=null&&typeof _0xbf802c=='object'||_0x936f29!=null&&typeof _0x936f29=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x2a70f3){if(_0x2a70f3['hasStart']()&&_0x2a70f3['hasEnd']()&&_0x2a70f3['hasLimit']()&&!_0x2a70f3['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x53600a,_0x4c80fd){super(_0x53600a,_0x4c80fd,new Zi(),!0x1);}get['parent'](){const _0x225b54=Ro(this['_path']);return _0x225b54===null?null:new ee(this['_repo'],_0x225b54);}get['root'](){let _0x2d592a=this;for(;_0x2d592a['parent']!==null;)_0x2d592a=_0x2d592a['parent'];return _0x2d592a;}}class lt{constructor(_0x4f2e9c,_0x17669b,_0x266b92){this['_node']=_0x4f2e9c,this['ref']=_0x17669b,this['_index']=_0x266b92;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x1be750){const _0x3b9378=new C(_0x1be750),_0x285203=Vt(this['ref'],_0x1be750);return new lt(this['_node']['getChild'](_0x3b9378),_0x285203,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x54fa41){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0xb3f693,_0x2894ea)=>_0x54fa41(new lt(_0x2894ea,Vt(this['ref'],_0xb3f693),R)));}['hasChild'](_0x313489){const _0x594d4f=new C(_0x313489);return!this['_node']['getChild'](_0x594d4f)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x18fc9a,_0x4d528b){return _0x18fc9a=P(_0x18fc9a),_0x18fc9a['_checkNotDeleted']('ref'),_0x4d528b!==void 0x0?Vt(_0x18fc9a['_root'],_0x4d528b):_0x18fc9a['_root'];}function Vt(_0x50c39c,_0x1265e4){return _0x50c39c=P(_0x50c39c),y(_0x50c39c['_path'])===null?pd('child','path',_0x1265e4):ys('child','path',_0x1265e4),new ee(_0x50c39c['_repo'],k(_0x50c39c['_path'],_0x1265e4));}function v_(_0x2a6a89){return _0x2a6a89=P(_0x2a6a89),new Vd(_0x2a6a89['_repo'],_0x2a6a89['_path']);}function E_(_0x2499ca,_0x2758dd){_0x2499ca=P(_0x2499ca),Me('push',_0x2499ca['_path']),He('push',_0x2758dd,_0x2499ca['_path'],!0x0);const _0xb3b627=la(_0x2499ca['_repo']),_0x54a3de=Ud(_0xb3b627),_0x3c3f48=Vt(_0x2499ca,_0x54a3de),_0xc7b231=Vt(_0x2499ca,_0x54a3de);let _0x24dcaf;return _0x2758dd!=null?_0x24dcaf=Hd(_0xc7b231,_0x2758dd)['then'](()=>_0xc7b231):_0x24dcaf=Promise['resolve'](_0xc7b231),_0x3c3f48['then']=_0x24dcaf['then']['bind'](_0x24dcaf),_0x3c3f48['catch']=_0x24dcaf['then']['bind'](_0x24dcaf,void 0x0),_0x3c3f48;}function Hd(_0x120a17,_0x94cf53){_0x120a17=P(_0x120a17),Me('set',_0x120a17['_path']),He('set',_0x94cf53,_0x120a17['_path'],!0x1);const _0xadfcb6=new H();return Cd(_0x120a17['_repo'],_0x120a17['_path'],_0x94cf53,null,_0xadfcb6['wrapCallback'](()=>{})),_0xadfcb6['promise'];}function I_(_0x412650,_0x5d92aa){ra('update',_0x5d92aa,_0x412650['_path']);const _0x46c5ff=new H();return Td(_0x412650['_repo'],_0x412650['_path'],_0x5d92aa,_0x46c5ff['wrapCallback'](()=>{})),_0x46c5ff['promise'];}function w_(_0x497c59){_0x497c59=P(_0x497c59);const _0x310976=new pa(()=>{}),_0xc98452=new Qn(_0x310976);return wd(_0x497c59['_repo'],_0x497c59,_0xc98452)['then'](_0x445a23=>new lt(_0x445a23,new ee(_0x497c59['_repo'],_0x497c59['_path']),_0x497c59['_queryParams']['getIndex']()));}class Qn{constructor(_0x5ce587){this['callbackContext']=_0x5ce587;}['respondsTo'](_0x234f55){return _0x234f55==='value';}['createEvent'](_0x293281,_0x19058b){const _0x20d2c9=_0x19058b['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x293281['snapshotNode'],new ee(_0x19058b['_repo'],_0x19058b['_path']),_0x20d2c9));}['getEventRunner'](_0x58f05f){return _0x58f05f['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x58f05f['error']):()=>this['callbackContext']['onValue'](_0x58f05f['snapshot'],null);}['createCancelEvent'](_0x298aae,_0x46a08e){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x298aae,_0x46a08e):null;}['matches'](_0x30f986){return _0x30f986 instanceof Qn?!_0x30f986['callbackContext']||!this['callbackContext']?!0x0:_0x30f986['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x102124,_0xad74ea,_0x55a98c,_0x1b1d5a,_0x361abd){const _0x2ecf69=new pa(_0x55a98c,void 0x0),_0x3c905d=new Qn(_0x2ecf69);return kd(_0x102124['_repo'],_0x102124,_0x3c905d),()=>Pd(_0x102124['_repo'],_0x102124,_0x3c905d);}function Gd(_0x2d4a51,_0x5b962e,_0x156f77,_0x485f43){return $d(_0x2d4a51,'value',_0x5b962e);}class mt{}class ma extends mt{constructor(_0x32d05b,_0x15d50c){super(),this['_value']=_0x32d05b,this['_key']=_0x15d50c,this['type']='endAt';}['_apply'](_0x3ea9f5){He('endAt',this['_value'],_0x3ea9f5['_path'],!0x0);const _0x55673b=Jh(_0x3ea9f5['_queryParams'],this['_value'],this['_key']);if(ga(_0x55673b),Yn(_0x55673b),_0x3ea9f5['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x3ea9f5['_repo'],_0x3ea9f5['_path'],_0x55673b,_0x3ea9f5['_orderByCalled']);}}function C_(_0x5c04b6,_0x35f070){return new ma(_0x5c04b6,_0x35f070);}class ya extends mt{constructor(_0x8aeef2,_0x571ee4){super(),this['_value']=_0x8aeef2,this['_key']=_0x571ee4,this['type']='startAt';}['_apply'](_0x241e6f){He('startAt',this['_value'],_0x241e6f['_path'],!0x0);const _0x5e9c8d=Qh(_0x241e6f['_queryParams'],this['_value'],this['_key']);if(ga(_0x5e9c8d),Yn(_0x5e9c8d),_0x241e6f['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x241e6f['_repo'],_0x241e6f['_path'],_0x5e9c8d,_0x241e6f['_orderByCalled']);}}function T_(_0x34366a=null,_0x449c46){return new ya(_0x34366a,_0x449c46);}class qd extends mt{constructor(_0xa9e1be){super(),this['_limit']=_0xa9e1be,this['type']='limitToFirst';}['_apply'](_0x479d74){if(_0x479d74['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x479d74['_repo'],_0x479d74['_path'],Yh(_0x479d74['_queryParams'],this['_limit']),_0x479d74['_orderByCalled']);}}function S_(_0x258b51){if(Math['floor'](_0x258b51)!==_0x258b51||_0x258b51<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x258b51);}class zd extends mt{constructor(_0x4fd182){super(),this['_path']=_0x4fd182,this['type']='orderByChild';}['_apply'](_0x3c0979){_a(_0x3c0979,'orderByChild');const _0x5ae3fc=new C(this['_path']);if(v(_0x5ae3fc))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0xeb5f2d=new Ji(_0x5ae3fc),_0x2fbec7=xo(_0x3c0979['_queryParams'],_0xeb5f2d);return Yn(_0x2fbec7),new Ae(_0x3c0979['_repo'],_0x3c0979['_path'],_0x2fbec7,!0x0);}}function b_(_0x5210cd){if(_0x5210cd==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x5210cd==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x5210cd==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x5210cd),new zd(_0x5210cd);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x3c097d){_a(_0x3c097d,'orderByKey');const _0x307a26=xo(_0x3c097d['_queryParams'],ve);return Yn(_0x307a26),new Ae(_0x3c097d['_repo'],_0x3c097d['_path'],_0x307a26,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x5bb095,_0x55c2ea){super(),this['_value']=_0x5bb095,this['_key']=_0x55c2ea,this['type']='equalTo';}['_apply'](_0x37568d){if(He('equalTo',this['_value'],_0x37568d['_path'],!0x1),_0x37568d['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x37568d['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x37568d));}}function A_(_0x333707,_0x4e2ff2){return new Kd(_0x333707,_0x4e2ff2);}function k_(_0x1383a3,..._0x397243){let _0x50fba3=P(_0x1383a3);for(const _0x592476 of _0x397243)_0x50fba3=_0x592476['_apply'](_0x50fba3);return _0x50fba3;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x2b86e9,_0x16713d,_0x282e9f,_0x1b6798){const _0x43896f=_0x16713d['lastIndexOf'](':'),_0x451e69=_0x16713d['substring'](0x0,_0x43896f),_0x4d5b2c=qt(_0x451e69);_0x2b86e9['repoInfo_']=new yo(_0x16713d,_0x4d5b2c,_0x2b86e9['repoInfo_']['namespace'],_0x2b86e9['repoInfo_']['webSocketOnly'],_0x2b86e9['repoInfo_']['nodeAdmin'],_0x2b86e9['repoInfo_']['persistenceKey'],_0x2b86e9['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x282e9f),_0x1b6798&&(_0x2b86e9['authTokenProvider_']=_0x1b6798);}function Xd(_0x3c4297,_0x2d20ab,_0x546b4c,_0x1ebbfb,_0x4cd71e){let _0x15226b=_0x1ebbfb||_0x3c4297['options']['databaseURL'];_0x15226b===void 0x0&&(_0x3c4297['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x3c4297['options']['projectId']),_0x15226b=_0x3c4297['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x2fbea7=vr(_0x15226b,_0x4cd71e),_0x2c13b1=_0x2fbea7['repoInfo'],_0x507f00;typeof process<'u'&&Bs&&(_0x507f00=Bs[Yd]),_0x507f00?(_0x15226b='http://'+_0x507f00+'?ns='+_0x2c13b1['namespace'],_0x2fbea7=vr(_0x15226b,_0x4cd71e),_0x2c13b1=_0x2fbea7['repoInfo']):_0x2fbea7['repoInfo']['secure'];const _0x3e2243=new eh(_0x3c4297['name'],_0x3c4297['options'],_0x2d20ab);_d('Invalid\x20Firebase\x20Database\x20URL',_0x2fbea7),v(_0x2fbea7['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x5f38d2=ef(_0x2c13b1,_0x3c4297,_0x3e2243,new Zl(_0x3c4297,_0x546b4c));return new tf(_0x5f38d2,_0x3c4297);}function Zd(_0x49b93e,_0x540b3e){const _0x4d0034=Di[_0x540b3e];(!_0x4d0034||_0x4d0034[_0x49b93e['key']]!==_0x49b93e)&&ae('Database\x20'+_0x540b3e+'('+_0x49b93e['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x49b93e),delete _0x4d0034[_0x49b93e['key']];}function ef(_0x4a1416,_0x41092c,_0xb08f83,_0x38c3bd){let _0x42791d=Di[_0x41092c['name']];_0x42791d||(_0x42791d={},Di[_0x41092c['name']]=_0x42791d);let _0x2cef92=_0x42791d[_0x4a1416['toURLString']()];return _0x2cef92&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x2cef92=new vd(_0x4a1416,Qd,_0xb08f83,_0x38c3bd),_0x42791d[_0x4a1416['toURLString']()]=_0x2cef92,_0x2cef92;}class tf{constructor(_0x43e7be,_0x3d8327){this['_repoInternal']=_0x43e7be,this['app']=_0x3d8327,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x4f6c69){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x4f6c69+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x2c93fa=Zr(),_0x547030){const _0x39d0b1=Hi(_0x2c93fa,'database')['getImmediate']({'identifier':_0x547030});if(!_0x39d0b1['_instanceStarted']){const _0xe32a35=hc('database');_0xe32a35&&nf(_0x39d0b1,..._0xe32a35);}return _0x39d0b1;}function nf(_0x19410b,_0x52ce34,_0x3c2748,_0x2044f4={}){_0x19410b=P(_0x19410b),_0x19410b['_checkNotDeleted']('useEmulator');const _0x3fea88=_0x52ce34+':'+_0x3c2748,_0x3cc08a=_0x19410b['_repoInternal'];if(_0x19410b['_instanceStarted']){if(_0x3fea88===_0x19410b['_repoInternal']['repoInfo_']['host']&&xe(_0x2044f4,_0x3cc08a['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x5b466f;if(_0x3cc08a['repoInfo_']['nodeAdmin'])_0x2044f4['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x5b466f=new an(an['OWNER']);else{if(_0x2044f4['mockUserToken']){const _0x49527a=typeof _0x2044f4['mockUserToken']=='string'?_0x2044f4['mockUserToken']:uc(_0x2044f4['mockUserToken'],_0x19410b['app']['options']['projectId']);_0x5b466f=new an(_0x49527a);}}qt(_0x52ce34)&&Qr(_0x52ce34),Jd(_0x3cc08a,_0x3fea88,_0x2044f4,_0x5b466f);}function N_(_0x3616c5){_0x3616c5=P(_0x3616c5),_0x3616c5['_checkNotDeleted']('goOffline'),ha(_0x3616c5['_repo']);}function O_(_0x112757){_0x112757=P(_0x112757),_0x112757['_checkNotDeleted']('goOnline'),Nd(_0x112757['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x4801dd){Ul(dt),st(new Fe('database',(_0x483f7e,{instanceIdentifier:_0x38d2ce})=>{const _0x3cc608=_0x483f7e['getProvider']('app')['getImmediate'](),_0x5f10f0=_0x483f7e['getProvider']('auth-internal'),_0x258685=_0x483f7e['getProvider']('app-check-internal');return Xd(_0x3cc608,_0x5f10f0,_0x258685,_0x38d2ce);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x4801dd),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x21e4a6,_0x28e6fd){this['committed']=_0x21e4a6,this['snapshot']=_0x28e6fd;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0xa8d765,_0x252e71,_0x345840){if(_0xa8d765=P(_0xa8d765),Me('Reference.transaction',_0xa8d765['_path']),_0xa8d765['key']==='.length'||_0xa8d765['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0xa8d765['key']+'\x20is\x20a\x20read-only\x20object.';const _0x214109=!0x0,_0x38219e=new H(),_0x216a71=(_0x2472ed,_0x14719a,_0x42f45a)=>{let _0x589d1f=null;_0x2472ed?_0x38219e['reject'](_0x2472ed):(_0x589d1f=new lt(_0x42f45a,new ee(_0xa8d765['_repo'],_0xa8d765['_path']),R),_0x38219e['resolve'](new of(_0x14719a,_0x589d1f)));},_0x46b0e7=Gd(_0xa8d765,()=>{});return Od(_0xa8d765['_repo'],_0xa8d765['_path'],_0x252e71,_0x216a71,_0x46b0e7,_0x214109),_0x38219e['promise'];}se['prototype']['simpleListen']=function(_0x5e4413,_0x114556){this['sendRequest']('q',{'p':_0x5e4413},_0x114556);},se['prototype']['echo']=function(_0xe84487,_0x28ef7a){this['sendRequest']('echo',{'d':_0xe84487},_0x28ef7a);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x2798d9,..._0x21e5fd){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x2798d9,..._0x21e5fd);}function cn(_0x405e27,..._0x337835){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x405e27,..._0x337835);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x5e5a35,..._0x3619cc){throw ws(_0x5e5a35,..._0x3619cc);}function X(_0x2300d8,..._0x4435ac){return ws(_0x2300d8,..._0x4435ac);}function Ia(_0x24cf4c,_0x2f4c28,_0x2f99ac){const _0x18b754={...af(),[_0x2f4c28]:_0x2f99ac};return new Gt('auth','Firebase',_0x18b754)['create'](_0x2f4c28,{'appName':_0x24cf4c['name']});}function re(_0x444913){return Ia(_0x444913,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x4028a4,..._0x3d1faf){if(typeof _0x4028a4!='string'){const _0x20eaa0=_0x3d1faf[0x0],_0x4fcf95=[..._0x3d1faf['slice'](0x1)];return _0x4fcf95[0x0]&&(_0x4fcf95[0x0]['appName']=_0x4028a4['name']),_0x4028a4['_errorFactory']['create'](_0x20eaa0,..._0x4fcf95);}return Ea['create'](_0x4028a4,..._0x3d1faf);}function m(_0x444a35,_0xad578f,..._0x56afbe){if(!_0x444a35)throw ws(_0xad578f,..._0x56afbe);}function ne(_0x32a446){const _0x3966b5='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x32a446;throw cn(_0x3966b5),new Error(_0x3966b5);}function ce(_0x49855a,_0x4bc8ab){_0x49855a||ne(_0x4bc8ab);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x529168;return typeof self<'u'&&((_0x529168=self['location'])==null?void 0x0:_0x529168['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x22dcd0;return typeof self<'u'&&((_0x22dcd0=self['location'])==null?void 0x0:_0x22dcd0['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x1d83bb=navigator;return _0x1d83bb['languages']&&_0x1d83bb['languages'][0x0]||_0x1d83bb['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x4b61b2,_0x3be32b){this['shortDelay']=_0x4b61b2,this['longDelay']=_0x3be32b,ce(_0x3be32b>_0x4b61b2,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x14bfd4,_0x21f1a1){ce(_0x14bfd4['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x37d241}=_0x14bfd4['emulator'];return _0x21f1a1?''+_0x37d241+(_0x21f1a1['startsWith']('/')?_0x21f1a1['slice'](0x1):_0x21f1a1):_0x37d241;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0xe5ff24,_0x4aae5c,_0x1fc71b){this['fetchImpl']=_0xe5ff24,_0x4aae5c&&(this['headersImpl']=_0x4aae5c),_0x1fc71b&&(this['responseImpl']=_0x1fc71b);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x14da1e,_0x214385){return _0x14da1e['tenantId']&&!_0x214385['tenantId']?{..._0x214385,'tenantId':_0x14da1e['tenantId']}:_0x214385;}async function Pe(_0x7a54ce,_0x7e76ae,_0x19a41e,_0x3eb1f9,_0x267c2a={}){return Ca(_0x7a54ce,_0x267c2a,async()=>{let _0xfc01e4={},_0x335d17={};_0x3eb1f9&&(_0x7e76ae==='GET'?_0x335d17=_0x3eb1f9:_0xfc01e4={'body':JSON['stringify'](_0x3eb1f9)});const _0x2f9f1f=ut({..._0x335d17,'key':_0x7a54ce['config']['apiKey']})['slice'](0x1),_0x4d250e=await _0x7a54ce['_getAdditionalHeaders']();_0x4d250e['Content-Type']='application/json',_0x7a54ce['languageCode']&&(_0x4d250e['X-Firebase-Locale']=_0x7a54ce['languageCode']);const _0x12cc91={'method':_0x7e76ae,'headers':_0x4d250e,..._0xfc01e4};return dc()||(_0x12cc91['referrerPolicy']='strict-origin-when-cross-origin'),_0x7a54ce['emulatorConfig']&&qt(_0x7a54ce['emulatorConfig']['host'])&&(_0x12cc91['credentials']='include'),wa['fetch']()(await Ta(_0x7a54ce,_0x7a54ce['config']['apiHost'],_0x19a41e,_0x2f9f1f),_0x12cc91);});}async function Ca(_0x70a7ad,_0x108569,_0xe37833){_0x70a7ad['_canInitEmulator']=!0x1;const _0x11b700={...df,..._0x108569};try{const _0x16fec2=new gf(_0x70a7ad),_0x5684ad=await Promise['race']([_0xe37833(),_0x16fec2['promise']]);_0x16fec2['clearNetworkTimeout']();const _0x3538df=await _0x5684ad['json']();if('needConfirmation'in _0x3538df)throw on(_0x70a7ad,'account-exists-with-different-credential',_0x3538df);if(_0x5684ad['ok']&&!('errorMessage'in _0x3538df))return _0x3538df;{const _0x55bcd2=_0x5684ad['ok']?_0x3538df['errorMessage']:_0x3538df['error']['message'],[_0x4e561b,_0x491307]=_0x55bcd2['split']('\x20:\x20');if(_0x4e561b==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x70a7ad,'credential-already-in-use',_0x3538df);if(_0x4e561b==='EMAIL_EXISTS')throw on(_0x70a7ad,'email-already-in-use',_0x3538df);if(_0x4e561b==='USER_DISABLED')throw on(_0x70a7ad,'user-disabled',_0x3538df);const _0x2ba52c=_0x11b700[_0x4e561b]||_0x4e561b['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x491307)throw Ia(_0x70a7ad,_0x2ba52c,_0x491307);Y(_0x70a7ad,_0x2ba52c);}}catch(_0x5a2209){if(_0x5a2209 instanceof Re)throw _0x5a2209;Y(_0x70a7ad,'network-request-failed',{'message':String(_0x5a2209)});}}async function en(_0x1cf60b,_0x141bad,_0x8e5912,_0x2698b7,_0x16fbd3={}){const _0x523a59=await Pe(_0x1cf60b,_0x141bad,_0x8e5912,_0x2698b7,_0x16fbd3);return'mfaPendingCredential'in _0x523a59&&Y(_0x1cf60b,'multi-factor-auth-required',{'_serverResponse':_0x523a59}),_0x523a59;}async function Ta(_0x5503f9,_0x1d11d,_0x1ade5d,_0x37fc61){const _0x15a95c=''+_0x1d11d+_0x1ade5d+'?'+_0x37fc61,_0x436cef=_0x5503f9,_0x34f807=_0x436cef['config']['emulator']?Cs(_0x5503f9['config'],_0x15a95c):_0x5503f9['config']['apiScheme']+'://'+_0x15a95c;return ff['includes'](_0x1ade5d)&&(await _0x436cef['_persistenceManagerAvailable'],_0x436cef['_getPersistenceType']()==='COOKIE')?_0x436cef['_getPersistence']()['_getFinalTarget'](_0x34f807)['toString']():_0x34f807;}function _f(_0x666e57){switch(_0x666e57){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x49146e){this['auth']=_0x49146e,this['timer']=null,this['promise']=new Promise((_0x53a4f5,_0x122796)=>{this['timer']=setTimeout(()=>_0x122796(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x5abe41,_0x4686d2,_0x5604da){const _0x1710b2={'appName':_0x5abe41['name']};_0x5604da['email']&&(_0x1710b2['email']=_0x5604da['email']),_0x5604da['phoneNumber']&&(_0x1710b2['phoneNumber']=_0x5604da['phoneNumber']);const _0x379ecd=X(_0x5abe41,_0x4686d2,_0x1710b2);return _0x379ecd['customData']['_tokenResponse']=_0x5604da,_0x379ecd;}function wr(_0x33ad70){return _0x33ad70!==void 0x0&&_0x33ad70['enterprise']!==void 0x0;}class mf{constructor(_0x2bea07){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x2bea07['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x2bea07['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x2bea07['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0xcc6220){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x219edf of this['recaptchaEnforcementState'])if(_0x219edf['provider']&&_0x219edf['provider']===_0xcc6220)return _f(_0x219edf['enforcementState']);return null;}['isProviderEnabled'](_0x525fe9){return this['getProviderEnforcementState'](_0x525fe9)==='ENFORCE'||this['getProviderEnforcementState'](_0x525fe9)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x2e096c,_0x4219d0){return Pe(_0x2e096c,'GET','/v2/recaptchaConfig',ke(_0x2e096c,_0x4219d0));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x630eff,_0x4e1095){return Pe(_0x630eff,'POST','/v1/accounts:delete',_0x4e1095);}async function Pn(_0x44a587,_0x2e546f){return Pe(_0x44a587,'POST','/v1/accounts:lookup',_0x2e546f);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x309580){if(_0x309580)try{const _0x318949=new Date(Number(_0x309580));if(!isNaN(_0x318949['getTime']()))return _0x318949['toUTCString']();}catch{}}async function Ef(_0x6f0a28,_0x1931e4=!0x1){const _0x4471a3=P(_0x6f0a28),_0x1c847c=await _0x4471a3['getIdToken'](_0x1931e4),_0x41e888=Ts(_0x1c847c);m(_0x41e888&&_0x41e888['exp']&&_0x41e888['auth_time']&&_0x41e888['iat'],_0x4471a3['auth'],'internal-error');const _0x24a7e1=typeof _0x41e888['firebase']=='object'?_0x41e888['firebase']:void 0x0,_0x3f4fc6=_0x24a7e1==null?void 0x0:_0x24a7e1['sign_in_provider'];return{'claims':_0x41e888,'token':_0x1c847c,'authTime':Pt(fi(_0x41e888['auth_time'])),'issuedAtTime':Pt(fi(_0x41e888['iat'])),'expirationTime':Pt(fi(_0x41e888['exp'])),'signInProvider':_0x3f4fc6||null,'signInSecondFactor':(_0x24a7e1==null?void 0x0:_0x24a7e1['sign_in_second_factor'])||null};}function fi(_0x586ea4){return Number(_0x586ea4)*0x3e8;}function Ts(_0x41ca09){const [_0x5028fd,_0x413575,_0x1e20d4]=_0x41ca09['split']('.');if(_0x5028fd===void 0x0||_0x413575===void 0x0||_0x1e20d4===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x5533b2=fn(_0x413575);return _0x5533b2?JSON['parse'](_0x5533b2):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x11ba4f){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x11ba4f==null?void 0x0:_0x11ba4f['toString']()),null;}}function Cr(_0x546577){const _0x3e3680=Ts(_0x546577);return m(_0x3e3680,'internal-error'),m(typeof _0x3e3680['exp']<'u','internal-error'),m(typeof _0x3e3680['iat']<'u','internal-error'),Number(_0x3e3680['exp'])-Number(_0x3e3680['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x357e3b,_0xb2518a,_0x4daed=!0x1){if(_0x4daed)return _0xb2518a;try{return await _0xb2518a;}catch(_0x47b633){throw _0x47b633 instanceof Re&&If(_0x47b633)&&_0x357e3b['auth']['currentUser']===_0x357e3b&&await _0x357e3b['auth']['signOut'](),_0x47b633;}}function If({code:_0x165934}){return _0x165934==='auth/user-disabled'||_0x165934==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x2e6e74){this['user']=_0x2e6e74,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x50a497){if(_0x50a497){const _0x2d93f8=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x2d93f8;}else{this['errorBackoff']=0x7530;const _0x3c14f9=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x3c14f9);}}['schedule'](_0x21d78c=!0x1){if(!this['isRunning'])return;const _0x2f8bc2=this['getInterval'](_0x21d78c);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x2f8bc2);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x2c6e0b){(_0x2c6e0b==null?void 0x0:_0x2c6e0b['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x3fd13b,_0x14851b){this['createdAt']=_0x3fd13b,this['lastLoginAt']=_0x14851b,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x4991ed){this['createdAt']=_0x4991ed['createdAt'],this['lastLoginAt']=_0x4991ed['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x52800e){var _0x2a0402;const _0x31d4f1=_0x52800e['auth'],_0x5d8bb5=await _0x52800e['getIdToken'](),_0x4ef37c=await Ht(_0x52800e,Pn(_0x31d4f1,{'idToken':_0x5d8bb5}));m(_0x4ef37c==null?void 0x0:_0x4ef37c['users']['length'],_0x31d4f1,'internal-error');const _0xbf3a33=_0x4ef37c['users'][0x0];_0x52800e['_notifyReloadListener'](_0xbf3a33);const _0x280d25=(_0x2a0402=_0xbf3a33['providerUserInfo'])!=null&&_0x2a0402['length']?Sa(_0xbf3a33['providerUserInfo']):[],_0x1ec118=Tf(_0x52800e['providerData'],_0x280d25),_0x22bd58=_0x52800e['isAnonymous'],_0x39f7ba=!(_0x52800e['email']&&_0xbf3a33['passwordHash'])&&!(_0x1ec118!=null&&_0x1ec118['length']),_0x2d7dca=_0x22bd58?_0x39f7ba:!0x1,_0x2d4104={'uid':_0xbf3a33['localId'],'displayName':_0xbf3a33['displayName']||null,'photoURL':_0xbf3a33['photoUrl']||null,'email':_0xbf3a33['email']||null,'emailVerified':_0xbf3a33['emailVerified']||!0x1,'phoneNumber':_0xbf3a33['phoneNumber']||null,'tenantId':_0xbf3a33['tenantId']||null,'providerData':_0x1ec118,'metadata':new Li(_0xbf3a33['createdAt'],_0xbf3a33['lastLoginAt']),'isAnonymous':_0x2d7dca};Object['assign'](_0x52800e,_0x2d4104);}async function Cf(_0x4b7899){const _0x4979f2=P(_0x4b7899);await Nn(_0x4979f2),await _0x4979f2['auth']['_persistUserIfCurrent'](_0x4979f2),_0x4979f2['auth']['_notifyListenersIfCurrent'](_0x4979f2);}function Tf(_0x1a47ea,_0x1e33c7){return[..._0x1a47ea['filter'](_0x3c7b1f=>!_0x1e33c7['some'](_0x55803b=>_0x55803b['providerId']===_0x3c7b1f['providerId'])),..._0x1e33c7];}function Sa(_0x449d2){return _0x449d2['map'](({providerId:_0x360676,..._0x172cd7})=>({'providerId':_0x360676,'uid':_0x172cd7['rawId']||'','displayName':_0x172cd7['displayName']||null,'email':_0x172cd7['email']||null,'phoneNumber':_0x172cd7['phoneNumber']||null,'photoURL':_0x172cd7['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x37d873,_0x5ef5dd){const _0x272090=await Ca(_0x37d873,{},async()=>{const _0x4d21d7=ut({'grant_type':'refresh_token','refresh_token':_0x5ef5dd})['slice'](0x1),{tokenApiHost:_0x1c83fc,apiKey:_0x327073}=_0x37d873['config'],_0x14478f=await Ta(_0x37d873,_0x1c83fc,'/v1/token','key='+_0x327073),_0x149f97=await _0x37d873['_getAdditionalHeaders']();_0x149f97['Content-Type']='application/x-www-form-urlencoded';const _0x4fc9a1={'method':'POST','headers':_0x149f97,'body':_0x4d21d7};return _0x37d873['emulatorConfig']&&qt(_0x37d873['emulatorConfig']['host'])&&(_0x4fc9a1['credentials']='include'),wa['fetch']()(_0x14478f,_0x4fc9a1);});return{'accessToken':_0x272090['access_token'],'expiresIn':_0x272090['expires_in'],'refreshToken':_0x272090['refresh_token']};}async function bf(_0x5952b9,_0x5a94bc){return Pe(_0x5952b9,'POST','/v2/accounts:revokeToken',ke(_0x5952b9,_0x5a94bc));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x510f48){m(_0x510f48['idToken'],'internal-error'),m(typeof _0x510f48['idToken']<'u','internal-error'),m(typeof _0x510f48['refreshToken']<'u','internal-error');const _0x34ea0b='expiresIn'in _0x510f48&&typeof _0x510f48['expiresIn']<'u'?Number(_0x510f48['expiresIn']):Cr(_0x510f48['idToken']);this['updateTokensAndExpiration'](_0x510f48['idToken'],_0x510f48['refreshToken'],_0x34ea0b);}['updateFromIdToken'](_0x2344ba){m(_0x2344ba['length']!==0x0,'internal-error');const _0x225ba8=Cr(_0x2344ba);this['updateTokensAndExpiration'](_0x2344ba,null,_0x225ba8);}async['getToken'](_0x6c1815,_0x268b94=!0x1){return!_0x268b94&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x6c1815,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x6c1815,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x43fbef,_0x300f5b){const {accessToken:_0x32449a,refreshToken:_0x6c258b,expiresIn:_0x1cb462}=await Sf(_0x43fbef,_0x300f5b);this['updateTokensAndExpiration'](_0x32449a,_0x6c258b,Number(_0x1cb462));}['updateTokensAndExpiration'](_0x41471a,_0x576e38,_0x3cfd50){this['refreshToken']=_0x576e38||null,this['accessToken']=_0x41471a||null,this['expirationTime']=Date['now']()+_0x3cfd50*0x3e8;}static['fromJSON'](_0x5b7267,_0x1342c4){const {refreshToken:_0x1ec836,accessToken:_0xd958b8,expirationTime:_0xb0f4bf}=_0x1342c4,_0x3d5000=new et();return _0x1ec836&&(m(typeof _0x1ec836=='string','internal-error',{'appName':_0x5b7267}),_0x3d5000['refreshToken']=_0x1ec836),_0xd958b8&&(m(typeof _0xd958b8=='string','internal-error',{'appName':_0x5b7267}),_0x3d5000['accessToken']=_0xd958b8),_0xb0f4bf&&(m(typeof _0xb0f4bf=='number','internal-error',{'appName':_0x5b7267}),_0x3d5000['expirationTime']=_0xb0f4bf),_0x3d5000;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x810d08){this['accessToken']=_0x810d08['accessToken'],this['refreshToken']=_0x810d08['refreshToken'],this['expirationTime']=_0x810d08['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0xcd08b7,_0x10898b){m(typeof _0xcd08b7=='string'||typeof _0xcd08b7>'u','internal-error',{'appName':_0x10898b});}class j{constructor({uid:_0x3e7c4f,auth:_0x19cf93,stsTokenManager:_0x5a1fcb,..._0x5381cd}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x3e7c4f,this['auth']=_0x19cf93,this['stsTokenManager']=_0x5a1fcb,this['accessToken']=_0x5a1fcb['accessToken'],this['displayName']=_0x5381cd['displayName']||null,this['email']=_0x5381cd['email']||null,this['emailVerified']=_0x5381cd['emailVerified']||!0x1,this['phoneNumber']=_0x5381cd['phoneNumber']||null,this['photoURL']=_0x5381cd['photoURL']||null,this['isAnonymous']=_0x5381cd['isAnonymous']||!0x1,this['tenantId']=_0x5381cd['tenantId']||null,this['providerData']=_0x5381cd['providerData']?[..._0x5381cd['providerData']]:[],this['metadata']=new Li(_0x5381cd['createdAt']||void 0x0,_0x5381cd['lastLoginAt']||void 0x0);}async['getIdToken'](_0x444369){const _0x4edaa3=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x444369));return m(_0x4edaa3,this['auth'],'internal-error'),this['accessToken']!==_0x4edaa3&&(this['accessToken']=_0x4edaa3,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x4edaa3;}['getIdTokenResult'](_0x3faab6){return Ef(this,_0x3faab6);}['reload'](){return Cf(this);}['_assign'](_0x41d88b){this!==_0x41d88b&&(m(this['uid']===_0x41d88b['uid'],this['auth'],'internal-error'),this['displayName']=_0x41d88b['displayName'],this['photoURL']=_0x41d88b['photoURL'],this['email']=_0x41d88b['email'],this['emailVerified']=_0x41d88b['emailVerified'],this['phoneNumber']=_0x41d88b['phoneNumber'],this['isAnonymous']=_0x41d88b['isAnonymous'],this['tenantId']=_0x41d88b['tenantId'],this['providerData']=_0x41d88b['providerData']['map'](_0x536ebf=>({..._0x536ebf})),this['metadata']['_copy'](_0x41d88b['metadata']),this['stsTokenManager']['_assign'](_0x41d88b['stsTokenManager']));}['_clone'](_0x32a1ba){const _0x4f894a=new j({...this,'auth':_0x32a1ba,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x4f894a['metadata']['_copy'](this['metadata']),_0x4f894a;}['_onReload'](_0x388db6){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x388db6,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x5ea9a6){this['reloadListener']?this['reloadListener'](_0x5ea9a6):this['reloadUserInfo']=_0x5ea9a6;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x117214,_0x5aefbd=!0x1){let _0x2c2401=!0x1;_0x117214['idToken']&&_0x117214['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x117214),_0x2c2401=!0x0),_0x5aefbd&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x2c2401&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x4021e8=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x4021e8})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x5b302a=>({..._0x5b302a})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x164001,_0x185713){const _0x3437b7=_0x185713['displayName']??void 0x0,_0x5c123a=_0x185713['email']??void 0x0,_0x2c1ec1=_0x185713['phoneNumber']??void 0x0,_0x45289c=_0x185713['photoURL']??void 0x0,_0xc4b2fb=_0x185713['tenantId']??void 0x0,_0x58aa5d=_0x185713['_redirectEventId']??void 0x0,_0xd00b37=_0x185713['createdAt']??void 0x0,_0x2c7923=_0x185713['lastLoginAt']??void 0x0,{uid:_0x30ee98,emailVerified:_0x59f7de,isAnonymous:_0x449110,providerData:_0x3517ff,stsTokenManager:_0x15e2ae}=_0x185713;m(_0x30ee98&&_0x15e2ae,_0x164001,'internal-error');const _0x275de1=et['fromJSON'](this['name'],_0x15e2ae);m(typeof _0x30ee98=='string',_0x164001,'internal-error'),le(_0x3437b7,_0x164001['name']),le(_0x5c123a,_0x164001['name']),m(typeof _0x59f7de=='boolean',_0x164001,'internal-error'),m(typeof _0x449110=='boolean',_0x164001,'internal-error'),le(_0x2c1ec1,_0x164001['name']),le(_0x45289c,_0x164001['name']),le(_0xc4b2fb,_0x164001['name']),le(_0x58aa5d,_0x164001['name']),le(_0xd00b37,_0x164001['name']),le(_0x2c7923,_0x164001['name']);const _0x149441=new j({'uid':_0x30ee98,'auth':_0x164001,'email':_0x5c123a,'emailVerified':_0x59f7de,'displayName':_0x3437b7,'isAnonymous':_0x449110,'photoURL':_0x45289c,'phoneNumber':_0x2c1ec1,'tenantId':_0xc4b2fb,'stsTokenManager':_0x275de1,'createdAt':_0xd00b37,'lastLoginAt':_0x2c7923});return _0x3517ff&&Array['isArray'](_0x3517ff)&&(_0x149441['providerData']=_0x3517ff['map'](_0x470a4c=>({..._0x470a4c}))),_0x58aa5d&&(_0x149441['_redirectEventId']=_0x58aa5d),_0x149441;}static async['_fromIdTokenResponse'](_0x55fbf1,_0x57064a,_0x3d4c78=!0x1){const _0x110add=new et();_0x110add['updateFromServerResponse'](_0x57064a);const _0x84028f=new j({'uid':_0x57064a['localId'],'auth':_0x55fbf1,'stsTokenManager':_0x110add,'isAnonymous':_0x3d4c78});return await Nn(_0x84028f),_0x84028f;}static async['_fromGetAccountInfoResponse'](_0x4e8fd0,_0x57597b,_0x510f96){const _0x3385cf=_0x57597b['users'][0x0];m(_0x3385cf['localId']!==void 0x0,'internal-error');const _0x3a8328=_0x3385cf['providerUserInfo']!==void 0x0?Sa(_0x3385cf['providerUserInfo']):[],_0x567093=!(_0x3385cf['email']&&_0x3385cf['passwordHash'])&&!(_0x3a8328!=null&&_0x3a8328['length']),_0x1579ff=new et();_0x1579ff['updateFromIdToken'](_0x510f96);const _0x569dbe=new j({'uid':_0x3385cf['localId'],'auth':_0x4e8fd0,'stsTokenManager':_0x1579ff,'isAnonymous':_0x567093}),_0x219014={'uid':_0x3385cf['localId'],'displayName':_0x3385cf['displayName']||null,'photoURL':_0x3385cf['photoUrl']||null,'email':_0x3385cf['email']||null,'emailVerified':_0x3385cf['emailVerified']||!0x1,'phoneNumber':_0x3385cf['phoneNumber']||null,'tenantId':_0x3385cf['tenantId']||null,'providerData':_0x3a8328,'metadata':new Li(_0x3385cf['createdAt'],_0x3385cf['lastLoginAt']),'isAnonymous':!(_0x3385cf['email']&&_0x3385cf['passwordHash'])&&!(_0x3a8328!=null&&_0x3a8328['length'])};return Object['assign'](_0x569dbe,_0x219014),_0x569dbe;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0xb620c9){ce(_0xb620c9 instanceof Function,'Expected\x20a\x20class\x20definition');let _0xa27c04=Tr['get'](_0xb620c9);return _0xa27c04?(ce(_0xa27c04 instanceof _0xb620c9,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0xa27c04):(_0xa27c04=new _0xb620c9(),Tr['set'](_0xb620c9,_0xa27c04),_0xa27c04);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x17fe51,_0x192e4c){this['storage'][_0x17fe51]=_0x192e4c;}async['_get'](_0x12623d){const _0x4f5e72=this['storage'][_0x12623d];return _0x4f5e72===void 0x0?null:_0x4f5e72;}async['_remove'](_0x51c8a6){delete this['storage'][_0x51c8a6];}['_addListener'](_0x2c5340,_0x46b3cf){}['_removeListener'](_0x1af52e,_0x5e5f6b){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x218ee9,_0x59c870,_0x115540){return'firebase:'+_0x218ee9+':'+_0x59c870+':'+_0x115540;}class tt{constructor(_0xaaf292,_0x472975,_0x25eb75){this['persistence']=_0xaaf292,this['auth']=_0x472975,this['userKey']=_0x25eb75;const {config:_0x59af6d,name:_0x5c2dac}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x59af6d['apiKey'],_0x5c2dac),this['fullPersistenceKey']=ln('persistence',_0x59af6d['apiKey'],_0x5c2dac),this['boundEventHandler']=_0x472975['_onStorageEvent']['bind'](_0x472975),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x1d116c){return this['persistence']['_set'](this['fullUserKey'],_0x1d116c['toJSON']());}async['getCurrentUser'](){const _0x4c44f3=await this['persistence']['_get'](this['fullUserKey']);if(!_0x4c44f3)return null;if(typeof _0x4c44f3=='string'){const _0x10594d=await Pn(this['auth'],{'idToken':_0x4c44f3})['catch'](()=>{});return _0x10594d?j['_fromGetAccountInfoResponse'](this['auth'],_0x10594d,_0x4c44f3):null;}return j['_fromJSON'](this['auth'],_0x4c44f3);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x1e03b4){if(this['persistence']===_0x1e03b4)return;const _0x2d9884=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x1e03b4,_0x2d9884)return this['setCurrentUser'](_0x2d9884);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x383ab2,_0x5a5258,_0x4279e3='authUser'){if(!_0x5a5258['length'])return new tt(ie(Sr),_0x383ab2,_0x4279e3);const _0x45d0c3=(await Promise['all'](_0x5a5258['map'](async _0x5ca212=>{if(await _0x5ca212['_isAvailable']())return _0x5ca212;})))['filter'](_0x2df0ac=>_0x2df0ac);let _0x487e1a=_0x45d0c3[0x0]||ie(Sr);const _0x4de68b=ln(_0x4279e3,_0x383ab2['config']['apiKey'],_0x383ab2['name']);let _0x80e5bb=null;for(const _0xd8c5a4 of _0x5a5258)try{const _0x5cf430=await _0xd8c5a4['_get'](_0x4de68b);if(_0x5cf430){let _0xb5b284;if(typeof _0x5cf430=='string'){const _0x1df57c=await Pn(_0x383ab2,{'idToken':_0x5cf430})['catch'](()=>{});if(!_0x1df57c)break;_0xb5b284=await j['_fromGetAccountInfoResponse'](_0x383ab2,_0x1df57c,_0x5cf430);}else _0xb5b284=j['_fromJSON'](_0x383ab2,_0x5cf430);_0xd8c5a4!==_0x487e1a&&(_0x80e5bb=_0xb5b284),_0x487e1a=_0xd8c5a4;break;}}catch{}const _0x11f440=_0x45d0c3['filter'](_0x27de48=>_0x27de48['_shouldAllowMigration']);return!_0x487e1a['_shouldAllowMigration']||!_0x11f440['length']?new tt(_0x487e1a,_0x383ab2,_0x4279e3):(_0x487e1a=_0x11f440[0x0],_0x80e5bb&&await _0x487e1a['_set'](_0x4de68b,_0x80e5bb['toJSON']()),await Promise['all'](_0x5a5258['map'](async _0x244d29=>{if(_0x244d29!==_0x487e1a)try{await _0x244d29['_remove'](_0x4de68b);}catch{}})),new tt(_0x487e1a,_0x383ab2,_0x4279e3));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x4b29cb){const _0x549256=_0x4b29cb['toLowerCase']();if(_0x549256['includes']('opera/')||_0x549256['includes']('opr/')||_0x549256['includes']('opios/'))return'Opera';if(Pa(_0x549256))return'IEMobile';if(_0x549256['includes']('msie')||_0x549256['includes']('trident/'))return'IE';if(_0x549256['includes']('edge/'))return'Edge';if(Ra(_0x549256))return'Firefox';if(_0x549256['includes']('silk/'))return'Silk';if(Oa(_0x549256))return'Blackberry';if(Da(_0x549256))return'Webos';if(Aa(_0x549256))return'Safari';if((_0x549256['includes']('chrome/')||ka(_0x549256))&&!_0x549256['includes']('edge/'))return'Chrome';if(Na(_0x549256))return'Android';{const _0xf21042=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x4db7a6=_0x4b29cb['match'](_0xf21042);if((_0x4db7a6==null?void 0x0:_0x4db7a6['length'])===0x2)return _0x4db7a6[0x1];}return'Other';}function Ra(_0x233245=W()){return/firefox\//i['test'](_0x233245);}function Aa(_0x5c2864=W()){const _0x4fc973=_0x5c2864['toLowerCase']();return _0x4fc973['includes']('safari/')&&!_0x4fc973['includes']('chrome/')&&!_0x4fc973['includes']('crios/')&&!_0x4fc973['includes']('android');}function ka(_0x219105=W()){return/crios\//i['test'](_0x219105);}function Pa(_0x3f3b6a=W()){return/iemobile/i['test'](_0x3f3b6a);}function Na(_0x58ab84=W()){return/android/i['test'](_0x58ab84);}function Oa(_0x1726a9=W()){return/blackberry/i['test'](_0x1726a9);}function Da(_0x440574=W()){return/webos/i['test'](_0x440574);}function Ss(_0x28ad69=W()){return/iphone|ipad|ipod/i['test'](_0x28ad69)||/macintosh/i['test'](_0x28ad69)&&/mobile/i['test'](_0x28ad69);}function Rf(_0x2b0a9d=W()){var _0x4e88df;return Ss(_0x2b0a9d)&&!!((_0x4e88df=window['navigator'])!=null&&_0x4e88df['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x4a45be=W()){return Ss(_0x4a45be)||Na(_0x4a45be)||Da(_0x4a45be)||Oa(_0x4a45be)||/windows phone/i['test'](_0x4a45be)||Pa(_0x4a45be);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x4e7a38,_0x52f7f4=[]){let _0x8e7690;switch(_0x4e7a38){case'Browser':_0x8e7690=br(W());break;case'Worker':_0x8e7690=br(W())+'-'+_0x4e7a38;break;default:_0x8e7690=_0x4e7a38;}const _0x17e420=_0x52f7f4['length']?_0x52f7f4['join'](','):'FirebaseCore-web';return _0x8e7690+'/JsCore/'+dt+'/'+_0x17e420;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x5a4380){this['auth']=_0x5a4380,this['queue']=[];}['pushCallback'](_0x482a9f,_0x4bf72a){const _0x3599e3=_0x4b6dfc=>new Promise((_0x3e8808,_0x3cf058)=>{try{const _0x4d863c=_0x482a9f(_0x4b6dfc);_0x3e8808(_0x4d863c);}catch(_0x2c26e6){_0x3cf058(_0x2c26e6);}});_0x3599e3['onAbort']=_0x4bf72a,this['queue']['push'](_0x3599e3);const _0x199719=this['queue']['length']-0x1;return()=>{this['queue'][_0x199719]=()=>Promise['resolve']();};}async['runMiddleware'](_0x8fb134){if(this['auth']['currentUser']===_0x8fb134)return;const _0x328bec=[];try{for(const _0x4a5f80 of this['queue'])await _0x4a5f80(_0x8fb134),_0x4a5f80['onAbort']&&_0x328bec['push'](_0x4a5f80['onAbort']);}catch(_0x49d15f){_0x328bec['reverse']();for(const _0x6ed5c5 of _0x328bec)try{_0x6ed5c5();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x49d15f==null?void 0x0:_0x49d15f['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x1bd02d,_0x598013={}){return Pe(_0x1bd02d,'GET','/v2/passwordPolicy',ke(_0x1bd02d,_0x598013));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x33b0dc){var _0x15d6d4;const _0x257020=_0x33b0dc['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x257020['minPasswordLength']??Nf,_0x257020['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x257020['maxPasswordLength']),_0x257020['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x257020['containsLowercaseCharacter']),_0x257020['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x257020['containsUppercaseCharacter']),_0x257020['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x257020['containsNumericCharacter']),_0x257020['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x257020['containsNonAlphanumericCharacter']),this['enforcementState']=_0x33b0dc['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x15d6d4=_0x33b0dc['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x15d6d4['join'](''))??'',this['forceUpgradeOnSignin']=_0x33b0dc['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x33b0dc['schemaVersion'];}['validatePassword'](_0x9c135a){const _0x446ca6={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x9c135a,_0x446ca6),this['validatePasswordCharacterOptions'](_0x9c135a,_0x446ca6),_0x446ca6['isValid']&&(_0x446ca6['isValid']=_0x446ca6['meetsMinPasswordLength']??!0x0),_0x446ca6['isValid']&&(_0x446ca6['isValid']=_0x446ca6['meetsMaxPasswordLength']??!0x0),_0x446ca6['isValid']&&(_0x446ca6['isValid']=_0x446ca6['containsLowercaseLetter']??!0x0),_0x446ca6['isValid']&&(_0x446ca6['isValid']=_0x446ca6['containsUppercaseLetter']??!0x0),_0x446ca6['isValid']&&(_0x446ca6['isValid']=_0x446ca6['containsNumericCharacter']??!0x0),_0x446ca6['isValid']&&(_0x446ca6['isValid']=_0x446ca6['containsNonAlphanumericCharacter']??!0x0),_0x446ca6;}['validatePasswordLengthOptions'](_0x274cf6,_0x464f4f){const _0x46d1bb=this['customStrengthOptions']['minPasswordLength'],_0x56b535=this['customStrengthOptions']['maxPasswordLength'];_0x46d1bb&&(_0x464f4f['meetsMinPasswordLength']=_0x274cf6['length']>=_0x46d1bb),_0x56b535&&(_0x464f4f['meetsMaxPasswordLength']=_0x274cf6['length']<=_0x56b535);}['validatePasswordCharacterOptions'](_0x1540a7,_0x541dd9){this['updatePasswordCharacterOptionsStatuses'](_0x541dd9,!0x1,!0x1,!0x1,!0x1);let _0x28c4da;for(let _0x207f73=0x0;_0x207f73<_0x1540a7['length'];_0x207f73++)_0x28c4da=_0x1540a7['charAt'](_0x207f73),this['updatePasswordCharacterOptionsStatuses'](_0x541dd9,_0x28c4da>='a'&&_0x28c4da<='z',_0x28c4da>='A'&&_0x28c4da<='Z',_0x28c4da>='0'&&_0x28c4da<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x28c4da));}['updatePasswordCharacterOptionsStatuses'](_0x286ae6,_0x43e6b5,_0x3509c4,_0x55892f,_0x1d57b9){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x286ae6['containsLowercaseLetter']||(_0x286ae6['containsLowercaseLetter']=_0x43e6b5)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x286ae6['containsUppercaseLetter']||(_0x286ae6['containsUppercaseLetter']=_0x3509c4)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x286ae6['containsNumericCharacter']||(_0x286ae6['containsNumericCharacter']=_0x55892f)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x286ae6['containsNonAlphanumericCharacter']||(_0x286ae6['containsNonAlphanumericCharacter']=_0x1d57b9));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0xe43c05,_0x4bf40e,_0x128ac0,_0x39a93b){this['app']=_0xe43c05,this['heartbeatServiceProvider']=_0x4bf40e,this['appCheckServiceProvider']=_0x128ac0,this['config']=_0x39a93b,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0xe43c05['name'],this['clientVersion']=_0x39a93b['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x174d69=>this['_resolvePersistenceManagerAvailable']=_0x174d69);}['_initializeWithPersistence'](_0x3a7334,_0x3965b7){return _0x3965b7&&(this['_popupRedirectResolver']=ie(_0x3965b7)),this['_initializationPromise']=this['queue'](async()=>{var _0x11d628,_0x739b07,_0xe083dc;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x3a7334),(_0x11d628=this['_resolvePersistenceManagerAvailable'])==null||_0x11d628['call'](this),!this['_deleted'])){if((_0x739b07=this['_popupRedirectResolver'])!=null&&_0x739b07['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x3965b7),this['lastNotifiedUid']=((_0xe083dc=this['currentUser'])==null?void 0x0:_0xe083dc['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x2e1b7b=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x2e1b7b)){if(this['currentUser']&&_0x2e1b7b&&this['currentUser']['uid']===_0x2e1b7b['uid']){this['_currentUser']['_assign'](_0x2e1b7b),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x2e1b7b,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x18dfdb){try{const _0x35f355=await Pn(this,{'idToken':_0x18dfdb}),_0x2e5aa2=await j['_fromGetAccountInfoResponse'](this,_0x35f355,_0x18dfdb);await this['directlySetCurrentUser'](_0x2e5aa2);}catch(_0x1ac9a0){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x1ac9a0),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x4685bc){var _0x3c3a1c;if($(this['app'])){const _0x45b3f0=this['app']['settings']['authIdToken'];return _0x45b3f0?new Promise(_0x1b2b13=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x45b3f0)['then'](_0x1b2b13,_0x1b2b13));}):this['directlySetCurrentUser'](null);}const _0x30a4e8=await this['assertedPersistence']['getCurrentUser']();let _0x104181=_0x30a4e8,_0xa4e13b=!0x1;if(_0x4685bc&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x15943e=(_0x3c3a1c=this['redirectUser'])==null?void 0x0:_0x3c3a1c['_redirectEventId'],_0x4fdc1c=_0x104181==null?void 0x0:_0x104181['_redirectEventId'],_0x14142=await this['tryRedirectSignIn'](_0x4685bc);(!_0x15943e||_0x15943e===_0x4fdc1c)&&(_0x14142!=null&&_0x14142['user'])&&(_0x104181=_0x14142['user'],_0xa4e13b=!0x0);}if(!_0x104181)return this['directlySetCurrentUser'](null);if(!_0x104181['_redirectEventId']){if(_0xa4e13b)try{await this['beforeStateQueue']['runMiddleware'](_0x104181);}catch(_0x2568c8){_0x104181=_0x30a4e8,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x2568c8));}return _0x104181?this['reloadAndSetCurrentUserOrClear'](_0x104181):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x104181['_redirectEventId']?this['directlySetCurrentUser'](_0x104181):this['reloadAndSetCurrentUserOrClear'](_0x104181);}async['tryRedirectSignIn'](_0x59a930){let _0xed27d0=null;try{_0xed27d0=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x59a930,!0x0);}catch{await this['_setRedirectUser'](null);}return _0xed27d0;}async['reloadAndSetCurrentUserOrClear'](_0x3b326f){try{await Nn(_0x3b326f);}catch(_0x10af2d){if((_0x10af2d==null?void 0x0:_0x10af2d['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x3b326f);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x477a64){if($(this['app']))return Promise['reject'](re(this));const _0x3a6636=_0x477a64?P(_0x477a64):null;return _0x3a6636&&m(_0x3a6636['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x3a6636&&_0x3a6636['_clone'](this));}async['_updateCurrentUser'](_0x13324c,_0x3d66a2=!0x1){if(!this['_deleted'])return _0x13324c&&m(this['tenantId']===_0x13324c['tenantId'],this,'tenant-id-mismatch'),_0x3d66a2||await this['beforeStateQueue']['runMiddleware'](_0x13324c),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x13324c),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x15a520){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x15a520));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x2ed72d){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x5dd3fd=this['_getPasswordPolicyInternal']();return _0x5dd3fd['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x5dd3fd['validatePassword'](_0x2ed72d);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x13edea=await Pf(this),_0x36bcbf=new Of(_0x13edea);this['tenantId']===null?this['_projectPasswordPolicy']=_0x36bcbf:this['_tenantPasswordPolicies'][this['tenantId']]=_0x36bcbf;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x584a2f){this['_errorFactory']=new Gt('auth','Firebase',_0x584a2f());}['onAuthStateChanged'](_0x51b68f,_0x198717,_0x55da13){return this['registerStateListener'](this['authStateSubscription'],_0x51b68f,_0x198717,_0x55da13);}['beforeAuthStateChanged'](_0xeb74f0,_0x155a55){return this['beforeStateQueue']['pushCallback'](_0xeb74f0,_0x155a55);}['onIdTokenChanged'](_0x218e1c,_0x1d81e5,_0x1693ef){return this['registerStateListener'](this['idTokenSubscription'],_0x218e1c,_0x1d81e5,_0x1693ef);}['authStateReady'](){return new Promise((_0x20969e,_0x2bbfac)=>{if(this['currentUser'])_0x20969e();else{const _0x495298=this['onAuthStateChanged'](()=>{_0x495298(),_0x20969e();},_0x2bbfac);}});}async['revokeAccessToken'](_0x1031d1){if(this['currentUser']){const _0x3eb84c=await this['currentUser']['getIdToken'](),_0x1fabda={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x1031d1,'idToken':_0x3eb84c};this['tenantId']!=null&&(_0x1fabda['tenantId']=this['tenantId']),await bf(this,_0x1fabda);}}['toJSON'](){var _0x48d2ea;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x48d2ea=this['_currentUser'])==null?void 0x0:_0x48d2ea['toJSON']()};}async['_setRedirectUser'](_0x5527e9,_0x40e8d3){const _0x4c4fdd=await this['getOrInitRedirectPersistenceManager'](_0x40e8d3);return _0x5527e9===null?_0x4c4fdd['removeCurrentUser']():_0x4c4fdd['setCurrentUser'](_0x5527e9);}async['getOrInitRedirectPersistenceManager'](_0x21b08b){if(!this['redirectPersistenceManager']){const _0x4c94fb=_0x21b08b&&ie(_0x21b08b)||this['_popupRedirectResolver'];m(_0x4c94fb,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x4c94fb['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x12f924){var _0x3fe577,_0x17f21c;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x3fe577=this['_currentUser'])==null?void 0x0:_0x3fe577['_redirectEventId'])===_0x12f924?this['_currentUser']:((_0x17f21c=this['redirectUser'])==null?void 0x0:_0x17f21c['_redirectEventId'])===_0x12f924?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x3f084a){if(_0x3f084a===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x3f084a));}['_notifyListenersIfCurrent'](_0x44713e){_0x44713e===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x91a6bd;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x3ebd3b=((_0x91a6bd=this['currentUser'])==null?void 0x0:_0x91a6bd['uid'])??null;this['lastNotifiedUid']!==_0x3ebd3b&&(this['lastNotifiedUid']=_0x3ebd3b,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x105031,_0x1ba9df,_0x4d387a,_0x5df312){if(this['_deleted'])return()=>{};const _0x2f34ed=typeof _0x1ba9df=='function'?_0x1ba9df:_0x1ba9df['next']['bind'](_0x1ba9df);let _0x38ae9e=!0x1;const _0x4469d0=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x4469d0,this,'internal-error'),_0x4469d0['then'](()=>{_0x38ae9e||_0x2f34ed(this['currentUser']);}),typeof _0x1ba9df=='function'){const _0x426fa6=_0x105031['addObserver'](_0x1ba9df,_0x4d387a,_0x5df312);return()=>{_0x38ae9e=!0x0,_0x426fa6();};}else{const _0x48f096=_0x105031['addObserver'](_0x1ba9df);return()=>{_0x38ae9e=!0x0,_0x48f096();};}}async['directlySetCurrentUser'](_0x2b514a){this['currentUser']&&this['currentUser']!==_0x2b514a&&this['_currentUser']['_stopProactiveRefresh'](),_0x2b514a&&this['isProactiveRefreshEnabled']&&_0x2b514a['_startProactiveRefresh'](),this['currentUser']=_0x2b514a,_0x2b514a?await this['assertedPersistence']['setCurrentUser'](_0x2b514a):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x1fe97a){return this['operations']=this['operations']['then'](_0x1fe97a,_0x1fe97a),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x13bc22){!_0x13bc22||this['frameworks']['includes'](_0x13bc22)||(this['frameworks']['push'](_0x13bc22),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x3d747b;const _0x1240dc={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x1240dc['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x567f46=await((_0x3d747b=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x3d747b['getHeartbeatsHeader']());_0x567f46&&(_0x1240dc['X-Firebase-Client']=_0x567f46);const _0x2de8d9=await this['_getAppCheckToken']();return _0x2de8d9&&(_0x1240dc['X-Firebase-AppCheck']=_0x2de8d9),_0x1240dc;}async['_getAppCheckToken'](){var _0x6541b9;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x5b8d0d=await((_0x6541b9=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x6541b9['getToken']());return _0x5b8d0d!=null&&_0x5b8d0d['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x5b8d0d['error']),_0x5b8d0d==null?void 0x0:_0x5b8d0d['token'];}}function Ke(_0x209627){return P(_0x209627);}class Rr{constructor(_0x138b49){this['auth']=_0x138b49,this['observer']=null,this['addObserver']=Tc(_0x4a9de4=>this['observer']=_0x4a9de4);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x2bec16){Jn=_0x2bec16;}function xa(_0x338153){return Jn['loadJS'](_0x338153);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x2e97c9){return'__'+_0x2e97c9+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x4ec665){_0x4ec665();}['execute'](_0x2c9aec,_0x25ddf8){return Promise['resolve']('token');}['render'](_0x56442b,_0x1a49cd){return'';}}class Wf{['ready'](_0x4f8dfc){_0x4f8dfc();}['execute'](_0x466c70,_0xb20f89){return Promise['resolve']('token');}['render'](_0x49af32,_0x483cee){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0xe2416f){this['type']=Bf,this['auth']=Ke(_0xe2416f);}async['verify'](_0x4cdb13='verify',_0x4ea1ea=!0x1){async function _0xdc085(_0x823e43){if(!_0x4ea1ea){if(_0x823e43['tenantId']==null&&_0x823e43['_agentRecaptchaConfig']!=null)return _0x823e43['_agentRecaptchaConfig']['siteKey'];if(_0x823e43['tenantId']!=null&&_0x823e43['_tenantRecaptchaConfigs'][_0x823e43['tenantId']]!==void 0x0)return _0x823e43['_tenantRecaptchaConfigs'][_0x823e43['tenantId']]['siteKey'];}return new Promise(async(_0x4c942c,_0x5b35ed)=>{yf(_0x823e43,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x6ddaea=>{if(_0x6ddaea['recaptchaKey']===void 0x0)_0x5b35ed(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x22d0b4=new mf(_0x6ddaea);return _0x823e43['tenantId']==null?_0x823e43['_agentRecaptchaConfig']=_0x22d0b4:_0x823e43['_tenantRecaptchaConfigs'][_0x823e43['tenantId']]=_0x22d0b4,_0x4c942c(_0x22d0b4['siteKey']);}})['catch'](_0x515960=>{_0x5b35ed(_0x515960);});});}function _0x226858(_0x1ef649,_0x26ce19,_0x2607a8){const _0x424dc7=window['grecaptcha'];wr(_0x424dc7)?_0x424dc7['enterprise']['ready'](()=>{_0x424dc7['enterprise']['execute'](_0x1ef649,{'action':_0x4cdb13})['then'](_0x263927=>{_0x26ce19(_0x263927);})['catch'](()=>{_0x26ce19(Fa);});}):_0x2607a8(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x34f516,_0x410ee1)=>{_0xdc085(this['auth'])['then'](async _0x2f33dd=>{if(!_0x4ea1ea&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x226858(_0x2f33dd,_0x34f516,_0x410ee1);else{if(typeof window>'u'){_0x410ee1(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x372032=Lf();_0x372032['length']!==0x0&&(_0x372032+=_0x2f33dd+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0xdc1bcc;(_0xdc1bcc=he['scriptInjectionDeferred'])==null||_0xdc1bcc['resolve']();},xa(_0x372032)['then'](()=>{var _0x2099dc;return(_0x2099dc=he['scriptInjectionDeferred'])==null?void 0x0:_0x2099dc['promise'];})['then'](()=>{_0x226858(_0x2f33dd,_0x34f516,_0x410ee1);})['catch'](_0x5525c8=>{_0x410ee1(_0x5525c8);});}})['catch'](_0x55f9fc=>{_0x410ee1(_0x55f9fc);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x3d494b,_0x5887d9,_0x36e403,_0x2628fb=!0x1,_0x2be434=!0x1){const _0x1995df=new he(_0x3d494b);let _0x20df01;if(_0x2be434)_0x20df01=Fa;else try{_0x20df01=await _0x1995df['verify'](_0x36e403);}catch{_0x20df01=await _0x1995df['verify'](_0x36e403,!0x0);}const _0xa97186={..._0x5887d9};if(_0x36e403==='mfaSmsEnrollment'||_0x36e403==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0xa97186){const _0x2aaf71=_0xa97186['phoneEnrollmentInfo']['phoneNumber'],_0x56c64e=_0xa97186['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0xa97186,{'phoneEnrollmentInfo':{'phoneNumber':_0x2aaf71,'recaptchaToken':_0x56c64e,'captchaResponse':_0x20df01,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0xa97186){const _0x55a9c5=_0xa97186['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0xa97186,{'phoneSignInInfo':{'recaptchaToken':_0x55a9c5,'captchaResponse':_0x20df01,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0xa97186;}return _0x2628fb?Object['assign'](_0xa97186,{'captchaResp':_0x20df01}):Object['assign'](_0xa97186,{'captchaResponse':_0x20df01}),Object['assign'](_0xa97186,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0xa97186,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0xa97186;}async function xi(_0x230a0c,_0x1f88a7,_0xc8de5f,_0x16b480,_0x151b82){var _0x25e6f2;if((_0x25e6f2=_0x230a0c['_getRecaptchaConfig']())!=null&&_0x25e6f2['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x22c3f3=await kr(_0x230a0c,_0x1f88a7,_0xc8de5f,_0xc8de5f==='getOobCode');return _0x16b480(_0x230a0c,_0x22c3f3);}else return _0x16b480(_0x230a0c,_0x1f88a7)['catch'](async _0x424d00=>{if(_0x424d00['code']==='auth/missing-recaptcha-token'){console['log'](_0xc8de5f+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x4bc391=await kr(_0x230a0c,_0x1f88a7,_0xc8de5f,_0xc8de5f==='getOobCode');return _0x16b480(_0x230a0c,_0x4bc391);}else return Promise['reject'](_0x424d00);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x165a2e,_0x42e960){const _0x482afe=Hi(_0x165a2e,'auth');if(_0x482afe['isInitialized']()){const _0x391ccd=_0x482afe['getImmediate'](),_0x520a2d=_0x482afe['getOptions']();if(xe(_0x520a2d,_0x42e960??{}))return _0x391ccd;Y(_0x391ccd,'already-initialized');}return _0x482afe['initialize']({'options':_0x42e960});}function Hf(_0x4ef092,_0x103196){const _0x2d918e=(_0x103196==null?void 0x0:_0x103196['persistence'])||[],_0x20236b=(Array['isArray'](_0x2d918e)?_0x2d918e:[_0x2d918e])['map'](ie);_0x103196!=null&&_0x103196['errorMap']&&_0x4ef092['_updateErrorMap'](_0x103196['errorMap']),_0x4ef092['_initializeWithPersistence'](_0x20236b,_0x103196==null?void 0x0:_0x103196['popupRedirectResolver']);}function $f(_0xbd6266,_0x24690e,_0x4f3beb){const _0x1717e1=Ke(_0xbd6266);m(/^https?:\/\//['test'](_0x24690e),_0x1717e1,'invalid-emulator-scheme');const _0x378695=!0x1,_0x5b8e56=Ua(_0x24690e),{host:_0x16e3a6,port:_0x2f63ab}=Gf(_0x24690e),_0x2a529b=_0x2f63ab===null?'':':'+_0x2f63ab,_0x4b636e={'url':_0x5b8e56+'//'+_0x16e3a6+_0x2a529b+'/'},_0x2a3284=Object['freeze']({'host':_0x16e3a6,'port':_0x2f63ab,'protocol':_0x5b8e56['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x378695})});if(!_0x1717e1['_canInitEmulator']){m(_0x1717e1['config']['emulator']&&_0x1717e1['emulatorConfig'],_0x1717e1,'emulator-config-failed'),m(xe(_0x4b636e,_0x1717e1['config']['emulator'])&&xe(_0x2a3284,_0x1717e1['emulatorConfig']),_0x1717e1,'emulator-config-failed');return;}_0x1717e1['config']['emulator']=_0x4b636e,_0x1717e1['emulatorConfig']=_0x2a3284,_0x1717e1['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x16e3a6)?Qr(_0x5b8e56+'//'+_0x16e3a6+_0x2a529b):qf();}function Ua(_0x719cda){const _0x11191a=_0x719cda['indexOf'](':');return _0x11191a<0x0?'':_0x719cda['substr'](0x0,_0x11191a+0x1);}function Gf(_0x3a12a4){const _0x1f4808=Ua(_0x3a12a4),_0x4cacdc=/(\/\/)?([^?#/]+)/['exec'](_0x3a12a4['substr'](_0x1f4808['length']));if(!_0x4cacdc)return{'host':'','port':null};const _0x151bbc=_0x4cacdc[0x2]['split']('@')['pop']()||'',_0x7931b1=/^(\[[^\]]+\])(:|$)/['exec'](_0x151bbc);if(_0x7931b1){const _0x6bae70=_0x7931b1[0x1];return{'host':_0x6bae70,'port':Pr(_0x151bbc['substr'](_0x6bae70['length']+0x1))};}else{const [_0x67d3a8,_0x22eec3]=_0x151bbc['split'](':');return{'host':_0x67d3a8,'port':Pr(_0x22eec3)};}}function Pr(_0x3440e6){if(!_0x3440e6)return null;const _0x6ead0c=Number(_0x3440e6);return isNaN(_0x6ead0c)?null:_0x6ead0c;}function qf(){function _0x4746c2(){const _0x2d1d71=document['createElement']('p'),_0x45645d=_0x2d1d71['style'];_0x2d1d71['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x45645d['position']='fixed',_0x45645d['width']='100%',_0x45645d['backgroundColor']='#ffffff',_0x45645d['border']='.1em\x20solid\x20#000000',_0x45645d['color']='#b50000',_0x45645d['bottom']='0px',_0x45645d['left']='0px',_0x45645d['margin']='0px',_0x45645d['zIndex']='10000',_0x45645d['textAlign']='center',_0x2d1d71['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x2d1d71);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x4746c2):_0x4746c2());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x520fb9,_0x19ae17){this['providerId']=_0x520fb9,this['signInMethod']=_0x19ae17;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x3d317a){return ne('not\x20implemented');}['_linkToIdToken'](_0x59bf82,_0x2788c2){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x3e88ea){return ne('not\x20implemented');}}async function zf(_0x446529,_0x56cb0b){return Pe(_0x446529,'POST','/v1/accounts:signUp',_0x56cb0b);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x4d5064,_0x33e6d7){return en(_0x4d5064,'POST','/v1/accounts:signInWithPassword',ke(_0x4d5064,_0x33e6d7));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x17300a,_0x56a52a){return en(_0x17300a,'POST','/v1/accounts:signInWithEmailLink',ke(_0x17300a,_0x56a52a));}async function Yf(_0xaebcba,_0x4eb89b){return en(_0xaebcba,'POST','/v1/accounts:signInWithEmailLink',ke(_0xaebcba,_0x4eb89b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0xc59a55,_0x411823,_0x269558,_0x4b316f=null){super('password',_0x269558),this['_email']=_0xc59a55,this['_password']=_0x411823,this['_tenantId']=_0x4b316f;}static['_fromEmailAndPassword'](_0x3966ba,_0x151540){return new $t(_0x3966ba,_0x151540,'password');}static['_fromEmailAndCode'](_0x119d6c,_0x4dff26,_0x562e45=null){return new $t(_0x119d6c,_0x4dff26,'emailLink',_0x562e45);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x8baa1d){const _0x1e0cea=typeof _0x8baa1d=='string'?JSON['parse'](_0x8baa1d):_0x8baa1d;if(_0x1e0cea!=null&&_0x1e0cea['email']&&(_0x1e0cea!=null&&_0x1e0cea['password'])){if(_0x1e0cea['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x1e0cea['email'],_0x1e0cea['password']);if(_0x1e0cea['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x1e0cea['email'],_0x1e0cea['password'],_0x1e0cea['tenantId']);}return null;}async['_getIdTokenResponse'](_0xaa16f0){switch(this['signInMethod']){case'password':const _0x3824a0={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0xaa16f0,_0x3824a0,'signInWithPassword',jf);case'emailLink':return Kf(_0xaa16f0,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0xaa16f0,'internal-error');}}async['_linkToIdToken'](_0x399ae0,_0x313cfd){switch(this['signInMethod']){case'password':const _0x318953={'idToken':_0x313cfd,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x399ae0,_0x318953,'signUpPassword',zf);case'emailLink':return Yf(_0x399ae0,{'idToken':_0x313cfd,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x399ae0,'internal-error');}}['_getReauthenticationResolver'](_0x18f4dc){return this['_getIdTokenResponse'](_0x18f4dc);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x272a4,_0x4839a1){return en(_0x272a4,'POST','/v1/accounts:signInWithIdp',ke(_0x272a4,_0x4839a1));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x285713){const _0x3f1416=new $e(_0x285713['providerId'],_0x285713['signInMethod']);return _0x285713['idToken']||_0x285713['accessToken']?(_0x285713['idToken']&&(_0x3f1416['idToken']=_0x285713['idToken']),_0x285713['accessToken']&&(_0x3f1416['accessToken']=_0x285713['accessToken']),_0x285713['nonce']&&!_0x285713['pendingToken']&&(_0x3f1416['nonce']=_0x285713['nonce']),_0x285713['pendingToken']&&(_0x3f1416['pendingToken']=_0x285713['pendingToken'])):_0x285713['oauthToken']&&_0x285713['oauthTokenSecret']?(_0x3f1416['accessToken']=_0x285713['oauthToken'],_0x3f1416['secret']=_0x285713['oauthTokenSecret']):Y('argument-error'),_0x3f1416;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x55e6e5){const _0xd04ca5=typeof _0x55e6e5=='string'?JSON['parse'](_0x55e6e5):_0x55e6e5,{providerId:_0x42a87e,signInMethod:_0x2a0909,..._0x2b662e}=_0xd04ca5;if(!_0x42a87e||!_0x2a0909)return null;const _0x5b4ed4=new $e(_0x42a87e,_0x2a0909);return _0x5b4ed4['idToken']=_0x2b662e['idToken']||void 0x0,_0x5b4ed4['accessToken']=_0x2b662e['accessToken']||void 0x0,_0x5b4ed4['secret']=_0x2b662e['secret'],_0x5b4ed4['nonce']=_0x2b662e['nonce'],_0x5b4ed4['pendingToken']=_0x2b662e['pendingToken']||null,_0x5b4ed4;}['_getIdTokenResponse'](_0x249ef1){const _0x1fcf8e=this['buildRequest']();return nt(_0x249ef1,_0x1fcf8e);}['_linkToIdToken'](_0x339ffc,_0x42f631){const _0x4a045d=this['buildRequest']();return _0x4a045d['idToken']=_0x42f631,nt(_0x339ffc,_0x4a045d);}['_getReauthenticationResolver'](_0xa9e8c0){const _0x22a901=this['buildRequest']();return _0x22a901['autoCreate']=!0x1,nt(_0xa9e8c0,_0x22a901);}['buildRequest'](){const _0x5d3de5={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x5d3de5['pendingToken']=this['pendingToken'];else{const _0x4fdf66={};this['idToken']&&(_0x4fdf66['id_token']=this['idToken']),this['accessToken']&&(_0x4fdf66['access_token']=this['accessToken']),this['secret']&&(_0x4fdf66['oauth_token_secret']=this['secret']),_0x4fdf66['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x4fdf66['nonce']=this['nonce']),_0x5d3de5['postBody']=ut(_0x4fdf66);}return _0x5d3de5;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x5843d1){switch(_0x5843d1){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0xe1776){const _0x1028da=Ct(Tt(_0xe1776))['link'],_0x5384bd=_0x1028da?Ct(Tt(_0x1028da))['deep_link_id']:null,_0x3b24e8=Ct(Tt(_0xe1776))['deep_link_id'];return(_0x3b24e8?Ct(Tt(_0x3b24e8))['link']:null)||_0x3b24e8||_0x5384bd||_0x1028da||_0xe1776;}class Rs{constructor(_0x165945){const _0x228398=Ct(Tt(_0x165945)),_0x528316=_0x228398['apiKey']??null,_0x2d1aa9=_0x228398['oobCode']??null,_0x4a787c=Jf(_0x228398['mode']??null);m(_0x528316&&_0x2d1aa9&&_0x4a787c,'argument-error'),this['apiKey']=_0x528316,this['operation']=_0x4a787c,this['code']=_0x2d1aa9,this['continueUrl']=_0x228398['continueUrl']??null,this['languageCode']=_0x228398['lang']??null,this['tenantId']=_0x228398['tenantId']??null;}static['parseLink'](_0x4bef1f){const _0x117d6d=Xf(_0x4bef1f);try{return new Rs(_0x117d6d);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x26a64c,_0x42aaa7){return $t['_fromEmailAndPassword'](_0x26a64c,_0x42aaa7);}static['credentialWithLink'](_0x523a80,_0x21ff11){const _0x4c6fb2=Rs['parseLink'](_0x21ff11);return m(_0x4c6fb2,'argument-error'),$t['_fromEmailAndCode'](_0x523a80,_0x4c6fb2['code'],_0x4c6fb2['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x45e021){this['providerId']=_0x45e021,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x312d9b){this['defaultLanguageCode']=_0x312d9b;}['setCustomParameters'](_0x222f95){return this['customParameters']=_0x222f95,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x149388){return this['scopes']['includes'](_0x149388)||this['scopes']['push'](_0x149388),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x4f91eb){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x4f91eb});}static['credentialFromResult'](_0x31019c){return ue['credentialFromTaggedObject'](_0x31019c);}static['credentialFromError'](_0x537d28){return ue['credentialFromTaggedObject'](_0x537d28['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x141557}){if(!_0x141557||!('oauthAccessToken'in _0x141557)||!_0x141557['oauthAccessToken'])return null;try{return ue['credential'](_0x141557['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x374d2e,_0x54a03a){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x374d2e,'accessToken':_0x54a03a});}static['credentialFromResult'](_0xd7b7a1){return de['credentialFromTaggedObject'](_0xd7b7a1);}static['credentialFromError'](_0xc8f785){return de['credentialFromTaggedObject'](_0xc8f785['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x18a8f8}){if(!_0x18a8f8)return null;const {oauthIdToken:_0x1cb493,oauthAccessToken:_0x3d53da}=_0x18a8f8;if(!_0x1cb493&&!_0x3d53da)return null;try{return de['credential'](_0x1cb493,_0x3d53da);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x437ede){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x437ede});}static['credentialFromResult'](_0x39de3e){return fe['credentialFromTaggedObject'](_0x39de3e);}static['credentialFromError'](_0x1f3a32){return fe['credentialFromTaggedObject'](_0x1f3a32['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1e42ac}){if(!_0x1e42ac||!('oauthAccessToken'in _0x1e42ac)||!_0x1e42ac['oauthAccessToken'])return null;try{return fe['credential'](_0x1e42ac['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x22b45c,_0x523542){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x22b45c,'oauthTokenSecret':_0x523542});}static['credentialFromResult'](_0x1d08f0){return pe['credentialFromTaggedObject'](_0x1d08f0);}static['credentialFromError'](_0x2d4dd2){return pe['credentialFromTaggedObject'](_0x2d4dd2['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1b2f66}){if(!_0x1b2f66)return null;const {oauthAccessToken:_0x3a1baf,oauthTokenSecret:_0x5c680e}=_0x1b2f66;if(!_0x3a1baf||!_0x5c680e)return null;try{return pe['credential'](_0x3a1baf,_0x5c680e);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x5f397d,_0x44898e){return en(_0x5f397d,'POST','/v1/accounts:signUp',ke(_0x5f397d,_0x44898e));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x13cd1f){this['user']=_0x13cd1f['user'],this['providerId']=_0x13cd1f['providerId'],this['_tokenResponse']=_0x13cd1f['_tokenResponse'],this['operationType']=_0x13cd1f['operationType'];}static async['_fromIdTokenResponse'](_0x3870db,_0x5d57c3,_0x5aae55,_0x41b77c=!0x1){const _0x5890af=await j['_fromIdTokenResponse'](_0x3870db,_0x5aae55,_0x41b77c),_0x428733=Nr(_0x5aae55);return new Ge({'user':_0x5890af,'providerId':_0x428733,'_tokenResponse':_0x5aae55,'operationType':_0x5d57c3});}static async['_forOperation'](_0x3a5b27,_0x43a9dd,_0x355ef5){await _0x3a5b27['_updateTokensIfNecessary'](_0x355ef5,!0x0);const _0x302849=Nr(_0x355ef5);return new Ge({'user':_0x3a5b27,'providerId':_0x302849,'_tokenResponse':_0x355ef5,'operationType':_0x43a9dd});}}function Nr(_0x199ba9){return _0x199ba9['providerId']?_0x199ba9['providerId']:'phoneNumber'in _0x199ba9?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0xbfebb8,_0x3a145b,_0x373f69,_0x3ee835){super(_0x3a145b['code'],_0x3a145b['message']),this['operationType']=_0x373f69,this['user']=_0x3ee835,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0xbfebb8['name'],'tenantId':_0xbfebb8['tenantId']??void 0x0,'_serverResponse':_0x3a145b['customData']['_serverResponse'],'operationType':_0x373f69};}static['_fromErrorAndOperation'](_0x35a57b,_0x2c21e2,_0x4b6d6b,_0x2d42be){return new On(_0x35a57b,_0x2c21e2,_0x4b6d6b,_0x2d42be);}}function Ba(_0x5073b2,_0x278d8e,_0x3ad66c,_0xb5bd34){return(_0x278d8e==='reauthenticate'?_0x3ad66c['_getReauthenticationResolver'](_0x5073b2):_0x3ad66c['_getIdTokenResponse'](_0x5073b2))['catch'](_0x4e25eb=>{throw _0x4e25eb['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x5073b2,_0x4e25eb,_0x278d8e,_0xb5bd34):_0x4e25eb;});}async function ep(_0x57b3bc,_0x53a207,_0x1f2d81=!0x1){const _0x4a8f65=await Ht(_0x57b3bc,_0x53a207['_linkToIdToken'](_0x57b3bc['auth'],await _0x57b3bc['getIdToken']()),_0x1f2d81);return Ge['_forOperation'](_0x57b3bc,'link',_0x4a8f65);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x45dcca,_0x3c4b97,_0x5bf6c3=!0x1){const {auth:_0x56cfab}=_0x45dcca;if($(_0x56cfab['app']))return Promise['reject'](re(_0x56cfab));const _0x14e8ea='reauthenticate';try{const _0x57c4d6=await Ht(_0x45dcca,Ba(_0x56cfab,_0x14e8ea,_0x3c4b97,_0x45dcca),_0x5bf6c3);m(_0x57c4d6['idToken'],_0x56cfab,'internal-error');const _0x46aa65=Ts(_0x57c4d6['idToken']);m(_0x46aa65,_0x56cfab,'internal-error');const {sub:_0x115684}=_0x46aa65;return m(_0x45dcca['uid']===_0x115684,_0x56cfab,'user-mismatch'),Ge['_forOperation'](_0x45dcca,_0x14e8ea,_0x57c4d6);}catch(_0x100810){throw(_0x100810==null?void 0x0:_0x100810['code'])==='auth/user-not-found'&&Y(_0x56cfab,'user-mismatch'),_0x100810;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x4c96e5,_0x266baa,_0x43acc7=!0x1){if($(_0x4c96e5['app']))return Promise['reject'](re(_0x4c96e5));const _0x5cb866='signIn',_0x16a852=await Ba(_0x4c96e5,_0x5cb866,_0x266baa),_0x152e98=await Ge['_fromIdTokenResponse'](_0x4c96e5,_0x5cb866,_0x16a852);return _0x43acc7||await _0x4c96e5['_updateCurrentUser'](_0x152e98['user']),_0x152e98;}async function np(_0x50c81a,_0x427723){return Va(Ke(_0x50c81a),_0x427723);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x36fb17){const _0x4f259d=Ke(_0x36fb17);_0x4f259d['_getPasswordPolicyInternal']()&&await _0x4f259d['_updatePasswordPolicy']();}async function L_(_0x5a2bdc,_0x22bf7b,_0x2d790c){if($(_0x5a2bdc['app']))return Promise['reject'](re(_0x5a2bdc));const _0x25048f=Ke(_0x5a2bdc),_0x423c90=await xi(_0x25048f,{'returnSecureToken':!0x0,'email':_0x22bf7b,'password':_0x2d790c,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0xf4194d=>{throw _0xf4194d['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x5a2bdc),_0xf4194d;}),_0x50cc7c=await Ge['_fromIdTokenResponse'](_0x25048f,'signIn',_0x423c90);return await _0x25048f['_updateCurrentUser'](_0x50cc7c['user']),_0x50cc7c;}function x_(_0x3001d0,_0x4d9d75,_0x30072a){return $(_0x3001d0['app'])?Promise['reject'](re(_0x3001d0)):np(P(_0x3001d0),yt['credential'](_0x4d9d75,_0x30072a))['catch'](async _0x442652=>{throw _0x442652['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x3001d0),_0x442652;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x7c7389,_0x2a37a9){return P(_0x7c7389)['setPersistence'](_0x2a37a9);}function ip(_0x700f42,_0x6c3114,_0xa9278a,_0x5d1441){return P(_0x700f42)['onIdTokenChanged'](_0x6c3114,_0xa9278a,_0x5d1441);}function sp(_0x40ae3c,_0x1cd6a8,_0x2bc42b){return P(_0x40ae3c)['beforeAuthStateChanged'](_0x1cd6a8,_0x2bc42b);}function U_(_0x5905b6,_0x286c06,_0x3f9dce,_0x20e680){return P(_0x5905b6)['onAuthStateChanged'](_0x286c06,_0x3f9dce,_0x20e680);}function W_(_0x35032b){return P(_0x35032b)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x50a1ba,_0x63fd47){this['storageRetriever']=_0x50a1ba,this['type']=_0x63fd47;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x187af9,_0x37b71b){return this['storage']['setItem'](_0x187af9,JSON['stringify'](_0x37b71b)),Promise['resolve']();}['_get'](_0x2ff677){const _0x4aef73=this['storage']['getItem'](_0x2ff677);return Promise['resolve'](_0x4aef73?JSON['parse'](_0x4aef73):null);}['_remove'](_0x349158){return this['storage']['removeItem'](_0x349158),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x2610cf,_0x233148)=>this['onStorageEvent'](_0x2610cf,_0x233148),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x1c74eb){for(const _0x3ed5ae of Object['keys'](this['listeners'])){const _0x44583c=this['storage']['getItem'](_0x3ed5ae),_0x527f9a=this['localCache'][_0x3ed5ae];_0x44583c!==_0x527f9a&&_0x1c74eb(_0x3ed5ae,_0x527f9a,_0x44583c);}}['onStorageEvent'](_0x48da33,_0x5738c0=!0x1){if(!_0x48da33['key']){this['forAllChangedKeys']((_0x49d8bb,_0x5e9584,_0x2a97f4)=>{this['notifyListeners'](_0x49d8bb,_0x2a97f4);});return;}const _0x47f4c1=_0x48da33['key'];_0x5738c0?this['detachListener']():this['stopPolling']();const _0x2a14bf=()=>{const _0xdbe6c6=this['storage']['getItem'](_0x47f4c1);!_0x5738c0&&this['localCache'][_0x47f4c1]===_0xdbe6c6||this['notifyListeners'](_0x47f4c1,_0xdbe6c6);},_0xc6d10b=this['storage']['getItem'](_0x47f4c1);Af()&&_0xc6d10b!==_0x48da33['newValue']&&_0x48da33['newValue']!==_0x48da33['oldValue']?setTimeout(_0x2a14bf,op):_0x2a14bf();}['notifyListeners'](_0xe0275d,_0x118e3a){this['localCache'][_0xe0275d]=_0x118e3a;const _0x371d86=this['listeners'][_0xe0275d];if(_0x371d86){for(const _0x117133 of Array['from'](_0x371d86))_0x117133(_0x118e3a&&JSON['parse'](_0x118e3a));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x5d45c3,_0x1ea191,_0x2bc0c3)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x5d45c3,'oldValue':_0x1ea191,'newValue':_0x2bc0c3}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0xaf3b0f,_0x54fb61){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0xaf3b0f]||(this['listeners'][_0xaf3b0f]=new Set(),this['localCache'][_0xaf3b0f]=this['storage']['getItem'](_0xaf3b0f)),this['listeners'][_0xaf3b0f]['add'](_0x54fb61);}['_removeListener'](_0xf52d78,_0x5cef3d){this['listeners'][_0xf52d78]&&(this['listeners'][_0xf52d78]['delete'](_0x5cef3d),this['listeners'][_0xf52d78]['size']===0x0&&delete this['listeners'][_0xf52d78]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x5887e8,_0x57ad81){await super['_set'](_0x5887e8,_0x57ad81),this['localCache'][_0x5887e8]=JSON['stringify'](_0x57ad81);}async['_get'](_0x1a78d2){const _0x575cae=await super['_get'](_0x1a78d2);return this['localCache'][_0x1a78d2]=JSON['stringify'](_0x575cae),_0x575cae;}async['_remove'](_0x2bcde1){await super['_remove'](_0x2bcde1),delete this['localCache'][_0x2bcde1];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x656b07,_0x538b2f){}['_removeListener'](_0x928c2,_0xf2553f){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x43f46c){return Promise['all'](_0x43f46c['map'](async _0x16af82=>{try{return{'fulfilled':!0x0,'value':await _0x16af82};}catch(_0x15b2b8){return{'fulfilled':!0x1,'reason':_0x15b2b8};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x4fcc58){this['eventTarget']=_0x4fcc58,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x4e0704){const _0x462029=this['receivers']['find'](_0x2d1b2f=>_0x2d1b2f['isListeningto'](_0x4e0704));if(_0x462029)return _0x462029;const _0x15b24f=new Xn(_0x4e0704);return this['receivers']['push'](_0x15b24f),_0x15b24f;}['isListeningto'](_0x372481){return this['eventTarget']===_0x372481;}async['handleEvent'](_0x38eab8){const _0x4e7010=_0x38eab8,{eventId:_0x549768,eventType:_0x2f9f28,data:_0x17b37f}=_0x4e7010['data'],_0x274629=this['handlersMap'][_0x2f9f28];if(!(_0x274629!=null&&_0x274629['size']))return;_0x4e7010['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x549768,'eventType':_0x2f9f28});const _0xf5a262=Array['from'](_0x274629)['map'](async _0x389989=>_0x389989(_0x4e7010['origin'],_0x17b37f)),_0x216f9c=await cp(_0xf5a262);_0x4e7010['ports'][0x0]['postMessage']({'status':'done','eventId':_0x549768,'eventType':_0x2f9f28,'response':_0x216f9c});}['_subscribe'](_0x27745d,_0x58de30){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x27745d]||(this['handlersMap'][_0x27745d]=new Set()),this['handlersMap'][_0x27745d]['add'](_0x58de30);}['_unsubscribe'](_0x2474e5,_0x4c8ff5){this['handlersMap'][_0x2474e5]&&_0x4c8ff5&&this['handlersMap'][_0x2474e5]['delete'](_0x4c8ff5),(!_0x4c8ff5||this['handlersMap'][_0x2474e5]['size']===0x0)&&delete this['handlersMap'][_0x2474e5],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x3df9d1='',_0x10e2e2=0xa){let _0x440e88='';for(let _0x23867d=0x0;_0x23867d<_0x10e2e2;_0x23867d++)_0x440e88+=Math['floor'](Math['random']()*0xa);return _0x3df9d1+_0x440e88;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x1a2a59){this['target']=_0x1a2a59,this['handlers']=new Set();}['removeMessageHandler'](_0x1f1fd7){_0x1f1fd7['messageChannel']&&(_0x1f1fd7['messageChannel']['port1']['removeEventListener']('message',_0x1f1fd7['onMessage']),_0x1f1fd7['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x1f1fd7);}async['_send'](_0x50c3de,_0x1d4d35,_0x2a82a4=0x32){const _0x4a32e2=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x4a32e2)throw new Error('connection_unavailable');let _0xc168b3,_0x4b9ff6;return new Promise((_0x47d3e7,_0xc06322)=>{const _0x55699c=As('',0x14);_0x4a32e2['port1']['start']();const _0x5c9198=setTimeout(()=>{_0xc06322(new Error('unsupported_event'));},_0x2a82a4);_0x4b9ff6={'messageChannel':_0x4a32e2,'onMessage'(_0x42e06a){const _0x2480fc=_0x42e06a;if(_0x2480fc['data']['eventId']===_0x55699c)switch(_0x2480fc['data']['status']){case'ack':clearTimeout(_0x5c9198),_0xc168b3=setTimeout(()=>{_0xc06322(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0xc168b3),_0x47d3e7(_0x2480fc['data']['response']);break;default:clearTimeout(_0x5c9198),clearTimeout(_0xc168b3),_0xc06322(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x4b9ff6),_0x4a32e2['port1']['addEventListener']('message',_0x4b9ff6['onMessage']),this['target']['postMessage']({'eventType':_0x50c3de,'eventId':_0x55699c,'data':_0x1d4d35},[_0x4a32e2['port2']]);})['finally'](()=>{_0x4b9ff6&&this['removeMessageHandler'](_0x4b9ff6);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x28ca68){Z()['location']['href']=_0x28ca68;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x65bac8;return((_0x65bac8=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x65bac8['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x16c994){this['request']=_0x16c994;}['toPromise'](){return new Promise((_0x2fd5db,_0x42541c)=>{this['request']['addEventListener']('success',()=>{_0x2fd5db(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x42541c(this['request']['error']);});});}}function Zn(_0x31034c,_0x54b41c){return _0x31034c['transaction']([Mn],_0x54b41c?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x1f26fd=indexedDB['deleteDatabase'](Ka);return new nn(_0x1f26fd)['toPromise']();}function Qa(){const _0x599b07=indexedDB['open'](Ka,pp);return new Promise((_0x5e5f8d,_0x9cb95d)=>{_0x599b07['addEventListener']('error',()=>{_0x9cb95d(_0x599b07['error']);}),_0x599b07['addEventListener']('upgradeneeded',()=>{const _0x54c1b0=_0x599b07['result'];try{_0x54c1b0['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x1d02b4){_0x9cb95d(_0x1d02b4);}}),_0x599b07['addEventListener']('success',async()=>{const _0x517dcf=_0x599b07['result'];_0x517dcf['objectStoreNames']['contains'](Mn)?_0x5e5f8d(_0x517dcf):(_0x517dcf['close'](),await _p(),_0x5e5f8d(await Qa()));});});}async function Or(_0x4914e2,_0x3df7f3,_0x2bcd35){const _0x35d23e=Zn(_0x4914e2,!0x0)['put']({[Ya]:_0x3df7f3,'value':_0x2bcd35});return new nn(_0x35d23e)['toPromise']();}async function gp(_0x5a2e0c,_0x5e1037){const _0x15f8c6=Zn(_0x5a2e0c,!0x1)['get'](_0x5e1037),_0x5631ce=await new nn(_0x15f8c6)['toPromise']();return _0x5631ce===void 0x0?null:_0x5631ce['value'];}function Dr(_0xf1c871,_0x50ad64){const _0x41b47f=Zn(_0xf1c871,!0x0)['delete'](_0x50ad64);return new nn(_0x41b47f)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x5a90e9){let _0x22d8ba=0x0;for(;;)try{const _0x293c3e=await this['_openDb']();return await _0x5a90e9(_0x293c3e);}catch(_0x56c77d){if(_0x22d8ba++>yp)throw _0x56c77d;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x141e2e,_0x5482d4)=>({'keyProcessed':(await this['_poll']())['includes'](_0x5482d4['key'])})),this['receiver']['_subscribe']('ping',async(_0x1a5417,_0x1a4746)=>['keyChanged']);}async['initializeSender'](){var _0x373dfb,_0x377b22;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x4c1802=await this['sender']['_send']('ping',{},0x320);_0x4c1802&&(_0x373dfb=_0x4c1802[0x0])!=null&&_0x373dfb['fulfilled']&&(_0x377b22=_0x4c1802[0x0])!=null&&_0x377b22['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x114f6c){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x114f6c},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x4fd27e=>{await Or(_0x4fd27e,Dn,'1'),await Dr(_0x4fd27e,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x18c004){this['pendingWrites']++;try{await _0x18c004();}finally{this['pendingWrites']--;}}async['_set'](_0x2b274a,_0x42f3fd){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x10d99a=>Or(_0x10d99a,_0x2b274a,_0x42f3fd)),this['localCache'][_0x2b274a]=_0x42f3fd,this['notifyServiceWorker'](_0x2b274a)));}async['_get'](_0x35d0f9){const _0x3f393c=await this['_withRetries'](_0x34900f=>gp(_0x34900f,_0x35d0f9));return this['localCache'][_0x35d0f9]=_0x3f393c,_0x3f393c;}async['_remove'](_0x111dec){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x42c3f3=>Dr(_0x42c3f3,_0x111dec)),delete this['localCache'][_0x111dec],this['notifyServiceWorker'](_0x111dec)));}async['_poll'](){const _0x322170=await this['_withRetries'](_0x3b40b1=>{const _0x1b27cb=Zn(_0x3b40b1,!0x1)['getAll']();return new nn(_0x1b27cb)['toPromise']();});if(!_0x322170)return[];if(this['pendingWrites']!==0x0)return[];const _0x5e78f8=[],_0x451e18=new Set();if(_0x322170['length']!==0x0){for(const {fbase_key:_0x3a5a4e,value:_0x3d49a1}of _0x322170)_0x451e18['add'](_0x3a5a4e),JSON['stringify'](this['localCache'][_0x3a5a4e])!==JSON['stringify'](_0x3d49a1)&&(this['notifyListeners'](_0x3a5a4e,_0x3d49a1),_0x5e78f8['push'](_0x3a5a4e));}for(const _0x275596 of Object['keys'](this['localCache']))this['localCache'][_0x275596]&&!_0x451e18['has'](_0x275596)&&(this['notifyListeners'](_0x275596,null),_0x5e78f8['push'](_0x275596));return _0x5e78f8;}['notifyListeners'](_0x12907d,_0x1b4479){this['localCache'][_0x12907d]=_0x1b4479;const _0x21d16b=this['listeners'][_0x12907d];if(_0x21d16b){for(const _0x3cec24 of Array['from'](_0x21d16b))_0x3cec24(_0x1b4479);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x3305dc,_0x17b053){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x3305dc]||(this['listeners'][_0x3305dc]=new Set(),this['_get'](_0x3305dc)),this['listeners'][_0x3305dc]['add'](_0x17b053);}['_removeListener'](_0x137290,_0x18be45){this['listeners'][_0x137290]&&(this['listeners'][_0x137290]['delete'](_0x18be45),this['listeners'][_0x137290]['size']===0x0&&delete this['listeners'][_0x137290]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x288256,_0x41b4f9){return _0x41b4f9?ie(_0x41b4f9):(m(_0x288256['_popupRedirectResolver'],_0x288256,'argument-error'),_0x288256['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x2db623){super('custom','custom'),this['params']=_0x2db623;}['_getIdTokenResponse'](_0x103fcf){return nt(_0x103fcf,this['_buildIdpRequest']());}['_linkToIdToken'](_0x2b0315,_0x3d7836){return nt(_0x2b0315,this['_buildIdpRequest'](_0x3d7836));}['_getReauthenticationResolver'](_0x18c608){return nt(_0x18c608,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x346220){const _0x26f5d0={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x346220&&(_0x26f5d0['idToken']=_0x346220),_0x26f5d0;}}function Ip(_0xc3a454){return Va(_0xc3a454['auth'],new ks(_0xc3a454),_0xc3a454['bypassAuthState']);}function wp(_0x1b14cf){const {auth:_0x52bee7,user:_0xb4eeb0}=_0x1b14cf;return m(_0xb4eeb0,_0x52bee7,'internal-error'),tp(_0xb4eeb0,new ks(_0x1b14cf),_0x1b14cf['bypassAuthState']);}async function Cp(_0x24d684){const {auth:_0x2ed3db,user:_0x270127}=_0x24d684;return m(_0x270127,_0x2ed3db,'internal-error'),ep(_0x270127,new ks(_0x24d684),_0x24d684['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x225a0d,_0x4d6489,_0x1f9ef3,_0x43b20f,_0xb6c490=!0x1){this['auth']=_0x225a0d,this['resolver']=_0x1f9ef3,this['user']=_0x43b20f,this['bypassAuthState']=_0xb6c490,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x4d6489)?_0x4d6489:[_0x4d6489];}['execute'](){return new Promise(async(_0x13c4a2,_0x27830e)=>{this['pendingPromise']={'resolve':_0x13c4a2,'reject':_0x27830e};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0xcc7b32){this['reject'](_0xcc7b32);}});}async['onAuthEvent'](_0x5b4dc4){const {urlResponse:_0x348824,sessionId:_0x1fcaec,postBody:_0x323e08,tenantId:_0x241fd6,error:_0x2d106b,type:_0xb8f80b}=_0x5b4dc4;if(_0x2d106b){this['reject'](_0x2d106b);return;}const _0x103f20={'auth':this['auth'],'requestUri':_0x348824,'sessionId':_0x1fcaec,'tenantId':_0x241fd6||void 0x0,'postBody':_0x323e08||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0xb8f80b)(_0x103f20));}catch(_0x305393){this['reject'](_0x305393);}}['onError'](_0x58458e){this['reject'](_0x58458e);}['getIdpTask'](_0x573345){switch(_0x573345){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x19ade9){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x19ade9),this['unregisterAndCleanUp']();}['reject'](_0x110ec4){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x110ec4),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x5c5859,_0x496dab,_0x254110,_0x461476,_0x431e7f){super(_0x5c5859,_0x496dab,_0x461476,_0x431e7f),this['provider']=_0x254110,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x4ed051=await this['execute']();return m(_0x4ed051,this['auth'],'internal-error'),_0x4ed051;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x2c5c5b=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x2c5c5b),this['authWindow']['associatedEvent']=_0x2c5c5b,this['resolver']['_originValidation'](this['auth'])['catch'](_0x1b98ec=>{this['reject'](_0x1b98ec);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x483e3f=>{_0x483e3f||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x5e9831;return((_0x5e9831=this['authWindow'])==null?void 0x0:_0x5e9831['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x143468=()=>{var _0x33bc47,_0xd274d4;if((_0xd274d4=(_0x33bc47=this['authWindow'])==null?void 0x0:_0x33bc47['window'])!=null&&_0xd274d4['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x143468,Tp['get']());};_0x143468();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x8663d5,_0x5dde22,_0x4305f2=!0x1){super(_0x8663d5,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x5dde22,void 0x0,_0x4305f2),this['eventId']=null;}async['execute'](){let _0x38a277=hn['get'](this['auth']['_key']());if(!_0x38a277){try{const _0x5d0a24=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x38a277=()=>Promise['resolve'](_0x5d0a24);}catch(_0x550567){_0x38a277=()=>Promise['reject'](_0x550567);}hn['set'](this['auth']['_key'](),_0x38a277);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x38a277();}async['onAuthEvent'](_0x538eff){if(_0x538eff['type']==='signInViaRedirect')return super['onAuthEvent'](_0x538eff);if(_0x538eff['type']==='unknown'){this['resolve'](null);return;}if(_0x538eff['eventId']){const _0x2602a9=await this['auth']['_redirectUserForId'](_0x538eff['eventId']);if(_0x2602a9)return this['user']=_0x2602a9,super['onAuthEvent'](_0x538eff);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x2c77c0,_0x1f5291){const _0x53355f=Pp(_0x1f5291),_0x537d14=kp(_0x2c77c0);if(!await _0x537d14['_isAvailable']())return!0x1;const _0x5a84db=await _0x537d14['_get'](_0x53355f)==='true';return await _0x537d14['_remove'](_0x53355f),_0x5a84db;}function Ap(_0x52058a,_0x47af7f){hn['set'](_0x52058a['_key'](),_0x47af7f);}function kp(_0x4c77f4){return ie(_0x4c77f4['_redirectPersistence']);}function Pp(_0x1274f1){return ln(Sp,_0x1274f1['config']['apiKey'],_0x1274f1['name']);}async function Np(_0x5631b7,_0xbc431f,_0x35f345=!0x1){if($(_0x5631b7['app']))return Promise['reject'](re(_0x5631b7));const _0x523222=Ke(_0x5631b7),_0x5b36e8=Ep(_0x523222,_0xbc431f),_0x340197=await new bp(_0x523222,_0x5b36e8,_0x35f345)['execute']();return _0x340197&&!_0x35f345&&(delete _0x340197['user']['_redirectEventId'],await _0x523222['_persistUserIfCurrent'](_0x340197['user']),await _0x523222['_setRedirectUser'](null,_0xbc431f)),_0x340197;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x455a5b){this['auth']=_0x455a5b,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x146f55){this['consumers']['add'](_0x146f55),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x146f55)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x146f55),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x2eed82){this['consumers']['delete'](_0x2eed82);}['onEvent'](_0x39b13e){if(this['hasEventBeenHandled'](_0x39b13e))return!0x1;let _0x5d9d5d=!0x1;return this['consumers']['forEach'](_0x20e6f8=>{this['isEventForConsumer'](_0x39b13e,_0x20e6f8)&&(_0x5d9d5d=!0x0,this['sendToConsumer'](_0x39b13e,_0x20e6f8),this['saveEventToCache'](_0x39b13e));}),this['hasHandledPotentialRedirect']||!Mp(_0x39b13e)||(this['hasHandledPotentialRedirect']=!0x0,_0x5d9d5d||(this['queuedRedirectEvent']=_0x39b13e,_0x5d9d5d=!0x0)),_0x5d9d5d;}['sendToConsumer'](_0x2c628b,_0x27c251){var _0x25e3be;if(_0x2c628b['error']&&!Za(_0x2c628b)){const _0x447d7e=((_0x25e3be=_0x2c628b['error']['code'])==null?void 0x0:_0x25e3be['split']('auth/')[0x1])||'internal-error';_0x27c251['onError'](X(this['auth'],_0x447d7e));}else _0x27c251['onAuthEvent'](_0x2c628b);}['isEventForConsumer'](_0x4081cb,_0x5c10f9){const _0x457e83=_0x5c10f9['eventId']===null||!!_0x4081cb['eventId']&&_0x4081cb['eventId']===_0x5c10f9['eventId'];return _0x5c10f9['filter']['includes'](_0x4081cb['type'])&&_0x457e83;}['hasEventBeenHandled'](_0x354d95){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x354d95));}['saveEventToCache'](_0x594c97){this['cachedEventUids']['add'](Mr(_0x594c97)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0xe76a3){return[_0xe76a3['type'],_0xe76a3['eventId'],_0xe76a3['sessionId'],_0xe76a3['tenantId']]['filter'](_0x1352a7=>_0x1352a7)['join']('-');}function Za({type:_0x14d0c4,error:_0x129423}){return _0x14d0c4==='unknown'&&(_0x129423==null?void 0x0:_0x129423['code'])==='auth/no-auth-event';}function Mp(_0x44105e){switch(_0x44105e['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x44105e);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x38e97e,_0xc01d8c={}){return Pe(_0x38e97e,'GET','/v1/projects',_0xc01d8c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x429d7a){if(_0x429d7a['config']['emulator'])return;const {authorizedDomains:_0x5b82d7}=await Lp(_0x429d7a);for(const _0x502d57 of _0x5b82d7)try{if(Wp(_0x502d57))return;}catch{}Y(_0x429d7a,'unauthorized-domain');}function Wp(_0x1348d0){const _0x5938f5=Mi(),{protocol:_0x1929b7,hostname:_0x3cbd9a}=new URL(_0x5938f5);if(_0x1348d0['startsWith']('chrome-extension://')){const _0x480e36=new URL(_0x1348d0);return _0x480e36['hostname']===''&&_0x3cbd9a===''?_0x1929b7==='chrome-extension:'&&_0x1348d0['replace']('chrome-extension://','')===_0x5938f5['replace']('chrome-extension://',''):_0x1929b7==='chrome-extension:'&&_0x480e36['hostname']===_0x3cbd9a;}if(!Fp['test'](_0x1929b7))return!0x1;if(xp['test'](_0x1348d0))return _0x3cbd9a===_0x1348d0;const _0x23ede5=_0x1348d0['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x23ede5+'|'+_0x23ede5+')$','i')['test'](_0x3cbd9a);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x4acb5e=Z()['___jsl'];if(_0x4acb5e!=null&&_0x4acb5e['H']){for(const _0x4e3830 of Object['keys'](_0x4acb5e['H']))if(_0x4acb5e['H'][_0x4e3830]['r']=_0x4acb5e['H'][_0x4e3830]['r']||[],_0x4acb5e['H'][_0x4e3830]['L']=_0x4acb5e['H'][_0x4e3830]['L']||[],_0x4acb5e['H'][_0x4e3830]['r']=[..._0x4acb5e['H'][_0x4e3830]['L']],_0x4acb5e['CP']){for(let _0x128a8e=0x0;_0x128a8e<_0x4acb5e['CP']['length'];_0x128a8e++)_0x4acb5e['CP'][_0x128a8e]=null;}}}function Vp(_0x44d73b){return new Promise((_0x38d385,_0x4b1701)=>{var _0x2eefdd,_0x2c2662,_0x4a3747;function _0x13d230(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x38d385(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x4b1701(X(_0x44d73b,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x2c2662=(_0x2eefdd=Z()['gapi'])==null?void 0x0:_0x2eefdd['iframes'])!=null&&_0x2c2662['Iframe'])_0x38d385(gapi['iframes']['getContext']());else{if((_0x4a3747=Z()['gapi'])!=null&&_0x4a3747['load'])_0x13d230();else{const _0x7cf4b1=Ff('iframefcb');return Z()[_0x7cf4b1]=()=>{gapi['load']?_0x13d230():_0x4b1701(X(_0x44d73b,'network-request-failed'));},xa(xf()+'?onload='+_0x7cf4b1)['catch'](_0x9bc707=>_0x4b1701(_0x9bc707));}}})['catch'](_0x53d502=>{throw un=null,_0x53d502;});}let un=null;function Hp(_0x42353f){return un=un||Vp(_0x42353f),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x4d5735){const _0x509901=_0x4d5735['config'];m(_0x509901['authDomain'],_0x4d5735,'auth-domain-config-required');const _0x628350=_0x509901['emulator']?Cs(_0x509901,qp):'https://'+_0x4d5735['config']['authDomain']+'/'+Gp,_0x27a7fc={'apiKey':_0x509901['apiKey'],'appName':_0x4d5735['name'],'v':dt},_0x37fc67=jp['get'](_0x4d5735['config']['apiHost']);_0x37fc67&&(_0x27a7fc['eid']=_0x37fc67);const _0x1f1515=_0x4d5735['_getFrameworks']();return _0x1f1515['length']&&(_0x27a7fc['fw']=_0x1f1515['join'](',')),_0x628350+'?'+ut(_0x27a7fc)['slice'](0x1);}async function Yp(_0x4fc259){const _0x4e91b0=await Hp(_0x4fc259),_0x3723a8=Z()['gapi'];return m(_0x3723a8,_0x4fc259,'internal-error'),_0x4e91b0['open']({'where':document['body'],'url':Kp(_0x4fc259),'messageHandlersFilter':_0x3723a8['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x19e8af=>new Promise(async(_0x3a30dd,_0x93a1b3)=>{await _0x19e8af['restyle']({'setHideOnLeave':!0x1});const _0x480e1f=X(_0x4fc259,'network-request-failed'),_0x16df40=Z()['setTimeout'](()=>{_0x93a1b3(_0x480e1f);},$p['get']());function _0x1a3834(){Z()['clearTimeout'](_0x16df40),_0x3a30dd(_0x19e8af);}_0x19e8af['ping'](_0x1a3834)['then'](_0x1a3834,()=>{_0x93a1b3(_0x480e1f);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x36aec0){this['window']=_0x36aec0,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x631dce,_0x44858d,_0x279345,_0x12630b=Jp,_0x421a52=Xp){const _0x2f85b0=Math['max']((window['screen']['availHeight']-_0x421a52)/0x2,0x0)['toString'](),_0x1bf5fb=Math['max']((window['screen']['availWidth']-_0x12630b)/0x2,0x0)['toString']();let _0x28ff74='';const _0xc38fe4={...Qp,'width':_0x12630b['toString'](),'height':_0x421a52['toString'](),'top':_0x2f85b0,'left':_0x1bf5fb},_0x21c15c=W()['toLowerCase']();_0x279345&&(_0x28ff74=ka(_0x21c15c)?Zp:_0x279345),Ra(_0x21c15c)&&(_0x44858d=_0x44858d||e_,_0xc38fe4['scrollbars']='yes');const _0xcbda7d=Object['entries'](_0xc38fe4)['reduce']((_0x499d86,[_0x5dbb6e,_0x2dbc8f])=>''+_0x499d86+_0x5dbb6e+'='+_0x2dbc8f+',','');if(Rf(_0x21c15c)&&_0x28ff74!=='_self')return n_(_0x44858d||'',_0x28ff74),new xr(null);const _0x1e6ed0=window['open'](_0x44858d||'',_0x28ff74,_0xcbda7d);m(_0x1e6ed0,_0x631dce,'popup-blocked');try{_0x1e6ed0['focus']();}catch{}return new xr(_0x1e6ed0);}function n_(_0x30ee84,_0x314669){const _0x1600d3=document['createElement']('a');_0x1600d3['href']=_0x30ee84,_0x1600d3['target']=_0x314669;const _0xabc34=document['createEvent']('MouseEvent');_0xabc34['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x1600d3['dispatchEvent'](_0xabc34);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x2a9538,_0x5d95a6,_0x322693,_0x742673,_0x2340d1,_0x13fa74){m(_0x2a9538['config']['authDomain'],_0x2a9538,'auth-domain-config-required'),m(_0x2a9538['config']['apiKey'],_0x2a9538,'invalid-api-key');const _0x192ed5={'apiKey':_0x2a9538['config']['apiKey'],'appName':_0x2a9538['name'],'authType':_0x322693,'redirectUrl':_0x742673,'v':dt,'eventId':_0x2340d1};if(_0x5d95a6 instanceof Wa){_0x5d95a6['setDefaultLanguage'](_0x2a9538['languageCode']),_0x192ed5['providerId']=_0x5d95a6['providerId']||'',pn(_0x5d95a6['getCustomParameters']())||(_0x192ed5['customParameters']=JSON['stringify'](_0x5d95a6['getCustomParameters']()));for(const [_0x2fc7ee,_0x3417b1]of Object['entries']({}))_0x192ed5[_0x2fc7ee]=_0x3417b1;}if(_0x5d95a6 instanceof tn){const _0xb33133=_0x5d95a6['getScopes']()['filter'](_0x197078=>_0x197078!=='');_0xb33133['length']>0x0&&(_0x192ed5['scopes']=_0xb33133['join'](','));}_0x2a9538['tenantId']&&(_0x192ed5['tid']=_0x2a9538['tenantId']);const _0x25de30=_0x192ed5;for(const _0x550fef of Object['keys'](_0x25de30))_0x25de30[_0x550fef]===void 0x0&&delete _0x25de30[_0x550fef];const _0x16cf5a=await _0x2a9538['_getAppCheckToken'](),_0x5117b4=_0x16cf5a?'#'+r_+'='+encodeURIComponent(_0x16cf5a):'';return o_(_0x2a9538)+'?'+ut(_0x25de30)['slice'](0x1)+_0x5117b4;}function o_({config:_0xa5850a}){return _0xa5850a['emulator']?Cs(_0xa5850a,s_):'https://'+_0xa5850a['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x54ef5c,_0xbae5af,_0x26ca63,_0x3367ed){var _0x5263c1;ce((_0x5263c1=this['eventManagers'][_0x54ef5c['_key']()])==null?void 0x0:_0x5263c1['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x365ca9=await Fr(_0x54ef5c,_0xbae5af,_0x26ca63,Mi(),_0x3367ed);return t_(_0x54ef5c,_0x365ca9,As());}async['_openRedirect'](_0x229c57,_0x383486,_0x1cdc23,_0x194071){await this['_originValidation'](_0x229c57);const _0x2fa9ab=await Fr(_0x229c57,_0x383486,_0x1cdc23,Mi(),_0x194071);return hp(_0x2fa9ab),new Promise(()=>{});}['_initialize'](_0x38ca4a){const _0x42bbd7=_0x38ca4a['_key']();if(this['eventManagers'][_0x42bbd7]){const {manager:_0x444136,promise:_0x1b7f6c}=this['eventManagers'][_0x42bbd7];return _0x444136?Promise['resolve'](_0x444136):(ce(_0x1b7f6c,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x1b7f6c);}const _0x4f5fd6=this['initAndGetManager'](_0x38ca4a);return this['eventManagers'][_0x42bbd7]={'promise':_0x4f5fd6},_0x4f5fd6['catch'](()=>{delete this['eventManagers'][_0x42bbd7];}),_0x4f5fd6;}async['initAndGetManager'](_0x5a1281){const _0x4fc46e=await Yp(_0x5a1281),_0x597991=new Dp(_0x5a1281);return _0x4fc46e['register']('authEvent',_0x403fb2=>(m(_0x403fb2==null?void 0x0:_0x403fb2['authEvent'],_0x5a1281,'invalid-auth-event'),{'status':_0x597991['onEvent'](_0x403fb2['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x5a1281['_key']()]={'manager':_0x597991},this['iframes'][_0x5a1281['_key']()]=_0x4fc46e,_0x597991;}['_isIframeWebStorageSupported'](_0x19a23b,_0x4954c0){this['iframes'][_0x19a23b['_key']()]['send'](pi,{'type':pi},_0x50605c=>{var _0x537cba;const _0x24b5b6=(_0x537cba=_0x50605c==null?void 0x0:_0x50605c[0x0])==null?void 0x0:_0x537cba[pi];_0x24b5b6!==void 0x0&&_0x4954c0(!!_0x24b5b6),Y(_0x19a23b,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x3caac0){const _0x3f6af0=_0x3caac0['_key']();return this['originValidationPromises'][_0x3f6af0]||(this['originValidationPromises'][_0x3f6af0]=Up(_0x3caac0)),this['originValidationPromises'][_0x3f6af0];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x4b6c2c){this['auth']=_0x4b6c2c,this['internalListeners']=new Map();}['getUid'](){var _0x17dcf6;return this['assertAuthConfigured'](),((_0x17dcf6=this['auth']['currentUser'])==null?void 0x0:_0x17dcf6['uid'])||null;}async['getToken'](_0x354fa5){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x354fa5)}:null;}['addAuthTokenListener'](_0x466565){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x466565))return;const _0x5bbc0b=this['auth']['onIdTokenChanged'](_0x3fef0d=>{_0x466565((_0x3fef0d==null?void 0x0:_0x3fef0d['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x466565,_0x5bbc0b),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x1c1fff){this['assertAuthConfigured']();const _0x213246=this['internalListeners']['get'](_0x1c1fff);_0x213246&&(this['internalListeners']['delete'](_0x1c1fff),_0x213246(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x4cb6dc){switch(_0x4cb6dc){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x4f5863){st(new Fe('auth',(_0xc2aed,{options:_0x2a82be})=>{const _0xc7e679=_0xc2aed['getProvider']('app')['getImmediate'](),_0x5e3db1=_0xc2aed['getProvider']('heartbeat'),_0x96c760=_0xc2aed['getProvider']('app-check-internal'),{apiKey:_0x221e14,authDomain:_0x3b2572}=_0xc7e679['options'];m(_0x221e14&&!_0x221e14['includes'](':'),'invalid-api-key',{'appName':_0xc7e679['name']});const _0x5132d6={'apiKey':_0x221e14,'authDomain':_0x3b2572,'clientPlatform':_0x4f5863,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x4f5863)},_0x23d29a=new Df(_0xc7e679,_0x5e3db1,_0x96c760,_0x5132d6);return Hf(_0x23d29a,_0x2a82be),_0x23d29a;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x502bd9,_0x2973b4,_0x96b048)=>{_0x502bd9['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x414371=>{const _0xc698d2=Ke(_0x414371['getProvider']('auth')['getImmediate']());return(_0x417438=>new l_(_0x417438))(_0xc698d2);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x4f5863)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x505f77=>async _0x5405f9=>{const _0x2564ee=_0x5405f9&&await _0x5405f9['getIdTokenResult'](),_0xbe41bf=_0x2564ee&&(new Date()['getTime']()-Date['parse'](_0x2564ee['issuedAtTime']))/0x3e8;if(_0xbe41bf&&_0xbe41bf>f_)return;const _0x37dc7b=_0x2564ee==null?void 0x0:_0x2564ee['token'];Br!==_0x37dc7b&&(Br=_0x37dc7b,await fetch(_0x505f77,{'method':_0x37dc7b?'POST':'DELETE','headers':_0x37dc7b?{'Authorization':'Bearer\x20'+_0x37dc7b}:{}}));};function B_(_0x36f5cf=Zr()){const _0x1e54e9=Hi(_0x36f5cf,'auth');if(_0x1e54e9['isInitialized']())return _0x1e54e9['getImmediate']();const _0x466ab5=Vf(_0x36f5cf,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x111feb=jr('authTokenSyncURL');if(_0x111feb&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x259223=new URL(_0x111feb,location['origin']);if(location['origin']===_0x259223['origin']){const _0x57789e=p_(_0x259223['toString']());sp(_0x466ab5,_0x57789e,()=>_0x57789e(_0x466ab5['currentUser'])),ip(_0x466ab5,_0x34bd13=>_0x57789e(_0x34bd13));}}const _0x4f7ff7=qr('auth');return _0x4f7ff7&&$f(_0x466ab5,'http://'+_0x4f7ff7),_0x466ab5;}function __(){var _0xb7d78a;return((_0xb7d78a=document['getElementsByTagName']('head'))==null?void 0x0:_0xb7d78a[0x0])??document;}Mf({'loadJS'(_0xeb7b94){return new Promise((_0x50f7e6,_0x16c702)=>{const _0x2bdea=document['createElement']('script');_0x2bdea['setAttribute']('src',_0xeb7b94),_0x2bdea['onload']=_0x50f7e6,_0x2bdea['onerror']=_0x21f3d0=>{const _0x22d2bb=X('internal-error');_0x22d2bb['customData']=_0x21f3d0,_0x16c702(_0x22d2bb);},_0x2bdea['type']='text/javascript',_0x2bdea['charset']='UTF-8',__()['appendChild'](_0x2bdea);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,B_ as a,ap as b,x_ as c,g_ as d,m_ as e,Zr as f,P_ as g,Hd as h,Sl as i,D_ as j,Gd as k,w_ as l,b_ as m,A_ as n,v_ as o,E_ as p,k_ as q,y_ as r,F_ as s,Vt as t,I_ as u,N_ as v,U_ as w,O_ as x,M_ as y,T_ as z};