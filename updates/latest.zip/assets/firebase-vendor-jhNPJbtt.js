const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x542e2d,_0x565b20){if(!_0x542e2d)throw ht(_0x565b20);},ht=function(_0xb4b96b){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0xb4b96b);},Hr=function(_0x5ea456){const _0x2bd8f9=[];let _0x456cfc=0x0;for(let _0x2464ae=0x0;_0x2464ae<_0x5ea456['length'];_0x2464ae++){let _0x4689cb=_0x5ea456['charCodeAt'](_0x2464ae);_0x4689cb<0x80?_0x2bd8f9[_0x456cfc++]=_0x4689cb:_0x4689cb<0x800?(_0x2bd8f9[_0x456cfc++]=_0x4689cb>>0x6|0xc0,_0x2bd8f9[_0x456cfc++]=_0x4689cb&0x3f|0x80):(_0x4689cb&0xfc00)===0xd800&&_0x2464ae+0x1<_0x5ea456['length']&&(_0x5ea456['charCodeAt'](_0x2464ae+0x1)&0xfc00)===0xdc00?(_0x4689cb=0x10000+((_0x4689cb&0x3ff)<<0xa)+(_0x5ea456['charCodeAt'](++_0x2464ae)&0x3ff),_0x2bd8f9[_0x456cfc++]=_0x4689cb>>0x12|0xf0,_0x2bd8f9[_0x456cfc++]=_0x4689cb>>0xc&0x3f|0x80,_0x2bd8f9[_0x456cfc++]=_0x4689cb>>0x6&0x3f|0x80,_0x2bd8f9[_0x456cfc++]=_0x4689cb&0x3f|0x80):(_0x2bd8f9[_0x456cfc++]=_0x4689cb>>0xc|0xe0,_0x2bd8f9[_0x456cfc++]=_0x4689cb>>0x6&0x3f|0x80,_0x2bd8f9[_0x456cfc++]=_0x4689cb&0x3f|0x80);}return _0x2bd8f9;},nc=function(_0x5ef374){const _0x4070c5=[];let _0x3b9f91=0x0,_0x59c67e=0x0;for(;_0x3b9f91<_0x5ef374['length'];){const _0x1ba55d=_0x5ef374[_0x3b9f91++];if(_0x1ba55d<0x80)_0x4070c5[_0x59c67e++]=String['fromCharCode'](_0x1ba55d);else{if(_0x1ba55d>0xbf&&_0x1ba55d<0xe0){const _0x4b5af7=_0x5ef374[_0x3b9f91++];_0x4070c5[_0x59c67e++]=String['fromCharCode']((_0x1ba55d&0x1f)<<0x6|_0x4b5af7&0x3f);}else{if(_0x1ba55d>0xef&&_0x1ba55d<0x16d){const _0x1ceeef=_0x5ef374[_0x3b9f91++],_0x3768f9=_0x5ef374[_0x3b9f91++],_0x50b9f4=_0x5ef374[_0x3b9f91++],_0x2793bf=((_0x1ba55d&0x7)<<0x12|(_0x1ceeef&0x3f)<<0xc|(_0x3768f9&0x3f)<<0x6|_0x50b9f4&0x3f)-0x10000;_0x4070c5[_0x59c67e++]=String['fromCharCode'](0xd800+(_0x2793bf>>0xa)),_0x4070c5[_0x59c67e++]=String['fromCharCode'](0xdc00+(_0x2793bf&0x3ff));}else{const _0x2b47cc=_0x5ef374[_0x3b9f91++],_0x54dd36=_0x5ef374[_0x3b9f91++];_0x4070c5[_0x59c67e++]=String['fromCharCode']((_0x1ba55d&0xf)<<0xc|(_0x2b47cc&0x3f)<<0x6|_0x54dd36&0x3f);}}}}return _0x4070c5['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x9ac6d0,_0x53ec0a){if(!Array['isArray'](_0x9ac6d0))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x48eec0=_0x53ec0a?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x3f106c=[];for(let _0x3e644b=0x0;_0x3e644b<_0x9ac6d0['length'];_0x3e644b+=0x3){const _0x4cb384=_0x9ac6d0[_0x3e644b],_0x448cd0=_0x3e644b+0x1<_0x9ac6d0['length'],_0x3a15a9=_0x448cd0?_0x9ac6d0[_0x3e644b+0x1]:0x0,_0x131b83=_0x3e644b+0x2<_0x9ac6d0['length'],_0x462c61=_0x131b83?_0x9ac6d0[_0x3e644b+0x2]:0x0,_0x345b49=_0x4cb384>>0x2,_0x456b58=(_0x4cb384&0x3)<<0x4|_0x3a15a9>>0x4;let _0x530175=(_0x3a15a9&0xf)<<0x2|_0x462c61>>0x6,_0x509e48=_0x462c61&0x3f;_0x131b83||(_0x509e48=0x40,_0x448cd0||(_0x530175=0x40)),_0x3f106c['push'](_0x48eec0[_0x345b49],_0x48eec0[_0x456b58],_0x48eec0[_0x530175],_0x48eec0[_0x509e48]);}return _0x3f106c['join']('');},'encodeString'(_0x45e086,_0x404dc2){return this['HAS_NATIVE_SUPPORT']&&!_0x404dc2?btoa(_0x45e086):this['encodeByteArray'](Hr(_0x45e086),_0x404dc2);},'decodeString'(_0x20abcc,_0x16b195){return this['HAS_NATIVE_SUPPORT']&&!_0x16b195?atob(_0x20abcc):nc(this['decodeStringToByteArray'](_0x20abcc,_0x16b195));},'decodeStringToByteArray'(_0x23c70a,_0x1b21c2){this['init_']();const _0x16c624=_0x1b21c2?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x36a9d5=[];for(let _0x1d5778=0x0;_0x1d5778<_0x23c70a['length'];){const _0x17587f=_0x16c624[_0x23c70a['charAt'](_0x1d5778++)],_0x9b4648=_0x1d5778<_0x23c70a['length']?_0x16c624[_0x23c70a['charAt'](_0x1d5778)]:0x0;++_0x1d5778;const _0x37b887=_0x1d5778<_0x23c70a['length']?_0x16c624[_0x23c70a['charAt'](_0x1d5778)]:0x40;++_0x1d5778;const _0x19d22=_0x1d5778<_0x23c70a['length']?_0x16c624[_0x23c70a['charAt'](_0x1d5778)]:0x40;if(++_0x1d5778,_0x17587f==null||_0x9b4648==null||_0x37b887==null||_0x19d22==null)throw new ic();const _0x3ae675=_0x17587f<<0x2|_0x9b4648>>0x4;if(_0x36a9d5['push'](_0x3ae675),_0x37b887!==0x40){const _0x290115=_0x9b4648<<0x4&0xf0|_0x37b887>>0x2;if(_0x36a9d5['push'](_0x290115),_0x19d22!==0x40){const _0x2cc64d=_0x37b887<<0x6&0xc0|_0x19d22;_0x36a9d5['push'](_0x2cc64d);}}}return _0x36a9d5;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x4380ef=0x0;_0x4380ef<this['ENCODED_VALS']['length'];_0x4380ef++)this['byteToCharMap_'][_0x4380ef]=this['ENCODED_VALS']['charAt'](_0x4380ef),this['charToByteMap_'][this['byteToCharMap_'][_0x4380ef]]=_0x4380ef,this['byteToCharMapWebSafe_'][_0x4380ef]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x4380ef),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x4380ef]]=_0x4380ef,_0x4380ef>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x4380ef)]=_0x4380ef,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x4380ef)]=_0x4380ef);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x1debd5){const _0x2b8366=Hr(_0x1debd5);return Fi['encodeByteArray'](_0x2b8366,!0x0);},dn=function(_0xa08daf){return $r(_0xa08daf)['replace'](/\./g,'');},fn=function(_0x3a4477){try{return Fi['decodeString'](_0x3a4477,!0x0);}catch(_0x213c88){console['error']('base64Decode\x20failed:\x20',_0x213c88);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x55f106){return Gr(void 0x0,_0x55f106);}function Gr(_0x95b1c5,_0x12029f){if(!(_0x12029f instanceof Object))return _0x12029f;switch(_0x12029f['constructor']){case Date:const _0x1f92f5=_0x12029f;return new Date(_0x1f92f5['getTime']());case Object:_0x95b1c5===void 0x0&&(_0x95b1c5={});break;case Array:_0x95b1c5=[];break;default:return _0x12029f;}for(const _0x517cdb in _0x12029f)!_0x12029f['hasOwnProperty'](_0x517cdb)||!rc(_0x517cdb)||(_0x95b1c5[_0x517cdb]=Gr(_0x95b1c5[_0x517cdb],_0x12029f[_0x517cdb]));return _0x95b1c5;}function rc(_0x5e90b8){return _0x5e90b8!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x22b441=Ps['__FIREBASE_DEFAULTS__'];if(_0x22b441)return JSON['parse'](_0x22b441);},lc=()=>{if(typeof document>'u')return;let _0x2a77fb;try{_0x2a77fb=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x135f5d=_0x2a77fb&&fn(_0x2a77fb[0x1]);return _0x135f5d&&JSON['parse'](_0x135f5d);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x18e518){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x18e518);return;}},qr=_0x497d0c=>{var _0x3fd796,_0x3e08e5;return(_0x3e08e5=(_0x3fd796=Ui())==null?void 0x0:_0x3fd796['emulatorHosts'])==null?void 0x0:_0x3e08e5[_0x497d0c];},hc=_0x67c267=>{const _0x25c0a6=qr(_0x67c267);if(!_0x25c0a6)return;const _0x38554e=_0x25c0a6['lastIndexOf'](':');if(_0x38554e<=0x0||_0x38554e+0x1===_0x25c0a6['length'])throw new Error('Invalid\x20host\x20'+_0x25c0a6+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x4b0d68=parseInt(_0x25c0a6['substring'](_0x38554e+0x1),0xa);return _0x25c0a6[0x0]==='['?[_0x25c0a6['substring'](0x1,_0x38554e-0x1),_0x4b0d68]:[_0x25c0a6['substring'](0x0,_0x38554e),_0x4b0d68];},zr=()=>{var _0x12f7e4;return(_0x12f7e4=Ui())==null?void 0x0:_0x12f7e4['config'];},jr=_0x35bbf5=>{var _0x221504;return(_0x221504=Ui())==null?void 0x0:_0x221504['_'+_0x35bbf5];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x2f4f43,_0x379f47)=>{this['resolve']=_0x2f4f43,this['reject']=_0x379f47;});}['wrapCallback'](_0x377f08){return(_0x54bf73,_0x2c437)=>{_0x54bf73?this['reject'](_0x54bf73):this['resolve'](_0x2c437),typeof _0x377f08=='function'&&(this['promise']['catch'](()=>{}),_0x377f08['length']===0x1?_0x377f08(_0x54bf73):_0x377f08(_0x54bf73,_0x2c437));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x4d2d55,_0x104fa6){if(_0x4d2d55['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x55b88c={'alg':'none','type':'JWT'},_0x5280ce=_0x104fa6||'demo-project',_0x1ad610=_0x4d2d55['iat']||0x0,_0x5b1a9f=_0x4d2d55['sub']||_0x4d2d55['user_id'];if(!_0x5b1a9f)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x5d3f12={'iss':'https://securetoken.google.com/'+_0x5280ce,'aud':_0x5280ce,'iat':_0x1ad610,'exp':_0x1ad610+0xe10,'auth_time':_0x1ad610,'sub':_0x5b1a9f,'user_id':_0x5b1a9f,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x4d2d55};return[dn(JSON['stringify'](_0x55b88c)),dn(JSON['stringify'](_0x5d3f12)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x33baa8=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x33baa8=='object'&&_0x33baa8['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x37ecbc=W();return _0x37ecbc['indexOf']('MSIE\x20')>=0x0||_0x37ecbc['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x2e2f00,_0x5ac444)=>{try{let _0x1a02bd=!0x0;const _0x2548fe='validate-browser-context-for-indexeddb-analytics-module',_0x17925a=self['indexedDB']['open'](_0x2548fe);_0x17925a['onsuccess']=()=>{_0x17925a['result']['close'](),_0x1a02bd||self['indexedDB']['deleteDatabase'](_0x2548fe),_0x2e2f00(!0x0);},_0x17925a['onupgradeneeded']=()=>{_0x1a02bd=!0x1;},_0x17925a['onerror']=()=>{var _0x211750;_0x5ac444(((_0x211750=_0x17925a['error'])==null?void 0x0:_0x211750['message'])||'');};}catch(_0x56b95f){_0x5ac444(_0x56b95f);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x40cdfa,_0x3faf74,_0x28af12){super(_0x3faf74),this['code']=_0x40cdfa,this['customData']=_0x28af12,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x86376f,_0x23053e,_0xbe6cb1){this['service']=_0x86376f,this['serviceName']=_0x23053e,this['errors']=_0xbe6cb1;}['create'](_0x129df0,..._0x23dbbb){const _0x1e3584=_0x23dbbb[0x0]||{},_0x39ce4e=this['service']+'/'+_0x129df0,_0x1f7cca=this['errors'][_0x129df0],_0xe77fca=_0x1f7cca?vc(_0x1f7cca,_0x1e3584):'Error',_0x4a4974=this['serviceName']+':\x20'+_0xe77fca+'\x20('+_0x39ce4e+').';return new Re(_0x39ce4e,_0x4a4974,_0x1e3584);}}function vc(_0x429cc0,_0x2adc38){return _0x429cc0['replace'](Ec,(_0x53227d,_0x1ec176)=>{const _0x512453=_0x2adc38[_0x1ec176];return _0x512453!=null?String(_0x512453):'<'+_0x1ec176+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x40e31a){return JSON['parse'](_0x40e31a);}function O(_0x2914df){return JSON['stringify'](_0x2914df);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x2b4fd6){let _0x55fe41={},_0x240a8c={},_0x2b4d4e={},_0x2d75f8='';try{const _0xd6792c=_0x2b4fd6['split']('.');_0x55fe41=Nt(fn(_0xd6792c[0x0])||''),_0x240a8c=Nt(fn(_0xd6792c[0x1])||''),_0x2d75f8=_0xd6792c[0x2],_0x2b4d4e=_0x240a8c['d']||{},delete _0x240a8c['d'];}catch{}return{'header':_0x55fe41,'claims':_0x240a8c,'data':_0x2b4d4e,'signature':_0x2d75f8};},Ic=function(_0x5ca771){const _0x2f73f6=Yr(_0x5ca771),_0x106fc5=_0x2f73f6['claims'];return!!_0x106fc5&&typeof _0x106fc5=='object'&&_0x106fc5['hasOwnProperty']('iat');},wc=function(_0x2c9436){const _0x3140c5=Yr(_0x2c9436)['claims'];return typeof _0x3140c5=='object'&&_0x3140c5['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x28f129,_0xa78a9e){return Object['prototype']['hasOwnProperty']['call'](_0x28f129,_0xa78a9e);}function Le(_0x50a7bd,_0x2555cf){if(Object['prototype']['hasOwnProperty']['call'](_0x50a7bd,_0x2555cf))return _0x50a7bd[_0x2555cf];}function pn(_0x3ff022){for(const _0x212be9 in _0x3ff022)if(Object['prototype']['hasOwnProperty']['call'](_0x3ff022,_0x212be9))return!0x1;return!0x0;}function _n(_0xce1941,_0x5e588e,_0x40271f){const _0x5adefd={};for(const _0x3749c1 in _0xce1941)Object['prototype']['hasOwnProperty']['call'](_0xce1941,_0x3749c1)&&(_0x5adefd[_0x3749c1]=_0x5e588e['call'](_0x40271f,_0xce1941[_0x3749c1],_0x3749c1,_0xce1941));return _0x5adefd;}function xe(_0x1c9cfd,_0x2536fc){if(_0x1c9cfd===_0x2536fc)return!0x0;const _0x255336=Object['keys'](_0x1c9cfd),_0x5bd063=Object['keys'](_0x2536fc);for(const _0x41298f of _0x255336){if(!_0x5bd063['includes'](_0x41298f))return!0x1;const _0x36e75b=_0x1c9cfd[_0x41298f],_0x153e65=_0x2536fc[_0x41298f];if(Ns(_0x36e75b)&&Ns(_0x153e65)){if(!xe(_0x36e75b,_0x153e65))return!0x1;}else{if(_0x36e75b!==_0x153e65)return!0x1;}}for(const _0x302036 of _0x5bd063)if(!_0x255336['includes'](_0x302036))return!0x1;return!0x0;}function Ns(_0x327ea8){return _0x327ea8!==null&&typeof _0x327ea8=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x553a05){const _0x4fb63f=[];for(const [_0x4ad068,_0x48ab84]of Object['entries'](_0x553a05))Array['isArray'](_0x48ab84)?_0x48ab84['forEach'](_0x57fe8e=>{_0x4fb63f['push'](encodeURIComponent(_0x4ad068)+'='+encodeURIComponent(_0x57fe8e));}):_0x4fb63f['push'](encodeURIComponent(_0x4ad068)+'='+encodeURIComponent(_0x48ab84));return _0x4fb63f['length']?'&'+_0x4fb63f['join']('&'):'';}function Ct(_0x2c70d9){const _0x340302={};return _0x2c70d9['replace'](/^\?/,'')['split']('&')['forEach'](_0x51e252=>{if(_0x51e252){const [_0x2b86dd,_0x57e485]=_0x51e252['split']('=');_0x340302[decodeURIComponent(_0x2b86dd)]=decodeURIComponent(_0x57e485);}}),_0x340302;}function Tt(_0x404120){const _0x266413=_0x404120['indexOf']('?');if(!_0x266413)return'';const _0x129dcd=_0x404120['indexOf']('#',_0x266413);return _0x404120['substring'](_0x266413,_0x129dcd>0x0?_0x129dcd:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x218d8a=0x1;_0x218d8a<this['blockSize'];++_0x218d8a)this['pad_'][_0x218d8a]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x1e5ebe,_0x474d84){_0x474d84||(_0x474d84=0x0);const _0x659a9f=this['W_'];if(typeof _0x1e5ebe=='string'){for(let _0x34452a=0x0;_0x34452a<0x10;_0x34452a++)_0x659a9f[_0x34452a]=_0x1e5ebe['charCodeAt'](_0x474d84)<<0x18|_0x1e5ebe['charCodeAt'](_0x474d84+0x1)<<0x10|_0x1e5ebe['charCodeAt'](_0x474d84+0x2)<<0x8|_0x1e5ebe['charCodeAt'](_0x474d84+0x3),_0x474d84+=0x4;}else{for(let _0x5f06a7=0x0;_0x5f06a7<0x10;_0x5f06a7++)_0x659a9f[_0x5f06a7]=_0x1e5ebe[_0x474d84]<<0x18|_0x1e5ebe[_0x474d84+0x1]<<0x10|_0x1e5ebe[_0x474d84+0x2]<<0x8|_0x1e5ebe[_0x474d84+0x3],_0x474d84+=0x4;}for(let _0x4a54b7=0x10;_0x4a54b7<0x50;_0x4a54b7++){const _0xc15f65=_0x659a9f[_0x4a54b7-0x3]^_0x659a9f[_0x4a54b7-0x8]^_0x659a9f[_0x4a54b7-0xe]^_0x659a9f[_0x4a54b7-0x10];_0x659a9f[_0x4a54b7]=(_0xc15f65<<0x1|_0xc15f65>>>0x1f)&0xffffffff;}let _0x29ce8e=this['chain_'][0x0],_0x5dc363=this['chain_'][0x1],_0x39401b=this['chain_'][0x2],_0x180b4b=this['chain_'][0x3],_0x2c4301=this['chain_'][0x4],_0x2dca1b,_0x5e5458;for(let _0x1f78da=0x0;_0x1f78da<0x50;_0x1f78da++){_0x1f78da<0x28?_0x1f78da<0x14?(_0x2dca1b=_0x180b4b^_0x5dc363&(_0x39401b^_0x180b4b),_0x5e5458=0x5a827999):(_0x2dca1b=_0x5dc363^_0x39401b^_0x180b4b,_0x5e5458=0x6ed9eba1):_0x1f78da<0x3c?(_0x2dca1b=_0x5dc363&_0x39401b|_0x180b4b&(_0x5dc363|_0x39401b),_0x5e5458=0x8f1bbcdc):(_0x2dca1b=_0x5dc363^_0x39401b^_0x180b4b,_0x5e5458=0xca62c1d6);const _0x4a88a8=(_0x29ce8e<<0x5|_0x29ce8e>>>0x1b)+_0x2dca1b+_0x2c4301+_0x5e5458+_0x659a9f[_0x1f78da]&0xffffffff;_0x2c4301=_0x180b4b,_0x180b4b=_0x39401b,_0x39401b=(_0x5dc363<<0x1e|_0x5dc363>>>0x2)&0xffffffff,_0x5dc363=_0x29ce8e,_0x29ce8e=_0x4a88a8;}this['chain_'][0x0]=this['chain_'][0x0]+_0x29ce8e&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x5dc363&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x39401b&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x180b4b&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x2c4301&0xffffffff;}['update'](_0x500c78,_0x234670){if(_0x500c78==null)return;_0x234670===void 0x0&&(_0x234670=_0x500c78['length']);const _0x201827=_0x234670-this['blockSize'];let _0x4b61f6=0x0;const _0x4310b9=this['buf_'];let _0x79af22=this['inbuf_'];for(;_0x4b61f6<_0x234670;){if(_0x79af22===0x0){for(;_0x4b61f6<=_0x201827;)this['compress_'](_0x500c78,_0x4b61f6),_0x4b61f6+=this['blockSize'];}if(typeof _0x500c78=='string'){for(;_0x4b61f6<_0x234670;)if(_0x4310b9[_0x79af22]=_0x500c78['charCodeAt'](_0x4b61f6),++_0x79af22,++_0x4b61f6,_0x79af22===this['blockSize']){this['compress_'](_0x4310b9),_0x79af22=0x0;break;}}else{for(;_0x4b61f6<_0x234670;)if(_0x4310b9[_0x79af22]=_0x500c78[_0x4b61f6],++_0x79af22,++_0x4b61f6,_0x79af22===this['blockSize']){this['compress_'](_0x4310b9),_0x79af22=0x0;break;}}}this['inbuf_']=_0x79af22,this['total_']+=_0x234670;}['digest'](){const _0x18bb94=[];let _0x480fa4=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x23565c=this['blockSize']-0x1;_0x23565c>=0x38;_0x23565c--)this['buf_'][_0x23565c]=_0x480fa4&0xff,_0x480fa4/=0x100;this['compress_'](this['buf_']);let _0x2e26d0=0x0;for(let _0x5e60c1=0x0;_0x5e60c1<0x5;_0x5e60c1++)for(let _0x3652a7=0x18;_0x3652a7>=0x0;_0x3652a7-=0x8)_0x18bb94[_0x2e26d0]=this['chain_'][_0x5e60c1]>>_0x3652a7&0xff,++_0x2e26d0;return _0x18bb94;}}function Tc(_0x73bcb0,_0x1807d1){const _0x59c25f=new Sc(_0x73bcb0,_0x1807d1);return _0x59c25f['subscribe']['bind'](_0x59c25f);}class Sc{constructor(_0x42a395,_0x4360b7){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x4360b7,this['task']['then'](()=>{_0x42a395(this);})['catch'](_0x39aeb5=>{this['error'](_0x39aeb5);});}['next'](_0x537d3a){this['forEachObserver'](_0x538a47=>{_0x538a47['next'](_0x537d3a);});}['error'](_0x415755){this['forEachObserver'](_0x38309f=>{_0x38309f['error'](_0x415755);}),this['close'](_0x415755);}['complete'](){this['forEachObserver'](_0x484c99=>{_0x484c99['complete']();}),this['close']();}['subscribe'](_0x4a448b,_0xcaac8b,_0xa1c0aa){let _0x185b52;if(_0x4a448b===void 0x0&&_0xcaac8b===void 0x0&&_0xa1c0aa===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x4a448b,['next','error','complete'])?_0x185b52=_0x4a448b:_0x185b52={'next':_0x4a448b,'error':_0xcaac8b,'complete':_0xa1c0aa},_0x185b52['next']===void 0x0&&(_0x185b52['next']=ti),_0x185b52['error']===void 0x0&&(_0x185b52['error']=ti),_0x185b52['complete']===void 0x0&&(_0x185b52['complete']=ti);const _0x2acc50=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x185b52['error'](this['finalError']):_0x185b52['complete']();}catch{}}),this['observers']['push'](_0x185b52),_0x2acc50;}['unsubscribeOne'](_0x2f286c){this['observers']===void 0x0||this['observers'][_0x2f286c]===void 0x0||(delete this['observers'][_0x2f286c],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x5c5b5c){if(!this['finalized']){for(let _0x53e3fb=0x0;_0x53e3fb<this['observers']['length'];_0x53e3fb++)this['sendOne'](_0x53e3fb,_0x5c5b5c);}}['sendOne'](_0x226dc7,_0x5ae30b){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x226dc7]!==void 0x0)try{_0x5ae30b(this['observers'][_0x226dc7]);}catch(_0x3de82b){typeof console<'u'&&console['error']&&console['error'](_0x3de82b);}});}['close'](_0x26760b){this['finalized']||(this['finalized']=!0x0,_0x26760b!==void 0x0&&(this['finalError']=_0x26760b),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x1a138b,_0x110032){if(typeof _0x1a138b!='object'||_0x1a138b===null)return!0x1;for(const _0x1f79d0 of _0x110032)if(_0x1f79d0 in _0x1a138b&&typeof _0x1a138b[_0x1f79d0]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x390506,_0xb322a8){return _0x390506+'\x20failed:\x20'+_0xb322a8+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x80c312){const _0x558b0a=[];let _0x28dca4=0x0;for(let _0x574d91=0x0;_0x574d91<_0x80c312['length'];_0x574d91++){let _0x46aaea=_0x80c312['charCodeAt'](_0x574d91);if(_0x46aaea>=0xd800&&_0x46aaea<=0xdbff){const _0x44d996=_0x46aaea-0xd800;_0x574d91++,f(_0x574d91<_0x80c312['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x2c69bc=_0x80c312['charCodeAt'](_0x574d91)-0xdc00;_0x46aaea=0x10000+(_0x44d996<<0xa)+_0x2c69bc;}_0x46aaea<0x80?_0x558b0a[_0x28dca4++]=_0x46aaea:_0x46aaea<0x800?(_0x558b0a[_0x28dca4++]=_0x46aaea>>0x6|0xc0,_0x558b0a[_0x28dca4++]=_0x46aaea&0x3f|0x80):_0x46aaea<0x10000?(_0x558b0a[_0x28dca4++]=_0x46aaea>>0xc|0xe0,_0x558b0a[_0x28dca4++]=_0x46aaea>>0x6&0x3f|0x80,_0x558b0a[_0x28dca4++]=_0x46aaea&0x3f|0x80):(_0x558b0a[_0x28dca4++]=_0x46aaea>>0x12|0xf0,_0x558b0a[_0x28dca4++]=_0x46aaea>>0xc&0x3f|0x80,_0x558b0a[_0x28dca4++]=_0x46aaea>>0x6&0x3f|0x80,_0x558b0a[_0x28dca4++]=_0x46aaea&0x3f|0x80);}return _0x558b0a;},Ln=function(_0x2aaacf){let _0x5f4c75=0x0;for(let _0x2aac2b=0x0;_0x2aac2b<_0x2aaacf['length'];_0x2aac2b++){const _0x11c1fa=_0x2aaacf['charCodeAt'](_0x2aac2b);_0x11c1fa<0x80?_0x5f4c75++:_0x11c1fa<0x800?_0x5f4c75+=0x2:_0x11c1fa>=0xd800&&_0x11c1fa<=0xdbff?(_0x5f4c75+=0x4,_0x2aac2b++):_0x5f4c75+=0x3;}return _0x5f4c75;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x3e4abb){return _0x3e4abb&&_0x3e4abb['_delegate']?_0x3e4abb['_delegate']:_0x3e4abb;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0xe4b18e){try{return(_0xe4b18e['startsWith']('http://')||_0xe4b18e['startsWith']('https://')?new URL(_0xe4b18e)['hostname']:_0xe4b18e)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x10cea6){return(await fetch(_0x10cea6,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x445303,_0x43b309,_0x4bd54d){this['name']=_0x445303,this['instanceFactory']=_0x43b309,this['type']=_0x4bd54d,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x28dab1){return this['instantiationMode']=_0x28dab1,this;}['setMultipleInstances'](_0x26ff8d){return this['multipleInstances']=_0x26ff8d,this;}['setServiceProps'](_0x77c1f2){return this['serviceProps']=_0x77c1f2,this;}['setInstanceCreatedCallback'](_0x239655){return this['onInstanceCreated']=_0x239655,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x3e7be6,_0x2a396f){this['name']=_0x3e7be6,this['container']=_0x2a396f,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x10ac55){const _0xd979d8=this['normalizeInstanceIdentifier'](_0x10ac55);if(!this['instancesDeferred']['has'](_0xd979d8)){const _0x31a762=new H();if(this['instancesDeferred']['set'](_0xd979d8,_0x31a762),this['isInitialized'](_0xd979d8)||this['shouldAutoInitialize']())try{const _0x1ff4a9=this['getOrInitializeService']({'instanceIdentifier':_0xd979d8});_0x1ff4a9&&_0x31a762['resolve'](_0x1ff4a9);}catch{}}return this['instancesDeferred']['get'](_0xd979d8)['promise'];}['getImmediate'](_0x1a9b79){const _0x1cca0c=this['normalizeInstanceIdentifier'](_0x1a9b79==null?void 0x0:_0x1a9b79['identifier']),_0x17a41a=(_0x1a9b79==null?void 0x0:_0x1a9b79['optional'])??!0x1;if(this['isInitialized'](_0x1cca0c)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x1cca0c});}catch(_0x1d3fcb){if(_0x17a41a)return null;throw _0x1d3fcb;}else{if(_0x17a41a)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x4d897f){if(_0x4d897f['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x4d897f['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x4d897f,!!this['shouldAutoInitialize']()){if(Pc(_0x4d897f))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x1b5753,_0x1ffcdb]of this['instancesDeferred']['entries']()){const _0x32c6a0=this['normalizeInstanceIdentifier'](_0x1b5753);try{const _0x5cfcea=this['getOrInitializeService']({'instanceIdentifier':_0x32c6a0});_0x1ffcdb['resolve'](_0x5cfcea);}catch{}}}}['clearInstance'](_0x49a4c5=Ne){this['instancesDeferred']['delete'](_0x49a4c5),this['instancesOptions']['delete'](_0x49a4c5),this['instances']['delete'](_0x49a4c5);}async['delete'](){const _0x39c6d1=Array['from'](this['instances']['values']());await Promise['all']([..._0x39c6d1['filter'](_0x16e21c=>'INTERNAL'in _0x16e21c)['map'](_0x236e72=>_0x236e72['INTERNAL']['delete']()),..._0x39c6d1['filter'](_0x568b29=>'_delete'in _0x568b29)['map'](_0x27104c=>_0x27104c['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x46ab0e=Ne){return this['instances']['has'](_0x46ab0e);}['getOptions'](_0xfe09f3=Ne){return this['instancesOptions']['get'](_0xfe09f3)||{};}['initialize'](_0x57e0f5={}){const {options:_0x5cd2f7={}}=_0x57e0f5,_0x1e45e6=this['normalizeInstanceIdentifier'](_0x57e0f5['instanceIdentifier']);if(this['isInitialized'](_0x1e45e6))throw Error(this['name']+'('+_0x1e45e6+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x24d0e7=this['getOrInitializeService']({'instanceIdentifier':_0x1e45e6,'options':_0x5cd2f7});for(const [_0x525337,_0x233069]of this['instancesDeferred']['entries']()){const _0x28827a=this['normalizeInstanceIdentifier'](_0x525337);_0x1e45e6===_0x28827a&&_0x233069['resolve'](_0x24d0e7);}return _0x24d0e7;}['onInit'](_0x32ea56,_0x5a329a){const _0x39eeb8=this['normalizeInstanceIdentifier'](_0x5a329a),_0x375182=this['onInitCallbacks']['get'](_0x39eeb8)??new Set();_0x375182['add'](_0x32ea56),this['onInitCallbacks']['set'](_0x39eeb8,_0x375182);const _0x19d2d8=this['instances']['get'](_0x39eeb8);return _0x19d2d8&&_0x32ea56(_0x19d2d8,_0x39eeb8),()=>{_0x375182['delete'](_0x32ea56);};}['invokeOnInitCallbacks'](_0x2e2b0c,_0x48a2dd){const _0x3b8282=this['onInitCallbacks']['get'](_0x48a2dd);if(_0x3b8282){for(const _0x230ca6 of _0x3b8282)try{_0x230ca6(_0x2e2b0c,_0x48a2dd);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x538486,options:_0xed942c={}}){let _0x5bbf61=this['instances']['get'](_0x538486);if(!_0x5bbf61&&this['component']&&(_0x5bbf61=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x538486),'options':_0xed942c}),this['instances']['set'](_0x538486,_0x5bbf61),this['instancesOptions']['set'](_0x538486,_0xed942c),this['invokeOnInitCallbacks'](_0x5bbf61,_0x538486),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x538486,_0x5bbf61);}catch{}return _0x5bbf61||null;}['normalizeInstanceIdentifier'](_0x4d5657=Ne){return this['component']?this['component']['multipleInstances']?_0x4d5657:Ne:_0x4d5657;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x38a072){return _0x38a072===Ne?void 0x0:_0x38a072;}function Pc(_0x17d27a){return _0x17d27a['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x27545e){this['name']=_0x27545e,this['providers']=new Map();}['addComponent'](_0x2d075f){const _0x481b8a=this['getProvider'](_0x2d075f['name']);if(_0x481b8a['isComponentSet']())throw new Error('Component\x20'+_0x2d075f['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x481b8a['setComponent'](_0x2d075f);}['addOrOverwriteComponent'](_0x1bff5b){this['getProvider'](_0x1bff5b['name'])['isComponentSet']()&&this['providers']['delete'](_0x1bff5b['name']),this['addComponent'](_0x1bff5b);}['getProvider'](_0x13e12a){if(this['providers']['has'](_0x13e12a))return this['providers']['get'](_0x13e12a);const _0x2e06e0=new Ac(_0x13e12a,this);return this['providers']['set'](_0x13e12a,_0x2e06e0),_0x2e06e0;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x28e6cf){_0x28e6cf[_0x28e6cf['DEBUG']=0x0]='DEBUG',_0x28e6cf[_0x28e6cf['VERBOSE']=0x1]='VERBOSE',_0x28e6cf[_0x28e6cf['INFO']=0x2]='INFO',_0x28e6cf[_0x28e6cf['WARN']=0x3]='WARN',_0x28e6cf[_0x28e6cf['ERROR']=0x4]='ERROR',_0x28e6cf[_0x28e6cf['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x15bd14,_0x20e628,..._0x5ccc85)=>{if(_0x20e628<_0x15bd14['logLevel'])return;const _0x272ffa=new Date()['toISOString'](),_0x31eb5f=Mc[_0x20e628];if(_0x31eb5f)console[_0x31eb5f]('['+_0x272ffa+']\x20\x20'+_0x15bd14['name']+':',..._0x5ccc85);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x20e628+')');};class Bi{constructor(_0x10573e){this['name']=_0x10573e,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x3bdc8f){if(!(_0x3bdc8f in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x3bdc8f+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x3bdc8f;}['setLogLevel'](_0x213254){this['_logLevel']=typeof _0x213254=='string'?Oc[_0x213254]:_0x213254;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x1a4bed){if(typeof _0x1a4bed!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x1a4bed;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0xa8b234){this['_userLogHandler']=_0xa8b234;}['debug'](..._0x13a7e8){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x13a7e8),this['_logHandler'](this,T['DEBUG'],..._0x13a7e8);}['log'](..._0x4d574b){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x4d574b),this['_logHandler'](this,T['VERBOSE'],..._0x4d574b);}['info'](..._0x270bf7){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x270bf7),this['_logHandler'](this,T['INFO'],..._0x270bf7);}['warn'](..._0x37b673){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x37b673),this['_logHandler'](this,T['WARN'],..._0x37b673);}['error'](..._0xd0371f){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0xd0371f),this['_logHandler'](this,T['ERROR'],..._0xd0371f);}}const xc=(_0x1f6fc3,_0x7337e1)=>_0x7337e1['some'](_0x451b59=>_0x1f6fc3 instanceof _0x451b59);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x1d4d08){const _0x381425=new Promise((_0x5a5706,_0x27b62a)=>{const _0x1285b2=()=>{_0x1d4d08['removeEventListener']('success',_0x2df60a),_0x1d4d08['removeEventListener']('error',_0x58dcc4);},_0x2df60a=()=>{_0x5a5706(ge(_0x1d4d08['result'])),_0x1285b2();},_0x58dcc4=()=>{_0x27b62a(_0x1d4d08['error']),_0x1285b2();};_0x1d4d08['addEventListener']('success',_0x2df60a),_0x1d4d08['addEventListener']('error',_0x58dcc4);});return _0x381425['then'](_0x44176e=>{_0x44176e instanceof IDBCursor&&Jr['set'](_0x44176e,_0x1d4d08);})['catch'](()=>{}),Vi['set'](_0x381425,_0x1d4d08),_0x381425;}function Bc(_0x48a9db){if(_i['has'](_0x48a9db))return;const _0x35e9e3=new Promise((_0x1a8267,_0x38c629)=>{const _0x18df11=()=>{_0x48a9db['removeEventListener']('complete',_0x426ffc),_0x48a9db['removeEventListener']('error',_0x34e216),_0x48a9db['removeEventListener']('abort',_0x34e216);},_0x426ffc=()=>{_0x1a8267(),_0x18df11();},_0x34e216=()=>{_0x38c629(_0x48a9db['error']||new DOMException('AbortError','AbortError')),_0x18df11();};_0x48a9db['addEventListener']('complete',_0x426ffc),_0x48a9db['addEventListener']('error',_0x34e216),_0x48a9db['addEventListener']('abort',_0x34e216);});_i['set'](_0x48a9db,_0x35e9e3);}let gi={'get'(_0xad6f71,_0x2676a1,_0x2c5663){if(_0xad6f71 instanceof IDBTransaction){if(_0x2676a1==='done')return _i['get'](_0xad6f71);if(_0x2676a1==='objectStoreNames')return _0xad6f71['objectStoreNames']||Xr['get'](_0xad6f71);if(_0x2676a1==='store')return _0x2c5663['objectStoreNames'][0x1]?void 0x0:_0x2c5663['objectStore'](_0x2c5663['objectStoreNames'][0x0]);}return ge(_0xad6f71[_0x2676a1]);},'set'(_0x51b7dd,_0x40244d,_0x410e65){return _0x51b7dd[_0x40244d]=_0x410e65,!0x0;},'has'(_0x1fb035,_0xb1380d){return _0x1fb035 instanceof IDBTransaction&&(_0xb1380d==='done'||_0xb1380d==='store')?!0x0:_0xb1380d in _0x1fb035;}};function Vc(_0x36037d){gi=_0x36037d(gi);}function Hc(_0x16c7ed){return _0x16c7ed===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x313f81,..._0x554251){const _0x53d4f8=_0x16c7ed['call'](ii(this),_0x313f81,..._0x554251);return Xr['set'](_0x53d4f8,_0x313f81['sort']?_0x313f81['sort']():[_0x313f81]),ge(_0x53d4f8);}:Uc()['includes'](_0x16c7ed)?function(..._0x5e4c4f){return _0x16c7ed['apply'](ii(this),_0x5e4c4f),ge(Jr['get'](this));}:function(..._0x360db3){return ge(_0x16c7ed['apply'](ii(this),_0x360db3));};}function $c(_0x57cf37){return typeof _0x57cf37=='function'?Hc(_0x57cf37):(_0x57cf37 instanceof IDBTransaction&&Bc(_0x57cf37),xc(_0x57cf37,Fc())?new Proxy(_0x57cf37,gi):_0x57cf37);}function ge(_0x544c3b){if(_0x544c3b instanceof IDBRequest)return Wc(_0x544c3b);if(ni['has'](_0x544c3b))return ni['get'](_0x544c3b);const _0x508a01=$c(_0x544c3b);return _0x508a01!==_0x544c3b&&(ni['set'](_0x544c3b,_0x508a01),Vi['set'](_0x508a01,_0x544c3b)),_0x508a01;}const ii=_0x61609b=>Vi['get'](_0x61609b);function Gc(_0x17e90d,_0x4ffded,{blocked:_0x41c3f5,upgrade:_0x2350ad,blocking:_0x1bdeb3,terminated:_0x5aeaca}={}){const _0x43cbab=indexedDB['open'](_0x17e90d,_0x4ffded),_0x28983a=ge(_0x43cbab);return _0x2350ad&&_0x43cbab['addEventListener']('upgradeneeded',_0x5c27f1=>{_0x2350ad(ge(_0x43cbab['result']),_0x5c27f1['oldVersion'],_0x5c27f1['newVersion'],ge(_0x43cbab['transaction']),_0x5c27f1);}),_0x41c3f5&&_0x43cbab['addEventListener']('blocked',_0x1db41d=>_0x41c3f5(_0x1db41d['oldVersion'],_0x1db41d['newVersion'],_0x1db41d)),_0x28983a['then'](_0xcddef0=>{_0x5aeaca&&_0xcddef0['addEventListener']('close',()=>_0x5aeaca()),_0x1bdeb3&&_0xcddef0['addEventListener']('versionchange',_0x26628a=>_0x1bdeb3(_0x26628a['oldVersion'],_0x26628a['newVersion'],_0x26628a));})['catch'](()=>{}),_0x28983a;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x53bfcc,_0x11f1cd){if(!(_0x53bfcc instanceof IDBDatabase&&!(_0x11f1cd in _0x53bfcc)&&typeof _0x11f1cd=='string'))return;if(si['get'](_0x11f1cd))return si['get'](_0x11f1cd);const _0x113c55=_0x11f1cd['replace'](/FromIndex$/,''),_0xdda492=_0x11f1cd!==_0x113c55,_0x5ca64e=zc['includes'](_0x113c55);if(!(_0x113c55 in(_0xdda492?IDBIndex:IDBObjectStore)['prototype'])||!(_0x5ca64e||qc['includes'](_0x113c55)))return;const _0xc28610=async function(_0x1bb793,..._0x1dd5ca){const _0xa0ed6e=this['transaction'](_0x1bb793,_0x5ca64e?'readwrite':'readonly');let _0x271994=_0xa0ed6e['store'];return _0xdda492&&(_0x271994=_0x271994['index'](_0x1dd5ca['shift']())),(await Promise['all']([_0x271994[_0x113c55](..._0x1dd5ca),_0x5ca64e&&_0xa0ed6e['done']]))[0x0];};return si['set'](_0x11f1cd,_0xc28610),_0xc28610;}Vc(_0x4a158b=>({..._0x4a158b,'get':(_0x7d3a64,_0xd6c6b1,_0x1edbbf)=>Ms(_0x7d3a64,_0xd6c6b1)||_0x4a158b['get'](_0x7d3a64,_0xd6c6b1,_0x1edbbf),'has':(_0x52be0c,_0x1c3770)=>!!Ms(_0x52be0c,_0x1c3770)||_0x4a158b['has'](_0x52be0c,_0x1c3770)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x52df9b){this['container']=_0x52df9b;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x4f4310=>{if(Kc(_0x4f4310)){const _0x563d49=_0x4f4310['getImmediate']();return _0x563d49['library']+'/'+_0x563d49['version'];}else return null;})['filter'](_0x2e102d=>_0x2e102d)['join']('\x20');}}function Kc(_0x57ef83){const _0x4e1a21=_0x57ef83['getComponent']();return(_0x4e1a21==null?void 0x0:_0x4e1a21['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x12bd4c,_0x9a9a59){try{_0x12bd4c['container']['addComponent'](_0x9a9a59);}catch(_0x3b6253){oe['debug']('Component\x20'+_0x9a9a59['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x12bd4c['name'],_0x3b6253);}}function st(_0x2d3882){const _0x2f6251=_0x2d3882['name'];if(Ei['has'](_0x2f6251))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x2f6251+'.'),!0x1;Ei['set'](_0x2f6251,_0x2d3882);for(const _0x1430e9 of Ue['values']())xs(_0x1430e9,_0x2d3882);for(const _0x136c16 of vi['values']())xs(_0x136c16,_0x2d3882);return!0x0;}function Hi(_0x56975c,_0x5cc37a){const _0x3a4074=_0x56975c['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x3a4074&&_0x3a4074['triggerHeartbeat'](),_0x56975c['container']['getProvider'](_0x5cc37a);}function $(_0x1179c4){return _0x1179c4==null?!0x1:_0x1179c4['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x1dddbb,_0x12a7a7,_0x26de04){this['_isDeleted']=!0x1,this['_options']={..._0x1dddbb},this['_config']={..._0x12a7a7},this['_name']=_0x12a7a7['name'],this['_automaticDataCollectionEnabled']=_0x12a7a7['automaticDataCollectionEnabled'],this['_container']=_0x26de04,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x2794ba){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x2794ba;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x21867d){this['_isDeleted']=_0x21867d;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x1b25c2,_0x43cf33={}){let _0x1043a8=_0x1b25c2;typeof _0x43cf33!='object'&&(_0x43cf33={'name':_0x43cf33});const _0x4285ac={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x43cf33},_0xddd3f8=_0x4285ac['name'];if(typeof _0xddd3f8!='string'||!_0xddd3f8)throw me['create']('bad-app-name',{'appName':String(_0xddd3f8)});if(_0x1043a8||(_0x1043a8=zr()),!_0x1043a8)throw me['create']('no-options');const _0x7d535c=Ue['get'](_0xddd3f8);if(_0x7d535c){if(xe(_0x1043a8,_0x7d535c['options'])&&xe(_0x4285ac,_0x7d535c['config']))return _0x7d535c;throw me['create']('duplicate-app',{'appName':_0xddd3f8});}const _0x1dbdf6=new Nc(_0xddd3f8);for(const _0x43adc3 of Ei['values']())_0x1dbdf6['addComponent'](_0x43adc3);const _0x1747e6=new Tl(_0x1043a8,_0x4285ac,_0x1dbdf6);return Ue['set'](_0xddd3f8,_0x1747e6),_0x1747e6;}function Zr(_0x3936e2=yi){const _0x218579=Ue['get'](_0x3936e2);if(!_0x218579&&_0x3936e2===yi&&zr())return Sl();if(!_0x218579)throw me['create']('no-app',{'appName':_0x3936e2});return _0x218579;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x130fd7){let _0x177eef=!0x1;const _0x2b5d18=_0x130fd7['name'];Ue['has'](_0x2b5d18)?(_0x177eef=!0x0,Ue['delete'](_0x2b5d18)):vi['has'](_0x2b5d18)&&_0x130fd7['decRefCount']()<=0x0&&(vi['delete'](_0x2b5d18),_0x177eef=!0x0),_0x177eef&&(await Promise['all'](_0x130fd7['container']['getProviders']()['map'](_0x44021b=>_0x44021b['delete']())),_0x130fd7['isDeleted']=!0x0);}function ye(_0x317f0b,_0x106a29,_0x3df34b){let _0x5d6ddd=wl[_0x317f0b]??_0x317f0b;_0x3df34b&&(_0x5d6ddd+='-'+_0x3df34b);const _0x1af95c=_0x5d6ddd['match'](/\s|\//),_0x29e9e2=_0x106a29['match'](/\s|\//);if(_0x1af95c||_0x29e9e2){const _0x35c5a6=['Unable\x20to\x20register\x20library\x20\x22'+_0x5d6ddd+'\x22\x20with\x20version\x20\x22'+_0x106a29+'\x22:'];_0x1af95c&&_0x35c5a6['push']('library\x20name\x20\x22'+_0x5d6ddd+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x1af95c&&_0x29e9e2&&_0x35c5a6['push']('and'),_0x29e9e2&&_0x35c5a6['push']('version\x20name\x20\x22'+_0x106a29+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x35c5a6['join']('\x20'));return;}st(new Fe(_0x5d6ddd+'-version',()=>({'library':_0x5d6ddd,'version':_0x106a29}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x7ad2ce,_0x219ece)=>{switch(_0x219ece){case 0x0:try{_0x7ad2ce['createObjectStore'](Ot);}catch(_0x274045){console['warn'](_0x274045);}}}})['catch'](_0x3f029e=>{throw me['create']('idb-open',{'originalErrorMessage':_0x3f029e['message']});})),ri;}async function Al(_0x4a6974){try{const _0x2d9ae0=(await eo())['transaction'](Ot),_0x37704a=await _0x2d9ae0['objectStore'](Ot)['get'](to(_0x4a6974));return await _0x2d9ae0['done'],_0x37704a;}catch(_0x441f86){if(_0x441f86 instanceof Re)oe['warn'](_0x441f86['message']);else{const _0x3dc7a4=me['create']('idb-get',{'originalErrorMessage':_0x441f86==null?void 0x0:_0x441f86['message']});oe['warn'](_0x3dc7a4['message']);}}}async function Fs(_0x4343db,_0x4a2ec0){try{const _0x11dd96=(await eo())['transaction'](Ot,'readwrite');await _0x11dd96['objectStore'](Ot)['put'](_0x4a2ec0,to(_0x4343db)),await _0x11dd96['done'];}catch(_0x309f93){if(_0x309f93 instanceof Re)oe['warn'](_0x309f93['message']);else{const _0x43e99a=me['create']('idb-set',{'originalErrorMessage':_0x309f93==null?void 0x0:_0x309f93['message']});oe['warn'](_0x43e99a['message']);}}}function to(_0x3f5341){return _0x3f5341['name']+'!'+_0x3f5341['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0xf00508){this['container']=_0xf00508,this['_heartbeatsCache']=null;const _0x13eb55=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x13eb55),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x13dc63=>(this['_heartbeatsCache']=_0x13dc63,_0x13dc63));}async['triggerHeartbeat'](){var _0xc972b9,_0x39f615;try{const _0x3ebabf=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x20e7fb=Us();if(((_0xc972b9=this['_heartbeatsCache'])==null?void 0x0:_0xc972b9['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x39f615=this['_heartbeatsCache'])==null?void 0x0:_0x39f615['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x20e7fb||this['_heartbeatsCache']['heartbeats']['some'](_0xdf9cc9=>_0xdf9cc9['date']===_0x20e7fb))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x20e7fb,'agent':_0x3ebabf}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x5958b4=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x5958b4,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x41fcc4){oe['warn'](_0x41fcc4);}}async['getHeartbeatsHeader'](){var _0x594558;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x594558=this['_heartbeatsCache'])==null?void 0x0:_0x594558['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x49daca=Us(),{heartbeatsToSend:_0x585ee1,unsentEntries:_0x3fb437}=Ol(this['_heartbeatsCache']['heartbeats']),_0x12e8ac=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x585ee1}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x49daca,_0x3fb437['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x3fb437,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x12e8ac;}catch(_0x155874){return oe['warn'](_0x155874),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x2f66d1,_0x550df8=kl){const _0x303836=[];let _0x3c974e=_0x2f66d1['slice']();for(const _0x170493 of _0x2f66d1){const _0x2d0868=_0x303836['find'](_0x5e695b=>_0x5e695b['agent']===_0x170493['agent']);if(_0x2d0868){if(_0x2d0868['dates']['push'](_0x170493['date']),Ws(_0x303836)>_0x550df8){_0x2d0868['dates']['pop']();break;}}else{if(_0x303836['push']({'agent':_0x170493['agent'],'dates':[_0x170493['date']]}),Ws(_0x303836)>_0x550df8){_0x303836['pop']();break;}}_0x3c974e=_0x3c974e['slice'](0x1);}return{'heartbeatsToSend':_0x303836,'unsentEntries':_0x3c974e};}class Dl{constructor(_0x33e5da){this['app']=_0x33e5da,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x1e1303=await Al(this['app']);return _0x1e1303!=null&&_0x1e1303['heartbeats']?_0x1e1303:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x51893d){if(await this['_canUseIndexedDBPromise']){const _0x38ea05=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x51893d['lastSentHeartbeatDate']??_0x38ea05['lastSentHeartbeatDate'],'heartbeats':_0x51893d['heartbeats']});}else return;}async['add'](_0x1644a4){if(await this['_canUseIndexedDBPromise']){const _0x875496=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x1644a4['lastSentHeartbeatDate']??_0x875496['lastSentHeartbeatDate'],'heartbeats':[..._0x875496['heartbeats'],..._0x1644a4['heartbeats']]});}else return;}}function Ws(_0x4bd964){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x4bd964}))['length'];}function Ml(_0x3ee7df){if(_0x3ee7df['length']===0x0)return-0x1;let _0x429767=0x0,_0x5986bd=_0x3ee7df[0x0]['date'];for(let _0x582194=0x1;_0x582194<_0x3ee7df['length'];_0x582194++)_0x3ee7df[_0x582194]['date']<_0x5986bd&&(_0x5986bd=_0x3ee7df[_0x582194]['date'],_0x429767=_0x582194);return _0x429767;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x22caee){st(new Fe('platform-logger',_0x45b960=>new jc(_0x45b960),'PRIVATE')),st(new Fe('heartbeat',_0x3d79eb=>new Nl(_0x3d79eb),'PRIVATE')),ye(mi,Ls,_0x22caee),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x48fb1d){no=_0x48fb1d;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x2e5c35){this['domStorage_']=_0x2e5c35,this['prefix_']='firebase:';}['set'](_0x2f04b7,_0x1c5163){_0x1c5163==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x2f04b7)):this['domStorage_']['setItem'](this['prefixedName_'](_0x2f04b7),O(_0x1c5163));}['get'](_0x3b2748){const _0x22fa21=this['domStorage_']['getItem'](this['prefixedName_'](_0x3b2748));return _0x22fa21==null?null:Nt(_0x22fa21);}['remove'](_0x5d7f26){this['domStorage_']['removeItem'](this['prefixedName_'](_0x5d7f26));}['prefixedName_'](_0x167a36){return this['prefix_']+_0x167a36;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x2c2c9b,_0x2cc381){_0x2cc381==null?delete this['cache_'][_0x2c2c9b]:this['cache_'][_0x2c2c9b]=_0x2cc381;}['get'](_0x42e694){return Q(this['cache_'],_0x42e694)?this['cache_'][_0x42e694]:null;}['remove'](_0xa0d1e0){delete this['cache_'][_0xa0d1e0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x440df8){try{if(typeof window<'u'&&typeof window[_0x440df8]<'u'){const _0xaa1ba=window[_0x440df8];return _0xaa1ba['setItem']('firebase:sentinel','cache'),_0xaa1ba['removeItem']('firebase:sentinel'),new Wl(_0xaa1ba);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x3b8b18=0x1;return function(){return _0x3b8b18++;};}()),ro=function(_0x56936e){const _0x2e51f2=Rc(_0x56936e),_0x3cc1b4=new Cc();_0x3cc1b4['update'](_0x2e51f2);const _0x210242=_0x3cc1b4['digest']();return Fi['encodeByteArray'](_0x210242);},zt=function(..._0x15768b){let _0x5db2a2='';for(let _0x3d1fcc=0x0;_0x3d1fcc<_0x15768b['length'];_0x3d1fcc++){const _0x379e4c=_0x15768b[_0x3d1fcc];Array['isArray'](_0x379e4c)||_0x379e4c&&typeof _0x379e4c=='object'&&typeof _0x379e4c['length']=='number'?_0x5db2a2+=zt['apply'](null,_0x379e4c):typeof _0x379e4c=='object'?_0x5db2a2+=O(_0x379e4c):_0x5db2a2+=_0x379e4c,_0x5db2a2+='\x20';}return _0x5db2a2;};let St=null,$s=!0x0;const Hl=function(_0x20de9b,_0x116861){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x5bf7cf){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x132c4a=zt['apply'](null,_0x5bf7cf);St(_0x132c4a);}},jt=function(_0x34bc43){return function(..._0x20a433){L(_0x34bc43,..._0x20a433);};},Ii=function(..._0x1d38d2){const _0x51cfd5='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x1d38d2);Ze['error'](_0x51cfd5);},ae=function(..._0x578083){const _0x479362='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x578083);throw Ze['error'](_0x479362),new Error(_0x479362);},U=function(..._0x5018c6){const _0x2ac523='FIREBASE\x20WARNING:\x20'+zt(..._0x5018c6);Ze['warn'](_0x2ac523);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x6e0b3e){return typeof _0x6e0b3e=='number'&&(_0x6e0b3e!==_0x6e0b3e||_0x6e0b3e===Number['POSITIVE_INFINITY']||_0x6e0b3e===Number['NEGATIVE_INFINITY']);},Gl=function(_0x441a6d){if(document['readyState']==='complete')_0x441a6d();else{let _0x174132=!0x1;const _0x3de8e8=function(){if(!document['body']){setTimeout(_0x3de8e8,Math['floor'](0xa));return;}_0x174132||(_0x174132=!0x0,_0x441a6d());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x3de8e8,!0x1),window['addEventListener']('load',_0x3de8e8,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x3de8e8();}),window['attachEvent']('onload',_0x3de8e8));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x4aff33,_0x3ed2e2){if(_0x4aff33===_0x3ed2e2)return 0x0;if(_0x4aff33===We||_0x3ed2e2===we)return-0x1;if(_0x3ed2e2===We||_0x4aff33===we)return 0x1;{const _0x2208c6=Gs(_0x4aff33),_0x221f27=Gs(_0x3ed2e2);return _0x2208c6!==null?_0x221f27!==null?_0x2208c6-_0x221f27===0x0?_0x4aff33['length']-_0x3ed2e2['length']:_0x2208c6-_0x221f27:-0x1:_0x221f27!==null?0x1:_0x4aff33<_0x3ed2e2?-0x1:0x1;}},ql=function(_0x54663b,_0xe8e7fb){return _0x54663b===_0xe8e7fb?0x0:_0x54663b<_0xe8e7fb?-0x1:0x1;},vt=function(_0x1f329d,_0x4ad5aa){if(_0x4ad5aa&&_0x1f329d in _0x4ad5aa)return _0x4ad5aa[_0x1f329d];throw new Error('Missing\x20required\x20key\x20('+_0x1f329d+')\x20in\x20object:\x20'+O(_0x4ad5aa));},$i=function(_0x3b40e9){if(typeof _0x3b40e9!='object'||_0x3b40e9===null)return O(_0x3b40e9);const _0xd2ed4d=[];for(const _0x169704 in _0x3b40e9)_0xd2ed4d['push'](_0x169704);_0xd2ed4d['sort']();let _0x4ea4e0='{';for(let _0x1602ff=0x0;_0x1602ff<_0xd2ed4d['length'];_0x1602ff++)_0x1602ff!==0x0&&(_0x4ea4e0+=','),_0x4ea4e0+=O(_0xd2ed4d[_0x1602ff]),_0x4ea4e0+=':',_0x4ea4e0+=$i(_0x3b40e9[_0xd2ed4d[_0x1602ff]]);return _0x4ea4e0+='}',_0x4ea4e0;},oo=function(_0x30d6cb,_0x43c7a6){const _0x1d6f03=_0x30d6cb['length'];if(_0x1d6f03<=_0x43c7a6)return[_0x30d6cb];const _0x3c75e2=[];for(let _0x5e69f5=0x0;_0x5e69f5<_0x1d6f03;_0x5e69f5+=_0x43c7a6)_0x5e69f5+_0x43c7a6>_0x1d6f03?_0x3c75e2['push'](_0x30d6cb['substring'](_0x5e69f5,_0x1d6f03)):_0x3c75e2['push'](_0x30d6cb['substring'](_0x5e69f5,_0x5e69f5+_0x43c7a6));return _0x3c75e2;};function x(_0x3d6885,_0x276720){for(const _0x49b60d in _0x3d6885)_0x3d6885['hasOwnProperty'](_0x49b60d)&&_0x276720(_0x49b60d,_0x3d6885[_0x49b60d]);}const ao=function(_0x59fcd2){f(!xn(_0x59fcd2),'Invalid\x20JSON\x20number');const _0x20b929=0xb,_0x13e1c7=0x34,_0x5c7701=(0x1<<_0x20b929-0x1)-0x1;let _0x5007bc,_0x46d6c7,_0xfc329d,_0xdf787d,_0x3827c9;_0x59fcd2===0x0?(_0x46d6c7=0x0,_0xfc329d=0x0,_0x5007bc=0x1/_0x59fcd2===-0x1/0x0?0x1:0x0):(_0x5007bc=_0x59fcd2<0x0,_0x59fcd2=Math['abs'](_0x59fcd2),_0x59fcd2>=Math['pow'](0x2,0x1-_0x5c7701)?(_0xdf787d=Math['min'](Math['floor'](Math['log'](_0x59fcd2)/Math['LN2']),_0x5c7701),_0x46d6c7=_0xdf787d+_0x5c7701,_0xfc329d=Math['round'](_0x59fcd2*Math['pow'](0x2,_0x13e1c7-_0xdf787d)-Math['pow'](0x2,_0x13e1c7))):(_0x46d6c7=0x0,_0xfc329d=Math['round'](_0x59fcd2/Math['pow'](0x2,0x1-_0x5c7701-_0x13e1c7))));const _0x25a8b2=[];for(_0x3827c9=_0x13e1c7;_0x3827c9;_0x3827c9-=0x1)_0x25a8b2['push'](_0xfc329d%0x2?0x1:0x0),_0xfc329d=Math['floor'](_0xfc329d/0x2);for(_0x3827c9=_0x20b929;_0x3827c9;_0x3827c9-=0x1)_0x25a8b2['push'](_0x46d6c7%0x2?0x1:0x0),_0x46d6c7=Math['floor'](_0x46d6c7/0x2);_0x25a8b2['push'](_0x5007bc?0x1:0x0),_0x25a8b2['reverse']();const _0x39bd11=_0x25a8b2['join']('');let _0x415ec3='';for(_0x3827c9=0x0;_0x3827c9<0x40;_0x3827c9+=0x8){let _0x1c7864=parseInt(_0x39bd11['substr'](_0x3827c9,0x8),0x2)['toString'](0x10);_0x1c7864['length']===0x1&&(_0x1c7864='0'+_0x1c7864),_0x415ec3=_0x415ec3+_0x1c7864;}return _0x415ec3['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x5f34a7,_0x558bfe){let _0x246c2f='Unknown\x20Error';_0x5f34a7==='too_big'?_0x246c2f='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x5f34a7==='permission_denied'?_0x246c2f='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x5f34a7==='unavailable'&&(_0x246c2f='The\x20service\x20is\x20unavailable');const _0x360fa5=new Error(_0x5f34a7+'\x20at\x20'+_0x558bfe['_path']['toString']()+':\x20'+_0x246c2f);return _0x360fa5['code']=_0x5f34a7['toUpperCase'](),_0x360fa5;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x10a934){if(Yl['test'](_0x10a934)){const _0x357aa9=Number(_0x10a934);if(_0x357aa9>=Ql&&_0x357aa9<=Jl)return _0x357aa9;}return null;},ft=function(_0x2b1cf7){try{_0x2b1cf7();}catch(_0xccc02){setTimeout(()=>{const _0x379aa7=_0xccc02['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x379aa7),_0xccc02;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x5e1062,_0xea522c){const _0x2fa16d=setTimeout(_0x5e1062,_0xea522c);return typeof _0x2fa16d=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x2fa16d):typeof _0x2fa16d=='object'&&_0x2fa16d['unref']&&_0x2fa16d['unref'](),_0x2fa16d;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x3e0da0,_0x536fab){this['appCheckProvider']=_0x536fab,this['appName']=_0x3e0da0['name'],$(_0x3e0da0)&&_0x3e0da0['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x3e0da0['settings']['appCheckToken']),this['appCheck']=_0x536fab==null?void 0x0:_0x536fab['getImmediate']({'optional':!0x0}),this['appCheck']||_0x536fab==null||_0x536fab['get']()['then'](_0x160619=>this['appCheck']=_0x160619);}['getToken'](_0x494796){if(this['serverAppAppCheckToken']){if(_0x494796)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x494796):new Promise((_0x107e7b,_0x1aa1b4)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x494796)['then'](_0x107e7b,_0x1aa1b4):_0x107e7b(null);},0x0);});}['addTokenChangeListener'](_0x58cd68){var _0xd8ec03;(_0xd8ec03=this['appCheckProvider'])==null||_0xd8ec03['get']()['then'](_0x3a946a=>_0x3a946a['addTokenListener'](_0x58cd68));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x14b015,_0x1758ee,_0x26b438){this['appName_']=_0x14b015,this['firebaseOptions_']=_0x1758ee,this['authProvider_']=_0x26b438,this['auth_']=null,this['auth_']=_0x26b438['getImmediate']({'optional':!0x0}),this['auth_']||_0x26b438['onInit'](_0x4de2e9=>this['auth_']=_0x4de2e9);}['getToken'](_0x151313){return this['auth_']?this['auth_']['getToken'](_0x151313)['catch'](_0x337994=>_0x337994&&_0x337994['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x337994)):new Promise((_0x730f51,_0x36c8cc)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x151313)['then'](_0x730f51,_0x36c8cc):_0x730f51(null);},0x0);});}['addTokenChangeListener'](_0x51bd72){this['auth_']?this['auth_']['addAuthTokenListener'](_0x51bd72):this['authProvider_']['get']()['then'](_0x47d308=>_0x47d308['addAuthTokenListener'](_0x51bd72));}['removeTokenChangeListener'](_0x45a23b){this['authProvider_']['get']()['then'](_0x4b248b=>_0x4b248b['removeAuthTokenListener'](_0x45a23b));}['notifyForInvalidToken'](){let _0x1d1d6c='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x1d1d6c+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x1d1d6c+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x1d1d6c+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x1d1d6c);}}class an{constructor(_0x5a410b){this['accessToken']=_0x5a410b;}['getToken'](_0xc6e714){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x3acf74){_0x3acf74(this['accessToken']);}['removeTokenChangeListener'](_0x28ac52){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x191b22,_0x19d970,_0x16dceb,_0x6e85b4,_0x480e1c=!0x1,_0x528829='',_0x47d595=!0x1,_0x1a9038=!0x1,_0x1c3912=null){this['secure']=_0x19d970,this['namespace']=_0x16dceb,this['webSocketOnly']=_0x6e85b4,this['nodeAdmin']=_0x480e1c,this['persistenceKey']=_0x528829,this['includeNamespaceInQueryParams']=_0x47d595,this['isUsingEmulator']=_0x1a9038,this['emulatorOptions']=_0x1c3912,this['_host']=_0x191b22['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x191b22)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0xb26ac3){_0xb26ac3!==this['internalHost']&&(this['internalHost']=_0xb26ac3,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x504d1d=this['toURLString']();return this['persistenceKey']&&(_0x504d1d+='<'+this['persistenceKey']+'>'),_0x504d1d;}['toURLString'](){const _0xb71698=this['secure']?'https://':'http://',_0x1d5132=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0xb71698+this['host']+'/'+_0x1d5132;}}function th(_0x38ee38){return _0x38ee38['host']!==_0x38ee38['internalHost']||_0x38ee38['isCustomHost']()||_0x38ee38['includeNamespaceInQueryParams'];}function vo(_0x505bdd,_0x1d34c1,_0xbbe125){f(typeof _0x1d34c1=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0xbbe125=='object','typeof\x20params\x20must\x20==\x20object');let _0x32e102;if(_0x1d34c1===go)_0x32e102=(_0x505bdd['secure']?'wss://':'ws://')+_0x505bdd['internalHost']+'/.ws?';else{if(_0x1d34c1===mo)_0x32e102=(_0x505bdd['secure']?'https://':'http://')+_0x505bdd['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x1d34c1);}th(_0x505bdd)&&(_0xbbe125['ns']=_0x505bdd['namespace']);const _0xc7d461=[];return x(_0xbbe125,(_0x46bd72,_0xa884ac)=>{_0xc7d461['push'](_0x46bd72+'='+_0xa884ac);}),_0x32e102+_0xc7d461['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x1b9ee8,_0xef7abe=0x1){Q(this['counters_'],_0x1b9ee8)||(this['counters_'][_0x1b9ee8]=0x0),this['counters_'][_0x1b9ee8]+=_0xef7abe;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x1b61d0){const _0x4a7484=_0x1b61d0['toString']();return oi[_0x4a7484]||(oi[_0x4a7484]=new nh()),oi[_0x4a7484];}function ih(_0x55a530,_0x53fdbb){const _0x124759=_0x55a530['toString']();return ai[_0x124759]||(ai[_0x124759]=_0x53fdbb()),ai[_0x124759];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x41098e){this['onMessage_']=_0x41098e,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x2066eb,_0x30c52e){this['closeAfterResponse']=_0x2066eb,this['onClose']=_0x30c52e,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x268fd5,_0x33a9fa){for(this['pendingResponses'][_0x268fd5]=_0x33a9fa;this['pendingResponses'][this['currentResponseNum']];){const _0x17d3a6=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x4f99ec=0x0;_0x4f99ec<_0x17d3a6['length'];++_0x4f99ec)_0x17d3a6[_0x4f99ec]&&ft(()=>{this['onMessage_'](_0x17d3a6[_0x4f99ec]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x284ba8,_0x2030d4,_0x354748,_0x3bd972,_0x31d1a4,_0xff3f1b,_0x9cd569){this['connId']=_0x284ba8,this['repoInfo']=_0x2030d4,this['applicationId']=_0x354748,this['appCheckToken']=_0x3bd972,this['authToken']=_0x31d1a4,this['transportSessionId']=_0xff3f1b,this['lastSessionId']=_0x9cd569,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x284ba8),this['stats_']=qi(_0x2030d4),this['urlFn']=_0xf872b3=>(this['appCheckToken']&&(_0xf872b3[wi]=this['appCheckToken']),vo(_0x2030d4,mo,_0xf872b3));}['open'](_0x4b46bd,_0x350d56){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x350d56,this['myPacketOrderer']=new sh(_0x4b46bd),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x4a2515)=>{const [_0x28efb5,_0x54a130,_0x2ed1b2,_0x1fbe82,_0x361320]=_0x4a2515;if(this['incrementIncomingBytes_'](_0x4a2515),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x28efb5===qs)this['id']=_0x54a130,this['password']=_0x2ed1b2;else{if(_0x28efb5===rh)_0x54a130?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x54a130,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x28efb5);}}},(..._0x16042b)=>{const [_0x237ed9,_0x4ef221]=_0x16042b;this['incrementIncomingBytes_'](_0x16042b),this['myPacketOrderer']['handleResponse'](_0x237ed9,_0x4ef221);},()=>{this['onClosed_']();},this['urlFn']);const _0x5b5086={};_0x5b5086[qs]='t',_0x5b5086[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x5b5086[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x5b5086[co]=Gi,this['transportSessionId']&&(_0x5b5086[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x5b5086[po]=this['lastSessionId']),this['applicationId']&&(_0x5b5086[_o]=this['applicationId']),this['appCheckToken']&&(_0x5b5086[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x5b5086[ho]=uo);const _0xd0dd2d=this['urlFn'](_0x5b5086);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0xd0dd2d),this['scriptTagHolder']['addTag'](_0xd0dd2d,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x4b0694){const _0x502948=O(_0x4b0694);this['bytesSent']+=_0x502948['length'],this['stats_']['incrementCounter']('bytes_sent',_0x502948['length']);const _0xb82703=$r(_0x502948),_0x2c099=oo(_0xb82703,fh);for(let _0xc81d03=0x0;_0xc81d03<_0x2c099['length'];_0xc81d03++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x2c099['length'],_0x2c099[_0xc81d03]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x57cca4,_0x2e09a4){this['myDisconnFrame']=document['createElement']('iframe');const _0x528058={};_0x528058[dh]='t',_0x528058[Eo]=_0x57cca4,_0x528058[Io]=_0x2e09a4,this['myDisconnFrame']['src']=this['urlFn'](_0x528058),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x446cad){const _0x8a8f79=O(_0x446cad)['length'];this['bytesReceived']+=_0x8a8f79,this['stats_']['incrementCounter']('bytes_received',_0x8a8f79);}}class zi{constructor(_0x67d34,_0x5af9d1,_0xf82303,_0x3eebb3){this['onDisconnect']=_0xf82303,this['urlFn']=_0x3eebb3,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x67d34,window[ah+this['uniqueCallbackIdentifier']]=_0x5af9d1,this['myIFrame']=zi['createIFrame_']();let _0x471c31='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x471c31='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x46395a='<html><body>'+_0x471c31+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x46395a),this['myIFrame']['doc']['close']();}catch(_0xe8cc66){L('frame\x20writing\x20exception'),_0xe8cc66['stack']&&L(_0xe8cc66['stack']),L(_0xe8cc66);}}}static['createIFrame_'](){const _0x2cb172=document['createElement']('iframe');if(_0x2cb172['style']['display']='none',document['body']){document['body']['appendChild'](_0x2cb172);try{_0x2cb172['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x15cae2=document['domain'];_0x2cb172['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x15cae2+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x2cb172['contentDocument']?_0x2cb172['doc']=_0x2cb172['contentDocument']:_0x2cb172['contentWindow']?_0x2cb172['doc']=_0x2cb172['contentWindow']['document']:_0x2cb172['document']&&(_0x2cb172['doc']=_0x2cb172['document']),_0x2cb172;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x24dd9f=this['onDisconnect'];_0x24dd9f&&(this['onDisconnect']=null,_0x24dd9f());}['startLongPoll'](_0x48f28d,_0x5c1bd8){for(this['myID']=_0x48f28d,this['myPW']=_0x5c1bd8,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x571965={};_0x571965[Eo]=this['myID'],_0x571965[Io]=this['myPW'],_0x571965[wo]=this['currentSerial'];let _0x533fc3=this['urlFn'](_0x571965),_0x5d2ea0='',_0x40a249=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x5d2ea0['length']<=Co;){const _0x3be0cf=this['pendingSegs']['shift']();_0x5d2ea0=_0x5d2ea0+'&'+lh+_0x40a249+'='+_0x3be0cf['seg']+'&'+hh+_0x40a249+'='+_0x3be0cf['ts']+'&'+uh+_0x40a249+'='+_0x3be0cf['d'],_0x40a249++;}return _0x533fc3=_0x533fc3+_0x5d2ea0,this['addLongPollTag_'](_0x533fc3,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x14547b,_0x50bab2,_0x5c8337){this['pendingSegs']['push']({'seg':_0x14547b,'ts':_0x50bab2,'d':_0x5c8337}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x5341c8,_0x48489b){this['outstandingRequests']['add'](_0x48489b);const _0x38f231=()=>{this['outstandingRequests']['delete'](_0x48489b),this['newRequest_']();},_0xf755e=setTimeout(_0x38f231,Math['floor'](ph)),_0x321ce1=()=>{clearTimeout(_0xf755e),_0x38f231();};this['addTag'](_0x5341c8,_0x321ce1);}['addTag'](_0x15c963,_0x1c21cf){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x419b64=this['myIFrame']['doc']['createElement']('script');_0x419b64['type']='text/javascript',_0x419b64['async']=!0x0,_0x419b64['src']=_0x15c963,_0x419b64['onload']=_0x419b64['onreadystatechange']=function(){const _0x4543de=_0x419b64['readyState'];(!_0x4543de||_0x4543de==='loaded'||_0x4543de==='complete')&&(_0x419b64['onload']=_0x419b64['onreadystatechange']=null,_0x419b64['parentNode']&&_0x419b64['parentNode']['removeChild'](_0x419b64),_0x1c21cf());},_0x419b64['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x15c963),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x419b64);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x5f17fd,_0x55be32,_0x1cf476,_0x277430,_0x588e0e,_0x3f1be1,_0x32c228){this['connId']=_0x5f17fd,this['applicationId']=_0x1cf476,this['appCheckToken']=_0x277430,this['authToken']=_0x588e0e,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x55be32),this['connURL']=q['connectionURL_'](_0x55be32,_0x3f1be1,_0x32c228,_0x277430,_0x1cf476),this['nodeAdmin']=_0x55be32['nodeAdmin'];}static['connectionURL_'](_0x569ffa,_0x29453d,_0x22cd41,_0x52af10,_0x333957){const _0x217f9d={};return _0x217f9d[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x217f9d[ho]=uo),_0x29453d&&(_0x217f9d[lo]=_0x29453d),_0x22cd41&&(_0x217f9d[po]=_0x22cd41),_0x52af10&&(_0x217f9d[wi]=_0x52af10),_0x333957&&(_0x217f9d[_o]=_0x333957),vo(_0x569ffa,go,_0x217f9d);}['open'](_0x860910,_0x5092a2){this['onDisconnect']=_0x5092a2,this['onMessage']=_0x860910,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x74aa1c;_c(),this['mySock']=new gn(this['connURL'],[],_0x74aa1c);}catch(_0x1a7ad4){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x4b4fc0=_0x1a7ad4['message']||_0x1a7ad4['data'];_0x4b4fc0&&this['log_'](_0x4b4fc0),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x3ea6a4=>{this['handleIncomingFrame'](_0x3ea6a4);},this['mySock']['onerror']=_0xc7a19d=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x35f4e1=_0xc7a19d['message']||_0xc7a19d['data'];_0x35f4e1&&this['log_'](_0x35f4e1),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x3393ef=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x1741e5=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x3f03ac=navigator['userAgent']['match'](_0x1741e5);_0x3f03ac&&_0x3f03ac['length']>0x1&&parseFloat(_0x3f03ac[0x1])<4.4&&(_0x3393ef=!0x0);}return!_0x3393ef&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x3ede7e){if(this['frames']['push'](_0x3ede7e),this['frames']['length']===this['totalFrames']){const _0xd9aaa5=this['frames']['join']('');this['frames']=null;const _0xefb63f=Nt(_0xd9aaa5);this['onMessage'](_0xefb63f);}}['handleNewFrameCount_'](_0x12e41c){this['totalFrames']=_0x12e41c,this['frames']=[];}['extractFrameCount_'](_0x5dd120){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x5dd120['length']<=0x6){const _0x9bcfba=Number(_0x5dd120);if(!isNaN(_0x9bcfba))return this['handleNewFrameCount_'](_0x9bcfba),null;}return this['handleNewFrameCount_'](0x1),_0x5dd120;}['handleIncomingFrame'](_0x236337){if(this['mySock']===null)return;const _0x158b87=_0x236337['data'];if(this['bytesReceived']+=_0x158b87['length'],this['stats_']['incrementCounter']('bytes_received',_0x158b87['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x158b87);else{const _0x58d41e=this['extractFrameCount_'](_0x158b87);_0x58d41e!==null&&this['appendFrame_'](_0x58d41e);}}['send'](_0x548bdb){this['resetKeepAlive']();const _0x21debf=O(_0x548bdb);this['bytesSent']+=_0x21debf['length'],this['stats_']['incrementCounter']('bytes_sent',_0x21debf['length']);const _0x27c3b0=oo(_0x21debf,gh);_0x27c3b0['length']>0x1&&this['sendString_'](String(_0x27c3b0['length']));for(let _0x34c70e=0x0;_0x34c70e<_0x27c3b0['length'];_0x34c70e++)this['sendString_'](_0x27c3b0[_0x34c70e]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x5a7ca1){try{this['mySock']['send'](_0x5a7ca1);}catch(_0x5c47c7){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x5c47c7['message']||_0x5c47c7['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x4b789d){this['initTransports_'](_0x4b789d);}['initTransports_'](_0x594d2f){const _0x135a49=q&&q['isAvailable']();let _0x8e0d55=_0x135a49&&!q['previouslyFailed']();if(_0x594d2f['webSocketOnly']&&(_0x135a49||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x8e0d55=!0x0),_0x8e0d55)this['transports_']=[q];else{const _0x4ec5f9=this['transports_']=[];for(const _0x3f1133 of Dt['ALL_TRANSPORTS'])_0x3f1133&&_0x3f1133['isAvailable']()&&_0x4ec5f9['push'](_0x3f1133);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0xa8315d,_0x25f77d,_0x2c1cf7,_0x2eeea8,_0x241ef0,_0x4d7cff,_0x4418bf,_0x1075e2,_0x4723e6,_0x1f4cb1){this['id']=_0xa8315d,this['repoInfo_']=_0x25f77d,this['applicationId_']=_0x2c1cf7,this['appCheckToken_']=_0x2eeea8,this['authToken_']=_0x241ef0,this['onMessage_']=_0x4d7cff,this['onReady_']=_0x4418bf,this['onDisconnect_']=_0x1075e2,this['onKill_']=_0x4723e6,this['lastSessionId']=_0x1f4cb1,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x25f77d),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x1230bb=this['transportManager_']['initialTransport']();this['conn_']=new _0x1230bb(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x1230bb['responsesRequiredToBeHealthy']||0x0;const _0x86ecb9=this['connReceiver_'](this['conn_']),_0x212dcc=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x86ecb9,_0x212dcc);},Math['floor'](0x0));const _0x45116=_0x1230bb['healthyTimeout']||0x0;_0x45116>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x45116)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x54260a){return _0x47ccfb=>{_0x54260a===this['conn_']?this['onConnectionLost_'](_0x47ccfb):_0x54260a===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x896ac2){return _0x110810=>{this['state_']!==0x2&&(_0x896ac2===this['rx_']?this['onPrimaryMessageReceived_'](_0x110810):_0x896ac2===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x110810):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x4f2d99){const _0x16e58b={'t':'d','d':_0x4f2d99};this['sendData_'](_0x16e58b);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x4d2d2b){if(ci in _0x4d2d2b){const _0x504e1b=_0x4d2d2b[ci];_0x504e1b===Ys?this['upgradeIfSecondaryHealthy_']():_0x504e1b===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x504e1b===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x22d652){const _0x4314c3=vt('t',_0x22d652),_0x2655fd=vt('d',_0x22d652);if(_0x4314c3==='c')this['onSecondaryControl_'](_0x2655fd);else{if(_0x4314c3==='d')this['pendingDataMessages']['push'](_0x2655fd);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x4314c3);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x2c6de5){const _0xf7ba48=vt('t',_0x2c6de5),_0x260d4d=vt('d',_0x2c6de5);_0xf7ba48==='c'?this['onControl_'](_0x260d4d):_0xf7ba48==='d'&&this['onDataMessage_'](_0x260d4d);}['onDataMessage_'](_0x2e6195){this['onPrimaryResponse_'](),this['onMessage_'](_0x2e6195);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x582e6d){const _0x2529d9=vt(ci,_0x582e6d);if(zs in _0x582e6d){const _0x5bc2eb=_0x582e6d[zs];if(_0x2529d9===Th){const _0x493cf4={..._0x5bc2eb};this['repoInfo_']['isUsingEmulator']&&(_0x493cf4['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x493cf4);}else{if(_0x2529d9===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x24542c=0x0;_0x24542c<this['pendingDataMessages']['length'];++_0x24542c)this['onDataMessage_'](this['pendingDataMessages'][_0x24542c]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x2529d9===wh?this['onConnectionShutdown_'](_0x5bc2eb):_0x2529d9===js?this['onReset_'](_0x5bc2eb):_0x2529d9===Ch?Ii('Server\x20Error:\x20'+_0x5bc2eb):_0x2529d9===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x2529d9);}}}['onHandshake_'](_0x5c4fdd){const _0x1fcb83=_0x5c4fdd['ts'],_0xca2130=_0x5c4fdd['v'],_0x4cb36b=_0x5c4fdd['h'];this['sessionId']=_0x5c4fdd['s'],this['repoInfo_']['host']=_0x4cb36b,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x1fcb83),Gi!==_0xca2130&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x56df99=this['transportManager_']['upgradeTransport']();_0x56df99&&this['startUpgrade_'](_0x56df99);}['startUpgrade_'](_0x24257c){this['secondaryConn_']=new _0x24257c(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x24257c['responsesRequiredToBeHealthy']||0x0;const _0x5369b1=this['connReceiver_'](this['secondaryConn_']),_0x524c8a=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x5369b1,_0x524c8a),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x5c6c3){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x5c6c3),this['repoInfo_']['host']=_0x5c6c3,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x5b3106,_0x486d29){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x5b3106,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x486d29,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x46f35e=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x46f35e||this['rx_']===_0x46f35e)&&this['close']();}['onConnectionLost_'](_0x243b08){this['conn_']=null,!_0x243b08&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x5cf644){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x5cf644),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x20a349){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x20a349);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x3c1c48,_0x37e0fa,_0x4dc1bb,_0x487ffa){}['merge'](_0x2c10a8,_0x3d267d,_0x1d496e,_0x5d6338){}['refreshAuthToken'](_0x3c3e45){}['refreshAppCheckToken'](_0xb244f9){}['onDisconnectPut'](_0x1271da,_0x2c8bc9,_0x269207){}['onDisconnectMerge'](_0x15ac63,_0x49a1bb,_0x4065e4){}['onDisconnectCancel'](_0x1b43cf,_0x9b554e){}['reportStats'](_0x3b3419){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x36ca2b){this['allowedEvents_']=_0x36ca2b,this['listeners_']={},f(Array['isArray'](_0x36ca2b)&&_0x36ca2b['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x558b98,..._0x5dc55c){if(Array['isArray'](this['listeners_'][_0x558b98])){const _0x4a7b20=[...this['listeners_'][_0x558b98]];for(let _0x17216b=0x0;_0x17216b<_0x4a7b20['length'];_0x17216b++)_0x4a7b20[_0x17216b]['callback']['apply'](_0x4a7b20[_0x17216b]['context'],_0x5dc55c);}}['on'](_0x33e6af,_0x5a0764,_0x554051){this['validateEventType_'](_0x33e6af),this['listeners_'][_0x33e6af]=this['listeners_'][_0x33e6af]||[],this['listeners_'][_0x33e6af]['push']({'callback':_0x5a0764,'context':_0x554051});const _0x5836fd=this['getInitialEvent'](_0x33e6af);_0x5836fd&&_0x5a0764['apply'](_0x554051,_0x5836fd);}['off'](_0x1b67e6,_0x38a433,_0x49e203){this['validateEventType_'](_0x1b67e6);const _0x4c05af=this['listeners_'][_0x1b67e6]||[];for(let _0x45a7df=0x0;_0x45a7df<_0x4c05af['length'];_0x45a7df++)if(_0x4c05af[_0x45a7df]['callback']===_0x38a433&&(!_0x49e203||_0x49e203===_0x4c05af[_0x45a7df]['context'])){_0x4c05af['splice'](_0x45a7df,0x1);return;}}['validateEventType_'](_0x3d5071){f(this['allowedEvents_']['find'](_0x19e9b8=>_0x19e9b8===_0x3d5071),'Unknown\x20event:\x20'+_0x3d5071);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x5bcf5c){return f(_0x5bcf5c==='online','Unknown\x20event\x20type:\x20'+_0x5bcf5c),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x37ae8c,_0x58d095){if(_0x58d095===void 0x0){this['pieces_']=_0x37ae8c['split']('/');let _0x448efc=0x0;for(let _0x5b46df=0x0;_0x5b46df<this['pieces_']['length'];_0x5b46df++)this['pieces_'][_0x5b46df]['length']>0x0&&(this['pieces_'][_0x448efc]=this['pieces_'][_0x5b46df],_0x448efc++);this['pieces_']['length']=_0x448efc,this['pieceNum_']=0x0;}else this['pieces_']=_0x37ae8c,this['pieceNum_']=_0x58d095;}['toString'](){let _0x42ec0e='';for(let _0x2884f9=this['pieceNum_'];_0x2884f9<this['pieces_']['length'];_0x2884f9++)this['pieces_'][_0x2884f9]!==''&&(_0x42ec0e+='/'+this['pieces_'][_0x2884f9]);return _0x42ec0e||'/';}}function w(){return new C('');}function y(_0x53bc60){return _0x53bc60['pieceNum_']>=_0x53bc60['pieces_']['length']?null:_0x53bc60['pieces_'][_0x53bc60['pieceNum_']];}function Ce(_0x2c30c2){return _0x2c30c2['pieces_']['length']-_0x2c30c2['pieceNum_'];}function S(_0x1dc5c5){let _0x55a058=_0x1dc5c5['pieceNum_'];return _0x55a058<_0x1dc5c5['pieces_']['length']&&_0x55a058++,new C(_0x1dc5c5['pieces_'],_0x55a058);}function ji(_0x51f28d){return _0x51f28d['pieceNum_']<_0x51f28d['pieces_']['length']?_0x51f28d['pieces_'][_0x51f28d['pieces_']['length']-0x1]:null;}function bh(_0x107d36){let _0x2df2f9='';for(let _0x122708=_0x107d36['pieceNum_'];_0x122708<_0x107d36['pieces_']['length'];_0x122708++)_0x107d36['pieces_'][_0x122708]!==''&&(_0x2df2f9+='/'+encodeURIComponent(String(_0x107d36['pieces_'][_0x122708])));return _0x2df2f9||'/';}function Mt(_0x3f4c19,_0x3b982a=0x0){return _0x3f4c19['pieces_']['slice'](_0x3f4c19['pieceNum_']+_0x3b982a);}function Ro(_0x2ed0ee){if(_0x2ed0ee['pieceNum_']>=_0x2ed0ee['pieces_']['length'])return null;const _0x57123f=[];for(let _0x8c625f=_0x2ed0ee['pieceNum_'];_0x8c625f<_0x2ed0ee['pieces_']['length']-0x1;_0x8c625f++)_0x57123f['push'](_0x2ed0ee['pieces_'][_0x8c625f]);return new C(_0x57123f,0x0);}function k(_0x59aa45,_0x39972f){const _0x4e9a4a=[];for(let _0x130d43=_0x59aa45['pieceNum_'];_0x130d43<_0x59aa45['pieces_']['length'];_0x130d43++)_0x4e9a4a['push'](_0x59aa45['pieces_'][_0x130d43]);if(_0x39972f instanceof C){for(let _0xb0f037=_0x39972f['pieceNum_'];_0xb0f037<_0x39972f['pieces_']['length'];_0xb0f037++)_0x4e9a4a['push'](_0x39972f['pieces_'][_0xb0f037]);}else{const _0x20f811=_0x39972f['split']('/');for(let _0x45a793=0x0;_0x45a793<_0x20f811['length'];_0x45a793++)_0x20f811[_0x45a793]['length']>0x0&&_0x4e9a4a['push'](_0x20f811[_0x45a793]);}return new C(_0x4e9a4a,0x0);}function v(_0x105a9e){return _0x105a9e['pieceNum_']>=_0x105a9e['pieces_']['length'];}function F(_0x3be53b,_0x5daef7){const _0xbf482f=y(_0x3be53b),_0x4342db=y(_0x5daef7);if(_0xbf482f===null)return _0x5daef7;if(_0xbf482f===_0x4342db)return F(S(_0x3be53b),S(_0x5daef7));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x5daef7+')\x20is\x20not\x20within\x20outerPath\x20('+_0x3be53b+')');}function Rh(_0xf82478,_0xdfce4d){const _0x3d9d9b=Mt(_0xf82478,0x0),_0x37ad08=Mt(_0xdfce4d,0x0);for(let _0x4feecf=0x0;_0x4feecf<_0x3d9d9b['length']&&_0x4feecf<_0x37ad08['length'];_0x4feecf++){const _0x526731=qe(_0x3d9d9b[_0x4feecf],_0x37ad08[_0x4feecf]);if(_0x526731!==0x0)return _0x526731;}return _0x3d9d9b['length']===_0x37ad08['length']?0x0:_0x3d9d9b['length']<_0x37ad08['length']?-0x1:0x1;}function Ki(_0x49f6a7,_0x1829ce){if(Ce(_0x49f6a7)!==Ce(_0x1829ce))return!0x1;for(let _0x420692=_0x49f6a7['pieceNum_'],_0x4aad82=_0x1829ce['pieceNum_'];_0x420692<=_0x49f6a7['pieces_']['length'];_0x420692++,_0x4aad82++)if(_0x49f6a7['pieces_'][_0x420692]!==_0x1829ce['pieces_'][_0x4aad82])return!0x1;return!0x0;}function G(_0x2d83da,_0x5e0f42){let _0x2d5d98=_0x2d83da['pieceNum_'],_0x148dd0=_0x5e0f42['pieceNum_'];if(Ce(_0x2d83da)>Ce(_0x5e0f42))return!0x1;for(;_0x2d5d98<_0x2d83da['pieces_']['length'];){if(_0x2d83da['pieces_'][_0x2d5d98]!==_0x5e0f42['pieces_'][_0x148dd0])return!0x1;++_0x2d5d98,++_0x148dd0;}return!0x0;}class Ah{constructor(_0x2e4b3d,_0x1edd90){this['errorPrefix_']=_0x1edd90,this['parts_']=Mt(_0x2e4b3d,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x506302=0x0;_0x506302<this['parts_']['length'];_0x506302++)this['byteLength_']+=Ln(this['parts_'][_0x506302]);Ao(this);}}function kh(_0x42f6ae,_0x5de360){_0x42f6ae['parts_']['length']>0x0&&(_0x42f6ae['byteLength_']+=0x1),_0x42f6ae['parts_']['push'](_0x5de360),_0x42f6ae['byteLength_']+=Ln(_0x5de360),Ao(_0x42f6ae);}function Ph(_0x415604){const _0x5205d2=_0x415604['parts_']['pop']();_0x415604['byteLength_']-=Ln(_0x5205d2),_0x415604['parts_']['length']>0x0&&(_0x415604['byteLength_']-=0x1);}function Ao(_0x254773){if(_0x254773['byteLength_']>Zs)throw new Error(_0x254773['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x254773['byteLength_']+').');if(_0x254773['parts_']['length']>Xs)throw new Error(_0x254773['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x254773));}function Oe(_0x41c5a0){return _0x41c5a0['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x41c5a0['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x31b07b,_0x5e668a;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x5e668a='visibilitychange',_0x31b07b='hidden'):typeof document['mozHidden']<'u'?(_0x5e668a='mozvisibilitychange',_0x31b07b='mozHidden'):typeof document['msHidden']<'u'?(_0x5e668a='msvisibilitychange',_0x31b07b='msHidden'):typeof document['webkitHidden']<'u'&&(_0x5e668a='webkitvisibilitychange',_0x31b07b='webkitHidden')),this['visible_']=!0x0,_0x5e668a&&document['addEventListener'](_0x5e668a,()=>{const _0xf7d7bf=!document[_0x31b07b];_0xf7d7bf!==this['visible_']&&(this['visible_']=_0xf7d7bf,this['trigger']('visible',_0xf7d7bf));},!0x1);}['getInitialEvent'](_0x5b709e){return f(_0x5b709e==='visible','Unknown\x20event\x20type:\x20'+_0x5b709e),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x132c41,_0x23a186,_0x1739db,_0x470ba8,_0x4c6f9d,_0x26cbf8,_0x4c2bed,_0x286105){if(super(),this['repoInfo_']=_0x132c41,this['applicationId_']=_0x23a186,this['onDataUpdate_']=_0x1739db,this['onConnectStatus_']=_0x470ba8,this['onServerInfoUpdate_']=_0x4c6f9d,this['authTokenProvider_']=_0x26cbf8,this['appCheckTokenProvider_']=_0x4c2bed,this['authOverride_']=_0x286105,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x286105)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x132c41['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x384872,_0x478737,_0x76462c){const _0x58738f=++this['requestNumber_'],_0x1de8a5={'r':_0x58738f,'a':_0x384872,'b':_0x478737};this['log_'](O(_0x1de8a5)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x1de8a5),_0x76462c&&(this['requestCBHash_'][_0x58738f]=_0x76462c);}['get'](_0x295f3f){this['initConnection_']();const _0x5b4e4b=new H(),_0x5012ff={'action':'g','request':{'p':_0x295f3f['_path']['toString'](),'q':_0x295f3f['_queryObject']},'onComplete':_0x3c5f9c=>{const _0x4de670=_0x3c5f9c['d'];_0x3c5f9c['s']==='ok'?_0x5b4e4b['resolve'](_0x4de670):_0x5b4e4b['reject'](_0x4de670);}};this['outstandingGets_']['push'](_0x5012ff),this['outstandingGetCount_']++;const _0x3f3b27=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x3f3b27),_0x5b4e4b['promise'];}['listen'](_0x35fb62,_0x4219dc,_0x440e97,_0xa6d648){this['initConnection_']();const _0x2c27d8=_0x35fb62['_queryIdentifier'],_0x88e59d=_0x35fb62['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x88e59d+'\x20'+_0x2c27d8),this['listens']['has'](_0x88e59d)||this['listens']['set'](_0x88e59d,new Map()),f(_0x35fb62['_queryParams']['isDefault']()||!_0x35fb62['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x88e59d)['has'](_0x2c27d8),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x776d00={'onComplete':_0xa6d648,'hashFn':_0x4219dc,'query':_0x35fb62,'tag':_0x440e97};this['listens']['get'](_0x88e59d)['set'](_0x2c27d8,_0x776d00),this['connected_']&&this['sendListen_'](_0x776d00);}['sendGet_'](_0x19afdc){const _0x380dd1=this['outstandingGets_'][_0x19afdc];this['sendRequest']('g',_0x380dd1['request'],_0xeee0b7=>{delete this['outstandingGets_'][_0x19afdc],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x380dd1['onComplete']&&_0x380dd1['onComplete'](_0xeee0b7);});}['sendListen_'](_0x5d1477){const _0x5a278c=_0x5d1477['query'],_0x2c55ec=_0x5a278c['_path']['toString'](),_0x3f7127=_0x5a278c['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x2c55ec+'\x20for\x20'+_0x3f7127);const _0x197da6={'p':_0x2c55ec},_0x31b0c8='q';_0x5d1477['tag']&&(_0x197da6['q']=_0x5a278c['_queryObject'],_0x197da6['t']=_0x5d1477['tag']),_0x197da6['h']=_0x5d1477['hashFn'](),this['sendRequest'](_0x31b0c8,_0x197da6,_0x385f21=>{const _0x3243d9=_0x385f21['d'],_0x1b9ea2=_0x385f21['s'];se['warnOnListenWarnings_'](_0x3243d9,_0x5a278c),(this['listens']['get'](_0x2c55ec)&&this['listens']['get'](_0x2c55ec)['get'](_0x3f7127))===_0x5d1477&&(this['log_']('listen\x20response',_0x385f21),_0x1b9ea2!=='ok'&&this['removeListen_'](_0x2c55ec,_0x3f7127),_0x5d1477['onComplete']&&_0x5d1477['onComplete'](_0x1b9ea2,_0x3243d9));});}static['warnOnListenWarnings_'](_0xa54e9e,_0x106b82){if(_0xa54e9e&&typeof _0xa54e9e=='object'&&Q(_0xa54e9e,'w')){const _0x695cd=Le(_0xa54e9e,'w');if(Array['isArray'](_0x695cd)&&~_0x695cd['indexOf']('no_index')){const _0x4f2a01='\x22.indexOn\x22:\x20\x22'+_0x106b82['_queryParams']['getIndex']()['toString']()+'\x22',_0x25ec0f=_0x106b82['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x4f2a01+'\x20at\x20'+_0x25ec0f+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x402fc7){this['authToken_']=_0x402fc7,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x402fc7);}['reduceReconnectDelayIfAdminCredential_'](_0x5c0b30){(_0x5c0b30&&_0x5c0b30['length']===0x28||wc(_0x5c0b30))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x1ffd74){this['appCheckToken_']=_0x1ffd74,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x2a9f89=this['authToken_'],_0x305559=Ic(_0x2a9f89)?'auth':'gauth',_0x10305a={'cred':_0x2a9f89};this['authOverride_']===null?_0x10305a['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x10305a['authvar']=this['authOverride_']),this['sendRequest'](_0x305559,_0x10305a,_0x247239=>{const _0x2fd22d=_0x247239['s'],_0x3a6c79=_0x247239['d']||'error';this['authToken_']===_0x2a9f89&&(_0x2fd22d==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x2fd22d,_0x3a6c79));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x308b5f=>{const _0x2f8ecf=_0x308b5f['s'],_0x200ea3=_0x308b5f['d']||'error';_0x2f8ecf==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x2f8ecf,_0x200ea3);});}['unlisten'](_0x1b9be1,_0x53ec71){const _0x26df65=_0x1b9be1['_path']['toString'](),_0x2fcce5=_0x1b9be1['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x26df65+'\x20'+_0x2fcce5),f(_0x1b9be1['_queryParams']['isDefault']()||!_0x1b9be1['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x26df65,_0x2fcce5)&&this['connected_']&&this['sendUnlisten_'](_0x26df65,_0x2fcce5,_0x1b9be1['_queryObject'],_0x53ec71);}['sendUnlisten_'](_0x1391e4,_0x1591ae,_0x1e6d26,_0x5b461a){this['log_']('Unlisten\x20on\x20'+_0x1391e4+'\x20for\x20'+_0x1591ae);const _0xe6342e={'p':_0x1391e4},_0x1aea6b='n';_0x5b461a&&(_0xe6342e['q']=_0x1e6d26,_0xe6342e['t']=_0x5b461a),this['sendRequest'](_0x1aea6b,_0xe6342e);}['onDisconnectPut'](_0xd88d60,_0x59b322,_0x2c5309){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0xd88d60,_0x59b322,_0x2c5309):this['onDisconnectRequestQueue_']['push']({'pathString':_0xd88d60,'action':'o','data':_0x59b322,'onComplete':_0x2c5309});}['onDisconnectMerge'](_0x1f345d,_0x471176,_0x3eb974){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x1f345d,_0x471176,_0x3eb974):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1f345d,'action':'om','data':_0x471176,'onComplete':_0x3eb974});}['onDisconnectCancel'](_0x4b2438,_0x27d977){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x4b2438,null,_0x27d977):this['onDisconnectRequestQueue_']['push']({'pathString':_0x4b2438,'action':'oc','data':null,'onComplete':_0x27d977});}['sendOnDisconnect_'](_0x55f134,_0x54c74e,_0x24506f,_0x263ab1){const _0x206442={'p':_0x54c74e,'d':_0x24506f};this['log_']('onDisconnect\x20'+_0x55f134,_0x206442),this['sendRequest'](_0x55f134,_0x206442,_0x33237d=>{_0x263ab1&&setTimeout(()=>{_0x263ab1(_0x33237d['s'],_0x33237d['d']);},Math['floor'](0x0));});}['put'](_0x305468,_0x4e5e23,_0x183a4f,_0x4c2ecd){this['putInternal']('p',_0x305468,_0x4e5e23,_0x183a4f,_0x4c2ecd);}['merge'](_0x4967e5,_0x3304da,_0x1b3a6b,_0x3ede15){this['putInternal']('m',_0x4967e5,_0x3304da,_0x1b3a6b,_0x3ede15);}['putInternal'](_0x52db7d,_0x4e6820,_0x158ab6,_0x43bf43,_0x4c1ce7){this['initConnection_']();const _0x3d6edf={'p':_0x4e6820,'d':_0x158ab6};_0x4c1ce7!==void 0x0&&(_0x3d6edf['h']=_0x4c1ce7),this['outstandingPuts_']['push']({'action':_0x52db7d,'request':_0x3d6edf,'onComplete':_0x43bf43}),this['outstandingPutCount_']++;const _0x18aa4c=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x18aa4c):this['log_']('Buffering\x20put:\x20'+_0x4e6820);}['sendPut_'](_0x4e43c2){const _0x1b8fd2=this['outstandingPuts_'][_0x4e43c2]['action'],_0x1e1fcf=this['outstandingPuts_'][_0x4e43c2]['request'],_0x3c46e8=this['outstandingPuts_'][_0x4e43c2]['onComplete'];this['outstandingPuts_'][_0x4e43c2]['queued']=this['connected_'],this['sendRequest'](_0x1b8fd2,_0x1e1fcf,_0x47eb3e=>{this['log_'](_0x1b8fd2+'\x20response',_0x47eb3e),delete this['outstandingPuts_'][_0x4e43c2],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x3c46e8&&_0x3c46e8(_0x47eb3e['s'],_0x47eb3e['d']);});}['reportStats'](_0x320aca){if(this['connected_']){const _0x282295={'c':_0x320aca};this['log_']('reportStats',_0x282295),this['sendRequest']('s',_0x282295,_0x43d218=>{if(_0x43d218['s']!=='ok'){const _0x157fa2=_0x43d218['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x157fa2);}});}}['onDataMessage_'](_0x37b656){if('r'in _0x37b656){this['log_']('from\x20server:\x20'+O(_0x37b656));const _0x5a2368=_0x37b656['r'],_0x2d205a=this['requestCBHash_'][_0x5a2368];_0x2d205a&&(delete this['requestCBHash_'][_0x5a2368],_0x2d205a(_0x37b656['b']));}else{if('error'in _0x37b656)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x37b656['error'];'a'in _0x37b656&&this['onDataPush_'](_0x37b656['a'],_0x37b656['b']);}}['onDataPush_'](_0x5baba6,_0x4e4fa9){this['log_']('handleServerMessage',_0x5baba6,_0x4e4fa9),_0x5baba6==='d'?this['onDataUpdate_'](_0x4e4fa9['p'],_0x4e4fa9['d'],!0x1,_0x4e4fa9['t']):_0x5baba6==='m'?this['onDataUpdate_'](_0x4e4fa9['p'],_0x4e4fa9['d'],!0x0,_0x4e4fa9['t']):_0x5baba6==='c'?this['onListenRevoked_'](_0x4e4fa9['p'],_0x4e4fa9['q']):_0x5baba6==='ac'?this['onAuthRevoked_'](_0x4e4fa9['s'],_0x4e4fa9['d']):_0x5baba6==='apc'?this['onAppCheckRevoked_'](_0x4e4fa9['s'],_0x4e4fa9['d']):_0x5baba6==='sd'?this['onSecurityDebugPacket_'](_0x4e4fa9):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x5baba6)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x5d78c4,_0x438f87){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x5d78c4),this['lastSessionId']=_0x438f87,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x2e3e04){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x2e3e04));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x23aeb0){_0x23aeb0&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x23aeb0;}['onOnline_'](_0x1ea2a1){_0x1ea2a1?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x253758=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x47d349=Math['max'](0x0,this['reconnectDelay_']-_0x253758);_0x47d349=Math['random']()*_0x47d349,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x47d349+'ms'),this['scheduleConnect_'](_0x47d349),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x18e191=this['onDataMessage_']['bind'](this),_0x5828e3=this['onReady_']['bind'](this),_0x15bd41=this['onRealtimeDisconnect_']['bind'](this),_0x50872e=this['id']+':'+se['nextConnectionId_']++,_0x1b2070=this['lastSessionId'];let _0x53d014=!0x1,_0x1bc295=null;const _0x36515f=function(){_0x1bc295?_0x1bc295['close']():(_0x53d014=!0x0,_0x15bd41());},_0x1413c5=function(_0xe74f41){f(_0x1bc295,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x1bc295['sendRequest'](_0xe74f41);};this['realtime_']={'close':_0x36515f,'sendRequest':_0x1413c5};const _0xe4b946=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x577064,_0x174793]=await Promise['all']([this['authTokenProvider_']['getToken'](_0xe4b946),this['appCheckTokenProvider_']['getToken'](_0xe4b946)]);_0x53d014?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x577064&&_0x577064['accessToken'],this['appCheckToken_']=_0x174793&&_0x174793['token'],_0x1bc295=new Sh(_0x50872e,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x18e191,_0x5828e3,_0x15bd41,_0x197041=>{U(_0x197041+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x1b2070));}catch(_0x443c2b){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x443c2b),_0x53d014||(this['repoInfo_']['nodeAdmin']&&U(_0x443c2b),_0x36515f());}}}['interrupt'](_0x59f0f0){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x59f0f0),this['interruptReasons_'][_0x59f0f0]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x516c66){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x516c66),delete this['interruptReasons_'][_0x516c66],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x9ead45){const _0x56497c=_0x9ead45-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x56497c});}['cancelSentTransactions_'](){for(let _0x3da018=0x0;_0x3da018<this['outstandingPuts_']['length'];_0x3da018++){const _0x1b8043=this['outstandingPuts_'][_0x3da018];_0x1b8043&&'h'in _0x1b8043['request']&&_0x1b8043['queued']&&(_0x1b8043['onComplete']&&_0x1b8043['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x3da018],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x5043bf,_0x4ffc99){let _0x368624;_0x4ffc99?_0x368624=_0x4ffc99['map'](_0x80d419=>$i(_0x80d419))['join']('$'):_0x368624='default';const _0xc95fe5=this['removeListen_'](_0x5043bf,_0x368624);_0xc95fe5&&_0xc95fe5['onComplete']&&_0xc95fe5['onComplete']('permission_denied');}['removeListen_'](_0x4b89a8,_0x5d6752){const _0x1596ad=new C(_0x4b89a8)['toString']();let _0x210561;if(this['listens']['has'](_0x1596ad)){const _0x17165b=this['listens']['get'](_0x1596ad);_0x210561=_0x17165b['get'](_0x5d6752),_0x17165b['delete'](_0x5d6752),_0x17165b['size']===0x0&&this['listens']['delete'](_0x1596ad);}else _0x210561=void 0x0;return _0x210561;}['onAuthRevoked_'](_0x27c294,_0x3ba700){L('Auth\x20token\x20revoked:\x20'+_0x27c294+'/'+_0x3ba700),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x27c294==='invalid_token'||_0x27c294==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x4d60f0,_0x585c07){L('App\x20check\x20token\x20revoked:\x20'+_0x4d60f0+'/'+_0x585c07),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x4d60f0==='invalid_token'||_0x4d60f0==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x136c7e){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x136c7e):'msg'in _0x136c7e&&console['log']('FIREBASE:\x20'+_0x136c7e['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x25eef8 of this['listens']['values']())for(const _0x2abbb7 of _0x25eef8['values']())this['sendListen_'](_0x2abbb7);for(let _0x5b624d=0x0;_0x5b624d<this['outstandingPuts_']['length'];_0x5b624d++)this['outstandingPuts_'][_0x5b624d]&&this['sendPut_'](_0x5b624d);for(;this['onDisconnectRequestQueue_']['length'];){const _0x1227a2=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x1227a2['action'],_0x1227a2['pathString'],_0x1227a2['data'],_0x1227a2['onComplete']);}for(let _0x40e9d8=0x0;_0x40e9d8<this['outstandingGets_']['length'];_0x40e9d8++)this['outstandingGets_'][_0x40e9d8]&&this['sendGet_'](_0x40e9d8);}['sendConnectStats_'](){const _0x115a0c={};let _0x188f82='js';_0x115a0c['sdk.'+_0x188f82+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x115a0c['framework.cordova']=0x1:Kr()&&(_0x115a0c['framework.reactnative']=0x1),this['reportStats'](_0x115a0c);}['shouldReconnect_'](){const _0x5cd9ff=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x5cd9ff;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x200ea0,_0x1ca157){this['name']=_0x200ea0,this['node']=_0x1ca157;}static['Wrap'](_0x29de40,_0x4667ad){return new E(_0x29de40,_0x4667ad);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x2fa446,_0xe90ae1){const _0x340b1b=new E(We,_0x2fa446),_0x3adbac=new E(We,_0xe90ae1);return this['compare'](_0x340b1b,_0x3adbac)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x3209c4){sn=_0x3209c4;}['compare'](_0xcdfe5e,_0x76b0fc){return qe(_0xcdfe5e['name'],_0x76b0fc['name']);}['isDefinedOn'](_0x3109e8){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x13f3ec,_0x2c39ab){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x19c81f,_0x20c8a3){return f(typeof _0x19c81f=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x19c81f,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0xb95dfb,_0x3bf24e,_0x3169ec,_0x1bdd89,_0x2f2189=null){this['isReverse_']=_0x1bdd89,this['resultGenerator_']=_0x2f2189,this['nodeStack_']=[];let _0x33eae8=0x1;for(;!_0xb95dfb['isEmpty']();)if(_0xb95dfb=_0xb95dfb,_0x33eae8=_0x3bf24e?_0x3169ec(_0xb95dfb['key'],_0x3bf24e):0x1,_0x1bdd89&&(_0x33eae8*=-0x1),_0x33eae8<0x0)this['isReverse_']?_0xb95dfb=_0xb95dfb['left']:_0xb95dfb=_0xb95dfb['right'];else{if(_0x33eae8===0x0){this['nodeStack_']['push'](_0xb95dfb);break;}else this['nodeStack_']['push'](_0xb95dfb),this['isReverse_']?_0xb95dfb=_0xb95dfb['right']:_0xb95dfb=_0xb95dfb['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x47c0f4=this['nodeStack_']['pop'](),_0x201922;if(this['resultGenerator_']?_0x201922=this['resultGenerator_'](_0x47c0f4['key'],_0x47c0f4['value']):_0x201922={'key':_0x47c0f4['key'],'value':_0x47c0f4['value']},this['isReverse_']){for(_0x47c0f4=_0x47c0f4['left'];!_0x47c0f4['isEmpty']();)this['nodeStack_']['push'](_0x47c0f4),_0x47c0f4=_0x47c0f4['right'];}else{for(_0x47c0f4=_0x47c0f4['right'];!_0x47c0f4['isEmpty']();)this['nodeStack_']['push'](_0x47c0f4),_0x47c0f4=_0x47c0f4['left'];}return _0x201922;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x8b3d53=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x8b3d53['key'],_0x8b3d53['value']):{'key':_0x8b3d53['key'],'value':_0x8b3d53['value']};}}class M{constructor(_0x4fb845,_0x5cf297,_0x2ed5e5,_0x3a5295,_0x590c7f){this['key']=_0x4fb845,this['value']=_0x5cf297,this['color']=_0x2ed5e5??M['RED'],this['left']=_0x3a5295??B['EMPTY_NODE'],this['right']=_0x590c7f??B['EMPTY_NODE'];}['copy'](_0x2f7ce8,_0x2d9302,_0xdb0052,_0x3084fd,_0x4d86b4){return new M(_0x2f7ce8??this['key'],_0x2d9302??this['value'],_0xdb0052??this['color'],_0x3084fd??this['left'],_0x4d86b4??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x219605){return this['left']['inorderTraversal'](_0x219605)||!!_0x219605(this['key'],this['value'])||this['right']['inorderTraversal'](_0x219605);}['reverseTraversal'](_0x365667){return this['right']['reverseTraversal'](_0x365667)||_0x365667(this['key'],this['value'])||this['left']['reverseTraversal'](_0x365667);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x5609bf,_0x13068b,_0x325f04){let _0xbdcbae=this;const _0x2b6d54=_0x325f04(_0x5609bf,_0xbdcbae['key']);return _0x2b6d54<0x0?_0xbdcbae=_0xbdcbae['copy'](null,null,null,_0xbdcbae['left']['insert'](_0x5609bf,_0x13068b,_0x325f04),null):_0x2b6d54===0x0?_0xbdcbae=_0xbdcbae['copy'](null,_0x13068b,null,null,null):_0xbdcbae=_0xbdcbae['copy'](null,null,null,null,_0xbdcbae['right']['insert'](_0x5609bf,_0x13068b,_0x325f04)),_0xbdcbae['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x49d446=this;return!_0x49d446['left']['isRed_']()&&!_0x49d446['left']['left']['isRed_']()&&(_0x49d446=_0x49d446['moveRedLeft_']()),_0x49d446=_0x49d446['copy'](null,null,null,_0x49d446['left']['removeMin_'](),null),_0x49d446['fixUp_']();}['remove'](_0xb5b58a,_0x8d53e1){let _0x35069a,_0x4111ac;if(_0x35069a=this,_0x8d53e1(_0xb5b58a,_0x35069a['key'])<0x0)!_0x35069a['left']['isEmpty']()&&!_0x35069a['left']['isRed_']()&&!_0x35069a['left']['left']['isRed_']()&&(_0x35069a=_0x35069a['moveRedLeft_']()),_0x35069a=_0x35069a['copy'](null,null,null,_0x35069a['left']['remove'](_0xb5b58a,_0x8d53e1),null);else{if(_0x35069a['left']['isRed_']()&&(_0x35069a=_0x35069a['rotateRight_']()),!_0x35069a['right']['isEmpty']()&&!_0x35069a['right']['isRed_']()&&!_0x35069a['right']['left']['isRed_']()&&(_0x35069a=_0x35069a['moveRedRight_']()),_0x8d53e1(_0xb5b58a,_0x35069a['key'])===0x0){if(_0x35069a['right']['isEmpty']())return B['EMPTY_NODE'];_0x4111ac=_0x35069a['right']['min_'](),_0x35069a=_0x35069a['copy'](_0x4111ac['key'],_0x4111ac['value'],null,null,_0x35069a['right']['removeMin_']());}_0x35069a=_0x35069a['copy'](null,null,null,null,_0x35069a['right']['remove'](_0xb5b58a,_0x8d53e1));}return _0x35069a['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x3505dd=this;return _0x3505dd['right']['isRed_']()&&!_0x3505dd['left']['isRed_']()&&(_0x3505dd=_0x3505dd['rotateLeft_']()),_0x3505dd['left']['isRed_']()&&_0x3505dd['left']['left']['isRed_']()&&(_0x3505dd=_0x3505dd['rotateRight_']()),_0x3505dd['left']['isRed_']()&&_0x3505dd['right']['isRed_']()&&(_0x3505dd=_0x3505dd['colorFlip_']()),_0x3505dd;}['moveRedLeft_'](){let _0x331e53=this['colorFlip_']();return _0x331e53['right']['left']['isRed_']()&&(_0x331e53=_0x331e53['copy'](null,null,null,null,_0x331e53['right']['rotateRight_']()),_0x331e53=_0x331e53['rotateLeft_'](),_0x331e53=_0x331e53['colorFlip_']()),_0x331e53;}['moveRedRight_'](){let _0x2cb31a=this['colorFlip_']();return _0x2cb31a['left']['left']['isRed_']()&&(_0x2cb31a=_0x2cb31a['rotateRight_'](),_0x2cb31a=_0x2cb31a['colorFlip_']()),_0x2cb31a;}['rotateLeft_'](){const _0x14cf22=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x14cf22,null);}['rotateRight_'](){const _0x1da122=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x1da122);}['colorFlip_'](){const _0x3fc50f=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x3f6f59=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x3fc50f,_0x3f6f59);}['checkMaxDepth_'](){const _0x3a33b2=this['check_']();return Math['pow'](0x2,_0x3a33b2)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x1609bf=this['left']['check_']();if(_0x1609bf!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x1609bf+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x182b38,_0x41c2ea,_0x5f134a,_0x137a90,_0x209e44){return this;}['insert'](_0x209516,_0x3217c5,_0xf03da){return new M(_0x209516,_0x3217c5,null);}['remove'](_0x315b37,_0x324be4){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x40c2ac){return!0x1;}['reverseTraversal'](_0x35e98a){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x14e932,_0x97b122=B['EMPTY_NODE']){this['comparator_']=_0x14e932,this['root_']=_0x97b122;}['insert'](_0x2847db,_0xd7e98a){return new B(this['comparator_'],this['root_']['insert'](_0x2847db,_0xd7e98a,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x1cf1bb){return new B(this['comparator_'],this['root_']['remove'](_0x1cf1bb,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x1af76d){let _0x3f696b,_0x5ce0b3=this['root_'];for(;!_0x5ce0b3['isEmpty']();){if(_0x3f696b=this['comparator_'](_0x1af76d,_0x5ce0b3['key']),_0x3f696b===0x0)return _0x5ce0b3['value'];_0x3f696b<0x0?_0x5ce0b3=_0x5ce0b3['left']:_0x3f696b>0x0&&(_0x5ce0b3=_0x5ce0b3['right']);}return null;}['getPredecessorKey'](_0x258908){let _0x4937bc,_0x583422=this['root_'],_0x4f8f95=null;for(;!_0x583422['isEmpty']();)if(_0x4937bc=this['comparator_'](_0x258908,_0x583422['key']),_0x4937bc===0x0){if(_0x583422['left']['isEmpty']())return _0x4f8f95?_0x4f8f95['key']:null;for(_0x583422=_0x583422['left'];!_0x583422['right']['isEmpty']();)_0x583422=_0x583422['right'];return _0x583422['key'];}else _0x4937bc<0x0?_0x583422=_0x583422['left']:_0x4937bc>0x0&&(_0x4f8f95=_0x583422,_0x583422=_0x583422['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x9b5d9d){return this['root_']['inorderTraversal'](_0x9b5d9d);}['reverseTraversal'](_0x834897){return this['root_']['reverseTraversal'](_0x834897);}['getIterator'](_0x21b354){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x21b354);}['getIteratorFrom'](_0x77ef29,_0x5a4406){return new rn(this['root_'],_0x77ef29,this['comparator_'],!0x1,_0x5a4406);}['getReverseIteratorFrom'](_0x5485a5,_0x35a642){return new rn(this['root_'],_0x5485a5,this['comparator_'],!0x0,_0x35a642);}['getReverseIterator'](_0x5568a0){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x5568a0);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x5ebc7e,_0x39a025){return qe(_0x5ebc7e['name'],_0x39a025['name']);}function Qi(_0x1b9463,_0x341687){return qe(_0x1b9463,_0x341687);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x4b8321){Ci=_0x4b8321;}const Po=function(_0xadb88a){return typeof _0xadb88a=='number'?'number:'+ao(_0xadb88a):'string:'+_0xadb88a;},No=function(_0x1cc059){if(_0x1cc059['isLeafNode']()){const _0x17392f=_0x1cc059['val']();f(typeof _0x17392f=='string'||typeof _0x17392f=='number'||typeof _0x17392f=='object'&&Q(_0x17392f,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x1cc059===Ci||_0x1cc059['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x1cc059===Ci||_0x1cc059['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x1396e9){nr=_0x1396e9;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x22973d,_0xaf69f6=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x22973d,this['priorityNode_']=_0xaf69f6,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x506b0f){return new D(this['value_'],_0x506b0f);}['getImmediateChild'](_0x35c8b5){return _0x35c8b5==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x3b4b81){return v(_0x3b4b81)?this:y(_0x3b4b81)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x48430d,_0x1b3a9c){return null;}['updateImmediateChild'](_0x1ff03c,_0x4ce328){return _0x1ff03c==='.priority'?this['updatePriority'](_0x4ce328):_0x4ce328['isEmpty']()&&_0x1ff03c!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x1ff03c,_0x4ce328)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x1e0911,_0x48763e){const _0x51da67=y(_0x1e0911);return _0x51da67===null?_0x48763e:_0x48763e['isEmpty']()&&_0x51da67!=='.priority'?this:(f(_0x51da67!=='.priority'||Ce(_0x1e0911)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x51da67,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x1e0911),_0x48763e)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x34b341,_0x43de8e){return!0x1;}['val'](_0x261bd5){return _0x261bd5&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x2d4705='';this['priorityNode_']['isEmpty']()||(_0x2d4705+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x506a40=typeof this['value_'];_0x2d4705+=_0x506a40+':',_0x506a40==='number'?_0x2d4705+=ao(this['value_']):_0x2d4705+=this['value_'],this['lazyHash_']=ro(_0x2d4705);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x2bb8a8){return _0x2bb8a8===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x2bb8a8 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x2bb8a8['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x2bb8a8));}['compareToLeafNode_'](_0x5f1bf3){const _0x4f4da7=typeof _0x5f1bf3['value_'],_0x589358=typeof this['value_'],_0x4c33f9=D['VALUE_TYPE_ORDER']['indexOf'](_0x4f4da7),_0x3e99e8=D['VALUE_TYPE_ORDER']['indexOf'](_0x589358);return f(_0x4c33f9>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x4f4da7),f(_0x3e99e8>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x589358),_0x4c33f9===_0x3e99e8?_0x589358==='object'?0x0:this['value_']<_0x5f1bf3['value_']?-0x1:this['value_']===_0x5f1bf3['value_']?0x0:0x1:_0x3e99e8-_0x4c33f9;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x90f882){if(_0x90f882===this)return!0x0;if(_0x90f882['isLeafNode']()){const _0x197a19=_0x90f882;return this['value_']===_0x197a19['value_']&&this['priorityNode_']['equals'](_0x197a19['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x41a540){Oo=_0x41a540;}function Wh(_0x3f93a1){Do=_0x3f93a1;}class Bh extends Fn{['compare'](_0x51da02,_0x33b949){const _0xcb9acf=_0x51da02['node']['getPriority'](),_0x531a80=_0x33b949['node']['getPriority'](),_0x5bf081=_0xcb9acf['compareTo'](_0x531a80);return _0x5bf081===0x0?qe(_0x51da02['name'],_0x33b949['name']):_0x5bf081;}['isDefinedOn'](_0x3b9a07){return!_0x3b9a07['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x5d0601,_0x589435){return!_0x5d0601['getPriority']()['equals'](_0x589435['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0xbdc84d,_0x88ff81){const _0x3a906f=Oo(_0xbdc84d);return new E(_0x88ff81,new D('[PRIORITY-POST]',_0x3a906f));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0xd2b92b){const _0x5e722f=_0x5ac548=>parseInt(Math['log'](_0x5ac548)/Vh,0xa),_0x4c4c20=_0x454420=>parseInt(Array(_0x454420+0x1)['join']('1'),0x2);this['count']=_0x5e722f(_0xd2b92b+0x1),this['current_']=this['count']-0x1;const _0x18a871=_0x4c4c20(this['count']);this['bits_']=_0xd2b92b+0x1&_0x18a871;}['nextBitIsOne'](){const _0x2bfa77=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x2bfa77;}}const yn=function(_0x356ca1,_0x1f8ea0,_0x246dec,_0x4b5b8c){_0x356ca1['sort'](_0x1f8ea0);const _0x5579b3=function(_0x541200,_0x3f02c0){const _0x3ec7b0=_0x3f02c0-_0x541200;let _0x3b89c6,_0x500a59;if(_0x3ec7b0===0x0)return null;if(_0x3ec7b0===0x1)return _0x3b89c6=_0x356ca1[_0x541200],_0x500a59=_0x246dec?_0x246dec(_0x3b89c6):_0x3b89c6,new M(_0x500a59,_0x3b89c6['node'],M['BLACK'],null,null);{const _0x354574=parseInt(_0x3ec7b0/0x2,0xa)+_0x541200,_0x44a852=_0x5579b3(_0x541200,_0x354574),_0x50b37b=_0x5579b3(_0x354574+0x1,_0x3f02c0);return _0x3b89c6=_0x356ca1[_0x354574],_0x500a59=_0x246dec?_0x246dec(_0x3b89c6):_0x3b89c6,new M(_0x500a59,_0x3b89c6['node'],M['BLACK'],_0x44a852,_0x50b37b);}},_0x449fad=function(_0x17ea99){let _0x2e88fc=null,_0x2aa9f9=null,_0x400d1a=_0x356ca1['length'];const _0xed33bb=function(_0x478f4a,_0x100413){const _0x1fcac1=_0x400d1a-_0x478f4a,_0x10b7ee=_0x400d1a;_0x400d1a-=_0x478f4a;const _0x5aa886=_0x5579b3(_0x1fcac1+0x1,_0x10b7ee),_0x123977=_0x356ca1[_0x1fcac1],_0x7886e0=_0x246dec?_0x246dec(_0x123977):_0x123977;_0x2a20af(new M(_0x7886e0,_0x123977['node'],_0x100413,null,_0x5aa886));},_0x2a20af=function(_0x1c1559){_0x2e88fc?(_0x2e88fc['left']=_0x1c1559,_0x2e88fc=_0x1c1559):(_0x2aa9f9=_0x1c1559,_0x2e88fc=_0x1c1559);};for(let _0xdc479d=0x0;_0xdc479d<_0x17ea99['count'];++_0xdc479d){const _0x19085c=_0x17ea99['nextBitIsOne'](),_0x3ead8a=Math['pow'](0x2,_0x17ea99['count']-(_0xdc479d+0x1));_0x19085c?_0xed33bb(_0x3ead8a,M['BLACK']):(_0xed33bb(_0x3ead8a,M['BLACK']),_0xed33bb(_0x3ead8a,M['RED']));}return _0x2aa9f9;},_0x505211=new Hh(_0x356ca1['length']),_0x59b631=_0x449fad(_0x505211);return new B(_0x4b5b8c||_0x1f8ea0,_0x59b631);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x3b8414,_0x2f9a12){this['indexes_']=_0x3b8414,this['indexSet_']=_0x2f9a12;}['get'](_0x324931){const _0xa1430c=Le(this['indexes_'],_0x324931);if(!_0xa1430c)throw new Error('No\x20index\x20defined\x20for\x20'+_0x324931);return _0xa1430c instanceof B?_0xa1430c:null;}['hasIndex'](_0x70d1c5){return Q(this['indexSet_'],_0x70d1c5['toString']());}['addIndex'](_0x5cac46,_0x58e9da){f(_0x5cac46!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x54a2d8=[];let _0x10fddb=!0x1;const _0x16cff2=_0x58e9da['getIterator'](E['Wrap']);let _0x193bef=_0x16cff2['getNext']();for(;_0x193bef;)_0x10fddb=_0x10fddb||_0x5cac46['isDefinedOn'](_0x193bef['node']),_0x54a2d8['push'](_0x193bef),_0x193bef=_0x16cff2['getNext']();let _0x501f36;_0x10fddb?_0x501f36=yn(_0x54a2d8,_0x5cac46['getCompare']()):_0x501f36=Qe;const _0x38819e=_0x5cac46['toString'](),_0x510843={...this['indexSet_']};_0x510843[_0x38819e]=_0x5cac46;const _0xd599e0={...this['indexes_']};return _0xd599e0[_0x38819e]=_0x501f36,new te(_0xd599e0,_0x510843);}['addToIndexes'](_0x255526,_0x1e9bfe){const _0x47a93e=_n(this['indexes_'],(_0x112244,_0x3a70ae)=>{const _0x5ef3a0=Le(this['indexSet_'],_0x3a70ae);if(f(_0x5ef3a0,'Missing\x20index\x20implementation\x20for\x20'+_0x3a70ae),_0x112244===Qe){if(_0x5ef3a0['isDefinedOn'](_0x255526['node'])){const _0x2536cd=[],_0x1a07ae=_0x1e9bfe['getIterator'](E['Wrap']);let _0x2e5e26=_0x1a07ae['getNext']();for(;_0x2e5e26;)_0x2e5e26['name']!==_0x255526['name']&&_0x2536cd['push'](_0x2e5e26),_0x2e5e26=_0x1a07ae['getNext']();return _0x2536cd['push'](_0x255526),yn(_0x2536cd,_0x5ef3a0['getCompare']());}else return Qe;}else{const _0x68b5c1=_0x1e9bfe['get'](_0x255526['name']);let _0x2c204d=_0x112244;return _0x68b5c1&&(_0x2c204d=_0x2c204d['remove'](new E(_0x255526['name'],_0x68b5c1))),_0x2c204d['insert'](_0x255526,_0x255526['node']);}});return new te(_0x47a93e,this['indexSet_']);}['removeFromIndexes'](_0x18ed89,_0x3ad575){const _0xae5ed7=_n(this['indexes_'],_0x198b51=>{if(_0x198b51===Qe)return _0x198b51;{const _0xa7aaea=_0x3ad575['get'](_0x18ed89['name']);return _0xa7aaea?_0x198b51['remove'](new E(_0x18ed89['name'],_0xa7aaea)):_0x198b51;}});return new te(_0xae5ed7,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x3fd976,_0x324b7d,_0x48a1cd){this['children_']=_0x3fd976,this['priorityNode_']=_0x324b7d,this['indexMap_']=_0x48a1cd,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x3a7392){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x3a7392,this['indexMap_']);}['getImmediateChild'](_0x1d8106){if(_0x1d8106==='.priority')return this['getPriority']();{const _0x410f9b=this['children_']['get'](_0x1d8106);return _0x410f9b===null?It:_0x410f9b;}}['getChild'](_0x4e16bc){const _0x14c027=y(_0x4e16bc);return _0x14c027===null?this:this['getImmediateChild'](_0x14c027)['getChild'](S(_0x4e16bc));}['hasChild'](_0x315658){return this['children_']['get'](_0x315658)!==null;}['updateImmediateChild'](_0x577d81,_0x32febf){if(f(_0x32febf,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x577d81==='.priority')return this['updatePriority'](_0x32febf);{const _0x4255ec=new E(_0x577d81,_0x32febf);let _0x46efd8,_0xae9e9d;_0x32febf['isEmpty']()?(_0x46efd8=this['children_']['remove'](_0x577d81),_0xae9e9d=this['indexMap_']['removeFromIndexes'](_0x4255ec,this['children_'])):(_0x46efd8=this['children_']['insert'](_0x577d81,_0x32febf),_0xae9e9d=this['indexMap_']['addToIndexes'](_0x4255ec,this['children_']));const _0x25484f=_0x46efd8['isEmpty']()?It:this['priorityNode_'];return new g(_0x46efd8,_0x25484f,_0xae9e9d);}}['updateChild'](_0x44849e,_0x26c3a3){const _0x53a509=y(_0x44849e);if(_0x53a509===null)return _0x26c3a3;{f(y(_0x44849e)!=='.priority'||Ce(_0x44849e)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x77f5ce=this['getImmediateChild'](_0x53a509)['updateChild'](S(_0x44849e),_0x26c3a3);return this['updateImmediateChild'](_0x53a509,_0x77f5ce);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x4ab4ef){if(this['isEmpty']())return null;const _0x203630={};let _0x28ef31=0x0,_0x82802f=0x0,_0x26eec4=!0x0;if(this['forEachChild'](R,(_0x4feb8b,_0x4756e5)=>{_0x203630[_0x4feb8b]=_0x4756e5['val'](_0x4ab4ef),_0x28ef31++,_0x26eec4&&g['INTEGER_REGEXP_']['test'](_0x4feb8b)?_0x82802f=Math['max'](_0x82802f,Number(_0x4feb8b)):_0x26eec4=!0x1;}),!_0x4ab4ef&&_0x26eec4&&_0x82802f<0x2*_0x28ef31){const _0x253efc=[];for(const _0x39c2c8 in _0x203630)_0x253efc[_0x39c2c8]=_0x203630[_0x39c2c8];return _0x253efc;}else return _0x4ab4ef&&!this['getPriority']()['isEmpty']()&&(_0x203630['.priority']=this['getPriority']()['val']()),_0x203630;}['hash'](){if(this['lazyHash_']===null){let _0x106313='';this['getPriority']()['isEmpty']()||(_0x106313+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x421bd7,_0x2f5b3a)=>{const _0xe1253e=_0x2f5b3a['hash']();_0xe1253e!==''&&(_0x106313+=':'+_0x421bd7+':'+_0xe1253e);}),this['lazyHash_']=_0x106313===''?'':ro(_0x106313);}return this['lazyHash_'];}['getPredecessorChildName'](_0x1c03cf,_0x1e8198,_0x89c51){const _0xf23cf1=this['resolveIndex_'](_0x89c51);if(_0xf23cf1){const _0x162ce4=_0xf23cf1['getPredecessorKey'](new E(_0x1c03cf,_0x1e8198));return _0x162ce4?_0x162ce4['name']:null;}else return this['children_']['getPredecessorKey'](_0x1c03cf);}['getFirstChildName'](_0x435cbe){const _0xb44a13=this['resolveIndex_'](_0x435cbe);if(_0xb44a13){const _0x45ef11=_0xb44a13['minKey']();return _0x45ef11&&_0x45ef11['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x3934dd){const _0x36241b=this['getFirstChildName'](_0x3934dd);return _0x36241b?new E(_0x36241b,this['children_']['get'](_0x36241b)):null;}['getLastChildName'](_0x46abea){const _0x12f365=this['resolveIndex_'](_0x46abea);if(_0x12f365){const _0x53eda6=_0x12f365['maxKey']();return _0x53eda6&&_0x53eda6['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x2f406e){const _0x3ee03b=this['getLastChildName'](_0x2f406e);return _0x3ee03b?new E(_0x3ee03b,this['children_']['get'](_0x3ee03b)):null;}['forEachChild'](_0x3ef90e,_0x16f009){const _0x437873=this['resolveIndex_'](_0x3ef90e);return _0x437873?_0x437873['inorderTraversal'](_0x54c729=>_0x16f009(_0x54c729['name'],_0x54c729['node'])):this['children_']['inorderTraversal'](_0x16f009);}['getIterator'](_0x5d9ada){return this['getIteratorFrom'](_0x5d9ada['minPost'](),_0x5d9ada);}['getIteratorFrom'](_0x462ea0,_0x4b4da7){const _0x164bf8=this['resolveIndex_'](_0x4b4da7);if(_0x164bf8)return _0x164bf8['getIteratorFrom'](_0x462ea0,_0x11311e=>_0x11311e);{const _0x3ab7c7=this['children_']['getIteratorFrom'](_0x462ea0['name'],E['Wrap']);let _0x3b530e=_0x3ab7c7['peek']();for(;_0x3b530e!=null&&_0x4b4da7['compare'](_0x3b530e,_0x462ea0)<0x0;)_0x3ab7c7['getNext'](),_0x3b530e=_0x3ab7c7['peek']();return _0x3ab7c7;}}['getReverseIterator'](_0xc9d60a){return this['getReverseIteratorFrom'](_0xc9d60a['maxPost'](),_0xc9d60a);}['getReverseIteratorFrom'](_0x4f7325,_0x2b0d6e){const _0x4bb549=this['resolveIndex_'](_0x2b0d6e);if(_0x4bb549)return _0x4bb549['getReverseIteratorFrom'](_0x4f7325,_0x1fd225=>_0x1fd225);{const _0x51fad1=this['children_']['getReverseIteratorFrom'](_0x4f7325['name'],E['Wrap']);let _0x13fcae=_0x51fad1['peek']();for(;_0x13fcae!=null&&_0x2b0d6e['compare'](_0x13fcae,_0x4f7325)>0x0;)_0x51fad1['getNext'](),_0x13fcae=_0x51fad1['peek']();return _0x51fad1;}}['compareTo'](_0x445484){return this['isEmpty']()?_0x445484['isEmpty']()?0x0:-0x1:_0x445484['isLeafNode']()||_0x445484['isEmpty']()?0x1:_0x445484===Kt?-0x1:0x0;}['withIndex'](_0x3a9b00){if(_0x3a9b00===ve||this['indexMap_']['hasIndex'](_0x3a9b00))return this;{const _0x230555=this['indexMap_']['addIndex'](_0x3a9b00,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x230555);}}['isIndexed'](_0x319f35){return _0x319f35===ve||this['indexMap_']['hasIndex'](_0x319f35);}['equals'](_0x14c5a2){if(_0x14c5a2===this)return!0x0;if(_0x14c5a2['isLeafNode']())return!0x1;{const _0x4fc6ae=_0x14c5a2;if(this['getPriority']()['equals'](_0x4fc6ae['getPriority']())){if(this['children_']['count']()===_0x4fc6ae['children_']['count']()){const _0x1a1879=this['getIterator'](R),_0x42784=_0x4fc6ae['getIterator'](R);let _0x1c94d5=_0x1a1879['getNext'](),_0x21a54d=_0x42784['getNext']();for(;_0x1c94d5&&_0x21a54d;){if(_0x1c94d5['name']!==_0x21a54d['name']||!_0x1c94d5['node']['equals'](_0x21a54d['node']))return!0x1;_0x1c94d5=_0x1a1879['getNext'](),_0x21a54d=_0x42784['getNext']();}return _0x1c94d5===null&&_0x21a54d===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x588be7){return _0x588be7===ve?null:this['indexMap_']['get'](_0x588be7['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x3fd3c3){return _0x3fd3c3===this?0x0:0x1;}['equals'](_0x4c188a){return _0x4c188a===this;}['getPriority'](){return this;}['getImmediateChild'](_0x5ca1f1){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x253361,_0x11099e=null){if(_0x253361===null)return g['EMPTY_NODE'];if(typeof _0x253361=='object'&&'.priority'in _0x253361&&(_0x11099e=_0x253361['.priority']),f(_0x11099e===null||typeof _0x11099e=='string'||typeof _0x11099e=='number'||typeof _0x11099e=='object'&&'.sv'in _0x11099e,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x11099e),typeof _0x253361=='object'&&'.value'in _0x253361&&_0x253361['.value']!==null&&(_0x253361=_0x253361['.value']),typeof _0x253361!='object'||'.sv'in _0x253361){const _0x4c37e9=_0x253361;return new D(_0x4c37e9,A(_0x11099e));}if(!(_0x253361 instanceof Array)&&Gh){const _0x44b15f=[];let _0x121c62=!0x1;if(x(_0x253361,(_0xc00c12,_0x1442c3)=>{if(_0xc00c12['substring'](0x0,0x1)!=='.'){const _0x3ae901=A(_0x1442c3);_0x3ae901['isEmpty']()||(_0x121c62=_0x121c62||!_0x3ae901['getPriority']()['isEmpty'](),_0x44b15f['push'](new E(_0xc00c12,_0x3ae901)));}}),_0x44b15f['length']===0x0)return g['EMPTY_NODE'];const _0x4fb5ed=yn(_0x44b15f,xh,_0x3fa2d8=>_0x3fa2d8['name'],Qi);if(_0x121c62){const _0x5a9870=yn(_0x44b15f,R['getCompare']());return new g(_0x4fb5ed,A(_0x11099e),new te({'.priority':_0x5a9870},{'.priority':R}));}else return new g(_0x4fb5ed,A(_0x11099e),te['Default']);}else{let _0x4d95ff=g['EMPTY_NODE'];return x(_0x253361,(_0x3a49f0,_0x1883e5)=>{if(Q(_0x253361,_0x3a49f0)&&_0x3a49f0['substring'](0x0,0x1)!=='.'){const _0x390d18=A(_0x1883e5);(_0x390d18['isLeafNode']()||!_0x390d18['isEmpty']())&&(_0x4d95ff=_0x4d95ff['updateImmediateChild'](_0x3a49f0,_0x390d18));}}),_0x4d95ff['updatePriority'](A(_0x11099e));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x2cf148){super(),this['indexPath_']=_0x2cf148,f(!v(_0x2cf148)&&y(_0x2cf148)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x4ed7f6){return _0x4ed7f6['getChild'](this['indexPath_']);}['isDefinedOn'](_0x591e5c){return!_0x591e5c['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x30542d,_0x4ca0f0){const _0x1c3817=this['extractChild'](_0x30542d['node']),_0x115503=this['extractChild'](_0x4ca0f0['node']),_0x2fc982=_0x1c3817['compareTo'](_0x115503);return _0x2fc982===0x0?qe(_0x30542d['name'],_0x4ca0f0['name']):_0x2fc982;}['makePost'](_0x4681b7,_0x4d186f){const _0x5450b0=A(_0x4681b7),_0x6af610=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x5450b0);return new E(_0x4d186f,_0x6af610);}['maxPost'](){const _0x44b4c9=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x44b4c9);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x3d4ddf,_0x2e83a8){const _0x5c1423=_0x3d4ddf['node']['compareTo'](_0x2e83a8['node']);return _0x5c1423===0x0?qe(_0x3d4ddf['name'],_0x2e83a8['name']):_0x5c1423;}['isDefinedOn'](_0x43a553){return!0x0;}['indexedValueChanged'](_0x11d88b,_0x1c402e){return!_0x11d88b['equals'](_0x1c402e);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x5f1ce5,_0x406100){const _0xa0d240=A(_0x5f1ce5);return new E(_0x406100,_0xa0d240);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x1b6aa3){return{'type':'value','snapshotNode':_0x1b6aa3};}function rt(_0x1e1b9a,_0x6d6381){return{'type':'child_added','snapshotNode':_0x6d6381,'childName':_0x1e1b9a};}function Lt(_0x37c527,_0x37e086){return{'type':'child_removed','snapshotNode':_0x37e086,'childName':_0x37c527};}function xt(_0x49ce19,_0x4f2dee,_0x291a14){return{'type':'child_changed','snapshotNode':_0x4f2dee,'childName':_0x49ce19,'oldSnap':_0x291a14};}function zh(_0x5525be,_0x237b8f){return{'type':'child_moved','snapshotNode':_0x237b8f,'childName':_0x5525be};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x47abae){this['index_']=_0x47abae;}['updateChild'](_0x1c65c1,_0x289874,_0x9d855f,_0x5c228b,_0x442af1,_0x57a4ab){f(_0x1c65c1['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x59e6ef=_0x1c65c1['getImmediateChild'](_0x289874);return _0x59e6ef['getChild'](_0x5c228b)['equals'](_0x9d855f['getChild'](_0x5c228b))&&_0x59e6ef['isEmpty']()===_0x9d855f['isEmpty']()||(_0x57a4ab!=null&&(_0x9d855f['isEmpty']()?_0x1c65c1['hasChild'](_0x289874)?_0x57a4ab['trackChildChange'](Lt(_0x289874,_0x59e6ef)):f(_0x1c65c1['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x59e6ef['isEmpty']()?_0x57a4ab['trackChildChange'](rt(_0x289874,_0x9d855f)):_0x57a4ab['trackChildChange'](xt(_0x289874,_0x9d855f,_0x59e6ef))),_0x1c65c1['isLeafNode']()&&_0x9d855f['isEmpty']())?_0x1c65c1:_0x1c65c1['updateImmediateChild'](_0x289874,_0x9d855f)['withIndex'](this['index_']);}['updateFullNode'](_0x2e2778,_0x535bb2,_0x367586){return _0x367586!=null&&(_0x2e2778['isLeafNode']()||_0x2e2778['forEachChild'](R,(_0x3f8b25,_0x3f8cf4)=>{_0x535bb2['hasChild'](_0x3f8b25)||_0x367586['trackChildChange'](Lt(_0x3f8b25,_0x3f8cf4));}),_0x535bb2['isLeafNode']()||_0x535bb2['forEachChild'](R,(_0xf5a820,_0x309d07)=>{if(_0x2e2778['hasChild'](_0xf5a820)){const _0x34d3e6=_0x2e2778['getImmediateChild'](_0xf5a820);_0x34d3e6['equals'](_0x309d07)||_0x367586['trackChildChange'](xt(_0xf5a820,_0x309d07,_0x34d3e6));}else _0x367586['trackChildChange'](rt(_0xf5a820,_0x309d07));})),_0x535bb2['withIndex'](this['index_']);}['updatePriority'](_0x480ff1,_0x1a37be){return _0x480ff1['isEmpty']()?g['EMPTY_NODE']:_0x480ff1['updatePriority'](_0x1a37be);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x4a66cb){this['indexedFilter_']=new Xi(_0x4a66cb['getIndex']()),this['index_']=_0x4a66cb['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x4a66cb),this['endPost_']=Ft['getEndPost_'](_0x4a66cb),this['startIsInclusive_']=!_0x4a66cb['startAfterSet_'],this['endIsInclusive_']=!_0x4a66cb['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0xa2a481){const _0x272458=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0xa2a481)<=0x0:this['index_']['compare'](this['getStartPost'](),_0xa2a481)<0x0,_0x2d7b50=this['endIsInclusive_']?this['index_']['compare'](_0xa2a481,this['getEndPost']())<=0x0:this['index_']['compare'](_0xa2a481,this['getEndPost']())<0x0;return _0x272458&&_0x2d7b50;}['updateChild'](_0x1ba3a3,_0x13164f,_0x4de92b,_0x57b0f8,_0x360a5e,_0xe69d50){return this['matches'](new E(_0x13164f,_0x4de92b))||(_0x4de92b=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x1ba3a3,_0x13164f,_0x4de92b,_0x57b0f8,_0x360a5e,_0xe69d50);}['updateFullNode'](_0x530ae0,_0x4627de,_0x598db9){_0x4627de['isLeafNode']()&&(_0x4627de=g['EMPTY_NODE']);let _0x2b7630=_0x4627de['withIndex'](this['index_']);_0x2b7630=_0x2b7630['updatePriority'](g['EMPTY_NODE']);const _0x4f7ab6=this;return _0x4627de['forEachChild'](R,(_0x255d2e,_0x359277)=>{_0x4f7ab6['matches'](new E(_0x255d2e,_0x359277))||(_0x2b7630=_0x2b7630['updateImmediateChild'](_0x255d2e,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x530ae0,_0x2b7630,_0x598db9);}['updatePriority'](_0x17c1d7,_0x85a174){return _0x17c1d7;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x2e0a9d){if(_0x2e0a9d['hasStart']()){const _0x292438=_0x2e0a9d['getIndexStartName']();return _0x2e0a9d['getIndex']()['makePost'](_0x2e0a9d['getIndexStartValue'](),_0x292438);}else return _0x2e0a9d['getIndex']()['minPost']();}static['getEndPost_'](_0x5c4c15){if(_0x5c4c15['hasEnd']()){const _0x4a4068=_0x5c4c15['getIndexEndName']();return _0x5c4c15['getIndex']()['makePost'](_0x5c4c15['getIndexEndValue'](),_0x4a4068);}else return _0x5c4c15['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x49a9bb){this['withinDirectionalStart']=_0x1f2d04=>this['reverse_']?this['withinEndPost'](_0x1f2d04):this['withinStartPost'](_0x1f2d04),this['withinDirectionalEnd']=_0x240895=>this['reverse_']?this['withinStartPost'](_0x240895):this['withinEndPost'](_0x240895),this['withinStartPost']=_0xe67123=>{const _0xfba1fa=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0xe67123);return this['startIsInclusive_']?_0xfba1fa<=0x0:_0xfba1fa<0x0;},this['withinEndPost']=_0x1d952d=>{const _0x3c3329=this['index_']['compare'](_0x1d952d,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x3c3329<=0x0:_0x3c3329<0x0;},this['rangedFilter_']=new Ft(_0x49a9bb),this['index_']=_0x49a9bb['getIndex'](),this['limit_']=_0x49a9bb['getLimit'](),this['reverse_']=!_0x49a9bb['isViewFromLeft'](),this['startIsInclusive_']=!_0x49a9bb['startAfterSet_'],this['endIsInclusive_']=!_0x49a9bb['endBeforeSet_'];}['updateChild'](_0x363717,_0x5ec1a3,_0x12a50d,_0x29619e,_0x52486d,_0x2f5585){return this['rangedFilter_']['matches'](new E(_0x5ec1a3,_0x12a50d))||(_0x12a50d=g['EMPTY_NODE']),_0x363717['getImmediateChild'](_0x5ec1a3)['equals'](_0x12a50d)?_0x363717:_0x363717['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x363717,_0x5ec1a3,_0x12a50d,_0x29619e,_0x52486d,_0x2f5585):this['fullLimitUpdateChild_'](_0x363717,_0x5ec1a3,_0x12a50d,_0x52486d,_0x2f5585);}['updateFullNode'](_0x4e49cd,_0x579ff0,_0x15aa9d){let _0x2634f4;if(_0x579ff0['isLeafNode']()||_0x579ff0['isEmpty']())_0x2634f4=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x579ff0['numChildren']()&&_0x579ff0['isIndexed'](this['index_'])){_0x2634f4=g['EMPTY_NODE']['withIndex'](this['index_']);let _0xdab582;this['reverse_']?_0xdab582=_0x579ff0['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0xdab582=_0x579ff0['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x11b9f6=0x0;for(;_0xdab582['hasNext']()&&_0x11b9f6<this['limit_'];){const _0x48ab9a=_0xdab582['getNext']();if(this['withinDirectionalStart'](_0x48ab9a)){if(this['withinDirectionalEnd'](_0x48ab9a))_0x2634f4=_0x2634f4['updateImmediateChild'](_0x48ab9a['name'],_0x48ab9a['node']),_0x11b9f6++;else break;}else continue;}}else{_0x2634f4=_0x579ff0['withIndex'](this['index_']),_0x2634f4=_0x2634f4['updatePriority'](g['EMPTY_NODE']);let _0x3ed1fe;this['reverse_']?_0x3ed1fe=_0x2634f4['getReverseIterator'](this['index_']):_0x3ed1fe=_0x2634f4['getIterator'](this['index_']);let _0x48f827=0x0;for(;_0x3ed1fe['hasNext']();){const _0x5c6f89=_0x3ed1fe['getNext']();_0x48f827<this['limit_']&&this['withinDirectionalStart'](_0x5c6f89)&&this['withinDirectionalEnd'](_0x5c6f89)?_0x48f827++:_0x2634f4=_0x2634f4['updateImmediateChild'](_0x5c6f89['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x4e49cd,_0x2634f4,_0x15aa9d);}['updatePriority'](_0x3f7a31,_0x33905c){return _0x3f7a31;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x239dd5,_0x259b8f,_0xf0e7c,_0x4964f9,_0x436152){let _0x1bf344;if(this['reverse_']){const _0x3b069c=this['index_']['getCompare']();_0x1bf344=(_0x475757,_0x3859f0)=>_0x3b069c(_0x3859f0,_0x475757);}else _0x1bf344=this['index_']['getCompare']();const _0x78742=_0x239dd5;f(_0x78742['numChildren']()===this['limit_'],'');const _0x53a5f3=new E(_0x259b8f,_0xf0e7c),_0x6b5691=this['reverse_']?_0x78742['getFirstChild'](this['index_']):_0x78742['getLastChild'](this['index_']),_0x339111=this['rangedFilter_']['matches'](_0x53a5f3);if(_0x78742['hasChild'](_0x259b8f)){const _0xcdc231=_0x78742['getImmediateChild'](_0x259b8f);let _0x3b0eea=_0x4964f9['getChildAfterChild'](this['index_'],_0x6b5691,this['reverse_']);for(;_0x3b0eea!=null&&(_0x3b0eea['name']===_0x259b8f||_0x78742['hasChild'](_0x3b0eea['name']));)_0x3b0eea=_0x4964f9['getChildAfterChild'](this['index_'],_0x3b0eea,this['reverse_']);const _0x4e376e=_0x3b0eea==null?0x1:_0x1bf344(_0x3b0eea,_0x53a5f3);if(_0x339111&&!_0xf0e7c['isEmpty']()&&_0x4e376e>=0x0)return _0x436152!=null&&_0x436152['trackChildChange'](xt(_0x259b8f,_0xf0e7c,_0xcdc231)),_0x78742['updateImmediateChild'](_0x259b8f,_0xf0e7c);{_0x436152!=null&&_0x436152['trackChildChange'](Lt(_0x259b8f,_0xcdc231));const _0x1de767=_0x78742['updateImmediateChild'](_0x259b8f,g['EMPTY_NODE']);return _0x3b0eea!=null&&this['rangedFilter_']['matches'](_0x3b0eea)?(_0x436152!=null&&_0x436152['trackChildChange'](rt(_0x3b0eea['name'],_0x3b0eea['node'])),_0x1de767['updateImmediateChild'](_0x3b0eea['name'],_0x3b0eea['node'])):_0x1de767;}}else return _0xf0e7c['isEmpty']()?_0x239dd5:_0x339111&&_0x1bf344(_0x6b5691,_0x53a5f3)>=0x0?(_0x436152!=null&&(_0x436152['trackChildChange'](Lt(_0x6b5691['name'],_0x6b5691['node'])),_0x436152['trackChildChange'](rt(_0x259b8f,_0xf0e7c))),_0x78742['updateImmediateChild'](_0x259b8f,_0xf0e7c)['updateImmediateChild'](_0x6b5691['name'],g['EMPTY_NODE'])):_0x239dd5;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x27526b=new Zi();return _0x27526b['limitSet_']=this['limitSet_'],_0x27526b['limit_']=this['limit_'],_0x27526b['startSet_']=this['startSet_'],_0x27526b['startAfterSet_']=this['startAfterSet_'],_0x27526b['indexStartValue_']=this['indexStartValue_'],_0x27526b['startNameSet_']=this['startNameSet_'],_0x27526b['indexStartName_']=this['indexStartName_'],_0x27526b['endSet_']=this['endSet_'],_0x27526b['endBeforeSet_']=this['endBeforeSet_'],_0x27526b['indexEndValue_']=this['indexEndValue_'],_0x27526b['endNameSet_']=this['endNameSet_'],_0x27526b['indexEndName_']=this['indexEndName_'],_0x27526b['index_']=this['index_'],_0x27526b['viewFrom_']=this['viewFrom_'],_0x27526b;}}function Kh(_0xd4bf22){return _0xd4bf22['loadsAllData']()?new Xi(_0xd4bf22['getIndex']()):_0xd4bf22['hasLimit']()?new jh(_0xd4bf22):new Ft(_0xd4bf22);}function Yh(_0x592b46,_0x53fe9a){const _0x17605d=_0x592b46['copy']();return _0x17605d['limitSet_']=!0x0,_0x17605d['limit_']=_0x53fe9a,_0x17605d['viewFrom_']='l',_0x17605d;}function Qh(_0x526ea7,_0x10b8f2,_0x2cc511){const _0x3cd01c=_0x526ea7['copy']();return _0x3cd01c['startSet_']=!0x0,_0x10b8f2===void 0x0&&(_0x10b8f2=null),_0x3cd01c['indexStartValue_']=_0x10b8f2,_0x2cc511!=null?(_0x3cd01c['startNameSet_']=!0x0,_0x3cd01c['indexStartName_']=_0x2cc511):(_0x3cd01c['startNameSet_']=!0x1,_0x3cd01c['indexStartName_']=''),_0x3cd01c;}function Jh(_0x41bc9c,_0x844e37,_0x50fa87){const _0x3d1a86=_0x41bc9c['copy']();return _0x3d1a86['endSet_']=!0x0,_0x844e37===void 0x0&&(_0x844e37=null),_0x3d1a86['indexEndValue_']=_0x844e37,_0x50fa87!==void 0x0?(_0x3d1a86['endNameSet_']=!0x0,_0x3d1a86['indexEndName_']=_0x50fa87):(_0x3d1a86['endNameSet_']=!0x1,_0x3d1a86['indexEndName_']=''),_0x3d1a86;}function xo(_0x2acd3,_0x46ea76){const _0x1b21a0=_0x2acd3['copy']();return _0x1b21a0['index_']=_0x46ea76,_0x1b21a0;}function ir(_0x3adaec){const _0x23002a={};if(_0x3adaec['isDefault']())return _0x23002a;let _0x456e92;if(_0x3adaec['index_']===R?_0x456e92='$priority':_0x3adaec['index_']===Mo?_0x456e92='$value':_0x3adaec['index_']===ve?_0x456e92='$key':(f(_0x3adaec['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x456e92=_0x3adaec['index_']['toString']()),_0x23002a['orderBy']=O(_0x456e92),_0x3adaec['startSet_']){const _0xc4b6ef=_0x3adaec['startAfterSet_']?'startAfter':'startAt';_0x23002a[_0xc4b6ef]=O(_0x3adaec['indexStartValue_']),_0x3adaec['startNameSet_']&&(_0x23002a[_0xc4b6ef]+=','+O(_0x3adaec['indexStartName_']));}if(_0x3adaec['endSet_']){const _0x49fad2=_0x3adaec['endBeforeSet_']?'endBefore':'endAt';_0x23002a[_0x49fad2]=O(_0x3adaec['indexEndValue_']),_0x3adaec['endNameSet_']&&(_0x23002a[_0x49fad2]+=','+O(_0x3adaec['indexEndName_']));}return _0x3adaec['limitSet_']&&(_0x3adaec['isViewFromLeft']()?_0x23002a['limitToFirst']=_0x3adaec['limit_']:_0x23002a['limitToLast']=_0x3adaec['limit_']),_0x23002a;}function sr(_0x988997){const _0xcf3c19={};if(_0x988997['startSet_']&&(_0xcf3c19['sp']=_0x988997['indexStartValue_'],_0x988997['startNameSet_']&&(_0xcf3c19['sn']=_0x988997['indexStartName_']),_0xcf3c19['sin']=!_0x988997['startAfterSet_']),_0x988997['endSet_']&&(_0xcf3c19['ep']=_0x988997['indexEndValue_'],_0x988997['endNameSet_']&&(_0xcf3c19['en']=_0x988997['indexEndName_']),_0xcf3c19['ein']=!_0x988997['endBeforeSet_']),_0x988997['limitSet_']){_0xcf3c19['l']=_0x988997['limit_'];let _0x5ee444=_0x988997['viewFrom_'];_0x5ee444===''&&(_0x988997['isViewFromLeft']()?_0x5ee444='l':_0x5ee444='r'),_0xcf3c19['vf']=_0x5ee444;}return _0x988997['index_']!==R&&(_0xcf3c19['i']=_0x988997['index_']['toString']()),_0xcf3c19;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x388d67){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x49586b,_0x26ca2c){return _0x26ca2c!==void 0x0?'tag$'+_0x26ca2c:(f(_0x49586b['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x49586b['_path']['toString']());}constructor(_0x23e7ba,_0x23c695,_0x38a190,_0xe0a85f){super(),this['repoInfo_']=_0x23e7ba,this['onDataUpdate_']=_0x23c695,this['authTokenProvider_']=_0x38a190,this['appCheckTokenProvider_']=_0xe0a85f,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0xf12969,_0x1544bc,_0xa80379,_0x24fca3){const _0x16a491=_0xf12969['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x16a491+'\x20'+_0xf12969['_queryIdentifier']);const _0x547c54=vn['getListenId_'](_0xf12969,_0xa80379),_0x582bb8={};this['listens_'][_0x547c54]=_0x582bb8;const _0x5bd1d8=ir(_0xf12969['_queryParams']);this['restRequest_'](_0x16a491+'.json',_0x5bd1d8,(_0x12b6d8,_0x512ed9)=>{let _0xdcc7e9=_0x512ed9;if(_0x12b6d8===0x194&&(_0xdcc7e9=null,_0x12b6d8=null),_0x12b6d8===null&&this['onDataUpdate_'](_0x16a491,_0xdcc7e9,!0x1,_0xa80379),Le(this['listens_'],_0x547c54)===_0x582bb8){let _0x3f87e9;_0x12b6d8?_0x12b6d8===0x191?_0x3f87e9='permission_denied':_0x3f87e9='rest_error:'+_0x12b6d8:_0x3f87e9='ok',_0x24fca3(_0x3f87e9,null);}});}['unlisten'](_0x59c1c0,_0x3e2096){const _0x403fc6=vn['getListenId_'](_0x59c1c0,_0x3e2096);delete this['listens_'][_0x403fc6];}['get'](_0x1d29f8){const _0x36fb8b=ir(_0x1d29f8['_queryParams']),_0x56a5f4=_0x1d29f8['_path']['toString'](),_0x1fa23f=new H();return this['restRequest_'](_0x56a5f4+'.json',_0x36fb8b,(_0x94cb68,_0x4a9ee6)=>{let _0x115259=_0x4a9ee6;_0x94cb68===0x194&&(_0x115259=null,_0x94cb68=null),_0x94cb68===null?(this['onDataUpdate_'](_0x56a5f4,_0x115259,!0x1,null),_0x1fa23f['resolve'](_0x115259)):_0x1fa23f['reject'](new Error(_0x115259));}),_0x1fa23f['promise'];}['refreshAuthToken'](_0x40db05){}['restRequest_'](_0x2453b2,_0x2500a5={},_0x32ce72){return _0x2500a5['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x527501,_0x5daeb6])=>{_0x527501&&_0x527501['accessToken']&&(_0x2500a5['auth']=_0x527501['accessToken']),_0x5daeb6&&_0x5daeb6['token']&&(_0x2500a5['ac']=_0x5daeb6['token']);const _0x2dbc04=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x2453b2+'?ns='+this['repoInfo_']['namespace']+ut(_0x2500a5);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x2dbc04);const _0x48e263=new XMLHttpRequest();_0x48e263['onreadystatechange']=()=>{if(_0x32ce72&&_0x48e263['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x2dbc04+'\x20received.\x20status:',_0x48e263['status'],'response:',_0x48e263['responseText']);let _0x169bdf=null;if(_0x48e263['status']>=0xc8&&_0x48e263['status']<0x12c){try{_0x169bdf=Nt(_0x48e263['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x2dbc04+':\x20'+_0x48e263['responseText']);}_0x32ce72(null,_0x169bdf);}else _0x48e263['status']!==0x191&&_0x48e263['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x2dbc04+'\x20Status:\x20'+_0x48e263['status']),_0x32ce72(_0x48e263['status']);_0x32ce72=null;}},_0x48e263['open']('GET',_0x2dbc04,!0x0),_0x48e263['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x5f2cc2){return this['rootNode_']['getChild'](_0x5f2cc2);}['updateSnapshot'](_0x5b4240,_0x1e214a){this['rootNode_']=this['rootNode_']['updateChild'](_0x5b4240,_0x1e214a);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x33e4e9,_0x9c9097,_0x2d87a9){if(v(_0x9c9097))_0x33e4e9['value']=_0x2d87a9,_0x33e4e9['children']['clear']();else{if(_0x33e4e9['value']!==null)_0x33e4e9['value']=_0x33e4e9['value']['updateChild'](_0x9c9097,_0x2d87a9);else{const _0x2b87fb=y(_0x9c9097);_0x33e4e9['children']['has'](_0x2b87fb)||_0x33e4e9['children']['set'](_0x2b87fb,En());const _0x56ed05=_0x33e4e9['children']['get'](_0x2b87fb);_0x9c9097=S(_0x9c9097),pt(_0x56ed05,_0x9c9097,_0x2d87a9);}}}function Ti(_0x3beb2b,_0x4184f7){if(v(_0x4184f7))return _0x3beb2b['value']=null,_0x3beb2b['children']['clear'](),!0x0;if(_0x3beb2b['value']!==null){if(_0x3beb2b['value']['isLeafNode']())return!0x1;{const _0x36dcdc=_0x3beb2b['value'];return _0x3beb2b['value']=null,_0x36dcdc['forEachChild'](R,(_0x3130c2,_0x214d47)=>{pt(_0x3beb2b,new C(_0x3130c2),_0x214d47);}),Ti(_0x3beb2b,_0x4184f7);}}else{if(_0x3beb2b['children']['size']>0x0){const _0x54a647=y(_0x4184f7);return _0x4184f7=S(_0x4184f7),_0x3beb2b['children']['has'](_0x54a647)&&Ti(_0x3beb2b['children']['get'](_0x54a647),_0x4184f7)&&_0x3beb2b['children']['delete'](_0x54a647),_0x3beb2b['children']['size']===0x0;}else return!0x0;}}function Si(_0x277e3f,_0x4ce8fb,_0x819336){_0x277e3f['value']!==null?_0x819336(_0x4ce8fb,_0x277e3f['value']):Zh(_0x277e3f,(_0x1f8fca,_0x410aac)=>{const _0x269668=new C(_0x4ce8fb['toString']()+'/'+_0x1f8fca);Si(_0x410aac,_0x269668,_0x819336);});}function Zh(_0x196f1e,_0x285885){_0x196f1e['children']['forEach']((_0x44b686,_0x2fb375)=>{_0x285885(_0x2fb375,_0x44b686);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x35a80a){this['collection_']=_0x35a80a,this['last_']=null;}['get'](){const _0x159c3a=this['collection_']['get'](),_0x43b0d5={..._0x159c3a};return this['last_']&&x(this['last_'],(_0x53760a,_0x9668d7)=>{_0x43b0d5[_0x53760a]=_0x43b0d5[_0x53760a]-_0x9668d7;}),this['last_']=_0x159c3a,_0x43b0d5;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x1dc1a3,_0x1af0e9){this['server_']=_0x1af0e9,this['statsToReport_']={},this['statsListener_']=new eu(_0x1dc1a3);const _0x3a0cc0=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x3a0cc0));}['reportStats_'](){const _0x578b24=this['statsListener_']['get'](),_0x215768={};let _0x549fc6=!0x1;x(_0x578b24,(_0x3d61a1,_0x116b63)=>{_0x116b63>0x0&&Q(this['statsToReport_'],_0x3d61a1)&&(_0x215768[_0x3d61a1]=_0x116b63,_0x549fc6=!0x0);}),_0x549fc6&&this['server_']['reportStats'](_0x215768),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x1d080f){_0x1d080f[_0x1d080f['OVERWRITE']=0x0]='OVERWRITE',_0x1d080f[_0x1d080f['MERGE']=0x1]='MERGE',_0x1d080f[_0x1d080f['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x1d080f[_0x1d080f['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x47f346){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x47f346,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x40ab5c,_0xbbd3bb,_0x1757ae){this['path']=_0x40ab5c,this['affectedTree']=_0xbbd3bb,this['revert']=_0x1757ae,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x1c7676){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x384069=this['affectedTree']['subtree'](new C(_0x1c7676));return new In(w(),_0x384069,this['revert']);}}else return f(y(this['path'])===_0x1c7676,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0xca74fd,_0x247dce){this['source']=_0xca74fd,this['path']=_0x247dce,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0xd8f272){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x190f53,_0x16d372,_0x578f93){this['source']=_0x190f53,this['path']=_0x16d372,this['snap']=_0x578f93,this['type']=z['OVERWRITE'];}['operationForChild'](_0x2d0bd0){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x2d0bd0)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x43c599,_0x587cd9,_0x5b43c0){this['source']=_0x43c599,this['path']=_0x587cd9,this['children']=_0x5b43c0,this['type']=z['MERGE'];}['operationForChild'](_0x528f9d){if(v(this['path'])){const _0xb3db7b=this['children']['subtree'](new C(_0x528f9d));return _0xb3db7b['isEmpty']()?null:_0xb3db7b['value']?new Be(this['source'],w(),_0xb3db7b['value']):new ot(this['source'],w(),_0xb3db7b);}else return f(y(this['path'])===_0x528f9d,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x2a443c,_0x473eb0,_0x14a758){this['node_']=_0x2a443c,this['fullyInitialized_']=_0x473eb0,this['filtered_']=_0x14a758;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x15d2da){if(v(_0x15d2da))return this['isFullyInitialized']()&&!this['filtered_'];const _0x85cbe=y(_0x15d2da);return this['isCompleteForChild'](_0x85cbe);}['isCompleteForChild'](_0x315b4d){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x315b4d);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x19480f){this['query_']=_0x19480f,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x321bca,_0x356f17,_0x18d49a,_0x5d33ae){const _0x456509=[],_0x58cfaa=[];return _0x356f17['forEach'](_0x45a990=>{_0x45a990['type']==='child_changed'&&_0x321bca['index_']['indexedValueChanged'](_0x45a990['oldSnap'],_0x45a990['snapshotNode'])&&_0x58cfaa['push'](zh(_0x45a990['childName'],_0x45a990['snapshotNode']));}),wt(_0x321bca,_0x456509,'child_removed',_0x356f17,_0x5d33ae,_0x18d49a),wt(_0x321bca,_0x456509,'child_added',_0x356f17,_0x5d33ae,_0x18d49a),wt(_0x321bca,_0x456509,'child_moved',_0x58cfaa,_0x5d33ae,_0x18d49a),wt(_0x321bca,_0x456509,'child_changed',_0x356f17,_0x5d33ae,_0x18d49a),wt(_0x321bca,_0x456509,'value',_0x356f17,_0x5d33ae,_0x18d49a),_0x456509;}function wt(_0x3f7567,_0x589b91,_0x49c53b,_0x2f60d5,_0x5ebee3,_0x3e4436){const _0x2b1d73=_0x2f60d5['filter'](_0x111823=>_0x111823['type']===_0x49c53b);_0x2b1d73['sort']((_0x11196f,_0x3128d9)=>au(_0x3f7567,_0x11196f,_0x3128d9)),_0x2b1d73['forEach'](_0x2cd8fd=>{const _0xa94834=ou(_0x3f7567,_0x2cd8fd,_0x3e4436);_0x5ebee3['forEach'](_0x51e7da=>{_0x51e7da['respondsTo'](_0x2cd8fd['type'])&&_0x589b91['push'](_0x51e7da['createEvent'](_0xa94834,_0x3f7567['query_']));});});}function ou(_0x505e39,_0x150483,_0x3586f5){return _0x150483['type']==='value'||_0x150483['type']==='child_removed'||(_0x150483['prevName']=_0x3586f5['getPredecessorChildName'](_0x150483['childName'],_0x150483['snapshotNode'],_0x505e39['index_'])),_0x150483;}function au(_0x3525fe,_0x4a1089,_0x4fa055){if(_0x4a1089['childName']==null||_0x4fa055['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x3eb522=new E(_0x4a1089['childName'],_0x4a1089['snapshotNode']),_0x541597=new E(_0x4fa055['childName'],_0x4fa055['snapshotNode']);return _0x3525fe['index_']['compare'](_0x3eb522,_0x541597);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x4e7dfd,_0x4d51c4){return{'eventCache':_0x4e7dfd,'serverCache':_0x4d51c4};}function Rt(_0x3d435b,_0x208a6e,_0x302dc1,_0x585501){return Un(new Te(_0x208a6e,_0x302dc1,_0x585501),_0x3d435b['serverCache']);}function Fo(_0x3b5ab4,_0x4d6f83,_0x472eb6,_0x35a974){return Un(_0x3b5ab4['eventCache'],new Te(_0x4d6f83,_0x472eb6,_0x35a974));}function wn(_0x5b0b4a){return _0x5b0b4a['eventCache']['isFullyInitialized']()?_0x5b0b4a['eventCache']['getNode']():null;}function Ve(_0x43aaf0){return _0x43aaf0['serverCache']['isFullyInitialized']()?_0x43aaf0['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x4b22be){let _0x4a34b5=new b(null);return x(_0x4b22be,(_0x30e19f,_0x2bf313)=>{_0x4a34b5=_0x4a34b5['set'](new C(_0x30e19f),_0x2bf313);}),_0x4a34b5;}constructor(_0x251b95,_0x2dc2da=cu()){this['value']=_0x251b95,this['children']=_0x2dc2da;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x448c4b,_0x33e2d9){if(this['value']!=null&&_0x33e2d9(this['value']))return{'path':w(),'value':this['value']};if(v(_0x448c4b))return null;{const _0x30dcf0=y(_0x448c4b),_0x2abf10=this['children']['get'](_0x30dcf0);if(_0x2abf10!==null){const _0x352285=_0x2abf10['findRootMostMatchingPathAndValue'](S(_0x448c4b),_0x33e2d9);return _0x352285!=null?{'path':k(new C(_0x30dcf0),_0x352285['path']),'value':_0x352285['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x31808c){return this['findRootMostMatchingPathAndValue'](_0x31808c,()=>!0x0);}['subtree'](_0x31191a){if(v(_0x31191a))return this;{const _0x383f69=y(_0x31191a),_0x33c93b=this['children']['get'](_0x383f69);return _0x33c93b!==null?_0x33c93b['subtree'](S(_0x31191a)):new b(null);}}['set'](_0x4fc924,_0x4a9b87){if(v(_0x4fc924))return new b(_0x4a9b87,this['children']);{const _0x23428d=y(_0x4fc924),_0x1fa117=(this['children']['get'](_0x23428d)||new b(null))['set'](S(_0x4fc924),_0x4a9b87),_0x6ae798=this['children']['insert'](_0x23428d,_0x1fa117);return new b(this['value'],_0x6ae798);}}['remove'](_0x183294){if(v(_0x183294))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x5d3210=y(_0x183294),_0xbb71d0=this['children']['get'](_0x5d3210);if(_0xbb71d0){const _0x3866f3=_0xbb71d0['remove'](S(_0x183294));let _0x1d3a61;return _0x3866f3['isEmpty']()?_0x1d3a61=this['children']['remove'](_0x5d3210):_0x1d3a61=this['children']['insert'](_0x5d3210,_0x3866f3),this['value']===null&&_0x1d3a61['isEmpty']()?new b(null):new b(this['value'],_0x1d3a61);}else return this;}}['get'](_0x1b4f64){if(v(_0x1b4f64))return this['value'];{const _0x3df4d1=y(_0x1b4f64),_0x3aac44=this['children']['get'](_0x3df4d1);return _0x3aac44?_0x3aac44['get'](S(_0x1b4f64)):null;}}['setTree'](_0x23ab5d,_0x58ab02){if(v(_0x23ab5d))return _0x58ab02;{const _0x264798=y(_0x23ab5d),_0x517ccd=(this['children']['get'](_0x264798)||new b(null))['setTree'](S(_0x23ab5d),_0x58ab02);let _0x4753ae;return _0x517ccd['isEmpty']()?_0x4753ae=this['children']['remove'](_0x264798):_0x4753ae=this['children']['insert'](_0x264798,_0x517ccd),new b(this['value'],_0x4753ae);}}['fold'](_0x550a69){return this['fold_'](w(),_0x550a69);}['fold_'](_0x1f114e,_0x4f9672){const _0xd67c5d={};return this['children']['inorderTraversal']((_0xa3b513,_0x8236d5)=>{_0xd67c5d[_0xa3b513]=_0x8236d5['fold_'](k(_0x1f114e,_0xa3b513),_0x4f9672);}),_0x4f9672(_0x1f114e,this['value'],_0xd67c5d);}['findOnPath'](_0xf52270,_0x586860){return this['findOnPath_'](_0xf52270,w(),_0x586860);}['findOnPath_'](_0x27e126,_0x5a1bba,_0x237ea9){const _0x289cdf=this['value']?_0x237ea9(_0x5a1bba,this['value']):!0x1;if(_0x289cdf)return _0x289cdf;if(v(_0x27e126))return null;{const _0x5ec9a8=y(_0x27e126),_0x3abe42=this['children']['get'](_0x5ec9a8);return _0x3abe42?_0x3abe42['findOnPath_'](S(_0x27e126),k(_0x5a1bba,_0x5ec9a8),_0x237ea9):null;}}['foreachOnPath'](_0x901f41,_0x7825ae){return this['foreachOnPath_'](_0x901f41,w(),_0x7825ae);}['foreachOnPath_'](_0xb35ef,_0x473f6a,_0x585235){if(v(_0xb35ef))return this;{this['value']&&_0x585235(_0x473f6a,this['value']);const _0x224f86=y(_0xb35ef),_0x55aa7c=this['children']['get'](_0x224f86);return _0x55aa7c?_0x55aa7c['foreachOnPath_'](S(_0xb35ef),k(_0x473f6a,_0x224f86),_0x585235):new b(null);}}['foreach'](_0x5053e0){this['foreach_'](w(),_0x5053e0);}['foreach_'](_0x980728,_0x39533d){this['children']['inorderTraversal']((_0x2fea53,_0x33a325)=>{_0x33a325['foreach_'](k(_0x980728,_0x2fea53),_0x39533d);}),this['value']&&_0x39533d(_0x980728,this['value']);}['foreachChild'](_0x16af94){this['children']['inorderTraversal']((_0x171070,_0x21fae8)=>{_0x21fae8['value']&&_0x16af94(_0x171070,_0x21fae8['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x1a7348){this['writeTree_']=_0x1a7348;}static['empty'](){return new K(new b(null));}}function At(_0x44d3bc,_0x2c57fd,_0x31916b){if(v(_0x2c57fd))return new K(new b(_0x31916b));{const _0x43a1ee=_0x44d3bc['writeTree_']['findRootMostValueAndPath'](_0x2c57fd);if(_0x43a1ee!=null){const _0xcc49be=_0x43a1ee['path'];let _0x4b45dd=_0x43a1ee['value'];const _0x4a26b3=F(_0xcc49be,_0x2c57fd);return _0x4b45dd=_0x4b45dd['updateChild'](_0x4a26b3,_0x31916b),new K(_0x44d3bc['writeTree_']['set'](_0xcc49be,_0x4b45dd));}else{const _0x46be8b=new b(_0x31916b),_0x350e31=_0x44d3bc['writeTree_']['setTree'](_0x2c57fd,_0x46be8b);return new K(_0x350e31);}}}function bi(_0x5cc437,_0x3ace05,_0x367bef){let _0x2c37ad=_0x5cc437;return x(_0x367bef,(_0x338d3f,_0x2306a6)=>{_0x2c37ad=At(_0x2c37ad,k(_0x3ace05,_0x338d3f),_0x2306a6);}),_0x2c37ad;}function or(_0x4ff3a8,_0xa72ad5){if(v(_0xa72ad5))return K['empty']();{const _0x1c8698=_0x4ff3a8['writeTree_']['setTree'](_0xa72ad5,new b(null));return new K(_0x1c8698);}}function Ri(_0x3bff5e,_0x462e4a){return ze(_0x3bff5e,_0x462e4a)!=null;}function ze(_0xce1563,_0x2d6d84){const _0x21c18f=_0xce1563['writeTree_']['findRootMostValueAndPath'](_0x2d6d84);return _0x21c18f!=null?_0xce1563['writeTree_']['get'](_0x21c18f['path'])['getChild'](F(_0x21c18f['path'],_0x2d6d84)):null;}function ar(_0x2460af){const _0x1580d6=[],_0x449a80=_0x2460af['writeTree_']['value'];return _0x449a80!=null?_0x449a80['isLeafNode']()||_0x449a80['forEachChild'](R,(_0x17d40e,_0xc82d3b)=>{_0x1580d6['push'](new E(_0x17d40e,_0xc82d3b));}):_0x2460af['writeTree_']['children']['inorderTraversal']((_0x29863d,_0x518465)=>{_0x518465['value']!=null&&_0x1580d6['push'](new E(_0x29863d,_0x518465['value']));}),_0x1580d6;}function Ee(_0x312862,_0x5c7e7a){if(v(_0x5c7e7a))return _0x312862;{const _0x2f5d08=ze(_0x312862,_0x5c7e7a);return _0x2f5d08!=null?new K(new b(_0x2f5d08)):new K(_0x312862['writeTree_']['subtree'](_0x5c7e7a));}}function Ai(_0x2b8b81){return _0x2b8b81['writeTree_']['isEmpty']();}function at(_0x54b696,_0x4e590a){return Uo(w(),_0x54b696['writeTree_'],_0x4e590a);}function Uo(_0xce6079,_0x5f1905,_0x18b194){if(_0x5f1905['value']!=null)return _0x18b194['updateChild'](_0xce6079,_0x5f1905['value']);{let _0x3ad49d=null;return _0x5f1905['children']['inorderTraversal']((_0x2c3086,_0x2c971a)=>{_0x2c3086==='.priority'?(f(_0x2c971a['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x3ad49d=_0x2c971a['value']):_0x18b194=Uo(k(_0xce6079,_0x2c3086),_0x2c971a,_0x18b194);}),!_0x18b194['getChild'](_0xce6079)['isEmpty']()&&_0x3ad49d!==null&&(_0x18b194=_0x18b194['updateChild'](k(_0xce6079,'.priority'),_0x3ad49d)),_0x18b194;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x52f70d,_0x22a62d){return Ho(_0x22a62d,_0x52f70d);}function lu(_0x3e4f22,_0x233b44,_0x455e57,_0x56b387,_0x4ae4b8){f(_0x56b387>_0x3e4f22['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x4ae4b8===void 0x0&&(_0x4ae4b8=!0x0),_0x3e4f22['allWrites']['push']({'path':_0x233b44,'snap':_0x455e57,'writeId':_0x56b387,'visible':_0x4ae4b8}),_0x4ae4b8&&(_0x3e4f22['visibleWrites']=At(_0x3e4f22['visibleWrites'],_0x233b44,_0x455e57)),_0x3e4f22['lastWriteId']=_0x56b387;}function hu(_0x102573,_0x5c7e4d,_0x58e82e,_0x3045e4){f(_0x3045e4>_0x102573['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x102573['allWrites']['push']({'path':_0x5c7e4d,'children':_0x58e82e,'writeId':_0x3045e4,'visible':!0x0}),_0x102573['visibleWrites']=bi(_0x102573['visibleWrites'],_0x5c7e4d,_0x58e82e),_0x102573['lastWriteId']=_0x3045e4;}function uu(_0x5a8f65,_0x2526a3){for(let _0x518501=0x0;_0x518501<_0x5a8f65['allWrites']['length'];_0x518501++){const _0x5aa47c=_0x5a8f65['allWrites'][_0x518501];if(_0x5aa47c['writeId']===_0x2526a3)return _0x5aa47c;}return null;}function du(_0x27160f,_0x966733){const _0xe355e8=_0x27160f['allWrites']['findIndex'](_0x542161=>_0x542161['writeId']===_0x966733);f(_0xe355e8>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x4b3a02=_0x27160f['allWrites'][_0xe355e8];_0x27160f['allWrites']['splice'](_0xe355e8,0x1);let _0x36dc79=_0x4b3a02['visible'],_0x110015=!0x1,_0x45005=_0x27160f['allWrites']['length']-0x1;for(;_0x36dc79&&_0x45005>=0x0;){const _0x8f4ade=_0x27160f['allWrites'][_0x45005];_0x8f4ade['visible']&&(_0x45005>=_0xe355e8&&fu(_0x8f4ade,_0x4b3a02['path'])?_0x36dc79=!0x1:G(_0x4b3a02['path'],_0x8f4ade['path'])&&(_0x110015=!0x0)),_0x45005--;}if(_0x36dc79){if(_0x110015)return pu(_0x27160f),!0x0;if(_0x4b3a02['snap'])_0x27160f['visibleWrites']=or(_0x27160f['visibleWrites'],_0x4b3a02['path']);else{const _0x528808=_0x4b3a02['children'];x(_0x528808,_0x2ec73b=>{_0x27160f['visibleWrites']=or(_0x27160f['visibleWrites'],k(_0x4b3a02['path'],_0x2ec73b));});}return!0x0;}else return!0x1;}function fu(_0x1f4782,_0x2f7e1c){if(_0x1f4782['snap'])return G(_0x1f4782['path'],_0x2f7e1c);for(const _0x2216bd in _0x1f4782['children'])if(_0x1f4782['children']['hasOwnProperty'](_0x2216bd)&&G(k(_0x1f4782['path'],_0x2216bd),_0x2f7e1c))return!0x0;return!0x1;}function pu(_0x3dde41){_0x3dde41['visibleWrites']=Wo(_0x3dde41['allWrites'],_u,w()),_0x3dde41['allWrites']['length']>0x0?_0x3dde41['lastWriteId']=_0x3dde41['allWrites'][_0x3dde41['allWrites']['length']-0x1]['writeId']:_0x3dde41['lastWriteId']=-0x1;}function _u(_0x5498a0){return _0x5498a0['visible'];}function Wo(_0x575b3c,_0x3f3498,_0x3374ed){let _0x597140=K['empty']();for(let _0x321c5e=0x0;_0x321c5e<_0x575b3c['length'];++_0x321c5e){const _0x121e11=_0x575b3c[_0x321c5e];if(_0x3f3498(_0x121e11)){const _0x537be0=_0x121e11['path'];let _0x3ce6a;if(_0x121e11['snap'])G(_0x3374ed,_0x537be0)?(_0x3ce6a=F(_0x3374ed,_0x537be0),_0x597140=At(_0x597140,_0x3ce6a,_0x121e11['snap'])):G(_0x537be0,_0x3374ed)&&(_0x3ce6a=F(_0x537be0,_0x3374ed),_0x597140=At(_0x597140,w(),_0x121e11['snap']['getChild'](_0x3ce6a)));else{if(_0x121e11['children']){if(G(_0x3374ed,_0x537be0))_0x3ce6a=F(_0x3374ed,_0x537be0),_0x597140=bi(_0x597140,_0x3ce6a,_0x121e11['children']);else{if(G(_0x537be0,_0x3374ed)){if(_0x3ce6a=F(_0x537be0,_0x3374ed),v(_0x3ce6a))_0x597140=bi(_0x597140,w(),_0x121e11['children']);else{const _0x187f1e=Le(_0x121e11['children'],y(_0x3ce6a));if(_0x187f1e){const _0x44032c=_0x187f1e['getChild'](S(_0x3ce6a));_0x597140=At(_0x597140,w(),_0x44032c);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x597140;}function Bo(_0x5c5377,_0x3fb4f7,_0x33796a,_0x32fcc3,_0x1fa7d1){if(!_0x32fcc3&&!_0x1fa7d1){const _0x8198a4=ze(_0x5c5377['visibleWrites'],_0x3fb4f7);if(_0x8198a4!=null)return _0x8198a4;{const _0x4474f4=Ee(_0x5c5377['visibleWrites'],_0x3fb4f7);if(Ai(_0x4474f4))return _0x33796a;if(_0x33796a==null&&!Ri(_0x4474f4,w()))return null;{const _0x4fffde=_0x33796a||g['EMPTY_NODE'];return at(_0x4474f4,_0x4fffde);}}}else{const _0x275a20=Ee(_0x5c5377['visibleWrites'],_0x3fb4f7);if(!_0x1fa7d1&&Ai(_0x275a20))return _0x33796a;if(!_0x1fa7d1&&_0x33796a==null&&!Ri(_0x275a20,w()))return null;{const _0x1a2182=function(_0x59154a){return(_0x59154a['visible']||_0x1fa7d1)&&(!_0x32fcc3||!~_0x32fcc3['indexOf'](_0x59154a['writeId']))&&(G(_0x59154a['path'],_0x3fb4f7)||G(_0x3fb4f7,_0x59154a['path']));},_0x320ac8=Wo(_0x5c5377['allWrites'],_0x1a2182,_0x3fb4f7),_0x3a1bd4=_0x33796a||g['EMPTY_NODE'];return at(_0x320ac8,_0x3a1bd4);}}}function gu(_0x536be1,_0x2199d0,_0x284b82){let _0x4940b7=g['EMPTY_NODE'];const _0x51db43=ze(_0x536be1['visibleWrites'],_0x2199d0);if(_0x51db43)return _0x51db43['isLeafNode']()||_0x51db43['forEachChild'](R,(_0x5e89e3,_0x3f7349)=>{_0x4940b7=_0x4940b7['updateImmediateChild'](_0x5e89e3,_0x3f7349);}),_0x4940b7;if(_0x284b82){const _0x26f4ce=Ee(_0x536be1['visibleWrites'],_0x2199d0);return _0x284b82['forEachChild'](R,(_0x73596d,_0x28216f)=>{const _0x4f869e=at(Ee(_0x26f4ce,new C(_0x73596d)),_0x28216f);_0x4940b7=_0x4940b7['updateImmediateChild'](_0x73596d,_0x4f869e);}),ar(_0x26f4ce)['forEach'](_0x5e5c52=>{_0x4940b7=_0x4940b7['updateImmediateChild'](_0x5e5c52['name'],_0x5e5c52['node']);}),_0x4940b7;}else{const _0x2679ab=Ee(_0x536be1['visibleWrites'],_0x2199d0);return ar(_0x2679ab)['forEach'](_0x3c3ad3=>{_0x4940b7=_0x4940b7['updateImmediateChild'](_0x3c3ad3['name'],_0x3c3ad3['node']);}),_0x4940b7;}}function mu(_0xefa863,_0x73601a,_0x2be545,_0x2939ce,_0x2b6663){f(_0x2939ce||_0x2b6663,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x32f7b3=k(_0x73601a,_0x2be545);if(Ri(_0xefa863['visibleWrites'],_0x32f7b3))return null;{const _0x514992=Ee(_0xefa863['visibleWrites'],_0x32f7b3);return Ai(_0x514992)?_0x2b6663['getChild'](_0x2be545):at(_0x514992,_0x2b6663['getChild'](_0x2be545));}}function yu(_0x3c1eea,_0x3cb369,_0x1e6f52,_0x2a5799){const _0x3bc3a6=k(_0x3cb369,_0x1e6f52),_0x1ed602=ze(_0x3c1eea['visibleWrites'],_0x3bc3a6);if(_0x1ed602!=null)return _0x1ed602;if(_0x2a5799['isCompleteForChild'](_0x1e6f52)){const _0x399231=Ee(_0x3c1eea['visibleWrites'],_0x3bc3a6);return at(_0x399231,_0x2a5799['getNode']()['getImmediateChild'](_0x1e6f52));}else return null;}function vu(_0x367a91,_0x567a87){return ze(_0x367a91['visibleWrites'],_0x567a87);}function Eu(_0x23ab3e,_0x278b69,_0x26d7d0,_0x5035a9,_0x3dbda9,_0x44f001,_0x7adf37){let _0x25fb9b;const _0x5cc077=Ee(_0x23ab3e['visibleWrites'],_0x278b69),_0x854343=ze(_0x5cc077,w());if(_0x854343!=null)_0x25fb9b=_0x854343;else{if(_0x26d7d0!=null)_0x25fb9b=at(_0x5cc077,_0x26d7d0);else return[];}if(_0x25fb9b=_0x25fb9b['withIndex'](_0x7adf37),!_0x25fb9b['isEmpty']()&&!_0x25fb9b['isLeafNode']()){const _0x36d07a=[],_0x5ba1a0=_0x7adf37['getCompare'](),_0x387933=_0x44f001?_0x25fb9b['getReverseIteratorFrom'](_0x5035a9,_0x7adf37):_0x25fb9b['getIteratorFrom'](_0x5035a9,_0x7adf37);let _0x57cfb2=_0x387933['getNext']();for(;_0x57cfb2&&_0x36d07a['length']<_0x3dbda9;)_0x5ba1a0(_0x57cfb2,_0x5035a9)!==0x0&&_0x36d07a['push'](_0x57cfb2),_0x57cfb2=_0x387933['getNext']();return _0x36d07a;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x41d909,_0x477ddc,_0x16e83b,_0x5d5db4){return Bo(_0x41d909['writeTree'],_0x41d909['treePath'],_0x477ddc,_0x16e83b,_0x5d5db4);}function is(_0x4d5adb,_0x4feacf){return gu(_0x4d5adb['writeTree'],_0x4d5adb['treePath'],_0x4feacf);}function cr(_0x190dba,_0x4c0994,_0x400011,_0x14b53f){return mu(_0x190dba['writeTree'],_0x190dba['treePath'],_0x4c0994,_0x400011,_0x14b53f);}function Tn(_0x22b615,_0x560d2b){return vu(_0x22b615['writeTree'],k(_0x22b615['treePath'],_0x560d2b));}function wu(_0x586143,_0x1ae2bb,_0x4c95b6,_0x2800ff,_0xc08864,_0x467117){return Eu(_0x586143['writeTree'],_0x586143['treePath'],_0x1ae2bb,_0x4c95b6,_0x2800ff,_0xc08864,_0x467117);}function ss(_0x4783ed,_0x249d86,_0x19260c){return yu(_0x4783ed['writeTree'],_0x4783ed['treePath'],_0x249d86,_0x19260c);}function Vo(_0x44fa1c,_0x67c7f8){return Ho(k(_0x44fa1c['treePath'],_0x67c7f8),_0x44fa1c['writeTree']);}function Ho(_0x3e2dd0,_0x16d3b2){return{'treePath':_0x3e2dd0,'writeTree':_0x16d3b2};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x57cc1b){const _0x15527c=_0x57cc1b['type'],_0x194ab3=_0x57cc1b['childName'];f(_0x15527c==='child_added'||_0x15527c==='child_changed'||_0x15527c==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x194ab3!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x2b1a23=this['changeMap']['get'](_0x194ab3);if(_0x2b1a23){const _0x1b858a=_0x2b1a23['type'];if(_0x15527c==='child_added'&&_0x1b858a==='child_removed')this['changeMap']['set'](_0x194ab3,xt(_0x194ab3,_0x57cc1b['snapshotNode'],_0x2b1a23['snapshotNode']));else{if(_0x15527c==='child_removed'&&_0x1b858a==='child_added')this['changeMap']['delete'](_0x194ab3);else{if(_0x15527c==='child_removed'&&_0x1b858a==='child_changed')this['changeMap']['set'](_0x194ab3,Lt(_0x194ab3,_0x2b1a23['oldSnap']));else{if(_0x15527c==='child_changed'&&_0x1b858a==='child_added')this['changeMap']['set'](_0x194ab3,rt(_0x194ab3,_0x57cc1b['snapshotNode']));else{if(_0x15527c==='child_changed'&&_0x1b858a==='child_changed')this['changeMap']['set'](_0x194ab3,xt(_0x194ab3,_0x57cc1b['snapshotNode'],_0x2b1a23['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x57cc1b+'\x20occurred\x20after\x20'+_0x2b1a23);}}}}}else this['changeMap']['set'](_0x194ab3,_0x57cc1b);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x59c74e){return null;}['getChildAfterChild'](_0x17bf9e,_0x54ffb7,_0x570861){return null;}}const $o=new Tu();class rs{constructor(_0x285ec8,_0x36f44f,_0x15ff5f=null){this['writes_']=_0x285ec8,this['viewCache_']=_0x36f44f,this['optCompleteServerCache_']=_0x15ff5f;}['getCompleteChild'](_0x257ca7){const _0x21148c=this['viewCache_']['eventCache'];if(_0x21148c['isCompleteForChild'](_0x257ca7))return _0x21148c['getNode']()['getImmediateChild'](_0x257ca7);{const _0x375c17=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x257ca7,_0x375c17);}}['getChildAfterChild'](_0x496311,_0x1fdd84,_0x6a9165){const _0x12dc2a=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x492218=wu(this['writes_'],_0x12dc2a,_0x1fdd84,0x1,_0x6a9165,_0x496311);return _0x492218['length']===0x0?null:_0x492218[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x178225){return{'filter':_0x178225};}function bu(_0xdeda54,_0x387ac7){f(_0x387ac7['eventCache']['getNode']()['isIndexed'](_0xdeda54['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x387ac7['serverCache']['getNode']()['isIndexed'](_0xdeda54['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x4de9a6,_0x207f0b,_0x1b81a7,_0x469959,_0x3c39cb){const _0x5ee9e1=new Cu();let _0x123864,_0x45b327;if(_0x1b81a7['type']===z['OVERWRITE']){const _0x34be63=_0x1b81a7;_0x34be63['source']['fromUser']?_0x123864=ki(_0x4de9a6,_0x207f0b,_0x34be63['path'],_0x34be63['snap'],_0x469959,_0x3c39cb,_0x5ee9e1):(f(_0x34be63['source']['fromServer'],'Unknown\x20source.'),_0x45b327=_0x34be63['source']['tagged']||_0x207f0b['serverCache']['isFiltered']()&&!v(_0x34be63['path']),_0x123864=Sn(_0x4de9a6,_0x207f0b,_0x34be63['path'],_0x34be63['snap'],_0x469959,_0x3c39cb,_0x45b327,_0x5ee9e1));}else{if(_0x1b81a7['type']===z['MERGE']){const _0x18d84b=_0x1b81a7;_0x18d84b['source']['fromUser']?_0x123864=ku(_0x4de9a6,_0x207f0b,_0x18d84b['path'],_0x18d84b['children'],_0x469959,_0x3c39cb,_0x5ee9e1):(f(_0x18d84b['source']['fromServer'],'Unknown\x20source.'),_0x45b327=_0x18d84b['source']['tagged']||_0x207f0b['serverCache']['isFiltered'](),_0x123864=Pi(_0x4de9a6,_0x207f0b,_0x18d84b['path'],_0x18d84b['children'],_0x469959,_0x3c39cb,_0x45b327,_0x5ee9e1));}else{if(_0x1b81a7['type']===z['ACK_USER_WRITE']){const _0x52205d=_0x1b81a7;_0x52205d['revert']?_0x123864=Ou(_0x4de9a6,_0x207f0b,_0x52205d['path'],_0x469959,_0x3c39cb,_0x5ee9e1):_0x123864=Pu(_0x4de9a6,_0x207f0b,_0x52205d['path'],_0x52205d['affectedTree'],_0x469959,_0x3c39cb,_0x5ee9e1);}else{if(_0x1b81a7['type']===z['LISTEN_COMPLETE'])_0x123864=Nu(_0x4de9a6,_0x207f0b,_0x1b81a7['path'],_0x469959,_0x5ee9e1);else throw ht('Unknown\x20operation\x20type:\x20'+_0x1b81a7['type']);}}}const _0x212ff8=_0x5ee9e1['getChanges']();return Au(_0x207f0b,_0x123864,_0x212ff8),{'viewCache':_0x123864,'changes':_0x212ff8};}function Au(_0x560b8f,_0xa1b0e5,_0x4e0302){const _0x1b6b4d=_0xa1b0e5['eventCache'];if(_0x1b6b4d['isFullyInitialized']()){const _0x224c5b=_0x1b6b4d['getNode']()['isLeafNode']()||_0x1b6b4d['getNode']()['isEmpty'](),_0x3f0739=wn(_0x560b8f);(_0x4e0302['length']>0x0||!_0x560b8f['eventCache']['isFullyInitialized']()||_0x224c5b&&!_0x1b6b4d['getNode']()['equals'](_0x3f0739)||!_0x1b6b4d['getNode']()['getPriority']()['equals'](_0x3f0739['getPriority']()))&&_0x4e0302['push'](Lo(wn(_0xa1b0e5)));}}function Go(_0x5928e9,_0x2bcf83,_0x14c2dd,_0x3c26c8,_0x38d1e6,_0x17a5ce){const _0x5c727a=_0x2bcf83['eventCache'];if(Tn(_0x3c26c8,_0x14c2dd)!=null)return _0x2bcf83;{let _0x15dc48,_0x405309;if(v(_0x14c2dd)){if(f(_0x2bcf83['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x2bcf83['serverCache']['isFiltered']()){const _0x456aaf=Ve(_0x2bcf83),_0x3f3f52=_0x456aaf instanceof g?_0x456aaf:g['EMPTY_NODE'],_0x3bfab1=is(_0x3c26c8,_0x3f3f52);_0x15dc48=_0x5928e9['filter']['updateFullNode'](_0x2bcf83['eventCache']['getNode'](),_0x3bfab1,_0x17a5ce);}else{const _0x4ea5e2=Cn(_0x3c26c8,Ve(_0x2bcf83));_0x15dc48=_0x5928e9['filter']['updateFullNode'](_0x2bcf83['eventCache']['getNode'](),_0x4ea5e2,_0x17a5ce);}}else{const _0x3a79a5=y(_0x14c2dd);if(_0x3a79a5==='.priority'){f(Ce(_0x14c2dd)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x8a73bc=_0x5c727a['getNode']();_0x405309=_0x2bcf83['serverCache']['getNode']();const _0x2265fe=cr(_0x3c26c8,_0x14c2dd,_0x8a73bc,_0x405309);_0x2265fe!=null?_0x15dc48=_0x5928e9['filter']['updatePriority'](_0x8a73bc,_0x2265fe):_0x15dc48=_0x5c727a['getNode']();}else{const _0x441522=S(_0x14c2dd);let _0x26232a;if(_0x5c727a['isCompleteForChild'](_0x3a79a5)){_0x405309=_0x2bcf83['serverCache']['getNode']();const _0x49f24d=cr(_0x3c26c8,_0x14c2dd,_0x5c727a['getNode'](),_0x405309);_0x49f24d!=null?_0x26232a=_0x5c727a['getNode']()['getImmediateChild'](_0x3a79a5)['updateChild'](_0x441522,_0x49f24d):_0x26232a=_0x5c727a['getNode']()['getImmediateChild'](_0x3a79a5);}else _0x26232a=ss(_0x3c26c8,_0x3a79a5,_0x2bcf83['serverCache']);_0x26232a!=null?_0x15dc48=_0x5928e9['filter']['updateChild'](_0x5c727a['getNode'](),_0x3a79a5,_0x26232a,_0x441522,_0x38d1e6,_0x17a5ce):_0x15dc48=_0x5c727a['getNode']();}}return Rt(_0x2bcf83,_0x15dc48,_0x5c727a['isFullyInitialized']()||v(_0x14c2dd),_0x5928e9['filter']['filtersNodes']());}}function Sn(_0x396d17,_0x11a338,_0x42c97f,_0x337213,_0x4841bb,_0x53d752,_0x4d9dbc,_0x4b90cb){const _0x3bb5ab=_0x11a338['serverCache'];let _0x77846b;const _0x3af61a=_0x4d9dbc?_0x396d17['filter']:_0x396d17['filter']['getIndexedFilter']();if(v(_0x42c97f))_0x77846b=_0x3af61a['updateFullNode'](_0x3bb5ab['getNode'](),_0x337213,null);else{if(_0x3af61a['filtersNodes']()&&!_0x3bb5ab['isFiltered']()){const _0x408157=_0x3bb5ab['getNode']()['updateChild'](_0x42c97f,_0x337213);_0x77846b=_0x3af61a['updateFullNode'](_0x3bb5ab['getNode'](),_0x408157,null);}else{const _0x582de7=y(_0x42c97f);if(!_0x3bb5ab['isCompleteForPath'](_0x42c97f)&&Ce(_0x42c97f)>0x1)return _0x11a338;const _0x2a05d0=S(_0x42c97f),_0x2f0c6a=_0x3bb5ab['getNode']()['getImmediateChild'](_0x582de7)['updateChild'](_0x2a05d0,_0x337213);_0x582de7==='.priority'?_0x77846b=_0x3af61a['updatePriority'](_0x3bb5ab['getNode'](),_0x2f0c6a):_0x77846b=_0x3af61a['updateChild'](_0x3bb5ab['getNode'](),_0x582de7,_0x2f0c6a,_0x2a05d0,$o,null);}}const _0x260d70=Fo(_0x11a338,_0x77846b,_0x3bb5ab['isFullyInitialized']()||v(_0x42c97f),_0x3af61a['filtersNodes']()),_0x5d6332=new rs(_0x4841bb,_0x260d70,_0x53d752);return Go(_0x396d17,_0x260d70,_0x42c97f,_0x4841bb,_0x5d6332,_0x4b90cb);}function ki(_0x22b733,_0x1f192e,_0x3ed56f,_0x482691,_0x2c6295,_0x54669,_0x40aca6){const _0x1bd20b=_0x1f192e['eventCache'];let _0x23c3f4,_0x86a242;const _0x5a3c09=new rs(_0x2c6295,_0x1f192e,_0x54669);if(v(_0x3ed56f))_0x86a242=_0x22b733['filter']['updateFullNode'](_0x1f192e['eventCache']['getNode'](),_0x482691,_0x40aca6),_0x23c3f4=Rt(_0x1f192e,_0x86a242,!0x0,_0x22b733['filter']['filtersNodes']());else{const _0x1d7251=y(_0x3ed56f);if(_0x1d7251==='.priority')_0x86a242=_0x22b733['filter']['updatePriority'](_0x1f192e['eventCache']['getNode'](),_0x482691),_0x23c3f4=Rt(_0x1f192e,_0x86a242,_0x1bd20b['isFullyInitialized'](),_0x1bd20b['isFiltered']());else{const _0x1d907b=S(_0x3ed56f),_0x50f629=_0x1bd20b['getNode']()['getImmediateChild'](_0x1d7251);let _0x316647;if(v(_0x1d907b))_0x316647=_0x482691;else{const _0x378f80=_0x5a3c09['getCompleteChild'](_0x1d7251);_0x378f80!=null?ji(_0x1d907b)==='.priority'&&_0x378f80['getChild'](Ro(_0x1d907b))['isEmpty']()?_0x316647=_0x378f80:_0x316647=_0x378f80['updateChild'](_0x1d907b,_0x482691):_0x316647=g['EMPTY_NODE'];}if(_0x50f629['equals'](_0x316647))_0x23c3f4=_0x1f192e;else{const _0x613fe6=_0x22b733['filter']['updateChild'](_0x1bd20b['getNode'](),_0x1d7251,_0x316647,_0x1d907b,_0x5a3c09,_0x40aca6);_0x23c3f4=Rt(_0x1f192e,_0x613fe6,_0x1bd20b['isFullyInitialized'](),_0x22b733['filter']['filtersNodes']());}}}return _0x23c3f4;}function lr(_0x1e2d07,_0x3be697){return _0x1e2d07['eventCache']['isCompleteForChild'](_0x3be697);}function ku(_0xf72c44,_0x37287c,_0x5135a4,_0x510963,_0x2895ea,_0x34cbb9,_0x521b75){let _0x370af4=_0x37287c;return _0x510963['foreach']((_0x2a2802,_0x18482e)=>{const _0x85552d=k(_0x5135a4,_0x2a2802);lr(_0x37287c,y(_0x85552d))&&(_0x370af4=ki(_0xf72c44,_0x370af4,_0x85552d,_0x18482e,_0x2895ea,_0x34cbb9,_0x521b75));}),_0x510963['foreach']((_0x3e6e7c,_0x2944db)=>{const _0x250868=k(_0x5135a4,_0x3e6e7c);lr(_0x37287c,y(_0x250868))||(_0x370af4=ki(_0xf72c44,_0x370af4,_0x250868,_0x2944db,_0x2895ea,_0x34cbb9,_0x521b75));}),_0x370af4;}function hr(_0x67f749,_0x1dd811,_0x4e977a){return _0x4e977a['foreach']((_0x56148a,_0x3eb93c)=>{_0x1dd811=_0x1dd811['updateChild'](_0x56148a,_0x3eb93c);}),_0x1dd811;}function Pi(_0x307ab5,_0x2cb76e,_0x40ed30,_0x47502c,_0x5beba0,_0x4eb36f,_0x4c4eaf,_0x1b2c82){if(_0x2cb76e['serverCache']['getNode']()['isEmpty']()&&!_0x2cb76e['serverCache']['isFullyInitialized']())return _0x2cb76e;let _0x4d98c4=_0x2cb76e,_0x32fc9b;v(_0x40ed30)?_0x32fc9b=_0x47502c:_0x32fc9b=new b(null)['setTree'](_0x40ed30,_0x47502c);const _0x4d4a50=_0x2cb76e['serverCache']['getNode']();return _0x32fc9b['children']['inorderTraversal']((_0x57b5bc,_0x189686)=>{if(_0x4d4a50['hasChild'](_0x57b5bc)){const _0x591617=_0x2cb76e['serverCache']['getNode']()['getImmediateChild'](_0x57b5bc),_0x46b41e=hr(_0x307ab5,_0x591617,_0x189686);_0x4d98c4=Sn(_0x307ab5,_0x4d98c4,new C(_0x57b5bc),_0x46b41e,_0x5beba0,_0x4eb36f,_0x4c4eaf,_0x1b2c82);}}),_0x32fc9b['children']['inorderTraversal']((_0xb36376,_0x4e6635)=>{const _0xf2f68=!_0x2cb76e['serverCache']['isCompleteForChild'](_0xb36376)&&_0x4e6635['value']===null;if(!_0x4d4a50['hasChild'](_0xb36376)&&!_0xf2f68){const _0x3c5cb1=_0x2cb76e['serverCache']['getNode']()['getImmediateChild'](_0xb36376),_0x116915=hr(_0x307ab5,_0x3c5cb1,_0x4e6635);_0x4d98c4=Sn(_0x307ab5,_0x4d98c4,new C(_0xb36376),_0x116915,_0x5beba0,_0x4eb36f,_0x4c4eaf,_0x1b2c82);}}),_0x4d98c4;}function Pu(_0x1c242e,_0x707a6c,_0x3be014,_0x1356e5,_0x543506,_0x3ac50e,_0x2149d6){if(Tn(_0x543506,_0x3be014)!=null)return _0x707a6c;const _0x18b8dd=_0x707a6c['serverCache']['isFiltered'](),_0x51a928=_0x707a6c['serverCache'];if(_0x1356e5['value']!=null){if(v(_0x3be014)&&_0x51a928['isFullyInitialized']()||_0x51a928['isCompleteForPath'](_0x3be014))return Sn(_0x1c242e,_0x707a6c,_0x3be014,_0x51a928['getNode']()['getChild'](_0x3be014),_0x543506,_0x3ac50e,_0x18b8dd,_0x2149d6);if(v(_0x3be014)){let _0xbecbb6=new b(null);return _0x51a928['getNode']()['forEachChild'](ve,(_0x46c87b,_0x3b09c3)=>{_0xbecbb6=_0xbecbb6['set'](new C(_0x46c87b),_0x3b09c3);}),Pi(_0x1c242e,_0x707a6c,_0x3be014,_0xbecbb6,_0x543506,_0x3ac50e,_0x18b8dd,_0x2149d6);}else return _0x707a6c;}else{let _0x14841e=new b(null);return _0x1356e5['foreach']((_0x441440,_0x45eb96)=>{const _0xd4c775=k(_0x3be014,_0x441440);_0x51a928['isCompleteForPath'](_0xd4c775)&&(_0x14841e=_0x14841e['set'](_0x441440,_0x51a928['getNode']()['getChild'](_0xd4c775)));}),Pi(_0x1c242e,_0x707a6c,_0x3be014,_0x14841e,_0x543506,_0x3ac50e,_0x18b8dd,_0x2149d6);}}function Nu(_0x35f067,_0x5c5942,_0x55ecff,_0x1193db,_0x2ca2ef){const _0x59d1f1=_0x5c5942['serverCache'],_0x5b3c89=Fo(_0x5c5942,_0x59d1f1['getNode'](),_0x59d1f1['isFullyInitialized']()||v(_0x55ecff),_0x59d1f1['isFiltered']());return Go(_0x35f067,_0x5b3c89,_0x55ecff,_0x1193db,$o,_0x2ca2ef);}function Ou(_0x5b35aa,_0x2d1e9c,_0x2cba38,_0x545ec6,_0x175c21,_0x42b56c){let _0x532ab4;if(Tn(_0x545ec6,_0x2cba38)!=null)return _0x2d1e9c;{const _0x4ca2ae=new rs(_0x545ec6,_0x2d1e9c,_0x175c21),_0x5524c9=_0x2d1e9c['eventCache']['getNode']();let _0x3fa2b6;if(v(_0x2cba38)||y(_0x2cba38)==='.priority'){let _0x3aa61a;if(_0x2d1e9c['serverCache']['isFullyInitialized']())_0x3aa61a=Cn(_0x545ec6,Ve(_0x2d1e9c));else{const _0xf94891=_0x2d1e9c['serverCache']['getNode']();f(_0xf94891 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x3aa61a=is(_0x545ec6,_0xf94891);}_0x3aa61a=_0x3aa61a,_0x3fa2b6=_0x5b35aa['filter']['updateFullNode'](_0x5524c9,_0x3aa61a,_0x42b56c);}else{const _0x262c2b=y(_0x2cba38);let _0xb94e7b=ss(_0x545ec6,_0x262c2b,_0x2d1e9c['serverCache']);_0xb94e7b==null&&_0x2d1e9c['serverCache']['isCompleteForChild'](_0x262c2b)&&(_0xb94e7b=_0x5524c9['getImmediateChild'](_0x262c2b)),_0xb94e7b!=null?_0x3fa2b6=_0x5b35aa['filter']['updateChild'](_0x5524c9,_0x262c2b,_0xb94e7b,S(_0x2cba38),_0x4ca2ae,_0x42b56c):_0x2d1e9c['eventCache']['getNode']()['hasChild'](_0x262c2b)?_0x3fa2b6=_0x5b35aa['filter']['updateChild'](_0x5524c9,_0x262c2b,g['EMPTY_NODE'],S(_0x2cba38),_0x4ca2ae,_0x42b56c):_0x3fa2b6=_0x5524c9,_0x3fa2b6['isEmpty']()&&_0x2d1e9c['serverCache']['isFullyInitialized']()&&(_0x532ab4=Cn(_0x545ec6,Ve(_0x2d1e9c)),_0x532ab4['isLeafNode']()&&(_0x3fa2b6=_0x5b35aa['filter']['updateFullNode'](_0x3fa2b6,_0x532ab4,_0x42b56c)));}return _0x532ab4=_0x2d1e9c['serverCache']['isFullyInitialized']()||Tn(_0x545ec6,w())!=null,Rt(_0x2d1e9c,_0x3fa2b6,_0x532ab4,_0x5b35aa['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x5932b1,_0x178a74){this['query_']=_0x5932b1,this['eventRegistrations_']=[];const _0x3a26ea=this['query_']['_queryParams'],_0x4cef13=new Xi(_0x3a26ea['getIndex']()),_0x4f8e48=Kh(_0x3a26ea);this['processor_']=Su(_0x4f8e48);const _0x44e0ab=_0x178a74['serverCache'],_0x2c0336=_0x178a74['eventCache'],_0x4a0bef=_0x4cef13['updateFullNode'](g['EMPTY_NODE'],_0x44e0ab['getNode'](),null),_0x402260=_0x4f8e48['updateFullNode'](g['EMPTY_NODE'],_0x2c0336['getNode'](),null),_0x4fc09e=new Te(_0x4a0bef,_0x44e0ab['isFullyInitialized'](),_0x4cef13['filtersNodes']()),_0x477260=new Te(_0x402260,_0x2c0336['isFullyInitialized'](),_0x4f8e48['filtersNodes']());this['viewCache_']=Un(_0x477260,_0x4fc09e),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x11598f){return _0x11598f['viewCache_']['serverCache']['getNode']();}function Lu(_0x395318){return wn(_0x395318['viewCache_']);}function xu(_0x326b85,_0x1743c0){const _0xec5135=Ve(_0x326b85['viewCache_']);return _0xec5135&&(_0x326b85['query']['_queryParams']['loadsAllData']()||!v(_0x1743c0)&&!_0xec5135['getImmediateChild'](y(_0x1743c0))['isEmpty']())?_0xec5135['getChild'](_0x1743c0):null;}function ur(_0x2a0739){return _0x2a0739['eventRegistrations_']['length']===0x0;}function Fu(_0x3c5afa,_0x4420ba){_0x3c5afa['eventRegistrations_']['push'](_0x4420ba);}function dr(_0x4d95df,_0x17c95c,_0x3cdfbb){const _0x542f32=[];if(_0x3cdfbb){f(_0x17c95c==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x42fb28=_0x4d95df['query']['_path'];_0x4d95df['eventRegistrations_']['forEach'](_0x23b296=>{const _0x60d620=_0x23b296['createCancelEvent'](_0x3cdfbb,_0x42fb28);_0x60d620&&_0x542f32['push'](_0x60d620);});}if(_0x17c95c){let _0x3e3fdf=[];for(let _0x39e50e=0x0;_0x39e50e<_0x4d95df['eventRegistrations_']['length'];++_0x39e50e){const _0xb23600=_0x4d95df['eventRegistrations_'][_0x39e50e];if(!_0xb23600['matches'](_0x17c95c))_0x3e3fdf['push'](_0xb23600);else{if(_0x17c95c['hasAnyCallback']()){_0x3e3fdf=_0x3e3fdf['concat'](_0x4d95df['eventRegistrations_']['slice'](_0x39e50e+0x1));break;}}}_0x4d95df['eventRegistrations_']=_0x3e3fdf;}else _0x4d95df['eventRegistrations_']=[];return _0x542f32;}function fr(_0x17c6a1,_0x49f617,_0x359d8e,_0x1ebd5b){_0x49f617['type']===z['MERGE']&&_0x49f617['source']['queryId']!==null&&(f(Ve(_0x17c6a1['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x17c6a1['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x14217f=_0x17c6a1['viewCache_'],_0x7d0c93=Ru(_0x17c6a1['processor_'],_0x14217f,_0x49f617,_0x359d8e,_0x1ebd5b);return bu(_0x17c6a1['processor_'],_0x7d0c93['viewCache']),f(_0x7d0c93['viewCache']['serverCache']['isFullyInitialized']()||!_0x14217f['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x17c6a1['viewCache_']=_0x7d0c93['viewCache'],qo(_0x17c6a1,_0x7d0c93['changes'],_0x7d0c93['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x2087ba,_0x107b13){const _0x292d0d=_0x2087ba['viewCache_']['eventCache'],_0x15fae0=[];return _0x292d0d['getNode']()['isLeafNode']()||_0x292d0d['getNode']()['forEachChild'](R,(_0x24d485,_0x4e80a6)=>{_0x15fae0['push'](rt(_0x24d485,_0x4e80a6));}),_0x292d0d['isFullyInitialized']()&&_0x15fae0['push'](Lo(_0x292d0d['getNode']())),qo(_0x2087ba,_0x15fae0,_0x292d0d['getNode'](),_0x107b13);}function qo(_0x1e64d8,_0x5dd9a9,_0x196b2c,_0x1309f6){const _0x2eeb96=_0x1309f6?[_0x1309f6]:_0x1e64d8['eventRegistrations_'];return ru(_0x1e64d8['eventGenerator_'],_0x5dd9a9,_0x196b2c,_0x2eeb96);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x12a535){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x12a535;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x44ad7){return _0x44ad7['views']['size']===0x0;}function os(_0x3d6ced,_0x339bd5,_0x4d0ad0,_0x512dc){const _0x433c19=_0x339bd5['source']['queryId'];if(_0x433c19!==null){const _0x337c93=_0x3d6ced['views']['get'](_0x433c19);return f(_0x337c93!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x337c93,_0x339bd5,_0x4d0ad0,_0x512dc);}else{let _0x22d1af=[];for(const _0x366819 of _0x3d6ced['views']['values']())_0x22d1af=_0x22d1af['concat'](fr(_0x366819,_0x339bd5,_0x4d0ad0,_0x512dc));return _0x22d1af;}}function jo(_0x247624,_0x5655fc,_0x57ac31,_0x577f1b,_0x5361de){const _0x1344b4=_0x5655fc['_queryIdentifier'],_0x113397=_0x247624['views']['get'](_0x1344b4);if(!_0x113397){let _0x1304fa=Cn(_0x57ac31,_0x5361de?_0x577f1b:null),_0x46fedf=!0x1;_0x1304fa?_0x46fedf=!0x0:_0x577f1b instanceof g?(_0x1304fa=is(_0x57ac31,_0x577f1b),_0x46fedf=!0x1):(_0x1304fa=g['EMPTY_NODE'],_0x46fedf=!0x1);const _0x5a0b82=Un(new Te(_0x1304fa,_0x46fedf,!0x1),new Te(_0x577f1b,_0x5361de,!0x1));return new Du(_0x5655fc,_0x5a0b82);}return _0x113397;}function Hu(_0x2afa1a,_0x2a9e42,_0x130eea,_0x10134b,_0x45b60f,_0x10dce8){const _0x2e2e31=jo(_0x2afa1a,_0x2a9e42,_0x10134b,_0x45b60f,_0x10dce8);return _0x2afa1a['views']['has'](_0x2a9e42['_queryIdentifier'])||_0x2afa1a['views']['set'](_0x2a9e42['_queryIdentifier'],_0x2e2e31),Fu(_0x2e2e31,_0x130eea),Uu(_0x2e2e31,_0x130eea);}function $u(_0x3ec768,_0x576364,_0x11f397,_0x36da4a){const _0x1b95cc=_0x576364['_queryIdentifier'],_0x1d1aa2=[];let _0x244415=[];const _0x244e68=Se(_0x3ec768);if(_0x1b95cc==='default'){for(const [_0x5923ca,_0x42c1c5]of _0x3ec768['views']['entries']())_0x244415=_0x244415['concat'](dr(_0x42c1c5,_0x11f397,_0x36da4a)),ur(_0x42c1c5)&&(_0x3ec768['views']['delete'](_0x5923ca),_0x42c1c5['query']['_queryParams']['loadsAllData']()||_0x1d1aa2['push'](_0x42c1c5['query']));}else{const _0x589426=_0x3ec768['views']['get'](_0x1b95cc);_0x589426&&(_0x244415=_0x244415['concat'](dr(_0x589426,_0x11f397,_0x36da4a)),ur(_0x589426)&&(_0x3ec768['views']['delete'](_0x1b95cc),_0x589426['query']['_queryParams']['loadsAllData']()||_0x1d1aa2['push'](_0x589426['query'])));}return _0x244e68&&!Se(_0x3ec768)&&_0x1d1aa2['push'](new(Bu())(_0x576364['_repo'],_0x576364['_path'])),{'removed':_0x1d1aa2,'events':_0x244415};}function Ko(_0x11213f){const _0x13897d=[];for(const _0x3be7a0 of _0x11213f['views']['values']())_0x3be7a0['query']['_queryParams']['loadsAllData']()||_0x13897d['push'](_0x3be7a0);return _0x13897d;}function Ie(_0x30a741,_0x1ba6ea){let _0x544df4=null;for(const _0x584b0f of _0x30a741['views']['values']())_0x544df4=_0x544df4||xu(_0x584b0f,_0x1ba6ea);return _0x544df4;}function Yo(_0x14780c,_0x478ddf){if(_0x478ddf['_queryParams']['loadsAllData']())return Bn(_0x14780c);{const _0x18576=_0x478ddf['_queryIdentifier'];return _0x14780c['views']['get'](_0x18576);}}function Qo(_0x573aa2,_0x51cff0){return Yo(_0x573aa2,_0x51cff0)!=null;}function Se(_0xb5b76c){return Bn(_0xb5b76c)!=null;}function Bn(_0x3dc4f4){for(const _0x36b26e of _0x3dc4f4['views']['values']())if(_0x36b26e['query']['_queryParams']['loadsAllData']())return _0x36b26e;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x36baf9){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x36baf9;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x4a31ea){this['listenProvider_']=_0x4a31ea,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x3962d4,_0x315026,_0x399013,_0x2e14a4,_0xffb1be){return lu(_0x3962d4['pendingWriteTree_'],_0x315026,_0x399013,_0x2e14a4,_0xffb1be),_0xffb1be?_t(_0x3962d4,new Be(es(),_0x315026,_0x399013)):[];}function ju(_0x4e6e7b,_0x5f0c7c,_0x2acbfa,_0xfd933d){hu(_0x4e6e7b['pendingWriteTree_'],_0x5f0c7c,_0x2acbfa,_0xfd933d);const _0x5c7b2f=b['fromObject'](_0x2acbfa);return _t(_0x4e6e7b,new ot(es(),_0x5f0c7c,_0x5c7b2f));}function _e(_0x153eef,_0x4a6b35,_0xe00326=!0x1){const _0x296dfc=uu(_0x153eef['pendingWriteTree_'],_0x4a6b35);if(du(_0x153eef['pendingWriteTree_'],_0x4a6b35)){let _0x4f84a8=new b(null);return _0x296dfc['snap']!=null?_0x4f84a8=_0x4f84a8['set'](w(),!0x0):x(_0x296dfc['children'],_0x3c8aa8=>{_0x4f84a8=_0x4f84a8['set'](new C(_0x3c8aa8),!0x0);}),_t(_0x153eef,new In(_0x296dfc['path'],_0x4f84a8,_0xe00326));}else return[];}function Yt(_0x1d15b6,_0x4bb758,_0x1a0a72){return _t(_0x1d15b6,new Be(ts(),_0x4bb758,_0x1a0a72));}function Ku(_0x2aa6ba,_0xdd60ef,_0x5c8c3c){const _0x3f97f1=b['fromObject'](_0x5c8c3c);return _t(_0x2aa6ba,new ot(ts(),_0xdd60ef,_0x3f97f1));}function Yu(_0x45a1b7,_0x83d8a3){return _t(_0x45a1b7,new Ut(ts(),_0x83d8a3));}function Qu(_0x5b4346,_0x2f8b73,_0x34d563){const _0x36a6ed=cs(_0x5b4346,_0x34d563);if(_0x36a6ed){const _0x505cb1=ls(_0x36a6ed),_0x3d2fc3=_0x505cb1['path'],_0x4afcf7=_0x505cb1['queryId'],_0x5e4fed=F(_0x3d2fc3,_0x2f8b73),_0x44380f=new Ut(ns(_0x4afcf7),_0x5e4fed);return hs(_0x5b4346,_0x3d2fc3,_0x44380f);}else return[];}function An(_0x45c08b,_0x5589f0,_0x2d71d7,_0x3c712b,_0x27358a=!0x1){const _0x416d08=_0x5589f0['_path'],_0xecc40d=_0x45c08b['syncPointTree_']['get'](_0x416d08);let _0x3d4d7b=[];if(_0xecc40d&&(_0x5589f0['_queryIdentifier']==='default'||Qo(_0xecc40d,_0x5589f0))){const _0x52761f=$u(_0xecc40d,_0x5589f0,_0x2d71d7,_0x3c712b);Vu(_0xecc40d)&&(_0x45c08b['syncPointTree_']=_0x45c08b['syncPointTree_']['remove'](_0x416d08));const _0x3b441e=_0x52761f['removed'];if(_0x3d4d7b=_0x52761f['events'],!_0x27358a){const _0x542ce9=_0x3b441e['findIndex'](_0xcb42b6=>_0xcb42b6['_queryParams']['loadsAllData']())!==-0x1,_0x233633=_0x45c08b['syncPointTree_']['findOnPath'](_0x416d08,(_0x396481,_0x6faa41)=>Se(_0x6faa41));if(_0x542ce9&&!_0x233633){const _0x45f772=_0x45c08b['syncPointTree_']['subtree'](_0x416d08);if(!_0x45f772['isEmpty']()){const _0x54b830=Zu(_0x45f772);for(let _0x7b5e1d=0x0;_0x7b5e1d<_0x54b830['length'];++_0x7b5e1d){const _0x35de2e=_0x54b830[_0x7b5e1d],_0x5c4769=_0x35de2e['query'],_0x1b4996=ea(_0x45c08b,_0x35de2e);_0x45c08b['listenProvider_']['startListening'](kt(_0x5c4769),Wt(_0x45c08b,_0x5c4769),_0x1b4996['hashFn'],_0x1b4996['onComplete']);}}}!_0x233633&&_0x3b441e['length']>0x0&&!_0x3c712b&&(_0x542ce9?_0x45c08b['listenProvider_']['stopListening'](kt(_0x5589f0),null):_0x3b441e['forEach'](_0x4b8fb3=>{const _0xe375ef=_0x45c08b['queryToTagMap']['get'](Hn(_0x4b8fb3));_0x45c08b['listenProvider_']['stopListening'](kt(_0x4b8fb3),_0xe375ef);}));}ed(_0x45c08b,_0x3b441e);}return _0x3d4d7b;}function Jo(_0x17e9b0,_0x3f338e,_0x58840f,_0x486598){const _0x3ea55e=cs(_0x17e9b0,_0x486598);if(_0x3ea55e!=null){const _0x108e62=ls(_0x3ea55e),_0x23d0b5=_0x108e62['path'],_0x399eb3=_0x108e62['queryId'],_0x223ae0=F(_0x23d0b5,_0x3f338e),_0x1c24aa=new Be(ns(_0x399eb3),_0x223ae0,_0x58840f);return hs(_0x17e9b0,_0x23d0b5,_0x1c24aa);}else return[];}function Ju(_0xf385e5,_0x59cd62,_0x9fe971,_0x49c0b4){const _0x253705=cs(_0xf385e5,_0x49c0b4);if(_0x253705){const _0x4c3a8f=ls(_0x253705),_0x5f4e06=_0x4c3a8f['path'],_0x3b4e6a=_0x4c3a8f['queryId'],_0x3dccf8=F(_0x5f4e06,_0x59cd62),_0x280ba5=b['fromObject'](_0x9fe971),_0x19adae=new ot(ns(_0x3b4e6a),_0x3dccf8,_0x280ba5);return hs(_0xf385e5,_0x5f4e06,_0x19adae);}else return[];}function Ni(_0x4c3999,_0x3afc78,_0x26aa17,_0x25d174=!0x1){const _0x58f1a5=_0x3afc78['_path'];let _0x29af4a=null,_0x15773d=!0x1;_0x4c3999['syncPointTree_']['foreachOnPath'](_0x58f1a5,(_0x247c35,_0x4c2947)=>{const _0x21939d=F(_0x247c35,_0x58f1a5);_0x29af4a=_0x29af4a||Ie(_0x4c2947,_0x21939d),_0x15773d=_0x15773d||Se(_0x4c2947);});let _0xad8fbe=_0x4c3999['syncPointTree_']['get'](_0x58f1a5);_0xad8fbe?(_0x15773d=_0x15773d||Se(_0xad8fbe),_0x29af4a=_0x29af4a||Ie(_0xad8fbe,w())):(_0xad8fbe=new zo(),_0x4c3999['syncPointTree_']=_0x4c3999['syncPointTree_']['set'](_0x58f1a5,_0xad8fbe));let _0x25db55;_0x29af4a!=null?_0x25db55=!0x0:(_0x25db55=!0x1,_0x29af4a=g['EMPTY_NODE'],_0x4c3999['syncPointTree_']['subtree'](_0x58f1a5)['foreachChild']((_0x133ff1,_0x46627b)=>{const _0x457df8=Ie(_0x46627b,w());_0x457df8&&(_0x29af4a=_0x29af4a['updateImmediateChild'](_0x133ff1,_0x457df8));}));const _0x5324ca=Qo(_0xad8fbe,_0x3afc78);if(!_0x5324ca&&!_0x3afc78['_queryParams']['loadsAllData']()){const _0x4038f4=Hn(_0x3afc78);f(!_0x4c3999['queryToTagMap']['has'](_0x4038f4),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x2b116e=td();_0x4c3999['queryToTagMap']['set'](_0x4038f4,_0x2b116e),_0x4c3999['tagToQueryMap']['set'](_0x2b116e,_0x4038f4);}const _0x1518d2=Wn(_0x4c3999['pendingWriteTree_'],_0x58f1a5);let _0x24b05d=Hu(_0xad8fbe,_0x3afc78,_0x26aa17,_0x1518d2,_0x29af4a,_0x25db55);if(!_0x5324ca&&!_0x15773d&&!_0x25d174){const _0x55f44b=Yo(_0xad8fbe,_0x3afc78);_0x24b05d=_0x24b05d['concat'](nd(_0x4c3999,_0x3afc78,_0x55f44b));}return _0x24b05d;}function Vn(_0x595427,_0x4835a1,_0x403439){const _0x19dd2f=_0x595427['pendingWriteTree_'],_0xf1aa72=_0x595427['syncPointTree_']['findOnPath'](_0x4835a1,(_0x52d269,_0x3d1e17)=>{const _0x4531d4=F(_0x52d269,_0x4835a1),_0x5a5ceb=Ie(_0x3d1e17,_0x4531d4);if(_0x5a5ceb)return _0x5a5ceb;});return Bo(_0x19dd2f,_0x4835a1,_0xf1aa72,_0x403439,!0x0);}function Xu(_0x2c6ba0,_0x3493fa){const _0x4793d4=_0x3493fa['_path'];let _0x5e23d4=null;_0x2c6ba0['syncPointTree_']['foreachOnPath'](_0x4793d4,(_0x51174d,_0x571614)=>{const _0x19b09f=F(_0x51174d,_0x4793d4);_0x5e23d4=_0x5e23d4||Ie(_0x571614,_0x19b09f);});let _0x3e9265=_0x2c6ba0['syncPointTree_']['get'](_0x4793d4);_0x3e9265?_0x5e23d4=_0x5e23d4||Ie(_0x3e9265,w()):(_0x3e9265=new zo(),_0x2c6ba0['syncPointTree_']=_0x2c6ba0['syncPointTree_']['set'](_0x4793d4,_0x3e9265));const _0x32a3d6=_0x5e23d4!=null,_0x2bd51f=_0x32a3d6?new Te(_0x5e23d4,!0x0,!0x1):null,_0x58955e=Wn(_0x2c6ba0['pendingWriteTree_'],_0x3493fa['_path']),_0x263f9c=jo(_0x3e9265,_0x3493fa,_0x58955e,_0x32a3d6?_0x2bd51f['getNode']():g['EMPTY_NODE'],_0x32a3d6);return Lu(_0x263f9c);}function _t(_0x5d2f8c,_0x5abeb1){return Xo(_0x5abeb1,_0x5d2f8c['syncPointTree_'],null,Wn(_0x5d2f8c['pendingWriteTree_'],w()));}function Xo(_0x85d698,_0x2a7935,_0x4b0cf8,_0x66cb74){if(v(_0x85d698['path']))return Zo(_0x85d698,_0x2a7935,_0x4b0cf8,_0x66cb74);{const _0x21baa9=_0x2a7935['get'](w());_0x4b0cf8==null&&_0x21baa9!=null&&(_0x4b0cf8=Ie(_0x21baa9,w()));let _0x8d5a5f=[];const _0x291f70=y(_0x85d698['path']),_0x385de4=_0x85d698['operationForChild'](_0x291f70),_0x5118c8=_0x2a7935['children']['get'](_0x291f70);if(_0x5118c8&&_0x385de4){const _0x32075a=_0x4b0cf8?_0x4b0cf8['getImmediateChild'](_0x291f70):null,_0xb9a91d=Vo(_0x66cb74,_0x291f70);_0x8d5a5f=_0x8d5a5f['concat'](Xo(_0x385de4,_0x5118c8,_0x32075a,_0xb9a91d));}return _0x21baa9&&(_0x8d5a5f=_0x8d5a5f['concat'](os(_0x21baa9,_0x85d698,_0x66cb74,_0x4b0cf8))),_0x8d5a5f;}}function Zo(_0x183157,_0x4f5937,_0x52dafe,_0x18d943){const _0x1d9364=_0x4f5937['get'](w());_0x52dafe==null&&_0x1d9364!=null&&(_0x52dafe=Ie(_0x1d9364,w()));let _0x1f276e=[];return _0x4f5937['children']['inorderTraversal']((_0x1c6430,_0x40ebce)=>{const _0x151540=_0x52dafe?_0x52dafe['getImmediateChild'](_0x1c6430):null,_0x2abab1=Vo(_0x18d943,_0x1c6430),_0x33f283=_0x183157['operationForChild'](_0x1c6430);_0x33f283&&(_0x1f276e=_0x1f276e['concat'](Zo(_0x33f283,_0x40ebce,_0x151540,_0x2abab1)));}),_0x1d9364&&(_0x1f276e=_0x1f276e['concat'](os(_0x1d9364,_0x183157,_0x18d943,_0x52dafe))),_0x1f276e;}function ea(_0x479158,_0x291071){const _0x1c85f0=_0x291071['query'],_0x5d74dc=Wt(_0x479158,_0x1c85f0);return{'hashFn':()=>(Mu(_0x291071)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x56fa3c=>{if(_0x56fa3c==='ok')return _0x5d74dc?Qu(_0x479158,_0x1c85f0['_path'],_0x5d74dc):Yu(_0x479158,_0x1c85f0['_path']);{const _0x1c0e3c=Kl(_0x56fa3c,_0x1c85f0);return An(_0x479158,_0x1c85f0,null,_0x1c0e3c);}}};}function Wt(_0x3ec9b6,_0x25385c){const _0x495eef=Hn(_0x25385c);return _0x3ec9b6['queryToTagMap']['get'](_0x495eef);}function Hn(_0x3b5752){return _0x3b5752['_path']['toString']()+'$'+_0x3b5752['_queryIdentifier'];}function cs(_0x48cce2,_0x38b930){return _0x48cce2['tagToQueryMap']['get'](_0x38b930);}function ls(_0x470d47){const _0x30ae09=_0x470d47['indexOf']('$');return f(_0x30ae09!==-0x1&&_0x30ae09<_0x470d47['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x470d47['substr'](_0x30ae09+0x1),'path':new C(_0x470d47['substr'](0x0,_0x30ae09))};}function hs(_0x11c11f,_0x4a0073,_0x394f0d){const _0x443f48=_0x11c11f['syncPointTree_']['get'](_0x4a0073);f(_0x443f48,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x3cfc97=Wn(_0x11c11f['pendingWriteTree_'],_0x4a0073);return os(_0x443f48,_0x394f0d,_0x3cfc97,null);}function Zu(_0x1b89c1){return _0x1b89c1['fold']((_0x3f4c4e,_0x347030,_0x42af97)=>{if(_0x347030&&Se(_0x347030))return[Bn(_0x347030)];{let _0x79a0bf=[];return _0x347030&&(_0x79a0bf=Ko(_0x347030)),x(_0x42af97,(_0x5e58d5,_0x4b04ec)=>{_0x79a0bf=_0x79a0bf['concat'](_0x4b04ec);}),_0x79a0bf;}});}function kt(_0x3d4cd8){return _0x3d4cd8['_queryParams']['loadsAllData']()&&!_0x3d4cd8['_queryParams']['isDefault']()?new(qu())(_0x3d4cd8['_repo'],_0x3d4cd8['_path']):_0x3d4cd8;}function ed(_0x4cc47a,_0x41a112){for(let _0x2ea1a5=0x0;_0x2ea1a5<_0x41a112['length'];++_0x2ea1a5){const _0x3a8433=_0x41a112[_0x2ea1a5];if(!_0x3a8433['_queryParams']['loadsAllData']()){const _0x2fcabc=Hn(_0x3a8433),_0x3ba199=_0x4cc47a['queryToTagMap']['get'](_0x2fcabc);_0x4cc47a['queryToTagMap']['delete'](_0x2fcabc),_0x4cc47a['tagToQueryMap']['delete'](_0x3ba199);}}}function td(){return zu++;}function nd(_0x4a6f72,_0x5ba54b,_0x4d5871){const _0x259ce6=_0x5ba54b['_path'],_0x461e08=Wt(_0x4a6f72,_0x5ba54b),_0x502867=ea(_0x4a6f72,_0x4d5871),_0x347e1c=_0x4a6f72['listenProvider_']['startListening'](kt(_0x5ba54b),_0x461e08,_0x502867['hashFn'],_0x502867['onComplete']),_0x2bad92=_0x4a6f72['syncPointTree_']['subtree'](_0x259ce6);if(_0x461e08)f(!Se(_0x2bad92['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x574f4e=_0x2bad92['fold']((_0x5783fa,_0x4ae092,_0x4e572f)=>{if(!v(_0x5783fa)&&_0x4ae092&&Se(_0x4ae092))return[Bn(_0x4ae092)['query']];{let _0x2754f9=[];return _0x4ae092&&(_0x2754f9=_0x2754f9['concat'](Ko(_0x4ae092)['map'](_0x5bf137=>_0x5bf137['query']))),x(_0x4e572f,(_0x336b21,_0x30ec74)=>{_0x2754f9=_0x2754f9['concat'](_0x30ec74);}),_0x2754f9;}});for(let _0x1a3cec=0x0;_0x1a3cec<_0x574f4e['length'];++_0x1a3cec){const _0xe0b80d=_0x574f4e[_0x1a3cec];_0x4a6f72['listenProvider_']['stopListening'](kt(_0xe0b80d),Wt(_0x4a6f72,_0xe0b80d));}}return _0x347e1c;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x37287a){this['node_']=_0x37287a;}['getImmediateChild'](_0xb5d942){const _0x38732d=this['node_']['getImmediateChild'](_0xb5d942);return new us(_0x38732d);}['node'](){return this['node_'];}}class ds{constructor(_0x2c8180,_0x5a1700){this['syncTree_']=_0x2c8180,this['path_']=_0x5a1700;}['getImmediateChild'](_0x26498f){const _0x5e6128=k(this['path_'],_0x26498f);return new ds(this['syncTree_'],_0x5e6128);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x455db3){return _0x455db3=_0x455db3||{},_0x455db3['timestamp']=_0x455db3['timestamp']||new Date()['getTime'](),_0x455db3;},_r=function(_0x162ec6,_0x3acf22,_0x2fa245){if(!_0x162ec6||typeof _0x162ec6!='object')return _0x162ec6;if(f('.sv'in _0x162ec6,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x162ec6['.sv']=='string')return sd(_0x162ec6['.sv'],_0x3acf22,_0x2fa245);if(typeof _0x162ec6['.sv']=='object')return rd(_0x162ec6['.sv'],_0x3acf22);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x162ec6,null,0x2));},sd=function(_0x148d19,_0x1b2b1f,_0x345580){switch(_0x148d19){case'timestamp':return _0x345580['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x148d19);}},rd=function(_0x58938f,_0x277766,_0x47d2a1){_0x58938f['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x58938f,null,0x2));const _0x400534=_0x58938f['increment'];typeof _0x400534!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x400534);const _0x391850=_0x277766['node']();if(f(_0x391850!==null&&typeof _0x391850<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x391850['isLeafNode']())return _0x400534;const _0x50e716=_0x391850['getValue']();return typeof _0x50e716!='number'?_0x400534:_0x50e716+_0x400534;},ta=function(_0x9b0369,_0x40ae42,_0x436a4a,_0x25e0d5){return ps(_0x40ae42,new ds(_0x436a4a,_0x9b0369),_0x25e0d5);},fs=function(_0x3df656,_0x2b7baf,_0x2dc33c){return ps(_0x3df656,new us(_0x2b7baf),_0x2dc33c);};function ps(_0x50946c,_0x3c8b42,_0x1bce95){const _0x35303b=_0x50946c['getPriority']()['val'](),_0x3c63b7=_r(_0x35303b,_0x3c8b42['getImmediateChild']('.priority'),_0x1bce95);let _0x1c29c0;if(_0x50946c['isLeafNode']()){const _0x156700=_0x50946c,_0x18c01a=_r(_0x156700['getValue'](),_0x3c8b42,_0x1bce95);return _0x18c01a!==_0x156700['getValue']()||_0x3c63b7!==_0x156700['getPriority']()['val']()?new D(_0x18c01a,A(_0x3c63b7)):_0x50946c;}else{const _0xfbe482=_0x50946c;return _0x1c29c0=_0xfbe482,_0x3c63b7!==_0xfbe482['getPriority']()['val']()&&(_0x1c29c0=_0x1c29c0['updatePriority'](new D(_0x3c63b7))),_0xfbe482['forEachChild'](R,(_0x4937d0,_0xe14298)=>{const _0x2f9124=ps(_0xe14298,_0x3c8b42['getImmediateChild'](_0x4937d0),_0x1bce95);_0x2f9124!==_0xe14298&&(_0x1c29c0=_0x1c29c0['updateImmediateChild'](_0x4937d0,_0x2f9124));}),_0x1c29c0;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x850914='',_0x4317e4=null,_0x36aa42={'children':{},'childCount':0x0}){this['name']=_0x850914,this['parent']=_0x4317e4,this['node']=_0x36aa42;}}function $n(_0x3a620e,_0x3edf05){let _0x34cec7=_0x3edf05 instanceof C?_0x3edf05:new C(_0x3edf05),_0x54923c=_0x3a620e,_0x2843e1=y(_0x34cec7);for(;_0x2843e1!==null;){const _0xca952d=Le(_0x54923c['node']['children'],_0x2843e1)||{'children':{},'childCount':0x0};_0x54923c=new _s(_0x2843e1,_0x54923c,_0xca952d),_0x34cec7=S(_0x34cec7),_0x2843e1=y(_0x34cec7);}return _0x54923c;}function je(_0xb74368){return _0xb74368['node']['value'];}function gs(_0x4e6d21,_0x3bbdeb){_0x4e6d21['node']['value']=_0x3bbdeb,Oi(_0x4e6d21);}function na(_0x57aa93){return _0x57aa93['node']['childCount']>0x0;}function od(_0x281bda){return je(_0x281bda)===void 0x0&&!na(_0x281bda);}function Gn(_0x5eafd6,_0x24152c){x(_0x5eafd6['node']['children'],(_0x3b837b,_0x43741d)=>{_0x24152c(new _s(_0x3b837b,_0x5eafd6,_0x43741d));});}function ia(_0x365535,_0x19c959,_0x417ca6,_0x8c490f){_0x417ca6&&_0x19c959(_0x365535),Gn(_0x365535,_0x112dd3=>{ia(_0x112dd3,_0x19c959,!0x0);});}function ad(_0x1d74a4,_0x55922f,_0x1a2fbb){let _0xf185fb=_0x1d74a4['parent'];for(;_0xf185fb!==null;){if(_0x55922f(_0xf185fb))return!0x0;_0xf185fb=_0xf185fb['parent'];}return!0x1;}function Qt(_0xfa5b7b){return new C(_0xfa5b7b['parent']===null?_0xfa5b7b['name']:Qt(_0xfa5b7b['parent'])+'/'+_0xfa5b7b['name']);}function Oi(_0x27b902){_0x27b902['parent']!==null&&cd(_0x27b902['parent'],_0x27b902['name'],_0x27b902);}function cd(_0x1a97c5,_0x541ba6,_0x4cbbe9){const _0x28afb0=od(_0x4cbbe9),_0x28f06c=Q(_0x1a97c5['node']['children'],_0x541ba6);_0x28afb0&&_0x28f06c?(delete _0x1a97c5['node']['children'][_0x541ba6],_0x1a97c5['node']['childCount']--,Oi(_0x1a97c5)):!_0x28afb0&&!_0x28f06c&&(_0x1a97c5['node']['children'][_0x541ba6]=_0x4cbbe9['node'],_0x1a97c5['node']['childCount']++,Oi(_0x1a97c5));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x57b234){return typeof _0x57b234=='string'&&_0x57b234['length']!==0x0&&!ld['test'](_0x57b234);},sa=function(_0x3789c5){return typeof _0x3789c5=='string'&&_0x3789c5['length']!==0x0&&!hd['test'](_0x3789c5);},ud=function(_0x50648e){return _0x50648e&&(_0x50648e=_0x50648e['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x50648e);},Bt=function(_0x7c4734){return _0x7c4734===null||typeof _0x7c4734=='string'||typeof _0x7c4734=='number'&&!xn(_0x7c4734)||_0x7c4734&&typeof _0x7c4734=='object'&&Q(_0x7c4734,'.sv');},He=function(_0x272f28,_0x719a0c,_0x14924f,_0x134f21){_0x134f21&&_0x719a0c===void 0x0||Jt(it(_0x272f28,'value'),_0x719a0c,_0x14924f);},Jt=function(_0x52b46e,_0x11816d,_0x44a67f){const _0x15c6ad=_0x44a67f instanceof C?new Ah(_0x44a67f,_0x52b46e):_0x44a67f;if(_0x11816d===void 0x0)throw new Error(_0x52b46e+'contains\x20undefined\x20'+Oe(_0x15c6ad));if(typeof _0x11816d=='function')throw new Error(_0x52b46e+'contains\x20a\x20function\x20'+Oe(_0x15c6ad)+'\x20with\x20contents\x20=\x20'+_0x11816d['toString']());if(xn(_0x11816d))throw new Error(_0x52b46e+'contains\x20'+_0x11816d['toString']()+'\x20'+Oe(_0x15c6ad));if(typeof _0x11816d=='string'&&_0x11816d['length']>ui/0x3&&Ln(_0x11816d)>ui)throw new Error(_0x52b46e+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x15c6ad)+'\x20(\x27'+_0x11816d['substring'](0x0,0x32)+'...\x27)');if(_0x11816d&&typeof _0x11816d=='object'){let _0x23e357=!0x1,_0x104ab6=!0x1;if(x(_0x11816d,(_0x1c8056,_0x4652ad)=>{if(_0x1c8056==='.value')_0x23e357=!0x0;else{if(_0x1c8056!=='.priority'&&_0x1c8056!=='.sv'&&(_0x104ab6=!0x0,!ms(_0x1c8056)))throw new Error(_0x52b46e+'\x20contains\x20an\x20invalid\x20key\x20('+_0x1c8056+')\x20'+Oe(_0x15c6ad)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x15c6ad,_0x1c8056),Jt(_0x52b46e,_0x4652ad,_0x15c6ad),Ph(_0x15c6ad);}),_0x23e357&&_0x104ab6)throw new Error(_0x52b46e+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x15c6ad)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x6a6583,_0xff7935){let _0x5c7bc4,_0x1d5da5;for(_0x5c7bc4=0x0;_0x5c7bc4<_0xff7935['length'];_0x5c7bc4++){_0x1d5da5=_0xff7935[_0x5c7bc4];const _0xa1d6fa=Mt(_0x1d5da5);for(let _0xacbd4=0x0;_0xacbd4<_0xa1d6fa['length'];_0xacbd4++)if(!(_0xa1d6fa[_0xacbd4]==='.priority'&&_0xacbd4===_0xa1d6fa['length']-0x1)){if(!ms(_0xa1d6fa[_0xacbd4]))throw new Error(_0x6a6583+'contains\x20an\x20invalid\x20key\x20('+_0xa1d6fa[_0xacbd4]+')\x20in\x20path\x20'+_0x1d5da5['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0xff7935['sort'](Rh);let _0x9e39c9=null;for(_0x5c7bc4=0x0;_0x5c7bc4<_0xff7935['length'];_0x5c7bc4++){if(_0x1d5da5=_0xff7935[_0x5c7bc4],_0x9e39c9!==null&&G(_0x9e39c9,_0x1d5da5))throw new Error(_0x6a6583+'contains\x20a\x20path\x20'+_0x9e39c9['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x1d5da5['toString']());_0x9e39c9=_0x1d5da5;}},ra=function(_0x3ae566,_0x2df02d,_0x1f5a0c,_0x443ead){const _0x2f3cfd=it(_0x3ae566,'values');if(!(_0x2df02d&&typeof _0x2df02d=='object')||Array['isArray'](_0x2df02d))throw new Error(_0x2f3cfd+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x3f91aa=[];x(_0x2df02d,(_0x2fc569,_0x124934)=>{const _0x437152=new C(_0x2fc569);if(Jt(_0x2f3cfd,_0x124934,k(_0x1f5a0c,_0x437152)),ji(_0x437152)==='.priority'&&!Bt(_0x124934))throw new Error(_0x2f3cfd+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x437152['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x3f91aa['push'](_0x437152);}),dd(_0x2f3cfd,_0x3f91aa);},fd=function(_0x1ce0aa,_0x5c50f8,_0x3bcf39){if(xn(_0x5c50f8))throw new Error(it(_0x1ce0aa,'priority')+'is\x20'+_0x5c50f8['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x5c50f8))throw new Error(it(_0x1ce0aa,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x286c04,_0xdae187,_0x578c94,_0x38c17b){if(!sa(_0x578c94))throw new Error(it(_0x286c04,_0xdae187)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x578c94+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0xda06ef,_0x54119a,_0x52f321,_0x4d291c){_0x52f321&&(_0x52f321=_0x52f321['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0xda06ef,_0x54119a,_0x52f321);},Me=function(_0x447407,_0x5ba22d){if(y(_0x5ba22d)==='.info')throw new Error(_0x447407+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x1dacfd,_0x3d2e23){const _0x57b0f4=_0x3d2e23['path']['toString']();if(typeof _0x3d2e23['repoInfo']['host']!='string'||_0x3d2e23['repoInfo']['host']['length']===0x0||!ms(_0x3d2e23['repoInfo']['namespace'])&&_0x3d2e23['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x57b0f4['length']!==0x0&&!ud(_0x57b0f4))throw new Error(it(_0x1dacfd,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x385ee1,_0x32afce){let _0x381127=null;for(let _0x50cae3=0x0;_0x50cae3<_0x32afce['length'];_0x50cae3++){const _0xb79272=_0x32afce[_0x50cae3],_0x400602=_0xb79272['getPath']();_0x381127!==null&&!Ki(_0x400602,_0x381127['path'])&&(_0x385ee1['eventLists_']['push'](_0x381127),_0x381127=null),_0x381127===null&&(_0x381127={'events':[],'path':_0x400602}),_0x381127['events']['push'](_0xb79272);}_0x381127&&_0x385ee1['eventLists_']['push'](_0x381127);}function oa(_0x555c55,_0x20c192,_0x5d3f5b){qn(_0x555c55,_0x5d3f5b),aa(_0x555c55,_0x23be72=>Ki(_0x23be72,_0x20c192));}function V(_0x484674,_0x5e4ea7,_0x469313){qn(_0x484674,_0x469313),aa(_0x484674,_0x56df17=>G(_0x56df17,_0x5e4ea7)||G(_0x5e4ea7,_0x56df17));}function aa(_0x47c6af,_0xc7a642){_0x47c6af['recursionDepth_']++;let _0xa588ea=!0x0;for(let _0x220ba8=0x0;_0x220ba8<_0x47c6af['eventLists_']['length'];_0x220ba8++){const _0x30f2a2=_0x47c6af['eventLists_'][_0x220ba8];if(_0x30f2a2){const _0x5ba24f=_0x30f2a2['path'];_0xc7a642(_0x5ba24f)?(md(_0x47c6af['eventLists_'][_0x220ba8]),_0x47c6af['eventLists_'][_0x220ba8]=null):_0xa588ea=!0x1;}}_0xa588ea&&(_0x47c6af['eventLists_']=[]),_0x47c6af['recursionDepth_']--;}function md(_0x278f82){for(let _0x87a3ae=0x0;_0x87a3ae<_0x278f82['events']['length'];_0x87a3ae++){const _0x1bcfe3=_0x278f82['events'][_0x87a3ae];if(_0x1bcfe3!==null){_0x278f82['events'][_0x87a3ae]=null;const _0x30a548=_0x1bcfe3['getEventRunner']();St&&L('event:\x20'+_0x1bcfe3['toString']()),ft(_0x30a548);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x5361fa,_0x113da6,_0x490d89,_0x2e7d8b){this['repoInfo_']=_0x5361fa,this['forceRestClient_']=_0x113da6,this['authTokenProvider_']=_0x490d89,this['appCheckProvider_']=_0x2e7d8b,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x2c44b6,_0x6caa0e,_0x2b1739){if(_0x2c44b6['stats_']=qi(_0x2c44b6['repoInfo_']),_0x2c44b6['forceRestClient_']||Xl())_0x2c44b6['server_']=new vn(_0x2c44b6['repoInfo_'],(_0x327a6a,_0x10287d,_0x1c18b6,_0x3fb8c1)=>{gr(_0x2c44b6,_0x327a6a,_0x10287d,_0x1c18b6,_0x3fb8c1);},_0x2c44b6['authTokenProvider_'],_0x2c44b6['appCheckProvider_']),setTimeout(()=>mr(_0x2c44b6,!0x0),0x0);else{if(typeof _0x2b1739<'u'&&_0x2b1739!==null){if(typeof _0x2b1739!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x2b1739);}catch(_0x5bc3be){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x5bc3be);}}_0x2c44b6['persistentConnection_']=new se(_0x2c44b6['repoInfo_'],_0x6caa0e,(_0x23f69b,_0x26f93f,_0xc44ea3,_0x3b1534)=>{gr(_0x2c44b6,_0x23f69b,_0x26f93f,_0xc44ea3,_0x3b1534);},_0x2329de=>{mr(_0x2c44b6,_0x2329de);},_0x423488=>{Id(_0x2c44b6,_0x423488);},_0x2c44b6['authTokenProvider_'],_0x2c44b6['appCheckProvider_'],_0x2b1739),_0x2c44b6['server_']=_0x2c44b6['persistentConnection_'];}_0x2c44b6['authTokenProvider_']['addTokenChangeListener'](_0x18e5b2=>{_0x2c44b6['server_']['refreshAuthToken'](_0x18e5b2);}),_0x2c44b6['appCheckProvider_']['addTokenChangeListener'](_0x803989=>{_0x2c44b6['server_']['refreshAppCheckToken'](_0x803989['token']);}),_0x2c44b6['statsReporter_']=ih(_0x2c44b6['repoInfo_'],()=>new iu(_0x2c44b6['stats_'],_0x2c44b6['server_'])),_0x2c44b6['infoData_']=new Xh(),_0x2c44b6['infoSyncTree_']=new pr({'startListening':(_0x4ca1fd,_0x59d21b,_0x442b84,_0x202eee)=>{let _0x59e468=[];const _0x312b50=_0x2c44b6['infoData_']['getNode'](_0x4ca1fd['_path']);return _0x312b50['isEmpty']()||(_0x59e468=Yt(_0x2c44b6['infoSyncTree_'],_0x4ca1fd['_path'],_0x312b50),setTimeout(()=>{_0x202eee('ok');},0x0)),_0x59e468;},'stopListening':()=>{}}),vs(_0x2c44b6,'connected',!0x1),_0x2c44b6['serverSyncTree_']=new pr({'startListening':(_0x11380a,_0x56896f,_0x116689,_0xea6fba)=>(_0x2c44b6['server_']['listen'](_0x11380a,_0x116689,_0x56896f,(_0x309785,_0x143327)=>{const _0x2aaa39=_0xea6fba(_0x309785,_0x143327);V(_0x2c44b6['eventQueue_'],_0x11380a['_path'],_0x2aaa39);}),[]),'stopListening':(_0x5ca911,_0x110ab3)=>{_0x2c44b6['server_']['unlisten'](_0x5ca911,_0x110ab3);}});}function la(_0x4eeecc){const _0x4cea4d=_0x4eeecc['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x4cea4d;}function Xt(_0x26b94e){return id({'timestamp':la(_0x26b94e)});}function gr(_0x194a02,_0x415a53,_0xe55982,_0x502822,_0x4d631a){_0x194a02['dataUpdateCount']++;const _0x4f2b06=new C(_0x415a53);_0xe55982=_0x194a02['interceptServerDataCallback_']?_0x194a02['interceptServerDataCallback_'](_0x415a53,_0xe55982):_0xe55982;let _0x5355b6=[];if(_0x4d631a){if(_0x502822){const _0x45eae5=_n(_0xe55982,_0x483481=>A(_0x483481));_0x5355b6=Ju(_0x194a02['serverSyncTree_'],_0x4f2b06,_0x45eae5,_0x4d631a);}else{const _0x23d0e7=A(_0xe55982);_0x5355b6=Jo(_0x194a02['serverSyncTree_'],_0x4f2b06,_0x23d0e7,_0x4d631a);}}else{if(_0x502822){const _0x14e3c5=_n(_0xe55982,_0x32c75e=>A(_0x32c75e));_0x5355b6=Ku(_0x194a02['serverSyncTree_'],_0x4f2b06,_0x14e3c5);}else{const _0x71fa25=A(_0xe55982);_0x5355b6=Yt(_0x194a02['serverSyncTree_'],_0x4f2b06,_0x71fa25);}}let _0x33a43c=_0x4f2b06;_0x5355b6['length']>0x0&&(_0x33a43c=ct(_0x194a02,_0x4f2b06)),V(_0x194a02['eventQueue_'],_0x33a43c,_0x5355b6);}function mr(_0x156703,_0x198ad1){vs(_0x156703,'connected',_0x198ad1),_0x198ad1===!0x1&&Sd(_0x156703);}function Id(_0x1b0470,_0x2a6ee2){x(_0x2a6ee2,(_0x37c13d,_0x225639)=>{vs(_0x1b0470,_0x37c13d,_0x225639);});}function vs(_0xd5aa54,_0x30f99e,_0x15c0a2){const _0x161630=new C('/.info/'+_0x30f99e),_0x1fd717=A(_0x15c0a2);_0xd5aa54['infoData_']['updateSnapshot'](_0x161630,_0x1fd717);const _0x29d0c7=Yt(_0xd5aa54['infoSyncTree_'],_0x161630,_0x1fd717);V(_0xd5aa54['eventQueue_'],_0x161630,_0x29d0c7);}function zn(_0x5725c7){return _0x5725c7['nextWriteId_']++;}function wd(_0x52008e,_0x1c8dea,_0x1b6460){const _0xfa2aea=Xu(_0x52008e['serverSyncTree_'],_0x1c8dea);return _0xfa2aea!=null?Promise['resolve'](_0xfa2aea):_0x52008e['server_']['get'](_0x1c8dea)['then'](_0x50d699=>{const _0x361d44=A(_0x50d699)['withIndex'](_0x1c8dea['_queryParams']['getIndex']());Ni(_0x52008e['serverSyncTree_'],_0x1c8dea,_0x1b6460,!0x0);let _0x37e2e8;if(_0x1c8dea['_queryParams']['loadsAllData']())_0x37e2e8=Yt(_0x52008e['serverSyncTree_'],_0x1c8dea['_path'],_0x361d44);else{const _0x42e85a=Wt(_0x52008e['serverSyncTree_'],_0x1c8dea);_0x37e2e8=Jo(_0x52008e['serverSyncTree_'],_0x1c8dea['_path'],_0x361d44,_0x42e85a);}return V(_0x52008e['eventQueue_'],_0x1c8dea['_path'],_0x37e2e8),An(_0x52008e['serverSyncTree_'],_0x1c8dea,_0x1b6460,null,!0x0),_0x361d44;},_0x953145=>(gt(_0x52008e,'get\x20for\x20query\x20'+O(_0x1c8dea)+'\x20failed:\x20'+_0x953145),Promise['reject'](new Error(_0x953145))));}function Cd(_0x3270ef,_0x2573f8,_0x1d5a11,_0x794a65,_0xc3f64){gt(_0x3270ef,'set',{'path':_0x2573f8['toString'](),'value':_0x1d5a11,'priority':_0x794a65});const _0x7ce10d=Xt(_0x3270ef),_0x253129=A(_0x1d5a11,_0x794a65),_0x48a05e=Vn(_0x3270ef['serverSyncTree_'],_0x2573f8),_0x52ed30=fs(_0x253129,_0x48a05e,_0x7ce10d),_0x480af7=zn(_0x3270ef),_0x108322=as(_0x3270ef['serverSyncTree_'],_0x2573f8,_0x52ed30,_0x480af7,!0x0);qn(_0x3270ef['eventQueue_'],_0x108322),_0x3270ef['server_']['put'](_0x2573f8['toString'](),_0x253129['val'](!0x0),(_0x10fa53,_0x1e035c)=>{const _0x5bffab=_0x10fa53==='ok';_0x5bffab||U('set\x20at\x20'+_0x2573f8+'\x20failed:\x20'+_0x10fa53);const _0x9b1c0c=_e(_0x3270ef['serverSyncTree_'],_0x480af7,!_0x5bffab);V(_0x3270ef['eventQueue_'],_0x2573f8,_0x9b1c0c),be(_0x3270ef,_0xc3f64,_0x10fa53,_0x1e035c);});const _0x32b0b6=Is(_0x3270ef,_0x2573f8);ct(_0x3270ef,_0x32b0b6),V(_0x3270ef['eventQueue_'],_0x32b0b6,[]);}function Td(_0x53d3d1,_0x23626d,_0x9e4ca5,_0x183453){gt(_0x53d3d1,'update',{'path':_0x23626d['toString'](),'value':_0x9e4ca5});let _0x5a040a=!0x0;const _0x41ac29=Xt(_0x53d3d1),_0x2f001b={};if(x(_0x9e4ca5,(_0x23b3cc,_0xe15257)=>{_0x5a040a=!0x1,_0x2f001b[_0x23b3cc]=ta(k(_0x23626d,_0x23b3cc),A(_0xe15257),_0x53d3d1['serverSyncTree_'],_0x41ac29);}),_0x5a040a)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x53d3d1,_0x183453,'ok',void 0x0);else{const _0x1b41cd=zn(_0x53d3d1),_0x4102b5=ju(_0x53d3d1['serverSyncTree_'],_0x23626d,_0x2f001b,_0x1b41cd);qn(_0x53d3d1['eventQueue_'],_0x4102b5),_0x53d3d1['server_']['merge'](_0x23626d['toString'](),_0x9e4ca5,(_0x41cfc7,_0x190672)=>{const _0x2db17c=_0x41cfc7==='ok';_0x2db17c||U('update\x20at\x20'+_0x23626d+'\x20failed:\x20'+_0x41cfc7);const _0x486f88=_e(_0x53d3d1['serverSyncTree_'],_0x1b41cd,!_0x2db17c),_0x5f43bc=_0x486f88['length']>0x0?ct(_0x53d3d1,_0x23626d):_0x23626d;V(_0x53d3d1['eventQueue_'],_0x5f43bc,_0x486f88),be(_0x53d3d1,_0x183453,_0x41cfc7,_0x190672);}),x(_0x9e4ca5,_0x42bfbe=>{const _0x54512e=Is(_0x53d3d1,k(_0x23626d,_0x42bfbe));ct(_0x53d3d1,_0x54512e);}),V(_0x53d3d1['eventQueue_'],_0x23626d,[]);}}function Sd(_0x1bcdd8){gt(_0x1bcdd8,'onDisconnectEvents');const _0x23a250=Xt(_0x1bcdd8),_0x1a54b3=En();Si(_0x1bcdd8['onDisconnect_'],w(),(_0x126d45,_0x2e37f2)=>{const _0x2b9f88=ta(_0x126d45,_0x2e37f2,_0x1bcdd8['serverSyncTree_'],_0x23a250);pt(_0x1a54b3,_0x126d45,_0x2b9f88);});let _0x36ee63=[];Si(_0x1a54b3,w(),(_0x53b18c,_0x3cf9d8)=>{_0x36ee63=_0x36ee63['concat'](Yt(_0x1bcdd8['serverSyncTree_'],_0x53b18c,_0x3cf9d8));const _0x25ffeb=Is(_0x1bcdd8,_0x53b18c);ct(_0x1bcdd8,_0x25ffeb);}),_0x1bcdd8['onDisconnect_']=En(),V(_0x1bcdd8['eventQueue_'],w(),_0x36ee63);}function bd(_0x235979,_0x19835c,_0x3f4244){_0x235979['server_']['onDisconnectCancel'](_0x19835c['toString'](),(_0x22c2dc,_0x16bca9)=>{_0x22c2dc==='ok'&&Ti(_0x235979['onDisconnect_'],_0x19835c),be(_0x235979,_0x3f4244,_0x22c2dc,_0x16bca9);});}function yr(_0xe3d2f8,_0x459a6f,_0x269461,_0x38b200){const _0x504d40=A(_0x269461);_0xe3d2f8['server_']['onDisconnectPut'](_0x459a6f['toString'](),_0x504d40['val'](!0x0),(_0x30be69,_0x3eff4e)=>{_0x30be69==='ok'&&pt(_0xe3d2f8['onDisconnect_'],_0x459a6f,_0x504d40),be(_0xe3d2f8,_0x38b200,_0x30be69,_0x3eff4e);});}function Rd(_0x197ae1,_0x5ea605,_0x275fac,_0x46a7cd,_0x2ae3f5){const _0x547f95=A(_0x275fac,_0x46a7cd);_0x197ae1['server_']['onDisconnectPut'](_0x5ea605['toString'](),_0x547f95['val'](!0x0),(_0x22478,_0x5be3e4)=>{_0x22478==='ok'&&pt(_0x197ae1['onDisconnect_'],_0x5ea605,_0x547f95),be(_0x197ae1,_0x2ae3f5,_0x22478,_0x5be3e4);});}function Ad(_0x4ec3b7,_0x5099a4,_0x5eb030,_0x5c62c0){if(pn(_0x5eb030)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x4ec3b7,_0x5c62c0,'ok',void 0x0);return;}_0x4ec3b7['server_']['onDisconnectMerge'](_0x5099a4['toString'](),_0x5eb030,(_0x1b59fc,_0x57cc68)=>{_0x1b59fc==='ok'&&x(_0x5eb030,(_0x70b24b,_0x2db21e)=>{const _0x5d54ef=A(_0x2db21e);pt(_0x4ec3b7['onDisconnect_'],k(_0x5099a4,_0x70b24b),_0x5d54ef);}),be(_0x4ec3b7,_0x5c62c0,_0x1b59fc,_0x57cc68);});}function kd(_0xdae120,_0x172229,_0x489426){let _0x32bd23;y(_0x172229['_path'])==='.info'?_0x32bd23=Ni(_0xdae120['infoSyncTree_'],_0x172229,_0x489426):_0x32bd23=Ni(_0xdae120['serverSyncTree_'],_0x172229,_0x489426),oa(_0xdae120['eventQueue_'],_0x172229['_path'],_0x32bd23);}function Pd(_0x441e78,_0x427653,_0x119514){let _0x5ec0ea;y(_0x427653['_path'])==='.info'?_0x5ec0ea=An(_0x441e78['infoSyncTree_'],_0x427653,_0x119514):_0x5ec0ea=An(_0x441e78['serverSyncTree_'],_0x427653,_0x119514),oa(_0x441e78['eventQueue_'],_0x427653['_path'],_0x5ec0ea);}function ha(_0xd85c35){_0xd85c35['persistentConnection_']&&_0xd85c35['persistentConnection_']['interrupt'](ca);}function Nd(_0x3f0aa5){_0x3f0aa5['persistentConnection_']&&_0x3f0aa5['persistentConnection_']['resume'](ca);}function gt(_0x1a8110,..._0x1eb2f5){let _0x23aff3='';_0x1a8110['persistentConnection_']&&(_0x23aff3=_0x1a8110['persistentConnection_']['id']+':'),L(_0x23aff3,..._0x1eb2f5);}function be(_0x1802b3,_0xf6c8ac,_0x25ecb5,_0x14780a){_0xf6c8ac&&ft(()=>{if(_0x25ecb5==='ok')_0xf6c8ac(null);else{const _0x208138=(_0x25ecb5||'error')['toUpperCase']();let _0x46d111=_0x208138;_0x14780a&&(_0x46d111+=':\x20'+_0x14780a);const _0x54d79d=new Error(_0x46d111);_0x54d79d['code']=_0x208138,_0xf6c8ac(_0x54d79d);}});}function Od(_0x2e8de4,_0x424ea3,_0x20c1f6,_0x540489,_0x18d66c,_0xec4ba5){gt(_0x2e8de4,'transaction\x20on\x20'+_0x424ea3);const _0x134eab={'path':_0x424ea3,'update':_0x20c1f6,'onComplete':_0x540489,'status':null,'order':so(),'applyLocally':_0xec4ba5,'retryCount':0x0,'unwatcher':_0x18d66c,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x352628=Es(_0x2e8de4,_0x424ea3,void 0x0);_0x134eab['currentInputSnapshot']=_0x352628;const _0x29e46c=_0x134eab['update'](_0x352628['val']());if(_0x29e46c===void 0x0)_0x134eab['unwatcher'](),_0x134eab['currentOutputSnapshotRaw']=null,_0x134eab['currentOutputSnapshotResolved']=null,_0x134eab['onComplete']&&_0x134eab['onComplete'](null,!0x1,_0x134eab['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x29e46c,_0x134eab['path']),_0x134eab['status']=0x0;const _0x1acd38=$n(_0x2e8de4['transactionQueueTree_'],_0x424ea3),_0x35a705=je(_0x1acd38)||[];_0x35a705['push'](_0x134eab),gs(_0x1acd38,_0x35a705);let _0x493f08;typeof _0x29e46c=='object'&&_0x29e46c!==null&&Q(_0x29e46c,'.priority')?(_0x493f08=Le(_0x29e46c,'.priority'),f(Bt(_0x493f08),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x493f08=(Vn(_0x2e8de4['serverSyncTree_'],_0x424ea3)||g['EMPTY_NODE'])['getPriority']()['val']();const _0xe25292=Xt(_0x2e8de4),_0x1a1043=A(_0x29e46c,_0x493f08),_0x55290d=fs(_0x1a1043,_0x352628,_0xe25292);_0x134eab['currentOutputSnapshotRaw']=_0x1a1043,_0x134eab['currentOutputSnapshotResolved']=_0x55290d,_0x134eab['currentWriteId']=zn(_0x2e8de4);const _0x50d4ae=as(_0x2e8de4['serverSyncTree_'],_0x424ea3,_0x55290d,_0x134eab['currentWriteId'],_0x134eab['applyLocally']);V(_0x2e8de4['eventQueue_'],_0x424ea3,_0x50d4ae),jn(_0x2e8de4,_0x2e8de4['transactionQueueTree_']);}}function Es(_0x59786b,_0x5b1316,_0x7df9dc){return Vn(_0x59786b['serverSyncTree_'],_0x5b1316,_0x7df9dc)||g['EMPTY_NODE'];}function jn(_0x2ac74e,_0x295c66=_0x2ac74e['transactionQueueTree_']){if(_0x295c66||Kn(_0x2ac74e,_0x295c66),je(_0x295c66)){const _0xa3dea6=da(_0x2ac74e,_0x295c66);f(_0xa3dea6['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0xa3dea6['every'](_0x542f64=>_0x542f64['status']===0x0)&&Dd(_0x2ac74e,Qt(_0x295c66),_0xa3dea6);}else na(_0x295c66)&&Gn(_0x295c66,_0x299e72=>{jn(_0x2ac74e,_0x299e72);});}function Dd(_0x103870,_0x318332,_0x3a2140){const _0x3ed7bc=_0x3a2140['map'](_0x51e3c7=>_0x51e3c7['currentWriteId']),_0xb53644=Es(_0x103870,_0x318332,_0x3ed7bc);let _0xadde57=_0xb53644;const _0x2832ae=_0xb53644['hash']();for(let _0x3e2d00=0x0;_0x3e2d00<_0x3a2140['length'];_0x3e2d00++){const _0x2fd826=_0x3a2140[_0x3e2d00];f(_0x2fd826['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x2fd826['status']=0x1,_0x2fd826['retryCount']++;const _0x501a87=F(_0x318332,_0x2fd826['path']);_0xadde57=_0xadde57['updateChild'](_0x501a87,_0x2fd826['currentOutputSnapshotRaw']);}const _0x3fd865=_0xadde57['val'](!0x0),_0x409a0a=_0x318332;_0x103870['server_']['put'](_0x409a0a['toString'](),_0x3fd865,_0x235943=>{gt(_0x103870,'transaction\x20put\x20response',{'path':_0x409a0a['toString'](),'status':_0x235943});let _0xbb1f41=[];if(_0x235943==='ok'){const _0x1fd8d4=[];for(let _0x2d23ab=0x0;_0x2d23ab<_0x3a2140['length'];_0x2d23ab++)_0x3a2140[_0x2d23ab]['status']=0x2,_0xbb1f41=_0xbb1f41['concat'](_e(_0x103870['serverSyncTree_'],_0x3a2140[_0x2d23ab]['currentWriteId'])),_0x3a2140[_0x2d23ab]['onComplete']&&_0x1fd8d4['push'](()=>_0x3a2140[_0x2d23ab]['onComplete'](null,!0x0,_0x3a2140[_0x2d23ab]['currentOutputSnapshotResolved'])),_0x3a2140[_0x2d23ab]['unwatcher']();Kn(_0x103870,$n(_0x103870['transactionQueueTree_'],_0x318332)),jn(_0x103870,_0x103870['transactionQueueTree_']),V(_0x103870['eventQueue_'],_0x318332,_0xbb1f41);for(let _0x498f8e=0x0;_0x498f8e<_0x1fd8d4['length'];_0x498f8e++)ft(_0x1fd8d4[_0x498f8e]);}else{if(_0x235943==='datastale'){for(let _0x164ad6=0x0;_0x164ad6<_0x3a2140['length'];_0x164ad6++)_0x3a2140[_0x164ad6]['status']===0x3?_0x3a2140[_0x164ad6]['status']=0x4:_0x3a2140[_0x164ad6]['status']=0x0;}else{U('transaction\x20at\x20'+_0x409a0a['toString']()+'\x20failed:\x20'+_0x235943);for(let _0x59d2dd=0x0;_0x59d2dd<_0x3a2140['length'];_0x59d2dd++)_0x3a2140[_0x59d2dd]['status']=0x4,_0x3a2140[_0x59d2dd]['abortReason']=_0x235943;}ct(_0x103870,_0x318332);}},_0x2832ae);}function ct(_0x4d344b,_0x3dda42){const _0x58cd58=ua(_0x4d344b,_0x3dda42),_0x257fa5=Qt(_0x58cd58),_0x520628=da(_0x4d344b,_0x58cd58);return Md(_0x4d344b,_0x520628,_0x257fa5),_0x257fa5;}function Md(_0x10da83,_0x5c218a,_0x53744f){if(_0x5c218a['length']===0x0)return;const _0x472cec=[];let _0x33e4a8=[];const _0x5d5fe2=_0x5c218a['filter'](_0x32c715=>_0x32c715['status']===0x0)['map'](_0x2fd44a=>_0x2fd44a['currentWriteId']);for(let _0x3ba032=0x0;_0x3ba032<_0x5c218a['length'];_0x3ba032++){const _0x3dc557=_0x5c218a[_0x3ba032],_0x522cce=F(_0x53744f,_0x3dc557['path']);let _0x15d393=!0x1,_0x45a6e7;if(f(_0x522cce!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x3dc557['status']===0x4)_0x15d393=!0x0,_0x45a6e7=_0x3dc557['abortReason'],_0x33e4a8=_0x33e4a8['concat'](_e(_0x10da83['serverSyncTree_'],_0x3dc557['currentWriteId'],!0x0));else{if(_0x3dc557['status']===0x0){if(_0x3dc557['retryCount']>=yd)_0x15d393=!0x0,_0x45a6e7='maxretry',_0x33e4a8=_0x33e4a8['concat'](_e(_0x10da83['serverSyncTree_'],_0x3dc557['currentWriteId'],!0x0));else{const _0x51e42c=Es(_0x10da83,_0x3dc557['path'],_0x5d5fe2);_0x3dc557['currentInputSnapshot']=_0x51e42c;const _0x2575f6=_0x5c218a[_0x3ba032]['update'](_0x51e42c['val']());if(_0x2575f6!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x2575f6,_0x3dc557['path']);let _0x28051b=A(_0x2575f6);typeof _0x2575f6=='object'&&_0x2575f6!=null&&Q(_0x2575f6,'.priority')||(_0x28051b=_0x28051b['updatePriority'](_0x51e42c['getPriority']()));const _0x1a0ffe=_0x3dc557['currentWriteId'],_0x282a82=Xt(_0x10da83),_0x1aa17a=fs(_0x28051b,_0x51e42c,_0x282a82);_0x3dc557['currentOutputSnapshotRaw']=_0x28051b,_0x3dc557['currentOutputSnapshotResolved']=_0x1aa17a,_0x3dc557['currentWriteId']=zn(_0x10da83),_0x5d5fe2['splice'](_0x5d5fe2['indexOf'](_0x1a0ffe),0x1),_0x33e4a8=_0x33e4a8['concat'](as(_0x10da83['serverSyncTree_'],_0x3dc557['path'],_0x1aa17a,_0x3dc557['currentWriteId'],_0x3dc557['applyLocally'])),_0x33e4a8=_0x33e4a8['concat'](_e(_0x10da83['serverSyncTree_'],_0x1a0ffe,!0x0));}else _0x15d393=!0x0,_0x45a6e7='nodata',_0x33e4a8=_0x33e4a8['concat'](_e(_0x10da83['serverSyncTree_'],_0x3dc557['currentWriteId'],!0x0));}}}V(_0x10da83['eventQueue_'],_0x53744f,_0x33e4a8),_0x33e4a8=[],_0x15d393&&(_0x5c218a[_0x3ba032]['status']=0x2,function(_0x1bf8cf){setTimeout(_0x1bf8cf,Math['floor'](0x0));}(_0x5c218a[_0x3ba032]['unwatcher']),_0x5c218a[_0x3ba032]['onComplete']&&(_0x45a6e7==='nodata'?_0x472cec['push'](()=>_0x5c218a[_0x3ba032]['onComplete'](null,!0x1,_0x5c218a[_0x3ba032]['currentInputSnapshot'])):_0x472cec['push'](()=>_0x5c218a[_0x3ba032]['onComplete'](new Error(_0x45a6e7),!0x1,null))));}Kn(_0x10da83,_0x10da83['transactionQueueTree_']);for(let _0x40cfcb=0x0;_0x40cfcb<_0x472cec['length'];_0x40cfcb++)ft(_0x472cec[_0x40cfcb]);jn(_0x10da83,_0x10da83['transactionQueueTree_']);}function ua(_0x20fd13,_0x13fc44){let _0x1cc565,_0x50f717=_0x20fd13['transactionQueueTree_'];for(_0x1cc565=y(_0x13fc44);_0x1cc565!==null&&je(_0x50f717)===void 0x0;)_0x50f717=$n(_0x50f717,_0x1cc565),_0x13fc44=S(_0x13fc44),_0x1cc565=y(_0x13fc44);return _0x50f717;}function da(_0x23c1f4,_0x25fe1a){const _0xc84d2a=[];return fa(_0x23c1f4,_0x25fe1a,_0xc84d2a),_0xc84d2a['sort']((_0x2f89dc,_0x31a305)=>_0x2f89dc['order']-_0x31a305['order']),_0xc84d2a;}function fa(_0x3e9006,_0x124196,_0x4eb5a8){const _0x48eb57=je(_0x124196);if(_0x48eb57){for(let _0x4d5563=0x0;_0x4d5563<_0x48eb57['length'];_0x4d5563++)_0x4eb5a8['push'](_0x48eb57[_0x4d5563]);}Gn(_0x124196,_0x705739=>{fa(_0x3e9006,_0x705739,_0x4eb5a8);});}function Kn(_0x23da48,_0x5cbbf0){const _0x36fc74=je(_0x5cbbf0);if(_0x36fc74){let _0x1b2ed2=0x0;for(let _0x570427=0x0;_0x570427<_0x36fc74['length'];_0x570427++)_0x36fc74[_0x570427]['status']!==0x2&&(_0x36fc74[_0x1b2ed2]=_0x36fc74[_0x570427],_0x1b2ed2++);_0x36fc74['length']=_0x1b2ed2,gs(_0x5cbbf0,_0x36fc74['length']>0x0?_0x36fc74:void 0x0);}Gn(_0x5cbbf0,_0x23705a=>{Kn(_0x23da48,_0x23705a);});}function Is(_0x22c341,_0x1ec1e8){const _0x489411=Qt(ua(_0x22c341,_0x1ec1e8)),_0x370b90=$n(_0x22c341['transactionQueueTree_'],_0x1ec1e8);return ad(_0x370b90,_0x499e3c=>{di(_0x22c341,_0x499e3c);}),di(_0x22c341,_0x370b90),ia(_0x370b90,_0x381905=>{di(_0x22c341,_0x381905);}),_0x489411;}function di(_0x5c3347,_0x5b67d9){const _0x43daaa=je(_0x5b67d9);if(_0x43daaa){const _0x99714f=[];let _0x528206=[],_0x1a2d84=-0x1;for(let _0x58123f=0x0;_0x58123f<_0x43daaa['length'];_0x58123f++)_0x43daaa[_0x58123f]['status']===0x3||(_0x43daaa[_0x58123f]['status']===0x1?(f(_0x1a2d84===_0x58123f-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x1a2d84=_0x58123f,_0x43daaa[_0x58123f]['status']=0x3,_0x43daaa[_0x58123f]['abortReason']='set'):(f(_0x43daaa[_0x58123f]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x43daaa[_0x58123f]['unwatcher'](),_0x528206=_0x528206['concat'](_e(_0x5c3347['serverSyncTree_'],_0x43daaa[_0x58123f]['currentWriteId'],!0x0)),_0x43daaa[_0x58123f]['onComplete']&&_0x99714f['push'](_0x43daaa[_0x58123f]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x1a2d84===-0x1?gs(_0x5b67d9,void 0x0):_0x43daaa['length']=_0x1a2d84+0x1,V(_0x5c3347['eventQueue_'],Qt(_0x5b67d9),_0x528206);for(let _0x422977=0x0;_0x422977<_0x99714f['length'];_0x422977++)ft(_0x99714f[_0x422977]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x3b6379){let _0x74db13='';const _0x3b2520=_0x3b6379['split']('/');for(let _0x3fbc91=0x0;_0x3fbc91<_0x3b2520['length'];_0x3fbc91++)if(_0x3b2520[_0x3fbc91]['length']>0x0){let _0x420994=_0x3b2520[_0x3fbc91];try{_0x420994=decodeURIComponent(_0x420994['replace'](/\+/g,'\x20'));}catch{}_0x74db13+='/'+_0x420994;}return _0x74db13;}function xd(_0x149836){const _0x509f31={};_0x149836['charAt'](0x0)==='?'&&(_0x149836=_0x149836['substring'](0x1));for(const _0x3ce3c1 of _0x149836['split']('&')){if(_0x3ce3c1['length']===0x0)continue;const _0x402113=_0x3ce3c1['split']('=');_0x402113['length']===0x2?_0x509f31[decodeURIComponent(_0x402113[0x0])]=decodeURIComponent(_0x402113[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x3ce3c1+'\x27\x20in\x20query\x20\x27'+_0x149836+'\x27');}return _0x509f31;}const vr=function(_0x38ee72,_0x394a43){const _0xb0eb80=Fd(_0x38ee72),_0x34731e=_0xb0eb80['namespace'];_0xb0eb80['domain']==='firebase.com'&&ae(_0xb0eb80['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x34731e||_0x34731e==='undefined')&&_0xb0eb80['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0xb0eb80['secure']||$l();const _0x23ecaf=_0xb0eb80['scheme']==='ws'||_0xb0eb80['scheme']==='wss';return{'repoInfo':new yo(_0xb0eb80['host'],_0xb0eb80['secure'],_0x34731e,_0x23ecaf,_0x394a43,'',_0x34731e!==_0xb0eb80['subdomain']),'path':new C(_0xb0eb80['pathString'])};},Fd=function(_0x4d28b9){let _0x1de758='',_0x58a72b='',_0x906fde='',_0x1a0b44='',_0x17f3d9='',_0x4a9147=!0x0,_0x5a853d='https',_0x4818e4=0x1bb;if(typeof _0x4d28b9=='string'){let _0x52c816=_0x4d28b9['indexOf']('//');_0x52c816>=0x0&&(_0x5a853d=_0x4d28b9['substring'](0x0,_0x52c816-0x1),_0x4d28b9=_0x4d28b9['substring'](_0x52c816+0x2));let _0x3aa0bb=_0x4d28b9['indexOf']('/');_0x3aa0bb===-0x1&&(_0x3aa0bb=_0x4d28b9['length']);let _0x56cc18=_0x4d28b9['indexOf']('?');_0x56cc18===-0x1&&(_0x56cc18=_0x4d28b9['length']),_0x1de758=_0x4d28b9['substring'](0x0,Math['min'](_0x3aa0bb,_0x56cc18)),_0x3aa0bb<_0x56cc18&&(_0x1a0b44=Ld(_0x4d28b9['substring'](_0x3aa0bb,_0x56cc18)));const _0x473057=xd(_0x4d28b9['substring'](Math['min'](_0x4d28b9['length'],_0x56cc18)));_0x52c816=_0x1de758['indexOf'](':'),_0x52c816>=0x0?(_0x4a9147=_0x5a853d==='https'||_0x5a853d==='wss',_0x4818e4=parseInt(_0x1de758['substring'](_0x52c816+0x1),0xa)):_0x52c816=_0x1de758['length'];const _0xc447f2=_0x1de758['slice'](0x0,_0x52c816);if(_0xc447f2['toLowerCase']()==='localhost')_0x58a72b='localhost';else{if(_0xc447f2['split']('.')['length']<=0x2)_0x58a72b=_0xc447f2;else{const _0x27dba9=_0x1de758['indexOf']('.');_0x906fde=_0x1de758['substring'](0x0,_0x27dba9)['toLowerCase'](),_0x58a72b=_0x1de758['substring'](_0x27dba9+0x1),_0x17f3d9=_0x906fde;}}'ns'in _0x473057&&(_0x17f3d9=_0x473057['ns']);}return{'host':_0x1de758,'port':_0x4818e4,'domain':_0x58a72b,'subdomain':_0x906fde,'secure':_0x4a9147,'scheme':_0x5a853d,'pathString':_0x1a0b44,'namespace':_0x17f3d9};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x26a6d1=0x0;const _0xba820e=[];return function(_0x19ff0a){const _0x2ed85c=_0x19ff0a===_0x26a6d1;_0x26a6d1=_0x19ff0a;let _0x2562b5;const _0x3ba0d4=new Array(0x8);for(_0x2562b5=0x7;_0x2562b5>=0x0;_0x2562b5--)_0x3ba0d4[_0x2562b5]=Er['charAt'](_0x19ff0a%0x40),_0x19ff0a=Math['floor'](_0x19ff0a/0x40);f(_0x19ff0a===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x33d730=_0x3ba0d4['join']('');if(_0x2ed85c){for(_0x2562b5=0xb;_0x2562b5>=0x0&&_0xba820e[_0x2562b5]===0x3f;_0x2562b5--)_0xba820e[_0x2562b5]=0x0;_0xba820e[_0x2562b5]++;}else{for(_0x2562b5=0x0;_0x2562b5<0xc;_0x2562b5++)_0xba820e[_0x2562b5]=Math['floor'](Math['random']()*0x40);}for(_0x2562b5=0x0;_0x2562b5<0xc;_0x2562b5++)_0x33d730+=Er['charAt'](_0xba820e[_0x2562b5]);return f(_0x33d730['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x33d730;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x51d57e,_0x406b7c,_0x2b079e,_0x221705){this['eventType']=_0x51d57e,this['eventRegistration']=_0x406b7c,this['snapshot']=_0x2b079e,this['prevName']=_0x221705;}['getPath'](){const _0x5aecb1=this['snapshot']['ref'];return this['eventType']==='value'?_0x5aecb1['_path']:_0x5aecb1['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x500066,_0x5bdaa5,_0x2b1303){this['eventRegistration']=_0x500066,this['error']=_0x5bdaa5,this['path']=_0x2b1303;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x4b93b5,_0x4fe760){this['snapshotCallback']=_0x4b93b5,this['cancelCallback']=_0x4fe760;}['onValue'](_0x283117,_0x43a4b8){this['snapshotCallback']['call'](null,_0x283117,_0x43a4b8);}['onCancel'](_0x1a072e){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x1a072e);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x8e5d96){return this['snapshotCallback']===_0x8e5d96['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x8e5d96['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x8e5d96['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x3e0e57,_0x1a78e8){this['_repo']=_0x3e0e57,this['_path']=_0x1a78e8;}['cancel'](){const _0x58a18b=new H();return bd(this['_repo'],this['_path'],_0x58a18b['wrapCallback'](()=>{})),_0x58a18b['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x48ca3f=new H();return yr(this['_repo'],this['_path'],null,_0x48ca3f['wrapCallback'](()=>{})),_0x48ca3f['promise'];}['set'](_0x465383){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x465383,this['_path'],!0x1);const _0x5c8193=new H();return yr(this['_repo'],this['_path'],_0x465383,_0x5c8193['wrapCallback'](()=>{})),_0x5c8193['promise'];}['setWithPriority'](_0x5b062b,_0x2efa28){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x5b062b,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x2efa28);const _0x4d7af1=new H();return Rd(this['_repo'],this['_path'],_0x5b062b,_0x2efa28,_0x4d7af1['wrapCallback'](()=>{})),_0x4d7af1['promise'];}['update'](_0x585ad2){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x585ad2,this['_path']);const _0x38dbd4=new H();return Ad(this['_repo'],this['_path'],_0x585ad2,_0x38dbd4['wrapCallback'](()=>{})),_0x38dbd4['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x5aa12f,_0x1015b9,_0x599a72,_0x1bfdba){this['_repo']=_0x5aa12f,this['_path']=_0x1015b9,this['_queryParams']=_0x599a72,this['_orderByCalled']=_0x1bfdba;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x16220f=sr(this['_queryParams']),_0x1dd77f=$i(_0x16220f);return _0x1dd77f==='{}'?'default':_0x1dd77f;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x244303){if(_0x244303=P(_0x244303),!(_0x244303 instanceof Ae))return!0x1;const _0x11f568=this['_repo']===_0x244303['_repo'],_0x2bbb21=Ki(this['_path'],_0x244303['_path']),_0xcf4818=this['_queryIdentifier']===_0x244303['_queryIdentifier'];return _0x11f568&&_0x2bbb21&&_0xcf4818;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x2c277d,_0x4a5745){if(_0x2c277d['_orderByCalled']===!0x0)throw new Error(_0x4a5745+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x1186fc){let _0x575573=null,_0x2ccba4=null;if(_0x1186fc['hasStart']()&&(_0x575573=_0x1186fc['getIndexStartValue']()),_0x1186fc['hasEnd']()&&(_0x2ccba4=_0x1186fc['getIndexEndValue']()),_0x1186fc['getIndex']()===ve){const _0x502680='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x2f8c17='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x1186fc['hasStart']()){if(_0x1186fc['getIndexStartName']()!==We)throw new Error(_0x502680);if(typeof _0x575573!='string')throw new Error(_0x2f8c17);}if(_0x1186fc['hasEnd']()){if(_0x1186fc['getIndexEndName']()!==we)throw new Error(_0x502680);if(typeof _0x2ccba4!='string')throw new Error(_0x2f8c17);}}else{if(_0x1186fc['getIndex']()===R){if(_0x575573!=null&&!Bt(_0x575573)||_0x2ccba4!=null&&!Bt(_0x2ccba4))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x1186fc['getIndex']()instanceof Ji||_0x1186fc['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x575573!=null&&typeof _0x575573=='object'||_0x2ccba4!=null&&typeof _0x2ccba4=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x1de796){if(_0x1de796['hasStart']()&&_0x1de796['hasEnd']()&&_0x1de796['hasLimit']()&&!_0x1de796['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x1ab69d,_0x2d123c){super(_0x1ab69d,_0x2d123c,new Zi(),!0x1);}get['parent'](){const _0x39551b=Ro(this['_path']);return _0x39551b===null?null:new ee(this['_repo'],_0x39551b);}get['root'](){let _0x5d523c=this;for(;_0x5d523c['parent']!==null;)_0x5d523c=_0x5d523c['parent'];return _0x5d523c;}}class lt{constructor(_0xa8a4c9,_0x2dbd29,_0x122880){this['_node']=_0xa8a4c9,this['ref']=_0x2dbd29,this['_index']=_0x122880;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x1cca56){const _0x4f5da3=new C(_0x1cca56),_0x4be01d=Vt(this['ref'],_0x1cca56);return new lt(this['_node']['getChild'](_0x4f5da3),_0x4be01d,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0xcd7c72){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x11ac30,_0xb47c45)=>_0xcd7c72(new lt(_0xb47c45,Vt(this['ref'],_0x11ac30),R)));}['hasChild'](_0x106311){const _0x24fe5a=new C(_0x106311);return!this['_node']['getChild'](_0x24fe5a)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x306032,_0x20d248){return _0x306032=P(_0x306032),_0x306032['_checkNotDeleted']('ref'),_0x20d248!==void 0x0?Vt(_0x306032['_root'],_0x20d248):_0x306032['_root'];}function Vt(_0x82dc23,_0x48aeea){return _0x82dc23=P(_0x82dc23),y(_0x82dc23['_path'])===null?pd('child','path',_0x48aeea):ys('child','path',_0x48aeea),new ee(_0x82dc23['_repo'],k(_0x82dc23['_path'],_0x48aeea));}function v_(_0x2ae515){return _0x2ae515=P(_0x2ae515),new Vd(_0x2ae515['_repo'],_0x2ae515['_path']);}function E_(_0x141567,_0x33a4c8){_0x141567=P(_0x141567),Me('push',_0x141567['_path']),He('push',_0x33a4c8,_0x141567['_path'],!0x0);const _0x197e37=la(_0x141567['_repo']),_0x303bc2=Ud(_0x197e37),_0x35b992=Vt(_0x141567,_0x303bc2),_0x1be80d=Vt(_0x141567,_0x303bc2);let _0x15cb3e;return _0x33a4c8!=null?_0x15cb3e=Hd(_0x1be80d,_0x33a4c8)['then'](()=>_0x1be80d):_0x15cb3e=Promise['resolve'](_0x1be80d),_0x35b992['then']=_0x15cb3e['then']['bind'](_0x15cb3e),_0x35b992['catch']=_0x15cb3e['then']['bind'](_0x15cb3e,void 0x0),_0x35b992;}function Hd(_0x56300e,_0x33d340){_0x56300e=P(_0x56300e),Me('set',_0x56300e['_path']),He('set',_0x33d340,_0x56300e['_path'],!0x1);const _0x3310c0=new H();return Cd(_0x56300e['_repo'],_0x56300e['_path'],_0x33d340,null,_0x3310c0['wrapCallback'](()=>{})),_0x3310c0['promise'];}function I_(_0x46bb73,_0x181cc7){ra('update',_0x181cc7,_0x46bb73['_path']);const _0x1323c1=new H();return Td(_0x46bb73['_repo'],_0x46bb73['_path'],_0x181cc7,_0x1323c1['wrapCallback'](()=>{})),_0x1323c1['promise'];}function w_(_0xca100b){_0xca100b=P(_0xca100b);const _0x27f429=new pa(()=>{}),_0x2200bc=new Qn(_0x27f429);return wd(_0xca100b['_repo'],_0xca100b,_0x2200bc)['then'](_0x1c8c82=>new lt(_0x1c8c82,new ee(_0xca100b['_repo'],_0xca100b['_path']),_0xca100b['_queryParams']['getIndex']()));}class Qn{constructor(_0x2c9add){this['callbackContext']=_0x2c9add;}['respondsTo'](_0x58a477){return _0x58a477==='value';}['createEvent'](_0x125f07,_0xcb24b){const _0x5006a4=_0xcb24b['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x125f07['snapshotNode'],new ee(_0xcb24b['_repo'],_0xcb24b['_path']),_0x5006a4));}['getEventRunner'](_0x397d1f){return _0x397d1f['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x397d1f['error']):()=>this['callbackContext']['onValue'](_0x397d1f['snapshot'],null);}['createCancelEvent'](_0x1fa19b,_0x329781){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x1fa19b,_0x329781):null;}['matches'](_0x59444e){return _0x59444e instanceof Qn?!_0x59444e['callbackContext']||!this['callbackContext']?!0x0:_0x59444e['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x17fd26,_0x2e88e5,_0x69fe33,_0x45d997,_0x8ec6d3){const _0x10032d=new pa(_0x69fe33,void 0x0),_0x5d389d=new Qn(_0x10032d);return kd(_0x17fd26['_repo'],_0x17fd26,_0x5d389d),()=>Pd(_0x17fd26['_repo'],_0x17fd26,_0x5d389d);}function Gd(_0x4fc96f,_0x1f43be,_0x2bb509,_0x5763fb){return $d(_0x4fc96f,'value',_0x1f43be);}class mt{}class ma extends mt{constructor(_0x1f61c4,_0x315f77){super(),this['_value']=_0x1f61c4,this['_key']=_0x315f77,this['type']='endAt';}['_apply'](_0x13074a){He('endAt',this['_value'],_0x13074a['_path'],!0x0);const _0x2fffc2=Jh(_0x13074a['_queryParams'],this['_value'],this['_key']);if(ga(_0x2fffc2),Yn(_0x2fffc2),_0x13074a['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x13074a['_repo'],_0x13074a['_path'],_0x2fffc2,_0x13074a['_orderByCalled']);}}function C_(_0x3d2cfe,_0x132ec0){return new ma(_0x3d2cfe,_0x132ec0);}class ya extends mt{constructor(_0x22063d,_0x1e467a){super(),this['_value']=_0x22063d,this['_key']=_0x1e467a,this['type']='startAt';}['_apply'](_0x29dfd0){He('startAt',this['_value'],_0x29dfd0['_path'],!0x0);const _0x4dd549=Qh(_0x29dfd0['_queryParams'],this['_value'],this['_key']);if(ga(_0x4dd549),Yn(_0x4dd549),_0x29dfd0['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x29dfd0['_repo'],_0x29dfd0['_path'],_0x4dd549,_0x29dfd0['_orderByCalled']);}}function T_(_0x1652a1=null,_0x44e0aa){return new ya(_0x1652a1,_0x44e0aa);}class qd extends mt{constructor(_0x2ffad5){super(),this['_limit']=_0x2ffad5,this['type']='limitToFirst';}['_apply'](_0x4a2835){if(_0x4a2835['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x4a2835['_repo'],_0x4a2835['_path'],Yh(_0x4a2835['_queryParams'],this['_limit']),_0x4a2835['_orderByCalled']);}}function S_(_0x3a4a70){if(Math['floor'](_0x3a4a70)!==_0x3a4a70||_0x3a4a70<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x3a4a70);}class zd extends mt{constructor(_0x48c947){super(),this['_path']=_0x48c947,this['type']='orderByChild';}['_apply'](_0x2da2f6){_a(_0x2da2f6,'orderByChild');const _0x1761ee=new C(this['_path']);if(v(_0x1761ee))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x4898c0=new Ji(_0x1761ee),_0x49b331=xo(_0x2da2f6['_queryParams'],_0x4898c0);return Yn(_0x49b331),new Ae(_0x2da2f6['_repo'],_0x2da2f6['_path'],_0x49b331,!0x0);}}function b_(_0x17f021){if(_0x17f021==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x17f021==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x17f021==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x17f021),new zd(_0x17f021);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0xdc7991){_a(_0xdc7991,'orderByKey');const _0x31d28c=xo(_0xdc7991['_queryParams'],ve);return Yn(_0x31d28c),new Ae(_0xdc7991['_repo'],_0xdc7991['_path'],_0x31d28c,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x4fce91,_0x2c7469){super(),this['_value']=_0x4fce91,this['_key']=_0x2c7469,this['type']='equalTo';}['_apply'](_0x1bea3e){if(He('equalTo',this['_value'],_0x1bea3e['_path'],!0x1),_0x1bea3e['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x1bea3e['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x1bea3e));}}function A_(_0x16c267,_0x2a5add){return new Kd(_0x16c267,_0x2a5add);}function k_(_0x4e5fe7,..._0x2cff33){let _0x594510=P(_0x4e5fe7);for(const _0x3435b5 of _0x2cff33)_0x594510=_0x3435b5['_apply'](_0x594510);return _0x594510;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x3c87f6,_0x43fc1e,_0x46dd22,_0x5da1e4){const _0x30645a=_0x43fc1e['lastIndexOf'](':'),_0x13f174=_0x43fc1e['substring'](0x0,_0x30645a),_0x4471dc=qt(_0x13f174);_0x3c87f6['repoInfo_']=new yo(_0x43fc1e,_0x4471dc,_0x3c87f6['repoInfo_']['namespace'],_0x3c87f6['repoInfo_']['webSocketOnly'],_0x3c87f6['repoInfo_']['nodeAdmin'],_0x3c87f6['repoInfo_']['persistenceKey'],_0x3c87f6['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x46dd22),_0x5da1e4&&(_0x3c87f6['authTokenProvider_']=_0x5da1e4);}function Xd(_0x211d13,_0x28553e,_0x8694a2,_0x1c6153,_0x447c1c){let _0x42de11=_0x1c6153||_0x211d13['options']['databaseURL'];_0x42de11===void 0x0&&(_0x211d13['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x211d13['options']['projectId']),_0x42de11=_0x211d13['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x2ac9fb=vr(_0x42de11,_0x447c1c),_0x11b465=_0x2ac9fb['repoInfo'],_0x9e88d7;typeof process<'u'&&Bs&&(_0x9e88d7=Bs[Yd]),_0x9e88d7?(_0x42de11='http://'+_0x9e88d7+'?ns='+_0x11b465['namespace'],_0x2ac9fb=vr(_0x42de11,_0x447c1c),_0x11b465=_0x2ac9fb['repoInfo']):_0x2ac9fb['repoInfo']['secure'];const _0x1a876a=new eh(_0x211d13['name'],_0x211d13['options'],_0x28553e);_d('Invalid\x20Firebase\x20Database\x20URL',_0x2ac9fb),v(_0x2ac9fb['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x26883b=ef(_0x11b465,_0x211d13,_0x1a876a,new Zl(_0x211d13,_0x8694a2));return new tf(_0x26883b,_0x211d13);}function Zd(_0xf3ca1f,_0x126ecf){const _0x519ea7=Di[_0x126ecf];(!_0x519ea7||_0x519ea7[_0xf3ca1f['key']]!==_0xf3ca1f)&&ae('Database\x20'+_0x126ecf+'('+_0xf3ca1f['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0xf3ca1f),delete _0x519ea7[_0xf3ca1f['key']];}function ef(_0x1f9381,_0x31a52a,_0x22aa4e,_0x31c0b3){let _0x55615e=Di[_0x31a52a['name']];_0x55615e||(_0x55615e={},Di[_0x31a52a['name']]=_0x55615e);let _0x22f87e=_0x55615e[_0x1f9381['toURLString']()];return _0x22f87e&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x22f87e=new vd(_0x1f9381,Qd,_0x22aa4e,_0x31c0b3),_0x55615e[_0x1f9381['toURLString']()]=_0x22f87e,_0x22f87e;}class tf{constructor(_0x572fee,_0x1b7020){this['_repoInternal']=_0x572fee,this['app']=_0x1b7020,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x456afc){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x456afc+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x69434f=Zr(),_0x9d1068){const _0x28e64f=Hi(_0x69434f,'database')['getImmediate']({'identifier':_0x9d1068});if(!_0x28e64f['_instanceStarted']){const _0x57ebb9=hc('database');_0x57ebb9&&nf(_0x28e64f,..._0x57ebb9);}return _0x28e64f;}function nf(_0x5356ae,_0x3b6033,_0x38b626,_0x13b0a8={}){_0x5356ae=P(_0x5356ae),_0x5356ae['_checkNotDeleted']('useEmulator');const _0x19defb=_0x3b6033+':'+_0x38b626,_0x3bbd8e=_0x5356ae['_repoInternal'];if(_0x5356ae['_instanceStarted']){if(_0x19defb===_0x5356ae['_repoInternal']['repoInfo_']['host']&&xe(_0x13b0a8,_0x3bbd8e['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x45ab5e;if(_0x3bbd8e['repoInfo_']['nodeAdmin'])_0x13b0a8['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x45ab5e=new an(an['OWNER']);else{if(_0x13b0a8['mockUserToken']){const _0x507ba5=typeof _0x13b0a8['mockUserToken']=='string'?_0x13b0a8['mockUserToken']:uc(_0x13b0a8['mockUserToken'],_0x5356ae['app']['options']['projectId']);_0x45ab5e=new an(_0x507ba5);}}qt(_0x3b6033)&&Qr(_0x3b6033),Jd(_0x3bbd8e,_0x19defb,_0x13b0a8,_0x45ab5e);}function N_(_0x170e32){_0x170e32=P(_0x170e32),_0x170e32['_checkNotDeleted']('goOffline'),ha(_0x170e32['_repo']);}function O_(_0x250c0e){_0x250c0e=P(_0x250c0e),_0x250c0e['_checkNotDeleted']('goOnline'),Nd(_0x250c0e['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x44e1e1){Ul(dt),st(new Fe('database',(_0x56e406,{instanceIdentifier:_0x409bc2})=>{const _0xf707a9=_0x56e406['getProvider']('app')['getImmediate'](),_0x2d540a=_0x56e406['getProvider']('auth-internal'),_0xb0aad0=_0x56e406['getProvider']('app-check-internal');return Xd(_0xf707a9,_0x2d540a,_0xb0aad0,_0x409bc2);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x44e1e1),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x5198e2,_0x335790){this['committed']=_0x5198e2,this['snapshot']=_0x335790;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x22c65b,_0x23ec0c,_0x27b911){if(_0x22c65b=P(_0x22c65b),Me('Reference.transaction',_0x22c65b['_path']),_0x22c65b['key']==='.length'||_0x22c65b['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x22c65b['key']+'\x20is\x20a\x20read-only\x20object.';const _0x151d89=!0x0,_0x76193b=new H(),_0x104159=(_0xe5858f,_0x5c7613,_0x10a74d)=>{let _0x589d09=null;_0xe5858f?_0x76193b['reject'](_0xe5858f):(_0x589d09=new lt(_0x10a74d,new ee(_0x22c65b['_repo'],_0x22c65b['_path']),R),_0x76193b['resolve'](new of(_0x5c7613,_0x589d09)));},_0x2edcff=Gd(_0x22c65b,()=>{});return Od(_0x22c65b['_repo'],_0x22c65b['_path'],_0x23ec0c,_0x104159,_0x2edcff,_0x151d89),_0x76193b['promise'];}se['prototype']['simpleListen']=function(_0x5e6bfc,_0x5d39c9){this['sendRequest']('q',{'p':_0x5e6bfc},_0x5d39c9);},se['prototype']['echo']=function(_0xd52c97,_0x3c6ec4){this['sendRequest']('echo',{'d':_0xd52c97},_0x3c6ec4);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0xbcd002,..._0x62c8bb){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0xbcd002,..._0x62c8bb);}function cn(_0x24cbc7,..._0x1a555b){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x24cbc7,..._0x1a555b);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x52740e,..._0x23698c){throw ws(_0x52740e,..._0x23698c);}function X(_0x2c5adb,..._0x5f0ccd){return ws(_0x2c5adb,..._0x5f0ccd);}function Ia(_0x4741ce,_0x4089c2,_0x38fc76){const _0x4d58eb={...af(),[_0x4089c2]:_0x38fc76};return new Gt('auth','Firebase',_0x4d58eb)['create'](_0x4089c2,{'appName':_0x4741ce['name']});}function re(_0x120d10){return Ia(_0x120d10,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x196536,..._0x3652be){if(typeof _0x196536!='string'){const _0x40ad6b=_0x3652be[0x0],_0x1308a2=[..._0x3652be['slice'](0x1)];return _0x1308a2[0x0]&&(_0x1308a2[0x0]['appName']=_0x196536['name']),_0x196536['_errorFactory']['create'](_0x40ad6b,..._0x1308a2);}return Ea['create'](_0x196536,..._0x3652be);}function m(_0x4c6c3a,_0x58a820,..._0x611313){if(!_0x4c6c3a)throw ws(_0x58a820,..._0x611313);}function ne(_0x496219){const _0x15693f='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x496219;throw cn(_0x15693f),new Error(_0x15693f);}function ce(_0x12ba39,_0x2aa493){_0x12ba39||ne(_0x2aa493);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x17e6aa;return typeof self<'u'&&((_0x17e6aa=self['location'])==null?void 0x0:_0x17e6aa['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x1f38b6;return typeof self<'u'&&((_0x1f38b6=self['location'])==null?void 0x0:_0x1f38b6['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x4c6872=navigator;return _0x4c6872['languages']&&_0x4c6872['languages'][0x0]||_0x4c6872['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x5bc9bc,_0x57d834){this['shortDelay']=_0x5bc9bc,this['longDelay']=_0x57d834,ce(_0x57d834>_0x5bc9bc,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x424b67,_0x1754d0){ce(_0x424b67['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x828747}=_0x424b67['emulator'];return _0x1754d0?''+_0x828747+(_0x1754d0['startsWith']('/')?_0x1754d0['slice'](0x1):_0x1754d0):_0x828747;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0xb8e3f5,_0x87c8cb,_0x5c3e28){this['fetchImpl']=_0xb8e3f5,_0x87c8cb&&(this['headersImpl']=_0x87c8cb),_0x5c3e28&&(this['responseImpl']=_0x5c3e28);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x5a51c8,_0x4b76f4){return _0x5a51c8['tenantId']&&!_0x4b76f4['tenantId']?{..._0x4b76f4,'tenantId':_0x5a51c8['tenantId']}:_0x4b76f4;}async function Pe(_0x1a5556,_0x243552,_0x32a6b5,_0x132351,_0x2c92b5={}){return Ca(_0x1a5556,_0x2c92b5,async()=>{let _0x3cf020={},_0x28eb3b={};_0x132351&&(_0x243552==='GET'?_0x28eb3b=_0x132351:_0x3cf020={'body':JSON['stringify'](_0x132351)});const _0x2474f1=ut({..._0x28eb3b,'key':_0x1a5556['config']['apiKey']})['slice'](0x1),_0x551755=await _0x1a5556['_getAdditionalHeaders']();_0x551755['Content-Type']='application/json',_0x1a5556['languageCode']&&(_0x551755['X-Firebase-Locale']=_0x1a5556['languageCode']);const _0xe6c57f={'method':_0x243552,'headers':_0x551755,..._0x3cf020};return dc()||(_0xe6c57f['referrerPolicy']='strict-origin-when-cross-origin'),_0x1a5556['emulatorConfig']&&qt(_0x1a5556['emulatorConfig']['host'])&&(_0xe6c57f['credentials']='include'),wa['fetch']()(await Ta(_0x1a5556,_0x1a5556['config']['apiHost'],_0x32a6b5,_0x2474f1),_0xe6c57f);});}async function Ca(_0x554337,_0x23ec32,_0x25ac0a){_0x554337['_canInitEmulator']=!0x1;const _0x2a09fb={...df,..._0x23ec32};try{const _0x3b8e1a=new gf(_0x554337),_0xdf3787=await Promise['race']([_0x25ac0a(),_0x3b8e1a['promise']]);_0x3b8e1a['clearNetworkTimeout']();const _0x3e0a52=await _0xdf3787['json']();if('needConfirmation'in _0x3e0a52)throw on(_0x554337,'account-exists-with-different-credential',_0x3e0a52);if(_0xdf3787['ok']&&!('errorMessage'in _0x3e0a52))return _0x3e0a52;{const _0x1042c3=_0xdf3787['ok']?_0x3e0a52['errorMessage']:_0x3e0a52['error']['message'],[_0x54a29b,_0x3e2a26]=_0x1042c3['split']('\x20:\x20');if(_0x54a29b==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x554337,'credential-already-in-use',_0x3e0a52);if(_0x54a29b==='EMAIL_EXISTS')throw on(_0x554337,'email-already-in-use',_0x3e0a52);if(_0x54a29b==='USER_DISABLED')throw on(_0x554337,'user-disabled',_0x3e0a52);const _0x9a8b7=_0x2a09fb[_0x54a29b]||_0x54a29b['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x3e2a26)throw Ia(_0x554337,_0x9a8b7,_0x3e2a26);Y(_0x554337,_0x9a8b7);}}catch(_0x4dcc35){if(_0x4dcc35 instanceof Re)throw _0x4dcc35;Y(_0x554337,'network-request-failed',{'message':String(_0x4dcc35)});}}async function en(_0x11464c,_0x428e2a,_0x1edcac,_0x363292,_0x5b9f92={}){const _0x47cf05=await Pe(_0x11464c,_0x428e2a,_0x1edcac,_0x363292,_0x5b9f92);return'mfaPendingCredential'in _0x47cf05&&Y(_0x11464c,'multi-factor-auth-required',{'_serverResponse':_0x47cf05}),_0x47cf05;}async function Ta(_0xcbcbae,_0x437b97,_0x300a38,_0x364699){const _0x49d2ca=''+_0x437b97+_0x300a38+'?'+_0x364699,_0xeb0b24=_0xcbcbae,_0x4ffc7c=_0xeb0b24['config']['emulator']?Cs(_0xcbcbae['config'],_0x49d2ca):_0xcbcbae['config']['apiScheme']+'://'+_0x49d2ca;return ff['includes'](_0x300a38)&&(await _0xeb0b24['_persistenceManagerAvailable'],_0xeb0b24['_getPersistenceType']()==='COOKIE')?_0xeb0b24['_getPersistence']()['_getFinalTarget'](_0x4ffc7c)['toString']():_0x4ffc7c;}function _f(_0x143c2d){switch(_0x143c2d){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x5e46cd){this['auth']=_0x5e46cd,this['timer']=null,this['promise']=new Promise((_0x516a7,_0x6a3465)=>{this['timer']=setTimeout(()=>_0x6a3465(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x33c5c5,_0x5cfa18,_0x25d7c5){const _0x46a43d={'appName':_0x33c5c5['name']};_0x25d7c5['email']&&(_0x46a43d['email']=_0x25d7c5['email']),_0x25d7c5['phoneNumber']&&(_0x46a43d['phoneNumber']=_0x25d7c5['phoneNumber']);const _0x323e53=X(_0x33c5c5,_0x5cfa18,_0x46a43d);return _0x323e53['customData']['_tokenResponse']=_0x25d7c5,_0x323e53;}function wr(_0x43f793){return _0x43f793!==void 0x0&&_0x43f793['enterprise']!==void 0x0;}class mf{constructor(_0x4bcdf3){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x4bcdf3['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x4bcdf3['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x4bcdf3['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x2c2216){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x17eaaa of this['recaptchaEnforcementState'])if(_0x17eaaa['provider']&&_0x17eaaa['provider']===_0x2c2216)return _f(_0x17eaaa['enforcementState']);return null;}['isProviderEnabled'](_0x2fccf0){return this['getProviderEnforcementState'](_0x2fccf0)==='ENFORCE'||this['getProviderEnforcementState'](_0x2fccf0)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x82d15c,_0x3cdc3a){return Pe(_0x82d15c,'GET','/v2/recaptchaConfig',ke(_0x82d15c,_0x3cdc3a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x4a2eed,_0x3c96bb){return Pe(_0x4a2eed,'POST','/v1/accounts:delete',_0x3c96bb);}async function Pn(_0x155288,_0x2645cf){return Pe(_0x155288,'POST','/v1/accounts:lookup',_0x2645cf);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x1fa293){if(_0x1fa293)try{const _0x459f9c=new Date(Number(_0x1fa293));if(!isNaN(_0x459f9c['getTime']()))return _0x459f9c['toUTCString']();}catch{}}async function Ef(_0x426d62,_0x153e7c=!0x1){const _0x51c83a=P(_0x426d62),_0x423df5=await _0x51c83a['getIdToken'](_0x153e7c),_0x1724f9=Ts(_0x423df5);m(_0x1724f9&&_0x1724f9['exp']&&_0x1724f9['auth_time']&&_0x1724f9['iat'],_0x51c83a['auth'],'internal-error');const _0x5c3435=typeof _0x1724f9['firebase']=='object'?_0x1724f9['firebase']:void 0x0,_0x40ad1=_0x5c3435==null?void 0x0:_0x5c3435['sign_in_provider'];return{'claims':_0x1724f9,'token':_0x423df5,'authTime':Pt(fi(_0x1724f9['auth_time'])),'issuedAtTime':Pt(fi(_0x1724f9['iat'])),'expirationTime':Pt(fi(_0x1724f9['exp'])),'signInProvider':_0x40ad1||null,'signInSecondFactor':(_0x5c3435==null?void 0x0:_0x5c3435['sign_in_second_factor'])||null};}function fi(_0x273899){return Number(_0x273899)*0x3e8;}function Ts(_0x2439eb){const [_0x2dd475,_0x1c60df,_0x1560a4]=_0x2439eb['split']('.');if(_0x2dd475===void 0x0||_0x1c60df===void 0x0||_0x1560a4===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x32ad04=fn(_0x1c60df);return _0x32ad04?JSON['parse'](_0x32ad04):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x525fe8){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x525fe8==null?void 0x0:_0x525fe8['toString']()),null;}}function Cr(_0x67718c){const _0x56b9ad=Ts(_0x67718c);return m(_0x56b9ad,'internal-error'),m(typeof _0x56b9ad['exp']<'u','internal-error'),m(typeof _0x56b9ad['iat']<'u','internal-error'),Number(_0x56b9ad['exp'])-Number(_0x56b9ad['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x4be9a9,_0x37c5e3,_0x1021aa=!0x1){if(_0x1021aa)return _0x37c5e3;try{return await _0x37c5e3;}catch(_0x56df2f){throw _0x56df2f instanceof Re&&If(_0x56df2f)&&_0x4be9a9['auth']['currentUser']===_0x4be9a9&&await _0x4be9a9['auth']['signOut'](),_0x56df2f;}}function If({code:_0xd1dac6}){return _0xd1dac6==='auth/user-disabled'||_0xd1dac6==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x55926c){this['user']=_0x55926c,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x592377){if(_0x592377){const _0x515d06=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x515d06;}else{this['errorBackoff']=0x7530;const _0x5e7e5f=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x5e7e5f);}}['schedule'](_0x26df8e=!0x1){if(!this['isRunning'])return;const _0xdb2c2e=this['getInterval'](_0x26df8e);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0xdb2c2e);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x2a20a6){(_0x2a20a6==null?void 0x0:_0x2a20a6['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x285e00,_0x42d391){this['createdAt']=_0x285e00,this['lastLoginAt']=_0x42d391,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x3faccb){this['createdAt']=_0x3faccb['createdAt'],this['lastLoginAt']=_0x3faccb['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x5e86ac){var _0x5048a1;const _0xfbe563=_0x5e86ac['auth'],_0x50ad13=await _0x5e86ac['getIdToken'](),_0x4bb9ee=await Ht(_0x5e86ac,Pn(_0xfbe563,{'idToken':_0x50ad13}));m(_0x4bb9ee==null?void 0x0:_0x4bb9ee['users']['length'],_0xfbe563,'internal-error');const _0x483178=_0x4bb9ee['users'][0x0];_0x5e86ac['_notifyReloadListener'](_0x483178);const _0x98c04e=(_0x5048a1=_0x483178['providerUserInfo'])!=null&&_0x5048a1['length']?Sa(_0x483178['providerUserInfo']):[],_0x16b650=Tf(_0x5e86ac['providerData'],_0x98c04e),_0xbc8095=_0x5e86ac['isAnonymous'],_0x47de41=!(_0x5e86ac['email']&&_0x483178['passwordHash'])&&!(_0x16b650!=null&&_0x16b650['length']),_0x3d2842=_0xbc8095?_0x47de41:!0x1,_0x193905={'uid':_0x483178['localId'],'displayName':_0x483178['displayName']||null,'photoURL':_0x483178['photoUrl']||null,'email':_0x483178['email']||null,'emailVerified':_0x483178['emailVerified']||!0x1,'phoneNumber':_0x483178['phoneNumber']||null,'tenantId':_0x483178['tenantId']||null,'providerData':_0x16b650,'metadata':new Li(_0x483178['createdAt'],_0x483178['lastLoginAt']),'isAnonymous':_0x3d2842};Object['assign'](_0x5e86ac,_0x193905);}async function Cf(_0x33aaf0){const _0x4c4668=P(_0x33aaf0);await Nn(_0x4c4668),await _0x4c4668['auth']['_persistUserIfCurrent'](_0x4c4668),_0x4c4668['auth']['_notifyListenersIfCurrent'](_0x4c4668);}function Tf(_0x1dcc70,_0x4b8919){return[..._0x1dcc70['filter'](_0x2ded9f=>!_0x4b8919['some'](_0x15123c=>_0x15123c['providerId']===_0x2ded9f['providerId'])),..._0x4b8919];}function Sa(_0x4acb10){return _0x4acb10['map'](({providerId:_0x3a1d3f,..._0x3920a8})=>({'providerId':_0x3a1d3f,'uid':_0x3920a8['rawId']||'','displayName':_0x3920a8['displayName']||null,'email':_0x3920a8['email']||null,'phoneNumber':_0x3920a8['phoneNumber']||null,'photoURL':_0x3920a8['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x407bea,_0x2e7e5f){const _0xe07b20=await Ca(_0x407bea,{},async()=>{const _0xa2f0a8=ut({'grant_type':'refresh_token','refresh_token':_0x2e7e5f})['slice'](0x1),{tokenApiHost:_0x2e1a82,apiKey:_0x166770}=_0x407bea['config'],_0x1a08b8=await Ta(_0x407bea,_0x2e1a82,'/v1/token','key='+_0x166770),_0x2fabd5=await _0x407bea['_getAdditionalHeaders']();_0x2fabd5['Content-Type']='application/x-www-form-urlencoded';const _0x540361={'method':'POST','headers':_0x2fabd5,'body':_0xa2f0a8};return _0x407bea['emulatorConfig']&&qt(_0x407bea['emulatorConfig']['host'])&&(_0x540361['credentials']='include'),wa['fetch']()(_0x1a08b8,_0x540361);});return{'accessToken':_0xe07b20['access_token'],'expiresIn':_0xe07b20['expires_in'],'refreshToken':_0xe07b20['refresh_token']};}async function bf(_0x11760d,_0x12aaa2){return Pe(_0x11760d,'POST','/v2/accounts:revokeToken',ke(_0x11760d,_0x12aaa2));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x50f222){m(_0x50f222['idToken'],'internal-error'),m(typeof _0x50f222['idToken']<'u','internal-error'),m(typeof _0x50f222['refreshToken']<'u','internal-error');const _0x44c44b='expiresIn'in _0x50f222&&typeof _0x50f222['expiresIn']<'u'?Number(_0x50f222['expiresIn']):Cr(_0x50f222['idToken']);this['updateTokensAndExpiration'](_0x50f222['idToken'],_0x50f222['refreshToken'],_0x44c44b);}['updateFromIdToken'](_0x39143a){m(_0x39143a['length']!==0x0,'internal-error');const _0x3cbbaa=Cr(_0x39143a);this['updateTokensAndExpiration'](_0x39143a,null,_0x3cbbaa);}async['getToken'](_0x4900fa,_0x4ba429=!0x1){return!_0x4ba429&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x4900fa,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x4900fa,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x544bc5,_0x17da2b){const {accessToken:_0x2fa16c,refreshToken:_0x3cfa50,expiresIn:_0x1ab0cc}=await Sf(_0x544bc5,_0x17da2b);this['updateTokensAndExpiration'](_0x2fa16c,_0x3cfa50,Number(_0x1ab0cc));}['updateTokensAndExpiration'](_0x4dc60e,_0x49bbe8,_0x522a90){this['refreshToken']=_0x49bbe8||null,this['accessToken']=_0x4dc60e||null,this['expirationTime']=Date['now']()+_0x522a90*0x3e8;}static['fromJSON'](_0x322c2e,_0x5ca3cd){const {refreshToken:_0x1808ba,accessToken:_0x3c461b,expirationTime:_0x1c23ae}=_0x5ca3cd,_0x1ac8d1=new et();return _0x1808ba&&(m(typeof _0x1808ba=='string','internal-error',{'appName':_0x322c2e}),_0x1ac8d1['refreshToken']=_0x1808ba),_0x3c461b&&(m(typeof _0x3c461b=='string','internal-error',{'appName':_0x322c2e}),_0x1ac8d1['accessToken']=_0x3c461b),_0x1c23ae&&(m(typeof _0x1c23ae=='number','internal-error',{'appName':_0x322c2e}),_0x1ac8d1['expirationTime']=_0x1c23ae),_0x1ac8d1;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x39fde2){this['accessToken']=_0x39fde2['accessToken'],this['refreshToken']=_0x39fde2['refreshToken'],this['expirationTime']=_0x39fde2['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x26d508,_0xa51b3b){m(typeof _0x26d508=='string'||typeof _0x26d508>'u','internal-error',{'appName':_0xa51b3b});}class j{constructor({uid:_0x5c8aa9,auth:_0x2d1ab2,stsTokenManager:_0x2091ce,..._0x88fe65}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x5c8aa9,this['auth']=_0x2d1ab2,this['stsTokenManager']=_0x2091ce,this['accessToken']=_0x2091ce['accessToken'],this['displayName']=_0x88fe65['displayName']||null,this['email']=_0x88fe65['email']||null,this['emailVerified']=_0x88fe65['emailVerified']||!0x1,this['phoneNumber']=_0x88fe65['phoneNumber']||null,this['photoURL']=_0x88fe65['photoURL']||null,this['isAnonymous']=_0x88fe65['isAnonymous']||!0x1,this['tenantId']=_0x88fe65['tenantId']||null,this['providerData']=_0x88fe65['providerData']?[..._0x88fe65['providerData']]:[],this['metadata']=new Li(_0x88fe65['createdAt']||void 0x0,_0x88fe65['lastLoginAt']||void 0x0);}async['getIdToken'](_0x43d87d){const _0x56a8ba=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x43d87d));return m(_0x56a8ba,this['auth'],'internal-error'),this['accessToken']!==_0x56a8ba&&(this['accessToken']=_0x56a8ba,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x56a8ba;}['getIdTokenResult'](_0x569a89){return Ef(this,_0x569a89);}['reload'](){return Cf(this);}['_assign'](_0x4271e3){this!==_0x4271e3&&(m(this['uid']===_0x4271e3['uid'],this['auth'],'internal-error'),this['displayName']=_0x4271e3['displayName'],this['photoURL']=_0x4271e3['photoURL'],this['email']=_0x4271e3['email'],this['emailVerified']=_0x4271e3['emailVerified'],this['phoneNumber']=_0x4271e3['phoneNumber'],this['isAnonymous']=_0x4271e3['isAnonymous'],this['tenantId']=_0x4271e3['tenantId'],this['providerData']=_0x4271e3['providerData']['map'](_0x58ddc8=>({..._0x58ddc8})),this['metadata']['_copy'](_0x4271e3['metadata']),this['stsTokenManager']['_assign'](_0x4271e3['stsTokenManager']));}['_clone'](_0x14375b){const _0x1f6dde=new j({...this,'auth':_0x14375b,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x1f6dde['metadata']['_copy'](this['metadata']),_0x1f6dde;}['_onReload'](_0x1b680d){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x1b680d,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x27458c){this['reloadListener']?this['reloadListener'](_0x27458c):this['reloadUserInfo']=_0x27458c;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x5eda08,_0x5f20c9=!0x1){let _0x19c2bc=!0x1;_0x5eda08['idToken']&&_0x5eda08['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x5eda08),_0x19c2bc=!0x0),_0x5f20c9&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x19c2bc&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x16b4c8=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x16b4c8})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x591878=>({..._0x591878})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x49d840,_0x50802e){const _0x2cae4b=_0x50802e['displayName']??void 0x0,_0x4a18ef=_0x50802e['email']??void 0x0,_0x449089=_0x50802e['phoneNumber']??void 0x0,_0x1bb5d7=_0x50802e['photoURL']??void 0x0,_0xb45f18=_0x50802e['tenantId']??void 0x0,_0x5c853a=_0x50802e['_redirectEventId']??void 0x0,_0x57b71a=_0x50802e['createdAt']??void 0x0,_0x58c789=_0x50802e['lastLoginAt']??void 0x0,{uid:_0x436aa9,emailVerified:_0x668a4d,isAnonymous:_0x408f54,providerData:_0x1479db,stsTokenManager:_0x151b59}=_0x50802e;m(_0x436aa9&&_0x151b59,_0x49d840,'internal-error');const _0xc49034=et['fromJSON'](this['name'],_0x151b59);m(typeof _0x436aa9=='string',_0x49d840,'internal-error'),le(_0x2cae4b,_0x49d840['name']),le(_0x4a18ef,_0x49d840['name']),m(typeof _0x668a4d=='boolean',_0x49d840,'internal-error'),m(typeof _0x408f54=='boolean',_0x49d840,'internal-error'),le(_0x449089,_0x49d840['name']),le(_0x1bb5d7,_0x49d840['name']),le(_0xb45f18,_0x49d840['name']),le(_0x5c853a,_0x49d840['name']),le(_0x57b71a,_0x49d840['name']),le(_0x58c789,_0x49d840['name']);const _0x207be6=new j({'uid':_0x436aa9,'auth':_0x49d840,'email':_0x4a18ef,'emailVerified':_0x668a4d,'displayName':_0x2cae4b,'isAnonymous':_0x408f54,'photoURL':_0x1bb5d7,'phoneNumber':_0x449089,'tenantId':_0xb45f18,'stsTokenManager':_0xc49034,'createdAt':_0x57b71a,'lastLoginAt':_0x58c789});return _0x1479db&&Array['isArray'](_0x1479db)&&(_0x207be6['providerData']=_0x1479db['map'](_0x275869=>({..._0x275869}))),_0x5c853a&&(_0x207be6['_redirectEventId']=_0x5c853a),_0x207be6;}static async['_fromIdTokenResponse'](_0x638686,_0x34293f,_0x15cda0=!0x1){const _0x1d97ab=new et();_0x1d97ab['updateFromServerResponse'](_0x34293f);const _0x399b55=new j({'uid':_0x34293f['localId'],'auth':_0x638686,'stsTokenManager':_0x1d97ab,'isAnonymous':_0x15cda0});return await Nn(_0x399b55),_0x399b55;}static async['_fromGetAccountInfoResponse'](_0x155ea9,_0x1cfe4d,_0x57e682){const _0xd6d882=_0x1cfe4d['users'][0x0];m(_0xd6d882['localId']!==void 0x0,'internal-error');const _0x1c18b5=_0xd6d882['providerUserInfo']!==void 0x0?Sa(_0xd6d882['providerUserInfo']):[],_0x41516b=!(_0xd6d882['email']&&_0xd6d882['passwordHash'])&&!(_0x1c18b5!=null&&_0x1c18b5['length']),_0x34b83c=new et();_0x34b83c['updateFromIdToken'](_0x57e682);const _0x292ccc=new j({'uid':_0xd6d882['localId'],'auth':_0x155ea9,'stsTokenManager':_0x34b83c,'isAnonymous':_0x41516b}),_0x2834b2={'uid':_0xd6d882['localId'],'displayName':_0xd6d882['displayName']||null,'photoURL':_0xd6d882['photoUrl']||null,'email':_0xd6d882['email']||null,'emailVerified':_0xd6d882['emailVerified']||!0x1,'phoneNumber':_0xd6d882['phoneNumber']||null,'tenantId':_0xd6d882['tenantId']||null,'providerData':_0x1c18b5,'metadata':new Li(_0xd6d882['createdAt'],_0xd6d882['lastLoginAt']),'isAnonymous':!(_0xd6d882['email']&&_0xd6d882['passwordHash'])&&!(_0x1c18b5!=null&&_0x1c18b5['length'])};return Object['assign'](_0x292ccc,_0x2834b2),_0x292ccc;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x252c69){ce(_0x252c69 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x1b956b=Tr['get'](_0x252c69);return _0x1b956b?(ce(_0x1b956b instanceof _0x252c69,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x1b956b):(_0x1b956b=new _0x252c69(),Tr['set'](_0x252c69,_0x1b956b),_0x1b956b);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0xc0b920,_0x1d34d4){this['storage'][_0xc0b920]=_0x1d34d4;}async['_get'](_0x13804e){const _0x24cd67=this['storage'][_0x13804e];return _0x24cd67===void 0x0?null:_0x24cd67;}async['_remove'](_0x2bb20b){delete this['storage'][_0x2bb20b];}['_addListener'](_0x49de15,_0x3ccbc6){}['_removeListener'](_0x3f2d6b,_0x4518bf){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x115061,_0x23158c,_0x31f316){return'firebase:'+_0x115061+':'+_0x23158c+':'+_0x31f316;}class tt{constructor(_0x542e19,_0x2b6e50,_0x3c82ce){this['persistence']=_0x542e19,this['auth']=_0x2b6e50,this['userKey']=_0x3c82ce;const {config:_0x18f072,name:_0x71d42f}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x18f072['apiKey'],_0x71d42f),this['fullPersistenceKey']=ln('persistence',_0x18f072['apiKey'],_0x71d42f),this['boundEventHandler']=_0x2b6e50['_onStorageEvent']['bind'](_0x2b6e50),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x2b4d61){return this['persistence']['_set'](this['fullUserKey'],_0x2b4d61['toJSON']());}async['getCurrentUser'](){const _0x1574a4=await this['persistence']['_get'](this['fullUserKey']);if(!_0x1574a4)return null;if(typeof _0x1574a4=='string'){const _0x2b5111=await Pn(this['auth'],{'idToken':_0x1574a4})['catch'](()=>{});return _0x2b5111?j['_fromGetAccountInfoResponse'](this['auth'],_0x2b5111,_0x1574a4):null;}return j['_fromJSON'](this['auth'],_0x1574a4);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x2cfabb){if(this['persistence']===_0x2cfabb)return;const _0x47a030=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x2cfabb,_0x47a030)return this['setCurrentUser'](_0x47a030);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x49df43,_0x427b57,_0x13b2da='authUser'){if(!_0x427b57['length'])return new tt(ie(Sr),_0x49df43,_0x13b2da);const _0x32f7f5=(await Promise['all'](_0x427b57['map'](async _0x4a5b03=>{if(await _0x4a5b03['_isAvailable']())return _0x4a5b03;})))['filter'](_0x3f4186=>_0x3f4186);let _0x4f50b7=_0x32f7f5[0x0]||ie(Sr);const _0x4577ec=ln(_0x13b2da,_0x49df43['config']['apiKey'],_0x49df43['name']);let _0x17cfb9=null;for(const _0x1880c4 of _0x427b57)try{const _0x6f050a=await _0x1880c4['_get'](_0x4577ec);if(_0x6f050a){let _0x1ddad4;if(typeof _0x6f050a=='string'){const _0x46fba0=await Pn(_0x49df43,{'idToken':_0x6f050a})['catch'](()=>{});if(!_0x46fba0)break;_0x1ddad4=await j['_fromGetAccountInfoResponse'](_0x49df43,_0x46fba0,_0x6f050a);}else _0x1ddad4=j['_fromJSON'](_0x49df43,_0x6f050a);_0x1880c4!==_0x4f50b7&&(_0x17cfb9=_0x1ddad4),_0x4f50b7=_0x1880c4;break;}}catch{}const _0x370a76=_0x32f7f5['filter'](_0x1fe5a0=>_0x1fe5a0['_shouldAllowMigration']);return!_0x4f50b7['_shouldAllowMigration']||!_0x370a76['length']?new tt(_0x4f50b7,_0x49df43,_0x13b2da):(_0x4f50b7=_0x370a76[0x0],_0x17cfb9&&await _0x4f50b7['_set'](_0x4577ec,_0x17cfb9['toJSON']()),await Promise['all'](_0x427b57['map'](async _0xc9d424=>{if(_0xc9d424!==_0x4f50b7)try{await _0xc9d424['_remove'](_0x4577ec);}catch{}})),new tt(_0x4f50b7,_0x49df43,_0x13b2da));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x2ac374){const _0x113c41=_0x2ac374['toLowerCase']();if(_0x113c41['includes']('opera/')||_0x113c41['includes']('opr/')||_0x113c41['includes']('opios/'))return'Opera';if(Pa(_0x113c41))return'IEMobile';if(_0x113c41['includes']('msie')||_0x113c41['includes']('trident/'))return'IE';if(_0x113c41['includes']('edge/'))return'Edge';if(Ra(_0x113c41))return'Firefox';if(_0x113c41['includes']('silk/'))return'Silk';if(Oa(_0x113c41))return'Blackberry';if(Da(_0x113c41))return'Webos';if(Aa(_0x113c41))return'Safari';if((_0x113c41['includes']('chrome/')||ka(_0x113c41))&&!_0x113c41['includes']('edge/'))return'Chrome';if(Na(_0x113c41))return'Android';{const _0x53a678=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x24f15f=_0x2ac374['match'](_0x53a678);if((_0x24f15f==null?void 0x0:_0x24f15f['length'])===0x2)return _0x24f15f[0x1];}return'Other';}function Ra(_0x55d1c1=W()){return/firefox\//i['test'](_0x55d1c1);}function Aa(_0x260aa7=W()){const _0x182831=_0x260aa7['toLowerCase']();return _0x182831['includes']('safari/')&&!_0x182831['includes']('chrome/')&&!_0x182831['includes']('crios/')&&!_0x182831['includes']('android');}function ka(_0x132788=W()){return/crios\//i['test'](_0x132788);}function Pa(_0xac696=W()){return/iemobile/i['test'](_0xac696);}function Na(_0x55d1cf=W()){return/android/i['test'](_0x55d1cf);}function Oa(_0x4db61b=W()){return/blackberry/i['test'](_0x4db61b);}function Da(_0x1efb63=W()){return/webos/i['test'](_0x1efb63);}function Ss(_0x36cacf=W()){return/iphone|ipad|ipod/i['test'](_0x36cacf)||/macintosh/i['test'](_0x36cacf)&&/mobile/i['test'](_0x36cacf);}function Rf(_0x347426=W()){var _0x1db540;return Ss(_0x347426)&&!!((_0x1db540=window['navigator'])!=null&&_0x1db540['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x12e23e=W()){return Ss(_0x12e23e)||Na(_0x12e23e)||Da(_0x12e23e)||Oa(_0x12e23e)||/windows phone/i['test'](_0x12e23e)||Pa(_0x12e23e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x56f991,_0x3e0dd7=[]){let _0xee572c;switch(_0x56f991){case'Browser':_0xee572c=br(W());break;case'Worker':_0xee572c=br(W())+'-'+_0x56f991;break;default:_0xee572c=_0x56f991;}const _0x3cb953=_0x3e0dd7['length']?_0x3e0dd7['join'](','):'FirebaseCore-web';return _0xee572c+'/JsCore/'+dt+'/'+_0x3cb953;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x5a1d32){this['auth']=_0x5a1d32,this['queue']=[];}['pushCallback'](_0xbd04de,_0x52c8d9){const _0x387dce=_0x56e5af=>new Promise((_0x542ff5,_0x2641c7)=>{try{const _0x407cac=_0xbd04de(_0x56e5af);_0x542ff5(_0x407cac);}catch(_0x71097a){_0x2641c7(_0x71097a);}});_0x387dce['onAbort']=_0x52c8d9,this['queue']['push'](_0x387dce);const _0x1a6bc0=this['queue']['length']-0x1;return()=>{this['queue'][_0x1a6bc0]=()=>Promise['resolve']();};}async['runMiddleware'](_0x3083ba){if(this['auth']['currentUser']===_0x3083ba)return;const _0x3eca98=[];try{for(const _0x10bcd1 of this['queue'])await _0x10bcd1(_0x3083ba),_0x10bcd1['onAbort']&&_0x3eca98['push'](_0x10bcd1['onAbort']);}catch(_0x2a659e){_0x3eca98['reverse']();for(const _0x344bbb of _0x3eca98)try{_0x344bbb();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x2a659e==null?void 0x0:_0x2a659e['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x55d154,_0x44a8e3={}){return Pe(_0x55d154,'GET','/v2/passwordPolicy',ke(_0x55d154,_0x44a8e3));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x499dfa){var _0x3a1a20;const _0xfbf1a9=_0x499dfa['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0xfbf1a9['minPasswordLength']??Nf,_0xfbf1a9['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0xfbf1a9['maxPasswordLength']),_0xfbf1a9['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0xfbf1a9['containsLowercaseCharacter']),_0xfbf1a9['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0xfbf1a9['containsUppercaseCharacter']),_0xfbf1a9['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0xfbf1a9['containsNumericCharacter']),_0xfbf1a9['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0xfbf1a9['containsNonAlphanumericCharacter']),this['enforcementState']=_0x499dfa['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x3a1a20=_0x499dfa['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x3a1a20['join'](''))??'',this['forceUpgradeOnSignin']=_0x499dfa['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x499dfa['schemaVersion'];}['validatePassword'](_0x1786cc){const _0x524fdf={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x1786cc,_0x524fdf),this['validatePasswordCharacterOptions'](_0x1786cc,_0x524fdf),_0x524fdf['isValid']&&(_0x524fdf['isValid']=_0x524fdf['meetsMinPasswordLength']??!0x0),_0x524fdf['isValid']&&(_0x524fdf['isValid']=_0x524fdf['meetsMaxPasswordLength']??!0x0),_0x524fdf['isValid']&&(_0x524fdf['isValid']=_0x524fdf['containsLowercaseLetter']??!0x0),_0x524fdf['isValid']&&(_0x524fdf['isValid']=_0x524fdf['containsUppercaseLetter']??!0x0),_0x524fdf['isValid']&&(_0x524fdf['isValid']=_0x524fdf['containsNumericCharacter']??!0x0),_0x524fdf['isValid']&&(_0x524fdf['isValid']=_0x524fdf['containsNonAlphanumericCharacter']??!0x0),_0x524fdf;}['validatePasswordLengthOptions'](_0x43edb4,_0x4faf8d){const _0xc7851f=this['customStrengthOptions']['minPasswordLength'],_0x146f77=this['customStrengthOptions']['maxPasswordLength'];_0xc7851f&&(_0x4faf8d['meetsMinPasswordLength']=_0x43edb4['length']>=_0xc7851f),_0x146f77&&(_0x4faf8d['meetsMaxPasswordLength']=_0x43edb4['length']<=_0x146f77);}['validatePasswordCharacterOptions'](_0xb7cefe,_0x143196){this['updatePasswordCharacterOptionsStatuses'](_0x143196,!0x1,!0x1,!0x1,!0x1);let _0x1b7bb6;for(let _0x4dc359=0x0;_0x4dc359<_0xb7cefe['length'];_0x4dc359++)_0x1b7bb6=_0xb7cefe['charAt'](_0x4dc359),this['updatePasswordCharacterOptionsStatuses'](_0x143196,_0x1b7bb6>='a'&&_0x1b7bb6<='z',_0x1b7bb6>='A'&&_0x1b7bb6<='Z',_0x1b7bb6>='0'&&_0x1b7bb6<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x1b7bb6));}['updatePasswordCharacterOptionsStatuses'](_0x6866c3,_0x141c26,_0x1b7cb8,_0x4653c8,_0x44e107){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x6866c3['containsLowercaseLetter']||(_0x6866c3['containsLowercaseLetter']=_0x141c26)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x6866c3['containsUppercaseLetter']||(_0x6866c3['containsUppercaseLetter']=_0x1b7cb8)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x6866c3['containsNumericCharacter']||(_0x6866c3['containsNumericCharacter']=_0x4653c8)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x6866c3['containsNonAlphanumericCharacter']||(_0x6866c3['containsNonAlphanumericCharacter']=_0x44e107));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x5afb5d,_0xbe0b95,_0x512ab5,_0x19dc44){this['app']=_0x5afb5d,this['heartbeatServiceProvider']=_0xbe0b95,this['appCheckServiceProvider']=_0x512ab5,this['config']=_0x19dc44,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x5afb5d['name'],this['clientVersion']=_0x19dc44['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x149e2d=>this['_resolvePersistenceManagerAvailable']=_0x149e2d);}['_initializeWithPersistence'](_0x2ab364,_0x242c6b){return _0x242c6b&&(this['_popupRedirectResolver']=ie(_0x242c6b)),this['_initializationPromise']=this['queue'](async()=>{var _0x21d68c,_0x4e2b96,_0x37faf5;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x2ab364),(_0x21d68c=this['_resolvePersistenceManagerAvailable'])==null||_0x21d68c['call'](this),!this['_deleted'])){if((_0x4e2b96=this['_popupRedirectResolver'])!=null&&_0x4e2b96['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x242c6b),this['lastNotifiedUid']=((_0x37faf5=this['currentUser'])==null?void 0x0:_0x37faf5['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x33680e=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x33680e)){if(this['currentUser']&&_0x33680e&&this['currentUser']['uid']===_0x33680e['uid']){this['_currentUser']['_assign'](_0x33680e),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x33680e,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x165522){try{const _0x3fb71f=await Pn(this,{'idToken':_0x165522}),_0x46b4d7=await j['_fromGetAccountInfoResponse'](this,_0x3fb71f,_0x165522);await this['directlySetCurrentUser'](_0x46b4d7);}catch(_0x59bbb1){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x59bbb1),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x5cb102){var _0xe3924c;if($(this['app'])){const _0x560b8d=this['app']['settings']['authIdToken'];return _0x560b8d?new Promise(_0x5b0f81=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x560b8d)['then'](_0x5b0f81,_0x5b0f81));}):this['directlySetCurrentUser'](null);}const _0x2944dd=await this['assertedPersistence']['getCurrentUser']();let _0x442bef=_0x2944dd,_0x2535d2=!0x1;if(_0x5cb102&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0xaec95=(_0xe3924c=this['redirectUser'])==null?void 0x0:_0xe3924c['_redirectEventId'],_0x5bef47=_0x442bef==null?void 0x0:_0x442bef['_redirectEventId'],_0x1860b6=await this['tryRedirectSignIn'](_0x5cb102);(!_0xaec95||_0xaec95===_0x5bef47)&&(_0x1860b6!=null&&_0x1860b6['user'])&&(_0x442bef=_0x1860b6['user'],_0x2535d2=!0x0);}if(!_0x442bef)return this['directlySetCurrentUser'](null);if(!_0x442bef['_redirectEventId']){if(_0x2535d2)try{await this['beforeStateQueue']['runMiddleware'](_0x442bef);}catch(_0x2900c6){_0x442bef=_0x2944dd,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x2900c6));}return _0x442bef?this['reloadAndSetCurrentUserOrClear'](_0x442bef):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x442bef['_redirectEventId']?this['directlySetCurrentUser'](_0x442bef):this['reloadAndSetCurrentUserOrClear'](_0x442bef);}async['tryRedirectSignIn'](_0x429978){let _0x11186b=null;try{_0x11186b=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x429978,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x11186b;}async['reloadAndSetCurrentUserOrClear'](_0x373b96){try{await Nn(_0x373b96);}catch(_0x30d96a){if((_0x30d96a==null?void 0x0:_0x30d96a['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x373b96);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x2b0b70){if($(this['app']))return Promise['reject'](re(this));const _0x2bd905=_0x2b0b70?P(_0x2b0b70):null;return _0x2bd905&&m(_0x2bd905['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x2bd905&&_0x2bd905['_clone'](this));}async['_updateCurrentUser'](_0x1c7830,_0x1c84c9=!0x1){if(!this['_deleted'])return _0x1c7830&&m(this['tenantId']===_0x1c7830['tenantId'],this,'tenant-id-mismatch'),_0x1c84c9||await this['beforeStateQueue']['runMiddleware'](_0x1c7830),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x1c7830),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x59441b){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x59441b));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x5f3a25){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x48699f=this['_getPasswordPolicyInternal']();return _0x48699f['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x48699f['validatePassword'](_0x5f3a25);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x856903=await Pf(this),_0x313920=new Of(_0x856903);this['tenantId']===null?this['_projectPasswordPolicy']=_0x313920:this['_tenantPasswordPolicies'][this['tenantId']]=_0x313920;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x16609b){this['_errorFactory']=new Gt('auth','Firebase',_0x16609b());}['onAuthStateChanged'](_0x335a10,_0x396723,_0x4986a2){return this['registerStateListener'](this['authStateSubscription'],_0x335a10,_0x396723,_0x4986a2);}['beforeAuthStateChanged'](_0x3d69af,_0x1141c8){return this['beforeStateQueue']['pushCallback'](_0x3d69af,_0x1141c8);}['onIdTokenChanged'](_0x5c2a60,_0x46c915,_0x583f35){return this['registerStateListener'](this['idTokenSubscription'],_0x5c2a60,_0x46c915,_0x583f35);}['authStateReady'](){return new Promise((_0x58b2c7,_0x20fb8a)=>{if(this['currentUser'])_0x58b2c7();else{const _0x2ef504=this['onAuthStateChanged'](()=>{_0x2ef504(),_0x58b2c7();},_0x20fb8a);}});}async['revokeAccessToken'](_0x411ec9){if(this['currentUser']){const _0x5bbd0e=await this['currentUser']['getIdToken'](),_0x256d70={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x411ec9,'idToken':_0x5bbd0e};this['tenantId']!=null&&(_0x256d70['tenantId']=this['tenantId']),await bf(this,_0x256d70);}}['toJSON'](){var _0x3a9c8c;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x3a9c8c=this['_currentUser'])==null?void 0x0:_0x3a9c8c['toJSON']()};}async['_setRedirectUser'](_0x495064,_0xcd7377){const _0x44383e=await this['getOrInitRedirectPersistenceManager'](_0xcd7377);return _0x495064===null?_0x44383e['removeCurrentUser']():_0x44383e['setCurrentUser'](_0x495064);}async['getOrInitRedirectPersistenceManager'](_0x391d73){if(!this['redirectPersistenceManager']){const _0x3af19c=_0x391d73&&ie(_0x391d73)||this['_popupRedirectResolver'];m(_0x3af19c,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x3af19c['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x2366e4){var _0x320ed6,_0x439475;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x320ed6=this['_currentUser'])==null?void 0x0:_0x320ed6['_redirectEventId'])===_0x2366e4?this['_currentUser']:((_0x439475=this['redirectUser'])==null?void 0x0:_0x439475['_redirectEventId'])===_0x2366e4?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x494fff){if(_0x494fff===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x494fff));}['_notifyListenersIfCurrent'](_0xb48902){_0xb48902===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x95755b;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x32581c=((_0x95755b=this['currentUser'])==null?void 0x0:_0x95755b['uid'])??null;this['lastNotifiedUid']!==_0x32581c&&(this['lastNotifiedUid']=_0x32581c,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x32e72a,_0x4651e9,_0x3b1322,_0x21f334){if(this['_deleted'])return()=>{};const _0x15cbae=typeof _0x4651e9=='function'?_0x4651e9:_0x4651e9['next']['bind'](_0x4651e9);let _0x31742a=!0x1;const _0x3aaf59=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x3aaf59,this,'internal-error'),_0x3aaf59['then'](()=>{_0x31742a||_0x15cbae(this['currentUser']);}),typeof _0x4651e9=='function'){const _0x2aeba3=_0x32e72a['addObserver'](_0x4651e9,_0x3b1322,_0x21f334);return()=>{_0x31742a=!0x0,_0x2aeba3();};}else{const _0x4bd2f3=_0x32e72a['addObserver'](_0x4651e9);return()=>{_0x31742a=!0x0,_0x4bd2f3();};}}async['directlySetCurrentUser'](_0x5d923b){this['currentUser']&&this['currentUser']!==_0x5d923b&&this['_currentUser']['_stopProactiveRefresh'](),_0x5d923b&&this['isProactiveRefreshEnabled']&&_0x5d923b['_startProactiveRefresh'](),this['currentUser']=_0x5d923b,_0x5d923b?await this['assertedPersistence']['setCurrentUser'](_0x5d923b):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x67aac4){return this['operations']=this['operations']['then'](_0x67aac4,_0x67aac4),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x337f16){!_0x337f16||this['frameworks']['includes'](_0x337f16)||(this['frameworks']['push'](_0x337f16),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x571231;const _0x1ff3de={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x1ff3de['X-Firebase-gmpid']=this['app']['options']['appId']);const _0xa1c0e4=await((_0x571231=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x571231['getHeartbeatsHeader']());_0xa1c0e4&&(_0x1ff3de['X-Firebase-Client']=_0xa1c0e4);const _0x1b3fc3=await this['_getAppCheckToken']();return _0x1b3fc3&&(_0x1ff3de['X-Firebase-AppCheck']=_0x1b3fc3),_0x1ff3de;}async['_getAppCheckToken'](){var _0x2ade1a;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x49ef6b=await((_0x2ade1a=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x2ade1a['getToken']());return _0x49ef6b!=null&&_0x49ef6b['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x49ef6b['error']),_0x49ef6b==null?void 0x0:_0x49ef6b['token'];}}function Ke(_0x417d0d){return P(_0x417d0d);}class Rr{constructor(_0x3b1c3f){this['auth']=_0x3b1c3f,this['observer']=null,this['addObserver']=Tc(_0x32f9d6=>this['observer']=_0x32f9d6);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x446c27){Jn=_0x446c27;}function xa(_0x2da56f){return Jn['loadJS'](_0x2da56f);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x50214e){return'__'+_0x50214e+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x385a1d){_0x385a1d();}['execute'](_0x3a0d43,_0x99637){return Promise['resolve']('token');}['render'](_0x3b9d79,_0x9d555e){return'';}}class Wf{['ready'](_0x76dcb){_0x76dcb();}['execute'](_0x4da0b6,_0x40038c){return Promise['resolve']('token');}['render'](_0x203d10,_0x5bdaa3){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x646e60){this['type']=Bf,this['auth']=Ke(_0x646e60);}async['verify'](_0x34ad41='verify',_0x9b3eec=!0x1){async function _0x1b58d6(_0x2e6d70){if(!_0x9b3eec){if(_0x2e6d70['tenantId']==null&&_0x2e6d70['_agentRecaptchaConfig']!=null)return _0x2e6d70['_agentRecaptchaConfig']['siteKey'];if(_0x2e6d70['tenantId']!=null&&_0x2e6d70['_tenantRecaptchaConfigs'][_0x2e6d70['tenantId']]!==void 0x0)return _0x2e6d70['_tenantRecaptchaConfigs'][_0x2e6d70['tenantId']]['siteKey'];}return new Promise(async(_0x3d3b07,_0x219b42)=>{yf(_0x2e6d70,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x19c71a=>{if(_0x19c71a['recaptchaKey']===void 0x0)_0x219b42(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x307e19=new mf(_0x19c71a);return _0x2e6d70['tenantId']==null?_0x2e6d70['_agentRecaptchaConfig']=_0x307e19:_0x2e6d70['_tenantRecaptchaConfigs'][_0x2e6d70['tenantId']]=_0x307e19,_0x3d3b07(_0x307e19['siteKey']);}})['catch'](_0x248267=>{_0x219b42(_0x248267);});});}function _0x37a9a7(_0x3c1341,_0xc42374,_0x8c282){const _0xd0a162=window['grecaptcha'];wr(_0xd0a162)?_0xd0a162['enterprise']['ready'](()=>{_0xd0a162['enterprise']['execute'](_0x3c1341,{'action':_0x34ad41})['then'](_0x97463d=>{_0xc42374(_0x97463d);})['catch'](()=>{_0xc42374(Fa);});}):_0x8c282(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x16fcf3,_0x386200)=>{_0x1b58d6(this['auth'])['then'](async _0x4496c9=>{if(!_0x9b3eec&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x37a9a7(_0x4496c9,_0x16fcf3,_0x386200);else{if(typeof window>'u'){_0x386200(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x576de7=Lf();_0x576de7['length']!==0x0&&(_0x576de7+=_0x4496c9+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x5535a5;(_0x5535a5=he['scriptInjectionDeferred'])==null||_0x5535a5['resolve']();},xa(_0x576de7)['then'](()=>{var _0x5246f4;return(_0x5246f4=he['scriptInjectionDeferred'])==null?void 0x0:_0x5246f4['promise'];})['then'](()=>{_0x37a9a7(_0x4496c9,_0x16fcf3,_0x386200);})['catch'](_0x107c69=>{_0x386200(_0x107c69);});}})['catch'](_0x4440aa=>{_0x386200(_0x4440aa);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x5ce55f,_0x96f5d,_0x1d7968,_0x24be89=!0x1,_0x424cce=!0x1){const _0x4903c8=new he(_0x5ce55f);let _0x52a346;if(_0x424cce)_0x52a346=Fa;else try{_0x52a346=await _0x4903c8['verify'](_0x1d7968);}catch{_0x52a346=await _0x4903c8['verify'](_0x1d7968,!0x0);}const _0x303d2a={..._0x96f5d};if(_0x1d7968==='mfaSmsEnrollment'||_0x1d7968==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x303d2a){const _0x56f52f=_0x303d2a['phoneEnrollmentInfo']['phoneNumber'],_0x420092=_0x303d2a['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x303d2a,{'phoneEnrollmentInfo':{'phoneNumber':_0x56f52f,'recaptchaToken':_0x420092,'captchaResponse':_0x52a346,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x303d2a){const _0x36f9be=_0x303d2a['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x303d2a,{'phoneSignInInfo':{'recaptchaToken':_0x36f9be,'captchaResponse':_0x52a346,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x303d2a;}return _0x24be89?Object['assign'](_0x303d2a,{'captchaResp':_0x52a346}):Object['assign'](_0x303d2a,{'captchaResponse':_0x52a346}),Object['assign'](_0x303d2a,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x303d2a,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x303d2a;}async function xi(_0x24ef48,_0x381e59,_0x1629fa,_0x54fff1,_0x1e9d74){var _0x8531ef;if((_0x8531ef=_0x24ef48['_getRecaptchaConfig']())!=null&&_0x8531ef['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x7adf45=await kr(_0x24ef48,_0x381e59,_0x1629fa,_0x1629fa==='getOobCode');return _0x54fff1(_0x24ef48,_0x7adf45);}else return _0x54fff1(_0x24ef48,_0x381e59)['catch'](async _0x47251e=>{if(_0x47251e['code']==='auth/missing-recaptcha-token'){console['log'](_0x1629fa+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0xb44221=await kr(_0x24ef48,_0x381e59,_0x1629fa,_0x1629fa==='getOobCode');return _0x54fff1(_0x24ef48,_0xb44221);}else return Promise['reject'](_0x47251e);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x26e073,_0x5354b2){const _0x507691=Hi(_0x26e073,'auth');if(_0x507691['isInitialized']()){const _0x1ab653=_0x507691['getImmediate'](),_0x351f04=_0x507691['getOptions']();if(xe(_0x351f04,_0x5354b2??{}))return _0x1ab653;Y(_0x1ab653,'already-initialized');}return _0x507691['initialize']({'options':_0x5354b2});}function Hf(_0x4a4370,_0x43fef7){const _0x5bf4c0=(_0x43fef7==null?void 0x0:_0x43fef7['persistence'])||[],_0x40b7ac=(Array['isArray'](_0x5bf4c0)?_0x5bf4c0:[_0x5bf4c0])['map'](ie);_0x43fef7!=null&&_0x43fef7['errorMap']&&_0x4a4370['_updateErrorMap'](_0x43fef7['errorMap']),_0x4a4370['_initializeWithPersistence'](_0x40b7ac,_0x43fef7==null?void 0x0:_0x43fef7['popupRedirectResolver']);}function $f(_0x4d3826,_0x3ab194,_0x433e46){const _0x1b171a=Ke(_0x4d3826);m(/^https?:\/\//['test'](_0x3ab194),_0x1b171a,'invalid-emulator-scheme');const _0x2b5df0=!0x1,_0x522471=Ua(_0x3ab194),{host:_0x463db6,port:_0x527423}=Gf(_0x3ab194),_0x38bc37=_0x527423===null?'':':'+_0x527423,_0x47b8ed={'url':_0x522471+'//'+_0x463db6+_0x38bc37+'/'},_0x1499fb=Object['freeze']({'host':_0x463db6,'port':_0x527423,'protocol':_0x522471['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x2b5df0})});if(!_0x1b171a['_canInitEmulator']){m(_0x1b171a['config']['emulator']&&_0x1b171a['emulatorConfig'],_0x1b171a,'emulator-config-failed'),m(xe(_0x47b8ed,_0x1b171a['config']['emulator'])&&xe(_0x1499fb,_0x1b171a['emulatorConfig']),_0x1b171a,'emulator-config-failed');return;}_0x1b171a['config']['emulator']=_0x47b8ed,_0x1b171a['emulatorConfig']=_0x1499fb,_0x1b171a['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x463db6)?Qr(_0x522471+'//'+_0x463db6+_0x38bc37):qf();}function Ua(_0x1e19ee){const _0x55524b=_0x1e19ee['indexOf'](':');return _0x55524b<0x0?'':_0x1e19ee['substr'](0x0,_0x55524b+0x1);}function Gf(_0x338ddd){const _0x526a22=Ua(_0x338ddd),_0x2ee1f8=/(\/\/)?([^?#/]+)/['exec'](_0x338ddd['substr'](_0x526a22['length']));if(!_0x2ee1f8)return{'host':'','port':null};const _0x1e5838=_0x2ee1f8[0x2]['split']('@')['pop']()||'',_0x3351be=/^(\[[^\]]+\])(:|$)/['exec'](_0x1e5838);if(_0x3351be){const _0x1bc586=_0x3351be[0x1];return{'host':_0x1bc586,'port':Pr(_0x1e5838['substr'](_0x1bc586['length']+0x1))};}else{const [_0x3b5fca,_0x2970cb]=_0x1e5838['split'](':');return{'host':_0x3b5fca,'port':Pr(_0x2970cb)};}}function Pr(_0x269387){if(!_0x269387)return null;const _0x191798=Number(_0x269387);return isNaN(_0x191798)?null:_0x191798;}function qf(){function _0x12fc17(){const _0x9f9cb6=document['createElement']('p'),_0x143149=_0x9f9cb6['style'];_0x9f9cb6['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x143149['position']='fixed',_0x143149['width']='100%',_0x143149['backgroundColor']='#ffffff',_0x143149['border']='.1em\x20solid\x20#000000',_0x143149['color']='#b50000',_0x143149['bottom']='0px',_0x143149['left']='0px',_0x143149['margin']='0px',_0x143149['zIndex']='10000',_0x143149['textAlign']='center',_0x9f9cb6['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x9f9cb6);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x12fc17):_0x12fc17());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0xb585e9,_0x25842c){this['providerId']=_0xb585e9,this['signInMethod']=_0x25842c;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x444c0e){return ne('not\x20implemented');}['_linkToIdToken'](_0xd7159e,_0x3da315){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x4f7ddf){return ne('not\x20implemented');}}async function zf(_0x29d558,_0x4ca72a){return Pe(_0x29d558,'POST','/v1/accounts:signUp',_0x4ca72a);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x4c4a96,_0x5c59bb){return en(_0x4c4a96,'POST','/v1/accounts:signInWithPassword',ke(_0x4c4a96,_0x5c59bb));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x222a6c,_0x1f9098){return en(_0x222a6c,'POST','/v1/accounts:signInWithEmailLink',ke(_0x222a6c,_0x1f9098));}async function Yf(_0x906e88,_0xe6fc7){return en(_0x906e88,'POST','/v1/accounts:signInWithEmailLink',ke(_0x906e88,_0xe6fc7));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x1bbbb4,_0x3a3a48,_0x469006,_0x11b7f1=null){super('password',_0x469006),this['_email']=_0x1bbbb4,this['_password']=_0x3a3a48,this['_tenantId']=_0x11b7f1;}static['_fromEmailAndPassword'](_0x2a34e2,_0x1755cc){return new $t(_0x2a34e2,_0x1755cc,'password');}static['_fromEmailAndCode'](_0x3e4ba5,_0x307305,_0x432444=null){return new $t(_0x3e4ba5,_0x307305,'emailLink',_0x432444);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x1afae2){const _0x1f3806=typeof _0x1afae2=='string'?JSON['parse'](_0x1afae2):_0x1afae2;if(_0x1f3806!=null&&_0x1f3806['email']&&(_0x1f3806!=null&&_0x1f3806['password'])){if(_0x1f3806['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x1f3806['email'],_0x1f3806['password']);if(_0x1f3806['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x1f3806['email'],_0x1f3806['password'],_0x1f3806['tenantId']);}return null;}async['_getIdTokenResponse'](_0x53bae0){switch(this['signInMethod']){case'password':const _0x2d13bd={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x53bae0,_0x2d13bd,'signInWithPassword',jf);case'emailLink':return Kf(_0x53bae0,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x53bae0,'internal-error');}}async['_linkToIdToken'](_0x3dae89,_0x28f966){switch(this['signInMethod']){case'password':const _0x33c17e={'idToken':_0x28f966,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x3dae89,_0x33c17e,'signUpPassword',zf);case'emailLink':return Yf(_0x3dae89,{'idToken':_0x28f966,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x3dae89,'internal-error');}}['_getReauthenticationResolver'](_0x449e18){return this['_getIdTokenResponse'](_0x449e18);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x511b23,_0x266b34){return en(_0x511b23,'POST','/v1/accounts:signInWithIdp',ke(_0x511b23,_0x266b34));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x44e848){const _0x543081=new $e(_0x44e848['providerId'],_0x44e848['signInMethod']);return _0x44e848['idToken']||_0x44e848['accessToken']?(_0x44e848['idToken']&&(_0x543081['idToken']=_0x44e848['idToken']),_0x44e848['accessToken']&&(_0x543081['accessToken']=_0x44e848['accessToken']),_0x44e848['nonce']&&!_0x44e848['pendingToken']&&(_0x543081['nonce']=_0x44e848['nonce']),_0x44e848['pendingToken']&&(_0x543081['pendingToken']=_0x44e848['pendingToken'])):_0x44e848['oauthToken']&&_0x44e848['oauthTokenSecret']?(_0x543081['accessToken']=_0x44e848['oauthToken'],_0x543081['secret']=_0x44e848['oauthTokenSecret']):Y('argument-error'),_0x543081;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x248c67){const _0x3fb034=typeof _0x248c67=='string'?JSON['parse'](_0x248c67):_0x248c67,{providerId:_0x7ab0a3,signInMethod:_0x352b29,..._0x9fceb3}=_0x3fb034;if(!_0x7ab0a3||!_0x352b29)return null;const _0x5a01b5=new $e(_0x7ab0a3,_0x352b29);return _0x5a01b5['idToken']=_0x9fceb3['idToken']||void 0x0,_0x5a01b5['accessToken']=_0x9fceb3['accessToken']||void 0x0,_0x5a01b5['secret']=_0x9fceb3['secret'],_0x5a01b5['nonce']=_0x9fceb3['nonce'],_0x5a01b5['pendingToken']=_0x9fceb3['pendingToken']||null,_0x5a01b5;}['_getIdTokenResponse'](_0x3ca01e){const _0x1d0d60=this['buildRequest']();return nt(_0x3ca01e,_0x1d0d60);}['_linkToIdToken'](_0x2f0835,_0x3be501){const _0x452d5a=this['buildRequest']();return _0x452d5a['idToken']=_0x3be501,nt(_0x2f0835,_0x452d5a);}['_getReauthenticationResolver'](_0x3d1981){const _0x23d590=this['buildRequest']();return _0x23d590['autoCreate']=!0x1,nt(_0x3d1981,_0x23d590);}['buildRequest'](){const _0x3e17ee={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x3e17ee['pendingToken']=this['pendingToken'];else{const _0x564d99={};this['idToken']&&(_0x564d99['id_token']=this['idToken']),this['accessToken']&&(_0x564d99['access_token']=this['accessToken']),this['secret']&&(_0x564d99['oauth_token_secret']=this['secret']),_0x564d99['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x564d99['nonce']=this['nonce']),_0x3e17ee['postBody']=ut(_0x564d99);}return _0x3e17ee;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x1f4d03){switch(_0x1f4d03){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x19525f){const _0x33baac=Ct(Tt(_0x19525f))['link'],_0x38ff33=_0x33baac?Ct(Tt(_0x33baac))['deep_link_id']:null,_0x3ea984=Ct(Tt(_0x19525f))['deep_link_id'];return(_0x3ea984?Ct(Tt(_0x3ea984))['link']:null)||_0x3ea984||_0x38ff33||_0x33baac||_0x19525f;}class Rs{constructor(_0x377f06){const _0x1c81b0=Ct(Tt(_0x377f06)),_0x4c7988=_0x1c81b0['apiKey']??null,_0x21085f=_0x1c81b0['oobCode']??null,_0x90580=Jf(_0x1c81b0['mode']??null);m(_0x4c7988&&_0x21085f&&_0x90580,'argument-error'),this['apiKey']=_0x4c7988,this['operation']=_0x90580,this['code']=_0x21085f,this['continueUrl']=_0x1c81b0['continueUrl']??null,this['languageCode']=_0x1c81b0['lang']??null,this['tenantId']=_0x1c81b0['tenantId']??null;}static['parseLink'](_0x5441e6){const _0x383de0=Xf(_0x5441e6);try{return new Rs(_0x383de0);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x438768,_0x175dae){return $t['_fromEmailAndPassword'](_0x438768,_0x175dae);}static['credentialWithLink'](_0x398ce9,_0x27484b){const _0x4bc9a4=Rs['parseLink'](_0x27484b);return m(_0x4bc9a4,'argument-error'),$t['_fromEmailAndCode'](_0x398ce9,_0x4bc9a4['code'],_0x4bc9a4['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x2ed785){this['providerId']=_0x2ed785,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x54b5da){this['defaultLanguageCode']=_0x54b5da;}['setCustomParameters'](_0x233b5b){return this['customParameters']=_0x233b5b,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x4f5a99){return this['scopes']['includes'](_0x4f5a99)||this['scopes']['push'](_0x4f5a99),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x4638ef){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x4638ef});}static['credentialFromResult'](_0x9e47fa){return ue['credentialFromTaggedObject'](_0x9e47fa);}static['credentialFromError'](_0x5d7b07){return ue['credentialFromTaggedObject'](_0x5d7b07['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x39b59d}){if(!_0x39b59d||!('oauthAccessToken'in _0x39b59d)||!_0x39b59d['oauthAccessToken'])return null;try{return ue['credential'](_0x39b59d['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x5688a2,_0x18b406){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x5688a2,'accessToken':_0x18b406});}static['credentialFromResult'](_0x1205b3){return de['credentialFromTaggedObject'](_0x1205b3);}static['credentialFromError'](_0x3580b1){return de['credentialFromTaggedObject'](_0x3580b1['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x30cbb6}){if(!_0x30cbb6)return null;const {oauthIdToken:_0x1b8cce,oauthAccessToken:_0x440cdb}=_0x30cbb6;if(!_0x1b8cce&&!_0x440cdb)return null;try{return de['credential'](_0x1b8cce,_0x440cdb);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x41ae46){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x41ae46});}static['credentialFromResult'](_0x1588d9){return fe['credentialFromTaggedObject'](_0x1588d9);}static['credentialFromError'](_0x1c0262){return fe['credentialFromTaggedObject'](_0x1c0262['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x23b8fa}){if(!_0x23b8fa||!('oauthAccessToken'in _0x23b8fa)||!_0x23b8fa['oauthAccessToken'])return null;try{return fe['credential'](_0x23b8fa['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x4edeb4,_0x1860d3){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x4edeb4,'oauthTokenSecret':_0x1860d3});}static['credentialFromResult'](_0x13605b){return pe['credentialFromTaggedObject'](_0x13605b);}static['credentialFromError'](_0x1fbe20){return pe['credentialFromTaggedObject'](_0x1fbe20['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1c2409}){if(!_0x1c2409)return null;const {oauthAccessToken:_0x314f6a,oauthTokenSecret:_0x9e03b6}=_0x1c2409;if(!_0x314f6a||!_0x9e03b6)return null;try{return pe['credential'](_0x314f6a,_0x9e03b6);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x3fa21f,_0x2a0be0){return en(_0x3fa21f,'POST','/v1/accounts:signUp',ke(_0x3fa21f,_0x2a0be0));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x54ba91){this['user']=_0x54ba91['user'],this['providerId']=_0x54ba91['providerId'],this['_tokenResponse']=_0x54ba91['_tokenResponse'],this['operationType']=_0x54ba91['operationType'];}static async['_fromIdTokenResponse'](_0x20f4b0,_0x11651e,_0xb80014,_0x1b1d4c=!0x1){const _0x268caa=await j['_fromIdTokenResponse'](_0x20f4b0,_0xb80014,_0x1b1d4c),_0xa81f7e=Nr(_0xb80014);return new Ge({'user':_0x268caa,'providerId':_0xa81f7e,'_tokenResponse':_0xb80014,'operationType':_0x11651e});}static async['_forOperation'](_0x3783ae,_0x3a2edc,_0x3b7b74){await _0x3783ae['_updateTokensIfNecessary'](_0x3b7b74,!0x0);const _0x715034=Nr(_0x3b7b74);return new Ge({'user':_0x3783ae,'providerId':_0x715034,'_tokenResponse':_0x3b7b74,'operationType':_0x3a2edc});}}function Nr(_0x4d94d4){return _0x4d94d4['providerId']?_0x4d94d4['providerId']:'phoneNumber'in _0x4d94d4?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x3236b5,_0x47799c,_0x35ee97,_0x2b8c38){super(_0x47799c['code'],_0x47799c['message']),this['operationType']=_0x35ee97,this['user']=_0x2b8c38,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x3236b5['name'],'tenantId':_0x3236b5['tenantId']??void 0x0,'_serverResponse':_0x47799c['customData']['_serverResponse'],'operationType':_0x35ee97};}static['_fromErrorAndOperation'](_0x22b98a,_0x5951bb,_0x16e3e9,_0x57b468){return new On(_0x22b98a,_0x5951bb,_0x16e3e9,_0x57b468);}}function Ba(_0x396483,_0x30f741,_0x45381a,_0x43e994){return(_0x30f741==='reauthenticate'?_0x45381a['_getReauthenticationResolver'](_0x396483):_0x45381a['_getIdTokenResponse'](_0x396483))['catch'](_0x5255ff=>{throw _0x5255ff['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x396483,_0x5255ff,_0x30f741,_0x43e994):_0x5255ff;});}async function ep(_0x2f0a2d,_0x1c6e47,_0x53834b=!0x1){const _0x193388=await Ht(_0x2f0a2d,_0x1c6e47['_linkToIdToken'](_0x2f0a2d['auth'],await _0x2f0a2d['getIdToken']()),_0x53834b);return Ge['_forOperation'](_0x2f0a2d,'link',_0x193388);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x5822d7,_0x6b3618,_0x5b6e68=!0x1){const {auth:_0x57eccc}=_0x5822d7;if($(_0x57eccc['app']))return Promise['reject'](re(_0x57eccc));const _0x1cf8e6='reauthenticate';try{const _0x2d8722=await Ht(_0x5822d7,Ba(_0x57eccc,_0x1cf8e6,_0x6b3618,_0x5822d7),_0x5b6e68);m(_0x2d8722['idToken'],_0x57eccc,'internal-error');const _0x4c7860=Ts(_0x2d8722['idToken']);m(_0x4c7860,_0x57eccc,'internal-error');const {sub:_0x4718e8}=_0x4c7860;return m(_0x5822d7['uid']===_0x4718e8,_0x57eccc,'user-mismatch'),Ge['_forOperation'](_0x5822d7,_0x1cf8e6,_0x2d8722);}catch(_0x456e6c){throw(_0x456e6c==null?void 0x0:_0x456e6c['code'])==='auth/user-not-found'&&Y(_0x57eccc,'user-mismatch'),_0x456e6c;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x36b052,_0x2dec69,_0x1cae79=!0x1){if($(_0x36b052['app']))return Promise['reject'](re(_0x36b052));const _0x40032c='signIn',_0x2c245b=await Ba(_0x36b052,_0x40032c,_0x2dec69),_0x19f9e4=await Ge['_fromIdTokenResponse'](_0x36b052,_0x40032c,_0x2c245b);return _0x1cae79||await _0x36b052['_updateCurrentUser'](_0x19f9e4['user']),_0x19f9e4;}async function np(_0xd1da4b,_0x4199ab){return Va(Ke(_0xd1da4b),_0x4199ab);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0xcc7a3a){const _0x4e2eef=Ke(_0xcc7a3a);_0x4e2eef['_getPasswordPolicyInternal']()&&await _0x4e2eef['_updatePasswordPolicy']();}async function L_(_0x4ab1c8,_0xe50f11,_0x118ac2){if($(_0x4ab1c8['app']))return Promise['reject'](re(_0x4ab1c8));const _0x2f9152=Ke(_0x4ab1c8),_0xb0ce08=await xi(_0x2f9152,{'returnSecureToken':!0x0,'email':_0xe50f11,'password':_0x118ac2,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x40b90e=>{throw _0x40b90e['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x4ab1c8),_0x40b90e;}),_0x4b6651=await Ge['_fromIdTokenResponse'](_0x2f9152,'signIn',_0xb0ce08);return await _0x2f9152['_updateCurrentUser'](_0x4b6651['user']),_0x4b6651;}function x_(_0x11fb5a,_0x2f065a,_0x40fa08){return $(_0x11fb5a['app'])?Promise['reject'](re(_0x11fb5a)):np(P(_0x11fb5a),yt['credential'](_0x2f065a,_0x40fa08))['catch'](async _0x425467=>{throw _0x425467['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x11fb5a),_0x425467;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x38deec,_0x1acea4){return P(_0x38deec)['setPersistence'](_0x1acea4);}function ip(_0x688138,_0x30d50d,_0x2371a9,_0x4e42f2){return P(_0x688138)['onIdTokenChanged'](_0x30d50d,_0x2371a9,_0x4e42f2);}function sp(_0xedda7b,_0xf5e872,_0x181a3a){return P(_0xedda7b)['beforeAuthStateChanged'](_0xf5e872,_0x181a3a);}function U_(_0xcf8c3c,_0x516f80,_0x2318bb,_0x56cbcd){return P(_0xcf8c3c)['onAuthStateChanged'](_0x516f80,_0x2318bb,_0x56cbcd);}function W_(_0x66a3f2){return P(_0x66a3f2)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x3540c6,_0x5a2814){this['storageRetriever']=_0x3540c6,this['type']=_0x5a2814;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x367397,_0x31b40d){return this['storage']['setItem'](_0x367397,JSON['stringify'](_0x31b40d)),Promise['resolve']();}['_get'](_0x458ac4){const _0x308540=this['storage']['getItem'](_0x458ac4);return Promise['resolve'](_0x308540?JSON['parse'](_0x308540):null);}['_remove'](_0x3d018a){return this['storage']['removeItem'](_0x3d018a),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x52b631,_0x3281e7)=>this['onStorageEvent'](_0x52b631,_0x3281e7),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x5d143b){for(const _0x5a17ac of Object['keys'](this['listeners'])){const _0x3cfcae=this['storage']['getItem'](_0x5a17ac),_0x3f6874=this['localCache'][_0x5a17ac];_0x3cfcae!==_0x3f6874&&_0x5d143b(_0x5a17ac,_0x3f6874,_0x3cfcae);}}['onStorageEvent'](_0x27f45d,_0xa21b93=!0x1){if(!_0x27f45d['key']){this['forAllChangedKeys']((_0x21cea9,_0x55e5fc,_0x51e2f4)=>{this['notifyListeners'](_0x21cea9,_0x51e2f4);});return;}const _0x1fc12c=_0x27f45d['key'];_0xa21b93?this['detachListener']():this['stopPolling']();const _0x465cdc=()=>{const _0x11fa7a=this['storage']['getItem'](_0x1fc12c);!_0xa21b93&&this['localCache'][_0x1fc12c]===_0x11fa7a||this['notifyListeners'](_0x1fc12c,_0x11fa7a);},_0x262a62=this['storage']['getItem'](_0x1fc12c);Af()&&_0x262a62!==_0x27f45d['newValue']&&_0x27f45d['newValue']!==_0x27f45d['oldValue']?setTimeout(_0x465cdc,op):_0x465cdc();}['notifyListeners'](_0x3a7ec7,_0x3f0de7){this['localCache'][_0x3a7ec7]=_0x3f0de7;const _0x4201f1=this['listeners'][_0x3a7ec7];if(_0x4201f1){for(const _0x405a26 of Array['from'](_0x4201f1))_0x405a26(_0x3f0de7&&JSON['parse'](_0x3f0de7));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x58fe93,_0x409036,_0x4d9423)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x58fe93,'oldValue':_0x409036,'newValue':_0x4d9423}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x31fbe6,_0x42f10d){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x31fbe6]||(this['listeners'][_0x31fbe6]=new Set(),this['localCache'][_0x31fbe6]=this['storage']['getItem'](_0x31fbe6)),this['listeners'][_0x31fbe6]['add'](_0x42f10d);}['_removeListener'](_0x4f9eb3,_0x14695e){this['listeners'][_0x4f9eb3]&&(this['listeners'][_0x4f9eb3]['delete'](_0x14695e),this['listeners'][_0x4f9eb3]['size']===0x0&&delete this['listeners'][_0x4f9eb3]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x57c822,_0x247e4b){await super['_set'](_0x57c822,_0x247e4b),this['localCache'][_0x57c822]=JSON['stringify'](_0x247e4b);}async['_get'](_0x562ac6){const _0x24685d=await super['_get'](_0x562ac6);return this['localCache'][_0x562ac6]=JSON['stringify'](_0x24685d),_0x24685d;}async['_remove'](_0xe5b2aa){await super['_remove'](_0xe5b2aa),delete this['localCache'][_0xe5b2aa];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x1fe823,_0x31c083){}['_removeListener'](_0x1d94a7,_0x3132a2){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x2ea0bd){return Promise['all'](_0x2ea0bd['map'](async _0x32c525=>{try{return{'fulfilled':!0x0,'value':await _0x32c525};}catch(_0x454220){return{'fulfilled':!0x1,'reason':_0x454220};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x327f44){this['eventTarget']=_0x327f44,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0xca7405){const _0x377732=this['receivers']['find'](_0x14ce16=>_0x14ce16['isListeningto'](_0xca7405));if(_0x377732)return _0x377732;const _0x403696=new Xn(_0xca7405);return this['receivers']['push'](_0x403696),_0x403696;}['isListeningto'](_0x192978){return this['eventTarget']===_0x192978;}async['handleEvent'](_0x526b34){const _0x571a94=_0x526b34,{eventId:_0x378c99,eventType:_0x9102df,data:_0x4c4dab}=_0x571a94['data'],_0x5c7df5=this['handlersMap'][_0x9102df];if(!(_0x5c7df5!=null&&_0x5c7df5['size']))return;_0x571a94['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x378c99,'eventType':_0x9102df});const _0x297106=Array['from'](_0x5c7df5)['map'](async _0x2bc72c=>_0x2bc72c(_0x571a94['origin'],_0x4c4dab)),_0x4432d7=await cp(_0x297106);_0x571a94['ports'][0x0]['postMessage']({'status':'done','eventId':_0x378c99,'eventType':_0x9102df,'response':_0x4432d7});}['_subscribe'](_0xf491c0,_0x2c9fa9){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0xf491c0]||(this['handlersMap'][_0xf491c0]=new Set()),this['handlersMap'][_0xf491c0]['add'](_0x2c9fa9);}['_unsubscribe'](_0x982915,_0x293aa9){this['handlersMap'][_0x982915]&&_0x293aa9&&this['handlersMap'][_0x982915]['delete'](_0x293aa9),(!_0x293aa9||this['handlersMap'][_0x982915]['size']===0x0)&&delete this['handlersMap'][_0x982915],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x4407b8='',_0x29eb5f=0xa){let _0x37cce2='';for(let _0x4e7352=0x0;_0x4e7352<_0x29eb5f;_0x4e7352++)_0x37cce2+=Math['floor'](Math['random']()*0xa);return _0x4407b8+_0x37cce2;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x15dd61){this['target']=_0x15dd61,this['handlers']=new Set();}['removeMessageHandler'](_0x23f69a){_0x23f69a['messageChannel']&&(_0x23f69a['messageChannel']['port1']['removeEventListener']('message',_0x23f69a['onMessage']),_0x23f69a['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x23f69a);}async['_send'](_0x658ae8,_0x45a5cf,_0x82ff36=0x32){const _0x385984=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x385984)throw new Error('connection_unavailable');let _0x23209e,_0x33e9f4;return new Promise((_0x1aa64c,_0x15f7d7)=>{const _0x519a09=As('',0x14);_0x385984['port1']['start']();const _0x2914e7=setTimeout(()=>{_0x15f7d7(new Error('unsupported_event'));},_0x82ff36);_0x33e9f4={'messageChannel':_0x385984,'onMessage'(_0x2025f0){const _0x554354=_0x2025f0;if(_0x554354['data']['eventId']===_0x519a09)switch(_0x554354['data']['status']){case'ack':clearTimeout(_0x2914e7),_0x23209e=setTimeout(()=>{_0x15f7d7(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x23209e),_0x1aa64c(_0x554354['data']['response']);break;default:clearTimeout(_0x2914e7),clearTimeout(_0x23209e),_0x15f7d7(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x33e9f4),_0x385984['port1']['addEventListener']('message',_0x33e9f4['onMessage']),this['target']['postMessage']({'eventType':_0x658ae8,'eventId':_0x519a09,'data':_0x45a5cf},[_0x385984['port2']]);})['finally'](()=>{_0x33e9f4&&this['removeMessageHandler'](_0x33e9f4);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x15c46f){Z()['location']['href']=_0x15c46f;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x2a7e13;return((_0x2a7e13=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x2a7e13['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x5335b5){this['request']=_0x5335b5;}['toPromise'](){return new Promise((_0x22ca34,_0x3e1d14)=>{this['request']['addEventListener']('success',()=>{_0x22ca34(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x3e1d14(this['request']['error']);});});}}function Zn(_0x362244,_0x1025eb){return _0x362244['transaction']([Mn],_0x1025eb?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x3dc0bf=indexedDB['deleteDatabase'](Ka);return new nn(_0x3dc0bf)['toPromise']();}function Qa(){const _0x2cb0ff=indexedDB['open'](Ka,pp);return new Promise((_0x4ccaed,_0x14fc7b)=>{_0x2cb0ff['addEventListener']('error',()=>{_0x14fc7b(_0x2cb0ff['error']);}),_0x2cb0ff['addEventListener']('upgradeneeded',()=>{const _0x43a1e3=_0x2cb0ff['result'];try{_0x43a1e3['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x4aaada){_0x14fc7b(_0x4aaada);}}),_0x2cb0ff['addEventListener']('success',async()=>{const _0x541308=_0x2cb0ff['result'];_0x541308['objectStoreNames']['contains'](Mn)?_0x4ccaed(_0x541308):(_0x541308['close'](),await _p(),_0x4ccaed(await Qa()));});});}async function Or(_0x36be2d,_0x15c160,_0x5294a2){const _0x3638e7=Zn(_0x36be2d,!0x0)['put']({[Ya]:_0x15c160,'value':_0x5294a2});return new nn(_0x3638e7)['toPromise']();}async function gp(_0x2bdee9,_0x10bf64){const _0x3b6059=Zn(_0x2bdee9,!0x1)['get'](_0x10bf64),_0x228e45=await new nn(_0x3b6059)['toPromise']();return _0x228e45===void 0x0?null:_0x228e45['value'];}function Dr(_0x1eb8a0,_0x1dcd0e){const _0x5ef08e=Zn(_0x1eb8a0,!0x0)['delete'](_0x1dcd0e);return new nn(_0x5ef08e)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x4700e2){let _0x5cb6ec=0x0;for(;;)try{const _0x176d64=await this['_openDb']();return await _0x4700e2(_0x176d64);}catch(_0x5b137d){if(_0x5cb6ec++>yp)throw _0x5b137d;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x6d554,_0x4ed7e7)=>({'keyProcessed':(await this['_poll']())['includes'](_0x4ed7e7['key'])})),this['receiver']['_subscribe']('ping',async(_0xffaa2b,_0x967d47)=>['keyChanged']);}async['initializeSender'](){var _0x3f2a9c,_0xaefbae;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x31ac21=await this['sender']['_send']('ping',{},0x320);_0x31ac21&&(_0x3f2a9c=_0x31ac21[0x0])!=null&&_0x3f2a9c['fulfilled']&&(_0xaefbae=_0x31ac21[0x0])!=null&&_0xaefbae['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x2d3fea){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x2d3fea},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x589ed4=>{await Or(_0x589ed4,Dn,'1'),await Dr(_0x589ed4,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x222467){this['pendingWrites']++;try{await _0x222467();}finally{this['pendingWrites']--;}}async['_set'](_0x4cb26c,_0xc7540e){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x3824e1=>Or(_0x3824e1,_0x4cb26c,_0xc7540e)),this['localCache'][_0x4cb26c]=_0xc7540e,this['notifyServiceWorker'](_0x4cb26c)));}async['_get'](_0x571f14){const _0xfc28e1=await this['_withRetries'](_0x550a0f=>gp(_0x550a0f,_0x571f14));return this['localCache'][_0x571f14]=_0xfc28e1,_0xfc28e1;}async['_remove'](_0x8675ae){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x20de94=>Dr(_0x20de94,_0x8675ae)),delete this['localCache'][_0x8675ae],this['notifyServiceWorker'](_0x8675ae)));}async['_poll'](){const _0x5b9f82=await this['_withRetries'](_0x4149e5=>{const _0x31fce6=Zn(_0x4149e5,!0x1)['getAll']();return new nn(_0x31fce6)['toPromise']();});if(!_0x5b9f82)return[];if(this['pendingWrites']!==0x0)return[];const _0x304835=[],_0x1df046=new Set();if(_0x5b9f82['length']!==0x0){for(const {fbase_key:_0xa8b09b,value:_0x141636}of _0x5b9f82)_0x1df046['add'](_0xa8b09b),JSON['stringify'](this['localCache'][_0xa8b09b])!==JSON['stringify'](_0x141636)&&(this['notifyListeners'](_0xa8b09b,_0x141636),_0x304835['push'](_0xa8b09b));}for(const _0x4debe3 of Object['keys'](this['localCache']))this['localCache'][_0x4debe3]&&!_0x1df046['has'](_0x4debe3)&&(this['notifyListeners'](_0x4debe3,null),_0x304835['push'](_0x4debe3));return _0x304835;}['notifyListeners'](_0x4946ef,_0x523b1a){this['localCache'][_0x4946ef]=_0x523b1a;const _0x2709b1=this['listeners'][_0x4946ef];if(_0x2709b1){for(const _0x1d5556 of Array['from'](_0x2709b1))_0x1d5556(_0x523b1a);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x4399c4,_0x59db76){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x4399c4]||(this['listeners'][_0x4399c4]=new Set(),this['_get'](_0x4399c4)),this['listeners'][_0x4399c4]['add'](_0x59db76);}['_removeListener'](_0x1b9f16,_0x2dd683){this['listeners'][_0x1b9f16]&&(this['listeners'][_0x1b9f16]['delete'](_0x2dd683),this['listeners'][_0x1b9f16]['size']===0x0&&delete this['listeners'][_0x1b9f16]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x12f2a3,_0x2036e9){return _0x2036e9?ie(_0x2036e9):(m(_0x12f2a3['_popupRedirectResolver'],_0x12f2a3,'argument-error'),_0x12f2a3['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x528b00){super('custom','custom'),this['params']=_0x528b00;}['_getIdTokenResponse'](_0x4e52cd){return nt(_0x4e52cd,this['_buildIdpRequest']());}['_linkToIdToken'](_0x1579fd,_0x39e904){return nt(_0x1579fd,this['_buildIdpRequest'](_0x39e904));}['_getReauthenticationResolver'](_0x30d3b5){return nt(_0x30d3b5,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x29e929){const _0x31c581={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x29e929&&(_0x31c581['idToken']=_0x29e929),_0x31c581;}}function Ip(_0x37084d){return Va(_0x37084d['auth'],new ks(_0x37084d),_0x37084d['bypassAuthState']);}function wp(_0x4ebc4f){const {auth:_0x23339b,user:_0x2d9b5e}=_0x4ebc4f;return m(_0x2d9b5e,_0x23339b,'internal-error'),tp(_0x2d9b5e,new ks(_0x4ebc4f),_0x4ebc4f['bypassAuthState']);}async function Cp(_0x195a2a){const {auth:_0x4f0ffb,user:_0x365f67}=_0x195a2a;return m(_0x365f67,_0x4f0ffb,'internal-error'),ep(_0x365f67,new ks(_0x195a2a),_0x195a2a['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x549abc,_0x293434,_0x50f6e1,_0x120779,_0x22d494=!0x1){this['auth']=_0x549abc,this['resolver']=_0x50f6e1,this['user']=_0x120779,this['bypassAuthState']=_0x22d494,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x293434)?_0x293434:[_0x293434];}['execute'](){return new Promise(async(_0x4de9a5,_0x1fd14e)=>{this['pendingPromise']={'resolve':_0x4de9a5,'reject':_0x1fd14e};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x516ffc){this['reject'](_0x516ffc);}});}async['onAuthEvent'](_0x3e93b0){const {urlResponse:_0x3821df,sessionId:_0x32d786,postBody:_0x151e45,tenantId:_0x40e5d1,error:_0x312abf,type:_0x1cec7a}=_0x3e93b0;if(_0x312abf){this['reject'](_0x312abf);return;}const _0x49a3f2={'auth':this['auth'],'requestUri':_0x3821df,'sessionId':_0x32d786,'tenantId':_0x40e5d1||void 0x0,'postBody':_0x151e45||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x1cec7a)(_0x49a3f2));}catch(_0xb07f76){this['reject'](_0xb07f76);}}['onError'](_0x4b27e3){this['reject'](_0x4b27e3);}['getIdpTask'](_0x266432){switch(_0x266432){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x3a1b47){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x3a1b47),this['unregisterAndCleanUp']();}['reject'](_0x775a3d){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x775a3d),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x4746af,_0x44acc7,_0x3da987,_0x1ee66b,_0x1e2b40){super(_0x4746af,_0x44acc7,_0x1ee66b,_0x1e2b40),this['provider']=_0x3da987,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0xea4214=await this['execute']();return m(_0xea4214,this['auth'],'internal-error'),_0xea4214;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x3f0c83=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x3f0c83),this['authWindow']['associatedEvent']=_0x3f0c83,this['resolver']['_originValidation'](this['auth'])['catch'](_0x59969d=>{this['reject'](_0x59969d);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x4f8b64=>{_0x4f8b64||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x1abf95;return((_0x1abf95=this['authWindow'])==null?void 0x0:_0x1abf95['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x245dda=()=>{var _0x456b7b,_0x1f792b;if((_0x1f792b=(_0x456b7b=this['authWindow'])==null?void 0x0:_0x456b7b['window'])!=null&&_0x1f792b['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x245dda,Tp['get']());};_0x245dda();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x1081b6,_0x3f0f72,_0x54fdca=!0x1){super(_0x1081b6,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x3f0f72,void 0x0,_0x54fdca),this['eventId']=null;}async['execute'](){let _0x4d52c4=hn['get'](this['auth']['_key']());if(!_0x4d52c4){try{const _0x52690e=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x4d52c4=()=>Promise['resolve'](_0x52690e);}catch(_0x3d84d8){_0x4d52c4=()=>Promise['reject'](_0x3d84d8);}hn['set'](this['auth']['_key'](),_0x4d52c4);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x4d52c4();}async['onAuthEvent'](_0x14792c){if(_0x14792c['type']==='signInViaRedirect')return super['onAuthEvent'](_0x14792c);if(_0x14792c['type']==='unknown'){this['resolve'](null);return;}if(_0x14792c['eventId']){const _0xdde10c=await this['auth']['_redirectUserForId'](_0x14792c['eventId']);if(_0xdde10c)return this['user']=_0xdde10c,super['onAuthEvent'](_0x14792c);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x11f525,_0x5e99b3){const _0x1fc7ef=Pp(_0x5e99b3),_0x3b94c3=kp(_0x11f525);if(!await _0x3b94c3['_isAvailable']())return!0x1;const _0x228c9c=await _0x3b94c3['_get'](_0x1fc7ef)==='true';return await _0x3b94c3['_remove'](_0x1fc7ef),_0x228c9c;}function Ap(_0x575500,_0x3eb32f){hn['set'](_0x575500['_key'](),_0x3eb32f);}function kp(_0x1f6091){return ie(_0x1f6091['_redirectPersistence']);}function Pp(_0x30d798){return ln(Sp,_0x30d798['config']['apiKey'],_0x30d798['name']);}async function Np(_0x20354f,_0x179118,_0x187fa2=!0x1){if($(_0x20354f['app']))return Promise['reject'](re(_0x20354f));const _0x2935bb=Ke(_0x20354f),_0x2d9eb2=Ep(_0x2935bb,_0x179118),_0x282044=await new bp(_0x2935bb,_0x2d9eb2,_0x187fa2)['execute']();return _0x282044&&!_0x187fa2&&(delete _0x282044['user']['_redirectEventId'],await _0x2935bb['_persistUserIfCurrent'](_0x282044['user']),await _0x2935bb['_setRedirectUser'](null,_0x179118)),_0x282044;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x760a5){this['auth']=_0x760a5,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x1616ed){this['consumers']['add'](_0x1616ed),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x1616ed)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x1616ed),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x7862aa){this['consumers']['delete'](_0x7862aa);}['onEvent'](_0x47262f){if(this['hasEventBeenHandled'](_0x47262f))return!0x1;let _0x5916fa=!0x1;return this['consumers']['forEach'](_0x48125a=>{this['isEventForConsumer'](_0x47262f,_0x48125a)&&(_0x5916fa=!0x0,this['sendToConsumer'](_0x47262f,_0x48125a),this['saveEventToCache'](_0x47262f));}),this['hasHandledPotentialRedirect']||!Mp(_0x47262f)||(this['hasHandledPotentialRedirect']=!0x0,_0x5916fa||(this['queuedRedirectEvent']=_0x47262f,_0x5916fa=!0x0)),_0x5916fa;}['sendToConsumer'](_0x1052f1,_0x4febf1){var _0x2f4114;if(_0x1052f1['error']&&!Za(_0x1052f1)){const _0xc36446=((_0x2f4114=_0x1052f1['error']['code'])==null?void 0x0:_0x2f4114['split']('auth/')[0x1])||'internal-error';_0x4febf1['onError'](X(this['auth'],_0xc36446));}else _0x4febf1['onAuthEvent'](_0x1052f1);}['isEventForConsumer'](_0x5c018f,_0x25df9){const _0x2c2625=_0x25df9['eventId']===null||!!_0x5c018f['eventId']&&_0x5c018f['eventId']===_0x25df9['eventId'];return _0x25df9['filter']['includes'](_0x5c018f['type'])&&_0x2c2625;}['hasEventBeenHandled'](_0x2f6968){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x2f6968));}['saveEventToCache'](_0xec51e){this['cachedEventUids']['add'](Mr(_0xec51e)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x44f84d){return[_0x44f84d['type'],_0x44f84d['eventId'],_0x44f84d['sessionId'],_0x44f84d['tenantId']]['filter'](_0x75f135=>_0x75f135)['join']('-');}function Za({type:_0x197a04,error:_0x5bbf45}){return _0x197a04==='unknown'&&(_0x5bbf45==null?void 0x0:_0x5bbf45['code'])==='auth/no-auth-event';}function Mp(_0x11772a){switch(_0x11772a['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x11772a);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x52010c,_0x5c5a55={}){return Pe(_0x52010c,'GET','/v1/projects',_0x5c5a55);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x60066){if(_0x60066['config']['emulator'])return;const {authorizedDomains:_0x299fed}=await Lp(_0x60066);for(const _0x4af66c of _0x299fed)try{if(Wp(_0x4af66c))return;}catch{}Y(_0x60066,'unauthorized-domain');}function Wp(_0x5d2dc2){const _0x41e876=Mi(),{protocol:_0x3c9f55,hostname:_0x56b4d8}=new URL(_0x41e876);if(_0x5d2dc2['startsWith']('chrome-extension://')){const _0x283d9a=new URL(_0x5d2dc2);return _0x283d9a['hostname']===''&&_0x56b4d8===''?_0x3c9f55==='chrome-extension:'&&_0x5d2dc2['replace']('chrome-extension://','')===_0x41e876['replace']('chrome-extension://',''):_0x3c9f55==='chrome-extension:'&&_0x283d9a['hostname']===_0x56b4d8;}if(!Fp['test'](_0x3c9f55))return!0x1;if(xp['test'](_0x5d2dc2))return _0x56b4d8===_0x5d2dc2;const _0x2d2834=_0x5d2dc2['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x2d2834+'|'+_0x2d2834+')$','i')['test'](_0x56b4d8);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x12059c=Z()['___jsl'];if(_0x12059c!=null&&_0x12059c['H']){for(const _0x414c30 of Object['keys'](_0x12059c['H']))if(_0x12059c['H'][_0x414c30]['r']=_0x12059c['H'][_0x414c30]['r']||[],_0x12059c['H'][_0x414c30]['L']=_0x12059c['H'][_0x414c30]['L']||[],_0x12059c['H'][_0x414c30]['r']=[..._0x12059c['H'][_0x414c30]['L']],_0x12059c['CP']){for(let _0x8eb72b=0x0;_0x8eb72b<_0x12059c['CP']['length'];_0x8eb72b++)_0x12059c['CP'][_0x8eb72b]=null;}}}function Vp(_0x25f7b9){return new Promise((_0x223b6f,_0x12d33d)=>{var _0x507bf9,_0x2e6abf,_0x44a58a;function _0x47e301(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x223b6f(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x12d33d(X(_0x25f7b9,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x2e6abf=(_0x507bf9=Z()['gapi'])==null?void 0x0:_0x507bf9['iframes'])!=null&&_0x2e6abf['Iframe'])_0x223b6f(gapi['iframes']['getContext']());else{if((_0x44a58a=Z()['gapi'])!=null&&_0x44a58a['load'])_0x47e301();else{const _0x2d7e90=Ff('iframefcb');return Z()[_0x2d7e90]=()=>{gapi['load']?_0x47e301():_0x12d33d(X(_0x25f7b9,'network-request-failed'));},xa(xf()+'?onload='+_0x2d7e90)['catch'](_0x22d632=>_0x12d33d(_0x22d632));}}})['catch'](_0x2bc644=>{throw un=null,_0x2bc644;});}let un=null;function Hp(_0x4e0ade){return un=un||Vp(_0x4e0ade),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x23f59d){const _0x4c49f9=_0x23f59d['config'];m(_0x4c49f9['authDomain'],_0x23f59d,'auth-domain-config-required');const _0x11aa0e=_0x4c49f9['emulator']?Cs(_0x4c49f9,qp):'https://'+_0x23f59d['config']['authDomain']+'/'+Gp,_0x52b436={'apiKey':_0x4c49f9['apiKey'],'appName':_0x23f59d['name'],'v':dt},_0x465ee8=jp['get'](_0x23f59d['config']['apiHost']);_0x465ee8&&(_0x52b436['eid']=_0x465ee8);const _0x3fb4b6=_0x23f59d['_getFrameworks']();return _0x3fb4b6['length']&&(_0x52b436['fw']=_0x3fb4b6['join'](',')),_0x11aa0e+'?'+ut(_0x52b436)['slice'](0x1);}async function Yp(_0x5062f7){const _0x210dbc=await Hp(_0x5062f7),_0x4c14f6=Z()['gapi'];return m(_0x4c14f6,_0x5062f7,'internal-error'),_0x210dbc['open']({'where':document['body'],'url':Kp(_0x5062f7),'messageHandlersFilter':_0x4c14f6['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x206f7e=>new Promise(async(_0x25fa61,_0x5103fc)=>{await _0x206f7e['restyle']({'setHideOnLeave':!0x1});const _0x20b196=X(_0x5062f7,'network-request-failed'),_0x326450=Z()['setTimeout'](()=>{_0x5103fc(_0x20b196);},$p['get']());function _0x38e70e(){Z()['clearTimeout'](_0x326450),_0x25fa61(_0x206f7e);}_0x206f7e['ping'](_0x38e70e)['then'](_0x38e70e,()=>{_0x5103fc(_0x20b196);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x355d96){this['window']=_0x355d96,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x36ccea,_0x482ddd,_0x2ff148,_0x2dbb58=Jp,_0x56af19=Xp){const _0x280cce=Math['max']((window['screen']['availHeight']-_0x56af19)/0x2,0x0)['toString'](),_0x3ae471=Math['max']((window['screen']['availWidth']-_0x2dbb58)/0x2,0x0)['toString']();let _0x562cd9='';const _0x13ab4b={...Qp,'width':_0x2dbb58['toString'](),'height':_0x56af19['toString'](),'top':_0x280cce,'left':_0x3ae471},_0x32525f=W()['toLowerCase']();_0x2ff148&&(_0x562cd9=ka(_0x32525f)?Zp:_0x2ff148),Ra(_0x32525f)&&(_0x482ddd=_0x482ddd||e_,_0x13ab4b['scrollbars']='yes');const _0x10de56=Object['entries'](_0x13ab4b)['reduce']((_0x1c6d6a,[_0x2c3464,_0x2be007])=>''+_0x1c6d6a+_0x2c3464+'='+_0x2be007+',','');if(Rf(_0x32525f)&&_0x562cd9!=='_self')return n_(_0x482ddd||'',_0x562cd9),new xr(null);const _0x4b5790=window['open'](_0x482ddd||'',_0x562cd9,_0x10de56);m(_0x4b5790,_0x36ccea,'popup-blocked');try{_0x4b5790['focus']();}catch{}return new xr(_0x4b5790);}function n_(_0x3f9076,_0x263cca){const _0x5c87d4=document['createElement']('a');_0x5c87d4['href']=_0x3f9076,_0x5c87d4['target']=_0x263cca;const _0x1272ea=document['createEvent']('MouseEvent');_0x1272ea['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x5c87d4['dispatchEvent'](_0x1272ea);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x4bbdf1,_0x480644,_0x949645,_0x16f0af,_0x395365,_0x1eea10){m(_0x4bbdf1['config']['authDomain'],_0x4bbdf1,'auth-domain-config-required'),m(_0x4bbdf1['config']['apiKey'],_0x4bbdf1,'invalid-api-key');const _0x463d36={'apiKey':_0x4bbdf1['config']['apiKey'],'appName':_0x4bbdf1['name'],'authType':_0x949645,'redirectUrl':_0x16f0af,'v':dt,'eventId':_0x395365};if(_0x480644 instanceof Wa){_0x480644['setDefaultLanguage'](_0x4bbdf1['languageCode']),_0x463d36['providerId']=_0x480644['providerId']||'',pn(_0x480644['getCustomParameters']())||(_0x463d36['customParameters']=JSON['stringify'](_0x480644['getCustomParameters']()));for(const [_0x2f0652,_0x5b5671]of Object['entries']({}))_0x463d36[_0x2f0652]=_0x5b5671;}if(_0x480644 instanceof tn){const _0x5bff4c=_0x480644['getScopes']()['filter'](_0x25dd6d=>_0x25dd6d!=='');_0x5bff4c['length']>0x0&&(_0x463d36['scopes']=_0x5bff4c['join'](','));}_0x4bbdf1['tenantId']&&(_0x463d36['tid']=_0x4bbdf1['tenantId']);const _0x28465c=_0x463d36;for(const _0x3cc2d7 of Object['keys'](_0x28465c))_0x28465c[_0x3cc2d7]===void 0x0&&delete _0x28465c[_0x3cc2d7];const _0x2412b0=await _0x4bbdf1['_getAppCheckToken'](),_0x31d8ce=_0x2412b0?'#'+r_+'='+encodeURIComponent(_0x2412b0):'';return o_(_0x4bbdf1)+'?'+ut(_0x28465c)['slice'](0x1)+_0x31d8ce;}function o_({config:_0x3cfb01}){return _0x3cfb01['emulator']?Cs(_0x3cfb01,s_):'https://'+_0x3cfb01['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x54c1da,_0x23e303,_0x5e28dc,_0x6fe781){var _0x17afe3;ce((_0x17afe3=this['eventManagers'][_0x54c1da['_key']()])==null?void 0x0:_0x17afe3['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0xcc0196=await Fr(_0x54c1da,_0x23e303,_0x5e28dc,Mi(),_0x6fe781);return t_(_0x54c1da,_0xcc0196,As());}async['_openRedirect'](_0x17c565,_0x5c9896,_0x3352cb,_0x3c466d){await this['_originValidation'](_0x17c565);const _0x2824a0=await Fr(_0x17c565,_0x5c9896,_0x3352cb,Mi(),_0x3c466d);return hp(_0x2824a0),new Promise(()=>{});}['_initialize'](_0x5f54f3){const _0x3d5227=_0x5f54f3['_key']();if(this['eventManagers'][_0x3d5227]){const {manager:_0x2ed7e7,promise:_0x32ef8e}=this['eventManagers'][_0x3d5227];return _0x2ed7e7?Promise['resolve'](_0x2ed7e7):(ce(_0x32ef8e,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x32ef8e);}const _0x35ed1f=this['initAndGetManager'](_0x5f54f3);return this['eventManagers'][_0x3d5227]={'promise':_0x35ed1f},_0x35ed1f['catch'](()=>{delete this['eventManagers'][_0x3d5227];}),_0x35ed1f;}async['initAndGetManager'](_0x34b00f){const _0x23ef8c=await Yp(_0x34b00f),_0x44d59c=new Dp(_0x34b00f);return _0x23ef8c['register']('authEvent',_0x5c2bc3=>(m(_0x5c2bc3==null?void 0x0:_0x5c2bc3['authEvent'],_0x34b00f,'invalid-auth-event'),{'status':_0x44d59c['onEvent'](_0x5c2bc3['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x34b00f['_key']()]={'manager':_0x44d59c},this['iframes'][_0x34b00f['_key']()]=_0x23ef8c,_0x44d59c;}['_isIframeWebStorageSupported'](_0x28a57a,_0x15975a){this['iframes'][_0x28a57a['_key']()]['send'](pi,{'type':pi},_0x58f2f1=>{var _0x3d324d;const _0x3ffc14=(_0x3d324d=_0x58f2f1==null?void 0x0:_0x58f2f1[0x0])==null?void 0x0:_0x3d324d[pi];_0x3ffc14!==void 0x0&&_0x15975a(!!_0x3ffc14),Y(_0x28a57a,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x5a8244){const _0x658262=_0x5a8244['_key']();return this['originValidationPromises'][_0x658262]||(this['originValidationPromises'][_0x658262]=Up(_0x5a8244)),this['originValidationPromises'][_0x658262];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x46e873){this['auth']=_0x46e873,this['internalListeners']=new Map();}['getUid'](){var _0x3b2348;return this['assertAuthConfigured'](),((_0x3b2348=this['auth']['currentUser'])==null?void 0x0:_0x3b2348['uid'])||null;}async['getToken'](_0x570fbd){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x570fbd)}:null;}['addAuthTokenListener'](_0x347b5c){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x347b5c))return;const _0x723385=this['auth']['onIdTokenChanged'](_0xd20652=>{_0x347b5c((_0xd20652==null?void 0x0:_0xd20652['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x347b5c,_0x723385),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x4199c4){this['assertAuthConfigured']();const _0x840871=this['internalListeners']['get'](_0x4199c4);_0x840871&&(this['internalListeners']['delete'](_0x4199c4),_0x840871(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x1d9318){switch(_0x1d9318){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x2a1d62){st(new Fe('auth',(_0x1ee5d1,{options:_0x38bef8})=>{const _0x449e4c=_0x1ee5d1['getProvider']('app')['getImmediate'](),_0xa69eec=_0x1ee5d1['getProvider']('heartbeat'),_0x53f1a1=_0x1ee5d1['getProvider']('app-check-internal'),{apiKey:_0x11fb82,authDomain:_0x5f58f0}=_0x449e4c['options'];m(_0x11fb82&&!_0x11fb82['includes'](':'),'invalid-api-key',{'appName':_0x449e4c['name']});const _0x248018={'apiKey':_0x11fb82,'authDomain':_0x5f58f0,'clientPlatform':_0x2a1d62,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x2a1d62)},_0x44d0ad=new Df(_0x449e4c,_0xa69eec,_0x53f1a1,_0x248018);return Hf(_0x44d0ad,_0x38bef8),_0x44d0ad;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x588671,_0x16507a,_0x5c1332)=>{_0x588671['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x36c6c5=>{const _0x4c587e=Ke(_0x36c6c5['getProvider']('auth')['getImmediate']());return(_0x556141=>new l_(_0x556141))(_0x4c587e);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x2a1d62)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x1848d8=>async _0x2c0227=>{const _0xe16d3c=_0x2c0227&&await _0x2c0227['getIdTokenResult'](),_0x55d8f9=_0xe16d3c&&(new Date()['getTime']()-Date['parse'](_0xe16d3c['issuedAtTime']))/0x3e8;if(_0x55d8f9&&_0x55d8f9>f_)return;const _0x54d898=_0xe16d3c==null?void 0x0:_0xe16d3c['token'];Br!==_0x54d898&&(Br=_0x54d898,await fetch(_0x1848d8,{'method':_0x54d898?'POST':'DELETE','headers':_0x54d898?{'Authorization':'Bearer\x20'+_0x54d898}:{}}));};function B_(_0x1a4769=Zr()){const _0x465b9d=Hi(_0x1a4769,'auth');if(_0x465b9d['isInitialized']())return _0x465b9d['getImmediate']();const _0x3233fd=Vf(_0x1a4769,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x4112f0=jr('authTokenSyncURL');if(_0x4112f0&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x3fc919=new URL(_0x4112f0,location['origin']);if(location['origin']===_0x3fc919['origin']){const _0xbc3df3=p_(_0x3fc919['toString']());sp(_0x3233fd,_0xbc3df3,()=>_0xbc3df3(_0x3233fd['currentUser'])),ip(_0x3233fd,_0x45f3e3=>_0xbc3df3(_0x45f3e3));}}const _0x324e65=qr('auth');return _0x324e65&&$f(_0x3233fd,'http://'+_0x324e65),_0x3233fd;}function __(){var _0x148755;return((_0x148755=document['getElementsByTagName']('head'))==null?void 0x0:_0x148755[0x0])??document;}Mf({'loadJS'(_0x24908a){return new Promise((_0xf12e0,_0x2e15ab)=>{const _0x1955c0=document['createElement']('script');_0x1955c0['setAttribute']('src',_0x24908a),_0x1955c0['onload']=_0xf12e0,_0x1955c0['onerror']=_0x44d903=>{const _0x109cd6=X('internal-error');_0x109cd6['customData']=_0x44d903,_0x2e15ab(_0x109cd6);},_0x1955c0['type']='text/javascript',_0x1955c0['charset']='UTF-8',__()['appendChild'](_0x1955c0);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,B_ as a,ap as b,x_ as c,g_ as d,m_ as e,Zr as f,P_ as g,Hd as h,Sl as i,D_ as j,Gd as k,w_ as l,b_ as m,A_ as n,v_ as o,E_ as p,k_ as q,y_ as r,F_ as s,Vt as t,I_ as u,N_ as v,U_ as w,O_ as x,M_ as y,T_ as z};