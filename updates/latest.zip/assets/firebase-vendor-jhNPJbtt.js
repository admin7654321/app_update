const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x2588c0,_0x3d56c2){if(!_0x2588c0)throw ht(_0x3d56c2);},ht=function(_0x17ead3){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x17ead3);},Hr=function(_0x44ac33){const _0x2a5ce4=[];let _0x35971d=0x0;for(let _0x2ee7e5=0x0;_0x2ee7e5<_0x44ac33['length'];_0x2ee7e5++){let _0x190a1c=_0x44ac33['charCodeAt'](_0x2ee7e5);_0x190a1c<0x80?_0x2a5ce4[_0x35971d++]=_0x190a1c:_0x190a1c<0x800?(_0x2a5ce4[_0x35971d++]=_0x190a1c>>0x6|0xc0,_0x2a5ce4[_0x35971d++]=_0x190a1c&0x3f|0x80):(_0x190a1c&0xfc00)===0xd800&&_0x2ee7e5+0x1<_0x44ac33['length']&&(_0x44ac33['charCodeAt'](_0x2ee7e5+0x1)&0xfc00)===0xdc00?(_0x190a1c=0x10000+((_0x190a1c&0x3ff)<<0xa)+(_0x44ac33['charCodeAt'](++_0x2ee7e5)&0x3ff),_0x2a5ce4[_0x35971d++]=_0x190a1c>>0x12|0xf0,_0x2a5ce4[_0x35971d++]=_0x190a1c>>0xc&0x3f|0x80,_0x2a5ce4[_0x35971d++]=_0x190a1c>>0x6&0x3f|0x80,_0x2a5ce4[_0x35971d++]=_0x190a1c&0x3f|0x80):(_0x2a5ce4[_0x35971d++]=_0x190a1c>>0xc|0xe0,_0x2a5ce4[_0x35971d++]=_0x190a1c>>0x6&0x3f|0x80,_0x2a5ce4[_0x35971d++]=_0x190a1c&0x3f|0x80);}return _0x2a5ce4;},nc=function(_0x1dfb8d){const _0x3e4871=[];let _0x5c166e=0x0,_0x282775=0x0;for(;_0x5c166e<_0x1dfb8d['length'];){const _0x36300c=_0x1dfb8d[_0x5c166e++];if(_0x36300c<0x80)_0x3e4871[_0x282775++]=String['fromCharCode'](_0x36300c);else{if(_0x36300c>0xbf&&_0x36300c<0xe0){const _0x293c31=_0x1dfb8d[_0x5c166e++];_0x3e4871[_0x282775++]=String['fromCharCode']((_0x36300c&0x1f)<<0x6|_0x293c31&0x3f);}else{if(_0x36300c>0xef&&_0x36300c<0x16d){const _0x1d8fb3=_0x1dfb8d[_0x5c166e++],_0x2880a1=_0x1dfb8d[_0x5c166e++],_0x45312a=_0x1dfb8d[_0x5c166e++],_0x321715=((_0x36300c&0x7)<<0x12|(_0x1d8fb3&0x3f)<<0xc|(_0x2880a1&0x3f)<<0x6|_0x45312a&0x3f)-0x10000;_0x3e4871[_0x282775++]=String['fromCharCode'](0xd800+(_0x321715>>0xa)),_0x3e4871[_0x282775++]=String['fromCharCode'](0xdc00+(_0x321715&0x3ff));}else{const _0x30ec7d=_0x1dfb8d[_0x5c166e++],_0x2026ee=_0x1dfb8d[_0x5c166e++];_0x3e4871[_0x282775++]=String['fromCharCode']((_0x36300c&0xf)<<0xc|(_0x30ec7d&0x3f)<<0x6|_0x2026ee&0x3f);}}}}return _0x3e4871['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x6be29a,_0x64a35){if(!Array['isArray'](_0x6be29a))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x393451=_0x64a35?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x29259d=[];for(let _0x674884=0x0;_0x674884<_0x6be29a['length'];_0x674884+=0x3){const _0x1e33c5=_0x6be29a[_0x674884],_0x4cad3f=_0x674884+0x1<_0x6be29a['length'],_0x208ddb=_0x4cad3f?_0x6be29a[_0x674884+0x1]:0x0,_0x5192fa=_0x674884+0x2<_0x6be29a['length'],_0x159f7d=_0x5192fa?_0x6be29a[_0x674884+0x2]:0x0,_0x4b28f6=_0x1e33c5>>0x2,_0x3ed99a=(_0x1e33c5&0x3)<<0x4|_0x208ddb>>0x4;let _0x19ab68=(_0x208ddb&0xf)<<0x2|_0x159f7d>>0x6,_0xa9b0bc=_0x159f7d&0x3f;_0x5192fa||(_0xa9b0bc=0x40,_0x4cad3f||(_0x19ab68=0x40)),_0x29259d['push'](_0x393451[_0x4b28f6],_0x393451[_0x3ed99a],_0x393451[_0x19ab68],_0x393451[_0xa9b0bc]);}return _0x29259d['join']('');},'encodeString'(_0x545d65,_0x16b4bf){return this['HAS_NATIVE_SUPPORT']&&!_0x16b4bf?btoa(_0x545d65):this['encodeByteArray'](Hr(_0x545d65),_0x16b4bf);},'decodeString'(_0x389f4c,_0x5dcff0){return this['HAS_NATIVE_SUPPORT']&&!_0x5dcff0?atob(_0x389f4c):nc(this['decodeStringToByteArray'](_0x389f4c,_0x5dcff0));},'decodeStringToByteArray'(_0x133713,_0x54d3f3){this['init_']();const _0x264d94=_0x54d3f3?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x163536=[];for(let _0x21d773=0x0;_0x21d773<_0x133713['length'];){const _0x5d1678=_0x264d94[_0x133713['charAt'](_0x21d773++)],_0x4994dd=_0x21d773<_0x133713['length']?_0x264d94[_0x133713['charAt'](_0x21d773)]:0x0;++_0x21d773;const _0x7f5a52=_0x21d773<_0x133713['length']?_0x264d94[_0x133713['charAt'](_0x21d773)]:0x40;++_0x21d773;const _0x2005bc=_0x21d773<_0x133713['length']?_0x264d94[_0x133713['charAt'](_0x21d773)]:0x40;if(++_0x21d773,_0x5d1678==null||_0x4994dd==null||_0x7f5a52==null||_0x2005bc==null)throw new ic();const _0x18fcbd=_0x5d1678<<0x2|_0x4994dd>>0x4;if(_0x163536['push'](_0x18fcbd),_0x7f5a52!==0x40){const _0x1016a4=_0x4994dd<<0x4&0xf0|_0x7f5a52>>0x2;if(_0x163536['push'](_0x1016a4),_0x2005bc!==0x40){const _0x4a1f95=_0x7f5a52<<0x6&0xc0|_0x2005bc;_0x163536['push'](_0x4a1f95);}}}return _0x163536;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x3806f3=0x0;_0x3806f3<this['ENCODED_VALS']['length'];_0x3806f3++)this['byteToCharMap_'][_0x3806f3]=this['ENCODED_VALS']['charAt'](_0x3806f3),this['charToByteMap_'][this['byteToCharMap_'][_0x3806f3]]=_0x3806f3,this['byteToCharMapWebSafe_'][_0x3806f3]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x3806f3),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x3806f3]]=_0x3806f3,_0x3806f3>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x3806f3)]=_0x3806f3,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x3806f3)]=_0x3806f3);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0xcad22c){const _0x4dc742=Hr(_0xcad22c);return Fi['encodeByteArray'](_0x4dc742,!0x0);},dn=function(_0x20e271){return $r(_0x20e271)['replace'](/\./g,'');},fn=function(_0x13d562){try{return Fi['decodeString'](_0x13d562,!0x0);}catch(_0x13ca01){console['error']('base64Decode\x20failed:\x20',_0x13ca01);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x37298a){return Gr(void 0x0,_0x37298a);}function Gr(_0x566a5b,_0x202972){if(!(_0x202972 instanceof Object))return _0x202972;switch(_0x202972['constructor']){case Date:const _0x4d86fe=_0x202972;return new Date(_0x4d86fe['getTime']());case Object:_0x566a5b===void 0x0&&(_0x566a5b={});break;case Array:_0x566a5b=[];break;default:return _0x202972;}for(const _0x2a878b in _0x202972)!_0x202972['hasOwnProperty'](_0x2a878b)||!rc(_0x2a878b)||(_0x566a5b[_0x2a878b]=Gr(_0x566a5b[_0x2a878b],_0x202972[_0x2a878b]));return _0x566a5b;}function rc(_0x4e0ca9){return _0x4e0ca9!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x3c0575=Ps['__FIREBASE_DEFAULTS__'];if(_0x3c0575)return JSON['parse'](_0x3c0575);},lc=()=>{if(typeof document>'u')return;let _0x518185;try{_0x518185=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x34fb35=_0x518185&&fn(_0x518185[0x1]);return _0x34fb35&&JSON['parse'](_0x34fb35);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x5747f1){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x5747f1);return;}},qr=_0x3767a1=>{var _0x3b38cf,_0x2a1247;return(_0x2a1247=(_0x3b38cf=Ui())==null?void 0x0:_0x3b38cf['emulatorHosts'])==null?void 0x0:_0x2a1247[_0x3767a1];},hc=_0x50fb4d=>{const _0x485e0c=qr(_0x50fb4d);if(!_0x485e0c)return;const _0x355bbd=_0x485e0c['lastIndexOf'](':');if(_0x355bbd<=0x0||_0x355bbd+0x1===_0x485e0c['length'])throw new Error('Invalid\x20host\x20'+_0x485e0c+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x2dad3a=parseInt(_0x485e0c['substring'](_0x355bbd+0x1),0xa);return _0x485e0c[0x0]==='['?[_0x485e0c['substring'](0x1,_0x355bbd-0x1),_0x2dad3a]:[_0x485e0c['substring'](0x0,_0x355bbd),_0x2dad3a];},zr=()=>{var _0x2f4989;return(_0x2f4989=Ui())==null?void 0x0:_0x2f4989['config'];},jr=_0x4bb956=>{var _0x11dd4b;return(_0x11dd4b=Ui())==null?void 0x0:_0x11dd4b['_'+_0x4bb956];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x3a17cf,_0x239e29)=>{this['resolve']=_0x3a17cf,this['reject']=_0x239e29;});}['wrapCallback'](_0x24d720){return(_0x5564b6,_0x467953)=>{_0x5564b6?this['reject'](_0x5564b6):this['resolve'](_0x467953),typeof _0x24d720=='function'&&(this['promise']['catch'](()=>{}),_0x24d720['length']===0x1?_0x24d720(_0x5564b6):_0x24d720(_0x5564b6,_0x467953));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x4d478e,_0x37df88){if(_0x4d478e['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x5d1de8={'alg':'none','type':'JWT'},_0x300901=_0x37df88||'demo-project',_0xa52f11=_0x4d478e['iat']||0x0,_0x35594b=_0x4d478e['sub']||_0x4d478e['user_id'];if(!_0x35594b)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0xc01b0e={'iss':'https://securetoken.google.com/'+_0x300901,'aud':_0x300901,'iat':_0xa52f11,'exp':_0xa52f11+0xe10,'auth_time':_0xa52f11,'sub':_0x35594b,'user_id':_0x35594b,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x4d478e};return[dn(JSON['stringify'](_0x5d1de8)),dn(JSON['stringify'](_0xc01b0e)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x2fb45c=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x2fb45c=='object'&&_0x2fb45c['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x115261=W();return _0x115261['indexOf']('MSIE\x20')>=0x0||_0x115261['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x5b037f,_0x1de421)=>{try{let _0x360b39=!0x0;const _0x1b8bd2='validate-browser-context-for-indexeddb-analytics-module',_0x146cae=self['indexedDB']['open'](_0x1b8bd2);_0x146cae['onsuccess']=()=>{_0x146cae['result']['close'](),_0x360b39||self['indexedDB']['deleteDatabase'](_0x1b8bd2),_0x5b037f(!0x0);},_0x146cae['onupgradeneeded']=()=>{_0x360b39=!0x1;},_0x146cae['onerror']=()=>{var _0x1fe9b7;_0x1de421(((_0x1fe9b7=_0x146cae['error'])==null?void 0x0:_0x1fe9b7['message'])||'');};}catch(_0x2b3506){_0x1de421(_0x2b3506);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x32a79c,_0x4a7ce8,_0x1df2af){super(_0x4a7ce8),this['code']=_0x32a79c,this['customData']=_0x1df2af,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x18b3ac,_0x305d97,_0xc52262){this['service']=_0x18b3ac,this['serviceName']=_0x305d97,this['errors']=_0xc52262;}['create'](_0x252f02,..._0x2a76eb){const _0x19f1d2=_0x2a76eb[0x0]||{},_0x59153f=this['service']+'/'+_0x252f02,_0x517858=this['errors'][_0x252f02],_0x403967=_0x517858?vc(_0x517858,_0x19f1d2):'Error',_0xa879b8=this['serviceName']+':\x20'+_0x403967+'\x20('+_0x59153f+').';return new Re(_0x59153f,_0xa879b8,_0x19f1d2);}}function vc(_0x5e7815,_0x35fd15){return _0x5e7815['replace'](Ec,(_0x20efff,_0x40eb96)=>{const _0x2a8b82=_0x35fd15[_0x40eb96];return _0x2a8b82!=null?String(_0x2a8b82):'<'+_0x40eb96+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x13d5f3){return JSON['parse'](_0x13d5f3);}function O(_0x1b6a47){return JSON['stringify'](_0x1b6a47);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x5bf831){let _0x20adb1={},_0x220f94={},_0x2f404d={},_0x3012a1='';try{const _0x5405ba=_0x5bf831['split']('.');_0x20adb1=Nt(fn(_0x5405ba[0x0])||''),_0x220f94=Nt(fn(_0x5405ba[0x1])||''),_0x3012a1=_0x5405ba[0x2],_0x2f404d=_0x220f94['d']||{},delete _0x220f94['d'];}catch{}return{'header':_0x20adb1,'claims':_0x220f94,'data':_0x2f404d,'signature':_0x3012a1};},Ic=function(_0x49cc40){const _0x4f0724=Yr(_0x49cc40),_0xce345f=_0x4f0724['claims'];return!!_0xce345f&&typeof _0xce345f=='object'&&_0xce345f['hasOwnProperty']('iat');},wc=function(_0x1745e1){const _0x462342=Yr(_0x1745e1)['claims'];return typeof _0x462342=='object'&&_0x462342['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x544d13,_0x3ff54f){return Object['prototype']['hasOwnProperty']['call'](_0x544d13,_0x3ff54f);}function Le(_0x44e6ef,_0x5b6d2b){if(Object['prototype']['hasOwnProperty']['call'](_0x44e6ef,_0x5b6d2b))return _0x44e6ef[_0x5b6d2b];}function pn(_0x87fcd4){for(const _0x4eead2 in _0x87fcd4)if(Object['prototype']['hasOwnProperty']['call'](_0x87fcd4,_0x4eead2))return!0x1;return!0x0;}function _n(_0x5a0550,_0x300e68,_0x54e4b3){const _0x24a4e7={};for(const _0x112c6d in _0x5a0550)Object['prototype']['hasOwnProperty']['call'](_0x5a0550,_0x112c6d)&&(_0x24a4e7[_0x112c6d]=_0x300e68['call'](_0x54e4b3,_0x5a0550[_0x112c6d],_0x112c6d,_0x5a0550));return _0x24a4e7;}function xe(_0x4521ce,_0x1cd8a9){if(_0x4521ce===_0x1cd8a9)return!0x0;const _0x4d9d6e=Object['keys'](_0x4521ce),_0xd287e9=Object['keys'](_0x1cd8a9);for(const _0x2bf1f0 of _0x4d9d6e){if(!_0xd287e9['includes'](_0x2bf1f0))return!0x1;const _0x4f58fb=_0x4521ce[_0x2bf1f0],_0x253c71=_0x1cd8a9[_0x2bf1f0];if(Ns(_0x4f58fb)&&Ns(_0x253c71)){if(!xe(_0x4f58fb,_0x253c71))return!0x1;}else{if(_0x4f58fb!==_0x253c71)return!0x1;}}for(const _0x254e0f of _0xd287e9)if(!_0x4d9d6e['includes'](_0x254e0f))return!0x1;return!0x0;}function Ns(_0x28fc3f){return _0x28fc3f!==null&&typeof _0x28fc3f=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x3f9ea8){const _0x28b989=[];for(const [_0xaedfbd,_0x1145b0]of Object['entries'](_0x3f9ea8))Array['isArray'](_0x1145b0)?_0x1145b0['forEach'](_0x17b797=>{_0x28b989['push'](encodeURIComponent(_0xaedfbd)+'='+encodeURIComponent(_0x17b797));}):_0x28b989['push'](encodeURIComponent(_0xaedfbd)+'='+encodeURIComponent(_0x1145b0));return _0x28b989['length']?'&'+_0x28b989['join']('&'):'';}function Ct(_0x4f3e75){const _0x295bc3={};return _0x4f3e75['replace'](/^\?/,'')['split']('&')['forEach'](_0x313841=>{if(_0x313841){const [_0x51fb79,_0x21e092]=_0x313841['split']('=');_0x295bc3[decodeURIComponent(_0x51fb79)]=decodeURIComponent(_0x21e092);}}),_0x295bc3;}function Tt(_0x35008b){const _0x16a77a=_0x35008b['indexOf']('?');if(!_0x16a77a)return'';const _0x580c37=_0x35008b['indexOf']('#',_0x16a77a);return _0x35008b['substring'](_0x16a77a,_0x580c37>0x0?_0x580c37:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x441c91=0x1;_0x441c91<this['blockSize'];++_0x441c91)this['pad_'][_0x441c91]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x49efdc,_0x428e94){_0x428e94||(_0x428e94=0x0);const _0x210cf3=this['W_'];if(typeof _0x49efdc=='string'){for(let _0x1bcb4d=0x0;_0x1bcb4d<0x10;_0x1bcb4d++)_0x210cf3[_0x1bcb4d]=_0x49efdc['charCodeAt'](_0x428e94)<<0x18|_0x49efdc['charCodeAt'](_0x428e94+0x1)<<0x10|_0x49efdc['charCodeAt'](_0x428e94+0x2)<<0x8|_0x49efdc['charCodeAt'](_0x428e94+0x3),_0x428e94+=0x4;}else{for(let _0x113d29=0x0;_0x113d29<0x10;_0x113d29++)_0x210cf3[_0x113d29]=_0x49efdc[_0x428e94]<<0x18|_0x49efdc[_0x428e94+0x1]<<0x10|_0x49efdc[_0x428e94+0x2]<<0x8|_0x49efdc[_0x428e94+0x3],_0x428e94+=0x4;}for(let _0x4fb1cf=0x10;_0x4fb1cf<0x50;_0x4fb1cf++){const _0x8eb331=_0x210cf3[_0x4fb1cf-0x3]^_0x210cf3[_0x4fb1cf-0x8]^_0x210cf3[_0x4fb1cf-0xe]^_0x210cf3[_0x4fb1cf-0x10];_0x210cf3[_0x4fb1cf]=(_0x8eb331<<0x1|_0x8eb331>>>0x1f)&0xffffffff;}let _0x1ca8da=this['chain_'][0x0],_0x2f23bc=this['chain_'][0x1],_0x3113e1=this['chain_'][0x2],_0x1af694=this['chain_'][0x3],_0x45c937=this['chain_'][0x4],_0x167527,_0x5056a5;for(let _0x5eb767=0x0;_0x5eb767<0x50;_0x5eb767++){_0x5eb767<0x28?_0x5eb767<0x14?(_0x167527=_0x1af694^_0x2f23bc&(_0x3113e1^_0x1af694),_0x5056a5=0x5a827999):(_0x167527=_0x2f23bc^_0x3113e1^_0x1af694,_0x5056a5=0x6ed9eba1):_0x5eb767<0x3c?(_0x167527=_0x2f23bc&_0x3113e1|_0x1af694&(_0x2f23bc|_0x3113e1),_0x5056a5=0x8f1bbcdc):(_0x167527=_0x2f23bc^_0x3113e1^_0x1af694,_0x5056a5=0xca62c1d6);const _0x2f89b3=(_0x1ca8da<<0x5|_0x1ca8da>>>0x1b)+_0x167527+_0x45c937+_0x5056a5+_0x210cf3[_0x5eb767]&0xffffffff;_0x45c937=_0x1af694,_0x1af694=_0x3113e1,_0x3113e1=(_0x2f23bc<<0x1e|_0x2f23bc>>>0x2)&0xffffffff,_0x2f23bc=_0x1ca8da,_0x1ca8da=_0x2f89b3;}this['chain_'][0x0]=this['chain_'][0x0]+_0x1ca8da&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x2f23bc&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x3113e1&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x1af694&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x45c937&0xffffffff;}['update'](_0x19c724,_0x3283db){if(_0x19c724==null)return;_0x3283db===void 0x0&&(_0x3283db=_0x19c724['length']);const _0x1d3cbf=_0x3283db-this['blockSize'];let _0x2b7a2f=0x0;const _0x42b451=this['buf_'];let _0x2f7de0=this['inbuf_'];for(;_0x2b7a2f<_0x3283db;){if(_0x2f7de0===0x0){for(;_0x2b7a2f<=_0x1d3cbf;)this['compress_'](_0x19c724,_0x2b7a2f),_0x2b7a2f+=this['blockSize'];}if(typeof _0x19c724=='string'){for(;_0x2b7a2f<_0x3283db;)if(_0x42b451[_0x2f7de0]=_0x19c724['charCodeAt'](_0x2b7a2f),++_0x2f7de0,++_0x2b7a2f,_0x2f7de0===this['blockSize']){this['compress_'](_0x42b451),_0x2f7de0=0x0;break;}}else{for(;_0x2b7a2f<_0x3283db;)if(_0x42b451[_0x2f7de0]=_0x19c724[_0x2b7a2f],++_0x2f7de0,++_0x2b7a2f,_0x2f7de0===this['blockSize']){this['compress_'](_0x42b451),_0x2f7de0=0x0;break;}}}this['inbuf_']=_0x2f7de0,this['total_']+=_0x3283db;}['digest'](){const _0x1dfe13=[];let _0x3a0918=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x562bb2=this['blockSize']-0x1;_0x562bb2>=0x38;_0x562bb2--)this['buf_'][_0x562bb2]=_0x3a0918&0xff,_0x3a0918/=0x100;this['compress_'](this['buf_']);let _0xcda7e1=0x0;for(let _0x37dd34=0x0;_0x37dd34<0x5;_0x37dd34++)for(let _0xcbd9ef=0x18;_0xcbd9ef>=0x0;_0xcbd9ef-=0x8)_0x1dfe13[_0xcda7e1]=this['chain_'][_0x37dd34]>>_0xcbd9ef&0xff,++_0xcda7e1;return _0x1dfe13;}}function Tc(_0x5934d7,_0x419ee8){const _0x423c13=new Sc(_0x5934d7,_0x419ee8);return _0x423c13['subscribe']['bind'](_0x423c13);}class Sc{constructor(_0x1fc373,_0x7f7bc5){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x7f7bc5,this['task']['then'](()=>{_0x1fc373(this);})['catch'](_0x528407=>{this['error'](_0x528407);});}['next'](_0x4e7bed){this['forEachObserver'](_0x1c9d3f=>{_0x1c9d3f['next'](_0x4e7bed);});}['error'](_0x2a3006){this['forEachObserver'](_0x2bf038=>{_0x2bf038['error'](_0x2a3006);}),this['close'](_0x2a3006);}['complete'](){this['forEachObserver'](_0x250b72=>{_0x250b72['complete']();}),this['close']();}['subscribe'](_0x345822,_0x44b1d2,_0x3e08e3){let _0x28cb71;if(_0x345822===void 0x0&&_0x44b1d2===void 0x0&&_0x3e08e3===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x345822,['next','error','complete'])?_0x28cb71=_0x345822:_0x28cb71={'next':_0x345822,'error':_0x44b1d2,'complete':_0x3e08e3},_0x28cb71['next']===void 0x0&&(_0x28cb71['next']=ti),_0x28cb71['error']===void 0x0&&(_0x28cb71['error']=ti),_0x28cb71['complete']===void 0x0&&(_0x28cb71['complete']=ti);const _0xbaafbc=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x28cb71['error'](this['finalError']):_0x28cb71['complete']();}catch{}}),this['observers']['push'](_0x28cb71),_0xbaafbc;}['unsubscribeOne'](_0x1e907e){this['observers']===void 0x0||this['observers'][_0x1e907e]===void 0x0||(delete this['observers'][_0x1e907e],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x2cdedd){if(!this['finalized']){for(let _0x3c4a7b=0x0;_0x3c4a7b<this['observers']['length'];_0x3c4a7b++)this['sendOne'](_0x3c4a7b,_0x2cdedd);}}['sendOne'](_0x3feaeb,_0x3760c7){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x3feaeb]!==void 0x0)try{_0x3760c7(this['observers'][_0x3feaeb]);}catch(_0x58412e){typeof console<'u'&&console['error']&&console['error'](_0x58412e);}});}['close'](_0xa2bb9a){this['finalized']||(this['finalized']=!0x0,_0xa2bb9a!==void 0x0&&(this['finalError']=_0xa2bb9a),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x5d427a,_0x3b9474){if(typeof _0x5d427a!='object'||_0x5d427a===null)return!0x1;for(const _0x2799b2 of _0x3b9474)if(_0x2799b2 in _0x5d427a&&typeof _0x5d427a[_0x2799b2]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x40ef8e,_0x4f3db3){return _0x40ef8e+'\x20failed:\x20'+_0x4f3db3+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x2e1bb3){const _0x4fd8d9=[];let _0x296d13=0x0;for(let _0x28ee32=0x0;_0x28ee32<_0x2e1bb3['length'];_0x28ee32++){let _0x4d56ab=_0x2e1bb3['charCodeAt'](_0x28ee32);if(_0x4d56ab>=0xd800&&_0x4d56ab<=0xdbff){const _0x25d4d6=_0x4d56ab-0xd800;_0x28ee32++,f(_0x28ee32<_0x2e1bb3['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x1f0bd9=_0x2e1bb3['charCodeAt'](_0x28ee32)-0xdc00;_0x4d56ab=0x10000+(_0x25d4d6<<0xa)+_0x1f0bd9;}_0x4d56ab<0x80?_0x4fd8d9[_0x296d13++]=_0x4d56ab:_0x4d56ab<0x800?(_0x4fd8d9[_0x296d13++]=_0x4d56ab>>0x6|0xc0,_0x4fd8d9[_0x296d13++]=_0x4d56ab&0x3f|0x80):_0x4d56ab<0x10000?(_0x4fd8d9[_0x296d13++]=_0x4d56ab>>0xc|0xe0,_0x4fd8d9[_0x296d13++]=_0x4d56ab>>0x6&0x3f|0x80,_0x4fd8d9[_0x296d13++]=_0x4d56ab&0x3f|0x80):(_0x4fd8d9[_0x296d13++]=_0x4d56ab>>0x12|0xf0,_0x4fd8d9[_0x296d13++]=_0x4d56ab>>0xc&0x3f|0x80,_0x4fd8d9[_0x296d13++]=_0x4d56ab>>0x6&0x3f|0x80,_0x4fd8d9[_0x296d13++]=_0x4d56ab&0x3f|0x80);}return _0x4fd8d9;},Ln=function(_0x19f91b){let _0x3be3eb=0x0;for(let _0x32eac0=0x0;_0x32eac0<_0x19f91b['length'];_0x32eac0++){const _0x4751c0=_0x19f91b['charCodeAt'](_0x32eac0);_0x4751c0<0x80?_0x3be3eb++:_0x4751c0<0x800?_0x3be3eb+=0x2:_0x4751c0>=0xd800&&_0x4751c0<=0xdbff?(_0x3be3eb+=0x4,_0x32eac0++):_0x3be3eb+=0x3;}return _0x3be3eb;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x51e156){return _0x51e156&&_0x51e156['_delegate']?_0x51e156['_delegate']:_0x51e156;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x3611a9){try{return(_0x3611a9['startsWith']('http://')||_0x3611a9['startsWith']('https://')?new URL(_0x3611a9)['hostname']:_0x3611a9)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x5f59ee){return(await fetch(_0x5f59ee,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x1810fb,_0x28d93c,_0x48b047){this['name']=_0x1810fb,this['instanceFactory']=_0x28d93c,this['type']=_0x48b047,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x4bd84a){return this['instantiationMode']=_0x4bd84a,this;}['setMultipleInstances'](_0x3d103a){return this['multipleInstances']=_0x3d103a,this;}['setServiceProps'](_0x57f676){return this['serviceProps']=_0x57f676,this;}['setInstanceCreatedCallback'](_0x18d073){return this['onInstanceCreated']=_0x18d073,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x2f9cd6,_0x148092){this['name']=_0x2f9cd6,this['container']=_0x148092,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x147d82){const _0xb29bf8=this['normalizeInstanceIdentifier'](_0x147d82);if(!this['instancesDeferred']['has'](_0xb29bf8)){const _0x4fcb2f=new H();if(this['instancesDeferred']['set'](_0xb29bf8,_0x4fcb2f),this['isInitialized'](_0xb29bf8)||this['shouldAutoInitialize']())try{const _0x416b77=this['getOrInitializeService']({'instanceIdentifier':_0xb29bf8});_0x416b77&&_0x4fcb2f['resolve'](_0x416b77);}catch{}}return this['instancesDeferred']['get'](_0xb29bf8)['promise'];}['getImmediate'](_0x88c119){const _0x5c2951=this['normalizeInstanceIdentifier'](_0x88c119==null?void 0x0:_0x88c119['identifier']),_0x44147e=(_0x88c119==null?void 0x0:_0x88c119['optional'])??!0x1;if(this['isInitialized'](_0x5c2951)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x5c2951});}catch(_0x6abb5){if(_0x44147e)return null;throw _0x6abb5;}else{if(_0x44147e)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x39e5b3){if(_0x39e5b3['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x39e5b3['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x39e5b3,!!this['shouldAutoInitialize']()){if(Pc(_0x39e5b3))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x480e4c,_0x4969ff]of this['instancesDeferred']['entries']()){const _0x47eba4=this['normalizeInstanceIdentifier'](_0x480e4c);try{const _0x3f69cc=this['getOrInitializeService']({'instanceIdentifier':_0x47eba4});_0x4969ff['resolve'](_0x3f69cc);}catch{}}}}['clearInstance'](_0x3f3a39=Ne){this['instancesDeferred']['delete'](_0x3f3a39),this['instancesOptions']['delete'](_0x3f3a39),this['instances']['delete'](_0x3f3a39);}async['delete'](){const _0x1d3857=Array['from'](this['instances']['values']());await Promise['all']([..._0x1d3857['filter'](_0x5c25b6=>'INTERNAL'in _0x5c25b6)['map'](_0x564b50=>_0x564b50['INTERNAL']['delete']()),..._0x1d3857['filter'](_0x48f729=>'_delete'in _0x48f729)['map'](_0x210af0=>_0x210af0['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x19ca46=Ne){return this['instances']['has'](_0x19ca46);}['getOptions'](_0x56aa18=Ne){return this['instancesOptions']['get'](_0x56aa18)||{};}['initialize'](_0x3f5564={}){const {options:_0x21d612={}}=_0x3f5564,_0x4cddd0=this['normalizeInstanceIdentifier'](_0x3f5564['instanceIdentifier']);if(this['isInitialized'](_0x4cddd0))throw Error(this['name']+'('+_0x4cddd0+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x1edef9=this['getOrInitializeService']({'instanceIdentifier':_0x4cddd0,'options':_0x21d612});for(const [_0x3325ca,_0x26cff0]of this['instancesDeferred']['entries']()){const _0x22b036=this['normalizeInstanceIdentifier'](_0x3325ca);_0x4cddd0===_0x22b036&&_0x26cff0['resolve'](_0x1edef9);}return _0x1edef9;}['onInit'](_0x4cbac7,_0x173044){const _0x2c759a=this['normalizeInstanceIdentifier'](_0x173044),_0x5d5ca4=this['onInitCallbacks']['get'](_0x2c759a)??new Set();_0x5d5ca4['add'](_0x4cbac7),this['onInitCallbacks']['set'](_0x2c759a,_0x5d5ca4);const _0x3e9f60=this['instances']['get'](_0x2c759a);return _0x3e9f60&&_0x4cbac7(_0x3e9f60,_0x2c759a),()=>{_0x5d5ca4['delete'](_0x4cbac7);};}['invokeOnInitCallbacks'](_0x4df61c,_0x147d07){const _0x2cce16=this['onInitCallbacks']['get'](_0x147d07);if(_0x2cce16){for(const _0x1ba585 of _0x2cce16)try{_0x1ba585(_0x4df61c,_0x147d07);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x1e55b1,options:_0x4bf1ba={}}){let _0x24960a=this['instances']['get'](_0x1e55b1);if(!_0x24960a&&this['component']&&(_0x24960a=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x1e55b1),'options':_0x4bf1ba}),this['instances']['set'](_0x1e55b1,_0x24960a),this['instancesOptions']['set'](_0x1e55b1,_0x4bf1ba),this['invokeOnInitCallbacks'](_0x24960a,_0x1e55b1),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x1e55b1,_0x24960a);}catch{}return _0x24960a||null;}['normalizeInstanceIdentifier'](_0x2dd1a3=Ne){return this['component']?this['component']['multipleInstances']?_0x2dd1a3:Ne:_0x2dd1a3;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x5060e7){return _0x5060e7===Ne?void 0x0:_0x5060e7;}function Pc(_0x4e13ab){return _0x4e13ab['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x8a1ab5){this['name']=_0x8a1ab5,this['providers']=new Map();}['addComponent'](_0x1fa79b){const _0x488faf=this['getProvider'](_0x1fa79b['name']);if(_0x488faf['isComponentSet']())throw new Error('Component\x20'+_0x1fa79b['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x488faf['setComponent'](_0x1fa79b);}['addOrOverwriteComponent'](_0x49cd04){this['getProvider'](_0x49cd04['name'])['isComponentSet']()&&this['providers']['delete'](_0x49cd04['name']),this['addComponent'](_0x49cd04);}['getProvider'](_0x5b79e3){if(this['providers']['has'](_0x5b79e3))return this['providers']['get'](_0x5b79e3);const _0x2de49b=new Ac(_0x5b79e3,this);return this['providers']['set'](_0x5b79e3,_0x2de49b),_0x2de49b;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x1519bf){_0x1519bf[_0x1519bf['DEBUG']=0x0]='DEBUG',_0x1519bf[_0x1519bf['VERBOSE']=0x1]='VERBOSE',_0x1519bf[_0x1519bf['INFO']=0x2]='INFO',_0x1519bf[_0x1519bf['WARN']=0x3]='WARN',_0x1519bf[_0x1519bf['ERROR']=0x4]='ERROR',_0x1519bf[_0x1519bf['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x500399,_0x1fc78c,..._0xec8f7a)=>{if(_0x1fc78c<_0x500399['logLevel'])return;const _0x3fd842=new Date()['toISOString'](),_0x514ff4=Mc[_0x1fc78c];if(_0x514ff4)console[_0x514ff4]('['+_0x3fd842+']\x20\x20'+_0x500399['name']+':',..._0xec8f7a);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x1fc78c+')');};class Bi{constructor(_0x2ffedb){this['name']=_0x2ffedb,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x982eb2){if(!(_0x982eb2 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x982eb2+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x982eb2;}['setLogLevel'](_0x3901df){this['_logLevel']=typeof _0x3901df=='string'?Oc[_0x3901df]:_0x3901df;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x26e326){if(typeof _0x26e326!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x26e326;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x4755d8){this['_userLogHandler']=_0x4755d8;}['debug'](..._0x29c28d){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x29c28d),this['_logHandler'](this,T['DEBUG'],..._0x29c28d);}['log'](..._0x56ace6){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x56ace6),this['_logHandler'](this,T['VERBOSE'],..._0x56ace6);}['info'](..._0x40a81d){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x40a81d),this['_logHandler'](this,T['INFO'],..._0x40a81d);}['warn'](..._0x4062b4){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x4062b4),this['_logHandler'](this,T['WARN'],..._0x4062b4);}['error'](..._0x42f085){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x42f085),this['_logHandler'](this,T['ERROR'],..._0x42f085);}}const xc=(_0x526a40,_0xf4e101)=>_0xf4e101['some'](_0x2a70cd=>_0x526a40 instanceof _0x2a70cd);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x1f9dd5){const _0x2b0889=new Promise((_0x143d62,_0x1f3193)=>{const _0x525830=()=>{_0x1f9dd5['removeEventListener']('success',_0x12abd2),_0x1f9dd5['removeEventListener']('error',_0x56a655);},_0x12abd2=()=>{_0x143d62(ge(_0x1f9dd5['result'])),_0x525830();},_0x56a655=()=>{_0x1f3193(_0x1f9dd5['error']),_0x525830();};_0x1f9dd5['addEventListener']('success',_0x12abd2),_0x1f9dd5['addEventListener']('error',_0x56a655);});return _0x2b0889['then'](_0x2352bd=>{_0x2352bd instanceof IDBCursor&&Jr['set'](_0x2352bd,_0x1f9dd5);})['catch'](()=>{}),Vi['set'](_0x2b0889,_0x1f9dd5),_0x2b0889;}function Bc(_0x456a95){if(_i['has'](_0x456a95))return;const _0x1087dc=new Promise((_0x272dfb,_0x45ad7f)=>{const _0xfbd4b6=()=>{_0x456a95['removeEventListener']('complete',_0x2f0b44),_0x456a95['removeEventListener']('error',_0x44a7c2),_0x456a95['removeEventListener']('abort',_0x44a7c2);},_0x2f0b44=()=>{_0x272dfb(),_0xfbd4b6();},_0x44a7c2=()=>{_0x45ad7f(_0x456a95['error']||new DOMException('AbortError','AbortError')),_0xfbd4b6();};_0x456a95['addEventListener']('complete',_0x2f0b44),_0x456a95['addEventListener']('error',_0x44a7c2),_0x456a95['addEventListener']('abort',_0x44a7c2);});_i['set'](_0x456a95,_0x1087dc);}let gi={'get'(_0x44eced,_0x417151,_0x39732b){if(_0x44eced instanceof IDBTransaction){if(_0x417151==='done')return _i['get'](_0x44eced);if(_0x417151==='objectStoreNames')return _0x44eced['objectStoreNames']||Xr['get'](_0x44eced);if(_0x417151==='store')return _0x39732b['objectStoreNames'][0x1]?void 0x0:_0x39732b['objectStore'](_0x39732b['objectStoreNames'][0x0]);}return ge(_0x44eced[_0x417151]);},'set'(_0x407ddc,_0x52c33a,_0x3686c3){return _0x407ddc[_0x52c33a]=_0x3686c3,!0x0;},'has'(_0x623242,_0x15cb39){return _0x623242 instanceof IDBTransaction&&(_0x15cb39==='done'||_0x15cb39==='store')?!0x0:_0x15cb39 in _0x623242;}};function Vc(_0xa188bf){gi=_0xa188bf(gi);}function Hc(_0x2c0930){return _0x2c0930===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x8936be,..._0x14bb3c){const _0x34c5dc=_0x2c0930['call'](ii(this),_0x8936be,..._0x14bb3c);return Xr['set'](_0x34c5dc,_0x8936be['sort']?_0x8936be['sort']():[_0x8936be]),ge(_0x34c5dc);}:Uc()['includes'](_0x2c0930)?function(..._0x3dbcec){return _0x2c0930['apply'](ii(this),_0x3dbcec),ge(Jr['get'](this));}:function(..._0x15a93a){return ge(_0x2c0930['apply'](ii(this),_0x15a93a));};}function $c(_0x3908d4){return typeof _0x3908d4=='function'?Hc(_0x3908d4):(_0x3908d4 instanceof IDBTransaction&&Bc(_0x3908d4),xc(_0x3908d4,Fc())?new Proxy(_0x3908d4,gi):_0x3908d4);}function ge(_0x4fa347){if(_0x4fa347 instanceof IDBRequest)return Wc(_0x4fa347);if(ni['has'](_0x4fa347))return ni['get'](_0x4fa347);const _0x5ee234=$c(_0x4fa347);return _0x5ee234!==_0x4fa347&&(ni['set'](_0x4fa347,_0x5ee234),Vi['set'](_0x5ee234,_0x4fa347)),_0x5ee234;}const ii=_0x24f588=>Vi['get'](_0x24f588);function Gc(_0x2d5c4e,_0x42ea3c,{blocked:_0x11c41d,upgrade:_0x573003,blocking:_0x587907,terminated:_0x1cac19}={}){const _0x550bab=indexedDB['open'](_0x2d5c4e,_0x42ea3c),_0x2905e3=ge(_0x550bab);return _0x573003&&_0x550bab['addEventListener']('upgradeneeded',_0x549cd3=>{_0x573003(ge(_0x550bab['result']),_0x549cd3['oldVersion'],_0x549cd3['newVersion'],ge(_0x550bab['transaction']),_0x549cd3);}),_0x11c41d&&_0x550bab['addEventListener']('blocked',_0x582906=>_0x11c41d(_0x582906['oldVersion'],_0x582906['newVersion'],_0x582906)),_0x2905e3['then'](_0x4d905f=>{_0x1cac19&&_0x4d905f['addEventListener']('close',()=>_0x1cac19()),_0x587907&&_0x4d905f['addEventListener']('versionchange',_0x38d10e=>_0x587907(_0x38d10e['oldVersion'],_0x38d10e['newVersion'],_0x38d10e));})['catch'](()=>{}),_0x2905e3;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x12c4ca,_0x28434b){if(!(_0x12c4ca instanceof IDBDatabase&&!(_0x28434b in _0x12c4ca)&&typeof _0x28434b=='string'))return;if(si['get'](_0x28434b))return si['get'](_0x28434b);const _0x85d574=_0x28434b['replace'](/FromIndex$/,''),_0x5a72b1=_0x28434b!==_0x85d574,_0x5ad056=zc['includes'](_0x85d574);if(!(_0x85d574 in(_0x5a72b1?IDBIndex:IDBObjectStore)['prototype'])||!(_0x5ad056||qc['includes'](_0x85d574)))return;const _0x4bedec=async function(_0x133358,..._0x561f49){const _0x5cc22d=this['transaction'](_0x133358,_0x5ad056?'readwrite':'readonly');let _0x17c3f4=_0x5cc22d['store'];return _0x5a72b1&&(_0x17c3f4=_0x17c3f4['index'](_0x561f49['shift']())),(await Promise['all']([_0x17c3f4[_0x85d574](..._0x561f49),_0x5ad056&&_0x5cc22d['done']]))[0x0];};return si['set'](_0x28434b,_0x4bedec),_0x4bedec;}Vc(_0x51a082=>({..._0x51a082,'get':(_0x37aee3,_0x58a17a,_0x37e747)=>Ms(_0x37aee3,_0x58a17a)||_0x51a082['get'](_0x37aee3,_0x58a17a,_0x37e747),'has':(_0x47d3e1,_0x1ec963)=>!!Ms(_0x47d3e1,_0x1ec963)||_0x51a082['has'](_0x47d3e1,_0x1ec963)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x48f8c1){this['container']=_0x48f8c1;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x3cc364=>{if(Kc(_0x3cc364)){const _0x103989=_0x3cc364['getImmediate']();return _0x103989['library']+'/'+_0x103989['version'];}else return null;})['filter'](_0xeb0768=>_0xeb0768)['join']('\x20');}}function Kc(_0x582e3c){const _0x27dc36=_0x582e3c['getComponent']();return(_0x27dc36==null?void 0x0:_0x27dc36['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x4da7c0,_0x39bbc5){try{_0x4da7c0['container']['addComponent'](_0x39bbc5);}catch(_0x4ba746){oe['debug']('Component\x20'+_0x39bbc5['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x4da7c0['name'],_0x4ba746);}}function st(_0x1716eb){const _0x1769c2=_0x1716eb['name'];if(Ei['has'](_0x1769c2))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x1769c2+'.'),!0x1;Ei['set'](_0x1769c2,_0x1716eb);for(const _0x1cba77 of Ue['values']())xs(_0x1cba77,_0x1716eb);for(const _0x5653e3 of vi['values']())xs(_0x5653e3,_0x1716eb);return!0x0;}function Hi(_0x5c9a99,_0x4a3970){const _0x15e1ff=_0x5c9a99['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x15e1ff&&_0x15e1ff['triggerHeartbeat'](),_0x5c9a99['container']['getProvider'](_0x4a3970);}function $(_0x171d50){return _0x171d50==null?!0x1:_0x171d50['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x519610,_0x467d6d,_0x1bf286){this['_isDeleted']=!0x1,this['_options']={..._0x519610},this['_config']={..._0x467d6d},this['_name']=_0x467d6d['name'],this['_automaticDataCollectionEnabled']=_0x467d6d['automaticDataCollectionEnabled'],this['_container']=_0x1bf286,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x392aff){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x392aff;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x38e4f0){this['_isDeleted']=_0x38e4f0;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x499966,_0x43cca1={}){let _0x1b7c17=_0x499966;typeof _0x43cca1!='object'&&(_0x43cca1={'name':_0x43cca1});const _0x329335={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x43cca1},_0x171b08=_0x329335['name'];if(typeof _0x171b08!='string'||!_0x171b08)throw me['create']('bad-app-name',{'appName':String(_0x171b08)});if(_0x1b7c17||(_0x1b7c17=zr()),!_0x1b7c17)throw me['create']('no-options');const _0x1d9325=Ue['get'](_0x171b08);if(_0x1d9325){if(xe(_0x1b7c17,_0x1d9325['options'])&&xe(_0x329335,_0x1d9325['config']))return _0x1d9325;throw me['create']('duplicate-app',{'appName':_0x171b08});}const _0xa71bf=new Nc(_0x171b08);for(const _0x1ae052 of Ei['values']())_0xa71bf['addComponent'](_0x1ae052);const _0x4ba6df=new Tl(_0x1b7c17,_0x329335,_0xa71bf);return Ue['set'](_0x171b08,_0x4ba6df),_0x4ba6df;}function Zr(_0x95e00=yi){const _0x4d2e47=Ue['get'](_0x95e00);if(!_0x4d2e47&&_0x95e00===yi&&zr())return Sl();if(!_0x4d2e47)throw me['create']('no-app',{'appName':_0x95e00});return _0x4d2e47;}function g_(){return Array['from'](Ue['values']());}async function m_(_0xdc3e8a){let _0x187391=!0x1;const _0x294bda=_0xdc3e8a['name'];Ue['has'](_0x294bda)?(_0x187391=!0x0,Ue['delete'](_0x294bda)):vi['has'](_0x294bda)&&_0xdc3e8a['decRefCount']()<=0x0&&(vi['delete'](_0x294bda),_0x187391=!0x0),_0x187391&&(await Promise['all'](_0xdc3e8a['container']['getProviders']()['map'](_0x3ce22d=>_0x3ce22d['delete']())),_0xdc3e8a['isDeleted']=!0x0);}function ye(_0x4929e7,_0x2c4254,_0x203f7a){let _0x20b45d=wl[_0x4929e7]??_0x4929e7;_0x203f7a&&(_0x20b45d+='-'+_0x203f7a);const _0x5e0599=_0x20b45d['match'](/\s|\//),_0x20941b=_0x2c4254['match'](/\s|\//);if(_0x5e0599||_0x20941b){const _0x4670aa=['Unable\x20to\x20register\x20library\x20\x22'+_0x20b45d+'\x22\x20with\x20version\x20\x22'+_0x2c4254+'\x22:'];_0x5e0599&&_0x4670aa['push']('library\x20name\x20\x22'+_0x20b45d+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x5e0599&&_0x20941b&&_0x4670aa['push']('and'),_0x20941b&&_0x4670aa['push']('version\x20name\x20\x22'+_0x2c4254+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x4670aa['join']('\x20'));return;}st(new Fe(_0x20b45d+'-version',()=>({'library':_0x20b45d,'version':_0x2c4254}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x8e9a69,_0x2160b2)=>{switch(_0x2160b2){case 0x0:try{_0x8e9a69['createObjectStore'](Ot);}catch(_0x4441d0){console['warn'](_0x4441d0);}}}})['catch'](_0x1d2e2f=>{throw me['create']('idb-open',{'originalErrorMessage':_0x1d2e2f['message']});})),ri;}async function Al(_0x26d294){try{const _0x200fec=(await eo())['transaction'](Ot),_0x1f9fd9=await _0x200fec['objectStore'](Ot)['get'](to(_0x26d294));return await _0x200fec['done'],_0x1f9fd9;}catch(_0x3b820d){if(_0x3b820d instanceof Re)oe['warn'](_0x3b820d['message']);else{const _0x1e5085=me['create']('idb-get',{'originalErrorMessage':_0x3b820d==null?void 0x0:_0x3b820d['message']});oe['warn'](_0x1e5085['message']);}}}async function Fs(_0x2b085c,_0x58fb5e){try{const _0x156254=(await eo())['transaction'](Ot,'readwrite');await _0x156254['objectStore'](Ot)['put'](_0x58fb5e,to(_0x2b085c)),await _0x156254['done'];}catch(_0x2de168){if(_0x2de168 instanceof Re)oe['warn'](_0x2de168['message']);else{const _0x1dc30a=me['create']('idb-set',{'originalErrorMessage':_0x2de168==null?void 0x0:_0x2de168['message']});oe['warn'](_0x1dc30a['message']);}}}function to(_0x21d756){return _0x21d756['name']+'!'+_0x21d756['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0xe2672c){this['container']=_0xe2672c,this['_heartbeatsCache']=null;const _0xe68d63=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0xe68d63),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x4276aa=>(this['_heartbeatsCache']=_0x4276aa,_0x4276aa));}async['triggerHeartbeat'](){var _0x2a3322,_0x229e78;try{const _0x5c542f=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x57fbc3=Us();if(((_0x2a3322=this['_heartbeatsCache'])==null?void 0x0:_0x2a3322['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x229e78=this['_heartbeatsCache'])==null?void 0x0:_0x229e78['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x57fbc3||this['_heartbeatsCache']['heartbeats']['some'](_0x3e238c=>_0x3e238c['date']===_0x57fbc3))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x57fbc3,'agent':_0x5c542f}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x2d3d47=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x2d3d47,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x30e186){oe['warn'](_0x30e186);}}async['getHeartbeatsHeader'](){var _0x348ee0;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x348ee0=this['_heartbeatsCache'])==null?void 0x0:_0x348ee0['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x4c43ea=Us(),{heartbeatsToSend:_0x24c359,unsentEntries:_0x33cb5d}=Ol(this['_heartbeatsCache']['heartbeats']),_0x7c075c=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x24c359}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x4c43ea,_0x33cb5d['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x33cb5d,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x7c075c;}catch(_0x404c0c){return oe['warn'](_0x404c0c),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x3c77aa,_0x381bf3=kl){const _0x5ef67c=[];let _0x365f22=_0x3c77aa['slice']();for(const _0x1006f5 of _0x3c77aa){const _0x549829=_0x5ef67c['find'](_0x42ea1f=>_0x42ea1f['agent']===_0x1006f5['agent']);if(_0x549829){if(_0x549829['dates']['push'](_0x1006f5['date']),Ws(_0x5ef67c)>_0x381bf3){_0x549829['dates']['pop']();break;}}else{if(_0x5ef67c['push']({'agent':_0x1006f5['agent'],'dates':[_0x1006f5['date']]}),Ws(_0x5ef67c)>_0x381bf3){_0x5ef67c['pop']();break;}}_0x365f22=_0x365f22['slice'](0x1);}return{'heartbeatsToSend':_0x5ef67c,'unsentEntries':_0x365f22};}class Dl{constructor(_0x410506){this['app']=_0x410506,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x2aae95=await Al(this['app']);return _0x2aae95!=null&&_0x2aae95['heartbeats']?_0x2aae95:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x35053c){if(await this['_canUseIndexedDBPromise']){const _0x1ac468=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x35053c['lastSentHeartbeatDate']??_0x1ac468['lastSentHeartbeatDate'],'heartbeats':_0x35053c['heartbeats']});}else return;}async['add'](_0x41c395){if(await this['_canUseIndexedDBPromise']){const _0x4ce3a7=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x41c395['lastSentHeartbeatDate']??_0x4ce3a7['lastSentHeartbeatDate'],'heartbeats':[..._0x4ce3a7['heartbeats'],..._0x41c395['heartbeats']]});}else return;}}function Ws(_0x5000e4){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x5000e4}))['length'];}function Ml(_0x3bfc28){if(_0x3bfc28['length']===0x0)return-0x1;let _0x56a755=0x0,_0x33913a=_0x3bfc28[0x0]['date'];for(let _0x4a4e9c=0x1;_0x4a4e9c<_0x3bfc28['length'];_0x4a4e9c++)_0x3bfc28[_0x4a4e9c]['date']<_0x33913a&&(_0x33913a=_0x3bfc28[_0x4a4e9c]['date'],_0x56a755=_0x4a4e9c);return _0x56a755;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x52379d){st(new Fe('platform-logger',_0x4bba40=>new jc(_0x4bba40),'PRIVATE')),st(new Fe('heartbeat',_0x315735=>new Nl(_0x315735),'PRIVATE')),ye(mi,Ls,_0x52379d),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x42af00){no=_0x42af00;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x236f8b){this['domStorage_']=_0x236f8b,this['prefix_']='firebase:';}['set'](_0x37e757,_0x15fba2){_0x15fba2==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x37e757)):this['domStorage_']['setItem'](this['prefixedName_'](_0x37e757),O(_0x15fba2));}['get'](_0x34135d){const _0x4178fd=this['domStorage_']['getItem'](this['prefixedName_'](_0x34135d));return _0x4178fd==null?null:Nt(_0x4178fd);}['remove'](_0x4335b7){this['domStorage_']['removeItem'](this['prefixedName_'](_0x4335b7));}['prefixedName_'](_0xe8fba5){return this['prefix_']+_0xe8fba5;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0xf7ad29,_0x5bbbb2){_0x5bbbb2==null?delete this['cache_'][_0xf7ad29]:this['cache_'][_0xf7ad29]=_0x5bbbb2;}['get'](_0x57a64d){return Q(this['cache_'],_0x57a64d)?this['cache_'][_0x57a64d]:null;}['remove'](_0x403447){delete this['cache_'][_0x403447];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x4521dc){try{if(typeof window<'u'&&typeof window[_0x4521dc]<'u'){const _0x4ec724=window[_0x4521dc];return _0x4ec724['setItem']('firebase:sentinel','cache'),_0x4ec724['removeItem']('firebase:sentinel'),new Wl(_0x4ec724);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x7010b3=0x1;return function(){return _0x7010b3++;};}()),ro=function(_0x138a8f){const _0x542a7f=Rc(_0x138a8f),_0x5d0163=new Cc();_0x5d0163['update'](_0x542a7f);const _0x1962b1=_0x5d0163['digest']();return Fi['encodeByteArray'](_0x1962b1);},zt=function(..._0x1699f3){let _0x200d23='';for(let _0x1b029e=0x0;_0x1b029e<_0x1699f3['length'];_0x1b029e++){const _0xc26f3c=_0x1699f3[_0x1b029e];Array['isArray'](_0xc26f3c)||_0xc26f3c&&typeof _0xc26f3c=='object'&&typeof _0xc26f3c['length']=='number'?_0x200d23+=zt['apply'](null,_0xc26f3c):typeof _0xc26f3c=='object'?_0x200d23+=O(_0xc26f3c):_0x200d23+=_0xc26f3c,_0x200d23+='\x20';}return _0x200d23;};let St=null,$s=!0x0;const Hl=function(_0x37d8f7,_0x4c28af){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x4e102e){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x1b1e7b=zt['apply'](null,_0x4e102e);St(_0x1b1e7b);}},jt=function(_0x163293){return function(..._0x1e0944){L(_0x163293,..._0x1e0944);};},Ii=function(..._0x334f10){const _0x45b4d5='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x334f10);Ze['error'](_0x45b4d5);},ae=function(..._0x5ccd99){const _0x2c37c1='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x5ccd99);throw Ze['error'](_0x2c37c1),new Error(_0x2c37c1);},U=function(..._0xd5a198){const _0x2cfaec='FIREBASE\x20WARNING:\x20'+zt(..._0xd5a198);Ze['warn'](_0x2cfaec);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x497448){return typeof _0x497448=='number'&&(_0x497448!==_0x497448||_0x497448===Number['POSITIVE_INFINITY']||_0x497448===Number['NEGATIVE_INFINITY']);},Gl=function(_0x33c7c4){if(document['readyState']==='complete')_0x33c7c4();else{let _0x10c2e4=!0x1;const _0x46de9d=function(){if(!document['body']){setTimeout(_0x46de9d,Math['floor'](0xa));return;}_0x10c2e4||(_0x10c2e4=!0x0,_0x33c7c4());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x46de9d,!0x1),window['addEventListener']('load',_0x46de9d,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x46de9d();}),window['attachEvent']('onload',_0x46de9d));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x214ab0,_0x2ab7ec){if(_0x214ab0===_0x2ab7ec)return 0x0;if(_0x214ab0===We||_0x2ab7ec===we)return-0x1;if(_0x2ab7ec===We||_0x214ab0===we)return 0x1;{const _0xb114f=Gs(_0x214ab0),_0x3a52df=Gs(_0x2ab7ec);return _0xb114f!==null?_0x3a52df!==null?_0xb114f-_0x3a52df===0x0?_0x214ab0['length']-_0x2ab7ec['length']:_0xb114f-_0x3a52df:-0x1:_0x3a52df!==null?0x1:_0x214ab0<_0x2ab7ec?-0x1:0x1;}},ql=function(_0x240ade,_0x1a9c90){return _0x240ade===_0x1a9c90?0x0:_0x240ade<_0x1a9c90?-0x1:0x1;},vt=function(_0x2a7ce9,_0x54b110){if(_0x54b110&&_0x2a7ce9 in _0x54b110)return _0x54b110[_0x2a7ce9];throw new Error('Missing\x20required\x20key\x20('+_0x2a7ce9+')\x20in\x20object:\x20'+O(_0x54b110));},$i=function(_0x53b46c){if(typeof _0x53b46c!='object'||_0x53b46c===null)return O(_0x53b46c);const _0x519b59=[];for(const _0x220f4e in _0x53b46c)_0x519b59['push'](_0x220f4e);_0x519b59['sort']();let _0x1bc178='{';for(let _0x52768e=0x0;_0x52768e<_0x519b59['length'];_0x52768e++)_0x52768e!==0x0&&(_0x1bc178+=','),_0x1bc178+=O(_0x519b59[_0x52768e]),_0x1bc178+=':',_0x1bc178+=$i(_0x53b46c[_0x519b59[_0x52768e]]);return _0x1bc178+='}',_0x1bc178;},oo=function(_0x33f170,_0x547321){const _0x4a05d5=_0x33f170['length'];if(_0x4a05d5<=_0x547321)return[_0x33f170];const _0x13f2b5=[];for(let _0x10a426=0x0;_0x10a426<_0x4a05d5;_0x10a426+=_0x547321)_0x10a426+_0x547321>_0x4a05d5?_0x13f2b5['push'](_0x33f170['substring'](_0x10a426,_0x4a05d5)):_0x13f2b5['push'](_0x33f170['substring'](_0x10a426,_0x10a426+_0x547321));return _0x13f2b5;};function x(_0x225845,_0x288e1b){for(const _0x426e9f in _0x225845)_0x225845['hasOwnProperty'](_0x426e9f)&&_0x288e1b(_0x426e9f,_0x225845[_0x426e9f]);}const ao=function(_0x961d06){f(!xn(_0x961d06),'Invalid\x20JSON\x20number');const _0x1ef307=0xb,_0x157db5=0x34,_0x3dbdad=(0x1<<_0x1ef307-0x1)-0x1;let _0x4c0d46,_0x4426d4,_0x1175a7,_0x31d5fb,_0x14b367;_0x961d06===0x0?(_0x4426d4=0x0,_0x1175a7=0x0,_0x4c0d46=0x1/_0x961d06===-0x1/0x0?0x1:0x0):(_0x4c0d46=_0x961d06<0x0,_0x961d06=Math['abs'](_0x961d06),_0x961d06>=Math['pow'](0x2,0x1-_0x3dbdad)?(_0x31d5fb=Math['min'](Math['floor'](Math['log'](_0x961d06)/Math['LN2']),_0x3dbdad),_0x4426d4=_0x31d5fb+_0x3dbdad,_0x1175a7=Math['round'](_0x961d06*Math['pow'](0x2,_0x157db5-_0x31d5fb)-Math['pow'](0x2,_0x157db5))):(_0x4426d4=0x0,_0x1175a7=Math['round'](_0x961d06/Math['pow'](0x2,0x1-_0x3dbdad-_0x157db5))));const _0x372f31=[];for(_0x14b367=_0x157db5;_0x14b367;_0x14b367-=0x1)_0x372f31['push'](_0x1175a7%0x2?0x1:0x0),_0x1175a7=Math['floor'](_0x1175a7/0x2);for(_0x14b367=_0x1ef307;_0x14b367;_0x14b367-=0x1)_0x372f31['push'](_0x4426d4%0x2?0x1:0x0),_0x4426d4=Math['floor'](_0x4426d4/0x2);_0x372f31['push'](_0x4c0d46?0x1:0x0),_0x372f31['reverse']();const _0x2857a5=_0x372f31['join']('');let _0x1a3b67='';for(_0x14b367=0x0;_0x14b367<0x40;_0x14b367+=0x8){let _0x6917cf=parseInt(_0x2857a5['substr'](_0x14b367,0x8),0x2)['toString'](0x10);_0x6917cf['length']===0x1&&(_0x6917cf='0'+_0x6917cf),_0x1a3b67=_0x1a3b67+_0x6917cf;}return _0x1a3b67['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0xa6e130,_0xfbca51){let _0x452531='Unknown\x20Error';_0xa6e130==='too_big'?_0x452531='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0xa6e130==='permission_denied'?_0x452531='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0xa6e130==='unavailable'&&(_0x452531='The\x20service\x20is\x20unavailable');const _0x496df1=new Error(_0xa6e130+'\x20at\x20'+_0xfbca51['_path']['toString']()+':\x20'+_0x452531);return _0x496df1['code']=_0xa6e130['toUpperCase'](),_0x496df1;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0xfb6114){if(Yl['test'](_0xfb6114)){const _0x32c51a=Number(_0xfb6114);if(_0x32c51a>=Ql&&_0x32c51a<=Jl)return _0x32c51a;}return null;},ft=function(_0x165773){try{_0x165773();}catch(_0x2f86e8){setTimeout(()=>{const _0x5af083=_0x2f86e8['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x5af083),_0x2f86e8;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x4b954b,_0x36b341){const _0x236aac=setTimeout(_0x4b954b,_0x36b341);return typeof _0x236aac=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x236aac):typeof _0x236aac=='object'&&_0x236aac['unref']&&_0x236aac['unref'](),_0x236aac;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x32eff9,_0x2aeefa){this['appCheckProvider']=_0x2aeefa,this['appName']=_0x32eff9['name'],$(_0x32eff9)&&_0x32eff9['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x32eff9['settings']['appCheckToken']),this['appCheck']=_0x2aeefa==null?void 0x0:_0x2aeefa['getImmediate']({'optional':!0x0}),this['appCheck']||_0x2aeefa==null||_0x2aeefa['get']()['then'](_0x25bc8c=>this['appCheck']=_0x25bc8c);}['getToken'](_0x362b27){if(this['serverAppAppCheckToken']){if(_0x362b27)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x362b27):new Promise((_0x5333d8,_0x5f2a95)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x362b27)['then'](_0x5333d8,_0x5f2a95):_0x5333d8(null);},0x0);});}['addTokenChangeListener'](_0x217483){var _0x348b8e;(_0x348b8e=this['appCheckProvider'])==null||_0x348b8e['get']()['then'](_0x428029=>_0x428029['addTokenListener'](_0x217483));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x4ce48c,_0x31abab,_0x428f4b){this['appName_']=_0x4ce48c,this['firebaseOptions_']=_0x31abab,this['authProvider_']=_0x428f4b,this['auth_']=null,this['auth_']=_0x428f4b['getImmediate']({'optional':!0x0}),this['auth_']||_0x428f4b['onInit'](_0x4d60c0=>this['auth_']=_0x4d60c0);}['getToken'](_0x437ba2){return this['auth_']?this['auth_']['getToken'](_0x437ba2)['catch'](_0x708d5b=>_0x708d5b&&_0x708d5b['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x708d5b)):new Promise((_0x45c6db,_0x36b6f6)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x437ba2)['then'](_0x45c6db,_0x36b6f6):_0x45c6db(null);},0x0);});}['addTokenChangeListener'](_0x2752bb){this['auth_']?this['auth_']['addAuthTokenListener'](_0x2752bb):this['authProvider_']['get']()['then'](_0x24cc69=>_0x24cc69['addAuthTokenListener'](_0x2752bb));}['removeTokenChangeListener'](_0x29a7ac){this['authProvider_']['get']()['then'](_0x25968b=>_0x25968b['removeAuthTokenListener'](_0x29a7ac));}['notifyForInvalidToken'](){let _0x42f25c='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x42f25c+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x42f25c+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x42f25c+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x42f25c);}}class an{constructor(_0xc396ab){this['accessToken']=_0xc396ab;}['getToken'](_0x227418){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x2c3ff1){_0x2c3ff1(this['accessToken']);}['removeTokenChangeListener'](_0x422ad4){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x2ab23b,_0xe3e1a4,_0x189c78,_0x11c4a0,_0x1df6d7=!0x1,_0x12e3c7='',_0x117071=!0x1,_0xb85e5a=!0x1,_0x188e47=null){this['secure']=_0xe3e1a4,this['namespace']=_0x189c78,this['webSocketOnly']=_0x11c4a0,this['nodeAdmin']=_0x1df6d7,this['persistenceKey']=_0x12e3c7,this['includeNamespaceInQueryParams']=_0x117071,this['isUsingEmulator']=_0xb85e5a,this['emulatorOptions']=_0x188e47,this['_host']=_0x2ab23b['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x2ab23b)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x51bc66){_0x51bc66!==this['internalHost']&&(this['internalHost']=_0x51bc66,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x4a50a0=this['toURLString']();return this['persistenceKey']&&(_0x4a50a0+='<'+this['persistenceKey']+'>'),_0x4a50a0;}['toURLString'](){const _0x2df037=this['secure']?'https://':'http://',_0x15d51=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x2df037+this['host']+'/'+_0x15d51;}}function th(_0xfc53aa){return _0xfc53aa['host']!==_0xfc53aa['internalHost']||_0xfc53aa['isCustomHost']()||_0xfc53aa['includeNamespaceInQueryParams'];}function vo(_0x31b1f7,_0x34926f,_0x3145da){f(typeof _0x34926f=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x3145da=='object','typeof\x20params\x20must\x20==\x20object');let _0x45b269;if(_0x34926f===go)_0x45b269=(_0x31b1f7['secure']?'wss://':'ws://')+_0x31b1f7['internalHost']+'/.ws?';else{if(_0x34926f===mo)_0x45b269=(_0x31b1f7['secure']?'https://':'http://')+_0x31b1f7['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x34926f);}th(_0x31b1f7)&&(_0x3145da['ns']=_0x31b1f7['namespace']);const _0x23aaa3=[];return x(_0x3145da,(_0x2b4d6d,_0x1a7200)=>{_0x23aaa3['push'](_0x2b4d6d+'='+_0x1a7200);}),_0x45b269+_0x23aaa3['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x221ecb,_0x563c56=0x1){Q(this['counters_'],_0x221ecb)||(this['counters_'][_0x221ecb]=0x0),this['counters_'][_0x221ecb]+=_0x563c56;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x409248){const _0x47a3d9=_0x409248['toString']();return oi[_0x47a3d9]||(oi[_0x47a3d9]=new nh()),oi[_0x47a3d9];}function ih(_0x244c98,_0x3e8134){const _0x53a074=_0x244c98['toString']();return ai[_0x53a074]||(ai[_0x53a074]=_0x3e8134()),ai[_0x53a074];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x544042){this['onMessage_']=_0x544042,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x1905a4,_0x1588af){this['closeAfterResponse']=_0x1905a4,this['onClose']=_0x1588af,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x1a23c2,_0x1549a9){for(this['pendingResponses'][_0x1a23c2]=_0x1549a9;this['pendingResponses'][this['currentResponseNum']];){const _0x11a4e7=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x1f1810=0x0;_0x1f1810<_0x11a4e7['length'];++_0x1f1810)_0x11a4e7[_0x1f1810]&&ft(()=>{this['onMessage_'](_0x11a4e7[_0x1f1810]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x16098b,_0x449544,_0x21c1ea,_0x5ce6d7,_0x15e466,_0x2dad53,_0x5d83a1){this['connId']=_0x16098b,this['repoInfo']=_0x449544,this['applicationId']=_0x21c1ea,this['appCheckToken']=_0x5ce6d7,this['authToken']=_0x15e466,this['transportSessionId']=_0x2dad53,this['lastSessionId']=_0x5d83a1,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x16098b),this['stats_']=qi(_0x449544),this['urlFn']=_0x552694=>(this['appCheckToken']&&(_0x552694[wi]=this['appCheckToken']),vo(_0x449544,mo,_0x552694));}['open'](_0x355a1e,_0x3a3083){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x3a3083,this['myPacketOrderer']=new sh(_0x355a1e),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x10f793)=>{const [_0x47ebe9,_0x6ba6d6,_0x433f9e,_0x4881ad,_0x176e8e]=_0x10f793;if(this['incrementIncomingBytes_'](_0x10f793),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x47ebe9===qs)this['id']=_0x6ba6d6,this['password']=_0x433f9e;else{if(_0x47ebe9===rh)_0x6ba6d6?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x6ba6d6,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x47ebe9);}}},(..._0x5062de)=>{const [_0x54899c,_0x4e5c10]=_0x5062de;this['incrementIncomingBytes_'](_0x5062de),this['myPacketOrderer']['handleResponse'](_0x54899c,_0x4e5c10);},()=>{this['onClosed_']();},this['urlFn']);const _0x1cb5ad={};_0x1cb5ad[qs]='t',_0x1cb5ad[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x1cb5ad[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x1cb5ad[co]=Gi,this['transportSessionId']&&(_0x1cb5ad[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x1cb5ad[po]=this['lastSessionId']),this['applicationId']&&(_0x1cb5ad[_o]=this['applicationId']),this['appCheckToken']&&(_0x1cb5ad[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x1cb5ad[ho]=uo);const _0x4eb8b3=this['urlFn'](_0x1cb5ad);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x4eb8b3),this['scriptTagHolder']['addTag'](_0x4eb8b3,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x2cf686){const _0x5f2f1c=O(_0x2cf686);this['bytesSent']+=_0x5f2f1c['length'],this['stats_']['incrementCounter']('bytes_sent',_0x5f2f1c['length']);const _0xc00652=$r(_0x5f2f1c),_0x338451=oo(_0xc00652,fh);for(let _0x2bc11d=0x0;_0x2bc11d<_0x338451['length'];_0x2bc11d++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x338451['length'],_0x338451[_0x2bc11d]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0xccb413,_0x442001){this['myDisconnFrame']=document['createElement']('iframe');const _0xd240e2={};_0xd240e2[dh]='t',_0xd240e2[Eo]=_0xccb413,_0xd240e2[Io]=_0x442001,this['myDisconnFrame']['src']=this['urlFn'](_0xd240e2),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x5b98ae){const _0x405033=O(_0x5b98ae)['length'];this['bytesReceived']+=_0x405033,this['stats_']['incrementCounter']('bytes_received',_0x405033);}}class zi{constructor(_0x25c728,_0x3c9f58,_0x2ccd1b,_0x2fd3ef){this['onDisconnect']=_0x2ccd1b,this['urlFn']=_0x2fd3ef,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x25c728,window[ah+this['uniqueCallbackIdentifier']]=_0x3c9f58,this['myIFrame']=zi['createIFrame_']();let _0x82914a='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x82914a='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x34e092='<html><body>'+_0x82914a+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x34e092),this['myIFrame']['doc']['close']();}catch(_0x214d4d){L('frame\x20writing\x20exception'),_0x214d4d['stack']&&L(_0x214d4d['stack']),L(_0x214d4d);}}}static['createIFrame_'](){const _0x4d2ca5=document['createElement']('iframe');if(_0x4d2ca5['style']['display']='none',document['body']){document['body']['appendChild'](_0x4d2ca5);try{_0x4d2ca5['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x1eab49=document['domain'];_0x4d2ca5['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x1eab49+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x4d2ca5['contentDocument']?_0x4d2ca5['doc']=_0x4d2ca5['contentDocument']:_0x4d2ca5['contentWindow']?_0x4d2ca5['doc']=_0x4d2ca5['contentWindow']['document']:_0x4d2ca5['document']&&(_0x4d2ca5['doc']=_0x4d2ca5['document']),_0x4d2ca5;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x22e664=this['onDisconnect'];_0x22e664&&(this['onDisconnect']=null,_0x22e664());}['startLongPoll'](_0xe2516d,_0x59a012){for(this['myID']=_0xe2516d,this['myPW']=_0x59a012,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x445365={};_0x445365[Eo]=this['myID'],_0x445365[Io]=this['myPW'],_0x445365[wo]=this['currentSerial'];let _0x247de5=this['urlFn'](_0x445365),_0x26d45a='',_0x5663d8=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x26d45a['length']<=Co;){const _0x5a3607=this['pendingSegs']['shift']();_0x26d45a=_0x26d45a+'&'+lh+_0x5663d8+'='+_0x5a3607['seg']+'&'+hh+_0x5663d8+'='+_0x5a3607['ts']+'&'+uh+_0x5663d8+'='+_0x5a3607['d'],_0x5663d8++;}return _0x247de5=_0x247de5+_0x26d45a,this['addLongPollTag_'](_0x247de5,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x5b2b75,_0x16c23b,_0x28c7ce){this['pendingSegs']['push']({'seg':_0x5b2b75,'ts':_0x16c23b,'d':_0x28c7ce}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x39b828,_0x13960b){this['outstandingRequests']['add'](_0x13960b);const _0x195a3c=()=>{this['outstandingRequests']['delete'](_0x13960b),this['newRequest_']();},_0x197b72=setTimeout(_0x195a3c,Math['floor'](ph)),_0x1d525c=()=>{clearTimeout(_0x197b72),_0x195a3c();};this['addTag'](_0x39b828,_0x1d525c);}['addTag'](_0x482cb6,_0x37614d){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x13ec08=this['myIFrame']['doc']['createElement']('script');_0x13ec08['type']='text/javascript',_0x13ec08['async']=!0x0,_0x13ec08['src']=_0x482cb6,_0x13ec08['onload']=_0x13ec08['onreadystatechange']=function(){const _0x56fff7=_0x13ec08['readyState'];(!_0x56fff7||_0x56fff7==='loaded'||_0x56fff7==='complete')&&(_0x13ec08['onload']=_0x13ec08['onreadystatechange']=null,_0x13ec08['parentNode']&&_0x13ec08['parentNode']['removeChild'](_0x13ec08),_0x37614d());},_0x13ec08['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x482cb6),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x13ec08);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x131eed,_0x314a14,_0x25b096,_0x46c0fc,_0x3418f6,_0x34f0a2,_0x1013dd){this['connId']=_0x131eed,this['applicationId']=_0x25b096,this['appCheckToken']=_0x46c0fc,this['authToken']=_0x3418f6,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x314a14),this['connURL']=q['connectionURL_'](_0x314a14,_0x34f0a2,_0x1013dd,_0x46c0fc,_0x25b096),this['nodeAdmin']=_0x314a14['nodeAdmin'];}static['connectionURL_'](_0x406565,_0x2a6b61,_0x52ed21,_0x478ad7,_0x55bdb6){const _0x17b275={};return _0x17b275[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x17b275[ho]=uo),_0x2a6b61&&(_0x17b275[lo]=_0x2a6b61),_0x52ed21&&(_0x17b275[po]=_0x52ed21),_0x478ad7&&(_0x17b275[wi]=_0x478ad7),_0x55bdb6&&(_0x17b275[_o]=_0x55bdb6),vo(_0x406565,go,_0x17b275);}['open'](_0x3ee592,_0x5e9825){this['onDisconnect']=_0x5e9825,this['onMessage']=_0x3ee592,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x254a35;_c(),this['mySock']=new gn(this['connURL'],[],_0x254a35);}catch(_0x30609f){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x565ff9=_0x30609f['message']||_0x30609f['data'];_0x565ff9&&this['log_'](_0x565ff9),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x57ac57=>{this['handleIncomingFrame'](_0x57ac57);},this['mySock']['onerror']=_0x2f7159=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x541b8b=_0x2f7159['message']||_0x2f7159['data'];_0x541b8b&&this['log_'](_0x541b8b),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x5ea3c7=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x24ccf3=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x39bfce=navigator['userAgent']['match'](_0x24ccf3);_0x39bfce&&_0x39bfce['length']>0x1&&parseFloat(_0x39bfce[0x1])<4.4&&(_0x5ea3c7=!0x0);}return!_0x5ea3c7&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x5d4525){if(this['frames']['push'](_0x5d4525),this['frames']['length']===this['totalFrames']){const _0x3c60e4=this['frames']['join']('');this['frames']=null;const _0x4932c4=Nt(_0x3c60e4);this['onMessage'](_0x4932c4);}}['handleNewFrameCount_'](_0x381cbf){this['totalFrames']=_0x381cbf,this['frames']=[];}['extractFrameCount_'](_0x38e349){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x38e349['length']<=0x6){const _0x1e4a8f=Number(_0x38e349);if(!isNaN(_0x1e4a8f))return this['handleNewFrameCount_'](_0x1e4a8f),null;}return this['handleNewFrameCount_'](0x1),_0x38e349;}['handleIncomingFrame'](_0x17f243){if(this['mySock']===null)return;const _0x4c8cc6=_0x17f243['data'];if(this['bytesReceived']+=_0x4c8cc6['length'],this['stats_']['incrementCounter']('bytes_received',_0x4c8cc6['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x4c8cc6);else{const _0x82cf9e=this['extractFrameCount_'](_0x4c8cc6);_0x82cf9e!==null&&this['appendFrame_'](_0x82cf9e);}}['send'](_0x7c7c83){this['resetKeepAlive']();const _0x2e1b53=O(_0x7c7c83);this['bytesSent']+=_0x2e1b53['length'],this['stats_']['incrementCounter']('bytes_sent',_0x2e1b53['length']);const _0x2ea124=oo(_0x2e1b53,gh);_0x2ea124['length']>0x1&&this['sendString_'](String(_0x2ea124['length']));for(let _0x3d39ad=0x0;_0x3d39ad<_0x2ea124['length'];_0x3d39ad++)this['sendString_'](_0x2ea124[_0x3d39ad]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x30b997){try{this['mySock']['send'](_0x30b997);}catch(_0x3d6f98){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x3d6f98['message']||_0x3d6f98['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x39332d){this['initTransports_'](_0x39332d);}['initTransports_'](_0x57a126){const _0x43a66c=q&&q['isAvailable']();let _0x341b12=_0x43a66c&&!q['previouslyFailed']();if(_0x57a126['webSocketOnly']&&(_0x43a66c||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x341b12=!0x0),_0x341b12)this['transports_']=[q];else{const _0x43a04b=this['transports_']=[];for(const _0x11051c of Dt['ALL_TRANSPORTS'])_0x11051c&&_0x11051c['isAvailable']()&&_0x43a04b['push'](_0x11051c);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x2b7571,_0x17fba1,_0x402fe1,_0x2db036,_0x51c438,_0x52f0f9,_0x384313,_0x50b4f3,_0x1d0a77,_0x493c58){this['id']=_0x2b7571,this['repoInfo_']=_0x17fba1,this['applicationId_']=_0x402fe1,this['appCheckToken_']=_0x2db036,this['authToken_']=_0x51c438,this['onMessage_']=_0x52f0f9,this['onReady_']=_0x384313,this['onDisconnect_']=_0x50b4f3,this['onKill_']=_0x1d0a77,this['lastSessionId']=_0x493c58,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x17fba1),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x2c6a15=this['transportManager_']['initialTransport']();this['conn_']=new _0x2c6a15(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x2c6a15['responsesRequiredToBeHealthy']||0x0;const _0x513545=this['connReceiver_'](this['conn_']),_0x359fbb=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x513545,_0x359fbb);},Math['floor'](0x0));const _0x7bfeb9=_0x2c6a15['healthyTimeout']||0x0;_0x7bfeb9>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x7bfeb9)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x454d52){return _0x184e8c=>{_0x454d52===this['conn_']?this['onConnectionLost_'](_0x184e8c):_0x454d52===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x24385c){return _0x241aa4=>{this['state_']!==0x2&&(_0x24385c===this['rx_']?this['onPrimaryMessageReceived_'](_0x241aa4):_0x24385c===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x241aa4):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0xc907ed){const _0x23bd95={'t':'d','d':_0xc907ed};this['sendData_'](_0x23bd95);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x552263){if(ci in _0x552263){const _0x4a6939=_0x552263[ci];_0x4a6939===Ys?this['upgradeIfSecondaryHealthy_']():_0x4a6939===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x4a6939===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x1455e5){const _0x56847d=vt('t',_0x1455e5),_0x2a78fe=vt('d',_0x1455e5);if(_0x56847d==='c')this['onSecondaryControl_'](_0x2a78fe);else{if(_0x56847d==='d')this['pendingDataMessages']['push'](_0x2a78fe);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x56847d);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x10f4df){const _0xf7390a=vt('t',_0x10f4df),_0x556eb1=vt('d',_0x10f4df);_0xf7390a==='c'?this['onControl_'](_0x556eb1):_0xf7390a==='d'&&this['onDataMessage_'](_0x556eb1);}['onDataMessage_'](_0x197b0e){this['onPrimaryResponse_'](),this['onMessage_'](_0x197b0e);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x5219eb){const _0x1f7b10=vt(ci,_0x5219eb);if(zs in _0x5219eb){const _0x2a9205=_0x5219eb[zs];if(_0x1f7b10===Th){const _0x445808={..._0x2a9205};this['repoInfo_']['isUsingEmulator']&&(_0x445808['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x445808);}else{if(_0x1f7b10===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x27cae1=0x0;_0x27cae1<this['pendingDataMessages']['length'];++_0x27cae1)this['onDataMessage_'](this['pendingDataMessages'][_0x27cae1]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x1f7b10===wh?this['onConnectionShutdown_'](_0x2a9205):_0x1f7b10===js?this['onReset_'](_0x2a9205):_0x1f7b10===Ch?Ii('Server\x20Error:\x20'+_0x2a9205):_0x1f7b10===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x1f7b10);}}}['onHandshake_'](_0x443ccc){const _0x502ade=_0x443ccc['ts'],_0x4c5dd9=_0x443ccc['v'],_0x3dea40=_0x443ccc['h'];this['sessionId']=_0x443ccc['s'],this['repoInfo_']['host']=_0x3dea40,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x502ade),Gi!==_0x4c5dd9&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0xb678a4=this['transportManager_']['upgradeTransport']();_0xb678a4&&this['startUpgrade_'](_0xb678a4);}['startUpgrade_'](_0x58726e){this['secondaryConn_']=new _0x58726e(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x58726e['responsesRequiredToBeHealthy']||0x0;const _0x36b199=this['connReceiver_'](this['secondaryConn_']),_0x2ec696=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x36b199,_0x2ec696),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0xdf93a3){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0xdf93a3),this['repoInfo_']['host']=_0xdf93a3,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x225354,_0xddaffe){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x225354,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0xddaffe,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x36d995=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x36d995||this['rx_']===_0x36d995)&&this['close']();}['onConnectionLost_'](_0x1007a4){this['conn_']=null,!_0x1007a4&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x3386e4){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x3386e4),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x55b253){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x55b253);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x3a908a,_0x23e41f,_0x516c1a,_0x48a9c9){}['merge'](_0x549249,_0x1a82df,_0x4ea7a9,_0x1f6c27){}['refreshAuthToken'](_0x2e5802){}['refreshAppCheckToken'](_0x8f0471){}['onDisconnectPut'](_0x24b279,_0x4ade47,_0x4e0dc1){}['onDisconnectMerge'](_0xe34489,_0xc5d536,_0x47ae37){}['onDisconnectCancel'](_0x5b89eb,_0x12a1b8){}['reportStats'](_0x390a9c){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x1ff766){this['allowedEvents_']=_0x1ff766,this['listeners_']={},f(Array['isArray'](_0x1ff766)&&_0x1ff766['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x46d12b,..._0x496621){if(Array['isArray'](this['listeners_'][_0x46d12b])){const _0x1cb733=[...this['listeners_'][_0x46d12b]];for(let _0x3eaf56=0x0;_0x3eaf56<_0x1cb733['length'];_0x3eaf56++)_0x1cb733[_0x3eaf56]['callback']['apply'](_0x1cb733[_0x3eaf56]['context'],_0x496621);}}['on'](_0x2a9763,_0x437695,_0x17dc48){this['validateEventType_'](_0x2a9763),this['listeners_'][_0x2a9763]=this['listeners_'][_0x2a9763]||[],this['listeners_'][_0x2a9763]['push']({'callback':_0x437695,'context':_0x17dc48});const _0x228af4=this['getInitialEvent'](_0x2a9763);_0x228af4&&_0x437695['apply'](_0x17dc48,_0x228af4);}['off'](_0x234414,_0x3856fe,_0x52b118){this['validateEventType_'](_0x234414);const _0x1f6807=this['listeners_'][_0x234414]||[];for(let _0x425d21=0x0;_0x425d21<_0x1f6807['length'];_0x425d21++)if(_0x1f6807[_0x425d21]['callback']===_0x3856fe&&(!_0x52b118||_0x52b118===_0x1f6807[_0x425d21]['context'])){_0x1f6807['splice'](_0x425d21,0x1);return;}}['validateEventType_'](_0x295e49){f(this['allowedEvents_']['find'](_0x5e80c2=>_0x5e80c2===_0x295e49),'Unknown\x20event:\x20'+_0x295e49);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x35231d){return f(_0x35231d==='online','Unknown\x20event\x20type:\x20'+_0x35231d),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x2407be,_0x5e3e47){if(_0x5e3e47===void 0x0){this['pieces_']=_0x2407be['split']('/');let _0x1081ee=0x0;for(let _0x2b0350=0x0;_0x2b0350<this['pieces_']['length'];_0x2b0350++)this['pieces_'][_0x2b0350]['length']>0x0&&(this['pieces_'][_0x1081ee]=this['pieces_'][_0x2b0350],_0x1081ee++);this['pieces_']['length']=_0x1081ee,this['pieceNum_']=0x0;}else this['pieces_']=_0x2407be,this['pieceNum_']=_0x5e3e47;}['toString'](){let _0x89e905='';for(let _0x5dd412=this['pieceNum_'];_0x5dd412<this['pieces_']['length'];_0x5dd412++)this['pieces_'][_0x5dd412]!==''&&(_0x89e905+='/'+this['pieces_'][_0x5dd412]);return _0x89e905||'/';}}function w(){return new C('');}function y(_0x5337bf){return _0x5337bf['pieceNum_']>=_0x5337bf['pieces_']['length']?null:_0x5337bf['pieces_'][_0x5337bf['pieceNum_']];}function Ce(_0x16c934){return _0x16c934['pieces_']['length']-_0x16c934['pieceNum_'];}function S(_0x3783a8){let _0x5aca5c=_0x3783a8['pieceNum_'];return _0x5aca5c<_0x3783a8['pieces_']['length']&&_0x5aca5c++,new C(_0x3783a8['pieces_'],_0x5aca5c);}function ji(_0x5beeeb){return _0x5beeeb['pieceNum_']<_0x5beeeb['pieces_']['length']?_0x5beeeb['pieces_'][_0x5beeeb['pieces_']['length']-0x1]:null;}function bh(_0x256f4a){let _0x42797f='';for(let _0x160986=_0x256f4a['pieceNum_'];_0x160986<_0x256f4a['pieces_']['length'];_0x160986++)_0x256f4a['pieces_'][_0x160986]!==''&&(_0x42797f+='/'+encodeURIComponent(String(_0x256f4a['pieces_'][_0x160986])));return _0x42797f||'/';}function Mt(_0x397891,_0x307cce=0x0){return _0x397891['pieces_']['slice'](_0x397891['pieceNum_']+_0x307cce);}function Ro(_0x51e79e){if(_0x51e79e['pieceNum_']>=_0x51e79e['pieces_']['length'])return null;const _0xc13c76=[];for(let _0x3c7dfc=_0x51e79e['pieceNum_'];_0x3c7dfc<_0x51e79e['pieces_']['length']-0x1;_0x3c7dfc++)_0xc13c76['push'](_0x51e79e['pieces_'][_0x3c7dfc]);return new C(_0xc13c76,0x0);}function k(_0x40e8f1,_0x58572b){const _0x10b076=[];for(let _0x580c6b=_0x40e8f1['pieceNum_'];_0x580c6b<_0x40e8f1['pieces_']['length'];_0x580c6b++)_0x10b076['push'](_0x40e8f1['pieces_'][_0x580c6b]);if(_0x58572b instanceof C){for(let _0x30feee=_0x58572b['pieceNum_'];_0x30feee<_0x58572b['pieces_']['length'];_0x30feee++)_0x10b076['push'](_0x58572b['pieces_'][_0x30feee]);}else{const _0x534d8d=_0x58572b['split']('/');for(let _0x1a6a30=0x0;_0x1a6a30<_0x534d8d['length'];_0x1a6a30++)_0x534d8d[_0x1a6a30]['length']>0x0&&_0x10b076['push'](_0x534d8d[_0x1a6a30]);}return new C(_0x10b076,0x0);}function v(_0x566a62){return _0x566a62['pieceNum_']>=_0x566a62['pieces_']['length'];}function F(_0x1e6e47,_0x4447c1){const _0x53b538=y(_0x1e6e47),_0x165e43=y(_0x4447c1);if(_0x53b538===null)return _0x4447c1;if(_0x53b538===_0x165e43)return F(S(_0x1e6e47),S(_0x4447c1));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x4447c1+')\x20is\x20not\x20within\x20outerPath\x20('+_0x1e6e47+')');}function Rh(_0x29b242,_0x59c989){const _0x318dcf=Mt(_0x29b242,0x0),_0x1cd3fc=Mt(_0x59c989,0x0);for(let _0x1370ca=0x0;_0x1370ca<_0x318dcf['length']&&_0x1370ca<_0x1cd3fc['length'];_0x1370ca++){const _0xe4a0aa=qe(_0x318dcf[_0x1370ca],_0x1cd3fc[_0x1370ca]);if(_0xe4a0aa!==0x0)return _0xe4a0aa;}return _0x318dcf['length']===_0x1cd3fc['length']?0x0:_0x318dcf['length']<_0x1cd3fc['length']?-0x1:0x1;}function Ki(_0x19f81f,_0x1172a1){if(Ce(_0x19f81f)!==Ce(_0x1172a1))return!0x1;for(let _0xf12606=_0x19f81f['pieceNum_'],_0x6de490=_0x1172a1['pieceNum_'];_0xf12606<=_0x19f81f['pieces_']['length'];_0xf12606++,_0x6de490++)if(_0x19f81f['pieces_'][_0xf12606]!==_0x1172a1['pieces_'][_0x6de490])return!0x1;return!0x0;}function G(_0x327520,_0x42f84d){let _0x4d01d9=_0x327520['pieceNum_'],_0x2ba8ab=_0x42f84d['pieceNum_'];if(Ce(_0x327520)>Ce(_0x42f84d))return!0x1;for(;_0x4d01d9<_0x327520['pieces_']['length'];){if(_0x327520['pieces_'][_0x4d01d9]!==_0x42f84d['pieces_'][_0x2ba8ab])return!0x1;++_0x4d01d9,++_0x2ba8ab;}return!0x0;}class Ah{constructor(_0x35fb0d,_0xd22693){this['errorPrefix_']=_0xd22693,this['parts_']=Mt(_0x35fb0d,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x585b7d=0x0;_0x585b7d<this['parts_']['length'];_0x585b7d++)this['byteLength_']+=Ln(this['parts_'][_0x585b7d]);Ao(this);}}function kh(_0x179fc3,_0x1b132d){_0x179fc3['parts_']['length']>0x0&&(_0x179fc3['byteLength_']+=0x1),_0x179fc3['parts_']['push'](_0x1b132d),_0x179fc3['byteLength_']+=Ln(_0x1b132d),Ao(_0x179fc3);}function Ph(_0x11d789){const _0xfd1b70=_0x11d789['parts_']['pop']();_0x11d789['byteLength_']-=Ln(_0xfd1b70),_0x11d789['parts_']['length']>0x0&&(_0x11d789['byteLength_']-=0x1);}function Ao(_0x41cdd2){if(_0x41cdd2['byteLength_']>Zs)throw new Error(_0x41cdd2['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x41cdd2['byteLength_']+').');if(_0x41cdd2['parts_']['length']>Xs)throw new Error(_0x41cdd2['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x41cdd2));}function Oe(_0x56e491){return _0x56e491['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x56e491['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x21a9b2,_0x2d49d6;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x2d49d6='visibilitychange',_0x21a9b2='hidden'):typeof document['mozHidden']<'u'?(_0x2d49d6='mozvisibilitychange',_0x21a9b2='mozHidden'):typeof document['msHidden']<'u'?(_0x2d49d6='msvisibilitychange',_0x21a9b2='msHidden'):typeof document['webkitHidden']<'u'&&(_0x2d49d6='webkitvisibilitychange',_0x21a9b2='webkitHidden')),this['visible_']=!0x0,_0x2d49d6&&document['addEventListener'](_0x2d49d6,()=>{const _0x2c7b4c=!document[_0x21a9b2];_0x2c7b4c!==this['visible_']&&(this['visible_']=_0x2c7b4c,this['trigger']('visible',_0x2c7b4c));},!0x1);}['getInitialEvent'](_0x505684){return f(_0x505684==='visible','Unknown\x20event\x20type:\x20'+_0x505684),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x3ac1c1,_0x5c0d85,_0x36fe6f,_0x17f9a3,_0x3dde37,_0x2ffebe,_0xa63219,_0x355f68){if(super(),this['repoInfo_']=_0x3ac1c1,this['applicationId_']=_0x5c0d85,this['onDataUpdate_']=_0x36fe6f,this['onConnectStatus_']=_0x17f9a3,this['onServerInfoUpdate_']=_0x3dde37,this['authTokenProvider_']=_0x2ffebe,this['appCheckTokenProvider_']=_0xa63219,this['authOverride_']=_0x355f68,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x355f68)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x3ac1c1['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x5ec806,_0x46ad51,_0x385b57){const _0x5b9a4c=++this['requestNumber_'],_0x4cc950={'r':_0x5b9a4c,'a':_0x5ec806,'b':_0x46ad51};this['log_'](O(_0x4cc950)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x4cc950),_0x385b57&&(this['requestCBHash_'][_0x5b9a4c]=_0x385b57);}['get'](_0x1809a1){this['initConnection_']();const _0xe4a288=new H(),_0x494d0b={'action':'g','request':{'p':_0x1809a1['_path']['toString'](),'q':_0x1809a1['_queryObject']},'onComplete':_0x30f440=>{const _0x1b3467=_0x30f440['d'];_0x30f440['s']==='ok'?_0xe4a288['resolve'](_0x1b3467):_0xe4a288['reject'](_0x1b3467);}};this['outstandingGets_']['push'](_0x494d0b),this['outstandingGetCount_']++;const _0x4e2756=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x4e2756),_0xe4a288['promise'];}['listen'](_0x3f939e,_0xcc47c,_0x3586ce,_0x58b2ef){this['initConnection_']();const _0x1e6b28=_0x3f939e['_queryIdentifier'],_0x46e49b=_0x3f939e['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x46e49b+'\x20'+_0x1e6b28),this['listens']['has'](_0x46e49b)||this['listens']['set'](_0x46e49b,new Map()),f(_0x3f939e['_queryParams']['isDefault']()||!_0x3f939e['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x46e49b)['has'](_0x1e6b28),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x46aab9={'onComplete':_0x58b2ef,'hashFn':_0xcc47c,'query':_0x3f939e,'tag':_0x3586ce};this['listens']['get'](_0x46e49b)['set'](_0x1e6b28,_0x46aab9),this['connected_']&&this['sendListen_'](_0x46aab9);}['sendGet_'](_0x500556){const _0x1ba965=this['outstandingGets_'][_0x500556];this['sendRequest']('g',_0x1ba965['request'],_0x46d1a8=>{delete this['outstandingGets_'][_0x500556],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x1ba965['onComplete']&&_0x1ba965['onComplete'](_0x46d1a8);});}['sendListen_'](_0xaab044){const _0xb87a7e=_0xaab044['query'],_0x318b99=_0xb87a7e['_path']['toString'](),_0x5a3815=_0xb87a7e['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x318b99+'\x20for\x20'+_0x5a3815);const _0x37465d={'p':_0x318b99},_0x1e40b9='q';_0xaab044['tag']&&(_0x37465d['q']=_0xb87a7e['_queryObject'],_0x37465d['t']=_0xaab044['tag']),_0x37465d['h']=_0xaab044['hashFn'](),this['sendRequest'](_0x1e40b9,_0x37465d,_0x2d3166=>{const _0x557661=_0x2d3166['d'],_0x2070ad=_0x2d3166['s'];se['warnOnListenWarnings_'](_0x557661,_0xb87a7e),(this['listens']['get'](_0x318b99)&&this['listens']['get'](_0x318b99)['get'](_0x5a3815))===_0xaab044&&(this['log_']('listen\x20response',_0x2d3166),_0x2070ad!=='ok'&&this['removeListen_'](_0x318b99,_0x5a3815),_0xaab044['onComplete']&&_0xaab044['onComplete'](_0x2070ad,_0x557661));});}static['warnOnListenWarnings_'](_0x113e4c,_0x5125a3){if(_0x113e4c&&typeof _0x113e4c=='object'&&Q(_0x113e4c,'w')){const _0x15b37a=Le(_0x113e4c,'w');if(Array['isArray'](_0x15b37a)&&~_0x15b37a['indexOf']('no_index')){const _0x4a2b04='\x22.indexOn\x22:\x20\x22'+_0x5125a3['_queryParams']['getIndex']()['toString']()+'\x22',_0x20c937=_0x5125a3['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x4a2b04+'\x20at\x20'+_0x20c937+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x1b5fd7){this['authToken_']=_0x1b5fd7,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x1b5fd7);}['reduceReconnectDelayIfAdminCredential_'](_0x5aa998){(_0x5aa998&&_0x5aa998['length']===0x28||wc(_0x5aa998))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x3f55cf){this['appCheckToken_']=_0x3f55cf,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x4818b3=this['authToken_'],_0x12071f=Ic(_0x4818b3)?'auth':'gauth',_0x5be386={'cred':_0x4818b3};this['authOverride_']===null?_0x5be386['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x5be386['authvar']=this['authOverride_']),this['sendRequest'](_0x12071f,_0x5be386,_0x1f5224=>{const _0x2a6af9=_0x1f5224['s'],_0x9ff41d=_0x1f5224['d']||'error';this['authToken_']===_0x4818b3&&(_0x2a6af9==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x2a6af9,_0x9ff41d));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0xa573b7=>{const _0x1f8d84=_0xa573b7['s'],_0x1c08c8=_0xa573b7['d']||'error';_0x1f8d84==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x1f8d84,_0x1c08c8);});}['unlisten'](_0x258a3a,_0x2fbd99){const _0x563b86=_0x258a3a['_path']['toString'](),_0x62bde6=_0x258a3a['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x563b86+'\x20'+_0x62bde6),f(_0x258a3a['_queryParams']['isDefault']()||!_0x258a3a['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x563b86,_0x62bde6)&&this['connected_']&&this['sendUnlisten_'](_0x563b86,_0x62bde6,_0x258a3a['_queryObject'],_0x2fbd99);}['sendUnlisten_'](_0x11c5b8,_0x192c80,_0x24073f,_0x5ca0ce){this['log_']('Unlisten\x20on\x20'+_0x11c5b8+'\x20for\x20'+_0x192c80);const _0x129dae={'p':_0x11c5b8},_0x530dd6='n';_0x5ca0ce&&(_0x129dae['q']=_0x24073f,_0x129dae['t']=_0x5ca0ce),this['sendRequest'](_0x530dd6,_0x129dae);}['onDisconnectPut'](_0x3f4a9d,_0x24b9fb,_0x76e26f){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x3f4a9d,_0x24b9fb,_0x76e26f):this['onDisconnectRequestQueue_']['push']({'pathString':_0x3f4a9d,'action':'o','data':_0x24b9fb,'onComplete':_0x76e26f});}['onDisconnectMerge'](_0x46255b,_0x4430c8,_0x157363){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x46255b,_0x4430c8,_0x157363):this['onDisconnectRequestQueue_']['push']({'pathString':_0x46255b,'action':'om','data':_0x4430c8,'onComplete':_0x157363});}['onDisconnectCancel'](_0x3adee9,_0x2a0f9d){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x3adee9,null,_0x2a0f9d):this['onDisconnectRequestQueue_']['push']({'pathString':_0x3adee9,'action':'oc','data':null,'onComplete':_0x2a0f9d});}['sendOnDisconnect_'](_0x420d7e,_0x15fb74,_0x2c5fd6,_0x586c2f){const _0x28012f={'p':_0x15fb74,'d':_0x2c5fd6};this['log_']('onDisconnect\x20'+_0x420d7e,_0x28012f),this['sendRequest'](_0x420d7e,_0x28012f,_0x127f47=>{_0x586c2f&&setTimeout(()=>{_0x586c2f(_0x127f47['s'],_0x127f47['d']);},Math['floor'](0x0));});}['put'](_0x3e9ad2,_0x1280ea,_0x492e25,_0xd775e9){this['putInternal']('p',_0x3e9ad2,_0x1280ea,_0x492e25,_0xd775e9);}['merge'](_0x344cee,_0x7497ca,_0xc2bbd4,_0x37d371){this['putInternal']('m',_0x344cee,_0x7497ca,_0xc2bbd4,_0x37d371);}['putInternal'](_0x41967d,_0x45e966,_0x1f5344,_0x432ac7,_0x13792a){this['initConnection_']();const _0x46fe91={'p':_0x45e966,'d':_0x1f5344};_0x13792a!==void 0x0&&(_0x46fe91['h']=_0x13792a),this['outstandingPuts_']['push']({'action':_0x41967d,'request':_0x46fe91,'onComplete':_0x432ac7}),this['outstandingPutCount_']++;const _0x332693=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x332693):this['log_']('Buffering\x20put:\x20'+_0x45e966);}['sendPut_'](_0x52e9d7){const _0x3706e6=this['outstandingPuts_'][_0x52e9d7]['action'],_0x740312=this['outstandingPuts_'][_0x52e9d7]['request'],_0x4ad1f6=this['outstandingPuts_'][_0x52e9d7]['onComplete'];this['outstandingPuts_'][_0x52e9d7]['queued']=this['connected_'],this['sendRequest'](_0x3706e6,_0x740312,_0x18d98e=>{this['log_'](_0x3706e6+'\x20response',_0x18d98e),delete this['outstandingPuts_'][_0x52e9d7],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x4ad1f6&&_0x4ad1f6(_0x18d98e['s'],_0x18d98e['d']);});}['reportStats'](_0x34b580){if(this['connected_']){const _0xc7c3b2={'c':_0x34b580};this['log_']('reportStats',_0xc7c3b2),this['sendRequest']('s',_0xc7c3b2,_0x5ecdac=>{if(_0x5ecdac['s']!=='ok'){const _0x5ce95a=_0x5ecdac['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x5ce95a);}});}}['onDataMessage_'](_0x2f00db){if('r'in _0x2f00db){this['log_']('from\x20server:\x20'+O(_0x2f00db));const _0x427baa=_0x2f00db['r'],_0x440634=this['requestCBHash_'][_0x427baa];_0x440634&&(delete this['requestCBHash_'][_0x427baa],_0x440634(_0x2f00db['b']));}else{if('error'in _0x2f00db)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x2f00db['error'];'a'in _0x2f00db&&this['onDataPush_'](_0x2f00db['a'],_0x2f00db['b']);}}['onDataPush_'](_0x48f4ae,_0x2b3612){this['log_']('handleServerMessage',_0x48f4ae,_0x2b3612),_0x48f4ae==='d'?this['onDataUpdate_'](_0x2b3612['p'],_0x2b3612['d'],!0x1,_0x2b3612['t']):_0x48f4ae==='m'?this['onDataUpdate_'](_0x2b3612['p'],_0x2b3612['d'],!0x0,_0x2b3612['t']):_0x48f4ae==='c'?this['onListenRevoked_'](_0x2b3612['p'],_0x2b3612['q']):_0x48f4ae==='ac'?this['onAuthRevoked_'](_0x2b3612['s'],_0x2b3612['d']):_0x48f4ae==='apc'?this['onAppCheckRevoked_'](_0x2b3612['s'],_0x2b3612['d']):_0x48f4ae==='sd'?this['onSecurityDebugPacket_'](_0x2b3612):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x48f4ae)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x193b91,_0x5df82d){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x193b91),this['lastSessionId']=_0x5df82d,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x3bb756){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x3bb756));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x15ced8){_0x15ced8&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x15ced8;}['onOnline_'](_0x307d35){_0x307d35?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x565d11=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x3bf24f=Math['max'](0x0,this['reconnectDelay_']-_0x565d11);_0x3bf24f=Math['random']()*_0x3bf24f,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x3bf24f+'ms'),this['scheduleConnect_'](_0x3bf24f),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x5d3299=this['onDataMessage_']['bind'](this),_0xf9fe=this['onReady_']['bind'](this),_0x238079=this['onRealtimeDisconnect_']['bind'](this),_0x393a0b=this['id']+':'+se['nextConnectionId_']++,_0x3167b2=this['lastSessionId'];let _0x1adb21=!0x1,_0x43097c=null;const _0x22c567=function(){_0x43097c?_0x43097c['close']():(_0x1adb21=!0x0,_0x238079());},_0x17f6d7=function(_0x40571e){f(_0x43097c,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x43097c['sendRequest'](_0x40571e);};this['realtime_']={'close':_0x22c567,'sendRequest':_0x17f6d7};const _0x3143e1=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x3c87b0,_0x59661d]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x3143e1),this['appCheckTokenProvider_']['getToken'](_0x3143e1)]);_0x1adb21?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x3c87b0&&_0x3c87b0['accessToken'],this['appCheckToken_']=_0x59661d&&_0x59661d['token'],_0x43097c=new Sh(_0x393a0b,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x5d3299,_0xf9fe,_0x238079,_0x207fa0=>{U(_0x207fa0+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x3167b2));}catch(_0x35a9e8){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x35a9e8),_0x1adb21||(this['repoInfo_']['nodeAdmin']&&U(_0x35a9e8),_0x22c567());}}}['interrupt'](_0x237c5a){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x237c5a),this['interruptReasons_'][_0x237c5a]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x330483){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x330483),delete this['interruptReasons_'][_0x330483],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x5aa997){const _0x529534=_0x5aa997-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x529534});}['cancelSentTransactions_'](){for(let _0x4966a3=0x0;_0x4966a3<this['outstandingPuts_']['length'];_0x4966a3++){const _0x3acd9a=this['outstandingPuts_'][_0x4966a3];_0x3acd9a&&'h'in _0x3acd9a['request']&&_0x3acd9a['queued']&&(_0x3acd9a['onComplete']&&_0x3acd9a['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x4966a3],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x4b3de6,_0x406588){let _0x577ea3;_0x406588?_0x577ea3=_0x406588['map'](_0x4891e2=>$i(_0x4891e2))['join']('$'):_0x577ea3='default';const _0x48cc15=this['removeListen_'](_0x4b3de6,_0x577ea3);_0x48cc15&&_0x48cc15['onComplete']&&_0x48cc15['onComplete']('permission_denied');}['removeListen_'](_0x595b30,_0x553426){const _0x1b232a=new C(_0x595b30)['toString']();let _0x1cac1f;if(this['listens']['has'](_0x1b232a)){const _0x2211fc=this['listens']['get'](_0x1b232a);_0x1cac1f=_0x2211fc['get'](_0x553426),_0x2211fc['delete'](_0x553426),_0x2211fc['size']===0x0&&this['listens']['delete'](_0x1b232a);}else _0x1cac1f=void 0x0;return _0x1cac1f;}['onAuthRevoked_'](_0x38cdf3,_0x5675d1){L('Auth\x20token\x20revoked:\x20'+_0x38cdf3+'/'+_0x5675d1),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x38cdf3==='invalid_token'||_0x38cdf3==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x3a9677,_0x16754b){L('App\x20check\x20token\x20revoked:\x20'+_0x3a9677+'/'+_0x16754b),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x3a9677==='invalid_token'||_0x3a9677==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x23fe23){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x23fe23):'msg'in _0x23fe23&&console['log']('FIREBASE:\x20'+_0x23fe23['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x2ae42 of this['listens']['values']())for(const _0x19104a of _0x2ae42['values']())this['sendListen_'](_0x19104a);for(let _0x1a00fd=0x0;_0x1a00fd<this['outstandingPuts_']['length'];_0x1a00fd++)this['outstandingPuts_'][_0x1a00fd]&&this['sendPut_'](_0x1a00fd);for(;this['onDisconnectRequestQueue_']['length'];){const _0x154159=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x154159['action'],_0x154159['pathString'],_0x154159['data'],_0x154159['onComplete']);}for(let _0x4b10b2=0x0;_0x4b10b2<this['outstandingGets_']['length'];_0x4b10b2++)this['outstandingGets_'][_0x4b10b2]&&this['sendGet_'](_0x4b10b2);}['sendConnectStats_'](){const _0x5e5980={};let _0x1d2a4a='js';_0x5e5980['sdk.'+_0x1d2a4a+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x5e5980['framework.cordova']=0x1:Kr()&&(_0x5e5980['framework.reactnative']=0x1),this['reportStats'](_0x5e5980);}['shouldReconnect_'](){const _0xa9196a=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0xa9196a;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x8fd97e,_0x194670){this['name']=_0x8fd97e,this['node']=_0x194670;}static['Wrap'](_0x1f9370,_0x9088cc){return new E(_0x1f9370,_0x9088cc);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x6a402e,_0x2af44d){const _0x3a9d5b=new E(We,_0x6a402e),_0x3d4ceb=new E(We,_0x2af44d);return this['compare'](_0x3a9d5b,_0x3d4ceb)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x135aed){sn=_0x135aed;}['compare'](_0x516eca,_0x1f6b5d){return qe(_0x516eca['name'],_0x1f6b5d['name']);}['isDefinedOn'](_0x251530){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x1f1a5c,_0x4ba997){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x309874,_0x4b3ae7){return f(typeof _0x309874=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x309874,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0xce2290,_0x579442,_0x2b95c7,_0xf56705,_0x48507a=null){this['isReverse_']=_0xf56705,this['resultGenerator_']=_0x48507a,this['nodeStack_']=[];let _0x232190=0x1;for(;!_0xce2290['isEmpty']();)if(_0xce2290=_0xce2290,_0x232190=_0x579442?_0x2b95c7(_0xce2290['key'],_0x579442):0x1,_0xf56705&&(_0x232190*=-0x1),_0x232190<0x0)this['isReverse_']?_0xce2290=_0xce2290['left']:_0xce2290=_0xce2290['right'];else{if(_0x232190===0x0){this['nodeStack_']['push'](_0xce2290);break;}else this['nodeStack_']['push'](_0xce2290),this['isReverse_']?_0xce2290=_0xce2290['right']:_0xce2290=_0xce2290['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0xe8ca0d=this['nodeStack_']['pop'](),_0x2b7472;if(this['resultGenerator_']?_0x2b7472=this['resultGenerator_'](_0xe8ca0d['key'],_0xe8ca0d['value']):_0x2b7472={'key':_0xe8ca0d['key'],'value':_0xe8ca0d['value']},this['isReverse_']){for(_0xe8ca0d=_0xe8ca0d['left'];!_0xe8ca0d['isEmpty']();)this['nodeStack_']['push'](_0xe8ca0d),_0xe8ca0d=_0xe8ca0d['right'];}else{for(_0xe8ca0d=_0xe8ca0d['right'];!_0xe8ca0d['isEmpty']();)this['nodeStack_']['push'](_0xe8ca0d),_0xe8ca0d=_0xe8ca0d['left'];}return _0x2b7472;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x1b4284=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x1b4284['key'],_0x1b4284['value']):{'key':_0x1b4284['key'],'value':_0x1b4284['value']};}}class M{constructor(_0x3062b3,_0x2024ce,_0x18a99a,_0x5539a1,_0xbb046d){this['key']=_0x3062b3,this['value']=_0x2024ce,this['color']=_0x18a99a??M['RED'],this['left']=_0x5539a1??B['EMPTY_NODE'],this['right']=_0xbb046d??B['EMPTY_NODE'];}['copy'](_0x1a14be,_0x485806,_0x1e2b36,_0x4ea1f1,_0x3b7315){return new M(_0x1a14be??this['key'],_0x485806??this['value'],_0x1e2b36??this['color'],_0x4ea1f1??this['left'],_0x3b7315??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x32d52b){return this['left']['inorderTraversal'](_0x32d52b)||!!_0x32d52b(this['key'],this['value'])||this['right']['inorderTraversal'](_0x32d52b);}['reverseTraversal'](_0x43b219){return this['right']['reverseTraversal'](_0x43b219)||_0x43b219(this['key'],this['value'])||this['left']['reverseTraversal'](_0x43b219);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0xda253a,_0x1d5c84,_0x104520){let _0x54a2b3=this;const _0x2e7b32=_0x104520(_0xda253a,_0x54a2b3['key']);return _0x2e7b32<0x0?_0x54a2b3=_0x54a2b3['copy'](null,null,null,_0x54a2b3['left']['insert'](_0xda253a,_0x1d5c84,_0x104520),null):_0x2e7b32===0x0?_0x54a2b3=_0x54a2b3['copy'](null,_0x1d5c84,null,null,null):_0x54a2b3=_0x54a2b3['copy'](null,null,null,null,_0x54a2b3['right']['insert'](_0xda253a,_0x1d5c84,_0x104520)),_0x54a2b3['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x315cad=this;return!_0x315cad['left']['isRed_']()&&!_0x315cad['left']['left']['isRed_']()&&(_0x315cad=_0x315cad['moveRedLeft_']()),_0x315cad=_0x315cad['copy'](null,null,null,_0x315cad['left']['removeMin_'](),null),_0x315cad['fixUp_']();}['remove'](_0x39a3a7,_0x3054ca){let _0x18e7a5,_0x2e75eb;if(_0x18e7a5=this,_0x3054ca(_0x39a3a7,_0x18e7a5['key'])<0x0)!_0x18e7a5['left']['isEmpty']()&&!_0x18e7a5['left']['isRed_']()&&!_0x18e7a5['left']['left']['isRed_']()&&(_0x18e7a5=_0x18e7a5['moveRedLeft_']()),_0x18e7a5=_0x18e7a5['copy'](null,null,null,_0x18e7a5['left']['remove'](_0x39a3a7,_0x3054ca),null);else{if(_0x18e7a5['left']['isRed_']()&&(_0x18e7a5=_0x18e7a5['rotateRight_']()),!_0x18e7a5['right']['isEmpty']()&&!_0x18e7a5['right']['isRed_']()&&!_0x18e7a5['right']['left']['isRed_']()&&(_0x18e7a5=_0x18e7a5['moveRedRight_']()),_0x3054ca(_0x39a3a7,_0x18e7a5['key'])===0x0){if(_0x18e7a5['right']['isEmpty']())return B['EMPTY_NODE'];_0x2e75eb=_0x18e7a5['right']['min_'](),_0x18e7a5=_0x18e7a5['copy'](_0x2e75eb['key'],_0x2e75eb['value'],null,null,_0x18e7a5['right']['removeMin_']());}_0x18e7a5=_0x18e7a5['copy'](null,null,null,null,_0x18e7a5['right']['remove'](_0x39a3a7,_0x3054ca));}return _0x18e7a5['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x322942=this;return _0x322942['right']['isRed_']()&&!_0x322942['left']['isRed_']()&&(_0x322942=_0x322942['rotateLeft_']()),_0x322942['left']['isRed_']()&&_0x322942['left']['left']['isRed_']()&&(_0x322942=_0x322942['rotateRight_']()),_0x322942['left']['isRed_']()&&_0x322942['right']['isRed_']()&&(_0x322942=_0x322942['colorFlip_']()),_0x322942;}['moveRedLeft_'](){let _0x41f651=this['colorFlip_']();return _0x41f651['right']['left']['isRed_']()&&(_0x41f651=_0x41f651['copy'](null,null,null,null,_0x41f651['right']['rotateRight_']()),_0x41f651=_0x41f651['rotateLeft_'](),_0x41f651=_0x41f651['colorFlip_']()),_0x41f651;}['moveRedRight_'](){let _0x24fc51=this['colorFlip_']();return _0x24fc51['left']['left']['isRed_']()&&(_0x24fc51=_0x24fc51['rotateRight_'](),_0x24fc51=_0x24fc51['colorFlip_']()),_0x24fc51;}['rotateLeft_'](){const _0x42d0ec=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x42d0ec,null);}['rotateRight_'](){const _0xbbb225=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0xbbb225);}['colorFlip_'](){const _0x1c7840=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x2cd5b9=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x1c7840,_0x2cd5b9);}['checkMaxDepth_'](){const _0x1ee0bd=this['check_']();return Math['pow'](0x2,_0x1ee0bd)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x4f6ff2=this['left']['check_']();if(_0x4f6ff2!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x4f6ff2+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x52d50f,_0x3c92f3,_0x464910,_0x19033b,_0x2d5f59){return this;}['insert'](_0x138d24,_0x8da3d8,_0x5664b1){return new M(_0x138d24,_0x8da3d8,null);}['remove'](_0x594e4c,_0x347598){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x849f1d){return!0x1;}['reverseTraversal'](_0xfdf7b1){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x502335,_0x501573=B['EMPTY_NODE']){this['comparator_']=_0x502335,this['root_']=_0x501573;}['insert'](_0x50f27b,_0x2b6dcd){return new B(this['comparator_'],this['root_']['insert'](_0x50f27b,_0x2b6dcd,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x37202a){return new B(this['comparator_'],this['root_']['remove'](_0x37202a,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x5cddf1){let _0x5ec4b5,_0x547666=this['root_'];for(;!_0x547666['isEmpty']();){if(_0x5ec4b5=this['comparator_'](_0x5cddf1,_0x547666['key']),_0x5ec4b5===0x0)return _0x547666['value'];_0x5ec4b5<0x0?_0x547666=_0x547666['left']:_0x5ec4b5>0x0&&(_0x547666=_0x547666['right']);}return null;}['getPredecessorKey'](_0x4bbaec){let _0x216815,_0x588105=this['root_'],_0x477a9f=null;for(;!_0x588105['isEmpty']();)if(_0x216815=this['comparator_'](_0x4bbaec,_0x588105['key']),_0x216815===0x0){if(_0x588105['left']['isEmpty']())return _0x477a9f?_0x477a9f['key']:null;for(_0x588105=_0x588105['left'];!_0x588105['right']['isEmpty']();)_0x588105=_0x588105['right'];return _0x588105['key'];}else _0x216815<0x0?_0x588105=_0x588105['left']:_0x216815>0x0&&(_0x477a9f=_0x588105,_0x588105=_0x588105['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x418746){return this['root_']['inorderTraversal'](_0x418746);}['reverseTraversal'](_0x1290d8){return this['root_']['reverseTraversal'](_0x1290d8);}['getIterator'](_0x3d6458){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x3d6458);}['getIteratorFrom'](_0x413892,_0x101cec){return new rn(this['root_'],_0x413892,this['comparator_'],!0x1,_0x101cec);}['getReverseIteratorFrom'](_0xbb8401,_0x44245e){return new rn(this['root_'],_0xbb8401,this['comparator_'],!0x0,_0x44245e);}['getReverseIterator'](_0x20d0b7){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x20d0b7);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x2911ac,_0x575a24){return qe(_0x2911ac['name'],_0x575a24['name']);}function Qi(_0x34e5d4,_0x1d4c0c){return qe(_0x34e5d4,_0x1d4c0c);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0xb9eb8a){Ci=_0xb9eb8a;}const Po=function(_0x286021){return typeof _0x286021=='number'?'number:'+ao(_0x286021):'string:'+_0x286021;},No=function(_0x24ff07){if(_0x24ff07['isLeafNode']()){const _0x318d3b=_0x24ff07['val']();f(typeof _0x318d3b=='string'||typeof _0x318d3b=='number'||typeof _0x318d3b=='object'&&Q(_0x318d3b,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x24ff07===Ci||_0x24ff07['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x24ff07===Ci||_0x24ff07['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x23d88a){nr=_0x23d88a;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x32c5cc,_0x355b45=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x32c5cc,this['priorityNode_']=_0x355b45,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x3bc11d){return new D(this['value_'],_0x3bc11d);}['getImmediateChild'](_0x3e53ee){return _0x3e53ee==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x4c9c69){return v(_0x4c9c69)?this:y(_0x4c9c69)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x367082,_0x81c335){return null;}['updateImmediateChild'](_0x25c510,_0x3f80e5){return _0x25c510==='.priority'?this['updatePriority'](_0x3f80e5):_0x3f80e5['isEmpty']()&&_0x25c510!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x25c510,_0x3f80e5)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x203813,_0xa94921){const _0xa1c95f=y(_0x203813);return _0xa1c95f===null?_0xa94921:_0xa94921['isEmpty']()&&_0xa1c95f!=='.priority'?this:(f(_0xa1c95f!=='.priority'||Ce(_0x203813)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0xa1c95f,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x203813),_0xa94921)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x2ee8ce,_0x5762f9){return!0x1;}['val'](_0x1ad7a1){return _0x1ad7a1&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x33bc87='';this['priorityNode_']['isEmpty']()||(_0x33bc87+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x296dd5=typeof this['value_'];_0x33bc87+=_0x296dd5+':',_0x296dd5==='number'?_0x33bc87+=ao(this['value_']):_0x33bc87+=this['value_'],this['lazyHash_']=ro(_0x33bc87);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x27bf6d){return _0x27bf6d===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x27bf6d instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x27bf6d['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x27bf6d));}['compareToLeafNode_'](_0x195b1f){const _0x1a54ef=typeof _0x195b1f['value_'],_0x1eea5c=typeof this['value_'],_0x319086=D['VALUE_TYPE_ORDER']['indexOf'](_0x1a54ef),_0x26b49f=D['VALUE_TYPE_ORDER']['indexOf'](_0x1eea5c);return f(_0x319086>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x1a54ef),f(_0x26b49f>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x1eea5c),_0x319086===_0x26b49f?_0x1eea5c==='object'?0x0:this['value_']<_0x195b1f['value_']?-0x1:this['value_']===_0x195b1f['value_']?0x0:0x1:_0x26b49f-_0x319086;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x4dbe84){if(_0x4dbe84===this)return!0x0;if(_0x4dbe84['isLeafNode']()){const _0x41fd44=_0x4dbe84;return this['value_']===_0x41fd44['value_']&&this['priorityNode_']['equals'](_0x41fd44['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x16e2fc){Oo=_0x16e2fc;}function Wh(_0x2df558){Do=_0x2df558;}class Bh extends Fn{['compare'](_0x3afa26,_0x8a6b14){const _0x54b688=_0x3afa26['node']['getPriority'](),_0x29f63a=_0x8a6b14['node']['getPriority'](),_0xab1be6=_0x54b688['compareTo'](_0x29f63a);return _0xab1be6===0x0?qe(_0x3afa26['name'],_0x8a6b14['name']):_0xab1be6;}['isDefinedOn'](_0x54b713){return!_0x54b713['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x5ca4e3,_0x1d86cd){return!_0x5ca4e3['getPriority']()['equals'](_0x1d86cd['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0xf1c5f7,_0x5c0e1e){const _0x5c24be=Oo(_0xf1c5f7);return new E(_0x5c0e1e,new D('[PRIORITY-POST]',_0x5c24be));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x400cf8){const _0x1da3df=_0x5edee7=>parseInt(Math['log'](_0x5edee7)/Vh,0xa),_0x5aa22d=_0xc06c19=>parseInt(Array(_0xc06c19+0x1)['join']('1'),0x2);this['count']=_0x1da3df(_0x400cf8+0x1),this['current_']=this['count']-0x1;const _0x42929a=_0x5aa22d(this['count']);this['bits_']=_0x400cf8+0x1&_0x42929a;}['nextBitIsOne'](){const _0x3fef2d=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x3fef2d;}}const yn=function(_0x4bf951,_0x360cf8,_0x20033a,_0x5b6b8b){_0x4bf951['sort'](_0x360cf8);const _0xe2f782=function(_0x59c60f,_0x1d4e3d){const _0x200cdf=_0x1d4e3d-_0x59c60f;let _0xfd2d63,_0x46184a;if(_0x200cdf===0x0)return null;if(_0x200cdf===0x1)return _0xfd2d63=_0x4bf951[_0x59c60f],_0x46184a=_0x20033a?_0x20033a(_0xfd2d63):_0xfd2d63,new M(_0x46184a,_0xfd2d63['node'],M['BLACK'],null,null);{const _0x444bc9=parseInt(_0x200cdf/0x2,0xa)+_0x59c60f,_0x2e925b=_0xe2f782(_0x59c60f,_0x444bc9),_0x35511a=_0xe2f782(_0x444bc9+0x1,_0x1d4e3d);return _0xfd2d63=_0x4bf951[_0x444bc9],_0x46184a=_0x20033a?_0x20033a(_0xfd2d63):_0xfd2d63,new M(_0x46184a,_0xfd2d63['node'],M['BLACK'],_0x2e925b,_0x35511a);}},_0x238ffd=function(_0x2d903e){let _0x225b93=null,_0x3f498a=null,_0x456e75=_0x4bf951['length'];const _0x4af5e8=function(_0x2f8e62,_0x58bf68){const _0x3f0e5d=_0x456e75-_0x2f8e62,_0x4ed7bc=_0x456e75;_0x456e75-=_0x2f8e62;const _0x7db920=_0xe2f782(_0x3f0e5d+0x1,_0x4ed7bc),_0x1d068e=_0x4bf951[_0x3f0e5d],_0x27ebc6=_0x20033a?_0x20033a(_0x1d068e):_0x1d068e;_0x86bd68(new M(_0x27ebc6,_0x1d068e['node'],_0x58bf68,null,_0x7db920));},_0x86bd68=function(_0x5011b5){_0x225b93?(_0x225b93['left']=_0x5011b5,_0x225b93=_0x5011b5):(_0x3f498a=_0x5011b5,_0x225b93=_0x5011b5);};for(let _0x1c0a05=0x0;_0x1c0a05<_0x2d903e['count'];++_0x1c0a05){const _0x51b7a3=_0x2d903e['nextBitIsOne'](),_0x111eb6=Math['pow'](0x2,_0x2d903e['count']-(_0x1c0a05+0x1));_0x51b7a3?_0x4af5e8(_0x111eb6,M['BLACK']):(_0x4af5e8(_0x111eb6,M['BLACK']),_0x4af5e8(_0x111eb6,M['RED']));}return _0x3f498a;},_0x31c186=new Hh(_0x4bf951['length']),_0x4d9f93=_0x238ffd(_0x31c186);return new B(_0x5b6b8b||_0x360cf8,_0x4d9f93);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x495b90,_0x2e2397){this['indexes_']=_0x495b90,this['indexSet_']=_0x2e2397;}['get'](_0x2878e0){const _0x44604b=Le(this['indexes_'],_0x2878e0);if(!_0x44604b)throw new Error('No\x20index\x20defined\x20for\x20'+_0x2878e0);return _0x44604b instanceof B?_0x44604b:null;}['hasIndex'](_0x25a243){return Q(this['indexSet_'],_0x25a243['toString']());}['addIndex'](_0x36d0ae,_0x474e6a){f(_0x36d0ae!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x2f2dfb=[];let _0x1eae76=!0x1;const _0x2db32b=_0x474e6a['getIterator'](E['Wrap']);let _0xc7eb0=_0x2db32b['getNext']();for(;_0xc7eb0;)_0x1eae76=_0x1eae76||_0x36d0ae['isDefinedOn'](_0xc7eb0['node']),_0x2f2dfb['push'](_0xc7eb0),_0xc7eb0=_0x2db32b['getNext']();let _0x5d20e8;_0x1eae76?_0x5d20e8=yn(_0x2f2dfb,_0x36d0ae['getCompare']()):_0x5d20e8=Qe;const _0x196281=_0x36d0ae['toString'](),_0x3b1684={...this['indexSet_']};_0x3b1684[_0x196281]=_0x36d0ae;const _0x1014ad={...this['indexes_']};return _0x1014ad[_0x196281]=_0x5d20e8,new te(_0x1014ad,_0x3b1684);}['addToIndexes'](_0x24e0af,_0x5e23c5){const _0x559f87=_n(this['indexes_'],(_0x1bb4be,_0x563df8)=>{const _0x2564f3=Le(this['indexSet_'],_0x563df8);if(f(_0x2564f3,'Missing\x20index\x20implementation\x20for\x20'+_0x563df8),_0x1bb4be===Qe){if(_0x2564f3['isDefinedOn'](_0x24e0af['node'])){const _0x396d04=[],_0x24aba1=_0x5e23c5['getIterator'](E['Wrap']);let _0x3157b5=_0x24aba1['getNext']();for(;_0x3157b5;)_0x3157b5['name']!==_0x24e0af['name']&&_0x396d04['push'](_0x3157b5),_0x3157b5=_0x24aba1['getNext']();return _0x396d04['push'](_0x24e0af),yn(_0x396d04,_0x2564f3['getCompare']());}else return Qe;}else{const _0x24af07=_0x5e23c5['get'](_0x24e0af['name']);let _0x4ff914=_0x1bb4be;return _0x24af07&&(_0x4ff914=_0x4ff914['remove'](new E(_0x24e0af['name'],_0x24af07))),_0x4ff914['insert'](_0x24e0af,_0x24e0af['node']);}});return new te(_0x559f87,this['indexSet_']);}['removeFromIndexes'](_0x4110ca,_0xb0003d){const _0x3d366e=_n(this['indexes_'],_0x14a173=>{if(_0x14a173===Qe)return _0x14a173;{const _0x2cb955=_0xb0003d['get'](_0x4110ca['name']);return _0x2cb955?_0x14a173['remove'](new E(_0x4110ca['name'],_0x2cb955)):_0x14a173;}});return new te(_0x3d366e,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x3855f7,_0x15fd17,_0x1dbdaf){this['children_']=_0x3855f7,this['priorityNode_']=_0x15fd17,this['indexMap_']=_0x1dbdaf,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x4c6657){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x4c6657,this['indexMap_']);}['getImmediateChild'](_0x41cc88){if(_0x41cc88==='.priority')return this['getPriority']();{const _0x31ff9=this['children_']['get'](_0x41cc88);return _0x31ff9===null?It:_0x31ff9;}}['getChild'](_0x40ed1a){const _0x266894=y(_0x40ed1a);return _0x266894===null?this:this['getImmediateChild'](_0x266894)['getChild'](S(_0x40ed1a));}['hasChild'](_0x36d63b){return this['children_']['get'](_0x36d63b)!==null;}['updateImmediateChild'](_0xeab2eb,_0x3e2bb8){if(f(_0x3e2bb8,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0xeab2eb==='.priority')return this['updatePriority'](_0x3e2bb8);{const _0x417732=new E(_0xeab2eb,_0x3e2bb8);let _0x330432,_0x516f3a;_0x3e2bb8['isEmpty']()?(_0x330432=this['children_']['remove'](_0xeab2eb),_0x516f3a=this['indexMap_']['removeFromIndexes'](_0x417732,this['children_'])):(_0x330432=this['children_']['insert'](_0xeab2eb,_0x3e2bb8),_0x516f3a=this['indexMap_']['addToIndexes'](_0x417732,this['children_']));const _0x509ed3=_0x330432['isEmpty']()?It:this['priorityNode_'];return new g(_0x330432,_0x509ed3,_0x516f3a);}}['updateChild'](_0x2fb61f,_0x2d55c1){const _0x6ff41e=y(_0x2fb61f);if(_0x6ff41e===null)return _0x2d55c1;{f(y(_0x2fb61f)!=='.priority'||Ce(_0x2fb61f)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x51f6f1=this['getImmediateChild'](_0x6ff41e)['updateChild'](S(_0x2fb61f),_0x2d55c1);return this['updateImmediateChild'](_0x6ff41e,_0x51f6f1);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x3eb73b){if(this['isEmpty']())return null;const _0x28c637={};let _0x486fc0=0x0,_0x4248af=0x0,_0x407b23=!0x0;if(this['forEachChild'](R,(_0x1dab2d,_0x1e3e7a)=>{_0x28c637[_0x1dab2d]=_0x1e3e7a['val'](_0x3eb73b),_0x486fc0++,_0x407b23&&g['INTEGER_REGEXP_']['test'](_0x1dab2d)?_0x4248af=Math['max'](_0x4248af,Number(_0x1dab2d)):_0x407b23=!0x1;}),!_0x3eb73b&&_0x407b23&&_0x4248af<0x2*_0x486fc0){const _0x529d63=[];for(const _0x1fed21 in _0x28c637)_0x529d63[_0x1fed21]=_0x28c637[_0x1fed21];return _0x529d63;}else return _0x3eb73b&&!this['getPriority']()['isEmpty']()&&(_0x28c637['.priority']=this['getPriority']()['val']()),_0x28c637;}['hash'](){if(this['lazyHash_']===null){let _0x535287='';this['getPriority']()['isEmpty']()||(_0x535287+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x4e6509,_0x4e9cc4)=>{const _0x913294=_0x4e9cc4['hash']();_0x913294!==''&&(_0x535287+=':'+_0x4e6509+':'+_0x913294);}),this['lazyHash_']=_0x535287===''?'':ro(_0x535287);}return this['lazyHash_'];}['getPredecessorChildName'](_0xdf1a6e,_0x382bf7,_0x433e03){const _0x3a895e=this['resolveIndex_'](_0x433e03);if(_0x3a895e){const _0xf109fb=_0x3a895e['getPredecessorKey'](new E(_0xdf1a6e,_0x382bf7));return _0xf109fb?_0xf109fb['name']:null;}else return this['children_']['getPredecessorKey'](_0xdf1a6e);}['getFirstChildName'](_0x20e623){const _0x201062=this['resolveIndex_'](_0x20e623);if(_0x201062){const _0x40ddcb=_0x201062['minKey']();return _0x40ddcb&&_0x40ddcb['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x23f2df){const _0x5b54ea=this['getFirstChildName'](_0x23f2df);return _0x5b54ea?new E(_0x5b54ea,this['children_']['get'](_0x5b54ea)):null;}['getLastChildName'](_0x3cdc77){const _0x257d84=this['resolveIndex_'](_0x3cdc77);if(_0x257d84){const _0x204161=_0x257d84['maxKey']();return _0x204161&&_0x204161['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x2a8ede){const _0x63616e=this['getLastChildName'](_0x2a8ede);return _0x63616e?new E(_0x63616e,this['children_']['get'](_0x63616e)):null;}['forEachChild'](_0x3f22c8,_0x155f58){const _0x2ebcbd=this['resolveIndex_'](_0x3f22c8);return _0x2ebcbd?_0x2ebcbd['inorderTraversal'](_0x4254fa=>_0x155f58(_0x4254fa['name'],_0x4254fa['node'])):this['children_']['inorderTraversal'](_0x155f58);}['getIterator'](_0x5a4f18){return this['getIteratorFrom'](_0x5a4f18['minPost'](),_0x5a4f18);}['getIteratorFrom'](_0x4b96b3,_0x563a37){const _0xddb7b8=this['resolveIndex_'](_0x563a37);if(_0xddb7b8)return _0xddb7b8['getIteratorFrom'](_0x4b96b3,_0x518cce=>_0x518cce);{const _0x18f127=this['children_']['getIteratorFrom'](_0x4b96b3['name'],E['Wrap']);let _0xf69f1a=_0x18f127['peek']();for(;_0xf69f1a!=null&&_0x563a37['compare'](_0xf69f1a,_0x4b96b3)<0x0;)_0x18f127['getNext'](),_0xf69f1a=_0x18f127['peek']();return _0x18f127;}}['getReverseIterator'](_0x226303){return this['getReverseIteratorFrom'](_0x226303['maxPost'](),_0x226303);}['getReverseIteratorFrom'](_0x1c7d75,_0x28def1){const _0x288fcb=this['resolveIndex_'](_0x28def1);if(_0x288fcb)return _0x288fcb['getReverseIteratorFrom'](_0x1c7d75,_0x417bbd=>_0x417bbd);{const _0x1ebcab=this['children_']['getReverseIteratorFrom'](_0x1c7d75['name'],E['Wrap']);let _0x3c8233=_0x1ebcab['peek']();for(;_0x3c8233!=null&&_0x28def1['compare'](_0x3c8233,_0x1c7d75)>0x0;)_0x1ebcab['getNext'](),_0x3c8233=_0x1ebcab['peek']();return _0x1ebcab;}}['compareTo'](_0x4944d1){return this['isEmpty']()?_0x4944d1['isEmpty']()?0x0:-0x1:_0x4944d1['isLeafNode']()||_0x4944d1['isEmpty']()?0x1:_0x4944d1===Kt?-0x1:0x0;}['withIndex'](_0x3a61cf){if(_0x3a61cf===ve||this['indexMap_']['hasIndex'](_0x3a61cf))return this;{const _0x162595=this['indexMap_']['addIndex'](_0x3a61cf,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x162595);}}['isIndexed'](_0x1a76ab){return _0x1a76ab===ve||this['indexMap_']['hasIndex'](_0x1a76ab);}['equals'](_0x1d2276){if(_0x1d2276===this)return!0x0;if(_0x1d2276['isLeafNode']())return!0x1;{const _0x45d262=_0x1d2276;if(this['getPriority']()['equals'](_0x45d262['getPriority']())){if(this['children_']['count']()===_0x45d262['children_']['count']()){const _0x4f6173=this['getIterator'](R),_0x59c8e7=_0x45d262['getIterator'](R);let _0xafad06=_0x4f6173['getNext'](),_0x1e5084=_0x59c8e7['getNext']();for(;_0xafad06&&_0x1e5084;){if(_0xafad06['name']!==_0x1e5084['name']||!_0xafad06['node']['equals'](_0x1e5084['node']))return!0x1;_0xafad06=_0x4f6173['getNext'](),_0x1e5084=_0x59c8e7['getNext']();}return _0xafad06===null&&_0x1e5084===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x2e44ab){return _0x2e44ab===ve?null:this['indexMap_']['get'](_0x2e44ab['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x3f6d15){return _0x3f6d15===this?0x0:0x1;}['equals'](_0x5dbc22){return _0x5dbc22===this;}['getPriority'](){return this;}['getImmediateChild'](_0x1e5b84){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x1b7040,_0x3d7cbf=null){if(_0x1b7040===null)return g['EMPTY_NODE'];if(typeof _0x1b7040=='object'&&'.priority'in _0x1b7040&&(_0x3d7cbf=_0x1b7040['.priority']),f(_0x3d7cbf===null||typeof _0x3d7cbf=='string'||typeof _0x3d7cbf=='number'||typeof _0x3d7cbf=='object'&&'.sv'in _0x3d7cbf,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x3d7cbf),typeof _0x1b7040=='object'&&'.value'in _0x1b7040&&_0x1b7040['.value']!==null&&(_0x1b7040=_0x1b7040['.value']),typeof _0x1b7040!='object'||'.sv'in _0x1b7040){const _0x2b78db=_0x1b7040;return new D(_0x2b78db,A(_0x3d7cbf));}if(!(_0x1b7040 instanceof Array)&&Gh){const _0x59f20e=[];let _0x58f00f=!0x1;if(x(_0x1b7040,(_0x352cf6,_0x143f13)=>{if(_0x352cf6['substring'](0x0,0x1)!=='.'){const _0x34abdc=A(_0x143f13);_0x34abdc['isEmpty']()||(_0x58f00f=_0x58f00f||!_0x34abdc['getPriority']()['isEmpty'](),_0x59f20e['push'](new E(_0x352cf6,_0x34abdc)));}}),_0x59f20e['length']===0x0)return g['EMPTY_NODE'];const _0x71886b=yn(_0x59f20e,xh,_0x5e5d61=>_0x5e5d61['name'],Qi);if(_0x58f00f){const _0x3b7348=yn(_0x59f20e,R['getCompare']());return new g(_0x71886b,A(_0x3d7cbf),new te({'.priority':_0x3b7348},{'.priority':R}));}else return new g(_0x71886b,A(_0x3d7cbf),te['Default']);}else{let _0xd12426=g['EMPTY_NODE'];return x(_0x1b7040,(_0x507c8a,_0x5215d1)=>{if(Q(_0x1b7040,_0x507c8a)&&_0x507c8a['substring'](0x0,0x1)!=='.'){const _0x3cbb7c=A(_0x5215d1);(_0x3cbb7c['isLeafNode']()||!_0x3cbb7c['isEmpty']())&&(_0xd12426=_0xd12426['updateImmediateChild'](_0x507c8a,_0x3cbb7c));}}),_0xd12426['updatePriority'](A(_0x3d7cbf));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x15269d){super(),this['indexPath_']=_0x15269d,f(!v(_0x15269d)&&y(_0x15269d)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x199e01){return _0x199e01['getChild'](this['indexPath_']);}['isDefinedOn'](_0x3dc687){return!_0x3dc687['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x28f80d,_0x49d26e){const _0x58a20f=this['extractChild'](_0x28f80d['node']),_0x3bb345=this['extractChild'](_0x49d26e['node']),_0x28518c=_0x58a20f['compareTo'](_0x3bb345);return _0x28518c===0x0?qe(_0x28f80d['name'],_0x49d26e['name']):_0x28518c;}['makePost'](_0x578996,_0x5dd42f){const _0x403452=A(_0x578996),_0x4b2bf=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x403452);return new E(_0x5dd42f,_0x4b2bf);}['maxPost'](){const _0x4f3962=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x4f3962);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x538fc5,_0x570b59){const _0x4bbf11=_0x538fc5['node']['compareTo'](_0x570b59['node']);return _0x4bbf11===0x0?qe(_0x538fc5['name'],_0x570b59['name']):_0x4bbf11;}['isDefinedOn'](_0xb4603e){return!0x0;}['indexedValueChanged'](_0x29aa26,_0x1fdf3a){return!_0x29aa26['equals'](_0x1fdf3a);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x379651,_0x495efb){const _0x563614=A(_0x379651);return new E(_0x495efb,_0x563614);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x3fbdb0){return{'type':'value','snapshotNode':_0x3fbdb0};}function rt(_0x351f11,_0x267dcd){return{'type':'child_added','snapshotNode':_0x267dcd,'childName':_0x351f11};}function Lt(_0x5c6218,_0x2a53e9){return{'type':'child_removed','snapshotNode':_0x2a53e9,'childName':_0x5c6218};}function xt(_0x2f4025,_0x51b673,_0x75ff04){return{'type':'child_changed','snapshotNode':_0x51b673,'childName':_0x2f4025,'oldSnap':_0x75ff04};}function zh(_0x4968f7,_0x4f80ed){return{'type':'child_moved','snapshotNode':_0x4f80ed,'childName':_0x4968f7};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x506662){this['index_']=_0x506662;}['updateChild'](_0x151245,_0xcabf70,_0x54b5fd,_0x533dd2,_0x595e0a,_0x4b726f){f(_0x151245['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x56b11b=_0x151245['getImmediateChild'](_0xcabf70);return _0x56b11b['getChild'](_0x533dd2)['equals'](_0x54b5fd['getChild'](_0x533dd2))&&_0x56b11b['isEmpty']()===_0x54b5fd['isEmpty']()||(_0x4b726f!=null&&(_0x54b5fd['isEmpty']()?_0x151245['hasChild'](_0xcabf70)?_0x4b726f['trackChildChange'](Lt(_0xcabf70,_0x56b11b)):f(_0x151245['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x56b11b['isEmpty']()?_0x4b726f['trackChildChange'](rt(_0xcabf70,_0x54b5fd)):_0x4b726f['trackChildChange'](xt(_0xcabf70,_0x54b5fd,_0x56b11b))),_0x151245['isLeafNode']()&&_0x54b5fd['isEmpty']())?_0x151245:_0x151245['updateImmediateChild'](_0xcabf70,_0x54b5fd)['withIndex'](this['index_']);}['updateFullNode'](_0x1e0be8,_0x53c85a,_0x5dc0d0){return _0x5dc0d0!=null&&(_0x1e0be8['isLeafNode']()||_0x1e0be8['forEachChild'](R,(_0x30c96d,_0x1695cb)=>{_0x53c85a['hasChild'](_0x30c96d)||_0x5dc0d0['trackChildChange'](Lt(_0x30c96d,_0x1695cb));}),_0x53c85a['isLeafNode']()||_0x53c85a['forEachChild'](R,(_0x39a9b8,_0x244929)=>{if(_0x1e0be8['hasChild'](_0x39a9b8)){const _0xc503ec=_0x1e0be8['getImmediateChild'](_0x39a9b8);_0xc503ec['equals'](_0x244929)||_0x5dc0d0['trackChildChange'](xt(_0x39a9b8,_0x244929,_0xc503ec));}else _0x5dc0d0['trackChildChange'](rt(_0x39a9b8,_0x244929));})),_0x53c85a['withIndex'](this['index_']);}['updatePriority'](_0x174b0a,_0x34793b){return _0x174b0a['isEmpty']()?g['EMPTY_NODE']:_0x174b0a['updatePriority'](_0x34793b);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x359815){this['indexedFilter_']=new Xi(_0x359815['getIndex']()),this['index_']=_0x359815['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x359815),this['endPost_']=Ft['getEndPost_'](_0x359815),this['startIsInclusive_']=!_0x359815['startAfterSet_'],this['endIsInclusive_']=!_0x359815['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x22a7f2){const _0xa52ad6=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x22a7f2)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x22a7f2)<0x0,_0x854713=this['endIsInclusive_']?this['index_']['compare'](_0x22a7f2,this['getEndPost']())<=0x0:this['index_']['compare'](_0x22a7f2,this['getEndPost']())<0x0;return _0xa52ad6&&_0x854713;}['updateChild'](_0x5d63b3,_0x109787,_0x596d8d,_0x16e628,_0xfcf60e,_0x13c48b){return this['matches'](new E(_0x109787,_0x596d8d))||(_0x596d8d=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x5d63b3,_0x109787,_0x596d8d,_0x16e628,_0xfcf60e,_0x13c48b);}['updateFullNode'](_0x22d589,_0x53ff61,_0x4f7a91){_0x53ff61['isLeafNode']()&&(_0x53ff61=g['EMPTY_NODE']);let _0x17b809=_0x53ff61['withIndex'](this['index_']);_0x17b809=_0x17b809['updatePriority'](g['EMPTY_NODE']);const _0x4fc0dc=this;return _0x53ff61['forEachChild'](R,(_0x4c0a69,_0x126fcf)=>{_0x4fc0dc['matches'](new E(_0x4c0a69,_0x126fcf))||(_0x17b809=_0x17b809['updateImmediateChild'](_0x4c0a69,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x22d589,_0x17b809,_0x4f7a91);}['updatePriority'](_0x2aafa6,_0x46535c){return _0x2aafa6;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x482b83){if(_0x482b83['hasStart']()){const _0x25f31b=_0x482b83['getIndexStartName']();return _0x482b83['getIndex']()['makePost'](_0x482b83['getIndexStartValue'](),_0x25f31b);}else return _0x482b83['getIndex']()['minPost']();}static['getEndPost_'](_0x278050){if(_0x278050['hasEnd']()){const _0x3aa415=_0x278050['getIndexEndName']();return _0x278050['getIndex']()['makePost'](_0x278050['getIndexEndValue'](),_0x3aa415);}else return _0x278050['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x142936){this['withinDirectionalStart']=_0x486f80=>this['reverse_']?this['withinEndPost'](_0x486f80):this['withinStartPost'](_0x486f80),this['withinDirectionalEnd']=_0x13221c=>this['reverse_']?this['withinStartPost'](_0x13221c):this['withinEndPost'](_0x13221c),this['withinStartPost']=_0x582423=>{const _0x132048=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x582423);return this['startIsInclusive_']?_0x132048<=0x0:_0x132048<0x0;},this['withinEndPost']=_0x1f7078=>{const _0x32fe38=this['index_']['compare'](_0x1f7078,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x32fe38<=0x0:_0x32fe38<0x0;},this['rangedFilter_']=new Ft(_0x142936),this['index_']=_0x142936['getIndex'](),this['limit_']=_0x142936['getLimit'](),this['reverse_']=!_0x142936['isViewFromLeft'](),this['startIsInclusive_']=!_0x142936['startAfterSet_'],this['endIsInclusive_']=!_0x142936['endBeforeSet_'];}['updateChild'](_0x2946c3,_0x6919aa,_0x172d01,_0x55a981,_0x1a6772,_0x26862e){return this['rangedFilter_']['matches'](new E(_0x6919aa,_0x172d01))||(_0x172d01=g['EMPTY_NODE']),_0x2946c3['getImmediateChild'](_0x6919aa)['equals'](_0x172d01)?_0x2946c3:_0x2946c3['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x2946c3,_0x6919aa,_0x172d01,_0x55a981,_0x1a6772,_0x26862e):this['fullLimitUpdateChild_'](_0x2946c3,_0x6919aa,_0x172d01,_0x1a6772,_0x26862e);}['updateFullNode'](_0x1fef6f,_0x421e2d,_0x235c84){let _0x321d03;if(_0x421e2d['isLeafNode']()||_0x421e2d['isEmpty']())_0x321d03=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x421e2d['numChildren']()&&_0x421e2d['isIndexed'](this['index_'])){_0x321d03=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x5d3e27;this['reverse_']?_0x5d3e27=_0x421e2d['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x5d3e27=_0x421e2d['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0xaf8589=0x0;for(;_0x5d3e27['hasNext']()&&_0xaf8589<this['limit_'];){const _0x49b594=_0x5d3e27['getNext']();if(this['withinDirectionalStart'](_0x49b594)){if(this['withinDirectionalEnd'](_0x49b594))_0x321d03=_0x321d03['updateImmediateChild'](_0x49b594['name'],_0x49b594['node']),_0xaf8589++;else break;}else continue;}}else{_0x321d03=_0x421e2d['withIndex'](this['index_']),_0x321d03=_0x321d03['updatePriority'](g['EMPTY_NODE']);let _0x7ccb77;this['reverse_']?_0x7ccb77=_0x321d03['getReverseIterator'](this['index_']):_0x7ccb77=_0x321d03['getIterator'](this['index_']);let _0x3dcfd1=0x0;for(;_0x7ccb77['hasNext']();){const _0x22e996=_0x7ccb77['getNext']();_0x3dcfd1<this['limit_']&&this['withinDirectionalStart'](_0x22e996)&&this['withinDirectionalEnd'](_0x22e996)?_0x3dcfd1++:_0x321d03=_0x321d03['updateImmediateChild'](_0x22e996['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x1fef6f,_0x321d03,_0x235c84);}['updatePriority'](_0x207626,_0x21aea8){return _0x207626;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x27c8c4,_0x355b69,_0x12e8ac,_0x112685,_0x13a99f){let _0x57a0f6;if(this['reverse_']){const _0x12bbbd=this['index_']['getCompare']();_0x57a0f6=(_0x43830c,_0x47f70d)=>_0x12bbbd(_0x47f70d,_0x43830c);}else _0x57a0f6=this['index_']['getCompare']();const _0x155071=_0x27c8c4;f(_0x155071['numChildren']()===this['limit_'],'');const _0x197da5=new E(_0x355b69,_0x12e8ac),_0x4ce709=this['reverse_']?_0x155071['getFirstChild'](this['index_']):_0x155071['getLastChild'](this['index_']),_0x4ea4d7=this['rangedFilter_']['matches'](_0x197da5);if(_0x155071['hasChild'](_0x355b69)){const _0x1a8d31=_0x155071['getImmediateChild'](_0x355b69);let _0x2f34e7=_0x112685['getChildAfterChild'](this['index_'],_0x4ce709,this['reverse_']);for(;_0x2f34e7!=null&&(_0x2f34e7['name']===_0x355b69||_0x155071['hasChild'](_0x2f34e7['name']));)_0x2f34e7=_0x112685['getChildAfterChild'](this['index_'],_0x2f34e7,this['reverse_']);const _0x1101de=_0x2f34e7==null?0x1:_0x57a0f6(_0x2f34e7,_0x197da5);if(_0x4ea4d7&&!_0x12e8ac['isEmpty']()&&_0x1101de>=0x0)return _0x13a99f!=null&&_0x13a99f['trackChildChange'](xt(_0x355b69,_0x12e8ac,_0x1a8d31)),_0x155071['updateImmediateChild'](_0x355b69,_0x12e8ac);{_0x13a99f!=null&&_0x13a99f['trackChildChange'](Lt(_0x355b69,_0x1a8d31));const _0x356164=_0x155071['updateImmediateChild'](_0x355b69,g['EMPTY_NODE']);return _0x2f34e7!=null&&this['rangedFilter_']['matches'](_0x2f34e7)?(_0x13a99f!=null&&_0x13a99f['trackChildChange'](rt(_0x2f34e7['name'],_0x2f34e7['node'])),_0x356164['updateImmediateChild'](_0x2f34e7['name'],_0x2f34e7['node'])):_0x356164;}}else return _0x12e8ac['isEmpty']()?_0x27c8c4:_0x4ea4d7&&_0x57a0f6(_0x4ce709,_0x197da5)>=0x0?(_0x13a99f!=null&&(_0x13a99f['trackChildChange'](Lt(_0x4ce709['name'],_0x4ce709['node'])),_0x13a99f['trackChildChange'](rt(_0x355b69,_0x12e8ac))),_0x155071['updateImmediateChild'](_0x355b69,_0x12e8ac)['updateImmediateChild'](_0x4ce709['name'],g['EMPTY_NODE'])):_0x27c8c4;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x5bdc16=new Zi();return _0x5bdc16['limitSet_']=this['limitSet_'],_0x5bdc16['limit_']=this['limit_'],_0x5bdc16['startSet_']=this['startSet_'],_0x5bdc16['startAfterSet_']=this['startAfterSet_'],_0x5bdc16['indexStartValue_']=this['indexStartValue_'],_0x5bdc16['startNameSet_']=this['startNameSet_'],_0x5bdc16['indexStartName_']=this['indexStartName_'],_0x5bdc16['endSet_']=this['endSet_'],_0x5bdc16['endBeforeSet_']=this['endBeforeSet_'],_0x5bdc16['indexEndValue_']=this['indexEndValue_'],_0x5bdc16['endNameSet_']=this['endNameSet_'],_0x5bdc16['indexEndName_']=this['indexEndName_'],_0x5bdc16['index_']=this['index_'],_0x5bdc16['viewFrom_']=this['viewFrom_'],_0x5bdc16;}}function Kh(_0x115f39){return _0x115f39['loadsAllData']()?new Xi(_0x115f39['getIndex']()):_0x115f39['hasLimit']()?new jh(_0x115f39):new Ft(_0x115f39);}function Yh(_0x15d993,_0x4ab702){const _0x4bdd98=_0x15d993['copy']();return _0x4bdd98['limitSet_']=!0x0,_0x4bdd98['limit_']=_0x4ab702,_0x4bdd98['viewFrom_']='l',_0x4bdd98;}function Qh(_0x2adaa9,_0x263c7c,_0x5d7b64){const _0x2be599=_0x2adaa9['copy']();return _0x2be599['startSet_']=!0x0,_0x263c7c===void 0x0&&(_0x263c7c=null),_0x2be599['indexStartValue_']=_0x263c7c,_0x5d7b64!=null?(_0x2be599['startNameSet_']=!0x0,_0x2be599['indexStartName_']=_0x5d7b64):(_0x2be599['startNameSet_']=!0x1,_0x2be599['indexStartName_']=''),_0x2be599;}function Jh(_0x4112d1,_0xf3cb7b,_0x37207f){const _0x490cea=_0x4112d1['copy']();return _0x490cea['endSet_']=!0x0,_0xf3cb7b===void 0x0&&(_0xf3cb7b=null),_0x490cea['indexEndValue_']=_0xf3cb7b,_0x37207f!==void 0x0?(_0x490cea['endNameSet_']=!0x0,_0x490cea['indexEndName_']=_0x37207f):(_0x490cea['endNameSet_']=!0x1,_0x490cea['indexEndName_']=''),_0x490cea;}function xo(_0x3d039d,_0x411f77){const _0x52866f=_0x3d039d['copy']();return _0x52866f['index_']=_0x411f77,_0x52866f;}function ir(_0x4c95ce){const _0x4cec2a={};if(_0x4c95ce['isDefault']())return _0x4cec2a;let _0x10f7d2;if(_0x4c95ce['index_']===R?_0x10f7d2='$priority':_0x4c95ce['index_']===Mo?_0x10f7d2='$value':_0x4c95ce['index_']===ve?_0x10f7d2='$key':(f(_0x4c95ce['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x10f7d2=_0x4c95ce['index_']['toString']()),_0x4cec2a['orderBy']=O(_0x10f7d2),_0x4c95ce['startSet_']){const _0x475d59=_0x4c95ce['startAfterSet_']?'startAfter':'startAt';_0x4cec2a[_0x475d59]=O(_0x4c95ce['indexStartValue_']),_0x4c95ce['startNameSet_']&&(_0x4cec2a[_0x475d59]+=','+O(_0x4c95ce['indexStartName_']));}if(_0x4c95ce['endSet_']){const _0x5dfc44=_0x4c95ce['endBeforeSet_']?'endBefore':'endAt';_0x4cec2a[_0x5dfc44]=O(_0x4c95ce['indexEndValue_']),_0x4c95ce['endNameSet_']&&(_0x4cec2a[_0x5dfc44]+=','+O(_0x4c95ce['indexEndName_']));}return _0x4c95ce['limitSet_']&&(_0x4c95ce['isViewFromLeft']()?_0x4cec2a['limitToFirst']=_0x4c95ce['limit_']:_0x4cec2a['limitToLast']=_0x4c95ce['limit_']),_0x4cec2a;}function sr(_0x1297b0){const _0x4c5ec8={};if(_0x1297b0['startSet_']&&(_0x4c5ec8['sp']=_0x1297b0['indexStartValue_'],_0x1297b0['startNameSet_']&&(_0x4c5ec8['sn']=_0x1297b0['indexStartName_']),_0x4c5ec8['sin']=!_0x1297b0['startAfterSet_']),_0x1297b0['endSet_']&&(_0x4c5ec8['ep']=_0x1297b0['indexEndValue_'],_0x1297b0['endNameSet_']&&(_0x4c5ec8['en']=_0x1297b0['indexEndName_']),_0x4c5ec8['ein']=!_0x1297b0['endBeforeSet_']),_0x1297b0['limitSet_']){_0x4c5ec8['l']=_0x1297b0['limit_'];let _0x51da33=_0x1297b0['viewFrom_'];_0x51da33===''&&(_0x1297b0['isViewFromLeft']()?_0x51da33='l':_0x51da33='r'),_0x4c5ec8['vf']=_0x51da33;}return _0x1297b0['index_']!==R&&(_0x4c5ec8['i']=_0x1297b0['index_']['toString']()),_0x4c5ec8;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x19549d){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x51a823,_0x504cd5){return _0x504cd5!==void 0x0?'tag$'+_0x504cd5:(f(_0x51a823['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x51a823['_path']['toString']());}constructor(_0x245e2c,_0x1ed502,_0x3d598c,_0x58b920){super(),this['repoInfo_']=_0x245e2c,this['onDataUpdate_']=_0x1ed502,this['authTokenProvider_']=_0x3d598c,this['appCheckTokenProvider_']=_0x58b920,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x588992,_0xa458f4,_0x157478,_0x2e097c){const _0x2aacb5=_0x588992['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x2aacb5+'\x20'+_0x588992['_queryIdentifier']);const _0x30b08c=vn['getListenId_'](_0x588992,_0x157478),_0x185ffc={};this['listens_'][_0x30b08c]=_0x185ffc;const _0x497c97=ir(_0x588992['_queryParams']);this['restRequest_'](_0x2aacb5+'.json',_0x497c97,(_0x25fec8,_0x26f264)=>{let _0x2195db=_0x26f264;if(_0x25fec8===0x194&&(_0x2195db=null,_0x25fec8=null),_0x25fec8===null&&this['onDataUpdate_'](_0x2aacb5,_0x2195db,!0x1,_0x157478),Le(this['listens_'],_0x30b08c)===_0x185ffc){let _0x7f59d2;_0x25fec8?_0x25fec8===0x191?_0x7f59d2='permission_denied':_0x7f59d2='rest_error:'+_0x25fec8:_0x7f59d2='ok',_0x2e097c(_0x7f59d2,null);}});}['unlisten'](_0x67c3e2,_0x4ee8d3){const _0x9e02eb=vn['getListenId_'](_0x67c3e2,_0x4ee8d3);delete this['listens_'][_0x9e02eb];}['get'](_0x2cfa22){const _0x180f62=ir(_0x2cfa22['_queryParams']),_0x3d6acd=_0x2cfa22['_path']['toString'](),_0x4894bd=new H();return this['restRequest_'](_0x3d6acd+'.json',_0x180f62,(_0x141d36,_0x1dc966)=>{let _0x348bba=_0x1dc966;_0x141d36===0x194&&(_0x348bba=null,_0x141d36=null),_0x141d36===null?(this['onDataUpdate_'](_0x3d6acd,_0x348bba,!0x1,null),_0x4894bd['resolve'](_0x348bba)):_0x4894bd['reject'](new Error(_0x348bba));}),_0x4894bd['promise'];}['refreshAuthToken'](_0x7f8bec){}['restRequest_'](_0x36b835,_0x584979={},_0x15e085){return _0x584979['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x304f8e,_0x189a12])=>{_0x304f8e&&_0x304f8e['accessToken']&&(_0x584979['auth']=_0x304f8e['accessToken']),_0x189a12&&_0x189a12['token']&&(_0x584979['ac']=_0x189a12['token']);const _0x53fd38=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x36b835+'?ns='+this['repoInfo_']['namespace']+ut(_0x584979);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x53fd38);const _0x2a991c=new XMLHttpRequest();_0x2a991c['onreadystatechange']=()=>{if(_0x15e085&&_0x2a991c['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x53fd38+'\x20received.\x20status:',_0x2a991c['status'],'response:',_0x2a991c['responseText']);let _0x915c8f=null;if(_0x2a991c['status']>=0xc8&&_0x2a991c['status']<0x12c){try{_0x915c8f=Nt(_0x2a991c['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x53fd38+':\x20'+_0x2a991c['responseText']);}_0x15e085(null,_0x915c8f);}else _0x2a991c['status']!==0x191&&_0x2a991c['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x53fd38+'\x20Status:\x20'+_0x2a991c['status']),_0x15e085(_0x2a991c['status']);_0x15e085=null;}},_0x2a991c['open']('GET',_0x53fd38,!0x0),_0x2a991c['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x2c100e){return this['rootNode_']['getChild'](_0x2c100e);}['updateSnapshot'](_0x10cb54,_0x565edf){this['rootNode_']=this['rootNode_']['updateChild'](_0x10cb54,_0x565edf);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x368758,_0x4f8125,_0x3f4eda){if(v(_0x4f8125))_0x368758['value']=_0x3f4eda,_0x368758['children']['clear']();else{if(_0x368758['value']!==null)_0x368758['value']=_0x368758['value']['updateChild'](_0x4f8125,_0x3f4eda);else{const _0x16df55=y(_0x4f8125);_0x368758['children']['has'](_0x16df55)||_0x368758['children']['set'](_0x16df55,En());const _0x523d53=_0x368758['children']['get'](_0x16df55);_0x4f8125=S(_0x4f8125),pt(_0x523d53,_0x4f8125,_0x3f4eda);}}}function Ti(_0x59f08e,_0xb5ee02){if(v(_0xb5ee02))return _0x59f08e['value']=null,_0x59f08e['children']['clear'](),!0x0;if(_0x59f08e['value']!==null){if(_0x59f08e['value']['isLeafNode']())return!0x1;{const _0x59377f=_0x59f08e['value'];return _0x59f08e['value']=null,_0x59377f['forEachChild'](R,(_0x3078bc,_0x44161f)=>{pt(_0x59f08e,new C(_0x3078bc),_0x44161f);}),Ti(_0x59f08e,_0xb5ee02);}}else{if(_0x59f08e['children']['size']>0x0){const _0x3b4c92=y(_0xb5ee02);return _0xb5ee02=S(_0xb5ee02),_0x59f08e['children']['has'](_0x3b4c92)&&Ti(_0x59f08e['children']['get'](_0x3b4c92),_0xb5ee02)&&_0x59f08e['children']['delete'](_0x3b4c92),_0x59f08e['children']['size']===0x0;}else return!0x0;}}function Si(_0x3f708a,_0x54a4a1,_0x4b231c){_0x3f708a['value']!==null?_0x4b231c(_0x54a4a1,_0x3f708a['value']):Zh(_0x3f708a,(_0x8c305b,_0xf54326)=>{const _0x3029db=new C(_0x54a4a1['toString']()+'/'+_0x8c305b);Si(_0xf54326,_0x3029db,_0x4b231c);});}function Zh(_0x1d4474,_0x1dd013){_0x1d4474['children']['forEach']((_0x41254f,_0x1b8317)=>{_0x1dd013(_0x1b8317,_0x41254f);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x2fc99d){this['collection_']=_0x2fc99d,this['last_']=null;}['get'](){const _0x300426=this['collection_']['get'](),_0xba4633={..._0x300426};return this['last_']&&x(this['last_'],(_0x563aca,_0x28752a)=>{_0xba4633[_0x563aca]=_0xba4633[_0x563aca]-_0x28752a;}),this['last_']=_0x300426,_0xba4633;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x4d2506,_0x1377e7){this['server_']=_0x1377e7,this['statsToReport_']={},this['statsListener_']=new eu(_0x4d2506);const _0x375016=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x375016));}['reportStats_'](){const _0x5d017e=this['statsListener_']['get'](),_0x321ff1={};let _0x55fd58=!0x1;x(_0x5d017e,(_0x53aa93,_0x58b651)=>{_0x58b651>0x0&&Q(this['statsToReport_'],_0x53aa93)&&(_0x321ff1[_0x53aa93]=_0x58b651,_0x55fd58=!0x0);}),_0x55fd58&&this['server_']['reportStats'](_0x321ff1),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x2a3fc2){_0x2a3fc2[_0x2a3fc2['OVERWRITE']=0x0]='OVERWRITE',_0x2a3fc2[_0x2a3fc2['MERGE']=0x1]='MERGE',_0x2a3fc2[_0x2a3fc2['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x2a3fc2[_0x2a3fc2['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x2d3c20){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x2d3c20,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x38d849,_0x329417,_0x7281a9){this['path']=_0x38d849,this['affectedTree']=_0x329417,this['revert']=_0x7281a9,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x8fab30){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x2bbf0c=this['affectedTree']['subtree'](new C(_0x8fab30));return new In(w(),_0x2bbf0c,this['revert']);}}else return f(y(this['path'])===_0x8fab30,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x4b1ca9,_0x2b9270){this['source']=_0x4b1ca9,this['path']=_0x2b9270,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x567133){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x514846,_0x3d33a9,_0x412eb3){this['source']=_0x514846,this['path']=_0x3d33a9,this['snap']=_0x412eb3,this['type']=z['OVERWRITE'];}['operationForChild'](_0x482656){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x482656)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x54daff,_0x1deab0,_0x1b4898){this['source']=_0x54daff,this['path']=_0x1deab0,this['children']=_0x1b4898,this['type']=z['MERGE'];}['operationForChild'](_0x1912ac){if(v(this['path'])){const _0x5742f0=this['children']['subtree'](new C(_0x1912ac));return _0x5742f0['isEmpty']()?null:_0x5742f0['value']?new Be(this['source'],w(),_0x5742f0['value']):new ot(this['source'],w(),_0x5742f0);}else return f(y(this['path'])===_0x1912ac,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0xf9436,_0x340e0f,_0x4d1f5a){this['node_']=_0xf9436,this['fullyInitialized_']=_0x340e0f,this['filtered_']=_0x4d1f5a;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x4bb6ef){if(v(_0x4bb6ef))return this['isFullyInitialized']()&&!this['filtered_'];const _0x47e62f=y(_0x4bb6ef);return this['isCompleteForChild'](_0x47e62f);}['isCompleteForChild'](_0x599837){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x599837);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x58cf39){this['query_']=_0x58cf39,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x141500,_0x42ae1a,_0x291ea6,_0xef56c2){const _0x4a512d=[],_0x5a6ec4=[];return _0x42ae1a['forEach'](_0x26b6f9=>{_0x26b6f9['type']==='child_changed'&&_0x141500['index_']['indexedValueChanged'](_0x26b6f9['oldSnap'],_0x26b6f9['snapshotNode'])&&_0x5a6ec4['push'](zh(_0x26b6f9['childName'],_0x26b6f9['snapshotNode']));}),wt(_0x141500,_0x4a512d,'child_removed',_0x42ae1a,_0xef56c2,_0x291ea6),wt(_0x141500,_0x4a512d,'child_added',_0x42ae1a,_0xef56c2,_0x291ea6),wt(_0x141500,_0x4a512d,'child_moved',_0x5a6ec4,_0xef56c2,_0x291ea6),wt(_0x141500,_0x4a512d,'child_changed',_0x42ae1a,_0xef56c2,_0x291ea6),wt(_0x141500,_0x4a512d,'value',_0x42ae1a,_0xef56c2,_0x291ea6),_0x4a512d;}function wt(_0x4e897c,_0x102f15,_0x398ffa,_0x5b3d68,_0x16f16d,_0x4065fb){const _0x406c86=_0x5b3d68['filter'](_0x41b5b0=>_0x41b5b0['type']===_0x398ffa);_0x406c86['sort']((_0x34954a,_0xccb575)=>au(_0x4e897c,_0x34954a,_0xccb575)),_0x406c86['forEach'](_0x558336=>{const _0x4361cf=ou(_0x4e897c,_0x558336,_0x4065fb);_0x16f16d['forEach'](_0x24968c=>{_0x24968c['respondsTo'](_0x558336['type'])&&_0x102f15['push'](_0x24968c['createEvent'](_0x4361cf,_0x4e897c['query_']));});});}function ou(_0x3c3e06,_0x1063f0,_0x3b9f24){return _0x1063f0['type']==='value'||_0x1063f0['type']==='child_removed'||(_0x1063f0['prevName']=_0x3b9f24['getPredecessorChildName'](_0x1063f0['childName'],_0x1063f0['snapshotNode'],_0x3c3e06['index_'])),_0x1063f0;}function au(_0x459084,_0x454ea6,_0xeffac){if(_0x454ea6['childName']==null||_0xeffac['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x180db6=new E(_0x454ea6['childName'],_0x454ea6['snapshotNode']),_0x156452=new E(_0xeffac['childName'],_0xeffac['snapshotNode']);return _0x459084['index_']['compare'](_0x180db6,_0x156452);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x26337c,_0x346ad7){return{'eventCache':_0x26337c,'serverCache':_0x346ad7};}function Rt(_0xb79ed3,_0x2d7319,_0x5542c8,_0x2167da){return Un(new Te(_0x2d7319,_0x5542c8,_0x2167da),_0xb79ed3['serverCache']);}function Fo(_0x51430e,_0x170768,_0x9c8b21,_0x10e1cf){return Un(_0x51430e['eventCache'],new Te(_0x170768,_0x9c8b21,_0x10e1cf));}function wn(_0x3ec076){return _0x3ec076['eventCache']['isFullyInitialized']()?_0x3ec076['eventCache']['getNode']():null;}function Ve(_0x248e44){return _0x248e44['serverCache']['isFullyInitialized']()?_0x248e44['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x161ae2){let _0x45637a=new b(null);return x(_0x161ae2,(_0x31e16f,_0x357175)=>{_0x45637a=_0x45637a['set'](new C(_0x31e16f),_0x357175);}),_0x45637a;}constructor(_0x205b18,_0x54eedd=cu()){this['value']=_0x205b18,this['children']=_0x54eedd;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x1e53fc,_0xfe1abb){if(this['value']!=null&&_0xfe1abb(this['value']))return{'path':w(),'value':this['value']};if(v(_0x1e53fc))return null;{const _0x524fd4=y(_0x1e53fc),_0x348779=this['children']['get'](_0x524fd4);if(_0x348779!==null){const _0x133e90=_0x348779['findRootMostMatchingPathAndValue'](S(_0x1e53fc),_0xfe1abb);return _0x133e90!=null?{'path':k(new C(_0x524fd4),_0x133e90['path']),'value':_0x133e90['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x3509b1){return this['findRootMostMatchingPathAndValue'](_0x3509b1,()=>!0x0);}['subtree'](_0x534378){if(v(_0x534378))return this;{const _0x2a8560=y(_0x534378),_0x178264=this['children']['get'](_0x2a8560);return _0x178264!==null?_0x178264['subtree'](S(_0x534378)):new b(null);}}['set'](_0x49a4ab,_0x1f18da){if(v(_0x49a4ab))return new b(_0x1f18da,this['children']);{const _0xda3214=y(_0x49a4ab),_0x11ebcf=(this['children']['get'](_0xda3214)||new b(null))['set'](S(_0x49a4ab),_0x1f18da),_0x25dd06=this['children']['insert'](_0xda3214,_0x11ebcf);return new b(this['value'],_0x25dd06);}}['remove'](_0x2205cc){if(v(_0x2205cc))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x141d77=y(_0x2205cc),_0x3c9441=this['children']['get'](_0x141d77);if(_0x3c9441){const _0x24d121=_0x3c9441['remove'](S(_0x2205cc));let _0x5460c7;return _0x24d121['isEmpty']()?_0x5460c7=this['children']['remove'](_0x141d77):_0x5460c7=this['children']['insert'](_0x141d77,_0x24d121),this['value']===null&&_0x5460c7['isEmpty']()?new b(null):new b(this['value'],_0x5460c7);}else return this;}}['get'](_0x28a94a){if(v(_0x28a94a))return this['value'];{const _0x241360=y(_0x28a94a),_0x21966a=this['children']['get'](_0x241360);return _0x21966a?_0x21966a['get'](S(_0x28a94a)):null;}}['setTree'](_0x2b1fd5,_0xfe98c4){if(v(_0x2b1fd5))return _0xfe98c4;{const _0x3db976=y(_0x2b1fd5),_0x3f5b4b=(this['children']['get'](_0x3db976)||new b(null))['setTree'](S(_0x2b1fd5),_0xfe98c4);let _0x8bbce2;return _0x3f5b4b['isEmpty']()?_0x8bbce2=this['children']['remove'](_0x3db976):_0x8bbce2=this['children']['insert'](_0x3db976,_0x3f5b4b),new b(this['value'],_0x8bbce2);}}['fold'](_0x2fb7ad){return this['fold_'](w(),_0x2fb7ad);}['fold_'](_0x6184b4,_0x2d028a){const _0x5c1bdc={};return this['children']['inorderTraversal']((_0x281dcb,_0x6f8987)=>{_0x5c1bdc[_0x281dcb]=_0x6f8987['fold_'](k(_0x6184b4,_0x281dcb),_0x2d028a);}),_0x2d028a(_0x6184b4,this['value'],_0x5c1bdc);}['findOnPath'](_0x4d537b,_0x24471b){return this['findOnPath_'](_0x4d537b,w(),_0x24471b);}['findOnPath_'](_0x37e51c,_0x3e4262,_0x522ce6){const _0x223cce=this['value']?_0x522ce6(_0x3e4262,this['value']):!0x1;if(_0x223cce)return _0x223cce;if(v(_0x37e51c))return null;{const _0x2f5cc7=y(_0x37e51c),_0x4bf126=this['children']['get'](_0x2f5cc7);return _0x4bf126?_0x4bf126['findOnPath_'](S(_0x37e51c),k(_0x3e4262,_0x2f5cc7),_0x522ce6):null;}}['foreachOnPath'](_0x30ff7a,_0x2b889c){return this['foreachOnPath_'](_0x30ff7a,w(),_0x2b889c);}['foreachOnPath_'](_0x8e8d6a,_0x593a15,_0x55add8){if(v(_0x8e8d6a))return this;{this['value']&&_0x55add8(_0x593a15,this['value']);const _0x141138=y(_0x8e8d6a),_0x597be4=this['children']['get'](_0x141138);return _0x597be4?_0x597be4['foreachOnPath_'](S(_0x8e8d6a),k(_0x593a15,_0x141138),_0x55add8):new b(null);}}['foreach'](_0x25a5b3){this['foreach_'](w(),_0x25a5b3);}['foreach_'](_0x1c066a,_0x3232f5){this['children']['inorderTraversal']((_0x4228cb,_0xcdf346)=>{_0xcdf346['foreach_'](k(_0x1c066a,_0x4228cb),_0x3232f5);}),this['value']&&_0x3232f5(_0x1c066a,this['value']);}['foreachChild'](_0x424b29){this['children']['inorderTraversal']((_0x15e648,_0xb9beb4)=>{_0xb9beb4['value']&&_0x424b29(_0x15e648,_0xb9beb4['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x5a7027){this['writeTree_']=_0x5a7027;}static['empty'](){return new K(new b(null));}}function At(_0x58fb7a,_0xa5114d,_0x4bbc0b){if(v(_0xa5114d))return new K(new b(_0x4bbc0b));{const _0x5c625a=_0x58fb7a['writeTree_']['findRootMostValueAndPath'](_0xa5114d);if(_0x5c625a!=null){const _0x520956=_0x5c625a['path'];let _0x59e0a1=_0x5c625a['value'];const _0x291438=F(_0x520956,_0xa5114d);return _0x59e0a1=_0x59e0a1['updateChild'](_0x291438,_0x4bbc0b),new K(_0x58fb7a['writeTree_']['set'](_0x520956,_0x59e0a1));}else{const _0x264dca=new b(_0x4bbc0b),_0x47a577=_0x58fb7a['writeTree_']['setTree'](_0xa5114d,_0x264dca);return new K(_0x47a577);}}}function bi(_0x23640c,_0x459afb,_0x8df274){let _0x5112c2=_0x23640c;return x(_0x8df274,(_0x1b031e,_0x4844fb)=>{_0x5112c2=At(_0x5112c2,k(_0x459afb,_0x1b031e),_0x4844fb);}),_0x5112c2;}function or(_0x319a90,_0x1ec36c){if(v(_0x1ec36c))return K['empty']();{const _0x23753d=_0x319a90['writeTree_']['setTree'](_0x1ec36c,new b(null));return new K(_0x23753d);}}function Ri(_0xd91592,_0x490ae4){return ze(_0xd91592,_0x490ae4)!=null;}function ze(_0x12d8e8,_0x1642b9){const _0x2f7a39=_0x12d8e8['writeTree_']['findRootMostValueAndPath'](_0x1642b9);return _0x2f7a39!=null?_0x12d8e8['writeTree_']['get'](_0x2f7a39['path'])['getChild'](F(_0x2f7a39['path'],_0x1642b9)):null;}function ar(_0x4d8360){const _0x149103=[],_0x4c8a52=_0x4d8360['writeTree_']['value'];return _0x4c8a52!=null?_0x4c8a52['isLeafNode']()||_0x4c8a52['forEachChild'](R,(_0x4e097b,_0x353646)=>{_0x149103['push'](new E(_0x4e097b,_0x353646));}):_0x4d8360['writeTree_']['children']['inorderTraversal']((_0x508722,_0x1612b1)=>{_0x1612b1['value']!=null&&_0x149103['push'](new E(_0x508722,_0x1612b1['value']));}),_0x149103;}function Ee(_0xbfaf04,_0x398326){if(v(_0x398326))return _0xbfaf04;{const _0x5b6b80=ze(_0xbfaf04,_0x398326);return _0x5b6b80!=null?new K(new b(_0x5b6b80)):new K(_0xbfaf04['writeTree_']['subtree'](_0x398326));}}function Ai(_0x2bcae9){return _0x2bcae9['writeTree_']['isEmpty']();}function at(_0x1876b6,_0x3dd809){return Uo(w(),_0x1876b6['writeTree_'],_0x3dd809);}function Uo(_0x52f113,_0x50ab83,_0x471031){if(_0x50ab83['value']!=null)return _0x471031['updateChild'](_0x52f113,_0x50ab83['value']);{let _0x42e4fd=null;return _0x50ab83['children']['inorderTraversal']((_0x5cb95c,_0x59f0d2)=>{_0x5cb95c==='.priority'?(f(_0x59f0d2['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x42e4fd=_0x59f0d2['value']):_0x471031=Uo(k(_0x52f113,_0x5cb95c),_0x59f0d2,_0x471031);}),!_0x471031['getChild'](_0x52f113)['isEmpty']()&&_0x42e4fd!==null&&(_0x471031=_0x471031['updateChild'](k(_0x52f113,'.priority'),_0x42e4fd)),_0x471031;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x2b2347,_0x489058){return Ho(_0x489058,_0x2b2347);}function lu(_0x278aee,_0x2d227f,_0xec67b8,_0x597620,_0x296d18){f(_0x597620>_0x278aee['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x296d18===void 0x0&&(_0x296d18=!0x0),_0x278aee['allWrites']['push']({'path':_0x2d227f,'snap':_0xec67b8,'writeId':_0x597620,'visible':_0x296d18}),_0x296d18&&(_0x278aee['visibleWrites']=At(_0x278aee['visibleWrites'],_0x2d227f,_0xec67b8)),_0x278aee['lastWriteId']=_0x597620;}function hu(_0x1a856f,_0x536c8f,_0x59b983,_0x5380b3){f(_0x5380b3>_0x1a856f['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x1a856f['allWrites']['push']({'path':_0x536c8f,'children':_0x59b983,'writeId':_0x5380b3,'visible':!0x0}),_0x1a856f['visibleWrites']=bi(_0x1a856f['visibleWrites'],_0x536c8f,_0x59b983),_0x1a856f['lastWriteId']=_0x5380b3;}function uu(_0x74658f,_0x2cc1c1){for(let _0xaa3ccc=0x0;_0xaa3ccc<_0x74658f['allWrites']['length'];_0xaa3ccc++){const _0x3d53af=_0x74658f['allWrites'][_0xaa3ccc];if(_0x3d53af['writeId']===_0x2cc1c1)return _0x3d53af;}return null;}function du(_0x49b160,_0x477b53){const _0x59352c=_0x49b160['allWrites']['findIndex'](_0x179997=>_0x179997['writeId']===_0x477b53);f(_0x59352c>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x377622=_0x49b160['allWrites'][_0x59352c];_0x49b160['allWrites']['splice'](_0x59352c,0x1);let _0x39421e=_0x377622['visible'],_0x5055af=!0x1,_0x577173=_0x49b160['allWrites']['length']-0x1;for(;_0x39421e&&_0x577173>=0x0;){const _0x2f7531=_0x49b160['allWrites'][_0x577173];_0x2f7531['visible']&&(_0x577173>=_0x59352c&&fu(_0x2f7531,_0x377622['path'])?_0x39421e=!0x1:G(_0x377622['path'],_0x2f7531['path'])&&(_0x5055af=!0x0)),_0x577173--;}if(_0x39421e){if(_0x5055af)return pu(_0x49b160),!0x0;if(_0x377622['snap'])_0x49b160['visibleWrites']=or(_0x49b160['visibleWrites'],_0x377622['path']);else{const _0x2fc408=_0x377622['children'];x(_0x2fc408,_0x2849d2=>{_0x49b160['visibleWrites']=or(_0x49b160['visibleWrites'],k(_0x377622['path'],_0x2849d2));});}return!0x0;}else return!0x1;}function fu(_0x31bfca,_0x5ca6c5){if(_0x31bfca['snap'])return G(_0x31bfca['path'],_0x5ca6c5);for(const _0x55dec7 in _0x31bfca['children'])if(_0x31bfca['children']['hasOwnProperty'](_0x55dec7)&&G(k(_0x31bfca['path'],_0x55dec7),_0x5ca6c5))return!0x0;return!0x1;}function pu(_0x38c2ad){_0x38c2ad['visibleWrites']=Wo(_0x38c2ad['allWrites'],_u,w()),_0x38c2ad['allWrites']['length']>0x0?_0x38c2ad['lastWriteId']=_0x38c2ad['allWrites'][_0x38c2ad['allWrites']['length']-0x1]['writeId']:_0x38c2ad['lastWriteId']=-0x1;}function _u(_0x5274c4){return _0x5274c4['visible'];}function Wo(_0x419fcb,_0x3ddb53,_0x46d85f){let _0xb1dd1c=K['empty']();for(let _0x57e223=0x0;_0x57e223<_0x419fcb['length'];++_0x57e223){const _0x1dc0f6=_0x419fcb[_0x57e223];if(_0x3ddb53(_0x1dc0f6)){const _0x372ba6=_0x1dc0f6['path'];let _0x46809a;if(_0x1dc0f6['snap'])G(_0x46d85f,_0x372ba6)?(_0x46809a=F(_0x46d85f,_0x372ba6),_0xb1dd1c=At(_0xb1dd1c,_0x46809a,_0x1dc0f6['snap'])):G(_0x372ba6,_0x46d85f)&&(_0x46809a=F(_0x372ba6,_0x46d85f),_0xb1dd1c=At(_0xb1dd1c,w(),_0x1dc0f6['snap']['getChild'](_0x46809a)));else{if(_0x1dc0f6['children']){if(G(_0x46d85f,_0x372ba6))_0x46809a=F(_0x46d85f,_0x372ba6),_0xb1dd1c=bi(_0xb1dd1c,_0x46809a,_0x1dc0f6['children']);else{if(G(_0x372ba6,_0x46d85f)){if(_0x46809a=F(_0x372ba6,_0x46d85f),v(_0x46809a))_0xb1dd1c=bi(_0xb1dd1c,w(),_0x1dc0f6['children']);else{const _0x2e107e=Le(_0x1dc0f6['children'],y(_0x46809a));if(_0x2e107e){const _0x2ecfb6=_0x2e107e['getChild'](S(_0x46809a));_0xb1dd1c=At(_0xb1dd1c,w(),_0x2ecfb6);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0xb1dd1c;}function Bo(_0x3079c2,_0x48e3ae,_0x634bca,_0x26106f,_0x169260){if(!_0x26106f&&!_0x169260){const _0x1437e2=ze(_0x3079c2['visibleWrites'],_0x48e3ae);if(_0x1437e2!=null)return _0x1437e2;{const _0x225ed3=Ee(_0x3079c2['visibleWrites'],_0x48e3ae);if(Ai(_0x225ed3))return _0x634bca;if(_0x634bca==null&&!Ri(_0x225ed3,w()))return null;{const _0x2d4a3e=_0x634bca||g['EMPTY_NODE'];return at(_0x225ed3,_0x2d4a3e);}}}else{const _0x5d9185=Ee(_0x3079c2['visibleWrites'],_0x48e3ae);if(!_0x169260&&Ai(_0x5d9185))return _0x634bca;if(!_0x169260&&_0x634bca==null&&!Ri(_0x5d9185,w()))return null;{const _0x4b7592=function(_0x4f7605){return(_0x4f7605['visible']||_0x169260)&&(!_0x26106f||!~_0x26106f['indexOf'](_0x4f7605['writeId']))&&(G(_0x4f7605['path'],_0x48e3ae)||G(_0x48e3ae,_0x4f7605['path']));},_0x253fcf=Wo(_0x3079c2['allWrites'],_0x4b7592,_0x48e3ae),_0x27bf9a=_0x634bca||g['EMPTY_NODE'];return at(_0x253fcf,_0x27bf9a);}}}function gu(_0x33ddd6,_0x2f3ac9,_0x1fd047){let _0x120e0f=g['EMPTY_NODE'];const _0x3cb00b=ze(_0x33ddd6['visibleWrites'],_0x2f3ac9);if(_0x3cb00b)return _0x3cb00b['isLeafNode']()||_0x3cb00b['forEachChild'](R,(_0x8438b3,_0x278146)=>{_0x120e0f=_0x120e0f['updateImmediateChild'](_0x8438b3,_0x278146);}),_0x120e0f;if(_0x1fd047){const _0x3d54=Ee(_0x33ddd6['visibleWrites'],_0x2f3ac9);return _0x1fd047['forEachChild'](R,(_0x482b08,_0x279181)=>{const _0x3cdb1a=at(Ee(_0x3d54,new C(_0x482b08)),_0x279181);_0x120e0f=_0x120e0f['updateImmediateChild'](_0x482b08,_0x3cdb1a);}),ar(_0x3d54)['forEach'](_0x23e798=>{_0x120e0f=_0x120e0f['updateImmediateChild'](_0x23e798['name'],_0x23e798['node']);}),_0x120e0f;}else{const _0x5a4ec2=Ee(_0x33ddd6['visibleWrites'],_0x2f3ac9);return ar(_0x5a4ec2)['forEach'](_0x184d64=>{_0x120e0f=_0x120e0f['updateImmediateChild'](_0x184d64['name'],_0x184d64['node']);}),_0x120e0f;}}function mu(_0x1c3670,_0x4708b1,_0x16f649,_0x1e33e7,_0x1d894b){f(_0x1e33e7||_0x1d894b,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x24a522=k(_0x4708b1,_0x16f649);if(Ri(_0x1c3670['visibleWrites'],_0x24a522))return null;{const _0x5f4d6c=Ee(_0x1c3670['visibleWrites'],_0x24a522);return Ai(_0x5f4d6c)?_0x1d894b['getChild'](_0x16f649):at(_0x5f4d6c,_0x1d894b['getChild'](_0x16f649));}}function yu(_0x409c23,_0x502029,_0x8d0bf5,_0x3e8a46){const _0xde68a7=k(_0x502029,_0x8d0bf5),_0x1eeda9=ze(_0x409c23['visibleWrites'],_0xde68a7);if(_0x1eeda9!=null)return _0x1eeda9;if(_0x3e8a46['isCompleteForChild'](_0x8d0bf5)){const _0x3235a9=Ee(_0x409c23['visibleWrites'],_0xde68a7);return at(_0x3235a9,_0x3e8a46['getNode']()['getImmediateChild'](_0x8d0bf5));}else return null;}function vu(_0xd525ee,_0x261e2c){return ze(_0xd525ee['visibleWrites'],_0x261e2c);}function Eu(_0x1c91e9,_0x32168e,_0x5ad3cc,_0x4e0690,_0x1e9265,_0x510cf8,_0x2b6d8d){let _0x3d2393;const _0xb95258=Ee(_0x1c91e9['visibleWrites'],_0x32168e),_0x69752f=ze(_0xb95258,w());if(_0x69752f!=null)_0x3d2393=_0x69752f;else{if(_0x5ad3cc!=null)_0x3d2393=at(_0xb95258,_0x5ad3cc);else return[];}if(_0x3d2393=_0x3d2393['withIndex'](_0x2b6d8d),!_0x3d2393['isEmpty']()&&!_0x3d2393['isLeafNode']()){const _0x35eff1=[],_0x18029e=_0x2b6d8d['getCompare'](),_0x403ef6=_0x510cf8?_0x3d2393['getReverseIteratorFrom'](_0x4e0690,_0x2b6d8d):_0x3d2393['getIteratorFrom'](_0x4e0690,_0x2b6d8d);let _0x184a38=_0x403ef6['getNext']();for(;_0x184a38&&_0x35eff1['length']<_0x1e9265;)_0x18029e(_0x184a38,_0x4e0690)!==0x0&&_0x35eff1['push'](_0x184a38),_0x184a38=_0x403ef6['getNext']();return _0x35eff1;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x21a3a1,_0x3417e5,_0x38ef7b,_0x1a4bbb){return Bo(_0x21a3a1['writeTree'],_0x21a3a1['treePath'],_0x3417e5,_0x38ef7b,_0x1a4bbb);}function is(_0x120e80,_0x5b4fd3){return gu(_0x120e80['writeTree'],_0x120e80['treePath'],_0x5b4fd3);}function cr(_0x38a918,_0x569039,_0x11a66e,_0x21468f){return mu(_0x38a918['writeTree'],_0x38a918['treePath'],_0x569039,_0x11a66e,_0x21468f);}function Tn(_0x402337,_0x81113e){return vu(_0x402337['writeTree'],k(_0x402337['treePath'],_0x81113e));}function wu(_0x1ab14d,_0x361644,_0x136e11,_0x306d64,_0x94d84f,_0x236700){return Eu(_0x1ab14d['writeTree'],_0x1ab14d['treePath'],_0x361644,_0x136e11,_0x306d64,_0x94d84f,_0x236700);}function ss(_0x1fcfd4,_0x123261,_0x1f6cd4){return yu(_0x1fcfd4['writeTree'],_0x1fcfd4['treePath'],_0x123261,_0x1f6cd4);}function Vo(_0xf9f79b,_0x5af3c1){return Ho(k(_0xf9f79b['treePath'],_0x5af3c1),_0xf9f79b['writeTree']);}function Ho(_0x13a9de,_0x17224b){return{'treePath':_0x13a9de,'writeTree':_0x17224b};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x2c88e6){const _0xb722c7=_0x2c88e6['type'],_0x2408c8=_0x2c88e6['childName'];f(_0xb722c7==='child_added'||_0xb722c7==='child_changed'||_0xb722c7==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x2408c8!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x30ebe6=this['changeMap']['get'](_0x2408c8);if(_0x30ebe6){const _0x3ab08b=_0x30ebe6['type'];if(_0xb722c7==='child_added'&&_0x3ab08b==='child_removed')this['changeMap']['set'](_0x2408c8,xt(_0x2408c8,_0x2c88e6['snapshotNode'],_0x30ebe6['snapshotNode']));else{if(_0xb722c7==='child_removed'&&_0x3ab08b==='child_added')this['changeMap']['delete'](_0x2408c8);else{if(_0xb722c7==='child_removed'&&_0x3ab08b==='child_changed')this['changeMap']['set'](_0x2408c8,Lt(_0x2408c8,_0x30ebe6['oldSnap']));else{if(_0xb722c7==='child_changed'&&_0x3ab08b==='child_added')this['changeMap']['set'](_0x2408c8,rt(_0x2408c8,_0x2c88e6['snapshotNode']));else{if(_0xb722c7==='child_changed'&&_0x3ab08b==='child_changed')this['changeMap']['set'](_0x2408c8,xt(_0x2408c8,_0x2c88e6['snapshotNode'],_0x30ebe6['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x2c88e6+'\x20occurred\x20after\x20'+_0x30ebe6);}}}}}else this['changeMap']['set'](_0x2408c8,_0x2c88e6);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x5cef16){return null;}['getChildAfterChild'](_0x5ad223,_0x8c3f3d,_0x530a0c){return null;}}const $o=new Tu();class rs{constructor(_0x5d7471,_0x1e15e8,_0x46b7bf=null){this['writes_']=_0x5d7471,this['viewCache_']=_0x1e15e8,this['optCompleteServerCache_']=_0x46b7bf;}['getCompleteChild'](_0x3729a7){const _0x8f57ce=this['viewCache_']['eventCache'];if(_0x8f57ce['isCompleteForChild'](_0x3729a7))return _0x8f57ce['getNode']()['getImmediateChild'](_0x3729a7);{const _0xa125f8=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x3729a7,_0xa125f8);}}['getChildAfterChild'](_0x464b7b,_0x54d783,_0x4d7157){const _0x965356=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x6d34a6=wu(this['writes_'],_0x965356,_0x54d783,0x1,_0x4d7157,_0x464b7b);return _0x6d34a6['length']===0x0?null:_0x6d34a6[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x36e8be){return{'filter':_0x36e8be};}function bu(_0x2f3152,_0x59aeb1){f(_0x59aeb1['eventCache']['getNode']()['isIndexed'](_0x2f3152['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x59aeb1['serverCache']['getNode']()['isIndexed'](_0x2f3152['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x4c9887,_0x468dd4,_0x17301d,_0x456273,_0x50203f){const _0x4aa851=new Cu();let _0x294a4d,_0x25a865;if(_0x17301d['type']===z['OVERWRITE']){const _0x47844b=_0x17301d;_0x47844b['source']['fromUser']?_0x294a4d=ki(_0x4c9887,_0x468dd4,_0x47844b['path'],_0x47844b['snap'],_0x456273,_0x50203f,_0x4aa851):(f(_0x47844b['source']['fromServer'],'Unknown\x20source.'),_0x25a865=_0x47844b['source']['tagged']||_0x468dd4['serverCache']['isFiltered']()&&!v(_0x47844b['path']),_0x294a4d=Sn(_0x4c9887,_0x468dd4,_0x47844b['path'],_0x47844b['snap'],_0x456273,_0x50203f,_0x25a865,_0x4aa851));}else{if(_0x17301d['type']===z['MERGE']){const _0x55aa9e=_0x17301d;_0x55aa9e['source']['fromUser']?_0x294a4d=ku(_0x4c9887,_0x468dd4,_0x55aa9e['path'],_0x55aa9e['children'],_0x456273,_0x50203f,_0x4aa851):(f(_0x55aa9e['source']['fromServer'],'Unknown\x20source.'),_0x25a865=_0x55aa9e['source']['tagged']||_0x468dd4['serverCache']['isFiltered'](),_0x294a4d=Pi(_0x4c9887,_0x468dd4,_0x55aa9e['path'],_0x55aa9e['children'],_0x456273,_0x50203f,_0x25a865,_0x4aa851));}else{if(_0x17301d['type']===z['ACK_USER_WRITE']){const _0x216d20=_0x17301d;_0x216d20['revert']?_0x294a4d=Ou(_0x4c9887,_0x468dd4,_0x216d20['path'],_0x456273,_0x50203f,_0x4aa851):_0x294a4d=Pu(_0x4c9887,_0x468dd4,_0x216d20['path'],_0x216d20['affectedTree'],_0x456273,_0x50203f,_0x4aa851);}else{if(_0x17301d['type']===z['LISTEN_COMPLETE'])_0x294a4d=Nu(_0x4c9887,_0x468dd4,_0x17301d['path'],_0x456273,_0x4aa851);else throw ht('Unknown\x20operation\x20type:\x20'+_0x17301d['type']);}}}const _0x155b01=_0x4aa851['getChanges']();return Au(_0x468dd4,_0x294a4d,_0x155b01),{'viewCache':_0x294a4d,'changes':_0x155b01};}function Au(_0x2d1a23,_0xdbd2a6,_0x4099d2){const _0x1eefb1=_0xdbd2a6['eventCache'];if(_0x1eefb1['isFullyInitialized']()){const _0x2992d4=_0x1eefb1['getNode']()['isLeafNode']()||_0x1eefb1['getNode']()['isEmpty'](),_0x70214d=wn(_0x2d1a23);(_0x4099d2['length']>0x0||!_0x2d1a23['eventCache']['isFullyInitialized']()||_0x2992d4&&!_0x1eefb1['getNode']()['equals'](_0x70214d)||!_0x1eefb1['getNode']()['getPriority']()['equals'](_0x70214d['getPriority']()))&&_0x4099d2['push'](Lo(wn(_0xdbd2a6)));}}function Go(_0x1298da,_0xd2c152,_0x53ae42,_0xec363b,_0x4d283a,_0x315dde){const _0x466208=_0xd2c152['eventCache'];if(Tn(_0xec363b,_0x53ae42)!=null)return _0xd2c152;{let _0x2088a9,_0x9dbe8f;if(v(_0x53ae42)){if(f(_0xd2c152['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0xd2c152['serverCache']['isFiltered']()){const _0x3280e8=Ve(_0xd2c152),_0x38e39b=_0x3280e8 instanceof g?_0x3280e8:g['EMPTY_NODE'],_0x2cdf76=is(_0xec363b,_0x38e39b);_0x2088a9=_0x1298da['filter']['updateFullNode'](_0xd2c152['eventCache']['getNode'](),_0x2cdf76,_0x315dde);}else{const _0x2ab942=Cn(_0xec363b,Ve(_0xd2c152));_0x2088a9=_0x1298da['filter']['updateFullNode'](_0xd2c152['eventCache']['getNode'](),_0x2ab942,_0x315dde);}}else{const _0xd51be3=y(_0x53ae42);if(_0xd51be3==='.priority'){f(Ce(_0x53ae42)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x3f1ead=_0x466208['getNode']();_0x9dbe8f=_0xd2c152['serverCache']['getNode']();const _0x2e3195=cr(_0xec363b,_0x53ae42,_0x3f1ead,_0x9dbe8f);_0x2e3195!=null?_0x2088a9=_0x1298da['filter']['updatePriority'](_0x3f1ead,_0x2e3195):_0x2088a9=_0x466208['getNode']();}else{const _0x198ee5=S(_0x53ae42);let _0x15ff35;if(_0x466208['isCompleteForChild'](_0xd51be3)){_0x9dbe8f=_0xd2c152['serverCache']['getNode']();const _0xd27f06=cr(_0xec363b,_0x53ae42,_0x466208['getNode'](),_0x9dbe8f);_0xd27f06!=null?_0x15ff35=_0x466208['getNode']()['getImmediateChild'](_0xd51be3)['updateChild'](_0x198ee5,_0xd27f06):_0x15ff35=_0x466208['getNode']()['getImmediateChild'](_0xd51be3);}else _0x15ff35=ss(_0xec363b,_0xd51be3,_0xd2c152['serverCache']);_0x15ff35!=null?_0x2088a9=_0x1298da['filter']['updateChild'](_0x466208['getNode'](),_0xd51be3,_0x15ff35,_0x198ee5,_0x4d283a,_0x315dde):_0x2088a9=_0x466208['getNode']();}}return Rt(_0xd2c152,_0x2088a9,_0x466208['isFullyInitialized']()||v(_0x53ae42),_0x1298da['filter']['filtersNodes']());}}function Sn(_0x318e8e,_0x294cc5,_0x3f27ac,_0x1dd169,_0x1a2fb3,_0x3a4308,_0x2597fb,_0x5205a3){const _0x1b4955=_0x294cc5['serverCache'];let _0x276f08;const _0x3cb420=_0x2597fb?_0x318e8e['filter']:_0x318e8e['filter']['getIndexedFilter']();if(v(_0x3f27ac))_0x276f08=_0x3cb420['updateFullNode'](_0x1b4955['getNode'](),_0x1dd169,null);else{if(_0x3cb420['filtersNodes']()&&!_0x1b4955['isFiltered']()){const _0x313c14=_0x1b4955['getNode']()['updateChild'](_0x3f27ac,_0x1dd169);_0x276f08=_0x3cb420['updateFullNode'](_0x1b4955['getNode'](),_0x313c14,null);}else{const _0x305345=y(_0x3f27ac);if(!_0x1b4955['isCompleteForPath'](_0x3f27ac)&&Ce(_0x3f27ac)>0x1)return _0x294cc5;const _0xdf37ba=S(_0x3f27ac),_0x412137=_0x1b4955['getNode']()['getImmediateChild'](_0x305345)['updateChild'](_0xdf37ba,_0x1dd169);_0x305345==='.priority'?_0x276f08=_0x3cb420['updatePriority'](_0x1b4955['getNode'](),_0x412137):_0x276f08=_0x3cb420['updateChild'](_0x1b4955['getNode'](),_0x305345,_0x412137,_0xdf37ba,$o,null);}}const _0x584dfb=Fo(_0x294cc5,_0x276f08,_0x1b4955['isFullyInitialized']()||v(_0x3f27ac),_0x3cb420['filtersNodes']()),_0x2ab636=new rs(_0x1a2fb3,_0x584dfb,_0x3a4308);return Go(_0x318e8e,_0x584dfb,_0x3f27ac,_0x1a2fb3,_0x2ab636,_0x5205a3);}function ki(_0x184150,_0x53c4eb,_0x31175e,_0x20403a,_0x35dbc9,_0x2ec1c8,_0xa12e22){const _0x3c5343=_0x53c4eb['eventCache'];let _0x381ca5,_0x59e42d;const _0x308866=new rs(_0x35dbc9,_0x53c4eb,_0x2ec1c8);if(v(_0x31175e))_0x59e42d=_0x184150['filter']['updateFullNode'](_0x53c4eb['eventCache']['getNode'](),_0x20403a,_0xa12e22),_0x381ca5=Rt(_0x53c4eb,_0x59e42d,!0x0,_0x184150['filter']['filtersNodes']());else{const _0x58b8f9=y(_0x31175e);if(_0x58b8f9==='.priority')_0x59e42d=_0x184150['filter']['updatePriority'](_0x53c4eb['eventCache']['getNode'](),_0x20403a),_0x381ca5=Rt(_0x53c4eb,_0x59e42d,_0x3c5343['isFullyInitialized'](),_0x3c5343['isFiltered']());else{const _0x7a5850=S(_0x31175e),_0x52709d=_0x3c5343['getNode']()['getImmediateChild'](_0x58b8f9);let _0x3730a5;if(v(_0x7a5850))_0x3730a5=_0x20403a;else{const _0x18b9e3=_0x308866['getCompleteChild'](_0x58b8f9);_0x18b9e3!=null?ji(_0x7a5850)==='.priority'&&_0x18b9e3['getChild'](Ro(_0x7a5850))['isEmpty']()?_0x3730a5=_0x18b9e3:_0x3730a5=_0x18b9e3['updateChild'](_0x7a5850,_0x20403a):_0x3730a5=g['EMPTY_NODE'];}if(_0x52709d['equals'](_0x3730a5))_0x381ca5=_0x53c4eb;else{const _0x459a9c=_0x184150['filter']['updateChild'](_0x3c5343['getNode'](),_0x58b8f9,_0x3730a5,_0x7a5850,_0x308866,_0xa12e22);_0x381ca5=Rt(_0x53c4eb,_0x459a9c,_0x3c5343['isFullyInitialized'](),_0x184150['filter']['filtersNodes']());}}}return _0x381ca5;}function lr(_0x515081,_0x9b861e){return _0x515081['eventCache']['isCompleteForChild'](_0x9b861e);}function ku(_0x459c68,_0xbdcaba,_0x78b7eb,_0x43b2b0,_0x253d94,_0x47ce17,_0x5d8c1d){let _0x59e013=_0xbdcaba;return _0x43b2b0['foreach']((_0x48cf22,_0x6f73f3)=>{const _0x54f975=k(_0x78b7eb,_0x48cf22);lr(_0xbdcaba,y(_0x54f975))&&(_0x59e013=ki(_0x459c68,_0x59e013,_0x54f975,_0x6f73f3,_0x253d94,_0x47ce17,_0x5d8c1d));}),_0x43b2b0['foreach']((_0x5da4a6,_0x4a173a)=>{const _0x4acb5c=k(_0x78b7eb,_0x5da4a6);lr(_0xbdcaba,y(_0x4acb5c))||(_0x59e013=ki(_0x459c68,_0x59e013,_0x4acb5c,_0x4a173a,_0x253d94,_0x47ce17,_0x5d8c1d));}),_0x59e013;}function hr(_0x1b1e55,_0x37029d,_0x217dd6){return _0x217dd6['foreach']((_0x59b3c9,_0x17caa8)=>{_0x37029d=_0x37029d['updateChild'](_0x59b3c9,_0x17caa8);}),_0x37029d;}function Pi(_0x99e58c,_0x523586,_0x49706c,_0x2eece6,_0x4c137a,_0x45c893,_0x508456,_0x303a5f){if(_0x523586['serverCache']['getNode']()['isEmpty']()&&!_0x523586['serverCache']['isFullyInitialized']())return _0x523586;let _0x5ec946=_0x523586,_0x524aac;v(_0x49706c)?_0x524aac=_0x2eece6:_0x524aac=new b(null)['setTree'](_0x49706c,_0x2eece6);const _0x13ae32=_0x523586['serverCache']['getNode']();return _0x524aac['children']['inorderTraversal']((_0x3969d7,_0x22031e)=>{if(_0x13ae32['hasChild'](_0x3969d7)){const _0xdebb04=_0x523586['serverCache']['getNode']()['getImmediateChild'](_0x3969d7),_0x133ab0=hr(_0x99e58c,_0xdebb04,_0x22031e);_0x5ec946=Sn(_0x99e58c,_0x5ec946,new C(_0x3969d7),_0x133ab0,_0x4c137a,_0x45c893,_0x508456,_0x303a5f);}}),_0x524aac['children']['inorderTraversal']((_0x51b122,_0x334ac7)=>{const _0x53327c=!_0x523586['serverCache']['isCompleteForChild'](_0x51b122)&&_0x334ac7['value']===null;if(!_0x13ae32['hasChild'](_0x51b122)&&!_0x53327c){const _0x1f7571=_0x523586['serverCache']['getNode']()['getImmediateChild'](_0x51b122),_0xbfec75=hr(_0x99e58c,_0x1f7571,_0x334ac7);_0x5ec946=Sn(_0x99e58c,_0x5ec946,new C(_0x51b122),_0xbfec75,_0x4c137a,_0x45c893,_0x508456,_0x303a5f);}}),_0x5ec946;}function Pu(_0x1a7eaa,_0x1d1b85,_0x2a31a1,_0x14cc2a,_0x3940fa,_0x479b36,_0x1d8cf7){if(Tn(_0x3940fa,_0x2a31a1)!=null)return _0x1d1b85;const _0x61d11=_0x1d1b85['serverCache']['isFiltered'](),_0x15cf9a=_0x1d1b85['serverCache'];if(_0x14cc2a['value']!=null){if(v(_0x2a31a1)&&_0x15cf9a['isFullyInitialized']()||_0x15cf9a['isCompleteForPath'](_0x2a31a1))return Sn(_0x1a7eaa,_0x1d1b85,_0x2a31a1,_0x15cf9a['getNode']()['getChild'](_0x2a31a1),_0x3940fa,_0x479b36,_0x61d11,_0x1d8cf7);if(v(_0x2a31a1)){let _0x5f4d05=new b(null);return _0x15cf9a['getNode']()['forEachChild'](ve,(_0x46984e,_0x72ad34)=>{_0x5f4d05=_0x5f4d05['set'](new C(_0x46984e),_0x72ad34);}),Pi(_0x1a7eaa,_0x1d1b85,_0x2a31a1,_0x5f4d05,_0x3940fa,_0x479b36,_0x61d11,_0x1d8cf7);}else return _0x1d1b85;}else{let _0x40a63e=new b(null);return _0x14cc2a['foreach']((_0x2d96f9,_0x45221d)=>{const _0x188306=k(_0x2a31a1,_0x2d96f9);_0x15cf9a['isCompleteForPath'](_0x188306)&&(_0x40a63e=_0x40a63e['set'](_0x2d96f9,_0x15cf9a['getNode']()['getChild'](_0x188306)));}),Pi(_0x1a7eaa,_0x1d1b85,_0x2a31a1,_0x40a63e,_0x3940fa,_0x479b36,_0x61d11,_0x1d8cf7);}}function Nu(_0x276ee3,_0x12e63a,_0x2c9368,_0x2fd86d,_0x190072){const _0x2491ee=_0x12e63a['serverCache'],_0x4c920d=Fo(_0x12e63a,_0x2491ee['getNode'](),_0x2491ee['isFullyInitialized']()||v(_0x2c9368),_0x2491ee['isFiltered']());return Go(_0x276ee3,_0x4c920d,_0x2c9368,_0x2fd86d,$o,_0x190072);}function Ou(_0x163730,_0x311931,_0x2f553c,_0x497ee0,_0x117aaf,_0x5edb4d){let _0x47b7b3;if(Tn(_0x497ee0,_0x2f553c)!=null)return _0x311931;{const _0x40a962=new rs(_0x497ee0,_0x311931,_0x117aaf),_0x29bc4d=_0x311931['eventCache']['getNode']();let _0x1955be;if(v(_0x2f553c)||y(_0x2f553c)==='.priority'){let _0x4606ed;if(_0x311931['serverCache']['isFullyInitialized']())_0x4606ed=Cn(_0x497ee0,Ve(_0x311931));else{const _0x5027af=_0x311931['serverCache']['getNode']();f(_0x5027af instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x4606ed=is(_0x497ee0,_0x5027af);}_0x4606ed=_0x4606ed,_0x1955be=_0x163730['filter']['updateFullNode'](_0x29bc4d,_0x4606ed,_0x5edb4d);}else{const _0x12d206=y(_0x2f553c);let _0x1ac077=ss(_0x497ee0,_0x12d206,_0x311931['serverCache']);_0x1ac077==null&&_0x311931['serverCache']['isCompleteForChild'](_0x12d206)&&(_0x1ac077=_0x29bc4d['getImmediateChild'](_0x12d206)),_0x1ac077!=null?_0x1955be=_0x163730['filter']['updateChild'](_0x29bc4d,_0x12d206,_0x1ac077,S(_0x2f553c),_0x40a962,_0x5edb4d):_0x311931['eventCache']['getNode']()['hasChild'](_0x12d206)?_0x1955be=_0x163730['filter']['updateChild'](_0x29bc4d,_0x12d206,g['EMPTY_NODE'],S(_0x2f553c),_0x40a962,_0x5edb4d):_0x1955be=_0x29bc4d,_0x1955be['isEmpty']()&&_0x311931['serverCache']['isFullyInitialized']()&&(_0x47b7b3=Cn(_0x497ee0,Ve(_0x311931)),_0x47b7b3['isLeafNode']()&&(_0x1955be=_0x163730['filter']['updateFullNode'](_0x1955be,_0x47b7b3,_0x5edb4d)));}return _0x47b7b3=_0x311931['serverCache']['isFullyInitialized']()||Tn(_0x497ee0,w())!=null,Rt(_0x311931,_0x1955be,_0x47b7b3,_0x163730['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x1f4dee,_0x1e9634){this['query_']=_0x1f4dee,this['eventRegistrations_']=[];const _0x4aba19=this['query_']['_queryParams'],_0x3aff7d=new Xi(_0x4aba19['getIndex']()),_0x5d7456=Kh(_0x4aba19);this['processor_']=Su(_0x5d7456);const _0x3cb4a0=_0x1e9634['serverCache'],_0x2b8634=_0x1e9634['eventCache'],_0xb0d718=_0x3aff7d['updateFullNode'](g['EMPTY_NODE'],_0x3cb4a0['getNode'](),null),_0x5a396c=_0x5d7456['updateFullNode'](g['EMPTY_NODE'],_0x2b8634['getNode'](),null),_0x622f8a=new Te(_0xb0d718,_0x3cb4a0['isFullyInitialized'](),_0x3aff7d['filtersNodes']()),_0x19a2db=new Te(_0x5a396c,_0x2b8634['isFullyInitialized'](),_0x5d7456['filtersNodes']());this['viewCache_']=Un(_0x19a2db,_0x622f8a),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x2098eb){return _0x2098eb['viewCache_']['serverCache']['getNode']();}function Lu(_0x5346bf){return wn(_0x5346bf['viewCache_']);}function xu(_0x5bde88,_0x1c614d){const _0x205915=Ve(_0x5bde88['viewCache_']);return _0x205915&&(_0x5bde88['query']['_queryParams']['loadsAllData']()||!v(_0x1c614d)&&!_0x205915['getImmediateChild'](y(_0x1c614d))['isEmpty']())?_0x205915['getChild'](_0x1c614d):null;}function ur(_0x472557){return _0x472557['eventRegistrations_']['length']===0x0;}function Fu(_0x127886,_0x619f1a){_0x127886['eventRegistrations_']['push'](_0x619f1a);}function dr(_0x5abae0,_0x175196,_0x6f992){const _0x45c30d=[];if(_0x6f992){f(_0x175196==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x5cbfb9=_0x5abae0['query']['_path'];_0x5abae0['eventRegistrations_']['forEach'](_0x3a1907=>{const _0x57049a=_0x3a1907['createCancelEvent'](_0x6f992,_0x5cbfb9);_0x57049a&&_0x45c30d['push'](_0x57049a);});}if(_0x175196){let _0x3525a8=[];for(let _0x2991b0=0x0;_0x2991b0<_0x5abae0['eventRegistrations_']['length'];++_0x2991b0){const _0x479f16=_0x5abae0['eventRegistrations_'][_0x2991b0];if(!_0x479f16['matches'](_0x175196))_0x3525a8['push'](_0x479f16);else{if(_0x175196['hasAnyCallback']()){_0x3525a8=_0x3525a8['concat'](_0x5abae0['eventRegistrations_']['slice'](_0x2991b0+0x1));break;}}}_0x5abae0['eventRegistrations_']=_0x3525a8;}else _0x5abae0['eventRegistrations_']=[];return _0x45c30d;}function fr(_0x27f425,_0x28ca67,_0x2b985d,_0x3d9889){_0x28ca67['type']===z['MERGE']&&_0x28ca67['source']['queryId']!==null&&(f(Ve(_0x27f425['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x27f425['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x15e345=_0x27f425['viewCache_'],_0x6bd0a1=Ru(_0x27f425['processor_'],_0x15e345,_0x28ca67,_0x2b985d,_0x3d9889);return bu(_0x27f425['processor_'],_0x6bd0a1['viewCache']),f(_0x6bd0a1['viewCache']['serverCache']['isFullyInitialized']()||!_0x15e345['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x27f425['viewCache_']=_0x6bd0a1['viewCache'],qo(_0x27f425,_0x6bd0a1['changes'],_0x6bd0a1['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x41e94f,_0x57fca9){const _0x50d01d=_0x41e94f['viewCache_']['eventCache'],_0x1f09e1=[];return _0x50d01d['getNode']()['isLeafNode']()||_0x50d01d['getNode']()['forEachChild'](R,(_0x4a01d4,_0x4980bd)=>{_0x1f09e1['push'](rt(_0x4a01d4,_0x4980bd));}),_0x50d01d['isFullyInitialized']()&&_0x1f09e1['push'](Lo(_0x50d01d['getNode']())),qo(_0x41e94f,_0x1f09e1,_0x50d01d['getNode'](),_0x57fca9);}function qo(_0x463d37,_0x4e61a7,_0xa30cda,_0x2338c9){const _0x39f253=_0x2338c9?[_0x2338c9]:_0x463d37['eventRegistrations_'];return ru(_0x463d37['eventGenerator_'],_0x4e61a7,_0xa30cda,_0x39f253);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x28e2d8){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x28e2d8;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x3b46f2){return _0x3b46f2['views']['size']===0x0;}function os(_0x159447,_0x34fd4d,_0x9fd1c7,_0x186aee){const _0x1de80e=_0x34fd4d['source']['queryId'];if(_0x1de80e!==null){const _0x1d20af=_0x159447['views']['get'](_0x1de80e);return f(_0x1d20af!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x1d20af,_0x34fd4d,_0x9fd1c7,_0x186aee);}else{let _0x157cc8=[];for(const _0x2cf1fd of _0x159447['views']['values']())_0x157cc8=_0x157cc8['concat'](fr(_0x2cf1fd,_0x34fd4d,_0x9fd1c7,_0x186aee));return _0x157cc8;}}function jo(_0x3c2d46,_0x1ab439,_0x4a7a95,_0xfb2abf,_0x1cf7b5){const _0x4f9235=_0x1ab439['_queryIdentifier'],_0x56a005=_0x3c2d46['views']['get'](_0x4f9235);if(!_0x56a005){let _0x7e439f=Cn(_0x4a7a95,_0x1cf7b5?_0xfb2abf:null),_0x1af3a3=!0x1;_0x7e439f?_0x1af3a3=!0x0:_0xfb2abf instanceof g?(_0x7e439f=is(_0x4a7a95,_0xfb2abf),_0x1af3a3=!0x1):(_0x7e439f=g['EMPTY_NODE'],_0x1af3a3=!0x1);const _0xc46396=Un(new Te(_0x7e439f,_0x1af3a3,!0x1),new Te(_0xfb2abf,_0x1cf7b5,!0x1));return new Du(_0x1ab439,_0xc46396);}return _0x56a005;}function Hu(_0xe5c80c,_0x524035,_0x2380b1,_0x504513,_0xbd3d58,_0x487787){const _0x490236=jo(_0xe5c80c,_0x524035,_0x504513,_0xbd3d58,_0x487787);return _0xe5c80c['views']['has'](_0x524035['_queryIdentifier'])||_0xe5c80c['views']['set'](_0x524035['_queryIdentifier'],_0x490236),Fu(_0x490236,_0x2380b1),Uu(_0x490236,_0x2380b1);}function $u(_0x3abca0,_0xa43318,_0x61ee21,_0x25c253){const _0x27af5f=_0xa43318['_queryIdentifier'],_0x410c94=[];let _0x3a0cb4=[];const _0x40e121=Se(_0x3abca0);if(_0x27af5f==='default'){for(const [_0x1f6758,_0x3c4df5]of _0x3abca0['views']['entries']())_0x3a0cb4=_0x3a0cb4['concat'](dr(_0x3c4df5,_0x61ee21,_0x25c253)),ur(_0x3c4df5)&&(_0x3abca0['views']['delete'](_0x1f6758),_0x3c4df5['query']['_queryParams']['loadsAllData']()||_0x410c94['push'](_0x3c4df5['query']));}else{const _0x4fa4a2=_0x3abca0['views']['get'](_0x27af5f);_0x4fa4a2&&(_0x3a0cb4=_0x3a0cb4['concat'](dr(_0x4fa4a2,_0x61ee21,_0x25c253)),ur(_0x4fa4a2)&&(_0x3abca0['views']['delete'](_0x27af5f),_0x4fa4a2['query']['_queryParams']['loadsAllData']()||_0x410c94['push'](_0x4fa4a2['query'])));}return _0x40e121&&!Se(_0x3abca0)&&_0x410c94['push'](new(Bu())(_0xa43318['_repo'],_0xa43318['_path'])),{'removed':_0x410c94,'events':_0x3a0cb4};}function Ko(_0x47cd5f){const _0x37201a=[];for(const _0x45c1dd of _0x47cd5f['views']['values']())_0x45c1dd['query']['_queryParams']['loadsAllData']()||_0x37201a['push'](_0x45c1dd);return _0x37201a;}function Ie(_0x2f1e7d,_0x382cb3){let _0x16bbed=null;for(const _0x57712b of _0x2f1e7d['views']['values']())_0x16bbed=_0x16bbed||xu(_0x57712b,_0x382cb3);return _0x16bbed;}function Yo(_0x5a2967,_0x43ec14){if(_0x43ec14['_queryParams']['loadsAllData']())return Bn(_0x5a2967);{const _0x57d724=_0x43ec14['_queryIdentifier'];return _0x5a2967['views']['get'](_0x57d724);}}function Qo(_0x3fc853,_0x599588){return Yo(_0x3fc853,_0x599588)!=null;}function Se(_0xd0df0){return Bn(_0xd0df0)!=null;}function Bn(_0x96d42d){for(const _0x2feb23 of _0x96d42d['views']['values']())if(_0x2feb23['query']['_queryParams']['loadsAllData']())return _0x2feb23;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x320274){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x320274;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x5c5e93){this['listenProvider_']=_0x5c5e93,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x52fb75,_0xc52d12,_0xbefad4,_0x102933,_0x4d29b9){return lu(_0x52fb75['pendingWriteTree_'],_0xc52d12,_0xbefad4,_0x102933,_0x4d29b9),_0x4d29b9?_t(_0x52fb75,new Be(es(),_0xc52d12,_0xbefad4)):[];}function ju(_0x22fc0b,_0x381a09,_0x20724a,_0x31160e){hu(_0x22fc0b['pendingWriteTree_'],_0x381a09,_0x20724a,_0x31160e);const _0x2ba9b6=b['fromObject'](_0x20724a);return _t(_0x22fc0b,new ot(es(),_0x381a09,_0x2ba9b6));}function _e(_0x4cbc11,_0x2cd3b5,_0x95fcab=!0x1){const _0x54c690=uu(_0x4cbc11['pendingWriteTree_'],_0x2cd3b5);if(du(_0x4cbc11['pendingWriteTree_'],_0x2cd3b5)){let _0x4c8587=new b(null);return _0x54c690['snap']!=null?_0x4c8587=_0x4c8587['set'](w(),!0x0):x(_0x54c690['children'],_0xf28b00=>{_0x4c8587=_0x4c8587['set'](new C(_0xf28b00),!0x0);}),_t(_0x4cbc11,new In(_0x54c690['path'],_0x4c8587,_0x95fcab));}else return[];}function Yt(_0x5e615d,_0x27ad2c,_0x389b6b){return _t(_0x5e615d,new Be(ts(),_0x27ad2c,_0x389b6b));}function Ku(_0x2dafc0,_0x35d2b3,_0x421a12){const _0x1bdeb5=b['fromObject'](_0x421a12);return _t(_0x2dafc0,new ot(ts(),_0x35d2b3,_0x1bdeb5));}function Yu(_0x567881,_0x72b471){return _t(_0x567881,new Ut(ts(),_0x72b471));}function Qu(_0x253f7b,_0x28bd7b,_0x57ae80){const _0x1f12c6=cs(_0x253f7b,_0x57ae80);if(_0x1f12c6){const _0xe74c7d=ls(_0x1f12c6),_0x54f3bc=_0xe74c7d['path'],_0x4170ab=_0xe74c7d['queryId'],_0x44b6a2=F(_0x54f3bc,_0x28bd7b),_0x1df99a=new Ut(ns(_0x4170ab),_0x44b6a2);return hs(_0x253f7b,_0x54f3bc,_0x1df99a);}else return[];}function An(_0xc3c31b,_0x199945,_0x41429d,_0x13ac31,_0x261174=!0x1){const _0x2290d7=_0x199945['_path'],_0x229ad8=_0xc3c31b['syncPointTree_']['get'](_0x2290d7);let _0x2c09fc=[];if(_0x229ad8&&(_0x199945['_queryIdentifier']==='default'||Qo(_0x229ad8,_0x199945))){const _0x2eef4b=$u(_0x229ad8,_0x199945,_0x41429d,_0x13ac31);Vu(_0x229ad8)&&(_0xc3c31b['syncPointTree_']=_0xc3c31b['syncPointTree_']['remove'](_0x2290d7));const _0x337577=_0x2eef4b['removed'];if(_0x2c09fc=_0x2eef4b['events'],!_0x261174){const _0x3ad965=_0x337577['findIndex'](_0x30fbe4=>_0x30fbe4['_queryParams']['loadsAllData']())!==-0x1,_0x23f54a=_0xc3c31b['syncPointTree_']['findOnPath'](_0x2290d7,(_0x170160,_0x2b60b9)=>Se(_0x2b60b9));if(_0x3ad965&&!_0x23f54a){const _0x535888=_0xc3c31b['syncPointTree_']['subtree'](_0x2290d7);if(!_0x535888['isEmpty']()){const _0x1a001b=Zu(_0x535888);for(let _0x22cbe5=0x0;_0x22cbe5<_0x1a001b['length'];++_0x22cbe5){const _0x52a190=_0x1a001b[_0x22cbe5],_0x11d537=_0x52a190['query'],_0x39e0af=ea(_0xc3c31b,_0x52a190);_0xc3c31b['listenProvider_']['startListening'](kt(_0x11d537),Wt(_0xc3c31b,_0x11d537),_0x39e0af['hashFn'],_0x39e0af['onComplete']);}}}!_0x23f54a&&_0x337577['length']>0x0&&!_0x13ac31&&(_0x3ad965?_0xc3c31b['listenProvider_']['stopListening'](kt(_0x199945),null):_0x337577['forEach'](_0x140b44=>{const _0x2fa24b=_0xc3c31b['queryToTagMap']['get'](Hn(_0x140b44));_0xc3c31b['listenProvider_']['stopListening'](kt(_0x140b44),_0x2fa24b);}));}ed(_0xc3c31b,_0x337577);}return _0x2c09fc;}function Jo(_0x25bf1f,_0x587ebc,_0x1054f0,_0x3655e3){const _0x57dca6=cs(_0x25bf1f,_0x3655e3);if(_0x57dca6!=null){const _0x19f6b3=ls(_0x57dca6),_0x4fc17f=_0x19f6b3['path'],_0xb168e8=_0x19f6b3['queryId'],_0x20db15=F(_0x4fc17f,_0x587ebc),_0xb5787d=new Be(ns(_0xb168e8),_0x20db15,_0x1054f0);return hs(_0x25bf1f,_0x4fc17f,_0xb5787d);}else return[];}function Ju(_0x1252b1,_0xc7ba5,_0x1d1d70,_0x29682f){const _0x3a329f=cs(_0x1252b1,_0x29682f);if(_0x3a329f){const _0x56bc94=ls(_0x3a329f),_0x3b694e=_0x56bc94['path'],_0x3015cd=_0x56bc94['queryId'],_0x43bf60=F(_0x3b694e,_0xc7ba5),_0x312170=b['fromObject'](_0x1d1d70),_0x1f2ea3=new ot(ns(_0x3015cd),_0x43bf60,_0x312170);return hs(_0x1252b1,_0x3b694e,_0x1f2ea3);}else return[];}function Ni(_0x5ad689,_0x19cd6b,_0x1ed430,_0x1207ff=!0x1){const _0x591f56=_0x19cd6b['_path'];let _0x45f007=null,_0x3fa73e=!0x1;_0x5ad689['syncPointTree_']['foreachOnPath'](_0x591f56,(_0x23c70c,_0x5d5d59)=>{const _0x3161c9=F(_0x23c70c,_0x591f56);_0x45f007=_0x45f007||Ie(_0x5d5d59,_0x3161c9),_0x3fa73e=_0x3fa73e||Se(_0x5d5d59);});let _0x289288=_0x5ad689['syncPointTree_']['get'](_0x591f56);_0x289288?(_0x3fa73e=_0x3fa73e||Se(_0x289288),_0x45f007=_0x45f007||Ie(_0x289288,w())):(_0x289288=new zo(),_0x5ad689['syncPointTree_']=_0x5ad689['syncPointTree_']['set'](_0x591f56,_0x289288));let _0x568621;_0x45f007!=null?_0x568621=!0x0:(_0x568621=!0x1,_0x45f007=g['EMPTY_NODE'],_0x5ad689['syncPointTree_']['subtree'](_0x591f56)['foreachChild']((_0x5a10ea,_0x42a2e6)=>{const _0x1587d3=Ie(_0x42a2e6,w());_0x1587d3&&(_0x45f007=_0x45f007['updateImmediateChild'](_0x5a10ea,_0x1587d3));}));const _0x2f06f8=Qo(_0x289288,_0x19cd6b);if(!_0x2f06f8&&!_0x19cd6b['_queryParams']['loadsAllData']()){const _0xc9314e=Hn(_0x19cd6b);f(!_0x5ad689['queryToTagMap']['has'](_0xc9314e),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x19347f=td();_0x5ad689['queryToTagMap']['set'](_0xc9314e,_0x19347f),_0x5ad689['tagToQueryMap']['set'](_0x19347f,_0xc9314e);}const _0x1dc4ba=Wn(_0x5ad689['pendingWriteTree_'],_0x591f56);let _0xbef1d7=Hu(_0x289288,_0x19cd6b,_0x1ed430,_0x1dc4ba,_0x45f007,_0x568621);if(!_0x2f06f8&&!_0x3fa73e&&!_0x1207ff){const _0x5d9f73=Yo(_0x289288,_0x19cd6b);_0xbef1d7=_0xbef1d7['concat'](nd(_0x5ad689,_0x19cd6b,_0x5d9f73));}return _0xbef1d7;}function Vn(_0x2591c7,_0x565a33,_0x4b910e){const _0x1d68d4=_0x2591c7['pendingWriteTree_'],_0x51e892=_0x2591c7['syncPointTree_']['findOnPath'](_0x565a33,(_0xceaef9,_0x49df56)=>{const _0x29654e=F(_0xceaef9,_0x565a33),_0x4e113b=Ie(_0x49df56,_0x29654e);if(_0x4e113b)return _0x4e113b;});return Bo(_0x1d68d4,_0x565a33,_0x51e892,_0x4b910e,!0x0);}function Xu(_0x3e0b8f,_0x4415a4){const _0x6757ba=_0x4415a4['_path'];let _0x3db0c7=null;_0x3e0b8f['syncPointTree_']['foreachOnPath'](_0x6757ba,(_0x1f1780,_0x52a1e9)=>{const _0x18fe82=F(_0x1f1780,_0x6757ba);_0x3db0c7=_0x3db0c7||Ie(_0x52a1e9,_0x18fe82);});let _0x51b3f5=_0x3e0b8f['syncPointTree_']['get'](_0x6757ba);_0x51b3f5?_0x3db0c7=_0x3db0c7||Ie(_0x51b3f5,w()):(_0x51b3f5=new zo(),_0x3e0b8f['syncPointTree_']=_0x3e0b8f['syncPointTree_']['set'](_0x6757ba,_0x51b3f5));const _0x1d18ef=_0x3db0c7!=null,_0x43af25=_0x1d18ef?new Te(_0x3db0c7,!0x0,!0x1):null,_0x14c830=Wn(_0x3e0b8f['pendingWriteTree_'],_0x4415a4['_path']),_0x18fe95=jo(_0x51b3f5,_0x4415a4,_0x14c830,_0x1d18ef?_0x43af25['getNode']():g['EMPTY_NODE'],_0x1d18ef);return Lu(_0x18fe95);}function _t(_0x2125a9,_0x113489){return Xo(_0x113489,_0x2125a9['syncPointTree_'],null,Wn(_0x2125a9['pendingWriteTree_'],w()));}function Xo(_0xcb7b8e,_0x40695d,_0xd9e206,_0x5dfa2a){if(v(_0xcb7b8e['path']))return Zo(_0xcb7b8e,_0x40695d,_0xd9e206,_0x5dfa2a);{const _0x4cecd0=_0x40695d['get'](w());_0xd9e206==null&&_0x4cecd0!=null&&(_0xd9e206=Ie(_0x4cecd0,w()));let _0x12d9d3=[];const _0x868241=y(_0xcb7b8e['path']),_0x4d909b=_0xcb7b8e['operationForChild'](_0x868241),_0x53f41d=_0x40695d['children']['get'](_0x868241);if(_0x53f41d&&_0x4d909b){const _0x24a8e7=_0xd9e206?_0xd9e206['getImmediateChild'](_0x868241):null,_0x42c1d7=Vo(_0x5dfa2a,_0x868241);_0x12d9d3=_0x12d9d3['concat'](Xo(_0x4d909b,_0x53f41d,_0x24a8e7,_0x42c1d7));}return _0x4cecd0&&(_0x12d9d3=_0x12d9d3['concat'](os(_0x4cecd0,_0xcb7b8e,_0x5dfa2a,_0xd9e206))),_0x12d9d3;}}function Zo(_0x5f42d5,_0x27164c,_0x3aef92,_0x5be974){const _0x589d96=_0x27164c['get'](w());_0x3aef92==null&&_0x589d96!=null&&(_0x3aef92=Ie(_0x589d96,w()));let _0x40f125=[];return _0x27164c['children']['inorderTraversal']((_0x9acb50,_0x6a70d8)=>{const _0x2d4cef=_0x3aef92?_0x3aef92['getImmediateChild'](_0x9acb50):null,_0x29f7f7=Vo(_0x5be974,_0x9acb50),_0x2b00e1=_0x5f42d5['operationForChild'](_0x9acb50);_0x2b00e1&&(_0x40f125=_0x40f125['concat'](Zo(_0x2b00e1,_0x6a70d8,_0x2d4cef,_0x29f7f7)));}),_0x589d96&&(_0x40f125=_0x40f125['concat'](os(_0x589d96,_0x5f42d5,_0x5be974,_0x3aef92))),_0x40f125;}function ea(_0x306c60,_0x47102d){const _0x577a09=_0x47102d['query'],_0x2d6aff=Wt(_0x306c60,_0x577a09);return{'hashFn':()=>(Mu(_0x47102d)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x20679c=>{if(_0x20679c==='ok')return _0x2d6aff?Qu(_0x306c60,_0x577a09['_path'],_0x2d6aff):Yu(_0x306c60,_0x577a09['_path']);{const _0x13e003=Kl(_0x20679c,_0x577a09);return An(_0x306c60,_0x577a09,null,_0x13e003);}}};}function Wt(_0x49a537,_0x73349f){const _0x1ddec9=Hn(_0x73349f);return _0x49a537['queryToTagMap']['get'](_0x1ddec9);}function Hn(_0x215102){return _0x215102['_path']['toString']()+'$'+_0x215102['_queryIdentifier'];}function cs(_0x224e60,_0x2aef73){return _0x224e60['tagToQueryMap']['get'](_0x2aef73);}function ls(_0x3b14ee){const _0x43ad9e=_0x3b14ee['indexOf']('$');return f(_0x43ad9e!==-0x1&&_0x43ad9e<_0x3b14ee['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x3b14ee['substr'](_0x43ad9e+0x1),'path':new C(_0x3b14ee['substr'](0x0,_0x43ad9e))};}function hs(_0x5ea60c,_0x4560b0,_0x54f17d){const _0x1d126c=_0x5ea60c['syncPointTree_']['get'](_0x4560b0);f(_0x1d126c,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x23f0af=Wn(_0x5ea60c['pendingWriteTree_'],_0x4560b0);return os(_0x1d126c,_0x54f17d,_0x23f0af,null);}function Zu(_0x252ddf){return _0x252ddf['fold']((_0x16d916,_0x2c46c2,_0xff4ab5)=>{if(_0x2c46c2&&Se(_0x2c46c2))return[Bn(_0x2c46c2)];{let _0x2d59eb=[];return _0x2c46c2&&(_0x2d59eb=Ko(_0x2c46c2)),x(_0xff4ab5,(_0x48a954,_0x41503d)=>{_0x2d59eb=_0x2d59eb['concat'](_0x41503d);}),_0x2d59eb;}});}function kt(_0x107e60){return _0x107e60['_queryParams']['loadsAllData']()&&!_0x107e60['_queryParams']['isDefault']()?new(qu())(_0x107e60['_repo'],_0x107e60['_path']):_0x107e60;}function ed(_0x275d77,_0x442cb1){for(let _0x280003=0x0;_0x280003<_0x442cb1['length'];++_0x280003){const _0x46c5d2=_0x442cb1[_0x280003];if(!_0x46c5d2['_queryParams']['loadsAllData']()){const _0x124955=Hn(_0x46c5d2),_0xe77127=_0x275d77['queryToTagMap']['get'](_0x124955);_0x275d77['queryToTagMap']['delete'](_0x124955),_0x275d77['tagToQueryMap']['delete'](_0xe77127);}}}function td(){return zu++;}function nd(_0x5de0c5,_0x5363b6,_0x2df47c){const _0x70fd25=_0x5363b6['_path'],_0x15427e=Wt(_0x5de0c5,_0x5363b6),_0x39cfbe=ea(_0x5de0c5,_0x2df47c),_0x222158=_0x5de0c5['listenProvider_']['startListening'](kt(_0x5363b6),_0x15427e,_0x39cfbe['hashFn'],_0x39cfbe['onComplete']),_0x506a83=_0x5de0c5['syncPointTree_']['subtree'](_0x70fd25);if(_0x15427e)f(!Se(_0x506a83['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x353f79=_0x506a83['fold']((_0x407ee5,_0xe4dbc3,_0x1165ef)=>{if(!v(_0x407ee5)&&_0xe4dbc3&&Se(_0xe4dbc3))return[Bn(_0xe4dbc3)['query']];{let _0x102b81=[];return _0xe4dbc3&&(_0x102b81=_0x102b81['concat'](Ko(_0xe4dbc3)['map'](_0x323439=>_0x323439['query']))),x(_0x1165ef,(_0x2be502,_0x8dc9f7)=>{_0x102b81=_0x102b81['concat'](_0x8dc9f7);}),_0x102b81;}});for(let _0x167eb1=0x0;_0x167eb1<_0x353f79['length'];++_0x167eb1){const _0x66db00=_0x353f79[_0x167eb1];_0x5de0c5['listenProvider_']['stopListening'](kt(_0x66db00),Wt(_0x5de0c5,_0x66db00));}}return _0x222158;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x487e5d){this['node_']=_0x487e5d;}['getImmediateChild'](_0x663be0){const _0x1a5afd=this['node_']['getImmediateChild'](_0x663be0);return new us(_0x1a5afd);}['node'](){return this['node_'];}}class ds{constructor(_0x32a9ac,_0x5c8622){this['syncTree_']=_0x32a9ac,this['path_']=_0x5c8622;}['getImmediateChild'](_0x407b94){const _0x11b4bd=k(this['path_'],_0x407b94);return new ds(this['syncTree_'],_0x11b4bd);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0xd9c205){return _0xd9c205=_0xd9c205||{},_0xd9c205['timestamp']=_0xd9c205['timestamp']||new Date()['getTime'](),_0xd9c205;},_r=function(_0x48341f,_0x2cbf7b,_0x420e36){if(!_0x48341f||typeof _0x48341f!='object')return _0x48341f;if(f('.sv'in _0x48341f,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x48341f['.sv']=='string')return sd(_0x48341f['.sv'],_0x2cbf7b,_0x420e36);if(typeof _0x48341f['.sv']=='object')return rd(_0x48341f['.sv'],_0x2cbf7b);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x48341f,null,0x2));},sd=function(_0x2e1bf7,_0x1ed997,_0x14ad44){switch(_0x2e1bf7){case'timestamp':return _0x14ad44['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x2e1bf7);}},rd=function(_0x52a0cc,_0x24ab69,_0x121f99){_0x52a0cc['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x52a0cc,null,0x2));const _0x7affff=_0x52a0cc['increment'];typeof _0x7affff!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x7affff);const _0xc9694b=_0x24ab69['node']();if(f(_0xc9694b!==null&&typeof _0xc9694b<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0xc9694b['isLeafNode']())return _0x7affff;const _0x266429=_0xc9694b['getValue']();return typeof _0x266429!='number'?_0x7affff:_0x266429+_0x7affff;},ta=function(_0x408d1c,_0x11f7af,_0x145a4a,_0x58b6fa){return ps(_0x11f7af,new ds(_0x145a4a,_0x408d1c),_0x58b6fa);},fs=function(_0x51f415,_0xd33605,_0x2d4bc5){return ps(_0x51f415,new us(_0xd33605),_0x2d4bc5);};function ps(_0x111df8,_0xc74ca5,_0x313e8c){const _0x2c7d99=_0x111df8['getPriority']()['val'](),_0xf0dbfd=_r(_0x2c7d99,_0xc74ca5['getImmediateChild']('.priority'),_0x313e8c);let _0x436522;if(_0x111df8['isLeafNode']()){const _0x4bb40d=_0x111df8,_0xc419d8=_r(_0x4bb40d['getValue'](),_0xc74ca5,_0x313e8c);return _0xc419d8!==_0x4bb40d['getValue']()||_0xf0dbfd!==_0x4bb40d['getPriority']()['val']()?new D(_0xc419d8,A(_0xf0dbfd)):_0x111df8;}else{const _0x81d3d6=_0x111df8;return _0x436522=_0x81d3d6,_0xf0dbfd!==_0x81d3d6['getPriority']()['val']()&&(_0x436522=_0x436522['updatePriority'](new D(_0xf0dbfd))),_0x81d3d6['forEachChild'](R,(_0x5c116d,_0x584f8e)=>{const _0x2ebe04=ps(_0x584f8e,_0xc74ca5['getImmediateChild'](_0x5c116d),_0x313e8c);_0x2ebe04!==_0x584f8e&&(_0x436522=_0x436522['updateImmediateChild'](_0x5c116d,_0x2ebe04));}),_0x436522;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x11fb90='',_0x11ea3e=null,_0x591e83={'children':{},'childCount':0x0}){this['name']=_0x11fb90,this['parent']=_0x11ea3e,this['node']=_0x591e83;}}function $n(_0x55f913,_0x118b13){let _0x4971c8=_0x118b13 instanceof C?_0x118b13:new C(_0x118b13),_0x10301d=_0x55f913,_0x4fa239=y(_0x4971c8);for(;_0x4fa239!==null;){const _0x1057cf=Le(_0x10301d['node']['children'],_0x4fa239)||{'children':{},'childCount':0x0};_0x10301d=new _s(_0x4fa239,_0x10301d,_0x1057cf),_0x4971c8=S(_0x4971c8),_0x4fa239=y(_0x4971c8);}return _0x10301d;}function je(_0x8fec08){return _0x8fec08['node']['value'];}function gs(_0x9f1948,_0x2dfb00){_0x9f1948['node']['value']=_0x2dfb00,Oi(_0x9f1948);}function na(_0xa47520){return _0xa47520['node']['childCount']>0x0;}function od(_0x1ec4ed){return je(_0x1ec4ed)===void 0x0&&!na(_0x1ec4ed);}function Gn(_0x57056e,_0xfb6e92){x(_0x57056e['node']['children'],(_0x5a4882,_0x9082db)=>{_0xfb6e92(new _s(_0x5a4882,_0x57056e,_0x9082db));});}function ia(_0x390cc0,_0x4c52c2,_0x28d8fe,_0x424e43){_0x28d8fe&&_0x4c52c2(_0x390cc0),Gn(_0x390cc0,_0x128fd4=>{ia(_0x128fd4,_0x4c52c2,!0x0);});}function ad(_0x10dd02,_0x470bd8,_0x571315){let _0x261a1d=_0x10dd02['parent'];for(;_0x261a1d!==null;){if(_0x470bd8(_0x261a1d))return!0x0;_0x261a1d=_0x261a1d['parent'];}return!0x1;}function Qt(_0x2ae28a){return new C(_0x2ae28a['parent']===null?_0x2ae28a['name']:Qt(_0x2ae28a['parent'])+'/'+_0x2ae28a['name']);}function Oi(_0x602f5c){_0x602f5c['parent']!==null&&cd(_0x602f5c['parent'],_0x602f5c['name'],_0x602f5c);}function cd(_0x53ed36,_0x290e42,_0x39e7b6){const _0x32b7cf=od(_0x39e7b6),_0x4e9cc2=Q(_0x53ed36['node']['children'],_0x290e42);_0x32b7cf&&_0x4e9cc2?(delete _0x53ed36['node']['children'][_0x290e42],_0x53ed36['node']['childCount']--,Oi(_0x53ed36)):!_0x32b7cf&&!_0x4e9cc2&&(_0x53ed36['node']['children'][_0x290e42]=_0x39e7b6['node'],_0x53ed36['node']['childCount']++,Oi(_0x53ed36));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x41a114){return typeof _0x41a114=='string'&&_0x41a114['length']!==0x0&&!ld['test'](_0x41a114);},sa=function(_0x406ded){return typeof _0x406ded=='string'&&_0x406ded['length']!==0x0&&!hd['test'](_0x406ded);},ud=function(_0x26a6c1){return _0x26a6c1&&(_0x26a6c1=_0x26a6c1['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x26a6c1);},Bt=function(_0x305ee9){return _0x305ee9===null||typeof _0x305ee9=='string'||typeof _0x305ee9=='number'&&!xn(_0x305ee9)||_0x305ee9&&typeof _0x305ee9=='object'&&Q(_0x305ee9,'.sv');},He=function(_0x16c143,_0x347227,_0x5146fd,_0x4a889c){_0x4a889c&&_0x347227===void 0x0||Jt(it(_0x16c143,'value'),_0x347227,_0x5146fd);},Jt=function(_0x18c83f,_0x2c54b6,_0x2c5316){const _0x3f9961=_0x2c5316 instanceof C?new Ah(_0x2c5316,_0x18c83f):_0x2c5316;if(_0x2c54b6===void 0x0)throw new Error(_0x18c83f+'contains\x20undefined\x20'+Oe(_0x3f9961));if(typeof _0x2c54b6=='function')throw new Error(_0x18c83f+'contains\x20a\x20function\x20'+Oe(_0x3f9961)+'\x20with\x20contents\x20=\x20'+_0x2c54b6['toString']());if(xn(_0x2c54b6))throw new Error(_0x18c83f+'contains\x20'+_0x2c54b6['toString']()+'\x20'+Oe(_0x3f9961));if(typeof _0x2c54b6=='string'&&_0x2c54b6['length']>ui/0x3&&Ln(_0x2c54b6)>ui)throw new Error(_0x18c83f+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x3f9961)+'\x20(\x27'+_0x2c54b6['substring'](0x0,0x32)+'...\x27)');if(_0x2c54b6&&typeof _0x2c54b6=='object'){let _0x3c654b=!0x1,_0x41f7de=!0x1;if(x(_0x2c54b6,(_0x3398a5,_0x258bdd)=>{if(_0x3398a5==='.value')_0x3c654b=!0x0;else{if(_0x3398a5!=='.priority'&&_0x3398a5!=='.sv'&&(_0x41f7de=!0x0,!ms(_0x3398a5)))throw new Error(_0x18c83f+'\x20contains\x20an\x20invalid\x20key\x20('+_0x3398a5+')\x20'+Oe(_0x3f9961)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x3f9961,_0x3398a5),Jt(_0x18c83f,_0x258bdd,_0x3f9961),Ph(_0x3f9961);}),_0x3c654b&&_0x41f7de)throw new Error(_0x18c83f+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x3f9961)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x345985,_0x4df9c7){let _0x5b05ea,_0x4b9c84;for(_0x5b05ea=0x0;_0x5b05ea<_0x4df9c7['length'];_0x5b05ea++){_0x4b9c84=_0x4df9c7[_0x5b05ea];const _0x37b4f6=Mt(_0x4b9c84);for(let _0x49ce7a=0x0;_0x49ce7a<_0x37b4f6['length'];_0x49ce7a++)if(!(_0x37b4f6[_0x49ce7a]==='.priority'&&_0x49ce7a===_0x37b4f6['length']-0x1)){if(!ms(_0x37b4f6[_0x49ce7a]))throw new Error(_0x345985+'contains\x20an\x20invalid\x20key\x20('+_0x37b4f6[_0x49ce7a]+')\x20in\x20path\x20'+_0x4b9c84['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x4df9c7['sort'](Rh);let _0x400c4c=null;for(_0x5b05ea=0x0;_0x5b05ea<_0x4df9c7['length'];_0x5b05ea++){if(_0x4b9c84=_0x4df9c7[_0x5b05ea],_0x400c4c!==null&&G(_0x400c4c,_0x4b9c84))throw new Error(_0x345985+'contains\x20a\x20path\x20'+_0x400c4c['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x4b9c84['toString']());_0x400c4c=_0x4b9c84;}},ra=function(_0x3a4fba,_0x12403a,_0x4105c0,_0x52f477){const _0x2774cc=it(_0x3a4fba,'values');if(!(_0x12403a&&typeof _0x12403a=='object')||Array['isArray'](_0x12403a))throw new Error(_0x2774cc+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0xb0dde3=[];x(_0x12403a,(_0x35983a,_0x42adc0)=>{const _0x419908=new C(_0x35983a);if(Jt(_0x2774cc,_0x42adc0,k(_0x4105c0,_0x419908)),ji(_0x419908)==='.priority'&&!Bt(_0x42adc0))throw new Error(_0x2774cc+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x419908['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0xb0dde3['push'](_0x419908);}),dd(_0x2774cc,_0xb0dde3);},fd=function(_0x40a45f,_0x54f425,_0xc5b81b){if(xn(_0x54f425))throw new Error(it(_0x40a45f,'priority')+'is\x20'+_0x54f425['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x54f425))throw new Error(it(_0x40a45f,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x3dbce9,_0x1d7ed3,_0x46e654,_0x35d12c){if(!sa(_0x46e654))throw new Error(it(_0x3dbce9,_0x1d7ed3)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x46e654+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x5e7672,_0x23a22b,_0x5bab9a,_0x257325){_0x5bab9a&&(_0x5bab9a=_0x5bab9a['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x5e7672,_0x23a22b,_0x5bab9a);},Me=function(_0xc8b96f,_0x3e1a83){if(y(_0x3e1a83)==='.info')throw new Error(_0xc8b96f+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x5e8490,_0x555291){const _0x5eddf0=_0x555291['path']['toString']();if(typeof _0x555291['repoInfo']['host']!='string'||_0x555291['repoInfo']['host']['length']===0x0||!ms(_0x555291['repoInfo']['namespace'])&&_0x555291['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x5eddf0['length']!==0x0&&!ud(_0x5eddf0))throw new Error(it(_0x5e8490,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x3e3e47,_0x4453ad){let _0x3e24d2=null;for(let _0x241829=0x0;_0x241829<_0x4453ad['length'];_0x241829++){const _0x368093=_0x4453ad[_0x241829],_0x37a6ee=_0x368093['getPath']();_0x3e24d2!==null&&!Ki(_0x37a6ee,_0x3e24d2['path'])&&(_0x3e3e47['eventLists_']['push'](_0x3e24d2),_0x3e24d2=null),_0x3e24d2===null&&(_0x3e24d2={'events':[],'path':_0x37a6ee}),_0x3e24d2['events']['push'](_0x368093);}_0x3e24d2&&_0x3e3e47['eventLists_']['push'](_0x3e24d2);}function oa(_0x2e2749,_0x20cb50,_0x432233){qn(_0x2e2749,_0x432233),aa(_0x2e2749,_0x5f3030=>Ki(_0x5f3030,_0x20cb50));}function V(_0x410b9c,_0x5e1074,_0x1be9dd){qn(_0x410b9c,_0x1be9dd),aa(_0x410b9c,_0x160a19=>G(_0x160a19,_0x5e1074)||G(_0x5e1074,_0x160a19));}function aa(_0xe56dd4,_0x852e98){_0xe56dd4['recursionDepth_']++;let _0x2119ec=!0x0;for(let _0x2d5f6b=0x0;_0x2d5f6b<_0xe56dd4['eventLists_']['length'];_0x2d5f6b++){const _0x396872=_0xe56dd4['eventLists_'][_0x2d5f6b];if(_0x396872){const _0x2da997=_0x396872['path'];_0x852e98(_0x2da997)?(md(_0xe56dd4['eventLists_'][_0x2d5f6b]),_0xe56dd4['eventLists_'][_0x2d5f6b]=null):_0x2119ec=!0x1;}}_0x2119ec&&(_0xe56dd4['eventLists_']=[]),_0xe56dd4['recursionDepth_']--;}function md(_0x20da8f){for(let _0x166a9d=0x0;_0x166a9d<_0x20da8f['events']['length'];_0x166a9d++){const _0x49927d=_0x20da8f['events'][_0x166a9d];if(_0x49927d!==null){_0x20da8f['events'][_0x166a9d]=null;const _0x2745ed=_0x49927d['getEventRunner']();St&&L('event:\x20'+_0x49927d['toString']()),ft(_0x2745ed);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x261cba,_0x55310f,_0x8f8505,_0x47dd99){this['repoInfo_']=_0x261cba,this['forceRestClient_']=_0x55310f,this['authTokenProvider_']=_0x8f8505,this['appCheckProvider_']=_0x47dd99,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x313ea7,_0x23d105,_0x2cc156){if(_0x313ea7['stats_']=qi(_0x313ea7['repoInfo_']),_0x313ea7['forceRestClient_']||Xl())_0x313ea7['server_']=new vn(_0x313ea7['repoInfo_'],(_0x21a13d,_0x52021b,_0xa4383d,_0x2988a9)=>{gr(_0x313ea7,_0x21a13d,_0x52021b,_0xa4383d,_0x2988a9);},_0x313ea7['authTokenProvider_'],_0x313ea7['appCheckProvider_']),setTimeout(()=>mr(_0x313ea7,!0x0),0x0);else{if(typeof _0x2cc156<'u'&&_0x2cc156!==null){if(typeof _0x2cc156!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x2cc156);}catch(_0x31d39f){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x31d39f);}}_0x313ea7['persistentConnection_']=new se(_0x313ea7['repoInfo_'],_0x23d105,(_0x4401f6,_0x2f1c52,_0x1fc875,_0x52d86c)=>{gr(_0x313ea7,_0x4401f6,_0x2f1c52,_0x1fc875,_0x52d86c);},_0x31f817=>{mr(_0x313ea7,_0x31f817);},_0x4c9ee1=>{Id(_0x313ea7,_0x4c9ee1);},_0x313ea7['authTokenProvider_'],_0x313ea7['appCheckProvider_'],_0x2cc156),_0x313ea7['server_']=_0x313ea7['persistentConnection_'];}_0x313ea7['authTokenProvider_']['addTokenChangeListener'](_0x1c23d1=>{_0x313ea7['server_']['refreshAuthToken'](_0x1c23d1);}),_0x313ea7['appCheckProvider_']['addTokenChangeListener'](_0x62cc93=>{_0x313ea7['server_']['refreshAppCheckToken'](_0x62cc93['token']);}),_0x313ea7['statsReporter_']=ih(_0x313ea7['repoInfo_'],()=>new iu(_0x313ea7['stats_'],_0x313ea7['server_'])),_0x313ea7['infoData_']=new Xh(),_0x313ea7['infoSyncTree_']=new pr({'startListening':(_0x1d8620,_0x2ef226,_0x2b2456,_0x4e3528)=>{let _0xcc682c=[];const _0x1a38c0=_0x313ea7['infoData_']['getNode'](_0x1d8620['_path']);return _0x1a38c0['isEmpty']()||(_0xcc682c=Yt(_0x313ea7['infoSyncTree_'],_0x1d8620['_path'],_0x1a38c0),setTimeout(()=>{_0x4e3528('ok');},0x0)),_0xcc682c;},'stopListening':()=>{}}),vs(_0x313ea7,'connected',!0x1),_0x313ea7['serverSyncTree_']=new pr({'startListening':(_0x535c18,_0x4fb60a,_0x1ee497,_0x457244)=>(_0x313ea7['server_']['listen'](_0x535c18,_0x1ee497,_0x4fb60a,(_0x1c9a27,_0x5cf48c)=>{const _0x4ff47d=_0x457244(_0x1c9a27,_0x5cf48c);V(_0x313ea7['eventQueue_'],_0x535c18['_path'],_0x4ff47d);}),[]),'stopListening':(_0x2bf962,_0x1d5fea)=>{_0x313ea7['server_']['unlisten'](_0x2bf962,_0x1d5fea);}});}function la(_0x41d03f){const _0x395aa9=_0x41d03f['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x395aa9;}function Xt(_0x1df26a){return id({'timestamp':la(_0x1df26a)});}function gr(_0xe8fc50,_0x8efb50,_0x46b5d2,_0xc04cf8,_0x384934){_0xe8fc50['dataUpdateCount']++;const _0x38f072=new C(_0x8efb50);_0x46b5d2=_0xe8fc50['interceptServerDataCallback_']?_0xe8fc50['interceptServerDataCallback_'](_0x8efb50,_0x46b5d2):_0x46b5d2;let _0x2626e1=[];if(_0x384934){if(_0xc04cf8){const _0xb984cf=_n(_0x46b5d2,_0x2148d7=>A(_0x2148d7));_0x2626e1=Ju(_0xe8fc50['serverSyncTree_'],_0x38f072,_0xb984cf,_0x384934);}else{const _0x5dd249=A(_0x46b5d2);_0x2626e1=Jo(_0xe8fc50['serverSyncTree_'],_0x38f072,_0x5dd249,_0x384934);}}else{if(_0xc04cf8){const _0x34c75d=_n(_0x46b5d2,_0x366710=>A(_0x366710));_0x2626e1=Ku(_0xe8fc50['serverSyncTree_'],_0x38f072,_0x34c75d);}else{const _0x1fcada=A(_0x46b5d2);_0x2626e1=Yt(_0xe8fc50['serverSyncTree_'],_0x38f072,_0x1fcada);}}let _0x46025a=_0x38f072;_0x2626e1['length']>0x0&&(_0x46025a=ct(_0xe8fc50,_0x38f072)),V(_0xe8fc50['eventQueue_'],_0x46025a,_0x2626e1);}function mr(_0x5a9108,_0x412db8){vs(_0x5a9108,'connected',_0x412db8),_0x412db8===!0x1&&Sd(_0x5a9108);}function Id(_0x347904,_0x35649f){x(_0x35649f,(_0x5dffb5,_0xe3df6c)=>{vs(_0x347904,_0x5dffb5,_0xe3df6c);});}function vs(_0x4c25c1,_0xa6e75b,_0x1ee232){const _0x4ec56c=new C('/.info/'+_0xa6e75b),_0x217714=A(_0x1ee232);_0x4c25c1['infoData_']['updateSnapshot'](_0x4ec56c,_0x217714);const _0x2c7a22=Yt(_0x4c25c1['infoSyncTree_'],_0x4ec56c,_0x217714);V(_0x4c25c1['eventQueue_'],_0x4ec56c,_0x2c7a22);}function zn(_0xbb0457){return _0xbb0457['nextWriteId_']++;}function wd(_0x1eec7e,_0x3bbc82,_0x1ee402){const _0x590038=Xu(_0x1eec7e['serverSyncTree_'],_0x3bbc82);return _0x590038!=null?Promise['resolve'](_0x590038):_0x1eec7e['server_']['get'](_0x3bbc82)['then'](_0x12bcb9=>{const _0x3d682a=A(_0x12bcb9)['withIndex'](_0x3bbc82['_queryParams']['getIndex']());Ni(_0x1eec7e['serverSyncTree_'],_0x3bbc82,_0x1ee402,!0x0);let _0x305347;if(_0x3bbc82['_queryParams']['loadsAllData']())_0x305347=Yt(_0x1eec7e['serverSyncTree_'],_0x3bbc82['_path'],_0x3d682a);else{const _0xb27f59=Wt(_0x1eec7e['serverSyncTree_'],_0x3bbc82);_0x305347=Jo(_0x1eec7e['serverSyncTree_'],_0x3bbc82['_path'],_0x3d682a,_0xb27f59);}return V(_0x1eec7e['eventQueue_'],_0x3bbc82['_path'],_0x305347),An(_0x1eec7e['serverSyncTree_'],_0x3bbc82,_0x1ee402,null,!0x0),_0x3d682a;},_0x59d02e=>(gt(_0x1eec7e,'get\x20for\x20query\x20'+O(_0x3bbc82)+'\x20failed:\x20'+_0x59d02e),Promise['reject'](new Error(_0x59d02e))));}function Cd(_0x2596a9,_0x3bbeb2,_0x41d6b9,_0x3599e5,_0x51b0a5){gt(_0x2596a9,'set',{'path':_0x3bbeb2['toString'](),'value':_0x41d6b9,'priority':_0x3599e5});const _0x42eaa0=Xt(_0x2596a9),_0x2ee454=A(_0x41d6b9,_0x3599e5),_0x269e56=Vn(_0x2596a9['serverSyncTree_'],_0x3bbeb2),_0x31c8d8=fs(_0x2ee454,_0x269e56,_0x42eaa0),_0x520a0b=zn(_0x2596a9),_0x3cb344=as(_0x2596a9['serverSyncTree_'],_0x3bbeb2,_0x31c8d8,_0x520a0b,!0x0);qn(_0x2596a9['eventQueue_'],_0x3cb344),_0x2596a9['server_']['put'](_0x3bbeb2['toString'](),_0x2ee454['val'](!0x0),(_0x39b716,_0x58404e)=>{const _0x1c0e2a=_0x39b716==='ok';_0x1c0e2a||U('set\x20at\x20'+_0x3bbeb2+'\x20failed:\x20'+_0x39b716);const _0x4d1243=_e(_0x2596a9['serverSyncTree_'],_0x520a0b,!_0x1c0e2a);V(_0x2596a9['eventQueue_'],_0x3bbeb2,_0x4d1243),be(_0x2596a9,_0x51b0a5,_0x39b716,_0x58404e);});const _0x27f0fb=Is(_0x2596a9,_0x3bbeb2);ct(_0x2596a9,_0x27f0fb),V(_0x2596a9['eventQueue_'],_0x27f0fb,[]);}function Td(_0x3c11e8,_0x51e067,_0x4db677,_0x81c30a){gt(_0x3c11e8,'update',{'path':_0x51e067['toString'](),'value':_0x4db677});let _0x5dd103=!0x0;const _0x143a9f=Xt(_0x3c11e8),_0x2c1274={};if(x(_0x4db677,(_0x2d228b,_0x4fee23)=>{_0x5dd103=!0x1,_0x2c1274[_0x2d228b]=ta(k(_0x51e067,_0x2d228b),A(_0x4fee23),_0x3c11e8['serverSyncTree_'],_0x143a9f);}),_0x5dd103)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x3c11e8,_0x81c30a,'ok',void 0x0);else{const _0x1b8440=zn(_0x3c11e8),_0x2be239=ju(_0x3c11e8['serverSyncTree_'],_0x51e067,_0x2c1274,_0x1b8440);qn(_0x3c11e8['eventQueue_'],_0x2be239),_0x3c11e8['server_']['merge'](_0x51e067['toString'](),_0x4db677,(_0x330b5e,_0x375bde)=>{const _0xccbe85=_0x330b5e==='ok';_0xccbe85||U('update\x20at\x20'+_0x51e067+'\x20failed:\x20'+_0x330b5e);const _0x4e2412=_e(_0x3c11e8['serverSyncTree_'],_0x1b8440,!_0xccbe85),_0x8ed665=_0x4e2412['length']>0x0?ct(_0x3c11e8,_0x51e067):_0x51e067;V(_0x3c11e8['eventQueue_'],_0x8ed665,_0x4e2412),be(_0x3c11e8,_0x81c30a,_0x330b5e,_0x375bde);}),x(_0x4db677,_0x4aa07b=>{const _0x4b98cf=Is(_0x3c11e8,k(_0x51e067,_0x4aa07b));ct(_0x3c11e8,_0x4b98cf);}),V(_0x3c11e8['eventQueue_'],_0x51e067,[]);}}function Sd(_0x24f391){gt(_0x24f391,'onDisconnectEvents');const _0x200ebc=Xt(_0x24f391),_0x49b553=En();Si(_0x24f391['onDisconnect_'],w(),(_0x142e0a,_0x44b9d4)=>{const _0x598261=ta(_0x142e0a,_0x44b9d4,_0x24f391['serverSyncTree_'],_0x200ebc);pt(_0x49b553,_0x142e0a,_0x598261);});let _0x351fe8=[];Si(_0x49b553,w(),(_0x1eeefc,_0x5e19a2)=>{_0x351fe8=_0x351fe8['concat'](Yt(_0x24f391['serverSyncTree_'],_0x1eeefc,_0x5e19a2));const _0x5dc1e2=Is(_0x24f391,_0x1eeefc);ct(_0x24f391,_0x5dc1e2);}),_0x24f391['onDisconnect_']=En(),V(_0x24f391['eventQueue_'],w(),_0x351fe8);}function bd(_0x584728,_0x26b935,_0x36561d){_0x584728['server_']['onDisconnectCancel'](_0x26b935['toString'](),(_0x91fb7,_0x2aa774)=>{_0x91fb7==='ok'&&Ti(_0x584728['onDisconnect_'],_0x26b935),be(_0x584728,_0x36561d,_0x91fb7,_0x2aa774);});}function yr(_0xb178d0,_0x5902cd,_0x2dbcc2,_0x52dc7f){const _0x3534ec=A(_0x2dbcc2);_0xb178d0['server_']['onDisconnectPut'](_0x5902cd['toString'](),_0x3534ec['val'](!0x0),(_0x347ce8,_0x10ff94)=>{_0x347ce8==='ok'&&pt(_0xb178d0['onDisconnect_'],_0x5902cd,_0x3534ec),be(_0xb178d0,_0x52dc7f,_0x347ce8,_0x10ff94);});}function Rd(_0x2ca095,_0x23dc50,_0x29f674,_0x1bfd7a,_0x3573c5){const _0x46c0fa=A(_0x29f674,_0x1bfd7a);_0x2ca095['server_']['onDisconnectPut'](_0x23dc50['toString'](),_0x46c0fa['val'](!0x0),(_0xc60b38,_0x459bc1)=>{_0xc60b38==='ok'&&pt(_0x2ca095['onDisconnect_'],_0x23dc50,_0x46c0fa),be(_0x2ca095,_0x3573c5,_0xc60b38,_0x459bc1);});}function Ad(_0x20c2bc,_0x217a92,_0x32955d,_0x5dbc98){if(pn(_0x32955d)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x20c2bc,_0x5dbc98,'ok',void 0x0);return;}_0x20c2bc['server_']['onDisconnectMerge'](_0x217a92['toString'](),_0x32955d,(_0x9cc67f,_0x3b945a)=>{_0x9cc67f==='ok'&&x(_0x32955d,(_0x36442a,_0x387b8f)=>{const _0x242c8a=A(_0x387b8f);pt(_0x20c2bc['onDisconnect_'],k(_0x217a92,_0x36442a),_0x242c8a);}),be(_0x20c2bc,_0x5dbc98,_0x9cc67f,_0x3b945a);});}function kd(_0x4296c5,_0x449e25,_0x452411){let _0x2b8c28;y(_0x449e25['_path'])==='.info'?_0x2b8c28=Ni(_0x4296c5['infoSyncTree_'],_0x449e25,_0x452411):_0x2b8c28=Ni(_0x4296c5['serverSyncTree_'],_0x449e25,_0x452411),oa(_0x4296c5['eventQueue_'],_0x449e25['_path'],_0x2b8c28);}function Pd(_0x1cf00d,_0x36c391,_0xf4b93a){let _0x20c468;y(_0x36c391['_path'])==='.info'?_0x20c468=An(_0x1cf00d['infoSyncTree_'],_0x36c391,_0xf4b93a):_0x20c468=An(_0x1cf00d['serverSyncTree_'],_0x36c391,_0xf4b93a),oa(_0x1cf00d['eventQueue_'],_0x36c391['_path'],_0x20c468);}function ha(_0x19a8bd){_0x19a8bd['persistentConnection_']&&_0x19a8bd['persistentConnection_']['interrupt'](ca);}function Nd(_0x46af0f){_0x46af0f['persistentConnection_']&&_0x46af0f['persistentConnection_']['resume'](ca);}function gt(_0x57defb,..._0x5f5646){let _0x3b6151='';_0x57defb['persistentConnection_']&&(_0x3b6151=_0x57defb['persistentConnection_']['id']+':'),L(_0x3b6151,..._0x5f5646);}function be(_0x5161dc,_0x138617,_0x3333db,_0x509793){_0x138617&&ft(()=>{if(_0x3333db==='ok')_0x138617(null);else{const _0x1681ce=(_0x3333db||'error')['toUpperCase']();let _0x34068c=_0x1681ce;_0x509793&&(_0x34068c+=':\x20'+_0x509793);const _0x16d8de=new Error(_0x34068c);_0x16d8de['code']=_0x1681ce,_0x138617(_0x16d8de);}});}function Od(_0x1a9687,_0x8b0081,_0x1eeab7,_0x536dec,_0x4e39a1,_0x2c7503){gt(_0x1a9687,'transaction\x20on\x20'+_0x8b0081);const _0x584444={'path':_0x8b0081,'update':_0x1eeab7,'onComplete':_0x536dec,'status':null,'order':so(),'applyLocally':_0x2c7503,'retryCount':0x0,'unwatcher':_0x4e39a1,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x150edb=Es(_0x1a9687,_0x8b0081,void 0x0);_0x584444['currentInputSnapshot']=_0x150edb;const _0x18f002=_0x584444['update'](_0x150edb['val']());if(_0x18f002===void 0x0)_0x584444['unwatcher'](),_0x584444['currentOutputSnapshotRaw']=null,_0x584444['currentOutputSnapshotResolved']=null,_0x584444['onComplete']&&_0x584444['onComplete'](null,!0x1,_0x584444['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x18f002,_0x584444['path']),_0x584444['status']=0x0;const _0x419180=$n(_0x1a9687['transactionQueueTree_'],_0x8b0081),_0x1b7b78=je(_0x419180)||[];_0x1b7b78['push'](_0x584444),gs(_0x419180,_0x1b7b78);let _0x32d880;typeof _0x18f002=='object'&&_0x18f002!==null&&Q(_0x18f002,'.priority')?(_0x32d880=Le(_0x18f002,'.priority'),f(Bt(_0x32d880),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x32d880=(Vn(_0x1a9687['serverSyncTree_'],_0x8b0081)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x485e29=Xt(_0x1a9687),_0x9a415a=A(_0x18f002,_0x32d880),_0x13de7c=fs(_0x9a415a,_0x150edb,_0x485e29);_0x584444['currentOutputSnapshotRaw']=_0x9a415a,_0x584444['currentOutputSnapshotResolved']=_0x13de7c,_0x584444['currentWriteId']=zn(_0x1a9687);const _0x107c23=as(_0x1a9687['serverSyncTree_'],_0x8b0081,_0x13de7c,_0x584444['currentWriteId'],_0x584444['applyLocally']);V(_0x1a9687['eventQueue_'],_0x8b0081,_0x107c23),jn(_0x1a9687,_0x1a9687['transactionQueueTree_']);}}function Es(_0x1903e6,_0x1f42b8,_0x1388cf){return Vn(_0x1903e6['serverSyncTree_'],_0x1f42b8,_0x1388cf)||g['EMPTY_NODE'];}function jn(_0x592ed1,_0x13c453=_0x592ed1['transactionQueueTree_']){if(_0x13c453||Kn(_0x592ed1,_0x13c453),je(_0x13c453)){const _0x4a0367=da(_0x592ed1,_0x13c453);f(_0x4a0367['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x4a0367['every'](_0x442ceb=>_0x442ceb['status']===0x0)&&Dd(_0x592ed1,Qt(_0x13c453),_0x4a0367);}else na(_0x13c453)&&Gn(_0x13c453,_0x81f7f7=>{jn(_0x592ed1,_0x81f7f7);});}function Dd(_0x3a2bda,_0x23f31c,_0x2e0d2c){const _0x3ef76a=_0x2e0d2c['map'](_0x5ce2c4=>_0x5ce2c4['currentWriteId']),_0xae7db0=Es(_0x3a2bda,_0x23f31c,_0x3ef76a);let _0x2fd3d8=_0xae7db0;const _0x4a63f8=_0xae7db0['hash']();for(let _0x4ec64d=0x0;_0x4ec64d<_0x2e0d2c['length'];_0x4ec64d++){const _0x491f9a=_0x2e0d2c[_0x4ec64d];f(_0x491f9a['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x491f9a['status']=0x1,_0x491f9a['retryCount']++;const _0x2360ab=F(_0x23f31c,_0x491f9a['path']);_0x2fd3d8=_0x2fd3d8['updateChild'](_0x2360ab,_0x491f9a['currentOutputSnapshotRaw']);}const _0x451c04=_0x2fd3d8['val'](!0x0),_0x8556f4=_0x23f31c;_0x3a2bda['server_']['put'](_0x8556f4['toString'](),_0x451c04,_0x11466f=>{gt(_0x3a2bda,'transaction\x20put\x20response',{'path':_0x8556f4['toString'](),'status':_0x11466f});let _0x22e76e=[];if(_0x11466f==='ok'){const _0x40930f=[];for(let _0x535ae6=0x0;_0x535ae6<_0x2e0d2c['length'];_0x535ae6++)_0x2e0d2c[_0x535ae6]['status']=0x2,_0x22e76e=_0x22e76e['concat'](_e(_0x3a2bda['serverSyncTree_'],_0x2e0d2c[_0x535ae6]['currentWriteId'])),_0x2e0d2c[_0x535ae6]['onComplete']&&_0x40930f['push'](()=>_0x2e0d2c[_0x535ae6]['onComplete'](null,!0x0,_0x2e0d2c[_0x535ae6]['currentOutputSnapshotResolved'])),_0x2e0d2c[_0x535ae6]['unwatcher']();Kn(_0x3a2bda,$n(_0x3a2bda['transactionQueueTree_'],_0x23f31c)),jn(_0x3a2bda,_0x3a2bda['transactionQueueTree_']),V(_0x3a2bda['eventQueue_'],_0x23f31c,_0x22e76e);for(let _0x1b8e72=0x0;_0x1b8e72<_0x40930f['length'];_0x1b8e72++)ft(_0x40930f[_0x1b8e72]);}else{if(_0x11466f==='datastale'){for(let _0x262f12=0x0;_0x262f12<_0x2e0d2c['length'];_0x262f12++)_0x2e0d2c[_0x262f12]['status']===0x3?_0x2e0d2c[_0x262f12]['status']=0x4:_0x2e0d2c[_0x262f12]['status']=0x0;}else{U('transaction\x20at\x20'+_0x8556f4['toString']()+'\x20failed:\x20'+_0x11466f);for(let _0x1a4900=0x0;_0x1a4900<_0x2e0d2c['length'];_0x1a4900++)_0x2e0d2c[_0x1a4900]['status']=0x4,_0x2e0d2c[_0x1a4900]['abortReason']=_0x11466f;}ct(_0x3a2bda,_0x23f31c);}},_0x4a63f8);}function ct(_0x5af3f3,_0x550f32){const _0x30bc7c=ua(_0x5af3f3,_0x550f32),_0x3c2b45=Qt(_0x30bc7c),_0x44299b=da(_0x5af3f3,_0x30bc7c);return Md(_0x5af3f3,_0x44299b,_0x3c2b45),_0x3c2b45;}function Md(_0x2a9176,_0x4f4e1d,_0x441741){if(_0x4f4e1d['length']===0x0)return;const _0x293834=[];let _0x1057bb=[];const _0x23b788=_0x4f4e1d['filter'](_0x4b0053=>_0x4b0053['status']===0x0)['map'](_0x3a52a1=>_0x3a52a1['currentWriteId']);for(let _0x325e00=0x0;_0x325e00<_0x4f4e1d['length'];_0x325e00++){const _0x58eb44=_0x4f4e1d[_0x325e00],_0x26b03b=F(_0x441741,_0x58eb44['path']);let _0x3b519f=!0x1,_0x2d61ed;if(f(_0x26b03b!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x58eb44['status']===0x4)_0x3b519f=!0x0,_0x2d61ed=_0x58eb44['abortReason'],_0x1057bb=_0x1057bb['concat'](_e(_0x2a9176['serverSyncTree_'],_0x58eb44['currentWriteId'],!0x0));else{if(_0x58eb44['status']===0x0){if(_0x58eb44['retryCount']>=yd)_0x3b519f=!0x0,_0x2d61ed='maxretry',_0x1057bb=_0x1057bb['concat'](_e(_0x2a9176['serverSyncTree_'],_0x58eb44['currentWriteId'],!0x0));else{const _0x2b1c23=Es(_0x2a9176,_0x58eb44['path'],_0x23b788);_0x58eb44['currentInputSnapshot']=_0x2b1c23;const _0x215bd0=_0x4f4e1d[_0x325e00]['update'](_0x2b1c23['val']());if(_0x215bd0!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x215bd0,_0x58eb44['path']);let _0x3a685b=A(_0x215bd0);typeof _0x215bd0=='object'&&_0x215bd0!=null&&Q(_0x215bd0,'.priority')||(_0x3a685b=_0x3a685b['updatePriority'](_0x2b1c23['getPriority']()));const _0xf57e85=_0x58eb44['currentWriteId'],_0x2704ca=Xt(_0x2a9176),_0x4fcf8a=fs(_0x3a685b,_0x2b1c23,_0x2704ca);_0x58eb44['currentOutputSnapshotRaw']=_0x3a685b,_0x58eb44['currentOutputSnapshotResolved']=_0x4fcf8a,_0x58eb44['currentWriteId']=zn(_0x2a9176),_0x23b788['splice'](_0x23b788['indexOf'](_0xf57e85),0x1),_0x1057bb=_0x1057bb['concat'](as(_0x2a9176['serverSyncTree_'],_0x58eb44['path'],_0x4fcf8a,_0x58eb44['currentWriteId'],_0x58eb44['applyLocally'])),_0x1057bb=_0x1057bb['concat'](_e(_0x2a9176['serverSyncTree_'],_0xf57e85,!0x0));}else _0x3b519f=!0x0,_0x2d61ed='nodata',_0x1057bb=_0x1057bb['concat'](_e(_0x2a9176['serverSyncTree_'],_0x58eb44['currentWriteId'],!0x0));}}}V(_0x2a9176['eventQueue_'],_0x441741,_0x1057bb),_0x1057bb=[],_0x3b519f&&(_0x4f4e1d[_0x325e00]['status']=0x2,function(_0x44911c){setTimeout(_0x44911c,Math['floor'](0x0));}(_0x4f4e1d[_0x325e00]['unwatcher']),_0x4f4e1d[_0x325e00]['onComplete']&&(_0x2d61ed==='nodata'?_0x293834['push'](()=>_0x4f4e1d[_0x325e00]['onComplete'](null,!0x1,_0x4f4e1d[_0x325e00]['currentInputSnapshot'])):_0x293834['push'](()=>_0x4f4e1d[_0x325e00]['onComplete'](new Error(_0x2d61ed),!0x1,null))));}Kn(_0x2a9176,_0x2a9176['transactionQueueTree_']);for(let _0xae1048=0x0;_0xae1048<_0x293834['length'];_0xae1048++)ft(_0x293834[_0xae1048]);jn(_0x2a9176,_0x2a9176['transactionQueueTree_']);}function ua(_0x39eb27,_0x573877){let _0x86d230,_0x10fb01=_0x39eb27['transactionQueueTree_'];for(_0x86d230=y(_0x573877);_0x86d230!==null&&je(_0x10fb01)===void 0x0;)_0x10fb01=$n(_0x10fb01,_0x86d230),_0x573877=S(_0x573877),_0x86d230=y(_0x573877);return _0x10fb01;}function da(_0x55c46d,_0x224b2b){const _0x550b6b=[];return fa(_0x55c46d,_0x224b2b,_0x550b6b),_0x550b6b['sort']((_0x366de0,_0x2b07e7)=>_0x366de0['order']-_0x2b07e7['order']),_0x550b6b;}function fa(_0x480bfb,_0x469d06,_0x4c1a25){const _0x29ddec=je(_0x469d06);if(_0x29ddec){for(let _0x73d7cf=0x0;_0x73d7cf<_0x29ddec['length'];_0x73d7cf++)_0x4c1a25['push'](_0x29ddec[_0x73d7cf]);}Gn(_0x469d06,_0x19346b=>{fa(_0x480bfb,_0x19346b,_0x4c1a25);});}function Kn(_0x4c81b2,_0x54bf46){const _0x2447f4=je(_0x54bf46);if(_0x2447f4){let _0x1e9e52=0x0;for(let _0x4446cb=0x0;_0x4446cb<_0x2447f4['length'];_0x4446cb++)_0x2447f4[_0x4446cb]['status']!==0x2&&(_0x2447f4[_0x1e9e52]=_0x2447f4[_0x4446cb],_0x1e9e52++);_0x2447f4['length']=_0x1e9e52,gs(_0x54bf46,_0x2447f4['length']>0x0?_0x2447f4:void 0x0);}Gn(_0x54bf46,_0x4a028a=>{Kn(_0x4c81b2,_0x4a028a);});}function Is(_0x519dd2,_0x2ae5b4){const _0x23cdd6=Qt(ua(_0x519dd2,_0x2ae5b4)),_0x4e05b5=$n(_0x519dd2['transactionQueueTree_'],_0x2ae5b4);return ad(_0x4e05b5,_0xadf447=>{di(_0x519dd2,_0xadf447);}),di(_0x519dd2,_0x4e05b5),ia(_0x4e05b5,_0x2d7740=>{di(_0x519dd2,_0x2d7740);}),_0x23cdd6;}function di(_0x42525e,_0x9d2fca){const _0x1e7b44=je(_0x9d2fca);if(_0x1e7b44){const _0x3b7281=[];let _0x34e2bf=[],_0x2d1f82=-0x1;for(let _0x34055c=0x0;_0x34055c<_0x1e7b44['length'];_0x34055c++)_0x1e7b44[_0x34055c]['status']===0x3||(_0x1e7b44[_0x34055c]['status']===0x1?(f(_0x2d1f82===_0x34055c-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x2d1f82=_0x34055c,_0x1e7b44[_0x34055c]['status']=0x3,_0x1e7b44[_0x34055c]['abortReason']='set'):(f(_0x1e7b44[_0x34055c]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x1e7b44[_0x34055c]['unwatcher'](),_0x34e2bf=_0x34e2bf['concat'](_e(_0x42525e['serverSyncTree_'],_0x1e7b44[_0x34055c]['currentWriteId'],!0x0)),_0x1e7b44[_0x34055c]['onComplete']&&_0x3b7281['push'](_0x1e7b44[_0x34055c]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x2d1f82===-0x1?gs(_0x9d2fca,void 0x0):_0x1e7b44['length']=_0x2d1f82+0x1,V(_0x42525e['eventQueue_'],Qt(_0x9d2fca),_0x34e2bf);for(let _0x2907fe=0x0;_0x2907fe<_0x3b7281['length'];_0x2907fe++)ft(_0x3b7281[_0x2907fe]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x90797b){let _0x13f9d9='';const _0x284250=_0x90797b['split']('/');for(let _0x55bb05=0x0;_0x55bb05<_0x284250['length'];_0x55bb05++)if(_0x284250[_0x55bb05]['length']>0x0){let _0x34ec30=_0x284250[_0x55bb05];try{_0x34ec30=decodeURIComponent(_0x34ec30['replace'](/\+/g,'\x20'));}catch{}_0x13f9d9+='/'+_0x34ec30;}return _0x13f9d9;}function xd(_0x4913c3){const _0x46a062={};_0x4913c3['charAt'](0x0)==='?'&&(_0x4913c3=_0x4913c3['substring'](0x1));for(const _0x54cc8d of _0x4913c3['split']('&')){if(_0x54cc8d['length']===0x0)continue;const _0x1ee47c=_0x54cc8d['split']('=');_0x1ee47c['length']===0x2?_0x46a062[decodeURIComponent(_0x1ee47c[0x0])]=decodeURIComponent(_0x1ee47c[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x54cc8d+'\x27\x20in\x20query\x20\x27'+_0x4913c3+'\x27');}return _0x46a062;}const vr=function(_0x24e396,_0x12776d){const _0x1497cd=Fd(_0x24e396),_0x5bcfb4=_0x1497cd['namespace'];_0x1497cd['domain']==='firebase.com'&&ae(_0x1497cd['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x5bcfb4||_0x5bcfb4==='undefined')&&_0x1497cd['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x1497cd['secure']||$l();const _0x242f43=_0x1497cd['scheme']==='ws'||_0x1497cd['scheme']==='wss';return{'repoInfo':new yo(_0x1497cd['host'],_0x1497cd['secure'],_0x5bcfb4,_0x242f43,_0x12776d,'',_0x5bcfb4!==_0x1497cd['subdomain']),'path':new C(_0x1497cd['pathString'])};},Fd=function(_0x5250c7){let _0xdc0bd0='',_0x108a5b='',_0x44915c='',_0x2d7662='',_0x511539='',_0x1898c6=!0x0,_0x535569='https',_0x22ebdc=0x1bb;if(typeof _0x5250c7=='string'){let _0x3999a7=_0x5250c7['indexOf']('//');_0x3999a7>=0x0&&(_0x535569=_0x5250c7['substring'](0x0,_0x3999a7-0x1),_0x5250c7=_0x5250c7['substring'](_0x3999a7+0x2));let _0x3619e4=_0x5250c7['indexOf']('/');_0x3619e4===-0x1&&(_0x3619e4=_0x5250c7['length']);let _0x4936dd=_0x5250c7['indexOf']('?');_0x4936dd===-0x1&&(_0x4936dd=_0x5250c7['length']),_0xdc0bd0=_0x5250c7['substring'](0x0,Math['min'](_0x3619e4,_0x4936dd)),_0x3619e4<_0x4936dd&&(_0x2d7662=Ld(_0x5250c7['substring'](_0x3619e4,_0x4936dd)));const _0x22ffa4=xd(_0x5250c7['substring'](Math['min'](_0x5250c7['length'],_0x4936dd)));_0x3999a7=_0xdc0bd0['indexOf'](':'),_0x3999a7>=0x0?(_0x1898c6=_0x535569==='https'||_0x535569==='wss',_0x22ebdc=parseInt(_0xdc0bd0['substring'](_0x3999a7+0x1),0xa)):_0x3999a7=_0xdc0bd0['length'];const _0x23e618=_0xdc0bd0['slice'](0x0,_0x3999a7);if(_0x23e618['toLowerCase']()==='localhost')_0x108a5b='localhost';else{if(_0x23e618['split']('.')['length']<=0x2)_0x108a5b=_0x23e618;else{const _0x3e9105=_0xdc0bd0['indexOf']('.');_0x44915c=_0xdc0bd0['substring'](0x0,_0x3e9105)['toLowerCase'](),_0x108a5b=_0xdc0bd0['substring'](_0x3e9105+0x1),_0x511539=_0x44915c;}}'ns'in _0x22ffa4&&(_0x511539=_0x22ffa4['ns']);}return{'host':_0xdc0bd0,'port':_0x22ebdc,'domain':_0x108a5b,'subdomain':_0x44915c,'secure':_0x1898c6,'scheme':_0x535569,'pathString':_0x2d7662,'namespace':_0x511539};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0xdb18f8=0x0;const _0x46ac94=[];return function(_0x3c6a55){const _0x494a94=_0x3c6a55===_0xdb18f8;_0xdb18f8=_0x3c6a55;let _0x4b5267;const _0x5f136b=new Array(0x8);for(_0x4b5267=0x7;_0x4b5267>=0x0;_0x4b5267--)_0x5f136b[_0x4b5267]=Er['charAt'](_0x3c6a55%0x40),_0x3c6a55=Math['floor'](_0x3c6a55/0x40);f(_0x3c6a55===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x475957=_0x5f136b['join']('');if(_0x494a94){for(_0x4b5267=0xb;_0x4b5267>=0x0&&_0x46ac94[_0x4b5267]===0x3f;_0x4b5267--)_0x46ac94[_0x4b5267]=0x0;_0x46ac94[_0x4b5267]++;}else{for(_0x4b5267=0x0;_0x4b5267<0xc;_0x4b5267++)_0x46ac94[_0x4b5267]=Math['floor'](Math['random']()*0x40);}for(_0x4b5267=0x0;_0x4b5267<0xc;_0x4b5267++)_0x475957+=Er['charAt'](_0x46ac94[_0x4b5267]);return f(_0x475957['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x475957;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x1f8cae,_0x82f87d,_0x3e9771,_0x5d834d){this['eventType']=_0x1f8cae,this['eventRegistration']=_0x82f87d,this['snapshot']=_0x3e9771,this['prevName']=_0x5d834d;}['getPath'](){const _0x456d98=this['snapshot']['ref'];return this['eventType']==='value'?_0x456d98['_path']:_0x456d98['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x45e3c6,_0x5b9594,_0x4c3fc6){this['eventRegistration']=_0x45e3c6,this['error']=_0x5b9594,this['path']=_0x4c3fc6;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x1ed256,_0x1c659b){this['snapshotCallback']=_0x1ed256,this['cancelCallback']=_0x1c659b;}['onValue'](_0x7ebb58,_0x28ee96){this['snapshotCallback']['call'](null,_0x7ebb58,_0x28ee96);}['onCancel'](_0x47ace5){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x47ace5);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x543501){return this['snapshotCallback']===_0x543501['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x543501['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x543501['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x116ed7,_0x1126ff){this['_repo']=_0x116ed7,this['_path']=_0x1126ff;}['cancel'](){const _0x45deb7=new H();return bd(this['_repo'],this['_path'],_0x45deb7['wrapCallback'](()=>{})),_0x45deb7['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x2dc245=new H();return yr(this['_repo'],this['_path'],null,_0x2dc245['wrapCallback'](()=>{})),_0x2dc245['promise'];}['set'](_0x3f3479){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x3f3479,this['_path'],!0x1);const _0x1e9051=new H();return yr(this['_repo'],this['_path'],_0x3f3479,_0x1e9051['wrapCallback'](()=>{})),_0x1e9051['promise'];}['setWithPriority'](_0x2ae955,_0x4f5cb6){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x2ae955,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x4f5cb6);const _0x4b3cc7=new H();return Rd(this['_repo'],this['_path'],_0x2ae955,_0x4f5cb6,_0x4b3cc7['wrapCallback'](()=>{})),_0x4b3cc7['promise'];}['update'](_0x5dcad1){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x5dcad1,this['_path']);const _0x4846ba=new H();return Ad(this['_repo'],this['_path'],_0x5dcad1,_0x4846ba['wrapCallback'](()=>{})),_0x4846ba['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x207ba5,_0x56aede,_0x3b20ca,_0x4b3ed5){this['_repo']=_0x207ba5,this['_path']=_0x56aede,this['_queryParams']=_0x3b20ca,this['_orderByCalled']=_0x4b3ed5;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x30d53e=sr(this['_queryParams']),_0x2283b2=$i(_0x30d53e);return _0x2283b2==='{}'?'default':_0x2283b2;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0xa991a2){if(_0xa991a2=P(_0xa991a2),!(_0xa991a2 instanceof Ae))return!0x1;const _0x33af25=this['_repo']===_0xa991a2['_repo'],_0x18253e=Ki(this['_path'],_0xa991a2['_path']),_0x1ab61c=this['_queryIdentifier']===_0xa991a2['_queryIdentifier'];return _0x33af25&&_0x18253e&&_0x1ab61c;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x215808,_0x1ef23d){if(_0x215808['_orderByCalled']===!0x0)throw new Error(_0x1ef23d+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x2261b0){let _0x6e49c8=null,_0x2496a1=null;if(_0x2261b0['hasStart']()&&(_0x6e49c8=_0x2261b0['getIndexStartValue']()),_0x2261b0['hasEnd']()&&(_0x2496a1=_0x2261b0['getIndexEndValue']()),_0x2261b0['getIndex']()===ve){const _0x19cb5f='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x1f8535='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x2261b0['hasStart']()){if(_0x2261b0['getIndexStartName']()!==We)throw new Error(_0x19cb5f);if(typeof _0x6e49c8!='string')throw new Error(_0x1f8535);}if(_0x2261b0['hasEnd']()){if(_0x2261b0['getIndexEndName']()!==we)throw new Error(_0x19cb5f);if(typeof _0x2496a1!='string')throw new Error(_0x1f8535);}}else{if(_0x2261b0['getIndex']()===R){if(_0x6e49c8!=null&&!Bt(_0x6e49c8)||_0x2496a1!=null&&!Bt(_0x2496a1))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x2261b0['getIndex']()instanceof Ji||_0x2261b0['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x6e49c8!=null&&typeof _0x6e49c8=='object'||_0x2496a1!=null&&typeof _0x2496a1=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x58dd56){if(_0x58dd56['hasStart']()&&_0x58dd56['hasEnd']()&&_0x58dd56['hasLimit']()&&!_0x58dd56['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x4b169e,_0x1dd136){super(_0x4b169e,_0x1dd136,new Zi(),!0x1);}get['parent'](){const _0x3d482d=Ro(this['_path']);return _0x3d482d===null?null:new ee(this['_repo'],_0x3d482d);}get['root'](){let _0x177c52=this;for(;_0x177c52['parent']!==null;)_0x177c52=_0x177c52['parent'];return _0x177c52;}}class lt{constructor(_0x58a601,_0x39ddc8,_0xc7a4d2){this['_node']=_0x58a601,this['ref']=_0x39ddc8,this['_index']=_0xc7a4d2;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x3ea6b5){const _0x4374e5=new C(_0x3ea6b5),_0x1bfcfc=Vt(this['ref'],_0x3ea6b5);return new lt(this['_node']['getChild'](_0x4374e5),_0x1bfcfc,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x9c33ab){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x50c8d0,_0x13405e)=>_0x9c33ab(new lt(_0x13405e,Vt(this['ref'],_0x50c8d0),R)));}['hasChild'](_0x5e7a85){const _0x49ec7e=new C(_0x5e7a85);return!this['_node']['getChild'](_0x49ec7e)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x3521a1,_0x5e51fd){return _0x3521a1=P(_0x3521a1),_0x3521a1['_checkNotDeleted']('ref'),_0x5e51fd!==void 0x0?Vt(_0x3521a1['_root'],_0x5e51fd):_0x3521a1['_root'];}function Vt(_0x54aad9,_0x5c252a){return _0x54aad9=P(_0x54aad9),y(_0x54aad9['_path'])===null?pd('child','path',_0x5c252a):ys('child','path',_0x5c252a),new ee(_0x54aad9['_repo'],k(_0x54aad9['_path'],_0x5c252a));}function v_(_0x9d7f9e){return _0x9d7f9e=P(_0x9d7f9e),new Vd(_0x9d7f9e['_repo'],_0x9d7f9e['_path']);}function E_(_0x3e3dc8,_0x3581c9){_0x3e3dc8=P(_0x3e3dc8),Me('push',_0x3e3dc8['_path']),He('push',_0x3581c9,_0x3e3dc8['_path'],!0x0);const _0xcb37bc=la(_0x3e3dc8['_repo']),_0x27a1d3=Ud(_0xcb37bc),_0x1d61bc=Vt(_0x3e3dc8,_0x27a1d3),_0x5dc323=Vt(_0x3e3dc8,_0x27a1d3);let _0x59fd98;return _0x3581c9!=null?_0x59fd98=Hd(_0x5dc323,_0x3581c9)['then'](()=>_0x5dc323):_0x59fd98=Promise['resolve'](_0x5dc323),_0x1d61bc['then']=_0x59fd98['then']['bind'](_0x59fd98),_0x1d61bc['catch']=_0x59fd98['then']['bind'](_0x59fd98,void 0x0),_0x1d61bc;}function Hd(_0x204208,_0x47f6b8){_0x204208=P(_0x204208),Me('set',_0x204208['_path']),He('set',_0x47f6b8,_0x204208['_path'],!0x1);const _0x622d7c=new H();return Cd(_0x204208['_repo'],_0x204208['_path'],_0x47f6b8,null,_0x622d7c['wrapCallback'](()=>{})),_0x622d7c['promise'];}function I_(_0x305f18,_0x58f6a8){ra('update',_0x58f6a8,_0x305f18['_path']);const _0x4ac22f=new H();return Td(_0x305f18['_repo'],_0x305f18['_path'],_0x58f6a8,_0x4ac22f['wrapCallback'](()=>{})),_0x4ac22f['promise'];}function w_(_0x2a9319){_0x2a9319=P(_0x2a9319);const _0x1f7081=new pa(()=>{}),_0x2eb6d3=new Qn(_0x1f7081);return wd(_0x2a9319['_repo'],_0x2a9319,_0x2eb6d3)['then'](_0x3296a5=>new lt(_0x3296a5,new ee(_0x2a9319['_repo'],_0x2a9319['_path']),_0x2a9319['_queryParams']['getIndex']()));}class Qn{constructor(_0x4f1e97){this['callbackContext']=_0x4f1e97;}['respondsTo'](_0x226e10){return _0x226e10==='value';}['createEvent'](_0x3bfd67,_0x48494f){const _0x91e714=_0x48494f['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x3bfd67['snapshotNode'],new ee(_0x48494f['_repo'],_0x48494f['_path']),_0x91e714));}['getEventRunner'](_0x3d5368){return _0x3d5368['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x3d5368['error']):()=>this['callbackContext']['onValue'](_0x3d5368['snapshot'],null);}['createCancelEvent'](_0xc0302f,_0x47a9ff){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0xc0302f,_0x47a9ff):null;}['matches'](_0x1d17ad){return _0x1d17ad instanceof Qn?!_0x1d17ad['callbackContext']||!this['callbackContext']?!0x0:_0x1d17ad['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x4c12d1,_0x2effab,_0x39b89a,_0x314ac8,_0x8384dc){const _0x4a61f8=new pa(_0x39b89a,void 0x0),_0x1e41b4=new Qn(_0x4a61f8);return kd(_0x4c12d1['_repo'],_0x4c12d1,_0x1e41b4),()=>Pd(_0x4c12d1['_repo'],_0x4c12d1,_0x1e41b4);}function Gd(_0x12138c,_0x1552df,_0xeb197c,_0x1ad1b9){return $d(_0x12138c,'value',_0x1552df);}class mt{}class ma extends mt{constructor(_0x21ddbb,_0x2181e2){super(),this['_value']=_0x21ddbb,this['_key']=_0x2181e2,this['type']='endAt';}['_apply'](_0x3258d2){He('endAt',this['_value'],_0x3258d2['_path'],!0x0);const _0x24fcba=Jh(_0x3258d2['_queryParams'],this['_value'],this['_key']);if(ga(_0x24fcba),Yn(_0x24fcba),_0x3258d2['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x3258d2['_repo'],_0x3258d2['_path'],_0x24fcba,_0x3258d2['_orderByCalled']);}}function C_(_0x1cb95d,_0x550258){return new ma(_0x1cb95d,_0x550258);}class ya extends mt{constructor(_0x3bb2c4,_0x31355c){super(),this['_value']=_0x3bb2c4,this['_key']=_0x31355c,this['type']='startAt';}['_apply'](_0x3a03b5){He('startAt',this['_value'],_0x3a03b5['_path'],!0x0);const _0x4e7209=Qh(_0x3a03b5['_queryParams'],this['_value'],this['_key']);if(ga(_0x4e7209),Yn(_0x4e7209),_0x3a03b5['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x3a03b5['_repo'],_0x3a03b5['_path'],_0x4e7209,_0x3a03b5['_orderByCalled']);}}function T_(_0x25b9c5=null,_0x10bbeb){return new ya(_0x25b9c5,_0x10bbeb);}class qd extends mt{constructor(_0x554f26){super(),this['_limit']=_0x554f26,this['type']='limitToFirst';}['_apply'](_0x2ba69e){if(_0x2ba69e['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x2ba69e['_repo'],_0x2ba69e['_path'],Yh(_0x2ba69e['_queryParams'],this['_limit']),_0x2ba69e['_orderByCalled']);}}function S_(_0x314676){if(Math['floor'](_0x314676)!==_0x314676||_0x314676<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x314676);}class zd extends mt{constructor(_0xf066cd){super(),this['_path']=_0xf066cd,this['type']='orderByChild';}['_apply'](_0x2bb67a){_a(_0x2bb67a,'orderByChild');const _0x5dc324=new C(this['_path']);if(v(_0x5dc324))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x38214d=new Ji(_0x5dc324),_0x20fbb0=xo(_0x2bb67a['_queryParams'],_0x38214d);return Yn(_0x20fbb0),new Ae(_0x2bb67a['_repo'],_0x2bb67a['_path'],_0x20fbb0,!0x0);}}function b_(_0x2fbbd7){if(_0x2fbbd7==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x2fbbd7==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x2fbbd7==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x2fbbd7),new zd(_0x2fbbd7);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x31b283){_a(_0x31b283,'orderByKey');const _0x1ca12b=xo(_0x31b283['_queryParams'],ve);return Yn(_0x1ca12b),new Ae(_0x31b283['_repo'],_0x31b283['_path'],_0x1ca12b,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x58641f,_0x3d9f0c){super(),this['_value']=_0x58641f,this['_key']=_0x3d9f0c,this['type']='equalTo';}['_apply'](_0xb44445){if(He('equalTo',this['_value'],_0xb44445['_path'],!0x1),_0xb44445['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0xb44445['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0xb44445));}}function A_(_0x1e2b2b,_0x265134){return new Kd(_0x1e2b2b,_0x265134);}function k_(_0x53ee9a,..._0x3d72c5){let _0x52cc84=P(_0x53ee9a);for(const _0x53a1f1 of _0x3d72c5)_0x52cc84=_0x53a1f1['_apply'](_0x52cc84);return _0x52cc84;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x4a3c4a,_0x52c697,_0x14e953,_0x46bde0){const _0x6f003d=_0x52c697['lastIndexOf'](':'),_0x15f242=_0x52c697['substring'](0x0,_0x6f003d),_0x31b4b7=qt(_0x15f242);_0x4a3c4a['repoInfo_']=new yo(_0x52c697,_0x31b4b7,_0x4a3c4a['repoInfo_']['namespace'],_0x4a3c4a['repoInfo_']['webSocketOnly'],_0x4a3c4a['repoInfo_']['nodeAdmin'],_0x4a3c4a['repoInfo_']['persistenceKey'],_0x4a3c4a['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x14e953),_0x46bde0&&(_0x4a3c4a['authTokenProvider_']=_0x46bde0);}function Xd(_0x5cc481,_0x17ccc8,_0x57483e,_0x4912d3,_0x43d414){let _0x17e429=_0x4912d3||_0x5cc481['options']['databaseURL'];_0x17e429===void 0x0&&(_0x5cc481['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x5cc481['options']['projectId']),_0x17e429=_0x5cc481['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x4fa3b0=vr(_0x17e429,_0x43d414),_0x18b3c9=_0x4fa3b0['repoInfo'],_0x564610;typeof process<'u'&&Bs&&(_0x564610=Bs[Yd]),_0x564610?(_0x17e429='http://'+_0x564610+'?ns='+_0x18b3c9['namespace'],_0x4fa3b0=vr(_0x17e429,_0x43d414),_0x18b3c9=_0x4fa3b0['repoInfo']):_0x4fa3b0['repoInfo']['secure'];const _0xb4ef86=new eh(_0x5cc481['name'],_0x5cc481['options'],_0x17ccc8);_d('Invalid\x20Firebase\x20Database\x20URL',_0x4fa3b0),v(_0x4fa3b0['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x4a83e0=ef(_0x18b3c9,_0x5cc481,_0xb4ef86,new Zl(_0x5cc481,_0x57483e));return new tf(_0x4a83e0,_0x5cc481);}function Zd(_0x299bd7,_0x16d884){const _0xee84f9=Di[_0x16d884];(!_0xee84f9||_0xee84f9[_0x299bd7['key']]!==_0x299bd7)&&ae('Database\x20'+_0x16d884+'('+_0x299bd7['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x299bd7),delete _0xee84f9[_0x299bd7['key']];}function ef(_0x2e35b6,_0x2d8baa,_0x15ded4,_0x1d43ae){let _0x36e92d=Di[_0x2d8baa['name']];_0x36e92d||(_0x36e92d={},Di[_0x2d8baa['name']]=_0x36e92d);let _0x2f974b=_0x36e92d[_0x2e35b6['toURLString']()];return _0x2f974b&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x2f974b=new vd(_0x2e35b6,Qd,_0x15ded4,_0x1d43ae),_0x36e92d[_0x2e35b6['toURLString']()]=_0x2f974b,_0x2f974b;}class tf{constructor(_0x35ff70,_0x4b2eb6){this['_repoInternal']=_0x35ff70,this['app']=_0x4b2eb6,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x5630cd){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x5630cd+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x55a8f3=Zr(),_0xf53b1e){const _0x1e0708=Hi(_0x55a8f3,'database')['getImmediate']({'identifier':_0xf53b1e});if(!_0x1e0708['_instanceStarted']){const _0x356b11=hc('database');_0x356b11&&nf(_0x1e0708,..._0x356b11);}return _0x1e0708;}function nf(_0x5bcf46,_0x155040,_0x292618,_0xf76281={}){_0x5bcf46=P(_0x5bcf46),_0x5bcf46['_checkNotDeleted']('useEmulator');const _0x29e68c=_0x155040+':'+_0x292618,_0x2345ba=_0x5bcf46['_repoInternal'];if(_0x5bcf46['_instanceStarted']){if(_0x29e68c===_0x5bcf46['_repoInternal']['repoInfo_']['host']&&xe(_0xf76281,_0x2345ba['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0xe4f1da;if(_0x2345ba['repoInfo_']['nodeAdmin'])_0xf76281['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0xe4f1da=new an(an['OWNER']);else{if(_0xf76281['mockUserToken']){const _0x1cef58=typeof _0xf76281['mockUserToken']=='string'?_0xf76281['mockUserToken']:uc(_0xf76281['mockUserToken'],_0x5bcf46['app']['options']['projectId']);_0xe4f1da=new an(_0x1cef58);}}qt(_0x155040)&&Qr(_0x155040),Jd(_0x2345ba,_0x29e68c,_0xf76281,_0xe4f1da);}function N_(_0x76ba49){_0x76ba49=P(_0x76ba49),_0x76ba49['_checkNotDeleted']('goOffline'),ha(_0x76ba49['_repo']);}function O_(_0x2a5215){_0x2a5215=P(_0x2a5215),_0x2a5215['_checkNotDeleted']('goOnline'),Nd(_0x2a5215['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x5469d3){Ul(dt),st(new Fe('database',(_0x4b6808,{instanceIdentifier:_0x5ddec9})=>{const _0x3c2f9c=_0x4b6808['getProvider']('app')['getImmediate'](),_0x48f78e=_0x4b6808['getProvider']('auth-internal'),_0x3eea9d=_0x4b6808['getProvider']('app-check-internal');return Xd(_0x3c2f9c,_0x48f78e,_0x3eea9d,_0x5ddec9);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x5469d3),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x48361f,_0x43a649){this['committed']=_0x48361f,this['snapshot']=_0x43a649;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x16c2a2,_0xbb3a91,_0x55629a){if(_0x16c2a2=P(_0x16c2a2),Me('Reference.transaction',_0x16c2a2['_path']),_0x16c2a2['key']==='.length'||_0x16c2a2['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x16c2a2['key']+'\x20is\x20a\x20read-only\x20object.';const _0x26bc9f=!0x0,_0x89a1c9=new H(),_0x4f9123=(_0x172418,_0x2638b9,_0x590c65)=>{let _0x1205a=null;_0x172418?_0x89a1c9['reject'](_0x172418):(_0x1205a=new lt(_0x590c65,new ee(_0x16c2a2['_repo'],_0x16c2a2['_path']),R),_0x89a1c9['resolve'](new of(_0x2638b9,_0x1205a)));},_0x2de026=Gd(_0x16c2a2,()=>{});return Od(_0x16c2a2['_repo'],_0x16c2a2['_path'],_0xbb3a91,_0x4f9123,_0x2de026,_0x26bc9f),_0x89a1c9['promise'];}se['prototype']['simpleListen']=function(_0x162b91,_0x25169f){this['sendRequest']('q',{'p':_0x162b91},_0x25169f);},se['prototype']['echo']=function(_0x128a3c,_0x4c3987){this['sendRequest']('echo',{'d':_0x128a3c},_0x4c3987);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x1f1605,..._0x1c8591){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x1f1605,..._0x1c8591);}function cn(_0x5be71b,..._0x2716bf){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x5be71b,..._0x2716bf);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x5e08ee,..._0x2184ad){throw ws(_0x5e08ee,..._0x2184ad);}function X(_0x1381e7,..._0x51f60b){return ws(_0x1381e7,..._0x51f60b);}function Ia(_0x1cbb7b,_0x22de69,_0x2dbb14){const _0x297c51={...af(),[_0x22de69]:_0x2dbb14};return new Gt('auth','Firebase',_0x297c51)['create'](_0x22de69,{'appName':_0x1cbb7b['name']});}function re(_0x363db3){return Ia(_0x363db3,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x4ca33b,..._0x70a973){if(typeof _0x4ca33b!='string'){const _0x3037e8=_0x70a973[0x0],_0x2df218=[..._0x70a973['slice'](0x1)];return _0x2df218[0x0]&&(_0x2df218[0x0]['appName']=_0x4ca33b['name']),_0x4ca33b['_errorFactory']['create'](_0x3037e8,..._0x2df218);}return Ea['create'](_0x4ca33b,..._0x70a973);}function m(_0xd4171a,_0x15ae6c,..._0x1ab4c4){if(!_0xd4171a)throw ws(_0x15ae6c,..._0x1ab4c4);}function ne(_0x3d9440){const _0x485648='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x3d9440;throw cn(_0x485648),new Error(_0x485648);}function ce(_0x456562,_0x3e2f96){_0x456562||ne(_0x3e2f96);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x5be737;return typeof self<'u'&&((_0x5be737=self['location'])==null?void 0x0:_0x5be737['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x57fe87;return typeof self<'u'&&((_0x57fe87=self['location'])==null?void 0x0:_0x57fe87['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x503242=navigator;return _0x503242['languages']&&_0x503242['languages'][0x0]||_0x503242['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x247ab3,_0x262e52){this['shortDelay']=_0x247ab3,this['longDelay']=_0x262e52,ce(_0x262e52>_0x247ab3,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x9c57b4,_0x453497){ce(_0x9c57b4['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x20fbc2}=_0x9c57b4['emulator'];return _0x453497?''+_0x20fbc2+(_0x453497['startsWith']('/')?_0x453497['slice'](0x1):_0x453497):_0x20fbc2;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x3e4856,_0x1dede0,_0x371b95){this['fetchImpl']=_0x3e4856,_0x1dede0&&(this['headersImpl']=_0x1dede0),_0x371b95&&(this['responseImpl']=_0x371b95);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x343cee,_0x34efb1){return _0x343cee['tenantId']&&!_0x34efb1['tenantId']?{..._0x34efb1,'tenantId':_0x343cee['tenantId']}:_0x34efb1;}async function Pe(_0x3e2a60,_0x56d337,_0x505d26,_0x313fd9,_0x5123f3={}){return Ca(_0x3e2a60,_0x5123f3,async()=>{let _0x8be93e={},_0x52c2d8={};_0x313fd9&&(_0x56d337==='GET'?_0x52c2d8=_0x313fd9:_0x8be93e={'body':JSON['stringify'](_0x313fd9)});const _0x2eac53=ut({..._0x52c2d8,'key':_0x3e2a60['config']['apiKey']})['slice'](0x1),_0x5546fd=await _0x3e2a60['_getAdditionalHeaders']();_0x5546fd['Content-Type']='application/json',_0x3e2a60['languageCode']&&(_0x5546fd['X-Firebase-Locale']=_0x3e2a60['languageCode']);const _0x30e70b={'method':_0x56d337,'headers':_0x5546fd,..._0x8be93e};return dc()||(_0x30e70b['referrerPolicy']='strict-origin-when-cross-origin'),_0x3e2a60['emulatorConfig']&&qt(_0x3e2a60['emulatorConfig']['host'])&&(_0x30e70b['credentials']='include'),wa['fetch']()(await Ta(_0x3e2a60,_0x3e2a60['config']['apiHost'],_0x505d26,_0x2eac53),_0x30e70b);});}async function Ca(_0x586479,_0x1d545b,_0x3c7466){_0x586479['_canInitEmulator']=!0x1;const _0x1d59cb={...df,..._0x1d545b};try{const _0x1c23ae=new gf(_0x586479),_0x1ecd81=await Promise['race']([_0x3c7466(),_0x1c23ae['promise']]);_0x1c23ae['clearNetworkTimeout']();const _0x313382=await _0x1ecd81['json']();if('needConfirmation'in _0x313382)throw on(_0x586479,'account-exists-with-different-credential',_0x313382);if(_0x1ecd81['ok']&&!('errorMessage'in _0x313382))return _0x313382;{const _0x30f6f4=_0x1ecd81['ok']?_0x313382['errorMessage']:_0x313382['error']['message'],[_0x14baf1,_0x2cad44]=_0x30f6f4['split']('\x20:\x20');if(_0x14baf1==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x586479,'credential-already-in-use',_0x313382);if(_0x14baf1==='EMAIL_EXISTS')throw on(_0x586479,'email-already-in-use',_0x313382);if(_0x14baf1==='USER_DISABLED')throw on(_0x586479,'user-disabled',_0x313382);const _0x2df8d4=_0x1d59cb[_0x14baf1]||_0x14baf1['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x2cad44)throw Ia(_0x586479,_0x2df8d4,_0x2cad44);Y(_0x586479,_0x2df8d4);}}catch(_0x1fdaff){if(_0x1fdaff instanceof Re)throw _0x1fdaff;Y(_0x586479,'network-request-failed',{'message':String(_0x1fdaff)});}}async function en(_0x2d8a0e,_0x127064,_0x5f170d,_0x2ffa5a,_0x1cb316={}){const _0x2e7102=await Pe(_0x2d8a0e,_0x127064,_0x5f170d,_0x2ffa5a,_0x1cb316);return'mfaPendingCredential'in _0x2e7102&&Y(_0x2d8a0e,'multi-factor-auth-required',{'_serverResponse':_0x2e7102}),_0x2e7102;}async function Ta(_0x501642,_0x541599,_0x262e33,_0x43b53c){const _0x3fda07=''+_0x541599+_0x262e33+'?'+_0x43b53c,_0x560d65=_0x501642,_0x6797a4=_0x560d65['config']['emulator']?Cs(_0x501642['config'],_0x3fda07):_0x501642['config']['apiScheme']+'://'+_0x3fda07;return ff['includes'](_0x262e33)&&(await _0x560d65['_persistenceManagerAvailable'],_0x560d65['_getPersistenceType']()==='COOKIE')?_0x560d65['_getPersistence']()['_getFinalTarget'](_0x6797a4)['toString']():_0x6797a4;}function _f(_0x41758b){switch(_0x41758b){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x7c9769){this['auth']=_0x7c9769,this['timer']=null,this['promise']=new Promise((_0x285e04,_0xf4dab8)=>{this['timer']=setTimeout(()=>_0xf4dab8(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x2a1b83,_0x123838,_0x5e46cb){const _0x2a91dd={'appName':_0x2a1b83['name']};_0x5e46cb['email']&&(_0x2a91dd['email']=_0x5e46cb['email']),_0x5e46cb['phoneNumber']&&(_0x2a91dd['phoneNumber']=_0x5e46cb['phoneNumber']);const _0x42df7e=X(_0x2a1b83,_0x123838,_0x2a91dd);return _0x42df7e['customData']['_tokenResponse']=_0x5e46cb,_0x42df7e;}function wr(_0x3d43da){return _0x3d43da!==void 0x0&&_0x3d43da['enterprise']!==void 0x0;}class mf{constructor(_0x5bf939){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x5bf939['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x5bf939['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x5bf939['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x4f0f85){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x20b2a9 of this['recaptchaEnforcementState'])if(_0x20b2a9['provider']&&_0x20b2a9['provider']===_0x4f0f85)return _f(_0x20b2a9['enforcementState']);return null;}['isProviderEnabled'](_0x356e52){return this['getProviderEnforcementState'](_0x356e52)==='ENFORCE'||this['getProviderEnforcementState'](_0x356e52)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x271f5b,_0x1670b2){return Pe(_0x271f5b,'GET','/v2/recaptchaConfig',ke(_0x271f5b,_0x1670b2));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x45166c,_0x51545c){return Pe(_0x45166c,'POST','/v1/accounts:delete',_0x51545c);}async function Pn(_0x5c7cf1,_0x24305c){return Pe(_0x5c7cf1,'POST','/v1/accounts:lookup',_0x24305c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x4d2263){if(_0x4d2263)try{const _0x5471e3=new Date(Number(_0x4d2263));if(!isNaN(_0x5471e3['getTime']()))return _0x5471e3['toUTCString']();}catch{}}async function Ef(_0x38fb64,_0x2fdda2=!0x1){const _0x44532d=P(_0x38fb64),_0x28770e=await _0x44532d['getIdToken'](_0x2fdda2),_0x1f3b2c=Ts(_0x28770e);m(_0x1f3b2c&&_0x1f3b2c['exp']&&_0x1f3b2c['auth_time']&&_0x1f3b2c['iat'],_0x44532d['auth'],'internal-error');const _0x250a4a=typeof _0x1f3b2c['firebase']=='object'?_0x1f3b2c['firebase']:void 0x0,_0x4fe49c=_0x250a4a==null?void 0x0:_0x250a4a['sign_in_provider'];return{'claims':_0x1f3b2c,'token':_0x28770e,'authTime':Pt(fi(_0x1f3b2c['auth_time'])),'issuedAtTime':Pt(fi(_0x1f3b2c['iat'])),'expirationTime':Pt(fi(_0x1f3b2c['exp'])),'signInProvider':_0x4fe49c||null,'signInSecondFactor':(_0x250a4a==null?void 0x0:_0x250a4a['sign_in_second_factor'])||null};}function fi(_0xb93e64){return Number(_0xb93e64)*0x3e8;}function Ts(_0x4edcc0){const [_0x547240,_0x33ebbd,_0x1a6a90]=_0x4edcc0['split']('.');if(_0x547240===void 0x0||_0x33ebbd===void 0x0||_0x1a6a90===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x11efa6=fn(_0x33ebbd);return _0x11efa6?JSON['parse'](_0x11efa6):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x2161ce){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x2161ce==null?void 0x0:_0x2161ce['toString']()),null;}}function Cr(_0x8c84c4){const _0x131e21=Ts(_0x8c84c4);return m(_0x131e21,'internal-error'),m(typeof _0x131e21['exp']<'u','internal-error'),m(typeof _0x131e21['iat']<'u','internal-error'),Number(_0x131e21['exp'])-Number(_0x131e21['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x5adf9f,_0x11975a,_0xad420b=!0x1){if(_0xad420b)return _0x11975a;try{return await _0x11975a;}catch(_0x341ee7){throw _0x341ee7 instanceof Re&&If(_0x341ee7)&&_0x5adf9f['auth']['currentUser']===_0x5adf9f&&await _0x5adf9f['auth']['signOut'](),_0x341ee7;}}function If({code:_0x459376}){return _0x459376==='auth/user-disabled'||_0x459376==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x1e2980){this['user']=_0x1e2980,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x43f0c0){if(_0x43f0c0){const _0x267c4a=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x267c4a;}else{this['errorBackoff']=0x7530;const _0x508419=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x508419);}}['schedule'](_0x3c8824=!0x1){if(!this['isRunning'])return;const _0x395d7a=this['getInterval'](_0x3c8824);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x395d7a);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x5512f9){(_0x5512f9==null?void 0x0:_0x5512f9['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x9a731f,_0x14e1e3){this['createdAt']=_0x9a731f,this['lastLoginAt']=_0x14e1e3,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x33b120){this['createdAt']=_0x33b120['createdAt'],this['lastLoginAt']=_0x33b120['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x50f170){var _0x48c6b2;const _0xd48bcf=_0x50f170['auth'],_0x40c15c=await _0x50f170['getIdToken'](),_0x5e264d=await Ht(_0x50f170,Pn(_0xd48bcf,{'idToken':_0x40c15c}));m(_0x5e264d==null?void 0x0:_0x5e264d['users']['length'],_0xd48bcf,'internal-error');const _0x13925c=_0x5e264d['users'][0x0];_0x50f170['_notifyReloadListener'](_0x13925c);const _0x536856=(_0x48c6b2=_0x13925c['providerUserInfo'])!=null&&_0x48c6b2['length']?Sa(_0x13925c['providerUserInfo']):[],_0x354952=Tf(_0x50f170['providerData'],_0x536856),_0x23b0ba=_0x50f170['isAnonymous'],_0x3b12e5=!(_0x50f170['email']&&_0x13925c['passwordHash'])&&!(_0x354952!=null&&_0x354952['length']),_0x4ccfb9=_0x23b0ba?_0x3b12e5:!0x1,_0x3c424b={'uid':_0x13925c['localId'],'displayName':_0x13925c['displayName']||null,'photoURL':_0x13925c['photoUrl']||null,'email':_0x13925c['email']||null,'emailVerified':_0x13925c['emailVerified']||!0x1,'phoneNumber':_0x13925c['phoneNumber']||null,'tenantId':_0x13925c['tenantId']||null,'providerData':_0x354952,'metadata':new Li(_0x13925c['createdAt'],_0x13925c['lastLoginAt']),'isAnonymous':_0x4ccfb9};Object['assign'](_0x50f170,_0x3c424b);}async function Cf(_0x55687c){const _0x13f9a5=P(_0x55687c);await Nn(_0x13f9a5),await _0x13f9a5['auth']['_persistUserIfCurrent'](_0x13f9a5),_0x13f9a5['auth']['_notifyListenersIfCurrent'](_0x13f9a5);}function Tf(_0x5196da,_0x4ec111){return[..._0x5196da['filter'](_0x19105e=>!_0x4ec111['some'](_0x2a17ed=>_0x2a17ed['providerId']===_0x19105e['providerId'])),..._0x4ec111];}function Sa(_0x416fbf){return _0x416fbf['map'](({providerId:_0x37ff5c,..._0x5c24ef})=>({'providerId':_0x37ff5c,'uid':_0x5c24ef['rawId']||'','displayName':_0x5c24ef['displayName']||null,'email':_0x5c24ef['email']||null,'phoneNumber':_0x5c24ef['phoneNumber']||null,'photoURL':_0x5c24ef['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0xb0e6b2,_0x11ec35){const _0x572452=await Ca(_0xb0e6b2,{},async()=>{const _0x2177ff=ut({'grant_type':'refresh_token','refresh_token':_0x11ec35})['slice'](0x1),{tokenApiHost:_0x1bf455,apiKey:_0x40ebaf}=_0xb0e6b2['config'],_0x59c80a=await Ta(_0xb0e6b2,_0x1bf455,'/v1/token','key='+_0x40ebaf),_0x38c027=await _0xb0e6b2['_getAdditionalHeaders']();_0x38c027['Content-Type']='application/x-www-form-urlencoded';const _0x47d813={'method':'POST','headers':_0x38c027,'body':_0x2177ff};return _0xb0e6b2['emulatorConfig']&&qt(_0xb0e6b2['emulatorConfig']['host'])&&(_0x47d813['credentials']='include'),wa['fetch']()(_0x59c80a,_0x47d813);});return{'accessToken':_0x572452['access_token'],'expiresIn':_0x572452['expires_in'],'refreshToken':_0x572452['refresh_token']};}async function bf(_0x447353,_0x49153c){return Pe(_0x447353,'POST','/v2/accounts:revokeToken',ke(_0x447353,_0x49153c));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x2b4ae4){m(_0x2b4ae4['idToken'],'internal-error'),m(typeof _0x2b4ae4['idToken']<'u','internal-error'),m(typeof _0x2b4ae4['refreshToken']<'u','internal-error');const _0x3142d7='expiresIn'in _0x2b4ae4&&typeof _0x2b4ae4['expiresIn']<'u'?Number(_0x2b4ae4['expiresIn']):Cr(_0x2b4ae4['idToken']);this['updateTokensAndExpiration'](_0x2b4ae4['idToken'],_0x2b4ae4['refreshToken'],_0x3142d7);}['updateFromIdToken'](_0x1f36f5){m(_0x1f36f5['length']!==0x0,'internal-error');const _0x33168a=Cr(_0x1f36f5);this['updateTokensAndExpiration'](_0x1f36f5,null,_0x33168a);}async['getToken'](_0x1b7462,_0x521801=!0x1){return!_0x521801&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x1b7462,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x1b7462,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x3f2f5d,_0x56df63){const {accessToken:_0x47a829,refreshToken:_0x20e34d,expiresIn:_0x49b6bb}=await Sf(_0x3f2f5d,_0x56df63);this['updateTokensAndExpiration'](_0x47a829,_0x20e34d,Number(_0x49b6bb));}['updateTokensAndExpiration'](_0x532ed1,_0x1eb93c,_0x46507d){this['refreshToken']=_0x1eb93c||null,this['accessToken']=_0x532ed1||null,this['expirationTime']=Date['now']()+_0x46507d*0x3e8;}static['fromJSON'](_0x124b12,_0x2faf54){const {refreshToken:_0x1fbd99,accessToken:_0x1a4518,expirationTime:_0x3e997a}=_0x2faf54,_0x344e72=new et();return _0x1fbd99&&(m(typeof _0x1fbd99=='string','internal-error',{'appName':_0x124b12}),_0x344e72['refreshToken']=_0x1fbd99),_0x1a4518&&(m(typeof _0x1a4518=='string','internal-error',{'appName':_0x124b12}),_0x344e72['accessToken']=_0x1a4518),_0x3e997a&&(m(typeof _0x3e997a=='number','internal-error',{'appName':_0x124b12}),_0x344e72['expirationTime']=_0x3e997a),_0x344e72;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x95ef22){this['accessToken']=_0x95ef22['accessToken'],this['refreshToken']=_0x95ef22['refreshToken'],this['expirationTime']=_0x95ef22['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x12a595,_0x345b74){m(typeof _0x12a595=='string'||typeof _0x12a595>'u','internal-error',{'appName':_0x345b74});}class j{constructor({uid:_0xae7c47,auth:_0x459b58,stsTokenManager:_0x1d044d,..._0x3216c2}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0xae7c47,this['auth']=_0x459b58,this['stsTokenManager']=_0x1d044d,this['accessToken']=_0x1d044d['accessToken'],this['displayName']=_0x3216c2['displayName']||null,this['email']=_0x3216c2['email']||null,this['emailVerified']=_0x3216c2['emailVerified']||!0x1,this['phoneNumber']=_0x3216c2['phoneNumber']||null,this['photoURL']=_0x3216c2['photoURL']||null,this['isAnonymous']=_0x3216c2['isAnonymous']||!0x1,this['tenantId']=_0x3216c2['tenantId']||null,this['providerData']=_0x3216c2['providerData']?[..._0x3216c2['providerData']]:[],this['metadata']=new Li(_0x3216c2['createdAt']||void 0x0,_0x3216c2['lastLoginAt']||void 0x0);}async['getIdToken'](_0x43d8da){const _0x53284c=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x43d8da));return m(_0x53284c,this['auth'],'internal-error'),this['accessToken']!==_0x53284c&&(this['accessToken']=_0x53284c,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x53284c;}['getIdTokenResult'](_0x405407){return Ef(this,_0x405407);}['reload'](){return Cf(this);}['_assign'](_0x4545de){this!==_0x4545de&&(m(this['uid']===_0x4545de['uid'],this['auth'],'internal-error'),this['displayName']=_0x4545de['displayName'],this['photoURL']=_0x4545de['photoURL'],this['email']=_0x4545de['email'],this['emailVerified']=_0x4545de['emailVerified'],this['phoneNumber']=_0x4545de['phoneNumber'],this['isAnonymous']=_0x4545de['isAnonymous'],this['tenantId']=_0x4545de['tenantId'],this['providerData']=_0x4545de['providerData']['map'](_0x4100c2=>({..._0x4100c2})),this['metadata']['_copy'](_0x4545de['metadata']),this['stsTokenManager']['_assign'](_0x4545de['stsTokenManager']));}['_clone'](_0x5e59e6){const _0x567f79=new j({...this,'auth':_0x5e59e6,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x567f79['metadata']['_copy'](this['metadata']),_0x567f79;}['_onReload'](_0x16175e){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x16175e,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x4d18e7){this['reloadListener']?this['reloadListener'](_0x4d18e7):this['reloadUserInfo']=_0x4d18e7;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x5c9d9b,_0x262014=!0x1){let _0x4598bf=!0x1;_0x5c9d9b['idToken']&&_0x5c9d9b['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x5c9d9b),_0x4598bf=!0x0),_0x262014&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x4598bf&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x18d7b7=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x18d7b7})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x1bdcd6=>({..._0x1bdcd6})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x256477,_0x2326e9){const _0x2ab4ca=_0x2326e9['displayName']??void 0x0,_0x259e22=_0x2326e9['email']??void 0x0,_0x59072a=_0x2326e9['phoneNumber']??void 0x0,_0x1cd0f5=_0x2326e9['photoURL']??void 0x0,_0x2366b1=_0x2326e9['tenantId']??void 0x0,_0x22c7d1=_0x2326e9['_redirectEventId']??void 0x0,_0x59afed=_0x2326e9['createdAt']??void 0x0,_0x412b5c=_0x2326e9['lastLoginAt']??void 0x0,{uid:_0x309913,emailVerified:_0x53c5f0,isAnonymous:_0x2dacf0,providerData:_0x2fbdc7,stsTokenManager:_0x248560}=_0x2326e9;m(_0x309913&&_0x248560,_0x256477,'internal-error');const _0x338d91=et['fromJSON'](this['name'],_0x248560);m(typeof _0x309913=='string',_0x256477,'internal-error'),le(_0x2ab4ca,_0x256477['name']),le(_0x259e22,_0x256477['name']),m(typeof _0x53c5f0=='boolean',_0x256477,'internal-error'),m(typeof _0x2dacf0=='boolean',_0x256477,'internal-error'),le(_0x59072a,_0x256477['name']),le(_0x1cd0f5,_0x256477['name']),le(_0x2366b1,_0x256477['name']),le(_0x22c7d1,_0x256477['name']),le(_0x59afed,_0x256477['name']),le(_0x412b5c,_0x256477['name']);const _0xda5af6=new j({'uid':_0x309913,'auth':_0x256477,'email':_0x259e22,'emailVerified':_0x53c5f0,'displayName':_0x2ab4ca,'isAnonymous':_0x2dacf0,'photoURL':_0x1cd0f5,'phoneNumber':_0x59072a,'tenantId':_0x2366b1,'stsTokenManager':_0x338d91,'createdAt':_0x59afed,'lastLoginAt':_0x412b5c});return _0x2fbdc7&&Array['isArray'](_0x2fbdc7)&&(_0xda5af6['providerData']=_0x2fbdc7['map'](_0x223827=>({..._0x223827}))),_0x22c7d1&&(_0xda5af6['_redirectEventId']=_0x22c7d1),_0xda5af6;}static async['_fromIdTokenResponse'](_0x47ba64,_0x57fb00,_0x17c52d=!0x1){const _0x35d486=new et();_0x35d486['updateFromServerResponse'](_0x57fb00);const _0x1deff2=new j({'uid':_0x57fb00['localId'],'auth':_0x47ba64,'stsTokenManager':_0x35d486,'isAnonymous':_0x17c52d});return await Nn(_0x1deff2),_0x1deff2;}static async['_fromGetAccountInfoResponse'](_0x35c815,_0x24a5ed,_0x402306){const _0xd2442c=_0x24a5ed['users'][0x0];m(_0xd2442c['localId']!==void 0x0,'internal-error');const _0x27784f=_0xd2442c['providerUserInfo']!==void 0x0?Sa(_0xd2442c['providerUserInfo']):[],_0x52f4cb=!(_0xd2442c['email']&&_0xd2442c['passwordHash'])&&!(_0x27784f!=null&&_0x27784f['length']),_0x36742b=new et();_0x36742b['updateFromIdToken'](_0x402306);const _0xdeb2ea=new j({'uid':_0xd2442c['localId'],'auth':_0x35c815,'stsTokenManager':_0x36742b,'isAnonymous':_0x52f4cb}),_0x5c0c5d={'uid':_0xd2442c['localId'],'displayName':_0xd2442c['displayName']||null,'photoURL':_0xd2442c['photoUrl']||null,'email':_0xd2442c['email']||null,'emailVerified':_0xd2442c['emailVerified']||!0x1,'phoneNumber':_0xd2442c['phoneNumber']||null,'tenantId':_0xd2442c['tenantId']||null,'providerData':_0x27784f,'metadata':new Li(_0xd2442c['createdAt'],_0xd2442c['lastLoginAt']),'isAnonymous':!(_0xd2442c['email']&&_0xd2442c['passwordHash'])&&!(_0x27784f!=null&&_0x27784f['length'])};return Object['assign'](_0xdeb2ea,_0x5c0c5d),_0xdeb2ea;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x3e44f1){ce(_0x3e44f1 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x130cb2=Tr['get'](_0x3e44f1);return _0x130cb2?(ce(_0x130cb2 instanceof _0x3e44f1,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x130cb2):(_0x130cb2=new _0x3e44f1(),Tr['set'](_0x3e44f1,_0x130cb2),_0x130cb2);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x217b71,_0x1d65e7){this['storage'][_0x217b71]=_0x1d65e7;}async['_get'](_0xe6908c){const _0x3d77a8=this['storage'][_0xe6908c];return _0x3d77a8===void 0x0?null:_0x3d77a8;}async['_remove'](_0x1bdc2a){delete this['storage'][_0x1bdc2a];}['_addListener'](_0x382813,_0x1e7e41){}['_removeListener'](_0xa377f3,_0xae7c33){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x3a6263,_0x4d8262,_0xf62f4f){return'firebase:'+_0x3a6263+':'+_0x4d8262+':'+_0xf62f4f;}class tt{constructor(_0x2747e3,_0x2c208f,_0x35fed4){this['persistence']=_0x2747e3,this['auth']=_0x2c208f,this['userKey']=_0x35fed4;const {config:_0x5cad1d,name:_0x1531f0}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x5cad1d['apiKey'],_0x1531f0),this['fullPersistenceKey']=ln('persistence',_0x5cad1d['apiKey'],_0x1531f0),this['boundEventHandler']=_0x2c208f['_onStorageEvent']['bind'](_0x2c208f),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x311eeb){return this['persistence']['_set'](this['fullUserKey'],_0x311eeb['toJSON']());}async['getCurrentUser'](){const _0x7c0263=await this['persistence']['_get'](this['fullUserKey']);if(!_0x7c0263)return null;if(typeof _0x7c0263=='string'){const _0x5d95e6=await Pn(this['auth'],{'idToken':_0x7c0263})['catch'](()=>{});return _0x5d95e6?j['_fromGetAccountInfoResponse'](this['auth'],_0x5d95e6,_0x7c0263):null;}return j['_fromJSON'](this['auth'],_0x7c0263);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x26502d){if(this['persistence']===_0x26502d)return;const _0x15d7fa=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x26502d,_0x15d7fa)return this['setCurrentUser'](_0x15d7fa);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x40336e,_0x22e7ac,_0x3e1b01='authUser'){if(!_0x22e7ac['length'])return new tt(ie(Sr),_0x40336e,_0x3e1b01);const _0x3aeb1e=(await Promise['all'](_0x22e7ac['map'](async _0x567ee5=>{if(await _0x567ee5['_isAvailable']())return _0x567ee5;})))['filter'](_0x560621=>_0x560621);let _0x66d971=_0x3aeb1e[0x0]||ie(Sr);const _0x5370be=ln(_0x3e1b01,_0x40336e['config']['apiKey'],_0x40336e['name']);let _0x42b69c=null;for(const _0x45ae49 of _0x22e7ac)try{const _0x375bc7=await _0x45ae49['_get'](_0x5370be);if(_0x375bc7){let _0x24a849;if(typeof _0x375bc7=='string'){const _0x2db73f=await Pn(_0x40336e,{'idToken':_0x375bc7})['catch'](()=>{});if(!_0x2db73f)break;_0x24a849=await j['_fromGetAccountInfoResponse'](_0x40336e,_0x2db73f,_0x375bc7);}else _0x24a849=j['_fromJSON'](_0x40336e,_0x375bc7);_0x45ae49!==_0x66d971&&(_0x42b69c=_0x24a849),_0x66d971=_0x45ae49;break;}}catch{}const _0x27c95b=_0x3aeb1e['filter'](_0x49c35e=>_0x49c35e['_shouldAllowMigration']);return!_0x66d971['_shouldAllowMigration']||!_0x27c95b['length']?new tt(_0x66d971,_0x40336e,_0x3e1b01):(_0x66d971=_0x27c95b[0x0],_0x42b69c&&await _0x66d971['_set'](_0x5370be,_0x42b69c['toJSON']()),await Promise['all'](_0x22e7ac['map'](async _0x31f857=>{if(_0x31f857!==_0x66d971)try{await _0x31f857['_remove'](_0x5370be);}catch{}})),new tt(_0x66d971,_0x40336e,_0x3e1b01));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0xe73518){const _0x1ac10c=_0xe73518['toLowerCase']();if(_0x1ac10c['includes']('opera/')||_0x1ac10c['includes']('opr/')||_0x1ac10c['includes']('opios/'))return'Opera';if(Pa(_0x1ac10c))return'IEMobile';if(_0x1ac10c['includes']('msie')||_0x1ac10c['includes']('trident/'))return'IE';if(_0x1ac10c['includes']('edge/'))return'Edge';if(Ra(_0x1ac10c))return'Firefox';if(_0x1ac10c['includes']('silk/'))return'Silk';if(Oa(_0x1ac10c))return'Blackberry';if(Da(_0x1ac10c))return'Webos';if(Aa(_0x1ac10c))return'Safari';if((_0x1ac10c['includes']('chrome/')||ka(_0x1ac10c))&&!_0x1ac10c['includes']('edge/'))return'Chrome';if(Na(_0x1ac10c))return'Android';{const _0x307ec1=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x385b1f=_0xe73518['match'](_0x307ec1);if((_0x385b1f==null?void 0x0:_0x385b1f['length'])===0x2)return _0x385b1f[0x1];}return'Other';}function Ra(_0x21df99=W()){return/firefox\//i['test'](_0x21df99);}function Aa(_0x4af0dd=W()){const _0x319d56=_0x4af0dd['toLowerCase']();return _0x319d56['includes']('safari/')&&!_0x319d56['includes']('chrome/')&&!_0x319d56['includes']('crios/')&&!_0x319d56['includes']('android');}function ka(_0xb79b97=W()){return/crios\//i['test'](_0xb79b97);}function Pa(_0x22a543=W()){return/iemobile/i['test'](_0x22a543);}function Na(_0x2290ac=W()){return/android/i['test'](_0x2290ac);}function Oa(_0x437a2d=W()){return/blackberry/i['test'](_0x437a2d);}function Da(_0x3f7b7b=W()){return/webos/i['test'](_0x3f7b7b);}function Ss(_0x5efd37=W()){return/iphone|ipad|ipod/i['test'](_0x5efd37)||/macintosh/i['test'](_0x5efd37)&&/mobile/i['test'](_0x5efd37);}function Rf(_0xa9d0d0=W()){var _0x11bf4b;return Ss(_0xa9d0d0)&&!!((_0x11bf4b=window['navigator'])!=null&&_0x11bf4b['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x3c4e5e=W()){return Ss(_0x3c4e5e)||Na(_0x3c4e5e)||Da(_0x3c4e5e)||Oa(_0x3c4e5e)||/windows phone/i['test'](_0x3c4e5e)||Pa(_0x3c4e5e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x34be92,_0xf22a77=[]){let _0x3ba660;switch(_0x34be92){case'Browser':_0x3ba660=br(W());break;case'Worker':_0x3ba660=br(W())+'-'+_0x34be92;break;default:_0x3ba660=_0x34be92;}const _0x524dd3=_0xf22a77['length']?_0xf22a77['join'](','):'FirebaseCore-web';return _0x3ba660+'/JsCore/'+dt+'/'+_0x524dd3;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0xb35b14){this['auth']=_0xb35b14,this['queue']=[];}['pushCallback'](_0x251b5e,_0x5ad15d){const _0x1813af=_0x3a7f65=>new Promise((_0x3ddb84,_0x1016f2)=>{try{const _0x360bf5=_0x251b5e(_0x3a7f65);_0x3ddb84(_0x360bf5);}catch(_0x2a3e33){_0x1016f2(_0x2a3e33);}});_0x1813af['onAbort']=_0x5ad15d,this['queue']['push'](_0x1813af);const _0x43d325=this['queue']['length']-0x1;return()=>{this['queue'][_0x43d325]=()=>Promise['resolve']();};}async['runMiddleware'](_0x6b50c3){if(this['auth']['currentUser']===_0x6b50c3)return;const _0x14a26a=[];try{for(const _0x3e11b5 of this['queue'])await _0x3e11b5(_0x6b50c3),_0x3e11b5['onAbort']&&_0x14a26a['push'](_0x3e11b5['onAbort']);}catch(_0x185052){_0x14a26a['reverse']();for(const _0x95cb22 of _0x14a26a)try{_0x95cb22();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x185052==null?void 0x0:_0x185052['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x3d8ac7,_0x26575f={}){return Pe(_0x3d8ac7,'GET','/v2/passwordPolicy',ke(_0x3d8ac7,_0x26575f));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x47b7d9){var _0x190bcb;const _0x5e3094=_0x47b7d9['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x5e3094['minPasswordLength']??Nf,_0x5e3094['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x5e3094['maxPasswordLength']),_0x5e3094['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x5e3094['containsLowercaseCharacter']),_0x5e3094['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x5e3094['containsUppercaseCharacter']),_0x5e3094['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x5e3094['containsNumericCharacter']),_0x5e3094['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x5e3094['containsNonAlphanumericCharacter']),this['enforcementState']=_0x47b7d9['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x190bcb=_0x47b7d9['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x190bcb['join'](''))??'',this['forceUpgradeOnSignin']=_0x47b7d9['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x47b7d9['schemaVersion'];}['validatePassword'](_0x1fecdd){const _0x5ab1d7={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x1fecdd,_0x5ab1d7),this['validatePasswordCharacterOptions'](_0x1fecdd,_0x5ab1d7),_0x5ab1d7['isValid']&&(_0x5ab1d7['isValid']=_0x5ab1d7['meetsMinPasswordLength']??!0x0),_0x5ab1d7['isValid']&&(_0x5ab1d7['isValid']=_0x5ab1d7['meetsMaxPasswordLength']??!0x0),_0x5ab1d7['isValid']&&(_0x5ab1d7['isValid']=_0x5ab1d7['containsLowercaseLetter']??!0x0),_0x5ab1d7['isValid']&&(_0x5ab1d7['isValid']=_0x5ab1d7['containsUppercaseLetter']??!0x0),_0x5ab1d7['isValid']&&(_0x5ab1d7['isValid']=_0x5ab1d7['containsNumericCharacter']??!0x0),_0x5ab1d7['isValid']&&(_0x5ab1d7['isValid']=_0x5ab1d7['containsNonAlphanumericCharacter']??!0x0),_0x5ab1d7;}['validatePasswordLengthOptions'](_0x356f96,_0x1a659a){const _0x4050bd=this['customStrengthOptions']['minPasswordLength'],_0x1d4d41=this['customStrengthOptions']['maxPasswordLength'];_0x4050bd&&(_0x1a659a['meetsMinPasswordLength']=_0x356f96['length']>=_0x4050bd),_0x1d4d41&&(_0x1a659a['meetsMaxPasswordLength']=_0x356f96['length']<=_0x1d4d41);}['validatePasswordCharacterOptions'](_0x3bd210,_0x28755a){this['updatePasswordCharacterOptionsStatuses'](_0x28755a,!0x1,!0x1,!0x1,!0x1);let _0x5eb483;for(let _0x5c0676=0x0;_0x5c0676<_0x3bd210['length'];_0x5c0676++)_0x5eb483=_0x3bd210['charAt'](_0x5c0676),this['updatePasswordCharacterOptionsStatuses'](_0x28755a,_0x5eb483>='a'&&_0x5eb483<='z',_0x5eb483>='A'&&_0x5eb483<='Z',_0x5eb483>='0'&&_0x5eb483<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x5eb483));}['updatePasswordCharacterOptionsStatuses'](_0x3bb467,_0x119204,_0x4877f0,_0x31abad,_0x3bd45d){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x3bb467['containsLowercaseLetter']||(_0x3bb467['containsLowercaseLetter']=_0x119204)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x3bb467['containsUppercaseLetter']||(_0x3bb467['containsUppercaseLetter']=_0x4877f0)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x3bb467['containsNumericCharacter']||(_0x3bb467['containsNumericCharacter']=_0x31abad)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x3bb467['containsNonAlphanumericCharacter']||(_0x3bb467['containsNonAlphanumericCharacter']=_0x3bd45d));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x5360d3,_0x1fc3e2,_0xf07694,_0x48601b){this['app']=_0x5360d3,this['heartbeatServiceProvider']=_0x1fc3e2,this['appCheckServiceProvider']=_0xf07694,this['config']=_0x48601b,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x5360d3['name'],this['clientVersion']=_0x48601b['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x61db9a=>this['_resolvePersistenceManagerAvailable']=_0x61db9a);}['_initializeWithPersistence'](_0xb12eda,_0x5ee9dc){return _0x5ee9dc&&(this['_popupRedirectResolver']=ie(_0x5ee9dc)),this['_initializationPromise']=this['queue'](async()=>{var _0x3cf6f3,_0x1af508,_0x491970;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0xb12eda),(_0x3cf6f3=this['_resolvePersistenceManagerAvailable'])==null||_0x3cf6f3['call'](this),!this['_deleted'])){if((_0x1af508=this['_popupRedirectResolver'])!=null&&_0x1af508['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x5ee9dc),this['lastNotifiedUid']=((_0x491970=this['currentUser'])==null?void 0x0:_0x491970['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x1d7fa8=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x1d7fa8)){if(this['currentUser']&&_0x1d7fa8&&this['currentUser']['uid']===_0x1d7fa8['uid']){this['_currentUser']['_assign'](_0x1d7fa8),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x1d7fa8,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x4ffc39){try{const _0x84c666=await Pn(this,{'idToken':_0x4ffc39}),_0x76b494=await j['_fromGetAccountInfoResponse'](this,_0x84c666,_0x4ffc39);await this['directlySetCurrentUser'](_0x76b494);}catch(_0x2a0861){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x2a0861),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x5420d6){var _0x4e3695;if($(this['app'])){const _0x53fcce=this['app']['settings']['authIdToken'];return _0x53fcce?new Promise(_0x52458d=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x53fcce)['then'](_0x52458d,_0x52458d));}):this['directlySetCurrentUser'](null);}const _0x2168fb=await this['assertedPersistence']['getCurrentUser']();let _0x5764ba=_0x2168fb,_0x3376b8=!0x1;if(_0x5420d6&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x591095=(_0x4e3695=this['redirectUser'])==null?void 0x0:_0x4e3695['_redirectEventId'],_0x1fb925=_0x5764ba==null?void 0x0:_0x5764ba['_redirectEventId'],_0x319a4c=await this['tryRedirectSignIn'](_0x5420d6);(!_0x591095||_0x591095===_0x1fb925)&&(_0x319a4c!=null&&_0x319a4c['user'])&&(_0x5764ba=_0x319a4c['user'],_0x3376b8=!0x0);}if(!_0x5764ba)return this['directlySetCurrentUser'](null);if(!_0x5764ba['_redirectEventId']){if(_0x3376b8)try{await this['beforeStateQueue']['runMiddleware'](_0x5764ba);}catch(_0x5bbb56){_0x5764ba=_0x2168fb,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x5bbb56));}return _0x5764ba?this['reloadAndSetCurrentUserOrClear'](_0x5764ba):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x5764ba['_redirectEventId']?this['directlySetCurrentUser'](_0x5764ba):this['reloadAndSetCurrentUserOrClear'](_0x5764ba);}async['tryRedirectSignIn'](_0x266ec5){let _0x56a0a8=null;try{_0x56a0a8=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x266ec5,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x56a0a8;}async['reloadAndSetCurrentUserOrClear'](_0x2dbd9c){try{await Nn(_0x2dbd9c);}catch(_0x38fa5c){if((_0x38fa5c==null?void 0x0:_0x38fa5c['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x2dbd9c);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x45db34){if($(this['app']))return Promise['reject'](re(this));const _0x5d77ec=_0x45db34?P(_0x45db34):null;return _0x5d77ec&&m(_0x5d77ec['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x5d77ec&&_0x5d77ec['_clone'](this));}async['_updateCurrentUser'](_0x2a58d0,_0x384d7f=!0x1){if(!this['_deleted'])return _0x2a58d0&&m(this['tenantId']===_0x2a58d0['tenantId'],this,'tenant-id-mismatch'),_0x384d7f||await this['beforeStateQueue']['runMiddleware'](_0x2a58d0),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x2a58d0),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x134e75){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x134e75));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x659bbb){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x2f0b09=this['_getPasswordPolicyInternal']();return _0x2f0b09['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x2f0b09['validatePassword'](_0x659bbb);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x5cb83a=await Pf(this),_0x4fabfc=new Of(_0x5cb83a);this['tenantId']===null?this['_projectPasswordPolicy']=_0x4fabfc:this['_tenantPasswordPolicies'][this['tenantId']]=_0x4fabfc;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x2aa2e4){this['_errorFactory']=new Gt('auth','Firebase',_0x2aa2e4());}['onAuthStateChanged'](_0x18ebbf,_0x3fde2f,_0x342a04){return this['registerStateListener'](this['authStateSubscription'],_0x18ebbf,_0x3fde2f,_0x342a04);}['beforeAuthStateChanged'](_0x4967a8,_0x540e3b){return this['beforeStateQueue']['pushCallback'](_0x4967a8,_0x540e3b);}['onIdTokenChanged'](_0x4c1c5e,_0x3e9b2c,_0x21da4e){return this['registerStateListener'](this['idTokenSubscription'],_0x4c1c5e,_0x3e9b2c,_0x21da4e);}['authStateReady'](){return new Promise((_0x2c0f5a,_0x4bb4fa)=>{if(this['currentUser'])_0x2c0f5a();else{const _0x4dd1e5=this['onAuthStateChanged'](()=>{_0x4dd1e5(),_0x2c0f5a();},_0x4bb4fa);}});}async['revokeAccessToken'](_0x37f6d1){if(this['currentUser']){const _0x4785e3=await this['currentUser']['getIdToken'](),_0x248a9d={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x37f6d1,'idToken':_0x4785e3};this['tenantId']!=null&&(_0x248a9d['tenantId']=this['tenantId']),await bf(this,_0x248a9d);}}['toJSON'](){var _0x1359aa;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x1359aa=this['_currentUser'])==null?void 0x0:_0x1359aa['toJSON']()};}async['_setRedirectUser'](_0x5a9a5f,_0x255620){const _0x5108f0=await this['getOrInitRedirectPersistenceManager'](_0x255620);return _0x5a9a5f===null?_0x5108f0['removeCurrentUser']():_0x5108f0['setCurrentUser'](_0x5a9a5f);}async['getOrInitRedirectPersistenceManager'](_0x2790d6){if(!this['redirectPersistenceManager']){const _0x1e9d91=_0x2790d6&&ie(_0x2790d6)||this['_popupRedirectResolver'];m(_0x1e9d91,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x1e9d91['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x15bc22){var _0x22f401,_0x53670c;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x22f401=this['_currentUser'])==null?void 0x0:_0x22f401['_redirectEventId'])===_0x15bc22?this['_currentUser']:((_0x53670c=this['redirectUser'])==null?void 0x0:_0x53670c['_redirectEventId'])===_0x15bc22?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x250ebc){if(_0x250ebc===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x250ebc));}['_notifyListenersIfCurrent'](_0x15cef5){_0x15cef5===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x551627;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x4aec16=((_0x551627=this['currentUser'])==null?void 0x0:_0x551627['uid'])??null;this['lastNotifiedUid']!==_0x4aec16&&(this['lastNotifiedUid']=_0x4aec16,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0xd607b5,_0x2d39cb,_0x1f1c79,_0x579533){if(this['_deleted'])return()=>{};const _0x4084cd=typeof _0x2d39cb=='function'?_0x2d39cb:_0x2d39cb['next']['bind'](_0x2d39cb);let _0x4e918b=!0x1;const _0x137c63=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x137c63,this,'internal-error'),_0x137c63['then'](()=>{_0x4e918b||_0x4084cd(this['currentUser']);}),typeof _0x2d39cb=='function'){const _0x4f4476=_0xd607b5['addObserver'](_0x2d39cb,_0x1f1c79,_0x579533);return()=>{_0x4e918b=!0x0,_0x4f4476();};}else{const _0x232028=_0xd607b5['addObserver'](_0x2d39cb);return()=>{_0x4e918b=!0x0,_0x232028();};}}async['directlySetCurrentUser'](_0x3f6708){this['currentUser']&&this['currentUser']!==_0x3f6708&&this['_currentUser']['_stopProactiveRefresh'](),_0x3f6708&&this['isProactiveRefreshEnabled']&&_0x3f6708['_startProactiveRefresh'](),this['currentUser']=_0x3f6708,_0x3f6708?await this['assertedPersistence']['setCurrentUser'](_0x3f6708):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x17c6b7){return this['operations']=this['operations']['then'](_0x17c6b7,_0x17c6b7),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x515523){!_0x515523||this['frameworks']['includes'](_0x515523)||(this['frameworks']['push'](_0x515523),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x5d816f;const _0x1b59fc={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x1b59fc['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x58f5fd=await((_0x5d816f=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x5d816f['getHeartbeatsHeader']());_0x58f5fd&&(_0x1b59fc['X-Firebase-Client']=_0x58f5fd);const _0x8f3f36=await this['_getAppCheckToken']();return _0x8f3f36&&(_0x1b59fc['X-Firebase-AppCheck']=_0x8f3f36),_0x1b59fc;}async['_getAppCheckToken'](){var _0x175522;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x20d16d=await((_0x175522=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x175522['getToken']());return _0x20d16d!=null&&_0x20d16d['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x20d16d['error']),_0x20d16d==null?void 0x0:_0x20d16d['token'];}}function Ke(_0x20b050){return P(_0x20b050);}class Rr{constructor(_0x4015e2){this['auth']=_0x4015e2,this['observer']=null,this['addObserver']=Tc(_0x2d5c54=>this['observer']=_0x2d5c54);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x613f2f){Jn=_0x613f2f;}function xa(_0x58eecf){return Jn['loadJS'](_0x58eecf);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x197c0f){return'__'+_0x197c0f+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0xd90160){_0xd90160();}['execute'](_0x5114ef,_0x29902d){return Promise['resolve']('token');}['render'](_0x50d9a9,_0x4085c9){return'';}}class Wf{['ready'](_0x17aae7){_0x17aae7();}['execute'](_0x4d15e0,_0x5ceef0){return Promise['resolve']('token');}['render'](_0x121f03,_0x40f46a){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0xea3cdc){this['type']=Bf,this['auth']=Ke(_0xea3cdc);}async['verify'](_0x114fbd='verify',_0x2f11b0=!0x1){async function _0x1616ce(_0x1fb8af){if(!_0x2f11b0){if(_0x1fb8af['tenantId']==null&&_0x1fb8af['_agentRecaptchaConfig']!=null)return _0x1fb8af['_agentRecaptchaConfig']['siteKey'];if(_0x1fb8af['tenantId']!=null&&_0x1fb8af['_tenantRecaptchaConfigs'][_0x1fb8af['tenantId']]!==void 0x0)return _0x1fb8af['_tenantRecaptchaConfigs'][_0x1fb8af['tenantId']]['siteKey'];}return new Promise(async(_0x51f869,_0x536875)=>{yf(_0x1fb8af,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x214add=>{if(_0x214add['recaptchaKey']===void 0x0)_0x536875(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x140c18=new mf(_0x214add);return _0x1fb8af['tenantId']==null?_0x1fb8af['_agentRecaptchaConfig']=_0x140c18:_0x1fb8af['_tenantRecaptchaConfigs'][_0x1fb8af['tenantId']]=_0x140c18,_0x51f869(_0x140c18['siteKey']);}})['catch'](_0x153ad7=>{_0x536875(_0x153ad7);});});}function _0x3f24ed(_0x5e2306,_0x34c8d2,_0x35e2be){const _0x5178ab=window['grecaptcha'];wr(_0x5178ab)?_0x5178ab['enterprise']['ready'](()=>{_0x5178ab['enterprise']['execute'](_0x5e2306,{'action':_0x114fbd})['then'](_0x514ccc=>{_0x34c8d2(_0x514ccc);})['catch'](()=>{_0x34c8d2(Fa);});}):_0x35e2be(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x81b443,_0x2ec2b2)=>{_0x1616ce(this['auth'])['then'](async _0xd7d097=>{if(!_0x2f11b0&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x3f24ed(_0xd7d097,_0x81b443,_0x2ec2b2);else{if(typeof window>'u'){_0x2ec2b2(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x8d55cd=Lf();_0x8d55cd['length']!==0x0&&(_0x8d55cd+=_0xd7d097+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x5127fb;(_0x5127fb=he['scriptInjectionDeferred'])==null||_0x5127fb['resolve']();},xa(_0x8d55cd)['then'](()=>{var _0x53fb3f;return(_0x53fb3f=he['scriptInjectionDeferred'])==null?void 0x0:_0x53fb3f['promise'];})['then'](()=>{_0x3f24ed(_0xd7d097,_0x81b443,_0x2ec2b2);})['catch'](_0x141a16=>{_0x2ec2b2(_0x141a16);});}})['catch'](_0x1b4879=>{_0x2ec2b2(_0x1b4879);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x338994,_0x50fa14,_0x21fb81,_0x246f4b=!0x1,_0x29749f=!0x1){const _0x3c97f2=new he(_0x338994);let _0x2fc821;if(_0x29749f)_0x2fc821=Fa;else try{_0x2fc821=await _0x3c97f2['verify'](_0x21fb81);}catch{_0x2fc821=await _0x3c97f2['verify'](_0x21fb81,!0x0);}const _0x1d6442={..._0x50fa14};if(_0x21fb81==='mfaSmsEnrollment'||_0x21fb81==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x1d6442){const _0x41ea02=_0x1d6442['phoneEnrollmentInfo']['phoneNumber'],_0x1109e7=_0x1d6442['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x1d6442,{'phoneEnrollmentInfo':{'phoneNumber':_0x41ea02,'recaptchaToken':_0x1109e7,'captchaResponse':_0x2fc821,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x1d6442){const _0x4dbf20=_0x1d6442['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x1d6442,{'phoneSignInInfo':{'recaptchaToken':_0x4dbf20,'captchaResponse':_0x2fc821,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x1d6442;}return _0x246f4b?Object['assign'](_0x1d6442,{'captchaResp':_0x2fc821}):Object['assign'](_0x1d6442,{'captchaResponse':_0x2fc821}),Object['assign'](_0x1d6442,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x1d6442,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x1d6442;}async function xi(_0x519c48,_0x2517ca,_0x34cccb,_0x368b13,_0x363568){var _0x12c907;if((_0x12c907=_0x519c48['_getRecaptchaConfig']())!=null&&_0x12c907['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x5b9afd=await kr(_0x519c48,_0x2517ca,_0x34cccb,_0x34cccb==='getOobCode');return _0x368b13(_0x519c48,_0x5b9afd);}else return _0x368b13(_0x519c48,_0x2517ca)['catch'](async _0xc0ad70=>{if(_0xc0ad70['code']==='auth/missing-recaptcha-token'){console['log'](_0x34cccb+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x265c75=await kr(_0x519c48,_0x2517ca,_0x34cccb,_0x34cccb==='getOobCode');return _0x368b13(_0x519c48,_0x265c75);}else return Promise['reject'](_0xc0ad70);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x2091d0,_0x1f916f){const _0x14eb8a=Hi(_0x2091d0,'auth');if(_0x14eb8a['isInitialized']()){const _0xcf845e=_0x14eb8a['getImmediate'](),_0x4fbf9f=_0x14eb8a['getOptions']();if(xe(_0x4fbf9f,_0x1f916f??{}))return _0xcf845e;Y(_0xcf845e,'already-initialized');}return _0x14eb8a['initialize']({'options':_0x1f916f});}function Hf(_0xb74dbc,_0x4e61d9){const _0x5eaaf3=(_0x4e61d9==null?void 0x0:_0x4e61d9['persistence'])||[],_0xfd1269=(Array['isArray'](_0x5eaaf3)?_0x5eaaf3:[_0x5eaaf3])['map'](ie);_0x4e61d9!=null&&_0x4e61d9['errorMap']&&_0xb74dbc['_updateErrorMap'](_0x4e61d9['errorMap']),_0xb74dbc['_initializeWithPersistence'](_0xfd1269,_0x4e61d9==null?void 0x0:_0x4e61d9['popupRedirectResolver']);}function $f(_0x37569d,_0x3a2ab2,_0x1c5340){const _0x3bd8fa=Ke(_0x37569d);m(/^https?:\/\//['test'](_0x3a2ab2),_0x3bd8fa,'invalid-emulator-scheme');const _0x58cfa5=!0x1,_0x568246=Ua(_0x3a2ab2),{host:_0x1e0fe7,port:_0x55c3ec}=Gf(_0x3a2ab2),_0x5da7c2=_0x55c3ec===null?'':':'+_0x55c3ec,_0x372cad={'url':_0x568246+'//'+_0x1e0fe7+_0x5da7c2+'/'},_0x59e6c3=Object['freeze']({'host':_0x1e0fe7,'port':_0x55c3ec,'protocol':_0x568246['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x58cfa5})});if(!_0x3bd8fa['_canInitEmulator']){m(_0x3bd8fa['config']['emulator']&&_0x3bd8fa['emulatorConfig'],_0x3bd8fa,'emulator-config-failed'),m(xe(_0x372cad,_0x3bd8fa['config']['emulator'])&&xe(_0x59e6c3,_0x3bd8fa['emulatorConfig']),_0x3bd8fa,'emulator-config-failed');return;}_0x3bd8fa['config']['emulator']=_0x372cad,_0x3bd8fa['emulatorConfig']=_0x59e6c3,_0x3bd8fa['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x1e0fe7)?Qr(_0x568246+'//'+_0x1e0fe7+_0x5da7c2):qf();}function Ua(_0x48eb1d){const _0xe02228=_0x48eb1d['indexOf'](':');return _0xe02228<0x0?'':_0x48eb1d['substr'](0x0,_0xe02228+0x1);}function Gf(_0x28fdb8){const _0x5e6ada=Ua(_0x28fdb8),_0x1f941e=/(\/\/)?([^?#/]+)/['exec'](_0x28fdb8['substr'](_0x5e6ada['length']));if(!_0x1f941e)return{'host':'','port':null};const _0x276f45=_0x1f941e[0x2]['split']('@')['pop']()||'',_0x2d6839=/^(\[[^\]]+\])(:|$)/['exec'](_0x276f45);if(_0x2d6839){const _0x4247d9=_0x2d6839[0x1];return{'host':_0x4247d9,'port':Pr(_0x276f45['substr'](_0x4247d9['length']+0x1))};}else{const [_0x33bb17,_0x394d31]=_0x276f45['split'](':');return{'host':_0x33bb17,'port':Pr(_0x394d31)};}}function Pr(_0x129b8c){if(!_0x129b8c)return null;const _0x239898=Number(_0x129b8c);return isNaN(_0x239898)?null:_0x239898;}function qf(){function _0x41f4c0(){const _0x4df9eb=document['createElement']('p'),_0x7cf53c=_0x4df9eb['style'];_0x4df9eb['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x7cf53c['position']='fixed',_0x7cf53c['width']='100%',_0x7cf53c['backgroundColor']='#ffffff',_0x7cf53c['border']='.1em\x20solid\x20#000000',_0x7cf53c['color']='#b50000',_0x7cf53c['bottom']='0px',_0x7cf53c['left']='0px',_0x7cf53c['margin']='0px',_0x7cf53c['zIndex']='10000',_0x7cf53c['textAlign']='center',_0x4df9eb['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x4df9eb);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x41f4c0):_0x41f4c0());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x3cd72d,_0x5853a3){this['providerId']=_0x3cd72d,this['signInMethod']=_0x5853a3;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x2c904c){return ne('not\x20implemented');}['_linkToIdToken'](_0x374ff0,_0x592053){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x1e0a79){return ne('not\x20implemented');}}async function zf(_0x3891c3,_0x1a4196){return Pe(_0x3891c3,'POST','/v1/accounts:signUp',_0x1a4196);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x34425a,_0x422238){return en(_0x34425a,'POST','/v1/accounts:signInWithPassword',ke(_0x34425a,_0x422238));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x573dec,_0xe80285){return en(_0x573dec,'POST','/v1/accounts:signInWithEmailLink',ke(_0x573dec,_0xe80285));}async function Yf(_0x1563b9,_0xe0fda6){return en(_0x1563b9,'POST','/v1/accounts:signInWithEmailLink',ke(_0x1563b9,_0xe0fda6));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x115593,_0x46c2bb,_0x25e555,_0x145181=null){super('password',_0x25e555),this['_email']=_0x115593,this['_password']=_0x46c2bb,this['_tenantId']=_0x145181;}static['_fromEmailAndPassword'](_0xbdda93,_0x1183d7){return new $t(_0xbdda93,_0x1183d7,'password');}static['_fromEmailAndCode'](_0x576d68,_0x4d3cfb,_0xac0556=null){return new $t(_0x576d68,_0x4d3cfb,'emailLink',_0xac0556);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x188ecc){const _0x164d96=typeof _0x188ecc=='string'?JSON['parse'](_0x188ecc):_0x188ecc;if(_0x164d96!=null&&_0x164d96['email']&&(_0x164d96!=null&&_0x164d96['password'])){if(_0x164d96['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x164d96['email'],_0x164d96['password']);if(_0x164d96['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x164d96['email'],_0x164d96['password'],_0x164d96['tenantId']);}return null;}async['_getIdTokenResponse'](_0x41be7f){switch(this['signInMethod']){case'password':const _0x4a8678={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x41be7f,_0x4a8678,'signInWithPassword',jf);case'emailLink':return Kf(_0x41be7f,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x41be7f,'internal-error');}}async['_linkToIdToken'](_0x10db24,_0x57d597){switch(this['signInMethod']){case'password':const _0x148323={'idToken':_0x57d597,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x10db24,_0x148323,'signUpPassword',zf);case'emailLink':return Yf(_0x10db24,{'idToken':_0x57d597,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x10db24,'internal-error');}}['_getReauthenticationResolver'](_0x40e30c){return this['_getIdTokenResponse'](_0x40e30c);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x31de1e,_0x719613){return en(_0x31de1e,'POST','/v1/accounts:signInWithIdp',ke(_0x31de1e,_0x719613));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x1ab527){const _0x5f32ff=new $e(_0x1ab527['providerId'],_0x1ab527['signInMethod']);return _0x1ab527['idToken']||_0x1ab527['accessToken']?(_0x1ab527['idToken']&&(_0x5f32ff['idToken']=_0x1ab527['idToken']),_0x1ab527['accessToken']&&(_0x5f32ff['accessToken']=_0x1ab527['accessToken']),_0x1ab527['nonce']&&!_0x1ab527['pendingToken']&&(_0x5f32ff['nonce']=_0x1ab527['nonce']),_0x1ab527['pendingToken']&&(_0x5f32ff['pendingToken']=_0x1ab527['pendingToken'])):_0x1ab527['oauthToken']&&_0x1ab527['oauthTokenSecret']?(_0x5f32ff['accessToken']=_0x1ab527['oauthToken'],_0x5f32ff['secret']=_0x1ab527['oauthTokenSecret']):Y('argument-error'),_0x5f32ff;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x236295){const _0x6226f7=typeof _0x236295=='string'?JSON['parse'](_0x236295):_0x236295,{providerId:_0x2cd2f9,signInMethod:_0xafd2a5,..._0x3992c1}=_0x6226f7;if(!_0x2cd2f9||!_0xafd2a5)return null;const _0x4abdf0=new $e(_0x2cd2f9,_0xafd2a5);return _0x4abdf0['idToken']=_0x3992c1['idToken']||void 0x0,_0x4abdf0['accessToken']=_0x3992c1['accessToken']||void 0x0,_0x4abdf0['secret']=_0x3992c1['secret'],_0x4abdf0['nonce']=_0x3992c1['nonce'],_0x4abdf0['pendingToken']=_0x3992c1['pendingToken']||null,_0x4abdf0;}['_getIdTokenResponse'](_0x174606){const _0x43c237=this['buildRequest']();return nt(_0x174606,_0x43c237);}['_linkToIdToken'](_0x186f63,_0x1b8710){const _0x2c6e55=this['buildRequest']();return _0x2c6e55['idToken']=_0x1b8710,nt(_0x186f63,_0x2c6e55);}['_getReauthenticationResolver'](_0xbf30f4){const _0x179fa4=this['buildRequest']();return _0x179fa4['autoCreate']=!0x1,nt(_0xbf30f4,_0x179fa4);}['buildRequest'](){const _0x3ec485={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x3ec485['pendingToken']=this['pendingToken'];else{const _0x576244={};this['idToken']&&(_0x576244['id_token']=this['idToken']),this['accessToken']&&(_0x576244['access_token']=this['accessToken']),this['secret']&&(_0x576244['oauth_token_secret']=this['secret']),_0x576244['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x576244['nonce']=this['nonce']),_0x3ec485['postBody']=ut(_0x576244);}return _0x3ec485;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x502bc6){switch(_0x502bc6){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x22c563){const _0x47752a=Ct(Tt(_0x22c563))['link'],_0x4b8caa=_0x47752a?Ct(Tt(_0x47752a))['deep_link_id']:null,_0x254050=Ct(Tt(_0x22c563))['deep_link_id'];return(_0x254050?Ct(Tt(_0x254050))['link']:null)||_0x254050||_0x4b8caa||_0x47752a||_0x22c563;}class Rs{constructor(_0x48c992){const _0x22c1d9=Ct(Tt(_0x48c992)),_0xb4cbb7=_0x22c1d9['apiKey']??null,_0xb9324a=_0x22c1d9['oobCode']??null,_0x36c1d7=Jf(_0x22c1d9['mode']??null);m(_0xb4cbb7&&_0xb9324a&&_0x36c1d7,'argument-error'),this['apiKey']=_0xb4cbb7,this['operation']=_0x36c1d7,this['code']=_0xb9324a,this['continueUrl']=_0x22c1d9['continueUrl']??null,this['languageCode']=_0x22c1d9['lang']??null,this['tenantId']=_0x22c1d9['tenantId']??null;}static['parseLink'](_0x4f347b){const _0x40ff81=Xf(_0x4f347b);try{return new Rs(_0x40ff81);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x202a19,_0x2acf4b){return $t['_fromEmailAndPassword'](_0x202a19,_0x2acf4b);}static['credentialWithLink'](_0x178e31,_0x5adf79){const _0x44670d=Rs['parseLink'](_0x5adf79);return m(_0x44670d,'argument-error'),$t['_fromEmailAndCode'](_0x178e31,_0x44670d['code'],_0x44670d['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x2b004c){this['providerId']=_0x2b004c,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x44dc3a){this['defaultLanguageCode']=_0x44dc3a;}['setCustomParameters'](_0x303ef6){return this['customParameters']=_0x303ef6,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x26b3c5){return this['scopes']['includes'](_0x26b3c5)||this['scopes']['push'](_0x26b3c5),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x4c69ed){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x4c69ed});}static['credentialFromResult'](_0x181e82){return ue['credentialFromTaggedObject'](_0x181e82);}static['credentialFromError'](_0x3e3f3f){return ue['credentialFromTaggedObject'](_0x3e3f3f['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5f48f7}){if(!_0x5f48f7||!('oauthAccessToken'in _0x5f48f7)||!_0x5f48f7['oauthAccessToken'])return null;try{return ue['credential'](_0x5f48f7['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0xc69bac,_0x552fa9){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0xc69bac,'accessToken':_0x552fa9});}static['credentialFromResult'](_0x14b4ab){return de['credentialFromTaggedObject'](_0x14b4ab);}static['credentialFromError'](_0x95988c){return de['credentialFromTaggedObject'](_0x95988c['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4b2fc3}){if(!_0x4b2fc3)return null;const {oauthIdToken:_0xd86f6e,oauthAccessToken:_0x447551}=_0x4b2fc3;if(!_0xd86f6e&&!_0x447551)return null;try{return de['credential'](_0xd86f6e,_0x447551);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x4640b4){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x4640b4});}static['credentialFromResult'](_0x3cb3e1){return fe['credentialFromTaggedObject'](_0x3cb3e1);}static['credentialFromError'](_0x44d437){return fe['credentialFromTaggedObject'](_0x44d437['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x24110f}){if(!_0x24110f||!('oauthAccessToken'in _0x24110f)||!_0x24110f['oauthAccessToken'])return null;try{return fe['credential'](_0x24110f['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x3a7575,_0x3fe614){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x3a7575,'oauthTokenSecret':_0x3fe614});}static['credentialFromResult'](_0x1b1efc){return pe['credentialFromTaggedObject'](_0x1b1efc);}static['credentialFromError'](_0x4fc79b){return pe['credentialFromTaggedObject'](_0x4fc79b['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4ad515}){if(!_0x4ad515)return null;const {oauthAccessToken:_0x18c832,oauthTokenSecret:_0x30ba34}=_0x4ad515;if(!_0x18c832||!_0x30ba34)return null;try{return pe['credential'](_0x18c832,_0x30ba34);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x20a5ae,_0x41aa4d){return en(_0x20a5ae,'POST','/v1/accounts:signUp',ke(_0x20a5ae,_0x41aa4d));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0xca1036){this['user']=_0xca1036['user'],this['providerId']=_0xca1036['providerId'],this['_tokenResponse']=_0xca1036['_tokenResponse'],this['operationType']=_0xca1036['operationType'];}static async['_fromIdTokenResponse'](_0x4cc6bb,_0x574658,_0x12c96a,_0x43a18a=!0x1){const _0x845450=await j['_fromIdTokenResponse'](_0x4cc6bb,_0x12c96a,_0x43a18a),_0x385e74=Nr(_0x12c96a);return new Ge({'user':_0x845450,'providerId':_0x385e74,'_tokenResponse':_0x12c96a,'operationType':_0x574658});}static async['_forOperation'](_0x2f18f6,_0x4f0d3f,_0x1cdf67){await _0x2f18f6['_updateTokensIfNecessary'](_0x1cdf67,!0x0);const _0x38baba=Nr(_0x1cdf67);return new Ge({'user':_0x2f18f6,'providerId':_0x38baba,'_tokenResponse':_0x1cdf67,'operationType':_0x4f0d3f});}}function Nr(_0x5aa4e9){return _0x5aa4e9['providerId']?_0x5aa4e9['providerId']:'phoneNumber'in _0x5aa4e9?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x45f0ac,_0x206913,_0x539db0,_0x5e1aad){super(_0x206913['code'],_0x206913['message']),this['operationType']=_0x539db0,this['user']=_0x5e1aad,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x45f0ac['name'],'tenantId':_0x45f0ac['tenantId']??void 0x0,'_serverResponse':_0x206913['customData']['_serverResponse'],'operationType':_0x539db0};}static['_fromErrorAndOperation'](_0x451da5,_0x1dba2f,_0xbc5964,_0x5e6153){return new On(_0x451da5,_0x1dba2f,_0xbc5964,_0x5e6153);}}function Ba(_0x27b936,_0x39517d,_0x4ceb71,_0x2d8e1b){return(_0x39517d==='reauthenticate'?_0x4ceb71['_getReauthenticationResolver'](_0x27b936):_0x4ceb71['_getIdTokenResponse'](_0x27b936))['catch'](_0x2a1720=>{throw _0x2a1720['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x27b936,_0x2a1720,_0x39517d,_0x2d8e1b):_0x2a1720;});}async function ep(_0x260e51,_0x2abf54,_0x5cee6c=!0x1){const _0xfd5483=await Ht(_0x260e51,_0x2abf54['_linkToIdToken'](_0x260e51['auth'],await _0x260e51['getIdToken']()),_0x5cee6c);return Ge['_forOperation'](_0x260e51,'link',_0xfd5483);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x58df31,_0x24a804,_0x431b5b=!0x1){const {auth:_0x4c843c}=_0x58df31;if($(_0x4c843c['app']))return Promise['reject'](re(_0x4c843c));const _0x44c706='reauthenticate';try{const _0x4a1088=await Ht(_0x58df31,Ba(_0x4c843c,_0x44c706,_0x24a804,_0x58df31),_0x431b5b);m(_0x4a1088['idToken'],_0x4c843c,'internal-error');const _0x57bc89=Ts(_0x4a1088['idToken']);m(_0x57bc89,_0x4c843c,'internal-error');const {sub:_0x5cec45}=_0x57bc89;return m(_0x58df31['uid']===_0x5cec45,_0x4c843c,'user-mismatch'),Ge['_forOperation'](_0x58df31,_0x44c706,_0x4a1088);}catch(_0x5b6cd7){throw(_0x5b6cd7==null?void 0x0:_0x5b6cd7['code'])==='auth/user-not-found'&&Y(_0x4c843c,'user-mismatch'),_0x5b6cd7;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x2fe605,_0x7ddcc2,_0x4f6375=!0x1){if($(_0x2fe605['app']))return Promise['reject'](re(_0x2fe605));const _0x3aad5b='signIn',_0x572be9=await Ba(_0x2fe605,_0x3aad5b,_0x7ddcc2),_0x224c7a=await Ge['_fromIdTokenResponse'](_0x2fe605,_0x3aad5b,_0x572be9);return _0x4f6375||await _0x2fe605['_updateCurrentUser'](_0x224c7a['user']),_0x224c7a;}async function np(_0x46c1a7,_0x1617c9){return Va(Ke(_0x46c1a7),_0x1617c9);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x382a0f){const _0x1440f4=Ke(_0x382a0f);_0x1440f4['_getPasswordPolicyInternal']()&&await _0x1440f4['_updatePasswordPolicy']();}async function L_(_0x157816,_0x595ec2,_0x26eacc){if($(_0x157816['app']))return Promise['reject'](re(_0x157816));const _0x22fe9f=Ke(_0x157816),_0x34eb22=await xi(_0x22fe9f,{'returnSecureToken':!0x0,'email':_0x595ec2,'password':_0x26eacc,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x420da8=>{throw _0x420da8['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x157816),_0x420da8;}),_0x2af842=await Ge['_fromIdTokenResponse'](_0x22fe9f,'signIn',_0x34eb22);return await _0x22fe9f['_updateCurrentUser'](_0x2af842['user']),_0x2af842;}function x_(_0x46da75,_0x15a3de,_0x2b9d72){return $(_0x46da75['app'])?Promise['reject'](re(_0x46da75)):np(P(_0x46da75),yt['credential'](_0x15a3de,_0x2b9d72))['catch'](async _0x19af48=>{throw _0x19af48['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x46da75),_0x19af48;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x161773,_0xb0baef){return P(_0x161773)['setPersistence'](_0xb0baef);}function ip(_0x4c5f37,_0x5e16f7,_0x15bb16,_0x35d669){return P(_0x4c5f37)['onIdTokenChanged'](_0x5e16f7,_0x15bb16,_0x35d669);}function sp(_0x5f5136,_0x442b2a,_0x11de43){return P(_0x5f5136)['beforeAuthStateChanged'](_0x442b2a,_0x11de43);}function U_(_0x4e0f16,_0x4656b0,_0x376e0d,_0x379c42){return P(_0x4e0f16)['onAuthStateChanged'](_0x4656b0,_0x376e0d,_0x379c42);}function W_(_0x4767c7){return P(_0x4767c7)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0xa59aa4,_0x425930){this['storageRetriever']=_0xa59aa4,this['type']=_0x425930;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x323124,_0x3c7131){return this['storage']['setItem'](_0x323124,JSON['stringify'](_0x3c7131)),Promise['resolve']();}['_get'](_0x3ed1bc){const _0x544f45=this['storage']['getItem'](_0x3ed1bc);return Promise['resolve'](_0x544f45?JSON['parse'](_0x544f45):null);}['_remove'](_0x147508){return this['storage']['removeItem'](_0x147508),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x570ac8,_0x1cdc99)=>this['onStorageEvent'](_0x570ac8,_0x1cdc99),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x80a8bc){for(const _0x138be5 of Object['keys'](this['listeners'])){const _0x54dae1=this['storage']['getItem'](_0x138be5),_0x31831f=this['localCache'][_0x138be5];_0x54dae1!==_0x31831f&&_0x80a8bc(_0x138be5,_0x31831f,_0x54dae1);}}['onStorageEvent'](_0x821414,_0x13614f=!0x1){if(!_0x821414['key']){this['forAllChangedKeys']((_0x29df0c,_0x22a3f3,_0x197633)=>{this['notifyListeners'](_0x29df0c,_0x197633);});return;}const _0x1086ef=_0x821414['key'];_0x13614f?this['detachListener']():this['stopPolling']();const _0xa42600=()=>{const _0x3ee955=this['storage']['getItem'](_0x1086ef);!_0x13614f&&this['localCache'][_0x1086ef]===_0x3ee955||this['notifyListeners'](_0x1086ef,_0x3ee955);},_0x57d7f5=this['storage']['getItem'](_0x1086ef);Af()&&_0x57d7f5!==_0x821414['newValue']&&_0x821414['newValue']!==_0x821414['oldValue']?setTimeout(_0xa42600,op):_0xa42600();}['notifyListeners'](_0x3c5072,_0x178d43){this['localCache'][_0x3c5072]=_0x178d43;const _0x453c7b=this['listeners'][_0x3c5072];if(_0x453c7b){for(const _0x25f7b1 of Array['from'](_0x453c7b))_0x25f7b1(_0x178d43&&JSON['parse'](_0x178d43));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x219463,_0x22867e,_0x38c312)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x219463,'oldValue':_0x22867e,'newValue':_0x38c312}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x31b622,_0x32fa22){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x31b622]||(this['listeners'][_0x31b622]=new Set(),this['localCache'][_0x31b622]=this['storage']['getItem'](_0x31b622)),this['listeners'][_0x31b622]['add'](_0x32fa22);}['_removeListener'](_0x2038e6,_0x588ee8){this['listeners'][_0x2038e6]&&(this['listeners'][_0x2038e6]['delete'](_0x588ee8),this['listeners'][_0x2038e6]['size']===0x0&&delete this['listeners'][_0x2038e6]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x17909d,_0x50c88e){await super['_set'](_0x17909d,_0x50c88e),this['localCache'][_0x17909d]=JSON['stringify'](_0x50c88e);}async['_get'](_0x276915){const _0x35d6dd=await super['_get'](_0x276915);return this['localCache'][_0x276915]=JSON['stringify'](_0x35d6dd),_0x35d6dd;}async['_remove'](_0x717eb){await super['_remove'](_0x717eb),delete this['localCache'][_0x717eb];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x516fed,_0x46753a){}['_removeListener'](_0x3b3e0f,_0x51e3b2){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x50646b){return Promise['all'](_0x50646b['map'](async _0x588f31=>{try{return{'fulfilled':!0x0,'value':await _0x588f31};}catch(_0x23bd34){return{'fulfilled':!0x1,'reason':_0x23bd34};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x59bece){this['eventTarget']=_0x59bece,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x401660){const _0x4cb0b1=this['receivers']['find'](_0x38e801=>_0x38e801['isListeningto'](_0x401660));if(_0x4cb0b1)return _0x4cb0b1;const _0x35f3e2=new Xn(_0x401660);return this['receivers']['push'](_0x35f3e2),_0x35f3e2;}['isListeningto'](_0x3960a9){return this['eventTarget']===_0x3960a9;}async['handleEvent'](_0xc6e678){const _0x3210f6=_0xc6e678,{eventId:_0x56fed0,eventType:_0x1e0366,data:_0x1992e4}=_0x3210f6['data'],_0x3e4774=this['handlersMap'][_0x1e0366];if(!(_0x3e4774!=null&&_0x3e4774['size']))return;_0x3210f6['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x56fed0,'eventType':_0x1e0366});const _0x38817e=Array['from'](_0x3e4774)['map'](async _0x4dfd73=>_0x4dfd73(_0x3210f6['origin'],_0x1992e4)),_0x220296=await cp(_0x38817e);_0x3210f6['ports'][0x0]['postMessage']({'status':'done','eventId':_0x56fed0,'eventType':_0x1e0366,'response':_0x220296});}['_subscribe'](_0x56ad34,_0x15ab13){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x56ad34]||(this['handlersMap'][_0x56ad34]=new Set()),this['handlersMap'][_0x56ad34]['add'](_0x15ab13);}['_unsubscribe'](_0x487d59,_0x52a993){this['handlersMap'][_0x487d59]&&_0x52a993&&this['handlersMap'][_0x487d59]['delete'](_0x52a993),(!_0x52a993||this['handlersMap'][_0x487d59]['size']===0x0)&&delete this['handlersMap'][_0x487d59],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x1bc9e5='',_0x4aefc1=0xa){let _0x34f2b7='';for(let _0x163a20=0x0;_0x163a20<_0x4aefc1;_0x163a20++)_0x34f2b7+=Math['floor'](Math['random']()*0xa);return _0x1bc9e5+_0x34f2b7;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x2d0409){this['target']=_0x2d0409,this['handlers']=new Set();}['removeMessageHandler'](_0x410693){_0x410693['messageChannel']&&(_0x410693['messageChannel']['port1']['removeEventListener']('message',_0x410693['onMessage']),_0x410693['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x410693);}async['_send'](_0x3a99e2,_0x25c0fb,_0x42eeef=0x32){const _0x2ee2a5=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x2ee2a5)throw new Error('connection_unavailable');let _0x4c64eb,_0xd3156e;return new Promise((_0x5c1ec0,_0x4b6af3)=>{const _0x70d448=As('',0x14);_0x2ee2a5['port1']['start']();const _0x2e0e0e=setTimeout(()=>{_0x4b6af3(new Error('unsupported_event'));},_0x42eeef);_0xd3156e={'messageChannel':_0x2ee2a5,'onMessage'(_0x4131eb){const _0x7889e3=_0x4131eb;if(_0x7889e3['data']['eventId']===_0x70d448)switch(_0x7889e3['data']['status']){case'ack':clearTimeout(_0x2e0e0e),_0x4c64eb=setTimeout(()=>{_0x4b6af3(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x4c64eb),_0x5c1ec0(_0x7889e3['data']['response']);break;default:clearTimeout(_0x2e0e0e),clearTimeout(_0x4c64eb),_0x4b6af3(new Error('invalid_response'));break;}}},this['handlers']['add'](_0xd3156e),_0x2ee2a5['port1']['addEventListener']('message',_0xd3156e['onMessage']),this['target']['postMessage']({'eventType':_0x3a99e2,'eventId':_0x70d448,'data':_0x25c0fb},[_0x2ee2a5['port2']]);})['finally'](()=>{_0xd3156e&&this['removeMessageHandler'](_0xd3156e);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x19cd4a){Z()['location']['href']=_0x19cd4a;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x4e525a;return((_0x4e525a=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x4e525a['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x1428e9){this['request']=_0x1428e9;}['toPromise'](){return new Promise((_0x3982c6,_0x172bf2)=>{this['request']['addEventListener']('success',()=>{_0x3982c6(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x172bf2(this['request']['error']);});});}}function Zn(_0xc482e8,_0x570dba){return _0xc482e8['transaction']([Mn],_0x570dba?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x22bfb8=indexedDB['deleteDatabase'](Ka);return new nn(_0x22bfb8)['toPromise']();}function Qa(){const _0x4a86fd=indexedDB['open'](Ka,pp);return new Promise((_0x1597e2,_0x93ba60)=>{_0x4a86fd['addEventListener']('error',()=>{_0x93ba60(_0x4a86fd['error']);}),_0x4a86fd['addEventListener']('upgradeneeded',()=>{const _0x448ce4=_0x4a86fd['result'];try{_0x448ce4['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0xe15012){_0x93ba60(_0xe15012);}}),_0x4a86fd['addEventListener']('success',async()=>{const _0x62224=_0x4a86fd['result'];_0x62224['objectStoreNames']['contains'](Mn)?_0x1597e2(_0x62224):(_0x62224['close'](),await _p(),_0x1597e2(await Qa()));});});}async function Or(_0x400b35,_0x51636c,_0x22aa20){const _0x4d0224=Zn(_0x400b35,!0x0)['put']({[Ya]:_0x51636c,'value':_0x22aa20});return new nn(_0x4d0224)['toPromise']();}async function gp(_0x18038f,_0x1d449c){const _0x47c4a2=Zn(_0x18038f,!0x1)['get'](_0x1d449c),_0x2b1750=await new nn(_0x47c4a2)['toPromise']();return _0x2b1750===void 0x0?null:_0x2b1750['value'];}function Dr(_0x45df7e,_0x3cef9a){const _0x32678f=Zn(_0x45df7e,!0x0)['delete'](_0x3cef9a);return new nn(_0x32678f)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x3787d1){let _0x24c25d=0x0;for(;;)try{const _0x42abd3=await this['_openDb']();return await _0x3787d1(_0x42abd3);}catch(_0xd2f1fd){if(_0x24c25d++>yp)throw _0xd2f1fd;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x60ec51,_0x251349)=>({'keyProcessed':(await this['_poll']())['includes'](_0x251349['key'])})),this['receiver']['_subscribe']('ping',async(_0x5c0c05,_0x2dfb28)=>['keyChanged']);}async['initializeSender'](){var _0xeaf880,_0x3fa255;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x4107b2=await this['sender']['_send']('ping',{},0x320);_0x4107b2&&(_0xeaf880=_0x4107b2[0x0])!=null&&_0xeaf880['fulfilled']&&(_0x3fa255=_0x4107b2[0x0])!=null&&_0x3fa255['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x2d1e5b){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x2d1e5b},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0xd72398=>{await Or(_0xd72398,Dn,'1'),await Dr(_0xd72398,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x20a3a5){this['pendingWrites']++;try{await _0x20a3a5();}finally{this['pendingWrites']--;}}async['_set'](_0x2356b2,_0x1173ec){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x1444d8=>Or(_0x1444d8,_0x2356b2,_0x1173ec)),this['localCache'][_0x2356b2]=_0x1173ec,this['notifyServiceWorker'](_0x2356b2)));}async['_get'](_0x1cb36c){const _0x3630f9=await this['_withRetries'](_0x2aff1c=>gp(_0x2aff1c,_0x1cb36c));return this['localCache'][_0x1cb36c]=_0x3630f9,_0x3630f9;}async['_remove'](_0x3f8b7e){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x26eca6=>Dr(_0x26eca6,_0x3f8b7e)),delete this['localCache'][_0x3f8b7e],this['notifyServiceWorker'](_0x3f8b7e)));}async['_poll'](){const _0x1f99e9=await this['_withRetries'](_0x6da665=>{const _0x737f5=Zn(_0x6da665,!0x1)['getAll']();return new nn(_0x737f5)['toPromise']();});if(!_0x1f99e9)return[];if(this['pendingWrites']!==0x0)return[];const _0x2f9193=[],_0x171bc0=new Set();if(_0x1f99e9['length']!==0x0){for(const {fbase_key:_0x55f5f9,value:_0x51c2eb}of _0x1f99e9)_0x171bc0['add'](_0x55f5f9),JSON['stringify'](this['localCache'][_0x55f5f9])!==JSON['stringify'](_0x51c2eb)&&(this['notifyListeners'](_0x55f5f9,_0x51c2eb),_0x2f9193['push'](_0x55f5f9));}for(const _0x40d633 of Object['keys'](this['localCache']))this['localCache'][_0x40d633]&&!_0x171bc0['has'](_0x40d633)&&(this['notifyListeners'](_0x40d633,null),_0x2f9193['push'](_0x40d633));return _0x2f9193;}['notifyListeners'](_0x5b3546,_0x13da1e){this['localCache'][_0x5b3546]=_0x13da1e;const _0x1b1cd2=this['listeners'][_0x5b3546];if(_0x1b1cd2){for(const _0x3c6dc6 of Array['from'](_0x1b1cd2))_0x3c6dc6(_0x13da1e);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x18d6d3,_0x2f0c52){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x18d6d3]||(this['listeners'][_0x18d6d3]=new Set(),this['_get'](_0x18d6d3)),this['listeners'][_0x18d6d3]['add'](_0x2f0c52);}['_removeListener'](_0x457b54,_0x5715d9){this['listeners'][_0x457b54]&&(this['listeners'][_0x457b54]['delete'](_0x5715d9),this['listeners'][_0x457b54]['size']===0x0&&delete this['listeners'][_0x457b54]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x5a4a34,_0x4688fd){return _0x4688fd?ie(_0x4688fd):(m(_0x5a4a34['_popupRedirectResolver'],_0x5a4a34,'argument-error'),_0x5a4a34['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0xa7ded8){super('custom','custom'),this['params']=_0xa7ded8;}['_getIdTokenResponse'](_0x1a85a7){return nt(_0x1a85a7,this['_buildIdpRequest']());}['_linkToIdToken'](_0x1a2853,_0x2c1cee){return nt(_0x1a2853,this['_buildIdpRequest'](_0x2c1cee));}['_getReauthenticationResolver'](_0x26ce09){return nt(_0x26ce09,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x1841e9){const _0x4fbc53={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x1841e9&&(_0x4fbc53['idToken']=_0x1841e9),_0x4fbc53;}}function Ip(_0x43e992){return Va(_0x43e992['auth'],new ks(_0x43e992),_0x43e992['bypassAuthState']);}function wp(_0x50f3d9){const {auth:_0xd3b56b,user:_0x215512}=_0x50f3d9;return m(_0x215512,_0xd3b56b,'internal-error'),tp(_0x215512,new ks(_0x50f3d9),_0x50f3d9['bypassAuthState']);}async function Cp(_0x2cccdc){const {auth:_0x1828d7,user:_0x5c065d}=_0x2cccdc;return m(_0x5c065d,_0x1828d7,'internal-error'),ep(_0x5c065d,new ks(_0x2cccdc),_0x2cccdc['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x2b8e97,_0x3da85e,_0x365bf5,_0x4eb6e6,_0xa800a4=!0x1){this['auth']=_0x2b8e97,this['resolver']=_0x365bf5,this['user']=_0x4eb6e6,this['bypassAuthState']=_0xa800a4,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x3da85e)?_0x3da85e:[_0x3da85e];}['execute'](){return new Promise(async(_0x38414c,_0x5c745c)=>{this['pendingPromise']={'resolve':_0x38414c,'reject':_0x5c745c};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x6066d3){this['reject'](_0x6066d3);}});}async['onAuthEvent'](_0x2f1ac0){const {urlResponse:_0x33ddbc,sessionId:_0x29606e,postBody:_0x4fad51,tenantId:_0x1405a2,error:_0x4b37aa,type:_0x35ab55}=_0x2f1ac0;if(_0x4b37aa){this['reject'](_0x4b37aa);return;}const _0x260c95={'auth':this['auth'],'requestUri':_0x33ddbc,'sessionId':_0x29606e,'tenantId':_0x1405a2||void 0x0,'postBody':_0x4fad51||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x35ab55)(_0x260c95));}catch(_0x4cdad0){this['reject'](_0x4cdad0);}}['onError'](_0x291697){this['reject'](_0x291697);}['getIdpTask'](_0x1b0b99){switch(_0x1b0b99){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x3d47f5){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x3d47f5),this['unregisterAndCleanUp']();}['reject'](_0x1738e9){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x1738e9),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x51255c,_0x2319df,_0x4ed7e3,_0x500baf,_0x223d2d){super(_0x51255c,_0x2319df,_0x500baf,_0x223d2d),this['provider']=_0x4ed7e3,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x1f9c9c=await this['execute']();return m(_0x1f9c9c,this['auth'],'internal-error'),_0x1f9c9c;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x268986=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x268986),this['authWindow']['associatedEvent']=_0x268986,this['resolver']['_originValidation'](this['auth'])['catch'](_0x342100=>{this['reject'](_0x342100);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x2cc055=>{_0x2cc055||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x3a4e44;return((_0x3a4e44=this['authWindow'])==null?void 0x0:_0x3a4e44['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x4aa62f=()=>{var _0x5b6953,_0x1fbced;if((_0x1fbced=(_0x5b6953=this['authWindow'])==null?void 0x0:_0x5b6953['window'])!=null&&_0x1fbced['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x4aa62f,Tp['get']());};_0x4aa62f();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x548680,_0x1000c5,_0x45cefd=!0x1){super(_0x548680,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x1000c5,void 0x0,_0x45cefd),this['eventId']=null;}async['execute'](){let _0x4f7951=hn['get'](this['auth']['_key']());if(!_0x4f7951){try{const _0x13eb92=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x4f7951=()=>Promise['resolve'](_0x13eb92);}catch(_0xa0adb3){_0x4f7951=()=>Promise['reject'](_0xa0adb3);}hn['set'](this['auth']['_key'](),_0x4f7951);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x4f7951();}async['onAuthEvent'](_0x22f496){if(_0x22f496['type']==='signInViaRedirect')return super['onAuthEvent'](_0x22f496);if(_0x22f496['type']==='unknown'){this['resolve'](null);return;}if(_0x22f496['eventId']){const _0x1d9ed2=await this['auth']['_redirectUserForId'](_0x22f496['eventId']);if(_0x1d9ed2)return this['user']=_0x1d9ed2,super['onAuthEvent'](_0x22f496);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x543e4f,_0xb3f013){const _0x5024ca=Pp(_0xb3f013),_0x275114=kp(_0x543e4f);if(!await _0x275114['_isAvailable']())return!0x1;const _0x16b600=await _0x275114['_get'](_0x5024ca)==='true';return await _0x275114['_remove'](_0x5024ca),_0x16b600;}function Ap(_0x20eb3d,_0x31ac4c){hn['set'](_0x20eb3d['_key'](),_0x31ac4c);}function kp(_0x45c864){return ie(_0x45c864['_redirectPersistence']);}function Pp(_0x5042ea){return ln(Sp,_0x5042ea['config']['apiKey'],_0x5042ea['name']);}async function Np(_0xf2b811,_0xa5413f,_0x152a6=!0x1){if($(_0xf2b811['app']))return Promise['reject'](re(_0xf2b811));const _0x3d541d=Ke(_0xf2b811),_0xc5957c=Ep(_0x3d541d,_0xa5413f),_0x343465=await new bp(_0x3d541d,_0xc5957c,_0x152a6)['execute']();return _0x343465&&!_0x152a6&&(delete _0x343465['user']['_redirectEventId'],await _0x3d541d['_persistUserIfCurrent'](_0x343465['user']),await _0x3d541d['_setRedirectUser'](null,_0xa5413f)),_0x343465;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x32b48e){this['auth']=_0x32b48e,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0xc1492f){this['consumers']['add'](_0xc1492f),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0xc1492f)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0xc1492f),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x4a8850){this['consumers']['delete'](_0x4a8850);}['onEvent'](_0x2f269b){if(this['hasEventBeenHandled'](_0x2f269b))return!0x1;let _0x4df4a4=!0x1;return this['consumers']['forEach'](_0x596cf4=>{this['isEventForConsumer'](_0x2f269b,_0x596cf4)&&(_0x4df4a4=!0x0,this['sendToConsumer'](_0x2f269b,_0x596cf4),this['saveEventToCache'](_0x2f269b));}),this['hasHandledPotentialRedirect']||!Mp(_0x2f269b)||(this['hasHandledPotentialRedirect']=!0x0,_0x4df4a4||(this['queuedRedirectEvent']=_0x2f269b,_0x4df4a4=!0x0)),_0x4df4a4;}['sendToConsumer'](_0x287648,_0x4021fd){var _0xc8fcbb;if(_0x287648['error']&&!Za(_0x287648)){const _0x33a31c=((_0xc8fcbb=_0x287648['error']['code'])==null?void 0x0:_0xc8fcbb['split']('auth/')[0x1])||'internal-error';_0x4021fd['onError'](X(this['auth'],_0x33a31c));}else _0x4021fd['onAuthEvent'](_0x287648);}['isEventForConsumer'](_0x20d82b,_0x5e94ff){const _0xb80eb9=_0x5e94ff['eventId']===null||!!_0x20d82b['eventId']&&_0x20d82b['eventId']===_0x5e94ff['eventId'];return _0x5e94ff['filter']['includes'](_0x20d82b['type'])&&_0xb80eb9;}['hasEventBeenHandled'](_0x26cbf5){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x26cbf5));}['saveEventToCache'](_0x18a650){this['cachedEventUids']['add'](Mr(_0x18a650)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x4e10b2){return[_0x4e10b2['type'],_0x4e10b2['eventId'],_0x4e10b2['sessionId'],_0x4e10b2['tenantId']]['filter'](_0x136bab=>_0x136bab)['join']('-');}function Za({type:_0x221343,error:_0x1eed44}){return _0x221343==='unknown'&&(_0x1eed44==null?void 0x0:_0x1eed44['code'])==='auth/no-auth-event';}function Mp(_0x3b3a22){switch(_0x3b3a22['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x3b3a22);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x1b93cf,_0x58b8b6={}){return Pe(_0x1b93cf,'GET','/v1/projects',_0x58b8b6);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x386274){if(_0x386274['config']['emulator'])return;const {authorizedDomains:_0x3266db}=await Lp(_0x386274);for(const _0x44f711 of _0x3266db)try{if(Wp(_0x44f711))return;}catch{}Y(_0x386274,'unauthorized-domain');}function Wp(_0x5ade3b){const _0x39ae2e=Mi(),{protocol:_0x367759,hostname:_0x46ef13}=new URL(_0x39ae2e);if(_0x5ade3b['startsWith']('chrome-extension://')){const _0x525e91=new URL(_0x5ade3b);return _0x525e91['hostname']===''&&_0x46ef13===''?_0x367759==='chrome-extension:'&&_0x5ade3b['replace']('chrome-extension://','')===_0x39ae2e['replace']('chrome-extension://',''):_0x367759==='chrome-extension:'&&_0x525e91['hostname']===_0x46ef13;}if(!Fp['test'](_0x367759))return!0x1;if(xp['test'](_0x5ade3b))return _0x46ef13===_0x5ade3b;const _0x59f695=_0x5ade3b['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x59f695+'|'+_0x59f695+')$','i')['test'](_0x46ef13);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x3ba756=Z()['___jsl'];if(_0x3ba756!=null&&_0x3ba756['H']){for(const _0x289604 of Object['keys'](_0x3ba756['H']))if(_0x3ba756['H'][_0x289604]['r']=_0x3ba756['H'][_0x289604]['r']||[],_0x3ba756['H'][_0x289604]['L']=_0x3ba756['H'][_0x289604]['L']||[],_0x3ba756['H'][_0x289604]['r']=[..._0x3ba756['H'][_0x289604]['L']],_0x3ba756['CP']){for(let _0x55bfb7=0x0;_0x55bfb7<_0x3ba756['CP']['length'];_0x55bfb7++)_0x3ba756['CP'][_0x55bfb7]=null;}}}function Vp(_0x1f7cea){return new Promise((_0xb58fcb,_0x6d0942)=>{var _0x44dadb,_0x493e37,_0x1c3c72;function _0x3a7d80(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0xb58fcb(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x6d0942(X(_0x1f7cea,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x493e37=(_0x44dadb=Z()['gapi'])==null?void 0x0:_0x44dadb['iframes'])!=null&&_0x493e37['Iframe'])_0xb58fcb(gapi['iframes']['getContext']());else{if((_0x1c3c72=Z()['gapi'])!=null&&_0x1c3c72['load'])_0x3a7d80();else{const _0x4b0aa9=Ff('iframefcb');return Z()[_0x4b0aa9]=()=>{gapi['load']?_0x3a7d80():_0x6d0942(X(_0x1f7cea,'network-request-failed'));},xa(xf()+'?onload='+_0x4b0aa9)['catch'](_0x47c171=>_0x6d0942(_0x47c171));}}})['catch'](_0x5e06a9=>{throw un=null,_0x5e06a9;});}let un=null;function Hp(_0x2076e4){return un=un||Vp(_0x2076e4),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x42ebd1){const _0x429a10=_0x42ebd1['config'];m(_0x429a10['authDomain'],_0x42ebd1,'auth-domain-config-required');const _0x21061a=_0x429a10['emulator']?Cs(_0x429a10,qp):'https://'+_0x42ebd1['config']['authDomain']+'/'+Gp,_0x50b72b={'apiKey':_0x429a10['apiKey'],'appName':_0x42ebd1['name'],'v':dt},_0x450439=jp['get'](_0x42ebd1['config']['apiHost']);_0x450439&&(_0x50b72b['eid']=_0x450439);const _0x2dd55e=_0x42ebd1['_getFrameworks']();return _0x2dd55e['length']&&(_0x50b72b['fw']=_0x2dd55e['join'](',')),_0x21061a+'?'+ut(_0x50b72b)['slice'](0x1);}async function Yp(_0x3fa544){const _0x38ded1=await Hp(_0x3fa544),_0x1844a3=Z()['gapi'];return m(_0x1844a3,_0x3fa544,'internal-error'),_0x38ded1['open']({'where':document['body'],'url':Kp(_0x3fa544),'messageHandlersFilter':_0x1844a3['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0xffd7b0=>new Promise(async(_0x33e89e,_0x86f87a)=>{await _0xffd7b0['restyle']({'setHideOnLeave':!0x1});const _0x5b8689=X(_0x3fa544,'network-request-failed'),_0x54e523=Z()['setTimeout'](()=>{_0x86f87a(_0x5b8689);},$p['get']());function _0x32fe98(){Z()['clearTimeout'](_0x54e523),_0x33e89e(_0xffd7b0);}_0xffd7b0['ping'](_0x32fe98)['then'](_0x32fe98,()=>{_0x86f87a(_0x5b8689);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x46ceba){this['window']=_0x46ceba,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0xc8d88a,_0x3061a2,_0x346f4b,_0x5381cc=Jp,_0x2789a2=Xp){const _0x384f4c=Math['max']((window['screen']['availHeight']-_0x2789a2)/0x2,0x0)['toString'](),_0x12cc31=Math['max']((window['screen']['availWidth']-_0x5381cc)/0x2,0x0)['toString']();let _0x538001='';const _0x6cc5bb={...Qp,'width':_0x5381cc['toString'](),'height':_0x2789a2['toString'](),'top':_0x384f4c,'left':_0x12cc31},_0x1dd037=W()['toLowerCase']();_0x346f4b&&(_0x538001=ka(_0x1dd037)?Zp:_0x346f4b),Ra(_0x1dd037)&&(_0x3061a2=_0x3061a2||e_,_0x6cc5bb['scrollbars']='yes');const _0x2134a1=Object['entries'](_0x6cc5bb)['reduce']((_0xd99d7c,[_0x341ea1,_0x420b44])=>''+_0xd99d7c+_0x341ea1+'='+_0x420b44+',','');if(Rf(_0x1dd037)&&_0x538001!=='_self')return n_(_0x3061a2||'',_0x538001),new xr(null);const _0x379449=window['open'](_0x3061a2||'',_0x538001,_0x2134a1);m(_0x379449,_0xc8d88a,'popup-blocked');try{_0x379449['focus']();}catch{}return new xr(_0x379449);}function n_(_0x57d7d0,_0x28a9f8){const _0x3fb204=document['createElement']('a');_0x3fb204['href']=_0x57d7d0,_0x3fb204['target']=_0x28a9f8;const _0x57bac3=document['createEvent']('MouseEvent');_0x57bac3['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x3fb204['dispatchEvent'](_0x57bac3);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x37536c,_0x559260,_0x375a7b,_0x546825,_0x28094c,_0x156e79){m(_0x37536c['config']['authDomain'],_0x37536c,'auth-domain-config-required'),m(_0x37536c['config']['apiKey'],_0x37536c,'invalid-api-key');const _0x4e88cf={'apiKey':_0x37536c['config']['apiKey'],'appName':_0x37536c['name'],'authType':_0x375a7b,'redirectUrl':_0x546825,'v':dt,'eventId':_0x28094c};if(_0x559260 instanceof Wa){_0x559260['setDefaultLanguage'](_0x37536c['languageCode']),_0x4e88cf['providerId']=_0x559260['providerId']||'',pn(_0x559260['getCustomParameters']())||(_0x4e88cf['customParameters']=JSON['stringify'](_0x559260['getCustomParameters']()));for(const [_0x43a433,_0x299110]of Object['entries']({}))_0x4e88cf[_0x43a433]=_0x299110;}if(_0x559260 instanceof tn){const _0x55bf70=_0x559260['getScopes']()['filter'](_0x181284=>_0x181284!=='');_0x55bf70['length']>0x0&&(_0x4e88cf['scopes']=_0x55bf70['join'](','));}_0x37536c['tenantId']&&(_0x4e88cf['tid']=_0x37536c['tenantId']);const _0x3351de=_0x4e88cf;for(const _0x4378f8 of Object['keys'](_0x3351de))_0x3351de[_0x4378f8]===void 0x0&&delete _0x3351de[_0x4378f8];const _0x5b95aa=await _0x37536c['_getAppCheckToken'](),_0xbe97a5=_0x5b95aa?'#'+r_+'='+encodeURIComponent(_0x5b95aa):'';return o_(_0x37536c)+'?'+ut(_0x3351de)['slice'](0x1)+_0xbe97a5;}function o_({config:_0x42ea1a}){return _0x42ea1a['emulator']?Cs(_0x42ea1a,s_):'https://'+_0x42ea1a['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x7d09aa,_0x2e5670,_0x2fdf9a,_0x222148){var _0x18c709;ce((_0x18c709=this['eventManagers'][_0x7d09aa['_key']()])==null?void 0x0:_0x18c709['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x3fd819=await Fr(_0x7d09aa,_0x2e5670,_0x2fdf9a,Mi(),_0x222148);return t_(_0x7d09aa,_0x3fd819,As());}async['_openRedirect'](_0x5933df,_0x1cdd9a,_0xcfaa96,_0x78fd92){await this['_originValidation'](_0x5933df);const _0xc7aa17=await Fr(_0x5933df,_0x1cdd9a,_0xcfaa96,Mi(),_0x78fd92);return hp(_0xc7aa17),new Promise(()=>{});}['_initialize'](_0x46d3d0){const _0x559c12=_0x46d3d0['_key']();if(this['eventManagers'][_0x559c12]){const {manager:_0x8d40ea,promise:_0x3b82d1}=this['eventManagers'][_0x559c12];return _0x8d40ea?Promise['resolve'](_0x8d40ea):(ce(_0x3b82d1,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x3b82d1);}const _0xebd211=this['initAndGetManager'](_0x46d3d0);return this['eventManagers'][_0x559c12]={'promise':_0xebd211},_0xebd211['catch'](()=>{delete this['eventManagers'][_0x559c12];}),_0xebd211;}async['initAndGetManager'](_0xc95c28){const _0x2c9352=await Yp(_0xc95c28),_0x46602f=new Dp(_0xc95c28);return _0x2c9352['register']('authEvent',_0x593edd=>(m(_0x593edd==null?void 0x0:_0x593edd['authEvent'],_0xc95c28,'invalid-auth-event'),{'status':_0x46602f['onEvent'](_0x593edd['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0xc95c28['_key']()]={'manager':_0x46602f},this['iframes'][_0xc95c28['_key']()]=_0x2c9352,_0x46602f;}['_isIframeWebStorageSupported'](_0x42b806,_0x1343bf){this['iframes'][_0x42b806['_key']()]['send'](pi,{'type':pi},_0x173f38=>{var _0x4f94c9;const _0x599bf1=(_0x4f94c9=_0x173f38==null?void 0x0:_0x173f38[0x0])==null?void 0x0:_0x4f94c9[pi];_0x599bf1!==void 0x0&&_0x1343bf(!!_0x599bf1),Y(_0x42b806,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0xd83bdd){const _0x33d8e9=_0xd83bdd['_key']();return this['originValidationPromises'][_0x33d8e9]||(this['originValidationPromises'][_0x33d8e9]=Up(_0xd83bdd)),this['originValidationPromises'][_0x33d8e9];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x3f42ce){this['auth']=_0x3f42ce,this['internalListeners']=new Map();}['getUid'](){var _0x16014d;return this['assertAuthConfigured'](),((_0x16014d=this['auth']['currentUser'])==null?void 0x0:_0x16014d['uid'])||null;}async['getToken'](_0x279374){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x279374)}:null;}['addAuthTokenListener'](_0x10b58e){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x10b58e))return;const _0x39da61=this['auth']['onIdTokenChanged'](_0x21d5b3=>{_0x10b58e((_0x21d5b3==null?void 0x0:_0x21d5b3['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x10b58e,_0x39da61),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x27e238){this['assertAuthConfigured']();const _0x3a74b5=this['internalListeners']['get'](_0x27e238);_0x3a74b5&&(this['internalListeners']['delete'](_0x27e238),_0x3a74b5(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x5c6570){switch(_0x5c6570){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0xb343f6){st(new Fe('auth',(_0x4cfe68,{options:_0x390fd1})=>{const _0x378dda=_0x4cfe68['getProvider']('app')['getImmediate'](),_0x57a235=_0x4cfe68['getProvider']('heartbeat'),_0x5bb851=_0x4cfe68['getProvider']('app-check-internal'),{apiKey:_0x13ba59,authDomain:_0x225694}=_0x378dda['options'];m(_0x13ba59&&!_0x13ba59['includes'](':'),'invalid-api-key',{'appName':_0x378dda['name']});const _0x41d651={'apiKey':_0x13ba59,'authDomain':_0x225694,'clientPlatform':_0xb343f6,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0xb343f6)},_0x4083be=new Df(_0x378dda,_0x57a235,_0x5bb851,_0x41d651);return Hf(_0x4083be,_0x390fd1),_0x4083be;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x3073db,_0x29e226,_0x3cae4a)=>{_0x3073db['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x3abf42=>{const _0x5a9b8c=Ke(_0x3abf42['getProvider']('auth')['getImmediate']());return(_0x24a388=>new l_(_0x24a388))(_0x5a9b8c);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0xb343f6)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x4e4eba=>async _0xe02445=>{const _0x316cc1=_0xe02445&&await _0xe02445['getIdTokenResult'](),_0x31d39e=_0x316cc1&&(new Date()['getTime']()-Date['parse'](_0x316cc1['issuedAtTime']))/0x3e8;if(_0x31d39e&&_0x31d39e>f_)return;const _0x24faf7=_0x316cc1==null?void 0x0:_0x316cc1['token'];Br!==_0x24faf7&&(Br=_0x24faf7,await fetch(_0x4e4eba,{'method':_0x24faf7?'POST':'DELETE','headers':_0x24faf7?{'Authorization':'Bearer\x20'+_0x24faf7}:{}}));};function B_(_0x40048a=Zr()){const _0x174c40=Hi(_0x40048a,'auth');if(_0x174c40['isInitialized']())return _0x174c40['getImmediate']();const _0x1ea2a3=Vf(_0x40048a,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x1f0f74=jr('authTokenSyncURL');if(_0x1f0f74&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x238323=new URL(_0x1f0f74,location['origin']);if(location['origin']===_0x238323['origin']){const _0x535634=p_(_0x238323['toString']());sp(_0x1ea2a3,_0x535634,()=>_0x535634(_0x1ea2a3['currentUser'])),ip(_0x1ea2a3,_0x48d629=>_0x535634(_0x48d629));}}const _0x1ad24b=qr('auth');return _0x1ad24b&&$f(_0x1ea2a3,'http://'+_0x1ad24b),_0x1ea2a3;}function __(){var _0x2bbb01;return((_0x2bbb01=document['getElementsByTagName']('head'))==null?void 0x0:_0x2bbb01[0x0])??document;}Mf({'loadJS'(_0x16d196){return new Promise((_0x2d4e54,_0x138f9b)=>{const _0x28c6b8=document['createElement']('script');_0x28c6b8['setAttribute']('src',_0x16d196),_0x28c6b8['onload']=_0x2d4e54,_0x28c6b8['onerror']=_0x366df8=>{const _0x230ffd=X('internal-error');_0x230ffd['customData']=_0x366df8,_0x138f9b(_0x230ffd);},_0x28c6b8['type']='text/javascript',_0x28c6b8['charset']='UTF-8',__()['appendChild'](_0x28c6b8);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,B_ as a,ap as b,x_ as c,g_ as d,m_ as e,Zr as f,P_ as g,Hd as h,Sl as i,D_ as j,Gd as k,w_ as l,b_ as m,A_ as n,v_ as o,E_ as p,k_ as q,y_ as r,F_ as s,Vt as t,I_ as u,N_ as v,U_ as w,O_ as x,M_ as y,T_ as z};