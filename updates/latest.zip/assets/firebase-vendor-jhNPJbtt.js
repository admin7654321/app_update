const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x5a72d9,_0x33c4d4){if(!_0x5a72d9)throw ht(_0x33c4d4);},ht=function(_0x31803c){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x31803c);},Hr=function(_0x473a65){const _0x4bfea2=[];let _0x5b2f61=0x0;for(let _0x57cd26=0x0;_0x57cd26<_0x473a65['length'];_0x57cd26++){let _0x26382c=_0x473a65['charCodeAt'](_0x57cd26);_0x26382c<0x80?_0x4bfea2[_0x5b2f61++]=_0x26382c:_0x26382c<0x800?(_0x4bfea2[_0x5b2f61++]=_0x26382c>>0x6|0xc0,_0x4bfea2[_0x5b2f61++]=_0x26382c&0x3f|0x80):(_0x26382c&0xfc00)===0xd800&&_0x57cd26+0x1<_0x473a65['length']&&(_0x473a65['charCodeAt'](_0x57cd26+0x1)&0xfc00)===0xdc00?(_0x26382c=0x10000+((_0x26382c&0x3ff)<<0xa)+(_0x473a65['charCodeAt'](++_0x57cd26)&0x3ff),_0x4bfea2[_0x5b2f61++]=_0x26382c>>0x12|0xf0,_0x4bfea2[_0x5b2f61++]=_0x26382c>>0xc&0x3f|0x80,_0x4bfea2[_0x5b2f61++]=_0x26382c>>0x6&0x3f|0x80,_0x4bfea2[_0x5b2f61++]=_0x26382c&0x3f|0x80):(_0x4bfea2[_0x5b2f61++]=_0x26382c>>0xc|0xe0,_0x4bfea2[_0x5b2f61++]=_0x26382c>>0x6&0x3f|0x80,_0x4bfea2[_0x5b2f61++]=_0x26382c&0x3f|0x80);}return _0x4bfea2;},nc=function(_0x116997){const _0x4e27a2=[];let _0x55996d=0x0,_0x11e0d3=0x0;for(;_0x55996d<_0x116997['length'];){const _0x2bc08c=_0x116997[_0x55996d++];if(_0x2bc08c<0x80)_0x4e27a2[_0x11e0d3++]=String['fromCharCode'](_0x2bc08c);else{if(_0x2bc08c>0xbf&&_0x2bc08c<0xe0){const _0x3ac847=_0x116997[_0x55996d++];_0x4e27a2[_0x11e0d3++]=String['fromCharCode']((_0x2bc08c&0x1f)<<0x6|_0x3ac847&0x3f);}else{if(_0x2bc08c>0xef&&_0x2bc08c<0x16d){const _0x54f34c=_0x116997[_0x55996d++],_0x124f26=_0x116997[_0x55996d++],_0x4502d0=_0x116997[_0x55996d++],_0xa239fc=((_0x2bc08c&0x7)<<0x12|(_0x54f34c&0x3f)<<0xc|(_0x124f26&0x3f)<<0x6|_0x4502d0&0x3f)-0x10000;_0x4e27a2[_0x11e0d3++]=String['fromCharCode'](0xd800+(_0xa239fc>>0xa)),_0x4e27a2[_0x11e0d3++]=String['fromCharCode'](0xdc00+(_0xa239fc&0x3ff));}else{const _0x34a8ce=_0x116997[_0x55996d++],_0xf1fa73=_0x116997[_0x55996d++];_0x4e27a2[_0x11e0d3++]=String['fromCharCode']((_0x2bc08c&0xf)<<0xc|(_0x34a8ce&0x3f)<<0x6|_0xf1fa73&0x3f);}}}}return _0x4e27a2['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x35031a,_0x204d22){if(!Array['isArray'](_0x35031a))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x218a6f=_0x204d22?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x4326c6=[];for(let _0x10eea9=0x0;_0x10eea9<_0x35031a['length'];_0x10eea9+=0x3){const _0x49aa29=_0x35031a[_0x10eea9],_0xb80a01=_0x10eea9+0x1<_0x35031a['length'],_0x4842ca=_0xb80a01?_0x35031a[_0x10eea9+0x1]:0x0,_0x3b35b6=_0x10eea9+0x2<_0x35031a['length'],_0x14aad5=_0x3b35b6?_0x35031a[_0x10eea9+0x2]:0x0,_0xb3f8be=_0x49aa29>>0x2,_0x52f51c=(_0x49aa29&0x3)<<0x4|_0x4842ca>>0x4;let _0x20d19c=(_0x4842ca&0xf)<<0x2|_0x14aad5>>0x6,_0x2c27c1=_0x14aad5&0x3f;_0x3b35b6||(_0x2c27c1=0x40,_0xb80a01||(_0x20d19c=0x40)),_0x4326c6['push'](_0x218a6f[_0xb3f8be],_0x218a6f[_0x52f51c],_0x218a6f[_0x20d19c],_0x218a6f[_0x2c27c1]);}return _0x4326c6['join']('');},'encodeString'(_0x1c4c9a,_0x49275f){return this['HAS_NATIVE_SUPPORT']&&!_0x49275f?btoa(_0x1c4c9a):this['encodeByteArray'](Hr(_0x1c4c9a),_0x49275f);},'decodeString'(_0x3c329a,_0x32a975){return this['HAS_NATIVE_SUPPORT']&&!_0x32a975?atob(_0x3c329a):nc(this['decodeStringToByteArray'](_0x3c329a,_0x32a975));},'decodeStringToByteArray'(_0x589dd3,_0x2d894b){this['init_']();const _0x106331=_0x2d894b?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0xa388d2=[];for(let _0x3790f4=0x0;_0x3790f4<_0x589dd3['length'];){const _0x58b4fe=_0x106331[_0x589dd3['charAt'](_0x3790f4++)],_0x46fdf3=_0x3790f4<_0x589dd3['length']?_0x106331[_0x589dd3['charAt'](_0x3790f4)]:0x0;++_0x3790f4;const _0x5076fd=_0x3790f4<_0x589dd3['length']?_0x106331[_0x589dd3['charAt'](_0x3790f4)]:0x40;++_0x3790f4;const _0x91b1d9=_0x3790f4<_0x589dd3['length']?_0x106331[_0x589dd3['charAt'](_0x3790f4)]:0x40;if(++_0x3790f4,_0x58b4fe==null||_0x46fdf3==null||_0x5076fd==null||_0x91b1d9==null)throw new ic();const _0x120894=_0x58b4fe<<0x2|_0x46fdf3>>0x4;if(_0xa388d2['push'](_0x120894),_0x5076fd!==0x40){const _0x336c2d=_0x46fdf3<<0x4&0xf0|_0x5076fd>>0x2;if(_0xa388d2['push'](_0x336c2d),_0x91b1d9!==0x40){const _0x24d504=_0x5076fd<<0x6&0xc0|_0x91b1d9;_0xa388d2['push'](_0x24d504);}}}return _0xa388d2;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0xf69fb6=0x0;_0xf69fb6<this['ENCODED_VALS']['length'];_0xf69fb6++)this['byteToCharMap_'][_0xf69fb6]=this['ENCODED_VALS']['charAt'](_0xf69fb6),this['charToByteMap_'][this['byteToCharMap_'][_0xf69fb6]]=_0xf69fb6,this['byteToCharMapWebSafe_'][_0xf69fb6]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0xf69fb6),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0xf69fb6]]=_0xf69fb6,_0xf69fb6>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0xf69fb6)]=_0xf69fb6,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0xf69fb6)]=_0xf69fb6);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x50eab4){const _0x148a97=Hr(_0x50eab4);return Fi['encodeByteArray'](_0x148a97,!0x0);},dn=function(_0x4cc1bb){return $r(_0x4cc1bb)['replace'](/\./g,'');},fn=function(_0x46b061){try{return Fi['decodeString'](_0x46b061,!0x0);}catch(_0x4930ac){console['error']('base64Decode\x20failed:\x20',_0x4930ac);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x3f67fc){return Gr(void 0x0,_0x3f67fc);}function Gr(_0x506d0c,_0x2448ec){if(!(_0x2448ec instanceof Object))return _0x2448ec;switch(_0x2448ec['constructor']){case Date:const _0x293ea5=_0x2448ec;return new Date(_0x293ea5['getTime']());case Object:_0x506d0c===void 0x0&&(_0x506d0c={});break;case Array:_0x506d0c=[];break;default:return _0x2448ec;}for(const _0x323120 in _0x2448ec)!_0x2448ec['hasOwnProperty'](_0x323120)||!rc(_0x323120)||(_0x506d0c[_0x323120]=Gr(_0x506d0c[_0x323120],_0x2448ec[_0x323120]));return _0x506d0c;}function rc(_0x55a481){return _0x55a481!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x59eb6c=Ps['__FIREBASE_DEFAULTS__'];if(_0x59eb6c)return JSON['parse'](_0x59eb6c);},lc=()=>{if(typeof document>'u')return;let _0x507993;try{_0x507993=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x51435e=_0x507993&&fn(_0x507993[0x1]);return _0x51435e&&JSON['parse'](_0x51435e);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x17de91){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x17de91);return;}},qr=_0x3c5cc2=>{var _0x47ed6f,_0xc18725;return(_0xc18725=(_0x47ed6f=Ui())==null?void 0x0:_0x47ed6f['emulatorHosts'])==null?void 0x0:_0xc18725[_0x3c5cc2];},hc=_0xd57e92=>{const _0x3a50be=qr(_0xd57e92);if(!_0x3a50be)return;const _0x2a096f=_0x3a50be['lastIndexOf'](':');if(_0x2a096f<=0x0||_0x2a096f+0x1===_0x3a50be['length'])throw new Error('Invalid\x20host\x20'+_0x3a50be+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x64af12=parseInt(_0x3a50be['substring'](_0x2a096f+0x1),0xa);return _0x3a50be[0x0]==='['?[_0x3a50be['substring'](0x1,_0x2a096f-0x1),_0x64af12]:[_0x3a50be['substring'](0x0,_0x2a096f),_0x64af12];},zr=()=>{var _0x43c14c;return(_0x43c14c=Ui())==null?void 0x0:_0x43c14c['config'];},jr=_0x22e8a1=>{var _0x4f7057;return(_0x4f7057=Ui())==null?void 0x0:_0x4f7057['_'+_0x22e8a1];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x524216,_0x19f0ab)=>{this['resolve']=_0x524216,this['reject']=_0x19f0ab;});}['wrapCallback'](_0x461966){return(_0x19a5e7,_0xb7cdad)=>{_0x19a5e7?this['reject'](_0x19a5e7):this['resolve'](_0xb7cdad),typeof _0x461966=='function'&&(this['promise']['catch'](()=>{}),_0x461966['length']===0x1?_0x461966(_0x19a5e7):_0x461966(_0x19a5e7,_0xb7cdad));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x389f58,_0x5addd7){if(_0x389f58['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x147434={'alg':'none','type':'JWT'},_0x5e0b22=_0x5addd7||'demo-project',_0x1178ea=_0x389f58['iat']||0x0,_0x5b6aff=_0x389f58['sub']||_0x389f58['user_id'];if(!_0x5b6aff)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x116e8c={'iss':'https://securetoken.google.com/'+_0x5e0b22,'aud':_0x5e0b22,'iat':_0x1178ea,'exp':_0x1178ea+0xe10,'auth_time':_0x1178ea,'sub':_0x5b6aff,'user_id':_0x5b6aff,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x389f58};return[dn(JSON['stringify'](_0x147434)),dn(JSON['stringify'](_0x116e8c)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x1be8b2=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x1be8b2=='object'&&_0x1be8b2['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x501b52=W();return _0x501b52['indexOf']('MSIE\x20')>=0x0||_0x501b52['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x4a1b02,_0x3ed3a4)=>{try{let _0x2ad84f=!0x0;const _0x29b9f5='validate-browser-context-for-indexeddb-analytics-module',_0x2b5a64=self['indexedDB']['open'](_0x29b9f5);_0x2b5a64['onsuccess']=()=>{_0x2b5a64['result']['close'](),_0x2ad84f||self['indexedDB']['deleteDatabase'](_0x29b9f5),_0x4a1b02(!0x0);},_0x2b5a64['onupgradeneeded']=()=>{_0x2ad84f=!0x1;},_0x2b5a64['onerror']=()=>{var _0x2f1c79;_0x3ed3a4(((_0x2f1c79=_0x2b5a64['error'])==null?void 0x0:_0x2f1c79['message'])||'');};}catch(_0x233f77){_0x3ed3a4(_0x233f77);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x14672f,_0x9d0211,_0x191461){super(_0x9d0211),this['code']=_0x14672f,this['customData']=_0x191461,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x27c8f5,_0x303408,_0x1a48b8){this['service']=_0x27c8f5,this['serviceName']=_0x303408,this['errors']=_0x1a48b8;}['create'](_0x16b6d3,..._0x4d58b7){const _0x547f91=_0x4d58b7[0x0]||{},_0x426958=this['service']+'/'+_0x16b6d3,_0x19803d=this['errors'][_0x16b6d3],_0x584609=_0x19803d?vc(_0x19803d,_0x547f91):'Error',_0x783722=this['serviceName']+':\x20'+_0x584609+'\x20('+_0x426958+').';return new Re(_0x426958,_0x783722,_0x547f91);}}function vc(_0xa85192,_0x59a443){return _0xa85192['replace'](Ec,(_0x1b6a46,_0x3d4bc1)=>{const _0x3a49ad=_0x59a443[_0x3d4bc1];return _0x3a49ad!=null?String(_0x3a49ad):'<'+_0x3d4bc1+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x4280c6){return JSON['parse'](_0x4280c6);}function O(_0x3698cd){return JSON['stringify'](_0x3698cd);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x2d980a){let _0x3163d3={},_0x19c536={},_0x443723={},_0x1859bb='';try{const _0x1cb285=_0x2d980a['split']('.');_0x3163d3=Nt(fn(_0x1cb285[0x0])||''),_0x19c536=Nt(fn(_0x1cb285[0x1])||''),_0x1859bb=_0x1cb285[0x2],_0x443723=_0x19c536['d']||{},delete _0x19c536['d'];}catch{}return{'header':_0x3163d3,'claims':_0x19c536,'data':_0x443723,'signature':_0x1859bb};},Ic=function(_0x5f3260){const _0x187ca5=Yr(_0x5f3260),_0x46a027=_0x187ca5['claims'];return!!_0x46a027&&typeof _0x46a027=='object'&&_0x46a027['hasOwnProperty']('iat');},wc=function(_0xdb30ae){const _0xec0e9=Yr(_0xdb30ae)['claims'];return typeof _0xec0e9=='object'&&_0xec0e9['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x52192a,_0x324358){return Object['prototype']['hasOwnProperty']['call'](_0x52192a,_0x324358);}function Le(_0x2f719e,_0xdb409a){if(Object['prototype']['hasOwnProperty']['call'](_0x2f719e,_0xdb409a))return _0x2f719e[_0xdb409a];}function pn(_0x34ac86){for(const _0x5c512b in _0x34ac86)if(Object['prototype']['hasOwnProperty']['call'](_0x34ac86,_0x5c512b))return!0x1;return!0x0;}function _n(_0x3ce5ee,_0x393bfc,_0x3cc23d){const _0x5637a7={};for(const _0x4647d1 in _0x3ce5ee)Object['prototype']['hasOwnProperty']['call'](_0x3ce5ee,_0x4647d1)&&(_0x5637a7[_0x4647d1]=_0x393bfc['call'](_0x3cc23d,_0x3ce5ee[_0x4647d1],_0x4647d1,_0x3ce5ee));return _0x5637a7;}function xe(_0x1171bc,_0x580bd3){if(_0x1171bc===_0x580bd3)return!0x0;const _0x519c1a=Object['keys'](_0x1171bc),_0x952456=Object['keys'](_0x580bd3);for(const _0x3e1a60 of _0x519c1a){if(!_0x952456['includes'](_0x3e1a60))return!0x1;const _0x164f10=_0x1171bc[_0x3e1a60],_0x253963=_0x580bd3[_0x3e1a60];if(Ns(_0x164f10)&&Ns(_0x253963)){if(!xe(_0x164f10,_0x253963))return!0x1;}else{if(_0x164f10!==_0x253963)return!0x1;}}for(const _0x371180 of _0x952456)if(!_0x519c1a['includes'](_0x371180))return!0x1;return!0x0;}function Ns(_0x6116d5){return _0x6116d5!==null&&typeof _0x6116d5=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x395424){const _0x120098=[];for(const [_0x40343f,_0x4398c6]of Object['entries'](_0x395424))Array['isArray'](_0x4398c6)?_0x4398c6['forEach'](_0x4995dc=>{_0x120098['push'](encodeURIComponent(_0x40343f)+'='+encodeURIComponent(_0x4995dc));}):_0x120098['push'](encodeURIComponent(_0x40343f)+'='+encodeURIComponent(_0x4398c6));return _0x120098['length']?'&'+_0x120098['join']('&'):'';}function Ct(_0x1b752a){const _0x4ca203={};return _0x1b752a['replace'](/^\?/,'')['split']('&')['forEach'](_0x2b1e6d=>{if(_0x2b1e6d){const [_0x254d6f,_0x27a7ab]=_0x2b1e6d['split']('=');_0x4ca203[decodeURIComponent(_0x254d6f)]=decodeURIComponent(_0x27a7ab);}}),_0x4ca203;}function Tt(_0x1cf858){const _0xd4510e=_0x1cf858['indexOf']('?');if(!_0xd4510e)return'';const _0x2935b0=_0x1cf858['indexOf']('#',_0xd4510e);return _0x1cf858['substring'](_0xd4510e,_0x2935b0>0x0?_0x2935b0:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x547944=0x1;_0x547944<this['blockSize'];++_0x547944)this['pad_'][_0x547944]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x94772d,_0x37703d){_0x37703d||(_0x37703d=0x0);const _0xc7da52=this['W_'];if(typeof _0x94772d=='string'){for(let _0x3c1df5=0x0;_0x3c1df5<0x10;_0x3c1df5++)_0xc7da52[_0x3c1df5]=_0x94772d['charCodeAt'](_0x37703d)<<0x18|_0x94772d['charCodeAt'](_0x37703d+0x1)<<0x10|_0x94772d['charCodeAt'](_0x37703d+0x2)<<0x8|_0x94772d['charCodeAt'](_0x37703d+0x3),_0x37703d+=0x4;}else{for(let _0x4ce220=0x0;_0x4ce220<0x10;_0x4ce220++)_0xc7da52[_0x4ce220]=_0x94772d[_0x37703d]<<0x18|_0x94772d[_0x37703d+0x1]<<0x10|_0x94772d[_0x37703d+0x2]<<0x8|_0x94772d[_0x37703d+0x3],_0x37703d+=0x4;}for(let _0x1bc03b=0x10;_0x1bc03b<0x50;_0x1bc03b++){const _0x1fe7a1=_0xc7da52[_0x1bc03b-0x3]^_0xc7da52[_0x1bc03b-0x8]^_0xc7da52[_0x1bc03b-0xe]^_0xc7da52[_0x1bc03b-0x10];_0xc7da52[_0x1bc03b]=(_0x1fe7a1<<0x1|_0x1fe7a1>>>0x1f)&0xffffffff;}let _0x3b0348=this['chain_'][0x0],_0x1ebd73=this['chain_'][0x1],_0x2a294b=this['chain_'][0x2],_0x15894e=this['chain_'][0x3],_0x10763a=this['chain_'][0x4],_0x2f6ef8,_0x58e85d;for(let _0xfe932b=0x0;_0xfe932b<0x50;_0xfe932b++){_0xfe932b<0x28?_0xfe932b<0x14?(_0x2f6ef8=_0x15894e^_0x1ebd73&(_0x2a294b^_0x15894e),_0x58e85d=0x5a827999):(_0x2f6ef8=_0x1ebd73^_0x2a294b^_0x15894e,_0x58e85d=0x6ed9eba1):_0xfe932b<0x3c?(_0x2f6ef8=_0x1ebd73&_0x2a294b|_0x15894e&(_0x1ebd73|_0x2a294b),_0x58e85d=0x8f1bbcdc):(_0x2f6ef8=_0x1ebd73^_0x2a294b^_0x15894e,_0x58e85d=0xca62c1d6);const _0x5052cd=(_0x3b0348<<0x5|_0x3b0348>>>0x1b)+_0x2f6ef8+_0x10763a+_0x58e85d+_0xc7da52[_0xfe932b]&0xffffffff;_0x10763a=_0x15894e,_0x15894e=_0x2a294b,_0x2a294b=(_0x1ebd73<<0x1e|_0x1ebd73>>>0x2)&0xffffffff,_0x1ebd73=_0x3b0348,_0x3b0348=_0x5052cd;}this['chain_'][0x0]=this['chain_'][0x0]+_0x3b0348&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x1ebd73&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x2a294b&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x15894e&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x10763a&0xffffffff;}['update'](_0x1d5b6f,_0x5c7ce3){if(_0x1d5b6f==null)return;_0x5c7ce3===void 0x0&&(_0x5c7ce3=_0x1d5b6f['length']);const _0x5aa8a9=_0x5c7ce3-this['blockSize'];let _0x1ad6e6=0x0;const _0x5e2cfc=this['buf_'];let _0x14bfe9=this['inbuf_'];for(;_0x1ad6e6<_0x5c7ce3;){if(_0x14bfe9===0x0){for(;_0x1ad6e6<=_0x5aa8a9;)this['compress_'](_0x1d5b6f,_0x1ad6e6),_0x1ad6e6+=this['blockSize'];}if(typeof _0x1d5b6f=='string'){for(;_0x1ad6e6<_0x5c7ce3;)if(_0x5e2cfc[_0x14bfe9]=_0x1d5b6f['charCodeAt'](_0x1ad6e6),++_0x14bfe9,++_0x1ad6e6,_0x14bfe9===this['blockSize']){this['compress_'](_0x5e2cfc),_0x14bfe9=0x0;break;}}else{for(;_0x1ad6e6<_0x5c7ce3;)if(_0x5e2cfc[_0x14bfe9]=_0x1d5b6f[_0x1ad6e6],++_0x14bfe9,++_0x1ad6e6,_0x14bfe9===this['blockSize']){this['compress_'](_0x5e2cfc),_0x14bfe9=0x0;break;}}}this['inbuf_']=_0x14bfe9,this['total_']+=_0x5c7ce3;}['digest'](){const _0x1a4ca4=[];let _0x427452=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x215c9=this['blockSize']-0x1;_0x215c9>=0x38;_0x215c9--)this['buf_'][_0x215c9]=_0x427452&0xff,_0x427452/=0x100;this['compress_'](this['buf_']);let _0x4d52f6=0x0;for(let _0x58ce05=0x0;_0x58ce05<0x5;_0x58ce05++)for(let _0x2cfba2=0x18;_0x2cfba2>=0x0;_0x2cfba2-=0x8)_0x1a4ca4[_0x4d52f6]=this['chain_'][_0x58ce05]>>_0x2cfba2&0xff,++_0x4d52f6;return _0x1a4ca4;}}function Tc(_0xd5ce66,_0x1742cd){const _0x3b0549=new Sc(_0xd5ce66,_0x1742cd);return _0x3b0549['subscribe']['bind'](_0x3b0549);}class Sc{constructor(_0x114a50,_0x3bc68){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x3bc68,this['task']['then'](()=>{_0x114a50(this);})['catch'](_0x40d4f4=>{this['error'](_0x40d4f4);});}['next'](_0xd51dff){this['forEachObserver'](_0x5b579b=>{_0x5b579b['next'](_0xd51dff);});}['error'](_0x28ca15){this['forEachObserver'](_0x17c827=>{_0x17c827['error'](_0x28ca15);}),this['close'](_0x28ca15);}['complete'](){this['forEachObserver'](_0xd968ce=>{_0xd968ce['complete']();}),this['close']();}['subscribe'](_0x501679,_0x3b1856,_0x16d647){let _0x77d969;if(_0x501679===void 0x0&&_0x3b1856===void 0x0&&_0x16d647===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x501679,['next','error','complete'])?_0x77d969=_0x501679:_0x77d969={'next':_0x501679,'error':_0x3b1856,'complete':_0x16d647},_0x77d969['next']===void 0x0&&(_0x77d969['next']=ti),_0x77d969['error']===void 0x0&&(_0x77d969['error']=ti),_0x77d969['complete']===void 0x0&&(_0x77d969['complete']=ti);const _0x48244c=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x77d969['error'](this['finalError']):_0x77d969['complete']();}catch{}}),this['observers']['push'](_0x77d969),_0x48244c;}['unsubscribeOne'](_0x1543d4){this['observers']===void 0x0||this['observers'][_0x1543d4]===void 0x0||(delete this['observers'][_0x1543d4],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x209a5b){if(!this['finalized']){for(let _0x134d8d=0x0;_0x134d8d<this['observers']['length'];_0x134d8d++)this['sendOne'](_0x134d8d,_0x209a5b);}}['sendOne'](_0xfff47e,_0x7a69d8){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0xfff47e]!==void 0x0)try{_0x7a69d8(this['observers'][_0xfff47e]);}catch(_0x49d2e6){typeof console<'u'&&console['error']&&console['error'](_0x49d2e6);}});}['close'](_0x1e97cf){this['finalized']||(this['finalized']=!0x0,_0x1e97cf!==void 0x0&&(this['finalError']=_0x1e97cf),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x26e823,_0x584e53){if(typeof _0x26e823!='object'||_0x26e823===null)return!0x1;for(const _0xfdbed0 of _0x584e53)if(_0xfdbed0 in _0x26e823&&typeof _0x26e823[_0xfdbed0]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x29d09a,_0x10344f){return _0x29d09a+'\x20failed:\x20'+_0x10344f+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x55d3eb){const _0x3457ff=[];let _0x54428a=0x0;for(let _0x47963f=0x0;_0x47963f<_0x55d3eb['length'];_0x47963f++){let _0x203e68=_0x55d3eb['charCodeAt'](_0x47963f);if(_0x203e68>=0xd800&&_0x203e68<=0xdbff){const _0x55d041=_0x203e68-0xd800;_0x47963f++,f(_0x47963f<_0x55d3eb['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x5b42c7=_0x55d3eb['charCodeAt'](_0x47963f)-0xdc00;_0x203e68=0x10000+(_0x55d041<<0xa)+_0x5b42c7;}_0x203e68<0x80?_0x3457ff[_0x54428a++]=_0x203e68:_0x203e68<0x800?(_0x3457ff[_0x54428a++]=_0x203e68>>0x6|0xc0,_0x3457ff[_0x54428a++]=_0x203e68&0x3f|0x80):_0x203e68<0x10000?(_0x3457ff[_0x54428a++]=_0x203e68>>0xc|0xe0,_0x3457ff[_0x54428a++]=_0x203e68>>0x6&0x3f|0x80,_0x3457ff[_0x54428a++]=_0x203e68&0x3f|0x80):(_0x3457ff[_0x54428a++]=_0x203e68>>0x12|0xf0,_0x3457ff[_0x54428a++]=_0x203e68>>0xc&0x3f|0x80,_0x3457ff[_0x54428a++]=_0x203e68>>0x6&0x3f|0x80,_0x3457ff[_0x54428a++]=_0x203e68&0x3f|0x80);}return _0x3457ff;},Ln=function(_0x23b627){let _0x1d781b=0x0;for(let _0x454dad=0x0;_0x454dad<_0x23b627['length'];_0x454dad++){const _0x236eb9=_0x23b627['charCodeAt'](_0x454dad);_0x236eb9<0x80?_0x1d781b++:_0x236eb9<0x800?_0x1d781b+=0x2:_0x236eb9>=0xd800&&_0x236eb9<=0xdbff?(_0x1d781b+=0x4,_0x454dad++):_0x1d781b+=0x3;}return _0x1d781b;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0xa2d8be){return _0xa2d8be&&_0xa2d8be['_delegate']?_0xa2d8be['_delegate']:_0xa2d8be;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x4c1bb1){try{return(_0x4c1bb1['startsWith']('http://')||_0x4c1bb1['startsWith']('https://')?new URL(_0x4c1bb1)['hostname']:_0x4c1bb1)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x161e99){return(await fetch(_0x161e99,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x17f4e3,_0x3ddf5f,_0x22df8d){this['name']=_0x17f4e3,this['instanceFactory']=_0x3ddf5f,this['type']=_0x22df8d,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x348372){return this['instantiationMode']=_0x348372,this;}['setMultipleInstances'](_0x51935e){return this['multipleInstances']=_0x51935e,this;}['setServiceProps'](_0x54ad66){return this['serviceProps']=_0x54ad66,this;}['setInstanceCreatedCallback'](_0xd66d66){return this['onInstanceCreated']=_0xd66d66,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x206bed,_0x404a2e){this['name']=_0x206bed,this['container']=_0x404a2e,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x1cad2f){const _0x1167f3=this['normalizeInstanceIdentifier'](_0x1cad2f);if(!this['instancesDeferred']['has'](_0x1167f3)){const _0x4a117c=new H();if(this['instancesDeferred']['set'](_0x1167f3,_0x4a117c),this['isInitialized'](_0x1167f3)||this['shouldAutoInitialize']())try{const _0x6724dd=this['getOrInitializeService']({'instanceIdentifier':_0x1167f3});_0x6724dd&&_0x4a117c['resolve'](_0x6724dd);}catch{}}return this['instancesDeferred']['get'](_0x1167f3)['promise'];}['getImmediate'](_0x240347){const _0x2327a8=this['normalizeInstanceIdentifier'](_0x240347==null?void 0x0:_0x240347['identifier']),_0x105ea9=(_0x240347==null?void 0x0:_0x240347['optional'])??!0x1;if(this['isInitialized'](_0x2327a8)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x2327a8});}catch(_0x348a8d){if(_0x105ea9)return null;throw _0x348a8d;}else{if(_0x105ea9)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x436410){if(_0x436410['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x436410['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x436410,!!this['shouldAutoInitialize']()){if(Pc(_0x436410))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x3194f6,_0x2a377f]of this['instancesDeferred']['entries']()){const _0x419497=this['normalizeInstanceIdentifier'](_0x3194f6);try{const _0x54c0fe=this['getOrInitializeService']({'instanceIdentifier':_0x419497});_0x2a377f['resolve'](_0x54c0fe);}catch{}}}}['clearInstance'](_0x2c2ff0=Ne){this['instancesDeferred']['delete'](_0x2c2ff0),this['instancesOptions']['delete'](_0x2c2ff0),this['instances']['delete'](_0x2c2ff0);}async['delete'](){const _0xdfafcd=Array['from'](this['instances']['values']());await Promise['all']([..._0xdfafcd['filter'](_0x1802ee=>'INTERNAL'in _0x1802ee)['map'](_0x380353=>_0x380353['INTERNAL']['delete']()),..._0xdfafcd['filter'](_0x314456=>'_delete'in _0x314456)['map'](_0x47f15d=>_0x47f15d['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x31a86a=Ne){return this['instances']['has'](_0x31a86a);}['getOptions'](_0xa5a240=Ne){return this['instancesOptions']['get'](_0xa5a240)||{};}['initialize'](_0x364583={}){const {options:_0x5ceaed={}}=_0x364583,_0xbe7052=this['normalizeInstanceIdentifier'](_0x364583['instanceIdentifier']);if(this['isInitialized'](_0xbe7052))throw Error(this['name']+'('+_0xbe7052+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x3eb421=this['getOrInitializeService']({'instanceIdentifier':_0xbe7052,'options':_0x5ceaed});for(const [_0x1eaf08,_0x446f98]of this['instancesDeferred']['entries']()){const _0x592c12=this['normalizeInstanceIdentifier'](_0x1eaf08);_0xbe7052===_0x592c12&&_0x446f98['resolve'](_0x3eb421);}return _0x3eb421;}['onInit'](_0x1b13e1,_0x168ece){const _0x2ba5bb=this['normalizeInstanceIdentifier'](_0x168ece),_0x4fd9d5=this['onInitCallbacks']['get'](_0x2ba5bb)??new Set();_0x4fd9d5['add'](_0x1b13e1),this['onInitCallbacks']['set'](_0x2ba5bb,_0x4fd9d5);const _0x3024d0=this['instances']['get'](_0x2ba5bb);return _0x3024d0&&_0x1b13e1(_0x3024d0,_0x2ba5bb),()=>{_0x4fd9d5['delete'](_0x1b13e1);};}['invokeOnInitCallbacks'](_0x385f8d,_0x3722f7){const _0x1d867d=this['onInitCallbacks']['get'](_0x3722f7);if(_0x1d867d){for(const _0x2a85e2 of _0x1d867d)try{_0x2a85e2(_0x385f8d,_0x3722f7);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x1a9fbb,options:_0x14892d={}}){let _0x2bbeb2=this['instances']['get'](_0x1a9fbb);if(!_0x2bbeb2&&this['component']&&(_0x2bbeb2=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x1a9fbb),'options':_0x14892d}),this['instances']['set'](_0x1a9fbb,_0x2bbeb2),this['instancesOptions']['set'](_0x1a9fbb,_0x14892d),this['invokeOnInitCallbacks'](_0x2bbeb2,_0x1a9fbb),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x1a9fbb,_0x2bbeb2);}catch{}return _0x2bbeb2||null;}['normalizeInstanceIdentifier'](_0x3c75cf=Ne){return this['component']?this['component']['multipleInstances']?_0x3c75cf:Ne:_0x3c75cf;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x29d221){return _0x29d221===Ne?void 0x0:_0x29d221;}function Pc(_0x1403b1){return _0x1403b1['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x1f4e6a){this['name']=_0x1f4e6a,this['providers']=new Map();}['addComponent'](_0x452156){const _0xbf5c9a=this['getProvider'](_0x452156['name']);if(_0xbf5c9a['isComponentSet']())throw new Error('Component\x20'+_0x452156['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0xbf5c9a['setComponent'](_0x452156);}['addOrOverwriteComponent'](_0x142565){this['getProvider'](_0x142565['name'])['isComponentSet']()&&this['providers']['delete'](_0x142565['name']),this['addComponent'](_0x142565);}['getProvider'](_0x43a16c){if(this['providers']['has'](_0x43a16c))return this['providers']['get'](_0x43a16c);const _0x4f43fe=new Ac(_0x43a16c,this);return this['providers']['set'](_0x43a16c,_0x4f43fe),_0x4f43fe;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x5bff70){_0x5bff70[_0x5bff70['DEBUG']=0x0]='DEBUG',_0x5bff70[_0x5bff70['VERBOSE']=0x1]='VERBOSE',_0x5bff70[_0x5bff70['INFO']=0x2]='INFO',_0x5bff70[_0x5bff70['WARN']=0x3]='WARN',_0x5bff70[_0x5bff70['ERROR']=0x4]='ERROR',_0x5bff70[_0x5bff70['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x219a86,_0x513dfe,..._0x2f075d)=>{if(_0x513dfe<_0x219a86['logLevel'])return;const _0x694ca=new Date()['toISOString'](),_0xdf6cd8=Mc[_0x513dfe];if(_0xdf6cd8)console[_0xdf6cd8]('['+_0x694ca+']\x20\x20'+_0x219a86['name']+':',..._0x2f075d);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x513dfe+')');};class Bi{constructor(_0x1fefc8){this['name']=_0x1fefc8,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x4da91c){if(!(_0x4da91c in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x4da91c+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x4da91c;}['setLogLevel'](_0x2c20b7){this['_logLevel']=typeof _0x2c20b7=='string'?Oc[_0x2c20b7]:_0x2c20b7;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x1cb3ab){if(typeof _0x1cb3ab!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x1cb3ab;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x23976f){this['_userLogHandler']=_0x23976f;}['debug'](..._0x4cb357){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x4cb357),this['_logHandler'](this,T['DEBUG'],..._0x4cb357);}['log'](..._0x59f979){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x59f979),this['_logHandler'](this,T['VERBOSE'],..._0x59f979);}['info'](..._0xc02c79){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0xc02c79),this['_logHandler'](this,T['INFO'],..._0xc02c79);}['warn'](..._0x9a1beb){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x9a1beb),this['_logHandler'](this,T['WARN'],..._0x9a1beb);}['error'](..._0x4673c4){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x4673c4),this['_logHandler'](this,T['ERROR'],..._0x4673c4);}}const xc=(_0x53c4c0,_0x24dfa2)=>_0x24dfa2['some'](_0x4ff43d=>_0x53c4c0 instanceof _0x4ff43d);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x4fb95f){const _0x726a39=new Promise((_0x281016,_0x2c27f9)=>{const _0x10f551=()=>{_0x4fb95f['removeEventListener']('success',_0x589f31),_0x4fb95f['removeEventListener']('error',_0x28a11a);},_0x589f31=()=>{_0x281016(ge(_0x4fb95f['result'])),_0x10f551();},_0x28a11a=()=>{_0x2c27f9(_0x4fb95f['error']),_0x10f551();};_0x4fb95f['addEventListener']('success',_0x589f31),_0x4fb95f['addEventListener']('error',_0x28a11a);});return _0x726a39['then'](_0x4c4182=>{_0x4c4182 instanceof IDBCursor&&Jr['set'](_0x4c4182,_0x4fb95f);})['catch'](()=>{}),Vi['set'](_0x726a39,_0x4fb95f),_0x726a39;}function Bc(_0x1445cb){if(_i['has'](_0x1445cb))return;const _0x9eb92d=new Promise((_0x2345c0,_0x36b27a)=>{const _0xddb7f5=()=>{_0x1445cb['removeEventListener']('complete',_0x288c51),_0x1445cb['removeEventListener']('error',_0x46451e),_0x1445cb['removeEventListener']('abort',_0x46451e);},_0x288c51=()=>{_0x2345c0(),_0xddb7f5();},_0x46451e=()=>{_0x36b27a(_0x1445cb['error']||new DOMException('AbortError','AbortError')),_0xddb7f5();};_0x1445cb['addEventListener']('complete',_0x288c51),_0x1445cb['addEventListener']('error',_0x46451e),_0x1445cb['addEventListener']('abort',_0x46451e);});_i['set'](_0x1445cb,_0x9eb92d);}let gi={'get'(_0x33d22a,_0x84cf55,_0x4d557f){if(_0x33d22a instanceof IDBTransaction){if(_0x84cf55==='done')return _i['get'](_0x33d22a);if(_0x84cf55==='objectStoreNames')return _0x33d22a['objectStoreNames']||Xr['get'](_0x33d22a);if(_0x84cf55==='store')return _0x4d557f['objectStoreNames'][0x1]?void 0x0:_0x4d557f['objectStore'](_0x4d557f['objectStoreNames'][0x0]);}return ge(_0x33d22a[_0x84cf55]);},'set'(_0x441080,_0xfd9872,_0x1a70f0){return _0x441080[_0xfd9872]=_0x1a70f0,!0x0;},'has'(_0x52a041,_0x2d5ed0){return _0x52a041 instanceof IDBTransaction&&(_0x2d5ed0==='done'||_0x2d5ed0==='store')?!0x0:_0x2d5ed0 in _0x52a041;}};function Vc(_0x13bcad){gi=_0x13bcad(gi);}function Hc(_0x4f27b0){return _0x4f27b0===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x318b93,..._0xa9f7fe){const _0x4248e7=_0x4f27b0['call'](ii(this),_0x318b93,..._0xa9f7fe);return Xr['set'](_0x4248e7,_0x318b93['sort']?_0x318b93['sort']():[_0x318b93]),ge(_0x4248e7);}:Uc()['includes'](_0x4f27b0)?function(..._0x3fb3fa){return _0x4f27b0['apply'](ii(this),_0x3fb3fa),ge(Jr['get'](this));}:function(..._0x545443){return ge(_0x4f27b0['apply'](ii(this),_0x545443));};}function $c(_0x47ccbc){return typeof _0x47ccbc=='function'?Hc(_0x47ccbc):(_0x47ccbc instanceof IDBTransaction&&Bc(_0x47ccbc),xc(_0x47ccbc,Fc())?new Proxy(_0x47ccbc,gi):_0x47ccbc);}function ge(_0x58d0a4){if(_0x58d0a4 instanceof IDBRequest)return Wc(_0x58d0a4);if(ni['has'](_0x58d0a4))return ni['get'](_0x58d0a4);const _0x441d88=$c(_0x58d0a4);return _0x441d88!==_0x58d0a4&&(ni['set'](_0x58d0a4,_0x441d88),Vi['set'](_0x441d88,_0x58d0a4)),_0x441d88;}const ii=_0x4f1315=>Vi['get'](_0x4f1315);function Gc(_0x35273f,_0x483027,{blocked:_0xc2f830,upgrade:_0x303a13,blocking:_0x1ad9e1,terminated:_0x1b2ea6}={}){const _0x327a07=indexedDB['open'](_0x35273f,_0x483027),_0x6fe127=ge(_0x327a07);return _0x303a13&&_0x327a07['addEventListener']('upgradeneeded',_0x1be72d=>{_0x303a13(ge(_0x327a07['result']),_0x1be72d['oldVersion'],_0x1be72d['newVersion'],ge(_0x327a07['transaction']),_0x1be72d);}),_0xc2f830&&_0x327a07['addEventListener']('blocked',_0x33d30f=>_0xc2f830(_0x33d30f['oldVersion'],_0x33d30f['newVersion'],_0x33d30f)),_0x6fe127['then'](_0x35030c=>{_0x1b2ea6&&_0x35030c['addEventListener']('close',()=>_0x1b2ea6()),_0x1ad9e1&&_0x35030c['addEventListener']('versionchange',_0x4153f1=>_0x1ad9e1(_0x4153f1['oldVersion'],_0x4153f1['newVersion'],_0x4153f1));})['catch'](()=>{}),_0x6fe127;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x3b9f14,_0x2d28ab){if(!(_0x3b9f14 instanceof IDBDatabase&&!(_0x2d28ab in _0x3b9f14)&&typeof _0x2d28ab=='string'))return;if(si['get'](_0x2d28ab))return si['get'](_0x2d28ab);const _0x4b909e=_0x2d28ab['replace'](/FromIndex$/,''),_0x55ce9e=_0x2d28ab!==_0x4b909e,_0x4292ef=zc['includes'](_0x4b909e);if(!(_0x4b909e in(_0x55ce9e?IDBIndex:IDBObjectStore)['prototype'])||!(_0x4292ef||qc['includes'](_0x4b909e)))return;const _0x29f7c3=async function(_0x384aff,..._0xed31df){const _0x5620f4=this['transaction'](_0x384aff,_0x4292ef?'readwrite':'readonly');let _0x296038=_0x5620f4['store'];return _0x55ce9e&&(_0x296038=_0x296038['index'](_0xed31df['shift']())),(await Promise['all']([_0x296038[_0x4b909e](..._0xed31df),_0x4292ef&&_0x5620f4['done']]))[0x0];};return si['set'](_0x2d28ab,_0x29f7c3),_0x29f7c3;}Vc(_0x2d1de3=>({..._0x2d1de3,'get':(_0x5585c7,_0x2a5018,_0x40ef13)=>Ms(_0x5585c7,_0x2a5018)||_0x2d1de3['get'](_0x5585c7,_0x2a5018,_0x40ef13),'has':(_0x5b50ff,_0x33e0f6)=>!!Ms(_0x5b50ff,_0x33e0f6)||_0x2d1de3['has'](_0x5b50ff,_0x33e0f6)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x143327){this['container']=_0x143327;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x5b9d19=>{if(Kc(_0x5b9d19)){const _0x1b1a2b=_0x5b9d19['getImmediate']();return _0x1b1a2b['library']+'/'+_0x1b1a2b['version'];}else return null;})['filter'](_0xa07bf4=>_0xa07bf4)['join']('\x20');}}function Kc(_0x56c938){const _0x12fa22=_0x56c938['getComponent']();return(_0x12fa22==null?void 0x0:_0x12fa22['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x27be94,_0x88d676){try{_0x27be94['container']['addComponent'](_0x88d676);}catch(_0x20d572){oe['debug']('Component\x20'+_0x88d676['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x27be94['name'],_0x20d572);}}function st(_0x197e49){const _0x1ee292=_0x197e49['name'];if(Ei['has'](_0x1ee292))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x1ee292+'.'),!0x1;Ei['set'](_0x1ee292,_0x197e49);for(const _0x172e13 of Ue['values']())xs(_0x172e13,_0x197e49);for(const _0x589fc9 of vi['values']())xs(_0x589fc9,_0x197e49);return!0x0;}function Hi(_0x5bbfe5,_0xa524e3){const _0x3c7ed1=_0x5bbfe5['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x3c7ed1&&_0x3c7ed1['triggerHeartbeat'](),_0x5bbfe5['container']['getProvider'](_0xa524e3);}function $(_0x143942){return _0x143942==null?!0x1:_0x143942['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x5de23f,_0x439d0f,_0x1bcb4c){this['_isDeleted']=!0x1,this['_options']={..._0x5de23f},this['_config']={..._0x439d0f},this['_name']=_0x439d0f['name'],this['_automaticDataCollectionEnabled']=_0x439d0f['automaticDataCollectionEnabled'],this['_container']=_0x1bcb4c,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x2ff0fe){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x2ff0fe;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x6b79bf){this['_isDeleted']=_0x6b79bf;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x3d4bd6,_0x12f79e={}){let _0x3f73c9=_0x3d4bd6;typeof _0x12f79e!='object'&&(_0x12f79e={'name':_0x12f79e});const _0x17da78={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x12f79e},_0x302b2b=_0x17da78['name'];if(typeof _0x302b2b!='string'||!_0x302b2b)throw me['create']('bad-app-name',{'appName':String(_0x302b2b)});if(_0x3f73c9||(_0x3f73c9=zr()),!_0x3f73c9)throw me['create']('no-options');const _0x4e9cfa=Ue['get'](_0x302b2b);if(_0x4e9cfa){if(xe(_0x3f73c9,_0x4e9cfa['options'])&&xe(_0x17da78,_0x4e9cfa['config']))return _0x4e9cfa;throw me['create']('duplicate-app',{'appName':_0x302b2b});}const _0x1bfef4=new Nc(_0x302b2b);for(const _0x23d883 of Ei['values']())_0x1bfef4['addComponent'](_0x23d883);const _0x12617a=new Tl(_0x3f73c9,_0x17da78,_0x1bfef4);return Ue['set'](_0x302b2b,_0x12617a),_0x12617a;}function Zr(_0x4994df=yi){const _0x42aec2=Ue['get'](_0x4994df);if(!_0x42aec2&&_0x4994df===yi&&zr())return Sl();if(!_0x42aec2)throw me['create']('no-app',{'appName':_0x4994df});return _0x42aec2;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x50e5fb){let _0x15e6e4=!0x1;const _0x561f2f=_0x50e5fb['name'];Ue['has'](_0x561f2f)?(_0x15e6e4=!0x0,Ue['delete'](_0x561f2f)):vi['has'](_0x561f2f)&&_0x50e5fb['decRefCount']()<=0x0&&(vi['delete'](_0x561f2f),_0x15e6e4=!0x0),_0x15e6e4&&(await Promise['all'](_0x50e5fb['container']['getProviders']()['map'](_0x165c4f=>_0x165c4f['delete']())),_0x50e5fb['isDeleted']=!0x0);}function ye(_0x2c8844,_0x1e4d15,_0x25f04e){let _0x34df3e=wl[_0x2c8844]??_0x2c8844;_0x25f04e&&(_0x34df3e+='-'+_0x25f04e);const _0x26ff83=_0x34df3e['match'](/\s|\//),_0x5ce95a=_0x1e4d15['match'](/\s|\//);if(_0x26ff83||_0x5ce95a){const _0x417236=['Unable\x20to\x20register\x20library\x20\x22'+_0x34df3e+'\x22\x20with\x20version\x20\x22'+_0x1e4d15+'\x22:'];_0x26ff83&&_0x417236['push']('library\x20name\x20\x22'+_0x34df3e+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x26ff83&&_0x5ce95a&&_0x417236['push']('and'),_0x5ce95a&&_0x417236['push']('version\x20name\x20\x22'+_0x1e4d15+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x417236['join']('\x20'));return;}st(new Fe(_0x34df3e+'-version',()=>({'library':_0x34df3e,'version':_0x1e4d15}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0xdfa2e,_0x488470)=>{switch(_0x488470){case 0x0:try{_0xdfa2e['createObjectStore'](Ot);}catch(_0x26052b){console['warn'](_0x26052b);}}}})['catch'](_0x2a4378=>{throw me['create']('idb-open',{'originalErrorMessage':_0x2a4378['message']});})),ri;}async function Al(_0x21176c){try{const _0x39a6b0=(await eo())['transaction'](Ot),_0x5a402a=await _0x39a6b0['objectStore'](Ot)['get'](to(_0x21176c));return await _0x39a6b0['done'],_0x5a402a;}catch(_0x277d6b){if(_0x277d6b instanceof Re)oe['warn'](_0x277d6b['message']);else{const _0x581833=me['create']('idb-get',{'originalErrorMessage':_0x277d6b==null?void 0x0:_0x277d6b['message']});oe['warn'](_0x581833['message']);}}}async function Fs(_0x1f1d49,_0x3c803f){try{const _0x49630a=(await eo())['transaction'](Ot,'readwrite');await _0x49630a['objectStore'](Ot)['put'](_0x3c803f,to(_0x1f1d49)),await _0x49630a['done'];}catch(_0x452fd9){if(_0x452fd9 instanceof Re)oe['warn'](_0x452fd9['message']);else{const _0x26b528=me['create']('idb-set',{'originalErrorMessage':_0x452fd9==null?void 0x0:_0x452fd9['message']});oe['warn'](_0x26b528['message']);}}}function to(_0x5cf4ef){return _0x5cf4ef['name']+'!'+_0x5cf4ef['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x37cc23){this['container']=_0x37cc23,this['_heartbeatsCache']=null;const _0x292b9b=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x292b9b),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x36a8a2=>(this['_heartbeatsCache']=_0x36a8a2,_0x36a8a2));}async['triggerHeartbeat'](){var _0x3dd720,_0x456c90;try{const _0xcf6364=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x515ca1=Us();if(((_0x3dd720=this['_heartbeatsCache'])==null?void 0x0:_0x3dd720['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x456c90=this['_heartbeatsCache'])==null?void 0x0:_0x456c90['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x515ca1||this['_heartbeatsCache']['heartbeats']['some'](_0x205b08=>_0x205b08['date']===_0x515ca1))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x515ca1,'agent':_0xcf6364}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x51ff8c=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x51ff8c,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x50ddf5){oe['warn'](_0x50ddf5);}}async['getHeartbeatsHeader'](){var _0x2f68a3;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x2f68a3=this['_heartbeatsCache'])==null?void 0x0:_0x2f68a3['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0xf4bb8f=Us(),{heartbeatsToSend:_0x5b92ec,unsentEntries:_0x28199e}=Ol(this['_heartbeatsCache']['heartbeats']),_0x3aa6ff=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x5b92ec}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0xf4bb8f,_0x28199e['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x28199e,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x3aa6ff;}catch(_0x57ee17){return oe['warn'](_0x57ee17),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x3a56ad,_0x16475b=kl){const _0x478d4f=[];let _0x49f6c8=_0x3a56ad['slice']();for(const _0xa80da3 of _0x3a56ad){const _0x4567a6=_0x478d4f['find'](_0x4b0d22=>_0x4b0d22['agent']===_0xa80da3['agent']);if(_0x4567a6){if(_0x4567a6['dates']['push'](_0xa80da3['date']),Ws(_0x478d4f)>_0x16475b){_0x4567a6['dates']['pop']();break;}}else{if(_0x478d4f['push']({'agent':_0xa80da3['agent'],'dates':[_0xa80da3['date']]}),Ws(_0x478d4f)>_0x16475b){_0x478d4f['pop']();break;}}_0x49f6c8=_0x49f6c8['slice'](0x1);}return{'heartbeatsToSend':_0x478d4f,'unsentEntries':_0x49f6c8};}class Dl{constructor(_0x173732){this['app']=_0x173732,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x2b8ec6=await Al(this['app']);return _0x2b8ec6!=null&&_0x2b8ec6['heartbeats']?_0x2b8ec6:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x95d561){if(await this['_canUseIndexedDBPromise']){const _0x588190=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x95d561['lastSentHeartbeatDate']??_0x588190['lastSentHeartbeatDate'],'heartbeats':_0x95d561['heartbeats']});}else return;}async['add'](_0x12250e){if(await this['_canUseIndexedDBPromise']){const _0xe675d1=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x12250e['lastSentHeartbeatDate']??_0xe675d1['lastSentHeartbeatDate'],'heartbeats':[..._0xe675d1['heartbeats'],..._0x12250e['heartbeats']]});}else return;}}function Ws(_0x7cb7ce){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x7cb7ce}))['length'];}function Ml(_0x559f7f){if(_0x559f7f['length']===0x0)return-0x1;let _0x4695c7=0x0,_0x447c2a=_0x559f7f[0x0]['date'];for(let _0xfd1ee4=0x1;_0xfd1ee4<_0x559f7f['length'];_0xfd1ee4++)_0x559f7f[_0xfd1ee4]['date']<_0x447c2a&&(_0x447c2a=_0x559f7f[_0xfd1ee4]['date'],_0x4695c7=_0xfd1ee4);return _0x4695c7;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x3eb742){st(new Fe('platform-logger',_0x421b5c=>new jc(_0x421b5c),'PRIVATE')),st(new Fe('heartbeat',_0x7d668c=>new Nl(_0x7d668c),'PRIVATE')),ye(mi,Ls,_0x3eb742),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x5acea7){no=_0x5acea7;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x485320){this['domStorage_']=_0x485320,this['prefix_']='firebase:';}['set'](_0x295261,_0x1be899){_0x1be899==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x295261)):this['domStorage_']['setItem'](this['prefixedName_'](_0x295261),O(_0x1be899));}['get'](_0x5184fd){const _0x35b7a9=this['domStorage_']['getItem'](this['prefixedName_'](_0x5184fd));return _0x35b7a9==null?null:Nt(_0x35b7a9);}['remove'](_0x12096a){this['domStorage_']['removeItem'](this['prefixedName_'](_0x12096a));}['prefixedName_'](_0x543956){return this['prefix_']+_0x543956;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x7fe533,_0x22512a){_0x22512a==null?delete this['cache_'][_0x7fe533]:this['cache_'][_0x7fe533]=_0x22512a;}['get'](_0x500add){return Q(this['cache_'],_0x500add)?this['cache_'][_0x500add]:null;}['remove'](_0xd5df0a){delete this['cache_'][_0xd5df0a];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x46b9a4){try{if(typeof window<'u'&&typeof window[_0x46b9a4]<'u'){const _0x777f0=window[_0x46b9a4];return _0x777f0['setItem']('firebase:sentinel','cache'),_0x777f0['removeItem']('firebase:sentinel'),new Wl(_0x777f0);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x7c722b=0x1;return function(){return _0x7c722b++;};}()),ro=function(_0x4b4a7e){const _0x3372b7=Rc(_0x4b4a7e),_0x1c29a8=new Cc();_0x1c29a8['update'](_0x3372b7);const _0x531a3a=_0x1c29a8['digest']();return Fi['encodeByteArray'](_0x531a3a);},zt=function(..._0x2d681a){let _0x45b2b4='';for(let _0x54a556=0x0;_0x54a556<_0x2d681a['length'];_0x54a556++){const _0x475af3=_0x2d681a[_0x54a556];Array['isArray'](_0x475af3)||_0x475af3&&typeof _0x475af3=='object'&&typeof _0x475af3['length']=='number'?_0x45b2b4+=zt['apply'](null,_0x475af3):typeof _0x475af3=='object'?_0x45b2b4+=O(_0x475af3):_0x45b2b4+=_0x475af3,_0x45b2b4+='\x20';}return _0x45b2b4;};let St=null,$s=!0x0;const Hl=function(_0xc9ad91,_0x5f56fc){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x37bf17){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x3bd041=zt['apply'](null,_0x37bf17);St(_0x3bd041);}},jt=function(_0x2896be){return function(..._0x565404){L(_0x2896be,..._0x565404);};},Ii=function(..._0x340d2b){const _0x10708c='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x340d2b);Ze['error'](_0x10708c);},ae=function(..._0x17c90f){const _0x4d22c0='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x17c90f);throw Ze['error'](_0x4d22c0),new Error(_0x4d22c0);},U=function(..._0x2996cb){const _0x349870='FIREBASE\x20WARNING:\x20'+zt(..._0x2996cb);Ze['warn'](_0x349870);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x68ab17){return typeof _0x68ab17=='number'&&(_0x68ab17!==_0x68ab17||_0x68ab17===Number['POSITIVE_INFINITY']||_0x68ab17===Number['NEGATIVE_INFINITY']);},Gl=function(_0x2c66e1){if(document['readyState']==='complete')_0x2c66e1();else{let _0x1f5a4b=!0x1;const _0xc6819d=function(){if(!document['body']){setTimeout(_0xc6819d,Math['floor'](0xa));return;}_0x1f5a4b||(_0x1f5a4b=!0x0,_0x2c66e1());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0xc6819d,!0x1),window['addEventListener']('load',_0xc6819d,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0xc6819d();}),window['attachEvent']('onload',_0xc6819d));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x49665c,_0x32a0aa){if(_0x49665c===_0x32a0aa)return 0x0;if(_0x49665c===We||_0x32a0aa===we)return-0x1;if(_0x32a0aa===We||_0x49665c===we)return 0x1;{const _0x36af55=Gs(_0x49665c),_0x419f1e=Gs(_0x32a0aa);return _0x36af55!==null?_0x419f1e!==null?_0x36af55-_0x419f1e===0x0?_0x49665c['length']-_0x32a0aa['length']:_0x36af55-_0x419f1e:-0x1:_0x419f1e!==null?0x1:_0x49665c<_0x32a0aa?-0x1:0x1;}},ql=function(_0x522dfa,_0x50ca63){return _0x522dfa===_0x50ca63?0x0:_0x522dfa<_0x50ca63?-0x1:0x1;},vt=function(_0xa20ede,_0x6aa6a9){if(_0x6aa6a9&&_0xa20ede in _0x6aa6a9)return _0x6aa6a9[_0xa20ede];throw new Error('Missing\x20required\x20key\x20('+_0xa20ede+')\x20in\x20object:\x20'+O(_0x6aa6a9));},$i=function(_0x3469d1){if(typeof _0x3469d1!='object'||_0x3469d1===null)return O(_0x3469d1);const _0x5d47ef=[];for(const _0x4768fd in _0x3469d1)_0x5d47ef['push'](_0x4768fd);_0x5d47ef['sort']();let _0x17e160='{';for(let _0x52c2c5=0x0;_0x52c2c5<_0x5d47ef['length'];_0x52c2c5++)_0x52c2c5!==0x0&&(_0x17e160+=','),_0x17e160+=O(_0x5d47ef[_0x52c2c5]),_0x17e160+=':',_0x17e160+=$i(_0x3469d1[_0x5d47ef[_0x52c2c5]]);return _0x17e160+='}',_0x17e160;},oo=function(_0x23a801,_0x51d6ec){const _0x5ccedd=_0x23a801['length'];if(_0x5ccedd<=_0x51d6ec)return[_0x23a801];const _0x5822e5=[];for(let _0x5adc87=0x0;_0x5adc87<_0x5ccedd;_0x5adc87+=_0x51d6ec)_0x5adc87+_0x51d6ec>_0x5ccedd?_0x5822e5['push'](_0x23a801['substring'](_0x5adc87,_0x5ccedd)):_0x5822e5['push'](_0x23a801['substring'](_0x5adc87,_0x5adc87+_0x51d6ec));return _0x5822e5;};function x(_0x1da504,_0x18ff3f){for(const _0x5df3d9 in _0x1da504)_0x1da504['hasOwnProperty'](_0x5df3d9)&&_0x18ff3f(_0x5df3d9,_0x1da504[_0x5df3d9]);}const ao=function(_0x152217){f(!xn(_0x152217),'Invalid\x20JSON\x20number');const _0x1133e9=0xb,_0x30af05=0x34,_0x110d38=(0x1<<_0x1133e9-0x1)-0x1;let _0xb22a0a,_0x29ebe8,_0x45b2f5,_0x100cba,_0x343787;_0x152217===0x0?(_0x29ebe8=0x0,_0x45b2f5=0x0,_0xb22a0a=0x1/_0x152217===-0x1/0x0?0x1:0x0):(_0xb22a0a=_0x152217<0x0,_0x152217=Math['abs'](_0x152217),_0x152217>=Math['pow'](0x2,0x1-_0x110d38)?(_0x100cba=Math['min'](Math['floor'](Math['log'](_0x152217)/Math['LN2']),_0x110d38),_0x29ebe8=_0x100cba+_0x110d38,_0x45b2f5=Math['round'](_0x152217*Math['pow'](0x2,_0x30af05-_0x100cba)-Math['pow'](0x2,_0x30af05))):(_0x29ebe8=0x0,_0x45b2f5=Math['round'](_0x152217/Math['pow'](0x2,0x1-_0x110d38-_0x30af05))));const _0x591b54=[];for(_0x343787=_0x30af05;_0x343787;_0x343787-=0x1)_0x591b54['push'](_0x45b2f5%0x2?0x1:0x0),_0x45b2f5=Math['floor'](_0x45b2f5/0x2);for(_0x343787=_0x1133e9;_0x343787;_0x343787-=0x1)_0x591b54['push'](_0x29ebe8%0x2?0x1:0x0),_0x29ebe8=Math['floor'](_0x29ebe8/0x2);_0x591b54['push'](_0xb22a0a?0x1:0x0),_0x591b54['reverse']();const _0x7047e1=_0x591b54['join']('');let _0x1697dd='';for(_0x343787=0x0;_0x343787<0x40;_0x343787+=0x8){let _0x5d580c=parseInt(_0x7047e1['substr'](_0x343787,0x8),0x2)['toString'](0x10);_0x5d580c['length']===0x1&&(_0x5d580c='0'+_0x5d580c),_0x1697dd=_0x1697dd+_0x5d580c;}return _0x1697dd['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x29baaa,_0x399b9f){let _0x3cfa50='Unknown\x20Error';_0x29baaa==='too_big'?_0x3cfa50='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x29baaa==='permission_denied'?_0x3cfa50='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x29baaa==='unavailable'&&(_0x3cfa50='The\x20service\x20is\x20unavailable');const _0x2018c1=new Error(_0x29baaa+'\x20at\x20'+_0x399b9f['_path']['toString']()+':\x20'+_0x3cfa50);return _0x2018c1['code']=_0x29baaa['toUpperCase'](),_0x2018c1;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x136617){if(Yl['test'](_0x136617)){const _0x78aa63=Number(_0x136617);if(_0x78aa63>=Ql&&_0x78aa63<=Jl)return _0x78aa63;}return null;},ft=function(_0x194f2){try{_0x194f2();}catch(_0x2cc68e){setTimeout(()=>{const _0x180d14=_0x2cc68e['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x180d14),_0x2cc68e;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x54c59e,_0x3e7192){const _0x13442e=setTimeout(_0x54c59e,_0x3e7192);return typeof _0x13442e=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x13442e):typeof _0x13442e=='object'&&_0x13442e['unref']&&_0x13442e['unref'](),_0x13442e;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x15bce0,_0x226f0f){this['appCheckProvider']=_0x226f0f,this['appName']=_0x15bce0['name'],$(_0x15bce0)&&_0x15bce0['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x15bce0['settings']['appCheckToken']),this['appCheck']=_0x226f0f==null?void 0x0:_0x226f0f['getImmediate']({'optional':!0x0}),this['appCheck']||_0x226f0f==null||_0x226f0f['get']()['then'](_0x1a92f6=>this['appCheck']=_0x1a92f6);}['getToken'](_0x25e007){if(this['serverAppAppCheckToken']){if(_0x25e007)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x25e007):new Promise((_0x4a632a,_0x563e09)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x25e007)['then'](_0x4a632a,_0x563e09):_0x4a632a(null);},0x0);});}['addTokenChangeListener'](_0x1c45f5){var _0x4f8791;(_0x4f8791=this['appCheckProvider'])==null||_0x4f8791['get']()['then'](_0x4ada3e=>_0x4ada3e['addTokenListener'](_0x1c45f5));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x2904f8,_0x5da624,_0x3f64db){this['appName_']=_0x2904f8,this['firebaseOptions_']=_0x5da624,this['authProvider_']=_0x3f64db,this['auth_']=null,this['auth_']=_0x3f64db['getImmediate']({'optional':!0x0}),this['auth_']||_0x3f64db['onInit'](_0x4870c6=>this['auth_']=_0x4870c6);}['getToken'](_0x28f71e){return this['auth_']?this['auth_']['getToken'](_0x28f71e)['catch'](_0x2f1af0=>_0x2f1af0&&_0x2f1af0['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x2f1af0)):new Promise((_0x5c910d,_0x3ae604)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x28f71e)['then'](_0x5c910d,_0x3ae604):_0x5c910d(null);},0x0);});}['addTokenChangeListener'](_0x40b3e4){this['auth_']?this['auth_']['addAuthTokenListener'](_0x40b3e4):this['authProvider_']['get']()['then'](_0x52b22d=>_0x52b22d['addAuthTokenListener'](_0x40b3e4));}['removeTokenChangeListener'](_0x30ca81){this['authProvider_']['get']()['then'](_0x4a8cfa=>_0x4a8cfa['removeAuthTokenListener'](_0x30ca81));}['notifyForInvalidToken'](){let _0x4e6d02='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x4e6d02+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x4e6d02+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x4e6d02+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x4e6d02);}}class an{constructor(_0x735ee4){this['accessToken']=_0x735ee4;}['getToken'](_0xf4c7a0){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x173b03){_0x173b03(this['accessToken']);}['removeTokenChangeListener'](_0x1590e0){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x27a903,_0x562bdf,_0x2a0d24,_0x5ab782,_0x1be943=!0x1,_0x116436='',_0x150dce=!0x1,_0x2d0a33=!0x1,_0x3f0e05=null){this['secure']=_0x562bdf,this['namespace']=_0x2a0d24,this['webSocketOnly']=_0x5ab782,this['nodeAdmin']=_0x1be943,this['persistenceKey']=_0x116436,this['includeNamespaceInQueryParams']=_0x150dce,this['isUsingEmulator']=_0x2d0a33,this['emulatorOptions']=_0x3f0e05,this['_host']=_0x27a903['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x27a903)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x2fe87a){_0x2fe87a!==this['internalHost']&&(this['internalHost']=_0x2fe87a,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x33f9da=this['toURLString']();return this['persistenceKey']&&(_0x33f9da+='<'+this['persistenceKey']+'>'),_0x33f9da;}['toURLString'](){const _0x421ad5=this['secure']?'https://':'http://',_0x4cba6f=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x421ad5+this['host']+'/'+_0x4cba6f;}}function th(_0x5515de){return _0x5515de['host']!==_0x5515de['internalHost']||_0x5515de['isCustomHost']()||_0x5515de['includeNamespaceInQueryParams'];}function vo(_0x1413d9,_0x425dd9,_0x4401b2){f(typeof _0x425dd9=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x4401b2=='object','typeof\x20params\x20must\x20==\x20object');let _0x480944;if(_0x425dd9===go)_0x480944=(_0x1413d9['secure']?'wss://':'ws://')+_0x1413d9['internalHost']+'/.ws?';else{if(_0x425dd9===mo)_0x480944=(_0x1413d9['secure']?'https://':'http://')+_0x1413d9['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x425dd9);}th(_0x1413d9)&&(_0x4401b2['ns']=_0x1413d9['namespace']);const _0x4090e4=[];return x(_0x4401b2,(_0x43bfe0,_0x28086b)=>{_0x4090e4['push'](_0x43bfe0+'='+_0x28086b);}),_0x480944+_0x4090e4['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x3a158e,_0x2ebb72=0x1){Q(this['counters_'],_0x3a158e)||(this['counters_'][_0x3a158e]=0x0),this['counters_'][_0x3a158e]+=_0x2ebb72;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x1eb3b8){const _0x3058af=_0x1eb3b8['toString']();return oi[_0x3058af]||(oi[_0x3058af]=new nh()),oi[_0x3058af];}function ih(_0x25ad8f,_0x357e64){const _0x435671=_0x25ad8f['toString']();return ai[_0x435671]||(ai[_0x435671]=_0x357e64()),ai[_0x435671];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x55f1cd){this['onMessage_']=_0x55f1cd,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x4972fa,_0x5f646a){this['closeAfterResponse']=_0x4972fa,this['onClose']=_0x5f646a,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0xb4af7f,_0x2a1b08){for(this['pendingResponses'][_0xb4af7f]=_0x2a1b08;this['pendingResponses'][this['currentResponseNum']];){const _0x2b238a=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x4e97fc=0x0;_0x4e97fc<_0x2b238a['length'];++_0x4e97fc)_0x2b238a[_0x4e97fc]&&ft(()=>{this['onMessage_'](_0x2b238a[_0x4e97fc]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x38dd1d,_0x226671,_0x3c1a6d,_0x1a5e17,_0x171d40,_0x263bc0,_0x122e06){this['connId']=_0x38dd1d,this['repoInfo']=_0x226671,this['applicationId']=_0x3c1a6d,this['appCheckToken']=_0x1a5e17,this['authToken']=_0x171d40,this['transportSessionId']=_0x263bc0,this['lastSessionId']=_0x122e06,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x38dd1d),this['stats_']=qi(_0x226671),this['urlFn']=_0x3f1666=>(this['appCheckToken']&&(_0x3f1666[wi]=this['appCheckToken']),vo(_0x226671,mo,_0x3f1666));}['open'](_0x4eef0d,_0x2c278d){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x2c278d,this['myPacketOrderer']=new sh(_0x4eef0d),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x4ca0d0)=>{const [_0x15578c,_0x5667b2,_0x19ee9b,_0x588a66,_0x2a21a4]=_0x4ca0d0;if(this['incrementIncomingBytes_'](_0x4ca0d0),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x15578c===qs)this['id']=_0x5667b2,this['password']=_0x19ee9b;else{if(_0x15578c===rh)_0x5667b2?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x5667b2,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x15578c);}}},(..._0x8ca3d7)=>{const [_0x465e2e,_0x56a337]=_0x8ca3d7;this['incrementIncomingBytes_'](_0x8ca3d7),this['myPacketOrderer']['handleResponse'](_0x465e2e,_0x56a337);},()=>{this['onClosed_']();},this['urlFn']);const _0x48b61d={};_0x48b61d[qs]='t',_0x48b61d[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x48b61d[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x48b61d[co]=Gi,this['transportSessionId']&&(_0x48b61d[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x48b61d[po]=this['lastSessionId']),this['applicationId']&&(_0x48b61d[_o]=this['applicationId']),this['appCheckToken']&&(_0x48b61d[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x48b61d[ho]=uo);const _0x347878=this['urlFn'](_0x48b61d);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x347878),this['scriptTagHolder']['addTag'](_0x347878,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x185970){const _0xc5ece2=O(_0x185970);this['bytesSent']+=_0xc5ece2['length'],this['stats_']['incrementCounter']('bytes_sent',_0xc5ece2['length']);const _0x5c43f4=$r(_0xc5ece2),_0x7b9690=oo(_0x5c43f4,fh);for(let _0x17edd8=0x0;_0x17edd8<_0x7b9690['length'];_0x17edd8++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x7b9690['length'],_0x7b9690[_0x17edd8]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x1464d8,_0x24a3b4){this['myDisconnFrame']=document['createElement']('iframe');const _0x4e4808={};_0x4e4808[dh]='t',_0x4e4808[Eo]=_0x1464d8,_0x4e4808[Io]=_0x24a3b4,this['myDisconnFrame']['src']=this['urlFn'](_0x4e4808),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x2fa8e0){const _0x1cc90a=O(_0x2fa8e0)['length'];this['bytesReceived']+=_0x1cc90a,this['stats_']['incrementCounter']('bytes_received',_0x1cc90a);}}class zi{constructor(_0xdc3ec8,_0x52c0db,_0x245190,_0x4de3dc){this['onDisconnect']=_0x245190,this['urlFn']=_0x4de3dc,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0xdc3ec8,window[ah+this['uniqueCallbackIdentifier']]=_0x52c0db,this['myIFrame']=zi['createIFrame_']();let _0x4dc05e='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x4dc05e='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x2f5cd6='<html><body>'+_0x4dc05e+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x2f5cd6),this['myIFrame']['doc']['close']();}catch(_0x12d5f3){L('frame\x20writing\x20exception'),_0x12d5f3['stack']&&L(_0x12d5f3['stack']),L(_0x12d5f3);}}}static['createIFrame_'](){const _0x2a1b19=document['createElement']('iframe');if(_0x2a1b19['style']['display']='none',document['body']){document['body']['appendChild'](_0x2a1b19);try{_0x2a1b19['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x57e386=document['domain'];_0x2a1b19['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x57e386+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x2a1b19['contentDocument']?_0x2a1b19['doc']=_0x2a1b19['contentDocument']:_0x2a1b19['contentWindow']?_0x2a1b19['doc']=_0x2a1b19['contentWindow']['document']:_0x2a1b19['document']&&(_0x2a1b19['doc']=_0x2a1b19['document']),_0x2a1b19;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x2b93d3=this['onDisconnect'];_0x2b93d3&&(this['onDisconnect']=null,_0x2b93d3());}['startLongPoll'](_0x5aad72,_0x3ccc2f){for(this['myID']=_0x5aad72,this['myPW']=_0x3ccc2f,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x1fb818={};_0x1fb818[Eo]=this['myID'],_0x1fb818[Io]=this['myPW'],_0x1fb818[wo]=this['currentSerial'];let _0x52246c=this['urlFn'](_0x1fb818),_0x14a76f='',_0x351455=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x14a76f['length']<=Co;){const _0x350ed4=this['pendingSegs']['shift']();_0x14a76f=_0x14a76f+'&'+lh+_0x351455+'='+_0x350ed4['seg']+'&'+hh+_0x351455+'='+_0x350ed4['ts']+'&'+uh+_0x351455+'='+_0x350ed4['d'],_0x351455++;}return _0x52246c=_0x52246c+_0x14a76f,this['addLongPollTag_'](_0x52246c,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x2cccd4,_0x21da26,_0x466d17){this['pendingSegs']['push']({'seg':_0x2cccd4,'ts':_0x21da26,'d':_0x466d17}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x4970de,_0x4aef73){this['outstandingRequests']['add'](_0x4aef73);const _0x2bccfa=()=>{this['outstandingRequests']['delete'](_0x4aef73),this['newRequest_']();},_0x31dd84=setTimeout(_0x2bccfa,Math['floor'](ph)),_0xa1414c=()=>{clearTimeout(_0x31dd84),_0x2bccfa();};this['addTag'](_0x4970de,_0xa1414c);}['addTag'](_0x4274ad,_0x588f7f){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x20ede9=this['myIFrame']['doc']['createElement']('script');_0x20ede9['type']='text/javascript',_0x20ede9['async']=!0x0,_0x20ede9['src']=_0x4274ad,_0x20ede9['onload']=_0x20ede9['onreadystatechange']=function(){const _0x181169=_0x20ede9['readyState'];(!_0x181169||_0x181169==='loaded'||_0x181169==='complete')&&(_0x20ede9['onload']=_0x20ede9['onreadystatechange']=null,_0x20ede9['parentNode']&&_0x20ede9['parentNode']['removeChild'](_0x20ede9),_0x588f7f());},_0x20ede9['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x4274ad),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x20ede9);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x3c34fa,_0x195704,_0x7b1b8c,_0x13e452,_0x443e5e,_0x1cc93d,_0x23f033){this['connId']=_0x3c34fa,this['applicationId']=_0x7b1b8c,this['appCheckToken']=_0x13e452,this['authToken']=_0x443e5e,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x195704),this['connURL']=q['connectionURL_'](_0x195704,_0x1cc93d,_0x23f033,_0x13e452,_0x7b1b8c),this['nodeAdmin']=_0x195704['nodeAdmin'];}static['connectionURL_'](_0x2f8b05,_0x33dd41,_0xae45db,_0x1ad9c7,_0x565095){const _0x23d0e7={};return _0x23d0e7[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x23d0e7[ho]=uo),_0x33dd41&&(_0x23d0e7[lo]=_0x33dd41),_0xae45db&&(_0x23d0e7[po]=_0xae45db),_0x1ad9c7&&(_0x23d0e7[wi]=_0x1ad9c7),_0x565095&&(_0x23d0e7[_o]=_0x565095),vo(_0x2f8b05,go,_0x23d0e7);}['open'](_0x513678,_0x486bfe){this['onDisconnect']=_0x486bfe,this['onMessage']=_0x513678,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x3cf420;_c(),this['mySock']=new gn(this['connURL'],[],_0x3cf420);}catch(_0x34dab2){this['log_']('Error\x20instantiating\x20WebSocket.');const _0xbe143c=_0x34dab2['message']||_0x34dab2['data'];_0xbe143c&&this['log_'](_0xbe143c),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x19d8d7=>{this['handleIncomingFrame'](_0x19d8d7);},this['mySock']['onerror']=_0x3f1d50=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x35e274=_0x3f1d50['message']||_0x3f1d50['data'];_0x35e274&&this['log_'](_0x35e274),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0xec7f79=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x2406a5=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x33a1f1=navigator['userAgent']['match'](_0x2406a5);_0x33a1f1&&_0x33a1f1['length']>0x1&&parseFloat(_0x33a1f1[0x1])<4.4&&(_0xec7f79=!0x0);}return!_0xec7f79&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x5ac98b){if(this['frames']['push'](_0x5ac98b),this['frames']['length']===this['totalFrames']){const _0x2f301e=this['frames']['join']('');this['frames']=null;const _0x226c1f=Nt(_0x2f301e);this['onMessage'](_0x226c1f);}}['handleNewFrameCount_'](_0x1f676b){this['totalFrames']=_0x1f676b,this['frames']=[];}['extractFrameCount_'](_0x31341e){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x31341e['length']<=0x6){const _0x372122=Number(_0x31341e);if(!isNaN(_0x372122))return this['handleNewFrameCount_'](_0x372122),null;}return this['handleNewFrameCount_'](0x1),_0x31341e;}['handleIncomingFrame'](_0x48e995){if(this['mySock']===null)return;const _0x1047e7=_0x48e995['data'];if(this['bytesReceived']+=_0x1047e7['length'],this['stats_']['incrementCounter']('bytes_received',_0x1047e7['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x1047e7);else{const _0x404481=this['extractFrameCount_'](_0x1047e7);_0x404481!==null&&this['appendFrame_'](_0x404481);}}['send'](_0x141f42){this['resetKeepAlive']();const _0x5baf84=O(_0x141f42);this['bytesSent']+=_0x5baf84['length'],this['stats_']['incrementCounter']('bytes_sent',_0x5baf84['length']);const _0x2fe3e3=oo(_0x5baf84,gh);_0x2fe3e3['length']>0x1&&this['sendString_'](String(_0x2fe3e3['length']));for(let _0x59af0b=0x0;_0x59af0b<_0x2fe3e3['length'];_0x59af0b++)this['sendString_'](_0x2fe3e3[_0x59af0b]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x2c45f6){try{this['mySock']['send'](_0x2c45f6);}catch(_0x197f01){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x197f01['message']||_0x197f01['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x3e2371){this['initTransports_'](_0x3e2371);}['initTransports_'](_0x31ef26){const _0x29813b=q&&q['isAvailable']();let _0x38638c=_0x29813b&&!q['previouslyFailed']();if(_0x31ef26['webSocketOnly']&&(_0x29813b||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x38638c=!0x0),_0x38638c)this['transports_']=[q];else{const _0x239d48=this['transports_']=[];for(const _0x5035cc of Dt['ALL_TRANSPORTS'])_0x5035cc&&_0x5035cc['isAvailable']()&&_0x239d48['push'](_0x5035cc);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x429c45,_0x582e1b,_0x3e3e96,_0x151ea7,_0x1e56ee,_0x40bf39,_0xc59730,_0x35ad16,_0xf9114d,_0x1f88f2){this['id']=_0x429c45,this['repoInfo_']=_0x582e1b,this['applicationId_']=_0x3e3e96,this['appCheckToken_']=_0x151ea7,this['authToken_']=_0x1e56ee,this['onMessage_']=_0x40bf39,this['onReady_']=_0xc59730,this['onDisconnect_']=_0x35ad16,this['onKill_']=_0xf9114d,this['lastSessionId']=_0x1f88f2,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x582e1b),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x259336=this['transportManager_']['initialTransport']();this['conn_']=new _0x259336(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x259336['responsesRequiredToBeHealthy']||0x0;const _0x4a52be=this['connReceiver_'](this['conn_']),_0x544a6b=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x4a52be,_0x544a6b);},Math['floor'](0x0));const _0x5f303e=_0x259336['healthyTimeout']||0x0;_0x5f303e>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x5f303e)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x4a24d5){return _0x4a9c42=>{_0x4a24d5===this['conn_']?this['onConnectionLost_'](_0x4a9c42):_0x4a24d5===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x44d117){return _0x399dbb=>{this['state_']!==0x2&&(_0x44d117===this['rx_']?this['onPrimaryMessageReceived_'](_0x399dbb):_0x44d117===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x399dbb):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x119eaf){const _0x3c0ec4={'t':'d','d':_0x119eaf};this['sendData_'](_0x3c0ec4);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x5b4193){if(ci in _0x5b4193){const _0x8db077=_0x5b4193[ci];_0x8db077===Ys?this['upgradeIfSecondaryHealthy_']():_0x8db077===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x8db077===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x3a4283){const _0x5c2162=vt('t',_0x3a4283),_0x189f56=vt('d',_0x3a4283);if(_0x5c2162==='c')this['onSecondaryControl_'](_0x189f56);else{if(_0x5c2162==='d')this['pendingDataMessages']['push'](_0x189f56);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x5c2162);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x3efe4d){const _0x133fbf=vt('t',_0x3efe4d),_0x512c48=vt('d',_0x3efe4d);_0x133fbf==='c'?this['onControl_'](_0x512c48):_0x133fbf==='d'&&this['onDataMessage_'](_0x512c48);}['onDataMessage_'](_0x2128cb){this['onPrimaryResponse_'](),this['onMessage_'](_0x2128cb);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x30044d){const _0x331f95=vt(ci,_0x30044d);if(zs in _0x30044d){const _0x2e95ca=_0x30044d[zs];if(_0x331f95===Th){const _0x3431db={..._0x2e95ca};this['repoInfo_']['isUsingEmulator']&&(_0x3431db['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x3431db);}else{if(_0x331f95===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x429dc6=0x0;_0x429dc6<this['pendingDataMessages']['length'];++_0x429dc6)this['onDataMessage_'](this['pendingDataMessages'][_0x429dc6]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x331f95===wh?this['onConnectionShutdown_'](_0x2e95ca):_0x331f95===js?this['onReset_'](_0x2e95ca):_0x331f95===Ch?Ii('Server\x20Error:\x20'+_0x2e95ca):_0x331f95===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x331f95);}}}['onHandshake_'](_0x3ed136){const _0x431832=_0x3ed136['ts'],_0x21aa6d=_0x3ed136['v'],_0x46d533=_0x3ed136['h'];this['sessionId']=_0x3ed136['s'],this['repoInfo_']['host']=_0x46d533,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x431832),Gi!==_0x21aa6d&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x2353b8=this['transportManager_']['upgradeTransport']();_0x2353b8&&this['startUpgrade_'](_0x2353b8);}['startUpgrade_'](_0x52fd2a){this['secondaryConn_']=new _0x52fd2a(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x52fd2a['responsesRequiredToBeHealthy']||0x0;const _0x3e2b94=this['connReceiver_'](this['secondaryConn_']),_0x2d3891=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x3e2b94,_0x2d3891),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x56373a){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x56373a),this['repoInfo_']['host']=_0x56373a,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x1499f8,_0x49c0b9){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x1499f8,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x49c0b9,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x34373d=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x34373d||this['rx_']===_0x34373d)&&this['close']();}['onConnectionLost_'](_0x489821){this['conn_']=null,!_0x489821&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x34b516){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x34b516),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x1a3cc0){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x1a3cc0);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x1a0cec,_0x53eab3,_0x3878fb,_0x2208d5){}['merge'](_0x1c7619,_0x5ddf5d,_0x5609c6,_0x5a2834){}['refreshAuthToken'](_0x30f346){}['refreshAppCheckToken'](_0x1fd004){}['onDisconnectPut'](_0x18dd8a,_0x39011f,_0x359300){}['onDisconnectMerge'](_0x4150c1,_0x3ac525,_0x435400){}['onDisconnectCancel'](_0x573d97,_0x5241ff){}['reportStats'](_0x5bc9f8){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0xf66170){this['allowedEvents_']=_0xf66170,this['listeners_']={},f(Array['isArray'](_0xf66170)&&_0xf66170['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x271eff,..._0x3b95f7){if(Array['isArray'](this['listeners_'][_0x271eff])){const _0x339603=[...this['listeners_'][_0x271eff]];for(let _0x5ab4d8=0x0;_0x5ab4d8<_0x339603['length'];_0x5ab4d8++)_0x339603[_0x5ab4d8]['callback']['apply'](_0x339603[_0x5ab4d8]['context'],_0x3b95f7);}}['on'](_0x75bdd6,_0x5cd15d,_0x25114f){this['validateEventType_'](_0x75bdd6),this['listeners_'][_0x75bdd6]=this['listeners_'][_0x75bdd6]||[],this['listeners_'][_0x75bdd6]['push']({'callback':_0x5cd15d,'context':_0x25114f});const _0xde78ab=this['getInitialEvent'](_0x75bdd6);_0xde78ab&&_0x5cd15d['apply'](_0x25114f,_0xde78ab);}['off'](_0x40c99d,_0x216f09,_0x4defcb){this['validateEventType_'](_0x40c99d);const _0x2844dc=this['listeners_'][_0x40c99d]||[];for(let _0x471328=0x0;_0x471328<_0x2844dc['length'];_0x471328++)if(_0x2844dc[_0x471328]['callback']===_0x216f09&&(!_0x4defcb||_0x4defcb===_0x2844dc[_0x471328]['context'])){_0x2844dc['splice'](_0x471328,0x1);return;}}['validateEventType_'](_0x21a7cf){f(this['allowedEvents_']['find'](_0x32f127=>_0x32f127===_0x21a7cf),'Unknown\x20event:\x20'+_0x21a7cf);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x4d3080){return f(_0x4d3080==='online','Unknown\x20event\x20type:\x20'+_0x4d3080),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x440143,_0x5d3df0){if(_0x5d3df0===void 0x0){this['pieces_']=_0x440143['split']('/');let _0x29b5f9=0x0;for(let _0x139c55=0x0;_0x139c55<this['pieces_']['length'];_0x139c55++)this['pieces_'][_0x139c55]['length']>0x0&&(this['pieces_'][_0x29b5f9]=this['pieces_'][_0x139c55],_0x29b5f9++);this['pieces_']['length']=_0x29b5f9,this['pieceNum_']=0x0;}else this['pieces_']=_0x440143,this['pieceNum_']=_0x5d3df0;}['toString'](){let _0x105f5c='';for(let _0x4053b2=this['pieceNum_'];_0x4053b2<this['pieces_']['length'];_0x4053b2++)this['pieces_'][_0x4053b2]!==''&&(_0x105f5c+='/'+this['pieces_'][_0x4053b2]);return _0x105f5c||'/';}}function w(){return new C('');}function y(_0x49b2f5){return _0x49b2f5['pieceNum_']>=_0x49b2f5['pieces_']['length']?null:_0x49b2f5['pieces_'][_0x49b2f5['pieceNum_']];}function Ce(_0x41af62){return _0x41af62['pieces_']['length']-_0x41af62['pieceNum_'];}function S(_0x303350){let _0x24a7bd=_0x303350['pieceNum_'];return _0x24a7bd<_0x303350['pieces_']['length']&&_0x24a7bd++,new C(_0x303350['pieces_'],_0x24a7bd);}function ji(_0x3de9fa){return _0x3de9fa['pieceNum_']<_0x3de9fa['pieces_']['length']?_0x3de9fa['pieces_'][_0x3de9fa['pieces_']['length']-0x1]:null;}function bh(_0x569eee){let _0x67378a='';for(let _0x54e5be=_0x569eee['pieceNum_'];_0x54e5be<_0x569eee['pieces_']['length'];_0x54e5be++)_0x569eee['pieces_'][_0x54e5be]!==''&&(_0x67378a+='/'+encodeURIComponent(String(_0x569eee['pieces_'][_0x54e5be])));return _0x67378a||'/';}function Mt(_0x547721,_0x23a8cd=0x0){return _0x547721['pieces_']['slice'](_0x547721['pieceNum_']+_0x23a8cd);}function Ro(_0x3ca89c){if(_0x3ca89c['pieceNum_']>=_0x3ca89c['pieces_']['length'])return null;const _0x509691=[];for(let _0x38cbb3=_0x3ca89c['pieceNum_'];_0x38cbb3<_0x3ca89c['pieces_']['length']-0x1;_0x38cbb3++)_0x509691['push'](_0x3ca89c['pieces_'][_0x38cbb3]);return new C(_0x509691,0x0);}function k(_0x386f59,_0x56fdf3){const _0x3bf35f=[];for(let _0x40a60b=_0x386f59['pieceNum_'];_0x40a60b<_0x386f59['pieces_']['length'];_0x40a60b++)_0x3bf35f['push'](_0x386f59['pieces_'][_0x40a60b]);if(_0x56fdf3 instanceof C){for(let _0x4af971=_0x56fdf3['pieceNum_'];_0x4af971<_0x56fdf3['pieces_']['length'];_0x4af971++)_0x3bf35f['push'](_0x56fdf3['pieces_'][_0x4af971]);}else{const _0x4786c2=_0x56fdf3['split']('/');for(let _0x483783=0x0;_0x483783<_0x4786c2['length'];_0x483783++)_0x4786c2[_0x483783]['length']>0x0&&_0x3bf35f['push'](_0x4786c2[_0x483783]);}return new C(_0x3bf35f,0x0);}function v(_0x3bd4b2){return _0x3bd4b2['pieceNum_']>=_0x3bd4b2['pieces_']['length'];}function F(_0x53a1db,_0x593f73){const _0x350b9e=y(_0x53a1db),_0x6e4757=y(_0x593f73);if(_0x350b9e===null)return _0x593f73;if(_0x350b9e===_0x6e4757)return F(S(_0x53a1db),S(_0x593f73));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x593f73+')\x20is\x20not\x20within\x20outerPath\x20('+_0x53a1db+')');}function Rh(_0x37c8f3,_0x494000){const _0x5f8683=Mt(_0x37c8f3,0x0),_0x4288ff=Mt(_0x494000,0x0);for(let _0x46a82a=0x0;_0x46a82a<_0x5f8683['length']&&_0x46a82a<_0x4288ff['length'];_0x46a82a++){const _0xe8d859=qe(_0x5f8683[_0x46a82a],_0x4288ff[_0x46a82a]);if(_0xe8d859!==0x0)return _0xe8d859;}return _0x5f8683['length']===_0x4288ff['length']?0x0:_0x5f8683['length']<_0x4288ff['length']?-0x1:0x1;}function Ki(_0x123516,_0x30a66c){if(Ce(_0x123516)!==Ce(_0x30a66c))return!0x1;for(let _0x2d97f2=_0x123516['pieceNum_'],_0x20e2be=_0x30a66c['pieceNum_'];_0x2d97f2<=_0x123516['pieces_']['length'];_0x2d97f2++,_0x20e2be++)if(_0x123516['pieces_'][_0x2d97f2]!==_0x30a66c['pieces_'][_0x20e2be])return!0x1;return!0x0;}function G(_0x391478,_0x2ab478){let _0x4be9f9=_0x391478['pieceNum_'],_0x166ce3=_0x2ab478['pieceNum_'];if(Ce(_0x391478)>Ce(_0x2ab478))return!0x1;for(;_0x4be9f9<_0x391478['pieces_']['length'];){if(_0x391478['pieces_'][_0x4be9f9]!==_0x2ab478['pieces_'][_0x166ce3])return!0x1;++_0x4be9f9,++_0x166ce3;}return!0x0;}class Ah{constructor(_0x12a530,_0x31d350){this['errorPrefix_']=_0x31d350,this['parts_']=Mt(_0x12a530,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x2db235=0x0;_0x2db235<this['parts_']['length'];_0x2db235++)this['byteLength_']+=Ln(this['parts_'][_0x2db235]);Ao(this);}}function kh(_0x4cfdc9,_0x17a0e5){_0x4cfdc9['parts_']['length']>0x0&&(_0x4cfdc9['byteLength_']+=0x1),_0x4cfdc9['parts_']['push'](_0x17a0e5),_0x4cfdc9['byteLength_']+=Ln(_0x17a0e5),Ao(_0x4cfdc9);}function Ph(_0x42d40d){const _0x4be180=_0x42d40d['parts_']['pop']();_0x42d40d['byteLength_']-=Ln(_0x4be180),_0x42d40d['parts_']['length']>0x0&&(_0x42d40d['byteLength_']-=0x1);}function Ao(_0x2e97ae){if(_0x2e97ae['byteLength_']>Zs)throw new Error(_0x2e97ae['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x2e97ae['byteLength_']+').');if(_0x2e97ae['parts_']['length']>Xs)throw new Error(_0x2e97ae['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x2e97ae));}function Oe(_0x3eeec7){return _0x3eeec7['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x3eeec7['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x2e1730,_0x162085;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x162085='visibilitychange',_0x2e1730='hidden'):typeof document['mozHidden']<'u'?(_0x162085='mozvisibilitychange',_0x2e1730='mozHidden'):typeof document['msHidden']<'u'?(_0x162085='msvisibilitychange',_0x2e1730='msHidden'):typeof document['webkitHidden']<'u'&&(_0x162085='webkitvisibilitychange',_0x2e1730='webkitHidden')),this['visible_']=!0x0,_0x162085&&document['addEventListener'](_0x162085,()=>{const _0x5f26ea=!document[_0x2e1730];_0x5f26ea!==this['visible_']&&(this['visible_']=_0x5f26ea,this['trigger']('visible',_0x5f26ea));},!0x1);}['getInitialEvent'](_0x2e55b2){return f(_0x2e55b2==='visible','Unknown\x20event\x20type:\x20'+_0x2e55b2),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x3603b4,_0x46babd,_0x2d17bb,_0x339ba4,_0xa6ef27,_0x3340b1,_0x4d920b,_0x18e98e){if(super(),this['repoInfo_']=_0x3603b4,this['applicationId_']=_0x46babd,this['onDataUpdate_']=_0x2d17bb,this['onConnectStatus_']=_0x339ba4,this['onServerInfoUpdate_']=_0xa6ef27,this['authTokenProvider_']=_0x3340b1,this['appCheckTokenProvider_']=_0x4d920b,this['authOverride_']=_0x18e98e,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x18e98e)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x3603b4['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x2f283f,_0x30f9b0,_0x3a341e){const _0x390cbf=++this['requestNumber_'],_0x4d0af8={'r':_0x390cbf,'a':_0x2f283f,'b':_0x30f9b0};this['log_'](O(_0x4d0af8)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x4d0af8),_0x3a341e&&(this['requestCBHash_'][_0x390cbf]=_0x3a341e);}['get'](_0x317c6a){this['initConnection_']();const _0x20ccbe=new H(),_0x4a75a4={'action':'g','request':{'p':_0x317c6a['_path']['toString'](),'q':_0x317c6a['_queryObject']},'onComplete':_0x41b8a6=>{const _0x2d5c4c=_0x41b8a6['d'];_0x41b8a6['s']==='ok'?_0x20ccbe['resolve'](_0x2d5c4c):_0x20ccbe['reject'](_0x2d5c4c);}};this['outstandingGets_']['push'](_0x4a75a4),this['outstandingGetCount_']++;const _0x32c346=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x32c346),_0x20ccbe['promise'];}['listen'](_0x580473,_0x11d9a0,_0x2021c1,_0x2acc60){this['initConnection_']();const _0x5e344d=_0x580473['_queryIdentifier'],_0x5170af=_0x580473['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x5170af+'\x20'+_0x5e344d),this['listens']['has'](_0x5170af)||this['listens']['set'](_0x5170af,new Map()),f(_0x580473['_queryParams']['isDefault']()||!_0x580473['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x5170af)['has'](_0x5e344d),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x5162dd={'onComplete':_0x2acc60,'hashFn':_0x11d9a0,'query':_0x580473,'tag':_0x2021c1};this['listens']['get'](_0x5170af)['set'](_0x5e344d,_0x5162dd),this['connected_']&&this['sendListen_'](_0x5162dd);}['sendGet_'](_0x56e339){const _0x565eb4=this['outstandingGets_'][_0x56e339];this['sendRequest']('g',_0x565eb4['request'],_0x36fcc0=>{delete this['outstandingGets_'][_0x56e339],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x565eb4['onComplete']&&_0x565eb4['onComplete'](_0x36fcc0);});}['sendListen_'](_0x5e3254){const _0x1311eb=_0x5e3254['query'],_0x39b112=_0x1311eb['_path']['toString'](),_0x2aa224=_0x1311eb['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x39b112+'\x20for\x20'+_0x2aa224);const _0x155e94={'p':_0x39b112},_0x4ebe34='q';_0x5e3254['tag']&&(_0x155e94['q']=_0x1311eb['_queryObject'],_0x155e94['t']=_0x5e3254['tag']),_0x155e94['h']=_0x5e3254['hashFn'](),this['sendRequest'](_0x4ebe34,_0x155e94,_0x45a662=>{const _0xe327a5=_0x45a662['d'],_0x500475=_0x45a662['s'];se['warnOnListenWarnings_'](_0xe327a5,_0x1311eb),(this['listens']['get'](_0x39b112)&&this['listens']['get'](_0x39b112)['get'](_0x2aa224))===_0x5e3254&&(this['log_']('listen\x20response',_0x45a662),_0x500475!=='ok'&&this['removeListen_'](_0x39b112,_0x2aa224),_0x5e3254['onComplete']&&_0x5e3254['onComplete'](_0x500475,_0xe327a5));});}static['warnOnListenWarnings_'](_0x26b2ed,_0xaa3560){if(_0x26b2ed&&typeof _0x26b2ed=='object'&&Q(_0x26b2ed,'w')){const _0x21045b=Le(_0x26b2ed,'w');if(Array['isArray'](_0x21045b)&&~_0x21045b['indexOf']('no_index')){const _0x2c0e1b='\x22.indexOn\x22:\x20\x22'+_0xaa3560['_queryParams']['getIndex']()['toString']()+'\x22',_0x2f6a09=_0xaa3560['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x2c0e1b+'\x20at\x20'+_0x2f6a09+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x231a4b){this['authToken_']=_0x231a4b,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x231a4b);}['reduceReconnectDelayIfAdminCredential_'](_0x3abbc9){(_0x3abbc9&&_0x3abbc9['length']===0x28||wc(_0x3abbc9))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x41c75a){this['appCheckToken_']=_0x41c75a,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x496cd3=this['authToken_'],_0x15f9d4=Ic(_0x496cd3)?'auth':'gauth',_0x553926={'cred':_0x496cd3};this['authOverride_']===null?_0x553926['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x553926['authvar']=this['authOverride_']),this['sendRequest'](_0x15f9d4,_0x553926,_0x49a304=>{const _0x58774f=_0x49a304['s'],_0x3801e3=_0x49a304['d']||'error';this['authToken_']===_0x496cd3&&(_0x58774f==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x58774f,_0x3801e3));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x2b24d6=>{const _0x426493=_0x2b24d6['s'],_0x57d7d6=_0x2b24d6['d']||'error';_0x426493==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x426493,_0x57d7d6);});}['unlisten'](_0x2461d6,_0x2bf1d1){const _0x301723=_0x2461d6['_path']['toString'](),_0x13d9fd=_0x2461d6['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x301723+'\x20'+_0x13d9fd),f(_0x2461d6['_queryParams']['isDefault']()||!_0x2461d6['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x301723,_0x13d9fd)&&this['connected_']&&this['sendUnlisten_'](_0x301723,_0x13d9fd,_0x2461d6['_queryObject'],_0x2bf1d1);}['sendUnlisten_'](_0x337c92,_0x1c40c0,_0x5daae3,_0x3a05af){this['log_']('Unlisten\x20on\x20'+_0x337c92+'\x20for\x20'+_0x1c40c0);const _0x5134b6={'p':_0x337c92},_0x428b74='n';_0x3a05af&&(_0x5134b6['q']=_0x5daae3,_0x5134b6['t']=_0x3a05af),this['sendRequest'](_0x428b74,_0x5134b6);}['onDisconnectPut'](_0x4bd265,_0x283e46,_0x34b96c){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x4bd265,_0x283e46,_0x34b96c):this['onDisconnectRequestQueue_']['push']({'pathString':_0x4bd265,'action':'o','data':_0x283e46,'onComplete':_0x34b96c});}['onDisconnectMerge'](_0x571c0c,_0x2752a7,_0x5bff01){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x571c0c,_0x2752a7,_0x5bff01):this['onDisconnectRequestQueue_']['push']({'pathString':_0x571c0c,'action':'om','data':_0x2752a7,'onComplete':_0x5bff01});}['onDisconnectCancel'](_0x1f4f74,_0x57258d){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x1f4f74,null,_0x57258d):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1f4f74,'action':'oc','data':null,'onComplete':_0x57258d});}['sendOnDisconnect_'](_0x1e09c9,_0x4d1070,_0x3ae7a4,_0x134d01){const _0x3870ca={'p':_0x4d1070,'d':_0x3ae7a4};this['log_']('onDisconnect\x20'+_0x1e09c9,_0x3870ca),this['sendRequest'](_0x1e09c9,_0x3870ca,_0x59d441=>{_0x134d01&&setTimeout(()=>{_0x134d01(_0x59d441['s'],_0x59d441['d']);},Math['floor'](0x0));});}['put'](_0x5618be,_0x2ca716,_0x134e11,_0x164dbb){this['putInternal']('p',_0x5618be,_0x2ca716,_0x134e11,_0x164dbb);}['merge'](_0x35e6e4,_0x21005b,_0x5706b4,_0x3c2b13){this['putInternal']('m',_0x35e6e4,_0x21005b,_0x5706b4,_0x3c2b13);}['putInternal'](_0x344491,_0x5de497,_0x1c1256,_0x3c97bd,_0x401fcb){this['initConnection_']();const _0x58ea72={'p':_0x5de497,'d':_0x1c1256};_0x401fcb!==void 0x0&&(_0x58ea72['h']=_0x401fcb),this['outstandingPuts_']['push']({'action':_0x344491,'request':_0x58ea72,'onComplete':_0x3c97bd}),this['outstandingPutCount_']++;const _0x48daac=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x48daac):this['log_']('Buffering\x20put:\x20'+_0x5de497);}['sendPut_'](_0x27d5c9){const _0x853469=this['outstandingPuts_'][_0x27d5c9]['action'],_0x41341d=this['outstandingPuts_'][_0x27d5c9]['request'],_0x4e4608=this['outstandingPuts_'][_0x27d5c9]['onComplete'];this['outstandingPuts_'][_0x27d5c9]['queued']=this['connected_'],this['sendRequest'](_0x853469,_0x41341d,_0x1f75e4=>{this['log_'](_0x853469+'\x20response',_0x1f75e4),delete this['outstandingPuts_'][_0x27d5c9],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x4e4608&&_0x4e4608(_0x1f75e4['s'],_0x1f75e4['d']);});}['reportStats'](_0x1f7f53){if(this['connected_']){const _0x5ad812={'c':_0x1f7f53};this['log_']('reportStats',_0x5ad812),this['sendRequest']('s',_0x5ad812,_0x5ba3ea=>{if(_0x5ba3ea['s']!=='ok'){const _0x185e85=_0x5ba3ea['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x185e85);}});}}['onDataMessage_'](_0xd65988){if('r'in _0xd65988){this['log_']('from\x20server:\x20'+O(_0xd65988));const _0x581d17=_0xd65988['r'],_0x3752e4=this['requestCBHash_'][_0x581d17];_0x3752e4&&(delete this['requestCBHash_'][_0x581d17],_0x3752e4(_0xd65988['b']));}else{if('error'in _0xd65988)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0xd65988['error'];'a'in _0xd65988&&this['onDataPush_'](_0xd65988['a'],_0xd65988['b']);}}['onDataPush_'](_0x2b03dc,_0x4d62ac){this['log_']('handleServerMessage',_0x2b03dc,_0x4d62ac),_0x2b03dc==='d'?this['onDataUpdate_'](_0x4d62ac['p'],_0x4d62ac['d'],!0x1,_0x4d62ac['t']):_0x2b03dc==='m'?this['onDataUpdate_'](_0x4d62ac['p'],_0x4d62ac['d'],!0x0,_0x4d62ac['t']):_0x2b03dc==='c'?this['onListenRevoked_'](_0x4d62ac['p'],_0x4d62ac['q']):_0x2b03dc==='ac'?this['onAuthRevoked_'](_0x4d62ac['s'],_0x4d62ac['d']):_0x2b03dc==='apc'?this['onAppCheckRevoked_'](_0x4d62ac['s'],_0x4d62ac['d']):_0x2b03dc==='sd'?this['onSecurityDebugPacket_'](_0x4d62ac):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x2b03dc)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x1e7c4a,_0x5c0862){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x1e7c4a),this['lastSessionId']=_0x5c0862,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x5ce9e2){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x5ce9e2));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x506885){_0x506885&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x506885;}['onOnline_'](_0x1143ea){_0x1143ea?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x479c31=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x43245c=Math['max'](0x0,this['reconnectDelay_']-_0x479c31);_0x43245c=Math['random']()*_0x43245c,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x43245c+'ms'),this['scheduleConnect_'](_0x43245c),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x37ebdb=this['onDataMessage_']['bind'](this),_0x3ed18c=this['onReady_']['bind'](this),_0x57185d=this['onRealtimeDisconnect_']['bind'](this),_0x12d977=this['id']+':'+se['nextConnectionId_']++,_0x576606=this['lastSessionId'];let _0x1f8df3=!0x1,_0x5e965f=null;const _0x7d955=function(){_0x5e965f?_0x5e965f['close']():(_0x1f8df3=!0x0,_0x57185d());},_0x221df0=function(_0x20793c){f(_0x5e965f,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x5e965f['sendRequest'](_0x20793c);};this['realtime_']={'close':_0x7d955,'sendRequest':_0x221df0};const _0x28bd9b=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x8661b7,_0x54257e]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x28bd9b),this['appCheckTokenProvider_']['getToken'](_0x28bd9b)]);_0x1f8df3?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x8661b7&&_0x8661b7['accessToken'],this['appCheckToken_']=_0x54257e&&_0x54257e['token'],_0x5e965f=new Sh(_0x12d977,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x37ebdb,_0x3ed18c,_0x57185d,_0x5bcd10=>{U(_0x5bcd10+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x576606));}catch(_0x48fb3e){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x48fb3e),_0x1f8df3||(this['repoInfo_']['nodeAdmin']&&U(_0x48fb3e),_0x7d955());}}}['interrupt'](_0x394fd8){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x394fd8),this['interruptReasons_'][_0x394fd8]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x3894f6){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x3894f6),delete this['interruptReasons_'][_0x3894f6],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x33fac0){const _0x5aca58=_0x33fac0-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x5aca58});}['cancelSentTransactions_'](){for(let _0x2ac2a4=0x0;_0x2ac2a4<this['outstandingPuts_']['length'];_0x2ac2a4++){const _0x2e7735=this['outstandingPuts_'][_0x2ac2a4];_0x2e7735&&'h'in _0x2e7735['request']&&_0x2e7735['queued']&&(_0x2e7735['onComplete']&&_0x2e7735['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x2ac2a4],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x7e1369,_0x37ae61){let _0x344188;_0x37ae61?_0x344188=_0x37ae61['map'](_0x213fc7=>$i(_0x213fc7))['join']('$'):_0x344188='default';const _0x1c4e04=this['removeListen_'](_0x7e1369,_0x344188);_0x1c4e04&&_0x1c4e04['onComplete']&&_0x1c4e04['onComplete']('permission_denied');}['removeListen_'](_0x5e6e22,_0x1f4df1){const _0x37de78=new C(_0x5e6e22)['toString']();let _0x3a69e2;if(this['listens']['has'](_0x37de78)){const _0x4397eb=this['listens']['get'](_0x37de78);_0x3a69e2=_0x4397eb['get'](_0x1f4df1),_0x4397eb['delete'](_0x1f4df1),_0x4397eb['size']===0x0&&this['listens']['delete'](_0x37de78);}else _0x3a69e2=void 0x0;return _0x3a69e2;}['onAuthRevoked_'](_0x139c07,_0x4b3492){L('Auth\x20token\x20revoked:\x20'+_0x139c07+'/'+_0x4b3492),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x139c07==='invalid_token'||_0x139c07==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x14dec7,_0x49ae31){L('App\x20check\x20token\x20revoked:\x20'+_0x14dec7+'/'+_0x49ae31),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x14dec7==='invalid_token'||_0x14dec7==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x32ed2c){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x32ed2c):'msg'in _0x32ed2c&&console['log']('FIREBASE:\x20'+_0x32ed2c['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x2a7315 of this['listens']['values']())for(const _0x1956f1 of _0x2a7315['values']())this['sendListen_'](_0x1956f1);for(let _0x5d47d0=0x0;_0x5d47d0<this['outstandingPuts_']['length'];_0x5d47d0++)this['outstandingPuts_'][_0x5d47d0]&&this['sendPut_'](_0x5d47d0);for(;this['onDisconnectRequestQueue_']['length'];){const _0x160266=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x160266['action'],_0x160266['pathString'],_0x160266['data'],_0x160266['onComplete']);}for(let _0x3af331=0x0;_0x3af331<this['outstandingGets_']['length'];_0x3af331++)this['outstandingGets_'][_0x3af331]&&this['sendGet_'](_0x3af331);}['sendConnectStats_'](){const _0x11d716={};let _0x3d6fb4='js';_0x11d716['sdk.'+_0x3d6fb4+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x11d716['framework.cordova']=0x1:Kr()&&(_0x11d716['framework.reactnative']=0x1),this['reportStats'](_0x11d716);}['shouldReconnect_'](){const _0x422d26=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x422d26;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x3d111c,_0x57e10a){this['name']=_0x3d111c,this['node']=_0x57e10a;}static['Wrap'](_0x126fc9,_0x4a0c10){return new E(_0x126fc9,_0x4a0c10);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x1d5f9c,_0x5f05dc){const _0x1c4e69=new E(We,_0x1d5f9c),_0x1b5d53=new E(We,_0x5f05dc);return this['compare'](_0x1c4e69,_0x1b5d53)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x40a52b){sn=_0x40a52b;}['compare'](_0x54b91d,_0x5461dc){return qe(_0x54b91d['name'],_0x5461dc['name']);}['isDefinedOn'](_0x976ab5){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x446921,_0x4a2ba0){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x58b70f,_0x48f01b){return f(typeof _0x58b70f=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x58b70f,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x33a556,_0x245512,_0x43231a,_0x4149f5,_0x2bab69=null){this['isReverse_']=_0x4149f5,this['resultGenerator_']=_0x2bab69,this['nodeStack_']=[];let _0x315b62=0x1;for(;!_0x33a556['isEmpty']();)if(_0x33a556=_0x33a556,_0x315b62=_0x245512?_0x43231a(_0x33a556['key'],_0x245512):0x1,_0x4149f5&&(_0x315b62*=-0x1),_0x315b62<0x0)this['isReverse_']?_0x33a556=_0x33a556['left']:_0x33a556=_0x33a556['right'];else{if(_0x315b62===0x0){this['nodeStack_']['push'](_0x33a556);break;}else this['nodeStack_']['push'](_0x33a556),this['isReverse_']?_0x33a556=_0x33a556['right']:_0x33a556=_0x33a556['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x4b6cd0=this['nodeStack_']['pop'](),_0x2b15ef;if(this['resultGenerator_']?_0x2b15ef=this['resultGenerator_'](_0x4b6cd0['key'],_0x4b6cd0['value']):_0x2b15ef={'key':_0x4b6cd0['key'],'value':_0x4b6cd0['value']},this['isReverse_']){for(_0x4b6cd0=_0x4b6cd0['left'];!_0x4b6cd0['isEmpty']();)this['nodeStack_']['push'](_0x4b6cd0),_0x4b6cd0=_0x4b6cd0['right'];}else{for(_0x4b6cd0=_0x4b6cd0['right'];!_0x4b6cd0['isEmpty']();)this['nodeStack_']['push'](_0x4b6cd0),_0x4b6cd0=_0x4b6cd0['left'];}return _0x2b15ef;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x5f5c98=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x5f5c98['key'],_0x5f5c98['value']):{'key':_0x5f5c98['key'],'value':_0x5f5c98['value']};}}class M{constructor(_0x19f553,_0x18c5bc,_0x1f1377,_0x31f60e,_0x386a40){this['key']=_0x19f553,this['value']=_0x18c5bc,this['color']=_0x1f1377??M['RED'],this['left']=_0x31f60e??B['EMPTY_NODE'],this['right']=_0x386a40??B['EMPTY_NODE'];}['copy'](_0xe2075b,_0x9bab29,_0x43de21,_0x4b340a,_0x27cf0f){return new M(_0xe2075b??this['key'],_0x9bab29??this['value'],_0x43de21??this['color'],_0x4b340a??this['left'],_0x27cf0f??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x17811e){return this['left']['inorderTraversal'](_0x17811e)||!!_0x17811e(this['key'],this['value'])||this['right']['inorderTraversal'](_0x17811e);}['reverseTraversal'](_0xbb9c2a){return this['right']['reverseTraversal'](_0xbb9c2a)||_0xbb9c2a(this['key'],this['value'])||this['left']['reverseTraversal'](_0xbb9c2a);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x38aaf3,_0x1964ef,_0x3d614e){let _0x3d5ad8=this;const _0x16055b=_0x3d614e(_0x38aaf3,_0x3d5ad8['key']);return _0x16055b<0x0?_0x3d5ad8=_0x3d5ad8['copy'](null,null,null,_0x3d5ad8['left']['insert'](_0x38aaf3,_0x1964ef,_0x3d614e),null):_0x16055b===0x0?_0x3d5ad8=_0x3d5ad8['copy'](null,_0x1964ef,null,null,null):_0x3d5ad8=_0x3d5ad8['copy'](null,null,null,null,_0x3d5ad8['right']['insert'](_0x38aaf3,_0x1964ef,_0x3d614e)),_0x3d5ad8['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x6c308a=this;return!_0x6c308a['left']['isRed_']()&&!_0x6c308a['left']['left']['isRed_']()&&(_0x6c308a=_0x6c308a['moveRedLeft_']()),_0x6c308a=_0x6c308a['copy'](null,null,null,_0x6c308a['left']['removeMin_'](),null),_0x6c308a['fixUp_']();}['remove'](_0x18c5ee,_0x5b450f){let _0x2ed22d,_0x516498;if(_0x2ed22d=this,_0x5b450f(_0x18c5ee,_0x2ed22d['key'])<0x0)!_0x2ed22d['left']['isEmpty']()&&!_0x2ed22d['left']['isRed_']()&&!_0x2ed22d['left']['left']['isRed_']()&&(_0x2ed22d=_0x2ed22d['moveRedLeft_']()),_0x2ed22d=_0x2ed22d['copy'](null,null,null,_0x2ed22d['left']['remove'](_0x18c5ee,_0x5b450f),null);else{if(_0x2ed22d['left']['isRed_']()&&(_0x2ed22d=_0x2ed22d['rotateRight_']()),!_0x2ed22d['right']['isEmpty']()&&!_0x2ed22d['right']['isRed_']()&&!_0x2ed22d['right']['left']['isRed_']()&&(_0x2ed22d=_0x2ed22d['moveRedRight_']()),_0x5b450f(_0x18c5ee,_0x2ed22d['key'])===0x0){if(_0x2ed22d['right']['isEmpty']())return B['EMPTY_NODE'];_0x516498=_0x2ed22d['right']['min_'](),_0x2ed22d=_0x2ed22d['copy'](_0x516498['key'],_0x516498['value'],null,null,_0x2ed22d['right']['removeMin_']());}_0x2ed22d=_0x2ed22d['copy'](null,null,null,null,_0x2ed22d['right']['remove'](_0x18c5ee,_0x5b450f));}return _0x2ed22d['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x4573e1=this;return _0x4573e1['right']['isRed_']()&&!_0x4573e1['left']['isRed_']()&&(_0x4573e1=_0x4573e1['rotateLeft_']()),_0x4573e1['left']['isRed_']()&&_0x4573e1['left']['left']['isRed_']()&&(_0x4573e1=_0x4573e1['rotateRight_']()),_0x4573e1['left']['isRed_']()&&_0x4573e1['right']['isRed_']()&&(_0x4573e1=_0x4573e1['colorFlip_']()),_0x4573e1;}['moveRedLeft_'](){let _0x2b3535=this['colorFlip_']();return _0x2b3535['right']['left']['isRed_']()&&(_0x2b3535=_0x2b3535['copy'](null,null,null,null,_0x2b3535['right']['rotateRight_']()),_0x2b3535=_0x2b3535['rotateLeft_'](),_0x2b3535=_0x2b3535['colorFlip_']()),_0x2b3535;}['moveRedRight_'](){let _0x39713a=this['colorFlip_']();return _0x39713a['left']['left']['isRed_']()&&(_0x39713a=_0x39713a['rotateRight_'](),_0x39713a=_0x39713a['colorFlip_']()),_0x39713a;}['rotateLeft_'](){const _0x7d250f=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x7d250f,null);}['rotateRight_'](){const _0x5e9e12=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x5e9e12);}['colorFlip_'](){const _0x4b9345=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x4d85cf=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x4b9345,_0x4d85cf);}['checkMaxDepth_'](){const _0x545cd4=this['check_']();return Math['pow'](0x2,_0x545cd4)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x43139e=this['left']['check_']();if(_0x43139e!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x43139e+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x4eaf2a,_0x5e6dc4,_0x36b39b,_0xf1d5d4,_0xb88d60){return this;}['insert'](_0x55647d,_0x2ffb71,_0x38a042){return new M(_0x55647d,_0x2ffb71,null);}['remove'](_0x203c27,_0x10f706){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x16b76b){return!0x1;}['reverseTraversal'](_0x311761){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x391821,_0x45116e=B['EMPTY_NODE']){this['comparator_']=_0x391821,this['root_']=_0x45116e;}['insert'](_0x5d4327,_0x1d3bf4){return new B(this['comparator_'],this['root_']['insert'](_0x5d4327,_0x1d3bf4,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x541ae4){return new B(this['comparator_'],this['root_']['remove'](_0x541ae4,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0xb88957){let _0x1e8888,_0x4b6563=this['root_'];for(;!_0x4b6563['isEmpty']();){if(_0x1e8888=this['comparator_'](_0xb88957,_0x4b6563['key']),_0x1e8888===0x0)return _0x4b6563['value'];_0x1e8888<0x0?_0x4b6563=_0x4b6563['left']:_0x1e8888>0x0&&(_0x4b6563=_0x4b6563['right']);}return null;}['getPredecessorKey'](_0x19cf49){let _0x1a4a86,_0x5d4693=this['root_'],_0x79dfae=null;for(;!_0x5d4693['isEmpty']();)if(_0x1a4a86=this['comparator_'](_0x19cf49,_0x5d4693['key']),_0x1a4a86===0x0){if(_0x5d4693['left']['isEmpty']())return _0x79dfae?_0x79dfae['key']:null;for(_0x5d4693=_0x5d4693['left'];!_0x5d4693['right']['isEmpty']();)_0x5d4693=_0x5d4693['right'];return _0x5d4693['key'];}else _0x1a4a86<0x0?_0x5d4693=_0x5d4693['left']:_0x1a4a86>0x0&&(_0x79dfae=_0x5d4693,_0x5d4693=_0x5d4693['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x4da01b){return this['root_']['inorderTraversal'](_0x4da01b);}['reverseTraversal'](_0x2b7d0e){return this['root_']['reverseTraversal'](_0x2b7d0e);}['getIterator'](_0x120e95){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x120e95);}['getIteratorFrom'](_0x6d7154,_0x2b14e5){return new rn(this['root_'],_0x6d7154,this['comparator_'],!0x1,_0x2b14e5);}['getReverseIteratorFrom'](_0x27c66f,_0x1b0631){return new rn(this['root_'],_0x27c66f,this['comparator_'],!0x0,_0x1b0631);}['getReverseIterator'](_0x5847ee){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x5847ee);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x13795d,_0x4d49ce){return qe(_0x13795d['name'],_0x4d49ce['name']);}function Qi(_0x42fdc4,_0x166773){return qe(_0x42fdc4,_0x166773);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x44730e){Ci=_0x44730e;}const Po=function(_0xcb9952){return typeof _0xcb9952=='number'?'number:'+ao(_0xcb9952):'string:'+_0xcb9952;},No=function(_0x5f56e8){if(_0x5f56e8['isLeafNode']()){const _0x54d657=_0x5f56e8['val']();f(typeof _0x54d657=='string'||typeof _0x54d657=='number'||typeof _0x54d657=='object'&&Q(_0x54d657,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x5f56e8===Ci||_0x5f56e8['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x5f56e8===Ci||_0x5f56e8['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x14984a){nr=_0x14984a;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0xd0bbbb,_0x228447=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0xd0bbbb,this['priorityNode_']=_0x228447,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x131d5f){return new D(this['value_'],_0x131d5f);}['getImmediateChild'](_0x2fbaac){return _0x2fbaac==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x4cd95c){return v(_0x4cd95c)?this:y(_0x4cd95c)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x5de6d9,_0x167d72){return null;}['updateImmediateChild'](_0x240991,_0x43953d){return _0x240991==='.priority'?this['updatePriority'](_0x43953d):_0x43953d['isEmpty']()&&_0x240991!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x240991,_0x43953d)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x1abe31,_0x374dd0){const _0x96729a=y(_0x1abe31);return _0x96729a===null?_0x374dd0:_0x374dd0['isEmpty']()&&_0x96729a!=='.priority'?this:(f(_0x96729a!=='.priority'||Ce(_0x1abe31)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x96729a,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x1abe31),_0x374dd0)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x5d4585,_0x3f20f6){return!0x1;}['val'](_0x876ea9){return _0x876ea9&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x1323b5='';this['priorityNode_']['isEmpty']()||(_0x1323b5+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x3b99c3=typeof this['value_'];_0x1323b5+=_0x3b99c3+':',_0x3b99c3==='number'?_0x1323b5+=ao(this['value_']):_0x1323b5+=this['value_'],this['lazyHash_']=ro(_0x1323b5);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x3d1ecf){return _0x3d1ecf===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x3d1ecf instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x3d1ecf['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x3d1ecf));}['compareToLeafNode_'](_0x4214f9){const _0x462a62=typeof _0x4214f9['value_'],_0x1c9c71=typeof this['value_'],_0x460a7f=D['VALUE_TYPE_ORDER']['indexOf'](_0x462a62),_0x42213b=D['VALUE_TYPE_ORDER']['indexOf'](_0x1c9c71);return f(_0x460a7f>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x462a62),f(_0x42213b>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x1c9c71),_0x460a7f===_0x42213b?_0x1c9c71==='object'?0x0:this['value_']<_0x4214f9['value_']?-0x1:this['value_']===_0x4214f9['value_']?0x0:0x1:_0x42213b-_0x460a7f;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x5058a2){if(_0x5058a2===this)return!0x0;if(_0x5058a2['isLeafNode']()){const _0x3212de=_0x5058a2;return this['value_']===_0x3212de['value_']&&this['priorityNode_']['equals'](_0x3212de['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x2966d3){Oo=_0x2966d3;}function Wh(_0x5bb3ce){Do=_0x5bb3ce;}class Bh extends Fn{['compare'](_0x123aa0,_0x179924){const _0x10e677=_0x123aa0['node']['getPriority'](),_0x2746cb=_0x179924['node']['getPriority'](),_0x2c8151=_0x10e677['compareTo'](_0x2746cb);return _0x2c8151===0x0?qe(_0x123aa0['name'],_0x179924['name']):_0x2c8151;}['isDefinedOn'](_0x39571e){return!_0x39571e['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x36cdb7,_0x173d8c){return!_0x36cdb7['getPriority']()['equals'](_0x173d8c['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x20895e,_0x5b7705){const _0x458cc6=Oo(_0x20895e);return new E(_0x5b7705,new D('[PRIORITY-POST]',_0x458cc6));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x5edbd8){const _0x42d5c3=_0x11441f=>parseInt(Math['log'](_0x11441f)/Vh,0xa),_0x407703=_0x33a294=>parseInt(Array(_0x33a294+0x1)['join']('1'),0x2);this['count']=_0x42d5c3(_0x5edbd8+0x1),this['current_']=this['count']-0x1;const _0x5aa701=_0x407703(this['count']);this['bits_']=_0x5edbd8+0x1&_0x5aa701;}['nextBitIsOne'](){const _0x263191=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x263191;}}const yn=function(_0x312107,_0x1be500,_0x3abdab,_0x49b0e8){_0x312107['sort'](_0x1be500);const _0x240cca=function(_0x4a8169,_0x5595a7){const _0x501fc1=_0x5595a7-_0x4a8169;let _0x371481,_0x22aa7c;if(_0x501fc1===0x0)return null;if(_0x501fc1===0x1)return _0x371481=_0x312107[_0x4a8169],_0x22aa7c=_0x3abdab?_0x3abdab(_0x371481):_0x371481,new M(_0x22aa7c,_0x371481['node'],M['BLACK'],null,null);{const _0x2c3a8f=parseInt(_0x501fc1/0x2,0xa)+_0x4a8169,_0x572be2=_0x240cca(_0x4a8169,_0x2c3a8f),_0x4109a3=_0x240cca(_0x2c3a8f+0x1,_0x5595a7);return _0x371481=_0x312107[_0x2c3a8f],_0x22aa7c=_0x3abdab?_0x3abdab(_0x371481):_0x371481,new M(_0x22aa7c,_0x371481['node'],M['BLACK'],_0x572be2,_0x4109a3);}},_0x12198d=function(_0x5cf3d0){let _0x82f8b8=null,_0x481069=null,_0x3fdc2b=_0x312107['length'];const _0x55efee=function(_0x173ee4,_0x17ba91){const _0x237028=_0x3fdc2b-_0x173ee4,_0x24bdb8=_0x3fdc2b;_0x3fdc2b-=_0x173ee4;const _0x1edbe9=_0x240cca(_0x237028+0x1,_0x24bdb8),_0x271630=_0x312107[_0x237028],_0x58de24=_0x3abdab?_0x3abdab(_0x271630):_0x271630;_0x268b49(new M(_0x58de24,_0x271630['node'],_0x17ba91,null,_0x1edbe9));},_0x268b49=function(_0xffc4a6){_0x82f8b8?(_0x82f8b8['left']=_0xffc4a6,_0x82f8b8=_0xffc4a6):(_0x481069=_0xffc4a6,_0x82f8b8=_0xffc4a6);};for(let _0x4a2b01=0x0;_0x4a2b01<_0x5cf3d0['count'];++_0x4a2b01){const _0x197ff7=_0x5cf3d0['nextBitIsOne'](),_0x6eb728=Math['pow'](0x2,_0x5cf3d0['count']-(_0x4a2b01+0x1));_0x197ff7?_0x55efee(_0x6eb728,M['BLACK']):(_0x55efee(_0x6eb728,M['BLACK']),_0x55efee(_0x6eb728,M['RED']));}return _0x481069;},_0x172000=new Hh(_0x312107['length']),_0xfd8290=_0x12198d(_0x172000);return new B(_0x49b0e8||_0x1be500,_0xfd8290);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x3418b6,_0x1aacc1){this['indexes_']=_0x3418b6,this['indexSet_']=_0x1aacc1;}['get'](_0x203864){const _0xe87273=Le(this['indexes_'],_0x203864);if(!_0xe87273)throw new Error('No\x20index\x20defined\x20for\x20'+_0x203864);return _0xe87273 instanceof B?_0xe87273:null;}['hasIndex'](_0x53283e){return Q(this['indexSet_'],_0x53283e['toString']());}['addIndex'](_0x3f43f6,_0xcac648){f(_0x3f43f6!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x3d9fa4=[];let _0x118dee=!0x1;const _0x3925d6=_0xcac648['getIterator'](E['Wrap']);let _0x4074a7=_0x3925d6['getNext']();for(;_0x4074a7;)_0x118dee=_0x118dee||_0x3f43f6['isDefinedOn'](_0x4074a7['node']),_0x3d9fa4['push'](_0x4074a7),_0x4074a7=_0x3925d6['getNext']();let _0x330df;_0x118dee?_0x330df=yn(_0x3d9fa4,_0x3f43f6['getCompare']()):_0x330df=Qe;const _0x51f4d6=_0x3f43f6['toString'](),_0x5bd1a9={...this['indexSet_']};_0x5bd1a9[_0x51f4d6]=_0x3f43f6;const _0x5ceb65={...this['indexes_']};return _0x5ceb65[_0x51f4d6]=_0x330df,new te(_0x5ceb65,_0x5bd1a9);}['addToIndexes'](_0x1c4495,_0xc03a4c){const _0x389316=_n(this['indexes_'],(_0x4249a2,_0x1126c1)=>{const _0x422301=Le(this['indexSet_'],_0x1126c1);if(f(_0x422301,'Missing\x20index\x20implementation\x20for\x20'+_0x1126c1),_0x4249a2===Qe){if(_0x422301['isDefinedOn'](_0x1c4495['node'])){const _0x4faebe=[],_0x27a1ec=_0xc03a4c['getIterator'](E['Wrap']);let _0x52d814=_0x27a1ec['getNext']();for(;_0x52d814;)_0x52d814['name']!==_0x1c4495['name']&&_0x4faebe['push'](_0x52d814),_0x52d814=_0x27a1ec['getNext']();return _0x4faebe['push'](_0x1c4495),yn(_0x4faebe,_0x422301['getCompare']());}else return Qe;}else{const _0x229c32=_0xc03a4c['get'](_0x1c4495['name']);let _0x359ce2=_0x4249a2;return _0x229c32&&(_0x359ce2=_0x359ce2['remove'](new E(_0x1c4495['name'],_0x229c32))),_0x359ce2['insert'](_0x1c4495,_0x1c4495['node']);}});return new te(_0x389316,this['indexSet_']);}['removeFromIndexes'](_0x1bc652,_0xe70c91){const _0x271526=_n(this['indexes_'],_0xb69f09=>{if(_0xb69f09===Qe)return _0xb69f09;{const _0x45c942=_0xe70c91['get'](_0x1bc652['name']);return _0x45c942?_0xb69f09['remove'](new E(_0x1bc652['name'],_0x45c942)):_0xb69f09;}});return new te(_0x271526,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x126939,_0x1f21b5,_0x163afb){this['children_']=_0x126939,this['priorityNode_']=_0x1f21b5,this['indexMap_']=_0x163afb,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x814a9){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x814a9,this['indexMap_']);}['getImmediateChild'](_0x2df406){if(_0x2df406==='.priority')return this['getPriority']();{const _0x3b36df=this['children_']['get'](_0x2df406);return _0x3b36df===null?It:_0x3b36df;}}['getChild'](_0xaf424e){const _0x4f9fae=y(_0xaf424e);return _0x4f9fae===null?this:this['getImmediateChild'](_0x4f9fae)['getChild'](S(_0xaf424e));}['hasChild'](_0x132e95){return this['children_']['get'](_0x132e95)!==null;}['updateImmediateChild'](_0x35c873,_0x394299){if(f(_0x394299,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x35c873==='.priority')return this['updatePriority'](_0x394299);{const _0x53e78a=new E(_0x35c873,_0x394299);let _0x5b8040,_0x472637;_0x394299['isEmpty']()?(_0x5b8040=this['children_']['remove'](_0x35c873),_0x472637=this['indexMap_']['removeFromIndexes'](_0x53e78a,this['children_'])):(_0x5b8040=this['children_']['insert'](_0x35c873,_0x394299),_0x472637=this['indexMap_']['addToIndexes'](_0x53e78a,this['children_']));const _0xc4d479=_0x5b8040['isEmpty']()?It:this['priorityNode_'];return new g(_0x5b8040,_0xc4d479,_0x472637);}}['updateChild'](_0x129e17,_0x3ba2b5){const _0x440eb1=y(_0x129e17);if(_0x440eb1===null)return _0x3ba2b5;{f(y(_0x129e17)!=='.priority'||Ce(_0x129e17)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x2fc919=this['getImmediateChild'](_0x440eb1)['updateChild'](S(_0x129e17),_0x3ba2b5);return this['updateImmediateChild'](_0x440eb1,_0x2fc919);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x536307){if(this['isEmpty']())return null;const _0xd3e688={};let _0x2292ae=0x0,_0x3478e9=0x0,_0x2838f1=!0x0;if(this['forEachChild'](R,(_0x2102bd,_0x4899cd)=>{_0xd3e688[_0x2102bd]=_0x4899cd['val'](_0x536307),_0x2292ae++,_0x2838f1&&g['INTEGER_REGEXP_']['test'](_0x2102bd)?_0x3478e9=Math['max'](_0x3478e9,Number(_0x2102bd)):_0x2838f1=!0x1;}),!_0x536307&&_0x2838f1&&_0x3478e9<0x2*_0x2292ae){const _0x55581f=[];for(const _0x2d62d7 in _0xd3e688)_0x55581f[_0x2d62d7]=_0xd3e688[_0x2d62d7];return _0x55581f;}else return _0x536307&&!this['getPriority']()['isEmpty']()&&(_0xd3e688['.priority']=this['getPriority']()['val']()),_0xd3e688;}['hash'](){if(this['lazyHash_']===null){let _0x3dba59='';this['getPriority']()['isEmpty']()||(_0x3dba59+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x18d646,_0x3883d4)=>{const _0x1dbc59=_0x3883d4['hash']();_0x1dbc59!==''&&(_0x3dba59+=':'+_0x18d646+':'+_0x1dbc59);}),this['lazyHash_']=_0x3dba59===''?'':ro(_0x3dba59);}return this['lazyHash_'];}['getPredecessorChildName'](_0x5f20d0,_0x470bab,_0x77e713){const _0x21b3e6=this['resolveIndex_'](_0x77e713);if(_0x21b3e6){const _0x23bfd4=_0x21b3e6['getPredecessorKey'](new E(_0x5f20d0,_0x470bab));return _0x23bfd4?_0x23bfd4['name']:null;}else return this['children_']['getPredecessorKey'](_0x5f20d0);}['getFirstChildName'](_0x199df0){const _0x5f2701=this['resolveIndex_'](_0x199df0);if(_0x5f2701){const _0x53b1f6=_0x5f2701['minKey']();return _0x53b1f6&&_0x53b1f6['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x124f7a){const _0x1ba317=this['getFirstChildName'](_0x124f7a);return _0x1ba317?new E(_0x1ba317,this['children_']['get'](_0x1ba317)):null;}['getLastChildName'](_0x46b44f){const _0x4f410d=this['resolveIndex_'](_0x46b44f);if(_0x4f410d){const _0x1284b2=_0x4f410d['maxKey']();return _0x1284b2&&_0x1284b2['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x12650e){const _0x87dda9=this['getLastChildName'](_0x12650e);return _0x87dda9?new E(_0x87dda9,this['children_']['get'](_0x87dda9)):null;}['forEachChild'](_0x353e5a,_0x550805){const _0x332612=this['resolveIndex_'](_0x353e5a);return _0x332612?_0x332612['inorderTraversal'](_0x28da46=>_0x550805(_0x28da46['name'],_0x28da46['node'])):this['children_']['inorderTraversal'](_0x550805);}['getIterator'](_0x5df91){return this['getIteratorFrom'](_0x5df91['minPost'](),_0x5df91);}['getIteratorFrom'](_0x344a22,_0x7ef9a2){const _0x46b575=this['resolveIndex_'](_0x7ef9a2);if(_0x46b575)return _0x46b575['getIteratorFrom'](_0x344a22,_0x47acc5=>_0x47acc5);{const _0x15a51e=this['children_']['getIteratorFrom'](_0x344a22['name'],E['Wrap']);let _0x5beac9=_0x15a51e['peek']();for(;_0x5beac9!=null&&_0x7ef9a2['compare'](_0x5beac9,_0x344a22)<0x0;)_0x15a51e['getNext'](),_0x5beac9=_0x15a51e['peek']();return _0x15a51e;}}['getReverseIterator'](_0x2e78ff){return this['getReverseIteratorFrom'](_0x2e78ff['maxPost'](),_0x2e78ff);}['getReverseIteratorFrom'](_0x140e07,_0x1335c3){const _0x2ef47c=this['resolveIndex_'](_0x1335c3);if(_0x2ef47c)return _0x2ef47c['getReverseIteratorFrom'](_0x140e07,_0x46bf31=>_0x46bf31);{const _0x1754a3=this['children_']['getReverseIteratorFrom'](_0x140e07['name'],E['Wrap']);let _0x421b9d=_0x1754a3['peek']();for(;_0x421b9d!=null&&_0x1335c3['compare'](_0x421b9d,_0x140e07)>0x0;)_0x1754a3['getNext'](),_0x421b9d=_0x1754a3['peek']();return _0x1754a3;}}['compareTo'](_0x1947a6){return this['isEmpty']()?_0x1947a6['isEmpty']()?0x0:-0x1:_0x1947a6['isLeafNode']()||_0x1947a6['isEmpty']()?0x1:_0x1947a6===Kt?-0x1:0x0;}['withIndex'](_0x11eeb7){if(_0x11eeb7===ve||this['indexMap_']['hasIndex'](_0x11eeb7))return this;{const _0xca7cb7=this['indexMap_']['addIndex'](_0x11eeb7,this['children_']);return new g(this['children_'],this['priorityNode_'],_0xca7cb7);}}['isIndexed'](_0x22a894){return _0x22a894===ve||this['indexMap_']['hasIndex'](_0x22a894);}['equals'](_0xdf2f87){if(_0xdf2f87===this)return!0x0;if(_0xdf2f87['isLeafNode']())return!0x1;{const _0x3998b9=_0xdf2f87;if(this['getPriority']()['equals'](_0x3998b9['getPriority']())){if(this['children_']['count']()===_0x3998b9['children_']['count']()){const _0x59a18c=this['getIterator'](R),_0x3348ce=_0x3998b9['getIterator'](R);let _0x2effa6=_0x59a18c['getNext'](),_0x5e5230=_0x3348ce['getNext']();for(;_0x2effa6&&_0x5e5230;){if(_0x2effa6['name']!==_0x5e5230['name']||!_0x2effa6['node']['equals'](_0x5e5230['node']))return!0x1;_0x2effa6=_0x59a18c['getNext'](),_0x5e5230=_0x3348ce['getNext']();}return _0x2effa6===null&&_0x5e5230===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x4d1642){return _0x4d1642===ve?null:this['indexMap_']['get'](_0x4d1642['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x3d47fc){return _0x3d47fc===this?0x0:0x1;}['equals'](_0x452d00){return _0x452d00===this;}['getPriority'](){return this;}['getImmediateChild'](_0x200208){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x35515f,_0x2bc529=null){if(_0x35515f===null)return g['EMPTY_NODE'];if(typeof _0x35515f=='object'&&'.priority'in _0x35515f&&(_0x2bc529=_0x35515f['.priority']),f(_0x2bc529===null||typeof _0x2bc529=='string'||typeof _0x2bc529=='number'||typeof _0x2bc529=='object'&&'.sv'in _0x2bc529,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x2bc529),typeof _0x35515f=='object'&&'.value'in _0x35515f&&_0x35515f['.value']!==null&&(_0x35515f=_0x35515f['.value']),typeof _0x35515f!='object'||'.sv'in _0x35515f){const _0x3b90da=_0x35515f;return new D(_0x3b90da,A(_0x2bc529));}if(!(_0x35515f instanceof Array)&&Gh){const _0x2c7c6b=[];let _0xb6b693=!0x1;if(x(_0x35515f,(_0x4c4eac,_0x14c7af)=>{if(_0x4c4eac['substring'](0x0,0x1)!=='.'){const _0x36bfe2=A(_0x14c7af);_0x36bfe2['isEmpty']()||(_0xb6b693=_0xb6b693||!_0x36bfe2['getPriority']()['isEmpty'](),_0x2c7c6b['push'](new E(_0x4c4eac,_0x36bfe2)));}}),_0x2c7c6b['length']===0x0)return g['EMPTY_NODE'];const _0x4f3f81=yn(_0x2c7c6b,xh,_0x4ad94c=>_0x4ad94c['name'],Qi);if(_0xb6b693){const _0x67d9f3=yn(_0x2c7c6b,R['getCompare']());return new g(_0x4f3f81,A(_0x2bc529),new te({'.priority':_0x67d9f3},{'.priority':R}));}else return new g(_0x4f3f81,A(_0x2bc529),te['Default']);}else{let _0xaabb70=g['EMPTY_NODE'];return x(_0x35515f,(_0x38b6a2,_0x4090f7)=>{if(Q(_0x35515f,_0x38b6a2)&&_0x38b6a2['substring'](0x0,0x1)!=='.'){const _0x8f8354=A(_0x4090f7);(_0x8f8354['isLeafNode']()||!_0x8f8354['isEmpty']())&&(_0xaabb70=_0xaabb70['updateImmediateChild'](_0x38b6a2,_0x8f8354));}}),_0xaabb70['updatePriority'](A(_0x2bc529));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x23d4d8){super(),this['indexPath_']=_0x23d4d8,f(!v(_0x23d4d8)&&y(_0x23d4d8)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0xe87d5a){return _0xe87d5a['getChild'](this['indexPath_']);}['isDefinedOn'](_0x540986){return!_0x540986['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x558275,_0x285cc3){const _0x52f6ec=this['extractChild'](_0x558275['node']),_0x2c79af=this['extractChild'](_0x285cc3['node']),_0x3d69f7=_0x52f6ec['compareTo'](_0x2c79af);return _0x3d69f7===0x0?qe(_0x558275['name'],_0x285cc3['name']):_0x3d69f7;}['makePost'](_0x49364a,_0x47c7eb){const _0x16c65a=A(_0x49364a),_0x116d8b=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x16c65a);return new E(_0x47c7eb,_0x116d8b);}['maxPost'](){const _0x5e549e=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x5e549e);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x24026d,_0x5a8e9c){const _0x4256fe=_0x24026d['node']['compareTo'](_0x5a8e9c['node']);return _0x4256fe===0x0?qe(_0x24026d['name'],_0x5a8e9c['name']):_0x4256fe;}['isDefinedOn'](_0x4c1148){return!0x0;}['indexedValueChanged'](_0x37fc16,_0x3faf03){return!_0x37fc16['equals'](_0x3faf03);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x5d97dc,_0x356b04){const _0x5cbc89=A(_0x5d97dc);return new E(_0x356b04,_0x5cbc89);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x5bb940){return{'type':'value','snapshotNode':_0x5bb940};}function rt(_0x3f5f8c,_0x542acb){return{'type':'child_added','snapshotNode':_0x542acb,'childName':_0x3f5f8c};}function Lt(_0x1f2d64,_0x2613d6){return{'type':'child_removed','snapshotNode':_0x2613d6,'childName':_0x1f2d64};}function xt(_0x14382a,_0x136665,_0x43a13d){return{'type':'child_changed','snapshotNode':_0x136665,'childName':_0x14382a,'oldSnap':_0x43a13d};}function zh(_0x47d3f3,_0x3dd140){return{'type':'child_moved','snapshotNode':_0x3dd140,'childName':_0x47d3f3};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x4a4534){this['index_']=_0x4a4534;}['updateChild'](_0x459874,_0x362dad,_0x12be7c,_0x1aaaba,_0x591cb0,_0x265489){f(_0x459874['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x172fe0=_0x459874['getImmediateChild'](_0x362dad);return _0x172fe0['getChild'](_0x1aaaba)['equals'](_0x12be7c['getChild'](_0x1aaaba))&&_0x172fe0['isEmpty']()===_0x12be7c['isEmpty']()||(_0x265489!=null&&(_0x12be7c['isEmpty']()?_0x459874['hasChild'](_0x362dad)?_0x265489['trackChildChange'](Lt(_0x362dad,_0x172fe0)):f(_0x459874['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x172fe0['isEmpty']()?_0x265489['trackChildChange'](rt(_0x362dad,_0x12be7c)):_0x265489['trackChildChange'](xt(_0x362dad,_0x12be7c,_0x172fe0))),_0x459874['isLeafNode']()&&_0x12be7c['isEmpty']())?_0x459874:_0x459874['updateImmediateChild'](_0x362dad,_0x12be7c)['withIndex'](this['index_']);}['updateFullNode'](_0x399b98,_0x149bbc,_0x1c647c){return _0x1c647c!=null&&(_0x399b98['isLeafNode']()||_0x399b98['forEachChild'](R,(_0x44738d,_0x46d05f)=>{_0x149bbc['hasChild'](_0x44738d)||_0x1c647c['trackChildChange'](Lt(_0x44738d,_0x46d05f));}),_0x149bbc['isLeafNode']()||_0x149bbc['forEachChild'](R,(_0xa0feec,_0x344abf)=>{if(_0x399b98['hasChild'](_0xa0feec)){const _0x18bfbe=_0x399b98['getImmediateChild'](_0xa0feec);_0x18bfbe['equals'](_0x344abf)||_0x1c647c['trackChildChange'](xt(_0xa0feec,_0x344abf,_0x18bfbe));}else _0x1c647c['trackChildChange'](rt(_0xa0feec,_0x344abf));})),_0x149bbc['withIndex'](this['index_']);}['updatePriority'](_0x1079be,_0x36988e){return _0x1079be['isEmpty']()?g['EMPTY_NODE']:_0x1079be['updatePriority'](_0x36988e);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x382303){this['indexedFilter_']=new Xi(_0x382303['getIndex']()),this['index_']=_0x382303['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x382303),this['endPost_']=Ft['getEndPost_'](_0x382303),this['startIsInclusive_']=!_0x382303['startAfterSet_'],this['endIsInclusive_']=!_0x382303['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0xdb478a){const _0x2a3ea5=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0xdb478a)<=0x0:this['index_']['compare'](this['getStartPost'](),_0xdb478a)<0x0,_0x40d96c=this['endIsInclusive_']?this['index_']['compare'](_0xdb478a,this['getEndPost']())<=0x0:this['index_']['compare'](_0xdb478a,this['getEndPost']())<0x0;return _0x2a3ea5&&_0x40d96c;}['updateChild'](_0x3b3a2b,_0x3dcee9,_0xce9fa0,_0x3062a1,_0x2fee65,_0xdab126){return this['matches'](new E(_0x3dcee9,_0xce9fa0))||(_0xce9fa0=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x3b3a2b,_0x3dcee9,_0xce9fa0,_0x3062a1,_0x2fee65,_0xdab126);}['updateFullNode'](_0x1b983f,_0x3656cc,_0x2626fe){_0x3656cc['isLeafNode']()&&(_0x3656cc=g['EMPTY_NODE']);let _0x151861=_0x3656cc['withIndex'](this['index_']);_0x151861=_0x151861['updatePriority'](g['EMPTY_NODE']);const _0x188d2a=this;return _0x3656cc['forEachChild'](R,(_0x4a8d0b,_0x1337de)=>{_0x188d2a['matches'](new E(_0x4a8d0b,_0x1337de))||(_0x151861=_0x151861['updateImmediateChild'](_0x4a8d0b,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x1b983f,_0x151861,_0x2626fe);}['updatePriority'](_0x47c224,_0x4c85ab){return _0x47c224;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x35601e){if(_0x35601e['hasStart']()){const _0x3d166b=_0x35601e['getIndexStartName']();return _0x35601e['getIndex']()['makePost'](_0x35601e['getIndexStartValue'](),_0x3d166b);}else return _0x35601e['getIndex']()['minPost']();}static['getEndPost_'](_0x4e952f){if(_0x4e952f['hasEnd']()){const _0x465627=_0x4e952f['getIndexEndName']();return _0x4e952f['getIndex']()['makePost'](_0x4e952f['getIndexEndValue'](),_0x465627);}else return _0x4e952f['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x5b1607){this['withinDirectionalStart']=_0x4a21f6=>this['reverse_']?this['withinEndPost'](_0x4a21f6):this['withinStartPost'](_0x4a21f6),this['withinDirectionalEnd']=_0x3e5075=>this['reverse_']?this['withinStartPost'](_0x3e5075):this['withinEndPost'](_0x3e5075),this['withinStartPost']=_0x6fa8f3=>{const _0x3cd8a3=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x6fa8f3);return this['startIsInclusive_']?_0x3cd8a3<=0x0:_0x3cd8a3<0x0;},this['withinEndPost']=_0x2ea986=>{const _0x45e17b=this['index_']['compare'](_0x2ea986,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x45e17b<=0x0:_0x45e17b<0x0;},this['rangedFilter_']=new Ft(_0x5b1607),this['index_']=_0x5b1607['getIndex'](),this['limit_']=_0x5b1607['getLimit'](),this['reverse_']=!_0x5b1607['isViewFromLeft'](),this['startIsInclusive_']=!_0x5b1607['startAfterSet_'],this['endIsInclusive_']=!_0x5b1607['endBeforeSet_'];}['updateChild'](_0xbfaecc,_0x4c1ab4,_0x344934,_0x39087f,_0xc133b4,_0x427db1){return this['rangedFilter_']['matches'](new E(_0x4c1ab4,_0x344934))||(_0x344934=g['EMPTY_NODE']),_0xbfaecc['getImmediateChild'](_0x4c1ab4)['equals'](_0x344934)?_0xbfaecc:_0xbfaecc['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0xbfaecc,_0x4c1ab4,_0x344934,_0x39087f,_0xc133b4,_0x427db1):this['fullLimitUpdateChild_'](_0xbfaecc,_0x4c1ab4,_0x344934,_0xc133b4,_0x427db1);}['updateFullNode'](_0x2dbcae,_0x39165f,_0x507e93){let _0x9f2459;if(_0x39165f['isLeafNode']()||_0x39165f['isEmpty']())_0x9f2459=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x39165f['numChildren']()&&_0x39165f['isIndexed'](this['index_'])){_0x9f2459=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x26ee64;this['reverse_']?_0x26ee64=_0x39165f['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x26ee64=_0x39165f['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x37f453=0x0;for(;_0x26ee64['hasNext']()&&_0x37f453<this['limit_'];){const _0x1b4601=_0x26ee64['getNext']();if(this['withinDirectionalStart'](_0x1b4601)){if(this['withinDirectionalEnd'](_0x1b4601))_0x9f2459=_0x9f2459['updateImmediateChild'](_0x1b4601['name'],_0x1b4601['node']),_0x37f453++;else break;}else continue;}}else{_0x9f2459=_0x39165f['withIndex'](this['index_']),_0x9f2459=_0x9f2459['updatePriority'](g['EMPTY_NODE']);let _0x144c7f;this['reverse_']?_0x144c7f=_0x9f2459['getReverseIterator'](this['index_']):_0x144c7f=_0x9f2459['getIterator'](this['index_']);let _0x393e93=0x0;for(;_0x144c7f['hasNext']();){const _0x24acc9=_0x144c7f['getNext']();_0x393e93<this['limit_']&&this['withinDirectionalStart'](_0x24acc9)&&this['withinDirectionalEnd'](_0x24acc9)?_0x393e93++:_0x9f2459=_0x9f2459['updateImmediateChild'](_0x24acc9['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x2dbcae,_0x9f2459,_0x507e93);}['updatePriority'](_0x58d2b3,_0x1b27be){return _0x58d2b3;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x277b2f,_0x248d2e,_0x252246,_0x511d8,_0x712ea3){let _0x52cfb0;if(this['reverse_']){const _0x1478c4=this['index_']['getCompare']();_0x52cfb0=(_0x11d4dd,_0x89a59d)=>_0x1478c4(_0x89a59d,_0x11d4dd);}else _0x52cfb0=this['index_']['getCompare']();const _0x31e5a1=_0x277b2f;f(_0x31e5a1['numChildren']()===this['limit_'],'');const _0x51d59c=new E(_0x248d2e,_0x252246),_0x354cd8=this['reverse_']?_0x31e5a1['getFirstChild'](this['index_']):_0x31e5a1['getLastChild'](this['index_']),_0x4ea098=this['rangedFilter_']['matches'](_0x51d59c);if(_0x31e5a1['hasChild'](_0x248d2e)){const _0x54e88e=_0x31e5a1['getImmediateChild'](_0x248d2e);let _0x28c54e=_0x511d8['getChildAfterChild'](this['index_'],_0x354cd8,this['reverse_']);for(;_0x28c54e!=null&&(_0x28c54e['name']===_0x248d2e||_0x31e5a1['hasChild'](_0x28c54e['name']));)_0x28c54e=_0x511d8['getChildAfterChild'](this['index_'],_0x28c54e,this['reverse_']);const _0x50cdb1=_0x28c54e==null?0x1:_0x52cfb0(_0x28c54e,_0x51d59c);if(_0x4ea098&&!_0x252246['isEmpty']()&&_0x50cdb1>=0x0)return _0x712ea3!=null&&_0x712ea3['trackChildChange'](xt(_0x248d2e,_0x252246,_0x54e88e)),_0x31e5a1['updateImmediateChild'](_0x248d2e,_0x252246);{_0x712ea3!=null&&_0x712ea3['trackChildChange'](Lt(_0x248d2e,_0x54e88e));const _0x17b685=_0x31e5a1['updateImmediateChild'](_0x248d2e,g['EMPTY_NODE']);return _0x28c54e!=null&&this['rangedFilter_']['matches'](_0x28c54e)?(_0x712ea3!=null&&_0x712ea3['trackChildChange'](rt(_0x28c54e['name'],_0x28c54e['node'])),_0x17b685['updateImmediateChild'](_0x28c54e['name'],_0x28c54e['node'])):_0x17b685;}}else return _0x252246['isEmpty']()?_0x277b2f:_0x4ea098&&_0x52cfb0(_0x354cd8,_0x51d59c)>=0x0?(_0x712ea3!=null&&(_0x712ea3['trackChildChange'](Lt(_0x354cd8['name'],_0x354cd8['node'])),_0x712ea3['trackChildChange'](rt(_0x248d2e,_0x252246))),_0x31e5a1['updateImmediateChild'](_0x248d2e,_0x252246)['updateImmediateChild'](_0x354cd8['name'],g['EMPTY_NODE'])):_0x277b2f;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x24363b=new Zi();return _0x24363b['limitSet_']=this['limitSet_'],_0x24363b['limit_']=this['limit_'],_0x24363b['startSet_']=this['startSet_'],_0x24363b['startAfterSet_']=this['startAfterSet_'],_0x24363b['indexStartValue_']=this['indexStartValue_'],_0x24363b['startNameSet_']=this['startNameSet_'],_0x24363b['indexStartName_']=this['indexStartName_'],_0x24363b['endSet_']=this['endSet_'],_0x24363b['endBeforeSet_']=this['endBeforeSet_'],_0x24363b['indexEndValue_']=this['indexEndValue_'],_0x24363b['endNameSet_']=this['endNameSet_'],_0x24363b['indexEndName_']=this['indexEndName_'],_0x24363b['index_']=this['index_'],_0x24363b['viewFrom_']=this['viewFrom_'],_0x24363b;}}function Kh(_0x45603d){return _0x45603d['loadsAllData']()?new Xi(_0x45603d['getIndex']()):_0x45603d['hasLimit']()?new jh(_0x45603d):new Ft(_0x45603d);}function Yh(_0x5ad70f,_0x4447be){const _0x571856=_0x5ad70f['copy']();return _0x571856['limitSet_']=!0x0,_0x571856['limit_']=_0x4447be,_0x571856['viewFrom_']='l',_0x571856;}function Qh(_0x407c6e,_0x2744d1,_0x1e2be2){const _0x286d62=_0x407c6e['copy']();return _0x286d62['startSet_']=!0x0,_0x2744d1===void 0x0&&(_0x2744d1=null),_0x286d62['indexStartValue_']=_0x2744d1,_0x1e2be2!=null?(_0x286d62['startNameSet_']=!0x0,_0x286d62['indexStartName_']=_0x1e2be2):(_0x286d62['startNameSet_']=!0x1,_0x286d62['indexStartName_']=''),_0x286d62;}function Jh(_0x243630,_0x17ad7c,_0x14a936){const _0x771526=_0x243630['copy']();return _0x771526['endSet_']=!0x0,_0x17ad7c===void 0x0&&(_0x17ad7c=null),_0x771526['indexEndValue_']=_0x17ad7c,_0x14a936!==void 0x0?(_0x771526['endNameSet_']=!0x0,_0x771526['indexEndName_']=_0x14a936):(_0x771526['endNameSet_']=!0x1,_0x771526['indexEndName_']=''),_0x771526;}function xo(_0x4f05d9,_0x1e069d){const _0x2991dd=_0x4f05d9['copy']();return _0x2991dd['index_']=_0x1e069d,_0x2991dd;}function ir(_0x3f733b){const _0x1a1812={};if(_0x3f733b['isDefault']())return _0x1a1812;let _0x4c028b;if(_0x3f733b['index_']===R?_0x4c028b='$priority':_0x3f733b['index_']===Mo?_0x4c028b='$value':_0x3f733b['index_']===ve?_0x4c028b='$key':(f(_0x3f733b['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x4c028b=_0x3f733b['index_']['toString']()),_0x1a1812['orderBy']=O(_0x4c028b),_0x3f733b['startSet_']){const _0x2f6d10=_0x3f733b['startAfterSet_']?'startAfter':'startAt';_0x1a1812[_0x2f6d10]=O(_0x3f733b['indexStartValue_']),_0x3f733b['startNameSet_']&&(_0x1a1812[_0x2f6d10]+=','+O(_0x3f733b['indexStartName_']));}if(_0x3f733b['endSet_']){const _0x320d00=_0x3f733b['endBeforeSet_']?'endBefore':'endAt';_0x1a1812[_0x320d00]=O(_0x3f733b['indexEndValue_']),_0x3f733b['endNameSet_']&&(_0x1a1812[_0x320d00]+=','+O(_0x3f733b['indexEndName_']));}return _0x3f733b['limitSet_']&&(_0x3f733b['isViewFromLeft']()?_0x1a1812['limitToFirst']=_0x3f733b['limit_']:_0x1a1812['limitToLast']=_0x3f733b['limit_']),_0x1a1812;}function sr(_0x233fb7){const _0xebe776={};if(_0x233fb7['startSet_']&&(_0xebe776['sp']=_0x233fb7['indexStartValue_'],_0x233fb7['startNameSet_']&&(_0xebe776['sn']=_0x233fb7['indexStartName_']),_0xebe776['sin']=!_0x233fb7['startAfterSet_']),_0x233fb7['endSet_']&&(_0xebe776['ep']=_0x233fb7['indexEndValue_'],_0x233fb7['endNameSet_']&&(_0xebe776['en']=_0x233fb7['indexEndName_']),_0xebe776['ein']=!_0x233fb7['endBeforeSet_']),_0x233fb7['limitSet_']){_0xebe776['l']=_0x233fb7['limit_'];let _0x130b60=_0x233fb7['viewFrom_'];_0x130b60===''&&(_0x233fb7['isViewFromLeft']()?_0x130b60='l':_0x130b60='r'),_0xebe776['vf']=_0x130b60;}return _0x233fb7['index_']!==R&&(_0xebe776['i']=_0x233fb7['index_']['toString']()),_0xebe776;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x129a95){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x3a7674,_0x2e16f5){return _0x2e16f5!==void 0x0?'tag$'+_0x2e16f5:(f(_0x3a7674['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x3a7674['_path']['toString']());}constructor(_0x4f6846,_0x40b571,_0x1da2df,_0x4d571b){super(),this['repoInfo_']=_0x4f6846,this['onDataUpdate_']=_0x40b571,this['authTokenProvider_']=_0x1da2df,this['appCheckTokenProvider_']=_0x4d571b,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x16a68f,_0x2f732b,_0x1bdce2,_0x2d7241){const _0x4cf0a2=_0x16a68f['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x4cf0a2+'\x20'+_0x16a68f['_queryIdentifier']);const _0x23d691=vn['getListenId_'](_0x16a68f,_0x1bdce2),_0x4e6fb2={};this['listens_'][_0x23d691]=_0x4e6fb2;const _0x2bc48a=ir(_0x16a68f['_queryParams']);this['restRequest_'](_0x4cf0a2+'.json',_0x2bc48a,(_0xa91acc,_0x261812)=>{let _0x2051e1=_0x261812;if(_0xa91acc===0x194&&(_0x2051e1=null,_0xa91acc=null),_0xa91acc===null&&this['onDataUpdate_'](_0x4cf0a2,_0x2051e1,!0x1,_0x1bdce2),Le(this['listens_'],_0x23d691)===_0x4e6fb2){let _0x1d2417;_0xa91acc?_0xa91acc===0x191?_0x1d2417='permission_denied':_0x1d2417='rest_error:'+_0xa91acc:_0x1d2417='ok',_0x2d7241(_0x1d2417,null);}});}['unlisten'](_0x3701a1,_0x5beb20){const _0x59eb78=vn['getListenId_'](_0x3701a1,_0x5beb20);delete this['listens_'][_0x59eb78];}['get'](_0x3396e0){const _0x344d24=ir(_0x3396e0['_queryParams']),_0x82f5aa=_0x3396e0['_path']['toString'](),_0x3d0a7d=new H();return this['restRequest_'](_0x82f5aa+'.json',_0x344d24,(_0x21396c,_0x4ebc37)=>{let _0x3a4647=_0x4ebc37;_0x21396c===0x194&&(_0x3a4647=null,_0x21396c=null),_0x21396c===null?(this['onDataUpdate_'](_0x82f5aa,_0x3a4647,!0x1,null),_0x3d0a7d['resolve'](_0x3a4647)):_0x3d0a7d['reject'](new Error(_0x3a4647));}),_0x3d0a7d['promise'];}['refreshAuthToken'](_0x5770c9){}['restRequest_'](_0x29d5c2,_0x33ea9c={},_0x503c59){return _0x33ea9c['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x10c776,_0x53d32c])=>{_0x10c776&&_0x10c776['accessToken']&&(_0x33ea9c['auth']=_0x10c776['accessToken']),_0x53d32c&&_0x53d32c['token']&&(_0x33ea9c['ac']=_0x53d32c['token']);const _0x42f1ef=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x29d5c2+'?ns='+this['repoInfo_']['namespace']+ut(_0x33ea9c);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x42f1ef);const _0x3d7e1f=new XMLHttpRequest();_0x3d7e1f['onreadystatechange']=()=>{if(_0x503c59&&_0x3d7e1f['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x42f1ef+'\x20received.\x20status:',_0x3d7e1f['status'],'response:',_0x3d7e1f['responseText']);let _0x79abea=null;if(_0x3d7e1f['status']>=0xc8&&_0x3d7e1f['status']<0x12c){try{_0x79abea=Nt(_0x3d7e1f['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x42f1ef+':\x20'+_0x3d7e1f['responseText']);}_0x503c59(null,_0x79abea);}else _0x3d7e1f['status']!==0x191&&_0x3d7e1f['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x42f1ef+'\x20Status:\x20'+_0x3d7e1f['status']),_0x503c59(_0x3d7e1f['status']);_0x503c59=null;}},_0x3d7e1f['open']('GET',_0x42f1ef,!0x0),_0x3d7e1f['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x1b40d0){return this['rootNode_']['getChild'](_0x1b40d0);}['updateSnapshot'](_0x350b6f,_0x44b053){this['rootNode_']=this['rootNode_']['updateChild'](_0x350b6f,_0x44b053);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x3b0a15,_0x402f1a,_0x927b56){if(v(_0x402f1a))_0x3b0a15['value']=_0x927b56,_0x3b0a15['children']['clear']();else{if(_0x3b0a15['value']!==null)_0x3b0a15['value']=_0x3b0a15['value']['updateChild'](_0x402f1a,_0x927b56);else{const _0x4db01b=y(_0x402f1a);_0x3b0a15['children']['has'](_0x4db01b)||_0x3b0a15['children']['set'](_0x4db01b,En());const _0x41166a=_0x3b0a15['children']['get'](_0x4db01b);_0x402f1a=S(_0x402f1a),pt(_0x41166a,_0x402f1a,_0x927b56);}}}function Ti(_0x543e6e,_0x5b8302){if(v(_0x5b8302))return _0x543e6e['value']=null,_0x543e6e['children']['clear'](),!0x0;if(_0x543e6e['value']!==null){if(_0x543e6e['value']['isLeafNode']())return!0x1;{const _0x4cc773=_0x543e6e['value'];return _0x543e6e['value']=null,_0x4cc773['forEachChild'](R,(_0x48a5d9,_0x187fd5)=>{pt(_0x543e6e,new C(_0x48a5d9),_0x187fd5);}),Ti(_0x543e6e,_0x5b8302);}}else{if(_0x543e6e['children']['size']>0x0){const _0x3f438e=y(_0x5b8302);return _0x5b8302=S(_0x5b8302),_0x543e6e['children']['has'](_0x3f438e)&&Ti(_0x543e6e['children']['get'](_0x3f438e),_0x5b8302)&&_0x543e6e['children']['delete'](_0x3f438e),_0x543e6e['children']['size']===0x0;}else return!0x0;}}function Si(_0x1c2d83,_0x1a8306,_0x39be81){_0x1c2d83['value']!==null?_0x39be81(_0x1a8306,_0x1c2d83['value']):Zh(_0x1c2d83,(_0x5238f6,_0x55a324)=>{const _0x1b7b44=new C(_0x1a8306['toString']()+'/'+_0x5238f6);Si(_0x55a324,_0x1b7b44,_0x39be81);});}function Zh(_0x50114a,_0x47c351){_0x50114a['children']['forEach']((_0x2d50b4,_0x5a7dcc)=>{_0x47c351(_0x5a7dcc,_0x2d50b4);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x501e62){this['collection_']=_0x501e62,this['last_']=null;}['get'](){const _0x3c94c5=this['collection_']['get'](),_0x2d94dd={..._0x3c94c5};return this['last_']&&x(this['last_'],(_0x5c6f89,_0x1baae6)=>{_0x2d94dd[_0x5c6f89]=_0x2d94dd[_0x5c6f89]-_0x1baae6;}),this['last_']=_0x3c94c5,_0x2d94dd;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x44d828,_0x4d2811){this['server_']=_0x4d2811,this['statsToReport_']={},this['statsListener_']=new eu(_0x44d828);const _0x21a05c=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x21a05c));}['reportStats_'](){const _0x241e96=this['statsListener_']['get'](),_0x37c48a={};let _0x1148f5=!0x1;x(_0x241e96,(_0x1f7ee0,_0x3b7720)=>{_0x3b7720>0x0&&Q(this['statsToReport_'],_0x1f7ee0)&&(_0x37c48a[_0x1f7ee0]=_0x3b7720,_0x1148f5=!0x0);}),_0x1148f5&&this['server_']['reportStats'](_0x37c48a),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x2285b7){_0x2285b7[_0x2285b7['OVERWRITE']=0x0]='OVERWRITE',_0x2285b7[_0x2285b7['MERGE']=0x1]='MERGE',_0x2285b7[_0x2285b7['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x2285b7[_0x2285b7['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x52b914){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x52b914,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x1834aa,_0x12299d,_0x873a83){this['path']=_0x1834aa,this['affectedTree']=_0x12299d,this['revert']=_0x873a83,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x4df951){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x3679f8=this['affectedTree']['subtree'](new C(_0x4df951));return new In(w(),_0x3679f8,this['revert']);}}else return f(y(this['path'])===_0x4df951,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0xf313cf,_0x54bd5a){this['source']=_0xf313cf,this['path']=_0x54bd5a,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x48c42c){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x27b018,_0x2656b7,_0x5ef049){this['source']=_0x27b018,this['path']=_0x2656b7,this['snap']=_0x5ef049,this['type']=z['OVERWRITE'];}['operationForChild'](_0x492118){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x492118)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x344667,_0xce3d7,_0x2bf016){this['source']=_0x344667,this['path']=_0xce3d7,this['children']=_0x2bf016,this['type']=z['MERGE'];}['operationForChild'](_0x5baaa7){if(v(this['path'])){const _0x3d195a=this['children']['subtree'](new C(_0x5baaa7));return _0x3d195a['isEmpty']()?null:_0x3d195a['value']?new Be(this['source'],w(),_0x3d195a['value']):new ot(this['source'],w(),_0x3d195a);}else return f(y(this['path'])===_0x5baaa7,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x2674b1,_0x1c2261,_0x1ca7d4){this['node_']=_0x2674b1,this['fullyInitialized_']=_0x1c2261,this['filtered_']=_0x1ca7d4;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x47f995){if(v(_0x47f995))return this['isFullyInitialized']()&&!this['filtered_'];const _0x868715=y(_0x47f995);return this['isCompleteForChild'](_0x868715);}['isCompleteForChild'](_0x1ff1ad){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x1ff1ad);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x1f05e0){this['query_']=_0x1f05e0,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x44ae7d,_0x148726,_0x33850b,_0x49c9bc){const _0x1e6722=[],_0xec5a6a=[];return _0x148726['forEach'](_0x1ea522=>{_0x1ea522['type']==='child_changed'&&_0x44ae7d['index_']['indexedValueChanged'](_0x1ea522['oldSnap'],_0x1ea522['snapshotNode'])&&_0xec5a6a['push'](zh(_0x1ea522['childName'],_0x1ea522['snapshotNode']));}),wt(_0x44ae7d,_0x1e6722,'child_removed',_0x148726,_0x49c9bc,_0x33850b),wt(_0x44ae7d,_0x1e6722,'child_added',_0x148726,_0x49c9bc,_0x33850b),wt(_0x44ae7d,_0x1e6722,'child_moved',_0xec5a6a,_0x49c9bc,_0x33850b),wt(_0x44ae7d,_0x1e6722,'child_changed',_0x148726,_0x49c9bc,_0x33850b),wt(_0x44ae7d,_0x1e6722,'value',_0x148726,_0x49c9bc,_0x33850b),_0x1e6722;}function wt(_0x509420,_0x4bc136,_0xe811bd,_0x5e0b44,_0x5d26b6,_0x3e55d3){const _0x5562b6=_0x5e0b44['filter'](_0xbd3bc7=>_0xbd3bc7['type']===_0xe811bd);_0x5562b6['sort']((_0x26d9ce,_0x2d2798)=>au(_0x509420,_0x26d9ce,_0x2d2798)),_0x5562b6['forEach'](_0x33ce21=>{const _0x593742=ou(_0x509420,_0x33ce21,_0x3e55d3);_0x5d26b6['forEach'](_0x5425ea=>{_0x5425ea['respondsTo'](_0x33ce21['type'])&&_0x4bc136['push'](_0x5425ea['createEvent'](_0x593742,_0x509420['query_']));});});}function ou(_0x1bbe3a,_0x245d51,_0x3a49b3){return _0x245d51['type']==='value'||_0x245d51['type']==='child_removed'||(_0x245d51['prevName']=_0x3a49b3['getPredecessorChildName'](_0x245d51['childName'],_0x245d51['snapshotNode'],_0x1bbe3a['index_'])),_0x245d51;}function au(_0xe8767b,_0xf26c70,_0x350e48){if(_0xf26c70['childName']==null||_0x350e48['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x2eca54=new E(_0xf26c70['childName'],_0xf26c70['snapshotNode']),_0x4538fe=new E(_0x350e48['childName'],_0x350e48['snapshotNode']);return _0xe8767b['index_']['compare'](_0x2eca54,_0x4538fe);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x1ab643,_0x29a9eb){return{'eventCache':_0x1ab643,'serverCache':_0x29a9eb};}function Rt(_0x24c9f0,_0x3f3f3a,_0x1d29c7,_0x48493a){return Un(new Te(_0x3f3f3a,_0x1d29c7,_0x48493a),_0x24c9f0['serverCache']);}function Fo(_0x2da35f,_0x2e90a6,_0x165a29,_0xa3dc45){return Un(_0x2da35f['eventCache'],new Te(_0x2e90a6,_0x165a29,_0xa3dc45));}function wn(_0xd58f49){return _0xd58f49['eventCache']['isFullyInitialized']()?_0xd58f49['eventCache']['getNode']():null;}function Ve(_0x17bc1c){return _0x17bc1c['serverCache']['isFullyInitialized']()?_0x17bc1c['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x320080){let _0x5eedbd=new b(null);return x(_0x320080,(_0x11b3cd,_0x587061)=>{_0x5eedbd=_0x5eedbd['set'](new C(_0x11b3cd),_0x587061);}),_0x5eedbd;}constructor(_0x16d9b7,_0x531687=cu()){this['value']=_0x16d9b7,this['children']=_0x531687;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x2387f7,_0x19ada8){if(this['value']!=null&&_0x19ada8(this['value']))return{'path':w(),'value':this['value']};if(v(_0x2387f7))return null;{const _0x36da96=y(_0x2387f7),_0x38b888=this['children']['get'](_0x36da96);if(_0x38b888!==null){const _0x2d2ca2=_0x38b888['findRootMostMatchingPathAndValue'](S(_0x2387f7),_0x19ada8);return _0x2d2ca2!=null?{'path':k(new C(_0x36da96),_0x2d2ca2['path']),'value':_0x2d2ca2['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x35cfa9){return this['findRootMostMatchingPathAndValue'](_0x35cfa9,()=>!0x0);}['subtree'](_0x5f1eb3){if(v(_0x5f1eb3))return this;{const _0x380eaa=y(_0x5f1eb3),_0x17fbdc=this['children']['get'](_0x380eaa);return _0x17fbdc!==null?_0x17fbdc['subtree'](S(_0x5f1eb3)):new b(null);}}['set'](_0x346afc,_0x190d88){if(v(_0x346afc))return new b(_0x190d88,this['children']);{const _0x1e0977=y(_0x346afc),_0x2eff30=(this['children']['get'](_0x1e0977)||new b(null))['set'](S(_0x346afc),_0x190d88),_0x2d7ce0=this['children']['insert'](_0x1e0977,_0x2eff30);return new b(this['value'],_0x2d7ce0);}}['remove'](_0x3836b8){if(v(_0x3836b8))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x5cc8e2=y(_0x3836b8),_0x5e3e44=this['children']['get'](_0x5cc8e2);if(_0x5e3e44){const _0x3c3a94=_0x5e3e44['remove'](S(_0x3836b8));let _0x174d2d;return _0x3c3a94['isEmpty']()?_0x174d2d=this['children']['remove'](_0x5cc8e2):_0x174d2d=this['children']['insert'](_0x5cc8e2,_0x3c3a94),this['value']===null&&_0x174d2d['isEmpty']()?new b(null):new b(this['value'],_0x174d2d);}else return this;}}['get'](_0x49d6d0){if(v(_0x49d6d0))return this['value'];{const _0x4f9bfd=y(_0x49d6d0),_0x163aee=this['children']['get'](_0x4f9bfd);return _0x163aee?_0x163aee['get'](S(_0x49d6d0)):null;}}['setTree'](_0x35c8fc,_0x4b106a){if(v(_0x35c8fc))return _0x4b106a;{const _0x1e69d6=y(_0x35c8fc),_0x33e91b=(this['children']['get'](_0x1e69d6)||new b(null))['setTree'](S(_0x35c8fc),_0x4b106a);let _0x129b24;return _0x33e91b['isEmpty']()?_0x129b24=this['children']['remove'](_0x1e69d6):_0x129b24=this['children']['insert'](_0x1e69d6,_0x33e91b),new b(this['value'],_0x129b24);}}['fold'](_0x5fdbbf){return this['fold_'](w(),_0x5fdbbf);}['fold_'](_0x26957d,_0x2eb164){const _0x32efd1={};return this['children']['inorderTraversal']((_0x539f4b,_0x1fc189)=>{_0x32efd1[_0x539f4b]=_0x1fc189['fold_'](k(_0x26957d,_0x539f4b),_0x2eb164);}),_0x2eb164(_0x26957d,this['value'],_0x32efd1);}['findOnPath'](_0x5c811b,_0x564fe2){return this['findOnPath_'](_0x5c811b,w(),_0x564fe2);}['findOnPath_'](_0x507fdc,_0x42e59d,_0x56ef97){const _0x18e972=this['value']?_0x56ef97(_0x42e59d,this['value']):!0x1;if(_0x18e972)return _0x18e972;if(v(_0x507fdc))return null;{const _0x50f490=y(_0x507fdc),_0x336877=this['children']['get'](_0x50f490);return _0x336877?_0x336877['findOnPath_'](S(_0x507fdc),k(_0x42e59d,_0x50f490),_0x56ef97):null;}}['foreachOnPath'](_0x29dc7d,_0xfd097){return this['foreachOnPath_'](_0x29dc7d,w(),_0xfd097);}['foreachOnPath_'](_0x5cf6f6,_0x2bcd92,_0x20107d){if(v(_0x5cf6f6))return this;{this['value']&&_0x20107d(_0x2bcd92,this['value']);const _0x1ce6ab=y(_0x5cf6f6),_0x1bc4ce=this['children']['get'](_0x1ce6ab);return _0x1bc4ce?_0x1bc4ce['foreachOnPath_'](S(_0x5cf6f6),k(_0x2bcd92,_0x1ce6ab),_0x20107d):new b(null);}}['foreach'](_0x5937a7){this['foreach_'](w(),_0x5937a7);}['foreach_'](_0x3255f0,_0x2fd2a5){this['children']['inorderTraversal']((_0x28e0c5,_0x4b6d30)=>{_0x4b6d30['foreach_'](k(_0x3255f0,_0x28e0c5),_0x2fd2a5);}),this['value']&&_0x2fd2a5(_0x3255f0,this['value']);}['foreachChild'](_0x270211){this['children']['inorderTraversal']((_0x3b1a3a,_0x391805)=>{_0x391805['value']&&_0x270211(_0x3b1a3a,_0x391805['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x507a8a){this['writeTree_']=_0x507a8a;}static['empty'](){return new K(new b(null));}}function At(_0x199262,_0x8a91dc,_0x1aa0f5){if(v(_0x8a91dc))return new K(new b(_0x1aa0f5));{const _0x4f2465=_0x199262['writeTree_']['findRootMostValueAndPath'](_0x8a91dc);if(_0x4f2465!=null){const _0x201d6f=_0x4f2465['path'];let _0x50b985=_0x4f2465['value'];const _0x587063=F(_0x201d6f,_0x8a91dc);return _0x50b985=_0x50b985['updateChild'](_0x587063,_0x1aa0f5),new K(_0x199262['writeTree_']['set'](_0x201d6f,_0x50b985));}else{const _0x2633ce=new b(_0x1aa0f5),_0x714e29=_0x199262['writeTree_']['setTree'](_0x8a91dc,_0x2633ce);return new K(_0x714e29);}}}function bi(_0x28ff9c,_0x112333,_0x44ea7d){let _0x506d70=_0x28ff9c;return x(_0x44ea7d,(_0x56bc4b,_0x315188)=>{_0x506d70=At(_0x506d70,k(_0x112333,_0x56bc4b),_0x315188);}),_0x506d70;}function or(_0x55defd,_0x4e4691){if(v(_0x4e4691))return K['empty']();{const _0x1c25aa=_0x55defd['writeTree_']['setTree'](_0x4e4691,new b(null));return new K(_0x1c25aa);}}function Ri(_0x240895,_0xb9d315){return ze(_0x240895,_0xb9d315)!=null;}function ze(_0x509c56,_0x12d313){const _0x512986=_0x509c56['writeTree_']['findRootMostValueAndPath'](_0x12d313);return _0x512986!=null?_0x509c56['writeTree_']['get'](_0x512986['path'])['getChild'](F(_0x512986['path'],_0x12d313)):null;}function ar(_0x3c5015){const _0x25d738=[],_0x552e77=_0x3c5015['writeTree_']['value'];return _0x552e77!=null?_0x552e77['isLeafNode']()||_0x552e77['forEachChild'](R,(_0x139ae,_0x2703b0)=>{_0x25d738['push'](new E(_0x139ae,_0x2703b0));}):_0x3c5015['writeTree_']['children']['inorderTraversal']((_0x5af395,_0xc7a6b5)=>{_0xc7a6b5['value']!=null&&_0x25d738['push'](new E(_0x5af395,_0xc7a6b5['value']));}),_0x25d738;}function Ee(_0x478775,_0x183b47){if(v(_0x183b47))return _0x478775;{const _0x557148=ze(_0x478775,_0x183b47);return _0x557148!=null?new K(new b(_0x557148)):new K(_0x478775['writeTree_']['subtree'](_0x183b47));}}function Ai(_0x1c6bb4){return _0x1c6bb4['writeTree_']['isEmpty']();}function at(_0x3dd3d7,_0x1e19f5){return Uo(w(),_0x3dd3d7['writeTree_'],_0x1e19f5);}function Uo(_0x96f80f,_0x4350b3,_0x474b9a){if(_0x4350b3['value']!=null)return _0x474b9a['updateChild'](_0x96f80f,_0x4350b3['value']);{let _0x1a6803=null;return _0x4350b3['children']['inorderTraversal']((_0x314f56,_0x25e61f)=>{_0x314f56==='.priority'?(f(_0x25e61f['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x1a6803=_0x25e61f['value']):_0x474b9a=Uo(k(_0x96f80f,_0x314f56),_0x25e61f,_0x474b9a);}),!_0x474b9a['getChild'](_0x96f80f)['isEmpty']()&&_0x1a6803!==null&&(_0x474b9a=_0x474b9a['updateChild'](k(_0x96f80f,'.priority'),_0x1a6803)),_0x474b9a;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x5d6612,_0x4b5f70){return Ho(_0x4b5f70,_0x5d6612);}function lu(_0x33cc9f,_0x341747,_0x56483d,_0x14a68a,_0xb1dd54){f(_0x14a68a>_0x33cc9f['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0xb1dd54===void 0x0&&(_0xb1dd54=!0x0),_0x33cc9f['allWrites']['push']({'path':_0x341747,'snap':_0x56483d,'writeId':_0x14a68a,'visible':_0xb1dd54}),_0xb1dd54&&(_0x33cc9f['visibleWrites']=At(_0x33cc9f['visibleWrites'],_0x341747,_0x56483d)),_0x33cc9f['lastWriteId']=_0x14a68a;}function hu(_0x45eda7,_0x4db709,_0x54f893,_0x521201){f(_0x521201>_0x45eda7['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x45eda7['allWrites']['push']({'path':_0x4db709,'children':_0x54f893,'writeId':_0x521201,'visible':!0x0}),_0x45eda7['visibleWrites']=bi(_0x45eda7['visibleWrites'],_0x4db709,_0x54f893),_0x45eda7['lastWriteId']=_0x521201;}function uu(_0x4a56c4,_0x108e62){for(let _0x4e5af4=0x0;_0x4e5af4<_0x4a56c4['allWrites']['length'];_0x4e5af4++){const _0x5c007d=_0x4a56c4['allWrites'][_0x4e5af4];if(_0x5c007d['writeId']===_0x108e62)return _0x5c007d;}return null;}function du(_0x2de2b3,_0x457464){const _0x1ae452=_0x2de2b3['allWrites']['findIndex'](_0x14ea88=>_0x14ea88['writeId']===_0x457464);f(_0x1ae452>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x478e45=_0x2de2b3['allWrites'][_0x1ae452];_0x2de2b3['allWrites']['splice'](_0x1ae452,0x1);let _0xe5021=_0x478e45['visible'],_0x254262=!0x1,_0x25a381=_0x2de2b3['allWrites']['length']-0x1;for(;_0xe5021&&_0x25a381>=0x0;){const _0x579430=_0x2de2b3['allWrites'][_0x25a381];_0x579430['visible']&&(_0x25a381>=_0x1ae452&&fu(_0x579430,_0x478e45['path'])?_0xe5021=!0x1:G(_0x478e45['path'],_0x579430['path'])&&(_0x254262=!0x0)),_0x25a381--;}if(_0xe5021){if(_0x254262)return pu(_0x2de2b3),!0x0;if(_0x478e45['snap'])_0x2de2b3['visibleWrites']=or(_0x2de2b3['visibleWrites'],_0x478e45['path']);else{const _0x57788c=_0x478e45['children'];x(_0x57788c,_0x5829a7=>{_0x2de2b3['visibleWrites']=or(_0x2de2b3['visibleWrites'],k(_0x478e45['path'],_0x5829a7));});}return!0x0;}else return!0x1;}function fu(_0x46a78b,_0x4c6bf5){if(_0x46a78b['snap'])return G(_0x46a78b['path'],_0x4c6bf5);for(const _0x320a89 in _0x46a78b['children'])if(_0x46a78b['children']['hasOwnProperty'](_0x320a89)&&G(k(_0x46a78b['path'],_0x320a89),_0x4c6bf5))return!0x0;return!0x1;}function pu(_0x29eb48){_0x29eb48['visibleWrites']=Wo(_0x29eb48['allWrites'],_u,w()),_0x29eb48['allWrites']['length']>0x0?_0x29eb48['lastWriteId']=_0x29eb48['allWrites'][_0x29eb48['allWrites']['length']-0x1]['writeId']:_0x29eb48['lastWriteId']=-0x1;}function _u(_0x145b47){return _0x145b47['visible'];}function Wo(_0x221bca,_0x2a1a25,_0x3f0ac7){let _0x2bb2a7=K['empty']();for(let _0x2e0780=0x0;_0x2e0780<_0x221bca['length'];++_0x2e0780){const _0x3903bb=_0x221bca[_0x2e0780];if(_0x2a1a25(_0x3903bb)){const _0x3ff0e8=_0x3903bb['path'];let _0x3aadc0;if(_0x3903bb['snap'])G(_0x3f0ac7,_0x3ff0e8)?(_0x3aadc0=F(_0x3f0ac7,_0x3ff0e8),_0x2bb2a7=At(_0x2bb2a7,_0x3aadc0,_0x3903bb['snap'])):G(_0x3ff0e8,_0x3f0ac7)&&(_0x3aadc0=F(_0x3ff0e8,_0x3f0ac7),_0x2bb2a7=At(_0x2bb2a7,w(),_0x3903bb['snap']['getChild'](_0x3aadc0)));else{if(_0x3903bb['children']){if(G(_0x3f0ac7,_0x3ff0e8))_0x3aadc0=F(_0x3f0ac7,_0x3ff0e8),_0x2bb2a7=bi(_0x2bb2a7,_0x3aadc0,_0x3903bb['children']);else{if(G(_0x3ff0e8,_0x3f0ac7)){if(_0x3aadc0=F(_0x3ff0e8,_0x3f0ac7),v(_0x3aadc0))_0x2bb2a7=bi(_0x2bb2a7,w(),_0x3903bb['children']);else{const _0x4af79b=Le(_0x3903bb['children'],y(_0x3aadc0));if(_0x4af79b){const _0x41cb32=_0x4af79b['getChild'](S(_0x3aadc0));_0x2bb2a7=At(_0x2bb2a7,w(),_0x41cb32);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x2bb2a7;}function Bo(_0x24b4d1,_0x2b7e45,_0x29e718,_0x134f99,_0x5275d4){if(!_0x134f99&&!_0x5275d4){const _0x2bc72c=ze(_0x24b4d1['visibleWrites'],_0x2b7e45);if(_0x2bc72c!=null)return _0x2bc72c;{const _0x3adf58=Ee(_0x24b4d1['visibleWrites'],_0x2b7e45);if(Ai(_0x3adf58))return _0x29e718;if(_0x29e718==null&&!Ri(_0x3adf58,w()))return null;{const _0x238c67=_0x29e718||g['EMPTY_NODE'];return at(_0x3adf58,_0x238c67);}}}else{const _0x13b864=Ee(_0x24b4d1['visibleWrites'],_0x2b7e45);if(!_0x5275d4&&Ai(_0x13b864))return _0x29e718;if(!_0x5275d4&&_0x29e718==null&&!Ri(_0x13b864,w()))return null;{const _0x20a016=function(_0x5cc257){return(_0x5cc257['visible']||_0x5275d4)&&(!_0x134f99||!~_0x134f99['indexOf'](_0x5cc257['writeId']))&&(G(_0x5cc257['path'],_0x2b7e45)||G(_0x2b7e45,_0x5cc257['path']));},_0x12f292=Wo(_0x24b4d1['allWrites'],_0x20a016,_0x2b7e45),_0xc03a96=_0x29e718||g['EMPTY_NODE'];return at(_0x12f292,_0xc03a96);}}}function gu(_0x54615b,_0x2408b9,_0x4b31c7){let _0x1454bd=g['EMPTY_NODE'];const _0xe424d3=ze(_0x54615b['visibleWrites'],_0x2408b9);if(_0xe424d3)return _0xe424d3['isLeafNode']()||_0xe424d3['forEachChild'](R,(_0x4e6759,_0x11d3dc)=>{_0x1454bd=_0x1454bd['updateImmediateChild'](_0x4e6759,_0x11d3dc);}),_0x1454bd;if(_0x4b31c7){const _0x445ee3=Ee(_0x54615b['visibleWrites'],_0x2408b9);return _0x4b31c7['forEachChild'](R,(_0x2a9e7a,_0x4d7fb0)=>{const _0x4a84b2=at(Ee(_0x445ee3,new C(_0x2a9e7a)),_0x4d7fb0);_0x1454bd=_0x1454bd['updateImmediateChild'](_0x2a9e7a,_0x4a84b2);}),ar(_0x445ee3)['forEach'](_0x18258b=>{_0x1454bd=_0x1454bd['updateImmediateChild'](_0x18258b['name'],_0x18258b['node']);}),_0x1454bd;}else{const _0x2eb482=Ee(_0x54615b['visibleWrites'],_0x2408b9);return ar(_0x2eb482)['forEach'](_0x4ec070=>{_0x1454bd=_0x1454bd['updateImmediateChild'](_0x4ec070['name'],_0x4ec070['node']);}),_0x1454bd;}}function mu(_0x563eed,_0xe9496b,_0x5528fa,_0x4b47a,_0x4c70fe){f(_0x4b47a||_0x4c70fe,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x138f08=k(_0xe9496b,_0x5528fa);if(Ri(_0x563eed['visibleWrites'],_0x138f08))return null;{const _0x647e1f=Ee(_0x563eed['visibleWrites'],_0x138f08);return Ai(_0x647e1f)?_0x4c70fe['getChild'](_0x5528fa):at(_0x647e1f,_0x4c70fe['getChild'](_0x5528fa));}}function yu(_0x2a0f34,_0x22057c,_0x4d0133,_0x1049dc){const _0x5950f2=k(_0x22057c,_0x4d0133),_0x26eb19=ze(_0x2a0f34['visibleWrites'],_0x5950f2);if(_0x26eb19!=null)return _0x26eb19;if(_0x1049dc['isCompleteForChild'](_0x4d0133)){const _0x496ab6=Ee(_0x2a0f34['visibleWrites'],_0x5950f2);return at(_0x496ab6,_0x1049dc['getNode']()['getImmediateChild'](_0x4d0133));}else return null;}function vu(_0x35bfc7,_0x2cf04e){return ze(_0x35bfc7['visibleWrites'],_0x2cf04e);}function Eu(_0x4df22d,_0x4e9b08,_0x192758,_0x33370b,_0x250f07,_0x1a385f,_0x2a3db2){let _0x4d79f4;const _0xfc3dfa=Ee(_0x4df22d['visibleWrites'],_0x4e9b08),_0x53b46b=ze(_0xfc3dfa,w());if(_0x53b46b!=null)_0x4d79f4=_0x53b46b;else{if(_0x192758!=null)_0x4d79f4=at(_0xfc3dfa,_0x192758);else return[];}if(_0x4d79f4=_0x4d79f4['withIndex'](_0x2a3db2),!_0x4d79f4['isEmpty']()&&!_0x4d79f4['isLeafNode']()){const _0x5cef9c=[],_0x1ea281=_0x2a3db2['getCompare'](),_0x25b7de=_0x1a385f?_0x4d79f4['getReverseIteratorFrom'](_0x33370b,_0x2a3db2):_0x4d79f4['getIteratorFrom'](_0x33370b,_0x2a3db2);let _0x24fc0e=_0x25b7de['getNext']();for(;_0x24fc0e&&_0x5cef9c['length']<_0x250f07;)_0x1ea281(_0x24fc0e,_0x33370b)!==0x0&&_0x5cef9c['push'](_0x24fc0e),_0x24fc0e=_0x25b7de['getNext']();return _0x5cef9c;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x23d607,_0x3897d6,_0x4e9ef3,_0x536054){return Bo(_0x23d607['writeTree'],_0x23d607['treePath'],_0x3897d6,_0x4e9ef3,_0x536054);}function is(_0x30f71f,_0x4110b3){return gu(_0x30f71f['writeTree'],_0x30f71f['treePath'],_0x4110b3);}function cr(_0x3f054e,_0x55371e,_0x2d0a52,_0x43199e){return mu(_0x3f054e['writeTree'],_0x3f054e['treePath'],_0x55371e,_0x2d0a52,_0x43199e);}function Tn(_0x35771c,_0xc19384){return vu(_0x35771c['writeTree'],k(_0x35771c['treePath'],_0xc19384));}function wu(_0x5620d1,_0x38a9db,_0x2a37c8,_0x404f26,_0x5c13de,_0x16de2d){return Eu(_0x5620d1['writeTree'],_0x5620d1['treePath'],_0x38a9db,_0x2a37c8,_0x404f26,_0x5c13de,_0x16de2d);}function ss(_0x236830,_0x4ce6b6,_0x40175a){return yu(_0x236830['writeTree'],_0x236830['treePath'],_0x4ce6b6,_0x40175a);}function Vo(_0x418978,_0x575c72){return Ho(k(_0x418978['treePath'],_0x575c72),_0x418978['writeTree']);}function Ho(_0x2531d6,_0x44bd8a){return{'treePath':_0x2531d6,'writeTree':_0x44bd8a};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x35d9fb){const _0x6d5152=_0x35d9fb['type'],_0x50b90b=_0x35d9fb['childName'];f(_0x6d5152==='child_added'||_0x6d5152==='child_changed'||_0x6d5152==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x50b90b!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x3ee845=this['changeMap']['get'](_0x50b90b);if(_0x3ee845){const _0x12ce85=_0x3ee845['type'];if(_0x6d5152==='child_added'&&_0x12ce85==='child_removed')this['changeMap']['set'](_0x50b90b,xt(_0x50b90b,_0x35d9fb['snapshotNode'],_0x3ee845['snapshotNode']));else{if(_0x6d5152==='child_removed'&&_0x12ce85==='child_added')this['changeMap']['delete'](_0x50b90b);else{if(_0x6d5152==='child_removed'&&_0x12ce85==='child_changed')this['changeMap']['set'](_0x50b90b,Lt(_0x50b90b,_0x3ee845['oldSnap']));else{if(_0x6d5152==='child_changed'&&_0x12ce85==='child_added')this['changeMap']['set'](_0x50b90b,rt(_0x50b90b,_0x35d9fb['snapshotNode']));else{if(_0x6d5152==='child_changed'&&_0x12ce85==='child_changed')this['changeMap']['set'](_0x50b90b,xt(_0x50b90b,_0x35d9fb['snapshotNode'],_0x3ee845['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x35d9fb+'\x20occurred\x20after\x20'+_0x3ee845);}}}}}else this['changeMap']['set'](_0x50b90b,_0x35d9fb);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x5a3a89){return null;}['getChildAfterChild'](_0x28f9d9,_0x5a9705,_0x483ef4){return null;}}const $o=new Tu();class rs{constructor(_0x74293c,_0xc00c27,_0x5ca14c=null){this['writes_']=_0x74293c,this['viewCache_']=_0xc00c27,this['optCompleteServerCache_']=_0x5ca14c;}['getCompleteChild'](_0x33f759){const _0x41e454=this['viewCache_']['eventCache'];if(_0x41e454['isCompleteForChild'](_0x33f759))return _0x41e454['getNode']()['getImmediateChild'](_0x33f759);{const _0x13c11b=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x33f759,_0x13c11b);}}['getChildAfterChild'](_0x393826,_0xfae0f4,_0x2dd62d){const _0x35e4d8=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x595a0d=wu(this['writes_'],_0x35e4d8,_0xfae0f4,0x1,_0x2dd62d,_0x393826);return _0x595a0d['length']===0x0?null:_0x595a0d[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0xe24e3a){return{'filter':_0xe24e3a};}function bu(_0x3e8694,_0x3261cf){f(_0x3261cf['eventCache']['getNode']()['isIndexed'](_0x3e8694['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x3261cf['serverCache']['getNode']()['isIndexed'](_0x3e8694['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x195a02,_0x5ae2ef,_0x27aab4,_0x5048af,_0x257b04){const _0x74bc9=new Cu();let _0x4c8713,_0x46afe4;if(_0x27aab4['type']===z['OVERWRITE']){const _0x50d0f2=_0x27aab4;_0x50d0f2['source']['fromUser']?_0x4c8713=ki(_0x195a02,_0x5ae2ef,_0x50d0f2['path'],_0x50d0f2['snap'],_0x5048af,_0x257b04,_0x74bc9):(f(_0x50d0f2['source']['fromServer'],'Unknown\x20source.'),_0x46afe4=_0x50d0f2['source']['tagged']||_0x5ae2ef['serverCache']['isFiltered']()&&!v(_0x50d0f2['path']),_0x4c8713=Sn(_0x195a02,_0x5ae2ef,_0x50d0f2['path'],_0x50d0f2['snap'],_0x5048af,_0x257b04,_0x46afe4,_0x74bc9));}else{if(_0x27aab4['type']===z['MERGE']){const _0x513c10=_0x27aab4;_0x513c10['source']['fromUser']?_0x4c8713=ku(_0x195a02,_0x5ae2ef,_0x513c10['path'],_0x513c10['children'],_0x5048af,_0x257b04,_0x74bc9):(f(_0x513c10['source']['fromServer'],'Unknown\x20source.'),_0x46afe4=_0x513c10['source']['tagged']||_0x5ae2ef['serverCache']['isFiltered'](),_0x4c8713=Pi(_0x195a02,_0x5ae2ef,_0x513c10['path'],_0x513c10['children'],_0x5048af,_0x257b04,_0x46afe4,_0x74bc9));}else{if(_0x27aab4['type']===z['ACK_USER_WRITE']){const _0x2912bb=_0x27aab4;_0x2912bb['revert']?_0x4c8713=Ou(_0x195a02,_0x5ae2ef,_0x2912bb['path'],_0x5048af,_0x257b04,_0x74bc9):_0x4c8713=Pu(_0x195a02,_0x5ae2ef,_0x2912bb['path'],_0x2912bb['affectedTree'],_0x5048af,_0x257b04,_0x74bc9);}else{if(_0x27aab4['type']===z['LISTEN_COMPLETE'])_0x4c8713=Nu(_0x195a02,_0x5ae2ef,_0x27aab4['path'],_0x5048af,_0x74bc9);else throw ht('Unknown\x20operation\x20type:\x20'+_0x27aab4['type']);}}}const _0x5e8ce4=_0x74bc9['getChanges']();return Au(_0x5ae2ef,_0x4c8713,_0x5e8ce4),{'viewCache':_0x4c8713,'changes':_0x5e8ce4};}function Au(_0x59d466,_0xbf5024,_0x3d10ff){const _0x196d76=_0xbf5024['eventCache'];if(_0x196d76['isFullyInitialized']()){const _0x281d3e=_0x196d76['getNode']()['isLeafNode']()||_0x196d76['getNode']()['isEmpty'](),_0xca0739=wn(_0x59d466);(_0x3d10ff['length']>0x0||!_0x59d466['eventCache']['isFullyInitialized']()||_0x281d3e&&!_0x196d76['getNode']()['equals'](_0xca0739)||!_0x196d76['getNode']()['getPriority']()['equals'](_0xca0739['getPriority']()))&&_0x3d10ff['push'](Lo(wn(_0xbf5024)));}}function Go(_0x2419ab,_0x645d3d,_0x43afed,_0x3c938c,_0x3f2d70,_0x52e703){const _0x4fe4de=_0x645d3d['eventCache'];if(Tn(_0x3c938c,_0x43afed)!=null)return _0x645d3d;{let _0x4eda5e,_0x5c3c30;if(v(_0x43afed)){if(f(_0x645d3d['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x645d3d['serverCache']['isFiltered']()){const _0x41c071=Ve(_0x645d3d),_0x1f560c=_0x41c071 instanceof g?_0x41c071:g['EMPTY_NODE'],_0x3d29e7=is(_0x3c938c,_0x1f560c);_0x4eda5e=_0x2419ab['filter']['updateFullNode'](_0x645d3d['eventCache']['getNode'](),_0x3d29e7,_0x52e703);}else{const _0x547f54=Cn(_0x3c938c,Ve(_0x645d3d));_0x4eda5e=_0x2419ab['filter']['updateFullNode'](_0x645d3d['eventCache']['getNode'](),_0x547f54,_0x52e703);}}else{const _0xca7a65=y(_0x43afed);if(_0xca7a65==='.priority'){f(Ce(_0x43afed)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x2aea4a=_0x4fe4de['getNode']();_0x5c3c30=_0x645d3d['serverCache']['getNode']();const _0x11c10a=cr(_0x3c938c,_0x43afed,_0x2aea4a,_0x5c3c30);_0x11c10a!=null?_0x4eda5e=_0x2419ab['filter']['updatePriority'](_0x2aea4a,_0x11c10a):_0x4eda5e=_0x4fe4de['getNode']();}else{const _0x3ff498=S(_0x43afed);let _0x51b97f;if(_0x4fe4de['isCompleteForChild'](_0xca7a65)){_0x5c3c30=_0x645d3d['serverCache']['getNode']();const _0x47f9f5=cr(_0x3c938c,_0x43afed,_0x4fe4de['getNode'](),_0x5c3c30);_0x47f9f5!=null?_0x51b97f=_0x4fe4de['getNode']()['getImmediateChild'](_0xca7a65)['updateChild'](_0x3ff498,_0x47f9f5):_0x51b97f=_0x4fe4de['getNode']()['getImmediateChild'](_0xca7a65);}else _0x51b97f=ss(_0x3c938c,_0xca7a65,_0x645d3d['serverCache']);_0x51b97f!=null?_0x4eda5e=_0x2419ab['filter']['updateChild'](_0x4fe4de['getNode'](),_0xca7a65,_0x51b97f,_0x3ff498,_0x3f2d70,_0x52e703):_0x4eda5e=_0x4fe4de['getNode']();}}return Rt(_0x645d3d,_0x4eda5e,_0x4fe4de['isFullyInitialized']()||v(_0x43afed),_0x2419ab['filter']['filtersNodes']());}}function Sn(_0x46f316,_0x3076ca,_0x4d22ae,_0x58abba,_0x3afa5a,_0x3bb2e1,_0x20f6c9,_0x49654b){const _0x59c96c=_0x3076ca['serverCache'];let _0x2d70bc;const _0x4f3900=_0x20f6c9?_0x46f316['filter']:_0x46f316['filter']['getIndexedFilter']();if(v(_0x4d22ae))_0x2d70bc=_0x4f3900['updateFullNode'](_0x59c96c['getNode'](),_0x58abba,null);else{if(_0x4f3900['filtersNodes']()&&!_0x59c96c['isFiltered']()){const _0x585152=_0x59c96c['getNode']()['updateChild'](_0x4d22ae,_0x58abba);_0x2d70bc=_0x4f3900['updateFullNode'](_0x59c96c['getNode'](),_0x585152,null);}else{const _0x24c270=y(_0x4d22ae);if(!_0x59c96c['isCompleteForPath'](_0x4d22ae)&&Ce(_0x4d22ae)>0x1)return _0x3076ca;const _0x5a2f29=S(_0x4d22ae),_0x39b5d9=_0x59c96c['getNode']()['getImmediateChild'](_0x24c270)['updateChild'](_0x5a2f29,_0x58abba);_0x24c270==='.priority'?_0x2d70bc=_0x4f3900['updatePriority'](_0x59c96c['getNode'](),_0x39b5d9):_0x2d70bc=_0x4f3900['updateChild'](_0x59c96c['getNode'](),_0x24c270,_0x39b5d9,_0x5a2f29,$o,null);}}const _0x5c2bb6=Fo(_0x3076ca,_0x2d70bc,_0x59c96c['isFullyInitialized']()||v(_0x4d22ae),_0x4f3900['filtersNodes']()),_0x1a3e33=new rs(_0x3afa5a,_0x5c2bb6,_0x3bb2e1);return Go(_0x46f316,_0x5c2bb6,_0x4d22ae,_0x3afa5a,_0x1a3e33,_0x49654b);}function ki(_0x131eeb,_0x577e0e,_0xb52970,_0x57b3c1,_0x1bca77,_0x46dd1a,_0xe8d8f){const _0x290f8d=_0x577e0e['eventCache'];let _0x159a47,_0x1d723e;const _0x3d2f10=new rs(_0x1bca77,_0x577e0e,_0x46dd1a);if(v(_0xb52970))_0x1d723e=_0x131eeb['filter']['updateFullNode'](_0x577e0e['eventCache']['getNode'](),_0x57b3c1,_0xe8d8f),_0x159a47=Rt(_0x577e0e,_0x1d723e,!0x0,_0x131eeb['filter']['filtersNodes']());else{const _0x24816d=y(_0xb52970);if(_0x24816d==='.priority')_0x1d723e=_0x131eeb['filter']['updatePriority'](_0x577e0e['eventCache']['getNode'](),_0x57b3c1),_0x159a47=Rt(_0x577e0e,_0x1d723e,_0x290f8d['isFullyInitialized'](),_0x290f8d['isFiltered']());else{const _0x4bcdd8=S(_0xb52970),_0x361b47=_0x290f8d['getNode']()['getImmediateChild'](_0x24816d);let _0x430192;if(v(_0x4bcdd8))_0x430192=_0x57b3c1;else{const _0xb0086a=_0x3d2f10['getCompleteChild'](_0x24816d);_0xb0086a!=null?ji(_0x4bcdd8)==='.priority'&&_0xb0086a['getChild'](Ro(_0x4bcdd8))['isEmpty']()?_0x430192=_0xb0086a:_0x430192=_0xb0086a['updateChild'](_0x4bcdd8,_0x57b3c1):_0x430192=g['EMPTY_NODE'];}if(_0x361b47['equals'](_0x430192))_0x159a47=_0x577e0e;else{const _0x17e5bd=_0x131eeb['filter']['updateChild'](_0x290f8d['getNode'](),_0x24816d,_0x430192,_0x4bcdd8,_0x3d2f10,_0xe8d8f);_0x159a47=Rt(_0x577e0e,_0x17e5bd,_0x290f8d['isFullyInitialized'](),_0x131eeb['filter']['filtersNodes']());}}}return _0x159a47;}function lr(_0x319d21,_0x4cd858){return _0x319d21['eventCache']['isCompleteForChild'](_0x4cd858);}function ku(_0xd36be0,_0x3978ab,_0x266e08,_0x521dc7,_0x36b827,_0xffd8e9,_0x4cb985){let _0x10b52a=_0x3978ab;return _0x521dc7['foreach']((_0x1a7715,_0x311e37)=>{const _0x155aa4=k(_0x266e08,_0x1a7715);lr(_0x3978ab,y(_0x155aa4))&&(_0x10b52a=ki(_0xd36be0,_0x10b52a,_0x155aa4,_0x311e37,_0x36b827,_0xffd8e9,_0x4cb985));}),_0x521dc7['foreach']((_0x2e0aca,_0x88dba0)=>{const _0x3fa399=k(_0x266e08,_0x2e0aca);lr(_0x3978ab,y(_0x3fa399))||(_0x10b52a=ki(_0xd36be0,_0x10b52a,_0x3fa399,_0x88dba0,_0x36b827,_0xffd8e9,_0x4cb985));}),_0x10b52a;}function hr(_0x3704f8,_0x7eaa8a,_0x29eb27){return _0x29eb27['foreach']((_0x5cb21d,_0x349f90)=>{_0x7eaa8a=_0x7eaa8a['updateChild'](_0x5cb21d,_0x349f90);}),_0x7eaa8a;}function Pi(_0x176f1d,_0xdf4fe1,_0x1d7e01,_0x38d233,_0x547e55,_0x32dc41,_0x40a9cc,_0x5a84b8){if(_0xdf4fe1['serverCache']['getNode']()['isEmpty']()&&!_0xdf4fe1['serverCache']['isFullyInitialized']())return _0xdf4fe1;let _0x1879fd=_0xdf4fe1,_0x5710cc;v(_0x1d7e01)?_0x5710cc=_0x38d233:_0x5710cc=new b(null)['setTree'](_0x1d7e01,_0x38d233);const _0x180d65=_0xdf4fe1['serverCache']['getNode']();return _0x5710cc['children']['inorderTraversal']((_0x5a14ca,_0x4e635a)=>{if(_0x180d65['hasChild'](_0x5a14ca)){const _0x23021f=_0xdf4fe1['serverCache']['getNode']()['getImmediateChild'](_0x5a14ca),_0x51b691=hr(_0x176f1d,_0x23021f,_0x4e635a);_0x1879fd=Sn(_0x176f1d,_0x1879fd,new C(_0x5a14ca),_0x51b691,_0x547e55,_0x32dc41,_0x40a9cc,_0x5a84b8);}}),_0x5710cc['children']['inorderTraversal']((_0x45118a,_0xf694fd)=>{const _0x23a31f=!_0xdf4fe1['serverCache']['isCompleteForChild'](_0x45118a)&&_0xf694fd['value']===null;if(!_0x180d65['hasChild'](_0x45118a)&&!_0x23a31f){const _0x141591=_0xdf4fe1['serverCache']['getNode']()['getImmediateChild'](_0x45118a),_0x410074=hr(_0x176f1d,_0x141591,_0xf694fd);_0x1879fd=Sn(_0x176f1d,_0x1879fd,new C(_0x45118a),_0x410074,_0x547e55,_0x32dc41,_0x40a9cc,_0x5a84b8);}}),_0x1879fd;}function Pu(_0x40b206,_0x40986c,_0x1ece9c,_0x588a8e,_0x162ec4,_0x285012,_0x3fc4fd){if(Tn(_0x162ec4,_0x1ece9c)!=null)return _0x40986c;const _0x310d26=_0x40986c['serverCache']['isFiltered'](),_0x1e3b7a=_0x40986c['serverCache'];if(_0x588a8e['value']!=null){if(v(_0x1ece9c)&&_0x1e3b7a['isFullyInitialized']()||_0x1e3b7a['isCompleteForPath'](_0x1ece9c))return Sn(_0x40b206,_0x40986c,_0x1ece9c,_0x1e3b7a['getNode']()['getChild'](_0x1ece9c),_0x162ec4,_0x285012,_0x310d26,_0x3fc4fd);if(v(_0x1ece9c)){let _0x530733=new b(null);return _0x1e3b7a['getNode']()['forEachChild'](ve,(_0x2f77a4,_0x3f4063)=>{_0x530733=_0x530733['set'](new C(_0x2f77a4),_0x3f4063);}),Pi(_0x40b206,_0x40986c,_0x1ece9c,_0x530733,_0x162ec4,_0x285012,_0x310d26,_0x3fc4fd);}else return _0x40986c;}else{let _0x3cc12b=new b(null);return _0x588a8e['foreach']((_0x100158,_0x43f13e)=>{const _0xf33449=k(_0x1ece9c,_0x100158);_0x1e3b7a['isCompleteForPath'](_0xf33449)&&(_0x3cc12b=_0x3cc12b['set'](_0x100158,_0x1e3b7a['getNode']()['getChild'](_0xf33449)));}),Pi(_0x40b206,_0x40986c,_0x1ece9c,_0x3cc12b,_0x162ec4,_0x285012,_0x310d26,_0x3fc4fd);}}function Nu(_0x2e95b8,_0xfdc35,_0x1869fa,_0xc779f9,_0x2274e6){const _0x4721de=_0xfdc35['serverCache'],_0x27c81a=Fo(_0xfdc35,_0x4721de['getNode'](),_0x4721de['isFullyInitialized']()||v(_0x1869fa),_0x4721de['isFiltered']());return Go(_0x2e95b8,_0x27c81a,_0x1869fa,_0xc779f9,$o,_0x2274e6);}function Ou(_0x4a261c,_0x17c358,_0x499df2,_0x440e32,_0x3636aa,_0x454e13){let _0x3757df;if(Tn(_0x440e32,_0x499df2)!=null)return _0x17c358;{const _0x44cf3a=new rs(_0x440e32,_0x17c358,_0x3636aa),_0x5aba5e=_0x17c358['eventCache']['getNode']();let _0x509a38;if(v(_0x499df2)||y(_0x499df2)==='.priority'){let _0x248110;if(_0x17c358['serverCache']['isFullyInitialized']())_0x248110=Cn(_0x440e32,Ve(_0x17c358));else{const _0x22f5c8=_0x17c358['serverCache']['getNode']();f(_0x22f5c8 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x248110=is(_0x440e32,_0x22f5c8);}_0x248110=_0x248110,_0x509a38=_0x4a261c['filter']['updateFullNode'](_0x5aba5e,_0x248110,_0x454e13);}else{const _0x272263=y(_0x499df2);let _0x329071=ss(_0x440e32,_0x272263,_0x17c358['serverCache']);_0x329071==null&&_0x17c358['serverCache']['isCompleteForChild'](_0x272263)&&(_0x329071=_0x5aba5e['getImmediateChild'](_0x272263)),_0x329071!=null?_0x509a38=_0x4a261c['filter']['updateChild'](_0x5aba5e,_0x272263,_0x329071,S(_0x499df2),_0x44cf3a,_0x454e13):_0x17c358['eventCache']['getNode']()['hasChild'](_0x272263)?_0x509a38=_0x4a261c['filter']['updateChild'](_0x5aba5e,_0x272263,g['EMPTY_NODE'],S(_0x499df2),_0x44cf3a,_0x454e13):_0x509a38=_0x5aba5e,_0x509a38['isEmpty']()&&_0x17c358['serverCache']['isFullyInitialized']()&&(_0x3757df=Cn(_0x440e32,Ve(_0x17c358)),_0x3757df['isLeafNode']()&&(_0x509a38=_0x4a261c['filter']['updateFullNode'](_0x509a38,_0x3757df,_0x454e13)));}return _0x3757df=_0x17c358['serverCache']['isFullyInitialized']()||Tn(_0x440e32,w())!=null,Rt(_0x17c358,_0x509a38,_0x3757df,_0x4a261c['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x24ff32,_0x8d5a99){this['query_']=_0x24ff32,this['eventRegistrations_']=[];const _0x33dd63=this['query_']['_queryParams'],_0x38c3cd=new Xi(_0x33dd63['getIndex']()),_0x1b2873=Kh(_0x33dd63);this['processor_']=Su(_0x1b2873);const _0x312779=_0x8d5a99['serverCache'],_0x1195b9=_0x8d5a99['eventCache'],_0x36817f=_0x38c3cd['updateFullNode'](g['EMPTY_NODE'],_0x312779['getNode'](),null),_0x30f018=_0x1b2873['updateFullNode'](g['EMPTY_NODE'],_0x1195b9['getNode'](),null),_0x341234=new Te(_0x36817f,_0x312779['isFullyInitialized'](),_0x38c3cd['filtersNodes']()),_0x66c59e=new Te(_0x30f018,_0x1195b9['isFullyInitialized'](),_0x1b2873['filtersNodes']());this['viewCache_']=Un(_0x66c59e,_0x341234),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0xff785f){return _0xff785f['viewCache_']['serverCache']['getNode']();}function Lu(_0x47fa5e){return wn(_0x47fa5e['viewCache_']);}function xu(_0x36a077,_0x4b9599){const _0x20cc5b=Ve(_0x36a077['viewCache_']);return _0x20cc5b&&(_0x36a077['query']['_queryParams']['loadsAllData']()||!v(_0x4b9599)&&!_0x20cc5b['getImmediateChild'](y(_0x4b9599))['isEmpty']())?_0x20cc5b['getChild'](_0x4b9599):null;}function ur(_0x51a235){return _0x51a235['eventRegistrations_']['length']===0x0;}function Fu(_0xc2fd71,_0x239d74){_0xc2fd71['eventRegistrations_']['push'](_0x239d74);}function dr(_0x1fdcd3,_0x46a1ce,_0x56a936){const _0x3c5fe5=[];if(_0x56a936){f(_0x46a1ce==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x32edc8=_0x1fdcd3['query']['_path'];_0x1fdcd3['eventRegistrations_']['forEach'](_0xc44682=>{const _0x373a34=_0xc44682['createCancelEvent'](_0x56a936,_0x32edc8);_0x373a34&&_0x3c5fe5['push'](_0x373a34);});}if(_0x46a1ce){let _0x31d49f=[];for(let _0x2b7a62=0x0;_0x2b7a62<_0x1fdcd3['eventRegistrations_']['length'];++_0x2b7a62){const _0x47cdc0=_0x1fdcd3['eventRegistrations_'][_0x2b7a62];if(!_0x47cdc0['matches'](_0x46a1ce))_0x31d49f['push'](_0x47cdc0);else{if(_0x46a1ce['hasAnyCallback']()){_0x31d49f=_0x31d49f['concat'](_0x1fdcd3['eventRegistrations_']['slice'](_0x2b7a62+0x1));break;}}}_0x1fdcd3['eventRegistrations_']=_0x31d49f;}else _0x1fdcd3['eventRegistrations_']=[];return _0x3c5fe5;}function fr(_0x364f5a,_0xdf3d8c,_0x1665eb,_0x5e5d2a){_0xdf3d8c['type']===z['MERGE']&&_0xdf3d8c['source']['queryId']!==null&&(f(Ve(_0x364f5a['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x364f5a['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x1d87bd=_0x364f5a['viewCache_'],_0x15979d=Ru(_0x364f5a['processor_'],_0x1d87bd,_0xdf3d8c,_0x1665eb,_0x5e5d2a);return bu(_0x364f5a['processor_'],_0x15979d['viewCache']),f(_0x15979d['viewCache']['serverCache']['isFullyInitialized']()||!_0x1d87bd['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x364f5a['viewCache_']=_0x15979d['viewCache'],qo(_0x364f5a,_0x15979d['changes'],_0x15979d['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x5bbb73,_0xcf34c6){const _0x3661c8=_0x5bbb73['viewCache_']['eventCache'],_0x10ffe9=[];return _0x3661c8['getNode']()['isLeafNode']()||_0x3661c8['getNode']()['forEachChild'](R,(_0xc4454,_0x55b667)=>{_0x10ffe9['push'](rt(_0xc4454,_0x55b667));}),_0x3661c8['isFullyInitialized']()&&_0x10ffe9['push'](Lo(_0x3661c8['getNode']())),qo(_0x5bbb73,_0x10ffe9,_0x3661c8['getNode'](),_0xcf34c6);}function qo(_0x2126f4,_0x50e9af,_0x2df612,_0x4017dd){const _0x22d0d6=_0x4017dd?[_0x4017dd]:_0x2126f4['eventRegistrations_'];return ru(_0x2126f4['eventGenerator_'],_0x50e9af,_0x2df612,_0x22d0d6);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0xf62ca9){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0xf62ca9;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x263dd7){return _0x263dd7['views']['size']===0x0;}function os(_0x2063ea,_0x397cab,_0x293786,_0x1a2545){const _0x3aad4f=_0x397cab['source']['queryId'];if(_0x3aad4f!==null){const _0xccb342=_0x2063ea['views']['get'](_0x3aad4f);return f(_0xccb342!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0xccb342,_0x397cab,_0x293786,_0x1a2545);}else{let _0x4c96a8=[];for(const _0x1dd0f5 of _0x2063ea['views']['values']())_0x4c96a8=_0x4c96a8['concat'](fr(_0x1dd0f5,_0x397cab,_0x293786,_0x1a2545));return _0x4c96a8;}}function jo(_0x581010,_0x52a9e9,_0x127a11,_0x34d6f6,_0x442b41){const _0x500404=_0x52a9e9['_queryIdentifier'],_0x363708=_0x581010['views']['get'](_0x500404);if(!_0x363708){let _0x601a86=Cn(_0x127a11,_0x442b41?_0x34d6f6:null),_0x10b149=!0x1;_0x601a86?_0x10b149=!0x0:_0x34d6f6 instanceof g?(_0x601a86=is(_0x127a11,_0x34d6f6),_0x10b149=!0x1):(_0x601a86=g['EMPTY_NODE'],_0x10b149=!0x1);const _0x40e037=Un(new Te(_0x601a86,_0x10b149,!0x1),new Te(_0x34d6f6,_0x442b41,!0x1));return new Du(_0x52a9e9,_0x40e037);}return _0x363708;}function Hu(_0x4cf747,_0x1fe27b,_0x37742d,_0x597e7b,_0x27dd34,_0xd00bb3){const _0x88dd8b=jo(_0x4cf747,_0x1fe27b,_0x597e7b,_0x27dd34,_0xd00bb3);return _0x4cf747['views']['has'](_0x1fe27b['_queryIdentifier'])||_0x4cf747['views']['set'](_0x1fe27b['_queryIdentifier'],_0x88dd8b),Fu(_0x88dd8b,_0x37742d),Uu(_0x88dd8b,_0x37742d);}function $u(_0x5a9974,_0x4f4f30,_0x378b11,_0x18f2a5){const _0x311e6a=_0x4f4f30['_queryIdentifier'],_0x36fafd=[];let _0x21c4d1=[];const _0x31073e=Se(_0x5a9974);if(_0x311e6a==='default'){for(const [_0x420428,_0x5bd3e4]of _0x5a9974['views']['entries']())_0x21c4d1=_0x21c4d1['concat'](dr(_0x5bd3e4,_0x378b11,_0x18f2a5)),ur(_0x5bd3e4)&&(_0x5a9974['views']['delete'](_0x420428),_0x5bd3e4['query']['_queryParams']['loadsAllData']()||_0x36fafd['push'](_0x5bd3e4['query']));}else{const _0x4609e3=_0x5a9974['views']['get'](_0x311e6a);_0x4609e3&&(_0x21c4d1=_0x21c4d1['concat'](dr(_0x4609e3,_0x378b11,_0x18f2a5)),ur(_0x4609e3)&&(_0x5a9974['views']['delete'](_0x311e6a),_0x4609e3['query']['_queryParams']['loadsAllData']()||_0x36fafd['push'](_0x4609e3['query'])));}return _0x31073e&&!Se(_0x5a9974)&&_0x36fafd['push'](new(Bu())(_0x4f4f30['_repo'],_0x4f4f30['_path'])),{'removed':_0x36fafd,'events':_0x21c4d1};}function Ko(_0x5ae68e){const _0x57b097=[];for(const _0x22287e of _0x5ae68e['views']['values']())_0x22287e['query']['_queryParams']['loadsAllData']()||_0x57b097['push'](_0x22287e);return _0x57b097;}function Ie(_0x4fb946,_0x38d5a3){let _0x5b460e=null;for(const _0x3868db of _0x4fb946['views']['values']())_0x5b460e=_0x5b460e||xu(_0x3868db,_0x38d5a3);return _0x5b460e;}function Yo(_0x3b7473,_0x5f3d3a){if(_0x5f3d3a['_queryParams']['loadsAllData']())return Bn(_0x3b7473);{const _0x4e4409=_0x5f3d3a['_queryIdentifier'];return _0x3b7473['views']['get'](_0x4e4409);}}function Qo(_0x539950,_0x155188){return Yo(_0x539950,_0x155188)!=null;}function Se(_0x224faf){return Bn(_0x224faf)!=null;}function Bn(_0x5391fa){for(const _0x26c6cd of _0x5391fa['views']['values']())if(_0x26c6cd['query']['_queryParams']['loadsAllData']())return _0x26c6cd;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x3c5164){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x3c5164;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x155de1){this['listenProvider_']=_0x155de1,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x26a081,_0x1900c7,_0x5aea98,_0x5380ef,_0x4d4f40){return lu(_0x26a081['pendingWriteTree_'],_0x1900c7,_0x5aea98,_0x5380ef,_0x4d4f40),_0x4d4f40?_t(_0x26a081,new Be(es(),_0x1900c7,_0x5aea98)):[];}function ju(_0x393475,_0x6053a,_0x41327b,_0xe5de1c){hu(_0x393475['pendingWriteTree_'],_0x6053a,_0x41327b,_0xe5de1c);const _0x141b1a=b['fromObject'](_0x41327b);return _t(_0x393475,new ot(es(),_0x6053a,_0x141b1a));}function _e(_0x161da1,_0x2d96b2,_0x4b7960=!0x1){const _0x29a616=uu(_0x161da1['pendingWriteTree_'],_0x2d96b2);if(du(_0x161da1['pendingWriteTree_'],_0x2d96b2)){let _0x283241=new b(null);return _0x29a616['snap']!=null?_0x283241=_0x283241['set'](w(),!0x0):x(_0x29a616['children'],_0x24d69e=>{_0x283241=_0x283241['set'](new C(_0x24d69e),!0x0);}),_t(_0x161da1,new In(_0x29a616['path'],_0x283241,_0x4b7960));}else return[];}function Yt(_0x1c70e5,_0x3470bb,_0x5b3fa3){return _t(_0x1c70e5,new Be(ts(),_0x3470bb,_0x5b3fa3));}function Ku(_0x74cc04,_0x46f892,_0x3192fb){const _0x3e6517=b['fromObject'](_0x3192fb);return _t(_0x74cc04,new ot(ts(),_0x46f892,_0x3e6517));}function Yu(_0x376cc6,_0x2090b6){return _t(_0x376cc6,new Ut(ts(),_0x2090b6));}function Qu(_0x47bbda,_0x428709,_0x2cccb6){const _0x4b4d82=cs(_0x47bbda,_0x2cccb6);if(_0x4b4d82){const _0x569d15=ls(_0x4b4d82),_0x44d36a=_0x569d15['path'],_0x492ce0=_0x569d15['queryId'],_0x384f3c=F(_0x44d36a,_0x428709),_0x1372a0=new Ut(ns(_0x492ce0),_0x384f3c);return hs(_0x47bbda,_0x44d36a,_0x1372a0);}else return[];}function An(_0x33919a,_0x120821,_0x304cb9,_0x4dd560,_0x5ca32a=!0x1){const _0x58b7a5=_0x120821['_path'],_0x11ae4a=_0x33919a['syncPointTree_']['get'](_0x58b7a5);let _0xbe29fe=[];if(_0x11ae4a&&(_0x120821['_queryIdentifier']==='default'||Qo(_0x11ae4a,_0x120821))){const _0x30f95c=$u(_0x11ae4a,_0x120821,_0x304cb9,_0x4dd560);Vu(_0x11ae4a)&&(_0x33919a['syncPointTree_']=_0x33919a['syncPointTree_']['remove'](_0x58b7a5));const _0xf8dc35=_0x30f95c['removed'];if(_0xbe29fe=_0x30f95c['events'],!_0x5ca32a){const _0x15e9ae=_0xf8dc35['findIndex'](_0x2994a1=>_0x2994a1['_queryParams']['loadsAllData']())!==-0x1,_0x353e75=_0x33919a['syncPointTree_']['findOnPath'](_0x58b7a5,(_0x5c6d0,_0x36797e)=>Se(_0x36797e));if(_0x15e9ae&&!_0x353e75){const _0x51803a=_0x33919a['syncPointTree_']['subtree'](_0x58b7a5);if(!_0x51803a['isEmpty']()){const _0x456566=Zu(_0x51803a);for(let _0x2d3b78=0x0;_0x2d3b78<_0x456566['length'];++_0x2d3b78){const _0x371dcd=_0x456566[_0x2d3b78],_0x3ea69a=_0x371dcd['query'],_0x2706e4=ea(_0x33919a,_0x371dcd);_0x33919a['listenProvider_']['startListening'](kt(_0x3ea69a),Wt(_0x33919a,_0x3ea69a),_0x2706e4['hashFn'],_0x2706e4['onComplete']);}}}!_0x353e75&&_0xf8dc35['length']>0x0&&!_0x4dd560&&(_0x15e9ae?_0x33919a['listenProvider_']['stopListening'](kt(_0x120821),null):_0xf8dc35['forEach'](_0x2cb879=>{const _0xa3b4a6=_0x33919a['queryToTagMap']['get'](Hn(_0x2cb879));_0x33919a['listenProvider_']['stopListening'](kt(_0x2cb879),_0xa3b4a6);}));}ed(_0x33919a,_0xf8dc35);}return _0xbe29fe;}function Jo(_0x491a52,_0x27d227,_0x2a1f0c,_0x4e265e){const _0x2338a2=cs(_0x491a52,_0x4e265e);if(_0x2338a2!=null){const _0x3a247d=ls(_0x2338a2),_0x2d03fa=_0x3a247d['path'],_0x5bd3dc=_0x3a247d['queryId'],_0xda7692=F(_0x2d03fa,_0x27d227),_0x4385aa=new Be(ns(_0x5bd3dc),_0xda7692,_0x2a1f0c);return hs(_0x491a52,_0x2d03fa,_0x4385aa);}else return[];}function Ju(_0x2992bd,_0xd80fe8,_0x118b70,_0x57c5b3){const _0x4c601c=cs(_0x2992bd,_0x57c5b3);if(_0x4c601c){const _0x54ff27=ls(_0x4c601c),_0x3d6854=_0x54ff27['path'],_0x5c81eb=_0x54ff27['queryId'],_0x3ccb82=F(_0x3d6854,_0xd80fe8),_0x31922d=b['fromObject'](_0x118b70),_0x451a2c=new ot(ns(_0x5c81eb),_0x3ccb82,_0x31922d);return hs(_0x2992bd,_0x3d6854,_0x451a2c);}else return[];}function Ni(_0x3f6d20,_0x5a4751,_0x83ebe2,_0x5b3997=!0x1){const _0x5742e3=_0x5a4751['_path'];let _0x1399ce=null,_0x4461a5=!0x1;_0x3f6d20['syncPointTree_']['foreachOnPath'](_0x5742e3,(_0x2ce349,_0x51ae33)=>{const _0x4b061e=F(_0x2ce349,_0x5742e3);_0x1399ce=_0x1399ce||Ie(_0x51ae33,_0x4b061e),_0x4461a5=_0x4461a5||Se(_0x51ae33);});let _0x3e2519=_0x3f6d20['syncPointTree_']['get'](_0x5742e3);_0x3e2519?(_0x4461a5=_0x4461a5||Se(_0x3e2519),_0x1399ce=_0x1399ce||Ie(_0x3e2519,w())):(_0x3e2519=new zo(),_0x3f6d20['syncPointTree_']=_0x3f6d20['syncPointTree_']['set'](_0x5742e3,_0x3e2519));let _0x51c56c;_0x1399ce!=null?_0x51c56c=!0x0:(_0x51c56c=!0x1,_0x1399ce=g['EMPTY_NODE'],_0x3f6d20['syncPointTree_']['subtree'](_0x5742e3)['foreachChild']((_0x4bac66,_0x4a8cad)=>{const _0x4ba13d=Ie(_0x4a8cad,w());_0x4ba13d&&(_0x1399ce=_0x1399ce['updateImmediateChild'](_0x4bac66,_0x4ba13d));}));const _0x54c81d=Qo(_0x3e2519,_0x5a4751);if(!_0x54c81d&&!_0x5a4751['_queryParams']['loadsAllData']()){const _0x124607=Hn(_0x5a4751);f(!_0x3f6d20['queryToTagMap']['has'](_0x124607),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x348830=td();_0x3f6d20['queryToTagMap']['set'](_0x124607,_0x348830),_0x3f6d20['tagToQueryMap']['set'](_0x348830,_0x124607);}const _0x409d92=Wn(_0x3f6d20['pendingWriteTree_'],_0x5742e3);let _0x50472f=Hu(_0x3e2519,_0x5a4751,_0x83ebe2,_0x409d92,_0x1399ce,_0x51c56c);if(!_0x54c81d&&!_0x4461a5&&!_0x5b3997){const _0x5435e6=Yo(_0x3e2519,_0x5a4751);_0x50472f=_0x50472f['concat'](nd(_0x3f6d20,_0x5a4751,_0x5435e6));}return _0x50472f;}function Vn(_0x5e536a,_0x1490e8,_0x44e07b){const _0x47a187=_0x5e536a['pendingWriteTree_'],_0x40374c=_0x5e536a['syncPointTree_']['findOnPath'](_0x1490e8,(_0x116e60,_0x1ea31b)=>{const _0x4d82cc=F(_0x116e60,_0x1490e8),_0x210be4=Ie(_0x1ea31b,_0x4d82cc);if(_0x210be4)return _0x210be4;});return Bo(_0x47a187,_0x1490e8,_0x40374c,_0x44e07b,!0x0);}function Xu(_0x2cbcca,_0x393a79){const _0x17c92d=_0x393a79['_path'];let _0x31f966=null;_0x2cbcca['syncPointTree_']['foreachOnPath'](_0x17c92d,(_0x450f98,_0x3775d3)=>{const _0x2fd4fc=F(_0x450f98,_0x17c92d);_0x31f966=_0x31f966||Ie(_0x3775d3,_0x2fd4fc);});let _0x2cd086=_0x2cbcca['syncPointTree_']['get'](_0x17c92d);_0x2cd086?_0x31f966=_0x31f966||Ie(_0x2cd086,w()):(_0x2cd086=new zo(),_0x2cbcca['syncPointTree_']=_0x2cbcca['syncPointTree_']['set'](_0x17c92d,_0x2cd086));const _0x3015d6=_0x31f966!=null,_0x36eb7e=_0x3015d6?new Te(_0x31f966,!0x0,!0x1):null,_0x3f7e44=Wn(_0x2cbcca['pendingWriteTree_'],_0x393a79['_path']),_0x410fac=jo(_0x2cd086,_0x393a79,_0x3f7e44,_0x3015d6?_0x36eb7e['getNode']():g['EMPTY_NODE'],_0x3015d6);return Lu(_0x410fac);}function _t(_0x21494,_0x285d08){return Xo(_0x285d08,_0x21494['syncPointTree_'],null,Wn(_0x21494['pendingWriteTree_'],w()));}function Xo(_0x3a6e50,_0x45e7aa,_0x36abab,_0x5b36bc){if(v(_0x3a6e50['path']))return Zo(_0x3a6e50,_0x45e7aa,_0x36abab,_0x5b36bc);{const _0x3020ba=_0x45e7aa['get'](w());_0x36abab==null&&_0x3020ba!=null&&(_0x36abab=Ie(_0x3020ba,w()));let _0x5e6d8d=[];const _0x29fe6b=y(_0x3a6e50['path']),_0x615a53=_0x3a6e50['operationForChild'](_0x29fe6b),_0x2c2623=_0x45e7aa['children']['get'](_0x29fe6b);if(_0x2c2623&&_0x615a53){const _0x17c20c=_0x36abab?_0x36abab['getImmediateChild'](_0x29fe6b):null,_0x1b6571=Vo(_0x5b36bc,_0x29fe6b);_0x5e6d8d=_0x5e6d8d['concat'](Xo(_0x615a53,_0x2c2623,_0x17c20c,_0x1b6571));}return _0x3020ba&&(_0x5e6d8d=_0x5e6d8d['concat'](os(_0x3020ba,_0x3a6e50,_0x5b36bc,_0x36abab))),_0x5e6d8d;}}function Zo(_0x1cd5d1,_0xc66e61,_0x40a78c,_0x395cc0){const _0x2f32db=_0xc66e61['get'](w());_0x40a78c==null&&_0x2f32db!=null&&(_0x40a78c=Ie(_0x2f32db,w()));let _0xede76e=[];return _0xc66e61['children']['inorderTraversal']((_0x5c21e9,_0x1b5067)=>{const _0x391003=_0x40a78c?_0x40a78c['getImmediateChild'](_0x5c21e9):null,_0x47d608=Vo(_0x395cc0,_0x5c21e9),_0x4ee391=_0x1cd5d1['operationForChild'](_0x5c21e9);_0x4ee391&&(_0xede76e=_0xede76e['concat'](Zo(_0x4ee391,_0x1b5067,_0x391003,_0x47d608)));}),_0x2f32db&&(_0xede76e=_0xede76e['concat'](os(_0x2f32db,_0x1cd5d1,_0x395cc0,_0x40a78c))),_0xede76e;}function ea(_0x1c6422,_0x1b7988){const _0x50f3be=_0x1b7988['query'],_0x249127=Wt(_0x1c6422,_0x50f3be);return{'hashFn':()=>(Mu(_0x1b7988)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x24c17b=>{if(_0x24c17b==='ok')return _0x249127?Qu(_0x1c6422,_0x50f3be['_path'],_0x249127):Yu(_0x1c6422,_0x50f3be['_path']);{const _0x134ed5=Kl(_0x24c17b,_0x50f3be);return An(_0x1c6422,_0x50f3be,null,_0x134ed5);}}};}function Wt(_0x2a44bb,_0x321c63){const _0x2d47fe=Hn(_0x321c63);return _0x2a44bb['queryToTagMap']['get'](_0x2d47fe);}function Hn(_0x47fb5b){return _0x47fb5b['_path']['toString']()+'$'+_0x47fb5b['_queryIdentifier'];}function cs(_0x24930f,_0x36c803){return _0x24930f['tagToQueryMap']['get'](_0x36c803);}function ls(_0x4850a0){const _0x495e8f=_0x4850a0['indexOf']('$');return f(_0x495e8f!==-0x1&&_0x495e8f<_0x4850a0['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x4850a0['substr'](_0x495e8f+0x1),'path':new C(_0x4850a0['substr'](0x0,_0x495e8f))};}function hs(_0x445616,_0x44760b,_0x292e90){const _0x300d61=_0x445616['syncPointTree_']['get'](_0x44760b);f(_0x300d61,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x559947=Wn(_0x445616['pendingWriteTree_'],_0x44760b);return os(_0x300d61,_0x292e90,_0x559947,null);}function Zu(_0x5eab00){return _0x5eab00['fold']((_0x52a3de,_0x3012a2,_0x4f7ef1)=>{if(_0x3012a2&&Se(_0x3012a2))return[Bn(_0x3012a2)];{let _0x10fe1a=[];return _0x3012a2&&(_0x10fe1a=Ko(_0x3012a2)),x(_0x4f7ef1,(_0x341f38,_0x1b32cf)=>{_0x10fe1a=_0x10fe1a['concat'](_0x1b32cf);}),_0x10fe1a;}});}function kt(_0x435705){return _0x435705['_queryParams']['loadsAllData']()&&!_0x435705['_queryParams']['isDefault']()?new(qu())(_0x435705['_repo'],_0x435705['_path']):_0x435705;}function ed(_0x25738f,_0x2aa3ab){for(let _0x32f88f=0x0;_0x32f88f<_0x2aa3ab['length'];++_0x32f88f){const _0x2b01fd=_0x2aa3ab[_0x32f88f];if(!_0x2b01fd['_queryParams']['loadsAllData']()){const _0x2c9344=Hn(_0x2b01fd),_0xe7791f=_0x25738f['queryToTagMap']['get'](_0x2c9344);_0x25738f['queryToTagMap']['delete'](_0x2c9344),_0x25738f['tagToQueryMap']['delete'](_0xe7791f);}}}function td(){return zu++;}function nd(_0x73299c,_0x311ca8,_0x2f082a){const _0x291d79=_0x311ca8['_path'],_0x5e324c=Wt(_0x73299c,_0x311ca8),_0x5af208=ea(_0x73299c,_0x2f082a),_0xcf5801=_0x73299c['listenProvider_']['startListening'](kt(_0x311ca8),_0x5e324c,_0x5af208['hashFn'],_0x5af208['onComplete']),_0x121183=_0x73299c['syncPointTree_']['subtree'](_0x291d79);if(_0x5e324c)f(!Se(_0x121183['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x2b9852=_0x121183['fold']((_0x769d62,_0x1bc301,_0x356345)=>{if(!v(_0x769d62)&&_0x1bc301&&Se(_0x1bc301))return[Bn(_0x1bc301)['query']];{let _0x2a215d=[];return _0x1bc301&&(_0x2a215d=_0x2a215d['concat'](Ko(_0x1bc301)['map'](_0x2b6457=>_0x2b6457['query']))),x(_0x356345,(_0x13bf83,_0x1ba87c)=>{_0x2a215d=_0x2a215d['concat'](_0x1ba87c);}),_0x2a215d;}});for(let _0x4cecbb=0x0;_0x4cecbb<_0x2b9852['length'];++_0x4cecbb){const _0x1ad88a=_0x2b9852[_0x4cecbb];_0x73299c['listenProvider_']['stopListening'](kt(_0x1ad88a),Wt(_0x73299c,_0x1ad88a));}}return _0xcf5801;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x578139){this['node_']=_0x578139;}['getImmediateChild'](_0x4a986b){const _0x2ca86e=this['node_']['getImmediateChild'](_0x4a986b);return new us(_0x2ca86e);}['node'](){return this['node_'];}}class ds{constructor(_0x29ca22,_0x2ec4a9){this['syncTree_']=_0x29ca22,this['path_']=_0x2ec4a9;}['getImmediateChild'](_0x2ad562){const _0x27d498=k(this['path_'],_0x2ad562);return new ds(this['syncTree_'],_0x27d498);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x5ca3c2){return _0x5ca3c2=_0x5ca3c2||{},_0x5ca3c2['timestamp']=_0x5ca3c2['timestamp']||new Date()['getTime'](),_0x5ca3c2;},_r=function(_0x59fe12,_0x587e46,_0x40f183){if(!_0x59fe12||typeof _0x59fe12!='object')return _0x59fe12;if(f('.sv'in _0x59fe12,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x59fe12['.sv']=='string')return sd(_0x59fe12['.sv'],_0x587e46,_0x40f183);if(typeof _0x59fe12['.sv']=='object')return rd(_0x59fe12['.sv'],_0x587e46);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x59fe12,null,0x2));},sd=function(_0x538059,_0x1bda55,_0x2c1945){switch(_0x538059){case'timestamp':return _0x2c1945['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x538059);}},rd=function(_0x5c8f7a,_0x2a4d7f,_0x3fb052){_0x5c8f7a['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x5c8f7a,null,0x2));const _0x12526c=_0x5c8f7a['increment'];typeof _0x12526c!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x12526c);const _0x260166=_0x2a4d7f['node']();if(f(_0x260166!==null&&typeof _0x260166<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x260166['isLeafNode']())return _0x12526c;const _0x5d9a52=_0x260166['getValue']();return typeof _0x5d9a52!='number'?_0x12526c:_0x5d9a52+_0x12526c;},ta=function(_0x15df31,_0x27f5e4,_0x26f3e5,_0xb4eb8d){return ps(_0x27f5e4,new ds(_0x26f3e5,_0x15df31),_0xb4eb8d);},fs=function(_0x5740a7,_0x2a7ca2,_0x380f14){return ps(_0x5740a7,new us(_0x2a7ca2),_0x380f14);};function ps(_0x471104,_0x43e54e,_0x52fa73){const _0x43fafe=_0x471104['getPriority']()['val'](),_0x349124=_r(_0x43fafe,_0x43e54e['getImmediateChild']('.priority'),_0x52fa73);let _0x5e67fb;if(_0x471104['isLeafNode']()){const _0xf9fa87=_0x471104,_0x578b4d=_r(_0xf9fa87['getValue'](),_0x43e54e,_0x52fa73);return _0x578b4d!==_0xf9fa87['getValue']()||_0x349124!==_0xf9fa87['getPriority']()['val']()?new D(_0x578b4d,A(_0x349124)):_0x471104;}else{const _0x27fcfc=_0x471104;return _0x5e67fb=_0x27fcfc,_0x349124!==_0x27fcfc['getPriority']()['val']()&&(_0x5e67fb=_0x5e67fb['updatePriority'](new D(_0x349124))),_0x27fcfc['forEachChild'](R,(_0x55f6ef,_0x29f108)=>{const _0x189c06=ps(_0x29f108,_0x43e54e['getImmediateChild'](_0x55f6ef),_0x52fa73);_0x189c06!==_0x29f108&&(_0x5e67fb=_0x5e67fb['updateImmediateChild'](_0x55f6ef,_0x189c06));}),_0x5e67fb;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0xed10e5='',_0x337d67=null,_0x6a338f={'children':{},'childCount':0x0}){this['name']=_0xed10e5,this['parent']=_0x337d67,this['node']=_0x6a338f;}}function $n(_0x3a3171,_0x51760d){let _0x48d8cc=_0x51760d instanceof C?_0x51760d:new C(_0x51760d),_0x5f1803=_0x3a3171,_0x2deaa1=y(_0x48d8cc);for(;_0x2deaa1!==null;){const _0x598b59=Le(_0x5f1803['node']['children'],_0x2deaa1)||{'children':{},'childCount':0x0};_0x5f1803=new _s(_0x2deaa1,_0x5f1803,_0x598b59),_0x48d8cc=S(_0x48d8cc),_0x2deaa1=y(_0x48d8cc);}return _0x5f1803;}function je(_0x398ec5){return _0x398ec5['node']['value'];}function gs(_0xf5783b,_0x3aa750){_0xf5783b['node']['value']=_0x3aa750,Oi(_0xf5783b);}function na(_0x308b36){return _0x308b36['node']['childCount']>0x0;}function od(_0x240807){return je(_0x240807)===void 0x0&&!na(_0x240807);}function Gn(_0x5d733e,_0x4f607c){x(_0x5d733e['node']['children'],(_0x546a0d,_0x30bc5f)=>{_0x4f607c(new _s(_0x546a0d,_0x5d733e,_0x30bc5f));});}function ia(_0x37c81a,_0x387350,_0x317629,_0x4e3b72){_0x317629&&_0x387350(_0x37c81a),Gn(_0x37c81a,_0x1ae9d0=>{ia(_0x1ae9d0,_0x387350,!0x0);});}function ad(_0x27f359,_0x5136cb,_0x54a715){let _0x52b481=_0x27f359['parent'];for(;_0x52b481!==null;){if(_0x5136cb(_0x52b481))return!0x0;_0x52b481=_0x52b481['parent'];}return!0x1;}function Qt(_0x5068ee){return new C(_0x5068ee['parent']===null?_0x5068ee['name']:Qt(_0x5068ee['parent'])+'/'+_0x5068ee['name']);}function Oi(_0x265e74){_0x265e74['parent']!==null&&cd(_0x265e74['parent'],_0x265e74['name'],_0x265e74);}function cd(_0xc2842,_0x4d4649,_0x2e235d){const _0x4f0896=od(_0x2e235d),_0x47ba91=Q(_0xc2842['node']['children'],_0x4d4649);_0x4f0896&&_0x47ba91?(delete _0xc2842['node']['children'][_0x4d4649],_0xc2842['node']['childCount']--,Oi(_0xc2842)):!_0x4f0896&&!_0x47ba91&&(_0xc2842['node']['children'][_0x4d4649]=_0x2e235d['node'],_0xc2842['node']['childCount']++,Oi(_0xc2842));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x42dcec){return typeof _0x42dcec=='string'&&_0x42dcec['length']!==0x0&&!ld['test'](_0x42dcec);},sa=function(_0x32a243){return typeof _0x32a243=='string'&&_0x32a243['length']!==0x0&&!hd['test'](_0x32a243);},ud=function(_0x56b735){return _0x56b735&&(_0x56b735=_0x56b735['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x56b735);},Bt=function(_0x3f31fd){return _0x3f31fd===null||typeof _0x3f31fd=='string'||typeof _0x3f31fd=='number'&&!xn(_0x3f31fd)||_0x3f31fd&&typeof _0x3f31fd=='object'&&Q(_0x3f31fd,'.sv');},He=function(_0x5e8af3,_0x2d2476,_0x2d8417,_0x16cc4a){_0x16cc4a&&_0x2d2476===void 0x0||Jt(it(_0x5e8af3,'value'),_0x2d2476,_0x2d8417);},Jt=function(_0x548100,_0x3755f5,_0x30220d){const _0x2372c9=_0x30220d instanceof C?new Ah(_0x30220d,_0x548100):_0x30220d;if(_0x3755f5===void 0x0)throw new Error(_0x548100+'contains\x20undefined\x20'+Oe(_0x2372c9));if(typeof _0x3755f5=='function')throw new Error(_0x548100+'contains\x20a\x20function\x20'+Oe(_0x2372c9)+'\x20with\x20contents\x20=\x20'+_0x3755f5['toString']());if(xn(_0x3755f5))throw new Error(_0x548100+'contains\x20'+_0x3755f5['toString']()+'\x20'+Oe(_0x2372c9));if(typeof _0x3755f5=='string'&&_0x3755f5['length']>ui/0x3&&Ln(_0x3755f5)>ui)throw new Error(_0x548100+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x2372c9)+'\x20(\x27'+_0x3755f5['substring'](0x0,0x32)+'...\x27)');if(_0x3755f5&&typeof _0x3755f5=='object'){let _0x128b40=!0x1,_0x4cb588=!0x1;if(x(_0x3755f5,(_0x5ead61,_0x15c490)=>{if(_0x5ead61==='.value')_0x128b40=!0x0;else{if(_0x5ead61!=='.priority'&&_0x5ead61!=='.sv'&&(_0x4cb588=!0x0,!ms(_0x5ead61)))throw new Error(_0x548100+'\x20contains\x20an\x20invalid\x20key\x20('+_0x5ead61+')\x20'+Oe(_0x2372c9)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x2372c9,_0x5ead61),Jt(_0x548100,_0x15c490,_0x2372c9),Ph(_0x2372c9);}),_0x128b40&&_0x4cb588)throw new Error(_0x548100+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x2372c9)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x1d5bbb,_0x2a10be){let _0x383421,_0x3838b8;for(_0x383421=0x0;_0x383421<_0x2a10be['length'];_0x383421++){_0x3838b8=_0x2a10be[_0x383421];const _0x58f855=Mt(_0x3838b8);for(let _0x21cbbd=0x0;_0x21cbbd<_0x58f855['length'];_0x21cbbd++)if(!(_0x58f855[_0x21cbbd]==='.priority'&&_0x21cbbd===_0x58f855['length']-0x1)){if(!ms(_0x58f855[_0x21cbbd]))throw new Error(_0x1d5bbb+'contains\x20an\x20invalid\x20key\x20('+_0x58f855[_0x21cbbd]+')\x20in\x20path\x20'+_0x3838b8['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x2a10be['sort'](Rh);let _0x36cb8c=null;for(_0x383421=0x0;_0x383421<_0x2a10be['length'];_0x383421++){if(_0x3838b8=_0x2a10be[_0x383421],_0x36cb8c!==null&&G(_0x36cb8c,_0x3838b8))throw new Error(_0x1d5bbb+'contains\x20a\x20path\x20'+_0x36cb8c['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x3838b8['toString']());_0x36cb8c=_0x3838b8;}},ra=function(_0x2af8cc,_0x1cec4a,_0x2f5f0e,_0x3d87c5){const _0x2e83bf=it(_0x2af8cc,'values');if(!(_0x1cec4a&&typeof _0x1cec4a=='object')||Array['isArray'](_0x1cec4a))throw new Error(_0x2e83bf+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x2dd311=[];x(_0x1cec4a,(_0x3aebd0,_0x25bbbb)=>{const _0x2c2b6b=new C(_0x3aebd0);if(Jt(_0x2e83bf,_0x25bbbb,k(_0x2f5f0e,_0x2c2b6b)),ji(_0x2c2b6b)==='.priority'&&!Bt(_0x25bbbb))throw new Error(_0x2e83bf+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x2c2b6b['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x2dd311['push'](_0x2c2b6b);}),dd(_0x2e83bf,_0x2dd311);},fd=function(_0x184402,_0x2f2ebf,_0x3aeeb6){if(xn(_0x2f2ebf))throw new Error(it(_0x184402,'priority')+'is\x20'+_0x2f2ebf['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x2f2ebf))throw new Error(it(_0x184402,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x5dd980,_0x5d5424,_0x939150,_0x31d059){if(!sa(_0x939150))throw new Error(it(_0x5dd980,_0x5d5424)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x939150+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0xaede87,_0x21837b,_0x16965a,_0x51265e){_0x16965a&&(_0x16965a=_0x16965a['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0xaede87,_0x21837b,_0x16965a);},Me=function(_0x4ece50,_0x4d5c6a){if(y(_0x4d5c6a)==='.info')throw new Error(_0x4ece50+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x25ddc7,_0x5f285e){const _0x5823cf=_0x5f285e['path']['toString']();if(typeof _0x5f285e['repoInfo']['host']!='string'||_0x5f285e['repoInfo']['host']['length']===0x0||!ms(_0x5f285e['repoInfo']['namespace'])&&_0x5f285e['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x5823cf['length']!==0x0&&!ud(_0x5823cf))throw new Error(it(_0x25ddc7,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x319b38,_0x573042){let _0x2aadec=null;for(let _0x48685b=0x0;_0x48685b<_0x573042['length'];_0x48685b++){const _0x5140b4=_0x573042[_0x48685b],_0x28818a=_0x5140b4['getPath']();_0x2aadec!==null&&!Ki(_0x28818a,_0x2aadec['path'])&&(_0x319b38['eventLists_']['push'](_0x2aadec),_0x2aadec=null),_0x2aadec===null&&(_0x2aadec={'events':[],'path':_0x28818a}),_0x2aadec['events']['push'](_0x5140b4);}_0x2aadec&&_0x319b38['eventLists_']['push'](_0x2aadec);}function oa(_0x36f7b0,_0x447adb,_0x2ea8ee){qn(_0x36f7b0,_0x2ea8ee),aa(_0x36f7b0,_0x4c67ba=>Ki(_0x4c67ba,_0x447adb));}function V(_0x142e9b,_0x39b9d5,_0x296da8){qn(_0x142e9b,_0x296da8),aa(_0x142e9b,_0x45dd2b=>G(_0x45dd2b,_0x39b9d5)||G(_0x39b9d5,_0x45dd2b));}function aa(_0x4002d7,_0x29a451){_0x4002d7['recursionDepth_']++;let _0x30d0cf=!0x0;for(let _0x3049c5=0x0;_0x3049c5<_0x4002d7['eventLists_']['length'];_0x3049c5++){const _0x16cc42=_0x4002d7['eventLists_'][_0x3049c5];if(_0x16cc42){const _0x1e2520=_0x16cc42['path'];_0x29a451(_0x1e2520)?(md(_0x4002d7['eventLists_'][_0x3049c5]),_0x4002d7['eventLists_'][_0x3049c5]=null):_0x30d0cf=!0x1;}}_0x30d0cf&&(_0x4002d7['eventLists_']=[]),_0x4002d7['recursionDepth_']--;}function md(_0x426304){for(let _0x22a1c0=0x0;_0x22a1c0<_0x426304['events']['length'];_0x22a1c0++){const _0x8f5eb4=_0x426304['events'][_0x22a1c0];if(_0x8f5eb4!==null){_0x426304['events'][_0x22a1c0]=null;const _0x34287d=_0x8f5eb4['getEventRunner']();St&&L('event:\x20'+_0x8f5eb4['toString']()),ft(_0x34287d);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x47ed3c,_0x438137,_0x63aa4,_0x366395){this['repoInfo_']=_0x47ed3c,this['forceRestClient_']=_0x438137,this['authTokenProvider_']=_0x63aa4,this['appCheckProvider_']=_0x366395,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x3789a7,_0x1224a0,_0x1a4ef9){if(_0x3789a7['stats_']=qi(_0x3789a7['repoInfo_']),_0x3789a7['forceRestClient_']||Xl())_0x3789a7['server_']=new vn(_0x3789a7['repoInfo_'],(_0x78ccb0,_0x4a5a4d,_0xa67852,_0x323b99)=>{gr(_0x3789a7,_0x78ccb0,_0x4a5a4d,_0xa67852,_0x323b99);},_0x3789a7['authTokenProvider_'],_0x3789a7['appCheckProvider_']),setTimeout(()=>mr(_0x3789a7,!0x0),0x0);else{if(typeof _0x1a4ef9<'u'&&_0x1a4ef9!==null){if(typeof _0x1a4ef9!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x1a4ef9);}catch(_0x327f3b){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x327f3b);}}_0x3789a7['persistentConnection_']=new se(_0x3789a7['repoInfo_'],_0x1224a0,(_0x287c74,_0x1a9649,_0x3f4854,_0x12b3d4)=>{gr(_0x3789a7,_0x287c74,_0x1a9649,_0x3f4854,_0x12b3d4);},_0x8276fa=>{mr(_0x3789a7,_0x8276fa);},_0x115819=>{Id(_0x3789a7,_0x115819);},_0x3789a7['authTokenProvider_'],_0x3789a7['appCheckProvider_'],_0x1a4ef9),_0x3789a7['server_']=_0x3789a7['persistentConnection_'];}_0x3789a7['authTokenProvider_']['addTokenChangeListener'](_0x283d4b=>{_0x3789a7['server_']['refreshAuthToken'](_0x283d4b);}),_0x3789a7['appCheckProvider_']['addTokenChangeListener'](_0x31d756=>{_0x3789a7['server_']['refreshAppCheckToken'](_0x31d756['token']);}),_0x3789a7['statsReporter_']=ih(_0x3789a7['repoInfo_'],()=>new iu(_0x3789a7['stats_'],_0x3789a7['server_'])),_0x3789a7['infoData_']=new Xh(),_0x3789a7['infoSyncTree_']=new pr({'startListening':(_0x3e16c0,_0x52ce66,_0x8abf15,_0x34294d)=>{let _0x34caba=[];const _0x1b7466=_0x3789a7['infoData_']['getNode'](_0x3e16c0['_path']);return _0x1b7466['isEmpty']()||(_0x34caba=Yt(_0x3789a7['infoSyncTree_'],_0x3e16c0['_path'],_0x1b7466),setTimeout(()=>{_0x34294d('ok');},0x0)),_0x34caba;},'stopListening':()=>{}}),vs(_0x3789a7,'connected',!0x1),_0x3789a7['serverSyncTree_']=new pr({'startListening':(_0x38ffac,_0x46db64,_0x134e5e,_0x41f947)=>(_0x3789a7['server_']['listen'](_0x38ffac,_0x134e5e,_0x46db64,(_0x4e9191,_0x30bcd2)=>{const _0x3b2564=_0x41f947(_0x4e9191,_0x30bcd2);V(_0x3789a7['eventQueue_'],_0x38ffac['_path'],_0x3b2564);}),[]),'stopListening':(_0x3d5c9c,_0x5d0f98)=>{_0x3789a7['server_']['unlisten'](_0x3d5c9c,_0x5d0f98);}});}function la(_0x379a35){const _0x399799=_0x379a35['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x399799;}function Xt(_0x4d1888){return id({'timestamp':la(_0x4d1888)});}function gr(_0x45c36e,_0x3d6bf4,_0x5120fe,_0x41af9a,_0x43d483){_0x45c36e['dataUpdateCount']++;const _0xaed7c4=new C(_0x3d6bf4);_0x5120fe=_0x45c36e['interceptServerDataCallback_']?_0x45c36e['interceptServerDataCallback_'](_0x3d6bf4,_0x5120fe):_0x5120fe;let _0x37702f=[];if(_0x43d483){if(_0x41af9a){const _0x1dde9d=_n(_0x5120fe,_0x2003ef=>A(_0x2003ef));_0x37702f=Ju(_0x45c36e['serverSyncTree_'],_0xaed7c4,_0x1dde9d,_0x43d483);}else{const _0x5f11ff=A(_0x5120fe);_0x37702f=Jo(_0x45c36e['serverSyncTree_'],_0xaed7c4,_0x5f11ff,_0x43d483);}}else{if(_0x41af9a){const _0x4ccbdc=_n(_0x5120fe,_0x53ab05=>A(_0x53ab05));_0x37702f=Ku(_0x45c36e['serverSyncTree_'],_0xaed7c4,_0x4ccbdc);}else{const _0x529d1b=A(_0x5120fe);_0x37702f=Yt(_0x45c36e['serverSyncTree_'],_0xaed7c4,_0x529d1b);}}let _0x23a758=_0xaed7c4;_0x37702f['length']>0x0&&(_0x23a758=ct(_0x45c36e,_0xaed7c4)),V(_0x45c36e['eventQueue_'],_0x23a758,_0x37702f);}function mr(_0x3b5f71,_0x3cd077){vs(_0x3b5f71,'connected',_0x3cd077),_0x3cd077===!0x1&&Sd(_0x3b5f71);}function Id(_0x40fb4f,_0x5a7107){x(_0x5a7107,(_0x36d08c,_0x425241)=>{vs(_0x40fb4f,_0x36d08c,_0x425241);});}function vs(_0x771bb,_0x184989,_0x39a19e){const _0x4184d0=new C('/.info/'+_0x184989),_0x566eba=A(_0x39a19e);_0x771bb['infoData_']['updateSnapshot'](_0x4184d0,_0x566eba);const _0x3959d0=Yt(_0x771bb['infoSyncTree_'],_0x4184d0,_0x566eba);V(_0x771bb['eventQueue_'],_0x4184d0,_0x3959d0);}function zn(_0x4372bd){return _0x4372bd['nextWriteId_']++;}function wd(_0x3f6861,_0x46bf0f,_0x3a1bcc){const _0x5f4c6b=Xu(_0x3f6861['serverSyncTree_'],_0x46bf0f);return _0x5f4c6b!=null?Promise['resolve'](_0x5f4c6b):_0x3f6861['server_']['get'](_0x46bf0f)['then'](_0x3a28cf=>{const _0x2f8b0b=A(_0x3a28cf)['withIndex'](_0x46bf0f['_queryParams']['getIndex']());Ni(_0x3f6861['serverSyncTree_'],_0x46bf0f,_0x3a1bcc,!0x0);let _0x418ca7;if(_0x46bf0f['_queryParams']['loadsAllData']())_0x418ca7=Yt(_0x3f6861['serverSyncTree_'],_0x46bf0f['_path'],_0x2f8b0b);else{const _0x510d41=Wt(_0x3f6861['serverSyncTree_'],_0x46bf0f);_0x418ca7=Jo(_0x3f6861['serverSyncTree_'],_0x46bf0f['_path'],_0x2f8b0b,_0x510d41);}return V(_0x3f6861['eventQueue_'],_0x46bf0f['_path'],_0x418ca7),An(_0x3f6861['serverSyncTree_'],_0x46bf0f,_0x3a1bcc,null,!0x0),_0x2f8b0b;},_0x564339=>(gt(_0x3f6861,'get\x20for\x20query\x20'+O(_0x46bf0f)+'\x20failed:\x20'+_0x564339),Promise['reject'](new Error(_0x564339))));}function Cd(_0x138a07,_0x2b89b9,_0x2f7d68,_0x45adf9,_0x2879d3){gt(_0x138a07,'set',{'path':_0x2b89b9['toString'](),'value':_0x2f7d68,'priority':_0x45adf9});const _0x11f9d9=Xt(_0x138a07),_0x10de8e=A(_0x2f7d68,_0x45adf9),_0x14146d=Vn(_0x138a07['serverSyncTree_'],_0x2b89b9),_0x499da0=fs(_0x10de8e,_0x14146d,_0x11f9d9),_0x51031e=zn(_0x138a07),_0x34fbb3=as(_0x138a07['serverSyncTree_'],_0x2b89b9,_0x499da0,_0x51031e,!0x0);qn(_0x138a07['eventQueue_'],_0x34fbb3),_0x138a07['server_']['put'](_0x2b89b9['toString'](),_0x10de8e['val'](!0x0),(_0x2565b8,_0x1ce47b)=>{const _0x535cb9=_0x2565b8==='ok';_0x535cb9||U('set\x20at\x20'+_0x2b89b9+'\x20failed:\x20'+_0x2565b8);const _0x4bfe58=_e(_0x138a07['serverSyncTree_'],_0x51031e,!_0x535cb9);V(_0x138a07['eventQueue_'],_0x2b89b9,_0x4bfe58),be(_0x138a07,_0x2879d3,_0x2565b8,_0x1ce47b);});const _0x461201=Is(_0x138a07,_0x2b89b9);ct(_0x138a07,_0x461201),V(_0x138a07['eventQueue_'],_0x461201,[]);}function Td(_0x529b53,_0x353584,_0x1ca29f,_0x4100eb){gt(_0x529b53,'update',{'path':_0x353584['toString'](),'value':_0x1ca29f});let _0x40c5a5=!0x0;const _0x476b35=Xt(_0x529b53),_0x43450d={};if(x(_0x1ca29f,(_0x33031d,_0x27860d)=>{_0x40c5a5=!0x1,_0x43450d[_0x33031d]=ta(k(_0x353584,_0x33031d),A(_0x27860d),_0x529b53['serverSyncTree_'],_0x476b35);}),_0x40c5a5)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x529b53,_0x4100eb,'ok',void 0x0);else{const _0x13ebcd=zn(_0x529b53),_0x49a91b=ju(_0x529b53['serverSyncTree_'],_0x353584,_0x43450d,_0x13ebcd);qn(_0x529b53['eventQueue_'],_0x49a91b),_0x529b53['server_']['merge'](_0x353584['toString'](),_0x1ca29f,(_0x35f4a5,_0x5e2138)=>{const _0x2ad274=_0x35f4a5==='ok';_0x2ad274||U('update\x20at\x20'+_0x353584+'\x20failed:\x20'+_0x35f4a5);const _0x24bc5e=_e(_0x529b53['serverSyncTree_'],_0x13ebcd,!_0x2ad274),_0x180ca8=_0x24bc5e['length']>0x0?ct(_0x529b53,_0x353584):_0x353584;V(_0x529b53['eventQueue_'],_0x180ca8,_0x24bc5e),be(_0x529b53,_0x4100eb,_0x35f4a5,_0x5e2138);}),x(_0x1ca29f,_0x5b9367=>{const _0x3ca8dd=Is(_0x529b53,k(_0x353584,_0x5b9367));ct(_0x529b53,_0x3ca8dd);}),V(_0x529b53['eventQueue_'],_0x353584,[]);}}function Sd(_0x314bee){gt(_0x314bee,'onDisconnectEvents');const _0x382f20=Xt(_0x314bee),_0x3ed76a=En();Si(_0x314bee['onDisconnect_'],w(),(_0x10b990,_0x4a120e)=>{const _0x317805=ta(_0x10b990,_0x4a120e,_0x314bee['serverSyncTree_'],_0x382f20);pt(_0x3ed76a,_0x10b990,_0x317805);});let _0x2fdf79=[];Si(_0x3ed76a,w(),(_0x26177e,_0x4e9bf8)=>{_0x2fdf79=_0x2fdf79['concat'](Yt(_0x314bee['serverSyncTree_'],_0x26177e,_0x4e9bf8));const _0x21828f=Is(_0x314bee,_0x26177e);ct(_0x314bee,_0x21828f);}),_0x314bee['onDisconnect_']=En(),V(_0x314bee['eventQueue_'],w(),_0x2fdf79);}function bd(_0xce64fb,_0x536758,_0x371f61){_0xce64fb['server_']['onDisconnectCancel'](_0x536758['toString'](),(_0x3f98fd,_0x3aefb0)=>{_0x3f98fd==='ok'&&Ti(_0xce64fb['onDisconnect_'],_0x536758),be(_0xce64fb,_0x371f61,_0x3f98fd,_0x3aefb0);});}function yr(_0x18ebe9,_0x42a5ec,_0x4978cd,_0x18a2b4){const _0x334dff=A(_0x4978cd);_0x18ebe9['server_']['onDisconnectPut'](_0x42a5ec['toString'](),_0x334dff['val'](!0x0),(_0x21b7c2,_0x87c56d)=>{_0x21b7c2==='ok'&&pt(_0x18ebe9['onDisconnect_'],_0x42a5ec,_0x334dff),be(_0x18ebe9,_0x18a2b4,_0x21b7c2,_0x87c56d);});}function Rd(_0x3a3d0d,_0x348293,_0x3e23ef,_0x274640,_0x293951){const _0x47112d=A(_0x3e23ef,_0x274640);_0x3a3d0d['server_']['onDisconnectPut'](_0x348293['toString'](),_0x47112d['val'](!0x0),(_0x1c4fb1,_0x3b33ac)=>{_0x1c4fb1==='ok'&&pt(_0x3a3d0d['onDisconnect_'],_0x348293,_0x47112d),be(_0x3a3d0d,_0x293951,_0x1c4fb1,_0x3b33ac);});}function Ad(_0x28ac3c,_0x2e95a9,_0xe5eecc,_0x58e170){if(pn(_0xe5eecc)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x28ac3c,_0x58e170,'ok',void 0x0);return;}_0x28ac3c['server_']['onDisconnectMerge'](_0x2e95a9['toString'](),_0xe5eecc,(_0x797279,_0x3d9aa7)=>{_0x797279==='ok'&&x(_0xe5eecc,(_0x159d91,_0x56f92a)=>{const _0xf3248e=A(_0x56f92a);pt(_0x28ac3c['onDisconnect_'],k(_0x2e95a9,_0x159d91),_0xf3248e);}),be(_0x28ac3c,_0x58e170,_0x797279,_0x3d9aa7);});}function kd(_0x7699f7,_0x2010d7,_0x569548){let _0x2ceeb9;y(_0x2010d7['_path'])==='.info'?_0x2ceeb9=Ni(_0x7699f7['infoSyncTree_'],_0x2010d7,_0x569548):_0x2ceeb9=Ni(_0x7699f7['serverSyncTree_'],_0x2010d7,_0x569548),oa(_0x7699f7['eventQueue_'],_0x2010d7['_path'],_0x2ceeb9);}function Pd(_0x30f197,_0x453d07,_0x4be2a4){let _0x63efd7;y(_0x453d07['_path'])==='.info'?_0x63efd7=An(_0x30f197['infoSyncTree_'],_0x453d07,_0x4be2a4):_0x63efd7=An(_0x30f197['serverSyncTree_'],_0x453d07,_0x4be2a4),oa(_0x30f197['eventQueue_'],_0x453d07['_path'],_0x63efd7);}function ha(_0x3ad52f){_0x3ad52f['persistentConnection_']&&_0x3ad52f['persistentConnection_']['interrupt'](ca);}function Nd(_0x5c1ea9){_0x5c1ea9['persistentConnection_']&&_0x5c1ea9['persistentConnection_']['resume'](ca);}function gt(_0x40db28,..._0x243da3){let _0x781640='';_0x40db28['persistentConnection_']&&(_0x781640=_0x40db28['persistentConnection_']['id']+':'),L(_0x781640,..._0x243da3);}function be(_0x1e1273,_0x2b5a32,_0x3cb898,_0xc1601f){_0x2b5a32&&ft(()=>{if(_0x3cb898==='ok')_0x2b5a32(null);else{const _0x4801d0=(_0x3cb898||'error')['toUpperCase']();let _0xaa2b3f=_0x4801d0;_0xc1601f&&(_0xaa2b3f+=':\x20'+_0xc1601f);const _0x46ae69=new Error(_0xaa2b3f);_0x46ae69['code']=_0x4801d0,_0x2b5a32(_0x46ae69);}});}function Od(_0x4f73dd,_0x2309a8,_0xecae45,_0x8b026b,_0x2f0e98,_0x151ac0){gt(_0x4f73dd,'transaction\x20on\x20'+_0x2309a8);const _0x1a420f={'path':_0x2309a8,'update':_0xecae45,'onComplete':_0x8b026b,'status':null,'order':so(),'applyLocally':_0x151ac0,'retryCount':0x0,'unwatcher':_0x2f0e98,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x21cce0=Es(_0x4f73dd,_0x2309a8,void 0x0);_0x1a420f['currentInputSnapshot']=_0x21cce0;const _0x3f49ec=_0x1a420f['update'](_0x21cce0['val']());if(_0x3f49ec===void 0x0)_0x1a420f['unwatcher'](),_0x1a420f['currentOutputSnapshotRaw']=null,_0x1a420f['currentOutputSnapshotResolved']=null,_0x1a420f['onComplete']&&_0x1a420f['onComplete'](null,!0x1,_0x1a420f['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x3f49ec,_0x1a420f['path']),_0x1a420f['status']=0x0;const _0x5d039c=$n(_0x4f73dd['transactionQueueTree_'],_0x2309a8),_0x36d73e=je(_0x5d039c)||[];_0x36d73e['push'](_0x1a420f),gs(_0x5d039c,_0x36d73e);let _0x48613c;typeof _0x3f49ec=='object'&&_0x3f49ec!==null&&Q(_0x3f49ec,'.priority')?(_0x48613c=Le(_0x3f49ec,'.priority'),f(Bt(_0x48613c),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x48613c=(Vn(_0x4f73dd['serverSyncTree_'],_0x2309a8)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x2340e3=Xt(_0x4f73dd),_0x3cb263=A(_0x3f49ec,_0x48613c),_0x5d60ea=fs(_0x3cb263,_0x21cce0,_0x2340e3);_0x1a420f['currentOutputSnapshotRaw']=_0x3cb263,_0x1a420f['currentOutputSnapshotResolved']=_0x5d60ea,_0x1a420f['currentWriteId']=zn(_0x4f73dd);const _0x103c26=as(_0x4f73dd['serverSyncTree_'],_0x2309a8,_0x5d60ea,_0x1a420f['currentWriteId'],_0x1a420f['applyLocally']);V(_0x4f73dd['eventQueue_'],_0x2309a8,_0x103c26),jn(_0x4f73dd,_0x4f73dd['transactionQueueTree_']);}}function Es(_0x4718da,_0x1d4e00,_0x18da28){return Vn(_0x4718da['serverSyncTree_'],_0x1d4e00,_0x18da28)||g['EMPTY_NODE'];}function jn(_0x31d8b4,_0x30b7b6=_0x31d8b4['transactionQueueTree_']){if(_0x30b7b6||Kn(_0x31d8b4,_0x30b7b6),je(_0x30b7b6)){const _0x32780d=da(_0x31d8b4,_0x30b7b6);f(_0x32780d['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x32780d['every'](_0x55e120=>_0x55e120['status']===0x0)&&Dd(_0x31d8b4,Qt(_0x30b7b6),_0x32780d);}else na(_0x30b7b6)&&Gn(_0x30b7b6,_0x16d977=>{jn(_0x31d8b4,_0x16d977);});}function Dd(_0x3da58d,_0x5694f8,_0x3228e8){const _0x296a0e=_0x3228e8['map'](_0x1da415=>_0x1da415['currentWriteId']),_0x555737=Es(_0x3da58d,_0x5694f8,_0x296a0e);let _0xe975dc=_0x555737;const _0x293e9a=_0x555737['hash']();for(let _0x1a9690=0x0;_0x1a9690<_0x3228e8['length'];_0x1a9690++){const _0x9039f8=_0x3228e8[_0x1a9690];f(_0x9039f8['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x9039f8['status']=0x1,_0x9039f8['retryCount']++;const _0x5758ed=F(_0x5694f8,_0x9039f8['path']);_0xe975dc=_0xe975dc['updateChild'](_0x5758ed,_0x9039f8['currentOutputSnapshotRaw']);}const _0x28930f=_0xe975dc['val'](!0x0),_0x26d45f=_0x5694f8;_0x3da58d['server_']['put'](_0x26d45f['toString'](),_0x28930f,_0x222f21=>{gt(_0x3da58d,'transaction\x20put\x20response',{'path':_0x26d45f['toString'](),'status':_0x222f21});let _0x2f745d=[];if(_0x222f21==='ok'){const _0x144dde=[];for(let _0x15945a=0x0;_0x15945a<_0x3228e8['length'];_0x15945a++)_0x3228e8[_0x15945a]['status']=0x2,_0x2f745d=_0x2f745d['concat'](_e(_0x3da58d['serverSyncTree_'],_0x3228e8[_0x15945a]['currentWriteId'])),_0x3228e8[_0x15945a]['onComplete']&&_0x144dde['push'](()=>_0x3228e8[_0x15945a]['onComplete'](null,!0x0,_0x3228e8[_0x15945a]['currentOutputSnapshotResolved'])),_0x3228e8[_0x15945a]['unwatcher']();Kn(_0x3da58d,$n(_0x3da58d['transactionQueueTree_'],_0x5694f8)),jn(_0x3da58d,_0x3da58d['transactionQueueTree_']),V(_0x3da58d['eventQueue_'],_0x5694f8,_0x2f745d);for(let _0x47272c=0x0;_0x47272c<_0x144dde['length'];_0x47272c++)ft(_0x144dde[_0x47272c]);}else{if(_0x222f21==='datastale'){for(let _0x3a78e3=0x0;_0x3a78e3<_0x3228e8['length'];_0x3a78e3++)_0x3228e8[_0x3a78e3]['status']===0x3?_0x3228e8[_0x3a78e3]['status']=0x4:_0x3228e8[_0x3a78e3]['status']=0x0;}else{U('transaction\x20at\x20'+_0x26d45f['toString']()+'\x20failed:\x20'+_0x222f21);for(let _0x591969=0x0;_0x591969<_0x3228e8['length'];_0x591969++)_0x3228e8[_0x591969]['status']=0x4,_0x3228e8[_0x591969]['abortReason']=_0x222f21;}ct(_0x3da58d,_0x5694f8);}},_0x293e9a);}function ct(_0x377915,_0x244005){const _0x46f6b6=ua(_0x377915,_0x244005),_0x3782fd=Qt(_0x46f6b6),_0x3155a5=da(_0x377915,_0x46f6b6);return Md(_0x377915,_0x3155a5,_0x3782fd),_0x3782fd;}function Md(_0xb59e00,_0x4e587e,_0x195427){if(_0x4e587e['length']===0x0)return;const _0x4d6add=[];let _0x51153c=[];const _0x1cbf70=_0x4e587e['filter'](_0x1e6b8a=>_0x1e6b8a['status']===0x0)['map'](_0xeebf5a=>_0xeebf5a['currentWriteId']);for(let _0x488c18=0x0;_0x488c18<_0x4e587e['length'];_0x488c18++){const _0xe82463=_0x4e587e[_0x488c18],_0x4954d8=F(_0x195427,_0xe82463['path']);let _0x22fdd7=!0x1,_0x5b184a;if(f(_0x4954d8!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0xe82463['status']===0x4)_0x22fdd7=!0x0,_0x5b184a=_0xe82463['abortReason'],_0x51153c=_0x51153c['concat'](_e(_0xb59e00['serverSyncTree_'],_0xe82463['currentWriteId'],!0x0));else{if(_0xe82463['status']===0x0){if(_0xe82463['retryCount']>=yd)_0x22fdd7=!0x0,_0x5b184a='maxretry',_0x51153c=_0x51153c['concat'](_e(_0xb59e00['serverSyncTree_'],_0xe82463['currentWriteId'],!0x0));else{const _0x579b9e=Es(_0xb59e00,_0xe82463['path'],_0x1cbf70);_0xe82463['currentInputSnapshot']=_0x579b9e;const _0x4d20a4=_0x4e587e[_0x488c18]['update'](_0x579b9e['val']());if(_0x4d20a4!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x4d20a4,_0xe82463['path']);let _0x4f4bb3=A(_0x4d20a4);typeof _0x4d20a4=='object'&&_0x4d20a4!=null&&Q(_0x4d20a4,'.priority')||(_0x4f4bb3=_0x4f4bb3['updatePriority'](_0x579b9e['getPriority']()));const _0x34d0c4=_0xe82463['currentWriteId'],_0x22ccee=Xt(_0xb59e00),_0x5db8f5=fs(_0x4f4bb3,_0x579b9e,_0x22ccee);_0xe82463['currentOutputSnapshotRaw']=_0x4f4bb3,_0xe82463['currentOutputSnapshotResolved']=_0x5db8f5,_0xe82463['currentWriteId']=zn(_0xb59e00),_0x1cbf70['splice'](_0x1cbf70['indexOf'](_0x34d0c4),0x1),_0x51153c=_0x51153c['concat'](as(_0xb59e00['serverSyncTree_'],_0xe82463['path'],_0x5db8f5,_0xe82463['currentWriteId'],_0xe82463['applyLocally'])),_0x51153c=_0x51153c['concat'](_e(_0xb59e00['serverSyncTree_'],_0x34d0c4,!0x0));}else _0x22fdd7=!0x0,_0x5b184a='nodata',_0x51153c=_0x51153c['concat'](_e(_0xb59e00['serverSyncTree_'],_0xe82463['currentWriteId'],!0x0));}}}V(_0xb59e00['eventQueue_'],_0x195427,_0x51153c),_0x51153c=[],_0x22fdd7&&(_0x4e587e[_0x488c18]['status']=0x2,function(_0xb4fae9){setTimeout(_0xb4fae9,Math['floor'](0x0));}(_0x4e587e[_0x488c18]['unwatcher']),_0x4e587e[_0x488c18]['onComplete']&&(_0x5b184a==='nodata'?_0x4d6add['push'](()=>_0x4e587e[_0x488c18]['onComplete'](null,!0x1,_0x4e587e[_0x488c18]['currentInputSnapshot'])):_0x4d6add['push'](()=>_0x4e587e[_0x488c18]['onComplete'](new Error(_0x5b184a),!0x1,null))));}Kn(_0xb59e00,_0xb59e00['transactionQueueTree_']);for(let _0xf60c87=0x0;_0xf60c87<_0x4d6add['length'];_0xf60c87++)ft(_0x4d6add[_0xf60c87]);jn(_0xb59e00,_0xb59e00['transactionQueueTree_']);}function ua(_0x2ad012,_0x575e47){let _0x8d3600,_0xd5ba34=_0x2ad012['transactionQueueTree_'];for(_0x8d3600=y(_0x575e47);_0x8d3600!==null&&je(_0xd5ba34)===void 0x0;)_0xd5ba34=$n(_0xd5ba34,_0x8d3600),_0x575e47=S(_0x575e47),_0x8d3600=y(_0x575e47);return _0xd5ba34;}function da(_0xd8c7dd,_0x41258b){const _0x51d5c6=[];return fa(_0xd8c7dd,_0x41258b,_0x51d5c6),_0x51d5c6['sort']((_0x48f0e9,_0x35d39)=>_0x48f0e9['order']-_0x35d39['order']),_0x51d5c6;}function fa(_0x5efcc6,_0x3c1d22,_0x6ab5b){const _0x379096=je(_0x3c1d22);if(_0x379096){for(let _0x26ffef=0x0;_0x26ffef<_0x379096['length'];_0x26ffef++)_0x6ab5b['push'](_0x379096[_0x26ffef]);}Gn(_0x3c1d22,_0x19fe7a=>{fa(_0x5efcc6,_0x19fe7a,_0x6ab5b);});}function Kn(_0x45ec3c,_0x72b121){const _0x2a7ff1=je(_0x72b121);if(_0x2a7ff1){let _0x3a2728=0x0;for(let _0x4365dc=0x0;_0x4365dc<_0x2a7ff1['length'];_0x4365dc++)_0x2a7ff1[_0x4365dc]['status']!==0x2&&(_0x2a7ff1[_0x3a2728]=_0x2a7ff1[_0x4365dc],_0x3a2728++);_0x2a7ff1['length']=_0x3a2728,gs(_0x72b121,_0x2a7ff1['length']>0x0?_0x2a7ff1:void 0x0);}Gn(_0x72b121,_0x3f1481=>{Kn(_0x45ec3c,_0x3f1481);});}function Is(_0x1efbab,_0x48a2e9){const _0x249572=Qt(ua(_0x1efbab,_0x48a2e9)),_0x3fa580=$n(_0x1efbab['transactionQueueTree_'],_0x48a2e9);return ad(_0x3fa580,_0x2b1f53=>{di(_0x1efbab,_0x2b1f53);}),di(_0x1efbab,_0x3fa580),ia(_0x3fa580,_0x54b11a=>{di(_0x1efbab,_0x54b11a);}),_0x249572;}function di(_0x593856,_0x45cdef){const _0x4064b7=je(_0x45cdef);if(_0x4064b7){const _0x416e5f=[];let _0x20a361=[],_0x5a34bc=-0x1;for(let _0x2471d=0x0;_0x2471d<_0x4064b7['length'];_0x2471d++)_0x4064b7[_0x2471d]['status']===0x3||(_0x4064b7[_0x2471d]['status']===0x1?(f(_0x5a34bc===_0x2471d-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x5a34bc=_0x2471d,_0x4064b7[_0x2471d]['status']=0x3,_0x4064b7[_0x2471d]['abortReason']='set'):(f(_0x4064b7[_0x2471d]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x4064b7[_0x2471d]['unwatcher'](),_0x20a361=_0x20a361['concat'](_e(_0x593856['serverSyncTree_'],_0x4064b7[_0x2471d]['currentWriteId'],!0x0)),_0x4064b7[_0x2471d]['onComplete']&&_0x416e5f['push'](_0x4064b7[_0x2471d]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x5a34bc===-0x1?gs(_0x45cdef,void 0x0):_0x4064b7['length']=_0x5a34bc+0x1,V(_0x593856['eventQueue_'],Qt(_0x45cdef),_0x20a361);for(let _0x407f3a=0x0;_0x407f3a<_0x416e5f['length'];_0x407f3a++)ft(_0x416e5f[_0x407f3a]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x3da5bd){let _0x478724='';const _0x4c1288=_0x3da5bd['split']('/');for(let _0x1ffcf0=0x0;_0x1ffcf0<_0x4c1288['length'];_0x1ffcf0++)if(_0x4c1288[_0x1ffcf0]['length']>0x0){let _0x1fb280=_0x4c1288[_0x1ffcf0];try{_0x1fb280=decodeURIComponent(_0x1fb280['replace'](/\+/g,'\x20'));}catch{}_0x478724+='/'+_0x1fb280;}return _0x478724;}function xd(_0x17d74c){const _0x1dfdd8={};_0x17d74c['charAt'](0x0)==='?'&&(_0x17d74c=_0x17d74c['substring'](0x1));for(const _0x2f2be3 of _0x17d74c['split']('&')){if(_0x2f2be3['length']===0x0)continue;const _0x3f2e9d=_0x2f2be3['split']('=');_0x3f2e9d['length']===0x2?_0x1dfdd8[decodeURIComponent(_0x3f2e9d[0x0])]=decodeURIComponent(_0x3f2e9d[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x2f2be3+'\x27\x20in\x20query\x20\x27'+_0x17d74c+'\x27');}return _0x1dfdd8;}const vr=function(_0x136d09,_0x1cbd6a){const _0x2bb3b7=Fd(_0x136d09),_0x238a91=_0x2bb3b7['namespace'];_0x2bb3b7['domain']==='firebase.com'&&ae(_0x2bb3b7['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x238a91||_0x238a91==='undefined')&&_0x2bb3b7['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x2bb3b7['secure']||$l();const _0x17d3f8=_0x2bb3b7['scheme']==='ws'||_0x2bb3b7['scheme']==='wss';return{'repoInfo':new yo(_0x2bb3b7['host'],_0x2bb3b7['secure'],_0x238a91,_0x17d3f8,_0x1cbd6a,'',_0x238a91!==_0x2bb3b7['subdomain']),'path':new C(_0x2bb3b7['pathString'])};},Fd=function(_0x5214b7){let _0x2b1c82='',_0xf97b9e='',_0x181ff2='',_0x124d90='',_0x56371d='',_0x495fa3=!0x0,_0x51ede6='https',_0x567530=0x1bb;if(typeof _0x5214b7=='string'){let _0x182e2a=_0x5214b7['indexOf']('//');_0x182e2a>=0x0&&(_0x51ede6=_0x5214b7['substring'](0x0,_0x182e2a-0x1),_0x5214b7=_0x5214b7['substring'](_0x182e2a+0x2));let _0x22edc2=_0x5214b7['indexOf']('/');_0x22edc2===-0x1&&(_0x22edc2=_0x5214b7['length']);let _0x388746=_0x5214b7['indexOf']('?');_0x388746===-0x1&&(_0x388746=_0x5214b7['length']),_0x2b1c82=_0x5214b7['substring'](0x0,Math['min'](_0x22edc2,_0x388746)),_0x22edc2<_0x388746&&(_0x124d90=Ld(_0x5214b7['substring'](_0x22edc2,_0x388746)));const _0x1a1915=xd(_0x5214b7['substring'](Math['min'](_0x5214b7['length'],_0x388746)));_0x182e2a=_0x2b1c82['indexOf'](':'),_0x182e2a>=0x0?(_0x495fa3=_0x51ede6==='https'||_0x51ede6==='wss',_0x567530=parseInt(_0x2b1c82['substring'](_0x182e2a+0x1),0xa)):_0x182e2a=_0x2b1c82['length'];const _0x1fa8ae=_0x2b1c82['slice'](0x0,_0x182e2a);if(_0x1fa8ae['toLowerCase']()==='localhost')_0xf97b9e='localhost';else{if(_0x1fa8ae['split']('.')['length']<=0x2)_0xf97b9e=_0x1fa8ae;else{const _0x3b79da=_0x2b1c82['indexOf']('.');_0x181ff2=_0x2b1c82['substring'](0x0,_0x3b79da)['toLowerCase'](),_0xf97b9e=_0x2b1c82['substring'](_0x3b79da+0x1),_0x56371d=_0x181ff2;}}'ns'in _0x1a1915&&(_0x56371d=_0x1a1915['ns']);}return{'host':_0x2b1c82,'port':_0x567530,'domain':_0xf97b9e,'subdomain':_0x181ff2,'secure':_0x495fa3,'scheme':_0x51ede6,'pathString':_0x124d90,'namespace':_0x56371d};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x58c3a0=0x0;const _0x169a05=[];return function(_0x21a22f){const _0x21846a=_0x21a22f===_0x58c3a0;_0x58c3a0=_0x21a22f;let _0x5e418c;const _0x33af2a=new Array(0x8);for(_0x5e418c=0x7;_0x5e418c>=0x0;_0x5e418c--)_0x33af2a[_0x5e418c]=Er['charAt'](_0x21a22f%0x40),_0x21a22f=Math['floor'](_0x21a22f/0x40);f(_0x21a22f===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x12fa96=_0x33af2a['join']('');if(_0x21846a){for(_0x5e418c=0xb;_0x5e418c>=0x0&&_0x169a05[_0x5e418c]===0x3f;_0x5e418c--)_0x169a05[_0x5e418c]=0x0;_0x169a05[_0x5e418c]++;}else{for(_0x5e418c=0x0;_0x5e418c<0xc;_0x5e418c++)_0x169a05[_0x5e418c]=Math['floor'](Math['random']()*0x40);}for(_0x5e418c=0x0;_0x5e418c<0xc;_0x5e418c++)_0x12fa96+=Er['charAt'](_0x169a05[_0x5e418c]);return f(_0x12fa96['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x12fa96;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x2aafca,_0x3c7317,_0x16fbd1,_0x4dbd8a){this['eventType']=_0x2aafca,this['eventRegistration']=_0x3c7317,this['snapshot']=_0x16fbd1,this['prevName']=_0x4dbd8a;}['getPath'](){const _0x2a98ed=this['snapshot']['ref'];return this['eventType']==='value'?_0x2a98ed['_path']:_0x2a98ed['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x2214ff,_0x236869,_0x184ab4){this['eventRegistration']=_0x2214ff,this['error']=_0x236869,this['path']=_0x184ab4;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x2e04c2,_0x399114){this['snapshotCallback']=_0x2e04c2,this['cancelCallback']=_0x399114;}['onValue'](_0x39180f,_0x549470){this['snapshotCallback']['call'](null,_0x39180f,_0x549470);}['onCancel'](_0x181b12){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x181b12);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x193882){return this['snapshotCallback']===_0x193882['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x193882['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x193882['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x4f60a5,_0x3fb248){this['_repo']=_0x4f60a5,this['_path']=_0x3fb248;}['cancel'](){const _0x4a67ac=new H();return bd(this['_repo'],this['_path'],_0x4a67ac['wrapCallback'](()=>{})),_0x4a67ac['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x36102e=new H();return yr(this['_repo'],this['_path'],null,_0x36102e['wrapCallback'](()=>{})),_0x36102e['promise'];}['set'](_0x38fd20){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x38fd20,this['_path'],!0x1);const _0x402cef=new H();return yr(this['_repo'],this['_path'],_0x38fd20,_0x402cef['wrapCallback'](()=>{})),_0x402cef['promise'];}['setWithPriority'](_0x5cc04e,_0x159ef4){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x5cc04e,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x159ef4);const _0x5ce6ad=new H();return Rd(this['_repo'],this['_path'],_0x5cc04e,_0x159ef4,_0x5ce6ad['wrapCallback'](()=>{})),_0x5ce6ad['promise'];}['update'](_0x1c89d7){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x1c89d7,this['_path']);const _0x52cb8d=new H();return Ad(this['_repo'],this['_path'],_0x1c89d7,_0x52cb8d['wrapCallback'](()=>{})),_0x52cb8d['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x1bda52,_0x37bdc4,_0x48940f,_0x40c52b){this['_repo']=_0x1bda52,this['_path']=_0x37bdc4,this['_queryParams']=_0x48940f,this['_orderByCalled']=_0x40c52b;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x4a2202=sr(this['_queryParams']),_0x364453=$i(_0x4a2202);return _0x364453==='{}'?'default':_0x364453;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x3b57fb){if(_0x3b57fb=P(_0x3b57fb),!(_0x3b57fb instanceof Ae))return!0x1;const _0x5500f6=this['_repo']===_0x3b57fb['_repo'],_0x2646f2=Ki(this['_path'],_0x3b57fb['_path']),_0x180e68=this['_queryIdentifier']===_0x3b57fb['_queryIdentifier'];return _0x5500f6&&_0x2646f2&&_0x180e68;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x29271a,_0x20ab96){if(_0x29271a['_orderByCalled']===!0x0)throw new Error(_0x20ab96+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x1c36ce){let _0x339619=null,_0xfb6919=null;if(_0x1c36ce['hasStart']()&&(_0x339619=_0x1c36ce['getIndexStartValue']()),_0x1c36ce['hasEnd']()&&(_0xfb6919=_0x1c36ce['getIndexEndValue']()),_0x1c36ce['getIndex']()===ve){const _0x3dd11f='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x4b1637='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x1c36ce['hasStart']()){if(_0x1c36ce['getIndexStartName']()!==We)throw new Error(_0x3dd11f);if(typeof _0x339619!='string')throw new Error(_0x4b1637);}if(_0x1c36ce['hasEnd']()){if(_0x1c36ce['getIndexEndName']()!==we)throw new Error(_0x3dd11f);if(typeof _0xfb6919!='string')throw new Error(_0x4b1637);}}else{if(_0x1c36ce['getIndex']()===R){if(_0x339619!=null&&!Bt(_0x339619)||_0xfb6919!=null&&!Bt(_0xfb6919))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x1c36ce['getIndex']()instanceof Ji||_0x1c36ce['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x339619!=null&&typeof _0x339619=='object'||_0xfb6919!=null&&typeof _0xfb6919=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x30f143){if(_0x30f143['hasStart']()&&_0x30f143['hasEnd']()&&_0x30f143['hasLimit']()&&!_0x30f143['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x424f5b,_0x53c5e6){super(_0x424f5b,_0x53c5e6,new Zi(),!0x1);}get['parent'](){const _0x5f4d8a=Ro(this['_path']);return _0x5f4d8a===null?null:new ee(this['_repo'],_0x5f4d8a);}get['root'](){let _0x18abcf=this;for(;_0x18abcf['parent']!==null;)_0x18abcf=_0x18abcf['parent'];return _0x18abcf;}}class lt{constructor(_0x5b96e8,_0x510293,_0x127c8a){this['_node']=_0x5b96e8,this['ref']=_0x510293,this['_index']=_0x127c8a;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x124375){const _0x346510=new C(_0x124375),_0x499420=Vt(this['ref'],_0x124375);return new lt(this['_node']['getChild'](_0x346510),_0x499420,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x2e2c29){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x4b30fb,_0x3225fc)=>_0x2e2c29(new lt(_0x3225fc,Vt(this['ref'],_0x4b30fb),R)));}['hasChild'](_0x38d0fe){const _0x51082a=new C(_0x38d0fe);return!this['_node']['getChild'](_0x51082a)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x4f0e4b,_0xf2d314){return _0x4f0e4b=P(_0x4f0e4b),_0x4f0e4b['_checkNotDeleted']('ref'),_0xf2d314!==void 0x0?Vt(_0x4f0e4b['_root'],_0xf2d314):_0x4f0e4b['_root'];}function Vt(_0x2c42a0,_0x31ff99){return _0x2c42a0=P(_0x2c42a0),y(_0x2c42a0['_path'])===null?pd('child','path',_0x31ff99):ys('child','path',_0x31ff99),new ee(_0x2c42a0['_repo'],k(_0x2c42a0['_path'],_0x31ff99));}function v_(_0x359c38){return _0x359c38=P(_0x359c38),new Vd(_0x359c38['_repo'],_0x359c38['_path']);}function E_(_0x255f43,_0x290da7){_0x255f43=P(_0x255f43),Me('push',_0x255f43['_path']),He('push',_0x290da7,_0x255f43['_path'],!0x0);const _0x4d9bbd=la(_0x255f43['_repo']),_0x453b4f=Ud(_0x4d9bbd),_0x2a6510=Vt(_0x255f43,_0x453b4f),_0x264117=Vt(_0x255f43,_0x453b4f);let _0x3e5726;return _0x290da7!=null?_0x3e5726=Hd(_0x264117,_0x290da7)['then'](()=>_0x264117):_0x3e5726=Promise['resolve'](_0x264117),_0x2a6510['then']=_0x3e5726['then']['bind'](_0x3e5726),_0x2a6510['catch']=_0x3e5726['then']['bind'](_0x3e5726,void 0x0),_0x2a6510;}function Hd(_0x17508b,_0x666845){_0x17508b=P(_0x17508b),Me('set',_0x17508b['_path']),He('set',_0x666845,_0x17508b['_path'],!0x1);const _0x2e4ac0=new H();return Cd(_0x17508b['_repo'],_0x17508b['_path'],_0x666845,null,_0x2e4ac0['wrapCallback'](()=>{})),_0x2e4ac0['promise'];}function I_(_0x351b96,_0xed4240){ra('update',_0xed4240,_0x351b96['_path']);const _0x564748=new H();return Td(_0x351b96['_repo'],_0x351b96['_path'],_0xed4240,_0x564748['wrapCallback'](()=>{})),_0x564748['promise'];}function w_(_0x24dc06){_0x24dc06=P(_0x24dc06);const _0x257060=new pa(()=>{}),_0x500f10=new Qn(_0x257060);return wd(_0x24dc06['_repo'],_0x24dc06,_0x500f10)['then'](_0x16f030=>new lt(_0x16f030,new ee(_0x24dc06['_repo'],_0x24dc06['_path']),_0x24dc06['_queryParams']['getIndex']()));}class Qn{constructor(_0x3f68bd){this['callbackContext']=_0x3f68bd;}['respondsTo'](_0x426c3e){return _0x426c3e==='value';}['createEvent'](_0x4379e0,_0x54b11e){const _0x17a5ca=_0x54b11e['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x4379e0['snapshotNode'],new ee(_0x54b11e['_repo'],_0x54b11e['_path']),_0x17a5ca));}['getEventRunner'](_0x25626b){return _0x25626b['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x25626b['error']):()=>this['callbackContext']['onValue'](_0x25626b['snapshot'],null);}['createCancelEvent'](_0xa59c80,_0xdcdf4b){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0xa59c80,_0xdcdf4b):null;}['matches'](_0x2749be){return _0x2749be instanceof Qn?!_0x2749be['callbackContext']||!this['callbackContext']?!0x0:_0x2749be['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x558925,_0x5315d3,_0x4c3b6b,_0x3cedc5,_0x800f41){const _0x1e41ac=new pa(_0x4c3b6b,void 0x0),_0x365876=new Qn(_0x1e41ac);return kd(_0x558925['_repo'],_0x558925,_0x365876),()=>Pd(_0x558925['_repo'],_0x558925,_0x365876);}function Gd(_0x5db37a,_0x1037ba,_0x320172,_0xe43eb1){return $d(_0x5db37a,'value',_0x1037ba);}class mt{}class ma extends mt{constructor(_0x343715,_0x593747){super(),this['_value']=_0x343715,this['_key']=_0x593747,this['type']='endAt';}['_apply'](_0x4d1ae6){He('endAt',this['_value'],_0x4d1ae6['_path'],!0x0);const _0x147a93=Jh(_0x4d1ae6['_queryParams'],this['_value'],this['_key']);if(ga(_0x147a93),Yn(_0x147a93),_0x4d1ae6['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x4d1ae6['_repo'],_0x4d1ae6['_path'],_0x147a93,_0x4d1ae6['_orderByCalled']);}}function C_(_0x12f5dc,_0x2318a4){return new ma(_0x12f5dc,_0x2318a4);}class ya extends mt{constructor(_0x2a50b0,_0x4d75e9){super(),this['_value']=_0x2a50b0,this['_key']=_0x4d75e9,this['type']='startAt';}['_apply'](_0x159fa6){He('startAt',this['_value'],_0x159fa6['_path'],!0x0);const _0xc9bfb2=Qh(_0x159fa6['_queryParams'],this['_value'],this['_key']);if(ga(_0xc9bfb2),Yn(_0xc9bfb2),_0x159fa6['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x159fa6['_repo'],_0x159fa6['_path'],_0xc9bfb2,_0x159fa6['_orderByCalled']);}}function T_(_0x217558=null,_0x4c4f4b){return new ya(_0x217558,_0x4c4f4b);}class qd extends mt{constructor(_0x405cd1){super(),this['_limit']=_0x405cd1,this['type']='limitToFirst';}['_apply'](_0x45771c){if(_0x45771c['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x45771c['_repo'],_0x45771c['_path'],Yh(_0x45771c['_queryParams'],this['_limit']),_0x45771c['_orderByCalled']);}}function S_(_0x19a1e3){if(Math['floor'](_0x19a1e3)!==_0x19a1e3||_0x19a1e3<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x19a1e3);}class zd extends mt{constructor(_0x2abe59){super(),this['_path']=_0x2abe59,this['type']='orderByChild';}['_apply'](_0x41b2ec){_a(_0x41b2ec,'orderByChild');const _0x1dd2d6=new C(this['_path']);if(v(_0x1dd2d6))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x134282=new Ji(_0x1dd2d6),_0x4f47dc=xo(_0x41b2ec['_queryParams'],_0x134282);return Yn(_0x4f47dc),new Ae(_0x41b2ec['_repo'],_0x41b2ec['_path'],_0x4f47dc,!0x0);}}function b_(_0x5e3057){if(_0x5e3057==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x5e3057==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x5e3057==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x5e3057),new zd(_0x5e3057);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x15dbba){_a(_0x15dbba,'orderByKey');const _0x3846d4=xo(_0x15dbba['_queryParams'],ve);return Yn(_0x3846d4),new Ae(_0x15dbba['_repo'],_0x15dbba['_path'],_0x3846d4,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x3d9b7a,_0x5b5cce){super(),this['_value']=_0x3d9b7a,this['_key']=_0x5b5cce,this['type']='equalTo';}['_apply'](_0x4083cc){if(He('equalTo',this['_value'],_0x4083cc['_path'],!0x1),_0x4083cc['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x4083cc['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x4083cc));}}function A_(_0x57a349,_0x437ef8){return new Kd(_0x57a349,_0x437ef8);}function k_(_0x5d2d20,..._0x213295){let _0x1fbd14=P(_0x5d2d20);for(const _0x29b341 of _0x213295)_0x1fbd14=_0x29b341['_apply'](_0x1fbd14);return _0x1fbd14;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x57bb3e,_0x155e99,_0x428994,_0x1e427a){const _0x463a23=_0x155e99['lastIndexOf'](':'),_0x1f961c=_0x155e99['substring'](0x0,_0x463a23),_0x4ae14c=qt(_0x1f961c);_0x57bb3e['repoInfo_']=new yo(_0x155e99,_0x4ae14c,_0x57bb3e['repoInfo_']['namespace'],_0x57bb3e['repoInfo_']['webSocketOnly'],_0x57bb3e['repoInfo_']['nodeAdmin'],_0x57bb3e['repoInfo_']['persistenceKey'],_0x57bb3e['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x428994),_0x1e427a&&(_0x57bb3e['authTokenProvider_']=_0x1e427a);}function Xd(_0x5bd405,_0x564fe5,_0x1027a5,_0x15ba02,_0x2c4288){let _0x528afe=_0x15ba02||_0x5bd405['options']['databaseURL'];_0x528afe===void 0x0&&(_0x5bd405['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x5bd405['options']['projectId']),_0x528afe=_0x5bd405['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x1b6de7=vr(_0x528afe,_0x2c4288),_0x51dd38=_0x1b6de7['repoInfo'],_0x23a831;typeof process<'u'&&Bs&&(_0x23a831=Bs[Yd]),_0x23a831?(_0x528afe='http://'+_0x23a831+'?ns='+_0x51dd38['namespace'],_0x1b6de7=vr(_0x528afe,_0x2c4288),_0x51dd38=_0x1b6de7['repoInfo']):_0x1b6de7['repoInfo']['secure'];const _0x57f460=new eh(_0x5bd405['name'],_0x5bd405['options'],_0x564fe5);_d('Invalid\x20Firebase\x20Database\x20URL',_0x1b6de7),v(_0x1b6de7['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x5775af=ef(_0x51dd38,_0x5bd405,_0x57f460,new Zl(_0x5bd405,_0x1027a5));return new tf(_0x5775af,_0x5bd405);}function Zd(_0x28cdf9,_0xb5712b){const _0xd97629=Di[_0xb5712b];(!_0xd97629||_0xd97629[_0x28cdf9['key']]!==_0x28cdf9)&&ae('Database\x20'+_0xb5712b+'('+_0x28cdf9['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x28cdf9),delete _0xd97629[_0x28cdf9['key']];}function ef(_0x1bbbbf,_0x14a57f,_0x1e5c55,_0x57b592){let _0x29e078=Di[_0x14a57f['name']];_0x29e078||(_0x29e078={},Di[_0x14a57f['name']]=_0x29e078);let _0x380ce1=_0x29e078[_0x1bbbbf['toURLString']()];return _0x380ce1&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x380ce1=new vd(_0x1bbbbf,Qd,_0x1e5c55,_0x57b592),_0x29e078[_0x1bbbbf['toURLString']()]=_0x380ce1,_0x380ce1;}class tf{constructor(_0x276b53,_0x1aca71){this['_repoInternal']=_0x276b53,this['app']=_0x1aca71,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x3128be){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x3128be+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x32bc28=Zr(),_0x4841bb){const _0x489424=Hi(_0x32bc28,'database')['getImmediate']({'identifier':_0x4841bb});if(!_0x489424['_instanceStarted']){const _0x37408e=hc('database');_0x37408e&&nf(_0x489424,..._0x37408e);}return _0x489424;}function nf(_0x3ab246,_0x39e210,_0xec9e9b,_0x5c90a7={}){_0x3ab246=P(_0x3ab246),_0x3ab246['_checkNotDeleted']('useEmulator');const _0x53887d=_0x39e210+':'+_0xec9e9b,_0x5be587=_0x3ab246['_repoInternal'];if(_0x3ab246['_instanceStarted']){if(_0x53887d===_0x3ab246['_repoInternal']['repoInfo_']['host']&&xe(_0x5c90a7,_0x5be587['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0xfee680;if(_0x5be587['repoInfo_']['nodeAdmin'])_0x5c90a7['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0xfee680=new an(an['OWNER']);else{if(_0x5c90a7['mockUserToken']){const _0x2cca8c=typeof _0x5c90a7['mockUserToken']=='string'?_0x5c90a7['mockUserToken']:uc(_0x5c90a7['mockUserToken'],_0x3ab246['app']['options']['projectId']);_0xfee680=new an(_0x2cca8c);}}qt(_0x39e210)&&Qr(_0x39e210),Jd(_0x5be587,_0x53887d,_0x5c90a7,_0xfee680);}function N_(_0x420ccb){_0x420ccb=P(_0x420ccb),_0x420ccb['_checkNotDeleted']('goOffline'),ha(_0x420ccb['_repo']);}function O_(_0x988984){_0x988984=P(_0x988984),_0x988984['_checkNotDeleted']('goOnline'),Nd(_0x988984['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0xad63a3){Ul(dt),st(new Fe('database',(_0x381b01,{instanceIdentifier:_0x134c0f})=>{const _0x587262=_0x381b01['getProvider']('app')['getImmediate'](),_0x510774=_0x381b01['getProvider']('auth-internal'),_0x2c06dd=_0x381b01['getProvider']('app-check-internal');return Xd(_0x587262,_0x510774,_0x2c06dd,_0x134c0f);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0xad63a3),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x318f76,_0x3f7139){this['committed']=_0x318f76,this['snapshot']=_0x3f7139;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x4e7a9d,_0x3c20c6,_0x4a2b9e){if(_0x4e7a9d=P(_0x4e7a9d),Me('Reference.transaction',_0x4e7a9d['_path']),_0x4e7a9d['key']==='.length'||_0x4e7a9d['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x4e7a9d['key']+'\x20is\x20a\x20read-only\x20object.';const _0x208931=!0x0,_0x365d12=new H(),_0x3e3788=(_0x5357dc,_0x49a938,_0x5a3e3c)=>{let _0x315647=null;_0x5357dc?_0x365d12['reject'](_0x5357dc):(_0x315647=new lt(_0x5a3e3c,new ee(_0x4e7a9d['_repo'],_0x4e7a9d['_path']),R),_0x365d12['resolve'](new of(_0x49a938,_0x315647)));},_0x1e0ddb=Gd(_0x4e7a9d,()=>{});return Od(_0x4e7a9d['_repo'],_0x4e7a9d['_path'],_0x3c20c6,_0x3e3788,_0x1e0ddb,_0x208931),_0x365d12['promise'];}se['prototype']['simpleListen']=function(_0x4408c0,_0x2aa318){this['sendRequest']('q',{'p':_0x4408c0},_0x2aa318);},se['prototype']['echo']=function(_0x7cbe7,_0x5bc5c7){this['sendRequest']('echo',{'d':_0x7cbe7},_0x5bc5c7);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x9c0533,..._0x430b4f){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x9c0533,..._0x430b4f);}function cn(_0x45806d,..._0x2c53e6){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x45806d,..._0x2c53e6);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x3f41b3,..._0x40849b){throw ws(_0x3f41b3,..._0x40849b);}function X(_0x1553c2,..._0x4772f9){return ws(_0x1553c2,..._0x4772f9);}function Ia(_0x2fbba5,_0x7c8c08,_0x143b8c){const _0x67f082={...af(),[_0x7c8c08]:_0x143b8c};return new Gt('auth','Firebase',_0x67f082)['create'](_0x7c8c08,{'appName':_0x2fbba5['name']});}function re(_0x3cc30e){return Ia(_0x3cc30e,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x3a7df3,..._0x1995aa){if(typeof _0x3a7df3!='string'){const _0x48cf74=_0x1995aa[0x0],_0x35b335=[..._0x1995aa['slice'](0x1)];return _0x35b335[0x0]&&(_0x35b335[0x0]['appName']=_0x3a7df3['name']),_0x3a7df3['_errorFactory']['create'](_0x48cf74,..._0x35b335);}return Ea['create'](_0x3a7df3,..._0x1995aa);}function m(_0x3056d3,_0x2e7d8f,..._0x4731a4){if(!_0x3056d3)throw ws(_0x2e7d8f,..._0x4731a4);}function ne(_0x15542b){const _0x2ee2d7='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x15542b;throw cn(_0x2ee2d7),new Error(_0x2ee2d7);}function ce(_0x52e5b0,_0x236b5e){_0x52e5b0||ne(_0x236b5e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x564cc5;return typeof self<'u'&&((_0x564cc5=self['location'])==null?void 0x0:_0x564cc5['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x255de7;return typeof self<'u'&&((_0x255de7=self['location'])==null?void 0x0:_0x255de7['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x5c4f78=navigator;return _0x5c4f78['languages']&&_0x5c4f78['languages'][0x0]||_0x5c4f78['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x32b19d,_0x5deec6){this['shortDelay']=_0x32b19d,this['longDelay']=_0x5deec6,ce(_0x5deec6>_0x32b19d,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x50616f,_0x33442f){ce(_0x50616f['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x3bf4e9}=_0x50616f['emulator'];return _0x33442f?''+_0x3bf4e9+(_0x33442f['startsWith']('/')?_0x33442f['slice'](0x1):_0x33442f):_0x3bf4e9;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x15678f,_0x50f699,_0x2b3570){this['fetchImpl']=_0x15678f,_0x50f699&&(this['headersImpl']=_0x50f699),_0x2b3570&&(this['responseImpl']=_0x2b3570);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x593eb6,_0x2108b9){return _0x593eb6['tenantId']&&!_0x2108b9['tenantId']?{..._0x2108b9,'tenantId':_0x593eb6['tenantId']}:_0x2108b9;}async function Pe(_0x22ff13,_0x22fa78,_0x4a1930,_0x5bb893,_0x1913be={}){return Ca(_0x22ff13,_0x1913be,async()=>{let _0x4c35c8={},_0x273194={};_0x5bb893&&(_0x22fa78==='GET'?_0x273194=_0x5bb893:_0x4c35c8={'body':JSON['stringify'](_0x5bb893)});const _0x300854=ut({..._0x273194,'key':_0x22ff13['config']['apiKey']})['slice'](0x1),_0x5cabf4=await _0x22ff13['_getAdditionalHeaders']();_0x5cabf4['Content-Type']='application/json',_0x22ff13['languageCode']&&(_0x5cabf4['X-Firebase-Locale']=_0x22ff13['languageCode']);const _0x4942f0={'method':_0x22fa78,'headers':_0x5cabf4,..._0x4c35c8};return dc()||(_0x4942f0['referrerPolicy']='strict-origin-when-cross-origin'),_0x22ff13['emulatorConfig']&&qt(_0x22ff13['emulatorConfig']['host'])&&(_0x4942f0['credentials']='include'),wa['fetch']()(await Ta(_0x22ff13,_0x22ff13['config']['apiHost'],_0x4a1930,_0x300854),_0x4942f0);});}async function Ca(_0x2e8caf,_0x44e595,_0x503d21){_0x2e8caf['_canInitEmulator']=!0x1;const _0xc52930={...df,..._0x44e595};try{const _0x3f6dae=new gf(_0x2e8caf),_0x2262ee=await Promise['race']([_0x503d21(),_0x3f6dae['promise']]);_0x3f6dae['clearNetworkTimeout']();const _0xeaa9fd=await _0x2262ee['json']();if('needConfirmation'in _0xeaa9fd)throw on(_0x2e8caf,'account-exists-with-different-credential',_0xeaa9fd);if(_0x2262ee['ok']&&!('errorMessage'in _0xeaa9fd))return _0xeaa9fd;{const _0xd62ead=_0x2262ee['ok']?_0xeaa9fd['errorMessage']:_0xeaa9fd['error']['message'],[_0x1e2f48,_0x36b461]=_0xd62ead['split']('\x20:\x20');if(_0x1e2f48==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x2e8caf,'credential-already-in-use',_0xeaa9fd);if(_0x1e2f48==='EMAIL_EXISTS')throw on(_0x2e8caf,'email-already-in-use',_0xeaa9fd);if(_0x1e2f48==='USER_DISABLED')throw on(_0x2e8caf,'user-disabled',_0xeaa9fd);const _0x1e4a96=_0xc52930[_0x1e2f48]||_0x1e2f48['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x36b461)throw Ia(_0x2e8caf,_0x1e4a96,_0x36b461);Y(_0x2e8caf,_0x1e4a96);}}catch(_0x3ac1a6){if(_0x3ac1a6 instanceof Re)throw _0x3ac1a6;Y(_0x2e8caf,'network-request-failed',{'message':String(_0x3ac1a6)});}}async function en(_0x2b38f8,_0xf130bf,_0x878132,_0x1284f4,_0x2a4fc7={}){const _0x192902=await Pe(_0x2b38f8,_0xf130bf,_0x878132,_0x1284f4,_0x2a4fc7);return'mfaPendingCredential'in _0x192902&&Y(_0x2b38f8,'multi-factor-auth-required',{'_serverResponse':_0x192902}),_0x192902;}async function Ta(_0x3e009f,_0x47f962,_0x1f33f2,_0xcc76){const _0x5cac8c=''+_0x47f962+_0x1f33f2+'?'+_0xcc76,_0x56d35e=_0x3e009f,_0x3a5738=_0x56d35e['config']['emulator']?Cs(_0x3e009f['config'],_0x5cac8c):_0x3e009f['config']['apiScheme']+'://'+_0x5cac8c;return ff['includes'](_0x1f33f2)&&(await _0x56d35e['_persistenceManagerAvailable'],_0x56d35e['_getPersistenceType']()==='COOKIE')?_0x56d35e['_getPersistence']()['_getFinalTarget'](_0x3a5738)['toString']():_0x3a5738;}function _f(_0x402bb7){switch(_0x402bb7){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x1473f0){this['auth']=_0x1473f0,this['timer']=null,this['promise']=new Promise((_0x578a39,_0x1bb4bd)=>{this['timer']=setTimeout(()=>_0x1bb4bd(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x2a9a98,_0x589a09,_0x121100){const _0x55c893={'appName':_0x2a9a98['name']};_0x121100['email']&&(_0x55c893['email']=_0x121100['email']),_0x121100['phoneNumber']&&(_0x55c893['phoneNumber']=_0x121100['phoneNumber']);const _0x5cbc21=X(_0x2a9a98,_0x589a09,_0x55c893);return _0x5cbc21['customData']['_tokenResponse']=_0x121100,_0x5cbc21;}function wr(_0x329611){return _0x329611!==void 0x0&&_0x329611['enterprise']!==void 0x0;}class mf{constructor(_0x5c5aa2){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x5c5aa2['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x5c5aa2['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x5c5aa2['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x5557d2){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x13302e of this['recaptchaEnforcementState'])if(_0x13302e['provider']&&_0x13302e['provider']===_0x5557d2)return _f(_0x13302e['enforcementState']);return null;}['isProviderEnabled'](_0x33fcf2){return this['getProviderEnforcementState'](_0x33fcf2)==='ENFORCE'||this['getProviderEnforcementState'](_0x33fcf2)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0xc8ad8b,_0x36806d){return Pe(_0xc8ad8b,'GET','/v2/recaptchaConfig',ke(_0xc8ad8b,_0x36806d));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x3ce993,_0x36d85f){return Pe(_0x3ce993,'POST','/v1/accounts:delete',_0x36d85f);}async function Pn(_0x36cf30,_0x434af9){return Pe(_0x36cf30,'POST','/v1/accounts:lookup',_0x434af9);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x1f2e3f){if(_0x1f2e3f)try{const _0x265dc1=new Date(Number(_0x1f2e3f));if(!isNaN(_0x265dc1['getTime']()))return _0x265dc1['toUTCString']();}catch{}}async function Ef(_0x3ed5f2,_0x4d87c3=!0x1){const _0x4e911c=P(_0x3ed5f2),_0x2a24d2=await _0x4e911c['getIdToken'](_0x4d87c3),_0x157e96=Ts(_0x2a24d2);m(_0x157e96&&_0x157e96['exp']&&_0x157e96['auth_time']&&_0x157e96['iat'],_0x4e911c['auth'],'internal-error');const _0x5dcbb3=typeof _0x157e96['firebase']=='object'?_0x157e96['firebase']:void 0x0,_0x53175c=_0x5dcbb3==null?void 0x0:_0x5dcbb3['sign_in_provider'];return{'claims':_0x157e96,'token':_0x2a24d2,'authTime':Pt(fi(_0x157e96['auth_time'])),'issuedAtTime':Pt(fi(_0x157e96['iat'])),'expirationTime':Pt(fi(_0x157e96['exp'])),'signInProvider':_0x53175c||null,'signInSecondFactor':(_0x5dcbb3==null?void 0x0:_0x5dcbb3['sign_in_second_factor'])||null};}function fi(_0xc002a1){return Number(_0xc002a1)*0x3e8;}function Ts(_0x6575e2){const [_0x4005d1,_0x37279d,_0x3efccc]=_0x6575e2['split']('.');if(_0x4005d1===void 0x0||_0x37279d===void 0x0||_0x3efccc===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x35f99a=fn(_0x37279d);return _0x35f99a?JSON['parse'](_0x35f99a):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x38a87f){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x38a87f==null?void 0x0:_0x38a87f['toString']()),null;}}function Cr(_0x1276ad){const _0x5133c6=Ts(_0x1276ad);return m(_0x5133c6,'internal-error'),m(typeof _0x5133c6['exp']<'u','internal-error'),m(typeof _0x5133c6['iat']<'u','internal-error'),Number(_0x5133c6['exp'])-Number(_0x5133c6['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x4c7c0b,_0x472efe,_0xdd7e49=!0x1){if(_0xdd7e49)return _0x472efe;try{return await _0x472efe;}catch(_0x37b007){throw _0x37b007 instanceof Re&&If(_0x37b007)&&_0x4c7c0b['auth']['currentUser']===_0x4c7c0b&&await _0x4c7c0b['auth']['signOut'](),_0x37b007;}}function If({code:_0x958af5}){return _0x958af5==='auth/user-disabled'||_0x958af5==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x367f79){this['user']=_0x367f79,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x28d007){if(_0x28d007){const _0x13d59a=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x13d59a;}else{this['errorBackoff']=0x7530;const _0x3df51a=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x3df51a);}}['schedule'](_0x29485e=!0x1){if(!this['isRunning'])return;const _0x3efb9a=this['getInterval'](_0x29485e);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x3efb9a);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x442c36){(_0x442c36==null?void 0x0:_0x442c36['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x4c68aa,_0x2844b8){this['createdAt']=_0x4c68aa,this['lastLoginAt']=_0x2844b8,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x2ff7b0){this['createdAt']=_0x2ff7b0['createdAt'],this['lastLoginAt']=_0x2ff7b0['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x4b51a5){var _0x2f665c;const _0x4475f0=_0x4b51a5['auth'],_0x67722e=await _0x4b51a5['getIdToken'](),_0x1671a3=await Ht(_0x4b51a5,Pn(_0x4475f0,{'idToken':_0x67722e}));m(_0x1671a3==null?void 0x0:_0x1671a3['users']['length'],_0x4475f0,'internal-error');const _0x22185f=_0x1671a3['users'][0x0];_0x4b51a5['_notifyReloadListener'](_0x22185f);const _0x2944e3=(_0x2f665c=_0x22185f['providerUserInfo'])!=null&&_0x2f665c['length']?Sa(_0x22185f['providerUserInfo']):[],_0x31feff=Tf(_0x4b51a5['providerData'],_0x2944e3),_0x3290fd=_0x4b51a5['isAnonymous'],_0x112494=!(_0x4b51a5['email']&&_0x22185f['passwordHash'])&&!(_0x31feff!=null&&_0x31feff['length']),_0x531662=_0x3290fd?_0x112494:!0x1,_0x3aed3a={'uid':_0x22185f['localId'],'displayName':_0x22185f['displayName']||null,'photoURL':_0x22185f['photoUrl']||null,'email':_0x22185f['email']||null,'emailVerified':_0x22185f['emailVerified']||!0x1,'phoneNumber':_0x22185f['phoneNumber']||null,'tenantId':_0x22185f['tenantId']||null,'providerData':_0x31feff,'metadata':new Li(_0x22185f['createdAt'],_0x22185f['lastLoginAt']),'isAnonymous':_0x531662};Object['assign'](_0x4b51a5,_0x3aed3a);}async function Cf(_0x31d1b1){const _0x392933=P(_0x31d1b1);await Nn(_0x392933),await _0x392933['auth']['_persistUserIfCurrent'](_0x392933),_0x392933['auth']['_notifyListenersIfCurrent'](_0x392933);}function Tf(_0x2d6270,_0x495a78){return[..._0x2d6270['filter'](_0x2a48e2=>!_0x495a78['some'](_0x3e0909=>_0x3e0909['providerId']===_0x2a48e2['providerId'])),..._0x495a78];}function Sa(_0x575ef6){return _0x575ef6['map'](({providerId:_0x1151d6,..._0xef44d7})=>({'providerId':_0x1151d6,'uid':_0xef44d7['rawId']||'','displayName':_0xef44d7['displayName']||null,'email':_0xef44d7['email']||null,'phoneNumber':_0xef44d7['phoneNumber']||null,'photoURL':_0xef44d7['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x2f3dbd,_0xe47390){const _0x4ec6ce=await Ca(_0x2f3dbd,{},async()=>{const _0x1ca8de=ut({'grant_type':'refresh_token','refresh_token':_0xe47390})['slice'](0x1),{tokenApiHost:_0x4a67e0,apiKey:_0x3ab007}=_0x2f3dbd['config'],_0x701b41=await Ta(_0x2f3dbd,_0x4a67e0,'/v1/token','key='+_0x3ab007),_0x404acf=await _0x2f3dbd['_getAdditionalHeaders']();_0x404acf['Content-Type']='application/x-www-form-urlencoded';const _0x2f0394={'method':'POST','headers':_0x404acf,'body':_0x1ca8de};return _0x2f3dbd['emulatorConfig']&&qt(_0x2f3dbd['emulatorConfig']['host'])&&(_0x2f0394['credentials']='include'),wa['fetch']()(_0x701b41,_0x2f0394);});return{'accessToken':_0x4ec6ce['access_token'],'expiresIn':_0x4ec6ce['expires_in'],'refreshToken':_0x4ec6ce['refresh_token']};}async function bf(_0x52c4b8,_0x44d421){return Pe(_0x52c4b8,'POST','/v2/accounts:revokeToken',ke(_0x52c4b8,_0x44d421));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x2ea465){m(_0x2ea465['idToken'],'internal-error'),m(typeof _0x2ea465['idToken']<'u','internal-error'),m(typeof _0x2ea465['refreshToken']<'u','internal-error');const _0xd334d4='expiresIn'in _0x2ea465&&typeof _0x2ea465['expiresIn']<'u'?Number(_0x2ea465['expiresIn']):Cr(_0x2ea465['idToken']);this['updateTokensAndExpiration'](_0x2ea465['idToken'],_0x2ea465['refreshToken'],_0xd334d4);}['updateFromIdToken'](_0x3eceb7){m(_0x3eceb7['length']!==0x0,'internal-error');const _0x52638d=Cr(_0x3eceb7);this['updateTokensAndExpiration'](_0x3eceb7,null,_0x52638d);}async['getToken'](_0x4654e0,_0x13437d=!0x1){return!_0x13437d&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x4654e0,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x4654e0,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x50e6cc,_0x8383ff){const {accessToken:_0x41c6fe,refreshToken:_0x5ea805,expiresIn:_0x401b59}=await Sf(_0x50e6cc,_0x8383ff);this['updateTokensAndExpiration'](_0x41c6fe,_0x5ea805,Number(_0x401b59));}['updateTokensAndExpiration'](_0x254dc9,_0x4d1502,_0x3fd523){this['refreshToken']=_0x4d1502||null,this['accessToken']=_0x254dc9||null,this['expirationTime']=Date['now']()+_0x3fd523*0x3e8;}static['fromJSON'](_0x288bc0,_0xa5f770){const {refreshToken:_0x29da14,accessToken:_0x164944,expirationTime:_0x410f1e}=_0xa5f770,_0x30dd1d=new et();return _0x29da14&&(m(typeof _0x29da14=='string','internal-error',{'appName':_0x288bc0}),_0x30dd1d['refreshToken']=_0x29da14),_0x164944&&(m(typeof _0x164944=='string','internal-error',{'appName':_0x288bc0}),_0x30dd1d['accessToken']=_0x164944),_0x410f1e&&(m(typeof _0x410f1e=='number','internal-error',{'appName':_0x288bc0}),_0x30dd1d['expirationTime']=_0x410f1e),_0x30dd1d;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x28b733){this['accessToken']=_0x28b733['accessToken'],this['refreshToken']=_0x28b733['refreshToken'],this['expirationTime']=_0x28b733['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x1611ca,_0x43bafb){m(typeof _0x1611ca=='string'||typeof _0x1611ca>'u','internal-error',{'appName':_0x43bafb});}class j{constructor({uid:_0x1401c4,auth:_0x258800,stsTokenManager:_0x3fe686,..._0x1575a4}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x1401c4,this['auth']=_0x258800,this['stsTokenManager']=_0x3fe686,this['accessToken']=_0x3fe686['accessToken'],this['displayName']=_0x1575a4['displayName']||null,this['email']=_0x1575a4['email']||null,this['emailVerified']=_0x1575a4['emailVerified']||!0x1,this['phoneNumber']=_0x1575a4['phoneNumber']||null,this['photoURL']=_0x1575a4['photoURL']||null,this['isAnonymous']=_0x1575a4['isAnonymous']||!0x1,this['tenantId']=_0x1575a4['tenantId']||null,this['providerData']=_0x1575a4['providerData']?[..._0x1575a4['providerData']]:[],this['metadata']=new Li(_0x1575a4['createdAt']||void 0x0,_0x1575a4['lastLoginAt']||void 0x0);}async['getIdToken'](_0x10662b){const _0xba98e3=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x10662b));return m(_0xba98e3,this['auth'],'internal-error'),this['accessToken']!==_0xba98e3&&(this['accessToken']=_0xba98e3,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0xba98e3;}['getIdTokenResult'](_0x59f726){return Ef(this,_0x59f726);}['reload'](){return Cf(this);}['_assign'](_0x359d6e){this!==_0x359d6e&&(m(this['uid']===_0x359d6e['uid'],this['auth'],'internal-error'),this['displayName']=_0x359d6e['displayName'],this['photoURL']=_0x359d6e['photoURL'],this['email']=_0x359d6e['email'],this['emailVerified']=_0x359d6e['emailVerified'],this['phoneNumber']=_0x359d6e['phoneNumber'],this['isAnonymous']=_0x359d6e['isAnonymous'],this['tenantId']=_0x359d6e['tenantId'],this['providerData']=_0x359d6e['providerData']['map'](_0x59928c=>({..._0x59928c})),this['metadata']['_copy'](_0x359d6e['metadata']),this['stsTokenManager']['_assign'](_0x359d6e['stsTokenManager']));}['_clone'](_0x21e007){const _0x26520a=new j({...this,'auth':_0x21e007,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x26520a['metadata']['_copy'](this['metadata']),_0x26520a;}['_onReload'](_0x1a87fb){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x1a87fb,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x14d452){this['reloadListener']?this['reloadListener'](_0x14d452):this['reloadUserInfo']=_0x14d452;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x137193,_0x5d376f=!0x1){let _0x12c813=!0x1;_0x137193['idToken']&&_0x137193['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x137193),_0x12c813=!0x0),_0x5d376f&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x12c813&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x321eff=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x321eff})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x1b2304=>({..._0x1b2304})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x44e7f8,_0x2b5757){const _0x3be6d6=_0x2b5757['displayName']??void 0x0,_0x10ada2=_0x2b5757['email']??void 0x0,_0x32b2a0=_0x2b5757['phoneNumber']??void 0x0,_0x5511f2=_0x2b5757['photoURL']??void 0x0,_0x3d39a1=_0x2b5757['tenantId']??void 0x0,_0x37040d=_0x2b5757['_redirectEventId']??void 0x0,_0x12efc3=_0x2b5757['createdAt']??void 0x0,_0xd0704e=_0x2b5757['lastLoginAt']??void 0x0,{uid:_0x38fc50,emailVerified:_0x5d6068,isAnonymous:_0x37532c,providerData:_0xa73a,stsTokenManager:_0x5d1f96}=_0x2b5757;m(_0x38fc50&&_0x5d1f96,_0x44e7f8,'internal-error');const _0x5c62a5=et['fromJSON'](this['name'],_0x5d1f96);m(typeof _0x38fc50=='string',_0x44e7f8,'internal-error'),le(_0x3be6d6,_0x44e7f8['name']),le(_0x10ada2,_0x44e7f8['name']),m(typeof _0x5d6068=='boolean',_0x44e7f8,'internal-error'),m(typeof _0x37532c=='boolean',_0x44e7f8,'internal-error'),le(_0x32b2a0,_0x44e7f8['name']),le(_0x5511f2,_0x44e7f8['name']),le(_0x3d39a1,_0x44e7f8['name']),le(_0x37040d,_0x44e7f8['name']),le(_0x12efc3,_0x44e7f8['name']),le(_0xd0704e,_0x44e7f8['name']);const _0x28984b=new j({'uid':_0x38fc50,'auth':_0x44e7f8,'email':_0x10ada2,'emailVerified':_0x5d6068,'displayName':_0x3be6d6,'isAnonymous':_0x37532c,'photoURL':_0x5511f2,'phoneNumber':_0x32b2a0,'tenantId':_0x3d39a1,'stsTokenManager':_0x5c62a5,'createdAt':_0x12efc3,'lastLoginAt':_0xd0704e});return _0xa73a&&Array['isArray'](_0xa73a)&&(_0x28984b['providerData']=_0xa73a['map'](_0x125a16=>({..._0x125a16}))),_0x37040d&&(_0x28984b['_redirectEventId']=_0x37040d),_0x28984b;}static async['_fromIdTokenResponse'](_0x1a0323,_0x4d5398,_0x2eee93=!0x1){const _0x225558=new et();_0x225558['updateFromServerResponse'](_0x4d5398);const _0x3d1c2a=new j({'uid':_0x4d5398['localId'],'auth':_0x1a0323,'stsTokenManager':_0x225558,'isAnonymous':_0x2eee93});return await Nn(_0x3d1c2a),_0x3d1c2a;}static async['_fromGetAccountInfoResponse'](_0x2b7fe3,_0x2fe073,_0x3332a8){const _0x315c66=_0x2fe073['users'][0x0];m(_0x315c66['localId']!==void 0x0,'internal-error');const _0x39e6fc=_0x315c66['providerUserInfo']!==void 0x0?Sa(_0x315c66['providerUserInfo']):[],_0x47acfc=!(_0x315c66['email']&&_0x315c66['passwordHash'])&&!(_0x39e6fc!=null&&_0x39e6fc['length']),_0x3863bf=new et();_0x3863bf['updateFromIdToken'](_0x3332a8);const _0x2ffb4a=new j({'uid':_0x315c66['localId'],'auth':_0x2b7fe3,'stsTokenManager':_0x3863bf,'isAnonymous':_0x47acfc}),_0x4719b3={'uid':_0x315c66['localId'],'displayName':_0x315c66['displayName']||null,'photoURL':_0x315c66['photoUrl']||null,'email':_0x315c66['email']||null,'emailVerified':_0x315c66['emailVerified']||!0x1,'phoneNumber':_0x315c66['phoneNumber']||null,'tenantId':_0x315c66['tenantId']||null,'providerData':_0x39e6fc,'metadata':new Li(_0x315c66['createdAt'],_0x315c66['lastLoginAt']),'isAnonymous':!(_0x315c66['email']&&_0x315c66['passwordHash'])&&!(_0x39e6fc!=null&&_0x39e6fc['length'])};return Object['assign'](_0x2ffb4a,_0x4719b3),_0x2ffb4a;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x811700){ce(_0x811700 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x54803e=Tr['get'](_0x811700);return _0x54803e?(ce(_0x54803e instanceof _0x811700,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x54803e):(_0x54803e=new _0x811700(),Tr['set'](_0x811700,_0x54803e),_0x54803e);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x59636b,_0x1425e7){this['storage'][_0x59636b]=_0x1425e7;}async['_get'](_0x23e4ae){const _0x65b126=this['storage'][_0x23e4ae];return _0x65b126===void 0x0?null:_0x65b126;}async['_remove'](_0x287156){delete this['storage'][_0x287156];}['_addListener'](_0x33ab3c,_0x4e9aa2){}['_removeListener'](_0x598d4e,_0xa9994e){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x7a0c86,_0x4e7611,_0x503d1d){return'firebase:'+_0x7a0c86+':'+_0x4e7611+':'+_0x503d1d;}class tt{constructor(_0x2bc1d8,_0x147e6d,_0x26b9ba){this['persistence']=_0x2bc1d8,this['auth']=_0x147e6d,this['userKey']=_0x26b9ba;const {config:_0x3a7af4,name:_0x42e0dc}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x3a7af4['apiKey'],_0x42e0dc),this['fullPersistenceKey']=ln('persistence',_0x3a7af4['apiKey'],_0x42e0dc),this['boundEventHandler']=_0x147e6d['_onStorageEvent']['bind'](_0x147e6d),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x1c19ea){return this['persistence']['_set'](this['fullUserKey'],_0x1c19ea['toJSON']());}async['getCurrentUser'](){const _0xdcbe2=await this['persistence']['_get'](this['fullUserKey']);if(!_0xdcbe2)return null;if(typeof _0xdcbe2=='string'){const _0x219136=await Pn(this['auth'],{'idToken':_0xdcbe2})['catch'](()=>{});return _0x219136?j['_fromGetAccountInfoResponse'](this['auth'],_0x219136,_0xdcbe2):null;}return j['_fromJSON'](this['auth'],_0xdcbe2);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x518725){if(this['persistence']===_0x518725)return;const _0xddbc72=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x518725,_0xddbc72)return this['setCurrentUser'](_0xddbc72);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x15ca72,_0x3dec37,_0x112706='authUser'){if(!_0x3dec37['length'])return new tt(ie(Sr),_0x15ca72,_0x112706);const _0x124fdd=(await Promise['all'](_0x3dec37['map'](async _0x372487=>{if(await _0x372487['_isAvailable']())return _0x372487;})))['filter'](_0x4f6292=>_0x4f6292);let _0x4b3932=_0x124fdd[0x0]||ie(Sr);const _0x53ecd4=ln(_0x112706,_0x15ca72['config']['apiKey'],_0x15ca72['name']);let _0x36d230=null;for(const _0x2ecd74 of _0x3dec37)try{const _0x4244ae=await _0x2ecd74['_get'](_0x53ecd4);if(_0x4244ae){let _0x3c9575;if(typeof _0x4244ae=='string'){const _0x45b3f4=await Pn(_0x15ca72,{'idToken':_0x4244ae})['catch'](()=>{});if(!_0x45b3f4)break;_0x3c9575=await j['_fromGetAccountInfoResponse'](_0x15ca72,_0x45b3f4,_0x4244ae);}else _0x3c9575=j['_fromJSON'](_0x15ca72,_0x4244ae);_0x2ecd74!==_0x4b3932&&(_0x36d230=_0x3c9575),_0x4b3932=_0x2ecd74;break;}}catch{}const _0x144fca=_0x124fdd['filter'](_0x2e213c=>_0x2e213c['_shouldAllowMigration']);return!_0x4b3932['_shouldAllowMigration']||!_0x144fca['length']?new tt(_0x4b3932,_0x15ca72,_0x112706):(_0x4b3932=_0x144fca[0x0],_0x36d230&&await _0x4b3932['_set'](_0x53ecd4,_0x36d230['toJSON']()),await Promise['all'](_0x3dec37['map'](async _0x45aa9b=>{if(_0x45aa9b!==_0x4b3932)try{await _0x45aa9b['_remove'](_0x53ecd4);}catch{}})),new tt(_0x4b3932,_0x15ca72,_0x112706));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0xde2abf){const _0x49bbd7=_0xde2abf['toLowerCase']();if(_0x49bbd7['includes']('opera/')||_0x49bbd7['includes']('opr/')||_0x49bbd7['includes']('opios/'))return'Opera';if(Pa(_0x49bbd7))return'IEMobile';if(_0x49bbd7['includes']('msie')||_0x49bbd7['includes']('trident/'))return'IE';if(_0x49bbd7['includes']('edge/'))return'Edge';if(Ra(_0x49bbd7))return'Firefox';if(_0x49bbd7['includes']('silk/'))return'Silk';if(Oa(_0x49bbd7))return'Blackberry';if(Da(_0x49bbd7))return'Webos';if(Aa(_0x49bbd7))return'Safari';if((_0x49bbd7['includes']('chrome/')||ka(_0x49bbd7))&&!_0x49bbd7['includes']('edge/'))return'Chrome';if(Na(_0x49bbd7))return'Android';{const _0x15b9fe=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x3312d5=_0xde2abf['match'](_0x15b9fe);if((_0x3312d5==null?void 0x0:_0x3312d5['length'])===0x2)return _0x3312d5[0x1];}return'Other';}function Ra(_0x3a1529=W()){return/firefox\//i['test'](_0x3a1529);}function Aa(_0x42a3=W()){const _0x4ec38f=_0x42a3['toLowerCase']();return _0x4ec38f['includes']('safari/')&&!_0x4ec38f['includes']('chrome/')&&!_0x4ec38f['includes']('crios/')&&!_0x4ec38f['includes']('android');}function ka(_0x4929f4=W()){return/crios\//i['test'](_0x4929f4);}function Pa(_0x156b5e=W()){return/iemobile/i['test'](_0x156b5e);}function Na(_0x5d0ca9=W()){return/android/i['test'](_0x5d0ca9);}function Oa(_0xebc22=W()){return/blackberry/i['test'](_0xebc22);}function Da(_0x40119b=W()){return/webos/i['test'](_0x40119b);}function Ss(_0x41b0d9=W()){return/iphone|ipad|ipod/i['test'](_0x41b0d9)||/macintosh/i['test'](_0x41b0d9)&&/mobile/i['test'](_0x41b0d9);}function Rf(_0x265bc0=W()){var _0x1c6e3a;return Ss(_0x265bc0)&&!!((_0x1c6e3a=window['navigator'])!=null&&_0x1c6e3a['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x1c9ce0=W()){return Ss(_0x1c9ce0)||Na(_0x1c9ce0)||Da(_0x1c9ce0)||Oa(_0x1c9ce0)||/windows phone/i['test'](_0x1c9ce0)||Pa(_0x1c9ce0);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0xec0d14,_0x3e578d=[]){let _0x4ebb48;switch(_0xec0d14){case'Browser':_0x4ebb48=br(W());break;case'Worker':_0x4ebb48=br(W())+'-'+_0xec0d14;break;default:_0x4ebb48=_0xec0d14;}const _0x46728b=_0x3e578d['length']?_0x3e578d['join'](','):'FirebaseCore-web';return _0x4ebb48+'/JsCore/'+dt+'/'+_0x46728b;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x48adb6){this['auth']=_0x48adb6,this['queue']=[];}['pushCallback'](_0x3b3cbe,_0x2485c9){const _0x4d042c=_0x452a2e=>new Promise((_0x423485,_0x242c21)=>{try{const _0x36270c=_0x3b3cbe(_0x452a2e);_0x423485(_0x36270c);}catch(_0x100f9a){_0x242c21(_0x100f9a);}});_0x4d042c['onAbort']=_0x2485c9,this['queue']['push'](_0x4d042c);const _0x172d47=this['queue']['length']-0x1;return()=>{this['queue'][_0x172d47]=()=>Promise['resolve']();};}async['runMiddleware'](_0x1a6649){if(this['auth']['currentUser']===_0x1a6649)return;const _0x20f192=[];try{for(const _0x2c2030 of this['queue'])await _0x2c2030(_0x1a6649),_0x2c2030['onAbort']&&_0x20f192['push'](_0x2c2030['onAbort']);}catch(_0x40c510){_0x20f192['reverse']();for(const _0x3484b6 of _0x20f192)try{_0x3484b6();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x40c510==null?void 0x0:_0x40c510['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x496f81,_0x23ebe2={}){return Pe(_0x496f81,'GET','/v2/passwordPolicy',ke(_0x496f81,_0x23ebe2));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0xb6c790){var _0x44e527;const _0x2b1e25=_0xb6c790['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x2b1e25['minPasswordLength']??Nf,_0x2b1e25['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x2b1e25['maxPasswordLength']),_0x2b1e25['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x2b1e25['containsLowercaseCharacter']),_0x2b1e25['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x2b1e25['containsUppercaseCharacter']),_0x2b1e25['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x2b1e25['containsNumericCharacter']),_0x2b1e25['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x2b1e25['containsNonAlphanumericCharacter']),this['enforcementState']=_0xb6c790['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x44e527=_0xb6c790['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x44e527['join'](''))??'',this['forceUpgradeOnSignin']=_0xb6c790['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0xb6c790['schemaVersion'];}['validatePassword'](_0x3b6e7e){const _0x220c4d={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x3b6e7e,_0x220c4d),this['validatePasswordCharacterOptions'](_0x3b6e7e,_0x220c4d),_0x220c4d['isValid']&&(_0x220c4d['isValid']=_0x220c4d['meetsMinPasswordLength']??!0x0),_0x220c4d['isValid']&&(_0x220c4d['isValid']=_0x220c4d['meetsMaxPasswordLength']??!0x0),_0x220c4d['isValid']&&(_0x220c4d['isValid']=_0x220c4d['containsLowercaseLetter']??!0x0),_0x220c4d['isValid']&&(_0x220c4d['isValid']=_0x220c4d['containsUppercaseLetter']??!0x0),_0x220c4d['isValid']&&(_0x220c4d['isValid']=_0x220c4d['containsNumericCharacter']??!0x0),_0x220c4d['isValid']&&(_0x220c4d['isValid']=_0x220c4d['containsNonAlphanumericCharacter']??!0x0),_0x220c4d;}['validatePasswordLengthOptions'](_0x153aed,_0x2130bb){const _0x385751=this['customStrengthOptions']['minPasswordLength'],_0x29f55b=this['customStrengthOptions']['maxPasswordLength'];_0x385751&&(_0x2130bb['meetsMinPasswordLength']=_0x153aed['length']>=_0x385751),_0x29f55b&&(_0x2130bb['meetsMaxPasswordLength']=_0x153aed['length']<=_0x29f55b);}['validatePasswordCharacterOptions'](_0x33e2d6,_0x39f1ab){this['updatePasswordCharacterOptionsStatuses'](_0x39f1ab,!0x1,!0x1,!0x1,!0x1);let _0x5aaa50;for(let _0x212462=0x0;_0x212462<_0x33e2d6['length'];_0x212462++)_0x5aaa50=_0x33e2d6['charAt'](_0x212462),this['updatePasswordCharacterOptionsStatuses'](_0x39f1ab,_0x5aaa50>='a'&&_0x5aaa50<='z',_0x5aaa50>='A'&&_0x5aaa50<='Z',_0x5aaa50>='0'&&_0x5aaa50<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x5aaa50));}['updatePasswordCharacterOptionsStatuses'](_0x298a95,_0x41f8b1,_0x1a695d,_0x8275eb,_0xae93e2){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x298a95['containsLowercaseLetter']||(_0x298a95['containsLowercaseLetter']=_0x41f8b1)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x298a95['containsUppercaseLetter']||(_0x298a95['containsUppercaseLetter']=_0x1a695d)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x298a95['containsNumericCharacter']||(_0x298a95['containsNumericCharacter']=_0x8275eb)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x298a95['containsNonAlphanumericCharacter']||(_0x298a95['containsNonAlphanumericCharacter']=_0xae93e2));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x2ee363,_0x151e9c,_0x104c5f,_0x1902fd){this['app']=_0x2ee363,this['heartbeatServiceProvider']=_0x151e9c,this['appCheckServiceProvider']=_0x104c5f,this['config']=_0x1902fd,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x2ee363['name'],this['clientVersion']=_0x1902fd['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x1296ce=>this['_resolvePersistenceManagerAvailable']=_0x1296ce);}['_initializeWithPersistence'](_0x48b267,_0x185731){return _0x185731&&(this['_popupRedirectResolver']=ie(_0x185731)),this['_initializationPromise']=this['queue'](async()=>{var _0x244722,_0x252436,_0x310227;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x48b267),(_0x244722=this['_resolvePersistenceManagerAvailable'])==null||_0x244722['call'](this),!this['_deleted'])){if((_0x252436=this['_popupRedirectResolver'])!=null&&_0x252436['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x185731),this['lastNotifiedUid']=((_0x310227=this['currentUser'])==null?void 0x0:_0x310227['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x536b79=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x536b79)){if(this['currentUser']&&_0x536b79&&this['currentUser']['uid']===_0x536b79['uid']){this['_currentUser']['_assign'](_0x536b79),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x536b79,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x457222){try{const _0x27c0b3=await Pn(this,{'idToken':_0x457222}),_0x370181=await j['_fromGetAccountInfoResponse'](this,_0x27c0b3,_0x457222);await this['directlySetCurrentUser'](_0x370181);}catch(_0x40a512){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x40a512),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x39e57c){var _0x4ed25c;if($(this['app'])){const _0x33edf6=this['app']['settings']['authIdToken'];return _0x33edf6?new Promise(_0x2dace5=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x33edf6)['then'](_0x2dace5,_0x2dace5));}):this['directlySetCurrentUser'](null);}const _0x1745d2=await this['assertedPersistence']['getCurrentUser']();let _0x4dbd05=_0x1745d2,_0x1e2ed8=!0x1;if(_0x39e57c&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x366c1d=(_0x4ed25c=this['redirectUser'])==null?void 0x0:_0x4ed25c['_redirectEventId'],_0x4e7ea0=_0x4dbd05==null?void 0x0:_0x4dbd05['_redirectEventId'],_0x532e2b=await this['tryRedirectSignIn'](_0x39e57c);(!_0x366c1d||_0x366c1d===_0x4e7ea0)&&(_0x532e2b!=null&&_0x532e2b['user'])&&(_0x4dbd05=_0x532e2b['user'],_0x1e2ed8=!0x0);}if(!_0x4dbd05)return this['directlySetCurrentUser'](null);if(!_0x4dbd05['_redirectEventId']){if(_0x1e2ed8)try{await this['beforeStateQueue']['runMiddleware'](_0x4dbd05);}catch(_0x591251){_0x4dbd05=_0x1745d2,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x591251));}return _0x4dbd05?this['reloadAndSetCurrentUserOrClear'](_0x4dbd05):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x4dbd05['_redirectEventId']?this['directlySetCurrentUser'](_0x4dbd05):this['reloadAndSetCurrentUserOrClear'](_0x4dbd05);}async['tryRedirectSignIn'](_0xdd230b){let _0x231103=null;try{_0x231103=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0xdd230b,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x231103;}async['reloadAndSetCurrentUserOrClear'](_0x1242a4){try{await Nn(_0x1242a4);}catch(_0xbcd1be){if((_0xbcd1be==null?void 0x0:_0xbcd1be['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x1242a4);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x2ff4a4){if($(this['app']))return Promise['reject'](re(this));const _0x15a5f9=_0x2ff4a4?P(_0x2ff4a4):null;return _0x15a5f9&&m(_0x15a5f9['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x15a5f9&&_0x15a5f9['_clone'](this));}async['_updateCurrentUser'](_0x59299,_0x1ff5f4=!0x1){if(!this['_deleted'])return _0x59299&&m(this['tenantId']===_0x59299['tenantId'],this,'tenant-id-mismatch'),_0x1ff5f4||await this['beforeStateQueue']['runMiddleware'](_0x59299),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x59299),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x4b5f2f){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x4b5f2f));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0xf0595b){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x596892=this['_getPasswordPolicyInternal']();return _0x596892['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x596892['validatePassword'](_0xf0595b);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x760f29=await Pf(this),_0x1e5c4a=new Of(_0x760f29);this['tenantId']===null?this['_projectPasswordPolicy']=_0x1e5c4a:this['_tenantPasswordPolicies'][this['tenantId']]=_0x1e5c4a;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x5cdae5){this['_errorFactory']=new Gt('auth','Firebase',_0x5cdae5());}['onAuthStateChanged'](_0x423951,_0xbc53c3,_0x52fb6b){return this['registerStateListener'](this['authStateSubscription'],_0x423951,_0xbc53c3,_0x52fb6b);}['beforeAuthStateChanged'](_0x5973a6,_0x447f9d){return this['beforeStateQueue']['pushCallback'](_0x5973a6,_0x447f9d);}['onIdTokenChanged'](_0x455e00,_0x22227a,_0x974052){return this['registerStateListener'](this['idTokenSubscription'],_0x455e00,_0x22227a,_0x974052);}['authStateReady'](){return new Promise((_0x66c059,_0xcc48b6)=>{if(this['currentUser'])_0x66c059();else{const _0x5e7c01=this['onAuthStateChanged'](()=>{_0x5e7c01(),_0x66c059();},_0xcc48b6);}});}async['revokeAccessToken'](_0x1717de){if(this['currentUser']){const _0x5d6d2a=await this['currentUser']['getIdToken'](),_0x416a0f={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x1717de,'idToken':_0x5d6d2a};this['tenantId']!=null&&(_0x416a0f['tenantId']=this['tenantId']),await bf(this,_0x416a0f);}}['toJSON'](){var _0x20552a;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x20552a=this['_currentUser'])==null?void 0x0:_0x20552a['toJSON']()};}async['_setRedirectUser'](_0x25b706,_0x2ae18f){const _0x13175d=await this['getOrInitRedirectPersistenceManager'](_0x2ae18f);return _0x25b706===null?_0x13175d['removeCurrentUser']():_0x13175d['setCurrentUser'](_0x25b706);}async['getOrInitRedirectPersistenceManager'](_0x53026b){if(!this['redirectPersistenceManager']){const _0xb9a075=_0x53026b&&ie(_0x53026b)||this['_popupRedirectResolver'];m(_0xb9a075,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0xb9a075['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x477f3c){var _0x15a434,_0x361f7f;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x15a434=this['_currentUser'])==null?void 0x0:_0x15a434['_redirectEventId'])===_0x477f3c?this['_currentUser']:((_0x361f7f=this['redirectUser'])==null?void 0x0:_0x361f7f['_redirectEventId'])===_0x477f3c?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x3127cd){if(_0x3127cd===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x3127cd));}['_notifyListenersIfCurrent'](_0x2fe039){_0x2fe039===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x454d91;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x54cb16=((_0x454d91=this['currentUser'])==null?void 0x0:_0x454d91['uid'])??null;this['lastNotifiedUid']!==_0x54cb16&&(this['lastNotifiedUid']=_0x54cb16,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0xbe5fd0,_0xc265a5,_0x36d2af,_0x435d0b){if(this['_deleted'])return()=>{};const _0x245594=typeof _0xc265a5=='function'?_0xc265a5:_0xc265a5['next']['bind'](_0xc265a5);let _0x3720d0=!0x1;const _0x1b10c9=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x1b10c9,this,'internal-error'),_0x1b10c9['then'](()=>{_0x3720d0||_0x245594(this['currentUser']);}),typeof _0xc265a5=='function'){const _0x3d0f57=_0xbe5fd0['addObserver'](_0xc265a5,_0x36d2af,_0x435d0b);return()=>{_0x3720d0=!0x0,_0x3d0f57();};}else{const _0x40886f=_0xbe5fd0['addObserver'](_0xc265a5);return()=>{_0x3720d0=!0x0,_0x40886f();};}}async['directlySetCurrentUser'](_0x5a86ff){this['currentUser']&&this['currentUser']!==_0x5a86ff&&this['_currentUser']['_stopProactiveRefresh'](),_0x5a86ff&&this['isProactiveRefreshEnabled']&&_0x5a86ff['_startProactiveRefresh'](),this['currentUser']=_0x5a86ff,_0x5a86ff?await this['assertedPersistence']['setCurrentUser'](_0x5a86ff):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x2d7aff){return this['operations']=this['operations']['then'](_0x2d7aff,_0x2d7aff),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x773233){!_0x773233||this['frameworks']['includes'](_0x773233)||(this['frameworks']['push'](_0x773233),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x1309cb;const _0x1c639d={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x1c639d['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x52de56=await((_0x1309cb=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x1309cb['getHeartbeatsHeader']());_0x52de56&&(_0x1c639d['X-Firebase-Client']=_0x52de56);const _0x51a350=await this['_getAppCheckToken']();return _0x51a350&&(_0x1c639d['X-Firebase-AppCheck']=_0x51a350),_0x1c639d;}async['_getAppCheckToken'](){var _0x1a5025;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x443a28=await((_0x1a5025=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x1a5025['getToken']());return _0x443a28!=null&&_0x443a28['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x443a28['error']),_0x443a28==null?void 0x0:_0x443a28['token'];}}function Ke(_0x464487){return P(_0x464487);}class Rr{constructor(_0x2609d2){this['auth']=_0x2609d2,this['observer']=null,this['addObserver']=Tc(_0x385e0c=>this['observer']=_0x385e0c);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x137e9c){Jn=_0x137e9c;}function xa(_0x54e56f){return Jn['loadJS'](_0x54e56f);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x550a3d){return'__'+_0x550a3d+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0xde3809){_0xde3809();}['execute'](_0x3b24ed,_0xe06848){return Promise['resolve']('token');}['render'](_0x164ea0,_0x403243){return'';}}class Wf{['ready'](_0x1c88cb){_0x1c88cb();}['execute'](_0xbc8e97,_0x45e0c6){return Promise['resolve']('token');}['render'](_0x431302,_0x589fe9){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x580944){this['type']=Bf,this['auth']=Ke(_0x580944);}async['verify'](_0x48cf42='verify',_0x389408=!0x1){async function _0x1b3230(_0x31cceb){if(!_0x389408){if(_0x31cceb['tenantId']==null&&_0x31cceb['_agentRecaptchaConfig']!=null)return _0x31cceb['_agentRecaptchaConfig']['siteKey'];if(_0x31cceb['tenantId']!=null&&_0x31cceb['_tenantRecaptchaConfigs'][_0x31cceb['tenantId']]!==void 0x0)return _0x31cceb['_tenantRecaptchaConfigs'][_0x31cceb['tenantId']]['siteKey'];}return new Promise(async(_0x55880e,_0x5dded2)=>{yf(_0x31cceb,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x190293=>{if(_0x190293['recaptchaKey']===void 0x0)_0x5dded2(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x3bd8a9=new mf(_0x190293);return _0x31cceb['tenantId']==null?_0x31cceb['_agentRecaptchaConfig']=_0x3bd8a9:_0x31cceb['_tenantRecaptchaConfigs'][_0x31cceb['tenantId']]=_0x3bd8a9,_0x55880e(_0x3bd8a9['siteKey']);}})['catch'](_0x1d407c=>{_0x5dded2(_0x1d407c);});});}function _0x4e1bdc(_0x3f83d0,_0x1867ff,_0x4782fd){const _0x1ce496=window['grecaptcha'];wr(_0x1ce496)?_0x1ce496['enterprise']['ready'](()=>{_0x1ce496['enterprise']['execute'](_0x3f83d0,{'action':_0x48cf42})['then'](_0x177036=>{_0x1867ff(_0x177036);})['catch'](()=>{_0x1867ff(Fa);});}):_0x4782fd(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0xce30df,_0x2eca6c)=>{_0x1b3230(this['auth'])['then'](async _0xfb64aa=>{if(!_0x389408&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x4e1bdc(_0xfb64aa,_0xce30df,_0x2eca6c);else{if(typeof window>'u'){_0x2eca6c(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x47de84=Lf();_0x47de84['length']!==0x0&&(_0x47de84+=_0xfb64aa+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x5368b4;(_0x5368b4=he['scriptInjectionDeferred'])==null||_0x5368b4['resolve']();},xa(_0x47de84)['then'](()=>{var _0x5a9ac4;return(_0x5a9ac4=he['scriptInjectionDeferred'])==null?void 0x0:_0x5a9ac4['promise'];})['then'](()=>{_0x4e1bdc(_0xfb64aa,_0xce30df,_0x2eca6c);})['catch'](_0x4ed7da=>{_0x2eca6c(_0x4ed7da);});}})['catch'](_0x5f78d6=>{_0x2eca6c(_0x5f78d6);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x31ddcd,_0x4eabd8,_0x1c1274,_0x5eefcf=!0x1,_0x229c08=!0x1){const _0x3195ae=new he(_0x31ddcd);let _0x8ae1aa;if(_0x229c08)_0x8ae1aa=Fa;else try{_0x8ae1aa=await _0x3195ae['verify'](_0x1c1274);}catch{_0x8ae1aa=await _0x3195ae['verify'](_0x1c1274,!0x0);}const _0x512d3f={..._0x4eabd8};if(_0x1c1274==='mfaSmsEnrollment'||_0x1c1274==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x512d3f){const _0x3d4872=_0x512d3f['phoneEnrollmentInfo']['phoneNumber'],_0x544d02=_0x512d3f['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x512d3f,{'phoneEnrollmentInfo':{'phoneNumber':_0x3d4872,'recaptchaToken':_0x544d02,'captchaResponse':_0x8ae1aa,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x512d3f){const _0x2467cb=_0x512d3f['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x512d3f,{'phoneSignInInfo':{'recaptchaToken':_0x2467cb,'captchaResponse':_0x8ae1aa,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x512d3f;}return _0x5eefcf?Object['assign'](_0x512d3f,{'captchaResp':_0x8ae1aa}):Object['assign'](_0x512d3f,{'captchaResponse':_0x8ae1aa}),Object['assign'](_0x512d3f,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x512d3f,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x512d3f;}async function xi(_0x17e455,_0x2a5ac6,_0x100238,_0x300a0c,_0x504363){var _0x48c195;if((_0x48c195=_0x17e455['_getRecaptchaConfig']())!=null&&_0x48c195['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x5f53af=await kr(_0x17e455,_0x2a5ac6,_0x100238,_0x100238==='getOobCode');return _0x300a0c(_0x17e455,_0x5f53af);}else return _0x300a0c(_0x17e455,_0x2a5ac6)['catch'](async _0x57acec=>{if(_0x57acec['code']==='auth/missing-recaptcha-token'){console['log'](_0x100238+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x22d218=await kr(_0x17e455,_0x2a5ac6,_0x100238,_0x100238==='getOobCode');return _0x300a0c(_0x17e455,_0x22d218);}else return Promise['reject'](_0x57acec);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x2658ed,_0x44d0b9){const _0x111f6e=Hi(_0x2658ed,'auth');if(_0x111f6e['isInitialized']()){const _0x3772a1=_0x111f6e['getImmediate'](),_0x1ebfde=_0x111f6e['getOptions']();if(xe(_0x1ebfde,_0x44d0b9??{}))return _0x3772a1;Y(_0x3772a1,'already-initialized');}return _0x111f6e['initialize']({'options':_0x44d0b9});}function Hf(_0x389580,_0x1dc204){const _0x20633c=(_0x1dc204==null?void 0x0:_0x1dc204['persistence'])||[],_0x4a1a32=(Array['isArray'](_0x20633c)?_0x20633c:[_0x20633c])['map'](ie);_0x1dc204!=null&&_0x1dc204['errorMap']&&_0x389580['_updateErrorMap'](_0x1dc204['errorMap']),_0x389580['_initializeWithPersistence'](_0x4a1a32,_0x1dc204==null?void 0x0:_0x1dc204['popupRedirectResolver']);}function $f(_0x18ddf6,_0x2a3b5d,_0x246444){const _0x37c515=Ke(_0x18ddf6);m(/^https?:\/\//['test'](_0x2a3b5d),_0x37c515,'invalid-emulator-scheme');const _0x399086=!0x1,_0x1c21c0=Ua(_0x2a3b5d),{host:_0x3220cd,port:_0x3da598}=Gf(_0x2a3b5d),_0x2a6af0=_0x3da598===null?'':':'+_0x3da598,_0x572480={'url':_0x1c21c0+'//'+_0x3220cd+_0x2a6af0+'/'},_0x54c54=Object['freeze']({'host':_0x3220cd,'port':_0x3da598,'protocol':_0x1c21c0['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x399086})});if(!_0x37c515['_canInitEmulator']){m(_0x37c515['config']['emulator']&&_0x37c515['emulatorConfig'],_0x37c515,'emulator-config-failed'),m(xe(_0x572480,_0x37c515['config']['emulator'])&&xe(_0x54c54,_0x37c515['emulatorConfig']),_0x37c515,'emulator-config-failed');return;}_0x37c515['config']['emulator']=_0x572480,_0x37c515['emulatorConfig']=_0x54c54,_0x37c515['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x3220cd)?Qr(_0x1c21c0+'//'+_0x3220cd+_0x2a6af0):qf();}function Ua(_0x5205ee){const _0x172972=_0x5205ee['indexOf'](':');return _0x172972<0x0?'':_0x5205ee['substr'](0x0,_0x172972+0x1);}function Gf(_0x3482bf){const _0x37a54f=Ua(_0x3482bf),_0x875e6e=/(\/\/)?([^?#/]+)/['exec'](_0x3482bf['substr'](_0x37a54f['length']));if(!_0x875e6e)return{'host':'','port':null};const _0xfea473=_0x875e6e[0x2]['split']('@')['pop']()||'',_0x581bac=/^(\[[^\]]+\])(:|$)/['exec'](_0xfea473);if(_0x581bac){const _0x25cbfd=_0x581bac[0x1];return{'host':_0x25cbfd,'port':Pr(_0xfea473['substr'](_0x25cbfd['length']+0x1))};}else{const [_0x22a158,_0x405d28]=_0xfea473['split'](':');return{'host':_0x22a158,'port':Pr(_0x405d28)};}}function Pr(_0x15759a){if(!_0x15759a)return null;const _0x5eb302=Number(_0x15759a);return isNaN(_0x5eb302)?null:_0x5eb302;}function qf(){function _0x82b67b(){const _0x3597b2=document['createElement']('p'),_0x5ecfa1=_0x3597b2['style'];_0x3597b2['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x5ecfa1['position']='fixed',_0x5ecfa1['width']='100%',_0x5ecfa1['backgroundColor']='#ffffff',_0x5ecfa1['border']='.1em\x20solid\x20#000000',_0x5ecfa1['color']='#b50000',_0x5ecfa1['bottom']='0px',_0x5ecfa1['left']='0px',_0x5ecfa1['margin']='0px',_0x5ecfa1['zIndex']='10000',_0x5ecfa1['textAlign']='center',_0x3597b2['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x3597b2);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x82b67b):_0x82b67b());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x3b6071,_0x36bd84){this['providerId']=_0x3b6071,this['signInMethod']=_0x36bd84;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x2b5dc1){return ne('not\x20implemented');}['_linkToIdToken'](_0x30fadb,_0x431ab1){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x26c409){return ne('not\x20implemented');}}async function zf(_0x3aaa4e,_0x304fb6){return Pe(_0x3aaa4e,'POST','/v1/accounts:signUp',_0x304fb6);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0xedba99,_0x364e0b){return en(_0xedba99,'POST','/v1/accounts:signInWithPassword',ke(_0xedba99,_0x364e0b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x527705,_0x3f4356){return en(_0x527705,'POST','/v1/accounts:signInWithEmailLink',ke(_0x527705,_0x3f4356));}async function Yf(_0x3fc6f8,_0x5aea89){return en(_0x3fc6f8,'POST','/v1/accounts:signInWithEmailLink',ke(_0x3fc6f8,_0x5aea89));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x50f860,_0x2b4adc,_0x812b12,_0xa50239=null){super('password',_0x812b12),this['_email']=_0x50f860,this['_password']=_0x2b4adc,this['_tenantId']=_0xa50239;}static['_fromEmailAndPassword'](_0x47d648,_0xa11c6b){return new $t(_0x47d648,_0xa11c6b,'password');}static['_fromEmailAndCode'](_0x2ece40,_0x3f110d,_0x594ca2=null){return new $t(_0x2ece40,_0x3f110d,'emailLink',_0x594ca2);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x496977){const _0x571333=typeof _0x496977=='string'?JSON['parse'](_0x496977):_0x496977;if(_0x571333!=null&&_0x571333['email']&&(_0x571333!=null&&_0x571333['password'])){if(_0x571333['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x571333['email'],_0x571333['password']);if(_0x571333['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x571333['email'],_0x571333['password'],_0x571333['tenantId']);}return null;}async['_getIdTokenResponse'](_0x159aac){switch(this['signInMethod']){case'password':const _0x2dedb2={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x159aac,_0x2dedb2,'signInWithPassword',jf);case'emailLink':return Kf(_0x159aac,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x159aac,'internal-error');}}async['_linkToIdToken'](_0x369dc4,_0x5f1550){switch(this['signInMethod']){case'password':const _0x340314={'idToken':_0x5f1550,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x369dc4,_0x340314,'signUpPassword',zf);case'emailLink':return Yf(_0x369dc4,{'idToken':_0x5f1550,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x369dc4,'internal-error');}}['_getReauthenticationResolver'](_0x2f5f23){return this['_getIdTokenResponse'](_0x2f5f23);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x1b17cf,_0x1d9b8a){return en(_0x1b17cf,'POST','/v1/accounts:signInWithIdp',ke(_0x1b17cf,_0x1d9b8a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x409106){const _0x46f60d=new $e(_0x409106['providerId'],_0x409106['signInMethod']);return _0x409106['idToken']||_0x409106['accessToken']?(_0x409106['idToken']&&(_0x46f60d['idToken']=_0x409106['idToken']),_0x409106['accessToken']&&(_0x46f60d['accessToken']=_0x409106['accessToken']),_0x409106['nonce']&&!_0x409106['pendingToken']&&(_0x46f60d['nonce']=_0x409106['nonce']),_0x409106['pendingToken']&&(_0x46f60d['pendingToken']=_0x409106['pendingToken'])):_0x409106['oauthToken']&&_0x409106['oauthTokenSecret']?(_0x46f60d['accessToken']=_0x409106['oauthToken'],_0x46f60d['secret']=_0x409106['oauthTokenSecret']):Y('argument-error'),_0x46f60d;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x243e67){const _0x2f59c1=typeof _0x243e67=='string'?JSON['parse'](_0x243e67):_0x243e67,{providerId:_0x37964f,signInMethod:_0x21e94f,..._0x2462e7}=_0x2f59c1;if(!_0x37964f||!_0x21e94f)return null;const _0x517300=new $e(_0x37964f,_0x21e94f);return _0x517300['idToken']=_0x2462e7['idToken']||void 0x0,_0x517300['accessToken']=_0x2462e7['accessToken']||void 0x0,_0x517300['secret']=_0x2462e7['secret'],_0x517300['nonce']=_0x2462e7['nonce'],_0x517300['pendingToken']=_0x2462e7['pendingToken']||null,_0x517300;}['_getIdTokenResponse'](_0x263927){const _0x46c5fb=this['buildRequest']();return nt(_0x263927,_0x46c5fb);}['_linkToIdToken'](_0x472ec0,_0x34ef23){const _0x58465f=this['buildRequest']();return _0x58465f['idToken']=_0x34ef23,nt(_0x472ec0,_0x58465f);}['_getReauthenticationResolver'](_0x54a20a){const _0x371958=this['buildRequest']();return _0x371958['autoCreate']=!0x1,nt(_0x54a20a,_0x371958);}['buildRequest'](){const _0x287039={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x287039['pendingToken']=this['pendingToken'];else{const _0x460e84={};this['idToken']&&(_0x460e84['id_token']=this['idToken']),this['accessToken']&&(_0x460e84['access_token']=this['accessToken']),this['secret']&&(_0x460e84['oauth_token_secret']=this['secret']),_0x460e84['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x460e84['nonce']=this['nonce']),_0x287039['postBody']=ut(_0x460e84);}return _0x287039;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x18bb0e){switch(_0x18bb0e){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x6e5d9c){const _0x2ba13f=Ct(Tt(_0x6e5d9c))['link'],_0x4c43f6=_0x2ba13f?Ct(Tt(_0x2ba13f))['deep_link_id']:null,_0x1478a7=Ct(Tt(_0x6e5d9c))['deep_link_id'];return(_0x1478a7?Ct(Tt(_0x1478a7))['link']:null)||_0x1478a7||_0x4c43f6||_0x2ba13f||_0x6e5d9c;}class Rs{constructor(_0x2ee9ad){const _0x23981b=Ct(Tt(_0x2ee9ad)),_0x4716ee=_0x23981b['apiKey']??null,_0x2b5b8c=_0x23981b['oobCode']??null,_0xea6e14=Jf(_0x23981b['mode']??null);m(_0x4716ee&&_0x2b5b8c&&_0xea6e14,'argument-error'),this['apiKey']=_0x4716ee,this['operation']=_0xea6e14,this['code']=_0x2b5b8c,this['continueUrl']=_0x23981b['continueUrl']??null,this['languageCode']=_0x23981b['lang']??null,this['tenantId']=_0x23981b['tenantId']??null;}static['parseLink'](_0x49774f){const _0x91996b=Xf(_0x49774f);try{return new Rs(_0x91996b);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x4ecdcb,_0x1c6d16){return $t['_fromEmailAndPassword'](_0x4ecdcb,_0x1c6d16);}static['credentialWithLink'](_0x416cda,_0xc9b4c1){const _0x3596df=Rs['parseLink'](_0xc9b4c1);return m(_0x3596df,'argument-error'),$t['_fromEmailAndCode'](_0x416cda,_0x3596df['code'],_0x3596df['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x49ebb3){this['providerId']=_0x49ebb3,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x40127b){this['defaultLanguageCode']=_0x40127b;}['setCustomParameters'](_0x1fc4df){return this['customParameters']=_0x1fc4df,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x2c1c27){return this['scopes']['includes'](_0x2c1c27)||this['scopes']['push'](_0x2c1c27),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x146ab5){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x146ab5});}static['credentialFromResult'](_0x873bc5){return ue['credentialFromTaggedObject'](_0x873bc5);}static['credentialFromError'](_0xf06854){return ue['credentialFromTaggedObject'](_0xf06854['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x26aeac}){if(!_0x26aeac||!('oauthAccessToken'in _0x26aeac)||!_0x26aeac['oauthAccessToken'])return null;try{return ue['credential'](_0x26aeac['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x5147b4,_0x4d294b){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x5147b4,'accessToken':_0x4d294b});}static['credentialFromResult'](_0x3948a3){return de['credentialFromTaggedObject'](_0x3948a3);}static['credentialFromError'](_0x2d6785){return de['credentialFromTaggedObject'](_0x2d6785['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x250387}){if(!_0x250387)return null;const {oauthIdToken:_0x5db2ff,oauthAccessToken:_0x234422}=_0x250387;if(!_0x5db2ff&&!_0x234422)return null;try{return de['credential'](_0x5db2ff,_0x234422);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x2767bf){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x2767bf});}static['credentialFromResult'](_0x5059ed){return fe['credentialFromTaggedObject'](_0x5059ed);}static['credentialFromError'](_0x452320){return fe['credentialFromTaggedObject'](_0x452320['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4b07c7}){if(!_0x4b07c7||!('oauthAccessToken'in _0x4b07c7)||!_0x4b07c7['oauthAccessToken'])return null;try{return fe['credential'](_0x4b07c7['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x3a97b6,_0x2d6677){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x3a97b6,'oauthTokenSecret':_0x2d6677});}static['credentialFromResult'](_0x34732a){return pe['credentialFromTaggedObject'](_0x34732a);}static['credentialFromError'](_0x37a4b1){return pe['credentialFromTaggedObject'](_0x37a4b1['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x6ecfb3}){if(!_0x6ecfb3)return null;const {oauthAccessToken:_0x377d62,oauthTokenSecret:_0x261765}=_0x6ecfb3;if(!_0x377d62||!_0x261765)return null;try{return pe['credential'](_0x377d62,_0x261765);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x23cc69,_0x9ebcd2){return en(_0x23cc69,'POST','/v1/accounts:signUp',ke(_0x23cc69,_0x9ebcd2));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x47b63f){this['user']=_0x47b63f['user'],this['providerId']=_0x47b63f['providerId'],this['_tokenResponse']=_0x47b63f['_tokenResponse'],this['operationType']=_0x47b63f['operationType'];}static async['_fromIdTokenResponse'](_0x55ee16,_0x1be1d2,_0x3314b0,_0x5ca78a=!0x1){const _0x16378e=await j['_fromIdTokenResponse'](_0x55ee16,_0x3314b0,_0x5ca78a),_0x34c76d=Nr(_0x3314b0);return new Ge({'user':_0x16378e,'providerId':_0x34c76d,'_tokenResponse':_0x3314b0,'operationType':_0x1be1d2});}static async['_forOperation'](_0x587870,_0x59ea06,_0x2a7ab7){await _0x587870['_updateTokensIfNecessary'](_0x2a7ab7,!0x0);const _0x4a40da=Nr(_0x2a7ab7);return new Ge({'user':_0x587870,'providerId':_0x4a40da,'_tokenResponse':_0x2a7ab7,'operationType':_0x59ea06});}}function Nr(_0x590c22){return _0x590c22['providerId']?_0x590c22['providerId']:'phoneNumber'in _0x590c22?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x3826ba,_0x34486d,_0x39af72,_0x251491){super(_0x34486d['code'],_0x34486d['message']),this['operationType']=_0x39af72,this['user']=_0x251491,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x3826ba['name'],'tenantId':_0x3826ba['tenantId']??void 0x0,'_serverResponse':_0x34486d['customData']['_serverResponse'],'operationType':_0x39af72};}static['_fromErrorAndOperation'](_0x4212fd,_0x1502e3,_0x524bb4,_0x27b6e9){return new On(_0x4212fd,_0x1502e3,_0x524bb4,_0x27b6e9);}}function Ba(_0x714ea3,_0x3f5503,_0x4c6bee,_0x5691fc){return(_0x3f5503==='reauthenticate'?_0x4c6bee['_getReauthenticationResolver'](_0x714ea3):_0x4c6bee['_getIdTokenResponse'](_0x714ea3))['catch'](_0x34cd3f=>{throw _0x34cd3f['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x714ea3,_0x34cd3f,_0x3f5503,_0x5691fc):_0x34cd3f;});}async function ep(_0x32e030,_0x5bec1d,_0x34d8da=!0x1){const _0x446617=await Ht(_0x32e030,_0x5bec1d['_linkToIdToken'](_0x32e030['auth'],await _0x32e030['getIdToken']()),_0x34d8da);return Ge['_forOperation'](_0x32e030,'link',_0x446617);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x1052f6,_0x5e83c1,_0x4702f4=!0x1){const {auth:_0x1ad503}=_0x1052f6;if($(_0x1ad503['app']))return Promise['reject'](re(_0x1ad503));const _0x3c5ec5='reauthenticate';try{const _0x2e08c1=await Ht(_0x1052f6,Ba(_0x1ad503,_0x3c5ec5,_0x5e83c1,_0x1052f6),_0x4702f4);m(_0x2e08c1['idToken'],_0x1ad503,'internal-error');const _0x3e7c7d=Ts(_0x2e08c1['idToken']);m(_0x3e7c7d,_0x1ad503,'internal-error');const {sub:_0x2a2a0d}=_0x3e7c7d;return m(_0x1052f6['uid']===_0x2a2a0d,_0x1ad503,'user-mismatch'),Ge['_forOperation'](_0x1052f6,_0x3c5ec5,_0x2e08c1);}catch(_0x33aeac){throw(_0x33aeac==null?void 0x0:_0x33aeac['code'])==='auth/user-not-found'&&Y(_0x1ad503,'user-mismatch'),_0x33aeac;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x24faf6,_0x48d945,_0x1f8c77=!0x1){if($(_0x24faf6['app']))return Promise['reject'](re(_0x24faf6));const _0x50d07b='signIn',_0x5d6924=await Ba(_0x24faf6,_0x50d07b,_0x48d945),_0x20c67f=await Ge['_fromIdTokenResponse'](_0x24faf6,_0x50d07b,_0x5d6924);return _0x1f8c77||await _0x24faf6['_updateCurrentUser'](_0x20c67f['user']),_0x20c67f;}async function np(_0x2c53c8,_0x34c3f8){return Va(Ke(_0x2c53c8),_0x34c3f8);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x5a61ce){const _0x167acc=Ke(_0x5a61ce);_0x167acc['_getPasswordPolicyInternal']()&&await _0x167acc['_updatePasswordPolicy']();}async function L_(_0x10091c,_0x1ee143,_0x5d1f91){if($(_0x10091c['app']))return Promise['reject'](re(_0x10091c));const _0x225187=Ke(_0x10091c),_0x3f59c9=await xi(_0x225187,{'returnSecureToken':!0x0,'email':_0x1ee143,'password':_0x5d1f91,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x8053c7=>{throw _0x8053c7['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x10091c),_0x8053c7;}),_0x3c2ff9=await Ge['_fromIdTokenResponse'](_0x225187,'signIn',_0x3f59c9);return await _0x225187['_updateCurrentUser'](_0x3c2ff9['user']),_0x3c2ff9;}function x_(_0x48889f,_0x14cf59,_0x10fc82){return $(_0x48889f['app'])?Promise['reject'](re(_0x48889f)):np(P(_0x48889f),yt['credential'](_0x14cf59,_0x10fc82))['catch'](async _0x28167e=>{throw _0x28167e['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x48889f),_0x28167e;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x2e5478,_0x2b8016){return P(_0x2e5478)['setPersistence'](_0x2b8016);}function ip(_0x1ec8f6,_0x5021ff,_0xf02263,_0x3da31f){return P(_0x1ec8f6)['onIdTokenChanged'](_0x5021ff,_0xf02263,_0x3da31f);}function sp(_0x36bb94,_0x2e7cec,_0x334e9b){return P(_0x36bb94)['beforeAuthStateChanged'](_0x2e7cec,_0x334e9b);}function U_(_0x36c962,_0x42cfad,_0x471e01,_0x45bdbc){return P(_0x36c962)['onAuthStateChanged'](_0x42cfad,_0x471e01,_0x45bdbc);}function W_(_0x32b64b){return P(_0x32b64b)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x5258ba,_0x17b82f){this['storageRetriever']=_0x5258ba,this['type']=_0x17b82f;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x376159,_0x2359ac){return this['storage']['setItem'](_0x376159,JSON['stringify'](_0x2359ac)),Promise['resolve']();}['_get'](_0xd72e8f){const _0x1b19f0=this['storage']['getItem'](_0xd72e8f);return Promise['resolve'](_0x1b19f0?JSON['parse'](_0x1b19f0):null);}['_remove'](_0x2adb18){return this['storage']['removeItem'](_0x2adb18),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x2ddf5d,_0x2edb72)=>this['onStorageEvent'](_0x2ddf5d,_0x2edb72),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x170d3d){for(const _0x877911 of Object['keys'](this['listeners'])){const _0x148915=this['storage']['getItem'](_0x877911),_0x18b456=this['localCache'][_0x877911];_0x148915!==_0x18b456&&_0x170d3d(_0x877911,_0x18b456,_0x148915);}}['onStorageEvent'](_0x98e58c,_0x4c7f8d=!0x1){if(!_0x98e58c['key']){this['forAllChangedKeys']((_0x274c62,_0x3114f7,_0x52af6e)=>{this['notifyListeners'](_0x274c62,_0x52af6e);});return;}const _0x3d4a2d=_0x98e58c['key'];_0x4c7f8d?this['detachListener']():this['stopPolling']();const _0x97599f=()=>{const _0x4696e5=this['storage']['getItem'](_0x3d4a2d);!_0x4c7f8d&&this['localCache'][_0x3d4a2d]===_0x4696e5||this['notifyListeners'](_0x3d4a2d,_0x4696e5);},_0x40997d=this['storage']['getItem'](_0x3d4a2d);Af()&&_0x40997d!==_0x98e58c['newValue']&&_0x98e58c['newValue']!==_0x98e58c['oldValue']?setTimeout(_0x97599f,op):_0x97599f();}['notifyListeners'](_0x5a64cb,_0x3939c7){this['localCache'][_0x5a64cb]=_0x3939c7;const _0x422dbf=this['listeners'][_0x5a64cb];if(_0x422dbf){for(const _0x3ebaf2 of Array['from'](_0x422dbf))_0x3ebaf2(_0x3939c7&&JSON['parse'](_0x3939c7));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x16becf,_0x27ad2a,_0x5e18d9)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x16becf,'oldValue':_0x27ad2a,'newValue':_0x5e18d9}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x2fb49d,_0x5b7836){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x2fb49d]||(this['listeners'][_0x2fb49d]=new Set(),this['localCache'][_0x2fb49d]=this['storage']['getItem'](_0x2fb49d)),this['listeners'][_0x2fb49d]['add'](_0x5b7836);}['_removeListener'](_0x5099e2,_0x12aed6){this['listeners'][_0x5099e2]&&(this['listeners'][_0x5099e2]['delete'](_0x12aed6),this['listeners'][_0x5099e2]['size']===0x0&&delete this['listeners'][_0x5099e2]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x240682,_0x3adf30){await super['_set'](_0x240682,_0x3adf30),this['localCache'][_0x240682]=JSON['stringify'](_0x3adf30);}async['_get'](_0xb499df){const _0x3d4f7f=await super['_get'](_0xb499df);return this['localCache'][_0xb499df]=JSON['stringify'](_0x3d4f7f),_0x3d4f7f;}async['_remove'](_0x364670){await super['_remove'](_0x364670),delete this['localCache'][_0x364670];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x4a09e7,_0x5a026d){}['_removeListener'](_0x4b5228,_0x5f4d84){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x5f545c){return Promise['all'](_0x5f545c['map'](async _0x17d829=>{try{return{'fulfilled':!0x0,'value':await _0x17d829};}catch(_0x48a90b){return{'fulfilled':!0x1,'reason':_0x48a90b};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x4eb5cd){this['eventTarget']=_0x4eb5cd,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x1fae16){const _0x48eee5=this['receivers']['find'](_0x3f3bd5=>_0x3f3bd5['isListeningto'](_0x1fae16));if(_0x48eee5)return _0x48eee5;const _0x48ffa4=new Xn(_0x1fae16);return this['receivers']['push'](_0x48ffa4),_0x48ffa4;}['isListeningto'](_0x29b9e3){return this['eventTarget']===_0x29b9e3;}async['handleEvent'](_0x4377ca){const _0x5f1f8c=_0x4377ca,{eventId:_0x1ecdf1,eventType:_0x35b980,data:_0x58c09e}=_0x5f1f8c['data'],_0x2e733f=this['handlersMap'][_0x35b980];if(!(_0x2e733f!=null&&_0x2e733f['size']))return;_0x5f1f8c['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x1ecdf1,'eventType':_0x35b980});const _0x4e4b6b=Array['from'](_0x2e733f)['map'](async _0x424c96=>_0x424c96(_0x5f1f8c['origin'],_0x58c09e)),_0x17eb2a=await cp(_0x4e4b6b);_0x5f1f8c['ports'][0x0]['postMessage']({'status':'done','eventId':_0x1ecdf1,'eventType':_0x35b980,'response':_0x17eb2a});}['_subscribe'](_0x262ab5,_0x3b68e4){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x262ab5]||(this['handlersMap'][_0x262ab5]=new Set()),this['handlersMap'][_0x262ab5]['add'](_0x3b68e4);}['_unsubscribe'](_0x11be01,_0x3fba32){this['handlersMap'][_0x11be01]&&_0x3fba32&&this['handlersMap'][_0x11be01]['delete'](_0x3fba32),(!_0x3fba32||this['handlersMap'][_0x11be01]['size']===0x0)&&delete this['handlersMap'][_0x11be01],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x513a81='',_0x1ea4b8=0xa){let _0x159064='';for(let _0x2503dc=0x0;_0x2503dc<_0x1ea4b8;_0x2503dc++)_0x159064+=Math['floor'](Math['random']()*0xa);return _0x513a81+_0x159064;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x392458){this['target']=_0x392458,this['handlers']=new Set();}['removeMessageHandler'](_0x2f83bb){_0x2f83bb['messageChannel']&&(_0x2f83bb['messageChannel']['port1']['removeEventListener']('message',_0x2f83bb['onMessage']),_0x2f83bb['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x2f83bb);}async['_send'](_0x581e6d,_0x3f0de2,_0x1f488e=0x32){const _0x15765e=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x15765e)throw new Error('connection_unavailable');let _0x3afa08,_0x31e3aa;return new Promise((_0x93ae39,_0x56f83e)=>{const _0x4dced4=As('',0x14);_0x15765e['port1']['start']();const _0x574c29=setTimeout(()=>{_0x56f83e(new Error('unsupported_event'));},_0x1f488e);_0x31e3aa={'messageChannel':_0x15765e,'onMessage'(_0x214176){const _0x3b0159=_0x214176;if(_0x3b0159['data']['eventId']===_0x4dced4)switch(_0x3b0159['data']['status']){case'ack':clearTimeout(_0x574c29),_0x3afa08=setTimeout(()=>{_0x56f83e(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x3afa08),_0x93ae39(_0x3b0159['data']['response']);break;default:clearTimeout(_0x574c29),clearTimeout(_0x3afa08),_0x56f83e(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x31e3aa),_0x15765e['port1']['addEventListener']('message',_0x31e3aa['onMessage']),this['target']['postMessage']({'eventType':_0x581e6d,'eventId':_0x4dced4,'data':_0x3f0de2},[_0x15765e['port2']]);})['finally'](()=>{_0x31e3aa&&this['removeMessageHandler'](_0x31e3aa);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0xf168b5){Z()['location']['href']=_0xf168b5;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x5cde6a;return((_0x5cde6a=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x5cde6a['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x161e9a){this['request']=_0x161e9a;}['toPromise'](){return new Promise((_0x4bad41,_0xffe9c1)=>{this['request']['addEventListener']('success',()=>{_0x4bad41(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0xffe9c1(this['request']['error']);});});}}function Zn(_0x348f4d,_0x1a1bf5){return _0x348f4d['transaction']([Mn],_0x1a1bf5?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x4b5cfb=indexedDB['deleteDatabase'](Ka);return new nn(_0x4b5cfb)['toPromise']();}function Qa(){const _0x180534=indexedDB['open'](Ka,pp);return new Promise((_0x5c5653,_0x4bc4db)=>{_0x180534['addEventListener']('error',()=>{_0x4bc4db(_0x180534['error']);}),_0x180534['addEventListener']('upgradeneeded',()=>{const _0x5f2462=_0x180534['result'];try{_0x5f2462['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x3569f1){_0x4bc4db(_0x3569f1);}}),_0x180534['addEventListener']('success',async()=>{const _0x3e4c0d=_0x180534['result'];_0x3e4c0d['objectStoreNames']['contains'](Mn)?_0x5c5653(_0x3e4c0d):(_0x3e4c0d['close'](),await _p(),_0x5c5653(await Qa()));});});}async function Or(_0x5291c3,_0x46e469,_0x357311){const _0x3f4b87=Zn(_0x5291c3,!0x0)['put']({[Ya]:_0x46e469,'value':_0x357311});return new nn(_0x3f4b87)['toPromise']();}async function gp(_0x227f4f,_0x1a2216){const _0x1052e2=Zn(_0x227f4f,!0x1)['get'](_0x1a2216),_0x1aa538=await new nn(_0x1052e2)['toPromise']();return _0x1aa538===void 0x0?null:_0x1aa538['value'];}function Dr(_0x3f140a,_0x174b99){const _0x56f2a3=Zn(_0x3f140a,!0x0)['delete'](_0x174b99);return new nn(_0x56f2a3)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x376f2f){let _0x138749=0x0;for(;;)try{const _0x13f956=await this['_openDb']();return await _0x376f2f(_0x13f956);}catch(_0x4a335e){if(_0x138749++>yp)throw _0x4a335e;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x405946,_0x4bd92b)=>({'keyProcessed':(await this['_poll']())['includes'](_0x4bd92b['key'])})),this['receiver']['_subscribe']('ping',async(_0x5b3e32,_0x32c022)=>['keyChanged']);}async['initializeSender'](){var _0x3048c6,_0x1367ea;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x454348=await this['sender']['_send']('ping',{},0x320);_0x454348&&(_0x3048c6=_0x454348[0x0])!=null&&_0x3048c6['fulfilled']&&(_0x1367ea=_0x454348[0x0])!=null&&_0x1367ea['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x45dc0b){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x45dc0b},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x5f0f78=>{await Or(_0x5f0f78,Dn,'1'),await Dr(_0x5f0f78,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x16f392){this['pendingWrites']++;try{await _0x16f392();}finally{this['pendingWrites']--;}}async['_set'](_0x5c0a69,_0x1241fc){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x1fea0f=>Or(_0x1fea0f,_0x5c0a69,_0x1241fc)),this['localCache'][_0x5c0a69]=_0x1241fc,this['notifyServiceWorker'](_0x5c0a69)));}async['_get'](_0x1e3338){const _0x24c0eb=await this['_withRetries'](_0x30cfc6=>gp(_0x30cfc6,_0x1e3338));return this['localCache'][_0x1e3338]=_0x24c0eb,_0x24c0eb;}async['_remove'](_0x3269f0){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0xe2b4fb=>Dr(_0xe2b4fb,_0x3269f0)),delete this['localCache'][_0x3269f0],this['notifyServiceWorker'](_0x3269f0)));}async['_poll'](){const _0x172c86=await this['_withRetries'](_0x445917=>{const _0x17cd43=Zn(_0x445917,!0x1)['getAll']();return new nn(_0x17cd43)['toPromise']();});if(!_0x172c86)return[];if(this['pendingWrites']!==0x0)return[];const _0x488e8c=[],_0x5b4013=new Set();if(_0x172c86['length']!==0x0){for(const {fbase_key:_0x56d267,value:_0x3a5499}of _0x172c86)_0x5b4013['add'](_0x56d267),JSON['stringify'](this['localCache'][_0x56d267])!==JSON['stringify'](_0x3a5499)&&(this['notifyListeners'](_0x56d267,_0x3a5499),_0x488e8c['push'](_0x56d267));}for(const _0x343ac9 of Object['keys'](this['localCache']))this['localCache'][_0x343ac9]&&!_0x5b4013['has'](_0x343ac9)&&(this['notifyListeners'](_0x343ac9,null),_0x488e8c['push'](_0x343ac9));return _0x488e8c;}['notifyListeners'](_0x3b8a15,_0x4f2723){this['localCache'][_0x3b8a15]=_0x4f2723;const _0x515c20=this['listeners'][_0x3b8a15];if(_0x515c20){for(const _0x2aecf3 of Array['from'](_0x515c20))_0x2aecf3(_0x4f2723);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x44a0e9,_0x29a2f6){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x44a0e9]||(this['listeners'][_0x44a0e9]=new Set(),this['_get'](_0x44a0e9)),this['listeners'][_0x44a0e9]['add'](_0x29a2f6);}['_removeListener'](_0x468264,_0x2b73b8){this['listeners'][_0x468264]&&(this['listeners'][_0x468264]['delete'](_0x2b73b8),this['listeners'][_0x468264]['size']===0x0&&delete this['listeners'][_0x468264]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x3f5efa,_0x58416b){return _0x58416b?ie(_0x58416b):(m(_0x3f5efa['_popupRedirectResolver'],_0x3f5efa,'argument-error'),_0x3f5efa['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x4c309){super('custom','custom'),this['params']=_0x4c309;}['_getIdTokenResponse'](_0x50b3a5){return nt(_0x50b3a5,this['_buildIdpRequest']());}['_linkToIdToken'](_0x2a0d75,_0xb95be5){return nt(_0x2a0d75,this['_buildIdpRequest'](_0xb95be5));}['_getReauthenticationResolver'](_0x417c88){return nt(_0x417c88,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x336669){const _0x13f288={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x336669&&(_0x13f288['idToken']=_0x336669),_0x13f288;}}function Ip(_0x263894){return Va(_0x263894['auth'],new ks(_0x263894),_0x263894['bypassAuthState']);}function wp(_0x5bd6f2){const {auth:_0x315b9f,user:_0x335d80}=_0x5bd6f2;return m(_0x335d80,_0x315b9f,'internal-error'),tp(_0x335d80,new ks(_0x5bd6f2),_0x5bd6f2['bypassAuthState']);}async function Cp(_0x56573e){const {auth:_0x1beb37,user:_0x109ac2}=_0x56573e;return m(_0x109ac2,_0x1beb37,'internal-error'),ep(_0x109ac2,new ks(_0x56573e),_0x56573e['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x115c54,_0x4ce214,_0x605090,_0x4d2baf,_0x4ffa08=!0x1){this['auth']=_0x115c54,this['resolver']=_0x605090,this['user']=_0x4d2baf,this['bypassAuthState']=_0x4ffa08,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x4ce214)?_0x4ce214:[_0x4ce214];}['execute'](){return new Promise(async(_0x24e96e,_0x375cc0)=>{this['pendingPromise']={'resolve':_0x24e96e,'reject':_0x375cc0};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x1016e5){this['reject'](_0x1016e5);}});}async['onAuthEvent'](_0x1c59b8){const {urlResponse:_0x4336c7,sessionId:_0x1da96b,postBody:_0x5c81e3,tenantId:_0x15acb4,error:_0x5b10bc,type:_0x17b708}=_0x1c59b8;if(_0x5b10bc){this['reject'](_0x5b10bc);return;}const _0x4fd786={'auth':this['auth'],'requestUri':_0x4336c7,'sessionId':_0x1da96b,'tenantId':_0x15acb4||void 0x0,'postBody':_0x5c81e3||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x17b708)(_0x4fd786));}catch(_0x1ca82a){this['reject'](_0x1ca82a);}}['onError'](_0x43a6c0){this['reject'](_0x43a6c0);}['getIdpTask'](_0x30199c){switch(_0x30199c){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x2d823c){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x2d823c),this['unregisterAndCleanUp']();}['reject'](_0xc0b26f){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0xc0b26f),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x138758,_0x5e1e08,_0x385fd4,_0x30530b,_0x91d9e7){super(_0x138758,_0x5e1e08,_0x30530b,_0x91d9e7),this['provider']=_0x385fd4,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x10cfb=await this['execute']();return m(_0x10cfb,this['auth'],'internal-error'),_0x10cfb;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x22f19e=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x22f19e),this['authWindow']['associatedEvent']=_0x22f19e,this['resolver']['_originValidation'](this['auth'])['catch'](_0x4a5fc8=>{this['reject'](_0x4a5fc8);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x260f8c=>{_0x260f8c||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x49597e;return((_0x49597e=this['authWindow'])==null?void 0x0:_0x49597e['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x55e4d8=()=>{var _0x30d354,_0x4fd475;if((_0x4fd475=(_0x30d354=this['authWindow'])==null?void 0x0:_0x30d354['window'])!=null&&_0x4fd475['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x55e4d8,Tp['get']());};_0x55e4d8();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x17209a,_0x8d063a,_0x521d3a=!0x1){super(_0x17209a,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x8d063a,void 0x0,_0x521d3a),this['eventId']=null;}async['execute'](){let _0xcca0cc=hn['get'](this['auth']['_key']());if(!_0xcca0cc){try{const _0x22053b=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0xcca0cc=()=>Promise['resolve'](_0x22053b);}catch(_0x4a518c){_0xcca0cc=()=>Promise['reject'](_0x4a518c);}hn['set'](this['auth']['_key'](),_0xcca0cc);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0xcca0cc();}async['onAuthEvent'](_0x52a32d){if(_0x52a32d['type']==='signInViaRedirect')return super['onAuthEvent'](_0x52a32d);if(_0x52a32d['type']==='unknown'){this['resolve'](null);return;}if(_0x52a32d['eventId']){const _0x473b49=await this['auth']['_redirectUserForId'](_0x52a32d['eventId']);if(_0x473b49)return this['user']=_0x473b49,super['onAuthEvent'](_0x52a32d);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x3864e6,_0x45dba6){const _0x344f20=Pp(_0x45dba6),_0xb58f48=kp(_0x3864e6);if(!await _0xb58f48['_isAvailable']())return!0x1;const _0x26a14c=await _0xb58f48['_get'](_0x344f20)==='true';return await _0xb58f48['_remove'](_0x344f20),_0x26a14c;}function Ap(_0x229a2f,_0x588535){hn['set'](_0x229a2f['_key'](),_0x588535);}function kp(_0x4a0a9d){return ie(_0x4a0a9d['_redirectPersistence']);}function Pp(_0x2b0319){return ln(Sp,_0x2b0319['config']['apiKey'],_0x2b0319['name']);}async function Np(_0x553d14,_0x265945,_0x287e29=!0x1){if($(_0x553d14['app']))return Promise['reject'](re(_0x553d14));const _0x1809e6=Ke(_0x553d14),_0x5845e3=Ep(_0x1809e6,_0x265945),_0x2ac254=await new bp(_0x1809e6,_0x5845e3,_0x287e29)['execute']();return _0x2ac254&&!_0x287e29&&(delete _0x2ac254['user']['_redirectEventId'],await _0x1809e6['_persistUserIfCurrent'](_0x2ac254['user']),await _0x1809e6['_setRedirectUser'](null,_0x265945)),_0x2ac254;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x53d654){this['auth']=_0x53d654,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x35dee2){this['consumers']['add'](_0x35dee2),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x35dee2)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x35dee2),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x29c906){this['consumers']['delete'](_0x29c906);}['onEvent'](_0x2c9e51){if(this['hasEventBeenHandled'](_0x2c9e51))return!0x1;let _0x2af3ad=!0x1;return this['consumers']['forEach'](_0x2c8728=>{this['isEventForConsumer'](_0x2c9e51,_0x2c8728)&&(_0x2af3ad=!0x0,this['sendToConsumer'](_0x2c9e51,_0x2c8728),this['saveEventToCache'](_0x2c9e51));}),this['hasHandledPotentialRedirect']||!Mp(_0x2c9e51)||(this['hasHandledPotentialRedirect']=!0x0,_0x2af3ad||(this['queuedRedirectEvent']=_0x2c9e51,_0x2af3ad=!0x0)),_0x2af3ad;}['sendToConsumer'](_0x3937bf,_0x585660){var _0x493d92;if(_0x3937bf['error']&&!Za(_0x3937bf)){const _0x39d2b2=((_0x493d92=_0x3937bf['error']['code'])==null?void 0x0:_0x493d92['split']('auth/')[0x1])||'internal-error';_0x585660['onError'](X(this['auth'],_0x39d2b2));}else _0x585660['onAuthEvent'](_0x3937bf);}['isEventForConsumer'](_0x609057,_0x110c57){const _0x5b2670=_0x110c57['eventId']===null||!!_0x609057['eventId']&&_0x609057['eventId']===_0x110c57['eventId'];return _0x110c57['filter']['includes'](_0x609057['type'])&&_0x5b2670;}['hasEventBeenHandled'](_0x1fc43b){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x1fc43b));}['saveEventToCache'](_0x4fc6a8){this['cachedEventUids']['add'](Mr(_0x4fc6a8)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x159b6c){return[_0x159b6c['type'],_0x159b6c['eventId'],_0x159b6c['sessionId'],_0x159b6c['tenantId']]['filter'](_0xfc683=>_0xfc683)['join']('-');}function Za({type:_0x3833de,error:_0xa9a30f}){return _0x3833de==='unknown'&&(_0xa9a30f==null?void 0x0:_0xa9a30f['code'])==='auth/no-auth-event';}function Mp(_0x213a8b){switch(_0x213a8b['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x213a8b);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x2dd5e3,_0x3ec3cd={}){return Pe(_0x2dd5e3,'GET','/v1/projects',_0x3ec3cd);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x1ce616){if(_0x1ce616['config']['emulator'])return;const {authorizedDomains:_0x2f71f0}=await Lp(_0x1ce616);for(const _0x3a95bc of _0x2f71f0)try{if(Wp(_0x3a95bc))return;}catch{}Y(_0x1ce616,'unauthorized-domain');}function Wp(_0x67f492){const _0x2f3581=Mi(),{protocol:_0x3551e5,hostname:_0x3fcfe4}=new URL(_0x2f3581);if(_0x67f492['startsWith']('chrome-extension://')){const _0x442e43=new URL(_0x67f492);return _0x442e43['hostname']===''&&_0x3fcfe4===''?_0x3551e5==='chrome-extension:'&&_0x67f492['replace']('chrome-extension://','')===_0x2f3581['replace']('chrome-extension://',''):_0x3551e5==='chrome-extension:'&&_0x442e43['hostname']===_0x3fcfe4;}if(!Fp['test'](_0x3551e5))return!0x1;if(xp['test'](_0x67f492))return _0x3fcfe4===_0x67f492;const _0x544ea3=_0x67f492['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x544ea3+'|'+_0x544ea3+')$','i')['test'](_0x3fcfe4);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x899cc=Z()['___jsl'];if(_0x899cc!=null&&_0x899cc['H']){for(const _0x56c967 of Object['keys'](_0x899cc['H']))if(_0x899cc['H'][_0x56c967]['r']=_0x899cc['H'][_0x56c967]['r']||[],_0x899cc['H'][_0x56c967]['L']=_0x899cc['H'][_0x56c967]['L']||[],_0x899cc['H'][_0x56c967]['r']=[..._0x899cc['H'][_0x56c967]['L']],_0x899cc['CP']){for(let _0x234c33=0x0;_0x234c33<_0x899cc['CP']['length'];_0x234c33++)_0x899cc['CP'][_0x234c33]=null;}}}function Vp(_0xa0149d){return new Promise((_0x371a08,_0x4628e2)=>{var _0x5f46f9,_0x23d993,_0x44c806;function _0x106fe4(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x371a08(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x4628e2(X(_0xa0149d,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x23d993=(_0x5f46f9=Z()['gapi'])==null?void 0x0:_0x5f46f9['iframes'])!=null&&_0x23d993['Iframe'])_0x371a08(gapi['iframes']['getContext']());else{if((_0x44c806=Z()['gapi'])!=null&&_0x44c806['load'])_0x106fe4();else{const _0x3467ab=Ff('iframefcb');return Z()[_0x3467ab]=()=>{gapi['load']?_0x106fe4():_0x4628e2(X(_0xa0149d,'network-request-failed'));},xa(xf()+'?onload='+_0x3467ab)['catch'](_0x504639=>_0x4628e2(_0x504639));}}})['catch'](_0x377918=>{throw un=null,_0x377918;});}let un=null;function Hp(_0x3323c7){return un=un||Vp(_0x3323c7),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0xe5da5){const _0x5bb320=_0xe5da5['config'];m(_0x5bb320['authDomain'],_0xe5da5,'auth-domain-config-required');const _0x974825=_0x5bb320['emulator']?Cs(_0x5bb320,qp):'https://'+_0xe5da5['config']['authDomain']+'/'+Gp,_0xcbd5b1={'apiKey':_0x5bb320['apiKey'],'appName':_0xe5da5['name'],'v':dt},_0x487c99=jp['get'](_0xe5da5['config']['apiHost']);_0x487c99&&(_0xcbd5b1['eid']=_0x487c99);const _0x2eb0a4=_0xe5da5['_getFrameworks']();return _0x2eb0a4['length']&&(_0xcbd5b1['fw']=_0x2eb0a4['join'](',')),_0x974825+'?'+ut(_0xcbd5b1)['slice'](0x1);}async function Yp(_0x1f7b48){const _0x54dae4=await Hp(_0x1f7b48),_0x116c65=Z()['gapi'];return m(_0x116c65,_0x1f7b48,'internal-error'),_0x54dae4['open']({'where':document['body'],'url':Kp(_0x1f7b48),'messageHandlersFilter':_0x116c65['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x3fa4b6=>new Promise(async(_0x46eeab,_0x5d6a9d)=>{await _0x3fa4b6['restyle']({'setHideOnLeave':!0x1});const _0x4b1a5a=X(_0x1f7b48,'network-request-failed'),_0x33b8bf=Z()['setTimeout'](()=>{_0x5d6a9d(_0x4b1a5a);},$p['get']());function _0x4b2784(){Z()['clearTimeout'](_0x33b8bf),_0x46eeab(_0x3fa4b6);}_0x3fa4b6['ping'](_0x4b2784)['then'](_0x4b2784,()=>{_0x5d6a9d(_0x4b1a5a);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x1c1d25){this['window']=_0x1c1d25,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x394508,_0x2b61b3,_0x17bc0e,_0x432ab4=Jp,_0x360a1e=Xp){const _0x4e26dd=Math['max']((window['screen']['availHeight']-_0x360a1e)/0x2,0x0)['toString'](),_0x33e429=Math['max']((window['screen']['availWidth']-_0x432ab4)/0x2,0x0)['toString']();let _0x3d18af='';const _0x64d1b5={...Qp,'width':_0x432ab4['toString'](),'height':_0x360a1e['toString'](),'top':_0x4e26dd,'left':_0x33e429},_0x5079c8=W()['toLowerCase']();_0x17bc0e&&(_0x3d18af=ka(_0x5079c8)?Zp:_0x17bc0e),Ra(_0x5079c8)&&(_0x2b61b3=_0x2b61b3||e_,_0x64d1b5['scrollbars']='yes');const _0x4805c5=Object['entries'](_0x64d1b5)['reduce']((_0x1f43b4,[_0x2fa3aa,_0x7eaf8c])=>''+_0x1f43b4+_0x2fa3aa+'='+_0x7eaf8c+',','');if(Rf(_0x5079c8)&&_0x3d18af!=='_self')return n_(_0x2b61b3||'',_0x3d18af),new xr(null);const _0x454a6f=window['open'](_0x2b61b3||'',_0x3d18af,_0x4805c5);m(_0x454a6f,_0x394508,'popup-blocked');try{_0x454a6f['focus']();}catch{}return new xr(_0x454a6f);}function n_(_0x30f2b1,_0x1d6005){const _0x5d5556=document['createElement']('a');_0x5d5556['href']=_0x30f2b1,_0x5d5556['target']=_0x1d6005;const _0x3661fd=document['createEvent']('MouseEvent');_0x3661fd['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x5d5556['dispatchEvent'](_0x3661fd);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x5ba558,_0x4eba48,_0x302970,_0xcde4cf,_0x18bfc,_0xfd750){m(_0x5ba558['config']['authDomain'],_0x5ba558,'auth-domain-config-required'),m(_0x5ba558['config']['apiKey'],_0x5ba558,'invalid-api-key');const _0x5d2209={'apiKey':_0x5ba558['config']['apiKey'],'appName':_0x5ba558['name'],'authType':_0x302970,'redirectUrl':_0xcde4cf,'v':dt,'eventId':_0x18bfc};if(_0x4eba48 instanceof Wa){_0x4eba48['setDefaultLanguage'](_0x5ba558['languageCode']),_0x5d2209['providerId']=_0x4eba48['providerId']||'',pn(_0x4eba48['getCustomParameters']())||(_0x5d2209['customParameters']=JSON['stringify'](_0x4eba48['getCustomParameters']()));for(const [_0x528c70,_0x48296f]of Object['entries']({}))_0x5d2209[_0x528c70]=_0x48296f;}if(_0x4eba48 instanceof tn){const _0x934d89=_0x4eba48['getScopes']()['filter'](_0x22c30e=>_0x22c30e!=='');_0x934d89['length']>0x0&&(_0x5d2209['scopes']=_0x934d89['join'](','));}_0x5ba558['tenantId']&&(_0x5d2209['tid']=_0x5ba558['tenantId']);const _0x637476=_0x5d2209;for(const _0x70f3b1 of Object['keys'](_0x637476))_0x637476[_0x70f3b1]===void 0x0&&delete _0x637476[_0x70f3b1];const _0x580181=await _0x5ba558['_getAppCheckToken'](),_0x20e979=_0x580181?'#'+r_+'='+encodeURIComponent(_0x580181):'';return o_(_0x5ba558)+'?'+ut(_0x637476)['slice'](0x1)+_0x20e979;}function o_({config:_0x264530}){return _0x264530['emulator']?Cs(_0x264530,s_):'https://'+_0x264530['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x349d04,_0x428913,_0x16e0e0,_0x5bfd52){var _0x39c800;ce((_0x39c800=this['eventManagers'][_0x349d04['_key']()])==null?void 0x0:_0x39c800['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x490661=await Fr(_0x349d04,_0x428913,_0x16e0e0,Mi(),_0x5bfd52);return t_(_0x349d04,_0x490661,As());}async['_openRedirect'](_0x388de3,_0x51ea00,_0x56c648,_0x36496d){await this['_originValidation'](_0x388de3);const _0x4ebd66=await Fr(_0x388de3,_0x51ea00,_0x56c648,Mi(),_0x36496d);return hp(_0x4ebd66),new Promise(()=>{});}['_initialize'](_0x2450a5){const _0x5c83d5=_0x2450a5['_key']();if(this['eventManagers'][_0x5c83d5]){const {manager:_0x26387e,promise:_0x2616f6}=this['eventManagers'][_0x5c83d5];return _0x26387e?Promise['resolve'](_0x26387e):(ce(_0x2616f6,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x2616f6);}const _0x458323=this['initAndGetManager'](_0x2450a5);return this['eventManagers'][_0x5c83d5]={'promise':_0x458323},_0x458323['catch'](()=>{delete this['eventManagers'][_0x5c83d5];}),_0x458323;}async['initAndGetManager'](_0x1b945d){const _0x50465c=await Yp(_0x1b945d),_0x3b9b57=new Dp(_0x1b945d);return _0x50465c['register']('authEvent',_0x4a23ed=>(m(_0x4a23ed==null?void 0x0:_0x4a23ed['authEvent'],_0x1b945d,'invalid-auth-event'),{'status':_0x3b9b57['onEvent'](_0x4a23ed['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x1b945d['_key']()]={'manager':_0x3b9b57},this['iframes'][_0x1b945d['_key']()]=_0x50465c,_0x3b9b57;}['_isIframeWebStorageSupported'](_0x7b676,_0x2cc651){this['iframes'][_0x7b676['_key']()]['send'](pi,{'type':pi},_0x2b68c8=>{var _0x448135;const _0xbea318=(_0x448135=_0x2b68c8==null?void 0x0:_0x2b68c8[0x0])==null?void 0x0:_0x448135[pi];_0xbea318!==void 0x0&&_0x2cc651(!!_0xbea318),Y(_0x7b676,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x2320de){const _0x1701e4=_0x2320de['_key']();return this['originValidationPromises'][_0x1701e4]||(this['originValidationPromises'][_0x1701e4]=Up(_0x2320de)),this['originValidationPromises'][_0x1701e4];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x323373){this['auth']=_0x323373,this['internalListeners']=new Map();}['getUid'](){var _0x201114;return this['assertAuthConfigured'](),((_0x201114=this['auth']['currentUser'])==null?void 0x0:_0x201114['uid'])||null;}async['getToken'](_0x1f96fc){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x1f96fc)}:null;}['addAuthTokenListener'](_0x5db9cc){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x5db9cc))return;const _0x1428cb=this['auth']['onIdTokenChanged'](_0x26482b=>{_0x5db9cc((_0x26482b==null?void 0x0:_0x26482b['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x5db9cc,_0x1428cb),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x501fd3){this['assertAuthConfigured']();const _0x3275a9=this['internalListeners']['get'](_0x501fd3);_0x3275a9&&(this['internalListeners']['delete'](_0x501fd3),_0x3275a9(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x7f72c4){switch(_0x7f72c4){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x2ae9ab){st(new Fe('auth',(_0x5532bb,{options:_0x1ee8ae})=>{const _0xdd442d=_0x5532bb['getProvider']('app')['getImmediate'](),_0xf98721=_0x5532bb['getProvider']('heartbeat'),_0x157b8f=_0x5532bb['getProvider']('app-check-internal'),{apiKey:_0x51a6ea,authDomain:_0x439e80}=_0xdd442d['options'];m(_0x51a6ea&&!_0x51a6ea['includes'](':'),'invalid-api-key',{'appName':_0xdd442d['name']});const _0x25bf0c={'apiKey':_0x51a6ea,'authDomain':_0x439e80,'clientPlatform':_0x2ae9ab,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x2ae9ab)},_0x39e9e6=new Df(_0xdd442d,_0xf98721,_0x157b8f,_0x25bf0c);return Hf(_0x39e9e6,_0x1ee8ae),_0x39e9e6;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x1b58a5,_0x393526,_0x21fc06)=>{_0x1b58a5['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x1eb956=>{const _0x598f63=Ke(_0x1eb956['getProvider']('auth')['getImmediate']());return(_0x272eff=>new l_(_0x272eff))(_0x598f63);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x2ae9ab)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x544bcb=>async _0x36372c=>{const _0x2c519a=_0x36372c&&await _0x36372c['getIdTokenResult'](),_0x40cf66=_0x2c519a&&(new Date()['getTime']()-Date['parse'](_0x2c519a['issuedAtTime']))/0x3e8;if(_0x40cf66&&_0x40cf66>f_)return;const _0x26670d=_0x2c519a==null?void 0x0:_0x2c519a['token'];Br!==_0x26670d&&(Br=_0x26670d,await fetch(_0x544bcb,{'method':_0x26670d?'POST':'DELETE','headers':_0x26670d?{'Authorization':'Bearer\x20'+_0x26670d}:{}}));};function B_(_0x52f52d=Zr()){const _0x225d2d=Hi(_0x52f52d,'auth');if(_0x225d2d['isInitialized']())return _0x225d2d['getImmediate']();const _0x30e4e5=Vf(_0x52f52d,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x3f2da7=jr('authTokenSyncURL');if(_0x3f2da7&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x4f6ffe=new URL(_0x3f2da7,location['origin']);if(location['origin']===_0x4f6ffe['origin']){const _0x2427c8=p_(_0x4f6ffe['toString']());sp(_0x30e4e5,_0x2427c8,()=>_0x2427c8(_0x30e4e5['currentUser'])),ip(_0x30e4e5,_0x33da7e=>_0x2427c8(_0x33da7e));}}const _0x3a9cac=qr('auth');return _0x3a9cac&&$f(_0x30e4e5,'http://'+_0x3a9cac),_0x30e4e5;}function __(){var _0x6fae1b;return((_0x6fae1b=document['getElementsByTagName']('head'))==null?void 0x0:_0x6fae1b[0x0])??document;}Mf({'loadJS'(_0x543628){return new Promise((_0x4ebf14,_0x2765e6)=>{const _0x5218bd=document['createElement']('script');_0x5218bd['setAttribute']('src',_0x543628),_0x5218bd['onload']=_0x4ebf14,_0x5218bd['onerror']=_0x11da20=>{const _0x1fb8d9=X('internal-error');_0x1fb8d9['customData']=_0x11da20,_0x2765e6(_0x1fb8d9);},_0x5218bd['type']='text/javascript',_0x5218bd['charset']='UTF-8',__()['appendChild'](_0x5218bd);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,B_ as a,ap as b,x_ as c,g_ as d,m_ as e,Zr as f,P_ as g,Hd as h,Sl as i,D_ as j,Gd as k,w_ as l,b_ as m,A_ as n,v_ as o,E_ as p,k_ as q,y_ as r,F_ as s,Vt as t,I_ as u,N_ as v,U_ as w,O_ as x,M_ as y,T_ as z};