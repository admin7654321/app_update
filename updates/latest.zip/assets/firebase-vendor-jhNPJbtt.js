const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x15d718,_0x470647){if(!_0x15d718)throw ht(_0x470647);},ht=function(_0x5c5ff7){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x5c5ff7);},Hr=function(_0x499b2c){const _0x1fd54f=[];let _0x412c79=0x0;for(let _0x41a686=0x0;_0x41a686<_0x499b2c['length'];_0x41a686++){let _0x4e561a=_0x499b2c['charCodeAt'](_0x41a686);_0x4e561a<0x80?_0x1fd54f[_0x412c79++]=_0x4e561a:_0x4e561a<0x800?(_0x1fd54f[_0x412c79++]=_0x4e561a>>0x6|0xc0,_0x1fd54f[_0x412c79++]=_0x4e561a&0x3f|0x80):(_0x4e561a&0xfc00)===0xd800&&_0x41a686+0x1<_0x499b2c['length']&&(_0x499b2c['charCodeAt'](_0x41a686+0x1)&0xfc00)===0xdc00?(_0x4e561a=0x10000+((_0x4e561a&0x3ff)<<0xa)+(_0x499b2c['charCodeAt'](++_0x41a686)&0x3ff),_0x1fd54f[_0x412c79++]=_0x4e561a>>0x12|0xf0,_0x1fd54f[_0x412c79++]=_0x4e561a>>0xc&0x3f|0x80,_0x1fd54f[_0x412c79++]=_0x4e561a>>0x6&0x3f|0x80,_0x1fd54f[_0x412c79++]=_0x4e561a&0x3f|0x80):(_0x1fd54f[_0x412c79++]=_0x4e561a>>0xc|0xe0,_0x1fd54f[_0x412c79++]=_0x4e561a>>0x6&0x3f|0x80,_0x1fd54f[_0x412c79++]=_0x4e561a&0x3f|0x80);}return _0x1fd54f;},nc=function(_0x4916eb){const _0x55c765=[];let _0x428edc=0x0,_0x2f4d62=0x0;for(;_0x428edc<_0x4916eb['length'];){const _0x5d418c=_0x4916eb[_0x428edc++];if(_0x5d418c<0x80)_0x55c765[_0x2f4d62++]=String['fromCharCode'](_0x5d418c);else{if(_0x5d418c>0xbf&&_0x5d418c<0xe0){const _0x278f45=_0x4916eb[_0x428edc++];_0x55c765[_0x2f4d62++]=String['fromCharCode']((_0x5d418c&0x1f)<<0x6|_0x278f45&0x3f);}else{if(_0x5d418c>0xef&&_0x5d418c<0x16d){const _0x4f87d3=_0x4916eb[_0x428edc++],_0x4f6eac=_0x4916eb[_0x428edc++],_0x48daf4=_0x4916eb[_0x428edc++],_0x59a780=((_0x5d418c&0x7)<<0x12|(_0x4f87d3&0x3f)<<0xc|(_0x4f6eac&0x3f)<<0x6|_0x48daf4&0x3f)-0x10000;_0x55c765[_0x2f4d62++]=String['fromCharCode'](0xd800+(_0x59a780>>0xa)),_0x55c765[_0x2f4d62++]=String['fromCharCode'](0xdc00+(_0x59a780&0x3ff));}else{const _0x514aec=_0x4916eb[_0x428edc++],_0x383c5d=_0x4916eb[_0x428edc++];_0x55c765[_0x2f4d62++]=String['fromCharCode']((_0x5d418c&0xf)<<0xc|(_0x514aec&0x3f)<<0x6|_0x383c5d&0x3f);}}}}return _0x55c765['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x429568,_0x1b94f8){if(!Array['isArray'](_0x429568))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x61f6e4=_0x1b94f8?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x44a818=[];for(let _0x2f4004=0x0;_0x2f4004<_0x429568['length'];_0x2f4004+=0x3){const _0x261881=_0x429568[_0x2f4004],_0x59f271=_0x2f4004+0x1<_0x429568['length'],_0x21e41a=_0x59f271?_0x429568[_0x2f4004+0x1]:0x0,_0x74d21c=_0x2f4004+0x2<_0x429568['length'],_0x2f11af=_0x74d21c?_0x429568[_0x2f4004+0x2]:0x0,_0xe8b755=_0x261881>>0x2,_0x7c2242=(_0x261881&0x3)<<0x4|_0x21e41a>>0x4;let _0x561c15=(_0x21e41a&0xf)<<0x2|_0x2f11af>>0x6,_0x750419=_0x2f11af&0x3f;_0x74d21c||(_0x750419=0x40,_0x59f271||(_0x561c15=0x40)),_0x44a818['push'](_0x61f6e4[_0xe8b755],_0x61f6e4[_0x7c2242],_0x61f6e4[_0x561c15],_0x61f6e4[_0x750419]);}return _0x44a818['join']('');},'encodeString'(_0x471fa3,_0x2e7cc3){return this['HAS_NATIVE_SUPPORT']&&!_0x2e7cc3?btoa(_0x471fa3):this['encodeByteArray'](Hr(_0x471fa3),_0x2e7cc3);},'decodeString'(_0x517ec3,_0x54da53){return this['HAS_NATIVE_SUPPORT']&&!_0x54da53?atob(_0x517ec3):nc(this['decodeStringToByteArray'](_0x517ec3,_0x54da53));},'decodeStringToByteArray'(_0x2c6e33,_0xcef22a){this['init_']();const _0xa8c64d=_0xcef22a?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x863c74=[];for(let _0x1fc0f6=0x0;_0x1fc0f6<_0x2c6e33['length'];){const _0x2898fb=_0xa8c64d[_0x2c6e33['charAt'](_0x1fc0f6++)],_0x13d9c5=_0x1fc0f6<_0x2c6e33['length']?_0xa8c64d[_0x2c6e33['charAt'](_0x1fc0f6)]:0x0;++_0x1fc0f6;const _0xfdb1bf=_0x1fc0f6<_0x2c6e33['length']?_0xa8c64d[_0x2c6e33['charAt'](_0x1fc0f6)]:0x40;++_0x1fc0f6;const _0x586ffb=_0x1fc0f6<_0x2c6e33['length']?_0xa8c64d[_0x2c6e33['charAt'](_0x1fc0f6)]:0x40;if(++_0x1fc0f6,_0x2898fb==null||_0x13d9c5==null||_0xfdb1bf==null||_0x586ffb==null)throw new ic();const _0x4a0f3e=_0x2898fb<<0x2|_0x13d9c5>>0x4;if(_0x863c74['push'](_0x4a0f3e),_0xfdb1bf!==0x40){const _0x2bc378=_0x13d9c5<<0x4&0xf0|_0xfdb1bf>>0x2;if(_0x863c74['push'](_0x2bc378),_0x586ffb!==0x40){const _0x4ef958=_0xfdb1bf<<0x6&0xc0|_0x586ffb;_0x863c74['push'](_0x4ef958);}}}return _0x863c74;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x48a0d5=0x0;_0x48a0d5<this['ENCODED_VALS']['length'];_0x48a0d5++)this['byteToCharMap_'][_0x48a0d5]=this['ENCODED_VALS']['charAt'](_0x48a0d5),this['charToByteMap_'][this['byteToCharMap_'][_0x48a0d5]]=_0x48a0d5,this['byteToCharMapWebSafe_'][_0x48a0d5]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x48a0d5),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x48a0d5]]=_0x48a0d5,_0x48a0d5>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x48a0d5)]=_0x48a0d5,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x48a0d5)]=_0x48a0d5);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x1793cc){const _0x2d0104=Hr(_0x1793cc);return Fi['encodeByteArray'](_0x2d0104,!0x0);},dn=function(_0x7cbee4){return $r(_0x7cbee4)['replace'](/\./g,'');},fn=function(_0x1f4c9e){try{return Fi['decodeString'](_0x1f4c9e,!0x0);}catch(_0x39a885){console['error']('base64Decode\x20failed:\x20',_0x39a885);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x2ac0f9){return Gr(void 0x0,_0x2ac0f9);}function Gr(_0x5d02ce,_0x2f3ed8){if(!(_0x2f3ed8 instanceof Object))return _0x2f3ed8;switch(_0x2f3ed8['constructor']){case Date:const _0x3f1510=_0x2f3ed8;return new Date(_0x3f1510['getTime']());case Object:_0x5d02ce===void 0x0&&(_0x5d02ce={});break;case Array:_0x5d02ce=[];break;default:return _0x2f3ed8;}for(const _0x51e29f in _0x2f3ed8)!_0x2f3ed8['hasOwnProperty'](_0x51e29f)||!rc(_0x51e29f)||(_0x5d02ce[_0x51e29f]=Gr(_0x5d02ce[_0x51e29f],_0x2f3ed8[_0x51e29f]));return _0x5d02ce;}function rc(_0x362ed5){return _0x362ed5!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0xffba7a=Ps['__FIREBASE_DEFAULTS__'];if(_0xffba7a)return JSON['parse'](_0xffba7a);},lc=()=>{if(typeof document>'u')return;let _0x1a3ed0;try{_0x1a3ed0=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x39f36d=_0x1a3ed0&&fn(_0x1a3ed0[0x1]);return _0x39f36d&&JSON['parse'](_0x39f36d);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x44c1b8){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x44c1b8);return;}},qr=_0x5d521c=>{var _0x5464aa,_0x350753;return(_0x350753=(_0x5464aa=Ui())==null?void 0x0:_0x5464aa['emulatorHosts'])==null?void 0x0:_0x350753[_0x5d521c];},hc=_0x3e83dd=>{const _0x4f6fe0=qr(_0x3e83dd);if(!_0x4f6fe0)return;const _0x10e2a6=_0x4f6fe0['lastIndexOf'](':');if(_0x10e2a6<=0x0||_0x10e2a6+0x1===_0x4f6fe0['length'])throw new Error('Invalid\x20host\x20'+_0x4f6fe0+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x3193a8=parseInt(_0x4f6fe0['substring'](_0x10e2a6+0x1),0xa);return _0x4f6fe0[0x0]==='['?[_0x4f6fe0['substring'](0x1,_0x10e2a6-0x1),_0x3193a8]:[_0x4f6fe0['substring'](0x0,_0x10e2a6),_0x3193a8];},zr=()=>{var _0x463501;return(_0x463501=Ui())==null?void 0x0:_0x463501['config'];},jr=_0x436ceb=>{var _0x204290;return(_0x204290=Ui())==null?void 0x0:_0x204290['_'+_0x436ceb];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x2cafd1,_0xf39da2)=>{this['resolve']=_0x2cafd1,this['reject']=_0xf39da2;});}['wrapCallback'](_0x112e57){return(_0x4eda8d,_0x519656)=>{_0x4eda8d?this['reject'](_0x4eda8d):this['resolve'](_0x519656),typeof _0x112e57=='function'&&(this['promise']['catch'](()=>{}),_0x112e57['length']===0x1?_0x112e57(_0x4eda8d):_0x112e57(_0x4eda8d,_0x519656));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x189ec,_0x1ad4b7){if(_0x189ec['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x4ced5e={'alg':'none','type':'JWT'},_0x3f28e9=_0x1ad4b7||'demo-project',_0x518b6b=_0x189ec['iat']||0x0,_0x354c04=_0x189ec['sub']||_0x189ec['user_id'];if(!_0x354c04)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x21687c={'iss':'https://securetoken.google.com/'+_0x3f28e9,'aud':_0x3f28e9,'iat':_0x518b6b,'exp':_0x518b6b+0xe10,'auth_time':_0x518b6b,'sub':_0x354c04,'user_id':_0x354c04,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x189ec};return[dn(JSON['stringify'](_0x4ced5e)),dn(JSON['stringify'](_0x21687c)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x245d1e=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x245d1e=='object'&&_0x245d1e['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x5e9077=W();return _0x5e9077['indexOf']('MSIE\x20')>=0x0||_0x5e9077['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x59b907,_0x454c6d)=>{try{let _0x2ac778=!0x0;const _0x4ae04a='validate-browser-context-for-indexeddb-analytics-module',_0x224288=self['indexedDB']['open'](_0x4ae04a);_0x224288['onsuccess']=()=>{_0x224288['result']['close'](),_0x2ac778||self['indexedDB']['deleteDatabase'](_0x4ae04a),_0x59b907(!0x0);},_0x224288['onupgradeneeded']=()=>{_0x2ac778=!0x1;},_0x224288['onerror']=()=>{var _0x520385;_0x454c6d(((_0x520385=_0x224288['error'])==null?void 0x0:_0x520385['message'])||'');};}catch(_0x21c5dc){_0x454c6d(_0x21c5dc);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x44fc42,_0x3fbc69,_0x42972a){super(_0x3fbc69),this['code']=_0x44fc42,this['customData']=_0x42972a,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x513c96,_0x3399bf,_0x294f7e){this['service']=_0x513c96,this['serviceName']=_0x3399bf,this['errors']=_0x294f7e;}['create'](_0x5d6c97,..._0x357947){const _0xad1473=_0x357947[0x0]||{},_0x6b5e9=this['service']+'/'+_0x5d6c97,_0x5b8b88=this['errors'][_0x5d6c97],_0x378f39=_0x5b8b88?vc(_0x5b8b88,_0xad1473):'Error',_0x50f62c=this['serviceName']+':\x20'+_0x378f39+'\x20('+_0x6b5e9+').';return new Re(_0x6b5e9,_0x50f62c,_0xad1473);}}function vc(_0x20f60e,_0x23b837){return _0x20f60e['replace'](Ec,(_0x2db4a0,_0x44d2ae)=>{const _0x2a753e=_0x23b837[_0x44d2ae];return _0x2a753e!=null?String(_0x2a753e):'<'+_0x44d2ae+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x509926){return JSON['parse'](_0x509926);}function O(_0x14b0a8){return JSON['stringify'](_0x14b0a8);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x357799){let _0x30206d={},_0x357804={},_0xee4c08={},_0x2d6bf3='';try{const _0x1f19f5=_0x357799['split']('.');_0x30206d=Nt(fn(_0x1f19f5[0x0])||''),_0x357804=Nt(fn(_0x1f19f5[0x1])||''),_0x2d6bf3=_0x1f19f5[0x2],_0xee4c08=_0x357804['d']||{},delete _0x357804['d'];}catch{}return{'header':_0x30206d,'claims':_0x357804,'data':_0xee4c08,'signature':_0x2d6bf3};},Ic=function(_0x324d5a){const _0x4db291=Yr(_0x324d5a),_0x54426b=_0x4db291['claims'];return!!_0x54426b&&typeof _0x54426b=='object'&&_0x54426b['hasOwnProperty']('iat');},wc=function(_0x533ee7){const _0x33047c=Yr(_0x533ee7)['claims'];return typeof _0x33047c=='object'&&_0x33047c['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x4aad78,_0x4c5b53){return Object['prototype']['hasOwnProperty']['call'](_0x4aad78,_0x4c5b53);}function Le(_0x2d1891,_0x57814e){if(Object['prototype']['hasOwnProperty']['call'](_0x2d1891,_0x57814e))return _0x2d1891[_0x57814e];}function pn(_0xc0395f){for(const _0x1ef577 in _0xc0395f)if(Object['prototype']['hasOwnProperty']['call'](_0xc0395f,_0x1ef577))return!0x1;return!0x0;}function _n(_0x3f4a97,_0x33d4fb,_0x265523){const _0x262936={};for(const _0x7bddfc in _0x3f4a97)Object['prototype']['hasOwnProperty']['call'](_0x3f4a97,_0x7bddfc)&&(_0x262936[_0x7bddfc]=_0x33d4fb['call'](_0x265523,_0x3f4a97[_0x7bddfc],_0x7bddfc,_0x3f4a97));return _0x262936;}function xe(_0x5552f7,_0x4e01d8){if(_0x5552f7===_0x4e01d8)return!0x0;const _0x1ffa47=Object['keys'](_0x5552f7),_0x5b49ad=Object['keys'](_0x4e01d8);for(const _0x54dd0a of _0x1ffa47){if(!_0x5b49ad['includes'](_0x54dd0a))return!0x1;const _0x12b76d=_0x5552f7[_0x54dd0a],_0x5d567=_0x4e01d8[_0x54dd0a];if(Ns(_0x12b76d)&&Ns(_0x5d567)){if(!xe(_0x12b76d,_0x5d567))return!0x1;}else{if(_0x12b76d!==_0x5d567)return!0x1;}}for(const _0x15039d of _0x5b49ad)if(!_0x1ffa47['includes'](_0x15039d))return!0x1;return!0x0;}function Ns(_0x547cd7){return _0x547cd7!==null&&typeof _0x547cd7=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x1ff565){const _0x117fd4=[];for(const [_0x3d5341,_0x596768]of Object['entries'](_0x1ff565))Array['isArray'](_0x596768)?_0x596768['forEach'](_0x380542=>{_0x117fd4['push'](encodeURIComponent(_0x3d5341)+'='+encodeURIComponent(_0x380542));}):_0x117fd4['push'](encodeURIComponent(_0x3d5341)+'='+encodeURIComponent(_0x596768));return _0x117fd4['length']?'&'+_0x117fd4['join']('&'):'';}function Ct(_0x293031){const _0x5e1374={};return _0x293031['replace'](/^\?/,'')['split']('&')['forEach'](_0x2559a9=>{if(_0x2559a9){const [_0x479ee6,_0x34248d]=_0x2559a9['split']('=');_0x5e1374[decodeURIComponent(_0x479ee6)]=decodeURIComponent(_0x34248d);}}),_0x5e1374;}function Tt(_0x4c1ce1){const _0x3df8a1=_0x4c1ce1['indexOf']('?');if(!_0x3df8a1)return'';const _0x1ec180=_0x4c1ce1['indexOf']('#',_0x3df8a1);return _0x4c1ce1['substring'](_0x3df8a1,_0x1ec180>0x0?_0x1ec180:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x429be5=0x1;_0x429be5<this['blockSize'];++_0x429be5)this['pad_'][_0x429be5]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x500351,_0x5407f7){_0x5407f7||(_0x5407f7=0x0);const _0x14e8b5=this['W_'];if(typeof _0x500351=='string'){for(let _0x73a193=0x0;_0x73a193<0x10;_0x73a193++)_0x14e8b5[_0x73a193]=_0x500351['charCodeAt'](_0x5407f7)<<0x18|_0x500351['charCodeAt'](_0x5407f7+0x1)<<0x10|_0x500351['charCodeAt'](_0x5407f7+0x2)<<0x8|_0x500351['charCodeAt'](_0x5407f7+0x3),_0x5407f7+=0x4;}else{for(let _0x5c18b5=0x0;_0x5c18b5<0x10;_0x5c18b5++)_0x14e8b5[_0x5c18b5]=_0x500351[_0x5407f7]<<0x18|_0x500351[_0x5407f7+0x1]<<0x10|_0x500351[_0x5407f7+0x2]<<0x8|_0x500351[_0x5407f7+0x3],_0x5407f7+=0x4;}for(let _0x3a9090=0x10;_0x3a9090<0x50;_0x3a9090++){const _0x4e37c4=_0x14e8b5[_0x3a9090-0x3]^_0x14e8b5[_0x3a9090-0x8]^_0x14e8b5[_0x3a9090-0xe]^_0x14e8b5[_0x3a9090-0x10];_0x14e8b5[_0x3a9090]=(_0x4e37c4<<0x1|_0x4e37c4>>>0x1f)&0xffffffff;}let _0x1b2b4f=this['chain_'][0x0],_0x83ceae=this['chain_'][0x1],_0x14c0bd=this['chain_'][0x2],_0x1c2fea=this['chain_'][0x3],_0xe94b3a=this['chain_'][0x4],_0xcba3fd,_0x2ae943;for(let _0x446798=0x0;_0x446798<0x50;_0x446798++){_0x446798<0x28?_0x446798<0x14?(_0xcba3fd=_0x1c2fea^_0x83ceae&(_0x14c0bd^_0x1c2fea),_0x2ae943=0x5a827999):(_0xcba3fd=_0x83ceae^_0x14c0bd^_0x1c2fea,_0x2ae943=0x6ed9eba1):_0x446798<0x3c?(_0xcba3fd=_0x83ceae&_0x14c0bd|_0x1c2fea&(_0x83ceae|_0x14c0bd),_0x2ae943=0x8f1bbcdc):(_0xcba3fd=_0x83ceae^_0x14c0bd^_0x1c2fea,_0x2ae943=0xca62c1d6);const _0x303fa8=(_0x1b2b4f<<0x5|_0x1b2b4f>>>0x1b)+_0xcba3fd+_0xe94b3a+_0x2ae943+_0x14e8b5[_0x446798]&0xffffffff;_0xe94b3a=_0x1c2fea,_0x1c2fea=_0x14c0bd,_0x14c0bd=(_0x83ceae<<0x1e|_0x83ceae>>>0x2)&0xffffffff,_0x83ceae=_0x1b2b4f,_0x1b2b4f=_0x303fa8;}this['chain_'][0x0]=this['chain_'][0x0]+_0x1b2b4f&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x83ceae&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x14c0bd&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x1c2fea&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0xe94b3a&0xffffffff;}['update'](_0x4f117b,_0x104af8){if(_0x4f117b==null)return;_0x104af8===void 0x0&&(_0x104af8=_0x4f117b['length']);const _0x25d6bf=_0x104af8-this['blockSize'];let _0x2f4e7f=0x0;const _0x28b76f=this['buf_'];let _0x5c6c89=this['inbuf_'];for(;_0x2f4e7f<_0x104af8;){if(_0x5c6c89===0x0){for(;_0x2f4e7f<=_0x25d6bf;)this['compress_'](_0x4f117b,_0x2f4e7f),_0x2f4e7f+=this['blockSize'];}if(typeof _0x4f117b=='string'){for(;_0x2f4e7f<_0x104af8;)if(_0x28b76f[_0x5c6c89]=_0x4f117b['charCodeAt'](_0x2f4e7f),++_0x5c6c89,++_0x2f4e7f,_0x5c6c89===this['blockSize']){this['compress_'](_0x28b76f),_0x5c6c89=0x0;break;}}else{for(;_0x2f4e7f<_0x104af8;)if(_0x28b76f[_0x5c6c89]=_0x4f117b[_0x2f4e7f],++_0x5c6c89,++_0x2f4e7f,_0x5c6c89===this['blockSize']){this['compress_'](_0x28b76f),_0x5c6c89=0x0;break;}}}this['inbuf_']=_0x5c6c89,this['total_']+=_0x104af8;}['digest'](){const _0x4277c4=[];let _0x5db5fa=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x5b1acd=this['blockSize']-0x1;_0x5b1acd>=0x38;_0x5b1acd--)this['buf_'][_0x5b1acd]=_0x5db5fa&0xff,_0x5db5fa/=0x100;this['compress_'](this['buf_']);let _0xb5f69e=0x0;for(let _0x27dbdf=0x0;_0x27dbdf<0x5;_0x27dbdf++)for(let _0x203cd5=0x18;_0x203cd5>=0x0;_0x203cd5-=0x8)_0x4277c4[_0xb5f69e]=this['chain_'][_0x27dbdf]>>_0x203cd5&0xff,++_0xb5f69e;return _0x4277c4;}}function Tc(_0x3a0c16,_0x23c210){const _0x1e379b=new Sc(_0x3a0c16,_0x23c210);return _0x1e379b['subscribe']['bind'](_0x1e379b);}class Sc{constructor(_0x4e8e7c,_0x52f588){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x52f588,this['task']['then'](()=>{_0x4e8e7c(this);})['catch'](_0x3cc584=>{this['error'](_0x3cc584);});}['next'](_0x328555){this['forEachObserver'](_0x5a3eb3=>{_0x5a3eb3['next'](_0x328555);});}['error'](_0x2e1a02){this['forEachObserver'](_0xd6f0de=>{_0xd6f0de['error'](_0x2e1a02);}),this['close'](_0x2e1a02);}['complete'](){this['forEachObserver'](_0x3fabfd=>{_0x3fabfd['complete']();}),this['close']();}['subscribe'](_0x51c4f6,_0x459d01,_0x5a58c3){let _0x28652c;if(_0x51c4f6===void 0x0&&_0x459d01===void 0x0&&_0x5a58c3===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x51c4f6,['next','error','complete'])?_0x28652c=_0x51c4f6:_0x28652c={'next':_0x51c4f6,'error':_0x459d01,'complete':_0x5a58c3},_0x28652c['next']===void 0x0&&(_0x28652c['next']=ti),_0x28652c['error']===void 0x0&&(_0x28652c['error']=ti),_0x28652c['complete']===void 0x0&&(_0x28652c['complete']=ti);const _0x378bd5=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x28652c['error'](this['finalError']):_0x28652c['complete']();}catch{}}),this['observers']['push'](_0x28652c),_0x378bd5;}['unsubscribeOne'](_0x833bfe){this['observers']===void 0x0||this['observers'][_0x833bfe]===void 0x0||(delete this['observers'][_0x833bfe],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x5ccf77){if(!this['finalized']){for(let _0x442bb9=0x0;_0x442bb9<this['observers']['length'];_0x442bb9++)this['sendOne'](_0x442bb9,_0x5ccf77);}}['sendOne'](_0x288c7c,_0x52db4e){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x288c7c]!==void 0x0)try{_0x52db4e(this['observers'][_0x288c7c]);}catch(_0x1e5df3){typeof console<'u'&&console['error']&&console['error'](_0x1e5df3);}});}['close'](_0x4a3e51){this['finalized']||(this['finalized']=!0x0,_0x4a3e51!==void 0x0&&(this['finalError']=_0x4a3e51),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x5cf54f,_0x12065b){if(typeof _0x5cf54f!='object'||_0x5cf54f===null)return!0x1;for(const _0x1a2e1d of _0x12065b)if(_0x1a2e1d in _0x5cf54f&&typeof _0x5cf54f[_0x1a2e1d]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x2f5578,_0x433869){return _0x2f5578+'\x20failed:\x20'+_0x433869+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0xe6041){const _0x4a1101=[];let _0x36fc28=0x0;for(let _0x5b574b=0x0;_0x5b574b<_0xe6041['length'];_0x5b574b++){let _0x441352=_0xe6041['charCodeAt'](_0x5b574b);if(_0x441352>=0xd800&&_0x441352<=0xdbff){const _0x3141fe=_0x441352-0xd800;_0x5b574b++,f(_0x5b574b<_0xe6041['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x20da8d=_0xe6041['charCodeAt'](_0x5b574b)-0xdc00;_0x441352=0x10000+(_0x3141fe<<0xa)+_0x20da8d;}_0x441352<0x80?_0x4a1101[_0x36fc28++]=_0x441352:_0x441352<0x800?(_0x4a1101[_0x36fc28++]=_0x441352>>0x6|0xc0,_0x4a1101[_0x36fc28++]=_0x441352&0x3f|0x80):_0x441352<0x10000?(_0x4a1101[_0x36fc28++]=_0x441352>>0xc|0xe0,_0x4a1101[_0x36fc28++]=_0x441352>>0x6&0x3f|0x80,_0x4a1101[_0x36fc28++]=_0x441352&0x3f|0x80):(_0x4a1101[_0x36fc28++]=_0x441352>>0x12|0xf0,_0x4a1101[_0x36fc28++]=_0x441352>>0xc&0x3f|0x80,_0x4a1101[_0x36fc28++]=_0x441352>>0x6&0x3f|0x80,_0x4a1101[_0x36fc28++]=_0x441352&0x3f|0x80);}return _0x4a1101;},Ln=function(_0x4b8b7b){let _0x22184e=0x0;for(let _0x1ee0b6=0x0;_0x1ee0b6<_0x4b8b7b['length'];_0x1ee0b6++){const _0xb11de8=_0x4b8b7b['charCodeAt'](_0x1ee0b6);_0xb11de8<0x80?_0x22184e++:_0xb11de8<0x800?_0x22184e+=0x2:_0xb11de8>=0xd800&&_0xb11de8<=0xdbff?(_0x22184e+=0x4,_0x1ee0b6++):_0x22184e+=0x3;}return _0x22184e;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x4b0f61){return _0x4b0f61&&_0x4b0f61['_delegate']?_0x4b0f61['_delegate']:_0x4b0f61;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x120805){try{return(_0x120805['startsWith']('http://')||_0x120805['startsWith']('https://')?new URL(_0x120805)['hostname']:_0x120805)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x543ddb){return(await fetch(_0x543ddb,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x271942,_0x58b857,_0x5d6e6c){this['name']=_0x271942,this['instanceFactory']=_0x58b857,this['type']=_0x5d6e6c,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x12e016){return this['instantiationMode']=_0x12e016,this;}['setMultipleInstances'](_0x407f06){return this['multipleInstances']=_0x407f06,this;}['setServiceProps'](_0x27904c){return this['serviceProps']=_0x27904c,this;}['setInstanceCreatedCallback'](_0x24da0f){return this['onInstanceCreated']=_0x24da0f,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x62173f,_0x2781f3){this['name']=_0x62173f,this['container']=_0x2781f3,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x542e47){const _0x3be632=this['normalizeInstanceIdentifier'](_0x542e47);if(!this['instancesDeferred']['has'](_0x3be632)){const _0x4edf9c=new H();if(this['instancesDeferred']['set'](_0x3be632,_0x4edf9c),this['isInitialized'](_0x3be632)||this['shouldAutoInitialize']())try{const _0x31db9f=this['getOrInitializeService']({'instanceIdentifier':_0x3be632});_0x31db9f&&_0x4edf9c['resolve'](_0x31db9f);}catch{}}return this['instancesDeferred']['get'](_0x3be632)['promise'];}['getImmediate'](_0x7db158){const _0x20497f=this['normalizeInstanceIdentifier'](_0x7db158==null?void 0x0:_0x7db158['identifier']),_0x1b9196=(_0x7db158==null?void 0x0:_0x7db158['optional'])??!0x1;if(this['isInitialized'](_0x20497f)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x20497f});}catch(_0x4f0264){if(_0x1b9196)return null;throw _0x4f0264;}else{if(_0x1b9196)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x482bf1){if(_0x482bf1['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x482bf1['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x482bf1,!!this['shouldAutoInitialize']()){if(Pc(_0x482bf1))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x3af771,_0x14ef77]of this['instancesDeferred']['entries']()){const _0x219806=this['normalizeInstanceIdentifier'](_0x3af771);try{const _0x4f4f1c=this['getOrInitializeService']({'instanceIdentifier':_0x219806});_0x14ef77['resolve'](_0x4f4f1c);}catch{}}}}['clearInstance'](_0x198e14=Ne){this['instancesDeferred']['delete'](_0x198e14),this['instancesOptions']['delete'](_0x198e14),this['instances']['delete'](_0x198e14);}async['delete'](){const _0x551622=Array['from'](this['instances']['values']());await Promise['all']([..._0x551622['filter'](_0x3f6fe1=>'INTERNAL'in _0x3f6fe1)['map'](_0x3098c5=>_0x3098c5['INTERNAL']['delete']()),..._0x551622['filter'](_0x513390=>'_delete'in _0x513390)['map'](_0xb4c16e=>_0xb4c16e['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x221ac7=Ne){return this['instances']['has'](_0x221ac7);}['getOptions'](_0x361ea2=Ne){return this['instancesOptions']['get'](_0x361ea2)||{};}['initialize'](_0x597ec8={}){const {options:_0x4bd524={}}=_0x597ec8,_0x4788d8=this['normalizeInstanceIdentifier'](_0x597ec8['instanceIdentifier']);if(this['isInitialized'](_0x4788d8))throw Error(this['name']+'('+_0x4788d8+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x3451fa=this['getOrInitializeService']({'instanceIdentifier':_0x4788d8,'options':_0x4bd524});for(const [_0x4855bf,_0x1043e9]of this['instancesDeferred']['entries']()){const _0x5d4709=this['normalizeInstanceIdentifier'](_0x4855bf);_0x4788d8===_0x5d4709&&_0x1043e9['resolve'](_0x3451fa);}return _0x3451fa;}['onInit'](_0x36d627,_0x25417d){const _0x1434d5=this['normalizeInstanceIdentifier'](_0x25417d),_0x571e49=this['onInitCallbacks']['get'](_0x1434d5)??new Set();_0x571e49['add'](_0x36d627),this['onInitCallbacks']['set'](_0x1434d5,_0x571e49);const _0x2f308b=this['instances']['get'](_0x1434d5);return _0x2f308b&&_0x36d627(_0x2f308b,_0x1434d5),()=>{_0x571e49['delete'](_0x36d627);};}['invokeOnInitCallbacks'](_0x3abc09,_0x18c369){const _0x3c35ad=this['onInitCallbacks']['get'](_0x18c369);if(_0x3c35ad){for(const _0x2d8375 of _0x3c35ad)try{_0x2d8375(_0x3abc09,_0x18c369);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x3d8636,options:_0x56001b={}}){let _0x540878=this['instances']['get'](_0x3d8636);if(!_0x540878&&this['component']&&(_0x540878=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x3d8636),'options':_0x56001b}),this['instances']['set'](_0x3d8636,_0x540878),this['instancesOptions']['set'](_0x3d8636,_0x56001b),this['invokeOnInitCallbacks'](_0x540878,_0x3d8636),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x3d8636,_0x540878);}catch{}return _0x540878||null;}['normalizeInstanceIdentifier'](_0x4d777f=Ne){return this['component']?this['component']['multipleInstances']?_0x4d777f:Ne:_0x4d777f;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x169ca0){return _0x169ca0===Ne?void 0x0:_0x169ca0;}function Pc(_0x3d3478){return _0x3d3478['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x5d4b29){this['name']=_0x5d4b29,this['providers']=new Map();}['addComponent'](_0x833041){const _0x155582=this['getProvider'](_0x833041['name']);if(_0x155582['isComponentSet']())throw new Error('Component\x20'+_0x833041['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x155582['setComponent'](_0x833041);}['addOrOverwriteComponent'](_0x15d83c){this['getProvider'](_0x15d83c['name'])['isComponentSet']()&&this['providers']['delete'](_0x15d83c['name']),this['addComponent'](_0x15d83c);}['getProvider'](_0x53d83f){if(this['providers']['has'](_0x53d83f))return this['providers']['get'](_0x53d83f);const _0x2b61f9=new Ac(_0x53d83f,this);return this['providers']['set'](_0x53d83f,_0x2b61f9),_0x2b61f9;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0xbc2284){_0xbc2284[_0xbc2284['DEBUG']=0x0]='DEBUG',_0xbc2284[_0xbc2284['VERBOSE']=0x1]='VERBOSE',_0xbc2284[_0xbc2284['INFO']=0x2]='INFO',_0xbc2284[_0xbc2284['WARN']=0x3]='WARN',_0xbc2284[_0xbc2284['ERROR']=0x4]='ERROR',_0xbc2284[_0xbc2284['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x4b872d,_0x3cfbc1,..._0x430d3f)=>{if(_0x3cfbc1<_0x4b872d['logLevel'])return;const _0x34713c=new Date()['toISOString'](),_0x4edba0=Mc[_0x3cfbc1];if(_0x4edba0)console[_0x4edba0]('['+_0x34713c+']\x20\x20'+_0x4b872d['name']+':',..._0x430d3f);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x3cfbc1+')');};class Bi{constructor(_0xfc233e){this['name']=_0xfc233e,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x463f7b){if(!(_0x463f7b in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x463f7b+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x463f7b;}['setLogLevel'](_0x54e2bc){this['_logLevel']=typeof _0x54e2bc=='string'?Oc[_0x54e2bc]:_0x54e2bc;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x1f7976){if(typeof _0x1f7976!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x1f7976;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x154734){this['_userLogHandler']=_0x154734;}['debug'](..._0x6c8f35){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x6c8f35),this['_logHandler'](this,T['DEBUG'],..._0x6c8f35);}['log'](..._0x396d88){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x396d88),this['_logHandler'](this,T['VERBOSE'],..._0x396d88);}['info'](..._0x7e3e55){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x7e3e55),this['_logHandler'](this,T['INFO'],..._0x7e3e55);}['warn'](..._0x3cebb7){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x3cebb7),this['_logHandler'](this,T['WARN'],..._0x3cebb7);}['error'](..._0x4a484f){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x4a484f),this['_logHandler'](this,T['ERROR'],..._0x4a484f);}}const xc=(_0xbb57c2,_0x539ff0)=>_0x539ff0['some'](_0x45f1fe=>_0xbb57c2 instanceof _0x45f1fe);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x56ffcd){const _0xe29ee1=new Promise((_0x4e7ddf,_0x4c48f7)=>{const _0x55edb8=()=>{_0x56ffcd['removeEventListener']('success',_0x26d4d6),_0x56ffcd['removeEventListener']('error',_0x30f529);},_0x26d4d6=()=>{_0x4e7ddf(ge(_0x56ffcd['result'])),_0x55edb8();},_0x30f529=()=>{_0x4c48f7(_0x56ffcd['error']),_0x55edb8();};_0x56ffcd['addEventListener']('success',_0x26d4d6),_0x56ffcd['addEventListener']('error',_0x30f529);});return _0xe29ee1['then'](_0xbf12e8=>{_0xbf12e8 instanceof IDBCursor&&Jr['set'](_0xbf12e8,_0x56ffcd);})['catch'](()=>{}),Vi['set'](_0xe29ee1,_0x56ffcd),_0xe29ee1;}function Bc(_0x2bf008){if(_i['has'](_0x2bf008))return;const _0x35d0d2=new Promise((_0x3b1963,_0x4274f9)=>{const _0x2909d9=()=>{_0x2bf008['removeEventListener']('complete',_0x5298c2),_0x2bf008['removeEventListener']('error',_0x1d1dde),_0x2bf008['removeEventListener']('abort',_0x1d1dde);},_0x5298c2=()=>{_0x3b1963(),_0x2909d9();},_0x1d1dde=()=>{_0x4274f9(_0x2bf008['error']||new DOMException('AbortError','AbortError')),_0x2909d9();};_0x2bf008['addEventListener']('complete',_0x5298c2),_0x2bf008['addEventListener']('error',_0x1d1dde),_0x2bf008['addEventListener']('abort',_0x1d1dde);});_i['set'](_0x2bf008,_0x35d0d2);}let gi={'get'(_0xf52c64,_0x4aa951,_0x330825){if(_0xf52c64 instanceof IDBTransaction){if(_0x4aa951==='done')return _i['get'](_0xf52c64);if(_0x4aa951==='objectStoreNames')return _0xf52c64['objectStoreNames']||Xr['get'](_0xf52c64);if(_0x4aa951==='store')return _0x330825['objectStoreNames'][0x1]?void 0x0:_0x330825['objectStore'](_0x330825['objectStoreNames'][0x0]);}return ge(_0xf52c64[_0x4aa951]);},'set'(_0x18b028,_0x25e121,_0x3aecbf){return _0x18b028[_0x25e121]=_0x3aecbf,!0x0;},'has'(_0x5f4983,_0xf87c93){return _0x5f4983 instanceof IDBTransaction&&(_0xf87c93==='done'||_0xf87c93==='store')?!0x0:_0xf87c93 in _0x5f4983;}};function Vc(_0x412114){gi=_0x412114(gi);}function Hc(_0x3fe16f){return _0x3fe16f===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x63801,..._0x4b889f){const _0x3e710b=_0x3fe16f['call'](ii(this),_0x63801,..._0x4b889f);return Xr['set'](_0x3e710b,_0x63801['sort']?_0x63801['sort']():[_0x63801]),ge(_0x3e710b);}:Uc()['includes'](_0x3fe16f)?function(..._0x21a694){return _0x3fe16f['apply'](ii(this),_0x21a694),ge(Jr['get'](this));}:function(..._0x11debc){return ge(_0x3fe16f['apply'](ii(this),_0x11debc));};}function $c(_0x338f8b){return typeof _0x338f8b=='function'?Hc(_0x338f8b):(_0x338f8b instanceof IDBTransaction&&Bc(_0x338f8b),xc(_0x338f8b,Fc())?new Proxy(_0x338f8b,gi):_0x338f8b);}function ge(_0x43c9e4){if(_0x43c9e4 instanceof IDBRequest)return Wc(_0x43c9e4);if(ni['has'](_0x43c9e4))return ni['get'](_0x43c9e4);const _0xde52fc=$c(_0x43c9e4);return _0xde52fc!==_0x43c9e4&&(ni['set'](_0x43c9e4,_0xde52fc),Vi['set'](_0xde52fc,_0x43c9e4)),_0xde52fc;}const ii=_0x1631e0=>Vi['get'](_0x1631e0);function Gc(_0x169b16,_0x345acf,{blocked:_0x48a447,upgrade:_0x361d31,blocking:_0x4bddc0,terminated:_0x13b08b}={}){const _0xbb9e2c=indexedDB['open'](_0x169b16,_0x345acf),_0x9951c7=ge(_0xbb9e2c);return _0x361d31&&_0xbb9e2c['addEventListener']('upgradeneeded',_0x217ac1=>{_0x361d31(ge(_0xbb9e2c['result']),_0x217ac1['oldVersion'],_0x217ac1['newVersion'],ge(_0xbb9e2c['transaction']),_0x217ac1);}),_0x48a447&&_0xbb9e2c['addEventListener']('blocked',_0x8a8ed4=>_0x48a447(_0x8a8ed4['oldVersion'],_0x8a8ed4['newVersion'],_0x8a8ed4)),_0x9951c7['then'](_0x12fcd9=>{_0x13b08b&&_0x12fcd9['addEventListener']('close',()=>_0x13b08b()),_0x4bddc0&&_0x12fcd9['addEventListener']('versionchange',_0x405e77=>_0x4bddc0(_0x405e77['oldVersion'],_0x405e77['newVersion'],_0x405e77));})['catch'](()=>{}),_0x9951c7;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x28fb86,_0x5e3871){if(!(_0x28fb86 instanceof IDBDatabase&&!(_0x5e3871 in _0x28fb86)&&typeof _0x5e3871=='string'))return;if(si['get'](_0x5e3871))return si['get'](_0x5e3871);const _0x21c02e=_0x5e3871['replace'](/FromIndex$/,''),_0x3e01ad=_0x5e3871!==_0x21c02e,_0x180c77=zc['includes'](_0x21c02e);if(!(_0x21c02e in(_0x3e01ad?IDBIndex:IDBObjectStore)['prototype'])||!(_0x180c77||qc['includes'](_0x21c02e)))return;const _0x529cc9=async function(_0xe7f337,..._0x25f8d2){const _0x24e3c3=this['transaction'](_0xe7f337,_0x180c77?'readwrite':'readonly');let _0x45e818=_0x24e3c3['store'];return _0x3e01ad&&(_0x45e818=_0x45e818['index'](_0x25f8d2['shift']())),(await Promise['all']([_0x45e818[_0x21c02e](..._0x25f8d2),_0x180c77&&_0x24e3c3['done']]))[0x0];};return si['set'](_0x5e3871,_0x529cc9),_0x529cc9;}Vc(_0x535102=>({..._0x535102,'get':(_0x367e0a,_0x2473fd,_0x34af7e)=>Ms(_0x367e0a,_0x2473fd)||_0x535102['get'](_0x367e0a,_0x2473fd,_0x34af7e),'has':(_0x590a11,_0x267383)=>!!Ms(_0x590a11,_0x267383)||_0x535102['has'](_0x590a11,_0x267383)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x343bbe){this['container']=_0x343bbe;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x53a2c8=>{if(Kc(_0x53a2c8)){const _0x2c3606=_0x53a2c8['getImmediate']();return _0x2c3606['library']+'/'+_0x2c3606['version'];}else return null;})['filter'](_0x2bd497=>_0x2bd497)['join']('\x20');}}function Kc(_0x32da11){const _0x2a7449=_0x32da11['getComponent']();return(_0x2a7449==null?void 0x0:_0x2a7449['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x2791e4,_0x26cd9f){try{_0x2791e4['container']['addComponent'](_0x26cd9f);}catch(_0xe5548b){oe['debug']('Component\x20'+_0x26cd9f['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x2791e4['name'],_0xe5548b);}}function st(_0x470c6c){const _0x483760=_0x470c6c['name'];if(Ei['has'](_0x483760))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x483760+'.'),!0x1;Ei['set'](_0x483760,_0x470c6c);for(const _0x2f9790 of Ue['values']())xs(_0x2f9790,_0x470c6c);for(const _0x12a678 of vi['values']())xs(_0x12a678,_0x470c6c);return!0x0;}function Hi(_0x1f03a9,_0x5e56b9){const _0x20608e=_0x1f03a9['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x20608e&&_0x20608e['triggerHeartbeat'](),_0x1f03a9['container']['getProvider'](_0x5e56b9);}function $(_0x3d7992){return _0x3d7992==null?!0x1:_0x3d7992['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x5e8081,_0x48e5cf,_0x53c3f3){this['_isDeleted']=!0x1,this['_options']={..._0x5e8081},this['_config']={..._0x48e5cf},this['_name']=_0x48e5cf['name'],this['_automaticDataCollectionEnabled']=_0x48e5cf['automaticDataCollectionEnabled'],this['_container']=_0x53c3f3,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x470445){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x470445;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x331bac){this['_isDeleted']=_0x331bac;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x195fa0,_0x27555e={}){let _0x3e38be=_0x195fa0;typeof _0x27555e!='object'&&(_0x27555e={'name':_0x27555e});const _0x117453={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x27555e},_0x4ca893=_0x117453['name'];if(typeof _0x4ca893!='string'||!_0x4ca893)throw me['create']('bad-app-name',{'appName':String(_0x4ca893)});if(_0x3e38be||(_0x3e38be=zr()),!_0x3e38be)throw me['create']('no-options');const _0x2e281b=Ue['get'](_0x4ca893);if(_0x2e281b){if(xe(_0x3e38be,_0x2e281b['options'])&&xe(_0x117453,_0x2e281b['config']))return _0x2e281b;throw me['create']('duplicate-app',{'appName':_0x4ca893});}const _0xa097a1=new Nc(_0x4ca893);for(const _0x3554d6 of Ei['values']())_0xa097a1['addComponent'](_0x3554d6);const _0x556aad=new Tl(_0x3e38be,_0x117453,_0xa097a1);return Ue['set'](_0x4ca893,_0x556aad),_0x556aad;}function Zr(_0x4d70d9=yi){const _0x5f2e2d=Ue['get'](_0x4d70d9);if(!_0x5f2e2d&&_0x4d70d9===yi&&zr())return Sl();if(!_0x5f2e2d)throw me['create']('no-app',{'appName':_0x4d70d9});return _0x5f2e2d;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x5a307f){let _0x4c6cad=!0x1;const _0x2ab19c=_0x5a307f['name'];Ue['has'](_0x2ab19c)?(_0x4c6cad=!0x0,Ue['delete'](_0x2ab19c)):vi['has'](_0x2ab19c)&&_0x5a307f['decRefCount']()<=0x0&&(vi['delete'](_0x2ab19c),_0x4c6cad=!0x0),_0x4c6cad&&(await Promise['all'](_0x5a307f['container']['getProviders']()['map'](_0x4a2add=>_0x4a2add['delete']())),_0x5a307f['isDeleted']=!0x0);}function ye(_0x515a96,_0x5e5f03,_0x141a71){let _0x4247fd=wl[_0x515a96]??_0x515a96;_0x141a71&&(_0x4247fd+='-'+_0x141a71);const _0x57f177=_0x4247fd['match'](/\s|\//),_0x17d37a=_0x5e5f03['match'](/\s|\//);if(_0x57f177||_0x17d37a){const _0x401998=['Unable\x20to\x20register\x20library\x20\x22'+_0x4247fd+'\x22\x20with\x20version\x20\x22'+_0x5e5f03+'\x22:'];_0x57f177&&_0x401998['push']('library\x20name\x20\x22'+_0x4247fd+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x57f177&&_0x17d37a&&_0x401998['push']('and'),_0x17d37a&&_0x401998['push']('version\x20name\x20\x22'+_0x5e5f03+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x401998['join']('\x20'));return;}st(new Fe(_0x4247fd+'-version',()=>({'library':_0x4247fd,'version':_0x5e5f03}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x1e87a2,_0x4a1c16)=>{switch(_0x4a1c16){case 0x0:try{_0x1e87a2['createObjectStore'](Ot);}catch(_0x2381a8){console['warn'](_0x2381a8);}}}})['catch'](_0x2ab9c2=>{throw me['create']('idb-open',{'originalErrorMessage':_0x2ab9c2['message']});})),ri;}async function Al(_0x579117){try{const _0x4a2894=(await eo())['transaction'](Ot),_0x5f3001=await _0x4a2894['objectStore'](Ot)['get'](to(_0x579117));return await _0x4a2894['done'],_0x5f3001;}catch(_0x353c9f){if(_0x353c9f instanceof Re)oe['warn'](_0x353c9f['message']);else{const _0x304d66=me['create']('idb-get',{'originalErrorMessage':_0x353c9f==null?void 0x0:_0x353c9f['message']});oe['warn'](_0x304d66['message']);}}}async function Fs(_0x25c1de,_0x3e32be){try{const _0x14e0eb=(await eo())['transaction'](Ot,'readwrite');await _0x14e0eb['objectStore'](Ot)['put'](_0x3e32be,to(_0x25c1de)),await _0x14e0eb['done'];}catch(_0x4e41d8){if(_0x4e41d8 instanceof Re)oe['warn'](_0x4e41d8['message']);else{const _0x35f917=me['create']('idb-set',{'originalErrorMessage':_0x4e41d8==null?void 0x0:_0x4e41d8['message']});oe['warn'](_0x35f917['message']);}}}function to(_0x5f3fcc){return _0x5f3fcc['name']+'!'+_0x5f3fcc['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x44c086){this['container']=_0x44c086,this['_heartbeatsCache']=null;const _0x59e0f7=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x59e0f7),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0xf3c390=>(this['_heartbeatsCache']=_0xf3c390,_0xf3c390));}async['triggerHeartbeat'](){var _0x5ea5c9,_0x4ec8b8;try{const _0x518668=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x3d857a=Us();if(((_0x5ea5c9=this['_heartbeatsCache'])==null?void 0x0:_0x5ea5c9['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x4ec8b8=this['_heartbeatsCache'])==null?void 0x0:_0x4ec8b8['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x3d857a||this['_heartbeatsCache']['heartbeats']['some'](_0x367bd4=>_0x367bd4['date']===_0x3d857a))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x3d857a,'agent':_0x518668}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x2af4fb=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x2af4fb,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x214f78){oe['warn'](_0x214f78);}}async['getHeartbeatsHeader'](){var _0x3c71c4;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x3c71c4=this['_heartbeatsCache'])==null?void 0x0:_0x3c71c4['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x2f9e2f=Us(),{heartbeatsToSend:_0x1f0abc,unsentEntries:_0x302e8e}=Ol(this['_heartbeatsCache']['heartbeats']),_0xed33e6=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x1f0abc}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x2f9e2f,_0x302e8e['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x302e8e,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0xed33e6;}catch(_0x167e6f){return oe['warn'](_0x167e6f),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x1c4678,_0x122bdf=kl){const _0x104b9e=[];let _0x5257e=_0x1c4678['slice']();for(const _0x4d1e86 of _0x1c4678){const _0x582985=_0x104b9e['find'](_0x2ada0b=>_0x2ada0b['agent']===_0x4d1e86['agent']);if(_0x582985){if(_0x582985['dates']['push'](_0x4d1e86['date']),Ws(_0x104b9e)>_0x122bdf){_0x582985['dates']['pop']();break;}}else{if(_0x104b9e['push']({'agent':_0x4d1e86['agent'],'dates':[_0x4d1e86['date']]}),Ws(_0x104b9e)>_0x122bdf){_0x104b9e['pop']();break;}}_0x5257e=_0x5257e['slice'](0x1);}return{'heartbeatsToSend':_0x104b9e,'unsentEntries':_0x5257e};}class Dl{constructor(_0x12eb83){this['app']=_0x12eb83,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0xab8786=await Al(this['app']);return _0xab8786!=null&&_0xab8786['heartbeats']?_0xab8786:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x417eb0){if(await this['_canUseIndexedDBPromise']){const _0xc401a1=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x417eb0['lastSentHeartbeatDate']??_0xc401a1['lastSentHeartbeatDate'],'heartbeats':_0x417eb0['heartbeats']});}else return;}async['add'](_0x356997){if(await this['_canUseIndexedDBPromise']){const _0x20ca16=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x356997['lastSentHeartbeatDate']??_0x20ca16['lastSentHeartbeatDate'],'heartbeats':[..._0x20ca16['heartbeats'],..._0x356997['heartbeats']]});}else return;}}function Ws(_0xa9221){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0xa9221}))['length'];}function Ml(_0x266efe){if(_0x266efe['length']===0x0)return-0x1;let _0x2ccbcb=0x0,_0x2bed49=_0x266efe[0x0]['date'];for(let _0x4a4f42=0x1;_0x4a4f42<_0x266efe['length'];_0x4a4f42++)_0x266efe[_0x4a4f42]['date']<_0x2bed49&&(_0x2bed49=_0x266efe[_0x4a4f42]['date'],_0x2ccbcb=_0x4a4f42);return _0x2ccbcb;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x18a9a7){st(new Fe('platform-logger',_0x1c6151=>new jc(_0x1c6151),'PRIVATE')),st(new Fe('heartbeat',_0x345de8=>new Nl(_0x345de8),'PRIVATE')),ye(mi,Ls,_0x18a9a7),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0xf22c68){no=_0xf22c68;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x2188f8){this['domStorage_']=_0x2188f8,this['prefix_']='firebase:';}['set'](_0x1a595b,_0xd6a35c){_0xd6a35c==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x1a595b)):this['domStorage_']['setItem'](this['prefixedName_'](_0x1a595b),O(_0xd6a35c));}['get'](_0x68e689){const _0x5db880=this['domStorage_']['getItem'](this['prefixedName_'](_0x68e689));return _0x5db880==null?null:Nt(_0x5db880);}['remove'](_0x278b6a){this['domStorage_']['removeItem'](this['prefixedName_'](_0x278b6a));}['prefixedName_'](_0x1f9adc){return this['prefix_']+_0x1f9adc;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x179a15,_0x54dbf6){_0x54dbf6==null?delete this['cache_'][_0x179a15]:this['cache_'][_0x179a15]=_0x54dbf6;}['get'](_0x22a2f1){return Q(this['cache_'],_0x22a2f1)?this['cache_'][_0x22a2f1]:null;}['remove'](_0x397f0e){delete this['cache_'][_0x397f0e];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x1dbd50){try{if(typeof window<'u'&&typeof window[_0x1dbd50]<'u'){const _0x4f6f9e=window[_0x1dbd50];return _0x4f6f9e['setItem']('firebase:sentinel','cache'),_0x4f6f9e['removeItem']('firebase:sentinel'),new Wl(_0x4f6f9e);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x4ddc56=0x1;return function(){return _0x4ddc56++;};}()),ro=function(_0x251fe7){const _0x1590ce=Rc(_0x251fe7),_0x4ccf32=new Cc();_0x4ccf32['update'](_0x1590ce);const _0x3f8b0c=_0x4ccf32['digest']();return Fi['encodeByteArray'](_0x3f8b0c);},zt=function(..._0x5e7524){let _0xf6e4a8='';for(let _0x522e11=0x0;_0x522e11<_0x5e7524['length'];_0x522e11++){const _0x2a7ebf=_0x5e7524[_0x522e11];Array['isArray'](_0x2a7ebf)||_0x2a7ebf&&typeof _0x2a7ebf=='object'&&typeof _0x2a7ebf['length']=='number'?_0xf6e4a8+=zt['apply'](null,_0x2a7ebf):typeof _0x2a7ebf=='object'?_0xf6e4a8+=O(_0x2a7ebf):_0xf6e4a8+=_0x2a7ebf,_0xf6e4a8+='\x20';}return _0xf6e4a8;};let St=null,$s=!0x0;const Hl=function(_0x460dee,_0xa6c667){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x5b471d){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0xdc896c=zt['apply'](null,_0x5b471d);St(_0xdc896c);}},jt=function(_0x1135f7){return function(..._0x1cf482){L(_0x1135f7,..._0x1cf482);};},Ii=function(..._0x16daec){const _0x3fe185='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x16daec);Ze['error'](_0x3fe185);},ae=function(..._0xc2e03d){const _0x46c87d='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0xc2e03d);throw Ze['error'](_0x46c87d),new Error(_0x46c87d);},U=function(..._0x33cecc){const _0x5ec1c8='FIREBASE\x20WARNING:\x20'+zt(..._0x33cecc);Ze['warn'](_0x5ec1c8);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x1d4ab4){return typeof _0x1d4ab4=='number'&&(_0x1d4ab4!==_0x1d4ab4||_0x1d4ab4===Number['POSITIVE_INFINITY']||_0x1d4ab4===Number['NEGATIVE_INFINITY']);},Gl=function(_0x4e4c9b){if(document['readyState']==='complete')_0x4e4c9b();else{let _0xc7c71b=!0x1;const _0x4238c2=function(){if(!document['body']){setTimeout(_0x4238c2,Math['floor'](0xa));return;}_0xc7c71b||(_0xc7c71b=!0x0,_0x4e4c9b());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x4238c2,!0x1),window['addEventListener']('load',_0x4238c2,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x4238c2();}),window['attachEvent']('onload',_0x4238c2));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x34294e,_0x526ba6){if(_0x34294e===_0x526ba6)return 0x0;if(_0x34294e===We||_0x526ba6===we)return-0x1;if(_0x526ba6===We||_0x34294e===we)return 0x1;{const _0xb5ad59=Gs(_0x34294e),_0x17b258=Gs(_0x526ba6);return _0xb5ad59!==null?_0x17b258!==null?_0xb5ad59-_0x17b258===0x0?_0x34294e['length']-_0x526ba6['length']:_0xb5ad59-_0x17b258:-0x1:_0x17b258!==null?0x1:_0x34294e<_0x526ba6?-0x1:0x1;}},ql=function(_0x13ceff,_0x958c9b){return _0x13ceff===_0x958c9b?0x0:_0x13ceff<_0x958c9b?-0x1:0x1;},vt=function(_0x37c06e,_0x487b64){if(_0x487b64&&_0x37c06e in _0x487b64)return _0x487b64[_0x37c06e];throw new Error('Missing\x20required\x20key\x20('+_0x37c06e+')\x20in\x20object:\x20'+O(_0x487b64));},$i=function(_0x1b1d4f){if(typeof _0x1b1d4f!='object'||_0x1b1d4f===null)return O(_0x1b1d4f);const _0x25eaad=[];for(const _0x320c97 in _0x1b1d4f)_0x25eaad['push'](_0x320c97);_0x25eaad['sort']();let _0x12339a='{';for(let _0x522d83=0x0;_0x522d83<_0x25eaad['length'];_0x522d83++)_0x522d83!==0x0&&(_0x12339a+=','),_0x12339a+=O(_0x25eaad[_0x522d83]),_0x12339a+=':',_0x12339a+=$i(_0x1b1d4f[_0x25eaad[_0x522d83]]);return _0x12339a+='}',_0x12339a;},oo=function(_0x20af73,_0x10315d){const _0x441a19=_0x20af73['length'];if(_0x441a19<=_0x10315d)return[_0x20af73];const _0x3a6312=[];for(let _0x5d7c23=0x0;_0x5d7c23<_0x441a19;_0x5d7c23+=_0x10315d)_0x5d7c23+_0x10315d>_0x441a19?_0x3a6312['push'](_0x20af73['substring'](_0x5d7c23,_0x441a19)):_0x3a6312['push'](_0x20af73['substring'](_0x5d7c23,_0x5d7c23+_0x10315d));return _0x3a6312;};function x(_0x47f0a0,_0x48808c){for(const _0x1bfd15 in _0x47f0a0)_0x47f0a0['hasOwnProperty'](_0x1bfd15)&&_0x48808c(_0x1bfd15,_0x47f0a0[_0x1bfd15]);}const ao=function(_0x12a782){f(!xn(_0x12a782),'Invalid\x20JSON\x20number');const _0x477385=0xb,_0x4cf028=0x34,_0x4a1213=(0x1<<_0x477385-0x1)-0x1;let _0x30da96,_0xa734b9,_0xb06e78,_0x382b65,_0x5778a7;_0x12a782===0x0?(_0xa734b9=0x0,_0xb06e78=0x0,_0x30da96=0x1/_0x12a782===-0x1/0x0?0x1:0x0):(_0x30da96=_0x12a782<0x0,_0x12a782=Math['abs'](_0x12a782),_0x12a782>=Math['pow'](0x2,0x1-_0x4a1213)?(_0x382b65=Math['min'](Math['floor'](Math['log'](_0x12a782)/Math['LN2']),_0x4a1213),_0xa734b9=_0x382b65+_0x4a1213,_0xb06e78=Math['round'](_0x12a782*Math['pow'](0x2,_0x4cf028-_0x382b65)-Math['pow'](0x2,_0x4cf028))):(_0xa734b9=0x0,_0xb06e78=Math['round'](_0x12a782/Math['pow'](0x2,0x1-_0x4a1213-_0x4cf028))));const _0x43bcfd=[];for(_0x5778a7=_0x4cf028;_0x5778a7;_0x5778a7-=0x1)_0x43bcfd['push'](_0xb06e78%0x2?0x1:0x0),_0xb06e78=Math['floor'](_0xb06e78/0x2);for(_0x5778a7=_0x477385;_0x5778a7;_0x5778a7-=0x1)_0x43bcfd['push'](_0xa734b9%0x2?0x1:0x0),_0xa734b9=Math['floor'](_0xa734b9/0x2);_0x43bcfd['push'](_0x30da96?0x1:0x0),_0x43bcfd['reverse']();const _0x2b8ee5=_0x43bcfd['join']('');let _0x582aac='';for(_0x5778a7=0x0;_0x5778a7<0x40;_0x5778a7+=0x8){let _0x4ccb6e=parseInt(_0x2b8ee5['substr'](_0x5778a7,0x8),0x2)['toString'](0x10);_0x4ccb6e['length']===0x1&&(_0x4ccb6e='0'+_0x4ccb6e),_0x582aac=_0x582aac+_0x4ccb6e;}return _0x582aac['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x747990,_0x186cee){let _0x41055a='Unknown\x20Error';_0x747990==='too_big'?_0x41055a='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x747990==='permission_denied'?_0x41055a='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x747990==='unavailable'&&(_0x41055a='The\x20service\x20is\x20unavailable');const _0x20e4af=new Error(_0x747990+'\x20at\x20'+_0x186cee['_path']['toString']()+':\x20'+_0x41055a);return _0x20e4af['code']=_0x747990['toUpperCase'](),_0x20e4af;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x1d7395){if(Yl['test'](_0x1d7395)){const _0x40b3d8=Number(_0x1d7395);if(_0x40b3d8>=Ql&&_0x40b3d8<=Jl)return _0x40b3d8;}return null;},ft=function(_0x25b928){try{_0x25b928();}catch(_0x3a8c43){setTimeout(()=>{const _0x340107=_0x3a8c43['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x340107),_0x3a8c43;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x1b9b02,_0x3dca9b){const _0x1186b6=setTimeout(_0x1b9b02,_0x3dca9b);return typeof _0x1186b6=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x1186b6):typeof _0x1186b6=='object'&&_0x1186b6['unref']&&_0x1186b6['unref'](),_0x1186b6;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x12f15f,_0x26a2e4){this['appCheckProvider']=_0x26a2e4,this['appName']=_0x12f15f['name'],$(_0x12f15f)&&_0x12f15f['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x12f15f['settings']['appCheckToken']),this['appCheck']=_0x26a2e4==null?void 0x0:_0x26a2e4['getImmediate']({'optional':!0x0}),this['appCheck']||_0x26a2e4==null||_0x26a2e4['get']()['then'](_0x406bab=>this['appCheck']=_0x406bab);}['getToken'](_0x91327e){if(this['serverAppAppCheckToken']){if(_0x91327e)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x91327e):new Promise((_0x1174e7,_0x57267d)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x91327e)['then'](_0x1174e7,_0x57267d):_0x1174e7(null);},0x0);});}['addTokenChangeListener'](_0x1dc4c2){var _0x227c8d;(_0x227c8d=this['appCheckProvider'])==null||_0x227c8d['get']()['then'](_0x17be0a=>_0x17be0a['addTokenListener'](_0x1dc4c2));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x3b873d,_0x3d6933,_0xeea501){this['appName_']=_0x3b873d,this['firebaseOptions_']=_0x3d6933,this['authProvider_']=_0xeea501,this['auth_']=null,this['auth_']=_0xeea501['getImmediate']({'optional':!0x0}),this['auth_']||_0xeea501['onInit'](_0x30b282=>this['auth_']=_0x30b282);}['getToken'](_0x3283f5){return this['auth_']?this['auth_']['getToken'](_0x3283f5)['catch'](_0x4ed671=>_0x4ed671&&_0x4ed671['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x4ed671)):new Promise((_0x48e1ac,_0x4b5170)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x3283f5)['then'](_0x48e1ac,_0x4b5170):_0x48e1ac(null);},0x0);});}['addTokenChangeListener'](_0xf293da){this['auth_']?this['auth_']['addAuthTokenListener'](_0xf293da):this['authProvider_']['get']()['then'](_0x18754b=>_0x18754b['addAuthTokenListener'](_0xf293da));}['removeTokenChangeListener'](_0x4eee03){this['authProvider_']['get']()['then'](_0x5ceb57=>_0x5ceb57['removeAuthTokenListener'](_0x4eee03));}['notifyForInvalidToken'](){let _0x48cdc4='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x48cdc4+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x48cdc4+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x48cdc4+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x48cdc4);}}class an{constructor(_0x39ec7b){this['accessToken']=_0x39ec7b;}['getToken'](_0x37728a){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x3141b3){_0x3141b3(this['accessToken']);}['removeTokenChangeListener'](_0x518a8e){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x4844c7,_0x5220e7,_0xde1ce1,_0x5eed0f,_0x1c8cbc=!0x1,_0x4a7cd1='',_0x1e13d8=!0x1,_0x2bdb23=!0x1,_0x5eb725=null){this['secure']=_0x5220e7,this['namespace']=_0xde1ce1,this['webSocketOnly']=_0x5eed0f,this['nodeAdmin']=_0x1c8cbc,this['persistenceKey']=_0x4a7cd1,this['includeNamespaceInQueryParams']=_0x1e13d8,this['isUsingEmulator']=_0x2bdb23,this['emulatorOptions']=_0x5eb725,this['_host']=_0x4844c7['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x4844c7)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x170ecc){_0x170ecc!==this['internalHost']&&(this['internalHost']=_0x170ecc,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x58833b=this['toURLString']();return this['persistenceKey']&&(_0x58833b+='<'+this['persistenceKey']+'>'),_0x58833b;}['toURLString'](){const _0x148194=this['secure']?'https://':'http://',_0x50d756=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x148194+this['host']+'/'+_0x50d756;}}function th(_0x45fde8){return _0x45fde8['host']!==_0x45fde8['internalHost']||_0x45fde8['isCustomHost']()||_0x45fde8['includeNamespaceInQueryParams'];}function vo(_0x5d739e,_0x39a5dd,_0x1be1d4){f(typeof _0x39a5dd=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x1be1d4=='object','typeof\x20params\x20must\x20==\x20object');let _0x306022;if(_0x39a5dd===go)_0x306022=(_0x5d739e['secure']?'wss://':'ws://')+_0x5d739e['internalHost']+'/.ws?';else{if(_0x39a5dd===mo)_0x306022=(_0x5d739e['secure']?'https://':'http://')+_0x5d739e['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x39a5dd);}th(_0x5d739e)&&(_0x1be1d4['ns']=_0x5d739e['namespace']);const _0x382ed5=[];return x(_0x1be1d4,(_0x1edff7,_0x38eafa)=>{_0x382ed5['push'](_0x1edff7+'='+_0x38eafa);}),_0x306022+_0x382ed5['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x3fec13,_0x4d4db6=0x1){Q(this['counters_'],_0x3fec13)||(this['counters_'][_0x3fec13]=0x0),this['counters_'][_0x3fec13]+=_0x4d4db6;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x27bd0a){const _0x2718ce=_0x27bd0a['toString']();return oi[_0x2718ce]||(oi[_0x2718ce]=new nh()),oi[_0x2718ce];}function ih(_0x246cf,_0x5062a2){const _0x2fcf9e=_0x246cf['toString']();return ai[_0x2fcf9e]||(ai[_0x2fcf9e]=_0x5062a2()),ai[_0x2fcf9e];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x5e8095){this['onMessage_']=_0x5e8095,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x2178da,_0x30573c){this['closeAfterResponse']=_0x2178da,this['onClose']=_0x30573c,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x2e5d32,_0x2afe9e){for(this['pendingResponses'][_0x2e5d32]=_0x2afe9e;this['pendingResponses'][this['currentResponseNum']];){const _0xd283c1=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x389d6b=0x0;_0x389d6b<_0xd283c1['length'];++_0x389d6b)_0xd283c1[_0x389d6b]&&ft(()=>{this['onMessage_'](_0xd283c1[_0x389d6b]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x321dd8,_0x261fc4,_0x5d9d8d,_0xccbb3c,_0x3b9460,_0x23cfa6,_0x58218a){this['connId']=_0x321dd8,this['repoInfo']=_0x261fc4,this['applicationId']=_0x5d9d8d,this['appCheckToken']=_0xccbb3c,this['authToken']=_0x3b9460,this['transportSessionId']=_0x23cfa6,this['lastSessionId']=_0x58218a,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x321dd8),this['stats_']=qi(_0x261fc4),this['urlFn']=_0x8f5cf2=>(this['appCheckToken']&&(_0x8f5cf2[wi]=this['appCheckToken']),vo(_0x261fc4,mo,_0x8f5cf2));}['open'](_0x2b2768,_0x3f61e8){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x3f61e8,this['myPacketOrderer']=new sh(_0x2b2768),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x37021f)=>{const [_0x2e79fd,_0x1aad86,_0x38077f,_0xb2e6e7,_0x5150b1]=_0x37021f;if(this['incrementIncomingBytes_'](_0x37021f),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x2e79fd===qs)this['id']=_0x1aad86,this['password']=_0x38077f;else{if(_0x2e79fd===rh)_0x1aad86?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x1aad86,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x2e79fd);}}},(..._0x109707)=>{const [_0x27eef1,_0x40123e]=_0x109707;this['incrementIncomingBytes_'](_0x109707),this['myPacketOrderer']['handleResponse'](_0x27eef1,_0x40123e);},()=>{this['onClosed_']();},this['urlFn']);const _0x13264f={};_0x13264f[qs]='t',_0x13264f[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x13264f[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x13264f[co]=Gi,this['transportSessionId']&&(_0x13264f[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x13264f[po]=this['lastSessionId']),this['applicationId']&&(_0x13264f[_o]=this['applicationId']),this['appCheckToken']&&(_0x13264f[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x13264f[ho]=uo);const _0x4f176a=this['urlFn'](_0x13264f);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x4f176a),this['scriptTagHolder']['addTag'](_0x4f176a,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x5a2c3f){const _0x95371a=O(_0x5a2c3f);this['bytesSent']+=_0x95371a['length'],this['stats_']['incrementCounter']('bytes_sent',_0x95371a['length']);const _0x173904=$r(_0x95371a),_0x5ddd56=oo(_0x173904,fh);for(let _0x41d0ab=0x0;_0x41d0ab<_0x5ddd56['length'];_0x41d0ab++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x5ddd56['length'],_0x5ddd56[_0x41d0ab]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x188187,_0x3d6161){this['myDisconnFrame']=document['createElement']('iframe');const _0x2e395a={};_0x2e395a[dh]='t',_0x2e395a[Eo]=_0x188187,_0x2e395a[Io]=_0x3d6161,this['myDisconnFrame']['src']=this['urlFn'](_0x2e395a),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x5977ca){const _0xb393cb=O(_0x5977ca)['length'];this['bytesReceived']+=_0xb393cb,this['stats_']['incrementCounter']('bytes_received',_0xb393cb);}}class zi{constructor(_0xbb50c7,_0x4bfff5,_0x3dffc0,_0x2e2a14){this['onDisconnect']=_0x3dffc0,this['urlFn']=_0x2e2a14,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0xbb50c7,window[ah+this['uniqueCallbackIdentifier']]=_0x4bfff5,this['myIFrame']=zi['createIFrame_']();let _0x3ddeca='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x3ddeca='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x50f22d='<html><body>'+_0x3ddeca+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x50f22d),this['myIFrame']['doc']['close']();}catch(_0xb83814){L('frame\x20writing\x20exception'),_0xb83814['stack']&&L(_0xb83814['stack']),L(_0xb83814);}}}static['createIFrame_'](){const _0x3fe161=document['createElement']('iframe');if(_0x3fe161['style']['display']='none',document['body']){document['body']['appendChild'](_0x3fe161);try{_0x3fe161['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x739563=document['domain'];_0x3fe161['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x739563+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x3fe161['contentDocument']?_0x3fe161['doc']=_0x3fe161['contentDocument']:_0x3fe161['contentWindow']?_0x3fe161['doc']=_0x3fe161['contentWindow']['document']:_0x3fe161['document']&&(_0x3fe161['doc']=_0x3fe161['document']),_0x3fe161;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x5b35f5=this['onDisconnect'];_0x5b35f5&&(this['onDisconnect']=null,_0x5b35f5());}['startLongPoll'](_0x4a624d,_0x2d3444){for(this['myID']=_0x4a624d,this['myPW']=_0x2d3444,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x1e07ce={};_0x1e07ce[Eo]=this['myID'],_0x1e07ce[Io]=this['myPW'],_0x1e07ce[wo]=this['currentSerial'];let _0x3faf3d=this['urlFn'](_0x1e07ce),_0x1ff604='',_0x30fc5a=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x1ff604['length']<=Co;){const _0x3c9f40=this['pendingSegs']['shift']();_0x1ff604=_0x1ff604+'&'+lh+_0x30fc5a+'='+_0x3c9f40['seg']+'&'+hh+_0x30fc5a+'='+_0x3c9f40['ts']+'&'+uh+_0x30fc5a+'='+_0x3c9f40['d'],_0x30fc5a++;}return _0x3faf3d=_0x3faf3d+_0x1ff604,this['addLongPollTag_'](_0x3faf3d,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x346952,_0x4aeebd,_0x41a40e){this['pendingSegs']['push']({'seg':_0x346952,'ts':_0x4aeebd,'d':_0x41a40e}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0xdd5a0f,_0xcc26ed){this['outstandingRequests']['add'](_0xcc26ed);const _0x1136fc=()=>{this['outstandingRequests']['delete'](_0xcc26ed),this['newRequest_']();},_0x3f45e2=setTimeout(_0x1136fc,Math['floor'](ph)),_0x331bde=()=>{clearTimeout(_0x3f45e2),_0x1136fc();};this['addTag'](_0xdd5a0f,_0x331bde);}['addTag'](_0x2ac22a,_0xbe2294){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x56f308=this['myIFrame']['doc']['createElement']('script');_0x56f308['type']='text/javascript',_0x56f308['async']=!0x0,_0x56f308['src']=_0x2ac22a,_0x56f308['onload']=_0x56f308['onreadystatechange']=function(){const _0x37779d=_0x56f308['readyState'];(!_0x37779d||_0x37779d==='loaded'||_0x37779d==='complete')&&(_0x56f308['onload']=_0x56f308['onreadystatechange']=null,_0x56f308['parentNode']&&_0x56f308['parentNode']['removeChild'](_0x56f308),_0xbe2294());},_0x56f308['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x2ac22a),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x56f308);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x45db90,_0x1e4779,_0x3e8210,_0x2664c9,_0x20c29e,_0x163c61,_0x2e2b19){this['connId']=_0x45db90,this['applicationId']=_0x3e8210,this['appCheckToken']=_0x2664c9,this['authToken']=_0x20c29e,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x1e4779),this['connURL']=q['connectionURL_'](_0x1e4779,_0x163c61,_0x2e2b19,_0x2664c9,_0x3e8210),this['nodeAdmin']=_0x1e4779['nodeAdmin'];}static['connectionURL_'](_0xeb0e7f,_0x5e3a7a,_0x531d8a,_0x4fae7d,_0x11cf04){const _0x1c3793={};return _0x1c3793[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x1c3793[ho]=uo),_0x5e3a7a&&(_0x1c3793[lo]=_0x5e3a7a),_0x531d8a&&(_0x1c3793[po]=_0x531d8a),_0x4fae7d&&(_0x1c3793[wi]=_0x4fae7d),_0x11cf04&&(_0x1c3793[_o]=_0x11cf04),vo(_0xeb0e7f,go,_0x1c3793);}['open'](_0x2051a7,_0x4eaa39){this['onDisconnect']=_0x4eaa39,this['onMessage']=_0x2051a7,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x34bd7f;_c(),this['mySock']=new gn(this['connURL'],[],_0x34bd7f);}catch(_0x3043e7){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x9e8636=_0x3043e7['message']||_0x3043e7['data'];_0x9e8636&&this['log_'](_0x9e8636),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x33145f=>{this['handleIncomingFrame'](_0x33145f);},this['mySock']['onerror']=_0x4c7012=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0xf76f76=_0x4c7012['message']||_0x4c7012['data'];_0xf76f76&&this['log_'](_0xf76f76),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0xa236c1=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0xae3041=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x157daf=navigator['userAgent']['match'](_0xae3041);_0x157daf&&_0x157daf['length']>0x1&&parseFloat(_0x157daf[0x1])<4.4&&(_0xa236c1=!0x0);}return!_0xa236c1&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0xc4fd74){if(this['frames']['push'](_0xc4fd74),this['frames']['length']===this['totalFrames']){const _0x3fed58=this['frames']['join']('');this['frames']=null;const _0x1e64f5=Nt(_0x3fed58);this['onMessage'](_0x1e64f5);}}['handleNewFrameCount_'](_0x4fbca8){this['totalFrames']=_0x4fbca8,this['frames']=[];}['extractFrameCount_'](_0x129223){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x129223['length']<=0x6){const _0x3c9eca=Number(_0x129223);if(!isNaN(_0x3c9eca))return this['handleNewFrameCount_'](_0x3c9eca),null;}return this['handleNewFrameCount_'](0x1),_0x129223;}['handleIncomingFrame'](_0x2029f5){if(this['mySock']===null)return;const _0x5c620d=_0x2029f5['data'];if(this['bytesReceived']+=_0x5c620d['length'],this['stats_']['incrementCounter']('bytes_received',_0x5c620d['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x5c620d);else{const _0x1de3be=this['extractFrameCount_'](_0x5c620d);_0x1de3be!==null&&this['appendFrame_'](_0x1de3be);}}['send'](_0x305dd2){this['resetKeepAlive']();const _0xd06b41=O(_0x305dd2);this['bytesSent']+=_0xd06b41['length'],this['stats_']['incrementCounter']('bytes_sent',_0xd06b41['length']);const _0x2262ef=oo(_0xd06b41,gh);_0x2262ef['length']>0x1&&this['sendString_'](String(_0x2262ef['length']));for(let _0x44a73f=0x0;_0x44a73f<_0x2262ef['length'];_0x44a73f++)this['sendString_'](_0x2262ef[_0x44a73f]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x14a532){try{this['mySock']['send'](_0x14a532);}catch(_0x2d336a){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x2d336a['message']||_0x2d336a['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x35c273){this['initTransports_'](_0x35c273);}['initTransports_'](_0x538b9b){const _0x1d8221=q&&q['isAvailable']();let _0x184019=_0x1d8221&&!q['previouslyFailed']();if(_0x538b9b['webSocketOnly']&&(_0x1d8221||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x184019=!0x0),_0x184019)this['transports_']=[q];else{const _0xe9a3cd=this['transports_']=[];for(const _0x1f526a of Dt['ALL_TRANSPORTS'])_0x1f526a&&_0x1f526a['isAvailable']()&&_0xe9a3cd['push'](_0x1f526a);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x41e709,_0x3ea03c,_0x5e851e,_0x205252,_0x90f22a,_0xabd571,_0x2b4eb8,_0x3aecf2,_0x13c0e5,_0x429c99){this['id']=_0x41e709,this['repoInfo_']=_0x3ea03c,this['applicationId_']=_0x5e851e,this['appCheckToken_']=_0x205252,this['authToken_']=_0x90f22a,this['onMessage_']=_0xabd571,this['onReady_']=_0x2b4eb8,this['onDisconnect_']=_0x3aecf2,this['onKill_']=_0x13c0e5,this['lastSessionId']=_0x429c99,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x3ea03c),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x461113=this['transportManager_']['initialTransport']();this['conn_']=new _0x461113(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x461113['responsesRequiredToBeHealthy']||0x0;const _0x3c6cac=this['connReceiver_'](this['conn_']),_0x251e8f=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x3c6cac,_0x251e8f);},Math['floor'](0x0));const _0x298de3=_0x461113['healthyTimeout']||0x0;_0x298de3>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x298de3)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x14b62){return _0x162bb4=>{_0x14b62===this['conn_']?this['onConnectionLost_'](_0x162bb4):_0x14b62===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x2b4b00){return _0x438b7e=>{this['state_']!==0x2&&(_0x2b4b00===this['rx_']?this['onPrimaryMessageReceived_'](_0x438b7e):_0x2b4b00===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x438b7e):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x90d194){const _0x2d6a0b={'t':'d','d':_0x90d194};this['sendData_'](_0x2d6a0b);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x47eace){if(ci in _0x47eace){const _0x5ccb65=_0x47eace[ci];_0x5ccb65===Ys?this['upgradeIfSecondaryHealthy_']():_0x5ccb65===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x5ccb65===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x434212){const _0x344748=vt('t',_0x434212),_0x10b93f=vt('d',_0x434212);if(_0x344748==='c')this['onSecondaryControl_'](_0x10b93f);else{if(_0x344748==='d')this['pendingDataMessages']['push'](_0x10b93f);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x344748);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x35e185){const _0x27f263=vt('t',_0x35e185),_0x66e68a=vt('d',_0x35e185);_0x27f263==='c'?this['onControl_'](_0x66e68a):_0x27f263==='d'&&this['onDataMessage_'](_0x66e68a);}['onDataMessage_'](_0x3d8f0d){this['onPrimaryResponse_'](),this['onMessage_'](_0x3d8f0d);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x1f448f){const _0x3dae7a=vt(ci,_0x1f448f);if(zs in _0x1f448f){const _0x7a6647=_0x1f448f[zs];if(_0x3dae7a===Th){const _0xcb6a94={..._0x7a6647};this['repoInfo_']['isUsingEmulator']&&(_0xcb6a94['h']=this['repoInfo_']['host']),this['onHandshake_'](_0xcb6a94);}else{if(_0x3dae7a===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x16db15=0x0;_0x16db15<this['pendingDataMessages']['length'];++_0x16db15)this['onDataMessage_'](this['pendingDataMessages'][_0x16db15]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x3dae7a===wh?this['onConnectionShutdown_'](_0x7a6647):_0x3dae7a===js?this['onReset_'](_0x7a6647):_0x3dae7a===Ch?Ii('Server\x20Error:\x20'+_0x7a6647):_0x3dae7a===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x3dae7a);}}}['onHandshake_'](_0x493d38){const _0x550ee4=_0x493d38['ts'],_0x551bf0=_0x493d38['v'],_0x92c3a9=_0x493d38['h'];this['sessionId']=_0x493d38['s'],this['repoInfo_']['host']=_0x92c3a9,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x550ee4),Gi!==_0x551bf0&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x116688=this['transportManager_']['upgradeTransport']();_0x116688&&this['startUpgrade_'](_0x116688);}['startUpgrade_'](_0x103a72){this['secondaryConn_']=new _0x103a72(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x103a72['responsesRequiredToBeHealthy']||0x0;const _0x3c428b=this['connReceiver_'](this['secondaryConn_']),_0x35ec58=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x3c428b,_0x35ec58),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x275267){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x275267),this['repoInfo_']['host']=_0x275267,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x28d7c9,_0x2a8c8d){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x28d7c9,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x2a8c8d,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x2baf48=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x2baf48||this['rx_']===_0x2baf48)&&this['close']();}['onConnectionLost_'](_0xeccefa){this['conn_']=null,!_0xeccefa&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x37cc9c){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x37cc9c),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x40fab7){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x40fab7);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x187aeb,_0x26f388,_0x3aed1a,_0x9a277c){}['merge'](_0x3c607f,_0x2e2c90,_0x12eea0,_0x385f74){}['refreshAuthToken'](_0x1d47a1){}['refreshAppCheckToken'](_0x353079){}['onDisconnectPut'](_0x2710e0,_0x2358a3,_0x3e3ee7){}['onDisconnectMerge'](_0x125923,_0x3045f7,_0x285e65){}['onDisconnectCancel'](_0xa3ab8d,_0x41eda4){}['reportStats'](_0x4a3ad5){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0xf0c092){this['allowedEvents_']=_0xf0c092,this['listeners_']={},f(Array['isArray'](_0xf0c092)&&_0xf0c092['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x1ce9db,..._0x193c38){if(Array['isArray'](this['listeners_'][_0x1ce9db])){const _0x231627=[...this['listeners_'][_0x1ce9db]];for(let _0x496442=0x0;_0x496442<_0x231627['length'];_0x496442++)_0x231627[_0x496442]['callback']['apply'](_0x231627[_0x496442]['context'],_0x193c38);}}['on'](_0x17a00b,_0x12a8ba,_0x281b08){this['validateEventType_'](_0x17a00b),this['listeners_'][_0x17a00b]=this['listeners_'][_0x17a00b]||[],this['listeners_'][_0x17a00b]['push']({'callback':_0x12a8ba,'context':_0x281b08});const _0x3558fe=this['getInitialEvent'](_0x17a00b);_0x3558fe&&_0x12a8ba['apply'](_0x281b08,_0x3558fe);}['off'](_0x321705,_0x11624a,_0xd6cdf5){this['validateEventType_'](_0x321705);const _0x3dd50c=this['listeners_'][_0x321705]||[];for(let _0x245de3=0x0;_0x245de3<_0x3dd50c['length'];_0x245de3++)if(_0x3dd50c[_0x245de3]['callback']===_0x11624a&&(!_0xd6cdf5||_0xd6cdf5===_0x3dd50c[_0x245de3]['context'])){_0x3dd50c['splice'](_0x245de3,0x1);return;}}['validateEventType_'](_0x16e3a0){f(this['allowedEvents_']['find'](_0x45ffc6=>_0x45ffc6===_0x16e3a0),'Unknown\x20event:\x20'+_0x16e3a0);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x581671){return f(_0x581671==='online','Unknown\x20event\x20type:\x20'+_0x581671),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x1ac078,_0x7b993a){if(_0x7b993a===void 0x0){this['pieces_']=_0x1ac078['split']('/');let _0x1f43e6=0x0;for(let _0x4c4889=0x0;_0x4c4889<this['pieces_']['length'];_0x4c4889++)this['pieces_'][_0x4c4889]['length']>0x0&&(this['pieces_'][_0x1f43e6]=this['pieces_'][_0x4c4889],_0x1f43e6++);this['pieces_']['length']=_0x1f43e6,this['pieceNum_']=0x0;}else this['pieces_']=_0x1ac078,this['pieceNum_']=_0x7b993a;}['toString'](){let _0xdc45c9='';for(let _0x4effeb=this['pieceNum_'];_0x4effeb<this['pieces_']['length'];_0x4effeb++)this['pieces_'][_0x4effeb]!==''&&(_0xdc45c9+='/'+this['pieces_'][_0x4effeb]);return _0xdc45c9||'/';}}function w(){return new C('');}function y(_0x20e1a2){return _0x20e1a2['pieceNum_']>=_0x20e1a2['pieces_']['length']?null:_0x20e1a2['pieces_'][_0x20e1a2['pieceNum_']];}function Ce(_0x181248){return _0x181248['pieces_']['length']-_0x181248['pieceNum_'];}function S(_0x5691eb){let _0x45b604=_0x5691eb['pieceNum_'];return _0x45b604<_0x5691eb['pieces_']['length']&&_0x45b604++,new C(_0x5691eb['pieces_'],_0x45b604);}function ji(_0x560536){return _0x560536['pieceNum_']<_0x560536['pieces_']['length']?_0x560536['pieces_'][_0x560536['pieces_']['length']-0x1]:null;}function bh(_0x5c21df){let _0x56818e='';for(let _0x50d108=_0x5c21df['pieceNum_'];_0x50d108<_0x5c21df['pieces_']['length'];_0x50d108++)_0x5c21df['pieces_'][_0x50d108]!==''&&(_0x56818e+='/'+encodeURIComponent(String(_0x5c21df['pieces_'][_0x50d108])));return _0x56818e||'/';}function Mt(_0xe04204,_0x415c89=0x0){return _0xe04204['pieces_']['slice'](_0xe04204['pieceNum_']+_0x415c89);}function Ro(_0x39097b){if(_0x39097b['pieceNum_']>=_0x39097b['pieces_']['length'])return null;const _0x3819fd=[];for(let _0x2767a5=_0x39097b['pieceNum_'];_0x2767a5<_0x39097b['pieces_']['length']-0x1;_0x2767a5++)_0x3819fd['push'](_0x39097b['pieces_'][_0x2767a5]);return new C(_0x3819fd,0x0);}function k(_0x2166f6,_0x5b3d9b){const _0x28ec88=[];for(let _0x5ac341=_0x2166f6['pieceNum_'];_0x5ac341<_0x2166f6['pieces_']['length'];_0x5ac341++)_0x28ec88['push'](_0x2166f6['pieces_'][_0x5ac341]);if(_0x5b3d9b instanceof C){for(let _0x4ddb37=_0x5b3d9b['pieceNum_'];_0x4ddb37<_0x5b3d9b['pieces_']['length'];_0x4ddb37++)_0x28ec88['push'](_0x5b3d9b['pieces_'][_0x4ddb37]);}else{const _0x3baf22=_0x5b3d9b['split']('/');for(let _0x590750=0x0;_0x590750<_0x3baf22['length'];_0x590750++)_0x3baf22[_0x590750]['length']>0x0&&_0x28ec88['push'](_0x3baf22[_0x590750]);}return new C(_0x28ec88,0x0);}function v(_0xf7d2fb){return _0xf7d2fb['pieceNum_']>=_0xf7d2fb['pieces_']['length'];}function F(_0x2eb6d2,_0x36760f){const _0x2eb20f=y(_0x2eb6d2),_0x5c1bd4=y(_0x36760f);if(_0x2eb20f===null)return _0x36760f;if(_0x2eb20f===_0x5c1bd4)return F(S(_0x2eb6d2),S(_0x36760f));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x36760f+')\x20is\x20not\x20within\x20outerPath\x20('+_0x2eb6d2+')');}function Rh(_0x3c8190,_0x4e9cb4){const _0x5b4207=Mt(_0x3c8190,0x0),_0x3e90b1=Mt(_0x4e9cb4,0x0);for(let _0x44e34b=0x0;_0x44e34b<_0x5b4207['length']&&_0x44e34b<_0x3e90b1['length'];_0x44e34b++){const _0x379072=qe(_0x5b4207[_0x44e34b],_0x3e90b1[_0x44e34b]);if(_0x379072!==0x0)return _0x379072;}return _0x5b4207['length']===_0x3e90b1['length']?0x0:_0x5b4207['length']<_0x3e90b1['length']?-0x1:0x1;}function Ki(_0x418626,_0x10b887){if(Ce(_0x418626)!==Ce(_0x10b887))return!0x1;for(let _0x8e0d3c=_0x418626['pieceNum_'],_0x524949=_0x10b887['pieceNum_'];_0x8e0d3c<=_0x418626['pieces_']['length'];_0x8e0d3c++,_0x524949++)if(_0x418626['pieces_'][_0x8e0d3c]!==_0x10b887['pieces_'][_0x524949])return!0x1;return!0x0;}function G(_0xefbcd7,_0x1a6aca){let _0x1e0cfc=_0xefbcd7['pieceNum_'],_0x191199=_0x1a6aca['pieceNum_'];if(Ce(_0xefbcd7)>Ce(_0x1a6aca))return!0x1;for(;_0x1e0cfc<_0xefbcd7['pieces_']['length'];){if(_0xefbcd7['pieces_'][_0x1e0cfc]!==_0x1a6aca['pieces_'][_0x191199])return!0x1;++_0x1e0cfc,++_0x191199;}return!0x0;}class Ah{constructor(_0x292654,_0x33993d){this['errorPrefix_']=_0x33993d,this['parts_']=Mt(_0x292654,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x13359a=0x0;_0x13359a<this['parts_']['length'];_0x13359a++)this['byteLength_']+=Ln(this['parts_'][_0x13359a]);Ao(this);}}function kh(_0x5e5b56,_0x1646dc){_0x5e5b56['parts_']['length']>0x0&&(_0x5e5b56['byteLength_']+=0x1),_0x5e5b56['parts_']['push'](_0x1646dc),_0x5e5b56['byteLength_']+=Ln(_0x1646dc),Ao(_0x5e5b56);}function Ph(_0x135631){const _0x5e0367=_0x135631['parts_']['pop']();_0x135631['byteLength_']-=Ln(_0x5e0367),_0x135631['parts_']['length']>0x0&&(_0x135631['byteLength_']-=0x1);}function Ao(_0x547256){if(_0x547256['byteLength_']>Zs)throw new Error(_0x547256['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x547256['byteLength_']+').');if(_0x547256['parts_']['length']>Xs)throw new Error(_0x547256['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x547256));}function Oe(_0x417499){return _0x417499['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x417499['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x4835e8,_0x5603fa;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x5603fa='visibilitychange',_0x4835e8='hidden'):typeof document['mozHidden']<'u'?(_0x5603fa='mozvisibilitychange',_0x4835e8='mozHidden'):typeof document['msHidden']<'u'?(_0x5603fa='msvisibilitychange',_0x4835e8='msHidden'):typeof document['webkitHidden']<'u'&&(_0x5603fa='webkitvisibilitychange',_0x4835e8='webkitHidden')),this['visible_']=!0x0,_0x5603fa&&document['addEventListener'](_0x5603fa,()=>{const _0x5be203=!document[_0x4835e8];_0x5be203!==this['visible_']&&(this['visible_']=_0x5be203,this['trigger']('visible',_0x5be203));},!0x1);}['getInitialEvent'](_0x35a9b3){return f(_0x35a9b3==='visible','Unknown\x20event\x20type:\x20'+_0x35a9b3),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x3a5d66,_0x4f26a9,_0x5b5dc0,_0x527ec4,_0x21c6e1,_0x55ea06,_0x3e7efe,_0xb8473e){if(super(),this['repoInfo_']=_0x3a5d66,this['applicationId_']=_0x4f26a9,this['onDataUpdate_']=_0x5b5dc0,this['onConnectStatus_']=_0x527ec4,this['onServerInfoUpdate_']=_0x21c6e1,this['authTokenProvider_']=_0x55ea06,this['appCheckTokenProvider_']=_0x3e7efe,this['authOverride_']=_0xb8473e,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0xb8473e)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x3a5d66['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x394c37,_0x1b2475,_0x5a905f){const _0x98f5c5=++this['requestNumber_'],_0x3bb390={'r':_0x98f5c5,'a':_0x394c37,'b':_0x1b2475};this['log_'](O(_0x3bb390)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x3bb390),_0x5a905f&&(this['requestCBHash_'][_0x98f5c5]=_0x5a905f);}['get'](_0x3ed3f6){this['initConnection_']();const _0x4ef96c=new H(),_0xfef81e={'action':'g','request':{'p':_0x3ed3f6['_path']['toString'](),'q':_0x3ed3f6['_queryObject']},'onComplete':_0x524790=>{const _0x330dd4=_0x524790['d'];_0x524790['s']==='ok'?_0x4ef96c['resolve'](_0x330dd4):_0x4ef96c['reject'](_0x330dd4);}};this['outstandingGets_']['push'](_0xfef81e),this['outstandingGetCount_']++;const _0x8018fc=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x8018fc),_0x4ef96c['promise'];}['listen'](_0x354930,_0x26ecb9,_0x3ab43a,_0x247e47){this['initConnection_']();const _0x5ed2e4=_0x354930['_queryIdentifier'],_0x3e1d99=_0x354930['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x3e1d99+'\x20'+_0x5ed2e4),this['listens']['has'](_0x3e1d99)||this['listens']['set'](_0x3e1d99,new Map()),f(_0x354930['_queryParams']['isDefault']()||!_0x354930['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x3e1d99)['has'](_0x5ed2e4),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x1cabee={'onComplete':_0x247e47,'hashFn':_0x26ecb9,'query':_0x354930,'tag':_0x3ab43a};this['listens']['get'](_0x3e1d99)['set'](_0x5ed2e4,_0x1cabee),this['connected_']&&this['sendListen_'](_0x1cabee);}['sendGet_'](_0x485833){const _0x4a98ec=this['outstandingGets_'][_0x485833];this['sendRequest']('g',_0x4a98ec['request'],_0x4fb249=>{delete this['outstandingGets_'][_0x485833],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x4a98ec['onComplete']&&_0x4a98ec['onComplete'](_0x4fb249);});}['sendListen_'](_0x454a08){const _0x32cac7=_0x454a08['query'],_0x147c7a=_0x32cac7['_path']['toString'](),_0x3c5c44=_0x32cac7['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x147c7a+'\x20for\x20'+_0x3c5c44);const _0x338f7b={'p':_0x147c7a},_0x5c02e4='q';_0x454a08['tag']&&(_0x338f7b['q']=_0x32cac7['_queryObject'],_0x338f7b['t']=_0x454a08['tag']),_0x338f7b['h']=_0x454a08['hashFn'](),this['sendRequest'](_0x5c02e4,_0x338f7b,_0xcd44bb=>{const _0x4b434e=_0xcd44bb['d'],_0x33ac94=_0xcd44bb['s'];se['warnOnListenWarnings_'](_0x4b434e,_0x32cac7),(this['listens']['get'](_0x147c7a)&&this['listens']['get'](_0x147c7a)['get'](_0x3c5c44))===_0x454a08&&(this['log_']('listen\x20response',_0xcd44bb),_0x33ac94!=='ok'&&this['removeListen_'](_0x147c7a,_0x3c5c44),_0x454a08['onComplete']&&_0x454a08['onComplete'](_0x33ac94,_0x4b434e));});}static['warnOnListenWarnings_'](_0x21b58a,_0x59d186){if(_0x21b58a&&typeof _0x21b58a=='object'&&Q(_0x21b58a,'w')){const _0xbebd83=Le(_0x21b58a,'w');if(Array['isArray'](_0xbebd83)&&~_0xbebd83['indexOf']('no_index')){const _0x94278c='\x22.indexOn\x22:\x20\x22'+_0x59d186['_queryParams']['getIndex']()['toString']()+'\x22',_0x8bcac4=_0x59d186['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x94278c+'\x20at\x20'+_0x8bcac4+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x208b4c){this['authToken_']=_0x208b4c,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x208b4c);}['reduceReconnectDelayIfAdminCredential_'](_0x113910){(_0x113910&&_0x113910['length']===0x28||wc(_0x113910))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x3705ce){this['appCheckToken_']=_0x3705ce,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x10677e=this['authToken_'],_0x579e46=Ic(_0x10677e)?'auth':'gauth',_0xf19ca4={'cred':_0x10677e};this['authOverride_']===null?_0xf19ca4['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0xf19ca4['authvar']=this['authOverride_']),this['sendRequest'](_0x579e46,_0xf19ca4,_0x41be71=>{const _0x5e9ba0=_0x41be71['s'],_0x24aa96=_0x41be71['d']||'error';this['authToken_']===_0x10677e&&(_0x5e9ba0==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x5e9ba0,_0x24aa96));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x14371f=>{const _0x4c9ebe=_0x14371f['s'],_0x5eaaf9=_0x14371f['d']||'error';_0x4c9ebe==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x4c9ebe,_0x5eaaf9);});}['unlisten'](_0xfcdef4,_0x56dca3){const _0x1c57dd=_0xfcdef4['_path']['toString'](),_0x181463=_0xfcdef4['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x1c57dd+'\x20'+_0x181463),f(_0xfcdef4['_queryParams']['isDefault']()||!_0xfcdef4['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x1c57dd,_0x181463)&&this['connected_']&&this['sendUnlisten_'](_0x1c57dd,_0x181463,_0xfcdef4['_queryObject'],_0x56dca3);}['sendUnlisten_'](_0x186661,_0x2de807,_0x2fc7ec,_0x55433e){this['log_']('Unlisten\x20on\x20'+_0x186661+'\x20for\x20'+_0x2de807);const _0x25cdcc={'p':_0x186661},_0x1185e7='n';_0x55433e&&(_0x25cdcc['q']=_0x2fc7ec,_0x25cdcc['t']=_0x55433e),this['sendRequest'](_0x1185e7,_0x25cdcc);}['onDisconnectPut'](_0x24b0a0,_0xc52c18,_0x2fe624){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x24b0a0,_0xc52c18,_0x2fe624):this['onDisconnectRequestQueue_']['push']({'pathString':_0x24b0a0,'action':'o','data':_0xc52c18,'onComplete':_0x2fe624});}['onDisconnectMerge'](_0x48b106,_0x4899ee,_0xa9dc10){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x48b106,_0x4899ee,_0xa9dc10):this['onDisconnectRequestQueue_']['push']({'pathString':_0x48b106,'action':'om','data':_0x4899ee,'onComplete':_0xa9dc10});}['onDisconnectCancel'](_0x48a43b,_0x108f80){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x48a43b,null,_0x108f80):this['onDisconnectRequestQueue_']['push']({'pathString':_0x48a43b,'action':'oc','data':null,'onComplete':_0x108f80});}['sendOnDisconnect_'](_0x4d8d7b,_0x4cc6a9,_0x2fa09d,_0x65300a){const _0x3f7ad0={'p':_0x4cc6a9,'d':_0x2fa09d};this['log_']('onDisconnect\x20'+_0x4d8d7b,_0x3f7ad0),this['sendRequest'](_0x4d8d7b,_0x3f7ad0,_0x393016=>{_0x65300a&&setTimeout(()=>{_0x65300a(_0x393016['s'],_0x393016['d']);},Math['floor'](0x0));});}['put'](_0x514e60,_0x5608cb,_0x1c5db9,_0x29a8cd){this['putInternal']('p',_0x514e60,_0x5608cb,_0x1c5db9,_0x29a8cd);}['merge'](_0x9b1bb9,_0x29c0f4,_0x478326,_0xdc8342){this['putInternal']('m',_0x9b1bb9,_0x29c0f4,_0x478326,_0xdc8342);}['putInternal'](_0x1ec846,_0x59ad0e,_0x2cf819,_0x4e3f29,_0x48e8f0){this['initConnection_']();const _0x53a975={'p':_0x59ad0e,'d':_0x2cf819};_0x48e8f0!==void 0x0&&(_0x53a975['h']=_0x48e8f0),this['outstandingPuts_']['push']({'action':_0x1ec846,'request':_0x53a975,'onComplete':_0x4e3f29}),this['outstandingPutCount_']++;const _0x3da84d=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x3da84d):this['log_']('Buffering\x20put:\x20'+_0x59ad0e);}['sendPut_'](_0x7a8f99){const _0x11c6f6=this['outstandingPuts_'][_0x7a8f99]['action'],_0x4cbf4a=this['outstandingPuts_'][_0x7a8f99]['request'],_0x55e59b=this['outstandingPuts_'][_0x7a8f99]['onComplete'];this['outstandingPuts_'][_0x7a8f99]['queued']=this['connected_'],this['sendRequest'](_0x11c6f6,_0x4cbf4a,_0x5d1c6f=>{this['log_'](_0x11c6f6+'\x20response',_0x5d1c6f),delete this['outstandingPuts_'][_0x7a8f99],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x55e59b&&_0x55e59b(_0x5d1c6f['s'],_0x5d1c6f['d']);});}['reportStats'](_0x2a22be){if(this['connected_']){const _0x4f693c={'c':_0x2a22be};this['log_']('reportStats',_0x4f693c),this['sendRequest']('s',_0x4f693c,_0x44ad5c=>{if(_0x44ad5c['s']!=='ok'){const _0x2a8aef=_0x44ad5c['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x2a8aef);}});}}['onDataMessage_'](_0x2b46c4){if('r'in _0x2b46c4){this['log_']('from\x20server:\x20'+O(_0x2b46c4));const _0x574314=_0x2b46c4['r'],_0x343844=this['requestCBHash_'][_0x574314];_0x343844&&(delete this['requestCBHash_'][_0x574314],_0x343844(_0x2b46c4['b']));}else{if('error'in _0x2b46c4)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x2b46c4['error'];'a'in _0x2b46c4&&this['onDataPush_'](_0x2b46c4['a'],_0x2b46c4['b']);}}['onDataPush_'](_0x1b01d5,_0x49998f){this['log_']('handleServerMessage',_0x1b01d5,_0x49998f),_0x1b01d5==='d'?this['onDataUpdate_'](_0x49998f['p'],_0x49998f['d'],!0x1,_0x49998f['t']):_0x1b01d5==='m'?this['onDataUpdate_'](_0x49998f['p'],_0x49998f['d'],!0x0,_0x49998f['t']):_0x1b01d5==='c'?this['onListenRevoked_'](_0x49998f['p'],_0x49998f['q']):_0x1b01d5==='ac'?this['onAuthRevoked_'](_0x49998f['s'],_0x49998f['d']):_0x1b01d5==='apc'?this['onAppCheckRevoked_'](_0x49998f['s'],_0x49998f['d']):_0x1b01d5==='sd'?this['onSecurityDebugPacket_'](_0x49998f):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x1b01d5)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x7ac063,_0x67e702){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x7ac063),this['lastSessionId']=_0x67e702,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x47d5d5){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x47d5d5));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x18b08f){_0x18b08f&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x18b08f;}['onOnline_'](_0xa79297){_0xa79297?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x3e7cd2=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x4be545=Math['max'](0x0,this['reconnectDelay_']-_0x3e7cd2);_0x4be545=Math['random']()*_0x4be545,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x4be545+'ms'),this['scheduleConnect_'](_0x4be545),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x54992f=this['onDataMessage_']['bind'](this),_0x48856e=this['onReady_']['bind'](this),_0x34eeaa=this['onRealtimeDisconnect_']['bind'](this),_0xd0745e=this['id']+':'+se['nextConnectionId_']++,_0x1e9ac2=this['lastSessionId'];let _0x4ccd45=!0x1,_0x413533=null;const _0x30a33f=function(){_0x413533?_0x413533['close']():(_0x4ccd45=!0x0,_0x34eeaa());},_0x2d0da3=function(_0x4d6c5b){f(_0x413533,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x413533['sendRequest'](_0x4d6c5b);};this['realtime_']={'close':_0x30a33f,'sendRequest':_0x2d0da3};const _0xc7759d=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x1956e9,_0x30e78d]=await Promise['all']([this['authTokenProvider_']['getToken'](_0xc7759d),this['appCheckTokenProvider_']['getToken'](_0xc7759d)]);_0x4ccd45?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x1956e9&&_0x1956e9['accessToken'],this['appCheckToken_']=_0x30e78d&&_0x30e78d['token'],_0x413533=new Sh(_0xd0745e,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x54992f,_0x48856e,_0x34eeaa,_0x39f967=>{U(_0x39f967+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x1e9ac2));}catch(_0x2d1ac6){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x2d1ac6),_0x4ccd45||(this['repoInfo_']['nodeAdmin']&&U(_0x2d1ac6),_0x30a33f());}}}['interrupt'](_0x275a67){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x275a67),this['interruptReasons_'][_0x275a67]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x1de7b3){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x1de7b3),delete this['interruptReasons_'][_0x1de7b3],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x587dd4){const _0x449f05=_0x587dd4-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x449f05});}['cancelSentTransactions_'](){for(let _0x52cf8d=0x0;_0x52cf8d<this['outstandingPuts_']['length'];_0x52cf8d++){const _0x438b0d=this['outstandingPuts_'][_0x52cf8d];_0x438b0d&&'h'in _0x438b0d['request']&&_0x438b0d['queued']&&(_0x438b0d['onComplete']&&_0x438b0d['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x52cf8d],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x21ac5b,_0x4b0804){let _0x83b4e9;_0x4b0804?_0x83b4e9=_0x4b0804['map'](_0x46ebbc=>$i(_0x46ebbc))['join']('$'):_0x83b4e9='default';const _0x4560ff=this['removeListen_'](_0x21ac5b,_0x83b4e9);_0x4560ff&&_0x4560ff['onComplete']&&_0x4560ff['onComplete']('permission_denied');}['removeListen_'](_0x3b845b,_0x59bc60){const _0x209aaa=new C(_0x3b845b)['toString']();let _0x3ad5c8;if(this['listens']['has'](_0x209aaa)){const _0x17fb92=this['listens']['get'](_0x209aaa);_0x3ad5c8=_0x17fb92['get'](_0x59bc60),_0x17fb92['delete'](_0x59bc60),_0x17fb92['size']===0x0&&this['listens']['delete'](_0x209aaa);}else _0x3ad5c8=void 0x0;return _0x3ad5c8;}['onAuthRevoked_'](_0x5f1184,_0x7f3224){L('Auth\x20token\x20revoked:\x20'+_0x5f1184+'/'+_0x7f3224),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x5f1184==='invalid_token'||_0x5f1184==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x788870,_0x2ab6ae){L('App\x20check\x20token\x20revoked:\x20'+_0x788870+'/'+_0x2ab6ae),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x788870==='invalid_token'||_0x788870==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x13bc4b){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x13bc4b):'msg'in _0x13bc4b&&console['log']('FIREBASE:\x20'+_0x13bc4b['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x1a214a of this['listens']['values']())for(const _0x5aa45f of _0x1a214a['values']())this['sendListen_'](_0x5aa45f);for(let _0x40ad54=0x0;_0x40ad54<this['outstandingPuts_']['length'];_0x40ad54++)this['outstandingPuts_'][_0x40ad54]&&this['sendPut_'](_0x40ad54);for(;this['onDisconnectRequestQueue_']['length'];){const _0x5c7a67=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x5c7a67['action'],_0x5c7a67['pathString'],_0x5c7a67['data'],_0x5c7a67['onComplete']);}for(let _0x179c0e=0x0;_0x179c0e<this['outstandingGets_']['length'];_0x179c0e++)this['outstandingGets_'][_0x179c0e]&&this['sendGet_'](_0x179c0e);}['sendConnectStats_'](){const _0x134f8c={};let _0x18954a='js';_0x134f8c['sdk.'+_0x18954a+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x134f8c['framework.cordova']=0x1:Kr()&&(_0x134f8c['framework.reactnative']=0x1),this['reportStats'](_0x134f8c);}['shouldReconnect_'](){const _0x40d20b=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x40d20b;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x49698e,_0x496335){this['name']=_0x49698e,this['node']=_0x496335;}static['Wrap'](_0x1b457a,_0x1bed61){return new E(_0x1b457a,_0x1bed61);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0xf87b45,_0x57397d){const _0x2f1116=new E(We,_0xf87b45),_0x3ed94e=new E(We,_0x57397d);return this['compare'](_0x2f1116,_0x3ed94e)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x40f78f){sn=_0x40f78f;}['compare'](_0x23e80d,_0x3e6069){return qe(_0x23e80d['name'],_0x3e6069['name']);}['isDefinedOn'](_0x47b66a){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x2fa7d5,_0x4df3b4){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x2a1e8c,_0x1f0658){return f(typeof _0x2a1e8c=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x2a1e8c,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x1367f6,_0x17b86b,_0xb60583,_0x19e20f,_0xbe3116=null){this['isReverse_']=_0x19e20f,this['resultGenerator_']=_0xbe3116,this['nodeStack_']=[];let _0x5f4d9e=0x1;for(;!_0x1367f6['isEmpty']();)if(_0x1367f6=_0x1367f6,_0x5f4d9e=_0x17b86b?_0xb60583(_0x1367f6['key'],_0x17b86b):0x1,_0x19e20f&&(_0x5f4d9e*=-0x1),_0x5f4d9e<0x0)this['isReverse_']?_0x1367f6=_0x1367f6['left']:_0x1367f6=_0x1367f6['right'];else{if(_0x5f4d9e===0x0){this['nodeStack_']['push'](_0x1367f6);break;}else this['nodeStack_']['push'](_0x1367f6),this['isReverse_']?_0x1367f6=_0x1367f6['right']:_0x1367f6=_0x1367f6['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0xe3224e=this['nodeStack_']['pop'](),_0x204cd7;if(this['resultGenerator_']?_0x204cd7=this['resultGenerator_'](_0xe3224e['key'],_0xe3224e['value']):_0x204cd7={'key':_0xe3224e['key'],'value':_0xe3224e['value']},this['isReverse_']){for(_0xe3224e=_0xe3224e['left'];!_0xe3224e['isEmpty']();)this['nodeStack_']['push'](_0xe3224e),_0xe3224e=_0xe3224e['right'];}else{for(_0xe3224e=_0xe3224e['right'];!_0xe3224e['isEmpty']();)this['nodeStack_']['push'](_0xe3224e),_0xe3224e=_0xe3224e['left'];}return _0x204cd7;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x57e1e3=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x57e1e3['key'],_0x57e1e3['value']):{'key':_0x57e1e3['key'],'value':_0x57e1e3['value']};}}class M{constructor(_0x151b97,_0x3fbc6b,_0x37499b,_0x4e66e0,_0x5c94c5){this['key']=_0x151b97,this['value']=_0x3fbc6b,this['color']=_0x37499b??M['RED'],this['left']=_0x4e66e0??B['EMPTY_NODE'],this['right']=_0x5c94c5??B['EMPTY_NODE'];}['copy'](_0x2bb722,_0x5d1537,_0x3a715c,_0x2c23f8,_0x51e906){return new M(_0x2bb722??this['key'],_0x5d1537??this['value'],_0x3a715c??this['color'],_0x2c23f8??this['left'],_0x51e906??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x41e6eb){return this['left']['inorderTraversal'](_0x41e6eb)||!!_0x41e6eb(this['key'],this['value'])||this['right']['inorderTraversal'](_0x41e6eb);}['reverseTraversal'](_0x8b1a5b){return this['right']['reverseTraversal'](_0x8b1a5b)||_0x8b1a5b(this['key'],this['value'])||this['left']['reverseTraversal'](_0x8b1a5b);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x20b78f,_0x5af23b,_0x7a40e0){let _0x1a32c4=this;const _0x5d9d8a=_0x7a40e0(_0x20b78f,_0x1a32c4['key']);return _0x5d9d8a<0x0?_0x1a32c4=_0x1a32c4['copy'](null,null,null,_0x1a32c4['left']['insert'](_0x20b78f,_0x5af23b,_0x7a40e0),null):_0x5d9d8a===0x0?_0x1a32c4=_0x1a32c4['copy'](null,_0x5af23b,null,null,null):_0x1a32c4=_0x1a32c4['copy'](null,null,null,null,_0x1a32c4['right']['insert'](_0x20b78f,_0x5af23b,_0x7a40e0)),_0x1a32c4['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x46d909=this;return!_0x46d909['left']['isRed_']()&&!_0x46d909['left']['left']['isRed_']()&&(_0x46d909=_0x46d909['moveRedLeft_']()),_0x46d909=_0x46d909['copy'](null,null,null,_0x46d909['left']['removeMin_'](),null),_0x46d909['fixUp_']();}['remove'](_0x3d19db,_0x572974){let _0xe0cbdb,_0xa8265b;if(_0xe0cbdb=this,_0x572974(_0x3d19db,_0xe0cbdb['key'])<0x0)!_0xe0cbdb['left']['isEmpty']()&&!_0xe0cbdb['left']['isRed_']()&&!_0xe0cbdb['left']['left']['isRed_']()&&(_0xe0cbdb=_0xe0cbdb['moveRedLeft_']()),_0xe0cbdb=_0xe0cbdb['copy'](null,null,null,_0xe0cbdb['left']['remove'](_0x3d19db,_0x572974),null);else{if(_0xe0cbdb['left']['isRed_']()&&(_0xe0cbdb=_0xe0cbdb['rotateRight_']()),!_0xe0cbdb['right']['isEmpty']()&&!_0xe0cbdb['right']['isRed_']()&&!_0xe0cbdb['right']['left']['isRed_']()&&(_0xe0cbdb=_0xe0cbdb['moveRedRight_']()),_0x572974(_0x3d19db,_0xe0cbdb['key'])===0x0){if(_0xe0cbdb['right']['isEmpty']())return B['EMPTY_NODE'];_0xa8265b=_0xe0cbdb['right']['min_'](),_0xe0cbdb=_0xe0cbdb['copy'](_0xa8265b['key'],_0xa8265b['value'],null,null,_0xe0cbdb['right']['removeMin_']());}_0xe0cbdb=_0xe0cbdb['copy'](null,null,null,null,_0xe0cbdb['right']['remove'](_0x3d19db,_0x572974));}return _0xe0cbdb['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x4cf6b5=this;return _0x4cf6b5['right']['isRed_']()&&!_0x4cf6b5['left']['isRed_']()&&(_0x4cf6b5=_0x4cf6b5['rotateLeft_']()),_0x4cf6b5['left']['isRed_']()&&_0x4cf6b5['left']['left']['isRed_']()&&(_0x4cf6b5=_0x4cf6b5['rotateRight_']()),_0x4cf6b5['left']['isRed_']()&&_0x4cf6b5['right']['isRed_']()&&(_0x4cf6b5=_0x4cf6b5['colorFlip_']()),_0x4cf6b5;}['moveRedLeft_'](){let _0x1d9c36=this['colorFlip_']();return _0x1d9c36['right']['left']['isRed_']()&&(_0x1d9c36=_0x1d9c36['copy'](null,null,null,null,_0x1d9c36['right']['rotateRight_']()),_0x1d9c36=_0x1d9c36['rotateLeft_'](),_0x1d9c36=_0x1d9c36['colorFlip_']()),_0x1d9c36;}['moveRedRight_'](){let _0x8e0804=this['colorFlip_']();return _0x8e0804['left']['left']['isRed_']()&&(_0x8e0804=_0x8e0804['rotateRight_'](),_0x8e0804=_0x8e0804['colorFlip_']()),_0x8e0804;}['rotateLeft_'](){const _0x1f7490=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x1f7490,null);}['rotateRight_'](){const _0x515c5c=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x515c5c);}['colorFlip_'](){const _0xb6664b=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x3b030e=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0xb6664b,_0x3b030e);}['checkMaxDepth_'](){const _0xdf546e=this['check_']();return Math['pow'](0x2,_0xdf546e)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x3d8089=this['left']['check_']();if(_0x3d8089!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x3d8089+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x5ba72e,_0x8eb0ba,_0x42154d,_0x521c40,_0x335020){return this;}['insert'](_0x1d7b6a,_0x4d57aa,_0x41a8ce){return new M(_0x1d7b6a,_0x4d57aa,null);}['remove'](_0x32afe3,_0xce82aa){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x39b1d8){return!0x1;}['reverseTraversal'](_0x49a10b){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x361745,_0x44f8ca=B['EMPTY_NODE']){this['comparator_']=_0x361745,this['root_']=_0x44f8ca;}['insert'](_0x33fd8e,_0x2b060d){return new B(this['comparator_'],this['root_']['insert'](_0x33fd8e,_0x2b060d,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x3e4093){return new B(this['comparator_'],this['root_']['remove'](_0x3e4093,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x581c21){let _0x4fa8c7,_0x5e4c32=this['root_'];for(;!_0x5e4c32['isEmpty']();){if(_0x4fa8c7=this['comparator_'](_0x581c21,_0x5e4c32['key']),_0x4fa8c7===0x0)return _0x5e4c32['value'];_0x4fa8c7<0x0?_0x5e4c32=_0x5e4c32['left']:_0x4fa8c7>0x0&&(_0x5e4c32=_0x5e4c32['right']);}return null;}['getPredecessorKey'](_0x19f660){let _0x23a67e,_0x3e96c5=this['root_'],_0x3b7669=null;for(;!_0x3e96c5['isEmpty']();)if(_0x23a67e=this['comparator_'](_0x19f660,_0x3e96c5['key']),_0x23a67e===0x0){if(_0x3e96c5['left']['isEmpty']())return _0x3b7669?_0x3b7669['key']:null;for(_0x3e96c5=_0x3e96c5['left'];!_0x3e96c5['right']['isEmpty']();)_0x3e96c5=_0x3e96c5['right'];return _0x3e96c5['key'];}else _0x23a67e<0x0?_0x3e96c5=_0x3e96c5['left']:_0x23a67e>0x0&&(_0x3b7669=_0x3e96c5,_0x3e96c5=_0x3e96c5['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x4a6633){return this['root_']['inorderTraversal'](_0x4a6633);}['reverseTraversal'](_0x2a2f00){return this['root_']['reverseTraversal'](_0x2a2f00);}['getIterator'](_0x55fe8f){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x55fe8f);}['getIteratorFrom'](_0x3debee,_0x2c1d7b){return new rn(this['root_'],_0x3debee,this['comparator_'],!0x1,_0x2c1d7b);}['getReverseIteratorFrom'](_0x5bafd7,_0x49a750){return new rn(this['root_'],_0x5bafd7,this['comparator_'],!0x0,_0x49a750);}['getReverseIterator'](_0x4878ed){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x4878ed);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x5c6821,_0x3fcff1){return qe(_0x5c6821['name'],_0x3fcff1['name']);}function Qi(_0x40eb1b,_0x3bd651){return qe(_0x40eb1b,_0x3bd651);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x439bb7){Ci=_0x439bb7;}const Po=function(_0x5dd935){return typeof _0x5dd935=='number'?'number:'+ao(_0x5dd935):'string:'+_0x5dd935;},No=function(_0x5daabe){if(_0x5daabe['isLeafNode']()){const _0x60805=_0x5daabe['val']();f(typeof _0x60805=='string'||typeof _0x60805=='number'||typeof _0x60805=='object'&&Q(_0x60805,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x5daabe===Ci||_0x5daabe['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x5daabe===Ci||_0x5daabe['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x14efdb){nr=_0x14efdb;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x20f6c7,_0x3d178b=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x20f6c7,this['priorityNode_']=_0x3d178b,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0xf7fa26){return new D(this['value_'],_0xf7fa26);}['getImmediateChild'](_0xe635b1){return _0xe635b1==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x368884){return v(_0x368884)?this:y(_0x368884)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x2bbb5e,_0x569850){return null;}['updateImmediateChild'](_0x5d3950,_0x4f1911){return _0x5d3950==='.priority'?this['updatePriority'](_0x4f1911):_0x4f1911['isEmpty']()&&_0x5d3950!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x5d3950,_0x4f1911)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x56a1f2,_0x3bce95){const _0x3db3ca=y(_0x56a1f2);return _0x3db3ca===null?_0x3bce95:_0x3bce95['isEmpty']()&&_0x3db3ca!=='.priority'?this:(f(_0x3db3ca!=='.priority'||Ce(_0x56a1f2)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x3db3ca,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x56a1f2),_0x3bce95)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x2afa0d,_0x439794){return!0x1;}['val'](_0x67a562){return _0x67a562&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0xe6afc='';this['priorityNode_']['isEmpty']()||(_0xe6afc+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x1a62b0=typeof this['value_'];_0xe6afc+=_0x1a62b0+':',_0x1a62b0==='number'?_0xe6afc+=ao(this['value_']):_0xe6afc+=this['value_'],this['lazyHash_']=ro(_0xe6afc);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x5502ee){return _0x5502ee===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x5502ee instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x5502ee['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x5502ee));}['compareToLeafNode_'](_0x455277){const _0x55dc43=typeof _0x455277['value_'],_0x191a06=typeof this['value_'],_0x485a66=D['VALUE_TYPE_ORDER']['indexOf'](_0x55dc43),_0x4a8814=D['VALUE_TYPE_ORDER']['indexOf'](_0x191a06);return f(_0x485a66>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x55dc43),f(_0x4a8814>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x191a06),_0x485a66===_0x4a8814?_0x191a06==='object'?0x0:this['value_']<_0x455277['value_']?-0x1:this['value_']===_0x455277['value_']?0x0:0x1:_0x4a8814-_0x485a66;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x2e3ed3){if(_0x2e3ed3===this)return!0x0;if(_0x2e3ed3['isLeafNode']()){const _0x206962=_0x2e3ed3;return this['value_']===_0x206962['value_']&&this['priorityNode_']['equals'](_0x206962['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x3e7983){Oo=_0x3e7983;}function Wh(_0xbf8760){Do=_0xbf8760;}class Bh extends Fn{['compare'](_0x200fe3,_0x37fd3b){const _0x45b326=_0x200fe3['node']['getPriority'](),_0x38e2b9=_0x37fd3b['node']['getPriority'](),_0x42f35f=_0x45b326['compareTo'](_0x38e2b9);return _0x42f35f===0x0?qe(_0x200fe3['name'],_0x37fd3b['name']):_0x42f35f;}['isDefinedOn'](_0x1fe282){return!_0x1fe282['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x3112d1,_0x1839b){return!_0x3112d1['getPriority']()['equals'](_0x1839b['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x573a3f,_0x139f36){const _0x4664e0=Oo(_0x573a3f);return new E(_0x139f36,new D('[PRIORITY-POST]',_0x4664e0));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x1c3dd7){const _0x7e222e=_0x17b4b5=>parseInt(Math['log'](_0x17b4b5)/Vh,0xa),_0x3945cd=_0xef92be=>parseInt(Array(_0xef92be+0x1)['join']('1'),0x2);this['count']=_0x7e222e(_0x1c3dd7+0x1),this['current_']=this['count']-0x1;const _0x1c5227=_0x3945cd(this['count']);this['bits_']=_0x1c3dd7+0x1&_0x1c5227;}['nextBitIsOne'](){const _0x1e3e0f=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x1e3e0f;}}const yn=function(_0x3129bb,_0x4cbb07,_0x4b4bd1,_0x32f49b){_0x3129bb['sort'](_0x4cbb07);const _0x3ccd49=function(_0x3480a7,_0x3bdf78){const _0x4f49aa=_0x3bdf78-_0x3480a7;let _0x3aa360,_0x1ced23;if(_0x4f49aa===0x0)return null;if(_0x4f49aa===0x1)return _0x3aa360=_0x3129bb[_0x3480a7],_0x1ced23=_0x4b4bd1?_0x4b4bd1(_0x3aa360):_0x3aa360,new M(_0x1ced23,_0x3aa360['node'],M['BLACK'],null,null);{const _0x4e3253=parseInt(_0x4f49aa/0x2,0xa)+_0x3480a7,_0xfa1457=_0x3ccd49(_0x3480a7,_0x4e3253),_0x47ebfa=_0x3ccd49(_0x4e3253+0x1,_0x3bdf78);return _0x3aa360=_0x3129bb[_0x4e3253],_0x1ced23=_0x4b4bd1?_0x4b4bd1(_0x3aa360):_0x3aa360,new M(_0x1ced23,_0x3aa360['node'],M['BLACK'],_0xfa1457,_0x47ebfa);}},_0x5594ee=function(_0x28c665){let _0x39cf8e=null,_0x3b48a4=null,_0x38dc80=_0x3129bb['length'];const _0x25eb5a=function(_0x2417c7,_0x2b2f54){const _0x1663da=_0x38dc80-_0x2417c7,_0x47a557=_0x38dc80;_0x38dc80-=_0x2417c7;const _0x41a8e1=_0x3ccd49(_0x1663da+0x1,_0x47a557),_0x1637d3=_0x3129bb[_0x1663da],_0x274f30=_0x4b4bd1?_0x4b4bd1(_0x1637d3):_0x1637d3;_0x12b34c(new M(_0x274f30,_0x1637d3['node'],_0x2b2f54,null,_0x41a8e1));},_0x12b34c=function(_0x1566c7){_0x39cf8e?(_0x39cf8e['left']=_0x1566c7,_0x39cf8e=_0x1566c7):(_0x3b48a4=_0x1566c7,_0x39cf8e=_0x1566c7);};for(let _0x4a3e20=0x0;_0x4a3e20<_0x28c665['count'];++_0x4a3e20){const _0x5612b7=_0x28c665['nextBitIsOne'](),_0x274388=Math['pow'](0x2,_0x28c665['count']-(_0x4a3e20+0x1));_0x5612b7?_0x25eb5a(_0x274388,M['BLACK']):(_0x25eb5a(_0x274388,M['BLACK']),_0x25eb5a(_0x274388,M['RED']));}return _0x3b48a4;},_0x2ff4c3=new Hh(_0x3129bb['length']),_0x2c748c=_0x5594ee(_0x2ff4c3);return new B(_0x32f49b||_0x4cbb07,_0x2c748c);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x4ed667,_0x1c3acf){this['indexes_']=_0x4ed667,this['indexSet_']=_0x1c3acf;}['get'](_0x256c0a){const _0x414c1b=Le(this['indexes_'],_0x256c0a);if(!_0x414c1b)throw new Error('No\x20index\x20defined\x20for\x20'+_0x256c0a);return _0x414c1b instanceof B?_0x414c1b:null;}['hasIndex'](_0x1414eb){return Q(this['indexSet_'],_0x1414eb['toString']());}['addIndex'](_0x4767e1,_0x1c7b8a){f(_0x4767e1!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x3c0a2a=[];let _0x1d8466=!0x1;const _0x1854b8=_0x1c7b8a['getIterator'](E['Wrap']);let _0x534273=_0x1854b8['getNext']();for(;_0x534273;)_0x1d8466=_0x1d8466||_0x4767e1['isDefinedOn'](_0x534273['node']),_0x3c0a2a['push'](_0x534273),_0x534273=_0x1854b8['getNext']();let _0x4067d6;_0x1d8466?_0x4067d6=yn(_0x3c0a2a,_0x4767e1['getCompare']()):_0x4067d6=Qe;const _0x5a7b86=_0x4767e1['toString'](),_0x234ee3={...this['indexSet_']};_0x234ee3[_0x5a7b86]=_0x4767e1;const _0x4ac6b3={...this['indexes_']};return _0x4ac6b3[_0x5a7b86]=_0x4067d6,new te(_0x4ac6b3,_0x234ee3);}['addToIndexes'](_0x25d3c3,_0x3a4357){const _0x2f3553=_n(this['indexes_'],(_0x454821,_0x539b17)=>{const _0x2f069f=Le(this['indexSet_'],_0x539b17);if(f(_0x2f069f,'Missing\x20index\x20implementation\x20for\x20'+_0x539b17),_0x454821===Qe){if(_0x2f069f['isDefinedOn'](_0x25d3c3['node'])){const _0x13bdd1=[],_0x2c2cf2=_0x3a4357['getIterator'](E['Wrap']);let _0x11c6e2=_0x2c2cf2['getNext']();for(;_0x11c6e2;)_0x11c6e2['name']!==_0x25d3c3['name']&&_0x13bdd1['push'](_0x11c6e2),_0x11c6e2=_0x2c2cf2['getNext']();return _0x13bdd1['push'](_0x25d3c3),yn(_0x13bdd1,_0x2f069f['getCompare']());}else return Qe;}else{const _0x1cea1c=_0x3a4357['get'](_0x25d3c3['name']);let _0x3aae84=_0x454821;return _0x1cea1c&&(_0x3aae84=_0x3aae84['remove'](new E(_0x25d3c3['name'],_0x1cea1c))),_0x3aae84['insert'](_0x25d3c3,_0x25d3c3['node']);}});return new te(_0x2f3553,this['indexSet_']);}['removeFromIndexes'](_0x30a063,_0x235d4d){const _0x5e0cf9=_n(this['indexes_'],_0xcc5838=>{if(_0xcc5838===Qe)return _0xcc5838;{const _0x605e51=_0x235d4d['get'](_0x30a063['name']);return _0x605e51?_0xcc5838['remove'](new E(_0x30a063['name'],_0x605e51)):_0xcc5838;}});return new te(_0x5e0cf9,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x33c364,_0x2c53e9,_0x34adc4){this['children_']=_0x33c364,this['priorityNode_']=_0x2c53e9,this['indexMap_']=_0x34adc4,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x5e458d){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x5e458d,this['indexMap_']);}['getImmediateChild'](_0x22b088){if(_0x22b088==='.priority')return this['getPriority']();{const _0x392c2e=this['children_']['get'](_0x22b088);return _0x392c2e===null?It:_0x392c2e;}}['getChild'](_0x31491c){const _0x13c1dd=y(_0x31491c);return _0x13c1dd===null?this:this['getImmediateChild'](_0x13c1dd)['getChild'](S(_0x31491c));}['hasChild'](_0xc72991){return this['children_']['get'](_0xc72991)!==null;}['updateImmediateChild'](_0x190c6c,_0x4f37d3){if(f(_0x4f37d3,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x190c6c==='.priority')return this['updatePriority'](_0x4f37d3);{const _0x4b4750=new E(_0x190c6c,_0x4f37d3);let _0x3c0576,_0x1f4757;_0x4f37d3['isEmpty']()?(_0x3c0576=this['children_']['remove'](_0x190c6c),_0x1f4757=this['indexMap_']['removeFromIndexes'](_0x4b4750,this['children_'])):(_0x3c0576=this['children_']['insert'](_0x190c6c,_0x4f37d3),_0x1f4757=this['indexMap_']['addToIndexes'](_0x4b4750,this['children_']));const _0x28e4d6=_0x3c0576['isEmpty']()?It:this['priorityNode_'];return new g(_0x3c0576,_0x28e4d6,_0x1f4757);}}['updateChild'](_0x2197c5,_0xe60921){const _0x5cde41=y(_0x2197c5);if(_0x5cde41===null)return _0xe60921;{f(y(_0x2197c5)!=='.priority'||Ce(_0x2197c5)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x5e8ff6=this['getImmediateChild'](_0x5cde41)['updateChild'](S(_0x2197c5),_0xe60921);return this['updateImmediateChild'](_0x5cde41,_0x5e8ff6);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x24b2d3){if(this['isEmpty']())return null;const _0x510991={};let _0x1bc910=0x0,_0x39ff7d=0x0,_0x5ff5a4=!0x0;if(this['forEachChild'](R,(_0x1dd777,_0x53e621)=>{_0x510991[_0x1dd777]=_0x53e621['val'](_0x24b2d3),_0x1bc910++,_0x5ff5a4&&g['INTEGER_REGEXP_']['test'](_0x1dd777)?_0x39ff7d=Math['max'](_0x39ff7d,Number(_0x1dd777)):_0x5ff5a4=!0x1;}),!_0x24b2d3&&_0x5ff5a4&&_0x39ff7d<0x2*_0x1bc910){const _0x27f5e0=[];for(const _0x34afcd in _0x510991)_0x27f5e0[_0x34afcd]=_0x510991[_0x34afcd];return _0x27f5e0;}else return _0x24b2d3&&!this['getPriority']()['isEmpty']()&&(_0x510991['.priority']=this['getPriority']()['val']()),_0x510991;}['hash'](){if(this['lazyHash_']===null){let _0x433e11='';this['getPriority']()['isEmpty']()||(_0x433e11+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x6217df,_0x524007)=>{const _0x5203d0=_0x524007['hash']();_0x5203d0!==''&&(_0x433e11+=':'+_0x6217df+':'+_0x5203d0);}),this['lazyHash_']=_0x433e11===''?'':ro(_0x433e11);}return this['lazyHash_'];}['getPredecessorChildName'](_0x12a6bf,_0x211ff7,_0x4ea564){const _0x1084de=this['resolveIndex_'](_0x4ea564);if(_0x1084de){const _0x4c5913=_0x1084de['getPredecessorKey'](new E(_0x12a6bf,_0x211ff7));return _0x4c5913?_0x4c5913['name']:null;}else return this['children_']['getPredecessorKey'](_0x12a6bf);}['getFirstChildName'](_0x2dd623){const _0x36d62c=this['resolveIndex_'](_0x2dd623);if(_0x36d62c){const _0x2279b2=_0x36d62c['minKey']();return _0x2279b2&&_0x2279b2['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x25c239){const _0x111f64=this['getFirstChildName'](_0x25c239);return _0x111f64?new E(_0x111f64,this['children_']['get'](_0x111f64)):null;}['getLastChildName'](_0x306031){const _0x24e06e=this['resolveIndex_'](_0x306031);if(_0x24e06e){const _0x39968b=_0x24e06e['maxKey']();return _0x39968b&&_0x39968b['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x5ae89b){const _0x397d2a=this['getLastChildName'](_0x5ae89b);return _0x397d2a?new E(_0x397d2a,this['children_']['get'](_0x397d2a)):null;}['forEachChild'](_0x41ba82,_0x3324e3){const _0x3c737b=this['resolveIndex_'](_0x41ba82);return _0x3c737b?_0x3c737b['inorderTraversal'](_0xf1f4e0=>_0x3324e3(_0xf1f4e0['name'],_0xf1f4e0['node'])):this['children_']['inorderTraversal'](_0x3324e3);}['getIterator'](_0xe8ba8){return this['getIteratorFrom'](_0xe8ba8['minPost'](),_0xe8ba8);}['getIteratorFrom'](_0x40f7e2,_0xbad667){const _0x36f44c=this['resolveIndex_'](_0xbad667);if(_0x36f44c)return _0x36f44c['getIteratorFrom'](_0x40f7e2,_0x33c0e6=>_0x33c0e6);{const _0x33ec77=this['children_']['getIteratorFrom'](_0x40f7e2['name'],E['Wrap']);let _0x473e4d=_0x33ec77['peek']();for(;_0x473e4d!=null&&_0xbad667['compare'](_0x473e4d,_0x40f7e2)<0x0;)_0x33ec77['getNext'](),_0x473e4d=_0x33ec77['peek']();return _0x33ec77;}}['getReverseIterator'](_0x1f36a0){return this['getReverseIteratorFrom'](_0x1f36a0['maxPost'](),_0x1f36a0);}['getReverseIteratorFrom'](_0xeaa163,_0x33284f){const _0xebb6a5=this['resolveIndex_'](_0x33284f);if(_0xebb6a5)return _0xebb6a5['getReverseIteratorFrom'](_0xeaa163,_0x4969b6=>_0x4969b6);{const _0x1313ef=this['children_']['getReverseIteratorFrom'](_0xeaa163['name'],E['Wrap']);let _0x4be52c=_0x1313ef['peek']();for(;_0x4be52c!=null&&_0x33284f['compare'](_0x4be52c,_0xeaa163)>0x0;)_0x1313ef['getNext'](),_0x4be52c=_0x1313ef['peek']();return _0x1313ef;}}['compareTo'](_0x3c67f0){return this['isEmpty']()?_0x3c67f0['isEmpty']()?0x0:-0x1:_0x3c67f0['isLeafNode']()||_0x3c67f0['isEmpty']()?0x1:_0x3c67f0===Kt?-0x1:0x0;}['withIndex'](_0xe2b20f){if(_0xe2b20f===ve||this['indexMap_']['hasIndex'](_0xe2b20f))return this;{const _0x5b7b52=this['indexMap_']['addIndex'](_0xe2b20f,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x5b7b52);}}['isIndexed'](_0x2efba7){return _0x2efba7===ve||this['indexMap_']['hasIndex'](_0x2efba7);}['equals'](_0x14515d){if(_0x14515d===this)return!0x0;if(_0x14515d['isLeafNode']())return!0x1;{const _0xa9b115=_0x14515d;if(this['getPriority']()['equals'](_0xa9b115['getPriority']())){if(this['children_']['count']()===_0xa9b115['children_']['count']()){const _0x54cf1a=this['getIterator'](R),_0xf67689=_0xa9b115['getIterator'](R);let _0x223923=_0x54cf1a['getNext'](),_0x1f7eef=_0xf67689['getNext']();for(;_0x223923&&_0x1f7eef;){if(_0x223923['name']!==_0x1f7eef['name']||!_0x223923['node']['equals'](_0x1f7eef['node']))return!0x1;_0x223923=_0x54cf1a['getNext'](),_0x1f7eef=_0xf67689['getNext']();}return _0x223923===null&&_0x1f7eef===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x54c2bb){return _0x54c2bb===ve?null:this['indexMap_']['get'](_0x54c2bb['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x38111c){return _0x38111c===this?0x0:0x1;}['equals'](_0x2cc695){return _0x2cc695===this;}['getPriority'](){return this;}['getImmediateChild'](_0x24ee49){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x2a7c19,_0x4d4462=null){if(_0x2a7c19===null)return g['EMPTY_NODE'];if(typeof _0x2a7c19=='object'&&'.priority'in _0x2a7c19&&(_0x4d4462=_0x2a7c19['.priority']),f(_0x4d4462===null||typeof _0x4d4462=='string'||typeof _0x4d4462=='number'||typeof _0x4d4462=='object'&&'.sv'in _0x4d4462,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x4d4462),typeof _0x2a7c19=='object'&&'.value'in _0x2a7c19&&_0x2a7c19['.value']!==null&&(_0x2a7c19=_0x2a7c19['.value']),typeof _0x2a7c19!='object'||'.sv'in _0x2a7c19){const _0x562237=_0x2a7c19;return new D(_0x562237,A(_0x4d4462));}if(!(_0x2a7c19 instanceof Array)&&Gh){const _0x21167c=[];let _0x1f5119=!0x1;if(x(_0x2a7c19,(_0x167206,_0xb83711)=>{if(_0x167206['substring'](0x0,0x1)!=='.'){const _0x1f9ca9=A(_0xb83711);_0x1f9ca9['isEmpty']()||(_0x1f5119=_0x1f5119||!_0x1f9ca9['getPriority']()['isEmpty'](),_0x21167c['push'](new E(_0x167206,_0x1f9ca9)));}}),_0x21167c['length']===0x0)return g['EMPTY_NODE'];const _0x1f0681=yn(_0x21167c,xh,_0x5bbf2b=>_0x5bbf2b['name'],Qi);if(_0x1f5119){const _0x28c6f8=yn(_0x21167c,R['getCompare']());return new g(_0x1f0681,A(_0x4d4462),new te({'.priority':_0x28c6f8},{'.priority':R}));}else return new g(_0x1f0681,A(_0x4d4462),te['Default']);}else{let _0x1c91a7=g['EMPTY_NODE'];return x(_0x2a7c19,(_0x34c412,_0x232778)=>{if(Q(_0x2a7c19,_0x34c412)&&_0x34c412['substring'](0x0,0x1)!=='.'){const _0x249c4b=A(_0x232778);(_0x249c4b['isLeafNode']()||!_0x249c4b['isEmpty']())&&(_0x1c91a7=_0x1c91a7['updateImmediateChild'](_0x34c412,_0x249c4b));}}),_0x1c91a7['updatePriority'](A(_0x4d4462));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x18ed63){super(),this['indexPath_']=_0x18ed63,f(!v(_0x18ed63)&&y(_0x18ed63)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x462078){return _0x462078['getChild'](this['indexPath_']);}['isDefinedOn'](_0x5ee50b){return!_0x5ee50b['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0xb89fe1,_0x5b3374){const _0x2756e2=this['extractChild'](_0xb89fe1['node']),_0x27f9ea=this['extractChild'](_0x5b3374['node']),_0x5a359f=_0x2756e2['compareTo'](_0x27f9ea);return _0x5a359f===0x0?qe(_0xb89fe1['name'],_0x5b3374['name']):_0x5a359f;}['makePost'](_0x5d6e65,_0x19bd0d){const _0x54ad71=A(_0x5d6e65),_0xeb794e=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x54ad71);return new E(_0x19bd0d,_0xeb794e);}['maxPost'](){const _0x2cd76c=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x2cd76c);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x58d30b,_0x476acb){const _0x3194b2=_0x58d30b['node']['compareTo'](_0x476acb['node']);return _0x3194b2===0x0?qe(_0x58d30b['name'],_0x476acb['name']):_0x3194b2;}['isDefinedOn'](_0x37d0fc){return!0x0;}['indexedValueChanged'](_0x201b5f,_0x456acf){return!_0x201b5f['equals'](_0x456acf);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0xdea58e,_0x385227){const _0x2d553f=A(_0xdea58e);return new E(_0x385227,_0x2d553f);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0xf3a5dd){return{'type':'value','snapshotNode':_0xf3a5dd};}function rt(_0x4a40f6,_0x4a72e7){return{'type':'child_added','snapshotNode':_0x4a72e7,'childName':_0x4a40f6};}function Lt(_0x25f19e,_0x36c338){return{'type':'child_removed','snapshotNode':_0x36c338,'childName':_0x25f19e};}function xt(_0x2afffa,_0x1ea9a2,_0x4c720f){return{'type':'child_changed','snapshotNode':_0x1ea9a2,'childName':_0x2afffa,'oldSnap':_0x4c720f};}function zh(_0x5c38be,_0x1f9374){return{'type':'child_moved','snapshotNode':_0x1f9374,'childName':_0x5c38be};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x4c43d3){this['index_']=_0x4c43d3;}['updateChild'](_0x129d86,_0x2ee7f8,_0x28d5b6,_0x4003fa,_0x429804,_0x5765e3){f(_0x129d86['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x1ff1b6=_0x129d86['getImmediateChild'](_0x2ee7f8);return _0x1ff1b6['getChild'](_0x4003fa)['equals'](_0x28d5b6['getChild'](_0x4003fa))&&_0x1ff1b6['isEmpty']()===_0x28d5b6['isEmpty']()||(_0x5765e3!=null&&(_0x28d5b6['isEmpty']()?_0x129d86['hasChild'](_0x2ee7f8)?_0x5765e3['trackChildChange'](Lt(_0x2ee7f8,_0x1ff1b6)):f(_0x129d86['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x1ff1b6['isEmpty']()?_0x5765e3['trackChildChange'](rt(_0x2ee7f8,_0x28d5b6)):_0x5765e3['trackChildChange'](xt(_0x2ee7f8,_0x28d5b6,_0x1ff1b6))),_0x129d86['isLeafNode']()&&_0x28d5b6['isEmpty']())?_0x129d86:_0x129d86['updateImmediateChild'](_0x2ee7f8,_0x28d5b6)['withIndex'](this['index_']);}['updateFullNode'](_0x5c2f42,_0x2c2429,_0x2ad30d){return _0x2ad30d!=null&&(_0x5c2f42['isLeafNode']()||_0x5c2f42['forEachChild'](R,(_0x3e0e55,_0x1d118c)=>{_0x2c2429['hasChild'](_0x3e0e55)||_0x2ad30d['trackChildChange'](Lt(_0x3e0e55,_0x1d118c));}),_0x2c2429['isLeafNode']()||_0x2c2429['forEachChild'](R,(_0xa78f8e,_0x329cd0)=>{if(_0x5c2f42['hasChild'](_0xa78f8e)){const _0x4ba942=_0x5c2f42['getImmediateChild'](_0xa78f8e);_0x4ba942['equals'](_0x329cd0)||_0x2ad30d['trackChildChange'](xt(_0xa78f8e,_0x329cd0,_0x4ba942));}else _0x2ad30d['trackChildChange'](rt(_0xa78f8e,_0x329cd0));})),_0x2c2429['withIndex'](this['index_']);}['updatePriority'](_0xa89eb4,_0x4b6e3b){return _0xa89eb4['isEmpty']()?g['EMPTY_NODE']:_0xa89eb4['updatePriority'](_0x4b6e3b);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x14f731){this['indexedFilter_']=new Xi(_0x14f731['getIndex']()),this['index_']=_0x14f731['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x14f731),this['endPost_']=Ft['getEndPost_'](_0x14f731),this['startIsInclusive_']=!_0x14f731['startAfterSet_'],this['endIsInclusive_']=!_0x14f731['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x5e9c98){const _0x4e292d=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x5e9c98)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x5e9c98)<0x0,_0x50dbf3=this['endIsInclusive_']?this['index_']['compare'](_0x5e9c98,this['getEndPost']())<=0x0:this['index_']['compare'](_0x5e9c98,this['getEndPost']())<0x0;return _0x4e292d&&_0x50dbf3;}['updateChild'](_0x56c35c,_0x30f790,_0x318243,_0x432991,_0x435a94,_0x3f7286){return this['matches'](new E(_0x30f790,_0x318243))||(_0x318243=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x56c35c,_0x30f790,_0x318243,_0x432991,_0x435a94,_0x3f7286);}['updateFullNode'](_0x3477e2,_0x3e3d17,_0x379d48){_0x3e3d17['isLeafNode']()&&(_0x3e3d17=g['EMPTY_NODE']);let _0x5767fc=_0x3e3d17['withIndex'](this['index_']);_0x5767fc=_0x5767fc['updatePriority'](g['EMPTY_NODE']);const _0x8d1250=this;return _0x3e3d17['forEachChild'](R,(_0x49a868,_0x241328)=>{_0x8d1250['matches'](new E(_0x49a868,_0x241328))||(_0x5767fc=_0x5767fc['updateImmediateChild'](_0x49a868,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x3477e2,_0x5767fc,_0x379d48);}['updatePriority'](_0x2257dc,_0x21f8bb){return _0x2257dc;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x3660be){if(_0x3660be['hasStart']()){const _0x19ec66=_0x3660be['getIndexStartName']();return _0x3660be['getIndex']()['makePost'](_0x3660be['getIndexStartValue'](),_0x19ec66);}else return _0x3660be['getIndex']()['minPost']();}static['getEndPost_'](_0x2b1f5f){if(_0x2b1f5f['hasEnd']()){const _0x8a4f4=_0x2b1f5f['getIndexEndName']();return _0x2b1f5f['getIndex']()['makePost'](_0x2b1f5f['getIndexEndValue'](),_0x8a4f4);}else return _0x2b1f5f['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x3e223e){this['withinDirectionalStart']=_0x37b922=>this['reverse_']?this['withinEndPost'](_0x37b922):this['withinStartPost'](_0x37b922),this['withinDirectionalEnd']=_0x25ea54=>this['reverse_']?this['withinStartPost'](_0x25ea54):this['withinEndPost'](_0x25ea54),this['withinStartPost']=_0x1f96cc=>{const _0x33013b=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x1f96cc);return this['startIsInclusive_']?_0x33013b<=0x0:_0x33013b<0x0;},this['withinEndPost']=_0x5a04a4=>{const _0x4b9347=this['index_']['compare'](_0x5a04a4,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x4b9347<=0x0:_0x4b9347<0x0;},this['rangedFilter_']=new Ft(_0x3e223e),this['index_']=_0x3e223e['getIndex'](),this['limit_']=_0x3e223e['getLimit'](),this['reverse_']=!_0x3e223e['isViewFromLeft'](),this['startIsInclusive_']=!_0x3e223e['startAfterSet_'],this['endIsInclusive_']=!_0x3e223e['endBeforeSet_'];}['updateChild'](_0x15c4a0,_0x1653f,_0x4077de,_0x5d2f7d,_0x3de94e,_0x569218){return this['rangedFilter_']['matches'](new E(_0x1653f,_0x4077de))||(_0x4077de=g['EMPTY_NODE']),_0x15c4a0['getImmediateChild'](_0x1653f)['equals'](_0x4077de)?_0x15c4a0:_0x15c4a0['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x15c4a0,_0x1653f,_0x4077de,_0x5d2f7d,_0x3de94e,_0x569218):this['fullLimitUpdateChild_'](_0x15c4a0,_0x1653f,_0x4077de,_0x3de94e,_0x569218);}['updateFullNode'](_0x85295d,_0x5bbe36,_0xcee290){let _0x50a0ce;if(_0x5bbe36['isLeafNode']()||_0x5bbe36['isEmpty']())_0x50a0ce=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x5bbe36['numChildren']()&&_0x5bbe36['isIndexed'](this['index_'])){_0x50a0ce=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x30d405;this['reverse_']?_0x30d405=_0x5bbe36['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x30d405=_0x5bbe36['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x502257=0x0;for(;_0x30d405['hasNext']()&&_0x502257<this['limit_'];){const _0x261f23=_0x30d405['getNext']();if(this['withinDirectionalStart'](_0x261f23)){if(this['withinDirectionalEnd'](_0x261f23))_0x50a0ce=_0x50a0ce['updateImmediateChild'](_0x261f23['name'],_0x261f23['node']),_0x502257++;else break;}else continue;}}else{_0x50a0ce=_0x5bbe36['withIndex'](this['index_']),_0x50a0ce=_0x50a0ce['updatePriority'](g['EMPTY_NODE']);let _0x46a9d9;this['reverse_']?_0x46a9d9=_0x50a0ce['getReverseIterator'](this['index_']):_0x46a9d9=_0x50a0ce['getIterator'](this['index_']);let _0x343690=0x0;for(;_0x46a9d9['hasNext']();){const _0x1b6206=_0x46a9d9['getNext']();_0x343690<this['limit_']&&this['withinDirectionalStart'](_0x1b6206)&&this['withinDirectionalEnd'](_0x1b6206)?_0x343690++:_0x50a0ce=_0x50a0ce['updateImmediateChild'](_0x1b6206['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x85295d,_0x50a0ce,_0xcee290);}['updatePriority'](_0x212cbe,_0x525520){return _0x212cbe;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x542b56,_0x1d2055,_0x323e2a,_0x250084,_0x4c34f8){let _0x3a662f;if(this['reverse_']){const _0x2cf0a5=this['index_']['getCompare']();_0x3a662f=(_0x2fdcd0,_0x41ab6d)=>_0x2cf0a5(_0x41ab6d,_0x2fdcd0);}else _0x3a662f=this['index_']['getCompare']();const _0x102535=_0x542b56;f(_0x102535['numChildren']()===this['limit_'],'');const _0x12a72d=new E(_0x1d2055,_0x323e2a),_0x558a44=this['reverse_']?_0x102535['getFirstChild'](this['index_']):_0x102535['getLastChild'](this['index_']),_0x19232e=this['rangedFilter_']['matches'](_0x12a72d);if(_0x102535['hasChild'](_0x1d2055)){const _0x1ed35a=_0x102535['getImmediateChild'](_0x1d2055);let _0x3a0efd=_0x250084['getChildAfterChild'](this['index_'],_0x558a44,this['reverse_']);for(;_0x3a0efd!=null&&(_0x3a0efd['name']===_0x1d2055||_0x102535['hasChild'](_0x3a0efd['name']));)_0x3a0efd=_0x250084['getChildAfterChild'](this['index_'],_0x3a0efd,this['reverse_']);const _0x489d86=_0x3a0efd==null?0x1:_0x3a662f(_0x3a0efd,_0x12a72d);if(_0x19232e&&!_0x323e2a['isEmpty']()&&_0x489d86>=0x0)return _0x4c34f8!=null&&_0x4c34f8['trackChildChange'](xt(_0x1d2055,_0x323e2a,_0x1ed35a)),_0x102535['updateImmediateChild'](_0x1d2055,_0x323e2a);{_0x4c34f8!=null&&_0x4c34f8['trackChildChange'](Lt(_0x1d2055,_0x1ed35a));const _0x578aef=_0x102535['updateImmediateChild'](_0x1d2055,g['EMPTY_NODE']);return _0x3a0efd!=null&&this['rangedFilter_']['matches'](_0x3a0efd)?(_0x4c34f8!=null&&_0x4c34f8['trackChildChange'](rt(_0x3a0efd['name'],_0x3a0efd['node'])),_0x578aef['updateImmediateChild'](_0x3a0efd['name'],_0x3a0efd['node'])):_0x578aef;}}else return _0x323e2a['isEmpty']()?_0x542b56:_0x19232e&&_0x3a662f(_0x558a44,_0x12a72d)>=0x0?(_0x4c34f8!=null&&(_0x4c34f8['trackChildChange'](Lt(_0x558a44['name'],_0x558a44['node'])),_0x4c34f8['trackChildChange'](rt(_0x1d2055,_0x323e2a))),_0x102535['updateImmediateChild'](_0x1d2055,_0x323e2a)['updateImmediateChild'](_0x558a44['name'],g['EMPTY_NODE'])):_0x542b56;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x5d0e5d=new Zi();return _0x5d0e5d['limitSet_']=this['limitSet_'],_0x5d0e5d['limit_']=this['limit_'],_0x5d0e5d['startSet_']=this['startSet_'],_0x5d0e5d['startAfterSet_']=this['startAfterSet_'],_0x5d0e5d['indexStartValue_']=this['indexStartValue_'],_0x5d0e5d['startNameSet_']=this['startNameSet_'],_0x5d0e5d['indexStartName_']=this['indexStartName_'],_0x5d0e5d['endSet_']=this['endSet_'],_0x5d0e5d['endBeforeSet_']=this['endBeforeSet_'],_0x5d0e5d['indexEndValue_']=this['indexEndValue_'],_0x5d0e5d['endNameSet_']=this['endNameSet_'],_0x5d0e5d['indexEndName_']=this['indexEndName_'],_0x5d0e5d['index_']=this['index_'],_0x5d0e5d['viewFrom_']=this['viewFrom_'],_0x5d0e5d;}}function Kh(_0x4450a8){return _0x4450a8['loadsAllData']()?new Xi(_0x4450a8['getIndex']()):_0x4450a8['hasLimit']()?new jh(_0x4450a8):new Ft(_0x4450a8);}function Yh(_0x5cb530,_0x3f70a4){const _0x4e9a0c=_0x5cb530['copy']();return _0x4e9a0c['limitSet_']=!0x0,_0x4e9a0c['limit_']=_0x3f70a4,_0x4e9a0c['viewFrom_']='l',_0x4e9a0c;}function Qh(_0x182f0a,_0xee5daa,_0xf6b46a){const _0x5bc797=_0x182f0a['copy']();return _0x5bc797['startSet_']=!0x0,_0xee5daa===void 0x0&&(_0xee5daa=null),_0x5bc797['indexStartValue_']=_0xee5daa,_0xf6b46a!=null?(_0x5bc797['startNameSet_']=!0x0,_0x5bc797['indexStartName_']=_0xf6b46a):(_0x5bc797['startNameSet_']=!0x1,_0x5bc797['indexStartName_']=''),_0x5bc797;}function Jh(_0x4026b5,_0x308f69,_0x2b5842){const _0x9cc73f=_0x4026b5['copy']();return _0x9cc73f['endSet_']=!0x0,_0x308f69===void 0x0&&(_0x308f69=null),_0x9cc73f['indexEndValue_']=_0x308f69,_0x2b5842!==void 0x0?(_0x9cc73f['endNameSet_']=!0x0,_0x9cc73f['indexEndName_']=_0x2b5842):(_0x9cc73f['endNameSet_']=!0x1,_0x9cc73f['indexEndName_']=''),_0x9cc73f;}function xo(_0x464554,_0x399875){const _0x381f2c=_0x464554['copy']();return _0x381f2c['index_']=_0x399875,_0x381f2c;}function ir(_0x34f462){const _0x20b9a6={};if(_0x34f462['isDefault']())return _0x20b9a6;let _0x50b182;if(_0x34f462['index_']===R?_0x50b182='$priority':_0x34f462['index_']===Mo?_0x50b182='$value':_0x34f462['index_']===ve?_0x50b182='$key':(f(_0x34f462['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x50b182=_0x34f462['index_']['toString']()),_0x20b9a6['orderBy']=O(_0x50b182),_0x34f462['startSet_']){const _0x4953e5=_0x34f462['startAfterSet_']?'startAfter':'startAt';_0x20b9a6[_0x4953e5]=O(_0x34f462['indexStartValue_']),_0x34f462['startNameSet_']&&(_0x20b9a6[_0x4953e5]+=','+O(_0x34f462['indexStartName_']));}if(_0x34f462['endSet_']){const _0x1b348e=_0x34f462['endBeforeSet_']?'endBefore':'endAt';_0x20b9a6[_0x1b348e]=O(_0x34f462['indexEndValue_']),_0x34f462['endNameSet_']&&(_0x20b9a6[_0x1b348e]+=','+O(_0x34f462['indexEndName_']));}return _0x34f462['limitSet_']&&(_0x34f462['isViewFromLeft']()?_0x20b9a6['limitToFirst']=_0x34f462['limit_']:_0x20b9a6['limitToLast']=_0x34f462['limit_']),_0x20b9a6;}function sr(_0xcaf1f){const _0x845029={};if(_0xcaf1f['startSet_']&&(_0x845029['sp']=_0xcaf1f['indexStartValue_'],_0xcaf1f['startNameSet_']&&(_0x845029['sn']=_0xcaf1f['indexStartName_']),_0x845029['sin']=!_0xcaf1f['startAfterSet_']),_0xcaf1f['endSet_']&&(_0x845029['ep']=_0xcaf1f['indexEndValue_'],_0xcaf1f['endNameSet_']&&(_0x845029['en']=_0xcaf1f['indexEndName_']),_0x845029['ein']=!_0xcaf1f['endBeforeSet_']),_0xcaf1f['limitSet_']){_0x845029['l']=_0xcaf1f['limit_'];let _0x38cb8d=_0xcaf1f['viewFrom_'];_0x38cb8d===''&&(_0xcaf1f['isViewFromLeft']()?_0x38cb8d='l':_0x38cb8d='r'),_0x845029['vf']=_0x38cb8d;}return _0xcaf1f['index_']!==R&&(_0x845029['i']=_0xcaf1f['index_']['toString']()),_0x845029;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x24f092){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x2fd761,_0x2877a6){return _0x2877a6!==void 0x0?'tag$'+_0x2877a6:(f(_0x2fd761['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x2fd761['_path']['toString']());}constructor(_0x45ed99,_0x28f8ec,_0x2e22d2,_0x9fbb50){super(),this['repoInfo_']=_0x45ed99,this['onDataUpdate_']=_0x28f8ec,this['authTokenProvider_']=_0x2e22d2,this['appCheckTokenProvider_']=_0x9fbb50,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0xc3d852,_0x4f7391,_0x28320a,_0x628e74){const _0x514c9d=_0xc3d852['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x514c9d+'\x20'+_0xc3d852['_queryIdentifier']);const _0x174b94=vn['getListenId_'](_0xc3d852,_0x28320a),_0x5c6579={};this['listens_'][_0x174b94]=_0x5c6579;const _0x1bd8ec=ir(_0xc3d852['_queryParams']);this['restRequest_'](_0x514c9d+'.json',_0x1bd8ec,(_0x594cdd,_0x39dbc0)=>{let _0x4a202d=_0x39dbc0;if(_0x594cdd===0x194&&(_0x4a202d=null,_0x594cdd=null),_0x594cdd===null&&this['onDataUpdate_'](_0x514c9d,_0x4a202d,!0x1,_0x28320a),Le(this['listens_'],_0x174b94)===_0x5c6579){let _0x30464b;_0x594cdd?_0x594cdd===0x191?_0x30464b='permission_denied':_0x30464b='rest_error:'+_0x594cdd:_0x30464b='ok',_0x628e74(_0x30464b,null);}});}['unlisten'](_0x74a823,_0x2d0587){const _0x1fc380=vn['getListenId_'](_0x74a823,_0x2d0587);delete this['listens_'][_0x1fc380];}['get'](_0x53696a){const _0x4c98bd=ir(_0x53696a['_queryParams']),_0x19b4df=_0x53696a['_path']['toString'](),_0x5aa8de=new H();return this['restRequest_'](_0x19b4df+'.json',_0x4c98bd,(_0x53b977,_0x56b1f7)=>{let _0x5bfa01=_0x56b1f7;_0x53b977===0x194&&(_0x5bfa01=null,_0x53b977=null),_0x53b977===null?(this['onDataUpdate_'](_0x19b4df,_0x5bfa01,!0x1,null),_0x5aa8de['resolve'](_0x5bfa01)):_0x5aa8de['reject'](new Error(_0x5bfa01));}),_0x5aa8de['promise'];}['refreshAuthToken'](_0x1ae695){}['restRequest_'](_0x21fcaa,_0x4ace98={},_0x45aab8){return _0x4ace98['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x55c3bb,_0x1e4627])=>{_0x55c3bb&&_0x55c3bb['accessToken']&&(_0x4ace98['auth']=_0x55c3bb['accessToken']),_0x1e4627&&_0x1e4627['token']&&(_0x4ace98['ac']=_0x1e4627['token']);const _0x3254af=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x21fcaa+'?ns='+this['repoInfo_']['namespace']+ut(_0x4ace98);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x3254af);const _0x3372cf=new XMLHttpRequest();_0x3372cf['onreadystatechange']=()=>{if(_0x45aab8&&_0x3372cf['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x3254af+'\x20received.\x20status:',_0x3372cf['status'],'response:',_0x3372cf['responseText']);let _0x1dd8b2=null;if(_0x3372cf['status']>=0xc8&&_0x3372cf['status']<0x12c){try{_0x1dd8b2=Nt(_0x3372cf['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x3254af+':\x20'+_0x3372cf['responseText']);}_0x45aab8(null,_0x1dd8b2);}else _0x3372cf['status']!==0x191&&_0x3372cf['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x3254af+'\x20Status:\x20'+_0x3372cf['status']),_0x45aab8(_0x3372cf['status']);_0x45aab8=null;}},_0x3372cf['open']('GET',_0x3254af,!0x0),_0x3372cf['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x322bf9){return this['rootNode_']['getChild'](_0x322bf9);}['updateSnapshot'](_0x218c6e,_0x8db7b){this['rootNode_']=this['rootNode_']['updateChild'](_0x218c6e,_0x8db7b);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x5897cf,_0x4a24fb,_0x5c0463){if(v(_0x4a24fb))_0x5897cf['value']=_0x5c0463,_0x5897cf['children']['clear']();else{if(_0x5897cf['value']!==null)_0x5897cf['value']=_0x5897cf['value']['updateChild'](_0x4a24fb,_0x5c0463);else{const _0x94698a=y(_0x4a24fb);_0x5897cf['children']['has'](_0x94698a)||_0x5897cf['children']['set'](_0x94698a,En());const _0x7884d0=_0x5897cf['children']['get'](_0x94698a);_0x4a24fb=S(_0x4a24fb),pt(_0x7884d0,_0x4a24fb,_0x5c0463);}}}function Ti(_0x261d24,_0x5d1c59){if(v(_0x5d1c59))return _0x261d24['value']=null,_0x261d24['children']['clear'](),!0x0;if(_0x261d24['value']!==null){if(_0x261d24['value']['isLeafNode']())return!0x1;{const _0x90bf3b=_0x261d24['value'];return _0x261d24['value']=null,_0x90bf3b['forEachChild'](R,(_0x447bd5,_0x4ebf36)=>{pt(_0x261d24,new C(_0x447bd5),_0x4ebf36);}),Ti(_0x261d24,_0x5d1c59);}}else{if(_0x261d24['children']['size']>0x0){const _0x4135a9=y(_0x5d1c59);return _0x5d1c59=S(_0x5d1c59),_0x261d24['children']['has'](_0x4135a9)&&Ti(_0x261d24['children']['get'](_0x4135a9),_0x5d1c59)&&_0x261d24['children']['delete'](_0x4135a9),_0x261d24['children']['size']===0x0;}else return!0x0;}}function Si(_0x5936ea,_0x83a292,_0x191b8e){_0x5936ea['value']!==null?_0x191b8e(_0x83a292,_0x5936ea['value']):Zh(_0x5936ea,(_0x24e18e,_0x21eb6f)=>{const _0x34546a=new C(_0x83a292['toString']()+'/'+_0x24e18e);Si(_0x21eb6f,_0x34546a,_0x191b8e);});}function Zh(_0x3d785a,_0x583333){_0x3d785a['children']['forEach']((_0xd5648f,_0x436469)=>{_0x583333(_0x436469,_0xd5648f);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x42f9d2){this['collection_']=_0x42f9d2,this['last_']=null;}['get'](){const _0x4b5232=this['collection_']['get'](),_0x2b2901={..._0x4b5232};return this['last_']&&x(this['last_'],(_0x1cd905,_0x5f0786)=>{_0x2b2901[_0x1cd905]=_0x2b2901[_0x1cd905]-_0x5f0786;}),this['last_']=_0x4b5232,_0x2b2901;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x11f017,_0x5dcc56){this['server_']=_0x5dcc56,this['statsToReport_']={},this['statsListener_']=new eu(_0x11f017);const _0x2c359d=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x2c359d));}['reportStats_'](){const _0x1a9003=this['statsListener_']['get'](),_0x563c0e={};let _0x24ff83=!0x1;x(_0x1a9003,(_0x3d5dda,_0x417696)=>{_0x417696>0x0&&Q(this['statsToReport_'],_0x3d5dda)&&(_0x563c0e[_0x3d5dda]=_0x417696,_0x24ff83=!0x0);}),_0x24ff83&&this['server_']['reportStats'](_0x563c0e),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x50c320){_0x50c320[_0x50c320['OVERWRITE']=0x0]='OVERWRITE',_0x50c320[_0x50c320['MERGE']=0x1]='MERGE',_0x50c320[_0x50c320['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x50c320[_0x50c320['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x1660e3){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x1660e3,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x19b892,_0x6a810c,_0x18f110){this['path']=_0x19b892,this['affectedTree']=_0x6a810c,this['revert']=_0x18f110,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x130f06){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x477240=this['affectedTree']['subtree'](new C(_0x130f06));return new In(w(),_0x477240,this['revert']);}}else return f(y(this['path'])===_0x130f06,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x3c77bf,_0x2993d8){this['source']=_0x3c77bf,this['path']=_0x2993d8,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x11aec9){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x28ce00,_0x2a9b08,_0x8ebfde){this['source']=_0x28ce00,this['path']=_0x2a9b08,this['snap']=_0x8ebfde,this['type']=z['OVERWRITE'];}['operationForChild'](_0x53799e){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x53799e)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x2fde69,_0x5555d4,_0x5bb9d1){this['source']=_0x2fde69,this['path']=_0x5555d4,this['children']=_0x5bb9d1,this['type']=z['MERGE'];}['operationForChild'](_0x31db4a){if(v(this['path'])){const _0x27d45f=this['children']['subtree'](new C(_0x31db4a));return _0x27d45f['isEmpty']()?null:_0x27d45f['value']?new Be(this['source'],w(),_0x27d45f['value']):new ot(this['source'],w(),_0x27d45f);}else return f(y(this['path'])===_0x31db4a,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0xb8e190,_0x872f88,_0x32bf6a){this['node_']=_0xb8e190,this['fullyInitialized_']=_0x872f88,this['filtered_']=_0x32bf6a;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x5c2bbb){if(v(_0x5c2bbb))return this['isFullyInitialized']()&&!this['filtered_'];const _0x5ae002=y(_0x5c2bbb);return this['isCompleteForChild'](_0x5ae002);}['isCompleteForChild'](_0x2dc48f){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x2dc48f);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x51a8f5){this['query_']=_0x51a8f5,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x59edde,_0x2b6220,_0x57e17d,_0x32a43c){const _0x16a672=[],_0x36310d=[];return _0x2b6220['forEach'](_0x3eae5a=>{_0x3eae5a['type']==='child_changed'&&_0x59edde['index_']['indexedValueChanged'](_0x3eae5a['oldSnap'],_0x3eae5a['snapshotNode'])&&_0x36310d['push'](zh(_0x3eae5a['childName'],_0x3eae5a['snapshotNode']));}),wt(_0x59edde,_0x16a672,'child_removed',_0x2b6220,_0x32a43c,_0x57e17d),wt(_0x59edde,_0x16a672,'child_added',_0x2b6220,_0x32a43c,_0x57e17d),wt(_0x59edde,_0x16a672,'child_moved',_0x36310d,_0x32a43c,_0x57e17d),wt(_0x59edde,_0x16a672,'child_changed',_0x2b6220,_0x32a43c,_0x57e17d),wt(_0x59edde,_0x16a672,'value',_0x2b6220,_0x32a43c,_0x57e17d),_0x16a672;}function wt(_0x3faf04,_0x2165e8,_0x19a699,_0x1463b3,_0x3321f8,_0x49ca02){const _0xf3b0aa=_0x1463b3['filter'](_0x2f9342=>_0x2f9342['type']===_0x19a699);_0xf3b0aa['sort']((_0x1e3fdb,_0x207f0d)=>au(_0x3faf04,_0x1e3fdb,_0x207f0d)),_0xf3b0aa['forEach'](_0x1df110=>{const _0x5acd17=ou(_0x3faf04,_0x1df110,_0x49ca02);_0x3321f8['forEach'](_0x50e0fd=>{_0x50e0fd['respondsTo'](_0x1df110['type'])&&_0x2165e8['push'](_0x50e0fd['createEvent'](_0x5acd17,_0x3faf04['query_']));});});}function ou(_0x5bbbea,_0x373fb6,_0x55a8c8){return _0x373fb6['type']==='value'||_0x373fb6['type']==='child_removed'||(_0x373fb6['prevName']=_0x55a8c8['getPredecessorChildName'](_0x373fb6['childName'],_0x373fb6['snapshotNode'],_0x5bbbea['index_'])),_0x373fb6;}function au(_0x5a1071,_0x1b236a,_0x578e14){if(_0x1b236a['childName']==null||_0x578e14['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x3055e3=new E(_0x1b236a['childName'],_0x1b236a['snapshotNode']),_0x460176=new E(_0x578e14['childName'],_0x578e14['snapshotNode']);return _0x5a1071['index_']['compare'](_0x3055e3,_0x460176);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x3e9531,_0x5f2283){return{'eventCache':_0x3e9531,'serverCache':_0x5f2283};}function Rt(_0x1c03d6,_0x237261,_0x5d0da3,_0x37c108){return Un(new Te(_0x237261,_0x5d0da3,_0x37c108),_0x1c03d6['serverCache']);}function Fo(_0x35a768,_0x337af4,_0x1e35f2,_0x1ad2b5){return Un(_0x35a768['eventCache'],new Te(_0x337af4,_0x1e35f2,_0x1ad2b5));}function wn(_0x1a480f){return _0x1a480f['eventCache']['isFullyInitialized']()?_0x1a480f['eventCache']['getNode']():null;}function Ve(_0xba9bf6){return _0xba9bf6['serverCache']['isFullyInitialized']()?_0xba9bf6['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x2992d0){let _0x37e139=new b(null);return x(_0x2992d0,(_0x3d11d0,_0x37de3c)=>{_0x37e139=_0x37e139['set'](new C(_0x3d11d0),_0x37de3c);}),_0x37e139;}constructor(_0x3cd531,_0x14277c=cu()){this['value']=_0x3cd531,this['children']=_0x14277c;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x1c7683,_0x2ce785){if(this['value']!=null&&_0x2ce785(this['value']))return{'path':w(),'value':this['value']};if(v(_0x1c7683))return null;{const _0x125aba=y(_0x1c7683),_0x4b9a30=this['children']['get'](_0x125aba);if(_0x4b9a30!==null){const _0xad4508=_0x4b9a30['findRootMostMatchingPathAndValue'](S(_0x1c7683),_0x2ce785);return _0xad4508!=null?{'path':k(new C(_0x125aba),_0xad4508['path']),'value':_0xad4508['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x3124b5){return this['findRootMostMatchingPathAndValue'](_0x3124b5,()=>!0x0);}['subtree'](_0x556151){if(v(_0x556151))return this;{const _0x483625=y(_0x556151),_0x3245d9=this['children']['get'](_0x483625);return _0x3245d9!==null?_0x3245d9['subtree'](S(_0x556151)):new b(null);}}['set'](_0xaeaa5c,_0x26ee2e){if(v(_0xaeaa5c))return new b(_0x26ee2e,this['children']);{const _0x494045=y(_0xaeaa5c),_0x855db2=(this['children']['get'](_0x494045)||new b(null))['set'](S(_0xaeaa5c),_0x26ee2e),_0x3efe71=this['children']['insert'](_0x494045,_0x855db2);return new b(this['value'],_0x3efe71);}}['remove'](_0x5207e9){if(v(_0x5207e9))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x3f3d81=y(_0x5207e9),_0x413aac=this['children']['get'](_0x3f3d81);if(_0x413aac){const _0x38b53e=_0x413aac['remove'](S(_0x5207e9));let _0xf69b56;return _0x38b53e['isEmpty']()?_0xf69b56=this['children']['remove'](_0x3f3d81):_0xf69b56=this['children']['insert'](_0x3f3d81,_0x38b53e),this['value']===null&&_0xf69b56['isEmpty']()?new b(null):new b(this['value'],_0xf69b56);}else return this;}}['get'](_0x13b92f){if(v(_0x13b92f))return this['value'];{const _0x27b71c=y(_0x13b92f),_0x40fc42=this['children']['get'](_0x27b71c);return _0x40fc42?_0x40fc42['get'](S(_0x13b92f)):null;}}['setTree'](_0x5d1100,_0x511775){if(v(_0x5d1100))return _0x511775;{const _0x176751=y(_0x5d1100),_0x49e332=(this['children']['get'](_0x176751)||new b(null))['setTree'](S(_0x5d1100),_0x511775);let _0x2ff017;return _0x49e332['isEmpty']()?_0x2ff017=this['children']['remove'](_0x176751):_0x2ff017=this['children']['insert'](_0x176751,_0x49e332),new b(this['value'],_0x2ff017);}}['fold'](_0x4a9d04){return this['fold_'](w(),_0x4a9d04);}['fold_'](_0x1e6392,_0x26093d){const _0x2a3d7d={};return this['children']['inorderTraversal']((_0xbefa1,_0x4616da)=>{_0x2a3d7d[_0xbefa1]=_0x4616da['fold_'](k(_0x1e6392,_0xbefa1),_0x26093d);}),_0x26093d(_0x1e6392,this['value'],_0x2a3d7d);}['findOnPath'](_0xd842a8,_0x42ebd8){return this['findOnPath_'](_0xd842a8,w(),_0x42ebd8);}['findOnPath_'](_0x22ad24,_0x35caea,_0x2fbea5){const _0x55ecd3=this['value']?_0x2fbea5(_0x35caea,this['value']):!0x1;if(_0x55ecd3)return _0x55ecd3;if(v(_0x22ad24))return null;{const _0x4873a5=y(_0x22ad24),_0x5af998=this['children']['get'](_0x4873a5);return _0x5af998?_0x5af998['findOnPath_'](S(_0x22ad24),k(_0x35caea,_0x4873a5),_0x2fbea5):null;}}['foreachOnPath'](_0x155fd1,_0xb0ef28){return this['foreachOnPath_'](_0x155fd1,w(),_0xb0ef28);}['foreachOnPath_'](_0x35be3a,_0x10119f,_0x4a2c8b){if(v(_0x35be3a))return this;{this['value']&&_0x4a2c8b(_0x10119f,this['value']);const _0x42d8a9=y(_0x35be3a),_0x3b9a43=this['children']['get'](_0x42d8a9);return _0x3b9a43?_0x3b9a43['foreachOnPath_'](S(_0x35be3a),k(_0x10119f,_0x42d8a9),_0x4a2c8b):new b(null);}}['foreach'](_0x2bcff5){this['foreach_'](w(),_0x2bcff5);}['foreach_'](_0x4a5172,_0x3f7bfa){this['children']['inorderTraversal']((_0x29f4ed,_0x29750f)=>{_0x29750f['foreach_'](k(_0x4a5172,_0x29f4ed),_0x3f7bfa);}),this['value']&&_0x3f7bfa(_0x4a5172,this['value']);}['foreachChild'](_0x5f3289){this['children']['inorderTraversal']((_0x417743,_0x355aad)=>{_0x355aad['value']&&_0x5f3289(_0x417743,_0x355aad['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x2d0912){this['writeTree_']=_0x2d0912;}static['empty'](){return new K(new b(null));}}function At(_0x2cd54f,_0x5a8404,_0x2c3673){if(v(_0x5a8404))return new K(new b(_0x2c3673));{const _0x511ba0=_0x2cd54f['writeTree_']['findRootMostValueAndPath'](_0x5a8404);if(_0x511ba0!=null){const _0x20ea15=_0x511ba0['path'];let _0x3213da=_0x511ba0['value'];const _0x78ca4f=F(_0x20ea15,_0x5a8404);return _0x3213da=_0x3213da['updateChild'](_0x78ca4f,_0x2c3673),new K(_0x2cd54f['writeTree_']['set'](_0x20ea15,_0x3213da));}else{const _0x4ad1c4=new b(_0x2c3673),_0x1b14f5=_0x2cd54f['writeTree_']['setTree'](_0x5a8404,_0x4ad1c4);return new K(_0x1b14f5);}}}function bi(_0x3fe932,_0x3ff201,_0x15b90b){let _0x5e63f3=_0x3fe932;return x(_0x15b90b,(_0x3b0ac0,_0x17fc2e)=>{_0x5e63f3=At(_0x5e63f3,k(_0x3ff201,_0x3b0ac0),_0x17fc2e);}),_0x5e63f3;}function or(_0x52a84d,_0x92308c){if(v(_0x92308c))return K['empty']();{const _0x5238fb=_0x52a84d['writeTree_']['setTree'](_0x92308c,new b(null));return new K(_0x5238fb);}}function Ri(_0x519783,_0xdb3a91){return ze(_0x519783,_0xdb3a91)!=null;}function ze(_0x5320a3,_0x2c51c9){const _0x4a5f82=_0x5320a3['writeTree_']['findRootMostValueAndPath'](_0x2c51c9);return _0x4a5f82!=null?_0x5320a3['writeTree_']['get'](_0x4a5f82['path'])['getChild'](F(_0x4a5f82['path'],_0x2c51c9)):null;}function ar(_0x1763e4){const _0x589fb9=[],_0xc2b06c=_0x1763e4['writeTree_']['value'];return _0xc2b06c!=null?_0xc2b06c['isLeafNode']()||_0xc2b06c['forEachChild'](R,(_0x397cd1,_0x2a150c)=>{_0x589fb9['push'](new E(_0x397cd1,_0x2a150c));}):_0x1763e4['writeTree_']['children']['inorderTraversal']((_0x4609d8,_0x4b14a4)=>{_0x4b14a4['value']!=null&&_0x589fb9['push'](new E(_0x4609d8,_0x4b14a4['value']));}),_0x589fb9;}function Ee(_0x48ca28,_0x348de7){if(v(_0x348de7))return _0x48ca28;{const _0x2ab147=ze(_0x48ca28,_0x348de7);return _0x2ab147!=null?new K(new b(_0x2ab147)):new K(_0x48ca28['writeTree_']['subtree'](_0x348de7));}}function Ai(_0x40e0b7){return _0x40e0b7['writeTree_']['isEmpty']();}function at(_0x300463,_0x1cd83d){return Uo(w(),_0x300463['writeTree_'],_0x1cd83d);}function Uo(_0x24aca0,_0x26e44a,_0x4ceddf){if(_0x26e44a['value']!=null)return _0x4ceddf['updateChild'](_0x24aca0,_0x26e44a['value']);{let _0x1d998c=null;return _0x26e44a['children']['inorderTraversal']((_0x58422a,_0x543983)=>{_0x58422a==='.priority'?(f(_0x543983['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x1d998c=_0x543983['value']):_0x4ceddf=Uo(k(_0x24aca0,_0x58422a),_0x543983,_0x4ceddf);}),!_0x4ceddf['getChild'](_0x24aca0)['isEmpty']()&&_0x1d998c!==null&&(_0x4ceddf=_0x4ceddf['updateChild'](k(_0x24aca0,'.priority'),_0x1d998c)),_0x4ceddf;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x10b104,_0x5c38b5){return Ho(_0x5c38b5,_0x10b104);}function lu(_0x1217bb,_0x250c91,_0x2af251,_0x11e995,_0x3b294b){f(_0x11e995>_0x1217bb['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x3b294b===void 0x0&&(_0x3b294b=!0x0),_0x1217bb['allWrites']['push']({'path':_0x250c91,'snap':_0x2af251,'writeId':_0x11e995,'visible':_0x3b294b}),_0x3b294b&&(_0x1217bb['visibleWrites']=At(_0x1217bb['visibleWrites'],_0x250c91,_0x2af251)),_0x1217bb['lastWriteId']=_0x11e995;}function hu(_0x21e801,_0x108730,_0x48c610,_0x3c82ba){f(_0x3c82ba>_0x21e801['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x21e801['allWrites']['push']({'path':_0x108730,'children':_0x48c610,'writeId':_0x3c82ba,'visible':!0x0}),_0x21e801['visibleWrites']=bi(_0x21e801['visibleWrites'],_0x108730,_0x48c610),_0x21e801['lastWriteId']=_0x3c82ba;}function uu(_0x512f99,_0x397ed0){for(let _0x2f1457=0x0;_0x2f1457<_0x512f99['allWrites']['length'];_0x2f1457++){const _0x58e36c=_0x512f99['allWrites'][_0x2f1457];if(_0x58e36c['writeId']===_0x397ed0)return _0x58e36c;}return null;}function du(_0x1d442c,_0x47cd8f){const _0x1394e7=_0x1d442c['allWrites']['findIndex'](_0x4393bf=>_0x4393bf['writeId']===_0x47cd8f);f(_0x1394e7>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x29a4a5=_0x1d442c['allWrites'][_0x1394e7];_0x1d442c['allWrites']['splice'](_0x1394e7,0x1);let _0x5b837b=_0x29a4a5['visible'],_0x446cf0=!0x1,_0x50e602=_0x1d442c['allWrites']['length']-0x1;for(;_0x5b837b&&_0x50e602>=0x0;){const _0x527b7b=_0x1d442c['allWrites'][_0x50e602];_0x527b7b['visible']&&(_0x50e602>=_0x1394e7&&fu(_0x527b7b,_0x29a4a5['path'])?_0x5b837b=!0x1:G(_0x29a4a5['path'],_0x527b7b['path'])&&(_0x446cf0=!0x0)),_0x50e602--;}if(_0x5b837b){if(_0x446cf0)return pu(_0x1d442c),!0x0;if(_0x29a4a5['snap'])_0x1d442c['visibleWrites']=or(_0x1d442c['visibleWrites'],_0x29a4a5['path']);else{const _0x53cf89=_0x29a4a5['children'];x(_0x53cf89,_0x236dc0=>{_0x1d442c['visibleWrites']=or(_0x1d442c['visibleWrites'],k(_0x29a4a5['path'],_0x236dc0));});}return!0x0;}else return!0x1;}function fu(_0x114bb4,_0x84cd26){if(_0x114bb4['snap'])return G(_0x114bb4['path'],_0x84cd26);for(const _0x71eea2 in _0x114bb4['children'])if(_0x114bb4['children']['hasOwnProperty'](_0x71eea2)&&G(k(_0x114bb4['path'],_0x71eea2),_0x84cd26))return!0x0;return!0x1;}function pu(_0x398259){_0x398259['visibleWrites']=Wo(_0x398259['allWrites'],_u,w()),_0x398259['allWrites']['length']>0x0?_0x398259['lastWriteId']=_0x398259['allWrites'][_0x398259['allWrites']['length']-0x1]['writeId']:_0x398259['lastWriteId']=-0x1;}function _u(_0x3043fc){return _0x3043fc['visible'];}function Wo(_0x25acd,_0x41de7d,_0x24d6e){let _0x14b497=K['empty']();for(let _0x3d23a1=0x0;_0x3d23a1<_0x25acd['length'];++_0x3d23a1){const _0x453ae4=_0x25acd[_0x3d23a1];if(_0x41de7d(_0x453ae4)){const _0x34bbe3=_0x453ae4['path'];let _0x187549;if(_0x453ae4['snap'])G(_0x24d6e,_0x34bbe3)?(_0x187549=F(_0x24d6e,_0x34bbe3),_0x14b497=At(_0x14b497,_0x187549,_0x453ae4['snap'])):G(_0x34bbe3,_0x24d6e)&&(_0x187549=F(_0x34bbe3,_0x24d6e),_0x14b497=At(_0x14b497,w(),_0x453ae4['snap']['getChild'](_0x187549)));else{if(_0x453ae4['children']){if(G(_0x24d6e,_0x34bbe3))_0x187549=F(_0x24d6e,_0x34bbe3),_0x14b497=bi(_0x14b497,_0x187549,_0x453ae4['children']);else{if(G(_0x34bbe3,_0x24d6e)){if(_0x187549=F(_0x34bbe3,_0x24d6e),v(_0x187549))_0x14b497=bi(_0x14b497,w(),_0x453ae4['children']);else{const _0x4afa1f=Le(_0x453ae4['children'],y(_0x187549));if(_0x4afa1f){const _0xebc83=_0x4afa1f['getChild'](S(_0x187549));_0x14b497=At(_0x14b497,w(),_0xebc83);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x14b497;}function Bo(_0x5dc853,_0x1a05ff,_0xfcb0f3,_0x14f20f,_0x2373b2){if(!_0x14f20f&&!_0x2373b2){const _0x5a5fb0=ze(_0x5dc853['visibleWrites'],_0x1a05ff);if(_0x5a5fb0!=null)return _0x5a5fb0;{const _0xac3757=Ee(_0x5dc853['visibleWrites'],_0x1a05ff);if(Ai(_0xac3757))return _0xfcb0f3;if(_0xfcb0f3==null&&!Ri(_0xac3757,w()))return null;{const _0x400411=_0xfcb0f3||g['EMPTY_NODE'];return at(_0xac3757,_0x400411);}}}else{const _0x2ba882=Ee(_0x5dc853['visibleWrites'],_0x1a05ff);if(!_0x2373b2&&Ai(_0x2ba882))return _0xfcb0f3;if(!_0x2373b2&&_0xfcb0f3==null&&!Ri(_0x2ba882,w()))return null;{const _0x41ed44=function(_0x8b626d){return(_0x8b626d['visible']||_0x2373b2)&&(!_0x14f20f||!~_0x14f20f['indexOf'](_0x8b626d['writeId']))&&(G(_0x8b626d['path'],_0x1a05ff)||G(_0x1a05ff,_0x8b626d['path']));},_0x4ce7cb=Wo(_0x5dc853['allWrites'],_0x41ed44,_0x1a05ff),_0x195f9c=_0xfcb0f3||g['EMPTY_NODE'];return at(_0x4ce7cb,_0x195f9c);}}}function gu(_0x3f5529,_0x53c44d,_0x4efbae){let _0x4036af=g['EMPTY_NODE'];const _0x2e3a16=ze(_0x3f5529['visibleWrites'],_0x53c44d);if(_0x2e3a16)return _0x2e3a16['isLeafNode']()||_0x2e3a16['forEachChild'](R,(_0x22375c,_0x497530)=>{_0x4036af=_0x4036af['updateImmediateChild'](_0x22375c,_0x497530);}),_0x4036af;if(_0x4efbae){const _0x5d50c1=Ee(_0x3f5529['visibleWrites'],_0x53c44d);return _0x4efbae['forEachChild'](R,(_0x5a1c43,_0xdc1e39)=>{const _0x236b1e=at(Ee(_0x5d50c1,new C(_0x5a1c43)),_0xdc1e39);_0x4036af=_0x4036af['updateImmediateChild'](_0x5a1c43,_0x236b1e);}),ar(_0x5d50c1)['forEach'](_0x5f5693=>{_0x4036af=_0x4036af['updateImmediateChild'](_0x5f5693['name'],_0x5f5693['node']);}),_0x4036af;}else{const _0x4a9df0=Ee(_0x3f5529['visibleWrites'],_0x53c44d);return ar(_0x4a9df0)['forEach'](_0x4d181f=>{_0x4036af=_0x4036af['updateImmediateChild'](_0x4d181f['name'],_0x4d181f['node']);}),_0x4036af;}}function mu(_0x7f5889,_0x27203c,_0x2cad77,_0x87dd73,_0x1dde25){f(_0x87dd73||_0x1dde25,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x5ef353=k(_0x27203c,_0x2cad77);if(Ri(_0x7f5889['visibleWrites'],_0x5ef353))return null;{const _0x3a3ad7=Ee(_0x7f5889['visibleWrites'],_0x5ef353);return Ai(_0x3a3ad7)?_0x1dde25['getChild'](_0x2cad77):at(_0x3a3ad7,_0x1dde25['getChild'](_0x2cad77));}}function yu(_0x210a3b,_0x19be7d,_0x310d7b,_0x30dffc){const _0x4fcb15=k(_0x19be7d,_0x310d7b),_0x27be03=ze(_0x210a3b['visibleWrites'],_0x4fcb15);if(_0x27be03!=null)return _0x27be03;if(_0x30dffc['isCompleteForChild'](_0x310d7b)){const _0x3a413c=Ee(_0x210a3b['visibleWrites'],_0x4fcb15);return at(_0x3a413c,_0x30dffc['getNode']()['getImmediateChild'](_0x310d7b));}else return null;}function vu(_0x8763fd,_0x39781e){return ze(_0x8763fd['visibleWrites'],_0x39781e);}function Eu(_0xcbf72d,_0x555823,_0x2c7780,_0x2aa598,_0xbc2cfd,_0x3b5dd6,_0x3bd1c7){let _0x14deb2;const _0x1e340c=Ee(_0xcbf72d['visibleWrites'],_0x555823),_0x2beca2=ze(_0x1e340c,w());if(_0x2beca2!=null)_0x14deb2=_0x2beca2;else{if(_0x2c7780!=null)_0x14deb2=at(_0x1e340c,_0x2c7780);else return[];}if(_0x14deb2=_0x14deb2['withIndex'](_0x3bd1c7),!_0x14deb2['isEmpty']()&&!_0x14deb2['isLeafNode']()){const _0x255dc1=[],_0x1f7d75=_0x3bd1c7['getCompare'](),_0x2e2428=_0x3b5dd6?_0x14deb2['getReverseIteratorFrom'](_0x2aa598,_0x3bd1c7):_0x14deb2['getIteratorFrom'](_0x2aa598,_0x3bd1c7);let _0x334884=_0x2e2428['getNext']();for(;_0x334884&&_0x255dc1['length']<_0xbc2cfd;)_0x1f7d75(_0x334884,_0x2aa598)!==0x0&&_0x255dc1['push'](_0x334884),_0x334884=_0x2e2428['getNext']();return _0x255dc1;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x3414e9,_0x5cc8e8,_0x25c381,_0x4987d0){return Bo(_0x3414e9['writeTree'],_0x3414e9['treePath'],_0x5cc8e8,_0x25c381,_0x4987d0);}function is(_0x3440ce,_0x3e07ba){return gu(_0x3440ce['writeTree'],_0x3440ce['treePath'],_0x3e07ba);}function cr(_0x1b70b8,_0x5a4ef5,_0x37fc26,_0x36e0c4){return mu(_0x1b70b8['writeTree'],_0x1b70b8['treePath'],_0x5a4ef5,_0x37fc26,_0x36e0c4);}function Tn(_0x18c77c,_0x5aff86){return vu(_0x18c77c['writeTree'],k(_0x18c77c['treePath'],_0x5aff86));}function wu(_0x2e8d0f,_0x158744,_0x13f878,_0x4df898,_0x4477c9,_0x4054da){return Eu(_0x2e8d0f['writeTree'],_0x2e8d0f['treePath'],_0x158744,_0x13f878,_0x4df898,_0x4477c9,_0x4054da);}function ss(_0x22b16c,_0x5b7d79,_0x6f642d){return yu(_0x22b16c['writeTree'],_0x22b16c['treePath'],_0x5b7d79,_0x6f642d);}function Vo(_0x48acc4,_0x5e1b3a){return Ho(k(_0x48acc4['treePath'],_0x5e1b3a),_0x48acc4['writeTree']);}function Ho(_0x566c15,_0x1caaa9){return{'treePath':_0x566c15,'writeTree':_0x1caaa9};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x355202){const _0x4b5432=_0x355202['type'],_0x509b07=_0x355202['childName'];f(_0x4b5432==='child_added'||_0x4b5432==='child_changed'||_0x4b5432==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x509b07!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x1b4cb7=this['changeMap']['get'](_0x509b07);if(_0x1b4cb7){const _0x1f7002=_0x1b4cb7['type'];if(_0x4b5432==='child_added'&&_0x1f7002==='child_removed')this['changeMap']['set'](_0x509b07,xt(_0x509b07,_0x355202['snapshotNode'],_0x1b4cb7['snapshotNode']));else{if(_0x4b5432==='child_removed'&&_0x1f7002==='child_added')this['changeMap']['delete'](_0x509b07);else{if(_0x4b5432==='child_removed'&&_0x1f7002==='child_changed')this['changeMap']['set'](_0x509b07,Lt(_0x509b07,_0x1b4cb7['oldSnap']));else{if(_0x4b5432==='child_changed'&&_0x1f7002==='child_added')this['changeMap']['set'](_0x509b07,rt(_0x509b07,_0x355202['snapshotNode']));else{if(_0x4b5432==='child_changed'&&_0x1f7002==='child_changed')this['changeMap']['set'](_0x509b07,xt(_0x509b07,_0x355202['snapshotNode'],_0x1b4cb7['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x355202+'\x20occurred\x20after\x20'+_0x1b4cb7);}}}}}else this['changeMap']['set'](_0x509b07,_0x355202);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x3feda2){return null;}['getChildAfterChild'](_0x184ea5,_0x26b04f,_0x214cc1){return null;}}const $o=new Tu();class rs{constructor(_0x191dde,_0x27e235,_0x4df1cf=null){this['writes_']=_0x191dde,this['viewCache_']=_0x27e235,this['optCompleteServerCache_']=_0x4df1cf;}['getCompleteChild'](_0x3ea435){const _0x37ec88=this['viewCache_']['eventCache'];if(_0x37ec88['isCompleteForChild'](_0x3ea435))return _0x37ec88['getNode']()['getImmediateChild'](_0x3ea435);{const _0x48d1b6=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x3ea435,_0x48d1b6);}}['getChildAfterChild'](_0x3eeea6,_0x35e920,_0x2fa28e){const _0x3370d4=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x37f799=wu(this['writes_'],_0x3370d4,_0x35e920,0x1,_0x2fa28e,_0x3eeea6);return _0x37f799['length']===0x0?null:_0x37f799[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x5efc3c){return{'filter':_0x5efc3c};}function bu(_0x59bf04,_0x57b79b){f(_0x57b79b['eventCache']['getNode']()['isIndexed'](_0x59bf04['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x57b79b['serverCache']['getNode']()['isIndexed'](_0x59bf04['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x44068f,_0xb40d95,_0x47a4ee,_0x155a5d,_0x368d1b){const _0x3fd852=new Cu();let _0x41a991,_0x39f669;if(_0x47a4ee['type']===z['OVERWRITE']){const _0x1665d6=_0x47a4ee;_0x1665d6['source']['fromUser']?_0x41a991=ki(_0x44068f,_0xb40d95,_0x1665d6['path'],_0x1665d6['snap'],_0x155a5d,_0x368d1b,_0x3fd852):(f(_0x1665d6['source']['fromServer'],'Unknown\x20source.'),_0x39f669=_0x1665d6['source']['tagged']||_0xb40d95['serverCache']['isFiltered']()&&!v(_0x1665d6['path']),_0x41a991=Sn(_0x44068f,_0xb40d95,_0x1665d6['path'],_0x1665d6['snap'],_0x155a5d,_0x368d1b,_0x39f669,_0x3fd852));}else{if(_0x47a4ee['type']===z['MERGE']){const _0x4a1387=_0x47a4ee;_0x4a1387['source']['fromUser']?_0x41a991=ku(_0x44068f,_0xb40d95,_0x4a1387['path'],_0x4a1387['children'],_0x155a5d,_0x368d1b,_0x3fd852):(f(_0x4a1387['source']['fromServer'],'Unknown\x20source.'),_0x39f669=_0x4a1387['source']['tagged']||_0xb40d95['serverCache']['isFiltered'](),_0x41a991=Pi(_0x44068f,_0xb40d95,_0x4a1387['path'],_0x4a1387['children'],_0x155a5d,_0x368d1b,_0x39f669,_0x3fd852));}else{if(_0x47a4ee['type']===z['ACK_USER_WRITE']){const _0x3c19fc=_0x47a4ee;_0x3c19fc['revert']?_0x41a991=Ou(_0x44068f,_0xb40d95,_0x3c19fc['path'],_0x155a5d,_0x368d1b,_0x3fd852):_0x41a991=Pu(_0x44068f,_0xb40d95,_0x3c19fc['path'],_0x3c19fc['affectedTree'],_0x155a5d,_0x368d1b,_0x3fd852);}else{if(_0x47a4ee['type']===z['LISTEN_COMPLETE'])_0x41a991=Nu(_0x44068f,_0xb40d95,_0x47a4ee['path'],_0x155a5d,_0x3fd852);else throw ht('Unknown\x20operation\x20type:\x20'+_0x47a4ee['type']);}}}const _0x35dd5d=_0x3fd852['getChanges']();return Au(_0xb40d95,_0x41a991,_0x35dd5d),{'viewCache':_0x41a991,'changes':_0x35dd5d};}function Au(_0x27af47,_0x45a246,_0x185f6c){const _0x4b7e46=_0x45a246['eventCache'];if(_0x4b7e46['isFullyInitialized']()){const _0x23f52b=_0x4b7e46['getNode']()['isLeafNode']()||_0x4b7e46['getNode']()['isEmpty'](),_0x582cda=wn(_0x27af47);(_0x185f6c['length']>0x0||!_0x27af47['eventCache']['isFullyInitialized']()||_0x23f52b&&!_0x4b7e46['getNode']()['equals'](_0x582cda)||!_0x4b7e46['getNode']()['getPriority']()['equals'](_0x582cda['getPriority']()))&&_0x185f6c['push'](Lo(wn(_0x45a246)));}}function Go(_0x59a86b,_0x2e433b,_0x125a77,_0x3dae8f,_0x4bf527,_0x146df5){const _0x208770=_0x2e433b['eventCache'];if(Tn(_0x3dae8f,_0x125a77)!=null)return _0x2e433b;{let _0x565d3d,_0x5deb19;if(v(_0x125a77)){if(f(_0x2e433b['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x2e433b['serverCache']['isFiltered']()){const _0x3a7268=Ve(_0x2e433b),_0x58d259=_0x3a7268 instanceof g?_0x3a7268:g['EMPTY_NODE'],_0x2567b4=is(_0x3dae8f,_0x58d259);_0x565d3d=_0x59a86b['filter']['updateFullNode'](_0x2e433b['eventCache']['getNode'](),_0x2567b4,_0x146df5);}else{const _0x19f047=Cn(_0x3dae8f,Ve(_0x2e433b));_0x565d3d=_0x59a86b['filter']['updateFullNode'](_0x2e433b['eventCache']['getNode'](),_0x19f047,_0x146df5);}}else{const _0x46559f=y(_0x125a77);if(_0x46559f==='.priority'){f(Ce(_0x125a77)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x3757e3=_0x208770['getNode']();_0x5deb19=_0x2e433b['serverCache']['getNode']();const _0x35c884=cr(_0x3dae8f,_0x125a77,_0x3757e3,_0x5deb19);_0x35c884!=null?_0x565d3d=_0x59a86b['filter']['updatePriority'](_0x3757e3,_0x35c884):_0x565d3d=_0x208770['getNode']();}else{const _0x30a7b1=S(_0x125a77);let _0x1dd920;if(_0x208770['isCompleteForChild'](_0x46559f)){_0x5deb19=_0x2e433b['serverCache']['getNode']();const _0x4ea200=cr(_0x3dae8f,_0x125a77,_0x208770['getNode'](),_0x5deb19);_0x4ea200!=null?_0x1dd920=_0x208770['getNode']()['getImmediateChild'](_0x46559f)['updateChild'](_0x30a7b1,_0x4ea200):_0x1dd920=_0x208770['getNode']()['getImmediateChild'](_0x46559f);}else _0x1dd920=ss(_0x3dae8f,_0x46559f,_0x2e433b['serverCache']);_0x1dd920!=null?_0x565d3d=_0x59a86b['filter']['updateChild'](_0x208770['getNode'](),_0x46559f,_0x1dd920,_0x30a7b1,_0x4bf527,_0x146df5):_0x565d3d=_0x208770['getNode']();}}return Rt(_0x2e433b,_0x565d3d,_0x208770['isFullyInitialized']()||v(_0x125a77),_0x59a86b['filter']['filtersNodes']());}}function Sn(_0x5e08ce,_0x2bba3b,_0x2f0cf3,_0x355bcc,_0x4e31ce,_0x4ef0e6,_0x260033,_0x47b66d){const _0x5e3bb6=_0x2bba3b['serverCache'];let _0x1dd2c3;const _0x12d66a=_0x260033?_0x5e08ce['filter']:_0x5e08ce['filter']['getIndexedFilter']();if(v(_0x2f0cf3))_0x1dd2c3=_0x12d66a['updateFullNode'](_0x5e3bb6['getNode'](),_0x355bcc,null);else{if(_0x12d66a['filtersNodes']()&&!_0x5e3bb6['isFiltered']()){const _0x216d95=_0x5e3bb6['getNode']()['updateChild'](_0x2f0cf3,_0x355bcc);_0x1dd2c3=_0x12d66a['updateFullNode'](_0x5e3bb6['getNode'](),_0x216d95,null);}else{const _0x1db340=y(_0x2f0cf3);if(!_0x5e3bb6['isCompleteForPath'](_0x2f0cf3)&&Ce(_0x2f0cf3)>0x1)return _0x2bba3b;const _0x4e528f=S(_0x2f0cf3),_0x120117=_0x5e3bb6['getNode']()['getImmediateChild'](_0x1db340)['updateChild'](_0x4e528f,_0x355bcc);_0x1db340==='.priority'?_0x1dd2c3=_0x12d66a['updatePriority'](_0x5e3bb6['getNode'](),_0x120117):_0x1dd2c3=_0x12d66a['updateChild'](_0x5e3bb6['getNode'](),_0x1db340,_0x120117,_0x4e528f,$o,null);}}const _0x43dc1c=Fo(_0x2bba3b,_0x1dd2c3,_0x5e3bb6['isFullyInitialized']()||v(_0x2f0cf3),_0x12d66a['filtersNodes']()),_0x45fe82=new rs(_0x4e31ce,_0x43dc1c,_0x4ef0e6);return Go(_0x5e08ce,_0x43dc1c,_0x2f0cf3,_0x4e31ce,_0x45fe82,_0x47b66d);}function ki(_0x50ae53,_0x2af16b,_0x583ab3,_0x4ed67e,_0x3132a4,_0xe444e9,_0x186d34){const _0x1ca6d8=_0x2af16b['eventCache'];let _0x4bf5fb,_0x41a229;const _0x19b2fd=new rs(_0x3132a4,_0x2af16b,_0xe444e9);if(v(_0x583ab3))_0x41a229=_0x50ae53['filter']['updateFullNode'](_0x2af16b['eventCache']['getNode'](),_0x4ed67e,_0x186d34),_0x4bf5fb=Rt(_0x2af16b,_0x41a229,!0x0,_0x50ae53['filter']['filtersNodes']());else{const _0x2a950a=y(_0x583ab3);if(_0x2a950a==='.priority')_0x41a229=_0x50ae53['filter']['updatePriority'](_0x2af16b['eventCache']['getNode'](),_0x4ed67e),_0x4bf5fb=Rt(_0x2af16b,_0x41a229,_0x1ca6d8['isFullyInitialized'](),_0x1ca6d8['isFiltered']());else{const _0x538895=S(_0x583ab3),_0x568d7e=_0x1ca6d8['getNode']()['getImmediateChild'](_0x2a950a);let _0x331e16;if(v(_0x538895))_0x331e16=_0x4ed67e;else{const _0x23a293=_0x19b2fd['getCompleteChild'](_0x2a950a);_0x23a293!=null?ji(_0x538895)==='.priority'&&_0x23a293['getChild'](Ro(_0x538895))['isEmpty']()?_0x331e16=_0x23a293:_0x331e16=_0x23a293['updateChild'](_0x538895,_0x4ed67e):_0x331e16=g['EMPTY_NODE'];}if(_0x568d7e['equals'](_0x331e16))_0x4bf5fb=_0x2af16b;else{const _0xead113=_0x50ae53['filter']['updateChild'](_0x1ca6d8['getNode'](),_0x2a950a,_0x331e16,_0x538895,_0x19b2fd,_0x186d34);_0x4bf5fb=Rt(_0x2af16b,_0xead113,_0x1ca6d8['isFullyInitialized'](),_0x50ae53['filter']['filtersNodes']());}}}return _0x4bf5fb;}function lr(_0x5bc005,_0xf1f9e8){return _0x5bc005['eventCache']['isCompleteForChild'](_0xf1f9e8);}function ku(_0xd0712f,_0x3ab571,_0x8fd6a2,_0xc028f4,_0x2fef43,_0x1ae17e,_0x126b7f){let _0x52d0fa=_0x3ab571;return _0xc028f4['foreach']((_0x5de687,_0x3bfd79)=>{const _0x3a1f11=k(_0x8fd6a2,_0x5de687);lr(_0x3ab571,y(_0x3a1f11))&&(_0x52d0fa=ki(_0xd0712f,_0x52d0fa,_0x3a1f11,_0x3bfd79,_0x2fef43,_0x1ae17e,_0x126b7f));}),_0xc028f4['foreach']((_0x50fb41,_0x29416f)=>{const _0x4bfb56=k(_0x8fd6a2,_0x50fb41);lr(_0x3ab571,y(_0x4bfb56))||(_0x52d0fa=ki(_0xd0712f,_0x52d0fa,_0x4bfb56,_0x29416f,_0x2fef43,_0x1ae17e,_0x126b7f));}),_0x52d0fa;}function hr(_0xc86f5d,_0x4782e2,_0x12761b){return _0x12761b['foreach']((_0x506ca8,_0x28dc2e)=>{_0x4782e2=_0x4782e2['updateChild'](_0x506ca8,_0x28dc2e);}),_0x4782e2;}function Pi(_0x4b11fa,_0x4c6719,_0x212ba4,_0xbdd99,_0xade8b,_0x4e32aa,_0x1e3765,_0x94e11c){if(_0x4c6719['serverCache']['getNode']()['isEmpty']()&&!_0x4c6719['serverCache']['isFullyInitialized']())return _0x4c6719;let _0x58746c=_0x4c6719,_0x46f130;v(_0x212ba4)?_0x46f130=_0xbdd99:_0x46f130=new b(null)['setTree'](_0x212ba4,_0xbdd99);const _0x5b6cb1=_0x4c6719['serverCache']['getNode']();return _0x46f130['children']['inorderTraversal']((_0xa53b72,_0x448028)=>{if(_0x5b6cb1['hasChild'](_0xa53b72)){const _0x1729c2=_0x4c6719['serverCache']['getNode']()['getImmediateChild'](_0xa53b72),_0x4d1b01=hr(_0x4b11fa,_0x1729c2,_0x448028);_0x58746c=Sn(_0x4b11fa,_0x58746c,new C(_0xa53b72),_0x4d1b01,_0xade8b,_0x4e32aa,_0x1e3765,_0x94e11c);}}),_0x46f130['children']['inorderTraversal']((_0xcc4700,_0x1de8ff)=>{const _0x5ae9fa=!_0x4c6719['serverCache']['isCompleteForChild'](_0xcc4700)&&_0x1de8ff['value']===null;if(!_0x5b6cb1['hasChild'](_0xcc4700)&&!_0x5ae9fa){const _0xf1daea=_0x4c6719['serverCache']['getNode']()['getImmediateChild'](_0xcc4700),_0x262cc0=hr(_0x4b11fa,_0xf1daea,_0x1de8ff);_0x58746c=Sn(_0x4b11fa,_0x58746c,new C(_0xcc4700),_0x262cc0,_0xade8b,_0x4e32aa,_0x1e3765,_0x94e11c);}}),_0x58746c;}function Pu(_0x45cdd8,_0x17b09b,_0x2525be,_0x380028,_0x491298,_0x509ef5,_0x245eba){if(Tn(_0x491298,_0x2525be)!=null)return _0x17b09b;const _0x2fdb79=_0x17b09b['serverCache']['isFiltered'](),_0x3a7712=_0x17b09b['serverCache'];if(_0x380028['value']!=null){if(v(_0x2525be)&&_0x3a7712['isFullyInitialized']()||_0x3a7712['isCompleteForPath'](_0x2525be))return Sn(_0x45cdd8,_0x17b09b,_0x2525be,_0x3a7712['getNode']()['getChild'](_0x2525be),_0x491298,_0x509ef5,_0x2fdb79,_0x245eba);if(v(_0x2525be)){let _0x45fb9d=new b(null);return _0x3a7712['getNode']()['forEachChild'](ve,(_0x5288ab,_0x3fddc0)=>{_0x45fb9d=_0x45fb9d['set'](new C(_0x5288ab),_0x3fddc0);}),Pi(_0x45cdd8,_0x17b09b,_0x2525be,_0x45fb9d,_0x491298,_0x509ef5,_0x2fdb79,_0x245eba);}else return _0x17b09b;}else{let _0x494a5a=new b(null);return _0x380028['foreach']((_0x813e20,_0x35da62)=>{const _0x4f1b60=k(_0x2525be,_0x813e20);_0x3a7712['isCompleteForPath'](_0x4f1b60)&&(_0x494a5a=_0x494a5a['set'](_0x813e20,_0x3a7712['getNode']()['getChild'](_0x4f1b60)));}),Pi(_0x45cdd8,_0x17b09b,_0x2525be,_0x494a5a,_0x491298,_0x509ef5,_0x2fdb79,_0x245eba);}}function Nu(_0x3ca1aa,_0x1c0c6f,_0x1f75c6,_0x2b7f54,_0xeec678){const _0xdb0d6b=_0x1c0c6f['serverCache'],_0x4dcfe9=Fo(_0x1c0c6f,_0xdb0d6b['getNode'](),_0xdb0d6b['isFullyInitialized']()||v(_0x1f75c6),_0xdb0d6b['isFiltered']());return Go(_0x3ca1aa,_0x4dcfe9,_0x1f75c6,_0x2b7f54,$o,_0xeec678);}function Ou(_0x28751a,_0x469540,_0x240338,_0x764b81,_0x356ea6,_0x25564f){let _0x9e3a99;if(Tn(_0x764b81,_0x240338)!=null)return _0x469540;{const _0x498b14=new rs(_0x764b81,_0x469540,_0x356ea6),_0x1dad26=_0x469540['eventCache']['getNode']();let _0x1fa2fd;if(v(_0x240338)||y(_0x240338)==='.priority'){let _0x2cc68a;if(_0x469540['serverCache']['isFullyInitialized']())_0x2cc68a=Cn(_0x764b81,Ve(_0x469540));else{const _0x48ea2b=_0x469540['serverCache']['getNode']();f(_0x48ea2b instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x2cc68a=is(_0x764b81,_0x48ea2b);}_0x2cc68a=_0x2cc68a,_0x1fa2fd=_0x28751a['filter']['updateFullNode'](_0x1dad26,_0x2cc68a,_0x25564f);}else{const _0x476746=y(_0x240338);let _0x2ab4a4=ss(_0x764b81,_0x476746,_0x469540['serverCache']);_0x2ab4a4==null&&_0x469540['serverCache']['isCompleteForChild'](_0x476746)&&(_0x2ab4a4=_0x1dad26['getImmediateChild'](_0x476746)),_0x2ab4a4!=null?_0x1fa2fd=_0x28751a['filter']['updateChild'](_0x1dad26,_0x476746,_0x2ab4a4,S(_0x240338),_0x498b14,_0x25564f):_0x469540['eventCache']['getNode']()['hasChild'](_0x476746)?_0x1fa2fd=_0x28751a['filter']['updateChild'](_0x1dad26,_0x476746,g['EMPTY_NODE'],S(_0x240338),_0x498b14,_0x25564f):_0x1fa2fd=_0x1dad26,_0x1fa2fd['isEmpty']()&&_0x469540['serverCache']['isFullyInitialized']()&&(_0x9e3a99=Cn(_0x764b81,Ve(_0x469540)),_0x9e3a99['isLeafNode']()&&(_0x1fa2fd=_0x28751a['filter']['updateFullNode'](_0x1fa2fd,_0x9e3a99,_0x25564f)));}return _0x9e3a99=_0x469540['serverCache']['isFullyInitialized']()||Tn(_0x764b81,w())!=null,Rt(_0x469540,_0x1fa2fd,_0x9e3a99,_0x28751a['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x708571,_0x186685){this['query_']=_0x708571,this['eventRegistrations_']=[];const _0x422519=this['query_']['_queryParams'],_0x2f409b=new Xi(_0x422519['getIndex']()),_0x4ed4e2=Kh(_0x422519);this['processor_']=Su(_0x4ed4e2);const _0x47659d=_0x186685['serverCache'],_0x3274ee=_0x186685['eventCache'],_0x4a4442=_0x2f409b['updateFullNode'](g['EMPTY_NODE'],_0x47659d['getNode'](),null),_0x399d94=_0x4ed4e2['updateFullNode'](g['EMPTY_NODE'],_0x3274ee['getNode'](),null),_0x3fa09a=new Te(_0x4a4442,_0x47659d['isFullyInitialized'](),_0x2f409b['filtersNodes']()),_0x3e9b83=new Te(_0x399d94,_0x3274ee['isFullyInitialized'](),_0x4ed4e2['filtersNodes']());this['viewCache_']=Un(_0x3e9b83,_0x3fa09a),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x2ad7e9){return _0x2ad7e9['viewCache_']['serverCache']['getNode']();}function Lu(_0x53d1e6){return wn(_0x53d1e6['viewCache_']);}function xu(_0x2a9333,_0x20217a){const _0x17e3da=Ve(_0x2a9333['viewCache_']);return _0x17e3da&&(_0x2a9333['query']['_queryParams']['loadsAllData']()||!v(_0x20217a)&&!_0x17e3da['getImmediateChild'](y(_0x20217a))['isEmpty']())?_0x17e3da['getChild'](_0x20217a):null;}function ur(_0x4983cc){return _0x4983cc['eventRegistrations_']['length']===0x0;}function Fu(_0x280ecd,_0x3ae49c){_0x280ecd['eventRegistrations_']['push'](_0x3ae49c);}function dr(_0x57e72d,_0x19c4a7,_0x3154f2){const _0x301ae4=[];if(_0x3154f2){f(_0x19c4a7==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x150cc7=_0x57e72d['query']['_path'];_0x57e72d['eventRegistrations_']['forEach'](_0xc0aea3=>{const _0x5c6467=_0xc0aea3['createCancelEvent'](_0x3154f2,_0x150cc7);_0x5c6467&&_0x301ae4['push'](_0x5c6467);});}if(_0x19c4a7){let _0x467fa7=[];for(let _0x41fce3=0x0;_0x41fce3<_0x57e72d['eventRegistrations_']['length'];++_0x41fce3){const _0x4471f2=_0x57e72d['eventRegistrations_'][_0x41fce3];if(!_0x4471f2['matches'](_0x19c4a7))_0x467fa7['push'](_0x4471f2);else{if(_0x19c4a7['hasAnyCallback']()){_0x467fa7=_0x467fa7['concat'](_0x57e72d['eventRegistrations_']['slice'](_0x41fce3+0x1));break;}}}_0x57e72d['eventRegistrations_']=_0x467fa7;}else _0x57e72d['eventRegistrations_']=[];return _0x301ae4;}function fr(_0x30feca,_0xcb18ca,_0x368282,_0x493576){_0xcb18ca['type']===z['MERGE']&&_0xcb18ca['source']['queryId']!==null&&(f(Ve(_0x30feca['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x30feca['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x312789=_0x30feca['viewCache_'],_0x15a248=Ru(_0x30feca['processor_'],_0x312789,_0xcb18ca,_0x368282,_0x493576);return bu(_0x30feca['processor_'],_0x15a248['viewCache']),f(_0x15a248['viewCache']['serverCache']['isFullyInitialized']()||!_0x312789['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x30feca['viewCache_']=_0x15a248['viewCache'],qo(_0x30feca,_0x15a248['changes'],_0x15a248['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x2f2924,_0x3e77ad){const _0x39a23c=_0x2f2924['viewCache_']['eventCache'],_0x590d93=[];return _0x39a23c['getNode']()['isLeafNode']()||_0x39a23c['getNode']()['forEachChild'](R,(_0xaca8b5,_0x7d1ea2)=>{_0x590d93['push'](rt(_0xaca8b5,_0x7d1ea2));}),_0x39a23c['isFullyInitialized']()&&_0x590d93['push'](Lo(_0x39a23c['getNode']())),qo(_0x2f2924,_0x590d93,_0x39a23c['getNode'](),_0x3e77ad);}function qo(_0x265ac3,_0x18415c,_0x36c522,_0x2500ef){const _0x50d340=_0x2500ef?[_0x2500ef]:_0x265ac3['eventRegistrations_'];return ru(_0x265ac3['eventGenerator_'],_0x18415c,_0x36c522,_0x50d340);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x2e778e){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x2e778e;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x21a07e){return _0x21a07e['views']['size']===0x0;}function os(_0xbb6b4b,_0x1324eb,_0x288984,_0x119eb8){const _0x46f7fe=_0x1324eb['source']['queryId'];if(_0x46f7fe!==null){const _0x415c3f=_0xbb6b4b['views']['get'](_0x46f7fe);return f(_0x415c3f!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x415c3f,_0x1324eb,_0x288984,_0x119eb8);}else{let _0x191292=[];for(const _0x416e66 of _0xbb6b4b['views']['values']())_0x191292=_0x191292['concat'](fr(_0x416e66,_0x1324eb,_0x288984,_0x119eb8));return _0x191292;}}function jo(_0x30b737,_0xd051c9,_0x15d150,_0x20199c,_0x1fe0cd){const _0x12f8a8=_0xd051c9['_queryIdentifier'],_0x3d5fa4=_0x30b737['views']['get'](_0x12f8a8);if(!_0x3d5fa4){let _0x237626=Cn(_0x15d150,_0x1fe0cd?_0x20199c:null),_0x533386=!0x1;_0x237626?_0x533386=!0x0:_0x20199c instanceof g?(_0x237626=is(_0x15d150,_0x20199c),_0x533386=!0x1):(_0x237626=g['EMPTY_NODE'],_0x533386=!0x1);const _0xfc8b6f=Un(new Te(_0x237626,_0x533386,!0x1),new Te(_0x20199c,_0x1fe0cd,!0x1));return new Du(_0xd051c9,_0xfc8b6f);}return _0x3d5fa4;}function Hu(_0x4c853c,_0x5da2da,_0x13eac0,_0x427fd3,_0x308698,_0xbc6f1){const _0x40c935=jo(_0x4c853c,_0x5da2da,_0x427fd3,_0x308698,_0xbc6f1);return _0x4c853c['views']['has'](_0x5da2da['_queryIdentifier'])||_0x4c853c['views']['set'](_0x5da2da['_queryIdentifier'],_0x40c935),Fu(_0x40c935,_0x13eac0),Uu(_0x40c935,_0x13eac0);}function $u(_0xcc3aad,_0x4ead19,_0x34fa08,_0x3ed511){const _0x2bfae8=_0x4ead19['_queryIdentifier'],_0x3c4945=[];let _0x30b16d=[];const _0xfe8686=Se(_0xcc3aad);if(_0x2bfae8==='default'){for(const [_0x3cf37e,_0x1fe828]of _0xcc3aad['views']['entries']())_0x30b16d=_0x30b16d['concat'](dr(_0x1fe828,_0x34fa08,_0x3ed511)),ur(_0x1fe828)&&(_0xcc3aad['views']['delete'](_0x3cf37e),_0x1fe828['query']['_queryParams']['loadsAllData']()||_0x3c4945['push'](_0x1fe828['query']));}else{const _0x5990ab=_0xcc3aad['views']['get'](_0x2bfae8);_0x5990ab&&(_0x30b16d=_0x30b16d['concat'](dr(_0x5990ab,_0x34fa08,_0x3ed511)),ur(_0x5990ab)&&(_0xcc3aad['views']['delete'](_0x2bfae8),_0x5990ab['query']['_queryParams']['loadsAllData']()||_0x3c4945['push'](_0x5990ab['query'])));}return _0xfe8686&&!Se(_0xcc3aad)&&_0x3c4945['push'](new(Bu())(_0x4ead19['_repo'],_0x4ead19['_path'])),{'removed':_0x3c4945,'events':_0x30b16d};}function Ko(_0x5f3847){const _0x1e10bd=[];for(const _0x2489b7 of _0x5f3847['views']['values']())_0x2489b7['query']['_queryParams']['loadsAllData']()||_0x1e10bd['push'](_0x2489b7);return _0x1e10bd;}function Ie(_0x298064,_0x5ee42c){let _0x352ece=null;for(const _0x4b17eb of _0x298064['views']['values']())_0x352ece=_0x352ece||xu(_0x4b17eb,_0x5ee42c);return _0x352ece;}function Yo(_0x4c2ba5,_0x86b495){if(_0x86b495['_queryParams']['loadsAllData']())return Bn(_0x4c2ba5);{const _0x152f08=_0x86b495['_queryIdentifier'];return _0x4c2ba5['views']['get'](_0x152f08);}}function Qo(_0x12965e,_0x256777){return Yo(_0x12965e,_0x256777)!=null;}function Se(_0x2409b6){return Bn(_0x2409b6)!=null;}function Bn(_0x4a28b4){for(const _0x2f1a2b of _0x4a28b4['views']['values']())if(_0x2f1a2b['query']['_queryParams']['loadsAllData']())return _0x2f1a2b;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x40b2ab){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x40b2ab;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x130df0){this['listenProvider_']=_0x130df0,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0xb573a9,_0x896513,_0x3a429d,_0x414548,_0x454af1){return lu(_0xb573a9['pendingWriteTree_'],_0x896513,_0x3a429d,_0x414548,_0x454af1),_0x454af1?_t(_0xb573a9,new Be(es(),_0x896513,_0x3a429d)):[];}function ju(_0x9b9301,_0x37b7a5,_0x476f92,_0x3b0acf){hu(_0x9b9301['pendingWriteTree_'],_0x37b7a5,_0x476f92,_0x3b0acf);const _0x2ca67e=b['fromObject'](_0x476f92);return _t(_0x9b9301,new ot(es(),_0x37b7a5,_0x2ca67e));}function _e(_0x2a0acc,_0x402fd2,_0x159af6=!0x1){const _0x5d0770=uu(_0x2a0acc['pendingWriteTree_'],_0x402fd2);if(du(_0x2a0acc['pendingWriteTree_'],_0x402fd2)){let _0x45bc73=new b(null);return _0x5d0770['snap']!=null?_0x45bc73=_0x45bc73['set'](w(),!0x0):x(_0x5d0770['children'],_0x9d6661=>{_0x45bc73=_0x45bc73['set'](new C(_0x9d6661),!0x0);}),_t(_0x2a0acc,new In(_0x5d0770['path'],_0x45bc73,_0x159af6));}else return[];}function Yt(_0x224a60,_0x343a6c,_0x22c9f4){return _t(_0x224a60,new Be(ts(),_0x343a6c,_0x22c9f4));}function Ku(_0x32942c,_0x8b84c,_0x2953d8){const _0x144081=b['fromObject'](_0x2953d8);return _t(_0x32942c,new ot(ts(),_0x8b84c,_0x144081));}function Yu(_0x95035c,_0x1cdbfe){return _t(_0x95035c,new Ut(ts(),_0x1cdbfe));}function Qu(_0x42abab,_0x47f019,_0x49a9b4){const _0x2ebf70=cs(_0x42abab,_0x49a9b4);if(_0x2ebf70){const _0x17f0a0=ls(_0x2ebf70),_0x1eb283=_0x17f0a0['path'],_0x104420=_0x17f0a0['queryId'],_0x8e30f0=F(_0x1eb283,_0x47f019),_0x3f4e40=new Ut(ns(_0x104420),_0x8e30f0);return hs(_0x42abab,_0x1eb283,_0x3f4e40);}else return[];}function An(_0x13503d,_0x237f9a,_0x2ce52a,_0x1dbf9b,_0xe49ebe=!0x1){const _0xf9399d=_0x237f9a['_path'],_0x7c2a29=_0x13503d['syncPointTree_']['get'](_0xf9399d);let _0x79fac4=[];if(_0x7c2a29&&(_0x237f9a['_queryIdentifier']==='default'||Qo(_0x7c2a29,_0x237f9a))){const _0x50da24=$u(_0x7c2a29,_0x237f9a,_0x2ce52a,_0x1dbf9b);Vu(_0x7c2a29)&&(_0x13503d['syncPointTree_']=_0x13503d['syncPointTree_']['remove'](_0xf9399d));const _0x540154=_0x50da24['removed'];if(_0x79fac4=_0x50da24['events'],!_0xe49ebe){const _0x2769d5=_0x540154['findIndex'](_0x1b1613=>_0x1b1613['_queryParams']['loadsAllData']())!==-0x1,_0x4ba8ba=_0x13503d['syncPointTree_']['findOnPath'](_0xf9399d,(_0x170e4d,_0x24b59)=>Se(_0x24b59));if(_0x2769d5&&!_0x4ba8ba){const _0x3bbbb3=_0x13503d['syncPointTree_']['subtree'](_0xf9399d);if(!_0x3bbbb3['isEmpty']()){const _0x7d4765=Zu(_0x3bbbb3);for(let _0x40804c=0x0;_0x40804c<_0x7d4765['length'];++_0x40804c){const _0x493b2d=_0x7d4765[_0x40804c],_0x34c08=_0x493b2d['query'],_0xc679c5=ea(_0x13503d,_0x493b2d);_0x13503d['listenProvider_']['startListening'](kt(_0x34c08),Wt(_0x13503d,_0x34c08),_0xc679c5['hashFn'],_0xc679c5['onComplete']);}}}!_0x4ba8ba&&_0x540154['length']>0x0&&!_0x1dbf9b&&(_0x2769d5?_0x13503d['listenProvider_']['stopListening'](kt(_0x237f9a),null):_0x540154['forEach'](_0x24eca3=>{const _0x2d0858=_0x13503d['queryToTagMap']['get'](Hn(_0x24eca3));_0x13503d['listenProvider_']['stopListening'](kt(_0x24eca3),_0x2d0858);}));}ed(_0x13503d,_0x540154);}return _0x79fac4;}function Jo(_0x28d47a,_0x79086e,_0x2a2e4,_0x336028){const _0x393e80=cs(_0x28d47a,_0x336028);if(_0x393e80!=null){const _0x3604d5=ls(_0x393e80),_0x1cd5c4=_0x3604d5['path'],_0x1949e0=_0x3604d5['queryId'],_0x52c703=F(_0x1cd5c4,_0x79086e),_0x2e3583=new Be(ns(_0x1949e0),_0x52c703,_0x2a2e4);return hs(_0x28d47a,_0x1cd5c4,_0x2e3583);}else return[];}function Ju(_0x5439a1,_0x75165,_0x326faf,_0x4dc211){const _0x3f131e=cs(_0x5439a1,_0x4dc211);if(_0x3f131e){const _0xa37465=ls(_0x3f131e),_0x699406=_0xa37465['path'],_0x49faad=_0xa37465['queryId'],_0x10564e=F(_0x699406,_0x75165),_0x32d85c=b['fromObject'](_0x326faf),_0x29c8e4=new ot(ns(_0x49faad),_0x10564e,_0x32d85c);return hs(_0x5439a1,_0x699406,_0x29c8e4);}else return[];}function Ni(_0x526f74,_0x2ead98,_0x161db9,_0x5be8db=!0x1){const _0x240680=_0x2ead98['_path'];let _0x3a7e23=null,_0x3dea76=!0x1;_0x526f74['syncPointTree_']['foreachOnPath'](_0x240680,(_0x1fef99,_0xd008db)=>{const _0xf94fb6=F(_0x1fef99,_0x240680);_0x3a7e23=_0x3a7e23||Ie(_0xd008db,_0xf94fb6),_0x3dea76=_0x3dea76||Se(_0xd008db);});let _0x26b41e=_0x526f74['syncPointTree_']['get'](_0x240680);_0x26b41e?(_0x3dea76=_0x3dea76||Se(_0x26b41e),_0x3a7e23=_0x3a7e23||Ie(_0x26b41e,w())):(_0x26b41e=new zo(),_0x526f74['syncPointTree_']=_0x526f74['syncPointTree_']['set'](_0x240680,_0x26b41e));let _0xe4503a;_0x3a7e23!=null?_0xe4503a=!0x0:(_0xe4503a=!0x1,_0x3a7e23=g['EMPTY_NODE'],_0x526f74['syncPointTree_']['subtree'](_0x240680)['foreachChild']((_0x1ff27d,_0x22a985)=>{const _0x3e5076=Ie(_0x22a985,w());_0x3e5076&&(_0x3a7e23=_0x3a7e23['updateImmediateChild'](_0x1ff27d,_0x3e5076));}));const _0x541e00=Qo(_0x26b41e,_0x2ead98);if(!_0x541e00&&!_0x2ead98['_queryParams']['loadsAllData']()){const _0x2a2ab6=Hn(_0x2ead98);f(!_0x526f74['queryToTagMap']['has'](_0x2a2ab6),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x9ef64c=td();_0x526f74['queryToTagMap']['set'](_0x2a2ab6,_0x9ef64c),_0x526f74['tagToQueryMap']['set'](_0x9ef64c,_0x2a2ab6);}const _0x5d3e40=Wn(_0x526f74['pendingWriteTree_'],_0x240680);let _0x367b6b=Hu(_0x26b41e,_0x2ead98,_0x161db9,_0x5d3e40,_0x3a7e23,_0xe4503a);if(!_0x541e00&&!_0x3dea76&&!_0x5be8db){const _0x5c3740=Yo(_0x26b41e,_0x2ead98);_0x367b6b=_0x367b6b['concat'](nd(_0x526f74,_0x2ead98,_0x5c3740));}return _0x367b6b;}function Vn(_0x40af47,_0x48b72b,_0x577540){const _0x492e46=_0x40af47['pendingWriteTree_'],_0x3ad763=_0x40af47['syncPointTree_']['findOnPath'](_0x48b72b,(_0x5360db,_0x4e2c9b)=>{const _0x580132=F(_0x5360db,_0x48b72b),_0x2df480=Ie(_0x4e2c9b,_0x580132);if(_0x2df480)return _0x2df480;});return Bo(_0x492e46,_0x48b72b,_0x3ad763,_0x577540,!0x0);}function Xu(_0x6065c6,_0x5a1474){const _0x947fa4=_0x5a1474['_path'];let _0x3fb4fe=null;_0x6065c6['syncPointTree_']['foreachOnPath'](_0x947fa4,(_0x360a4d,_0x2d1e7d)=>{const _0xfd11c6=F(_0x360a4d,_0x947fa4);_0x3fb4fe=_0x3fb4fe||Ie(_0x2d1e7d,_0xfd11c6);});let _0x30fe5d=_0x6065c6['syncPointTree_']['get'](_0x947fa4);_0x30fe5d?_0x3fb4fe=_0x3fb4fe||Ie(_0x30fe5d,w()):(_0x30fe5d=new zo(),_0x6065c6['syncPointTree_']=_0x6065c6['syncPointTree_']['set'](_0x947fa4,_0x30fe5d));const _0x1980cb=_0x3fb4fe!=null,_0x12ba35=_0x1980cb?new Te(_0x3fb4fe,!0x0,!0x1):null,_0x278514=Wn(_0x6065c6['pendingWriteTree_'],_0x5a1474['_path']),_0x5d4f2a=jo(_0x30fe5d,_0x5a1474,_0x278514,_0x1980cb?_0x12ba35['getNode']():g['EMPTY_NODE'],_0x1980cb);return Lu(_0x5d4f2a);}function _t(_0x446589,_0x2d5e38){return Xo(_0x2d5e38,_0x446589['syncPointTree_'],null,Wn(_0x446589['pendingWriteTree_'],w()));}function Xo(_0x2288c3,_0xe6ea89,_0x22759a,_0x22e967){if(v(_0x2288c3['path']))return Zo(_0x2288c3,_0xe6ea89,_0x22759a,_0x22e967);{const _0x2920b1=_0xe6ea89['get'](w());_0x22759a==null&&_0x2920b1!=null&&(_0x22759a=Ie(_0x2920b1,w()));let _0x293076=[];const _0xdf3ce0=y(_0x2288c3['path']),_0x2240e3=_0x2288c3['operationForChild'](_0xdf3ce0),_0x16a3af=_0xe6ea89['children']['get'](_0xdf3ce0);if(_0x16a3af&&_0x2240e3){const _0x27c921=_0x22759a?_0x22759a['getImmediateChild'](_0xdf3ce0):null,_0x350048=Vo(_0x22e967,_0xdf3ce0);_0x293076=_0x293076['concat'](Xo(_0x2240e3,_0x16a3af,_0x27c921,_0x350048));}return _0x2920b1&&(_0x293076=_0x293076['concat'](os(_0x2920b1,_0x2288c3,_0x22e967,_0x22759a))),_0x293076;}}function Zo(_0x518052,_0x31cfee,_0x373acc,_0x57a50c){const _0x41363d=_0x31cfee['get'](w());_0x373acc==null&&_0x41363d!=null&&(_0x373acc=Ie(_0x41363d,w()));let _0x33a256=[];return _0x31cfee['children']['inorderTraversal']((_0x331e93,_0x38865d)=>{const _0x3ab98d=_0x373acc?_0x373acc['getImmediateChild'](_0x331e93):null,_0x93d265=Vo(_0x57a50c,_0x331e93),_0x5a0c3d=_0x518052['operationForChild'](_0x331e93);_0x5a0c3d&&(_0x33a256=_0x33a256['concat'](Zo(_0x5a0c3d,_0x38865d,_0x3ab98d,_0x93d265)));}),_0x41363d&&(_0x33a256=_0x33a256['concat'](os(_0x41363d,_0x518052,_0x57a50c,_0x373acc))),_0x33a256;}function ea(_0x56e959,_0x4c97f2){const _0x35bb9d=_0x4c97f2['query'],_0xd58a33=Wt(_0x56e959,_0x35bb9d);return{'hashFn':()=>(Mu(_0x4c97f2)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x140a1f=>{if(_0x140a1f==='ok')return _0xd58a33?Qu(_0x56e959,_0x35bb9d['_path'],_0xd58a33):Yu(_0x56e959,_0x35bb9d['_path']);{const _0x24af1c=Kl(_0x140a1f,_0x35bb9d);return An(_0x56e959,_0x35bb9d,null,_0x24af1c);}}};}function Wt(_0x36ed09,_0x4e839f){const _0x1f46bf=Hn(_0x4e839f);return _0x36ed09['queryToTagMap']['get'](_0x1f46bf);}function Hn(_0x9723b){return _0x9723b['_path']['toString']()+'$'+_0x9723b['_queryIdentifier'];}function cs(_0x40e84e,_0x1b91f0){return _0x40e84e['tagToQueryMap']['get'](_0x1b91f0);}function ls(_0x56a496){const _0x2800f1=_0x56a496['indexOf']('$');return f(_0x2800f1!==-0x1&&_0x2800f1<_0x56a496['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x56a496['substr'](_0x2800f1+0x1),'path':new C(_0x56a496['substr'](0x0,_0x2800f1))};}function hs(_0x16bfcf,_0x20f2d9,_0x3b5cbd){const _0x3f6614=_0x16bfcf['syncPointTree_']['get'](_0x20f2d9);f(_0x3f6614,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x560314=Wn(_0x16bfcf['pendingWriteTree_'],_0x20f2d9);return os(_0x3f6614,_0x3b5cbd,_0x560314,null);}function Zu(_0xdab14a){return _0xdab14a['fold']((_0x1ed1d6,_0x494e04,_0x5abc79)=>{if(_0x494e04&&Se(_0x494e04))return[Bn(_0x494e04)];{let _0xe17a0f=[];return _0x494e04&&(_0xe17a0f=Ko(_0x494e04)),x(_0x5abc79,(_0x7d9c78,_0x538bfd)=>{_0xe17a0f=_0xe17a0f['concat'](_0x538bfd);}),_0xe17a0f;}});}function kt(_0x316a28){return _0x316a28['_queryParams']['loadsAllData']()&&!_0x316a28['_queryParams']['isDefault']()?new(qu())(_0x316a28['_repo'],_0x316a28['_path']):_0x316a28;}function ed(_0x5a24f7,_0x32229c){for(let _0x142d48=0x0;_0x142d48<_0x32229c['length'];++_0x142d48){const _0x2a8e4c=_0x32229c[_0x142d48];if(!_0x2a8e4c['_queryParams']['loadsAllData']()){const _0x16e5c7=Hn(_0x2a8e4c),_0x3394bb=_0x5a24f7['queryToTagMap']['get'](_0x16e5c7);_0x5a24f7['queryToTagMap']['delete'](_0x16e5c7),_0x5a24f7['tagToQueryMap']['delete'](_0x3394bb);}}}function td(){return zu++;}function nd(_0x477b1d,_0x34a770,_0x429c65){const _0x20044b=_0x34a770['_path'],_0x23f38f=Wt(_0x477b1d,_0x34a770),_0xd5d275=ea(_0x477b1d,_0x429c65),_0x529be5=_0x477b1d['listenProvider_']['startListening'](kt(_0x34a770),_0x23f38f,_0xd5d275['hashFn'],_0xd5d275['onComplete']),_0x3503f9=_0x477b1d['syncPointTree_']['subtree'](_0x20044b);if(_0x23f38f)f(!Se(_0x3503f9['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0xa2134f=_0x3503f9['fold']((_0x193da3,_0x5766a2,_0x64818f)=>{if(!v(_0x193da3)&&_0x5766a2&&Se(_0x5766a2))return[Bn(_0x5766a2)['query']];{let _0x1e589f=[];return _0x5766a2&&(_0x1e589f=_0x1e589f['concat'](Ko(_0x5766a2)['map'](_0x3e491b=>_0x3e491b['query']))),x(_0x64818f,(_0x20789a,_0x2bd29a)=>{_0x1e589f=_0x1e589f['concat'](_0x2bd29a);}),_0x1e589f;}});for(let _0x213960=0x0;_0x213960<_0xa2134f['length'];++_0x213960){const _0x3811f5=_0xa2134f[_0x213960];_0x477b1d['listenProvider_']['stopListening'](kt(_0x3811f5),Wt(_0x477b1d,_0x3811f5));}}return _0x529be5;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x4b4b7e){this['node_']=_0x4b4b7e;}['getImmediateChild'](_0x11e7a7){const _0x196cee=this['node_']['getImmediateChild'](_0x11e7a7);return new us(_0x196cee);}['node'](){return this['node_'];}}class ds{constructor(_0x11ccb9,_0x4a1b70){this['syncTree_']=_0x11ccb9,this['path_']=_0x4a1b70;}['getImmediateChild'](_0x319e97){const _0x4c145e=k(this['path_'],_0x319e97);return new ds(this['syncTree_'],_0x4c145e);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x446f04){return _0x446f04=_0x446f04||{},_0x446f04['timestamp']=_0x446f04['timestamp']||new Date()['getTime'](),_0x446f04;},_r=function(_0x5017a9,_0x38288d,_0x9fb0cf){if(!_0x5017a9||typeof _0x5017a9!='object')return _0x5017a9;if(f('.sv'in _0x5017a9,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x5017a9['.sv']=='string')return sd(_0x5017a9['.sv'],_0x38288d,_0x9fb0cf);if(typeof _0x5017a9['.sv']=='object')return rd(_0x5017a9['.sv'],_0x38288d);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x5017a9,null,0x2));},sd=function(_0x28d83b,_0x183cc6,_0x2f9acd){switch(_0x28d83b){case'timestamp':return _0x2f9acd['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x28d83b);}},rd=function(_0x30267e,_0x11104d,_0x30f998){_0x30267e['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x30267e,null,0x2));const _0x3f4d97=_0x30267e['increment'];typeof _0x3f4d97!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x3f4d97);const _0x1e9106=_0x11104d['node']();if(f(_0x1e9106!==null&&typeof _0x1e9106<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x1e9106['isLeafNode']())return _0x3f4d97;const _0x2cb556=_0x1e9106['getValue']();return typeof _0x2cb556!='number'?_0x3f4d97:_0x2cb556+_0x3f4d97;},ta=function(_0x5d7a6d,_0x27f91b,_0x229339,_0x3b774c){return ps(_0x27f91b,new ds(_0x229339,_0x5d7a6d),_0x3b774c);},fs=function(_0x11e211,_0x5a90f4,_0x5f4f5f){return ps(_0x11e211,new us(_0x5a90f4),_0x5f4f5f);};function ps(_0x210eb2,_0x3f1726,_0x38e91c){const _0x2e3729=_0x210eb2['getPriority']()['val'](),_0x5986fb=_r(_0x2e3729,_0x3f1726['getImmediateChild']('.priority'),_0x38e91c);let _0x2676e8;if(_0x210eb2['isLeafNode']()){const _0x41b4f7=_0x210eb2,_0x439c8a=_r(_0x41b4f7['getValue'](),_0x3f1726,_0x38e91c);return _0x439c8a!==_0x41b4f7['getValue']()||_0x5986fb!==_0x41b4f7['getPriority']()['val']()?new D(_0x439c8a,A(_0x5986fb)):_0x210eb2;}else{const _0x4e204f=_0x210eb2;return _0x2676e8=_0x4e204f,_0x5986fb!==_0x4e204f['getPriority']()['val']()&&(_0x2676e8=_0x2676e8['updatePriority'](new D(_0x5986fb))),_0x4e204f['forEachChild'](R,(_0x58cf54,_0x3b8690)=>{const _0x26c67a=ps(_0x3b8690,_0x3f1726['getImmediateChild'](_0x58cf54),_0x38e91c);_0x26c67a!==_0x3b8690&&(_0x2676e8=_0x2676e8['updateImmediateChild'](_0x58cf54,_0x26c67a));}),_0x2676e8;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x533657='',_0x2d9d1e=null,_0x109864={'children':{},'childCount':0x0}){this['name']=_0x533657,this['parent']=_0x2d9d1e,this['node']=_0x109864;}}function $n(_0x246cff,_0x1cb762){let _0x150ec7=_0x1cb762 instanceof C?_0x1cb762:new C(_0x1cb762),_0x36440c=_0x246cff,_0x25a09c=y(_0x150ec7);for(;_0x25a09c!==null;){const _0x1a4cd0=Le(_0x36440c['node']['children'],_0x25a09c)||{'children':{},'childCount':0x0};_0x36440c=new _s(_0x25a09c,_0x36440c,_0x1a4cd0),_0x150ec7=S(_0x150ec7),_0x25a09c=y(_0x150ec7);}return _0x36440c;}function je(_0x27cd6d){return _0x27cd6d['node']['value'];}function gs(_0x2d1d89,_0x130e32){_0x2d1d89['node']['value']=_0x130e32,Oi(_0x2d1d89);}function na(_0x303c5a){return _0x303c5a['node']['childCount']>0x0;}function od(_0x4e6d3f){return je(_0x4e6d3f)===void 0x0&&!na(_0x4e6d3f);}function Gn(_0x32e64b,_0x42d0ae){x(_0x32e64b['node']['children'],(_0x4976f4,_0x379d08)=>{_0x42d0ae(new _s(_0x4976f4,_0x32e64b,_0x379d08));});}function ia(_0x44a209,_0x384c1b,_0xf3e028,_0x3a7bb1){_0xf3e028&&_0x384c1b(_0x44a209),Gn(_0x44a209,_0x1b3058=>{ia(_0x1b3058,_0x384c1b,!0x0);});}function ad(_0x421a91,_0x54fa07,_0x58627c){let _0xd6c417=_0x421a91['parent'];for(;_0xd6c417!==null;){if(_0x54fa07(_0xd6c417))return!0x0;_0xd6c417=_0xd6c417['parent'];}return!0x1;}function Qt(_0x4114ba){return new C(_0x4114ba['parent']===null?_0x4114ba['name']:Qt(_0x4114ba['parent'])+'/'+_0x4114ba['name']);}function Oi(_0xd973d){_0xd973d['parent']!==null&&cd(_0xd973d['parent'],_0xd973d['name'],_0xd973d);}function cd(_0x5a91f7,_0x249c9e,_0x184667){const _0x18a0b2=od(_0x184667),_0x21505e=Q(_0x5a91f7['node']['children'],_0x249c9e);_0x18a0b2&&_0x21505e?(delete _0x5a91f7['node']['children'][_0x249c9e],_0x5a91f7['node']['childCount']--,Oi(_0x5a91f7)):!_0x18a0b2&&!_0x21505e&&(_0x5a91f7['node']['children'][_0x249c9e]=_0x184667['node'],_0x5a91f7['node']['childCount']++,Oi(_0x5a91f7));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x122470){return typeof _0x122470=='string'&&_0x122470['length']!==0x0&&!ld['test'](_0x122470);},sa=function(_0x590d22){return typeof _0x590d22=='string'&&_0x590d22['length']!==0x0&&!hd['test'](_0x590d22);},ud=function(_0xbbed53){return _0xbbed53&&(_0xbbed53=_0xbbed53['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0xbbed53);},Bt=function(_0xc77086){return _0xc77086===null||typeof _0xc77086=='string'||typeof _0xc77086=='number'&&!xn(_0xc77086)||_0xc77086&&typeof _0xc77086=='object'&&Q(_0xc77086,'.sv');},He=function(_0x198102,_0x4b1a3d,_0x3e89f5,_0x5e7317){_0x5e7317&&_0x4b1a3d===void 0x0||Jt(it(_0x198102,'value'),_0x4b1a3d,_0x3e89f5);},Jt=function(_0x169e3a,_0x25fec5,_0x114f46){const _0x49fd4b=_0x114f46 instanceof C?new Ah(_0x114f46,_0x169e3a):_0x114f46;if(_0x25fec5===void 0x0)throw new Error(_0x169e3a+'contains\x20undefined\x20'+Oe(_0x49fd4b));if(typeof _0x25fec5=='function')throw new Error(_0x169e3a+'contains\x20a\x20function\x20'+Oe(_0x49fd4b)+'\x20with\x20contents\x20=\x20'+_0x25fec5['toString']());if(xn(_0x25fec5))throw new Error(_0x169e3a+'contains\x20'+_0x25fec5['toString']()+'\x20'+Oe(_0x49fd4b));if(typeof _0x25fec5=='string'&&_0x25fec5['length']>ui/0x3&&Ln(_0x25fec5)>ui)throw new Error(_0x169e3a+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x49fd4b)+'\x20(\x27'+_0x25fec5['substring'](0x0,0x32)+'...\x27)');if(_0x25fec5&&typeof _0x25fec5=='object'){let _0x3c8da5=!0x1,_0x2e1d6a=!0x1;if(x(_0x25fec5,(_0x406bf4,_0x7259d1)=>{if(_0x406bf4==='.value')_0x3c8da5=!0x0;else{if(_0x406bf4!=='.priority'&&_0x406bf4!=='.sv'&&(_0x2e1d6a=!0x0,!ms(_0x406bf4)))throw new Error(_0x169e3a+'\x20contains\x20an\x20invalid\x20key\x20('+_0x406bf4+')\x20'+Oe(_0x49fd4b)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x49fd4b,_0x406bf4),Jt(_0x169e3a,_0x7259d1,_0x49fd4b),Ph(_0x49fd4b);}),_0x3c8da5&&_0x2e1d6a)throw new Error(_0x169e3a+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x49fd4b)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x5d4980,_0x2bc16c){let _0x291dfb,_0x4c8d59;for(_0x291dfb=0x0;_0x291dfb<_0x2bc16c['length'];_0x291dfb++){_0x4c8d59=_0x2bc16c[_0x291dfb];const _0x22d539=Mt(_0x4c8d59);for(let _0x43650c=0x0;_0x43650c<_0x22d539['length'];_0x43650c++)if(!(_0x22d539[_0x43650c]==='.priority'&&_0x43650c===_0x22d539['length']-0x1)){if(!ms(_0x22d539[_0x43650c]))throw new Error(_0x5d4980+'contains\x20an\x20invalid\x20key\x20('+_0x22d539[_0x43650c]+')\x20in\x20path\x20'+_0x4c8d59['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x2bc16c['sort'](Rh);let _0x8bc0ea=null;for(_0x291dfb=0x0;_0x291dfb<_0x2bc16c['length'];_0x291dfb++){if(_0x4c8d59=_0x2bc16c[_0x291dfb],_0x8bc0ea!==null&&G(_0x8bc0ea,_0x4c8d59))throw new Error(_0x5d4980+'contains\x20a\x20path\x20'+_0x8bc0ea['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x4c8d59['toString']());_0x8bc0ea=_0x4c8d59;}},ra=function(_0x7765fe,_0x3ceb60,_0x2b420e,_0x353a12){const _0x4843f0=it(_0x7765fe,'values');if(!(_0x3ceb60&&typeof _0x3ceb60=='object')||Array['isArray'](_0x3ceb60))throw new Error(_0x4843f0+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x5d3c57=[];x(_0x3ceb60,(_0x20b3a4,_0x5a8831)=>{const _0x3f6bbc=new C(_0x20b3a4);if(Jt(_0x4843f0,_0x5a8831,k(_0x2b420e,_0x3f6bbc)),ji(_0x3f6bbc)==='.priority'&&!Bt(_0x5a8831))throw new Error(_0x4843f0+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x3f6bbc['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x5d3c57['push'](_0x3f6bbc);}),dd(_0x4843f0,_0x5d3c57);},fd=function(_0x1094ee,_0xe66a35,_0x56ca5b){if(xn(_0xe66a35))throw new Error(it(_0x1094ee,'priority')+'is\x20'+_0xe66a35['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0xe66a35))throw new Error(it(_0x1094ee,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x292158,_0x32eb98,_0x518508,_0xc2e4a){if(!sa(_0x518508))throw new Error(it(_0x292158,_0x32eb98)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x518508+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x4dbc5d,_0x3319f8,_0x93f4a6,_0x3177e2){_0x93f4a6&&(_0x93f4a6=_0x93f4a6['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x4dbc5d,_0x3319f8,_0x93f4a6);},Me=function(_0x3b7820,_0x1dfef4){if(y(_0x1dfef4)==='.info')throw new Error(_0x3b7820+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x3d3542,_0xa6eb05){const _0x2db7eb=_0xa6eb05['path']['toString']();if(typeof _0xa6eb05['repoInfo']['host']!='string'||_0xa6eb05['repoInfo']['host']['length']===0x0||!ms(_0xa6eb05['repoInfo']['namespace'])&&_0xa6eb05['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x2db7eb['length']!==0x0&&!ud(_0x2db7eb))throw new Error(it(_0x3d3542,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x27ee34,_0x291f13){let _0x4e0b28=null;for(let _0x452c57=0x0;_0x452c57<_0x291f13['length'];_0x452c57++){const _0x1d3cdd=_0x291f13[_0x452c57],_0x37d83c=_0x1d3cdd['getPath']();_0x4e0b28!==null&&!Ki(_0x37d83c,_0x4e0b28['path'])&&(_0x27ee34['eventLists_']['push'](_0x4e0b28),_0x4e0b28=null),_0x4e0b28===null&&(_0x4e0b28={'events':[],'path':_0x37d83c}),_0x4e0b28['events']['push'](_0x1d3cdd);}_0x4e0b28&&_0x27ee34['eventLists_']['push'](_0x4e0b28);}function oa(_0x4572bb,_0x36c460,_0x26a624){qn(_0x4572bb,_0x26a624),aa(_0x4572bb,_0x5c36ee=>Ki(_0x5c36ee,_0x36c460));}function V(_0x51c817,_0x1fbb1a,_0x192aae){qn(_0x51c817,_0x192aae),aa(_0x51c817,_0xb40d4=>G(_0xb40d4,_0x1fbb1a)||G(_0x1fbb1a,_0xb40d4));}function aa(_0x302715,_0x135d1e){_0x302715['recursionDepth_']++;let _0x46191f=!0x0;for(let _0x1b5b89=0x0;_0x1b5b89<_0x302715['eventLists_']['length'];_0x1b5b89++){const _0x99fa01=_0x302715['eventLists_'][_0x1b5b89];if(_0x99fa01){const _0x17c14d=_0x99fa01['path'];_0x135d1e(_0x17c14d)?(md(_0x302715['eventLists_'][_0x1b5b89]),_0x302715['eventLists_'][_0x1b5b89]=null):_0x46191f=!0x1;}}_0x46191f&&(_0x302715['eventLists_']=[]),_0x302715['recursionDepth_']--;}function md(_0x36ba99){for(let _0x1c5761=0x0;_0x1c5761<_0x36ba99['events']['length'];_0x1c5761++){const _0x39f85c=_0x36ba99['events'][_0x1c5761];if(_0x39f85c!==null){_0x36ba99['events'][_0x1c5761]=null;const _0x29c5d1=_0x39f85c['getEventRunner']();St&&L('event:\x20'+_0x39f85c['toString']()),ft(_0x29c5d1);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x5dba9a,_0xe89da1,_0x203d5f,_0x28bf0e){this['repoInfo_']=_0x5dba9a,this['forceRestClient_']=_0xe89da1,this['authTokenProvider_']=_0x203d5f,this['appCheckProvider_']=_0x28bf0e,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x2b2ce8,_0x13260b,_0x296482){if(_0x2b2ce8['stats_']=qi(_0x2b2ce8['repoInfo_']),_0x2b2ce8['forceRestClient_']||Xl())_0x2b2ce8['server_']=new vn(_0x2b2ce8['repoInfo_'],(_0x3afda3,_0x53bf9e,_0x37ea7a,_0x223c9b)=>{gr(_0x2b2ce8,_0x3afda3,_0x53bf9e,_0x37ea7a,_0x223c9b);},_0x2b2ce8['authTokenProvider_'],_0x2b2ce8['appCheckProvider_']),setTimeout(()=>mr(_0x2b2ce8,!0x0),0x0);else{if(typeof _0x296482<'u'&&_0x296482!==null){if(typeof _0x296482!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x296482);}catch(_0x4584fc){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x4584fc);}}_0x2b2ce8['persistentConnection_']=new se(_0x2b2ce8['repoInfo_'],_0x13260b,(_0x2bf289,_0x3c1e44,_0x57b3a6,_0xd8ad7)=>{gr(_0x2b2ce8,_0x2bf289,_0x3c1e44,_0x57b3a6,_0xd8ad7);},_0x124673=>{mr(_0x2b2ce8,_0x124673);},_0x5b092c=>{Id(_0x2b2ce8,_0x5b092c);},_0x2b2ce8['authTokenProvider_'],_0x2b2ce8['appCheckProvider_'],_0x296482),_0x2b2ce8['server_']=_0x2b2ce8['persistentConnection_'];}_0x2b2ce8['authTokenProvider_']['addTokenChangeListener'](_0x451c46=>{_0x2b2ce8['server_']['refreshAuthToken'](_0x451c46);}),_0x2b2ce8['appCheckProvider_']['addTokenChangeListener'](_0xbf6abf=>{_0x2b2ce8['server_']['refreshAppCheckToken'](_0xbf6abf['token']);}),_0x2b2ce8['statsReporter_']=ih(_0x2b2ce8['repoInfo_'],()=>new iu(_0x2b2ce8['stats_'],_0x2b2ce8['server_'])),_0x2b2ce8['infoData_']=new Xh(),_0x2b2ce8['infoSyncTree_']=new pr({'startListening':(_0x2c8516,_0x4a6fa8,_0x53d71e,_0x43ae2b)=>{let _0x238020=[];const _0x2548a5=_0x2b2ce8['infoData_']['getNode'](_0x2c8516['_path']);return _0x2548a5['isEmpty']()||(_0x238020=Yt(_0x2b2ce8['infoSyncTree_'],_0x2c8516['_path'],_0x2548a5),setTimeout(()=>{_0x43ae2b('ok');},0x0)),_0x238020;},'stopListening':()=>{}}),vs(_0x2b2ce8,'connected',!0x1),_0x2b2ce8['serverSyncTree_']=new pr({'startListening':(_0x247d46,_0x2798c3,_0x43dae8,_0x473290)=>(_0x2b2ce8['server_']['listen'](_0x247d46,_0x43dae8,_0x2798c3,(_0xe19929,_0x336701)=>{const _0x1db85d=_0x473290(_0xe19929,_0x336701);V(_0x2b2ce8['eventQueue_'],_0x247d46['_path'],_0x1db85d);}),[]),'stopListening':(_0x5537b5,_0x4a42a7)=>{_0x2b2ce8['server_']['unlisten'](_0x5537b5,_0x4a42a7);}});}function la(_0x3bd2c0){const _0x5788b6=_0x3bd2c0['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x5788b6;}function Xt(_0x538443){return id({'timestamp':la(_0x538443)});}function gr(_0x499790,_0x11f949,_0x203fb0,_0x37d1e0,_0x2bd338){_0x499790['dataUpdateCount']++;const _0x4e2350=new C(_0x11f949);_0x203fb0=_0x499790['interceptServerDataCallback_']?_0x499790['interceptServerDataCallback_'](_0x11f949,_0x203fb0):_0x203fb0;let _0x483983=[];if(_0x2bd338){if(_0x37d1e0){const _0x1478a9=_n(_0x203fb0,_0x3162de=>A(_0x3162de));_0x483983=Ju(_0x499790['serverSyncTree_'],_0x4e2350,_0x1478a9,_0x2bd338);}else{const _0x322571=A(_0x203fb0);_0x483983=Jo(_0x499790['serverSyncTree_'],_0x4e2350,_0x322571,_0x2bd338);}}else{if(_0x37d1e0){const _0x3600bd=_n(_0x203fb0,_0x4daba9=>A(_0x4daba9));_0x483983=Ku(_0x499790['serverSyncTree_'],_0x4e2350,_0x3600bd);}else{const _0x15133e=A(_0x203fb0);_0x483983=Yt(_0x499790['serverSyncTree_'],_0x4e2350,_0x15133e);}}let _0x35f550=_0x4e2350;_0x483983['length']>0x0&&(_0x35f550=ct(_0x499790,_0x4e2350)),V(_0x499790['eventQueue_'],_0x35f550,_0x483983);}function mr(_0x20f86f,_0x1596b6){vs(_0x20f86f,'connected',_0x1596b6),_0x1596b6===!0x1&&Sd(_0x20f86f);}function Id(_0x2614be,_0x358fdf){x(_0x358fdf,(_0x3f1e84,_0x3a3602)=>{vs(_0x2614be,_0x3f1e84,_0x3a3602);});}function vs(_0x3b6b0c,_0x25bfc4,_0x590bcc){const _0x61b155=new C('/.info/'+_0x25bfc4),_0x554f4c=A(_0x590bcc);_0x3b6b0c['infoData_']['updateSnapshot'](_0x61b155,_0x554f4c);const _0xf82cd9=Yt(_0x3b6b0c['infoSyncTree_'],_0x61b155,_0x554f4c);V(_0x3b6b0c['eventQueue_'],_0x61b155,_0xf82cd9);}function zn(_0x463215){return _0x463215['nextWriteId_']++;}function wd(_0x1a0cae,_0x1b1d67,_0x59d43d){const _0x19fa9c=Xu(_0x1a0cae['serverSyncTree_'],_0x1b1d67);return _0x19fa9c!=null?Promise['resolve'](_0x19fa9c):_0x1a0cae['server_']['get'](_0x1b1d67)['then'](_0x536d99=>{const _0x436779=A(_0x536d99)['withIndex'](_0x1b1d67['_queryParams']['getIndex']());Ni(_0x1a0cae['serverSyncTree_'],_0x1b1d67,_0x59d43d,!0x0);let _0x1bc986;if(_0x1b1d67['_queryParams']['loadsAllData']())_0x1bc986=Yt(_0x1a0cae['serverSyncTree_'],_0x1b1d67['_path'],_0x436779);else{const _0x53cd9c=Wt(_0x1a0cae['serverSyncTree_'],_0x1b1d67);_0x1bc986=Jo(_0x1a0cae['serverSyncTree_'],_0x1b1d67['_path'],_0x436779,_0x53cd9c);}return V(_0x1a0cae['eventQueue_'],_0x1b1d67['_path'],_0x1bc986),An(_0x1a0cae['serverSyncTree_'],_0x1b1d67,_0x59d43d,null,!0x0),_0x436779;},_0x200c9e=>(gt(_0x1a0cae,'get\x20for\x20query\x20'+O(_0x1b1d67)+'\x20failed:\x20'+_0x200c9e),Promise['reject'](new Error(_0x200c9e))));}function Cd(_0x54605b,_0x5e39fe,_0x49068b,_0x334c37,_0x14962d){gt(_0x54605b,'set',{'path':_0x5e39fe['toString'](),'value':_0x49068b,'priority':_0x334c37});const _0x29a932=Xt(_0x54605b),_0x47bf78=A(_0x49068b,_0x334c37),_0x25bca4=Vn(_0x54605b['serverSyncTree_'],_0x5e39fe),_0x35bfbf=fs(_0x47bf78,_0x25bca4,_0x29a932),_0x2c1d80=zn(_0x54605b),_0x16f437=as(_0x54605b['serverSyncTree_'],_0x5e39fe,_0x35bfbf,_0x2c1d80,!0x0);qn(_0x54605b['eventQueue_'],_0x16f437),_0x54605b['server_']['put'](_0x5e39fe['toString'](),_0x47bf78['val'](!0x0),(_0xd17a42,_0x465e6a)=>{const _0x4271d9=_0xd17a42==='ok';_0x4271d9||U('set\x20at\x20'+_0x5e39fe+'\x20failed:\x20'+_0xd17a42);const _0x27a3c4=_e(_0x54605b['serverSyncTree_'],_0x2c1d80,!_0x4271d9);V(_0x54605b['eventQueue_'],_0x5e39fe,_0x27a3c4),be(_0x54605b,_0x14962d,_0xd17a42,_0x465e6a);});const _0x625f2d=Is(_0x54605b,_0x5e39fe);ct(_0x54605b,_0x625f2d),V(_0x54605b['eventQueue_'],_0x625f2d,[]);}function Td(_0x5a70e8,_0x29534c,_0x48520b,_0x30f063){gt(_0x5a70e8,'update',{'path':_0x29534c['toString'](),'value':_0x48520b});let _0x5d2bd1=!0x0;const _0x2cb67a=Xt(_0x5a70e8),_0x43e4c5={};if(x(_0x48520b,(_0x652f67,_0x55cfd5)=>{_0x5d2bd1=!0x1,_0x43e4c5[_0x652f67]=ta(k(_0x29534c,_0x652f67),A(_0x55cfd5),_0x5a70e8['serverSyncTree_'],_0x2cb67a);}),_0x5d2bd1)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x5a70e8,_0x30f063,'ok',void 0x0);else{const _0x4f420b=zn(_0x5a70e8),_0x276389=ju(_0x5a70e8['serverSyncTree_'],_0x29534c,_0x43e4c5,_0x4f420b);qn(_0x5a70e8['eventQueue_'],_0x276389),_0x5a70e8['server_']['merge'](_0x29534c['toString'](),_0x48520b,(_0x147582,_0xe225bb)=>{const _0xc63d06=_0x147582==='ok';_0xc63d06||U('update\x20at\x20'+_0x29534c+'\x20failed:\x20'+_0x147582);const _0x518e06=_e(_0x5a70e8['serverSyncTree_'],_0x4f420b,!_0xc63d06),_0x546c8d=_0x518e06['length']>0x0?ct(_0x5a70e8,_0x29534c):_0x29534c;V(_0x5a70e8['eventQueue_'],_0x546c8d,_0x518e06),be(_0x5a70e8,_0x30f063,_0x147582,_0xe225bb);}),x(_0x48520b,_0x33c062=>{const _0x150f7d=Is(_0x5a70e8,k(_0x29534c,_0x33c062));ct(_0x5a70e8,_0x150f7d);}),V(_0x5a70e8['eventQueue_'],_0x29534c,[]);}}function Sd(_0x3a5b2f){gt(_0x3a5b2f,'onDisconnectEvents');const _0x34311d=Xt(_0x3a5b2f),_0x11a490=En();Si(_0x3a5b2f['onDisconnect_'],w(),(_0x3da0dc,_0x12c8f4)=>{const _0x2e8b3b=ta(_0x3da0dc,_0x12c8f4,_0x3a5b2f['serverSyncTree_'],_0x34311d);pt(_0x11a490,_0x3da0dc,_0x2e8b3b);});let _0x4c1c07=[];Si(_0x11a490,w(),(_0x269583,_0x424da6)=>{_0x4c1c07=_0x4c1c07['concat'](Yt(_0x3a5b2f['serverSyncTree_'],_0x269583,_0x424da6));const _0x1502a3=Is(_0x3a5b2f,_0x269583);ct(_0x3a5b2f,_0x1502a3);}),_0x3a5b2f['onDisconnect_']=En(),V(_0x3a5b2f['eventQueue_'],w(),_0x4c1c07);}function bd(_0x3e66ef,_0x38252b,_0x3353da){_0x3e66ef['server_']['onDisconnectCancel'](_0x38252b['toString'](),(_0x2b7107,_0x141883)=>{_0x2b7107==='ok'&&Ti(_0x3e66ef['onDisconnect_'],_0x38252b),be(_0x3e66ef,_0x3353da,_0x2b7107,_0x141883);});}function yr(_0x503b8a,_0x49a2e9,_0x34d5bb,_0x4d82dc){const _0x5f238d=A(_0x34d5bb);_0x503b8a['server_']['onDisconnectPut'](_0x49a2e9['toString'](),_0x5f238d['val'](!0x0),(_0xdcd0b8,_0xc1d217)=>{_0xdcd0b8==='ok'&&pt(_0x503b8a['onDisconnect_'],_0x49a2e9,_0x5f238d),be(_0x503b8a,_0x4d82dc,_0xdcd0b8,_0xc1d217);});}function Rd(_0x197795,_0x2f9f61,_0x32632d,_0x4489f2,_0x590cb4){const _0x528b8f=A(_0x32632d,_0x4489f2);_0x197795['server_']['onDisconnectPut'](_0x2f9f61['toString'](),_0x528b8f['val'](!0x0),(_0xa1719c,_0x11ebc6)=>{_0xa1719c==='ok'&&pt(_0x197795['onDisconnect_'],_0x2f9f61,_0x528b8f),be(_0x197795,_0x590cb4,_0xa1719c,_0x11ebc6);});}function Ad(_0x190a64,_0x79d0eb,_0x43763b,_0x45276d){if(pn(_0x43763b)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x190a64,_0x45276d,'ok',void 0x0);return;}_0x190a64['server_']['onDisconnectMerge'](_0x79d0eb['toString'](),_0x43763b,(_0x2590a2,_0x43f3fc)=>{_0x2590a2==='ok'&&x(_0x43763b,(_0x2b898e,_0x10f950)=>{const _0x5cd735=A(_0x10f950);pt(_0x190a64['onDisconnect_'],k(_0x79d0eb,_0x2b898e),_0x5cd735);}),be(_0x190a64,_0x45276d,_0x2590a2,_0x43f3fc);});}function kd(_0x41275e,_0x52342a,_0x4b8a87){let _0x5e28ac;y(_0x52342a['_path'])==='.info'?_0x5e28ac=Ni(_0x41275e['infoSyncTree_'],_0x52342a,_0x4b8a87):_0x5e28ac=Ni(_0x41275e['serverSyncTree_'],_0x52342a,_0x4b8a87),oa(_0x41275e['eventQueue_'],_0x52342a['_path'],_0x5e28ac);}function Pd(_0x5b6d0c,_0x1b0f3a,_0x16e48f){let _0x222c59;y(_0x1b0f3a['_path'])==='.info'?_0x222c59=An(_0x5b6d0c['infoSyncTree_'],_0x1b0f3a,_0x16e48f):_0x222c59=An(_0x5b6d0c['serverSyncTree_'],_0x1b0f3a,_0x16e48f),oa(_0x5b6d0c['eventQueue_'],_0x1b0f3a['_path'],_0x222c59);}function ha(_0x29ae20){_0x29ae20['persistentConnection_']&&_0x29ae20['persistentConnection_']['interrupt'](ca);}function Nd(_0x1f00a3){_0x1f00a3['persistentConnection_']&&_0x1f00a3['persistentConnection_']['resume'](ca);}function gt(_0x2bc3b5,..._0x2c045d){let _0x205a68='';_0x2bc3b5['persistentConnection_']&&(_0x205a68=_0x2bc3b5['persistentConnection_']['id']+':'),L(_0x205a68,..._0x2c045d);}function be(_0x49f2a2,_0x1022fe,_0x55df6b,_0x5f2b0b){_0x1022fe&&ft(()=>{if(_0x55df6b==='ok')_0x1022fe(null);else{const _0x147d06=(_0x55df6b||'error')['toUpperCase']();let _0x1620d3=_0x147d06;_0x5f2b0b&&(_0x1620d3+=':\x20'+_0x5f2b0b);const _0x2c9f75=new Error(_0x1620d3);_0x2c9f75['code']=_0x147d06,_0x1022fe(_0x2c9f75);}});}function Od(_0x11637d,_0x5e463d,_0x149e21,_0x309878,_0x6f38af,_0xc811b9){gt(_0x11637d,'transaction\x20on\x20'+_0x5e463d);const _0x4bf01c={'path':_0x5e463d,'update':_0x149e21,'onComplete':_0x309878,'status':null,'order':so(),'applyLocally':_0xc811b9,'retryCount':0x0,'unwatcher':_0x6f38af,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x492286=Es(_0x11637d,_0x5e463d,void 0x0);_0x4bf01c['currentInputSnapshot']=_0x492286;const _0x4aba19=_0x4bf01c['update'](_0x492286['val']());if(_0x4aba19===void 0x0)_0x4bf01c['unwatcher'](),_0x4bf01c['currentOutputSnapshotRaw']=null,_0x4bf01c['currentOutputSnapshotResolved']=null,_0x4bf01c['onComplete']&&_0x4bf01c['onComplete'](null,!0x1,_0x4bf01c['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x4aba19,_0x4bf01c['path']),_0x4bf01c['status']=0x0;const _0x379ed4=$n(_0x11637d['transactionQueueTree_'],_0x5e463d),_0x603a4c=je(_0x379ed4)||[];_0x603a4c['push'](_0x4bf01c),gs(_0x379ed4,_0x603a4c);let _0x501596;typeof _0x4aba19=='object'&&_0x4aba19!==null&&Q(_0x4aba19,'.priority')?(_0x501596=Le(_0x4aba19,'.priority'),f(Bt(_0x501596),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x501596=(Vn(_0x11637d['serverSyncTree_'],_0x5e463d)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x18a01a=Xt(_0x11637d),_0x4c7ce5=A(_0x4aba19,_0x501596),_0x36ca6d=fs(_0x4c7ce5,_0x492286,_0x18a01a);_0x4bf01c['currentOutputSnapshotRaw']=_0x4c7ce5,_0x4bf01c['currentOutputSnapshotResolved']=_0x36ca6d,_0x4bf01c['currentWriteId']=zn(_0x11637d);const _0x33e793=as(_0x11637d['serverSyncTree_'],_0x5e463d,_0x36ca6d,_0x4bf01c['currentWriteId'],_0x4bf01c['applyLocally']);V(_0x11637d['eventQueue_'],_0x5e463d,_0x33e793),jn(_0x11637d,_0x11637d['transactionQueueTree_']);}}function Es(_0x57161c,_0x1993f2,_0x1368b5){return Vn(_0x57161c['serverSyncTree_'],_0x1993f2,_0x1368b5)||g['EMPTY_NODE'];}function jn(_0x6a048a,_0x1c3ba4=_0x6a048a['transactionQueueTree_']){if(_0x1c3ba4||Kn(_0x6a048a,_0x1c3ba4),je(_0x1c3ba4)){const _0x4abd13=da(_0x6a048a,_0x1c3ba4);f(_0x4abd13['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x4abd13['every'](_0x8c6d27=>_0x8c6d27['status']===0x0)&&Dd(_0x6a048a,Qt(_0x1c3ba4),_0x4abd13);}else na(_0x1c3ba4)&&Gn(_0x1c3ba4,_0x17a19a=>{jn(_0x6a048a,_0x17a19a);});}function Dd(_0x38ebfa,_0x506a26,_0x504fd0){const _0xcf604f=_0x504fd0['map'](_0x41b3d0=>_0x41b3d0['currentWriteId']),_0x171438=Es(_0x38ebfa,_0x506a26,_0xcf604f);let _0x4fafea=_0x171438;const _0x298b43=_0x171438['hash']();for(let _0x2a1232=0x0;_0x2a1232<_0x504fd0['length'];_0x2a1232++){const _0x46e25b=_0x504fd0[_0x2a1232];f(_0x46e25b['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x46e25b['status']=0x1,_0x46e25b['retryCount']++;const _0x39adee=F(_0x506a26,_0x46e25b['path']);_0x4fafea=_0x4fafea['updateChild'](_0x39adee,_0x46e25b['currentOutputSnapshotRaw']);}const _0x1f99f0=_0x4fafea['val'](!0x0),_0x5a97d5=_0x506a26;_0x38ebfa['server_']['put'](_0x5a97d5['toString'](),_0x1f99f0,_0x56392a=>{gt(_0x38ebfa,'transaction\x20put\x20response',{'path':_0x5a97d5['toString'](),'status':_0x56392a});let _0x50c0df=[];if(_0x56392a==='ok'){const _0x477213=[];for(let _0x4a9543=0x0;_0x4a9543<_0x504fd0['length'];_0x4a9543++)_0x504fd0[_0x4a9543]['status']=0x2,_0x50c0df=_0x50c0df['concat'](_e(_0x38ebfa['serverSyncTree_'],_0x504fd0[_0x4a9543]['currentWriteId'])),_0x504fd0[_0x4a9543]['onComplete']&&_0x477213['push'](()=>_0x504fd0[_0x4a9543]['onComplete'](null,!0x0,_0x504fd0[_0x4a9543]['currentOutputSnapshotResolved'])),_0x504fd0[_0x4a9543]['unwatcher']();Kn(_0x38ebfa,$n(_0x38ebfa['transactionQueueTree_'],_0x506a26)),jn(_0x38ebfa,_0x38ebfa['transactionQueueTree_']),V(_0x38ebfa['eventQueue_'],_0x506a26,_0x50c0df);for(let _0x492d25=0x0;_0x492d25<_0x477213['length'];_0x492d25++)ft(_0x477213[_0x492d25]);}else{if(_0x56392a==='datastale'){for(let _0x1c01ab=0x0;_0x1c01ab<_0x504fd0['length'];_0x1c01ab++)_0x504fd0[_0x1c01ab]['status']===0x3?_0x504fd0[_0x1c01ab]['status']=0x4:_0x504fd0[_0x1c01ab]['status']=0x0;}else{U('transaction\x20at\x20'+_0x5a97d5['toString']()+'\x20failed:\x20'+_0x56392a);for(let _0x2bd965=0x0;_0x2bd965<_0x504fd0['length'];_0x2bd965++)_0x504fd0[_0x2bd965]['status']=0x4,_0x504fd0[_0x2bd965]['abortReason']=_0x56392a;}ct(_0x38ebfa,_0x506a26);}},_0x298b43);}function ct(_0x53f507,_0x302705){const _0x4e84f6=ua(_0x53f507,_0x302705),_0x4ccb1c=Qt(_0x4e84f6),_0x3b01c3=da(_0x53f507,_0x4e84f6);return Md(_0x53f507,_0x3b01c3,_0x4ccb1c),_0x4ccb1c;}function Md(_0x4f9849,_0x368dd4,_0x126414){if(_0x368dd4['length']===0x0)return;const _0x598766=[];let _0x3f16b0=[];const _0x33d3a3=_0x368dd4['filter'](_0x2becfc=>_0x2becfc['status']===0x0)['map'](_0x149377=>_0x149377['currentWriteId']);for(let _0x5592f3=0x0;_0x5592f3<_0x368dd4['length'];_0x5592f3++){const _0xd72ac0=_0x368dd4[_0x5592f3],_0x30ed13=F(_0x126414,_0xd72ac0['path']);let _0x546ca5=!0x1,_0x29f91f;if(f(_0x30ed13!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0xd72ac0['status']===0x4)_0x546ca5=!0x0,_0x29f91f=_0xd72ac0['abortReason'],_0x3f16b0=_0x3f16b0['concat'](_e(_0x4f9849['serverSyncTree_'],_0xd72ac0['currentWriteId'],!0x0));else{if(_0xd72ac0['status']===0x0){if(_0xd72ac0['retryCount']>=yd)_0x546ca5=!0x0,_0x29f91f='maxretry',_0x3f16b0=_0x3f16b0['concat'](_e(_0x4f9849['serverSyncTree_'],_0xd72ac0['currentWriteId'],!0x0));else{const _0x9e8742=Es(_0x4f9849,_0xd72ac0['path'],_0x33d3a3);_0xd72ac0['currentInputSnapshot']=_0x9e8742;const _0x2e422a=_0x368dd4[_0x5592f3]['update'](_0x9e8742['val']());if(_0x2e422a!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x2e422a,_0xd72ac0['path']);let _0x236a43=A(_0x2e422a);typeof _0x2e422a=='object'&&_0x2e422a!=null&&Q(_0x2e422a,'.priority')||(_0x236a43=_0x236a43['updatePriority'](_0x9e8742['getPriority']()));const _0x107dcf=_0xd72ac0['currentWriteId'],_0x1cc392=Xt(_0x4f9849),_0x5e8f56=fs(_0x236a43,_0x9e8742,_0x1cc392);_0xd72ac0['currentOutputSnapshotRaw']=_0x236a43,_0xd72ac0['currentOutputSnapshotResolved']=_0x5e8f56,_0xd72ac0['currentWriteId']=zn(_0x4f9849),_0x33d3a3['splice'](_0x33d3a3['indexOf'](_0x107dcf),0x1),_0x3f16b0=_0x3f16b0['concat'](as(_0x4f9849['serverSyncTree_'],_0xd72ac0['path'],_0x5e8f56,_0xd72ac0['currentWriteId'],_0xd72ac0['applyLocally'])),_0x3f16b0=_0x3f16b0['concat'](_e(_0x4f9849['serverSyncTree_'],_0x107dcf,!0x0));}else _0x546ca5=!0x0,_0x29f91f='nodata',_0x3f16b0=_0x3f16b0['concat'](_e(_0x4f9849['serverSyncTree_'],_0xd72ac0['currentWriteId'],!0x0));}}}V(_0x4f9849['eventQueue_'],_0x126414,_0x3f16b0),_0x3f16b0=[],_0x546ca5&&(_0x368dd4[_0x5592f3]['status']=0x2,function(_0x55bbd1){setTimeout(_0x55bbd1,Math['floor'](0x0));}(_0x368dd4[_0x5592f3]['unwatcher']),_0x368dd4[_0x5592f3]['onComplete']&&(_0x29f91f==='nodata'?_0x598766['push'](()=>_0x368dd4[_0x5592f3]['onComplete'](null,!0x1,_0x368dd4[_0x5592f3]['currentInputSnapshot'])):_0x598766['push'](()=>_0x368dd4[_0x5592f3]['onComplete'](new Error(_0x29f91f),!0x1,null))));}Kn(_0x4f9849,_0x4f9849['transactionQueueTree_']);for(let _0x8aabc8=0x0;_0x8aabc8<_0x598766['length'];_0x8aabc8++)ft(_0x598766[_0x8aabc8]);jn(_0x4f9849,_0x4f9849['transactionQueueTree_']);}function ua(_0x256f7f,_0x233dfc){let _0x265286,_0x4ca244=_0x256f7f['transactionQueueTree_'];for(_0x265286=y(_0x233dfc);_0x265286!==null&&je(_0x4ca244)===void 0x0;)_0x4ca244=$n(_0x4ca244,_0x265286),_0x233dfc=S(_0x233dfc),_0x265286=y(_0x233dfc);return _0x4ca244;}function da(_0x3f69c9,_0x4c9345){const _0x36163f=[];return fa(_0x3f69c9,_0x4c9345,_0x36163f),_0x36163f['sort']((_0x497808,_0x2e6450)=>_0x497808['order']-_0x2e6450['order']),_0x36163f;}function fa(_0x1ee399,_0x4e57be,_0x17213c){const _0x479715=je(_0x4e57be);if(_0x479715){for(let _0x5f4b0a=0x0;_0x5f4b0a<_0x479715['length'];_0x5f4b0a++)_0x17213c['push'](_0x479715[_0x5f4b0a]);}Gn(_0x4e57be,_0x2fa128=>{fa(_0x1ee399,_0x2fa128,_0x17213c);});}function Kn(_0xedd725,_0x109070){const _0x506b75=je(_0x109070);if(_0x506b75){let _0x329cec=0x0;for(let _0x3497f7=0x0;_0x3497f7<_0x506b75['length'];_0x3497f7++)_0x506b75[_0x3497f7]['status']!==0x2&&(_0x506b75[_0x329cec]=_0x506b75[_0x3497f7],_0x329cec++);_0x506b75['length']=_0x329cec,gs(_0x109070,_0x506b75['length']>0x0?_0x506b75:void 0x0);}Gn(_0x109070,_0x8401c9=>{Kn(_0xedd725,_0x8401c9);});}function Is(_0x5c19be,_0x27fc8e){const _0x3ee8f4=Qt(ua(_0x5c19be,_0x27fc8e)),_0x17845b=$n(_0x5c19be['transactionQueueTree_'],_0x27fc8e);return ad(_0x17845b,_0x24633d=>{di(_0x5c19be,_0x24633d);}),di(_0x5c19be,_0x17845b),ia(_0x17845b,_0x25cb95=>{di(_0x5c19be,_0x25cb95);}),_0x3ee8f4;}function di(_0xdb9939,_0xdd70f6){const _0x5f4dee=je(_0xdd70f6);if(_0x5f4dee){const _0x539f68=[];let _0x4536f7=[],_0x4eed5a=-0x1;for(let _0x821472=0x0;_0x821472<_0x5f4dee['length'];_0x821472++)_0x5f4dee[_0x821472]['status']===0x3||(_0x5f4dee[_0x821472]['status']===0x1?(f(_0x4eed5a===_0x821472-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x4eed5a=_0x821472,_0x5f4dee[_0x821472]['status']=0x3,_0x5f4dee[_0x821472]['abortReason']='set'):(f(_0x5f4dee[_0x821472]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x5f4dee[_0x821472]['unwatcher'](),_0x4536f7=_0x4536f7['concat'](_e(_0xdb9939['serverSyncTree_'],_0x5f4dee[_0x821472]['currentWriteId'],!0x0)),_0x5f4dee[_0x821472]['onComplete']&&_0x539f68['push'](_0x5f4dee[_0x821472]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x4eed5a===-0x1?gs(_0xdd70f6,void 0x0):_0x5f4dee['length']=_0x4eed5a+0x1,V(_0xdb9939['eventQueue_'],Qt(_0xdd70f6),_0x4536f7);for(let _0x1cbd11=0x0;_0x1cbd11<_0x539f68['length'];_0x1cbd11++)ft(_0x539f68[_0x1cbd11]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x2f35f7){let _0x1dec1='';const _0x492a96=_0x2f35f7['split']('/');for(let _0x93c17e=0x0;_0x93c17e<_0x492a96['length'];_0x93c17e++)if(_0x492a96[_0x93c17e]['length']>0x0){let _0x2c245e=_0x492a96[_0x93c17e];try{_0x2c245e=decodeURIComponent(_0x2c245e['replace'](/\+/g,'\x20'));}catch{}_0x1dec1+='/'+_0x2c245e;}return _0x1dec1;}function xd(_0x74096a){const _0x411f99={};_0x74096a['charAt'](0x0)==='?'&&(_0x74096a=_0x74096a['substring'](0x1));for(const _0x5d6010 of _0x74096a['split']('&')){if(_0x5d6010['length']===0x0)continue;const _0x554bd4=_0x5d6010['split']('=');_0x554bd4['length']===0x2?_0x411f99[decodeURIComponent(_0x554bd4[0x0])]=decodeURIComponent(_0x554bd4[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x5d6010+'\x27\x20in\x20query\x20\x27'+_0x74096a+'\x27');}return _0x411f99;}const vr=function(_0x2faf74,_0x19a3a2){const _0x206e9a=Fd(_0x2faf74),_0x3429ae=_0x206e9a['namespace'];_0x206e9a['domain']==='firebase.com'&&ae(_0x206e9a['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x3429ae||_0x3429ae==='undefined')&&_0x206e9a['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x206e9a['secure']||$l();const _0x1293f0=_0x206e9a['scheme']==='ws'||_0x206e9a['scheme']==='wss';return{'repoInfo':new yo(_0x206e9a['host'],_0x206e9a['secure'],_0x3429ae,_0x1293f0,_0x19a3a2,'',_0x3429ae!==_0x206e9a['subdomain']),'path':new C(_0x206e9a['pathString'])};},Fd=function(_0x3cc52c){let _0xd9eb14='',_0x1ede0a='',_0x5813a2='',_0x3b7037='',_0x2d2d82='',_0xb1a8f4=!0x0,_0x2a85a5='https',_0x907f09=0x1bb;if(typeof _0x3cc52c=='string'){let _0x1b72c9=_0x3cc52c['indexOf']('//');_0x1b72c9>=0x0&&(_0x2a85a5=_0x3cc52c['substring'](0x0,_0x1b72c9-0x1),_0x3cc52c=_0x3cc52c['substring'](_0x1b72c9+0x2));let _0x349f3e=_0x3cc52c['indexOf']('/');_0x349f3e===-0x1&&(_0x349f3e=_0x3cc52c['length']);let _0x765035=_0x3cc52c['indexOf']('?');_0x765035===-0x1&&(_0x765035=_0x3cc52c['length']),_0xd9eb14=_0x3cc52c['substring'](0x0,Math['min'](_0x349f3e,_0x765035)),_0x349f3e<_0x765035&&(_0x3b7037=Ld(_0x3cc52c['substring'](_0x349f3e,_0x765035)));const _0x580fbd=xd(_0x3cc52c['substring'](Math['min'](_0x3cc52c['length'],_0x765035)));_0x1b72c9=_0xd9eb14['indexOf'](':'),_0x1b72c9>=0x0?(_0xb1a8f4=_0x2a85a5==='https'||_0x2a85a5==='wss',_0x907f09=parseInt(_0xd9eb14['substring'](_0x1b72c9+0x1),0xa)):_0x1b72c9=_0xd9eb14['length'];const _0x4d9459=_0xd9eb14['slice'](0x0,_0x1b72c9);if(_0x4d9459['toLowerCase']()==='localhost')_0x1ede0a='localhost';else{if(_0x4d9459['split']('.')['length']<=0x2)_0x1ede0a=_0x4d9459;else{const _0xee6a62=_0xd9eb14['indexOf']('.');_0x5813a2=_0xd9eb14['substring'](0x0,_0xee6a62)['toLowerCase'](),_0x1ede0a=_0xd9eb14['substring'](_0xee6a62+0x1),_0x2d2d82=_0x5813a2;}}'ns'in _0x580fbd&&(_0x2d2d82=_0x580fbd['ns']);}return{'host':_0xd9eb14,'port':_0x907f09,'domain':_0x1ede0a,'subdomain':_0x5813a2,'secure':_0xb1a8f4,'scheme':_0x2a85a5,'pathString':_0x3b7037,'namespace':_0x2d2d82};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x1f3a25=0x0;const _0x49bf0f=[];return function(_0x3a76b3){const _0x1d06b1=_0x3a76b3===_0x1f3a25;_0x1f3a25=_0x3a76b3;let _0x5084b7;const _0x2d306=new Array(0x8);for(_0x5084b7=0x7;_0x5084b7>=0x0;_0x5084b7--)_0x2d306[_0x5084b7]=Er['charAt'](_0x3a76b3%0x40),_0x3a76b3=Math['floor'](_0x3a76b3/0x40);f(_0x3a76b3===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x20234f=_0x2d306['join']('');if(_0x1d06b1){for(_0x5084b7=0xb;_0x5084b7>=0x0&&_0x49bf0f[_0x5084b7]===0x3f;_0x5084b7--)_0x49bf0f[_0x5084b7]=0x0;_0x49bf0f[_0x5084b7]++;}else{for(_0x5084b7=0x0;_0x5084b7<0xc;_0x5084b7++)_0x49bf0f[_0x5084b7]=Math['floor'](Math['random']()*0x40);}for(_0x5084b7=0x0;_0x5084b7<0xc;_0x5084b7++)_0x20234f+=Er['charAt'](_0x49bf0f[_0x5084b7]);return f(_0x20234f['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x20234f;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x58ef40,_0x7e592e,_0x2811a8,_0x503fca){this['eventType']=_0x58ef40,this['eventRegistration']=_0x7e592e,this['snapshot']=_0x2811a8,this['prevName']=_0x503fca;}['getPath'](){const _0x39ef92=this['snapshot']['ref'];return this['eventType']==='value'?_0x39ef92['_path']:_0x39ef92['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x211354,_0x10858e,_0x13d3eb){this['eventRegistration']=_0x211354,this['error']=_0x10858e,this['path']=_0x13d3eb;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x381ce7,_0x417262){this['snapshotCallback']=_0x381ce7,this['cancelCallback']=_0x417262;}['onValue'](_0x2e43a2,_0x1de977){this['snapshotCallback']['call'](null,_0x2e43a2,_0x1de977);}['onCancel'](_0x3fdc3a){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x3fdc3a);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x4b8ffa){return this['snapshotCallback']===_0x4b8ffa['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x4b8ffa['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x4b8ffa['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x7ca410,_0x24b450){this['_repo']=_0x7ca410,this['_path']=_0x24b450;}['cancel'](){const _0x30bad9=new H();return bd(this['_repo'],this['_path'],_0x30bad9['wrapCallback'](()=>{})),_0x30bad9['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x2d14cb=new H();return yr(this['_repo'],this['_path'],null,_0x2d14cb['wrapCallback'](()=>{})),_0x2d14cb['promise'];}['set'](_0x569d03){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x569d03,this['_path'],!0x1);const _0x3481ff=new H();return yr(this['_repo'],this['_path'],_0x569d03,_0x3481ff['wrapCallback'](()=>{})),_0x3481ff['promise'];}['setWithPriority'](_0x9733f9,_0x5260b6){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x9733f9,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x5260b6);const _0x1e1a5b=new H();return Rd(this['_repo'],this['_path'],_0x9733f9,_0x5260b6,_0x1e1a5b['wrapCallback'](()=>{})),_0x1e1a5b['promise'];}['update'](_0x14ac6c){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x14ac6c,this['_path']);const _0x2f793a=new H();return Ad(this['_repo'],this['_path'],_0x14ac6c,_0x2f793a['wrapCallback'](()=>{})),_0x2f793a['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x47a6d2,_0x4407a4,_0x3c496a,_0x3660d0){this['_repo']=_0x47a6d2,this['_path']=_0x4407a4,this['_queryParams']=_0x3c496a,this['_orderByCalled']=_0x3660d0;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x5137d1=sr(this['_queryParams']),_0x224365=$i(_0x5137d1);return _0x224365==='{}'?'default':_0x224365;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x15728a){if(_0x15728a=P(_0x15728a),!(_0x15728a instanceof Ae))return!0x1;const _0x53021e=this['_repo']===_0x15728a['_repo'],_0xccab19=Ki(this['_path'],_0x15728a['_path']),_0x35adc6=this['_queryIdentifier']===_0x15728a['_queryIdentifier'];return _0x53021e&&_0xccab19&&_0x35adc6;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x33f152,_0x1f686d){if(_0x33f152['_orderByCalled']===!0x0)throw new Error(_0x1f686d+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x33d5ed){let _0x35648f=null,_0x37c550=null;if(_0x33d5ed['hasStart']()&&(_0x35648f=_0x33d5ed['getIndexStartValue']()),_0x33d5ed['hasEnd']()&&(_0x37c550=_0x33d5ed['getIndexEndValue']()),_0x33d5ed['getIndex']()===ve){const _0x50472f='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x4cb9ac='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x33d5ed['hasStart']()){if(_0x33d5ed['getIndexStartName']()!==We)throw new Error(_0x50472f);if(typeof _0x35648f!='string')throw new Error(_0x4cb9ac);}if(_0x33d5ed['hasEnd']()){if(_0x33d5ed['getIndexEndName']()!==we)throw new Error(_0x50472f);if(typeof _0x37c550!='string')throw new Error(_0x4cb9ac);}}else{if(_0x33d5ed['getIndex']()===R){if(_0x35648f!=null&&!Bt(_0x35648f)||_0x37c550!=null&&!Bt(_0x37c550))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x33d5ed['getIndex']()instanceof Ji||_0x33d5ed['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x35648f!=null&&typeof _0x35648f=='object'||_0x37c550!=null&&typeof _0x37c550=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x189c0c){if(_0x189c0c['hasStart']()&&_0x189c0c['hasEnd']()&&_0x189c0c['hasLimit']()&&!_0x189c0c['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x558fb8,_0x407f89){super(_0x558fb8,_0x407f89,new Zi(),!0x1);}get['parent'](){const _0x3752f4=Ro(this['_path']);return _0x3752f4===null?null:new ee(this['_repo'],_0x3752f4);}get['root'](){let _0x4715aa=this;for(;_0x4715aa['parent']!==null;)_0x4715aa=_0x4715aa['parent'];return _0x4715aa;}}class lt{constructor(_0xd7c9a1,_0x24b0b6,_0x59e9c3){this['_node']=_0xd7c9a1,this['ref']=_0x24b0b6,this['_index']=_0x59e9c3;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x5ea734){const _0x13ac1f=new C(_0x5ea734),_0x242c3e=Vt(this['ref'],_0x5ea734);return new lt(this['_node']['getChild'](_0x13ac1f),_0x242c3e,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x6fd402){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x26f479,_0x4ddd69)=>_0x6fd402(new lt(_0x4ddd69,Vt(this['ref'],_0x26f479),R)));}['hasChild'](_0x57247e){const _0x331b70=new C(_0x57247e);return!this['_node']['getChild'](_0x331b70)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x4d5e74,_0x4dc982){return _0x4d5e74=P(_0x4d5e74),_0x4d5e74['_checkNotDeleted']('ref'),_0x4dc982!==void 0x0?Vt(_0x4d5e74['_root'],_0x4dc982):_0x4d5e74['_root'];}function Vt(_0x55a1c4,_0x5c9389){return _0x55a1c4=P(_0x55a1c4),y(_0x55a1c4['_path'])===null?pd('child','path',_0x5c9389):ys('child','path',_0x5c9389),new ee(_0x55a1c4['_repo'],k(_0x55a1c4['_path'],_0x5c9389));}function v_(_0xd70195){return _0xd70195=P(_0xd70195),new Vd(_0xd70195['_repo'],_0xd70195['_path']);}function E_(_0x370a3b,_0x14e876){_0x370a3b=P(_0x370a3b),Me('push',_0x370a3b['_path']),He('push',_0x14e876,_0x370a3b['_path'],!0x0);const _0xb86edb=la(_0x370a3b['_repo']),_0x2161cf=Ud(_0xb86edb),_0x203374=Vt(_0x370a3b,_0x2161cf),_0x388073=Vt(_0x370a3b,_0x2161cf);let _0x3317e7;return _0x14e876!=null?_0x3317e7=Hd(_0x388073,_0x14e876)['then'](()=>_0x388073):_0x3317e7=Promise['resolve'](_0x388073),_0x203374['then']=_0x3317e7['then']['bind'](_0x3317e7),_0x203374['catch']=_0x3317e7['then']['bind'](_0x3317e7,void 0x0),_0x203374;}function Hd(_0x286542,_0x286d9c){_0x286542=P(_0x286542),Me('set',_0x286542['_path']),He('set',_0x286d9c,_0x286542['_path'],!0x1);const _0x47fdac=new H();return Cd(_0x286542['_repo'],_0x286542['_path'],_0x286d9c,null,_0x47fdac['wrapCallback'](()=>{})),_0x47fdac['promise'];}function I_(_0x463991,_0x238909){ra('update',_0x238909,_0x463991['_path']);const _0x3afcf6=new H();return Td(_0x463991['_repo'],_0x463991['_path'],_0x238909,_0x3afcf6['wrapCallback'](()=>{})),_0x3afcf6['promise'];}function w_(_0x5589da){_0x5589da=P(_0x5589da);const _0x2010a0=new pa(()=>{}),_0xba82a3=new Qn(_0x2010a0);return wd(_0x5589da['_repo'],_0x5589da,_0xba82a3)['then'](_0x575353=>new lt(_0x575353,new ee(_0x5589da['_repo'],_0x5589da['_path']),_0x5589da['_queryParams']['getIndex']()));}class Qn{constructor(_0x48a5bf){this['callbackContext']=_0x48a5bf;}['respondsTo'](_0x1d39e3){return _0x1d39e3==='value';}['createEvent'](_0x2cb3f5,_0x383158){const _0x32cf66=_0x383158['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x2cb3f5['snapshotNode'],new ee(_0x383158['_repo'],_0x383158['_path']),_0x32cf66));}['getEventRunner'](_0x1219ae){return _0x1219ae['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x1219ae['error']):()=>this['callbackContext']['onValue'](_0x1219ae['snapshot'],null);}['createCancelEvent'](_0xaba18f,_0x4c9dba){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0xaba18f,_0x4c9dba):null;}['matches'](_0xc248df){return _0xc248df instanceof Qn?!_0xc248df['callbackContext']||!this['callbackContext']?!0x0:_0xc248df['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x2d48c9,_0x5a164e,_0x5c6148,_0x5034dd,_0x52fb4f){const _0x5be2f6=new pa(_0x5c6148,void 0x0),_0x13f445=new Qn(_0x5be2f6);return kd(_0x2d48c9['_repo'],_0x2d48c9,_0x13f445),()=>Pd(_0x2d48c9['_repo'],_0x2d48c9,_0x13f445);}function Gd(_0x2355d9,_0x48e03d,_0x2736d4,_0x3a40ff){return $d(_0x2355d9,'value',_0x48e03d);}class mt{}class ma extends mt{constructor(_0x31bf1b,_0x2aa1b1){super(),this['_value']=_0x31bf1b,this['_key']=_0x2aa1b1,this['type']='endAt';}['_apply'](_0x5aedea){He('endAt',this['_value'],_0x5aedea['_path'],!0x0);const _0xf03913=Jh(_0x5aedea['_queryParams'],this['_value'],this['_key']);if(ga(_0xf03913),Yn(_0xf03913),_0x5aedea['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x5aedea['_repo'],_0x5aedea['_path'],_0xf03913,_0x5aedea['_orderByCalled']);}}function C_(_0x2e9e4f,_0x361beb){return new ma(_0x2e9e4f,_0x361beb);}class ya extends mt{constructor(_0x29725a,_0x2d26c6){super(),this['_value']=_0x29725a,this['_key']=_0x2d26c6,this['type']='startAt';}['_apply'](_0x1c39a2){He('startAt',this['_value'],_0x1c39a2['_path'],!0x0);const _0x548054=Qh(_0x1c39a2['_queryParams'],this['_value'],this['_key']);if(ga(_0x548054),Yn(_0x548054),_0x1c39a2['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x1c39a2['_repo'],_0x1c39a2['_path'],_0x548054,_0x1c39a2['_orderByCalled']);}}function T_(_0x3da3fa=null,_0x50579c){return new ya(_0x3da3fa,_0x50579c);}class qd extends mt{constructor(_0x7169ac){super(),this['_limit']=_0x7169ac,this['type']='limitToFirst';}['_apply'](_0x2ecf72){if(_0x2ecf72['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x2ecf72['_repo'],_0x2ecf72['_path'],Yh(_0x2ecf72['_queryParams'],this['_limit']),_0x2ecf72['_orderByCalled']);}}function S_(_0x55e59e){if(Math['floor'](_0x55e59e)!==_0x55e59e||_0x55e59e<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x55e59e);}class zd extends mt{constructor(_0x54f812){super(),this['_path']=_0x54f812,this['type']='orderByChild';}['_apply'](_0x5c3b49){_a(_0x5c3b49,'orderByChild');const _0x4b076d=new C(this['_path']);if(v(_0x4b076d))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x4c3cdd=new Ji(_0x4b076d),_0x5e70ef=xo(_0x5c3b49['_queryParams'],_0x4c3cdd);return Yn(_0x5e70ef),new Ae(_0x5c3b49['_repo'],_0x5c3b49['_path'],_0x5e70ef,!0x0);}}function b_(_0x3fa453){if(_0x3fa453==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x3fa453==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x3fa453==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x3fa453),new zd(_0x3fa453);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x16cc12){_a(_0x16cc12,'orderByKey');const _0x3c9aa9=xo(_0x16cc12['_queryParams'],ve);return Yn(_0x3c9aa9),new Ae(_0x16cc12['_repo'],_0x16cc12['_path'],_0x3c9aa9,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x4e6a46,_0x4e9e52){super(),this['_value']=_0x4e6a46,this['_key']=_0x4e9e52,this['type']='equalTo';}['_apply'](_0x572d46){if(He('equalTo',this['_value'],_0x572d46['_path'],!0x1),_0x572d46['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x572d46['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x572d46));}}function A_(_0x2bcbda,_0x1e2ce4){return new Kd(_0x2bcbda,_0x1e2ce4);}function k_(_0x3ec7c5,..._0x49f399){let _0x10e281=P(_0x3ec7c5);for(const _0x27335a of _0x49f399)_0x10e281=_0x27335a['_apply'](_0x10e281);return _0x10e281;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x13f51e,_0x4499f1,_0x4574e1,_0x4eff80){const _0x27b3f8=_0x4499f1['lastIndexOf'](':'),_0x1a6c32=_0x4499f1['substring'](0x0,_0x27b3f8),_0x2d2e3f=qt(_0x1a6c32);_0x13f51e['repoInfo_']=new yo(_0x4499f1,_0x2d2e3f,_0x13f51e['repoInfo_']['namespace'],_0x13f51e['repoInfo_']['webSocketOnly'],_0x13f51e['repoInfo_']['nodeAdmin'],_0x13f51e['repoInfo_']['persistenceKey'],_0x13f51e['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x4574e1),_0x4eff80&&(_0x13f51e['authTokenProvider_']=_0x4eff80);}function Xd(_0x4d7496,_0x55ce9e,_0x1dbf0d,_0x278565,_0x26acea){let _0x172dc5=_0x278565||_0x4d7496['options']['databaseURL'];_0x172dc5===void 0x0&&(_0x4d7496['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x4d7496['options']['projectId']),_0x172dc5=_0x4d7496['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x2d9918=vr(_0x172dc5,_0x26acea),_0x40e19e=_0x2d9918['repoInfo'],_0x311be3;typeof process<'u'&&Bs&&(_0x311be3=Bs[Yd]),_0x311be3?(_0x172dc5='http://'+_0x311be3+'?ns='+_0x40e19e['namespace'],_0x2d9918=vr(_0x172dc5,_0x26acea),_0x40e19e=_0x2d9918['repoInfo']):_0x2d9918['repoInfo']['secure'];const _0x1c156e=new eh(_0x4d7496['name'],_0x4d7496['options'],_0x55ce9e);_d('Invalid\x20Firebase\x20Database\x20URL',_0x2d9918),v(_0x2d9918['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x35cfd0=ef(_0x40e19e,_0x4d7496,_0x1c156e,new Zl(_0x4d7496,_0x1dbf0d));return new tf(_0x35cfd0,_0x4d7496);}function Zd(_0x7922,_0x40d814){const _0x4df4db=Di[_0x40d814];(!_0x4df4db||_0x4df4db[_0x7922['key']]!==_0x7922)&&ae('Database\x20'+_0x40d814+'('+_0x7922['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x7922),delete _0x4df4db[_0x7922['key']];}function ef(_0x254cd7,_0x5d22c9,_0x3ea267,_0xfddaef){let _0x21afc2=Di[_0x5d22c9['name']];_0x21afc2||(_0x21afc2={},Di[_0x5d22c9['name']]=_0x21afc2);let _0x40503b=_0x21afc2[_0x254cd7['toURLString']()];return _0x40503b&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x40503b=new vd(_0x254cd7,Qd,_0x3ea267,_0xfddaef),_0x21afc2[_0x254cd7['toURLString']()]=_0x40503b,_0x40503b;}class tf{constructor(_0x4a1c95,_0x23488c){this['_repoInternal']=_0x4a1c95,this['app']=_0x23488c,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0xf7dc3d){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0xf7dc3d+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x11a989=Zr(),_0x15b9a3){const _0x288415=Hi(_0x11a989,'database')['getImmediate']({'identifier':_0x15b9a3});if(!_0x288415['_instanceStarted']){const _0x9c403=hc('database');_0x9c403&&nf(_0x288415,..._0x9c403);}return _0x288415;}function nf(_0x2a15ef,_0x432a94,_0x4d952c,_0x40493f={}){_0x2a15ef=P(_0x2a15ef),_0x2a15ef['_checkNotDeleted']('useEmulator');const _0x5749ef=_0x432a94+':'+_0x4d952c,_0x3bf3c9=_0x2a15ef['_repoInternal'];if(_0x2a15ef['_instanceStarted']){if(_0x5749ef===_0x2a15ef['_repoInternal']['repoInfo_']['host']&&xe(_0x40493f,_0x3bf3c9['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x1b09d4;if(_0x3bf3c9['repoInfo_']['nodeAdmin'])_0x40493f['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x1b09d4=new an(an['OWNER']);else{if(_0x40493f['mockUserToken']){const _0x37d3ba=typeof _0x40493f['mockUserToken']=='string'?_0x40493f['mockUserToken']:uc(_0x40493f['mockUserToken'],_0x2a15ef['app']['options']['projectId']);_0x1b09d4=new an(_0x37d3ba);}}qt(_0x432a94)&&Qr(_0x432a94),Jd(_0x3bf3c9,_0x5749ef,_0x40493f,_0x1b09d4);}function N_(_0x2ca11d){_0x2ca11d=P(_0x2ca11d),_0x2ca11d['_checkNotDeleted']('goOffline'),ha(_0x2ca11d['_repo']);}function O_(_0x212517){_0x212517=P(_0x212517),_0x212517['_checkNotDeleted']('goOnline'),Nd(_0x212517['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x424dee){Ul(dt),st(new Fe('database',(_0x14208e,{instanceIdentifier:_0x405c96})=>{const _0x411b9d=_0x14208e['getProvider']('app')['getImmediate'](),_0x5eddff=_0x14208e['getProvider']('auth-internal'),_0x3e0be0=_0x14208e['getProvider']('app-check-internal');return Xd(_0x411b9d,_0x5eddff,_0x3e0be0,_0x405c96);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x424dee),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x5f4050,_0x49ee5c){this['committed']=_0x5f4050,this['snapshot']=_0x49ee5c;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x513992,_0x5823a6,_0x40c5ca){if(_0x513992=P(_0x513992),Me('Reference.transaction',_0x513992['_path']),_0x513992['key']==='.length'||_0x513992['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x513992['key']+'\x20is\x20a\x20read-only\x20object.';const _0x3a9418=!0x0,_0x5c7b67=new H(),_0x2ba0d4=(_0xe0e6da,_0x18f677,_0x43fbeb)=>{let _0x462370=null;_0xe0e6da?_0x5c7b67['reject'](_0xe0e6da):(_0x462370=new lt(_0x43fbeb,new ee(_0x513992['_repo'],_0x513992['_path']),R),_0x5c7b67['resolve'](new of(_0x18f677,_0x462370)));},_0xcdb124=Gd(_0x513992,()=>{});return Od(_0x513992['_repo'],_0x513992['_path'],_0x5823a6,_0x2ba0d4,_0xcdb124,_0x3a9418),_0x5c7b67['promise'];}se['prototype']['simpleListen']=function(_0xf787a7,_0x4f5f45){this['sendRequest']('q',{'p':_0xf787a7},_0x4f5f45);},se['prototype']['echo']=function(_0x1ed6df,_0x31bf3b){this['sendRequest']('echo',{'d':_0x1ed6df},_0x31bf3b);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x477d16,..._0x4d8e0d){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x477d16,..._0x4d8e0d);}function cn(_0x57ab55,..._0x52cb7f){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x57ab55,..._0x52cb7f);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x49f068,..._0x339b99){throw ws(_0x49f068,..._0x339b99);}function X(_0x4d0eba,..._0x24fb59){return ws(_0x4d0eba,..._0x24fb59);}function Ia(_0x11d557,_0x13d3af,_0x4188b5){const _0xd40829={...af(),[_0x13d3af]:_0x4188b5};return new Gt('auth','Firebase',_0xd40829)['create'](_0x13d3af,{'appName':_0x11d557['name']});}function re(_0x209e73){return Ia(_0x209e73,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x21d747,..._0x1cea5c){if(typeof _0x21d747!='string'){const _0x47595e=_0x1cea5c[0x0],_0x5e5ba8=[..._0x1cea5c['slice'](0x1)];return _0x5e5ba8[0x0]&&(_0x5e5ba8[0x0]['appName']=_0x21d747['name']),_0x21d747['_errorFactory']['create'](_0x47595e,..._0x5e5ba8);}return Ea['create'](_0x21d747,..._0x1cea5c);}function m(_0x36ff2e,_0x2a267d,..._0x3244e9){if(!_0x36ff2e)throw ws(_0x2a267d,..._0x3244e9);}function ne(_0xcf34dc){const _0x2b8c64='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0xcf34dc;throw cn(_0x2b8c64),new Error(_0x2b8c64);}function ce(_0x48d859,_0x215aa6){_0x48d859||ne(_0x215aa6);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x2625d9;return typeof self<'u'&&((_0x2625d9=self['location'])==null?void 0x0:_0x2625d9['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x2b00ab;return typeof self<'u'&&((_0x2b00ab=self['location'])==null?void 0x0:_0x2b00ab['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x386425=navigator;return _0x386425['languages']&&_0x386425['languages'][0x0]||_0x386425['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x2335ae,_0x1d9dca){this['shortDelay']=_0x2335ae,this['longDelay']=_0x1d9dca,ce(_0x1d9dca>_0x2335ae,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x526506,_0x9c9278){ce(_0x526506['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x39d8a4}=_0x526506['emulator'];return _0x9c9278?''+_0x39d8a4+(_0x9c9278['startsWith']('/')?_0x9c9278['slice'](0x1):_0x9c9278):_0x39d8a4;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x2395d5,_0x4b5a79,_0x4b974d){this['fetchImpl']=_0x2395d5,_0x4b5a79&&(this['headersImpl']=_0x4b5a79),_0x4b974d&&(this['responseImpl']=_0x4b974d);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x211d55,_0x2767b8){return _0x211d55['tenantId']&&!_0x2767b8['tenantId']?{..._0x2767b8,'tenantId':_0x211d55['tenantId']}:_0x2767b8;}async function Pe(_0x325b07,_0x3db782,_0x2a51bd,_0x427f1e,_0x4b85b9={}){return Ca(_0x325b07,_0x4b85b9,async()=>{let _0x19bef9={},_0xd529db={};_0x427f1e&&(_0x3db782==='GET'?_0xd529db=_0x427f1e:_0x19bef9={'body':JSON['stringify'](_0x427f1e)});const _0x35abc2=ut({..._0xd529db,'key':_0x325b07['config']['apiKey']})['slice'](0x1),_0x25fca4=await _0x325b07['_getAdditionalHeaders']();_0x25fca4['Content-Type']='application/json',_0x325b07['languageCode']&&(_0x25fca4['X-Firebase-Locale']=_0x325b07['languageCode']);const _0x5dfb71={'method':_0x3db782,'headers':_0x25fca4,..._0x19bef9};return dc()||(_0x5dfb71['referrerPolicy']='strict-origin-when-cross-origin'),_0x325b07['emulatorConfig']&&qt(_0x325b07['emulatorConfig']['host'])&&(_0x5dfb71['credentials']='include'),wa['fetch']()(await Ta(_0x325b07,_0x325b07['config']['apiHost'],_0x2a51bd,_0x35abc2),_0x5dfb71);});}async function Ca(_0x559505,_0x306f9e,_0x1b2c59){_0x559505['_canInitEmulator']=!0x1;const _0x466cc1={...df,..._0x306f9e};try{const _0x43fff9=new gf(_0x559505),_0x2f8b18=await Promise['race']([_0x1b2c59(),_0x43fff9['promise']]);_0x43fff9['clearNetworkTimeout']();const _0x1cdf52=await _0x2f8b18['json']();if('needConfirmation'in _0x1cdf52)throw on(_0x559505,'account-exists-with-different-credential',_0x1cdf52);if(_0x2f8b18['ok']&&!('errorMessage'in _0x1cdf52))return _0x1cdf52;{const _0x146e0d=_0x2f8b18['ok']?_0x1cdf52['errorMessage']:_0x1cdf52['error']['message'],[_0x27466f,_0x5c5ceb]=_0x146e0d['split']('\x20:\x20');if(_0x27466f==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x559505,'credential-already-in-use',_0x1cdf52);if(_0x27466f==='EMAIL_EXISTS')throw on(_0x559505,'email-already-in-use',_0x1cdf52);if(_0x27466f==='USER_DISABLED')throw on(_0x559505,'user-disabled',_0x1cdf52);const _0x1b7c63=_0x466cc1[_0x27466f]||_0x27466f['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x5c5ceb)throw Ia(_0x559505,_0x1b7c63,_0x5c5ceb);Y(_0x559505,_0x1b7c63);}}catch(_0x5d10f4){if(_0x5d10f4 instanceof Re)throw _0x5d10f4;Y(_0x559505,'network-request-failed',{'message':String(_0x5d10f4)});}}async function en(_0x53d726,_0x3e8608,_0x1633bc,_0x63358,_0x1843f4={}){const _0x19037b=await Pe(_0x53d726,_0x3e8608,_0x1633bc,_0x63358,_0x1843f4);return'mfaPendingCredential'in _0x19037b&&Y(_0x53d726,'multi-factor-auth-required',{'_serverResponse':_0x19037b}),_0x19037b;}async function Ta(_0x8000dc,_0x4e3247,_0x539476,_0x3b8f16){const _0x1c94f7=''+_0x4e3247+_0x539476+'?'+_0x3b8f16,_0x262069=_0x8000dc,_0x2aab64=_0x262069['config']['emulator']?Cs(_0x8000dc['config'],_0x1c94f7):_0x8000dc['config']['apiScheme']+'://'+_0x1c94f7;return ff['includes'](_0x539476)&&(await _0x262069['_persistenceManagerAvailable'],_0x262069['_getPersistenceType']()==='COOKIE')?_0x262069['_getPersistence']()['_getFinalTarget'](_0x2aab64)['toString']():_0x2aab64;}function _f(_0x3d3051){switch(_0x3d3051){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x67981){this['auth']=_0x67981,this['timer']=null,this['promise']=new Promise((_0x1f7939,_0x1bcd38)=>{this['timer']=setTimeout(()=>_0x1bcd38(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x10c9e,_0x50fb85,_0xed4c50){const _0x4a85e7={'appName':_0x10c9e['name']};_0xed4c50['email']&&(_0x4a85e7['email']=_0xed4c50['email']),_0xed4c50['phoneNumber']&&(_0x4a85e7['phoneNumber']=_0xed4c50['phoneNumber']);const _0x37724b=X(_0x10c9e,_0x50fb85,_0x4a85e7);return _0x37724b['customData']['_tokenResponse']=_0xed4c50,_0x37724b;}function wr(_0x595dee){return _0x595dee!==void 0x0&&_0x595dee['enterprise']!==void 0x0;}class mf{constructor(_0x3fd69d){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x3fd69d['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x3fd69d['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x3fd69d['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x53a1c3){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0xf48aea of this['recaptchaEnforcementState'])if(_0xf48aea['provider']&&_0xf48aea['provider']===_0x53a1c3)return _f(_0xf48aea['enforcementState']);return null;}['isProviderEnabled'](_0x35ee5b){return this['getProviderEnforcementState'](_0x35ee5b)==='ENFORCE'||this['getProviderEnforcementState'](_0x35ee5b)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x161d89,_0x51bca4){return Pe(_0x161d89,'GET','/v2/recaptchaConfig',ke(_0x161d89,_0x51bca4));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x37557e,_0x46e067){return Pe(_0x37557e,'POST','/v1/accounts:delete',_0x46e067);}async function Pn(_0x13f83e,_0x113256){return Pe(_0x13f83e,'POST','/v1/accounts:lookup',_0x113256);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x4de734){if(_0x4de734)try{const _0x424227=new Date(Number(_0x4de734));if(!isNaN(_0x424227['getTime']()))return _0x424227['toUTCString']();}catch{}}async function Ef(_0x3d06d9,_0x1fbe7a=!0x1){const _0x5059b4=P(_0x3d06d9),_0xf4f898=await _0x5059b4['getIdToken'](_0x1fbe7a),_0xaab3f1=Ts(_0xf4f898);m(_0xaab3f1&&_0xaab3f1['exp']&&_0xaab3f1['auth_time']&&_0xaab3f1['iat'],_0x5059b4['auth'],'internal-error');const _0x199a1c=typeof _0xaab3f1['firebase']=='object'?_0xaab3f1['firebase']:void 0x0,_0x1a2bce=_0x199a1c==null?void 0x0:_0x199a1c['sign_in_provider'];return{'claims':_0xaab3f1,'token':_0xf4f898,'authTime':Pt(fi(_0xaab3f1['auth_time'])),'issuedAtTime':Pt(fi(_0xaab3f1['iat'])),'expirationTime':Pt(fi(_0xaab3f1['exp'])),'signInProvider':_0x1a2bce||null,'signInSecondFactor':(_0x199a1c==null?void 0x0:_0x199a1c['sign_in_second_factor'])||null};}function fi(_0x258b0b){return Number(_0x258b0b)*0x3e8;}function Ts(_0x3f61e1){const [_0x54e890,_0x4d4508,_0x447993]=_0x3f61e1['split']('.');if(_0x54e890===void 0x0||_0x4d4508===void 0x0||_0x447993===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x939c2d=fn(_0x4d4508);return _0x939c2d?JSON['parse'](_0x939c2d):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x3f7140){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x3f7140==null?void 0x0:_0x3f7140['toString']()),null;}}function Cr(_0x51c573){const _0x3637a6=Ts(_0x51c573);return m(_0x3637a6,'internal-error'),m(typeof _0x3637a6['exp']<'u','internal-error'),m(typeof _0x3637a6['iat']<'u','internal-error'),Number(_0x3637a6['exp'])-Number(_0x3637a6['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x2a4053,_0x33d665,_0x41205f=!0x1){if(_0x41205f)return _0x33d665;try{return await _0x33d665;}catch(_0x2e671c){throw _0x2e671c instanceof Re&&If(_0x2e671c)&&_0x2a4053['auth']['currentUser']===_0x2a4053&&await _0x2a4053['auth']['signOut'](),_0x2e671c;}}function If({code:_0x265ec0}){return _0x265ec0==='auth/user-disabled'||_0x265ec0==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x17951c){this['user']=_0x17951c,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0xff23b2){if(_0xff23b2){const _0x44b613=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x44b613;}else{this['errorBackoff']=0x7530;const _0x312c27=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x312c27);}}['schedule'](_0x4798f0=!0x1){if(!this['isRunning'])return;const _0x52707f=this['getInterval'](_0x4798f0);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x52707f);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x57095e){(_0x57095e==null?void 0x0:_0x57095e['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x4b0f92,_0xb55d09){this['createdAt']=_0x4b0f92,this['lastLoginAt']=_0xb55d09,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x5ea5d7){this['createdAt']=_0x5ea5d7['createdAt'],this['lastLoginAt']=_0x5ea5d7['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x54690f){var _0x4c8313;const _0x2f84ef=_0x54690f['auth'],_0x4000df=await _0x54690f['getIdToken'](),_0x4862d1=await Ht(_0x54690f,Pn(_0x2f84ef,{'idToken':_0x4000df}));m(_0x4862d1==null?void 0x0:_0x4862d1['users']['length'],_0x2f84ef,'internal-error');const _0x265153=_0x4862d1['users'][0x0];_0x54690f['_notifyReloadListener'](_0x265153);const _0x56455e=(_0x4c8313=_0x265153['providerUserInfo'])!=null&&_0x4c8313['length']?Sa(_0x265153['providerUserInfo']):[],_0x507985=Tf(_0x54690f['providerData'],_0x56455e),_0x5d0f52=_0x54690f['isAnonymous'],_0x479e5c=!(_0x54690f['email']&&_0x265153['passwordHash'])&&!(_0x507985!=null&&_0x507985['length']),_0x1452a5=_0x5d0f52?_0x479e5c:!0x1,_0x1a1243={'uid':_0x265153['localId'],'displayName':_0x265153['displayName']||null,'photoURL':_0x265153['photoUrl']||null,'email':_0x265153['email']||null,'emailVerified':_0x265153['emailVerified']||!0x1,'phoneNumber':_0x265153['phoneNumber']||null,'tenantId':_0x265153['tenantId']||null,'providerData':_0x507985,'metadata':new Li(_0x265153['createdAt'],_0x265153['lastLoginAt']),'isAnonymous':_0x1452a5};Object['assign'](_0x54690f,_0x1a1243);}async function Cf(_0x5ce6e2){const _0x580118=P(_0x5ce6e2);await Nn(_0x580118),await _0x580118['auth']['_persistUserIfCurrent'](_0x580118),_0x580118['auth']['_notifyListenersIfCurrent'](_0x580118);}function Tf(_0x18685,_0x259f3e){return[..._0x18685['filter'](_0x2ac0ff=>!_0x259f3e['some'](_0x4efa48=>_0x4efa48['providerId']===_0x2ac0ff['providerId'])),..._0x259f3e];}function Sa(_0x396e33){return _0x396e33['map'](({providerId:_0x26bf87,..._0x577aac})=>({'providerId':_0x26bf87,'uid':_0x577aac['rawId']||'','displayName':_0x577aac['displayName']||null,'email':_0x577aac['email']||null,'phoneNumber':_0x577aac['phoneNumber']||null,'photoURL':_0x577aac['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x468672,_0x24d97f){const _0x49fd4f=await Ca(_0x468672,{},async()=>{const _0x475e2a=ut({'grant_type':'refresh_token','refresh_token':_0x24d97f})['slice'](0x1),{tokenApiHost:_0x2f1301,apiKey:_0x366064}=_0x468672['config'],_0x432c5f=await Ta(_0x468672,_0x2f1301,'/v1/token','key='+_0x366064),_0x435433=await _0x468672['_getAdditionalHeaders']();_0x435433['Content-Type']='application/x-www-form-urlencoded';const _0x214716={'method':'POST','headers':_0x435433,'body':_0x475e2a};return _0x468672['emulatorConfig']&&qt(_0x468672['emulatorConfig']['host'])&&(_0x214716['credentials']='include'),wa['fetch']()(_0x432c5f,_0x214716);});return{'accessToken':_0x49fd4f['access_token'],'expiresIn':_0x49fd4f['expires_in'],'refreshToken':_0x49fd4f['refresh_token']};}async function bf(_0x33b4cd,_0x50bc81){return Pe(_0x33b4cd,'POST','/v2/accounts:revokeToken',ke(_0x33b4cd,_0x50bc81));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0xda6482){m(_0xda6482['idToken'],'internal-error'),m(typeof _0xda6482['idToken']<'u','internal-error'),m(typeof _0xda6482['refreshToken']<'u','internal-error');const _0xa3aeea='expiresIn'in _0xda6482&&typeof _0xda6482['expiresIn']<'u'?Number(_0xda6482['expiresIn']):Cr(_0xda6482['idToken']);this['updateTokensAndExpiration'](_0xda6482['idToken'],_0xda6482['refreshToken'],_0xa3aeea);}['updateFromIdToken'](_0x3b91c4){m(_0x3b91c4['length']!==0x0,'internal-error');const _0x15127c=Cr(_0x3b91c4);this['updateTokensAndExpiration'](_0x3b91c4,null,_0x15127c);}async['getToken'](_0x5f39b5,_0x422e4f=!0x1){return!_0x422e4f&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x5f39b5,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x5f39b5,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x3e8cdc,_0x33a230){const {accessToken:_0x221e42,refreshToken:_0x52fbce,expiresIn:_0x2a8d94}=await Sf(_0x3e8cdc,_0x33a230);this['updateTokensAndExpiration'](_0x221e42,_0x52fbce,Number(_0x2a8d94));}['updateTokensAndExpiration'](_0x5e6512,_0x3a5ef6,_0x9f515f){this['refreshToken']=_0x3a5ef6||null,this['accessToken']=_0x5e6512||null,this['expirationTime']=Date['now']()+_0x9f515f*0x3e8;}static['fromJSON'](_0x34af39,_0x59c9fa){const {refreshToken:_0xab90f0,accessToken:_0x5be371,expirationTime:_0x4de3a8}=_0x59c9fa,_0x54aaf5=new et();return _0xab90f0&&(m(typeof _0xab90f0=='string','internal-error',{'appName':_0x34af39}),_0x54aaf5['refreshToken']=_0xab90f0),_0x5be371&&(m(typeof _0x5be371=='string','internal-error',{'appName':_0x34af39}),_0x54aaf5['accessToken']=_0x5be371),_0x4de3a8&&(m(typeof _0x4de3a8=='number','internal-error',{'appName':_0x34af39}),_0x54aaf5['expirationTime']=_0x4de3a8),_0x54aaf5;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x2b9412){this['accessToken']=_0x2b9412['accessToken'],this['refreshToken']=_0x2b9412['refreshToken'],this['expirationTime']=_0x2b9412['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x185ea4,_0x434c9a){m(typeof _0x185ea4=='string'||typeof _0x185ea4>'u','internal-error',{'appName':_0x434c9a});}class j{constructor({uid:_0xeb34dc,auth:_0x2719d2,stsTokenManager:_0x4e4eaa,..._0x2f905e}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0xeb34dc,this['auth']=_0x2719d2,this['stsTokenManager']=_0x4e4eaa,this['accessToken']=_0x4e4eaa['accessToken'],this['displayName']=_0x2f905e['displayName']||null,this['email']=_0x2f905e['email']||null,this['emailVerified']=_0x2f905e['emailVerified']||!0x1,this['phoneNumber']=_0x2f905e['phoneNumber']||null,this['photoURL']=_0x2f905e['photoURL']||null,this['isAnonymous']=_0x2f905e['isAnonymous']||!0x1,this['tenantId']=_0x2f905e['tenantId']||null,this['providerData']=_0x2f905e['providerData']?[..._0x2f905e['providerData']]:[],this['metadata']=new Li(_0x2f905e['createdAt']||void 0x0,_0x2f905e['lastLoginAt']||void 0x0);}async['getIdToken'](_0x200687){const _0x14e753=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x200687));return m(_0x14e753,this['auth'],'internal-error'),this['accessToken']!==_0x14e753&&(this['accessToken']=_0x14e753,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x14e753;}['getIdTokenResult'](_0x4f4fa3){return Ef(this,_0x4f4fa3);}['reload'](){return Cf(this);}['_assign'](_0x5146be){this!==_0x5146be&&(m(this['uid']===_0x5146be['uid'],this['auth'],'internal-error'),this['displayName']=_0x5146be['displayName'],this['photoURL']=_0x5146be['photoURL'],this['email']=_0x5146be['email'],this['emailVerified']=_0x5146be['emailVerified'],this['phoneNumber']=_0x5146be['phoneNumber'],this['isAnonymous']=_0x5146be['isAnonymous'],this['tenantId']=_0x5146be['tenantId'],this['providerData']=_0x5146be['providerData']['map'](_0x526edb=>({..._0x526edb})),this['metadata']['_copy'](_0x5146be['metadata']),this['stsTokenManager']['_assign'](_0x5146be['stsTokenManager']));}['_clone'](_0x2e67b8){const _0x37cc28=new j({...this,'auth':_0x2e67b8,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x37cc28['metadata']['_copy'](this['metadata']),_0x37cc28;}['_onReload'](_0x360e50){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x360e50,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x192099){this['reloadListener']?this['reloadListener'](_0x192099):this['reloadUserInfo']=_0x192099;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x191ca8,_0x46bd56=!0x1){let _0x5301e3=!0x1;_0x191ca8['idToken']&&_0x191ca8['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x191ca8),_0x5301e3=!0x0),_0x46bd56&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x5301e3&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x98f544=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x98f544})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x3c7595=>({..._0x3c7595})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x59d0ca,_0x25d453){const _0x2ec162=_0x25d453['displayName']??void 0x0,_0x518fbc=_0x25d453['email']??void 0x0,_0x43fed0=_0x25d453['phoneNumber']??void 0x0,_0x4349e6=_0x25d453['photoURL']??void 0x0,_0x471aa4=_0x25d453['tenantId']??void 0x0,_0x11e7e1=_0x25d453['_redirectEventId']??void 0x0,_0x13a288=_0x25d453['createdAt']??void 0x0,_0x44f2fd=_0x25d453['lastLoginAt']??void 0x0,{uid:_0x2d4a16,emailVerified:_0xe46f62,isAnonymous:_0x5181b3,providerData:_0x45add2,stsTokenManager:_0x314e0b}=_0x25d453;m(_0x2d4a16&&_0x314e0b,_0x59d0ca,'internal-error');const _0x543665=et['fromJSON'](this['name'],_0x314e0b);m(typeof _0x2d4a16=='string',_0x59d0ca,'internal-error'),le(_0x2ec162,_0x59d0ca['name']),le(_0x518fbc,_0x59d0ca['name']),m(typeof _0xe46f62=='boolean',_0x59d0ca,'internal-error'),m(typeof _0x5181b3=='boolean',_0x59d0ca,'internal-error'),le(_0x43fed0,_0x59d0ca['name']),le(_0x4349e6,_0x59d0ca['name']),le(_0x471aa4,_0x59d0ca['name']),le(_0x11e7e1,_0x59d0ca['name']),le(_0x13a288,_0x59d0ca['name']),le(_0x44f2fd,_0x59d0ca['name']);const _0x22bb12=new j({'uid':_0x2d4a16,'auth':_0x59d0ca,'email':_0x518fbc,'emailVerified':_0xe46f62,'displayName':_0x2ec162,'isAnonymous':_0x5181b3,'photoURL':_0x4349e6,'phoneNumber':_0x43fed0,'tenantId':_0x471aa4,'stsTokenManager':_0x543665,'createdAt':_0x13a288,'lastLoginAt':_0x44f2fd});return _0x45add2&&Array['isArray'](_0x45add2)&&(_0x22bb12['providerData']=_0x45add2['map'](_0xe5f2bd=>({..._0xe5f2bd}))),_0x11e7e1&&(_0x22bb12['_redirectEventId']=_0x11e7e1),_0x22bb12;}static async['_fromIdTokenResponse'](_0x293ed6,_0x9734e5,_0x11a9f1=!0x1){const _0x482009=new et();_0x482009['updateFromServerResponse'](_0x9734e5);const _0x18e9b6=new j({'uid':_0x9734e5['localId'],'auth':_0x293ed6,'stsTokenManager':_0x482009,'isAnonymous':_0x11a9f1});return await Nn(_0x18e9b6),_0x18e9b6;}static async['_fromGetAccountInfoResponse'](_0x1bfe5a,_0xd70914,_0xdc4f00){const _0x464713=_0xd70914['users'][0x0];m(_0x464713['localId']!==void 0x0,'internal-error');const _0x4edb7c=_0x464713['providerUserInfo']!==void 0x0?Sa(_0x464713['providerUserInfo']):[],_0x3f7c0b=!(_0x464713['email']&&_0x464713['passwordHash'])&&!(_0x4edb7c!=null&&_0x4edb7c['length']),_0x51bd52=new et();_0x51bd52['updateFromIdToken'](_0xdc4f00);const _0x371dd7=new j({'uid':_0x464713['localId'],'auth':_0x1bfe5a,'stsTokenManager':_0x51bd52,'isAnonymous':_0x3f7c0b}),_0x5dc3d4={'uid':_0x464713['localId'],'displayName':_0x464713['displayName']||null,'photoURL':_0x464713['photoUrl']||null,'email':_0x464713['email']||null,'emailVerified':_0x464713['emailVerified']||!0x1,'phoneNumber':_0x464713['phoneNumber']||null,'tenantId':_0x464713['tenantId']||null,'providerData':_0x4edb7c,'metadata':new Li(_0x464713['createdAt'],_0x464713['lastLoginAt']),'isAnonymous':!(_0x464713['email']&&_0x464713['passwordHash'])&&!(_0x4edb7c!=null&&_0x4edb7c['length'])};return Object['assign'](_0x371dd7,_0x5dc3d4),_0x371dd7;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x3791dd){ce(_0x3791dd instanceof Function,'Expected\x20a\x20class\x20definition');let _0x1216ff=Tr['get'](_0x3791dd);return _0x1216ff?(ce(_0x1216ff instanceof _0x3791dd,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x1216ff):(_0x1216ff=new _0x3791dd(),Tr['set'](_0x3791dd,_0x1216ff),_0x1216ff);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x42e6a0,_0x1de3b5){this['storage'][_0x42e6a0]=_0x1de3b5;}async['_get'](_0x1b4e1c){const _0x3ab26e=this['storage'][_0x1b4e1c];return _0x3ab26e===void 0x0?null:_0x3ab26e;}async['_remove'](_0x1e0d1c){delete this['storage'][_0x1e0d1c];}['_addListener'](_0x2b9a79,_0x4581b0){}['_removeListener'](_0x2c3924,_0x7d03d2){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x2d89b0,_0x84855e,_0x29b543){return'firebase:'+_0x2d89b0+':'+_0x84855e+':'+_0x29b543;}class tt{constructor(_0x250253,_0x237591,_0x1deeab){this['persistence']=_0x250253,this['auth']=_0x237591,this['userKey']=_0x1deeab;const {config:_0x5bf667,name:_0x5ba9cc}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x5bf667['apiKey'],_0x5ba9cc),this['fullPersistenceKey']=ln('persistence',_0x5bf667['apiKey'],_0x5ba9cc),this['boundEventHandler']=_0x237591['_onStorageEvent']['bind'](_0x237591),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x16ac6c){return this['persistence']['_set'](this['fullUserKey'],_0x16ac6c['toJSON']());}async['getCurrentUser'](){const _0x10d952=await this['persistence']['_get'](this['fullUserKey']);if(!_0x10d952)return null;if(typeof _0x10d952=='string'){const _0x15ecec=await Pn(this['auth'],{'idToken':_0x10d952})['catch'](()=>{});return _0x15ecec?j['_fromGetAccountInfoResponse'](this['auth'],_0x15ecec,_0x10d952):null;}return j['_fromJSON'](this['auth'],_0x10d952);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x195f81){if(this['persistence']===_0x195f81)return;const _0x5cfae2=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x195f81,_0x5cfae2)return this['setCurrentUser'](_0x5cfae2);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x1b4f0f,_0x115088,_0x18c296='authUser'){if(!_0x115088['length'])return new tt(ie(Sr),_0x1b4f0f,_0x18c296);const _0x5be9f5=(await Promise['all'](_0x115088['map'](async _0x2b8fa6=>{if(await _0x2b8fa6['_isAvailable']())return _0x2b8fa6;})))['filter'](_0x6c317c=>_0x6c317c);let _0x1ea19d=_0x5be9f5[0x0]||ie(Sr);const _0x12138e=ln(_0x18c296,_0x1b4f0f['config']['apiKey'],_0x1b4f0f['name']);let _0x2de43f=null;for(const _0x159f9b of _0x115088)try{const _0x1d3481=await _0x159f9b['_get'](_0x12138e);if(_0x1d3481){let _0x3df16b;if(typeof _0x1d3481=='string'){const _0x56a336=await Pn(_0x1b4f0f,{'idToken':_0x1d3481})['catch'](()=>{});if(!_0x56a336)break;_0x3df16b=await j['_fromGetAccountInfoResponse'](_0x1b4f0f,_0x56a336,_0x1d3481);}else _0x3df16b=j['_fromJSON'](_0x1b4f0f,_0x1d3481);_0x159f9b!==_0x1ea19d&&(_0x2de43f=_0x3df16b),_0x1ea19d=_0x159f9b;break;}}catch{}const _0x2bdc69=_0x5be9f5['filter'](_0x640027=>_0x640027['_shouldAllowMigration']);return!_0x1ea19d['_shouldAllowMigration']||!_0x2bdc69['length']?new tt(_0x1ea19d,_0x1b4f0f,_0x18c296):(_0x1ea19d=_0x2bdc69[0x0],_0x2de43f&&await _0x1ea19d['_set'](_0x12138e,_0x2de43f['toJSON']()),await Promise['all'](_0x115088['map'](async _0x113994=>{if(_0x113994!==_0x1ea19d)try{await _0x113994['_remove'](_0x12138e);}catch{}})),new tt(_0x1ea19d,_0x1b4f0f,_0x18c296));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x63efc3){const _0x23d1d4=_0x63efc3['toLowerCase']();if(_0x23d1d4['includes']('opera/')||_0x23d1d4['includes']('opr/')||_0x23d1d4['includes']('opios/'))return'Opera';if(Pa(_0x23d1d4))return'IEMobile';if(_0x23d1d4['includes']('msie')||_0x23d1d4['includes']('trident/'))return'IE';if(_0x23d1d4['includes']('edge/'))return'Edge';if(Ra(_0x23d1d4))return'Firefox';if(_0x23d1d4['includes']('silk/'))return'Silk';if(Oa(_0x23d1d4))return'Blackberry';if(Da(_0x23d1d4))return'Webos';if(Aa(_0x23d1d4))return'Safari';if((_0x23d1d4['includes']('chrome/')||ka(_0x23d1d4))&&!_0x23d1d4['includes']('edge/'))return'Chrome';if(Na(_0x23d1d4))return'Android';{const _0x358d4d=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x56646f=_0x63efc3['match'](_0x358d4d);if((_0x56646f==null?void 0x0:_0x56646f['length'])===0x2)return _0x56646f[0x1];}return'Other';}function Ra(_0x37873f=W()){return/firefox\//i['test'](_0x37873f);}function Aa(_0xf5ccca=W()){const _0x318110=_0xf5ccca['toLowerCase']();return _0x318110['includes']('safari/')&&!_0x318110['includes']('chrome/')&&!_0x318110['includes']('crios/')&&!_0x318110['includes']('android');}function ka(_0x4317de=W()){return/crios\//i['test'](_0x4317de);}function Pa(_0x4ea15e=W()){return/iemobile/i['test'](_0x4ea15e);}function Na(_0x181190=W()){return/android/i['test'](_0x181190);}function Oa(_0x57087c=W()){return/blackberry/i['test'](_0x57087c);}function Da(_0x53ded3=W()){return/webos/i['test'](_0x53ded3);}function Ss(_0x30b9a0=W()){return/iphone|ipad|ipod/i['test'](_0x30b9a0)||/macintosh/i['test'](_0x30b9a0)&&/mobile/i['test'](_0x30b9a0);}function Rf(_0x225933=W()){var _0x2cbe70;return Ss(_0x225933)&&!!((_0x2cbe70=window['navigator'])!=null&&_0x2cbe70['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x33b5a9=W()){return Ss(_0x33b5a9)||Na(_0x33b5a9)||Da(_0x33b5a9)||Oa(_0x33b5a9)||/windows phone/i['test'](_0x33b5a9)||Pa(_0x33b5a9);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x4261a3,_0x12189f=[]){let _0x5e1ebc;switch(_0x4261a3){case'Browser':_0x5e1ebc=br(W());break;case'Worker':_0x5e1ebc=br(W())+'-'+_0x4261a3;break;default:_0x5e1ebc=_0x4261a3;}const _0xd02568=_0x12189f['length']?_0x12189f['join'](','):'FirebaseCore-web';return _0x5e1ebc+'/JsCore/'+dt+'/'+_0xd02568;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x17345f){this['auth']=_0x17345f,this['queue']=[];}['pushCallback'](_0xa7adc1,_0xd22198){const _0x724fb6=_0x1e12b1=>new Promise((_0x12ff20,_0x35e710)=>{try{const _0xabe317=_0xa7adc1(_0x1e12b1);_0x12ff20(_0xabe317);}catch(_0x3b04cd){_0x35e710(_0x3b04cd);}});_0x724fb6['onAbort']=_0xd22198,this['queue']['push'](_0x724fb6);const _0xf1f8d3=this['queue']['length']-0x1;return()=>{this['queue'][_0xf1f8d3]=()=>Promise['resolve']();};}async['runMiddleware'](_0x1331c2){if(this['auth']['currentUser']===_0x1331c2)return;const _0x2ee45c=[];try{for(const _0x33ad4c of this['queue'])await _0x33ad4c(_0x1331c2),_0x33ad4c['onAbort']&&_0x2ee45c['push'](_0x33ad4c['onAbort']);}catch(_0x3e545d){_0x2ee45c['reverse']();for(const _0x1f5f4d of _0x2ee45c)try{_0x1f5f4d();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x3e545d==null?void 0x0:_0x3e545d['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x9d08e5,_0x1adb68={}){return Pe(_0x9d08e5,'GET','/v2/passwordPolicy',ke(_0x9d08e5,_0x1adb68));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x549ec2){var _0x4509f4;const _0x40ab4c=_0x549ec2['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x40ab4c['minPasswordLength']??Nf,_0x40ab4c['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x40ab4c['maxPasswordLength']),_0x40ab4c['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x40ab4c['containsLowercaseCharacter']),_0x40ab4c['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x40ab4c['containsUppercaseCharacter']),_0x40ab4c['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x40ab4c['containsNumericCharacter']),_0x40ab4c['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x40ab4c['containsNonAlphanumericCharacter']),this['enforcementState']=_0x549ec2['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x4509f4=_0x549ec2['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x4509f4['join'](''))??'',this['forceUpgradeOnSignin']=_0x549ec2['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x549ec2['schemaVersion'];}['validatePassword'](_0x480889){const _0x51fdfe={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x480889,_0x51fdfe),this['validatePasswordCharacterOptions'](_0x480889,_0x51fdfe),_0x51fdfe['isValid']&&(_0x51fdfe['isValid']=_0x51fdfe['meetsMinPasswordLength']??!0x0),_0x51fdfe['isValid']&&(_0x51fdfe['isValid']=_0x51fdfe['meetsMaxPasswordLength']??!0x0),_0x51fdfe['isValid']&&(_0x51fdfe['isValid']=_0x51fdfe['containsLowercaseLetter']??!0x0),_0x51fdfe['isValid']&&(_0x51fdfe['isValid']=_0x51fdfe['containsUppercaseLetter']??!0x0),_0x51fdfe['isValid']&&(_0x51fdfe['isValid']=_0x51fdfe['containsNumericCharacter']??!0x0),_0x51fdfe['isValid']&&(_0x51fdfe['isValid']=_0x51fdfe['containsNonAlphanumericCharacter']??!0x0),_0x51fdfe;}['validatePasswordLengthOptions'](_0x3fdc2f,_0x24f5d5){const _0x32e3d4=this['customStrengthOptions']['minPasswordLength'],_0x115b55=this['customStrengthOptions']['maxPasswordLength'];_0x32e3d4&&(_0x24f5d5['meetsMinPasswordLength']=_0x3fdc2f['length']>=_0x32e3d4),_0x115b55&&(_0x24f5d5['meetsMaxPasswordLength']=_0x3fdc2f['length']<=_0x115b55);}['validatePasswordCharacterOptions'](_0x5c805f,_0x5d3b48){this['updatePasswordCharacterOptionsStatuses'](_0x5d3b48,!0x1,!0x1,!0x1,!0x1);let _0x4fbb20;for(let _0x2b9bff=0x0;_0x2b9bff<_0x5c805f['length'];_0x2b9bff++)_0x4fbb20=_0x5c805f['charAt'](_0x2b9bff),this['updatePasswordCharacterOptionsStatuses'](_0x5d3b48,_0x4fbb20>='a'&&_0x4fbb20<='z',_0x4fbb20>='A'&&_0x4fbb20<='Z',_0x4fbb20>='0'&&_0x4fbb20<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x4fbb20));}['updatePasswordCharacterOptionsStatuses'](_0x5781d1,_0x344495,_0x2292f8,_0x3f059c,_0x4958d5){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x5781d1['containsLowercaseLetter']||(_0x5781d1['containsLowercaseLetter']=_0x344495)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x5781d1['containsUppercaseLetter']||(_0x5781d1['containsUppercaseLetter']=_0x2292f8)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x5781d1['containsNumericCharacter']||(_0x5781d1['containsNumericCharacter']=_0x3f059c)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x5781d1['containsNonAlphanumericCharacter']||(_0x5781d1['containsNonAlphanumericCharacter']=_0x4958d5));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x255fca,_0x22c75b,_0x949195,_0x40e7d5){this['app']=_0x255fca,this['heartbeatServiceProvider']=_0x22c75b,this['appCheckServiceProvider']=_0x949195,this['config']=_0x40e7d5,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x255fca['name'],this['clientVersion']=_0x40e7d5['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x16b0ca=>this['_resolvePersistenceManagerAvailable']=_0x16b0ca);}['_initializeWithPersistence'](_0x2033af,_0x37ec26){return _0x37ec26&&(this['_popupRedirectResolver']=ie(_0x37ec26)),this['_initializationPromise']=this['queue'](async()=>{var _0xef6279,_0x467b4c,_0x483b12;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x2033af),(_0xef6279=this['_resolvePersistenceManagerAvailable'])==null||_0xef6279['call'](this),!this['_deleted'])){if((_0x467b4c=this['_popupRedirectResolver'])!=null&&_0x467b4c['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x37ec26),this['lastNotifiedUid']=((_0x483b12=this['currentUser'])==null?void 0x0:_0x483b12['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x7d8e56=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x7d8e56)){if(this['currentUser']&&_0x7d8e56&&this['currentUser']['uid']===_0x7d8e56['uid']){this['_currentUser']['_assign'](_0x7d8e56),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x7d8e56,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x4ec81c){try{const _0x41d840=await Pn(this,{'idToken':_0x4ec81c}),_0xd38024=await j['_fromGetAccountInfoResponse'](this,_0x41d840,_0x4ec81c);await this['directlySetCurrentUser'](_0xd38024);}catch(_0x4eef4b){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x4eef4b),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x518ed9){var _0x315cc2;if($(this['app'])){const _0x42ad67=this['app']['settings']['authIdToken'];return _0x42ad67?new Promise(_0x234f08=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x42ad67)['then'](_0x234f08,_0x234f08));}):this['directlySetCurrentUser'](null);}const _0x24184b=await this['assertedPersistence']['getCurrentUser']();let _0x275c07=_0x24184b,_0x1f0494=!0x1;if(_0x518ed9&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x4444af=(_0x315cc2=this['redirectUser'])==null?void 0x0:_0x315cc2['_redirectEventId'],_0x2dd556=_0x275c07==null?void 0x0:_0x275c07['_redirectEventId'],_0x45d02a=await this['tryRedirectSignIn'](_0x518ed9);(!_0x4444af||_0x4444af===_0x2dd556)&&(_0x45d02a!=null&&_0x45d02a['user'])&&(_0x275c07=_0x45d02a['user'],_0x1f0494=!0x0);}if(!_0x275c07)return this['directlySetCurrentUser'](null);if(!_0x275c07['_redirectEventId']){if(_0x1f0494)try{await this['beforeStateQueue']['runMiddleware'](_0x275c07);}catch(_0x590abc){_0x275c07=_0x24184b,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x590abc));}return _0x275c07?this['reloadAndSetCurrentUserOrClear'](_0x275c07):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x275c07['_redirectEventId']?this['directlySetCurrentUser'](_0x275c07):this['reloadAndSetCurrentUserOrClear'](_0x275c07);}async['tryRedirectSignIn'](_0x49b571){let _0x20d8ed=null;try{_0x20d8ed=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x49b571,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x20d8ed;}async['reloadAndSetCurrentUserOrClear'](_0x53c322){try{await Nn(_0x53c322);}catch(_0x497312){if((_0x497312==null?void 0x0:_0x497312['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x53c322);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x28e8cd){if($(this['app']))return Promise['reject'](re(this));const _0x333da4=_0x28e8cd?P(_0x28e8cd):null;return _0x333da4&&m(_0x333da4['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x333da4&&_0x333da4['_clone'](this));}async['_updateCurrentUser'](_0x523638,_0x2350d3=!0x1){if(!this['_deleted'])return _0x523638&&m(this['tenantId']===_0x523638['tenantId'],this,'tenant-id-mismatch'),_0x2350d3||await this['beforeStateQueue']['runMiddleware'](_0x523638),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x523638),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x4191a6){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x4191a6));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x10fe2a){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x118000=this['_getPasswordPolicyInternal']();return _0x118000['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x118000['validatePassword'](_0x10fe2a);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x8740ae=await Pf(this),_0x220e79=new Of(_0x8740ae);this['tenantId']===null?this['_projectPasswordPolicy']=_0x220e79:this['_tenantPasswordPolicies'][this['tenantId']]=_0x220e79;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x232d49){this['_errorFactory']=new Gt('auth','Firebase',_0x232d49());}['onAuthStateChanged'](_0x4bfdf3,_0x16bcd5,_0x127e60){return this['registerStateListener'](this['authStateSubscription'],_0x4bfdf3,_0x16bcd5,_0x127e60);}['beforeAuthStateChanged'](_0x366b6e,_0x39da08){return this['beforeStateQueue']['pushCallback'](_0x366b6e,_0x39da08);}['onIdTokenChanged'](_0x5db829,_0x4b0f11,_0x1780e4){return this['registerStateListener'](this['idTokenSubscription'],_0x5db829,_0x4b0f11,_0x1780e4);}['authStateReady'](){return new Promise((_0x2637b8,_0x43addb)=>{if(this['currentUser'])_0x2637b8();else{const _0xef64a5=this['onAuthStateChanged'](()=>{_0xef64a5(),_0x2637b8();},_0x43addb);}});}async['revokeAccessToken'](_0x6396a9){if(this['currentUser']){const _0x526c2a=await this['currentUser']['getIdToken'](),_0x4b46e8={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x6396a9,'idToken':_0x526c2a};this['tenantId']!=null&&(_0x4b46e8['tenantId']=this['tenantId']),await bf(this,_0x4b46e8);}}['toJSON'](){var _0x21ad1a;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x21ad1a=this['_currentUser'])==null?void 0x0:_0x21ad1a['toJSON']()};}async['_setRedirectUser'](_0x44148e,_0x4d9f7a){const _0x5a92bb=await this['getOrInitRedirectPersistenceManager'](_0x4d9f7a);return _0x44148e===null?_0x5a92bb['removeCurrentUser']():_0x5a92bb['setCurrentUser'](_0x44148e);}async['getOrInitRedirectPersistenceManager'](_0x10d34e){if(!this['redirectPersistenceManager']){const _0x51c9a2=_0x10d34e&&ie(_0x10d34e)||this['_popupRedirectResolver'];m(_0x51c9a2,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x51c9a2['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x54b49b){var _0x1789c9,_0x25e04b;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x1789c9=this['_currentUser'])==null?void 0x0:_0x1789c9['_redirectEventId'])===_0x54b49b?this['_currentUser']:((_0x25e04b=this['redirectUser'])==null?void 0x0:_0x25e04b['_redirectEventId'])===_0x54b49b?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x3dcafe){if(_0x3dcafe===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x3dcafe));}['_notifyListenersIfCurrent'](_0xda024c){_0xda024c===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x148020;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x2320b=((_0x148020=this['currentUser'])==null?void 0x0:_0x148020['uid'])??null;this['lastNotifiedUid']!==_0x2320b&&(this['lastNotifiedUid']=_0x2320b,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x3062b7,_0x394f54,_0x3521bc,_0x33cbe5){if(this['_deleted'])return()=>{};const _0x24476f=typeof _0x394f54=='function'?_0x394f54:_0x394f54['next']['bind'](_0x394f54);let _0x1b20e8=!0x1;const _0x3a7fa6=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x3a7fa6,this,'internal-error'),_0x3a7fa6['then'](()=>{_0x1b20e8||_0x24476f(this['currentUser']);}),typeof _0x394f54=='function'){const _0x5868e3=_0x3062b7['addObserver'](_0x394f54,_0x3521bc,_0x33cbe5);return()=>{_0x1b20e8=!0x0,_0x5868e3();};}else{const _0x366dcc=_0x3062b7['addObserver'](_0x394f54);return()=>{_0x1b20e8=!0x0,_0x366dcc();};}}async['directlySetCurrentUser'](_0x5975f6){this['currentUser']&&this['currentUser']!==_0x5975f6&&this['_currentUser']['_stopProactiveRefresh'](),_0x5975f6&&this['isProactiveRefreshEnabled']&&_0x5975f6['_startProactiveRefresh'](),this['currentUser']=_0x5975f6,_0x5975f6?await this['assertedPersistence']['setCurrentUser'](_0x5975f6):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x1c237d){return this['operations']=this['operations']['then'](_0x1c237d,_0x1c237d),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x21e997){!_0x21e997||this['frameworks']['includes'](_0x21e997)||(this['frameworks']['push'](_0x21e997),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x42712d;const _0x2a943d={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x2a943d['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x3ee7cf=await((_0x42712d=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x42712d['getHeartbeatsHeader']());_0x3ee7cf&&(_0x2a943d['X-Firebase-Client']=_0x3ee7cf);const _0x1091db=await this['_getAppCheckToken']();return _0x1091db&&(_0x2a943d['X-Firebase-AppCheck']=_0x1091db),_0x2a943d;}async['_getAppCheckToken'](){var _0xe4447c;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x3b8e1b=await((_0xe4447c=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0xe4447c['getToken']());return _0x3b8e1b!=null&&_0x3b8e1b['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x3b8e1b['error']),_0x3b8e1b==null?void 0x0:_0x3b8e1b['token'];}}function Ke(_0x1799f2){return P(_0x1799f2);}class Rr{constructor(_0x51349){this['auth']=_0x51349,this['observer']=null,this['addObserver']=Tc(_0x39756e=>this['observer']=_0x39756e);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x57accb){Jn=_0x57accb;}function xa(_0x261e7b){return Jn['loadJS'](_0x261e7b);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x2cc7d2){return'__'+_0x2cc7d2+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x2a6179){_0x2a6179();}['execute'](_0x25b5ad,_0x474236){return Promise['resolve']('token');}['render'](_0x44b80b,_0x39685a){return'';}}class Wf{['ready'](_0xce9e8a){_0xce9e8a();}['execute'](_0x180020,_0x37cf65){return Promise['resolve']('token');}['render'](_0x12d438,_0x7dd708){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x41a9c8){this['type']=Bf,this['auth']=Ke(_0x41a9c8);}async['verify'](_0x11ff02='verify',_0x259dbc=!0x1){async function _0x2e2269(_0x3b7da9){if(!_0x259dbc){if(_0x3b7da9['tenantId']==null&&_0x3b7da9['_agentRecaptchaConfig']!=null)return _0x3b7da9['_agentRecaptchaConfig']['siteKey'];if(_0x3b7da9['tenantId']!=null&&_0x3b7da9['_tenantRecaptchaConfigs'][_0x3b7da9['tenantId']]!==void 0x0)return _0x3b7da9['_tenantRecaptchaConfigs'][_0x3b7da9['tenantId']]['siteKey'];}return new Promise(async(_0x8b10f7,_0x62ccb8)=>{yf(_0x3b7da9,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x560b76=>{if(_0x560b76['recaptchaKey']===void 0x0)_0x62ccb8(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x10d9af=new mf(_0x560b76);return _0x3b7da9['tenantId']==null?_0x3b7da9['_agentRecaptchaConfig']=_0x10d9af:_0x3b7da9['_tenantRecaptchaConfigs'][_0x3b7da9['tenantId']]=_0x10d9af,_0x8b10f7(_0x10d9af['siteKey']);}})['catch'](_0x7e5446=>{_0x62ccb8(_0x7e5446);});});}function _0x35e8bb(_0x5856f7,_0x28c9fe,_0x220e34){const _0x239b18=window['grecaptcha'];wr(_0x239b18)?_0x239b18['enterprise']['ready'](()=>{_0x239b18['enterprise']['execute'](_0x5856f7,{'action':_0x11ff02})['then'](_0x553054=>{_0x28c9fe(_0x553054);})['catch'](()=>{_0x28c9fe(Fa);});}):_0x220e34(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x19c17a,_0x52e21f)=>{_0x2e2269(this['auth'])['then'](async _0x917d46=>{if(!_0x259dbc&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x35e8bb(_0x917d46,_0x19c17a,_0x52e21f);else{if(typeof window>'u'){_0x52e21f(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x1dda90=Lf();_0x1dda90['length']!==0x0&&(_0x1dda90+=_0x917d46+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x56ccc2;(_0x56ccc2=he['scriptInjectionDeferred'])==null||_0x56ccc2['resolve']();},xa(_0x1dda90)['then'](()=>{var _0x209730;return(_0x209730=he['scriptInjectionDeferred'])==null?void 0x0:_0x209730['promise'];})['then'](()=>{_0x35e8bb(_0x917d46,_0x19c17a,_0x52e21f);})['catch'](_0x33a39a=>{_0x52e21f(_0x33a39a);});}})['catch'](_0x19f873=>{_0x52e21f(_0x19f873);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x459c27,_0x70f719,_0x1dec76,_0x458850=!0x1,_0x4aa29b=!0x1){const _0x5e6657=new he(_0x459c27);let _0x474c98;if(_0x4aa29b)_0x474c98=Fa;else try{_0x474c98=await _0x5e6657['verify'](_0x1dec76);}catch{_0x474c98=await _0x5e6657['verify'](_0x1dec76,!0x0);}const _0x395a16={..._0x70f719};if(_0x1dec76==='mfaSmsEnrollment'||_0x1dec76==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x395a16){const _0x414db1=_0x395a16['phoneEnrollmentInfo']['phoneNumber'],_0xa8c5e3=_0x395a16['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x395a16,{'phoneEnrollmentInfo':{'phoneNumber':_0x414db1,'recaptchaToken':_0xa8c5e3,'captchaResponse':_0x474c98,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x395a16){const _0xb8cdae=_0x395a16['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x395a16,{'phoneSignInInfo':{'recaptchaToken':_0xb8cdae,'captchaResponse':_0x474c98,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x395a16;}return _0x458850?Object['assign'](_0x395a16,{'captchaResp':_0x474c98}):Object['assign'](_0x395a16,{'captchaResponse':_0x474c98}),Object['assign'](_0x395a16,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x395a16,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x395a16;}async function xi(_0xfca830,_0x43f1ad,_0x2002ae,_0x202797,_0x3b148c){var _0x441452;if((_0x441452=_0xfca830['_getRecaptchaConfig']())!=null&&_0x441452['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x5b8f75=await kr(_0xfca830,_0x43f1ad,_0x2002ae,_0x2002ae==='getOobCode');return _0x202797(_0xfca830,_0x5b8f75);}else return _0x202797(_0xfca830,_0x43f1ad)['catch'](async _0xfd31c7=>{if(_0xfd31c7['code']==='auth/missing-recaptcha-token'){console['log'](_0x2002ae+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x3e9462=await kr(_0xfca830,_0x43f1ad,_0x2002ae,_0x2002ae==='getOobCode');return _0x202797(_0xfca830,_0x3e9462);}else return Promise['reject'](_0xfd31c7);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x2bb2af,_0x22c3fd){const _0x3699a5=Hi(_0x2bb2af,'auth');if(_0x3699a5['isInitialized']()){const _0x56febd=_0x3699a5['getImmediate'](),_0x5dc7bc=_0x3699a5['getOptions']();if(xe(_0x5dc7bc,_0x22c3fd??{}))return _0x56febd;Y(_0x56febd,'already-initialized');}return _0x3699a5['initialize']({'options':_0x22c3fd});}function Hf(_0x452ad4,_0x9f316e){const _0x1675b7=(_0x9f316e==null?void 0x0:_0x9f316e['persistence'])||[],_0x13cb4d=(Array['isArray'](_0x1675b7)?_0x1675b7:[_0x1675b7])['map'](ie);_0x9f316e!=null&&_0x9f316e['errorMap']&&_0x452ad4['_updateErrorMap'](_0x9f316e['errorMap']),_0x452ad4['_initializeWithPersistence'](_0x13cb4d,_0x9f316e==null?void 0x0:_0x9f316e['popupRedirectResolver']);}function $f(_0x374232,_0x2d442f,_0x23724b){const _0x10e73e=Ke(_0x374232);m(/^https?:\/\//['test'](_0x2d442f),_0x10e73e,'invalid-emulator-scheme');const _0x605c83=!0x1,_0xb33a9d=Ua(_0x2d442f),{host:_0x3457ab,port:_0x3160ee}=Gf(_0x2d442f),_0x403663=_0x3160ee===null?'':':'+_0x3160ee,_0x468456={'url':_0xb33a9d+'//'+_0x3457ab+_0x403663+'/'},_0xcb2073=Object['freeze']({'host':_0x3457ab,'port':_0x3160ee,'protocol':_0xb33a9d['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x605c83})});if(!_0x10e73e['_canInitEmulator']){m(_0x10e73e['config']['emulator']&&_0x10e73e['emulatorConfig'],_0x10e73e,'emulator-config-failed'),m(xe(_0x468456,_0x10e73e['config']['emulator'])&&xe(_0xcb2073,_0x10e73e['emulatorConfig']),_0x10e73e,'emulator-config-failed');return;}_0x10e73e['config']['emulator']=_0x468456,_0x10e73e['emulatorConfig']=_0xcb2073,_0x10e73e['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x3457ab)?Qr(_0xb33a9d+'//'+_0x3457ab+_0x403663):qf();}function Ua(_0x26ee4f){const _0x367091=_0x26ee4f['indexOf'](':');return _0x367091<0x0?'':_0x26ee4f['substr'](0x0,_0x367091+0x1);}function Gf(_0x869dac){const _0x27ed65=Ua(_0x869dac),_0xad89ec=/(\/\/)?([^?#/]+)/['exec'](_0x869dac['substr'](_0x27ed65['length']));if(!_0xad89ec)return{'host':'','port':null};const _0x3a3776=_0xad89ec[0x2]['split']('@')['pop']()||'',_0xd1ef5c=/^(\[[^\]]+\])(:|$)/['exec'](_0x3a3776);if(_0xd1ef5c){const _0x3a2830=_0xd1ef5c[0x1];return{'host':_0x3a2830,'port':Pr(_0x3a3776['substr'](_0x3a2830['length']+0x1))};}else{const [_0x561616,_0x1e808a]=_0x3a3776['split'](':');return{'host':_0x561616,'port':Pr(_0x1e808a)};}}function Pr(_0x1752e8){if(!_0x1752e8)return null;const _0x593c80=Number(_0x1752e8);return isNaN(_0x593c80)?null:_0x593c80;}function qf(){function _0x37a871(){const _0xfe3992=document['createElement']('p'),_0x21465d=_0xfe3992['style'];_0xfe3992['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x21465d['position']='fixed',_0x21465d['width']='100%',_0x21465d['backgroundColor']='#ffffff',_0x21465d['border']='.1em\x20solid\x20#000000',_0x21465d['color']='#b50000',_0x21465d['bottom']='0px',_0x21465d['left']='0px',_0x21465d['margin']='0px',_0x21465d['zIndex']='10000',_0x21465d['textAlign']='center',_0xfe3992['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0xfe3992);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x37a871):_0x37a871());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0xdf9a02,_0x1e15ec){this['providerId']=_0xdf9a02,this['signInMethod']=_0x1e15ec;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x47cf19){return ne('not\x20implemented');}['_linkToIdToken'](_0x31ccae,_0x2fd018){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x4c75d0){return ne('not\x20implemented');}}async function zf(_0x554871,_0x367620){return Pe(_0x554871,'POST','/v1/accounts:signUp',_0x367620);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x3bde57,_0x119afe){return en(_0x3bde57,'POST','/v1/accounts:signInWithPassword',ke(_0x3bde57,_0x119afe));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x24dcd,_0x300513){return en(_0x24dcd,'POST','/v1/accounts:signInWithEmailLink',ke(_0x24dcd,_0x300513));}async function Yf(_0x1283b2,_0x2e5902){return en(_0x1283b2,'POST','/v1/accounts:signInWithEmailLink',ke(_0x1283b2,_0x2e5902));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x59dc77,_0x48c8ad,_0x20960b,_0x30efc1=null){super('password',_0x20960b),this['_email']=_0x59dc77,this['_password']=_0x48c8ad,this['_tenantId']=_0x30efc1;}static['_fromEmailAndPassword'](_0x44ae3a,_0x4a1ec5){return new $t(_0x44ae3a,_0x4a1ec5,'password');}static['_fromEmailAndCode'](_0x5b117b,_0x1f66b5,_0x237727=null){return new $t(_0x5b117b,_0x1f66b5,'emailLink',_0x237727);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x38284a){const _0x5901bc=typeof _0x38284a=='string'?JSON['parse'](_0x38284a):_0x38284a;if(_0x5901bc!=null&&_0x5901bc['email']&&(_0x5901bc!=null&&_0x5901bc['password'])){if(_0x5901bc['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x5901bc['email'],_0x5901bc['password']);if(_0x5901bc['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x5901bc['email'],_0x5901bc['password'],_0x5901bc['tenantId']);}return null;}async['_getIdTokenResponse'](_0x13c9c8){switch(this['signInMethod']){case'password':const _0x217fc8={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x13c9c8,_0x217fc8,'signInWithPassword',jf);case'emailLink':return Kf(_0x13c9c8,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x13c9c8,'internal-error');}}async['_linkToIdToken'](_0x49c4c5,_0x9cca21){switch(this['signInMethod']){case'password':const _0x1cee0a={'idToken':_0x9cca21,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x49c4c5,_0x1cee0a,'signUpPassword',zf);case'emailLink':return Yf(_0x49c4c5,{'idToken':_0x9cca21,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x49c4c5,'internal-error');}}['_getReauthenticationResolver'](_0x2e99cf){return this['_getIdTokenResponse'](_0x2e99cf);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x1f6048,_0x4f3dca){return en(_0x1f6048,'POST','/v1/accounts:signInWithIdp',ke(_0x1f6048,_0x4f3dca));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x1ccdf8){const _0x48389d=new $e(_0x1ccdf8['providerId'],_0x1ccdf8['signInMethod']);return _0x1ccdf8['idToken']||_0x1ccdf8['accessToken']?(_0x1ccdf8['idToken']&&(_0x48389d['idToken']=_0x1ccdf8['idToken']),_0x1ccdf8['accessToken']&&(_0x48389d['accessToken']=_0x1ccdf8['accessToken']),_0x1ccdf8['nonce']&&!_0x1ccdf8['pendingToken']&&(_0x48389d['nonce']=_0x1ccdf8['nonce']),_0x1ccdf8['pendingToken']&&(_0x48389d['pendingToken']=_0x1ccdf8['pendingToken'])):_0x1ccdf8['oauthToken']&&_0x1ccdf8['oauthTokenSecret']?(_0x48389d['accessToken']=_0x1ccdf8['oauthToken'],_0x48389d['secret']=_0x1ccdf8['oauthTokenSecret']):Y('argument-error'),_0x48389d;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x480ce8){const _0x426d0b=typeof _0x480ce8=='string'?JSON['parse'](_0x480ce8):_0x480ce8,{providerId:_0x20b7a2,signInMethod:_0x383673,..._0x20ad47}=_0x426d0b;if(!_0x20b7a2||!_0x383673)return null;const _0x3e6062=new $e(_0x20b7a2,_0x383673);return _0x3e6062['idToken']=_0x20ad47['idToken']||void 0x0,_0x3e6062['accessToken']=_0x20ad47['accessToken']||void 0x0,_0x3e6062['secret']=_0x20ad47['secret'],_0x3e6062['nonce']=_0x20ad47['nonce'],_0x3e6062['pendingToken']=_0x20ad47['pendingToken']||null,_0x3e6062;}['_getIdTokenResponse'](_0x2b4515){const _0x1660e0=this['buildRequest']();return nt(_0x2b4515,_0x1660e0);}['_linkToIdToken'](_0x4829ac,_0x2bd39f){const _0x3c8b00=this['buildRequest']();return _0x3c8b00['idToken']=_0x2bd39f,nt(_0x4829ac,_0x3c8b00);}['_getReauthenticationResolver'](_0x175f7c){const _0x47770c=this['buildRequest']();return _0x47770c['autoCreate']=!0x1,nt(_0x175f7c,_0x47770c);}['buildRequest'](){const _0x36f2ee={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x36f2ee['pendingToken']=this['pendingToken'];else{const _0xc40976={};this['idToken']&&(_0xc40976['id_token']=this['idToken']),this['accessToken']&&(_0xc40976['access_token']=this['accessToken']),this['secret']&&(_0xc40976['oauth_token_secret']=this['secret']),_0xc40976['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0xc40976['nonce']=this['nonce']),_0x36f2ee['postBody']=ut(_0xc40976);}return _0x36f2ee;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x11cb70){switch(_0x11cb70){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x31ccd7){const _0x1827a9=Ct(Tt(_0x31ccd7))['link'],_0x5aa211=_0x1827a9?Ct(Tt(_0x1827a9))['deep_link_id']:null,_0x466c74=Ct(Tt(_0x31ccd7))['deep_link_id'];return(_0x466c74?Ct(Tt(_0x466c74))['link']:null)||_0x466c74||_0x5aa211||_0x1827a9||_0x31ccd7;}class Rs{constructor(_0x1c4fdc){const _0x37f602=Ct(Tt(_0x1c4fdc)),_0x1a2186=_0x37f602['apiKey']??null,_0x7b303e=_0x37f602['oobCode']??null,_0x15e7bd=Jf(_0x37f602['mode']??null);m(_0x1a2186&&_0x7b303e&&_0x15e7bd,'argument-error'),this['apiKey']=_0x1a2186,this['operation']=_0x15e7bd,this['code']=_0x7b303e,this['continueUrl']=_0x37f602['continueUrl']??null,this['languageCode']=_0x37f602['lang']??null,this['tenantId']=_0x37f602['tenantId']??null;}static['parseLink'](_0x54a829){const _0xcce53c=Xf(_0x54a829);try{return new Rs(_0xcce53c);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x1fd1f9,_0x3225d1){return $t['_fromEmailAndPassword'](_0x1fd1f9,_0x3225d1);}static['credentialWithLink'](_0x5370f4,_0x2d10ed){const _0x236e5f=Rs['parseLink'](_0x2d10ed);return m(_0x236e5f,'argument-error'),$t['_fromEmailAndCode'](_0x5370f4,_0x236e5f['code'],_0x236e5f['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x171252){this['providerId']=_0x171252,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x41db64){this['defaultLanguageCode']=_0x41db64;}['setCustomParameters'](_0x29775a){return this['customParameters']=_0x29775a,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x48415c){return this['scopes']['includes'](_0x48415c)||this['scopes']['push'](_0x48415c),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x1acfc2){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x1acfc2});}static['credentialFromResult'](_0x741b47){return ue['credentialFromTaggedObject'](_0x741b47);}static['credentialFromError'](_0x2dbf40){return ue['credentialFromTaggedObject'](_0x2dbf40['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5e3ac3}){if(!_0x5e3ac3||!('oauthAccessToken'in _0x5e3ac3)||!_0x5e3ac3['oauthAccessToken'])return null;try{return ue['credential'](_0x5e3ac3['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x13dacd,_0x3fc0c0){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x13dacd,'accessToken':_0x3fc0c0});}static['credentialFromResult'](_0xa0effc){return de['credentialFromTaggedObject'](_0xa0effc);}static['credentialFromError'](_0x3180e5){return de['credentialFromTaggedObject'](_0x3180e5['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x2c82ac}){if(!_0x2c82ac)return null;const {oauthIdToken:_0x58782b,oauthAccessToken:_0x540d46}=_0x2c82ac;if(!_0x58782b&&!_0x540d46)return null;try{return de['credential'](_0x58782b,_0x540d46);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x493198){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x493198});}static['credentialFromResult'](_0x352325){return fe['credentialFromTaggedObject'](_0x352325);}static['credentialFromError'](_0xb3f729){return fe['credentialFromTaggedObject'](_0xb3f729['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x520e61}){if(!_0x520e61||!('oauthAccessToken'in _0x520e61)||!_0x520e61['oauthAccessToken'])return null;try{return fe['credential'](_0x520e61['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x3e7409,_0x4bd4a2){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x3e7409,'oauthTokenSecret':_0x4bd4a2});}static['credentialFromResult'](_0x4302bf){return pe['credentialFromTaggedObject'](_0x4302bf);}static['credentialFromError'](_0x2a830a){return pe['credentialFromTaggedObject'](_0x2a830a['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5bf73e}){if(!_0x5bf73e)return null;const {oauthAccessToken:_0x261af7,oauthTokenSecret:_0x1ffa35}=_0x5bf73e;if(!_0x261af7||!_0x1ffa35)return null;try{return pe['credential'](_0x261af7,_0x1ffa35);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x32f20c,_0x41cc4b){return en(_0x32f20c,'POST','/v1/accounts:signUp',ke(_0x32f20c,_0x41cc4b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x3c693a){this['user']=_0x3c693a['user'],this['providerId']=_0x3c693a['providerId'],this['_tokenResponse']=_0x3c693a['_tokenResponse'],this['operationType']=_0x3c693a['operationType'];}static async['_fromIdTokenResponse'](_0x58dc57,_0x1ec1ae,_0xefdc35,_0x402740=!0x1){const _0xd49076=await j['_fromIdTokenResponse'](_0x58dc57,_0xefdc35,_0x402740),_0x152ba7=Nr(_0xefdc35);return new Ge({'user':_0xd49076,'providerId':_0x152ba7,'_tokenResponse':_0xefdc35,'operationType':_0x1ec1ae});}static async['_forOperation'](_0x205c21,_0x5cd676,_0x4d1264){await _0x205c21['_updateTokensIfNecessary'](_0x4d1264,!0x0);const _0x359e8e=Nr(_0x4d1264);return new Ge({'user':_0x205c21,'providerId':_0x359e8e,'_tokenResponse':_0x4d1264,'operationType':_0x5cd676});}}function Nr(_0x328bad){return _0x328bad['providerId']?_0x328bad['providerId']:'phoneNumber'in _0x328bad?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x18bbdb,_0x375866,_0x2415a6,_0x2c2b45){super(_0x375866['code'],_0x375866['message']),this['operationType']=_0x2415a6,this['user']=_0x2c2b45,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x18bbdb['name'],'tenantId':_0x18bbdb['tenantId']??void 0x0,'_serverResponse':_0x375866['customData']['_serverResponse'],'operationType':_0x2415a6};}static['_fromErrorAndOperation'](_0x511b69,_0x26f8ec,_0x308427,_0x3936dc){return new On(_0x511b69,_0x26f8ec,_0x308427,_0x3936dc);}}function Ba(_0x103799,_0x228991,_0x6862b2,_0x54549e){return(_0x228991==='reauthenticate'?_0x6862b2['_getReauthenticationResolver'](_0x103799):_0x6862b2['_getIdTokenResponse'](_0x103799))['catch'](_0x334f93=>{throw _0x334f93['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x103799,_0x334f93,_0x228991,_0x54549e):_0x334f93;});}async function ep(_0x5389cd,_0x1d9d0e,_0x565f9f=!0x1){const _0x398635=await Ht(_0x5389cd,_0x1d9d0e['_linkToIdToken'](_0x5389cd['auth'],await _0x5389cd['getIdToken']()),_0x565f9f);return Ge['_forOperation'](_0x5389cd,'link',_0x398635);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x4652a5,_0x284297,_0x28e6c1=!0x1){const {auth:_0x484ab3}=_0x4652a5;if($(_0x484ab3['app']))return Promise['reject'](re(_0x484ab3));const _0x275a7f='reauthenticate';try{const _0x25d8cc=await Ht(_0x4652a5,Ba(_0x484ab3,_0x275a7f,_0x284297,_0x4652a5),_0x28e6c1);m(_0x25d8cc['idToken'],_0x484ab3,'internal-error');const _0x1794c7=Ts(_0x25d8cc['idToken']);m(_0x1794c7,_0x484ab3,'internal-error');const {sub:_0x4fcb78}=_0x1794c7;return m(_0x4652a5['uid']===_0x4fcb78,_0x484ab3,'user-mismatch'),Ge['_forOperation'](_0x4652a5,_0x275a7f,_0x25d8cc);}catch(_0x41aa3f){throw(_0x41aa3f==null?void 0x0:_0x41aa3f['code'])==='auth/user-not-found'&&Y(_0x484ab3,'user-mismatch'),_0x41aa3f;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x5ef038,_0x298dbb,_0x1dc89a=!0x1){if($(_0x5ef038['app']))return Promise['reject'](re(_0x5ef038));const _0x1739f1='signIn',_0x5c086e=await Ba(_0x5ef038,_0x1739f1,_0x298dbb),_0x2c2ffa=await Ge['_fromIdTokenResponse'](_0x5ef038,_0x1739f1,_0x5c086e);return _0x1dc89a||await _0x5ef038['_updateCurrentUser'](_0x2c2ffa['user']),_0x2c2ffa;}async function np(_0x4f93e3,_0x5f36c3){return Va(Ke(_0x4f93e3),_0x5f36c3);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x24316b){const _0xf42ee3=Ke(_0x24316b);_0xf42ee3['_getPasswordPolicyInternal']()&&await _0xf42ee3['_updatePasswordPolicy']();}async function L_(_0x4f4393,_0x56dab9,_0x5dbee1){if($(_0x4f4393['app']))return Promise['reject'](re(_0x4f4393));const _0x31de15=Ke(_0x4f4393),_0x574747=await xi(_0x31de15,{'returnSecureToken':!0x0,'email':_0x56dab9,'password':_0x5dbee1,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0xc27167=>{throw _0xc27167['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x4f4393),_0xc27167;}),_0x31ebe7=await Ge['_fromIdTokenResponse'](_0x31de15,'signIn',_0x574747);return await _0x31de15['_updateCurrentUser'](_0x31ebe7['user']),_0x31ebe7;}function x_(_0x3c7a5b,_0x55546e,_0x572471){return $(_0x3c7a5b['app'])?Promise['reject'](re(_0x3c7a5b)):np(P(_0x3c7a5b),yt['credential'](_0x55546e,_0x572471))['catch'](async _0x54762d=>{throw _0x54762d['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x3c7a5b),_0x54762d;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x37ed5c,_0x43de83){return P(_0x37ed5c)['setPersistence'](_0x43de83);}function ip(_0x206b4f,_0x45f68b,_0xc7b702,_0x112781){return P(_0x206b4f)['onIdTokenChanged'](_0x45f68b,_0xc7b702,_0x112781);}function sp(_0x3deda9,_0x2586d5,_0x58cdb9){return P(_0x3deda9)['beforeAuthStateChanged'](_0x2586d5,_0x58cdb9);}function U_(_0x11a330,_0xdbbc31,_0x15d67c,_0x21381e){return P(_0x11a330)['onAuthStateChanged'](_0xdbbc31,_0x15d67c,_0x21381e);}function W_(_0x555331){return P(_0x555331)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x128021,_0x5f1633){this['storageRetriever']=_0x128021,this['type']=_0x5f1633;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x86d9c9,_0x4e1183){return this['storage']['setItem'](_0x86d9c9,JSON['stringify'](_0x4e1183)),Promise['resolve']();}['_get'](_0x2f0a8c){const _0x55ba0f=this['storage']['getItem'](_0x2f0a8c);return Promise['resolve'](_0x55ba0f?JSON['parse'](_0x55ba0f):null);}['_remove'](_0x1776b5){return this['storage']['removeItem'](_0x1776b5),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x42c246,_0x440652)=>this['onStorageEvent'](_0x42c246,_0x440652),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x627980){for(const _0x536c95 of Object['keys'](this['listeners'])){const _0x1023cf=this['storage']['getItem'](_0x536c95),_0x26cc4e=this['localCache'][_0x536c95];_0x1023cf!==_0x26cc4e&&_0x627980(_0x536c95,_0x26cc4e,_0x1023cf);}}['onStorageEvent'](_0x4e9713,_0x4812ab=!0x1){if(!_0x4e9713['key']){this['forAllChangedKeys']((_0x559cf9,_0x326238,_0x20adcd)=>{this['notifyListeners'](_0x559cf9,_0x20adcd);});return;}const _0x8c71c4=_0x4e9713['key'];_0x4812ab?this['detachListener']():this['stopPolling']();const _0x13339d=()=>{const _0x5257de=this['storage']['getItem'](_0x8c71c4);!_0x4812ab&&this['localCache'][_0x8c71c4]===_0x5257de||this['notifyListeners'](_0x8c71c4,_0x5257de);},_0x3db1c9=this['storage']['getItem'](_0x8c71c4);Af()&&_0x3db1c9!==_0x4e9713['newValue']&&_0x4e9713['newValue']!==_0x4e9713['oldValue']?setTimeout(_0x13339d,op):_0x13339d();}['notifyListeners'](_0x2d6abf,_0x32187c){this['localCache'][_0x2d6abf]=_0x32187c;const _0x4a1a7a=this['listeners'][_0x2d6abf];if(_0x4a1a7a){for(const _0x91fd9a of Array['from'](_0x4a1a7a))_0x91fd9a(_0x32187c&&JSON['parse'](_0x32187c));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x2ee535,_0x131e1,_0x156165)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x2ee535,'oldValue':_0x131e1,'newValue':_0x156165}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x621c2c,_0x39c941){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x621c2c]||(this['listeners'][_0x621c2c]=new Set(),this['localCache'][_0x621c2c]=this['storage']['getItem'](_0x621c2c)),this['listeners'][_0x621c2c]['add'](_0x39c941);}['_removeListener'](_0x409513,_0x46572e){this['listeners'][_0x409513]&&(this['listeners'][_0x409513]['delete'](_0x46572e),this['listeners'][_0x409513]['size']===0x0&&delete this['listeners'][_0x409513]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x1fa048,_0x1bba5e){await super['_set'](_0x1fa048,_0x1bba5e),this['localCache'][_0x1fa048]=JSON['stringify'](_0x1bba5e);}async['_get'](_0x3e2093){const _0xee7308=await super['_get'](_0x3e2093);return this['localCache'][_0x3e2093]=JSON['stringify'](_0xee7308),_0xee7308;}async['_remove'](_0x2b5a87){await super['_remove'](_0x2b5a87),delete this['localCache'][_0x2b5a87];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x5539eb,_0x4ddfba){}['_removeListener'](_0x3a9edf,_0x301fa2){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x47595a){return Promise['all'](_0x47595a['map'](async _0x331190=>{try{return{'fulfilled':!0x0,'value':await _0x331190};}catch(_0x504836){return{'fulfilled':!0x1,'reason':_0x504836};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x47b2bb){this['eventTarget']=_0x47b2bb,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x597bc6){const _0x228408=this['receivers']['find'](_0x43a529=>_0x43a529['isListeningto'](_0x597bc6));if(_0x228408)return _0x228408;const _0x319aa9=new Xn(_0x597bc6);return this['receivers']['push'](_0x319aa9),_0x319aa9;}['isListeningto'](_0x1fbe6c){return this['eventTarget']===_0x1fbe6c;}async['handleEvent'](_0x5c1cac){const _0x53978b=_0x5c1cac,{eventId:_0x589006,eventType:_0x4cc7d0,data:_0x2c2b33}=_0x53978b['data'],_0x2487f3=this['handlersMap'][_0x4cc7d0];if(!(_0x2487f3!=null&&_0x2487f3['size']))return;_0x53978b['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x589006,'eventType':_0x4cc7d0});const _0x408a68=Array['from'](_0x2487f3)['map'](async _0x3ab2cf=>_0x3ab2cf(_0x53978b['origin'],_0x2c2b33)),_0x380346=await cp(_0x408a68);_0x53978b['ports'][0x0]['postMessage']({'status':'done','eventId':_0x589006,'eventType':_0x4cc7d0,'response':_0x380346});}['_subscribe'](_0x2937c3,_0x67ec31){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x2937c3]||(this['handlersMap'][_0x2937c3]=new Set()),this['handlersMap'][_0x2937c3]['add'](_0x67ec31);}['_unsubscribe'](_0x33d3b5,_0x1bb7d0){this['handlersMap'][_0x33d3b5]&&_0x1bb7d0&&this['handlersMap'][_0x33d3b5]['delete'](_0x1bb7d0),(!_0x1bb7d0||this['handlersMap'][_0x33d3b5]['size']===0x0)&&delete this['handlersMap'][_0x33d3b5],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x590e46='',_0x24639a=0xa){let _0x71c3a7='';for(let _0x36462e=0x0;_0x36462e<_0x24639a;_0x36462e++)_0x71c3a7+=Math['floor'](Math['random']()*0xa);return _0x590e46+_0x71c3a7;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x22be59){this['target']=_0x22be59,this['handlers']=new Set();}['removeMessageHandler'](_0x306cd6){_0x306cd6['messageChannel']&&(_0x306cd6['messageChannel']['port1']['removeEventListener']('message',_0x306cd6['onMessage']),_0x306cd6['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x306cd6);}async['_send'](_0x379e18,_0x2341ef,_0x2139f6=0x32){const _0x5b7bed=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x5b7bed)throw new Error('connection_unavailable');let _0x29b4d8,_0x42daf8;return new Promise((_0x28a5fc,_0x5891d0)=>{const _0x4b0af7=As('',0x14);_0x5b7bed['port1']['start']();const _0x190620=setTimeout(()=>{_0x5891d0(new Error('unsupported_event'));},_0x2139f6);_0x42daf8={'messageChannel':_0x5b7bed,'onMessage'(_0x64e815){const _0x50dbdc=_0x64e815;if(_0x50dbdc['data']['eventId']===_0x4b0af7)switch(_0x50dbdc['data']['status']){case'ack':clearTimeout(_0x190620),_0x29b4d8=setTimeout(()=>{_0x5891d0(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x29b4d8),_0x28a5fc(_0x50dbdc['data']['response']);break;default:clearTimeout(_0x190620),clearTimeout(_0x29b4d8),_0x5891d0(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x42daf8),_0x5b7bed['port1']['addEventListener']('message',_0x42daf8['onMessage']),this['target']['postMessage']({'eventType':_0x379e18,'eventId':_0x4b0af7,'data':_0x2341ef},[_0x5b7bed['port2']]);})['finally'](()=>{_0x42daf8&&this['removeMessageHandler'](_0x42daf8);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x224cfe){Z()['location']['href']=_0x224cfe;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x2d0ab7;return((_0x2d0ab7=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x2d0ab7['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x14f2e3){this['request']=_0x14f2e3;}['toPromise'](){return new Promise((_0x8d54b6,_0x2ecd5e)=>{this['request']['addEventListener']('success',()=>{_0x8d54b6(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x2ecd5e(this['request']['error']);});});}}function Zn(_0x3abd48,_0x332307){return _0x3abd48['transaction']([Mn],_0x332307?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x19956e=indexedDB['deleteDatabase'](Ka);return new nn(_0x19956e)['toPromise']();}function Qa(){const _0x5e5e73=indexedDB['open'](Ka,pp);return new Promise((_0x5e2c23,_0x298939)=>{_0x5e5e73['addEventListener']('error',()=>{_0x298939(_0x5e5e73['error']);}),_0x5e5e73['addEventListener']('upgradeneeded',()=>{const _0x294963=_0x5e5e73['result'];try{_0x294963['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x2cd92d){_0x298939(_0x2cd92d);}}),_0x5e5e73['addEventListener']('success',async()=>{const _0x3b65e6=_0x5e5e73['result'];_0x3b65e6['objectStoreNames']['contains'](Mn)?_0x5e2c23(_0x3b65e6):(_0x3b65e6['close'](),await _p(),_0x5e2c23(await Qa()));});});}async function Or(_0xfcf693,_0x3c7b3e,_0x4fbf56){const _0x5b092=Zn(_0xfcf693,!0x0)['put']({[Ya]:_0x3c7b3e,'value':_0x4fbf56});return new nn(_0x5b092)['toPromise']();}async function gp(_0x11078a,_0x2dce9c){const _0x5e8f28=Zn(_0x11078a,!0x1)['get'](_0x2dce9c),_0x3dcaf9=await new nn(_0x5e8f28)['toPromise']();return _0x3dcaf9===void 0x0?null:_0x3dcaf9['value'];}function Dr(_0x4cb33f,_0x307d1f){const _0x11d295=Zn(_0x4cb33f,!0x0)['delete'](_0x307d1f);return new nn(_0x11d295)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x58c7d0){let _0x304385=0x0;for(;;)try{const _0x570476=await this['_openDb']();return await _0x58c7d0(_0x570476);}catch(_0x3b2f5f){if(_0x304385++>yp)throw _0x3b2f5f;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x371ccd,_0x1699f3)=>({'keyProcessed':(await this['_poll']())['includes'](_0x1699f3['key'])})),this['receiver']['_subscribe']('ping',async(_0x298548,_0x571183)=>['keyChanged']);}async['initializeSender'](){var _0x401121,_0x2bea0a;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x171e99=await this['sender']['_send']('ping',{},0x320);_0x171e99&&(_0x401121=_0x171e99[0x0])!=null&&_0x401121['fulfilled']&&(_0x2bea0a=_0x171e99[0x0])!=null&&_0x2bea0a['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x21c29a){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x21c29a},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x4f7c07=>{await Or(_0x4f7c07,Dn,'1'),await Dr(_0x4f7c07,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x34643b){this['pendingWrites']++;try{await _0x34643b();}finally{this['pendingWrites']--;}}async['_set'](_0x972da8,_0x2d8a1b){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x1c4e98=>Or(_0x1c4e98,_0x972da8,_0x2d8a1b)),this['localCache'][_0x972da8]=_0x2d8a1b,this['notifyServiceWorker'](_0x972da8)));}async['_get'](_0x2289d4){const _0x27e920=await this['_withRetries'](_0x186a86=>gp(_0x186a86,_0x2289d4));return this['localCache'][_0x2289d4]=_0x27e920,_0x27e920;}async['_remove'](_0x38455b){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x3e9f9e=>Dr(_0x3e9f9e,_0x38455b)),delete this['localCache'][_0x38455b],this['notifyServiceWorker'](_0x38455b)));}async['_poll'](){const _0x2087ec=await this['_withRetries'](_0x2de571=>{const _0x10c80d=Zn(_0x2de571,!0x1)['getAll']();return new nn(_0x10c80d)['toPromise']();});if(!_0x2087ec)return[];if(this['pendingWrites']!==0x0)return[];const _0x2c4814=[],_0x1759b3=new Set();if(_0x2087ec['length']!==0x0){for(const {fbase_key:_0x37b473,value:_0x50d39f}of _0x2087ec)_0x1759b3['add'](_0x37b473),JSON['stringify'](this['localCache'][_0x37b473])!==JSON['stringify'](_0x50d39f)&&(this['notifyListeners'](_0x37b473,_0x50d39f),_0x2c4814['push'](_0x37b473));}for(const _0x2ef5d9 of Object['keys'](this['localCache']))this['localCache'][_0x2ef5d9]&&!_0x1759b3['has'](_0x2ef5d9)&&(this['notifyListeners'](_0x2ef5d9,null),_0x2c4814['push'](_0x2ef5d9));return _0x2c4814;}['notifyListeners'](_0x5d935d,_0x5686e4){this['localCache'][_0x5d935d]=_0x5686e4;const _0x22f011=this['listeners'][_0x5d935d];if(_0x22f011){for(const _0x3f554d of Array['from'](_0x22f011))_0x3f554d(_0x5686e4);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x6a4beb,_0x2bcc39){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x6a4beb]||(this['listeners'][_0x6a4beb]=new Set(),this['_get'](_0x6a4beb)),this['listeners'][_0x6a4beb]['add'](_0x2bcc39);}['_removeListener'](_0x15011f,_0x45bbf1){this['listeners'][_0x15011f]&&(this['listeners'][_0x15011f]['delete'](_0x45bbf1),this['listeners'][_0x15011f]['size']===0x0&&delete this['listeners'][_0x15011f]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x53beda,_0x4fde41){return _0x4fde41?ie(_0x4fde41):(m(_0x53beda['_popupRedirectResolver'],_0x53beda,'argument-error'),_0x53beda['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x3fd92d){super('custom','custom'),this['params']=_0x3fd92d;}['_getIdTokenResponse'](_0x5c3f73){return nt(_0x5c3f73,this['_buildIdpRequest']());}['_linkToIdToken'](_0x49c0d3,_0xb05d64){return nt(_0x49c0d3,this['_buildIdpRequest'](_0xb05d64));}['_getReauthenticationResolver'](_0x3085c3){return nt(_0x3085c3,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x165450){const _0x7a9ca5={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x165450&&(_0x7a9ca5['idToken']=_0x165450),_0x7a9ca5;}}function Ip(_0x17c67f){return Va(_0x17c67f['auth'],new ks(_0x17c67f),_0x17c67f['bypassAuthState']);}function wp(_0x9319ca){const {auth:_0x12b6f0,user:_0x4e857d}=_0x9319ca;return m(_0x4e857d,_0x12b6f0,'internal-error'),tp(_0x4e857d,new ks(_0x9319ca),_0x9319ca['bypassAuthState']);}async function Cp(_0x50d15e){const {auth:_0x9689cc,user:_0x142c1a}=_0x50d15e;return m(_0x142c1a,_0x9689cc,'internal-error'),ep(_0x142c1a,new ks(_0x50d15e),_0x50d15e['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x41844b,_0x5c8e5e,_0x5adac7,_0xb6c05c,_0x31aae2=!0x1){this['auth']=_0x41844b,this['resolver']=_0x5adac7,this['user']=_0xb6c05c,this['bypassAuthState']=_0x31aae2,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x5c8e5e)?_0x5c8e5e:[_0x5c8e5e];}['execute'](){return new Promise(async(_0x5252b5,_0x3e7bcd)=>{this['pendingPromise']={'resolve':_0x5252b5,'reject':_0x3e7bcd};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x533d32){this['reject'](_0x533d32);}});}async['onAuthEvent'](_0x1ba858){const {urlResponse:_0x5704ad,sessionId:_0x1cbd9c,postBody:_0x3043d6,tenantId:_0x352bb5,error:_0x5aaf76,type:_0x538871}=_0x1ba858;if(_0x5aaf76){this['reject'](_0x5aaf76);return;}const _0x1762bf={'auth':this['auth'],'requestUri':_0x5704ad,'sessionId':_0x1cbd9c,'tenantId':_0x352bb5||void 0x0,'postBody':_0x3043d6||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x538871)(_0x1762bf));}catch(_0x188348){this['reject'](_0x188348);}}['onError'](_0x495b39){this['reject'](_0x495b39);}['getIdpTask'](_0x1e6b52){switch(_0x1e6b52){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x259b84){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x259b84),this['unregisterAndCleanUp']();}['reject'](_0x40eabe){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x40eabe),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x293865,_0xd58091,_0x3e36dc,_0x58985b,_0x495719){super(_0x293865,_0xd58091,_0x58985b,_0x495719),this['provider']=_0x3e36dc,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x468260=await this['execute']();return m(_0x468260,this['auth'],'internal-error'),_0x468260;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x49df3f=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x49df3f),this['authWindow']['associatedEvent']=_0x49df3f,this['resolver']['_originValidation'](this['auth'])['catch'](_0x1cc373=>{this['reject'](_0x1cc373);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x431490=>{_0x431490||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x3f6fd8;return((_0x3f6fd8=this['authWindow'])==null?void 0x0:_0x3f6fd8['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x590e0c=()=>{var _0x2cc20c,_0x6b4146;if((_0x6b4146=(_0x2cc20c=this['authWindow'])==null?void 0x0:_0x2cc20c['window'])!=null&&_0x6b4146['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x590e0c,Tp['get']());};_0x590e0c();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x4b1a48,_0x5cc3da,_0x49f236=!0x1){super(_0x4b1a48,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x5cc3da,void 0x0,_0x49f236),this['eventId']=null;}async['execute'](){let _0x3ad848=hn['get'](this['auth']['_key']());if(!_0x3ad848){try{const _0x19b32c=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x3ad848=()=>Promise['resolve'](_0x19b32c);}catch(_0x5b25b6){_0x3ad848=()=>Promise['reject'](_0x5b25b6);}hn['set'](this['auth']['_key'](),_0x3ad848);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x3ad848();}async['onAuthEvent'](_0xac10b4){if(_0xac10b4['type']==='signInViaRedirect')return super['onAuthEvent'](_0xac10b4);if(_0xac10b4['type']==='unknown'){this['resolve'](null);return;}if(_0xac10b4['eventId']){const _0x1af9cc=await this['auth']['_redirectUserForId'](_0xac10b4['eventId']);if(_0x1af9cc)return this['user']=_0x1af9cc,super['onAuthEvent'](_0xac10b4);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x44a2c7,_0x4968df){const _0x445328=Pp(_0x4968df),_0x2dd3d7=kp(_0x44a2c7);if(!await _0x2dd3d7['_isAvailable']())return!0x1;const _0x33695d=await _0x2dd3d7['_get'](_0x445328)==='true';return await _0x2dd3d7['_remove'](_0x445328),_0x33695d;}function Ap(_0x446b76,_0x3781ed){hn['set'](_0x446b76['_key'](),_0x3781ed);}function kp(_0xcbe149){return ie(_0xcbe149['_redirectPersistence']);}function Pp(_0x461c76){return ln(Sp,_0x461c76['config']['apiKey'],_0x461c76['name']);}async function Np(_0x13783a,_0x16330c,_0x539462=!0x1){if($(_0x13783a['app']))return Promise['reject'](re(_0x13783a));const _0x171111=Ke(_0x13783a),_0x5ec3a7=Ep(_0x171111,_0x16330c),_0x39b853=await new bp(_0x171111,_0x5ec3a7,_0x539462)['execute']();return _0x39b853&&!_0x539462&&(delete _0x39b853['user']['_redirectEventId'],await _0x171111['_persistUserIfCurrent'](_0x39b853['user']),await _0x171111['_setRedirectUser'](null,_0x16330c)),_0x39b853;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x50da62){this['auth']=_0x50da62,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x2600c6){this['consumers']['add'](_0x2600c6),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x2600c6)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x2600c6),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0xcf10cb){this['consumers']['delete'](_0xcf10cb);}['onEvent'](_0xff23c){if(this['hasEventBeenHandled'](_0xff23c))return!0x1;let _0x286001=!0x1;return this['consumers']['forEach'](_0x324992=>{this['isEventForConsumer'](_0xff23c,_0x324992)&&(_0x286001=!0x0,this['sendToConsumer'](_0xff23c,_0x324992),this['saveEventToCache'](_0xff23c));}),this['hasHandledPotentialRedirect']||!Mp(_0xff23c)||(this['hasHandledPotentialRedirect']=!0x0,_0x286001||(this['queuedRedirectEvent']=_0xff23c,_0x286001=!0x0)),_0x286001;}['sendToConsumer'](_0x377461,_0x5827f7){var _0x2f69df;if(_0x377461['error']&&!Za(_0x377461)){const _0x1a8d4c=((_0x2f69df=_0x377461['error']['code'])==null?void 0x0:_0x2f69df['split']('auth/')[0x1])||'internal-error';_0x5827f7['onError'](X(this['auth'],_0x1a8d4c));}else _0x5827f7['onAuthEvent'](_0x377461);}['isEventForConsumer'](_0x770ecc,_0x577146){const _0xa7dbf7=_0x577146['eventId']===null||!!_0x770ecc['eventId']&&_0x770ecc['eventId']===_0x577146['eventId'];return _0x577146['filter']['includes'](_0x770ecc['type'])&&_0xa7dbf7;}['hasEventBeenHandled'](_0x1f1a5b){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x1f1a5b));}['saveEventToCache'](_0x1bdd52){this['cachedEventUids']['add'](Mr(_0x1bdd52)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x52e316){return[_0x52e316['type'],_0x52e316['eventId'],_0x52e316['sessionId'],_0x52e316['tenantId']]['filter'](_0x4c76ca=>_0x4c76ca)['join']('-');}function Za({type:_0x21bdd3,error:_0x20cc76}){return _0x21bdd3==='unknown'&&(_0x20cc76==null?void 0x0:_0x20cc76['code'])==='auth/no-auth-event';}function Mp(_0x84b610){switch(_0x84b610['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x84b610);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x433deb,_0x2a4fe4={}){return Pe(_0x433deb,'GET','/v1/projects',_0x2a4fe4);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x27c4ff){if(_0x27c4ff['config']['emulator'])return;const {authorizedDomains:_0x230e4e}=await Lp(_0x27c4ff);for(const _0x273333 of _0x230e4e)try{if(Wp(_0x273333))return;}catch{}Y(_0x27c4ff,'unauthorized-domain');}function Wp(_0x3aaf4c){const _0x1750be=Mi(),{protocol:_0x5b7ce3,hostname:_0x442900}=new URL(_0x1750be);if(_0x3aaf4c['startsWith']('chrome-extension://')){const _0x74f6da=new URL(_0x3aaf4c);return _0x74f6da['hostname']===''&&_0x442900===''?_0x5b7ce3==='chrome-extension:'&&_0x3aaf4c['replace']('chrome-extension://','')===_0x1750be['replace']('chrome-extension://',''):_0x5b7ce3==='chrome-extension:'&&_0x74f6da['hostname']===_0x442900;}if(!Fp['test'](_0x5b7ce3))return!0x1;if(xp['test'](_0x3aaf4c))return _0x442900===_0x3aaf4c;const _0x56742d=_0x3aaf4c['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x56742d+'|'+_0x56742d+')$','i')['test'](_0x442900);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x3a8db2=Z()['___jsl'];if(_0x3a8db2!=null&&_0x3a8db2['H']){for(const _0x2a454f of Object['keys'](_0x3a8db2['H']))if(_0x3a8db2['H'][_0x2a454f]['r']=_0x3a8db2['H'][_0x2a454f]['r']||[],_0x3a8db2['H'][_0x2a454f]['L']=_0x3a8db2['H'][_0x2a454f]['L']||[],_0x3a8db2['H'][_0x2a454f]['r']=[..._0x3a8db2['H'][_0x2a454f]['L']],_0x3a8db2['CP']){for(let _0x25c1bb=0x0;_0x25c1bb<_0x3a8db2['CP']['length'];_0x25c1bb++)_0x3a8db2['CP'][_0x25c1bb]=null;}}}function Vp(_0x43377c){return new Promise((_0x59b930,_0x161b96)=>{var _0x39c381,_0x463cf1,_0x14ac66;function _0x5587b2(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x59b930(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x161b96(X(_0x43377c,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x463cf1=(_0x39c381=Z()['gapi'])==null?void 0x0:_0x39c381['iframes'])!=null&&_0x463cf1['Iframe'])_0x59b930(gapi['iframes']['getContext']());else{if((_0x14ac66=Z()['gapi'])!=null&&_0x14ac66['load'])_0x5587b2();else{const _0x4f962e=Ff('iframefcb');return Z()[_0x4f962e]=()=>{gapi['load']?_0x5587b2():_0x161b96(X(_0x43377c,'network-request-failed'));},xa(xf()+'?onload='+_0x4f962e)['catch'](_0x63b2d9=>_0x161b96(_0x63b2d9));}}})['catch'](_0x11c526=>{throw un=null,_0x11c526;});}let un=null;function Hp(_0x4d94a2){return un=un||Vp(_0x4d94a2),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x5523c1){const _0x51585d=_0x5523c1['config'];m(_0x51585d['authDomain'],_0x5523c1,'auth-domain-config-required');const _0x29b54a=_0x51585d['emulator']?Cs(_0x51585d,qp):'https://'+_0x5523c1['config']['authDomain']+'/'+Gp,_0x32a5bd={'apiKey':_0x51585d['apiKey'],'appName':_0x5523c1['name'],'v':dt},_0x561a02=jp['get'](_0x5523c1['config']['apiHost']);_0x561a02&&(_0x32a5bd['eid']=_0x561a02);const _0x4467f6=_0x5523c1['_getFrameworks']();return _0x4467f6['length']&&(_0x32a5bd['fw']=_0x4467f6['join'](',')),_0x29b54a+'?'+ut(_0x32a5bd)['slice'](0x1);}async function Yp(_0x449183){const _0x163820=await Hp(_0x449183),_0x3606fb=Z()['gapi'];return m(_0x3606fb,_0x449183,'internal-error'),_0x163820['open']({'where':document['body'],'url':Kp(_0x449183),'messageHandlersFilter':_0x3606fb['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x134e7e=>new Promise(async(_0x5369f6,_0x79b43b)=>{await _0x134e7e['restyle']({'setHideOnLeave':!0x1});const _0x57a3da=X(_0x449183,'network-request-failed'),_0x3a2128=Z()['setTimeout'](()=>{_0x79b43b(_0x57a3da);},$p['get']());function _0x51cd62(){Z()['clearTimeout'](_0x3a2128),_0x5369f6(_0x134e7e);}_0x134e7e['ping'](_0x51cd62)['then'](_0x51cd62,()=>{_0x79b43b(_0x57a3da);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x3929a5){this['window']=_0x3929a5,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x239aa2,_0x154855,_0x4c1bf4,_0x530608=Jp,_0x31a749=Xp){const _0x112e71=Math['max']((window['screen']['availHeight']-_0x31a749)/0x2,0x0)['toString'](),_0x834aa7=Math['max']((window['screen']['availWidth']-_0x530608)/0x2,0x0)['toString']();let _0x358437='';const _0x2f0e65={...Qp,'width':_0x530608['toString'](),'height':_0x31a749['toString'](),'top':_0x112e71,'left':_0x834aa7},_0x58f473=W()['toLowerCase']();_0x4c1bf4&&(_0x358437=ka(_0x58f473)?Zp:_0x4c1bf4),Ra(_0x58f473)&&(_0x154855=_0x154855||e_,_0x2f0e65['scrollbars']='yes');const _0xf99b0d=Object['entries'](_0x2f0e65)['reduce']((_0x2c0135,[_0x1db9b7,_0x9cc982])=>''+_0x2c0135+_0x1db9b7+'='+_0x9cc982+',','');if(Rf(_0x58f473)&&_0x358437!=='_self')return n_(_0x154855||'',_0x358437),new xr(null);const _0x115c86=window['open'](_0x154855||'',_0x358437,_0xf99b0d);m(_0x115c86,_0x239aa2,'popup-blocked');try{_0x115c86['focus']();}catch{}return new xr(_0x115c86);}function n_(_0x51036e,_0xf998f3){const _0x20ac00=document['createElement']('a');_0x20ac00['href']=_0x51036e,_0x20ac00['target']=_0xf998f3;const _0x2948e1=document['createEvent']('MouseEvent');_0x2948e1['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x20ac00['dispatchEvent'](_0x2948e1);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x31aef6,_0x255312,_0xdab6a2,_0x375226,_0xe95b08,_0x422d5a){m(_0x31aef6['config']['authDomain'],_0x31aef6,'auth-domain-config-required'),m(_0x31aef6['config']['apiKey'],_0x31aef6,'invalid-api-key');const _0x426a42={'apiKey':_0x31aef6['config']['apiKey'],'appName':_0x31aef6['name'],'authType':_0xdab6a2,'redirectUrl':_0x375226,'v':dt,'eventId':_0xe95b08};if(_0x255312 instanceof Wa){_0x255312['setDefaultLanguage'](_0x31aef6['languageCode']),_0x426a42['providerId']=_0x255312['providerId']||'',pn(_0x255312['getCustomParameters']())||(_0x426a42['customParameters']=JSON['stringify'](_0x255312['getCustomParameters']()));for(const [_0x206807,_0x18a3f]of Object['entries']({}))_0x426a42[_0x206807]=_0x18a3f;}if(_0x255312 instanceof tn){const _0x48f892=_0x255312['getScopes']()['filter'](_0x4af1f6=>_0x4af1f6!=='');_0x48f892['length']>0x0&&(_0x426a42['scopes']=_0x48f892['join'](','));}_0x31aef6['tenantId']&&(_0x426a42['tid']=_0x31aef6['tenantId']);const _0x218b82=_0x426a42;for(const _0x5a727c of Object['keys'](_0x218b82))_0x218b82[_0x5a727c]===void 0x0&&delete _0x218b82[_0x5a727c];const _0x1d4444=await _0x31aef6['_getAppCheckToken'](),_0x57464a=_0x1d4444?'#'+r_+'='+encodeURIComponent(_0x1d4444):'';return o_(_0x31aef6)+'?'+ut(_0x218b82)['slice'](0x1)+_0x57464a;}function o_({config:_0x7c8d0}){return _0x7c8d0['emulator']?Cs(_0x7c8d0,s_):'https://'+_0x7c8d0['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x5387ab,_0x1eb8c2,_0x2fcdc2,_0x17cca4){var _0x99634b;ce((_0x99634b=this['eventManagers'][_0x5387ab['_key']()])==null?void 0x0:_0x99634b['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x171bd8=await Fr(_0x5387ab,_0x1eb8c2,_0x2fcdc2,Mi(),_0x17cca4);return t_(_0x5387ab,_0x171bd8,As());}async['_openRedirect'](_0x2cee92,_0x53b41b,_0x9e6c97,_0x5db49c){await this['_originValidation'](_0x2cee92);const _0x9ff20=await Fr(_0x2cee92,_0x53b41b,_0x9e6c97,Mi(),_0x5db49c);return hp(_0x9ff20),new Promise(()=>{});}['_initialize'](_0x4c6931){const _0x2b7d01=_0x4c6931['_key']();if(this['eventManagers'][_0x2b7d01]){const {manager:_0x22668a,promise:_0x2a1df2}=this['eventManagers'][_0x2b7d01];return _0x22668a?Promise['resolve'](_0x22668a):(ce(_0x2a1df2,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x2a1df2);}const _0x19a760=this['initAndGetManager'](_0x4c6931);return this['eventManagers'][_0x2b7d01]={'promise':_0x19a760},_0x19a760['catch'](()=>{delete this['eventManagers'][_0x2b7d01];}),_0x19a760;}async['initAndGetManager'](_0x366c60){const _0x2dfa4a=await Yp(_0x366c60),_0x512c8d=new Dp(_0x366c60);return _0x2dfa4a['register']('authEvent',_0x282877=>(m(_0x282877==null?void 0x0:_0x282877['authEvent'],_0x366c60,'invalid-auth-event'),{'status':_0x512c8d['onEvent'](_0x282877['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x366c60['_key']()]={'manager':_0x512c8d},this['iframes'][_0x366c60['_key']()]=_0x2dfa4a,_0x512c8d;}['_isIframeWebStorageSupported'](_0xd82649,_0xae8042){this['iframes'][_0xd82649['_key']()]['send'](pi,{'type':pi},_0x29ec43=>{var _0x41b3b0;const _0x13efe0=(_0x41b3b0=_0x29ec43==null?void 0x0:_0x29ec43[0x0])==null?void 0x0:_0x41b3b0[pi];_0x13efe0!==void 0x0&&_0xae8042(!!_0x13efe0),Y(_0xd82649,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0xbd1d90){const _0x37f880=_0xbd1d90['_key']();return this['originValidationPromises'][_0x37f880]||(this['originValidationPromises'][_0x37f880]=Up(_0xbd1d90)),this['originValidationPromises'][_0x37f880];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x2aca04){this['auth']=_0x2aca04,this['internalListeners']=new Map();}['getUid'](){var _0x451de1;return this['assertAuthConfigured'](),((_0x451de1=this['auth']['currentUser'])==null?void 0x0:_0x451de1['uid'])||null;}async['getToken'](_0xc33a70){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0xc33a70)}:null;}['addAuthTokenListener'](_0x47eff9){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x47eff9))return;const _0x4288be=this['auth']['onIdTokenChanged'](_0x3b43b3=>{_0x47eff9((_0x3b43b3==null?void 0x0:_0x3b43b3['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x47eff9,_0x4288be),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x59230c){this['assertAuthConfigured']();const _0x4eaa27=this['internalListeners']['get'](_0x59230c);_0x4eaa27&&(this['internalListeners']['delete'](_0x59230c),_0x4eaa27(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x1638bf){switch(_0x1638bf){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0xcaa0ea){st(new Fe('auth',(_0xb54146,{options:_0x3411ab})=>{const _0x9266b7=_0xb54146['getProvider']('app')['getImmediate'](),_0x452a83=_0xb54146['getProvider']('heartbeat'),_0x4cdbce=_0xb54146['getProvider']('app-check-internal'),{apiKey:_0x4f44c7,authDomain:_0x15a00f}=_0x9266b7['options'];m(_0x4f44c7&&!_0x4f44c7['includes'](':'),'invalid-api-key',{'appName':_0x9266b7['name']});const _0x596d12={'apiKey':_0x4f44c7,'authDomain':_0x15a00f,'clientPlatform':_0xcaa0ea,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0xcaa0ea)},_0x49cc57=new Df(_0x9266b7,_0x452a83,_0x4cdbce,_0x596d12);return Hf(_0x49cc57,_0x3411ab),_0x49cc57;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x1e6083,_0x61e3b7,_0x291530)=>{_0x1e6083['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x15c505=>{const _0x1459d5=Ke(_0x15c505['getProvider']('auth')['getImmediate']());return(_0x203bab=>new l_(_0x203bab))(_0x1459d5);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0xcaa0ea)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x428480=>async _0x33f230=>{const _0x44bfe7=_0x33f230&&await _0x33f230['getIdTokenResult'](),_0x7a523e=_0x44bfe7&&(new Date()['getTime']()-Date['parse'](_0x44bfe7['issuedAtTime']))/0x3e8;if(_0x7a523e&&_0x7a523e>f_)return;const _0x13c6ef=_0x44bfe7==null?void 0x0:_0x44bfe7['token'];Br!==_0x13c6ef&&(Br=_0x13c6ef,await fetch(_0x428480,{'method':_0x13c6ef?'POST':'DELETE','headers':_0x13c6ef?{'Authorization':'Bearer\x20'+_0x13c6ef}:{}}));};function B_(_0x375b83=Zr()){const _0x147f3a=Hi(_0x375b83,'auth');if(_0x147f3a['isInitialized']())return _0x147f3a['getImmediate']();const _0x40beed=Vf(_0x375b83,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x1e11fe=jr('authTokenSyncURL');if(_0x1e11fe&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x409084=new URL(_0x1e11fe,location['origin']);if(location['origin']===_0x409084['origin']){const _0x38da68=p_(_0x409084['toString']());sp(_0x40beed,_0x38da68,()=>_0x38da68(_0x40beed['currentUser'])),ip(_0x40beed,_0x405025=>_0x38da68(_0x405025));}}const _0x5d057b=qr('auth');return _0x5d057b&&$f(_0x40beed,'http://'+_0x5d057b),_0x40beed;}function __(){var _0xe32e0;return((_0xe32e0=document['getElementsByTagName']('head'))==null?void 0x0:_0xe32e0[0x0])??document;}Mf({'loadJS'(_0x4087f9){return new Promise((_0x24ff69,_0x550a3b)=>{const _0x495666=document['createElement']('script');_0x495666['setAttribute']('src',_0x4087f9),_0x495666['onload']=_0x24ff69,_0x495666['onerror']=_0x1a5e42=>{const _0x456675=X('internal-error');_0x456675['customData']=_0x1a5e42,_0x550a3b(_0x456675);},_0x495666['type']='text/javascript',_0x495666['charset']='UTF-8',__()['appendChild'](_0x495666);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,B_ as a,ap as b,x_ as c,g_ as d,m_ as e,Zr as f,P_ as g,Hd as h,Sl as i,D_ as j,Gd as k,w_ as l,b_ as m,A_ as n,v_ as o,E_ as p,k_ as q,y_ as r,F_ as s,Vt as t,I_ as u,N_ as v,U_ as w,O_ as x,M_ as y,T_ as z};