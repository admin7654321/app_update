const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x1548b9,_0x589cf9){if(!_0x1548b9)throw ht(_0x589cf9);},ht=function(_0x1b234e){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x1b234e);},Hr=function(_0x42723d){const _0x4b0e7e=[];let _0x2fef86=0x0;for(let _0x3eb440=0x0;_0x3eb440<_0x42723d['length'];_0x3eb440++){let _0x556d10=_0x42723d['charCodeAt'](_0x3eb440);_0x556d10<0x80?_0x4b0e7e[_0x2fef86++]=_0x556d10:_0x556d10<0x800?(_0x4b0e7e[_0x2fef86++]=_0x556d10>>0x6|0xc0,_0x4b0e7e[_0x2fef86++]=_0x556d10&0x3f|0x80):(_0x556d10&0xfc00)===0xd800&&_0x3eb440+0x1<_0x42723d['length']&&(_0x42723d['charCodeAt'](_0x3eb440+0x1)&0xfc00)===0xdc00?(_0x556d10=0x10000+((_0x556d10&0x3ff)<<0xa)+(_0x42723d['charCodeAt'](++_0x3eb440)&0x3ff),_0x4b0e7e[_0x2fef86++]=_0x556d10>>0x12|0xf0,_0x4b0e7e[_0x2fef86++]=_0x556d10>>0xc&0x3f|0x80,_0x4b0e7e[_0x2fef86++]=_0x556d10>>0x6&0x3f|0x80,_0x4b0e7e[_0x2fef86++]=_0x556d10&0x3f|0x80):(_0x4b0e7e[_0x2fef86++]=_0x556d10>>0xc|0xe0,_0x4b0e7e[_0x2fef86++]=_0x556d10>>0x6&0x3f|0x80,_0x4b0e7e[_0x2fef86++]=_0x556d10&0x3f|0x80);}return _0x4b0e7e;},nc=function(_0x286510){const _0x419919=[];let _0x5a4761=0x0,_0x53537e=0x0;for(;_0x5a4761<_0x286510['length'];){const _0x363e3a=_0x286510[_0x5a4761++];if(_0x363e3a<0x80)_0x419919[_0x53537e++]=String['fromCharCode'](_0x363e3a);else{if(_0x363e3a>0xbf&&_0x363e3a<0xe0){const _0x43fe22=_0x286510[_0x5a4761++];_0x419919[_0x53537e++]=String['fromCharCode']((_0x363e3a&0x1f)<<0x6|_0x43fe22&0x3f);}else{if(_0x363e3a>0xef&&_0x363e3a<0x16d){const _0x2ba4e8=_0x286510[_0x5a4761++],_0x441ae6=_0x286510[_0x5a4761++],_0x5f1919=_0x286510[_0x5a4761++],_0x3f32d4=((_0x363e3a&0x7)<<0x12|(_0x2ba4e8&0x3f)<<0xc|(_0x441ae6&0x3f)<<0x6|_0x5f1919&0x3f)-0x10000;_0x419919[_0x53537e++]=String['fromCharCode'](0xd800+(_0x3f32d4>>0xa)),_0x419919[_0x53537e++]=String['fromCharCode'](0xdc00+(_0x3f32d4&0x3ff));}else{const _0x25f5e0=_0x286510[_0x5a4761++],_0x1be9a2=_0x286510[_0x5a4761++];_0x419919[_0x53537e++]=String['fromCharCode']((_0x363e3a&0xf)<<0xc|(_0x25f5e0&0x3f)<<0x6|_0x1be9a2&0x3f);}}}}return _0x419919['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x38fb9d,_0xe384ff){if(!Array['isArray'](_0x38fb9d))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x13caee=_0xe384ff?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x1754a7=[];for(let _0x3d3ab1=0x0;_0x3d3ab1<_0x38fb9d['length'];_0x3d3ab1+=0x3){const _0x26ffa4=_0x38fb9d[_0x3d3ab1],_0x548d02=_0x3d3ab1+0x1<_0x38fb9d['length'],_0x208f5d=_0x548d02?_0x38fb9d[_0x3d3ab1+0x1]:0x0,_0xd1eac4=_0x3d3ab1+0x2<_0x38fb9d['length'],_0x19146a=_0xd1eac4?_0x38fb9d[_0x3d3ab1+0x2]:0x0,_0x33d509=_0x26ffa4>>0x2,_0xba8f94=(_0x26ffa4&0x3)<<0x4|_0x208f5d>>0x4;let _0x26f0e5=(_0x208f5d&0xf)<<0x2|_0x19146a>>0x6,_0x830112=_0x19146a&0x3f;_0xd1eac4||(_0x830112=0x40,_0x548d02||(_0x26f0e5=0x40)),_0x1754a7['push'](_0x13caee[_0x33d509],_0x13caee[_0xba8f94],_0x13caee[_0x26f0e5],_0x13caee[_0x830112]);}return _0x1754a7['join']('');},'encodeString'(_0x224363,_0x2fa0ee){return this['HAS_NATIVE_SUPPORT']&&!_0x2fa0ee?btoa(_0x224363):this['encodeByteArray'](Hr(_0x224363),_0x2fa0ee);},'decodeString'(_0x2d0ede,_0x4b2245){return this['HAS_NATIVE_SUPPORT']&&!_0x4b2245?atob(_0x2d0ede):nc(this['decodeStringToByteArray'](_0x2d0ede,_0x4b2245));},'decodeStringToByteArray'(_0x124f2d,_0x5050e5){this['init_']();const _0x6e60ec=_0x5050e5?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x44d38b=[];for(let _0x192048=0x0;_0x192048<_0x124f2d['length'];){const _0x1a51ca=_0x6e60ec[_0x124f2d['charAt'](_0x192048++)],_0x289630=_0x192048<_0x124f2d['length']?_0x6e60ec[_0x124f2d['charAt'](_0x192048)]:0x0;++_0x192048;const _0x41a035=_0x192048<_0x124f2d['length']?_0x6e60ec[_0x124f2d['charAt'](_0x192048)]:0x40;++_0x192048;const _0x41c43b=_0x192048<_0x124f2d['length']?_0x6e60ec[_0x124f2d['charAt'](_0x192048)]:0x40;if(++_0x192048,_0x1a51ca==null||_0x289630==null||_0x41a035==null||_0x41c43b==null)throw new ic();const _0x3063bd=_0x1a51ca<<0x2|_0x289630>>0x4;if(_0x44d38b['push'](_0x3063bd),_0x41a035!==0x40){const _0x34f52b=_0x289630<<0x4&0xf0|_0x41a035>>0x2;if(_0x44d38b['push'](_0x34f52b),_0x41c43b!==0x40){const _0x1ec923=_0x41a035<<0x6&0xc0|_0x41c43b;_0x44d38b['push'](_0x1ec923);}}}return _0x44d38b;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x210260=0x0;_0x210260<this['ENCODED_VALS']['length'];_0x210260++)this['byteToCharMap_'][_0x210260]=this['ENCODED_VALS']['charAt'](_0x210260),this['charToByteMap_'][this['byteToCharMap_'][_0x210260]]=_0x210260,this['byteToCharMapWebSafe_'][_0x210260]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x210260),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x210260]]=_0x210260,_0x210260>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x210260)]=_0x210260,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x210260)]=_0x210260);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x377a3c){const _0x599087=Hr(_0x377a3c);return Fi['encodeByteArray'](_0x599087,!0x0);},dn=function(_0x5b1a4c){return $r(_0x5b1a4c)['replace'](/\./g,'');},fn=function(_0x1efe94){try{return Fi['decodeString'](_0x1efe94,!0x0);}catch(_0x21d1f0){console['error']('base64Decode\x20failed:\x20',_0x21d1f0);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x16f38f){return Gr(void 0x0,_0x16f38f);}function Gr(_0x10eb9d,_0x44926f){if(!(_0x44926f instanceof Object))return _0x44926f;switch(_0x44926f['constructor']){case Date:const _0x392b6d=_0x44926f;return new Date(_0x392b6d['getTime']());case Object:_0x10eb9d===void 0x0&&(_0x10eb9d={});break;case Array:_0x10eb9d=[];break;default:return _0x44926f;}for(const _0x17d3b8 in _0x44926f)!_0x44926f['hasOwnProperty'](_0x17d3b8)||!rc(_0x17d3b8)||(_0x10eb9d[_0x17d3b8]=Gr(_0x10eb9d[_0x17d3b8],_0x44926f[_0x17d3b8]));return _0x10eb9d;}function rc(_0x1e80b1){return _0x1e80b1!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x486ca1=Ps['__FIREBASE_DEFAULTS__'];if(_0x486ca1)return JSON['parse'](_0x486ca1);},lc=()=>{if(typeof document>'u')return;let _0x26831e;try{_0x26831e=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x110465=_0x26831e&&fn(_0x26831e[0x1]);return _0x110465&&JSON['parse'](_0x110465);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x467f11){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x467f11);return;}},qr=_0x54a6cb=>{var _0x21c509,_0x4e4481;return(_0x4e4481=(_0x21c509=Ui())==null?void 0x0:_0x21c509['emulatorHosts'])==null?void 0x0:_0x4e4481[_0x54a6cb];},hc=_0x306ae7=>{const _0xfea198=qr(_0x306ae7);if(!_0xfea198)return;const _0x7826f8=_0xfea198['lastIndexOf'](':');if(_0x7826f8<=0x0||_0x7826f8+0x1===_0xfea198['length'])throw new Error('Invalid\x20host\x20'+_0xfea198+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x144781=parseInt(_0xfea198['substring'](_0x7826f8+0x1),0xa);return _0xfea198[0x0]==='['?[_0xfea198['substring'](0x1,_0x7826f8-0x1),_0x144781]:[_0xfea198['substring'](0x0,_0x7826f8),_0x144781];},zr=()=>{var _0x4f65b8;return(_0x4f65b8=Ui())==null?void 0x0:_0x4f65b8['config'];},jr=_0x3f314c=>{var _0x366d1c;return(_0x366d1c=Ui())==null?void 0x0:_0x366d1c['_'+_0x3f314c];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x2929b9,_0x27dbcd)=>{this['resolve']=_0x2929b9,this['reject']=_0x27dbcd;});}['wrapCallback'](_0x11c157){return(_0x13162c,_0x1242b3)=>{_0x13162c?this['reject'](_0x13162c):this['resolve'](_0x1242b3),typeof _0x11c157=='function'&&(this['promise']['catch'](()=>{}),_0x11c157['length']===0x1?_0x11c157(_0x13162c):_0x11c157(_0x13162c,_0x1242b3));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x468972,_0x2abea9){if(_0x468972['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x9832a1={'alg':'none','type':'JWT'},_0x595783=_0x2abea9||'demo-project',_0x1a35f7=_0x468972['iat']||0x0,_0x5ad1e4=_0x468972['sub']||_0x468972['user_id'];if(!_0x5ad1e4)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x562e0e={'iss':'https://securetoken.google.com/'+_0x595783,'aud':_0x595783,'iat':_0x1a35f7,'exp':_0x1a35f7+0xe10,'auth_time':_0x1a35f7,'sub':_0x5ad1e4,'user_id':_0x5ad1e4,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x468972};return[dn(JSON['stringify'](_0x9832a1)),dn(JSON['stringify'](_0x562e0e)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x5664c7=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x5664c7=='object'&&_0x5664c7['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x2691dd=W();return _0x2691dd['indexOf']('MSIE\x20')>=0x0||_0x2691dd['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x3dc356,_0x4fa7a2)=>{try{let _0x1bd202=!0x0;const _0x4e344e='validate-browser-context-for-indexeddb-analytics-module',_0x30e84c=self['indexedDB']['open'](_0x4e344e);_0x30e84c['onsuccess']=()=>{_0x30e84c['result']['close'](),_0x1bd202||self['indexedDB']['deleteDatabase'](_0x4e344e),_0x3dc356(!0x0);},_0x30e84c['onupgradeneeded']=()=>{_0x1bd202=!0x1;},_0x30e84c['onerror']=()=>{var _0x2f51b0;_0x4fa7a2(((_0x2f51b0=_0x30e84c['error'])==null?void 0x0:_0x2f51b0['message'])||'');};}catch(_0x404a8b){_0x4fa7a2(_0x404a8b);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x42075b,_0x143458,_0x420ae1){super(_0x143458),this['code']=_0x42075b,this['customData']=_0x420ae1,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x109682,_0x25f4f0,_0x4b33a8){this['service']=_0x109682,this['serviceName']=_0x25f4f0,this['errors']=_0x4b33a8;}['create'](_0x9d8ca6,..._0x3bb41f){const _0x58713f=_0x3bb41f[0x0]||{},_0x2a9ea2=this['service']+'/'+_0x9d8ca6,_0xaaef25=this['errors'][_0x9d8ca6],_0x392e50=_0xaaef25?vc(_0xaaef25,_0x58713f):'Error',_0x32d6f3=this['serviceName']+':\x20'+_0x392e50+'\x20('+_0x2a9ea2+').';return new Re(_0x2a9ea2,_0x32d6f3,_0x58713f);}}function vc(_0x315556,_0x511155){return _0x315556['replace'](Ec,(_0x1a84fb,_0x1c8a2f)=>{const _0x12409b=_0x511155[_0x1c8a2f];return _0x12409b!=null?String(_0x12409b):'<'+_0x1c8a2f+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x439d40){return JSON['parse'](_0x439d40);}function O(_0x8faeb2){return JSON['stringify'](_0x8faeb2);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x542875){let _0xa732a5={},_0x10efee={},_0x5300b8={},_0x252ac3='';try{const _0x4f08c1=_0x542875['split']('.');_0xa732a5=Nt(fn(_0x4f08c1[0x0])||''),_0x10efee=Nt(fn(_0x4f08c1[0x1])||''),_0x252ac3=_0x4f08c1[0x2],_0x5300b8=_0x10efee['d']||{},delete _0x10efee['d'];}catch{}return{'header':_0xa732a5,'claims':_0x10efee,'data':_0x5300b8,'signature':_0x252ac3};},Ic=function(_0x5ce78a){const _0x5ad264=Yr(_0x5ce78a),_0x423f49=_0x5ad264['claims'];return!!_0x423f49&&typeof _0x423f49=='object'&&_0x423f49['hasOwnProperty']('iat');},wc=function(_0x4d8518){const _0x4d1c87=Yr(_0x4d8518)['claims'];return typeof _0x4d1c87=='object'&&_0x4d1c87['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x275717,_0x3a3235){return Object['prototype']['hasOwnProperty']['call'](_0x275717,_0x3a3235);}function Le(_0x162f2a,_0x56cb6e){if(Object['prototype']['hasOwnProperty']['call'](_0x162f2a,_0x56cb6e))return _0x162f2a[_0x56cb6e];}function pn(_0x34cee3){for(const _0x47de8e in _0x34cee3)if(Object['prototype']['hasOwnProperty']['call'](_0x34cee3,_0x47de8e))return!0x1;return!0x0;}function _n(_0x3e555f,_0x3ba056,_0x11abc4){const _0x31344f={};for(const _0x39019c in _0x3e555f)Object['prototype']['hasOwnProperty']['call'](_0x3e555f,_0x39019c)&&(_0x31344f[_0x39019c]=_0x3ba056['call'](_0x11abc4,_0x3e555f[_0x39019c],_0x39019c,_0x3e555f));return _0x31344f;}function xe(_0x2d43f4,_0x2e6150){if(_0x2d43f4===_0x2e6150)return!0x0;const _0x3c6d53=Object['keys'](_0x2d43f4),_0x45cc18=Object['keys'](_0x2e6150);for(const _0x3ddd96 of _0x3c6d53){if(!_0x45cc18['includes'](_0x3ddd96))return!0x1;const _0x48e100=_0x2d43f4[_0x3ddd96],_0x4402f3=_0x2e6150[_0x3ddd96];if(Ns(_0x48e100)&&Ns(_0x4402f3)){if(!xe(_0x48e100,_0x4402f3))return!0x1;}else{if(_0x48e100!==_0x4402f3)return!0x1;}}for(const _0x38fb10 of _0x45cc18)if(!_0x3c6d53['includes'](_0x38fb10))return!0x1;return!0x0;}function Ns(_0xc44b34){return _0xc44b34!==null&&typeof _0xc44b34=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x4c7c51){const _0x23eb77=[];for(const [_0xbc4d47,_0x3348e2]of Object['entries'](_0x4c7c51))Array['isArray'](_0x3348e2)?_0x3348e2['forEach'](_0x28d87f=>{_0x23eb77['push'](encodeURIComponent(_0xbc4d47)+'='+encodeURIComponent(_0x28d87f));}):_0x23eb77['push'](encodeURIComponent(_0xbc4d47)+'='+encodeURIComponent(_0x3348e2));return _0x23eb77['length']?'&'+_0x23eb77['join']('&'):'';}function Ct(_0x2b7117){const _0x15519c={};return _0x2b7117['replace'](/^\?/,'')['split']('&')['forEach'](_0x2d15f6=>{if(_0x2d15f6){const [_0x22b430,_0xcd5e7c]=_0x2d15f6['split']('=');_0x15519c[decodeURIComponent(_0x22b430)]=decodeURIComponent(_0xcd5e7c);}}),_0x15519c;}function Tt(_0xea6dae){const _0x44956a=_0xea6dae['indexOf']('?');if(!_0x44956a)return'';const _0x27d54b=_0xea6dae['indexOf']('#',_0x44956a);return _0xea6dae['substring'](_0x44956a,_0x27d54b>0x0?_0x27d54b:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x182928=0x1;_0x182928<this['blockSize'];++_0x182928)this['pad_'][_0x182928]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x5cb210,_0x2b7621){_0x2b7621||(_0x2b7621=0x0);const _0x1291aa=this['W_'];if(typeof _0x5cb210=='string'){for(let _0x2d88d9=0x0;_0x2d88d9<0x10;_0x2d88d9++)_0x1291aa[_0x2d88d9]=_0x5cb210['charCodeAt'](_0x2b7621)<<0x18|_0x5cb210['charCodeAt'](_0x2b7621+0x1)<<0x10|_0x5cb210['charCodeAt'](_0x2b7621+0x2)<<0x8|_0x5cb210['charCodeAt'](_0x2b7621+0x3),_0x2b7621+=0x4;}else{for(let _0x20b594=0x0;_0x20b594<0x10;_0x20b594++)_0x1291aa[_0x20b594]=_0x5cb210[_0x2b7621]<<0x18|_0x5cb210[_0x2b7621+0x1]<<0x10|_0x5cb210[_0x2b7621+0x2]<<0x8|_0x5cb210[_0x2b7621+0x3],_0x2b7621+=0x4;}for(let _0x128735=0x10;_0x128735<0x50;_0x128735++){const _0xce14a8=_0x1291aa[_0x128735-0x3]^_0x1291aa[_0x128735-0x8]^_0x1291aa[_0x128735-0xe]^_0x1291aa[_0x128735-0x10];_0x1291aa[_0x128735]=(_0xce14a8<<0x1|_0xce14a8>>>0x1f)&0xffffffff;}let _0x4daf4c=this['chain_'][0x0],_0x45d2b9=this['chain_'][0x1],_0x52b7c0=this['chain_'][0x2],_0x12943c=this['chain_'][0x3],_0x35b02b=this['chain_'][0x4],_0x3a3d5a,_0x99db8e;for(let _0xe3bd6a=0x0;_0xe3bd6a<0x50;_0xe3bd6a++){_0xe3bd6a<0x28?_0xe3bd6a<0x14?(_0x3a3d5a=_0x12943c^_0x45d2b9&(_0x52b7c0^_0x12943c),_0x99db8e=0x5a827999):(_0x3a3d5a=_0x45d2b9^_0x52b7c0^_0x12943c,_0x99db8e=0x6ed9eba1):_0xe3bd6a<0x3c?(_0x3a3d5a=_0x45d2b9&_0x52b7c0|_0x12943c&(_0x45d2b9|_0x52b7c0),_0x99db8e=0x8f1bbcdc):(_0x3a3d5a=_0x45d2b9^_0x52b7c0^_0x12943c,_0x99db8e=0xca62c1d6);const _0xfb1e7=(_0x4daf4c<<0x5|_0x4daf4c>>>0x1b)+_0x3a3d5a+_0x35b02b+_0x99db8e+_0x1291aa[_0xe3bd6a]&0xffffffff;_0x35b02b=_0x12943c,_0x12943c=_0x52b7c0,_0x52b7c0=(_0x45d2b9<<0x1e|_0x45d2b9>>>0x2)&0xffffffff,_0x45d2b9=_0x4daf4c,_0x4daf4c=_0xfb1e7;}this['chain_'][0x0]=this['chain_'][0x0]+_0x4daf4c&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x45d2b9&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x52b7c0&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x12943c&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x35b02b&0xffffffff;}['update'](_0x87cd54,_0x3a0033){if(_0x87cd54==null)return;_0x3a0033===void 0x0&&(_0x3a0033=_0x87cd54['length']);const _0x41f0bb=_0x3a0033-this['blockSize'];let _0x38cd9a=0x0;const _0x4027ca=this['buf_'];let _0x469ec2=this['inbuf_'];for(;_0x38cd9a<_0x3a0033;){if(_0x469ec2===0x0){for(;_0x38cd9a<=_0x41f0bb;)this['compress_'](_0x87cd54,_0x38cd9a),_0x38cd9a+=this['blockSize'];}if(typeof _0x87cd54=='string'){for(;_0x38cd9a<_0x3a0033;)if(_0x4027ca[_0x469ec2]=_0x87cd54['charCodeAt'](_0x38cd9a),++_0x469ec2,++_0x38cd9a,_0x469ec2===this['blockSize']){this['compress_'](_0x4027ca),_0x469ec2=0x0;break;}}else{for(;_0x38cd9a<_0x3a0033;)if(_0x4027ca[_0x469ec2]=_0x87cd54[_0x38cd9a],++_0x469ec2,++_0x38cd9a,_0x469ec2===this['blockSize']){this['compress_'](_0x4027ca),_0x469ec2=0x0;break;}}}this['inbuf_']=_0x469ec2,this['total_']+=_0x3a0033;}['digest'](){const _0x2b1ca8=[];let _0x357eb5=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x1e620b=this['blockSize']-0x1;_0x1e620b>=0x38;_0x1e620b--)this['buf_'][_0x1e620b]=_0x357eb5&0xff,_0x357eb5/=0x100;this['compress_'](this['buf_']);let _0x1388b3=0x0;for(let _0x70adce=0x0;_0x70adce<0x5;_0x70adce++)for(let _0xb58925=0x18;_0xb58925>=0x0;_0xb58925-=0x8)_0x2b1ca8[_0x1388b3]=this['chain_'][_0x70adce]>>_0xb58925&0xff,++_0x1388b3;return _0x2b1ca8;}}function Tc(_0x3c9217,_0x4c1a38){const _0x11f654=new Sc(_0x3c9217,_0x4c1a38);return _0x11f654['subscribe']['bind'](_0x11f654);}class Sc{constructor(_0x5847c8,_0xf2808){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0xf2808,this['task']['then'](()=>{_0x5847c8(this);})['catch'](_0x5a4a07=>{this['error'](_0x5a4a07);});}['next'](_0x3d4e90){this['forEachObserver'](_0x4bebf8=>{_0x4bebf8['next'](_0x3d4e90);});}['error'](_0x1a5271){this['forEachObserver'](_0x3240fc=>{_0x3240fc['error'](_0x1a5271);}),this['close'](_0x1a5271);}['complete'](){this['forEachObserver'](_0x5c7b63=>{_0x5c7b63['complete']();}),this['close']();}['subscribe'](_0x56b795,_0x1c86d9,_0x34fe76){let _0x21dffc;if(_0x56b795===void 0x0&&_0x1c86d9===void 0x0&&_0x34fe76===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x56b795,['next','error','complete'])?_0x21dffc=_0x56b795:_0x21dffc={'next':_0x56b795,'error':_0x1c86d9,'complete':_0x34fe76},_0x21dffc['next']===void 0x0&&(_0x21dffc['next']=ti),_0x21dffc['error']===void 0x0&&(_0x21dffc['error']=ti),_0x21dffc['complete']===void 0x0&&(_0x21dffc['complete']=ti);const _0x40a68a=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x21dffc['error'](this['finalError']):_0x21dffc['complete']();}catch{}}),this['observers']['push'](_0x21dffc),_0x40a68a;}['unsubscribeOne'](_0x5cdb25){this['observers']===void 0x0||this['observers'][_0x5cdb25]===void 0x0||(delete this['observers'][_0x5cdb25],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x56443d){if(!this['finalized']){for(let _0x3e93cb=0x0;_0x3e93cb<this['observers']['length'];_0x3e93cb++)this['sendOne'](_0x3e93cb,_0x56443d);}}['sendOne'](_0x3724a7,_0x3d98d4){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x3724a7]!==void 0x0)try{_0x3d98d4(this['observers'][_0x3724a7]);}catch(_0x3f4a08){typeof console<'u'&&console['error']&&console['error'](_0x3f4a08);}});}['close'](_0x18ddfc){this['finalized']||(this['finalized']=!0x0,_0x18ddfc!==void 0x0&&(this['finalError']=_0x18ddfc),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x56abb7,_0x27b7cc){if(typeof _0x56abb7!='object'||_0x56abb7===null)return!0x1;for(const _0x458700 of _0x27b7cc)if(_0x458700 in _0x56abb7&&typeof _0x56abb7[_0x458700]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x31b79c,_0x492056){return _0x31b79c+'\x20failed:\x20'+_0x492056+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x22f5c4){const _0x23e7c7=[];let _0x384e6d=0x0;for(let _0x9a7ffc=0x0;_0x9a7ffc<_0x22f5c4['length'];_0x9a7ffc++){let _0x2fb458=_0x22f5c4['charCodeAt'](_0x9a7ffc);if(_0x2fb458>=0xd800&&_0x2fb458<=0xdbff){const _0x4a703c=_0x2fb458-0xd800;_0x9a7ffc++,f(_0x9a7ffc<_0x22f5c4['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x152687=_0x22f5c4['charCodeAt'](_0x9a7ffc)-0xdc00;_0x2fb458=0x10000+(_0x4a703c<<0xa)+_0x152687;}_0x2fb458<0x80?_0x23e7c7[_0x384e6d++]=_0x2fb458:_0x2fb458<0x800?(_0x23e7c7[_0x384e6d++]=_0x2fb458>>0x6|0xc0,_0x23e7c7[_0x384e6d++]=_0x2fb458&0x3f|0x80):_0x2fb458<0x10000?(_0x23e7c7[_0x384e6d++]=_0x2fb458>>0xc|0xe0,_0x23e7c7[_0x384e6d++]=_0x2fb458>>0x6&0x3f|0x80,_0x23e7c7[_0x384e6d++]=_0x2fb458&0x3f|0x80):(_0x23e7c7[_0x384e6d++]=_0x2fb458>>0x12|0xf0,_0x23e7c7[_0x384e6d++]=_0x2fb458>>0xc&0x3f|0x80,_0x23e7c7[_0x384e6d++]=_0x2fb458>>0x6&0x3f|0x80,_0x23e7c7[_0x384e6d++]=_0x2fb458&0x3f|0x80);}return _0x23e7c7;},Ln=function(_0x101a2f){let _0x5bc351=0x0;for(let _0x22e658=0x0;_0x22e658<_0x101a2f['length'];_0x22e658++){const _0x3fd232=_0x101a2f['charCodeAt'](_0x22e658);_0x3fd232<0x80?_0x5bc351++:_0x3fd232<0x800?_0x5bc351+=0x2:_0x3fd232>=0xd800&&_0x3fd232<=0xdbff?(_0x5bc351+=0x4,_0x22e658++):_0x5bc351+=0x3;}return _0x5bc351;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x467691){return _0x467691&&_0x467691['_delegate']?_0x467691['_delegate']:_0x467691;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x3c600d){try{return(_0x3c600d['startsWith']('http://')||_0x3c600d['startsWith']('https://')?new URL(_0x3c600d)['hostname']:_0x3c600d)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x2f834b){return(await fetch(_0x2f834b,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x4fd723,_0x1bcfae,_0x337ebc){this['name']=_0x4fd723,this['instanceFactory']=_0x1bcfae,this['type']=_0x337ebc,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x416de7){return this['instantiationMode']=_0x416de7,this;}['setMultipleInstances'](_0x4e7d93){return this['multipleInstances']=_0x4e7d93,this;}['setServiceProps'](_0x509cdc){return this['serviceProps']=_0x509cdc,this;}['setInstanceCreatedCallback'](_0x250e01){return this['onInstanceCreated']=_0x250e01,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x43eedf,_0x3e8249){this['name']=_0x43eedf,this['container']=_0x3e8249,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x31eca5){const _0x5ede6c=this['normalizeInstanceIdentifier'](_0x31eca5);if(!this['instancesDeferred']['has'](_0x5ede6c)){const _0x2f834c=new H();if(this['instancesDeferred']['set'](_0x5ede6c,_0x2f834c),this['isInitialized'](_0x5ede6c)||this['shouldAutoInitialize']())try{const _0x369caf=this['getOrInitializeService']({'instanceIdentifier':_0x5ede6c});_0x369caf&&_0x2f834c['resolve'](_0x369caf);}catch{}}return this['instancesDeferred']['get'](_0x5ede6c)['promise'];}['getImmediate'](_0x39ad5b){const _0x2467e6=this['normalizeInstanceIdentifier'](_0x39ad5b==null?void 0x0:_0x39ad5b['identifier']),_0x5e5e=(_0x39ad5b==null?void 0x0:_0x39ad5b['optional'])??!0x1;if(this['isInitialized'](_0x2467e6)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x2467e6});}catch(_0x25020a){if(_0x5e5e)return null;throw _0x25020a;}else{if(_0x5e5e)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0xf95270){if(_0xf95270['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0xf95270['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0xf95270,!!this['shouldAutoInitialize']()){if(Pc(_0xf95270))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0xeec6b1,_0x5eb5bc]of this['instancesDeferred']['entries']()){const _0x3b7968=this['normalizeInstanceIdentifier'](_0xeec6b1);try{const _0x1ece9e=this['getOrInitializeService']({'instanceIdentifier':_0x3b7968});_0x5eb5bc['resolve'](_0x1ece9e);}catch{}}}}['clearInstance'](_0x12f199=Ne){this['instancesDeferred']['delete'](_0x12f199),this['instancesOptions']['delete'](_0x12f199),this['instances']['delete'](_0x12f199);}async['delete'](){const _0x373bbf=Array['from'](this['instances']['values']());await Promise['all']([..._0x373bbf['filter'](_0x4c4e00=>'INTERNAL'in _0x4c4e00)['map'](_0x2effe6=>_0x2effe6['INTERNAL']['delete']()),..._0x373bbf['filter'](_0x59f543=>'_delete'in _0x59f543)['map'](_0x2d54a2=>_0x2d54a2['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x245a94=Ne){return this['instances']['has'](_0x245a94);}['getOptions'](_0x12b48e=Ne){return this['instancesOptions']['get'](_0x12b48e)||{};}['initialize'](_0x380b6b={}){const {options:_0x70071d={}}=_0x380b6b,_0x20680c=this['normalizeInstanceIdentifier'](_0x380b6b['instanceIdentifier']);if(this['isInitialized'](_0x20680c))throw Error(this['name']+'('+_0x20680c+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x55765d=this['getOrInitializeService']({'instanceIdentifier':_0x20680c,'options':_0x70071d});for(const [_0x5d4467,_0x29492a]of this['instancesDeferred']['entries']()){const _0x3b966d=this['normalizeInstanceIdentifier'](_0x5d4467);_0x20680c===_0x3b966d&&_0x29492a['resolve'](_0x55765d);}return _0x55765d;}['onInit'](_0x14faed,_0xd8bc64){const _0x3ee3ae=this['normalizeInstanceIdentifier'](_0xd8bc64),_0x12be84=this['onInitCallbacks']['get'](_0x3ee3ae)??new Set();_0x12be84['add'](_0x14faed),this['onInitCallbacks']['set'](_0x3ee3ae,_0x12be84);const _0x10f83b=this['instances']['get'](_0x3ee3ae);return _0x10f83b&&_0x14faed(_0x10f83b,_0x3ee3ae),()=>{_0x12be84['delete'](_0x14faed);};}['invokeOnInitCallbacks'](_0x17e2c8,_0x5ea849){const _0x52ccbe=this['onInitCallbacks']['get'](_0x5ea849);if(_0x52ccbe){for(const _0x2573e9 of _0x52ccbe)try{_0x2573e9(_0x17e2c8,_0x5ea849);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x45a08b,options:_0x50a41e={}}){let _0x336b82=this['instances']['get'](_0x45a08b);if(!_0x336b82&&this['component']&&(_0x336b82=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x45a08b),'options':_0x50a41e}),this['instances']['set'](_0x45a08b,_0x336b82),this['instancesOptions']['set'](_0x45a08b,_0x50a41e),this['invokeOnInitCallbacks'](_0x336b82,_0x45a08b),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x45a08b,_0x336b82);}catch{}return _0x336b82||null;}['normalizeInstanceIdentifier'](_0x59ff99=Ne){return this['component']?this['component']['multipleInstances']?_0x59ff99:Ne:_0x59ff99;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x57ac5d){return _0x57ac5d===Ne?void 0x0:_0x57ac5d;}function Pc(_0x1245da){return _0x1245da['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x301ca2){this['name']=_0x301ca2,this['providers']=new Map();}['addComponent'](_0x387c0e){const _0x5b16fe=this['getProvider'](_0x387c0e['name']);if(_0x5b16fe['isComponentSet']())throw new Error('Component\x20'+_0x387c0e['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x5b16fe['setComponent'](_0x387c0e);}['addOrOverwriteComponent'](_0x5ebbde){this['getProvider'](_0x5ebbde['name'])['isComponentSet']()&&this['providers']['delete'](_0x5ebbde['name']),this['addComponent'](_0x5ebbde);}['getProvider'](_0x3180b3){if(this['providers']['has'](_0x3180b3))return this['providers']['get'](_0x3180b3);const _0x3a3398=new Ac(_0x3180b3,this);return this['providers']['set'](_0x3180b3,_0x3a3398),_0x3a3398;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x3a456b){_0x3a456b[_0x3a456b['DEBUG']=0x0]='DEBUG',_0x3a456b[_0x3a456b['VERBOSE']=0x1]='VERBOSE',_0x3a456b[_0x3a456b['INFO']=0x2]='INFO',_0x3a456b[_0x3a456b['WARN']=0x3]='WARN',_0x3a456b[_0x3a456b['ERROR']=0x4]='ERROR',_0x3a456b[_0x3a456b['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x4a12a5,_0x4306ac,..._0xd1d1f3)=>{if(_0x4306ac<_0x4a12a5['logLevel'])return;const _0x3993c7=new Date()['toISOString'](),_0x15223c=Mc[_0x4306ac];if(_0x15223c)console[_0x15223c]('['+_0x3993c7+']\x20\x20'+_0x4a12a5['name']+':',..._0xd1d1f3);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x4306ac+')');};class Bi{constructor(_0x3ef60c){this['name']=_0x3ef60c,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x5bec75){if(!(_0x5bec75 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x5bec75+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x5bec75;}['setLogLevel'](_0xdcef61){this['_logLevel']=typeof _0xdcef61=='string'?Oc[_0xdcef61]:_0xdcef61;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0xab62e2){if(typeof _0xab62e2!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0xab62e2;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x172e5c){this['_userLogHandler']=_0x172e5c;}['debug'](..._0x463faf){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x463faf),this['_logHandler'](this,T['DEBUG'],..._0x463faf);}['log'](..._0x3157bc){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x3157bc),this['_logHandler'](this,T['VERBOSE'],..._0x3157bc);}['info'](..._0x313b11){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x313b11),this['_logHandler'](this,T['INFO'],..._0x313b11);}['warn'](..._0x1018a8){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x1018a8),this['_logHandler'](this,T['WARN'],..._0x1018a8);}['error'](..._0x2baf81){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x2baf81),this['_logHandler'](this,T['ERROR'],..._0x2baf81);}}const xc=(_0x2730b9,_0x174796)=>_0x174796['some'](_0x4a5dae=>_0x2730b9 instanceof _0x4a5dae);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x3cc94a){const _0x5a7ab8=new Promise((_0x57a2d1,_0x3179b1)=>{const _0x1c7ef9=()=>{_0x3cc94a['removeEventListener']('success',_0x4aafe5),_0x3cc94a['removeEventListener']('error',_0xb38e33);},_0x4aafe5=()=>{_0x57a2d1(ge(_0x3cc94a['result'])),_0x1c7ef9();},_0xb38e33=()=>{_0x3179b1(_0x3cc94a['error']),_0x1c7ef9();};_0x3cc94a['addEventListener']('success',_0x4aafe5),_0x3cc94a['addEventListener']('error',_0xb38e33);});return _0x5a7ab8['then'](_0x3f5017=>{_0x3f5017 instanceof IDBCursor&&Jr['set'](_0x3f5017,_0x3cc94a);})['catch'](()=>{}),Vi['set'](_0x5a7ab8,_0x3cc94a),_0x5a7ab8;}function Bc(_0x5a9cc5){if(_i['has'](_0x5a9cc5))return;const _0x285dd6=new Promise((_0x10917a,_0x52073e)=>{const _0x5627b1=()=>{_0x5a9cc5['removeEventListener']('complete',_0x360b13),_0x5a9cc5['removeEventListener']('error',_0xc7b788),_0x5a9cc5['removeEventListener']('abort',_0xc7b788);},_0x360b13=()=>{_0x10917a(),_0x5627b1();},_0xc7b788=()=>{_0x52073e(_0x5a9cc5['error']||new DOMException('AbortError','AbortError')),_0x5627b1();};_0x5a9cc5['addEventListener']('complete',_0x360b13),_0x5a9cc5['addEventListener']('error',_0xc7b788),_0x5a9cc5['addEventListener']('abort',_0xc7b788);});_i['set'](_0x5a9cc5,_0x285dd6);}let gi={'get'(_0x764c8,_0x2b3f48,_0x5a095a){if(_0x764c8 instanceof IDBTransaction){if(_0x2b3f48==='done')return _i['get'](_0x764c8);if(_0x2b3f48==='objectStoreNames')return _0x764c8['objectStoreNames']||Xr['get'](_0x764c8);if(_0x2b3f48==='store')return _0x5a095a['objectStoreNames'][0x1]?void 0x0:_0x5a095a['objectStore'](_0x5a095a['objectStoreNames'][0x0]);}return ge(_0x764c8[_0x2b3f48]);},'set'(_0x58330e,_0x128875,_0x447582){return _0x58330e[_0x128875]=_0x447582,!0x0;},'has'(_0x3e6e5b,_0x5687b8){return _0x3e6e5b instanceof IDBTransaction&&(_0x5687b8==='done'||_0x5687b8==='store')?!0x0:_0x5687b8 in _0x3e6e5b;}};function Vc(_0x50e91f){gi=_0x50e91f(gi);}function Hc(_0x14133b){return _0x14133b===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x134634,..._0x40b16f){const _0x543fed=_0x14133b['call'](ii(this),_0x134634,..._0x40b16f);return Xr['set'](_0x543fed,_0x134634['sort']?_0x134634['sort']():[_0x134634]),ge(_0x543fed);}:Uc()['includes'](_0x14133b)?function(..._0x33f06d){return _0x14133b['apply'](ii(this),_0x33f06d),ge(Jr['get'](this));}:function(..._0xe42d57){return ge(_0x14133b['apply'](ii(this),_0xe42d57));};}function $c(_0x469806){return typeof _0x469806=='function'?Hc(_0x469806):(_0x469806 instanceof IDBTransaction&&Bc(_0x469806),xc(_0x469806,Fc())?new Proxy(_0x469806,gi):_0x469806);}function ge(_0x3b3b53){if(_0x3b3b53 instanceof IDBRequest)return Wc(_0x3b3b53);if(ni['has'](_0x3b3b53))return ni['get'](_0x3b3b53);const _0xd29b20=$c(_0x3b3b53);return _0xd29b20!==_0x3b3b53&&(ni['set'](_0x3b3b53,_0xd29b20),Vi['set'](_0xd29b20,_0x3b3b53)),_0xd29b20;}const ii=_0x10cccc=>Vi['get'](_0x10cccc);function Gc(_0x2c108e,_0x32ccef,{blocked:_0x4c90c1,upgrade:_0x18360f,blocking:_0x2b3065,terminated:_0x55005c}={}){const _0x3ceeed=indexedDB['open'](_0x2c108e,_0x32ccef),_0x43a434=ge(_0x3ceeed);return _0x18360f&&_0x3ceeed['addEventListener']('upgradeneeded',_0xc96600=>{_0x18360f(ge(_0x3ceeed['result']),_0xc96600['oldVersion'],_0xc96600['newVersion'],ge(_0x3ceeed['transaction']),_0xc96600);}),_0x4c90c1&&_0x3ceeed['addEventListener']('blocked',_0x1bb6d7=>_0x4c90c1(_0x1bb6d7['oldVersion'],_0x1bb6d7['newVersion'],_0x1bb6d7)),_0x43a434['then'](_0x201fe6=>{_0x55005c&&_0x201fe6['addEventListener']('close',()=>_0x55005c()),_0x2b3065&&_0x201fe6['addEventListener']('versionchange',_0x1fea85=>_0x2b3065(_0x1fea85['oldVersion'],_0x1fea85['newVersion'],_0x1fea85));})['catch'](()=>{}),_0x43a434;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x86b2a3,_0x533435){if(!(_0x86b2a3 instanceof IDBDatabase&&!(_0x533435 in _0x86b2a3)&&typeof _0x533435=='string'))return;if(si['get'](_0x533435))return si['get'](_0x533435);const _0x2e095e=_0x533435['replace'](/FromIndex$/,''),_0x42f570=_0x533435!==_0x2e095e,_0x4c6c32=zc['includes'](_0x2e095e);if(!(_0x2e095e in(_0x42f570?IDBIndex:IDBObjectStore)['prototype'])||!(_0x4c6c32||qc['includes'](_0x2e095e)))return;const _0x30cc98=async function(_0xacb303,..._0x1e092c){const _0x36683d=this['transaction'](_0xacb303,_0x4c6c32?'readwrite':'readonly');let _0x827cc8=_0x36683d['store'];return _0x42f570&&(_0x827cc8=_0x827cc8['index'](_0x1e092c['shift']())),(await Promise['all']([_0x827cc8[_0x2e095e](..._0x1e092c),_0x4c6c32&&_0x36683d['done']]))[0x0];};return si['set'](_0x533435,_0x30cc98),_0x30cc98;}Vc(_0x130101=>({..._0x130101,'get':(_0x118e28,_0x2cb193,_0x4d278d)=>Ms(_0x118e28,_0x2cb193)||_0x130101['get'](_0x118e28,_0x2cb193,_0x4d278d),'has':(_0x431b6a,_0x2faf7b)=>!!Ms(_0x431b6a,_0x2faf7b)||_0x130101['has'](_0x431b6a,_0x2faf7b)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x5ad755){this['container']=_0x5ad755;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x11145f=>{if(Kc(_0x11145f)){const _0x98e0c3=_0x11145f['getImmediate']();return _0x98e0c3['library']+'/'+_0x98e0c3['version'];}else return null;})['filter'](_0x301968=>_0x301968)['join']('\x20');}}function Kc(_0x18172a){const _0x4374e7=_0x18172a['getComponent']();return(_0x4374e7==null?void 0x0:_0x4374e7['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x247734,_0x3212a9){try{_0x247734['container']['addComponent'](_0x3212a9);}catch(_0x32cf78){oe['debug']('Component\x20'+_0x3212a9['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x247734['name'],_0x32cf78);}}function st(_0x5c29b5){const _0x3befc5=_0x5c29b5['name'];if(Ei['has'](_0x3befc5))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x3befc5+'.'),!0x1;Ei['set'](_0x3befc5,_0x5c29b5);for(const _0x41b3ca of Ue['values']())xs(_0x41b3ca,_0x5c29b5);for(const _0x410e57 of vi['values']())xs(_0x410e57,_0x5c29b5);return!0x0;}function Hi(_0x1cbfcf,_0x5c7d85){const _0x27f758=_0x1cbfcf['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x27f758&&_0x27f758['triggerHeartbeat'](),_0x1cbfcf['container']['getProvider'](_0x5c7d85);}function $(_0x2449df){return _0x2449df==null?!0x1:_0x2449df['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x44f640,_0x530d14,_0x253f22){this['_isDeleted']=!0x1,this['_options']={..._0x44f640},this['_config']={..._0x530d14},this['_name']=_0x530d14['name'],this['_automaticDataCollectionEnabled']=_0x530d14['automaticDataCollectionEnabled'],this['_container']=_0x253f22,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x4b3533){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x4b3533;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0xd150b3){this['_isDeleted']=_0xd150b3;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x1e20f9,_0x3f0e74={}){let _0x121621=_0x1e20f9;typeof _0x3f0e74!='object'&&(_0x3f0e74={'name':_0x3f0e74});const _0x5765c2={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x3f0e74},_0x5a8bfe=_0x5765c2['name'];if(typeof _0x5a8bfe!='string'||!_0x5a8bfe)throw me['create']('bad-app-name',{'appName':String(_0x5a8bfe)});if(_0x121621||(_0x121621=zr()),!_0x121621)throw me['create']('no-options');const _0x24bbd9=Ue['get'](_0x5a8bfe);if(_0x24bbd9){if(xe(_0x121621,_0x24bbd9['options'])&&xe(_0x5765c2,_0x24bbd9['config']))return _0x24bbd9;throw me['create']('duplicate-app',{'appName':_0x5a8bfe});}const _0x4dbcc0=new Nc(_0x5a8bfe);for(const _0x3ffa3d of Ei['values']())_0x4dbcc0['addComponent'](_0x3ffa3d);const _0x145c5f=new Tl(_0x121621,_0x5765c2,_0x4dbcc0);return Ue['set'](_0x5a8bfe,_0x145c5f),_0x145c5f;}function Zr(_0x26d453=yi){const _0x35f88c=Ue['get'](_0x26d453);if(!_0x35f88c&&_0x26d453===yi&&zr())return Sl();if(!_0x35f88c)throw me['create']('no-app',{'appName':_0x26d453});return _0x35f88c;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x225c39){let _0x23c3e0=!0x1;const _0x484c1e=_0x225c39['name'];Ue['has'](_0x484c1e)?(_0x23c3e0=!0x0,Ue['delete'](_0x484c1e)):vi['has'](_0x484c1e)&&_0x225c39['decRefCount']()<=0x0&&(vi['delete'](_0x484c1e),_0x23c3e0=!0x0),_0x23c3e0&&(await Promise['all'](_0x225c39['container']['getProviders']()['map'](_0x13433a=>_0x13433a['delete']())),_0x225c39['isDeleted']=!0x0);}function ye(_0x22c7e2,_0x2da6b1,_0x142079){let _0x4092ed=wl[_0x22c7e2]??_0x22c7e2;_0x142079&&(_0x4092ed+='-'+_0x142079);const _0x39054b=_0x4092ed['match'](/\s|\//),_0x47802f=_0x2da6b1['match'](/\s|\//);if(_0x39054b||_0x47802f){const _0x51d9c4=['Unable\x20to\x20register\x20library\x20\x22'+_0x4092ed+'\x22\x20with\x20version\x20\x22'+_0x2da6b1+'\x22:'];_0x39054b&&_0x51d9c4['push']('library\x20name\x20\x22'+_0x4092ed+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x39054b&&_0x47802f&&_0x51d9c4['push']('and'),_0x47802f&&_0x51d9c4['push']('version\x20name\x20\x22'+_0x2da6b1+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x51d9c4['join']('\x20'));return;}st(new Fe(_0x4092ed+'-version',()=>({'library':_0x4092ed,'version':_0x2da6b1}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x1a60a1,_0x315ade)=>{switch(_0x315ade){case 0x0:try{_0x1a60a1['createObjectStore'](Ot);}catch(_0x1e5ab7){console['warn'](_0x1e5ab7);}}}})['catch'](_0x57518a=>{throw me['create']('idb-open',{'originalErrorMessage':_0x57518a['message']});})),ri;}async function Al(_0x4eef7a){try{const _0x376eb2=(await eo())['transaction'](Ot),_0x397fe0=await _0x376eb2['objectStore'](Ot)['get'](to(_0x4eef7a));return await _0x376eb2['done'],_0x397fe0;}catch(_0x88c29a){if(_0x88c29a instanceof Re)oe['warn'](_0x88c29a['message']);else{const _0x4b896a=me['create']('idb-get',{'originalErrorMessage':_0x88c29a==null?void 0x0:_0x88c29a['message']});oe['warn'](_0x4b896a['message']);}}}async function Fs(_0x43e431,_0x522717){try{const _0x1d428a=(await eo())['transaction'](Ot,'readwrite');await _0x1d428a['objectStore'](Ot)['put'](_0x522717,to(_0x43e431)),await _0x1d428a['done'];}catch(_0x206c38){if(_0x206c38 instanceof Re)oe['warn'](_0x206c38['message']);else{const _0x283094=me['create']('idb-set',{'originalErrorMessage':_0x206c38==null?void 0x0:_0x206c38['message']});oe['warn'](_0x283094['message']);}}}function to(_0x625807){return _0x625807['name']+'!'+_0x625807['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x4f2d96){this['container']=_0x4f2d96,this['_heartbeatsCache']=null;const _0x5bdf8f=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x5bdf8f),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x1113eb=>(this['_heartbeatsCache']=_0x1113eb,_0x1113eb));}async['triggerHeartbeat'](){var _0x1f6f09,_0x3cee92;try{const _0x3f11ca=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x6f3785=Us();if(((_0x1f6f09=this['_heartbeatsCache'])==null?void 0x0:_0x1f6f09['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x3cee92=this['_heartbeatsCache'])==null?void 0x0:_0x3cee92['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x6f3785||this['_heartbeatsCache']['heartbeats']['some'](_0x1f7d9d=>_0x1f7d9d['date']===_0x6f3785))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x6f3785,'agent':_0x3f11ca}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x37147a=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x37147a,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x4b37e6){oe['warn'](_0x4b37e6);}}async['getHeartbeatsHeader'](){var _0x36cafc;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x36cafc=this['_heartbeatsCache'])==null?void 0x0:_0x36cafc['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x54061f=Us(),{heartbeatsToSend:_0x28eb17,unsentEntries:_0x2a7dab}=Ol(this['_heartbeatsCache']['heartbeats']),_0x1db4f2=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x28eb17}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x54061f,_0x2a7dab['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x2a7dab,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x1db4f2;}catch(_0x5b652d){return oe['warn'](_0x5b652d),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x13b245,_0x40f2c2=kl){const _0x5113f7=[];let _0x5d2386=_0x13b245['slice']();for(const _0x520e6d of _0x13b245){const _0x1f436f=_0x5113f7['find'](_0x21ca52=>_0x21ca52['agent']===_0x520e6d['agent']);if(_0x1f436f){if(_0x1f436f['dates']['push'](_0x520e6d['date']),Ws(_0x5113f7)>_0x40f2c2){_0x1f436f['dates']['pop']();break;}}else{if(_0x5113f7['push']({'agent':_0x520e6d['agent'],'dates':[_0x520e6d['date']]}),Ws(_0x5113f7)>_0x40f2c2){_0x5113f7['pop']();break;}}_0x5d2386=_0x5d2386['slice'](0x1);}return{'heartbeatsToSend':_0x5113f7,'unsentEntries':_0x5d2386};}class Dl{constructor(_0x57b985){this['app']=_0x57b985,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x184e34=await Al(this['app']);return _0x184e34!=null&&_0x184e34['heartbeats']?_0x184e34:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x8ed80e){if(await this['_canUseIndexedDBPromise']){const _0x4e4f9b=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x8ed80e['lastSentHeartbeatDate']??_0x4e4f9b['lastSentHeartbeatDate'],'heartbeats':_0x8ed80e['heartbeats']});}else return;}async['add'](_0x3f9eb3){if(await this['_canUseIndexedDBPromise']){const _0x314a26=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x3f9eb3['lastSentHeartbeatDate']??_0x314a26['lastSentHeartbeatDate'],'heartbeats':[..._0x314a26['heartbeats'],..._0x3f9eb3['heartbeats']]});}else return;}}function Ws(_0x27c9dc){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x27c9dc}))['length'];}function Ml(_0x5adb74){if(_0x5adb74['length']===0x0)return-0x1;let _0x144b40=0x0,_0x55a425=_0x5adb74[0x0]['date'];for(let _0x4a280c=0x1;_0x4a280c<_0x5adb74['length'];_0x4a280c++)_0x5adb74[_0x4a280c]['date']<_0x55a425&&(_0x55a425=_0x5adb74[_0x4a280c]['date'],_0x144b40=_0x4a280c);return _0x144b40;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x1efdb3){st(new Fe('platform-logger',_0x30f933=>new jc(_0x30f933),'PRIVATE')),st(new Fe('heartbeat',_0x5a13f5=>new Nl(_0x5a13f5),'PRIVATE')),ye(mi,Ls,_0x1efdb3),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x18aa32){no=_0x18aa32;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x5a74c6){this['domStorage_']=_0x5a74c6,this['prefix_']='firebase:';}['set'](_0x48e9ee,_0x3ed64f){_0x3ed64f==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x48e9ee)):this['domStorage_']['setItem'](this['prefixedName_'](_0x48e9ee),O(_0x3ed64f));}['get'](_0xad1980){const _0x48709c=this['domStorage_']['getItem'](this['prefixedName_'](_0xad1980));return _0x48709c==null?null:Nt(_0x48709c);}['remove'](_0x276c84){this['domStorage_']['removeItem'](this['prefixedName_'](_0x276c84));}['prefixedName_'](_0x2c2d04){return this['prefix_']+_0x2c2d04;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x4bfc3b,_0x48d659){_0x48d659==null?delete this['cache_'][_0x4bfc3b]:this['cache_'][_0x4bfc3b]=_0x48d659;}['get'](_0x142dc9){return Q(this['cache_'],_0x142dc9)?this['cache_'][_0x142dc9]:null;}['remove'](_0x13712e){delete this['cache_'][_0x13712e];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x44170b){try{if(typeof window<'u'&&typeof window[_0x44170b]<'u'){const _0x1ef58c=window[_0x44170b];return _0x1ef58c['setItem']('firebase:sentinel','cache'),_0x1ef58c['removeItem']('firebase:sentinel'),new Wl(_0x1ef58c);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x2647bc=0x1;return function(){return _0x2647bc++;};}()),ro=function(_0x332bba){const _0x4d1874=Rc(_0x332bba),_0x593401=new Cc();_0x593401['update'](_0x4d1874);const _0x508250=_0x593401['digest']();return Fi['encodeByteArray'](_0x508250);},zt=function(..._0x48c226){let _0x1a4c0f='';for(let _0x3f61c2=0x0;_0x3f61c2<_0x48c226['length'];_0x3f61c2++){const _0x514924=_0x48c226[_0x3f61c2];Array['isArray'](_0x514924)||_0x514924&&typeof _0x514924=='object'&&typeof _0x514924['length']=='number'?_0x1a4c0f+=zt['apply'](null,_0x514924):typeof _0x514924=='object'?_0x1a4c0f+=O(_0x514924):_0x1a4c0f+=_0x514924,_0x1a4c0f+='\x20';}return _0x1a4c0f;};let St=null,$s=!0x0;const Hl=function(_0x40b76d,_0x559f5d){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x14137b){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x5294d4=zt['apply'](null,_0x14137b);St(_0x5294d4);}},jt=function(_0x5f2c2d){return function(..._0x245897){L(_0x5f2c2d,..._0x245897);};},Ii=function(..._0x523861){const _0x550d87='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x523861);Ze['error'](_0x550d87);},ae=function(..._0x244919){const _0x52d039='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x244919);throw Ze['error'](_0x52d039),new Error(_0x52d039);},U=function(..._0x549e9b){const _0x4eaf40='FIREBASE\x20WARNING:\x20'+zt(..._0x549e9b);Ze['warn'](_0x4eaf40);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x5dd973){return typeof _0x5dd973=='number'&&(_0x5dd973!==_0x5dd973||_0x5dd973===Number['POSITIVE_INFINITY']||_0x5dd973===Number['NEGATIVE_INFINITY']);},Gl=function(_0x311d1d){if(document['readyState']==='complete')_0x311d1d();else{let _0x1ff369=!0x1;const _0xeff0d2=function(){if(!document['body']){setTimeout(_0xeff0d2,Math['floor'](0xa));return;}_0x1ff369||(_0x1ff369=!0x0,_0x311d1d());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0xeff0d2,!0x1),window['addEventListener']('load',_0xeff0d2,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0xeff0d2();}),window['attachEvent']('onload',_0xeff0d2));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x721fbb,_0xdf140c){if(_0x721fbb===_0xdf140c)return 0x0;if(_0x721fbb===We||_0xdf140c===we)return-0x1;if(_0xdf140c===We||_0x721fbb===we)return 0x1;{const _0x5970e8=Gs(_0x721fbb),_0x3d3af2=Gs(_0xdf140c);return _0x5970e8!==null?_0x3d3af2!==null?_0x5970e8-_0x3d3af2===0x0?_0x721fbb['length']-_0xdf140c['length']:_0x5970e8-_0x3d3af2:-0x1:_0x3d3af2!==null?0x1:_0x721fbb<_0xdf140c?-0x1:0x1;}},ql=function(_0x1aac5f,_0x3bb8d7){return _0x1aac5f===_0x3bb8d7?0x0:_0x1aac5f<_0x3bb8d7?-0x1:0x1;},vt=function(_0x336262,_0x5ba3d4){if(_0x5ba3d4&&_0x336262 in _0x5ba3d4)return _0x5ba3d4[_0x336262];throw new Error('Missing\x20required\x20key\x20('+_0x336262+')\x20in\x20object:\x20'+O(_0x5ba3d4));},$i=function(_0x487e9b){if(typeof _0x487e9b!='object'||_0x487e9b===null)return O(_0x487e9b);const _0x6771b7=[];for(const _0x496f64 in _0x487e9b)_0x6771b7['push'](_0x496f64);_0x6771b7['sort']();let _0x1140ee='{';for(let _0x4d7d42=0x0;_0x4d7d42<_0x6771b7['length'];_0x4d7d42++)_0x4d7d42!==0x0&&(_0x1140ee+=','),_0x1140ee+=O(_0x6771b7[_0x4d7d42]),_0x1140ee+=':',_0x1140ee+=$i(_0x487e9b[_0x6771b7[_0x4d7d42]]);return _0x1140ee+='}',_0x1140ee;},oo=function(_0x8c070c,_0x11aa71){const _0x41aac4=_0x8c070c['length'];if(_0x41aac4<=_0x11aa71)return[_0x8c070c];const _0x2f80d0=[];for(let _0x2f795d=0x0;_0x2f795d<_0x41aac4;_0x2f795d+=_0x11aa71)_0x2f795d+_0x11aa71>_0x41aac4?_0x2f80d0['push'](_0x8c070c['substring'](_0x2f795d,_0x41aac4)):_0x2f80d0['push'](_0x8c070c['substring'](_0x2f795d,_0x2f795d+_0x11aa71));return _0x2f80d0;};function x(_0x5d934f,_0x782db5){for(const _0x28b52e in _0x5d934f)_0x5d934f['hasOwnProperty'](_0x28b52e)&&_0x782db5(_0x28b52e,_0x5d934f[_0x28b52e]);}const ao=function(_0x300afc){f(!xn(_0x300afc),'Invalid\x20JSON\x20number');const _0x3606ec=0xb,_0x98b9b3=0x34,_0x581538=(0x1<<_0x3606ec-0x1)-0x1;let _0x298085,_0x5a984a,_0x114174,_0x10a962,_0x14c35a;_0x300afc===0x0?(_0x5a984a=0x0,_0x114174=0x0,_0x298085=0x1/_0x300afc===-0x1/0x0?0x1:0x0):(_0x298085=_0x300afc<0x0,_0x300afc=Math['abs'](_0x300afc),_0x300afc>=Math['pow'](0x2,0x1-_0x581538)?(_0x10a962=Math['min'](Math['floor'](Math['log'](_0x300afc)/Math['LN2']),_0x581538),_0x5a984a=_0x10a962+_0x581538,_0x114174=Math['round'](_0x300afc*Math['pow'](0x2,_0x98b9b3-_0x10a962)-Math['pow'](0x2,_0x98b9b3))):(_0x5a984a=0x0,_0x114174=Math['round'](_0x300afc/Math['pow'](0x2,0x1-_0x581538-_0x98b9b3))));const _0x373644=[];for(_0x14c35a=_0x98b9b3;_0x14c35a;_0x14c35a-=0x1)_0x373644['push'](_0x114174%0x2?0x1:0x0),_0x114174=Math['floor'](_0x114174/0x2);for(_0x14c35a=_0x3606ec;_0x14c35a;_0x14c35a-=0x1)_0x373644['push'](_0x5a984a%0x2?0x1:0x0),_0x5a984a=Math['floor'](_0x5a984a/0x2);_0x373644['push'](_0x298085?0x1:0x0),_0x373644['reverse']();const _0x1248be=_0x373644['join']('');let _0x37f8ed='';for(_0x14c35a=0x0;_0x14c35a<0x40;_0x14c35a+=0x8){let _0x1ff1a5=parseInt(_0x1248be['substr'](_0x14c35a,0x8),0x2)['toString'](0x10);_0x1ff1a5['length']===0x1&&(_0x1ff1a5='0'+_0x1ff1a5),_0x37f8ed=_0x37f8ed+_0x1ff1a5;}return _0x37f8ed['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x16386f,_0x2086e8){let _0xaf2ac8='Unknown\x20Error';_0x16386f==='too_big'?_0xaf2ac8='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x16386f==='permission_denied'?_0xaf2ac8='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x16386f==='unavailable'&&(_0xaf2ac8='The\x20service\x20is\x20unavailable');const _0x2626c8=new Error(_0x16386f+'\x20at\x20'+_0x2086e8['_path']['toString']()+':\x20'+_0xaf2ac8);return _0x2626c8['code']=_0x16386f['toUpperCase'](),_0x2626c8;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x47b56d){if(Yl['test'](_0x47b56d)){const _0x5c66af=Number(_0x47b56d);if(_0x5c66af>=Ql&&_0x5c66af<=Jl)return _0x5c66af;}return null;},ft=function(_0x58fbc9){try{_0x58fbc9();}catch(_0x2a4cce){setTimeout(()=>{const _0x908208=_0x2a4cce['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x908208),_0x2a4cce;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x6ddd67,_0x440816){const _0x1f0ed1=setTimeout(_0x6ddd67,_0x440816);return typeof _0x1f0ed1=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x1f0ed1):typeof _0x1f0ed1=='object'&&_0x1f0ed1['unref']&&_0x1f0ed1['unref'](),_0x1f0ed1;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x146ec4,_0x1142cd){this['appCheckProvider']=_0x1142cd,this['appName']=_0x146ec4['name'],$(_0x146ec4)&&_0x146ec4['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x146ec4['settings']['appCheckToken']),this['appCheck']=_0x1142cd==null?void 0x0:_0x1142cd['getImmediate']({'optional':!0x0}),this['appCheck']||_0x1142cd==null||_0x1142cd['get']()['then'](_0x2cbdcf=>this['appCheck']=_0x2cbdcf);}['getToken'](_0x43be7f){if(this['serverAppAppCheckToken']){if(_0x43be7f)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x43be7f):new Promise((_0xd6a0a6,_0x6ef9c6)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x43be7f)['then'](_0xd6a0a6,_0x6ef9c6):_0xd6a0a6(null);},0x0);});}['addTokenChangeListener'](_0x1a8220){var _0xdd31f9;(_0xdd31f9=this['appCheckProvider'])==null||_0xdd31f9['get']()['then'](_0x5dbdec=>_0x5dbdec['addTokenListener'](_0x1a8220));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0xa6f3ea,_0x598a8d,_0x130c45){this['appName_']=_0xa6f3ea,this['firebaseOptions_']=_0x598a8d,this['authProvider_']=_0x130c45,this['auth_']=null,this['auth_']=_0x130c45['getImmediate']({'optional':!0x0}),this['auth_']||_0x130c45['onInit'](_0x5c014e=>this['auth_']=_0x5c014e);}['getToken'](_0x25e880){return this['auth_']?this['auth_']['getToken'](_0x25e880)['catch'](_0x48d4ac=>_0x48d4ac&&_0x48d4ac['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x48d4ac)):new Promise((_0x1167ac,_0x4ac45d)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x25e880)['then'](_0x1167ac,_0x4ac45d):_0x1167ac(null);},0x0);});}['addTokenChangeListener'](_0x36b5dc){this['auth_']?this['auth_']['addAuthTokenListener'](_0x36b5dc):this['authProvider_']['get']()['then'](_0x5f5844=>_0x5f5844['addAuthTokenListener'](_0x36b5dc));}['removeTokenChangeListener'](_0x3f7068){this['authProvider_']['get']()['then'](_0x3f8205=>_0x3f8205['removeAuthTokenListener'](_0x3f7068));}['notifyForInvalidToken'](){let _0x14c6f2='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x14c6f2+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x14c6f2+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x14c6f2+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x14c6f2);}}class an{constructor(_0x3cc606){this['accessToken']=_0x3cc606;}['getToken'](_0x3e3918){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x44eaeb){_0x44eaeb(this['accessToken']);}['removeTokenChangeListener'](_0x174a94){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x1eb8fa,_0x49c3cf,_0x5993d0,_0x51de18,_0x4027c8=!0x1,_0x13ccf4='',_0x642d7a=!0x1,_0x387c98=!0x1,_0x49eddb=null){this['secure']=_0x49c3cf,this['namespace']=_0x5993d0,this['webSocketOnly']=_0x51de18,this['nodeAdmin']=_0x4027c8,this['persistenceKey']=_0x13ccf4,this['includeNamespaceInQueryParams']=_0x642d7a,this['isUsingEmulator']=_0x387c98,this['emulatorOptions']=_0x49eddb,this['_host']=_0x1eb8fa['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x1eb8fa)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x18a30c){_0x18a30c!==this['internalHost']&&(this['internalHost']=_0x18a30c,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x7863e8=this['toURLString']();return this['persistenceKey']&&(_0x7863e8+='<'+this['persistenceKey']+'>'),_0x7863e8;}['toURLString'](){const _0x2a3fed=this['secure']?'https://':'http://',_0x4f2c78=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x2a3fed+this['host']+'/'+_0x4f2c78;}}function th(_0x326991){return _0x326991['host']!==_0x326991['internalHost']||_0x326991['isCustomHost']()||_0x326991['includeNamespaceInQueryParams'];}function vo(_0x4ac6b4,_0x3675e5,_0x491514){f(typeof _0x3675e5=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x491514=='object','typeof\x20params\x20must\x20==\x20object');let _0x7962c1;if(_0x3675e5===go)_0x7962c1=(_0x4ac6b4['secure']?'wss://':'ws://')+_0x4ac6b4['internalHost']+'/.ws?';else{if(_0x3675e5===mo)_0x7962c1=(_0x4ac6b4['secure']?'https://':'http://')+_0x4ac6b4['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x3675e5);}th(_0x4ac6b4)&&(_0x491514['ns']=_0x4ac6b4['namespace']);const _0x237231=[];return x(_0x491514,(_0x1bc037,_0x429338)=>{_0x237231['push'](_0x1bc037+'='+_0x429338);}),_0x7962c1+_0x237231['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0xe1cfb5,_0xfa7909=0x1){Q(this['counters_'],_0xe1cfb5)||(this['counters_'][_0xe1cfb5]=0x0),this['counters_'][_0xe1cfb5]+=_0xfa7909;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x210d00){const _0x4ccbba=_0x210d00['toString']();return oi[_0x4ccbba]||(oi[_0x4ccbba]=new nh()),oi[_0x4ccbba];}function ih(_0xf83b88,_0x4fa764){const _0x2d8d96=_0xf83b88['toString']();return ai[_0x2d8d96]||(ai[_0x2d8d96]=_0x4fa764()),ai[_0x2d8d96];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x1f7cfa){this['onMessage_']=_0x1f7cfa,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x59a9f9,_0x465d9c){this['closeAfterResponse']=_0x59a9f9,this['onClose']=_0x465d9c,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x30cd2c,_0x5dd54d){for(this['pendingResponses'][_0x30cd2c]=_0x5dd54d;this['pendingResponses'][this['currentResponseNum']];){const _0x550cc8=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x3f5dbe=0x0;_0x3f5dbe<_0x550cc8['length'];++_0x3f5dbe)_0x550cc8[_0x3f5dbe]&&ft(()=>{this['onMessage_'](_0x550cc8[_0x3f5dbe]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x2b75fe,_0x762e4b,_0x3b0b7e,_0x5dbeb0,_0x3132fe,_0x19e702,_0x51b02c){this['connId']=_0x2b75fe,this['repoInfo']=_0x762e4b,this['applicationId']=_0x3b0b7e,this['appCheckToken']=_0x5dbeb0,this['authToken']=_0x3132fe,this['transportSessionId']=_0x19e702,this['lastSessionId']=_0x51b02c,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x2b75fe),this['stats_']=qi(_0x762e4b),this['urlFn']=_0x342a75=>(this['appCheckToken']&&(_0x342a75[wi]=this['appCheckToken']),vo(_0x762e4b,mo,_0x342a75));}['open'](_0x5026da,_0x5a8603){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x5a8603,this['myPacketOrderer']=new sh(_0x5026da),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x5847c2)=>{const [_0x564a8e,_0x26a343,_0x4e4d78,_0x2f7b05,_0x4ca369]=_0x5847c2;if(this['incrementIncomingBytes_'](_0x5847c2),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x564a8e===qs)this['id']=_0x26a343,this['password']=_0x4e4d78;else{if(_0x564a8e===rh)_0x26a343?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x26a343,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x564a8e);}}},(..._0x11cfa8)=>{const [_0xf7b652,_0x1b9dd5]=_0x11cfa8;this['incrementIncomingBytes_'](_0x11cfa8),this['myPacketOrderer']['handleResponse'](_0xf7b652,_0x1b9dd5);},()=>{this['onClosed_']();},this['urlFn']);const _0x2ed2e5={};_0x2ed2e5[qs]='t',_0x2ed2e5[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x2ed2e5[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x2ed2e5[co]=Gi,this['transportSessionId']&&(_0x2ed2e5[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x2ed2e5[po]=this['lastSessionId']),this['applicationId']&&(_0x2ed2e5[_o]=this['applicationId']),this['appCheckToken']&&(_0x2ed2e5[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x2ed2e5[ho]=uo);const _0x4e0b1b=this['urlFn'](_0x2ed2e5);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x4e0b1b),this['scriptTagHolder']['addTag'](_0x4e0b1b,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x1dc222){const _0x4e7b09=O(_0x1dc222);this['bytesSent']+=_0x4e7b09['length'],this['stats_']['incrementCounter']('bytes_sent',_0x4e7b09['length']);const _0x315d32=$r(_0x4e7b09),_0x47fb9c=oo(_0x315d32,fh);for(let _0x46c75e=0x0;_0x46c75e<_0x47fb9c['length'];_0x46c75e++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x47fb9c['length'],_0x47fb9c[_0x46c75e]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x1c52f7,_0x3c8cfa){this['myDisconnFrame']=document['createElement']('iframe');const _0x491c53={};_0x491c53[dh]='t',_0x491c53[Eo]=_0x1c52f7,_0x491c53[Io]=_0x3c8cfa,this['myDisconnFrame']['src']=this['urlFn'](_0x491c53),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x3c23c5){const _0x107c50=O(_0x3c23c5)['length'];this['bytesReceived']+=_0x107c50,this['stats_']['incrementCounter']('bytes_received',_0x107c50);}}class zi{constructor(_0x261699,_0x1993ef,_0x9a8545,_0x437c1f){this['onDisconnect']=_0x9a8545,this['urlFn']=_0x437c1f,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x261699,window[ah+this['uniqueCallbackIdentifier']]=_0x1993ef,this['myIFrame']=zi['createIFrame_']();let _0x315efb='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x315efb='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x1aa102='<html><body>'+_0x315efb+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x1aa102),this['myIFrame']['doc']['close']();}catch(_0x451d76){L('frame\x20writing\x20exception'),_0x451d76['stack']&&L(_0x451d76['stack']),L(_0x451d76);}}}static['createIFrame_'](){const _0x220bc2=document['createElement']('iframe');if(_0x220bc2['style']['display']='none',document['body']){document['body']['appendChild'](_0x220bc2);try{_0x220bc2['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x2fe9f9=document['domain'];_0x220bc2['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x2fe9f9+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x220bc2['contentDocument']?_0x220bc2['doc']=_0x220bc2['contentDocument']:_0x220bc2['contentWindow']?_0x220bc2['doc']=_0x220bc2['contentWindow']['document']:_0x220bc2['document']&&(_0x220bc2['doc']=_0x220bc2['document']),_0x220bc2;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x4d8094=this['onDisconnect'];_0x4d8094&&(this['onDisconnect']=null,_0x4d8094());}['startLongPoll'](_0xa8e492,_0x5bdea2){for(this['myID']=_0xa8e492,this['myPW']=_0x5bdea2,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x2a6626={};_0x2a6626[Eo]=this['myID'],_0x2a6626[Io]=this['myPW'],_0x2a6626[wo]=this['currentSerial'];let _0x19fc89=this['urlFn'](_0x2a6626),_0x477db6='',_0xca7c7e=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x477db6['length']<=Co;){const _0x2e0fd2=this['pendingSegs']['shift']();_0x477db6=_0x477db6+'&'+lh+_0xca7c7e+'='+_0x2e0fd2['seg']+'&'+hh+_0xca7c7e+'='+_0x2e0fd2['ts']+'&'+uh+_0xca7c7e+'='+_0x2e0fd2['d'],_0xca7c7e++;}return _0x19fc89=_0x19fc89+_0x477db6,this['addLongPollTag_'](_0x19fc89,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x3a1b56,_0x14e01d,_0x357724){this['pendingSegs']['push']({'seg':_0x3a1b56,'ts':_0x14e01d,'d':_0x357724}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x1c1c0d,_0x4265b7){this['outstandingRequests']['add'](_0x4265b7);const _0x14474f=()=>{this['outstandingRequests']['delete'](_0x4265b7),this['newRequest_']();},_0x4ff9f4=setTimeout(_0x14474f,Math['floor'](ph)),_0x38b829=()=>{clearTimeout(_0x4ff9f4),_0x14474f();};this['addTag'](_0x1c1c0d,_0x38b829);}['addTag'](_0x204e64,_0x4595ef){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x9117fd=this['myIFrame']['doc']['createElement']('script');_0x9117fd['type']='text/javascript',_0x9117fd['async']=!0x0,_0x9117fd['src']=_0x204e64,_0x9117fd['onload']=_0x9117fd['onreadystatechange']=function(){const _0x22401f=_0x9117fd['readyState'];(!_0x22401f||_0x22401f==='loaded'||_0x22401f==='complete')&&(_0x9117fd['onload']=_0x9117fd['onreadystatechange']=null,_0x9117fd['parentNode']&&_0x9117fd['parentNode']['removeChild'](_0x9117fd),_0x4595ef());},_0x9117fd['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x204e64),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x9117fd);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x542afc,_0x45f78e,_0x1fca1f,_0x320c05,_0x1b8488,_0x3af8a3,_0x4e1b0a){this['connId']=_0x542afc,this['applicationId']=_0x1fca1f,this['appCheckToken']=_0x320c05,this['authToken']=_0x1b8488,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x45f78e),this['connURL']=q['connectionURL_'](_0x45f78e,_0x3af8a3,_0x4e1b0a,_0x320c05,_0x1fca1f),this['nodeAdmin']=_0x45f78e['nodeAdmin'];}static['connectionURL_'](_0x4dedd5,_0x155a70,_0x44f928,_0x4013b0,_0x367652){const _0x385786={};return _0x385786[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x385786[ho]=uo),_0x155a70&&(_0x385786[lo]=_0x155a70),_0x44f928&&(_0x385786[po]=_0x44f928),_0x4013b0&&(_0x385786[wi]=_0x4013b0),_0x367652&&(_0x385786[_o]=_0x367652),vo(_0x4dedd5,go,_0x385786);}['open'](_0x11de08,_0x2dff1c){this['onDisconnect']=_0x2dff1c,this['onMessage']=_0x11de08,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x282cf0;_c(),this['mySock']=new gn(this['connURL'],[],_0x282cf0);}catch(_0x23ed91){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x476560=_0x23ed91['message']||_0x23ed91['data'];_0x476560&&this['log_'](_0x476560),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x1697c3=>{this['handleIncomingFrame'](_0x1697c3);},this['mySock']['onerror']=_0xf0acef=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x215e91=_0xf0acef['message']||_0xf0acef['data'];_0x215e91&&this['log_'](_0x215e91),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x149f4f=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x3bafbc=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x47919d=navigator['userAgent']['match'](_0x3bafbc);_0x47919d&&_0x47919d['length']>0x1&&parseFloat(_0x47919d[0x1])<4.4&&(_0x149f4f=!0x0);}return!_0x149f4f&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x2ba528){if(this['frames']['push'](_0x2ba528),this['frames']['length']===this['totalFrames']){const _0x67a8ca=this['frames']['join']('');this['frames']=null;const _0x4bc789=Nt(_0x67a8ca);this['onMessage'](_0x4bc789);}}['handleNewFrameCount_'](_0x4685d6){this['totalFrames']=_0x4685d6,this['frames']=[];}['extractFrameCount_'](_0x1dbd50){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x1dbd50['length']<=0x6){const _0x3bcaee=Number(_0x1dbd50);if(!isNaN(_0x3bcaee))return this['handleNewFrameCount_'](_0x3bcaee),null;}return this['handleNewFrameCount_'](0x1),_0x1dbd50;}['handleIncomingFrame'](_0x4fc5d9){if(this['mySock']===null)return;const _0x198d37=_0x4fc5d9['data'];if(this['bytesReceived']+=_0x198d37['length'],this['stats_']['incrementCounter']('bytes_received',_0x198d37['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x198d37);else{const _0x58dd6d=this['extractFrameCount_'](_0x198d37);_0x58dd6d!==null&&this['appendFrame_'](_0x58dd6d);}}['send'](_0x284477){this['resetKeepAlive']();const _0x228fa9=O(_0x284477);this['bytesSent']+=_0x228fa9['length'],this['stats_']['incrementCounter']('bytes_sent',_0x228fa9['length']);const _0x3f46db=oo(_0x228fa9,gh);_0x3f46db['length']>0x1&&this['sendString_'](String(_0x3f46db['length']));for(let _0x346a76=0x0;_0x346a76<_0x3f46db['length'];_0x346a76++)this['sendString_'](_0x3f46db[_0x346a76]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x41cb55){try{this['mySock']['send'](_0x41cb55);}catch(_0x500c17){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x500c17['message']||_0x500c17['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x1799c1){this['initTransports_'](_0x1799c1);}['initTransports_'](_0x52860f){const _0x519970=q&&q['isAvailable']();let _0x49ca5d=_0x519970&&!q['previouslyFailed']();if(_0x52860f['webSocketOnly']&&(_0x519970||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x49ca5d=!0x0),_0x49ca5d)this['transports_']=[q];else{const _0xd2a5cd=this['transports_']=[];for(const _0x3a0e7b of Dt['ALL_TRANSPORTS'])_0x3a0e7b&&_0x3a0e7b['isAvailable']()&&_0xd2a5cd['push'](_0x3a0e7b);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x1186ff,_0x4e562f,_0x10e0f7,_0x275dd5,_0x5f2d6c,_0xe782fe,_0x27f3fa,_0x14447e,_0xefb0f4,_0x37a0e2){this['id']=_0x1186ff,this['repoInfo_']=_0x4e562f,this['applicationId_']=_0x10e0f7,this['appCheckToken_']=_0x275dd5,this['authToken_']=_0x5f2d6c,this['onMessage_']=_0xe782fe,this['onReady_']=_0x27f3fa,this['onDisconnect_']=_0x14447e,this['onKill_']=_0xefb0f4,this['lastSessionId']=_0x37a0e2,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x4e562f),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x937614=this['transportManager_']['initialTransport']();this['conn_']=new _0x937614(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x937614['responsesRequiredToBeHealthy']||0x0;const _0x1f4f28=this['connReceiver_'](this['conn_']),_0x32028d=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x1f4f28,_0x32028d);},Math['floor'](0x0));const _0xde706e=_0x937614['healthyTimeout']||0x0;_0xde706e>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0xde706e)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x42e2b9){return _0x4444e3=>{_0x42e2b9===this['conn_']?this['onConnectionLost_'](_0x4444e3):_0x42e2b9===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x236c2d){return _0x2a4a68=>{this['state_']!==0x2&&(_0x236c2d===this['rx_']?this['onPrimaryMessageReceived_'](_0x2a4a68):_0x236c2d===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x2a4a68):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x3d2bbb){const _0x256792={'t':'d','d':_0x3d2bbb};this['sendData_'](_0x256792);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x35b5b7){if(ci in _0x35b5b7){const _0x10883f=_0x35b5b7[ci];_0x10883f===Ys?this['upgradeIfSecondaryHealthy_']():_0x10883f===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x10883f===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x40de1d){const _0x422e44=vt('t',_0x40de1d),_0x3e0c8f=vt('d',_0x40de1d);if(_0x422e44==='c')this['onSecondaryControl_'](_0x3e0c8f);else{if(_0x422e44==='d')this['pendingDataMessages']['push'](_0x3e0c8f);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x422e44);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0xc4eaf2){const _0x490a94=vt('t',_0xc4eaf2),_0x15cddf=vt('d',_0xc4eaf2);_0x490a94==='c'?this['onControl_'](_0x15cddf):_0x490a94==='d'&&this['onDataMessage_'](_0x15cddf);}['onDataMessage_'](_0x3b2864){this['onPrimaryResponse_'](),this['onMessage_'](_0x3b2864);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x2a4a0a){const _0x4aad50=vt(ci,_0x2a4a0a);if(zs in _0x2a4a0a){const _0x15e186=_0x2a4a0a[zs];if(_0x4aad50===Th){const _0x7dd964={..._0x15e186};this['repoInfo_']['isUsingEmulator']&&(_0x7dd964['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x7dd964);}else{if(_0x4aad50===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x1ab2e8=0x0;_0x1ab2e8<this['pendingDataMessages']['length'];++_0x1ab2e8)this['onDataMessage_'](this['pendingDataMessages'][_0x1ab2e8]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x4aad50===wh?this['onConnectionShutdown_'](_0x15e186):_0x4aad50===js?this['onReset_'](_0x15e186):_0x4aad50===Ch?Ii('Server\x20Error:\x20'+_0x15e186):_0x4aad50===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x4aad50);}}}['onHandshake_'](_0x170f30){const _0x5c5e00=_0x170f30['ts'],_0x544870=_0x170f30['v'],_0x326702=_0x170f30['h'];this['sessionId']=_0x170f30['s'],this['repoInfo_']['host']=_0x326702,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x5c5e00),Gi!==_0x544870&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x340b90=this['transportManager_']['upgradeTransport']();_0x340b90&&this['startUpgrade_'](_0x340b90);}['startUpgrade_'](_0x444d22){this['secondaryConn_']=new _0x444d22(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x444d22['responsesRequiredToBeHealthy']||0x0;const _0x2f383b=this['connReceiver_'](this['secondaryConn_']),_0x196923=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x2f383b,_0x196923),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0xbd641a){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0xbd641a),this['repoInfo_']['host']=_0xbd641a,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x22bd8f,_0x22a43c){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x22bd8f,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x22a43c,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x187165=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x187165||this['rx_']===_0x187165)&&this['close']();}['onConnectionLost_'](_0x4a469d){this['conn_']=null,!_0x4a469d&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x73a28e){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x73a28e),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x3cb551){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x3cb551);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x10d1b8,_0x1eb78d,_0x1fd6b8,_0x49b9f8){}['merge'](_0x5290a6,_0x571fd6,_0x4a9ce3,_0x2ccead){}['refreshAuthToken'](_0x4bfd61){}['refreshAppCheckToken'](_0x1a54d0){}['onDisconnectPut'](_0x1e05a3,_0x4d836f,_0x34acdc){}['onDisconnectMerge'](_0x132738,_0x1c3a8a,_0x4cfcb9){}['onDisconnectCancel'](_0x1e9deb,_0x229514){}['reportStats'](_0x290396){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x56b0c7){this['allowedEvents_']=_0x56b0c7,this['listeners_']={},f(Array['isArray'](_0x56b0c7)&&_0x56b0c7['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x1def61,..._0x552047){if(Array['isArray'](this['listeners_'][_0x1def61])){const _0x4fc91d=[...this['listeners_'][_0x1def61]];for(let _0x5c0d63=0x0;_0x5c0d63<_0x4fc91d['length'];_0x5c0d63++)_0x4fc91d[_0x5c0d63]['callback']['apply'](_0x4fc91d[_0x5c0d63]['context'],_0x552047);}}['on'](_0x1e587a,_0x2f4169,_0x5f184c){this['validateEventType_'](_0x1e587a),this['listeners_'][_0x1e587a]=this['listeners_'][_0x1e587a]||[],this['listeners_'][_0x1e587a]['push']({'callback':_0x2f4169,'context':_0x5f184c});const _0x5bd3bc=this['getInitialEvent'](_0x1e587a);_0x5bd3bc&&_0x2f4169['apply'](_0x5f184c,_0x5bd3bc);}['off'](_0x211064,_0x455826,_0x4ff75d){this['validateEventType_'](_0x211064);const _0x2bcf2c=this['listeners_'][_0x211064]||[];for(let _0x12e31e=0x0;_0x12e31e<_0x2bcf2c['length'];_0x12e31e++)if(_0x2bcf2c[_0x12e31e]['callback']===_0x455826&&(!_0x4ff75d||_0x4ff75d===_0x2bcf2c[_0x12e31e]['context'])){_0x2bcf2c['splice'](_0x12e31e,0x1);return;}}['validateEventType_'](_0x5f3795){f(this['allowedEvents_']['find'](_0x432c73=>_0x432c73===_0x5f3795),'Unknown\x20event:\x20'+_0x5f3795);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x18a985){return f(_0x18a985==='online','Unknown\x20event\x20type:\x20'+_0x18a985),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x4f721a,_0x5bf75f){if(_0x5bf75f===void 0x0){this['pieces_']=_0x4f721a['split']('/');let _0x2766cf=0x0;for(let _0x441bb5=0x0;_0x441bb5<this['pieces_']['length'];_0x441bb5++)this['pieces_'][_0x441bb5]['length']>0x0&&(this['pieces_'][_0x2766cf]=this['pieces_'][_0x441bb5],_0x2766cf++);this['pieces_']['length']=_0x2766cf,this['pieceNum_']=0x0;}else this['pieces_']=_0x4f721a,this['pieceNum_']=_0x5bf75f;}['toString'](){let _0x118f4b='';for(let _0x1963c4=this['pieceNum_'];_0x1963c4<this['pieces_']['length'];_0x1963c4++)this['pieces_'][_0x1963c4]!==''&&(_0x118f4b+='/'+this['pieces_'][_0x1963c4]);return _0x118f4b||'/';}}function w(){return new C('');}function y(_0x3aef2b){return _0x3aef2b['pieceNum_']>=_0x3aef2b['pieces_']['length']?null:_0x3aef2b['pieces_'][_0x3aef2b['pieceNum_']];}function Ce(_0xd8007f){return _0xd8007f['pieces_']['length']-_0xd8007f['pieceNum_'];}function S(_0x44aae9){let _0x5aa457=_0x44aae9['pieceNum_'];return _0x5aa457<_0x44aae9['pieces_']['length']&&_0x5aa457++,new C(_0x44aae9['pieces_'],_0x5aa457);}function ji(_0x45cc3e){return _0x45cc3e['pieceNum_']<_0x45cc3e['pieces_']['length']?_0x45cc3e['pieces_'][_0x45cc3e['pieces_']['length']-0x1]:null;}function bh(_0x5c07f7){let _0x560870='';for(let _0x4206cb=_0x5c07f7['pieceNum_'];_0x4206cb<_0x5c07f7['pieces_']['length'];_0x4206cb++)_0x5c07f7['pieces_'][_0x4206cb]!==''&&(_0x560870+='/'+encodeURIComponent(String(_0x5c07f7['pieces_'][_0x4206cb])));return _0x560870||'/';}function Mt(_0x1a9ba4,_0x1483e9=0x0){return _0x1a9ba4['pieces_']['slice'](_0x1a9ba4['pieceNum_']+_0x1483e9);}function Ro(_0x1a26ff){if(_0x1a26ff['pieceNum_']>=_0x1a26ff['pieces_']['length'])return null;const _0x166655=[];for(let _0x12648b=_0x1a26ff['pieceNum_'];_0x12648b<_0x1a26ff['pieces_']['length']-0x1;_0x12648b++)_0x166655['push'](_0x1a26ff['pieces_'][_0x12648b]);return new C(_0x166655,0x0);}function k(_0x5f3855,_0xfd7771){const _0x2c27a5=[];for(let _0x15d426=_0x5f3855['pieceNum_'];_0x15d426<_0x5f3855['pieces_']['length'];_0x15d426++)_0x2c27a5['push'](_0x5f3855['pieces_'][_0x15d426]);if(_0xfd7771 instanceof C){for(let _0x41671c=_0xfd7771['pieceNum_'];_0x41671c<_0xfd7771['pieces_']['length'];_0x41671c++)_0x2c27a5['push'](_0xfd7771['pieces_'][_0x41671c]);}else{const _0x262348=_0xfd7771['split']('/');for(let _0x598e47=0x0;_0x598e47<_0x262348['length'];_0x598e47++)_0x262348[_0x598e47]['length']>0x0&&_0x2c27a5['push'](_0x262348[_0x598e47]);}return new C(_0x2c27a5,0x0);}function v(_0x3c7687){return _0x3c7687['pieceNum_']>=_0x3c7687['pieces_']['length'];}function F(_0x59aca6,_0x49576c){const _0x57ff87=y(_0x59aca6),_0x3cf09d=y(_0x49576c);if(_0x57ff87===null)return _0x49576c;if(_0x57ff87===_0x3cf09d)return F(S(_0x59aca6),S(_0x49576c));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x49576c+')\x20is\x20not\x20within\x20outerPath\x20('+_0x59aca6+')');}function Rh(_0x44e278,_0x1b5bc5){const _0x1b14e7=Mt(_0x44e278,0x0),_0x5273b7=Mt(_0x1b5bc5,0x0);for(let _0x443620=0x0;_0x443620<_0x1b14e7['length']&&_0x443620<_0x5273b7['length'];_0x443620++){const _0x2f11bf=qe(_0x1b14e7[_0x443620],_0x5273b7[_0x443620]);if(_0x2f11bf!==0x0)return _0x2f11bf;}return _0x1b14e7['length']===_0x5273b7['length']?0x0:_0x1b14e7['length']<_0x5273b7['length']?-0x1:0x1;}function Ki(_0x4a4e0f,_0x3c8a0d){if(Ce(_0x4a4e0f)!==Ce(_0x3c8a0d))return!0x1;for(let _0x218d3a=_0x4a4e0f['pieceNum_'],_0x3aec6a=_0x3c8a0d['pieceNum_'];_0x218d3a<=_0x4a4e0f['pieces_']['length'];_0x218d3a++,_0x3aec6a++)if(_0x4a4e0f['pieces_'][_0x218d3a]!==_0x3c8a0d['pieces_'][_0x3aec6a])return!0x1;return!0x0;}function G(_0x39a5cb,_0x5a746f){let _0x2e295d=_0x39a5cb['pieceNum_'],_0x3736d5=_0x5a746f['pieceNum_'];if(Ce(_0x39a5cb)>Ce(_0x5a746f))return!0x1;for(;_0x2e295d<_0x39a5cb['pieces_']['length'];){if(_0x39a5cb['pieces_'][_0x2e295d]!==_0x5a746f['pieces_'][_0x3736d5])return!0x1;++_0x2e295d,++_0x3736d5;}return!0x0;}class Ah{constructor(_0xe3df19,_0x55c338){this['errorPrefix_']=_0x55c338,this['parts_']=Mt(_0xe3df19,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x198578=0x0;_0x198578<this['parts_']['length'];_0x198578++)this['byteLength_']+=Ln(this['parts_'][_0x198578]);Ao(this);}}function kh(_0x2c83ee,_0x5615b4){_0x2c83ee['parts_']['length']>0x0&&(_0x2c83ee['byteLength_']+=0x1),_0x2c83ee['parts_']['push'](_0x5615b4),_0x2c83ee['byteLength_']+=Ln(_0x5615b4),Ao(_0x2c83ee);}function Ph(_0x590dc4){const _0x413375=_0x590dc4['parts_']['pop']();_0x590dc4['byteLength_']-=Ln(_0x413375),_0x590dc4['parts_']['length']>0x0&&(_0x590dc4['byteLength_']-=0x1);}function Ao(_0x2a3d7f){if(_0x2a3d7f['byteLength_']>Zs)throw new Error(_0x2a3d7f['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x2a3d7f['byteLength_']+').');if(_0x2a3d7f['parts_']['length']>Xs)throw new Error(_0x2a3d7f['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x2a3d7f));}function Oe(_0x4bd6b1){return _0x4bd6b1['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x4bd6b1['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x1a1f05,_0xca6896;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0xca6896='visibilitychange',_0x1a1f05='hidden'):typeof document['mozHidden']<'u'?(_0xca6896='mozvisibilitychange',_0x1a1f05='mozHidden'):typeof document['msHidden']<'u'?(_0xca6896='msvisibilitychange',_0x1a1f05='msHidden'):typeof document['webkitHidden']<'u'&&(_0xca6896='webkitvisibilitychange',_0x1a1f05='webkitHidden')),this['visible_']=!0x0,_0xca6896&&document['addEventListener'](_0xca6896,()=>{const _0x2cba31=!document[_0x1a1f05];_0x2cba31!==this['visible_']&&(this['visible_']=_0x2cba31,this['trigger']('visible',_0x2cba31));},!0x1);}['getInitialEvent'](_0x40f626){return f(_0x40f626==='visible','Unknown\x20event\x20type:\x20'+_0x40f626),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x1e1b61,_0x35ffb8,_0x1f8185,_0x18c405,_0xc5ca8e,_0x5554ab,_0x303cf8,_0x274fdb){if(super(),this['repoInfo_']=_0x1e1b61,this['applicationId_']=_0x35ffb8,this['onDataUpdate_']=_0x1f8185,this['onConnectStatus_']=_0x18c405,this['onServerInfoUpdate_']=_0xc5ca8e,this['authTokenProvider_']=_0x5554ab,this['appCheckTokenProvider_']=_0x303cf8,this['authOverride_']=_0x274fdb,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x274fdb)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x1e1b61['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x1e6cda,_0x146a73,_0x32b87a){const _0x2efa00=++this['requestNumber_'],_0x538b75={'r':_0x2efa00,'a':_0x1e6cda,'b':_0x146a73};this['log_'](O(_0x538b75)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x538b75),_0x32b87a&&(this['requestCBHash_'][_0x2efa00]=_0x32b87a);}['get'](_0x21349e){this['initConnection_']();const _0x25f325=new H(),_0x1a9621={'action':'g','request':{'p':_0x21349e['_path']['toString'](),'q':_0x21349e['_queryObject']},'onComplete':_0xf0c396=>{const _0x322dc5=_0xf0c396['d'];_0xf0c396['s']==='ok'?_0x25f325['resolve'](_0x322dc5):_0x25f325['reject'](_0x322dc5);}};this['outstandingGets_']['push'](_0x1a9621),this['outstandingGetCount_']++;const _0x35a4f7=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x35a4f7),_0x25f325['promise'];}['listen'](_0x104b37,_0x27cd91,_0xd51785,_0x37fb22){this['initConnection_']();const _0x3575ef=_0x104b37['_queryIdentifier'],_0x4fa1a3=_0x104b37['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x4fa1a3+'\x20'+_0x3575ef),this['listens']['has'](_0x4fa1a3)||this['listens']['set'](_0x4fa1a3,new Map()),f(_0x104b37['_queryParams']['isDefault']()||!_0x104b37['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x4fa1a3)['has'](_0x3575ef),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x50cb86={'onComplete':_0x37fb22,'hashFn':_0x27cd91,'query':_0x104b37,'tag':_0xd51785};this['listens']['get'](_0x4fa1a3)['set'](_0x3575ef,_0x50cb86),this['connected_']&&this['sendListen_'](_0x50cb86);}['sendGet_'](_0x51368d){const _0x7ffdb=this['outstandingGets_'][_0x51368d];this['sendRequest']('g',_0x7ffdb['request'],_0x5d00b8=>{delete this['outstandingGets_'][_0x51368d],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x7ffdb['onComplete']&&_0x7ffdb['onComplete'](_0x5d00b8);});}['sendListen_'](_0x328fac){const _0x30c99f=_0x328fac['query'],_0x53da8d=_0x30c99f['_path']['toString'](),_0x43217e=_0x30c99f['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x53da8d+'\x20for\x20'+_0x43217e);const _0x42b252={'p':_0x53da8d},_0x4e9467='q';_0x328fac['tag']&&(_0x42b252['q']=_0x30c99f['_queryObject'],_0x42b252['t']=_0x328fac['tag']),_0x42b252['h']=_0x328fac['hashFn'](),this['sendRequest'](_0x4e9467,_0x42b252,_0x55e20f=>{const _0x3ecf7c=_0x55e20f['d'],_0x582822=_0x55e20f['s'];se['warnOnListenWarnings_'](_0x3ecf7c,_0x30c99f),(this['listens']['get'](_0x53da8d)&&this['listens']['get'](_0x53da8d)['get'](_0x43217e))===_0x328fac&&(this['log_']('listen\x20response',_0x55e20f),_0x582822!=='ok'&&this['removeListen_'](_0x53da8d,_0x43217e),_0x328fac['onComplete']&&_0x328fac['onComplete'](_0x582822,_0x3ecf7c));});}static['warnOnListenWarnings_'](_0x47b291,_0x43aaf0){if(_0x47b291&&typeof _0x47b291=='object'&&Q(_0x47b291,'w')){const _0x45f5ce=Le(_0x47b291,'w');if(Array['isArray'](_0x45f5ce)&&~_0x45f5ce['indexOf']('no_index')){const _0x2f60f3='\x22.indexOn\x22:\x20\x22'+_0x43aaf0['_queryParams']['getIndex']()['toString']()+'\x22',_0x35c61f=_0x43aaf0['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x2f60f3+'\x20at\x20'+_0x35c61f+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x331984){this['authToken_']=_0x331984,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x331984);}['reduceReconnectDelayIfAdminCredential_'](_0x1ca184){(_0x1ca184&&_0x1ca184['length']===0x28||wc(_0x1ca184))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x2c6244){this['appCheckToken_']=_0x2c6244,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x596829=this['authToken_'],_0x1978e7=Ic(_0x596829)?'auth':'gauth',_0x178ba4={'cred':_0x596829};this['authOverride_']===null?_0x178ba4['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x178ba4['authvar']=this['authOverride_']),this['sendRequest'](_0x1978e7,_0x178ba4,_0x1cf4e3=>{const _0x4837c7=_0x1cf4e3['s'],_0x2b1212=_0x1cf4e3['d']||'error';this['authToken_']===_0x596829&&(_0x4837c7==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x4837c7,_0x2b1212));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x40edde=>{const _0xcf4bef=_0x40edde['s'],_0x590d85=_0x40edde['d']||'error';_0xcf4bef==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0xcf4bef,_0x590d85);});}['unlisten'](_0x24afcb,_0x3a39ba){const _0x3aa8bb=_0x24afcb['_path']['toString'](),_0x3cf2e5=_0x24afcb['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x3aa8bb+'\x20'+_0x3cf2e5),f(_0x24afcb['_queryParams']['isDefault']()||!_0x24afcb['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x3aa8bb,_0x3cf2e5)&&this['connected_']&&this['sendUnlisten_'](_0x3aa8bb,_0x3cf2e5,_0x24afcb['_queryObject'],_0x3a39ba);}['sendUnlisten_'](_0x2814c1,_0x35fb4b,_0x58c7bc,_0x486cbc){this['log_']('Unlisten\x20on\x20'+_0x2814c1+'\x20for\x20'+_0x35fb4b);const _0xcfe835={'p':_0x2814c1},_0x59c885='n';_0x486cbc&&(_0xcfe835['q']=_0x58c7bc,_0xcfe835['t']=_0x486cbc),this['sendRequest'](_0x59c885,_0xcfe835);}['onDisconnectPut'](_0x20bfe8,_0x3f122f,_0x54c0a0){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x20bfe8,_0x3f122f,_0x54c0a0):this['onDisconnectRequestQueue_']['push']({'pathString':_0x20bfe8,'action':'o','data':_0x3f122f,'onComplete':_0x54c0a0});}['onDisconnectMerge'](_0x190d0e,_0x5615bb,_0x12c8f6){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x190d0e,_0x5615bb,_0x12c8f6):this['onDisconnectRequestQueue_']['push']({'pathString':_0x190d0e,'action':'om','data':_0x5615bb,'onComplete':_0x12c8f6});}['onDisconnectCancel'](_0x43570,_0x2f28cc){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x43570,null,_0x2f28cc):this['onDisconnectRequestQueue_']['push']({'pathString':_0x43570,'action':'oc','data':null,'onComplete':_0x2f28cc});}['sendOnDisconnect_'](_0x3fb89b,_0x4ebcb9,_0x5c86d5,_0x3cea9e){const _0x52c932={'p':_0x4ebcb9,'d':_0x5c86d5};this['log_']('onDisconnect\x20'+_0x3fb89b,_0x52c932),this['sendRequest'](_0x3fb89b,_0x52c932,_0x9446ee=>{_0x3cea9e&&setTimeout(()=>{_0x3cea9e(_0x9446ee['s'],_0x9446ee['d']);},Math['floor'](0x0));});}['put'](_0x2859c0,_0x5b86cb,_0x5b1f5a,_0x3cee08){this['putInternal']('p',_0x2859c0,_0x5b86cb,_0x5b1f5a,_0x3cee08);}['merge'](_0x1f672e,_0x536b90,_0xfd63fd,_0x34c61a){this['putInternal']('m',_0x1f672e,_0x536b90,_0xfd63fd,_0x34c61a);}['putInternal'](_0x1673d1,_0x56ddce,_0x202ac5,_0x3393d2,_0x3107bf){this['initConnection_']();const _0x2f96a0={'p':_0x56ddce,'d':_0x202ac5};_0x3107bf!==void 0x0&&(_0x2f96a0['h']=_0x3107bf),this['outstandingPuts_']['push']({'action':_0x1673d1,'request':_0x2f96a0,'onComplete':_0x3393d2}),this['outstandingPutCount_']++;const _0x4a8628=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x4a8628):this['log_']('Buffering\x20put:\x20'+_0x56ddce);}['sendPut_'](_0x5625bc){const _0x448fcb=this['outstandingPuts_'][_0x5625bc]['action'],_0xd8977b=this['outstandingPuts_'][_0x5625bc]['request'],_0x81ddb=this['outstandingPuts_'][_0x5625bc]['onComplete'];this['outstandingPuts_'][_0x5625bc]['queued']=this['connected_'],this['sendRequest'](_0x448fcb,_0xd8977b,_0x5bd832=>{this['log_'](_0x448fcb+'\x20response',_0x5bd832),delete this['outstandingPuts_'][_0x5625bc],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x81ddb&&_0x81ddb(_0x5bd832['s'],_0x5bd832['d']);});}['reportStats'](_0x3000ea){if(this['connected_']){const _0x33ab1d={'c':_0x3000ea};this['log_']('reportStats',_0x33ab1d),this['sendRequest']('s',_0x33ab1d,_0x4ad0aa=>{if(_0x4ad0aa['s']!=='ok'){const _0x29e21c=_0x4ad0aa['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x29e21c);}});}}['onDataMessage_'](_0x2b467b){if('r'in _0x2b467b){this['log_']('from\x20server:\x20'+O(_0x2b467b));const _0x2b84bb=_0x2b467b['r'],_0x314dab=this['requestCBHash_'][_0x2b84bb];_0x314dab&&(delete this['requestCBHash_'][_0x2b84bb],_0x314dab(_0x2b467b['b']));}else{if('error'in _0x2b467b)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x2b467b['error'];'a'in _0x2b467b&&this['onDataPush_'](_0x2b467b['a'],_0x2b467b['b']);}}['onDataPush_'](_0x54c592,_0x4a3fd7){this['log_']('handleServerMessage',_0x54c592,_0x4a3fd7),_0x54c592==='d'?this['onDataUpdate_'](_0x4a3fd7['p'],_0x4a3fd7['d'],!0x1,_0x4a3fd7['t']):_0x54c592==='m'?this['onDataUpdate_'](_0x4a3fd7['p'],_0x4a3fd7['d'],!0x0,_0x4a3fd7['t']):_0x54c592==='c'?this['onListenRevoked_'](_0x4a3fd7['p'],_0x4a3fd7['q']):_0x54c592==='ac'?this['onAuthRevoked_'](_0x4a3fd7['s'],_0x4a3fd7['d']):_0x54c592==='apc'?this['onAppCheckRevoked_'](_0x4a3fd7['s'],_0x4a3fd7['d']):_0x54c592==='sd'?this['onSecurityDebugPacket_'](_0x4a3fd7):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x54c592)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x2fdf60,_0x277981){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x2fdf60),this['lastSessionId']=_0x277981,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x925957){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x925957));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x51ca7e){_0x51ca7e&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x51ca7e;}['onOnline_'](_0x100e16){_0x100e16?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x521da4=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x44dd61=Math['max'](0x0,this['reconnectDelay_']-_0x521da4);_0x44dd61=Math['random']()*_0x44dd61,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x44dd61+'ms'),this['scheduleConnect_'](_0x44dd61),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x46a8f2=this['onDataMessage_']['bind'](this),_0x5572fd=this['onReady_']['bind'](this),_0x40f4b6=this['onRealtimeDisconnect_']['bind'](this),_0x3c883c=this['id']+':'+se['nextConnectionId_']++,_0x40d628=this['lastSessionId'];let _0x4c3ed3=!0x1,_0x8c8945=null;const _0x42a35a=function(){_0x8c8945?_0x8c8945['close']():(_0x4c3ed3=!0x0,_0x40f4b6());},_0x3a7d93=function(_0x3ef2b4){f(_0x8c8945,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x8c8945['sendRequest'](_0x3ef2b4);};this['realtime_']={'close':_0x42a35a,'sendRequest':_0x3a7d93};const _0x3b8d61=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x1b5bda,_0x37b778]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x3b8d61),this['appCheckTokenProvider_']['getToken'](_0x3b8d61)]);_0x4c3ed3?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x1b5bda&&_0x1b5bda['accessToken'],this['appCheckToken_']=_0x37b778&&_0x37b778['token'],_0x8c8945=new Sh(_0x3c883c,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x46a8f2,_0x5572fd,_0x40f4b6,_0x57b00c=>{U(_0x57b00c+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x40d628));}catch(_0x335a8f){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x335a8f),_0x4c3ed3||(this['repoInfo_']['nodeAdmin']&&U(_0x335a8f),_0x42a35a());}}}['interrupt'](_0x4eeed3){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x4eeed3),this['interruptReasons_'][_0x4eeed3]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x289d82){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x289d82),delete this['interruptReasons_'][_0x289d82],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x43b7ad){const _0x372e61=_0x43b7ad-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x372e61});}['cancelSentTransactions_'](){for(let _0x4cb4a1=0x0;_0x4cb4a1<this['outstandingPuts_']['length'];_0x4cb4a1++){const _0x43b03e=this['outstandingPuts_'][_0x4cb4a1];_0x43b03e&&'h'in _0x43b03e['request']&&_0x43b03e['queued']&&(_0x43b03e['onComplete']&&_0x43b03e['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x4cb4a1],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x3c6bee,_0x31b0f3){let _0x30e0ae;_0x31b0f3?_0x30e0ae=_0x31b0f3['map'](_0x36484c=>$i(_0x36484c))['join']('$'):_0x30e0ae='default';const _0x3f2cab=this['removeListen_'](_0x3c6bee,_0x30e0ae);_0x3f2cab&&_0x3f2cab['onComplete']&&_0x3f2cab['onComplete']('permission_denied');}['removeListen_'](_0x2e8b6c,_0x4060c5){const _0x4da81e=new C(_0x2e8b6c)['toString']();let _0x5d48a2;if(this['listens']['has'](_0x4da81e)){const _0x8dc223=this['listens']['get'](_0x4da81e);_0x5d48a2=_0x8dc223['get'](_0x4060c5),_0x8dc223['delete'](_0x4060c5),_0x8dc223['size']===0x0&&this['listens']['delete'](_0x4da81e);}else _0x5d48a2=void 0x0;return _0x5d48a2;}['onAuthRevoked_'](_0x7a8fe0,_0x157b02){L('Auth\x20token\x20revoked:\x20'+_0x7a8fe0+'/'+_0x157b02),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x7a8fe0==='invalid_token'||_0x7a8fe0==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x2b6f76,_0x3f3502){L('App\x20check\x20token\x20revoked:\x20'+_0x2b6f76+'/'+_0x3f3502),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x2b6f76==='invalid_token'||_0x2b6f76==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0xa57e2d){this['securityDebugCallback_']?this['securityDebugCallback_'](_0xa57e2d):'msg'in _0xa57e2d&&console['log']('FIREBASE:\x20'+_0xa57e2d['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x256167 of this['listens']['values']())for(const _0x38ebdb of _0x256167['values']())this['sendListen_'](_0x38ebdb);for(let _0x4f9334=0x0;_0x4f9334<this['outstandingPuts_']['length'];_0x4f9334++)this['outstandingPuts_'][_0x4f9334]&&this['sendPut_'](_0x4f9334);for(;this['onDisconnectRequestQueue_']['length'];){const _0x5a164b=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x5a164b['action'],_0x5a164b['pathString'],_0x5a164b['data'],_0x5a164b['onComplete']);}for(let _0x3e24ed=0x0;_0x3e24ed<this['outstandingGets_']['length'];_0x3e24ed++)this['outstandingGets_'][_0x3e24ed]&&this['sendGet_'](_0x3e24ed);}['sendConnectStats_'](){const _0x16578f={};let _0xc9d7b6='js';_0x16578f['sdk.'+_0xc9d7b6+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x16578f['framework.cordova']=0x1:Kr()&&(_0x16578f['framework.reactnative']=0x1),this['reportStats'](_0x16578f);}['shouldReconnect_'](){const _0x29c459=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x29c459;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x4844ee,_0x57aed0){this['name']=_0x4844ee,this['node']=_0x57aed0;}static['Wrap'](_0x2ad847,_0x19c38a){return new E(_0x2ad847,_0x19c38a);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x5372eb,_0x448b02){const _0x319274=new E(We,_0x5372eb),_0x2b385b=new E(We,_0x448b02);return this['compare'](_0x319274,_0x2b385b)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0xf718fd){sn=_0xf718fd;}['compare'](_0x245b53,_0x2d4fd0){return qe(_0x245b53['name'],_0x2d4fd0['name']);}['isDefinedOn'](_0x315538){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x21859f,_0x30c049){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x4216f1,_0x159f5b){return f(typeof _0x4216f1=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x4216f1,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x3ca2b4,_0x361536,_0x9262fa,_0x1cab18,_0x40f8ac=null){this['isReverse_']=_0x1cab18,this['resultGenerator_']=_0x40f8ac,this['nodeStack_']=[];let _0x541d27=0x1;for(;!_0x3ca2b4['isEmpty']();)if(_0x3ca2b4=_0x3ca2b4,_0x541d27=_0x361536?_0x9262fa(_0x3ca2b4['key'],_0x361536):0x1,_0x1cab18&&(_0x541d27*=-0x1),_0x541d27<0x0)this['isReverse_']?_0x3ca2b4=_0x3ca2b4['left']:_0x3ca2b4=_0x3ca2b4['right'];else{if(_0x541d27===0x0){this['nodeStack_']['push'](_0x3ca2b4);break;}else this['nodeStack_']['push'](_0x3ca2b4),this['isReverse_']?_0x3ca2b4=_0x3ca2b4['right']:_0x3ca2b4=_0x3ca2b4['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0xf071af=this['nodeStack_']['pop'](),_0x467377;if(this['resultGenerator_']?_0x467377=this['resultGenerator_'](_0xf071af['key'],_0xf071af['value']):_0x467377={'key':_0xf071af['key'],'value':_0xf071af['value']},this['isReverse_']){for(_0xf071af=_0xf071af['left'];!_0xf071af['isEmpty']();)this['nodeStack_']['push'](_0xf071af),_0xf071af=_0xf071af['right'];}else{for(_0xf071af=_0xf071af['right'];!_0xf071af['isEmpty']();)this['nodeStack_']['push'](_0xf071af),_0xf071af=_0xf071af['left'];}return _0x467377;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x54f4c9=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x54f4c9['key'],_0x54f4c9['value']):{'key':_0x54f4c9['key'],'value':_0x54f4c9['value']};}}class M{constructor(_0x30ca02,_0xb02903,_0x105756,_0x3bee09,_0x347c84){this['key']=_0x30ca02,this['value']=_0xb02903,this['color']=_0x105756??M['RED'],this['left']=_0x3bee09??B['EMPTY_NODE'],this['right']=_0x347c84??B['EMPTY_NODE'];}['copy'](_0x512d44,_0x59cc3b,_0x55fd1b,_0xe455fe,_0x3cf43a){return new M(_0x512d44??this['key'],_0x59cc3b??this['value'],_0x55fd1b??this['color'],_0xe455fe??this['left'],_0x3cf43a??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x428410){return this['left']['inorderTraversal'](_0x428410)||!!_0x428410(this['key'],this['value'])||this['right']['inorderTraversal'](_0x428410);}['reverseTraversal'](_0x5ba241){return this['right']['reverseTraversal'](_0x5ba241)||_0x5ba241(this['key'],this['value'])||this['left']['reverseTraversal'](_0x5ba241);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x1da8d8,_0x56d0e9,_0x9b5697){let _0x2852fa=this;const _0x3ecd91=_0x9b5697(_0x1da8d8,_0x2852fa['key']);return _0x3ecd91<0x0?_0x2852fa=_0x2852fa['copy'](null,null,null,_0x2852fa['left']['insert'](_0x1da8d8,_0x56d0e9,_0x9b5697),null):_0x3ecd91===0x0?_0x2852fa=_0x2852fa['copy'](null,_0x56d0e9,null,null,null):_0x2852fa=_0x2852fa['copy'](null,null,null,null,_0x2852fa['right']['insert'](_0x1da8d8,_0x56d0e9,_0x9b5697)),_0x2852fa['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x89658b=this;return!_0x89658b['left']['isRed_']()&&!_0x89658b['left']['left']['isRed_']()&&(_0x89658b=_0x89658b['moveRedLeft_']()),_0x89658b=_0x89658b['copy'](null,null,null,_0x89658b['left']['removeMin_'](),null),_0x89658b['fixUp_']();}['remove'](_0x1f3435,_0x3d8779){let _0x45e001,_0x45c9e9;if(_0x45e001=this,_0x3d8779(_0x1f3435,_0x45e001['key'])<0x0)!_0x45e001['left']['isEmpty']()&&!_0x45e001['left']['isRed_']()&&!_0x45e001['left']['left']['isRed_']()&&(_0x45e001=_0x45e001['moveRedLeft_']()),_0x45e001=_0x45e001['copy'](null,null,null,_0x45e001['left']['remove'](_0x1f3435,_0x3d8779),null);else{if(_0x45e001['left']['isRed_']()&&(_0x45e001=_0x45e001['rotateRight_']()),!_0x45e001['right']['isEmpty']()&&!_0x45e001['right']['isRed_']()&&!_0x45e001['right']['left']['isRed_']()&&(_0x45e001=_0x45e001['moveRedRight_']()),_0x3d8779(_0x1f3435,_0x45e001['key'])===0x0){if(_0x45e001['right']['isEmpty']())return B['EMPTY_NODE'];_0x45c9e9=_0x45e001['right']['min_'](),_0x45e001=_0x45e001['copy'](_0x45c9e9['key'],_0x45c9e9['value'],null,null,_0x45e001['right']['removeMin_']());}_0x45e001=_0x45e001['copy'](null,null,null,null,_0x45e001['right']['remove'](_0x1f3435,_0x3d8779));}return _0x45e001['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x44528b=this;return _0x44528b['right']['isRed_']()&&!_0x44528b['left']['isRed_']()&&(_0x44528b=_0x44528b['rotateLeft_']()),_0x44528b['left']['isRed_']()&&_0x44528b['left']['left']['isRed_']()&&(_0x44528b=_0x44528b['rotateRight_']()),_0x44528b['left']['isRed_']()&&_0x44528b['right']['isRed_']()&&(_0x44528b=_0x44528b['colorFlip_']()),_0x44528b;}['moveRedLeft_'](){let _0x576a08=this['colorFlip_']();return _0x576a08['right']['left']['isRed_']()&&(_0x576a08=_0x576a08['copy'](null,null,null,null,_0x576a08['right']['rotateRight_']()),_0x576a08=_0x576a08['rotateLeft_'](),_0x576a08=_0x576a08['colorFlip_']()),_0x576a08;}['moveRedRight_'](){let _0x12e875=this['colorFlip_']();return _0x12e875['left']['left']['isRed_']()&&(_0x12e875=_0x12e875['rotateRight_'](),_0x12e875=_0x12e875['colorFlip_']()),_0x12e875;}['rotateLeft_'](){const _0x2737dc=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x2737dc,null);}['rotateRight_'](){const _0x5a3ce1=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x5a3ce1);}['colorFlip_'](){const _0x33cd14=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x12123e=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x33cd14,_0x12123e);}['checkMaxDepth_'](){const _0xfb4d6=this['check_']();return Math['pow'](0x2,_0xfb4d6)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x16e2d0=this['left']['check_']();if(_0x16e2d0!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x16e2d0+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x396373,_0x34d025,_0x5e1f70,_0x419ae1,_0x54e1cc){return this;}['insert'](_0x3a79b5,_0x1fe81f,_0x72c803){return new M(_0x3a79b5,_0x1fe81f,null);}['remove'](_0x19fac5,_0x46b6f1){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x2586d7){return!0x1;}['reverseTraversal'](_0x449fa5){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x3c4318,_0x4a5fe7=B['EMPTY_NODE']){this['comparator_']=_0x3c4318,this['root_']=_0x4a5fe7;}['insert'](_0x5dc03e,_0x58bb3c){return new B(this['comparator_'],this['root_']['insert'](_0x5dc03e,_0x58bb3c,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x15bdc5){return new B(this['comparator_'],this['root_']['remove'](_0x15bdc5,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x185997){let _0x271782,_0x1b22ca=this['root_'];for(;!_0x1b22ca['isEmpty']();){if(_0x271782=this['comparator_'](_0x185997,_0x1b22ca['key']),_0x271782===0x0)return _0x1b22ca['value'];_0x271782<0x0?_0x1b22ca=_0x1b22ca['left']:_0x271782>0x0&&(_0x1b22ca=_0x1b22ca['right']);}return null;}['getPredecessorKey'](_0x491ae3){let _0x29fa96,_0x22116e=this['root_'],_0x184f35=null;for(;!_0x22116e['isEmpty']();)if(_0x29fa96=this['comparator_'](_0x491ae3,_0x22116e['key']),_0x29fa96===0x0){if(_0x22116e['left']['isEmpty']())return _0x184f35?_0x184f35['key']:null;for(_0x22116e=_0x22116e['left'];!_0x22116e['right']['isEmpty']();)_0x22116e=_0x22116e['right'];return _0x22116e['key'];}else _0x29fa96<0x0?_0x22116e=_0x22116e['left']:_0x29fa96>0x0&&(_0x184f35=_0x22116e,_0x22116e=_0x22116e['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x168c44){return this['root_']['inorderTraversal'](_0x168c44);}['reverseTraversal'](_0x580a99){return this['root_']['reverseTraversal'](_0x580a99);}['getIterator'](_0x5dcad5){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x5dcad5);}['getIteratorFrom'](_0xdfe4d3,_0x45dc40){return new rn(this['root_'],_0xdfe4d3,this['comparator_'],!0x1,_0x45dc40);}['getReverseIteratorFrom'](_0x561486,_0x10e1db){return new rn(this['root_'],_0x561486,this['comparator_'],!0x0,_0x10e1db);}['getReverseIterator'](_0x3bfc5f){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x3bfc5f);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x293f26,_0x538d72){return qe(_0x293f26['name'],_0x538d72['name']);}function Qi(_0x37775d,_0x4cedbc){return qe(_0x37775d,_0x4cedbc);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x2d7bf8){Ci=_0x2d7bf8;}const Po=function(_0x4b91c9){return typeof _0x4b91c9=='number'?'number:'+ao(_0x4b91c9):'string:'+_0x4b91c9;},No=function(_0x49b20b){if(_0x49b20b['isLeafNode']()){const _0x1d86a6=_0x49b20b['val']();f(typeof _0x1d86a6=='string'||typeof _0x1d86a6=='number'||typeof _0x1d86a6=='object'&&Q(_0x1d86a6,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x49b20b===Ci||_0x49b20b['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x49b20b===Ci||_0x49b20b['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x53df49){nr=_0x53df49;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x1fff63,_0x31102b=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x1fff63,this['priorityNode_']=_0x31102b,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x4faee0){return new D(this['value_'],_0x4faee0);}['getImmediateChild'](_0x42bf3e){return _0x42bf3e==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x5a5708){return v(_0x5a5708)?this:y(_0x5a5708)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x1a6de2,_0x534180){return null;}['updateImmediateChild'](_0x572cfc,_0x1cda70){return _0x572cfc==='.priority'?this['updatePriority'](_0x1cda70):_0x1cda70['isEmpty']()&&_0x572cfc!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x572cfc,_0x1cda70)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x1fbcbc,_0x38808a){const _0x4267a6=y(_0x1fbcbc);return _0x4267a6===null?_0x38808a:_0x38808a['isEmpty']()&&_0x4267a6!=='.priority'?this:(f(_0x4267a6!=='.priority'||Ce(_0x1fbcbc)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x4267a6,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x1fbcbc),_0x38808a)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x4e9e91,_0x4d9f6a){return!0x1;}['val'](_0x45a697){return _0x45a697&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x42edfe='';this['priorityNode_']['isEmpty']()||(_0x42edfe+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x1ba239=typeof this['value_'];_0x42edfe+=_0x1ba239+':',_0x1ba239==='number'?_0x42edfe+=ao(this['value_']):_0x42edfe+=this['value_'],this['lazyHash_']=ro(_0x42edfe);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x688192){return _0x688192===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x688192 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x688192['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x688192));}['compareToLeafNode_'](_0x50f730){const _0x47f716=typeof _0x50f730['value_'],_0x13238e=typeof this['value_'],_0x265798=D['VALUE_TYPE_ORDER']['indexOf'](_0x47f716),_0x4ad769=D['VALUE_TYPE_ORDER']['indexOf'](_0x13238e);return f(_0x265798>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x47f716),f(_0x4ad769>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x13238e),_0x265798===_0x4ad769?_0x13238e==='object'?0x0:this['value_']<_0x50f730['value_']?-0x1:this['value_']===_0x50f730['value_']?0x0:0x1:_0x4ad769-_0x265798;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x32d804){if(_0x32d804===this)return!0x0;if(_0x32d804['isLeafNode']()){const _0x1d946d=_0x32d804;return this['value_']===_0x1d946d['value_']&&this['priorityNode_']['equals'](_0x1d946d['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x564672){Oo=_0x564672;}function Wh(_0x137c3c){Do=_0x137c3c;}class Bh extends Fn{['compare'](_0x292dd3,_0x2a6f87){const _0x55a3f0=_0x292dd3['node']['getPriority'](),_0x2215a7=_0x2a6f87['node']['getPriority'](),_0x10b5eb=_0x55a3f0['compareTo'](_0x2215a7);return _0x10b5eb===0x0?qe(_0x292dd3['name'],_0x2a6f87['name']):_0x10b5eb;}['isDefinedOn'](_0x4bba84){return!_0x4bba84['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x23209a,_0x25b244){return!_0x23209a['getPriority']()['equals'](_0x25b244['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x5e02b3,_0x329673){const _0x38a935=Oo(_0x5e02b3);return new E(_0x329673,new D('[PRIORITY-POST]',_0x38a935));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x4bae77){const _0x7d24e0=_0x170846=>parseInt(Math['log'](_0x170846)/Vh,0xa),_0x37f177=_0x154eba=>parseInt(Array(_0x154eba+0x1)['join']('1'),0x2);this['count']=_0x7d24e0(_0x4bae77+0x1),this['current_']=this['count']-0x1;const _0x1ef81d=_0x37f177(this['count']);this['bits_']=_0x4bae77+0x1&_0x1ef81d;}['nextBitIsOne'](){const _0x2a5502=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x2a5502;}}const yn=function(_0x39ec7b,_0x1281dc,_0x1f121b,_0x5a201c){_0x39ec7b['sort'](_0x1281dc);const _0x4cb66b=function(_0x4d28c6,_0x4923d5){const _0x58fefc=_0x4923d5-_0x4d28c6;let _0x2a11bc,_0x18e086;if(_0x58fefc===0x0)return null;if(_0x58fefc===0x1)return _0x2a11bc=_0x39ec7b[_0x4d28c6],_0x18e086=_0x1f121b?_0x1f121b(_0x2a11bc):_0x2a11bc,new M(_0x18e086,_0x2a11bc['node'],M['BLACK'],null,null);{const _0x34c911=parseInt(_0x58fefc/0x2,0xa)+_0x4d28c6,_0x6028bb=_0x4cb66b(_0x4d28c6,_0x34c911),_0x43c2e3=_0x4cb66b(_0x34c911+0x1,_0x4923d5);return _0x2a11bc=_0x39ec7b[_0x34c911],_0x18e086=_0x1f121b?_0x1f121b(_0x2a11bc):_0x2a11bc,new M(_0x18e086,_0x2a11bc['node'],M['BLACK'],_0x6028bb,_0x43c2e3);}},_0x2e5add=function(_0x15fc0c){let _0x459c7d=null,_0x29b979=null,_0x50fab6=_0x39ec7b['length'];const _0xd44193=function(_0x5c1568,_0xdca9a3){const _0x399e93=_0x50fab6-_0x5c1568,_0x494bba=_0x50fab6;_0x50fab6-=_0x5c1568;const _0x486025=_0x4cb66b(_0x399e93+0x1,_0x494bba),_0xe60abc=_0x39ec7b[_0x399e93],_0x173caa=_0x1f121b?_0x1f121b(_0xe60abc):_0xe60abc;_0xe27657(new M(_0x173caa,_0xe60abc['node'],_0xdca9a3,null,_0x486025));},_0xe27657=function(_0x5f543e){_0x459c7d?(_0x459c7d['left']=_0x5f543e,_0x459c7d=_0x5f543e):(_0x29b979=_0x5f543e,_0x459c7d=_0x5f543e);};for(let _0x29c9f0=0x0;_0x29c9f0<_0x15fc0c['count'];++_0x29c9f0){const _0x33edbe=_0x15fc0c['nextBitIsOne'](),_0x537ba4=Math['pow'](0x2,_0x15fc0c['count']-(_0x29c9f0+0x1));_0x33edbe?_0xd44193(_0x537ba4,M['BLACK']):(_0xd44193(_0x537ba4,M['BLACK']),_0xd44193(_0x537ba4,M['RED']));}return _0x29b979;},_0x21c4eb=new Hh(_0x39ec7b['length']),_0x48291f=_0x2e5add(_0x21c4eb);return new B(_0x5a201c||_0x1281dc,_0x48291f);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x3e68f4,_0x5ef786){this['indexes_']=_0x3e68f4,this['indexSet_']=_0x5ef786;}['get'](_0x4cdda){const _0x51c232=Le(this['indexes_'],_0x4cdda);if(!_0x51c232)throw new Error('No\x20index\x20defined\x20for\x20'+_0x4cdda);return _0x51c232 instanceof B?_0x51c232:null;}['hasIndex'](_0xfc6c4d){return Q(this['indexSet_'],_0xfc6c4d['toString']());}['addIndex'](_0x332a9e,_0x3e56fa){f(_0x332a9e!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x24b0ee=[];let _0x1b58ac=!0x1;const _0x4a4587=_0x3e56fa['getIterator'](E['Wrap']);let _0x4e99f0=_0x4a4587['getNext']();for(;_0x4e99f0;)_0x1b58ac=_0x1b58ac||_0x332a9e['isDefinedOn'](_0x4e99f0['node']),_0x24b0ee['push'](_0x4e99f0),_0x4e99f0=_0x4a4587['getNext']();let _0x447bf4;_0x1b58ac?_0x447bf4=yn(_0x24b0ee,_0x332a9e['getCompare']()):_0x447bf4=Qe;const _0x50516c=_0x332a9e['toString'](),_0x4e8f3e={...this['indexSet_']};_0x4e8f3e[_0x50516c]=_0x332a9e;const _0x513483={...this['indexes_']};return _0x513483[_0x50516c]=_0x447bf4,new te(_0x513483,_0x4e8f3e);}['addToIndexes'](_0x109cc8,_0x5ab217){const _0x2e94cb=_n(this['indexes_'],(_0x149427,_0x312287)=>{const _0x51377b=Le(this['indexSet_'],_0x312287);if(f(_0x51377b,'Missing\x20index\x20implementation\x20for\x20'+_0x312287),_0x149427===Qe){if(_0x51377b['isDefinedOn'](_0x109cc8['node'])){const _0x4d7423=[],_0x91fb31=_0x5ab217['getIterator'](E['Wrap']);let _0x42cce5=_0x91fb31['getNext']();for(;_0x42cce5;)_0x42cce5['name']!==_0x109cc8['name']&&_0x4d7423['push'](_0x42cce5),_0x42cce5=_0x91fb31['getNext']();return _0x4d7423['push'](_0x109cc8),yn(_0x4d7423,_0x51377b['getCompare']());}else return Qe;}else{const _0x4e88df=_0x5ab217['get'](_0x109cc8['name']);let _0x458a27=_0x149427;return _0x4e88df&&(_0x458a27=_0x458a27['remove'](new E(_0x109cc8['name'],_0x4e88df))),_0x458a27['insert'](_0x109cc8,_0x109cc8['node']);}});return new te(_0x2e94cb,this['indexSet_']);}['removeFromIndexes'](_0x4285e7,_0x56d81c){const _0x3cc5a7=_n(this['indexes_'],_0x23ee41=>{if(_0x23ee41===Qe)return _0x23ee41;{const _0x3c7618=_0x56d81c['get'](_0x4285e7['name']);return _0x3c7618?_0x23ee41['remove'](new E(_0x4285e7['name'],_0x3c7618)):_0x23ee41;}});return new te(_0x3cc5a7,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x4555a6,_0x8f5dfa,_0x54679e){this['children_']=_0x4555a6,this['priorityNode_']=_0x8f5dfa,this['indexMap_']=_0x54679e,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x1a799f){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x1a799f,this['indexMap_']);}['getImmediateChild'](_0x295436){if(_0x295436==='.priority')return this['getPriority']();{const _0x581b23=this['children_']['get'](_0x295436);return _0x581b23===null?It:_0x581b23;}}['getChild'](_0x1dfa92){const _0x2fc6ac=y(_0x1dfa92);return _0x2fc6ac===null?this:this['getImmediateChild'](_0x2fc6ac)['getChild'](S(_0x1dfa92));}['hasChild'](_0x256ca9){return this['children_']['get'](_0x256ca9)!==null;}['updateImmediateChild'](_0x2957c9,_0x13dc5b){if(f(_0x13dc5b,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x2957c9==='.priority')return this['updatePriority'](_0x13dc5b);{const _0x219647=new E(_0x2957c9,_0x13dc5b);let _0x4786d1,_0x211467;_0x13dc5b['isEmpty']()?(_0x4786d1=this['children_']['remove'](_0x2957c9),_0x211467=this['indexMap_']['removeFromIndexes'](_0x219647,this['children_'])):(_0x4786d1=this['children_']['insert'](_0x2957c9,_0x13dc5b),_0x211467=this['indexMap_']['addToIndexes'](_0x219647,this['children_']));const _0x2ab20f=_0x4786d1['isEmpty']()?It:this['priorityNode_'];return new g(_0x4786d1,_0x2ab20f,_0x211467);}}['updateChild'](_0x185e55,_0x2af879){const _0x1c6e32=y(_0x185e55);if(_0x1c6e32===null)return _0x2af879;{f(y(_0x185e55)!=='.priority'||Ce(_0x185e55)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x487dc8=this['getImmediateChild'](_0x1c6e32)['updateChild'](S(_0x185e55),_0x2af879);return this['updateImmediateChild'](_0x1c6e32,_0x487dc8);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x12c854){if(this['isEmpty']())return null;const _0x1be997={};let _0xc76d22=0x0,_0x595fb2=0x0,_0x103018=!0x0;if(this['forEachChild'](R,(_0x1fbf68,_0x2326b8)=>{_0x1be997[_0x1fbf68]=_0x2326b8['val'](_0x12c854),_0xc76d22++,_0x103018&&g['INTEGER_REGEXP_']['test'](_0x1fbf68)?_0x595fb2=Math['max'](_0x595fb2,Number(_0x1fbf68)):_0x103018=!0x1;}),!_0x12c854&&_0x103018&&_0x595fb2<0x2*_0xc76d22){const _0x4c753b=[];for(const _0x5a57a8 in _0x1be997)_0x4c753b[_0x5a57a8]=_0x1be997[_0x5a57a8];return _0x4c753b;}else return _0x12c854&&!this['getPriority']()['isEmpty']()&&(_0x1be997['.priority']=this['getPriority']()['val']()),_0x1be997;}['hash'](){if(this['lazyHash_']===null){let _0x4039b1='';this['getPriority']()['isEmpty']()||(_0x4039b1+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0xbb5cd4,_0x3c1cae)=>{const _0x358afc=_0x3c1cae['hash']();_0x358afc!==''&&(_0x4039b1+=':'+_0xbb5cd4+':'+_0x358afc);}),this['lazyHash_']=_0x4039b1===''?'':ro(_0x4039b1);}return this['lazyHash_'];}['getPredecessorChildName'](_0x4fb516,_0x2cf637,_0x537833){const _0x22f05f=this['resolveIndex_'](_0x537833);if(_0x22f05f){const _0x345fe0=_0x22f05f['getPredecessorKey'](new E(_0x4fb516,_0x2cf637));return _0x345fe0?_0x345fe0['name']:null;}else return this['children_']['getPredecessorKey'](_0x4fb516);}['getFirstChildName'](_0x1d6787){const _0x42bebe=this['resolveIndex_'](_0x1d6787);if(_0x42bebe){const _0x2f4cdc=_0x42bebe['minKey']();return _0x2f4cdc&&_0x2f4cdc['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0xa66728){const _0x3332d7=this['getFirstChildName'](_0xa66728);return _0x3332d7?new E(_0x3332d7,this['children_']['get'](_0x3332d7)):null;}['getLastChildName'](_0x10ea80){const _0x505068=this['resolveIndex_'](_0x10ea80);if(_0x505068){const _0x150a8d=_0x505068['maxKey']();return _0x150a8d&&_0x150a8d['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x9cbc28){const _0x2884a0=this['getLastChildName'](_0x9cbc28);return _0x2884a0?new E(_0x2884a0,this['children_']['get'](_0x2884a0)):null;}['forEachChild'](_0x5550df,_0x573abc){const _0x5d0e16=this['resolveIndex_'](_0x5550df);return _0x5d0e16?_0x5d0e16['inorderTraversal'](_0x5c1149=>_0x573abc(_0x5c1149['name'],_0x5c1149['node'])):this['children_']['inorderTraversal'](_0x573abc);}['getIterator'](_0x4f1b67){return this['getIteratorFrom'](_0x4f1b67['minPost'](),_0x4f1b67);}['getIteratorFrom'](_0x45122e,_0x6eaf00){const _0x5444b0=this['resolveIndex_'](_0x6eaf00);if(_0x5444b0)return _0x5444b0['getIteratorFrom'](_0x45122e,_0x7d75c4=>_0x7d75c4);{const _0x2345a7=this['children_']['getIteratorFrom'](_0x45122e['name'],E['Wrap']);let _0x598df3=_0x2345a7['peek']();for(;_0x598df3!=null&&_0x6eaf00['compare'](_0x598df3,_0x45122e)<0x0;)_0x2345a7['getNext'](),_0x598df3=_0x2345a7['peek']();return _0x2345a7;}}['getReverseIterator'](_0x442ecf){return this['getReverseIteratorFrom'](_0x442ecf['maxPost'](),_0x442ecf);}['getReverseIteratorFrom'](_0x1160ae,_0x4d6472){const _0x929fa8=this['resolveIndex_'](_0x4d6472);if(_0x929fa8)return _0x929fa8['getReverseIteratorFrom'](_0x1160ae,_0x47f94c=>_0x47f94c);{const _0x256e76=this['children_']['getReverseIteratorFrom'](_0x1160ae['name'],E['Wrap']);let _0x49987e=_0x256e76['peek']();for(;_0x49987e!=null&&_0x4d6472['compare'](_0x49987e,_0x1160ae)>0x0;)_0x256e76['getNext'](),_0x49987e=_0x256e76['peek']();return _0x256e76;}}['compareTo'](_0x417e91){return this['isEmpty']()?_0x417e91['isEmpty']()?0x0:-0x1:_0x417e91['isLeafNode']()||_0x417e91['isEmpty']()?0x1:_0x417e91===Kt?-0x1:0x0;}['withIndex'](_0x1f092d){if(_0x1f092d===ve||this['indexMap_']['hasIndex'](_0x1f092d))return this;{const _0x1fe35c=this['indexMap_']['addIndex'](_0x1f092d,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x1fe35c);}}['isIndexed'](_0x26041d){return _0x26041d===ve||this['indexMap_']['hasIndex'](_0x26041d);}['equals'](_0x4457d0){if(_0x4457d0===this)return!0x0;if(_0x4457d0['isLeafNode']())return!0x1;{const _0x49fe2c=_0x4457d0;if(this['getPriority']()['equals'](_0x49fe2c['getPriority']())){if(this['children_']['count']()===_0x49fe2c['children_']['count']()){const _0x2c45c=this['getIterator'](R),_0x5876f1=_0x49fe2c['getIterator'](R);let _0x5d6e88=_0x2c45c['getNext'](),_0xeebe7a=_0x5876f1['getNext']();for(;_0x5d6e88&&_0xeebe7a;){if(_0x5d6e88['name']!==_0xeebe7a['name']||!_0x5d6e88['node']['equals'](_0xeebe7a['node']))return!0x1;_0x5d6e88=_0x2c45c['getNext'](),_0xeebe7a=_0x5876f1['getNext']();}return _0x5d6e88===null&&_0xeebe7a===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x3e943f){return _0x3e943f===ve?null:this['indexMap_']['get'](_0x3e943f['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x44b9ed){return _0x44b9ed===this?0x0:0x1;}['equals'](_0x54795e){return _0x54795e===this;}['getPriority'](){return this;}['getImmediateChild'](_0x2994a6){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x3df638,_0x23587b=null){if(_0x3df638===null)return g['EMPTY_NODE'];if(typeof _0x3df638=='object'&&'.priority'in _0x3df638&&(_0x23587b=_0x3df638['.priority']),f(_0x23587b===null||typeof _0x23587b=='string'||typeof _0x23587b=='number'||typeof _0x23587b=='object'&&'.sv'in _0x23587b,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x23587b),typeof _0x3df638=='object'&&'.value'in _0x3df638&&_0x3df638['.value']!==null&&(_0x3df638=_0x3df638['.value']),typeof _0x3df638!='object'||'.sv'in _0x3df638){const _0x3e0751=_0x3df638;return new D(_0x3e0751,A(_0x23587b));}if(!(_0x3df638 instanceof Array)&&Gh){const _0x54bf4c=[];let _0x3627dc=!0x1;if(x(_0x3df638,(_0x32d4fa,_0x30bf76)=>{if(_0x32d4fa['substring'](0x0,0x1)!=='.'){const _0x2ad60c=A(_0x30bf76);_0x2ad60c['isEmpty']()||(_0x3627dc=_0x3627dc||!_0x2ad60c['getPriority']()['isEmpty'](),_0x54bf4c['push'](new E(_0x32d4fa,_0x2ad60c)));}}),_0x54bf4c['length']===0x0)return g['EMPTY_NODE'];const _0x4441c8=yn(_0x54bf4c,xh,_0xca59bd=>_0xca59bd['name'],Qi);if(_0x3627dc){const _0x58bc7a=yn(_0x54bf4c,R['getCompare']());return new g(_0x4441c8,A(_0x23587b),new te({'.priority':_0x58bc7a},{'.priority':R}));}else return new g(_0x4441c8,A(_0x23587b),te['Default']);}else{let _0x3730d1=g['EMPTY_NODE'];return x(_0x3df638,(_0x38e585,_0x2378c8)=>{if(Q(_0x3df638,_0x38e585)&&_0x38e585['substring'](0x0,0x1)!=='.'){const _0x335981=A(_0x2378c8);(_0x335981['isLeafNode']()||!_0x335981['isEmpty']())&&(_0x3730d1=_0x3730d1['updateImmediateChild'](_0x38e585,_0x335981));}}),_0x3730d1['updatePriority'](A(_0x23587b));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x4300ae){super(),this['indexPath_']=_0x4300ae,f(!v(_0x4300ae)&&y(_0x4300ae)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x363156){return _0x363156['getChild'](this['indexPath_']);}['isDefinedOn'](_0xdccf5a){return!_0xdccf5a['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x424df2,_0x477d2d){const _0x5d5c0f=this['extractChild'](_0x424df2['node']),_0x589480=this['extractChild'](_0x477d2d['node']),_0x465fc8=_0x5d5c0f['compareTo'](_0x589480);return _0x465fc8===0x0?qe(_0x424df2['name'],_0x477d2d['name']):_0x465fc8;}['makePost'](_0x336d2f,_0xc334b7){const _0x4ae8a4=A(_0x336d2f),_0x1c055c=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x4ae8a4);return new E(_0xc334b7,_0x1c055c);}['maxPost'](){const _0x4240d8=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x4240d8);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x22c097,_0x83c4e1){const _0x4ca757=_0x22c097['node']['compareTo'](_0x83c4e1['node']);return _0x4ca757===0x0?qe(_0x22c097['name'],_0x83c4e1['name']):_0x4ca757;}['isDefinedOn'](_0x5cc915){return!0x0;}['indexedValueChanged'](_0x5574e2,_0x1994d9){return!_0x5574e2['equals'](_0x1994d9);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x2c1e41,_0x5647bf){const _0x55601f=A(_0x2c1e41);return new E(_0x5647bf,_0x55601f);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x426c52){return{'type':'value','snapshotNode':_0x426c52};}function rt(_0x4c686f,_0x1ec234){return{'type':'child_added','snapshotNode':_0x1ec234,'childName':_0x4c686f};}function Lt(_0x4e90c4,_0xe211cd){return{'type':'child_removed','snapshotNode':_0xe211cd,'childName':_0x4e90c4};}function xt(_0x53eba6,_0x4b7860,_0x599d2d){return{'type':'child_changed','snapshotNode':_0x4b7860,'childName':_0x53eba6,'oldSnap':_0x599d2d};}function zh(_0x1903a4,_0x317057){return{'type':'child_moved','snapshotNode':_0x317057,'childName':_0x1903a4};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x10c3e7){this['index_']=_0x10c3e7;}['updateChild'](_0x3e91ff,_0x71b3eb,_0x41f37e,_0x51813b,_0x2ad669,_0x249860){f(_0x3e91ff['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x328cb8=_0x3e91ff['getImmediateChild'](_0x71b3eb);return _0x328cb8['getChild'](_0x51813b)['equals'](_0x41f37e['getChild'](_0x51813b))&&_0x328cb8['isEmpty']()===_0x41f37e['isEmpty']()||(_0x249860!=null&&(_0x41f37e['isEmpty']()?_0x3e91ff['hasChild'](_0x71b3eb)?_0x249860['trackChildChange'](Lt(_0x71b3eb,_0x328cb8)):f(_0x3e91ff['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x328cb8['isEmpty']()?_0x249860['trackChildChange'](rt(_0x71b3eb,_0x41f37e)):_0x249860['trackChildChange'](xt(_0x71b3eb,_0x41f37e,_0x328cb8))),_0x3e91ff['isLeafNode']()&&_0x41f37e['isEmpty']())?_0x3e91ff:_0x3e91ff['updateImmediateChild'](_0x71b3eb,_0x41f37e)['withIndex'](this['index_']);}['updateFullNode'](_0x25cff2,_0x927e65,_0x4dfb9f){return _0x4dfb9f!=null&&(_0x25cff2['isLeafNode']()||_0x25cff2['forEachChild'](R,(_0x467730,_0x1a9e06)=>{_0x927e65['hasChild'](_0x467730)||_0x4dfb9f['trackChildChange'](Lt(_0x467730,_0x1a9e06));}),_0x927e65['isLeafNode']()||_0x927e65['forEachChild'](R,(_0x2ae83c,_0x437562)=>{if(_0x25cff2['hasChild'](_0x2ae83c)){const _0x5319e7=_0x25cff2['getImmediateChild'](_0x2ae83c);_0x5319e7['equals'](_0x437562)||_0x4dfb9f['trackChildChange'](xt(_0x2ae83c,_0x437562,_0x5319e7));}else _0x4dfb9f['trackChildChange'](rt(_0x2ae83c,_0x437562));})),_0x927e65['withIndex'](this['index_']);}['updatePriority'](_0x56e02e,_0x16af5c){return _0x56e02e['isEmpty']()?g['EMPTY_NODE']:_0x56e02e['updatePriority'](_0x16af5c);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x51888f){this['indexedFilter_']=new Xi(_0x51888f['getIndex']()),this['index_']=_0x51888f['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x51888f),this['endPost_']=Ft['getEndPost_'](_0x51888f),this['startIsInclusive_']=!_0x51888f['startAfterSet_'],this['endIsInclusive_']=!_0x51888f['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x1514ee){const _0x49c47f=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x1514ee)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x1514ee)<0x0,_0x4fab41=this['endIsInclusive_']?this['index_']['compare'](_0x1514ee,this['getEndPost']())<=0x0:this['index_']['compare'](_0x1514ee,this['getEndPost']())<0x0;return _0x49c47f&&_0x4fab41;}['updateChild'](_0x13bc6b,_0x5afe1f,_0x4b7551,_0x4d0bc8,_0x105e78,_0x4f130){return this['matches'](new E(_0x5afe1f,_0x4b7551))||(_0x4b7551=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x13bc6b,_0x5afe1f,_0x4b7551,_0x4d0bc8,_0x105e78,_0x4f130);}['updateFullNode'](_0x2cbd98,_0x4b4703,_0x164fef){_0x4b4703['isLeafNode']()&&(_0x4b4703=g['EMPTY_NODE']);let _0x3cd013=_0x4b4703['withIndex'](this['index_']);_0x3cd013=_0x3cd013['updatePriority'](g['EMPTY_NODE']);const _0x3e42ca=this;return _0x4b4703['forEachChild'](R,(_0x3ed4ed,_0x4abee1)=>{_0x3e42ca['matches'](new E(_0x3ed4ed,_0x4abee1))||(_0x3cd013=_0x3cd013['updateImmediateChild'](_0x3ed4ed,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x2cbd98,_0x3cd013,_0x164fef);}['updatePriority'](_0x249fc6,_0x5dbaac){return _0x249fc6;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x493917){if(_0x493917['hasStart']()){const _0x401d30=_0x493917['getIndexStartName']();return _0x493917['getIndex']()['makePost'](_0x493917['getIndexStartValue'](),_0x401d30);}else return _0x493917['getIndex']()['minPost']();}static['getEndPost_'](_0xcb4269){if(_0xcb4269['hasEnd']()){const _0x45aa32=_0xcb4269['getIndexEndName']();return _0xcb4269['getIndex']()['makePost'](_0xcb4269['getIndexEndValue'](),_0x45aa32);}else return _0xcb4269['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x2254a3){this['withinDirectionalStart']=_0x2e1be4=>this['reverse_']?this['withinEndPost'](_0x2e1be4):this['withinStartPost'](_0x2e1be4),this['withinDirectionalEnd']=_0x1746a0=>this['reverse_']?this['withinStartPost'](_0x1746a0):this['withinEndPost'](_0x1746a0),this['withinStartPost']=_0x2718f8=>{const _0x3cbc8c=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x2718f8);return this['startIsInclusive_']?_0x3cbc8c<=0x0:_0x3cbc8c<0x0;},this['withinEndPost']=_0x355503=>{const _0x5794df=this['index_']['compare'](_0x355503,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x5794df<=0x0:_0x5794df<0x0;},this['rangedFilter_']=new Ft(_0x2254a3),this['index_']=_0x2254a3['getIndex'](),this['limit_']=_0x2254a3['getLimit'](),this['reverse_']=!_0x2254a3['isViewFromLeft'](),this['startIsInclusive_']=!_0x2254a3['startAfterSet_'],this['endIsInclusive_']=!_0x2254a3['endBeforeSet_'];}['updateChild'](_0x5e6772,_0x50ee73,_0x93ff2e,_0x473afb,_0x1edaac,_0x3d9ad7){return this['rangedFilter_']['matches'](new E(_0x50ee73,_0x93ff2e))||(_0x93ff2e=g['EMPTY_NODE']),_0x5e6772['getImmediateChild'](_0x50ee73)['equals'](_0x93ff2e)?_0x5e6772:_0x5e6772['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x5e6772,_0x50ee73,_0x93ff2e,_0x473afb,_0x1edaac,_0x3d9ad7):this['fullLimitUpdateChild_'](_0x5e6772,_0x50ee73,_0x93ff2e,_0x1edaac,_0x3d9ad7);}['updateFullNode'](_0x6295a4,_0x561b5b,_0x3b89df){let _0xfbde12;if(_0x561b5b['isLeafNode']()||_0x561b5b['isEmpty']())_0xfbde12=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x561b5b['numChildren']()&&_0x561b5b['isIndexed'](this['index_'])){_0xfbde12=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x5f64f4;this['reverse_']?_0x5f64f4=_0x561b5b['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x5f64f4=_0x561b5b['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x4a2c42=0x0;for(;_0x5f64f4['hasNext']()&&_0x4a2c42<this['limit_'];){const _0x38e3d8=_0x5f64f4['getNext']();if(this['withinDirectionalStart'](_0x38e3d8)){if(this['withinDirectionalEnd'](_0x38e3d8))_0xfbde12=_0xfbde12['updateImmediateChild'](_0x38e3d8['name'],_0x38e3d8['node']),_0x4a2c42++;else break;}else continue;}}else{_0xfbde12=_0x561b5b['withIndex'](this['index_']),_0xfbde12=_0xfbde12['updatePriority'](g['EMPTY_NODE']);let _0x47546e;this['reverse_']?_0x47546e=_0xfbde12['getReverseIterator'](this['index_']):_0x47546e=_0xfbde12['getIterator'](this['index_']);let _0x17989a=0x0;for(;_0x47546e['hasNext']();){const _0x2b9dbd=_0x47546e['getNext']();_0x17989a<this['limit_']&&this['withinDirectionalStart'](_0x2b9dbd)&&this['withinDirectionalEnd'](_0x2b9dbd)?_0x17989a++:_0xfbde12=_0xfbde12['updateImmediateChild'](_0x2b9dbd['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x6295a4,_0xfbde12,_0x3b89df);}['updatePriority'](_0x3b15c3,_0x2c116c){return _0x3b15c3;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x2a75a0,_0x4611b9,_0x5f20fd,_0x1e8108,_0x4ba109){let _0x1a1304;if(this['reverse_']){const _0x253adb=this['index_']['getCompare']();_0x1a1304=(_0x1f7e69,_0x2e65e5)=>_0x253adb(_0x2e65e5,_0x1f7e69);}else _0x1a1304=this['index_']['getCompare']();const _0x1f145a=_0x2a75a0;f(_0x1f145a['numChildren']()===this['limit_'],'');const _0x1b413a=new E(_0x4611b9,_0x5f20fd),_0xca0f09=this['reverse_']?_0x1f145a['getFirstChild'](this['index_']):_0x1f145a['getLastChild'](this['index_']),_0x358079=this['rangedFilter_']['matches'](_0x1b413a);if(_0x1f145a['hasChild'](_0x4611b9)){const _0x278c46=_0x1f145a['getImmediateChild'](_0x4611b9);let _0xd21ce8=_0x1e8108['getChildAfterChild'](this['index_'],_0xca0f09,this['reverse_']);for(;_0xd21ce8!=null&&(_0xd21ce8['name']===_0x4611b9||_0x1f145a['hasChild'](_0xd21ce8['name']));)_0xd21ce8=_0x1e8108['getChildAfterChild'](this['index_'],_0xd21ce8,this['reverse_']);const _0x18c509=_0xd21ce8==null?0x1:_0x1a1304(_0xd21ce8,_0x1b413a);if(_0x358079&&!_0x5f20fd['isEmpty']()&&_0x18c509>=0x0)return _0x4ba109!=null&&_0x4ba109['trackChildChange'](xt(_0x4611b9,_0x5f20fd,_0x278c46)),_0x1f145a['updateImmediateChild'](_0x4611b9,_0x5f20fd);{_0x4ba109!=null&&_0x4ba109['trackChildChange'](Lt(_0x4611b9,_0x278c46));const _0x17edc5=_0x1f145a['updateImmediateChild'](_0x4611b9,g['EMPTY_NODE']);return _0xd21ce8!=null&&this['rangedFilter_']['matches'](_0xd21ce8)?(_0x4ba109!=null&&_0x4ba109['trackChildChange'](rt(_0xd21ce8['name'],_0xd21ce8['node'])),_0x17edc5['updateImmediateChild'](_0xd21ce8['name'],_0xd21ce8['node'])):_0x17edc5;}}else return _0x5f20fd['isEmpty']()?_0x2a75a0:_0x358079&&_0x1a1304(_0xca0f09,_0x1b413a)>=0x0?(_0x4ba109!=null&&(_0x4ba109['trackChildChange'](Lt(_0xca0f09['name'],_0xca0f09['node'])),_0x4ba109['trackChildChange'](rt(_0x4611b9,_0x5f20fd))),_0x1f145a['updateImmediateChild'](_0x4611b9,_0x5f20fd)['updateImmediateChild'](_0xca0f09['name'],g['EMPTY_NODE'])):_0x2a75a0;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x160d71=new Zi();return _0x160d71['limitSet_']=this['limitSet_'],_0x160d71['limit_']=this['limit_'],_0x160d71['startSet_']=this['startSet_'],_0x160d71['startAfterSet_']=this['startAfterSet_'],_0x160d71['indexStartValue_']=this['indexStartValue_'],_0x160d71['startNameSet_']=this['startNameSet_'],_0x160d71['indexStartName_']=this['indexStartName_'],_0x160d71['endSet_']=this['endSet_'],_0x160d71['endBeforeSet_']=this['endBeforeSet_'],_0x160d71['indexEndValue_']=this['indexEndValue_'],_0x160d71['endNameSet_']=this['endNameSet_'],_0x160d71['indexEndName_']=this['indexEndName_'],_0x160d71['index_']=this['index_'],_0x160d71['viewFrom_']=this['viewFrom_'],_0x160d71;}}function Kh(_0x1c3176){return _0x1c3176['loadsAllData']()?new Xi(_0x1c3176['getIndex']()):_0x1c3176['hasLimit']()?new jh(_0x1c3176):new Ft(_0x1c3176);}function Yh(_0x3480d9,_0x48f7bd){const _0x3daf2d=_0x3480d9['copy']();return _0x3daf2d['limitSet_']=!0x0,_0x3daf2d['limit_']=_0x48f7bd,_0x3daf2d['viewFrom_']='l',_0x3daf2d;}function Qh(_0x220748,_0x102503,_0x5a623b){const _0x3924cc=_0x220748['copy']();return _0x3924cc['startSet_']=!0x0,_0x102503===void 0x0&&(_0x102503=null),_0x3924cc['indexStartValue_']=_0x102503,_0x5a623b!=null?(_0x3924cc['startNameSet_']=!0x0,_0x3924cc['indexStartName_']=_0x5a623b):(_0x3924cc['startNameSet_']=!0x1,_0x3924cc['indexStartName_']=''),_0x3924cc;}function Jh(_0x2af640,_0x10fc0b,_0x1eefa5){const _0x5e453d=_0x2af640['copy']();return _0x5e453d['endSet_']=!0x0,_0x10fc0b===void 0x0&&(_0x10fc0b=null),_0x5e453d['indexEndValue_']=_0x10fc0b,_0x1eefa5!==void 0x0?(_0x5e453d['endNameSet_']=!0x0,_0x5e453d['indexEndName_']=_0x1eefa5):(_0x5e453d['endNameSet_']=!0x1,_0x5e453d['indexEndName_']=''),_0x5e453d;}function xo(_0x47ade5,_0x54ead1){const _0x30eccb=_0x47ade5['copy']();return _0x30eccb['index_']=_0x54ead1,_0x30eccb;}function ir(_0x4e7382){const _0x5bffba={};if(_0x4e7382['isDefault']())return _0x5bffba;let _0x1331eb;if(_0x4e7382['index_']===R?_0x1331eb='$priority':_0x4e7382['index_']===Mo?_0x1331eb='$value':_0x4e7382['index_']===ve?_0x1331eb='$key':(f(_0x4e7382['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x1331eb=_0x4e7382['index_']['toString']()),_0x5bffba['orderBy']=O(_0x1331eb),_0x4e7382['startSet_']){const _0x21de4f=_0x4e7382['startAfterSet_']?'startAfter':'startAt';_0x5bffba[_0x21de4f]=O(_0x4e7382['indexStartValue_']),_0x4e7382['startNameSet_']&&(_0x5bffba[_0x21de4f]+=','+O(_0x4e7382['indexStartName_']));}if(_0x4e7382['endSet_']){const _0x1edef4=_0x4e7382['endBeforeSet_']?'endBefore':'endAt';_0x5bffba[_0x1edef4]=O(_0x4e7382['indexEndValue_']),_0x4e7382['endNameSet_']&&(_0x5bffba[_0x1edef4]+=','+O(_0x4e7382['indexEndName_']));}return _0x4e7382['limitSet_']&&(_0x4e7382['isViewFromLeft']()?_0x5bffba['limitToFirst']=_0x4e7382['limit_']:_0x5bffba['limitToLast']=_0x4e7382['limit_']),_0x5bffba;}function sr(_0xc979ce){const _0x51b4fa={};if(_0xc979ce['startSet_']&&(_0x51b4fa['sp']=_0xc979ce['indexStartValue_'],_0xc979ce['startNameSet_']&&(_0x51b4fa['sn']=_0xc979ce['indexStartName_']),_0x51b4fa['sin']=!_0xc979ce['startAfterSet_']),_0xc979ce['endSet_']&&(_0x51b4fa['ep']=_0xc979ce['indexEndValue_'],_0xc979ce['endNameSet_']&&(_0x51b4fa['en']=_0xc979ce['indexEndName_']),_0x51b4fa['ein']=!_0xc979ce['endBeforeSet_']),_0xc979ce['limitSet_']){_0x51b4fa['l']=_0xc979ce['limit_'];let _0x33ed03=_0xc979ce['viewFrom_'];_0x33ed03===''&&(_0xc979ce['isViewFromLeft']()?_0x33ed03='l':_0x33ed03='r'),_0x51b4fa['vf']=_0x33ed03;}return _0xc979ce['index_']!==R&&(_0x51b4fa['i']=_0xc979ce['index_']['toString']()),_0x51b4fa;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x27b9d1){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x3303d9,_0x423ff6){return _0x423ff6!==void 0x0?'tag$'+_0x423ff6:(f(_0x3303d9['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x3303d9['_path']['toString']());}constructor(_0x3b802,_0x52b856,_0x22d24c,_0x1c53fb){super(),this['repoInfo_']=_0x3b802,this['onDataUpdate_']=_0x52b856,this['authTokenProvider_']=_0x22d24c,this['appCheckTokenProvider_']=_0x1c53fb,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x1a451a,_0x3167fb,_0x585949,_0x491c58){const _0x1f3d9b=_0x1a451a['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x1f3d9b+'\x20'+_0x1a451a['_queryIdentifier']);const _0x19e28c=vn['getListenId_'](_0x1a451a,_0x585949),_0x2869bc={};this['listens_'][_0x19e28c]=_0x2869bc;const _0x2f44ff=ir(_0x1a451a['_queryParams']);this['restRequest_'](_0x1f3d9b+'.json',_0x2f44ff,(_0x25df5c,_0x34d0b5)=>{let _0x34fdd8=_0x34d0b5;if(_0x25df5c===0x194&&(_0x34fdd8=null,_0x25df5c=null),_0x25df5c===null&&this['onDataUpdate_'](_0x1f3d9b,_0x34fdd8,!0x1,_0x585949),Le(this['listens_'],_0x19e28c)===_0x2869bc){let _0x18b67d;_0x25df5c?_0x25df5c===0x191?_0x18b67d='permission_denied':_0x18b67d='rest_error:'+_0x25df5c:_0x18b67d='ok',_0x491c58(_0x18b67d,null);}});}['unlisten'](_0x3882a6,_0xd4ea47){const _0x33cba8=vn['getListenId_'](_0x3882a6,_0xd4ea47);delete this['listens_'][_0x33cba8];}['get'](_0x7b7f38){const _0x351b08=ir(_0x7b7f38['_queryParams']),_0x19fa34=_0x7b7f38['_path']['toString'](),_0x4d2202=new H();return this['restRequest_'](_0x19fa34+'.json',_0x351b08,(_0x1f6d7f,_0x1419e0)=>{let _0x40a62c=_0x1419e0;_0x1f6d7f===0x194&&(_0x40a62c=null,_0x1f6d7f=null),_0x1f6d7f===null?(this['onDataUpdate_'](_0x19fa34,_0x40a62c,!0x1,null),_0x4d2202['resolve'](_0x40a62c)):_0x4d2202['reject'](new Error(_0x40a62c));}),_0x4d2202['promise'];}['refreshAuthToken'](_0x15b99f){}['restRequest_'](_0xf4fd0f,_0x335815={},_0x639aff){return _0x335815['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x35f187,_0x378599])=>{_0x35f187&&_0x35f187['accessToken']&&(_0x335815['auth']=_0x35f187['accessToken']),_0x378599&&_0x378599['token']&&(_0x335815['ac']=_0x378599['token']);const _0x2ac5ef=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0xf4fd0f+'?ns='+this['repoInfo_']['namespace']+ut(_0x335815);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x2ac5ef);const _0x57302d=new XMLHttpRequest();_0x57302d['onreadystatechange']=()=>{if(_0x639aff&&_0x57302d['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x2ac5ef+'\x20received.\x20status:',_0x57302d['status'],'response:',_0x57302d['responseText']);let _0x5bf55d=null;if(_0x57302d['status']>=0xc8&&_0x57302d['status']<0x12c){try{_0x5bf55d=Nt(_0x57302d['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x2ac5ef+':\x20'+_0x57302d['responseText']);}_0x639aff(null,_0x5bf55d);}else _0x57302d['status']!==0x191&&_0x57302d['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x2ac5ef+'\x20Status:\x20'+_0x57302d['status']),_0x639aff(_0x57302d['status']);_0x639aff=null;}},_0x57302d['open']('GET',_0x2ac5ef,!0x0),_0x57302d['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x540782){return this['rootNode_']['getChild'](_0x540782);}['updateSnapshot'](_0x5d4c93,_0x1d1f73){this['rootNode_']=this['rootNode_']['updateChild'](_0x5d4c93,_0x1d1f73);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x858a54,_0x495023,_0x5b1ec1){if(v(_0x495023))_0x858a54['value']=_0x5b1ec1,_0x858a54['children']['clear']();else{if(_0x858a54['value']!==null)_0x858a54['value']=_0x858a54['value']['updateChild'](_0x495023,_0x5b1ec1);else{const _0x15094c=y(_0x495023);_0x858a54['children']['has'](_0x15094c)||_0x858a54['children']['set'](_0x15094c,En());const _0x2b18c0=_0x858a54['children']['get'](_0x15094c);_0x495023=S(_0x495023),pt(_0x2b18c0,_0x495023,_0x5b1ec1);}}}function Ti(_0x45d302,_0x46c44a){if(v(_0x46c44a))return _0x45d302['value']=null,_0x45d302['children']['clear'](),!0x0;if(_0x45d302['value']!==null){if(_0x45d302['value']['isLeafNode']())return!0x1;{const _0x3bd741=_0x45d302['value'];return _0x45d302['value']=null,_0x3bd741['forEachChild'](R,(_0x381050,_0x3c0918)=>{pt(_0x45d302,new C(_0x381050),_0x3c0918);}),Ti(_0x45d302,_0x46c44a);}}else{if(_0x45d302['children']['size']>0x0){const _0x6825a8=y(_0x46c44a);return _0x46c44a=S(_0x46c44a),_0x45d302['children']['has'](_0x6825a8)&&Ti(_0x45d302['children']['get'](_0x6825a8),_0x46c44a)&&_0x45d302['children']['delete'](_0x6825a8),_0x45d302['children']['size']===0x0;}else return!0x0;}}function Si(_0x54493e,_0x470e92,_0x476966){_0x54493e['value']!==null?_0x476966(_0x470e92,_0x54493e['value']):Zh(_0x54493e,(_0x496997,_0x385580)=>{const _0x4e7dbf=new C(_0x470e92['toString']()+'/'+_0x496997);Si(_0x385580,_0x4e7dbf,_0x476966);});}function Zh(_0x117410,_0x136cad){_0x117410['children']['forEach']((_0x5efe0c,_0xe5be29)=>{_0x136cad(_0xe5be29,_0x5efe0c);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x3ed460){this['collection_']=_0x3ed460,this['last_']=null;}['get'](){const _0x593dc2=this['collection_']['get'](),_0x40de5d={..._0x593dc2};return this['last_']&&x(this['last_'],(_0x1490bb,_0x21b908)=>{_0x40de5d[_0x1490bb]=_0x40de5d[_0x1490bb]-_0x21b908;}),this['last_']=_0x593dc2,_0x40de5d;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x8ca272,_0x3f10b0){this['server_']=_0x3f10b0,this['statsToReport_']={},this['statsListener_']=new eu(_0x8ca272);const _0x3748fc=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x3748fc));}['reportStats_'](){const _0x27c43a=this['statsListener_']['get'](),_0x524b14={};let _0x18069d=!0x1;x(_0x27c43a,(_0x21f477,_0x10b7c5)=>{_0x10b7c5>0x0&&Q(this['statsToReport_'],_0x21f477)&&(_0x524b14[_0x21f477]=_0x10b7c5,_0x18069d=!0x0);}),_0x18069d&&this['server_']['reportStats'](_0x524b14),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0xd80338){_0xd80338[_0xd80338['OVERWRITE']=0x0]='OVERWRITE',_0xd80338[_0xd80338['MERGE']=0x1]='MERGE',_0xd80338[_0xd80338['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0xd80338[_0xd80338['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x1e101a){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x1e101a,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x4f8980,_0x510a20,_0x367de9){this['path']=_0x4f8980,this['affectedTree']=_0x510a20,this['revert']=_0x367de9,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x388461){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x2d8446=this['affectedTree']['subtree'](new C(_0x388461));return new In(w(),_0x2d8446,this['revert']);}}else return f(y(this['path'])===_0x388461,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x16750b,_0x5395d6){this['source']=_0x16750b,this['path']=_0x5395d6,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x43812c){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x2433e2,_0x192537,_0x5f38ee){this['source']=_0x2433e2,this['path']=_0x192537,this['snap']=_0x5f38ee,this['type']=z['OVERWRITE'];}['operationForChild'](_0xa80a9e){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0xa80a9e)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x323f0a,_0x2fc173,_0x580db7){this['source']=_0x323f0a,this['path']=_0x2fc173,this['children']=_0x580db7,this['type']=z['MERGE'];}['operationForChild'](_0x248240){if(v(this['path'])){const _0x24e8c0=this['children']['subtree'](new C(_0x248240));return _0x24e8c0['isEmpty']()?null:_0x24e8c0['value']?new Be(this['source'],w(),_0x24e8c0['value']):new ot(this['source'],w(),_0x24e8c0);}else return f(y(this['path'])===_0x248240,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x145184,_0x5651b3,_0x580f8d){this['node_']=_0x145184,this['fullyInitialized_']=_0x5651b3,this['filtered_']=_0x580f8d;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x627fec){if(v(_0x627fec))return this['isFullyInitialized']()&&!this['filtered_'];const _0x4a9d8b=y(_0x627fec);return this['isCompleteForChild'](_0x4a9d8b);}['isCompleteForChild'](_0x1ffda7){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x1ffda7);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x3ebacb){this['query_']=_0x3ebacb,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x5cae80,_0x12601d,_0x33189d,_0x242ff6){const _0x51075a=[],_0x5ec0d5=[];return _0x12601d['forEach'](_0x4b6b78=>{_0x4b6b78['type']==='child_changed'&&_0x5cae80['index_']['indexedValueChanged'](_0x4b6b78['oldSnap'],_0x4b6b78['snapshotNode'])&&_0x5ec0d5['push'](zh(_0x4b6b78['childName'],_0x4b6b78['snapshotNode']));}),wt(_0x5cae80,_0x51075a,'child_removed',_0x12601d,_0x242ff6,_0x33189d),wt(_0x5cae80,_0x51075a,'child_added',_0x12601d,_0x242ff6,_0x33189d),wt(_0x5cae80,_0x51075a,'child_moved',_0x5ec0d5,_0x242ff6,_0x33189d),wt(_0x5cae80,_0x51075a,'child_changed',_0x12601d,_0x242ff6,_0x33189d),wt(_0x5cae80,_0x51075a,'value',_0x12601d,_0x242ff6,_0x33189d),_0x51075a;}function wt(_0x53e4a8,_0x1ad5fb,_0x202d29,_0x35b3f8,_0x2b94a1,_0x5c2c2e){const _0x2b1fd0=_0x35b3f8['filter'](_0xc058dd=>_0xc058dd['type']===_0x202d29);_0x2b1fd0['sort']((_0xe182c8,_0x5f006a)=>au(_0x53e4a8,_0xe182c8,_0x5f006a)),_0x2b1fd0['forEach'](_0xdd3f29=>{const _0x197585=ou(_0x53e4a8,_0xdd3f29,_0x5c2c2e);_0x2b94a1['forEach'](_0x461f85=>{_0x461f85['respondsTo'](_0xdd3f29['type'])&&_0x1ad5fb['push'](_0x461f85['createEvent'](_0x197585,_0x53e4a8['query_']));});});}function ou(_0x4de293,_0x3158ae,_0x7c9801){return _0x3158ae['type']==='value'||_0x3158ae['type']==='child_removed'||(_0x3158ae['prevName']=_0x7c9801['getPredecessorChildName'](_0x3158ae['childName'],_0x3158ae['snapshotNode'],_0x4de293['index_'])),_0x3158ae;}function au(_0x2ffdb8,_0x336cf6,_0x46565e){if(_0x336cf6['childName']==null||_0x46565e['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x54b906=new E(_0x336cf6['childName'],_0x336cf6['snapshotNode']),_0x57e905=new E(_0x46565e['childName'],_0x46565e['snapshotNode']);return _0x2ffdb8['index_']['compare'](_0x54b906,_0x57e905);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x37d21d,_0x31e9f4){return{'eventCache':_0x37d21d,'serverCache':_0x31e9f4};}function Rt(_0xa9f47e,_0x2f2504,_0x144570,_0x423d5c){return Un(new Te(_0x2f2504,_0x144570,_0x423d5c),_0xa9f47e['serverCache']);}function Fo(_0x4a39a4,_0x2d3448,_0x4cf50c,_0x4c1aa9){return Un(_0x4a39a4['eventCache'],new Te(_0x2d3448,_0x4cf50c,_0x4c1aa9));}function wn(_0x5a92d2){return _0x5a92d2['eventCache']['isFullyInitialized']()?_0x5a92d2['eventCache']['getNode']():null;}function Ve(_0x39e8e1){return _0x39e8e1['serverCache']['isFullyInitialized']()?_0x39e8e1['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x687cda){let _0x59f907=new b(null);return x(_0x687cda,(_0x304cde,_0x139290)=>{_0x59f907=_0x59f907['set'](new C(_0x304cde),_0x139290);}),_0x59f907;}constructor(_0x30ae8d,_0x1c397c=cu()){this['value']=_0x30ae8d,this['children']=_0x1c397c;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x14f3d9,_0x1b1b45){if(this['value']!=null&&_0x1b1b45(this['value']))return{'path':w(),'value':this['value']};if(v(_0x14f3d9))return null;{const _0x15d3c4=y(_0x14f3d9),_0x272fd2=this['children']['get'](_0x15d3c4);if(_0x272fd2!==null){const _0x31955a=_0x272fd2['findRootMostMatchingPathAndValue'](S(_0x14f3d9),_0x1b1b45);return _0x31955a!=null?{'path':k(new C(_0x15d3c4),_0x31955a['path']),'value':_0x31955a['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x242d23){return this['findRootMostMatchingPathAndValue'](_0x242d23,()=>!0x0);}['subtree'](_0x46973a){if(v(_0x46973a))return this;{const _0x5c7091=y(_0x46973a),_0x13c93f=this['children']['get'](_0x5c7091);return _0x13c93f!==null?_0x13c93f['subtree'](S(_0x46973a)):new b(null);}}['set'](_0x8fd011,_0x3a959e){if(v(_0x8fd011))return new b(_0x3a959e,this['children']);{const _0x3f62d9=y(_0x8fd011),_0x51176f=(this['children']['get'](_0x3f62d9)||new b(null))['set'](S(_0x8fd011),_0x3a959e),_0x148ff1=this['children']['insert'](_0x3f62d9,_0x51176f);return new b(this['value'],_0x148ff1);}}['remove'](_0x5b389c){if(v(_0x5b389c))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x490e4b=y(_0x5b389c),_0x116a71=this['children']['get'](_0x490e4b);if(_0x116a71){const _0x91152a=_0x116a71['remove'](S(_0x5b389c));let _0x5af5fe;return _0x91152a['isEmpty']()?_0x5af5fe=this['children']['remove'](_0x490e4b):_0x5af5fe=this['children']['insert'](_0x490e4b,_0x91152a),this['value']===null&&_0x5af5fe['isEmpty']()?new b(null):new b(this['value'],_0x5af5fe);}else return this;}}['get'](_0x2bd168){if(v(_0x2bd168))return this['value'];{const _0x2e7e14=y(_0x2bd168),_0x2da8a9=this['children']['get'](_0x2e7e14);return _0x2da8a9?_0x2da8a9['get'](S(_0x2bd168)):null;}}['setTree'](_0x35d46f,_0x4b8f09){if(v(_0x35d46f))return _0x4b8f09;{const _0xe71475=y(_0x35d46f),_0x983eab=(this['children']['get'](_0xe71475)||new b(null))['setTree'](S(_0x35d46f),_0x4b8f09);let _0x4587e6;return _0x983eab['isEmpty']()?_0x4587e6=this['children']['remove'](_0xe71475):_0x4587e6=this['children']['insert'](_0xe71475,_0x983eab),new b(this['value'],_0x4587e6);}}['fold'](_0x2c01cb){return this['fold_'](w(),_0x2c01cb);}['fold_'](_0x31a233,_0xd7a97e){const _0x38d942={};return this['children']['inorderTraversal']((_0x4c2ffa,_0x715539)=>{_0x38d942[_0x4c2ffa]=_0x715539['fold_'](k(_0x31a233,_0x4c2ffa),_0xd7a97e);}),_0xd7a97e(_0x31a233,this['value'],_0x38d942);}['findOnPath'](_0x6fb21e,_0x19eae6){return this['findOnPath_'](_0x6fb21e,w(),_0x19eae6);}['findOnPath_'](_0x5a052f,_0x55cec3,_0x318fed){const _0xcd8857=this['value']?_0x318fed(_0x55cec3,this['value']):!0x1;if(_0xcd8857)return _0xcd8857;if(v(_0x5a052f))return null;{const _0x1149a3=y(_0x5a052f),_0x1c0282=this['children']['get'](_0x1149a3);return _0x1c0282?_0x1c0282['findOnPath_'](S(_0x5a052f),k(_0x55cec3,_0x1149a3),_0x318fed):null;}}['foreachOnPath'](_0x527f77,_0x58b6cb){return this['foreachOnPath_'](_0x527f77,w(),_0x58b6cb);}['foreachOnPath_'](_0xdf3ae8,_0x3abea6,_0x786596){if(v(_0xdf3ae8))return this;{this['value']&&_0x786596(_0x3abea6,this['value']);const _0x2caf53=y(_0xdf3ae8),_0x1dfb8d=this['children']['get'](_0x2caf53);return _0x1dfb8d?_0x1dfb8d['foreachOnPath_'](S(_0xdf3ae8),k(_0x3abea6,_0x2caf53),_0x786596):new b(null);}}['foreach'](_0x4117d8){this['foreach_'](w(),_0x4117d8);}['foreach_'](_0x5663a8,_0x269cae){this['children']['inorderTraversal']((_0x21b317,_0x1b9f3c)=>{_0x1b9f3c['foreach_'](k(_0x5663a8,_0x21b317),_0x269cae);}),this['value']&&_0x269cae(_0x5663a8,this['value']);}['foreachChild'](_0x4df494){this['children']['inorderTraversal']((_0x10bf39,_0x4822d5)=>{_0x4822d5['value']&&_0x4df494(_0x10bf39,_0x4822d5['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x95e79b){this['writeTree_']=_0x95e79b;}static['empty'](){return new K(new b(null));}}function At(_0x58fcc2,_0x4c40b9,_0x48d1ca){if(v(_0x4c40b9))return new K(new b(_0x48d1ca));{const _0x2c0dff=_0x58fcc2['writeTree_']['findRootMostValueAndPath'](_0x4c40b9);if(_0x2c0dff!=null){const _0x3e11aa=_0x2c0dff['path'];let _0x40c231=_0x2c0dff['value'];const _0x39fd31=F(_0x3e11aa,_0x4c40b9);return _0x40c231=_0x40c231['updateChild'](_0x39fd31,_0x48d1ca),new K(_0x58fcc2['writeTree_']['set'](_0x3e11aa,_0x40c231));}else{const _0x2c62e2=new b(_0x48d1ca),_0x522ee0=_0x58fcc2['writeTree_']['setTree'](_0x4c40b9,_0x2c62e2);return new K(_0x522ee0);}}}function bi(_0x58ecfb,_0x5303f6,_0xdb4dc6){let _0x386f58=_0x58ecfb;return x(_0xdb4dc6,(_0x374a63,_0x13e4b3)=>{_0x386f58=At(_0x386f58,k(_0x5303f6,_0x374a63),_0x13e4b3);}),_0x386f58;}function or(_0x493f7f,_0x3bf325){if(v(_0x3bf325))return K['empty']();{const _0x5cfcf=_0x493f7f['writeTree_']['setTree'](_0x3bf325,new b(null));return new K(_0x5cfcf);}}function Ri(_0x1387d4,_0x2d4485){return ze(_0x1387d4,_0x2d4485)!=null;}function ze(_0x2dab3c,_0x40aefc){const _0x24d4d9=_0x2dab3c['writeTree_']['findRootMostValueAndPath'](_0x40aefc);return _0x24d4d9!=null?_0x2dab3c['writeTree_']['get'](_0x24d4d9['path'])['getChild'](F(_0x24d4d9['path'],_0x40aefc)):null;}function ar(_0x360306){const _0x3fbe80=[],_0x43ea91=_0x360306['writeTree_']['value'];return _0x43ea91!=null?_0x43ea91['isLeafNode']()||_0x43ea91['forEachChild'](R,(_0x4ba5db,_0x48d5da)=>{_0x3fbe80['push'](new E(_0x4ba5db,_0x48d5da));}):_0x360306['writeTree_']['children']['inorderTraversal']((_0x1636f7,_0x2ee622)=>{_0x2ee622['value']!=null&&_0x3fbe80['push'](new E(_0x1636f7,_0x2ee622['value']));}),_0x3fbe80;}function Ee(_0x46ab63,_0x5f4b9a){if(v(_0x5f4b9a))return _0x46ab63;{const _0x589c40=ze(_0x46ab63,_0x5f4b9a);return _0x589c40!=null?new K(new b(_0x589c40)):new K(_0x46ab63['writeTree_']['subtree'](_0x5f4b9a));}}function Ai(_0x204253){return _0x204253['writeTree_']['isEmpty']();}function at(_0x52021d,_0x1f3c5c){return Uo(w(),_0x52021d['writeTree_'],_0x1f3c5c);}function Uo(_0x1cfc7c,_0x5201b6,_0x406dba){if(_0x5201b6['value']!=null)return _0x406dba['updateChild'](_0x1cfc7c,_0x5201b6['value']);{let _0x495673=null;return _0x5201b6['children']['inorderTraversal']((_0x3baa0a,_0x49feb8)=>{_0x3baa0a==='.priority'?(f(_0x49feb8['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x495673=_0x49feb8['value']):_0x406dba=Uo(k(_0x1cfc7c,_0x3baa0a),_0x49feb8,_0x406dba);}),!_0x406dba['getChild'](_0x1cfc7c)['isEmpty']()&&_0x495673!==null&&(_0x406dba=_0x406dba['updateChild'](k(_0x1cfc7c,'.priority'),_0x495673)),_0x406dba;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x1baf01,_0x2526b2){return Ho(_0x2526b2,_0x1baf01);}function lu(_0x19b023,_0x15a381,_0x50ac16,_0x22b74d,_0x3ab3c6){f(_0x22b74d>_0x19b023['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x3ab3c6===void 0x0&&(_0x3ab3c6=!0x0),_0x19b023['allWrites']['push']({'path':_0x15a381,'snap':_0x50ac16,'writeId':_0x22b74d,'visible':_0x3ab3c6}),_0x3ab3c6&&(_0x19b023['visibleWrites']=At(_0x19b023['visibleWrites'],_0x15a381,_0x50ac16)),_0x19b023['lastWriteId']=_0x22b74d;}function hu(_0x1f0e2e,_0x317607,_0x56c456,_0x5c19bb){f(_0x5c19bb>_0x1f0e2e['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x1f0e2e['allWrites']['push']({'path':_0x317607,'children':_0x56c456,'writeId':_0x5c19bb,'visible':!0x0}),_0x1f0e2e['visibleWrites']=bi(_0x1f0e2e['visibleWrites'],_0x317607,_0x56c456),_0x1f0e2e['lastWriteId']=_0x5c19bb;}function uu(_0x40b965,_0x3db004){for(let _0x14a55c=0x0;_0x14a55c<_0x40b965['allWrites']['length'];_0x14a55c++){const _0x1358b7=_0x40b965['allWrites'][_0x14a55c];if(_0x1358b7['writeId']===_0x3db004)return _0x1358b7;}return null;}function du(_0x4d7d17,_0xaa1054){const _0x56523f=_0x4d7d17['allWrites']['findIndex'](_0x72a4c0=>_0x72a4c0['writeId']===_0xaa1054);f(_0x56523f>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x581fb8=_0x4d7d17['allWrites'][_0x56523f];_0x4d7d17['allWrites']['splice'](_0x56523f,0x1);let _0x1d4d17=_0x581fb8['visible'],_0x2e3eb1=!0x1,_0x6d5c50=_0x4d7d17['allWrites']['length']-0x1;for(;_0x1d4d17&&_0x6d5c50>=0x0;){const _0x55430d=_0x4d7d17['allWrites'][_0x6d5c50];_0x55430d['visible']&&(_0x6d5c50>=_0x56523f&&fu(_0x55430d,_0x581fb8['path'])?_0x1d4d17=!0x1:G(_0x581fb8['path'],_0x55430d['path'])&&(_0x2e3eb1=!0x0)),_0x6d5c50--;}if(_0x1d4d17){if(_0x2e3eb1)return pu(_0x4d7d17),!0x0;if(_0x581fb8['snap'])_0x4d7d17['visibleWrites']=or(_0x4d7d17['visibleWrites'],_0x581fb8['path']);else{const _0x565386=_0x581fb8['children'];x(_0x565386,_0xbb3ea4=>{_0x4d7d17['visibleWrites']=or(_0x4d7d17['visibleWrites'],k(_0x581fb8['path'],_0xbb3ea4));});}return!0x0;}else return!0x1;}function fu(_0x450fa1,_0x204dcb){if(_0x450fa1['snap'])return G(_0x450fa1['path'],_0x204dcb);for(const _0x1f21b7 in _0x450fa1['children'])if(_0x450fa1['children']['hasOwnProperty'](_0x1f21b7)&&G(k(_0x450fa1['path'],_0x1f21b7),_0x204dcb))return!0x0;return!0x1;}function pu(_0x4abd7c){_0x4abd7c['visibleWrites']=Wo(_0x4abd7c['allWrites'],_u,w()),_0x4abd7c['allWrites']['length']>0x0?_0x4abd7c['lastWriteId']=_0x4abd7c['allWrites'][_0x4abd7c['allWrites']['length']-0x1]['writeId']:_0x4abd7c['lastWriteId']=-0x1;}function _u(_0x52bfbf){return _0x52bfbf['visible'];}function Wo(_0x5eefac,_0xd6570a,_0x5512ba){let _0x160d69=K['empty']();for(let _0x38ea1a=0x0;_0x38ea1a<_0x5eefac['length'];++_0x38ea1a){const _0x275161=_0x5eefac[_0x38ea1a];if(_0xd6570a(_0x275161)){const _0x50bfe0=_0x275161['path'];let _0x55d606;if(_0x275161['snap'])G(_0x5512ba,_0x50bfe0)?(_0x55d606=F(_0x5512ba,_0x50bfe0),_0x160d69=At(_0x160d69,_0x55d606,_0x275161['snap'])):G(_0x50bfe0,_0x5512ba)&&(_0x55d606=F(_0x50bfe0,_0x5512ba),_0x160d69=At(_0x160d69,w(),_0x275161['snap']['getChild'](_0x55d606)));else{if(_0x275161['children']){if(G(_0x5512ba,_0x50bfe0))_0x55d606=F(_0x5512ba,_0x50bfe0),_0x160d69=bi(_0x160d69,_0x55d606,_0x275161['children']);else{if(G(_0x50bfe0,_0x5512ba)){if(_0x55d606=F(_0x50bfe0,_0x5512ba),v(_0x55d606))_0x160d69=bi(_0x160d69,w(),_0x275161['children']);else{const _0x2e6796=Le(_0x275161['children'],y(_0x55d606));if(_0x2e6796){const _0x5c88f5=_0x2e6796['getChild'](S(_0x55d606));_0x160d69=At(_0x160d69,w(),_0x5c88f5);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x160d69;}function Bo(_0x40d818,_0xeb59a5,_0x1c4f23,_0x2c7af9,_0x9e4af4){if(!_0x2c7af9&&!_0x9e4af4){const _0x3b5374=ze(_0x40d818['visibleWrites'],_0xeb59a5);if(_0x3b5374!=null)return _0x3b5374;{const _0x136d6b=Ee(_0x40d818['visibleWrites'],_0xeb59a5);if(Ai(_0x136d6b))return _0x1c4f23;if(_0x1c4f23==null&&!Ri(_0x136d6b,w()))return null;{const _0x13fc16=_0x1c4f23||g['EMPTY_NODE'];return at(_0x136d6b,_0x13fc16);}}}else{const _0x40a190=Ee(_0x40d818['visibleWrites'],_0xeb59a5);if(!_0x9e4af4&&Ai(_0x40a190))return _0x1c4f23;if(!_0x9e4af4&&_0x1c4f23==null&&!Ri(_0x40a190,w()))return null;{const _0x2d1e2d=function(_0x3704a6){return(_0x3704a6['visible']||_0x9e4af4)&&(!_0x2c7af9||!~_0x2c7af9['indexOf'](_0x3704a6['writeId']))&&(G(_0x3704a6['path'],_0xeb59a5)||G(_0xeb59a5,_0x3704a6['path']));},_0x3ea8da=Wo(_0x40d818['allWrites'],_0x2d1e2d,_0xeb59a5),_0x30b186=_0x1c4f23||g['EMPTY_NODE'];return at(_0x3ea8da,_0x30b186);}}}function gu(_0x406ddf,_0x46f576,_0x5aec20){let _0x175ed2=g['EMPTY_NODE'];const _0x207243=ze(_0x406ddf['visibleWrites'],_0x46f576);if(_0x207243)return _0x207243['isLeafNode']()||_0x207243['forEachChild'](R,(_0x5f17bb,_0x598da4)=>{_0x175ed2=_0x175ed2['updateImmediateChild'](_0x5f17bb,_0x598da4);}),_0x175ed2;if(_0x5aec20){const _0x5d5881=Ee(_0x406ddf['visibleWrites'],_0x46f576);return _0x5aec20['forEachChild'](R,(_0x2e795d,_0x5c0ab4)=>{const _0x1b9662=at(Ee(_0x5d5881,new C(_0x2e795d)),_0x5c0ab4);_0x175ed2=_0x175ed2['updateImmediateChild'](_0x2e795d,_0x1b9662);}),ar(_0x5d5881)['forEach'](_0x5d5e64=>{_0x175ed2=_0x175ed2['updateImmediateChild'](_0x5d5e64['name'],_0x5d5e64['node']);}),_0x175ed2;}else{const _0x28c785=Ee(_0x406ddf['visibleWrites'],_0x46f576);return ar(_0x28c785)['forEach'](_0x3da6e4=>{_0x175ed2=_0x175ed2['updateImmediateChild'](_0x3da6e4['name'],_0x3da6e4['node']);}),_0x175ed2;}}function mu(_0x3bcfdc,_0x539289,_0x6e1095,_0x1947af,_0x234f91){f(_0x1947af||_0x234f91,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x381f2d=k(_0x539289,_0x6e1095);if(Ri(_0x3bcfdc['visibleWrites'],_0x381f2d))return null;{const _0xcb67f2=Ee(_0x3bcfdc['visibleWrites'],_0x381f2d);return Ai(_0xcb67f2)?_0x234f91['getChild'](_0x6e1095):at(_0xcb67f2,_0x234f91['getChild'](_0x6e1095));}}function yu(_0x42e1d3,_0x24281e,_0x5621c1,_0x4bd706){const _0x552d22=k(_0x24281e,_0x5621c1),_0x420a9c=ze(_0x42e1d3['visibleWrites'],_0x552d22);if(_0x420a9c!=null)return _0x420a9c;if(_0x4bd706['isCompleteForChild'](_0x5621c1)){const _0x53111f=Ee(_0x42e1d3['visibleWrites'],_0x552d22);return at(_0x53111f,_0x4bd706['getNode']()['getImmediateChild'](_0x5621c1));}else return null;}function vu(_0x53da43,_0xe1340){return ze(_0x53da43['visibleWrites'],_0xe1340);}function Eu(_0x1dd0a6,_0x4307d0,_0x478ed9,_0x3e0ebf,_0x2699bc,_0x68503,_0x43ceca){let _0x1e74dc;const _0x1ace1f=Ee(_0x1dd0a6['visibleWrites'],_0x4307d0),_0x494018=ze(_0x1ace1f,w());if(_0x494018!=null)_0x1e74dc=_0x494018;else{if(_0x478ed9!=null)_0x1e74dc=at(_0x1ace1f,_0x478ed9);else return[];}if(_0x1e74dc=_0x1e74dc['withIndex'](_0x43ceca),!_0x1e74dc['isEmpty']()&&!_0x1e74dc['isLeafNode']()){const _0x20e539=[],_0x2fd127=_0x43ceca['getCompare'](),_0x50e787=_0x68503?_0x1e74dc['getReverseIteratorFrom'](_0x3e0ebf,_0x43ceca):_0x1e74dc['getIteratorFrom'](_0x3e0ebf,_0x43ceca);let _0x34a140=_0x50e787['getNext']();for(;_0x34a140&&_0x20e539['length']<_0x2699bc;)_0x2fd127(_0x34a140,_0x3e0ebf)!==0x0&&_0x20e539['push'](_0x34a140),_0x34a140=_0x50e787['getNext']();return _0x20e539;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x307b1a,_0x5f5d9e,_0x37913b,_0x12cff2){return Bo(_0x307b1a['writeTree'],_0x307b1a['treePath'],_0x5f5d9e,_0x37913b,_0x12cff2);}function is(_0x4c798a,_0x16afad){return gu(_0x4c798a['writeTree'],_0x4c798a['treePath'],_0x16afad);}function cr(_0x107246,_0x355c16,_0x3398dc,_0x4d4613){return mu(_0x107246['writeTree'],_0x107246['treePath'],_0x355c16,_0x3398dc,_0x4d4613);}function Tn(_0x4a1f36,_0x26f00c){return vu(_0x4a1f36['writeTree'],k(_0x4a1f36['treePath'],_0x26f00c));}function wu(_0x1d2bab,_0x488c67,_0x17d726,_0x4cf326,_0x2e57bc,_0x54e3ac){return Eu(_0x1d2bab['writeTree'],_0x1d2bab['treePath'],_0x488c67,_0x17d726,_0x4cf326,_0x2e57bc,_0x54e3ac);}function ss(_0x1806f0,_0x61260,_0x599836){return yu(_0x1806f0['writeTree'],_0x1806f0['treePath'],_0x61260,_0x599836);}function Vo(_0x128185,_0x519dd5){return Ho(k(_0x128185['treePath'],_0x519dd5),_0x128185['writeTree']);}function Ho(_0x4b7103,_0x5888c5){return{'treePath':_0x4b7103,'writeTree':_0x5888c5};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0xb853d){const _0x465530=_0xb853d['type'],_0x16c06f=_0xb853d['childName'];f(_0x465530==='child_added'||_0x465530==='child_changed'||_0x465530==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x16c06f!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x126816=this['changeMap']['get'](_0x16c06f);if(_0x126816){const _0x1021ef=_0x126816['type'];if(_0x465530==='child_added'&&_0x1021ef==='child_removed')this['changeMap']['set'](_0x16c06f,xt(_0x16c06f,_0xb853d['snapshotNode'],_0x126816['snapshotNode']));else{if(_0x465530==='child_removed'&&_0x1021ef==='child_added')this['changeMap']['delete'](_0x16c06f);else{if(_0x465530==='child_removed'&&_0x1021ef==='child_changed')this['changeMap']['set'](_0x16c06f,Lt(_0x16c06f,_0x126816['oldSnap']));else{if(_0x465530==='child_changed'&&_0x1021ef==='child_added')this['changeMap']['set'](_0x16c06f,rt(_0x16c06f,_0xb853d['snapshotNode']));else{if(_0x465530==='child_changed'&&_0x1021ef==='child_changed')this['changeMap']['set'](_0x16c06f,xt(_0x16c06f,_0xb853d['snapshotNode'],_0x126816['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0xb853d+'\x20occurred\x20after\x20'+_0x126816);}}}}}else this['changeMap']['set'](_0x16c06f,_0xb853d);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x3c8adb){return null;}['getChildAfterChild'](_0x2471ec,_0x2d2e27,_0x1fdacb){return null;}}const $o=new Tu();class rs{constructor(_0x2dfc22,_0x4533ee,_0x562def=null){this['writes_']=_0x2dfc22,this['viewCache_']=_0x4533ee,this['optCompleteServerCache_']=_0x562def;}['getCompleteChild'](_0x35bd3d){const _0xc3997=this['viewCache_']['eventCache'];if(_0xc3997['isCompleteForChild'](_0x35bd3d))return _0xc3997['getNode']()['getImmediateChild'](_0x35bd3d);{const _0x44f30b=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x35bd3d,_0x44f30b);}}['getChildAfterChild'](_0x5fc22b,_0x2f0c19,_0x323921){const _0x409c46=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x33d8cb=wu(this['writes_'],_0x409c46,_0x2f0c19,0x1,_0x323921,_0x5fc22b);return _0x33d8cb['length']===0x0?null:_0x33d8cb[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x53c3e8){return{'filter':_0x53c3e8};}function bu(_0x28f56a,_0x1eaba6){f(_0x1eaba6['eventCache']['getNode']()['isIndexed'](_0x28f56a['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x1eaba6['serverCache']['getNode']()['isIndexed'](_0x28f56a['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x5939aa,_0x14f820,_0x46b387,_0x42397e,_0x1a6c5e){const _0x36ffba=new Cu();let _0x472956,_0x441cfc;if(_0x46b387['type']===z['OVERWRITE']){const _0x43b7b9=_0x46b387;_0x43b7b9['source']['fromUser']?_0x472956=ki(_0x5939aa,_0x14f820,_0x43b7b9['path'],_0x43b7b9['snap'],_0x42397e,_0x1a6c5e,_0x36ffba):(f(_0x43b7b9['source']['fromServer'],'Unknown\x20source.'),_0x441cfc=_0x43b7b9['source']['tagged']||_0x14f820['serverCache']['isFiltered']()&&!v(_0x43b7b9['path']),_0x472956=Sn(_0x5939aa,_0x14f820,_0x43b7b9['path'],_0x43b7b9['snap'],_0x42397e,_0x1a6c5e,_0x441cfc,_0x36ffba));}else{if(_0x46b387['type']===z['MERGE']){const _0x5a150b=_0x46b387;_0x5a150b['source']['fromUser']?_0x472956=ku(_0x5939aa,_0x14f820,_0x5a150b['path'],_0x5a150b['children'],_0x42397e,_0x1a6c5e,_0x36ffba):(f(_0x5a150b['source']['fromServer'],'Unknown\x20source.'),_0x441cfc=_0x5a150b['source']['tagged']||_0x14f820['serverCache']['isFiltered'](),_0x472956=Pi(_0x5939aa,_0x14f820,_0x5a150b['path'],_0x5a150b['children'],_0x42397e,_0x1a6c5e,_0x441cfc,_0x36ffba));}else{if(_0x46b387['type']===z['ACK_USER_WRITE']){const _0x5bbbe5=_0x46b387;_0x5bbbe5['revert']?_0x472956=Ou(_0x5939aa,_0x14f820,_0x5bbbe5['path'],_0x42397e,_0x1a6c5e,_0x36ffba):_0x472956=Pu(_0x5939aa,_0x14f820,_0x5bbbe5['path'],_0x5bbbe5['affectedTree'],_0x42397e,_0x1a6c5e,_0x36ffba);}else{if(_0x46b387['type']===z['LISTEN_COMPLETE'])_0x472956=Nu(_0x5939aa,_0x14f820,_0x46b387['path'],_0x42397e,_0x36ffba);else throw ht('Unknown\x20operation\x20type:\x20'+_0x46b387['type']);}}}const _0x556cec=_0x36ffba['getChanges']();return Au(_0x14f820,_0x472956,_0x556cec),{'viewCache':_0x472956,'changes':_0x556cec};}function Au(_0x4ce121,_0x1d4677,_0x4e66e0){const _0x2d28cb=_0x1d4677['eventCache'];if(_0x2d28cb['isFullyInitialized']()){const _0x46ddeb=_0x2d28cb['getNode']()['isLeafNode']()||_0x2d28cb['getNode']()['isEmpty'](),_0x473783=wn(_0x4ce121);(_0x4e66e0['length']>0x0||!_0x4ce121['eventCache']['isFullyInitialized']()||_0x46ddeb&&!_0x2d28cb['getNode']()['equals'](_0x473783)||!_0x2d28cb['getNode']()['getPriority']()['equals'](_0x473783['getPriority']()))&&_0x4e66e0['push'](Lo(wn(_0x1d4677)));}}function Go(_0x3622a8,_0x7f8e24,_0x10ef05,_0x2ce143,_0x5503ce,_0x22b91d){const _0x5bb497=_0x7f8e24['eventCache'];if(Tn(_0x2ce143,_0x10ef05)!=null)return _0x7f8e24;{let _0x315854,_0x1adc3f;if(v(_0x10ef05)){if(f(_0x7f8e24['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x7f8e24['serverCache']['isFiltered']()){const _0x3fb9b5=Ve(_0x7f8e24),_0x24fa6d=_0x3fb9b5 instanceof g?_0x3fb9b5:g['EMPTY_NODE'],_0xb2c430=is(_0x2ce143,_0x24fa6d);_0x315854=_0x3622a8['filter']['updateFullNode'](_0x7f8e24['eventCache']['getNode'](),_0xb2c430,_0x22b91d);}else{const _0xa646b4=Cn(_0x2ce143,Ve(_0x7f8e24));_0x315854=_0x3622a8['filter']['updateFullNode'](_0x7f8e24['eventCache']['getNode'](),_0xa646b4,_0x22b91d);}}else{const _0x51cc49=y(_0x10ef05);if(_0x51cc49==='.priority'){f(Ce(_0x10ef05)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x332e15=_0x5bb497['getNode']();_0x1adc3f=_0x7f8e24['serverCache']['getNode']();const _0x5c796e=cr(_0x2ce143,_0x10ef05,_0x332e15,_0x1adc3f);_0x5c796e!=null?_0x315854=_0x3622a8['filter']['updatePriority'](_0x332e15,_0x5c796e):_0x315854=_0x5bb497['getNode']();}else{const _0xca8d76=S(_0x10ef05);let _0x42227c;if(_0x5bb497['isCompleteForChild'](_0x51cc49)){_0x1adc3f=_0x7f8e24['serverCache']['getNode']();const _0x16a71a=cr(_0x2ce143,_0x10ef05,_0x5bb497['getNode'](),_0x1adc3f);_0x16a71a!=null?_0x42227c=_0x5bb497['getNode']()['getImmediateChild'](_0x51cc49)['updateChild'](_0xca8d76,_0x16a71a):_0x42227c=_0x5bb497['getNode']()['getImmediateChild'](_0x51cc49);}else _0x42227c=ss(_0x2ce143,_0x51cc49,_0x7f8e24['serverCache']);_0x42227c!=null?_0x315854=_0x3622a8['filter']['updateChild'](_0x5bb497['getNode'](),_0x51cc49,_0x42227c,_0xca8d76,_0x5503ce,_0x22b91d):_0x315854=_0x5bb497['getNode']();}}return Rt(_0x7f8e24,_0x315854,_0x5bb497['isFullyInitialized']()||v(_0x10ef05),_0x3622a8['filter']['filtersNodes']());}}function Sn(_0x26c43,_0x5e03b8,_0x185f8d,_0x499168,_0x4ba5c4,_0x5b4ab9,_0x1721e0,_0x5c3968){const _0x2ce8b4=_0x5e03b8['serverCache'];let _0x19554a;const _0x42eb52=_0x1721e0?_0x26c43['filter']:_0x26c43['filter']['getIndexedFilter']();if(v(_0x185f8d))_0x19554a=_0x42eb52['updateFullNode'](_0x2ce8b4['getNode'](),_0x499168,null);else{if(_0x42eb52['filtersNodes']()&&!_0x2ce8b4['isFiltered']()){const _0x7eda18=_0x2ce8b4['getNode']()['updateChild'](_0x185f8d,_0x499168);_0x19554a=_0x42eb52['updateFullNode'](_0x2ce8b4['getNode'](),_0x7eda18,null);}else{const _0x23af31=y(_0x185f8d);if(!_0x2ce8b4['isCompleteForPath'](_0x185f8d)&&Ce(_0x185f8d)>0x1)return _0x5e03b8;const _0x4d5aff=S(_0x185f8d),_0x172172=_0x2ce8b4['getNode']()['getImmediateChild'](_0x23af31)['updateChild'](_0x4d5aff,_0x499168);_0x23af31==='.priority'?_0x19554a=_0x42eb52['updatePriority'](_0x2ce8b4['getNode'](),_0x172172):_0x19554a=_0x42eb52['updateChild'](_0x2ce8b4['getNode'](),_0x23af31,_0x172172,_0x4d5aff,$o,null);}}const _0x57e90d=Fo(_0x5e03b8,_0x19554a,_0x2ce8b4['isFullyInitialized']()||v(_0x185f8d),_0x42eb52['filtersNodes']()),_0x4bc279=new rs(_0x4ba5c4,_0x57e90d,_0x5b4ab9);return Go(_0x26c43,_0x57e90d,_0x185f8d,_0x4ba5c4,_0x4bc279,_0x5c3968);}function ki(_0x3ce5b9,_0x511c58,_0x2fa120,_0x43f15f,_0x211e43,_0x453b79,_0x20e7f1){const _0x4bd956=_0x511c58['eventCache'];let _0x1530be,_0x249b28;const _0x5ce9ac=new rs(_0x211e43,_0x511c58,_0x453b79);if(v(_0x2fa120))_0x249b28=_0x3ce5b9['filter']['updateFullNode'](_0x511c58['eventCache']['getNode'](),_0x43f15f,_0x20e7f1),_0x1530be=Rt(_0x511c58,_0x249b28,!0x0,_0x3ce5b9['filter']['filtersNodes']());else{const _0x1eb7ad=y(_0x2fa120);if(_0x1eb7ad==='.priority')_0x249b28=_0x3ce5b9['filter']['updatePriority'](_0x511c58['eventCache']['getNode'](),_0x43f15f),_0x1530be=Rt(_0x511c58,_0x249b28,_0x4bd956['isFullyInitialized'](),_0x4bd956['isFiltered']());else{const _0xb8f884=S(_0x2fa120),_0x1cdf05=_0x4bd956['getNode']()['getImmediateChild'](_0x1eb7ad);let _0x3d23ff;if(v(_0xb8f884))_0x3d23ff=_0x43f15f;else{const _0xbc8c0f=_0x5ce9ac['getCompleteChild'](_0x1eb7ad);_0xbc8c0f!=null?ji(_0xb8f884)==='.priority'&&_0xbc8c0f['getChild'](Ro(_0xb8f884))['isEmpty']()?_0x3d23ff=_0xbc8c0f:_0x3d23ff=_0xbc8c0f['updateChild'](_0xb8f884,_0x43f15f):_0x3d23ff=g['EMPTY_NODE'];}if(_0x1cdf05['equals'](_0x3d23ff))_0x1530be=_0x511c58;else{const _0x3ecaa4=_0x3ce5b9['filter']['updateChild'](_0x4bd956['getNode'](),_0x1eb7ad,_0x3d23ff,_0xb8f884,_0x5ce9ac,_0x20e7f1);_0x1530be=Rt(_0x511c58,_0x3ecaa4,_0x4bd956['isFullyInitialized'](),_0x3ce5b9['filter']['filtersNodes']());}}}return _0x1530be;}function lr(_0x37a178,_0x2ab3fc){return _0x37a178['eventCache']['isCompleteForChild'](_0x2ab3fc);}function ku(_0x20d8c8,_0x4b522b,_0x7303d0,_0x371025,_0x25270f,_0x813ed0,_0x398d03){let _0x3963c3=_0x4b522b;return _0x371025['foreach']((_0x242e2d,_0x1f67be)=>{const _0x1c4558=k(_0x7303d0,_0x242e2d);lr(_0x4b522b,y(_0x1c4558))&&(_0x3963c3=ki(_0x20d8c8,_0x3963c3,_0x1c4558,_0x1f67be,_0x25270f,_0x813ed0,_0x398d03));}),_0x371025['foreach']((_0xed8dcc,_0x39c715)=>{const _0x28a50a=k(_0x7303d0,_0xed8dcc);lr(_0x4b522b,y(_0x28a50a))||(_0x3963c3=ki(_0x20d8c8,_0x3963c3,_0x28a50a,_0x39c715,_0x25270f,_0x813ed0,_0x398d03));}),_0x3963c3;}function hr(_0x29a941,_0x8d64c5,_0x4f4775){return _0x4f4775['foreach']((_0xfade22,_0x30e3a6)=>{_0x8d64c5=_0x8d64c5['updateChild'](_0xfade22,_0x30e3a6);}),_0x8d64c5;}function Pi(_0x421fa3,_0x4d478d,_0x17e8f9,_0x5b35b4,_0x4bedf8,_0x2d54f4,_0x389101,_0x5094e3){if(_0x4d478d['serverCache']['getNode']()['isEmpty']()&&!_0x4d478d['serverCache']['isFullyInitialized']())return _0x4d478d;let _0x457da8=_0x4d478d,_0xf27ff4;v(_0x17e8f9)?_0xf27ff4=_0x5b35b4:_0xf27ff4=new b(null)['setTree'](_0x17e8f9,_0x5b35b4);const _0x42ff19=_0x4d478d['serverCache']['getNode']();return _0xf27ff4['children']['inorderTraversal']((_0x369c74,_0xa8390c)=>{if(_0x42ff19['hasChild'](_0x369c74)){const _0x362bb2=_0x4d478d['serverCache']['getNode']()['getImmediateChild'](_0x369c74),_0x111605=hr(_0x421fa3,_0x362bb2,_0xa8390c);_0x457da8=Sn(_0x421fa3,_0x457da8,new C(_0x369c74),_0x111605,_0x4bedf8,_0x2d54f4,_0x389101,_0x5094e3);}}),_0xf27ff4['children']['inorderTraversal']((_0x4c8519,_0x2f156c)=>{const _0x1b86d8=!_0x4d478d['serverCache']['isCompleteForChild'](_0x4c8519)&&_0x2f156c['value']===null;if(!_0x42ff19['hasChild'](_0x4c8519)&&!_0x1b86d8){const _0x5dd889=_0x4d478d['serverCache']['getNode']()['getImmediateChild'](_0x4c8519),_0x2ee2ec=hr(_0x421fa3,_0x5dd889,_0x2f156c);_0x457da8=Sn(_0x421fa3,_0x457da8,new C(_0x4c8519),_0x2ee2ec,_0x4bedf8,_0x2d54f4,_0x389101,_0x5094e3);}}),_0x457da8;}function Pu(_0x407c55,_0x4453b8,_0x5c763a,_0x539d9a,_0x498e7d,_0x16a674,_0x17b4a2){if(Tn(_0x498e7d,_0x5c763a)!=null)return _0x4453b8;const _0x292b0c=_0x4453b8['serverCache']['isFiltered'](),_0x3d3029=_0x4453b8['serverCache'];if(_0x539d9a['value']!=null){if(v(_0x5c763a)&&_0x3d3029['isFullyInitialized']()||_0x3d3029['isCompleteForPath'](_0x5c763a))return Sn(_0x407c55,_0x4453b8,_0x5c763a,_0x3d3029['getNode']()['getChild'](_0x5c763a),_0x498e7d,_0x16a674,_0x292b0c,_0x17b4a2);if(v(_0x5c763a)){let _0x1c44ab=new b(null);return _0x3d3029['getNode']()['forEachChild'](ve,(_0x58bc89,_0x1bd74a)=>{_0x1c44ab=_0x1c44ab['set'](new C(_0x58bc89),_0x1bd74a);}),Pi(_0x407c55,_0x4453b8,_0x5c763a,_0x1c44ab,_0x498e7d,_0x16a674,_0x292b0c,_0x17b4a2);}else return _0x4453b8;}else{let _0xa72ece=new b(null);return _0x539d9a['foreach']((_0x30a75e,_0x5b4103)=>{const _0x4daaec=k(_0x5c763a,_0x30a75e);_0x3d3029['isCompleteForPath'](_0x4daaec)&&(_0xa72ece=_0xa72ece['set'](_0x30a75e,_0x3d3029['getNode']()['getChild'](_0x4daaec)));}),Pi(_0x407c55,_0x4453b8,_0x5c763a,_0xa72ece,_0x498e7d,_0x16a674,_0x292b0c,_0x17b4a2);}}function Nu(_0x2c5bb1,_0x49b210,_0x5ef1fb,_0x42c3bf,_0x1aee1d){const _0x143247=_0x49b210['serverCache'],_0x508018=Fo(_0x49b210,_0x143247['getNode'](),_0x143247['isFullyInitialized']()||v(_0x5ef1fb),_0x143247['isFiltered']());return Go(_0x2c5bb1,_0x508018,_0x5ef1fb,_0x42c3bf,$o,_0x1aee1d);}function Ou(_0x57af2e,_0x216a1f,_0x47b515,_0x14ac46,_0x52e2b4,_0x266674){let _0x2dc273;if(Tn(_0x14ac46,_0x47b515)!=null)return _0x216a1f;{const _0x5efde6=new rs(_0x14ac46,_0x216a1f,_0x52e2b4),_0x24976a=_0x216a1f['eventCache']['getNode']();let _0xafd0a3;if(v(_0x47b515)||y(_0x47b515)==='.priority'){let _0xa2d765;if(_0x216a1f['serverCache']['isFullyInitialized']())_0xa2d765=Cn(_0x14ac46,Ve(_0x216a1f));else{const _0xd466af=_0x216a1f['serverCache']['getNode']();f(_0xd466af instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0xa2d765=is(_0x14ac46,_0xd466af);}_0xa2d765=_0xa2d765,_0xafd0a3=_0x57af2e['filter']['updateFullNode'](_0x24976a,_0xa2d765,_0x266674);}else{const _0x313a0d=y(_0x47b515);let _0x12f9d8=ss(_0x14ac46,_0x313a0d,_0x216a1f['serverCache']);_0x12f9d8==null&&_0x216a1f['serverCache']['isCompleteForChild'](_0x313a0d)&&(_0x12f9d8=_0x24976a['getImmediateChild'](_0x313a0d)),_0x12f9d8!=null?_0xafd0a3=_0x57af2e['filter']['updateChild'](_0x24976a,_0x313a0d,_0x12f9d8,S(_0x47b515),_0x5efde6,_0x266674):_0x216a1f['eventCache']['getNode']()['hasChild'](_0x313a0d)?_0xafd0a3=_0x57af2e['filter']['updateChild'](_0x24976a,_0x313a0d,g['EMPTY_NODE'],S(_0x47b515),_0x5efde6,_0x266674):_0xafd0a3=_0x24976a,_0xafd0a3['isEmpty']()&&_0x216a1f['serverCache']['isFullyInitialized']()&&(_0x2dc273=Cn(_0x14ac46,Ve(_0x216a1f)),_0x2dc273['isLeafNode']()&&(_0xafd0a3=_0x57af2e['filter']['updateFullNode'](_0xafd0a3,_0x2dc273,_0x266674)));}return _0x2dc273=_0x216a1f['serverCache']['isFullyInitialized']()||Tn(_0x14ac46,w())!=null,Rt(_0x216a1f,_0xafd0a3,_0x2dc273,_0x57af2e['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x2bc63f,_0x5289ba){this['query_']=_0x2bc63f,this['eventRegistrations_']=[];const _0x89bd49=this['query_']['_queryParams'],_0x58575d=new Xi(_0x89bd49['getIndex']()),_0x34dfd9=Kh(_0x89bd49);this['processor_']=Su(_0x34dfd9);const _0x6fb128=_0x5289ba['serverCache'],_0x20d28f=_0x5289ba['eventCache'],_0x46081a=_0x58575d['updateFullNode'](g['EMPTY_NODE'],_0x6fb128['getNode'](),null),_0x4763d6=_0x34dfd9['updateFullNode'](g['EMPTY_NODE'],_0x20d28f['getNode'](),null),_0xd22263=new Te(_0x46081a,_0x6fb128['isFullyInitialized'](),_0x58575d['filtersNodes']()),_0x565b09=new Te(_0x4763d6,_0x20d28f['isFullyInitialized'](),_0x34dfd9['filtersNodes']());this['viewCache_']=Un(_0x565b09,_0xd22263),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0xad4230){return _0xad4230['viewCache_']['serverCache']['getNode']();}function Lu(_0x4ab168){return wn(_0x4ab168['viewCache_']);}function xu(_0x349a6b,_0x3283e5){const _0x26f711=Ve(_0x349a6b['viewCache_']);return _0x26f711&&(_0x349a6b['query']['_queryParams']['loadsAllData']()||!v(_0x3283e5)&&!_0x26f711['getImmediateChild'](y(_0x3283e5))['isEmpty']())?_0x26f711['getChild'](_0x3283e5):null;}function ur(_0x246b7c){return _0x246b7c['eventRegistrations_']['length']===0x0;}function Fu(_0x53852b,_0x467c9e){_0x53852b['eventRegistrations_']['push'](_0x467c9e);}function dr(_0x26f6e5,_0x448d6a,_0x2ece18){const _0x22e6c1=[];if(_0x2ece18){f(_0x448d6a==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x567b3c=_0x26f6e5['query']['_path'];_0x26f6e5['eventRegistrations_']['forEach'](_0x20aa7c=>{const _0x39c35d=_0x20aa7c['createCancelEvent'](_0x2ece18,_0x567b3c);_0x39c35d&&_0x22e6c1['push'](_0x39c35d);});}if(_0x448d6a){let _0x4d4e7f=[];for(let _0xf87339=0x0;_0xf87339<_0x26f6e5['eventRegistrations_']['length'];++_0xf87339){const _0x9851d7=_0x26f6e5['eventRegistrations_'][_0xf87339];if(!_0x9851d7['matches'](_0x448d6a))_0x4d4e7f['push'](_0x9851d7);else{if(_0x448d6a['hasAnyCallback']()){_0x4d4e7f=_0x4d4e7f['concat'](_0x26f6e5['eventRegistrations_']['slice'](_0xf87339+0x1));break;}}}_0x26f6e5['eventRegistrations_']=_0x4d4e7f;}else _0x26f6e5['eventRegistrations_']=[];return _0x22e6c1;}function fr(_0x2408f3,_0x3109cf,_0x31e1ff,_0x1a5d89){_0x3109cf['type']===z['MERGE']&&_0x3109cf['source']['queryId']!==null&&(f(Ve(_0x2408f3['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x2408f3['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x5e0b73=_0x2408f3['viewCache_'],_0x3345e0=Ru(_0x2408f3['processor_'],_0x5e0b73,_0x3109cf,_0x31e1ff,_0x1a5d89);return bu(_0x2408f3['processor_'],_0x3345e0['viewCache']),f(_0x3345e0['viewCache']['serverCache']['isFullyInitialized']()||!_0x5e0b73['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x2408f3['viewCache_']=_0x3345e0['viewCache'],qo(_0x2408f3,_0x3345e0['changes'],_0x3345e0['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x536055,_0xf4cc63){const _0x5dcf37=_0x536055['viewCache_']['eventCache'],_0x13bd67=[];return _0x5dcf37['getNode']()['isLeafNode']()||_0x5dcf37['getNode']()['forEachChild'](R,(_0x422088,_0x2dc0c9)=>{_0x13bd67['push'](rt(_0x422088,_0x2dc0c9));}),_0x5dcf37['isFullyInitialized']()&&_0x13bd67['push'](Lo(_0x5dcf37['getNode']())),qo(_0x536055,_0x13bd67,_0x5dcf37['getNode'](),_0xf4cc63);}function qo(_0x5ea85f,_0x2ce315,_0x510088,_0x1f76e5){const _0x20f4cc=_0x1f76e5?[_0x1f76e5]:_0x5ea85f['eventRegistrations_'];return ru(_0x5ea85f['eventGenerator_'],_0x2ce315,_0x510088,_0x20f4cc);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x10e01a){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x10e01a;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x1149da){return _0x1149da['views']['size']===0x0;}function os(_0x4d9c76,_0x34c12c,_0x4eb947,_0x19f060){const _0x48e055=_0x34c12c['source']['queryId'];if(_0x48e055!==null){const _0x33498f=_0x4d9c76['views']['get'](_0x48e055);return f(_0x33498f!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x33498f,_0x34c12c,_0x4eb947,_0x19f060);}else{let _0x2fb4a8=[];for(const _0x3caeb6 of _0x4d9c76['views']['values']())_0x2fb4a8=_0x2fb4a8['concat'](fr(_0x3caeb6,_0x34c12c,_0x4eb947,_0x19f060));return _0x2fb4a8;}}function jo(_0x4f9e84,_0x2f224d,_0x36c0d8,_0x219648,_0x44364d){const _0x15409a=_0x2f224d['_queryIdentifier'],_0x5d36f3=_0x4f9e84['views']['get'](_0x15409a);if(!_0x5d36f3){let _0x31d013=Cn(_0x36c0d8,_0x44364d?_0x219648:null),_0x40ba02=!0x1;_0x31d013?_0x40ba02=!0x0:_0x219648 instanceof g?(_0x31d013=is(_0x36c0d8,_0x219648),_0x40ba02=!0x1):(_0x31d013=g['EMPTY_NODE'],_0x40ba02=!0x1);const _0x1c5467=Un(new Te(_0x31d013,_0x40ba02,!0x1),new Te(_0x219648,_0x44364d,!0x1));return new Du(_0x2f224d,_0x1c5467);}return _0x5d36f3;}function Hu(_0x111186,_0x38d4cc,_0x5eecf9,_0x4da84d,_0x5f4889,_0x42fce7){const _0x396a23=jo(_0x111186,_0x38d4cc,_0x4da84d,_0x5f4889,_0x42fce7);return _0x111186['views']['has'](_0x38d4cc['_queryIdentifier'])||_0x111186['views']['set'](_0x38d4cc['_queryIdentifier'],_0x396a23),Fu(_0x396a23,_0x5eecf9),Uu(_0x396a23,_0x5eecf9);}function $u(_0x4ac656,_0x4ac89e,_0x231836,_0x59e838){const _0xcf619d=_0x4ac89e['_queryIdentifier'],_0x2129a0=[];let _0x13fd01=[];const _0x165ba4=Se(_0x4ac656);if(_0xcf619d==='default'){for(const [_0x34969e,_0x3709ba]of _0x4ac656['views']['entries']())_0x13fd01=_0x13fd01['concat'](dr(_0x3709ba,_0x231836,_0x59e838)),ur(_0x3709ba)&&(_0x4ac656['views']['delete'](_0x34969e),_0x3709ba['query']['_queryParams']['loadsAllData']()||_0x2129a0['push'](_0x3709ba['query']));}else{const _0x5e79aa=_0x4ac656['views']['get'](_0xcf619d);_0x5e79aa&&(_0x13fd01=_0x13fd01['concat'](dr(_0x5e79aa,_0x231836,_0x59e838)),ur(_0x5e79aa)&&(_0x4ac656['views']['delete'](_0xcf619d),_0x5e79aa['query']['_queryParams']['loadsAllData']()||_0x2129a0['push'](_0x5e79aa['query'])));}return _0x165ba4&&!Se(_0x4ac656)&&_0x2129a0['push'](new(Bu())(_0x4ac89e['_repo'],_0x4ac89e['_path'])),{'removed':_0x2129a0,'events':_0x13fd01};}function Ko(_0xae3c64){const _0x405092=[];for(const _0x223f08 of _0xae3c64['views']['values']())_0x223f08['query']['_queryParams']['loadsAllData']()||_0x405092['push'](_0x223f08);return _0x405092;}function Ie(_0x43af55,_0x27436b){let _0x4552c4=null;for(const _0x3966d5 of _0x43af55['views']['values']())_0x4552c4=_0x4552c4||xu(_0x3966d5,_0x27436b);return _0x4552c4;}function Yo(_0x53d4bf,_0x56a902){if(_0x56a902['_queryParams']['loadsAllData']())return Bn(_0x53d4bf);{const _0x5d6230=_0x56a902['_queryIdentifier'];return _0x53d4bf['views']['get'](_0x5d6230);}}function Qo(_0x3eee65,_0x4a7c6b){return Yo(_0x3eee65,_0x4a7c6b)!=null;}function Se(_0x1d63e4){return Bn(_0x1d63e4)!=null;}function Bn(_0x480831){for(const _0xe231f5 of _0x480831['views']['values']())if(_0xe231f5['query']['_queryParams']['loadsAllData']())return _0xe231f5;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x1a783e){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x1a783e;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x1276d5){this['listenProvider_']=_0x1276d5,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x46b869,_0x1a8196,_0x10c0aa,_0x2cdd38,_0x161486){return lu(_0x46b869['pendingWriteTree_'],_0x1a8196,_0x10c0aa,_0x2cdd38,_0x161486),_0x161486?_t(_0x46b869,new Be(es(),_0x1a8196,_0x10c0aa)):[];}function ju(_0xd06431,_0x21f5eb,_0x252fec,_0x3b2db4){hu(_0xd06431['pendingWriteTree_'],_0x21f5eb,_0x252fec,_0x3b2db4);const _0x53bb39=b['fromObject'](_0x252fec);return _t(_0xd06431,new ot(es(),_0x21f5eb,_0x53bb39));}function _e(_0x312d0d,_0x22e861,_0x1c94e2=!0x1){const _0x135738=uu(_0x312d0d['pendingWriteTree_'],_0x22e861);if(du(_0x312d0d['pendingWriteTree_'],_0x22e861)){let _0x5976dd=new b(null);return _0x135738['snap']!=null?_0x5976dd=_0x5976dd['set'](w(),!0x0):x(_0x135738['children'],_0x4a23ff=>{_0x5976dd=_0x5976dd['set'](new C(_0x4a23ff),!0x0);}),_t(_0x312d0d,new In(_0x135738['path'],_0x5976dd,_0x1c94e2));}else return[];}function Yt(_0x56769a,_0x31a8d4,_0x4e33e5){return _t(_0x56769a,new Be(ts(),_0x31a8d4,_0x4e33e5));}function Ku(_0x357baa,_0x16cddd,_0x56df40){const _0x329e9f=b['fromObject'](_0x56df40);return _t(_0x357baa,new ot(ts(),_0x16cddd,_0x329e9f));}function Yu(_0x268d1c,_0x227dac){return _t(_0x268d1c,new Ut(ts(),_0x227dac));}function Qu(_0x2bc2fe,_0x335ead,_0x3abb5a){const _0x31d381=cs(_0x2bc2fe,_0x3abb5a);if(_0x31d381){const _0x42e4d4=ls(_0x31d381),_0x520000=_0x42e4d4['path'],_0x1d4e86=_0x42e4d4['queryId'],_0x10efbe=F(_0x520000,_0x335ead),_0x1f0dde=new Ut(ns(_0x1d4e86),_0x10efbe);return hs(_0x2bc2fe,_0x520000,_0x1f0dde);}else return[];}function An(_0x2c6c77,_0x3061ea,_0x8c7c5a,_0x169de8,_0x1a517c=!0x1){const _0x596226=_0x3061ea['_path'],_0x180bd1=_0x2c6c77['syncPointTree_']['get'](_0x596226);let _0x37efbf=[];if(_0x180bd1&&(_0x3061ea['_queryIdentifier']==='default'||Qo(_0x180bd1,_0x3061ea))){const _0x176b76=$u(_0x180bd1,_0x3061ea,_0x8c7c5a,_0x169de8);Vu(_0x180bd1)&&(_0x2c6c77['syncPointTree_']=_0x2c6c77['syncPointTree_']['remove'](_0x596226));const _0x3634c8=_0x176b76['removed'];if(_0x37efbf=_0x176b76['events'],!_0x1a517c){const _0x27f735=_0x3634c8['findIndex'](_0x55305f=>_0x55305f['_queryParams']['loadsAllData']())!==-0x1,_0x3864fa=_0x2c6c77['syncPointTree_']['findOnPath'](_0x596226,(_0x5ca608,_0x136e2e)=>Se(_0x136e2e));if(_0x27f735&&!_0x3864fa){const _0x23fbb9=_0x2c6c77['syncPointTree_']['subtree'](_0x596226);if(!_0x23fbb9['isEmpty']()){const _0xccdafe=Zu(_0x23fbb9);for(let _0xe8253e=0x0;_0xe8253e<_0xccdafe['length'];++_0xe8253e){const _0x4d0d7c=_0xccdafe[_0xe8253e],_0x241528=_0x4d0d7c['query'],_0x2409d7=ea(_0x2c6c77,_0x4d0d7c);_0x2c6c77['listenProvider_']['startListening'](kt(_0x241528),Wt(_0x2c6c77,_0x241528),_0x2409d7['hashFn'],_0x2409d7['onComplete']);}}}!_0x3864fa&&_0x3634c8['length']>0x0&&!_0x169de8&&(_0x27f735?_0x2c6c77['listenProvider_']['stopListening'](kt(_0x3061ea),null):_0x3634c8['forEach'](_0x9eee80=>{const _0x5a62ff=_0x2c6c77['queryToTagMap']['get'](Hn(_0x9eee80));_0x2c6c77['listenProvider_']['stopListening'](kt(_0x9eee80),_0x5a62ff);}));}ed(_0x2c6c77,_0x3634c8);}return _0x37efbf;}function Jo(_0x1583f1,_0x2b2113,_0x377089,_0x10ae0f){const _0x120dba=cs(_0x1583f1,_0x10ae0f);if(_0x120dba!=null){const _0x4264f5=ls(_0x120dba),_0x468638=_0x4264f5['path'],_0x846ae=_0x4264f5['queryId'],_0x3faa8f=F(_0x468638,_0x2b2113),_0x575aff=new Be(ns(_0x846ae),_0x3faa8f,_0x377089);return hs(_0x1583f1,_0x468638,_0x575aff);}else return[];}function Ju(_0x324db8,_0x23cd43,_0x57f01c,_0x2a586b){const _0x604fa3=cs(_0x324db8,_0x2a586b);if(_0x604fa3){const _0x5c364d=ls(_0x604fa3),_0x54f9df=_0x5c364d['path'],_0x4f6d16=_0x5c364d['queryId'],_0x94652f=F(_0x54f9df,_0x23cd43),_0xf2fbcb=b['fromObject'](_0x57f01c),_0x302ef4=new ot(ns(_0x4f6d16),_0x94652f,_0xf2fbcb);return hs(_0x324db8,_0x54f9df,_0x302ef4);}else return[];}function Ni(_0x2b3edf,_0x5f34c4,_0x1bdbfe,_0x227fbb=!0x1){const _0x399afe=_0x5f34c4['_path'];let _0x3561ce=null,_0x15721c=!0x1;_0x2b3edf['syncPointTree_']['foreachOnPath'](_0x399afe,(_0x4a68fd,_0x5f5204)=>{const _0x45356f=F(_0x4a68fd,_0x399afe);_0x3561ce=_0x3561ce||Ie(_0x5f5204,_0x45356f),_0x15721c=_0x15721c||Se(_0x5f5204);});let _0x476033=_0x2b3edf['syncPointTree_']['get'](_0x399afe);_0x476033?(_0x15721c=_0x15721c||Se(_0x476033),_0x3561ce=_0x3561ce||Ie(_0x476033,w())):(_0x476033=new zo(),_0x2b3edf['syncPointTree_']=_0x2b3edf['syncPointTree_']['set'](_0x399afe,_0x476033));let _0x2968b9;_0x3561ce!=null?_0x2968b9=!0x0:(_0x2968b9=!0x1,_0x3561ce=g['EMPTY_NODE'],_0x2b3edf['syncPointTree_']['subtree'](_0x399afe)['foreachChild']((_0x1f72e0,_0x58d73e)=>{const _0x5e1d8f=Ie(_0x58d73e,w());_0x5e1d8f&&(_0x3561ce=_0x3561ce['updateImmediateChild'](_0x1f72e0,_0x5e1d8f));}));const _0x42deee=Qo(_0x476033,_0x5f34c4);if(!_0x42deee&&!_0x5f34c4['_queryParams']['loadsAllData']()){const _0x56b14e=Hn(_0x5f34c4);f(!_0x2b3edf['queryToTagMap']['has'](_0x56b14e),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x46ce28=td();_0x2b3edf['queryToTagMap']['set'](_0x56b14e,_0x46ce28),_0x2b3edf['tagToQueryMap']['set'](_0x46ce28,_0x56b14e);}const _0x46b535=Wn(_0x2b3edf['pendingWriteTree_'],_0x399afe);let _0x1e4ad2=Hu(_0x476033,_0x5f34c4,_0x1bdbfe,_0x46b535,_0x3561ce,_0x2968b9);if(!_0x42deee&&!_0x15721c&&!_0x227fbb){const _0x291f61=Yo(_0x476033,_0x5f34c4);_0x1e4ad2=_0x1e4ad2['concat'](nd(_0x2b3edf,_0x5f34c4,_0x291f61));}return _0x1e4ad2;}function Vn(_0xa4dc4a,_0x5db921,_0x53c2b0){const _0x229848=_0xa4dc4a['pendingWriteTree_'],_0x10204d=_0xa4dc4a['syncPointTree_']['findOnPath'](_0x5db921,(_0x50abca,_0x21d770)=>{const _0x5ae96c=F(_0x50abca,_0x5db921),_0x35a701=Ie(_0x21d770,_0x5ae96c);if(_0x35a701)return _0x35a701;});return Bo(_0x229848,_0x5db921,_0x10204d,_0x53c2b0,!0x0);}function Xu(_0x454bfd,_0x478043){const _0x59a6a2=_0x478043['_path'];let _0x357e71=null;_0x454bfd['syncPointTree_']['foreachOnPath'](_0x59a6a2,(_0x33f197,_0x157201)=>{const _0x1ba580=F(_0x33f197,_0x59a6a2);_0x357e71=_0x357e71||Ie(_0x157201,_0x1ba580);});let _0x14c51a=_0x454bfd['syncPointTree_']['get'](_0x59a6a2);_0x14c51a?_0x357e71=_0x357e71||Ie(_0x14c51a,w()):(_0x14c51a=new zo(),_0x454bfd['syncPointTree_']=_0x454bfd['syncPointTree_']['set'](_0x59a6a2,_0x14c51a));const _0x331df1=_0x357e71!=null,_0x3b0d38=_0x331df1?new Te(_0x357e71,!0x0,!0x1):null,_0x424c54=Wn(_0x454bfd['pendingWriteTree_'],_0x478043['_path']),_0x52e8d6=jo(_0x14c51a,_0x478043,_0x424c54,_0x331df1?_0x3b0d38['getNode']():g['EMPTY_NODE'],_0x331df1);return Lu(_0x52e8d6);}function _t(_0x533ba0,_0x19b6b9){return Xo(_0x19b6b9,_0x533ba0['syncPointTree_'],null,Wn(_0x533ba0['pendingWriteTree_'],w()));}function Xo(_0x288ee0,_0x1144d1,_0x18c62b,_0x49347f){if(v(_0x288ee0['path']))return Zo(_0x288ee0,_0x1144d1,_0x18c62b,_0x49347f);{const _0x121804=_0x1144d1['get'](w());_0x18c62b==null&&_0x121804!=null&&(_0x18c62b=Ie(_0x121804,w()));let _0x3c0691=[];const _0x4b8fa6=y(_0x288ee0['path']),_0x336f67=_0x288ee0['operationForChild'](_0x4b8fa6),_0x3a8403=_0x1144d1['children']['get'](_0x4b8fa6);if(_0x3a8403&&_0x336f67){const _0x15a240=_0x18c62b?_0x18c62b['getImmediateChild'](_0x4b8fa6):null,_0x1c5205=Vo(_0x49347f,_0x4b8fa6);_0x3c0691=_0x3c0691['concat'](Xo(_0x336f67,_0x3a8403,_0x15a240,_0x1c5205));}return _0x121804&&(_0x3c0691=_0x3c0691['concat'](os(_0x121804,_0x288ee0,_0x49347f,_0x18c62b))),_0x3c0691;}}function Zo(_0x4c3878,_0x26dc72,_0x28339c,_0x3f7f2f){const _0x42ddc8=_0x26dc72['get'](w());_0x28339c==null&&_0x42ddc8!=null&&(_0x28339c=Ie(_0x42ddc8,w()));let _0x443689=[];return _0x26dc72['children']['inorderTraversal']((_0x27b41e,_0x2dcceb)=>{const _0x22ad28=_0x28339c?_0x28339c['getImmediateChild'](_0x27b41e):null,_0x5b4fef=Vo(_0x3f7f2f,_0x27b41e),_0x49c66a=_0x4c3878['operationForChild'](_0x27b41e);_0x49c66a&&(_0x443689=_0x443689['concat'](Zo(_0x49c66a,_0x2dcceb,_0x22ad28,_0x5b4fef)));}),_0x42ddc8&&(_0x443689=_0x443689['concat'](os(_0x42ddc8,_0x4c3878,_0x3f7f2f,_0x28339c))),_0x443689;}function ea(_0x563cf0,_0x3566a9){const _0x3bbe66=_0x3566a9['query'],_0x35f323=Wt(_0x563cf0,_0x3bbe66);return{'hashFn':()=>(Mu(_0x3566a9)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x5a83e9=>{if(_0x5a83e9==='ok')return _0x35f323?Qu(_0x563cf0,_0x3bbe66['_path'],_0x35f323):Yu(_0x563cf0,_0x3bbe66['_path']);{const _0x278102=Kl(_0x5a83e9,_0x3bbe66);return An(_0x563cf0,_0x3bbe66,null,_0x278102);}}};}function Wt(_0x23e264,_0x4e65c3){const _0x483830=Hn(_0x4e65c3);return _0x23e264['queryToTagMap']['get'](_0x483830);}function Hn(_0x58c0c0){return _0x58c0c0['_path']['toString']()+'$'+_0x58c0c0['_queryIdentifier'];}function cs(_0x3dc2bb,_0x16bf54){return _0x3dc2bb['tagToQueryMap']['get'](_0x16bf54);}function ls(_0x15d677){const _0x5840f5=_0x15d677['indexOf']('$');return f(_0x5840f5!==-0x1&&_0x5840f5<_0x15d677['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x15d677['substr'](_0x5840f5+0x1),'path':new C(_0x15d677['substr'](0x0,_0x5840f5))};}function hs(_0x1be26b,_0x330176,_0x604296){const _0x8afc2d=_0x1be26b['syncPointTree_']['get'](_0x330176);f(_0x8afc2d,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x42759c=Wn(_0x1be26b['pendingWriteTree_'],_0x330176);return os(_0x8afc2d,_0x604296,_0x42759c,null);}function Zu(_0x1436b6){return _0x1436b6['fold']((_0x5b3360,_0xedbada,_0xc7e800)=>{if(_0xedbada&&Se(_0xedbada))return[Bn(_0xedbada)];{let _0x4058a6=[];return _0xedbada&&(_0x4058a6=Ko(_0xedbada)),x(_0xc7e800,(_0x435337,_0x11b24e)=>{_0x4058a6=_0x4058a6['concat'](_0x11b24e);}),_0x4058a6;}});}function kt(_0x586373){return _0x586373['_queryParams']['loadsAllData']()&&!_0x586373['_queryParams']['isDefault']()?new(qu())(_0x586373['_repo'],_0x586373['_path']):_0x586373;}function ed(_0x52f136,_0x121fca){for(let _0x506cc2=0x0;_0x506cc2<_0x121fca['length'];++_0x506cc2){const _0x3fa5f8=_0x121fca[_0x506cc2];if(!_0x3fa5f8['_queryParams']['loadsAllData']()){const _0x9d48ae=Hn(_0x3fa5f8),_0x48b9eb=_0x52f136['queryToTagMap']['get'](_0x9d48ae);_0x52f136['queryToTagMap']['delete'](_0x9d48ae),_0x52f136['tagToQueryMap']['delete'](_0x48b9eb);}}}function td(){return zu++;}function nd(_0x1a76a9,_0x2e2312,_0x2b5da3){const _0x11dd42=_0x2e2312['_path'],_0x104747=Wt(_0x1a76a9,_0x2e2312),_0x2dccf3=ea(_0x1a76a9,_0x2b5da3),_0x483502=_0x1a76a9['listenProvider_']['startListening'](kt(_0x2e2312),_0x104747,_0x2dccf3['hashFn'],_0x2dccf3['onComplete']),_0x593ee0=_0x1a76a9['syncPointTree_']['subtree'](_0x11dd42);if(_0x104747)f(!Se(_0x593ee0['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x302883=_0x593ee0['fold']((_0x386c60,_0x362cb9,_0x357bf6)=>{if(!v(_0x386c60)&&_0x362cb9&&Se(_0x362cb9))return[Bn(_0x362cb9)['query']];{let _0x306601=[];return _0x362cb9&&(_0x306601=_0x306601['concat'](Ko(_0x362cb9)['map'](_0x48c7b0=>_0x48c7b0['query']))),x(_0x357bf6,(_0x326e55,_0x53a719)=>{_0x306601=_0x306601['concat'](_0x53a719);}),_0x306601;}});for(let _0xff6a68=0x0;_0xff6a68<_0x302883['length'];++_0xff6a68){const _0x30a032=_0x302883[_0xff6a68];_0x1a76a9['listenProvider_']['stopListening'](kt(_0x30a032),Wt(_0x1a76a9,_0x30a032));}}return _0x483502;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x46082d){this['node_']=_0x46082d;}['getImmediateChild'](_0x154af1){const _0x1e18d5=this['node_']['getImmediateChild'](_0x154af1);return new us(_0x1e18d5);}['node'](){return this['node_'];}}class ds{constructor(_0x29f315,_0x48533f){this['syncTree_']=_0x29f315,this['path_']=_0x48533f;}['getImmediateChild'](_0x3a6180){const _0x473302=k(this['path_'],_0x3a6180);return new ds(this['syncTree_'],_0x473302);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x4e8a18){return _0x4e8a18=_0x4e8a18||{},_0x4e8a18['timestamp']=_0x4e8a18['timestamp']||new Date()['getTime'](),_0x4e8a18;},_r=function(_0x492241,_0x15e925,_0x225dce){if(!_0x492241||typeof _0x492241!='object')return _0x492241;if(f('.sv'in _0x492241,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x492241['.sv']=='string')return sd(_0x492241['.sv'],_0x15e925,_0x225dce);if(typeof _0x492241['.sv']=='object')return rd(_0x492241['.sv'],_0x15e925);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x492241,null,0x2));},sd=function(_0x2f97fc,_0xdaff3,_0x4b7a17){switch(_0x2f97fc){case'timestamp':return _0x4b7a17['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x2f97fc);}},rd=function(_0x2e7fe0,_0x37e3bb,_0x4a57f4){_0x2e7fe0['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x2e7fe0,null,0x2));const _0x58c3d6=_0x2e7fe0['increment'];typeof _0x58c3d6!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x58c3d6);const _0x135ee7=_0x37e3bb['node']();if(f(_0x135ee7!==null&&typeof _0x135ee7<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x135ee7['isLeafNode']())return _0x58c3d6;const _0x9e40f4=_0x135ee7['getValue']();return typeof _0x9e40f4!='number'?_0x58c3d6:_0x9e40f4+_0x58c3d6;},ta=function(_0x532afb,_0x96e45c,_0xf2c434,_0x538eb6){return ps(_0x96e45c,new ds(_0xf2c434,_0x532afb),_0x538eb6);},fs=function(_0x1423b8,_0x33bea8,_0x31dd18){return ps(_0x1423b8,new us(_0x33bea8),_0x31dd18);};function ps(_0x1bc08c,_0x4ffeef,_0xe76e23){const _0x2d39db=_0x1bc08c['getPriority']()['val'](),_0x46d7e6=_r(_0x2d39db,_0x4ffeef['getImmediateChild']('.priority'),_0xe76e23);let _0x2eca49;if(_0x1bc08c['isLeafNode']()){const _0x4415ac=_0x1bc08c,_0x2f4961=_r(_0x4415ac['getValue'](),_0x4ffeef,_0xe76e23);return _0x2f4961!==_0x4415ac['getValue']()||_0x46d7e6!==_0x4415ac['getPriority']()['val']()?new D(_0x2f4961,A(_0x46d7e6)):_0x1bc08c;}else{const _0x44577a=_0x1bc08c;return _0x2eca49=_0x44577a,_0x46d7e6!==_0x44577a['getPriority']()['val']()&&(_0x2eca49=_0x2eca49['updatePriority'](new D(_0x46d7e6))),_0x44577a['forEachChild'](R,(_0x433f39,_0x5c3649)=>{const _0x29ee26=ps(_0x5c3649,_0x4ffeef['getImmediateChild'](_0x433f39),_0xe76e23);_0x29ee26!==_0x5c3649&&(_0x2eca49=_0x2eca49['updateImmediateChild'](_0x433f39,_0x29ee26));}),_0x2eca49;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x388bfd='',_0x405e4a=null,_0x19c08e={'children':{},'childCount':0x0}){this['name']=_0x388bfd,this['parent']=_0x405e4a,this['node']=_0x19c08e;}}function $n(_0x3211a4,_0x5037d1){let _0x4eeba5=_0x5037d1 instanceof C?_0x5037d1:new C(_0x5037d1),_0xd7e19a=_0x3211a4,_0x85b6a7=y(_0x4eeba5);for(;_0x85b6a7!==null;){const _0x4020f4=Le(_0xd7e19a['node']['children'],_0x85b6a7)||{'children':{},'childCount':0x0};_0xd7e19a=new _s(_0x85b6a7,_0xd7e19a,_0x4020f4),_0x4eeba5=S(_0x4eeba5),_0x85b6a7=y(_0x4eeba5);}return _0xd7e19a;}function je(_0x3f16c5){return _0x3f16c5['node']['value'];}function gs(_0x4bd26a,_0x4c68f9){_0x4bd26a['node']['value']=_0x4c68f9,Oi(_0x4bd26a);}function na(_0xb9e0a8){return _0xb9e0a8['node']['childCount']>0x0;}function od(_0x21374f){return je(_0x21374f)===void 0x0&&!na(_0x21374f);}function Gn(_0x39e365,_0x297dc7){x(_0x39e365['node']['children'],(_0x10fd84,_0x1a12c5)=>{_0x297dc7(new _s(_0x10fd84,_0x39e365,_0x1a12c5));});}function ia(_0x1f6135,_0xe1af92,_0x16c0d1,_0x4ffb12){_0x16c0d1&&_0xe1af92(_0x1f6135),Gn(_0x1f6135,_0x330f4e=>{ia(_0x330f4e,_0xe1af92,!0x0);});}function ad(_0x3b28d7,_0x18690e,_0x3dfdca){let _0x382f79=_0x3b28d7['parent'];for(;_0x382f79!==null;){if(_0x18690e(_0x382f79))return!0x0;_0x382f79=_0x382f79['parent'];}return!0x1;}function Qt(_0x4aa711){return new C(_0x4aa711['parent']===null?_0x4aa711['name']:Qt(_0x4aa711['parent'])+'/'+_0x4aa711['name']);}function Oi(_0x3135e2){_0x3135e2['parent']!==null&&cd(_0x3135e2['parent'],_0x3135e2['name'],_0x3135e2);}function cd(_0x4670de,_0x3c5e26,_0x548cd4){const _0x5438f9=od(_0x548cd4),_0x2c3a20=Q(_0x4670de['node']['children'],_0x3c5e26);_0x5438f9&&_0x2c3a20?(delete _0x4670de['node']['children'][_0x3c5e26],_0x4670de['node']['childCount']--,Oi(_0x4670de)):!_0x5438f9&&!_0x2c3a20&&(_0x4670de['node']['children'][_0x3c5e26]=_0x548cd4['node'],_0x4670de['node']['childCount']++,Oi(_0x4670de));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x3fe678){return typeof _0x3fe678=='string'&&_0x3fe678['length']!==0x0&&!ld['test'](_0x3fe678);},sa=function(_0x4a4213){return typeof _0x4a4213=='string'&&_0x4a4213['length']!==0x0&&!hd['test'](_0x4a4213);},ud=function(_0x3302d7){return _0x3302d7&&(_0x3302d7=_0x3302d7['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x3302d7);},Bt=function(_0x294bcf){return _0x294bcf===null||typeof _0x294bcf=='string'||typeof _0x294bcf=='number'&&!xn(_0x294bcf)||_0x294bcf&&typeof _0x294bcf=='object'&&Q(_0x294bcf,'.sv');},He=function(_0x1608f6,_0xfc1ed7,_0x386c65,_0x28564a){_0x28564a&&_0xfc1ed7===void 0x0||Jt(it(_0x1608f6,'value'),_0xfc1ed7,_0x386c65);},Jt=function(_0x456a7a,_0x531c7e,_0x581edf){const _0x38e570=_0x581edf instanceof C?new Ah(_0x581edf,_0x456a7a):_0x581edf;if(_0x531c7e===void 0x0)throw new Error(_0x456a7a+'contains\x20undefined\x20'+Oe(_0x38e570));if(typeof _0x531c7e=='function')throw new Error(_0x456a7a+'contains\x20a\x20function\x20'+Oe(_0x38e570)+'\x20with\x20contents\x20=\x20'+_0x531c7e['toString']());if(xn(_0x531c7e))throw new Error(_0x456a7a+'contains\x20'+_0x531c7e['toString']()+'\x20'+Oe(_0x38e570));if(typeof _0x531c7e=='string'&&_0x531c7e['length']>ui/0x3&&Ln(_0x531c7e)>ui)throw new Error(_0x456a7a+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x38e570)+'\x20(\x27'+_0x531c7e['substring'](0x0,0x32)+'...\x27)');if(_0x531c7e&&typeof _0x531c7e=='object'){let _0x31fc2a=!0x1,_0x144997=!0x1;if(x(_0x531c7e,(_0x3be046,_0x43e30b)=>{if(_0x3be046==='.value')_0x31fc2a=!0x0;else{if(_0x3be046!=='.priority'&&_0x3be046!=='.sv'&&(_0x144997=!0x0,!ms(_0x3be046)))throw new Error(_0x456a7a+'\x20contains\x20an\x20invalid\x20key\x20('+_0x3be046+')\x20'+Oe(_0x38e570)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x38e570,_0x3be046),Jt(_0x456a7a,_0x43e30b,_0x38e570),Ph(_0x38e570);}),_0x31fc2a&&_0x144997)throw new Error(_0x456a7a+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x38e570)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0xe79d40,_0x4c5f8d){let _0x7f0a83,_0x1350ed;for(_0x7f0a83=0x0;_0x7f0a83<_0x4c5f8d['length'];_0x7f0a83++){_0x1350ed=_0x4c5f8d[_0x7f0a83];const _0x2a29ec=Mt(_0x1350ed);for(let _0x190d16=0x0;_0x190d16<_0x2a29ec['length'];_0x190d16++)if(!(_0x2a29ec[_0x190d16]==='.priority'&&_0x190d16===_0x2a29ec['length']-0x1)){if(!ms(_0x2a29ec[_0x190d16]))throw new Error(_0xe79d40+'contains\x20an\x20invalid\x20key\x20('+_0x2a29ec[_0x190d16]+')\x20in\x20path\x20'+_0x1350ed['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x4c5f8d['sort'](Rh);let _0x1d842e=null;for(_0x7f0a83=0x0;_0x7f0a83<_0x4c5f8d['length'];_0x7f0a83++){if(_0x1350ed=_0x4c5f8d[_0x7f0a83],_0x1d842e!==null&&G(_0x1d842e,_0x1350ed))throw new Error(_0xe79d40+'contains\x20a\x20path\x20'+_0x1d842e['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x1350ed['toString']());_0x1d842e=_0x1350ed;}},ra=function(_0x2bab18,_0x2f0a05,_0x2d5215,_0x49af47){const _0x290d81=it(_0x2bab18,'values');if(!(_0x2f0a05&&typeof _0x2f0a05=='object')||Array['isArray'](_0x2f0a05))throw new Error(_0x290d81+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x6c6306=[];x(_0x2f0a05,(_0x2a1773,_0x5d2bef)=>{const _0x4fcb1f=new C(_0x2a1773);if(Jt(_0x290d81,_0x5d2bef,k(_0x2d5215,_0x4fcb1f)),ji(_0x4fcb1f)==='.priority'&&!Bt(_0x5d2bef))throw new Error(_0x290d81+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x4fcb1f['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x6c6306['push'](_0x4fcb1f);}),dd(_0x290d81,_0x6c6306);},fd=function(_0x21a989,_0x4270c4,_0x1cd974){if(xn(_0x4270c4))throw new Error(it(_0x21a989,'priority')+'is\x20'+_0x4270c4['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x4270c4))throw new Error(it(_0x21a989,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x285a30,_0x361dbe,_0x28a717,_0xb2dc3c){if(!sa(_0x28a717))throw new Error(it(_0x285a30,_0x361dbe)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x28a717+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x4fe35d,_0x34c596,_0x5eb442,_0x351c24){_0x5eb442&&(_0x5eb442=_0x5eb442['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x4fe35d,_0x34c596,_0x5eb442);},Me=function(_0x5ad445,_0x47df1b){if(y(_0x47df1b)==='.info')throw new Error(_0x5ad445+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x37f04a,_0xc64d62){const _0x658ee4=_0xc64d62['path']['toString']();if(typeof _0xc64d62['repoInfo']['host']!='string'||_0xc64d62['repoInfo']['host']['length']===0x0||!ms(_0xc64d62['repoInfo']['namespace'])&&_0xc64d62['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x658ee4['length']!==0x0&&!ud(_0x658ee4))throw new Error(it(_0x37f04a,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x551574,_0x56253f){let _0xd1f1b=null;for(let _0x88ec9f=0x0;_0x88ec9f<_0x56253f['length'];_0x88ec9f++){const _0x442bc5=_0x56253f[_0x88ec9f],_0x375c82=_0x442bc5['getPath']();_0xd1f1b!==null&&!Ki(_0x375c82,_0xd1f1b['path'])&&(_0x551574['eventLists_']['push'](_0xd1f1b),_0xd1f1b=null),_0xd1f1b===null&&(_0xd1f1b={'events':[],'path':_0x375c82}),_0xd1f1b['events']['push'](_0x442bc5);}_0xd1f1b&&_0x551574['eventLists_']['push'](_0xd1f1b);}function oa(_0xd4a70c,_0x2a5bcb,_0x1f5a22){qn(_0xd4a70c,_0x1f5a22),aa(_0xd4a70c,_0x5ea01e=>Ki(_0x5ea01e,_0x2a5bcb));}function V(_0x4190e1,_0x858ab,_0x4f50dd){qn(_0x4190e1,_0x4f50dd),aa(_0x4190e1,_0x27fba8=>G(_0x27fba8,_0x858ab)||G(_0x858ab,_0x27fba8));}function aa(_0x52990c,_0x3e3e6c){_0x52990c['recursionDepth_']++;let _0x41fde3=!0x0;for(let _0x436dc4=0x0;_0x436dc4<_0x52990c['eventLists_']['length'];_0x436dc4++){const _0x5f325b=_0x52990c['eventLists_'][_0x436dc4];if(_0x5f325b){const _0x3fc805=_0x5f325b['path'];_0x3e3e6c(_0x3fc805)?(md(_0x52990c['eventLists_'][_0x436dc4]),_0x52990c['eventLists_'][_0x436dc4]=null):_0x41fde3=!0x1;}}_0x41fde3&&(_0x52990c['eventLists_']=[]),_0x52990c['recursionDepth_']--;}function md(_0x445546){for(let _0x3730d6=0x0;_0x3730d6<_0x445546['events']['length'];_0x3730d6++){const _0x1851e3=_0x445546['events'][_0x3730d6];if(_0x1851e3!==null){_0x445546['events'][_0x3730d6]=null;const _0xc58260=_0x1851e3['getEventRunner']();St&&L('event:\x20'+_0x1851e3['toString']()),ft(_0xc58260);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x1a8e0e,_0x3d1299,_0x125851,_0x534139){this['repoInfo_']=_0x1a8e0e,this['forceRestClient_']=_0x3d1299,this['authTokenProvider_']=_0x125851,this['appCheckProvider_']=_0x534139,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x3942ab,_0x33a341,_0x4b7b61){if(_0x3942ab['stats_']=qi(_0x3942ab['repoInfo_']),_0x3942ab['forceRestClient_']||Xl())_0x3942ab['server_']=new vn(_0x3942ab['repoInfo_'],(_0x6eaf98,_0x536d46,_0x4ac000,_0x1e20ef)=>{gr(_0x3942ab,_0x6eaf98,_0x536d46,_0x4ac000,_0x1e20ef);},_0x3942ab['authTokenProvider_'],_0x3942ab['appCheckProvider_']),setTimeout(()=>mr(_0x3942ab,!0x0),0x0);else{if(typeof _0x4b7b61<'u'&&_0x4b7b61!==null){if(typeof _0x4b7b61!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x4b7b61);}catch(_0x203a48){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x203a48);}}_0x3942ab['persistentConnection_']=new se(_0x3942ab['repoInfo_'],_0x33a341,(_0x2e9151,_0x3fa93f,_0x2d2641,_0x15fb74)=>{gr(_0x3942ab,_0x2e9151,_0x3fa93f,_0x2d2641,_0x15fb74);},_0x1d3376=>{mr(_0x3942ab,_0x1d3376);},_0x3f0924=>{Id(_0x3942ab,_0x3f0924);},_0x3942ab['authTokenProvider_'],_0x3942ab['appCheckProvider_'],_0x4b7b61),_0x3942ab['server_']=_0x3942ab['persistentConnection_'];}_0x3942ab['authTokenProvider_']['addTokenChangeListener'](_0x3087eb=>{_0x3942ab['server_']['refreshAuthToken'](_0x3087eb);}),_0x3942ab['appCheckProvider_']['addTokenChangeListener'](_0x540b0a=>{_0x3942ab['server_']['refreshAppCheckToken'](_0x540b0a['token']);}),_0x3942ab['statsReporter_']=ih(_0x3942ab['repoInfo_'],()=>new iu(_0x3942ab['stats_'],_0x3942ab['server_'])),_0x3942ab['infoData_']=new Xh(),_0x3942ab['infoSyncTree_']=new pr({'startListening':(_0x31aa4d,_0xf11729,_0x1d74ea,_0x417c9c)=>{let _0x270c7d=[];const _0x1e8ca4=_0x3942ab['infoData_']['getNode'](_0x31aa4d['_path']);return _0x1e8ca4['isEmpty']()||(_0x270c7d=Yt(_0x3942ab['infoSyncTree_'],_0x31aa4d['_path'],_0x1e8ca4),setTimeout(()=>{_0x417c9c('ok');},0x0)),_0x270c7d;},'stopListening':()=>{}}),vs(_0x3942ab,'connected',!0x1),_0x3942ab['serverSyncTree_']=new pr({'startListening':(_0x81099,_0xab314b,_0x2e284f,_0x592985)=>(_0x3942ab['server_']['listen'](_0x81099,_0x2e284f,_0xab314b,(_0x525ab0,_0x2aec9d)=>{const _0x522080=_0x592985(_0x525ab0,_0x2aec9d);V(_0x3942ab['eventQueue_'],_0x81099['_path'],_0x522080);}),[]),'stopListening':(_0xd04b56,_0x23ffb8)=>{_0x3942ab['server_']['unlisten'](_0xd04b56,_0x23ffb8);}});}function la(_0x21187c){const _0x1d0b0e=_0x21187c['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x1d0b0e;}function Xt(_0xdd5ef){return id({'timestamp':la(_0xdd5ef)});}function gr(_0xfda9d8,_0x3be843,_0x5bf023,_0x26e970,_0x5b1c55){_0xfda9d8['dataUpdateCount']++;const _0x142f0e=new C(_0x3be843);_0x5bf023=_0xfda9d8['interceptServerDataCallback_']?_0xfda9d8['interceptServerDataCallback_'](_0x3be843,_0x5bf023):_0x5bf023;let _0xdb7844=[];if(_0x5b1c55){if(_0x26e970){const _0x5f442c=_n(_0x5bf023,_0x6cc34=>A(_0x6cc34));_0xdb7844=Ju(_0xfda9d8['serverSyncTree_'],_0x142f0e,_0x5f442c,_0x5b1c55);}else{const _0x24759b=A(_0x5bf023);_0xdb7844=Jo(_0xfda9d8['serverSyncTree_'],_0x142f0e,_0x24759b,_0x5b1c55);}}else{if(_0x26e970){const _0x54757b=_n(_0x5bf023,_0x3afed2=>A(_0x3afed2));_0xdb7844=Ku(_0xfda9d8['serverSyncTree_'],_0x142f0e,_0x54757b);}else{const _0x7e074f=A(_0x5bf023);_0xdb7844=Yt(_0xfda9d8['serverSyncTree_'],_0x142f0e,_0x7e074f);}}let _0x57d64a=_0x142f0e;_0xdb7844['length']>0x0&&(_0x57d64a=ct(_0xfda9d8,_0x142f0e)),V(_0xfda9d8['eventQueue_'],_0x57d64a,_0xdb7844);}function mr(_0x56dc0e,_0x6b82b8){vs(_0x56dc0e,'connected',_0x6b82b8),_0x6b82b8===!0x1&&Sd(_0x56dc0e);}function Id(_0x56a18c,_0x1bd644){x(_0x1bd644,(_0x58cfef,_0x386cf0)=>{vs(_0x56a18c,_0x58cfef,_0x386cf0);});}function vs(_0x7798a5,_0x435ce,_0x52d9a6){const _0x4f8d1e=new C('/.info/'+_0x435ce),_0x80a010=A(_0x52d9a6);_0x7798a5['infoData_']['updateSnapshot'](_0x4f8d1e,_0x80a010);const _0x20a085=Yt(_0x7798a5['infoSyncTree_'],_0x4f8d1e,_0x80a010);V(_0x7798a5['eventQueue_'],_0x4f8d1e,_0x20a085);}function zn(_0x19bd18){return _0x19bd18['nextWriteId_']++;}function wd(_0x10f0ad,_0x524d0f,_0x19335e){const _0x5f206e=Xu(_0x10f0ad['serverSyncTree_'],_0x524d0f);return _0x5f206e!=null?Promise['resolve'](_0x5f206e):_0x10f0ad['server_']['get'](_0x524d0f)['then'](_0xede129=>{const _0x1cf4f1=A(_0xede129)['withIndex'](_0x524d0f['_queryParams']['getIndex']());Ni(_0x10f0ad['serverSyncTree_'],_0x524d0f,_0x19335e,!0x0);let _0x443516;if(_0x524d0f['_queryParams']['loadsAllData']())_0x443516=Yt(_0x10f0ad['serverSyncTree_'],_0x524d0f['_path'],_0x1cf4f1);else{const _0x457b08=Wt(_0x10f0ad['serverSyncTree_'],_0x524d0f);_0x443516=Jo(_0x10f0ad['serverSyncTree_'],_0x524d0f['_path'],_0x1cf4f1,_0x457b08);}return V(_0x10f0ad['eventQueue_'],_0x524d0f['_path'],_0x443516),An(_0x10f0ad['serverSyncTree_'],_0x524d0f,_0x19335e,null,!0x0),_0x1cf4f1;},_0x148b0d=>(gt(_0x10f0ad,'get\x20for\x20query\x20'+O(_0x524d0f)+'\x20failed:\x20'+_0x148b0d),Promise['reject'](new Error(_0x148b0d))));}function Cd(_0x2b6399,_0x4da722,_0x593cf0,_0x10d3d7,_0x45a50a){gt(_0x2b6399,'set',{'path':_0x4da722['toString'](),'value':_0x593cf0,'priority':_0x10d3d7});const _0x12c896=Xt(_0x2b6399),_0x22d4c7=A(_0x593cf0,_0x10d3d7),_0xe89373=Vn(_0x2b6399['serverSyncTree_'],_0x4da722),_0xb4c8ee=fs(_0x22d4c7,_0xe89373,_0x12c896),_0x4f446b=zn(_0x2b6399),_0xf97954=as(_0x2b6399['serverSyncTree_'],_0x4da722,_0xb4c8ee,_0x4f446b,!0x0);qn(_0x2b6399['eventQueue_'],_0xf97954),_0x2b6399['server_']['put'](_0x4da722['toString'](),_0x22d4c7['val'](!0x0),(_0x23794a,_0x103093)=>{const _0x19b5ae=_0x23794a==='ok';_0x19b5ae||U('set\x20at\x20'+_0x4da722+'\x20failed:\x20'+_0x23794a);const _0x1e5f01=_e(_0x2b6399['serverSyncTree_'],_0x4f446b,!_0x19b5ae);V(_0x2b6399['eventQueue_'],_0x4da722,_0x1e5f01),be(_0x2b6399,_0x45a50a,_0x23794a,_0x103093);});const _0x4b29f1=Is(_0x2b6399,_0x4da722);ct(_0x2b6399,_0x4b29f1),V(_0x2b6399['eventQueue_'],_0x4b29f1,[]);}function Td(_0x2d69c4,_0x4e09fd,_0x3f3953,_0x4619e8){gt(_0x2d69c4,'update',{'path':_0x4e09fd['toString'](),'value':_0x3f3953});let _0x9dd701=!0x0;const _0xfe36ca=Xt(_0x2d69c4),_0x23081f={};if(x(_0x3f3953,(_0x103527,_0x5eac72)=>{_0x9dd701=!0x1,_0x23081f[_0x103527]=ta(k(_0x4e09fd,_0x103527),A(_0x5eac72),_0x2d69c4['serverSyncTree_'],_0xfe36ca);}),_0x9dd701)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x2d69c4,_0x4619e8,'ok',void 0x0);else{const _0x4a4cdc=zn(_0x2d69c4),_0xf8454e=ju(_0x2d69c4['serverSyncTree_'],_0x4e09fd,_0x23081f,_0x4a4cdc);qn(_0x2d69c4['eventQueue_'],_0xf8454e),_0x2d69c4['server_']['merge'](_0x4e09fd['toString'](),_0x3f3953,(_0x36c263,_0x5329ff)=>{const _0x136aa7=_0x36c263==='ok';_0x136aa7||U('update\x20at\x20'+_0x4e09fd+'\x20failed:\x20'+_0x36c263);const _0x39007c=_e(_0x2d69c4['serverSyncTree_'],_0x4a4cdc,!_0x136aa7),_0x12b5b3=_0x39007c['length']>0x0?ct(_0x2d69c4,_0x4e09fd):_0x4e09fd;V(_0x2d69c4['eventQueue_'],_0x12b5b3,_0x39007c),be(_0x2d69c4,_0x4619e8,_0x36c263,_0x5329ff);}),x(_0x3f3953,_0x110961=>{const _0x3fe1e2=Is(_0x2d69c4,k(_0x4e09fd,_0x110961));ct(_0x2d69c4,_0x3fe1e2);}),V(_0x2d69c4['eventQueue_'],_0x4e09fd,[]);}}function Sd(_0x29ec59){gt(_0x29ec59,'onDisconnectEvents');const _0x141911=Xt(_0x29ec59),_0x2ae701=En();Si(_0x29ec59['onDisconnect_'],w(),(_0x2a7565,_0x23b0d7)=>{const _0x16b5f6=ta(_0x2a7565,_0x23b0d7,_0x29ec59['serverSyncTree_'],_0x141911);pt(_0x2ae701,_0x2a7565,_0x16b5f6);});let _0x1913fa=[];Si(_0x2ae701,w(),(_0x310ff7,_0x52f66d)=>{_0x1913fa=_0x1913fa['concat'](Yt(_0x29ec59['serverSyncTree_'],_0x310ff7,_0x52f66d));const _0x24484c=Is(_0x29ec59,_0x310ff7);ct(_0x29ec59,_0x24484c);}),_0x29ec59['onDisconnect_']=En(),V(_0x29ec59['eventQueue_'],w(),_0x1913fa);}function bd(_0x7b4185,_0x28ec70,_0x4dbb0a){_0x7b4185['server_']['onDisconnectCancel'](_0x28ec70['toString'](),(_0xf51430,_0x1de0de)=>{_0xf51430==='ok'&&Ti(_0x7b4185['onDisconnect_'],_0x28ec70),be(_0x7b4185,_0x4dbb0a,_0xf51430,_0x1de0de);});}function yr(_0x481a3e,_0x1b872c,_0x2fc75f,_0x3103a9){const _0x2a3d96=A(_0x2fc75f);_0x481a3e['server_']['onDisconnectPut'](_0x1b872c['toString'](),_0x2a3d96['val'](!0x0),(_0x24b226,_0xcb2d87)=>{_0x24b226==='ok'&&pt(_0x481a3e['onDisconnect_'],_0x1b872c,_0x2a3d96),be(_0x481a3e,_0x3103a9,_0x24b226,_0xcb2d87);});}function Rd(_0x87b834,_0x48965c,_0x198d39,_0x6915e4,_0x1e39c5){const _0x57642e=A(_0x198d39,_0x6915e4);_0x87b834['server_']['onDisconnectPut'](_0x48965c['toString'](),_0x57642e['val'](!0x0),(_0xc86178,_0x42a5ea)=>{_0xc86178==='ok'&&pt(_0x87b834['onDisconnect_'],_0x48965c,_0x57642e),be(_0x87b834,_0x1e39c5,_0xc86178,_0x42a5ea);});}function Ad(_0x3fb3c5,_0x238998,_0x5c0cd9,_0x54da76){if(pn(_0x5c0cd9)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x3fb3c5,_0x54da76,'ok',void 0x0);return;}_0x3fb3c5['server_']['onDisconnectMerge'](_0x238998['toString'](),_0x5c0cd9,(_0x197e1a,_0x42d92d)=>{_0x197e1a==='ok'&&x(_0x5c0cd9,(_0x55725a,_0x48b17d)=>{const _0x212bf3=A(_0x48b17d);pt(_0x3fb3c5['onDisconnect_'],k(_0x238998,_0x55725a),_0x212bf3);}),be(_0x3fb3c5,_0x54da76,_0x197e1a,_0x42d92d);});}function kd(_0x1d5e13,_0x241f9c,_0x5b9332){let _0x23dff8;y(_0x241f9c['_path'])==='.info'?_0x23dff8=Ni(_0x1d5e13['infoSyncTree_'],_0x241f9c,_0x5b9332):_0x23dff8=Ni(_0x1d5e13['serverSyncTree_'],_0x241f9c,_0x5b9332),oa(_0x1d5e13['eventQueue_'],_0x241f9c['_path'],_0x23dff8);}function Pd(_0x51eecb,_0x48aff3,_0x4628ca){let _0x4ed458;y(_0x48aff3['_path'])==='.info'?_0x4ed458=An(_0x51eecb['infoSyncTree_'],_0x48aff3,_0x4628ca):_0x4ed458=An(_0x51eecb['serverSyncTree_'],_0x48aff3,_0x4628ca),oa(_0x51eecb['eventQueue_'],_0x48aff3['_path'],_0x4ed458);}function ha(_0x4eb30c){_0x4eb30c['persistentConnection_']&&_0x4eb30c['persistentConnection_']['interrupt'](ca);}function Nd(_0x2f8b35){_0x2f8b35['persistentConnection_']&&_0x2f8b35['persistentConnection_']['resume'](ca);}function gt(_0x2cc833,..._0x3c6ead){let _0x286108='';_0x2cc833['persistentConnection_']&&(_0x286108=_0x2cc833['persistentConnection_']['id']+':'),L(_0x286108,..._0x3c6ead);}function be(_0x1f2613,_0xf6f7,_0x453631,_0x208e93){_0xf6f7&&ft(()=>{if(_0x453631==='ok')_0xf6f7(null);else{const _0x4815cc=(_0x453631||'error')['toUpperCase']();let _0xc469d5=_0x4815cc;_0x208e93&&(_0xc469d5+=':\x20'+_0x208e93);const _0x51d867=new Error(_0xc469d5);_0x51d867['code']=_0x4815cc,_0xf6f7(_0x51d867);}});}function Od(_0x530cf1,_0x17f58d,_0x312c9f,_0x5a166b,_0x16d3c1,_0x3ee979){gt(_0x530cf1,'transaction\x20on\x20'+_0x17f58d);const _0x26247={'path':_0x17f58d,'update':_0x312c9f,'onComplete':_0x5a166b,'status':null,'order':so(),'applyLocally':_0x3ee979,'retryCount':0x0,'unwatcher':_0x16d3c1,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x466bae=Es(_0x530cf1,_0x17f58d,void 0x0);_0x26247['currentInputSnapshot']=_0x466bae;const _0x2c0cb0=_0x26247['update'](_0x466bae['val']());if(_0x2c0cb0===void 0x0)_0x26247['unwatcher'](),_0x26247['currentOutputSnapshotRaw']=null,_0x26247['currentOutputSnapshotResolved']=null,_0x26247['onComplete']&&_0x26247['onComplete'](null,!0x1,_0x26247['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x2c0cb0,_0x26247['path']),_0x26247['status']=0x0;const _0x4f2aca=$n(_0x530cf1['transactionQueueTree_'],_0x17f58d),_0x3f6635=je(_0x4f2aca)||[];_0x3f6635['push'](_0x26247),gs(_0x4f2aca,_0x3f6635);let _0x92fe66;typeof _0x2c0cb0=='object'&&_0x2c0cb0!==null&&Q(_0x2c0cb0,'.priority')?(_0x92fe66=Le(_0x2c0cb0,'.priority'),f(Bt(_0x92fe66),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x92fe66=(Vn(_0x530cf1['serverSyncTree_'],_0x17f58d)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x5cbe13=Xt(_0x530cf1),_0x503bc1=A(_0x2c0cb0,_0x92fe66),_0x51d98f=fs(_0x503bc1,_0x466bae,_0x5cbe13);_0x26247['currentOutputSnapshotRaw']=_0x503bc1,_0x26247['currentOutputSnapshotResolved']=_0x51d98f,_0x26247['currentWriteId']=zn(_0x530cf1);const _0x44502d=as(_0x530cf1['serverSyncTree_'],_0x17f58d,_0x51d98f,_0x26247['currentWriteId'],_0x26247['applyLocally']);V(_0x530cf1['eventQueue_'],_0x17f58d,_0x44502d),jn(_0x530cf1,_0x530cf1['transactionQueueTree_']);}}function Es(_0x4ea9f2,_0x668f85,_0x542a7a){return Vn(_0x4ea9f2['serverSyncTree_'],_0x668f85,_0x542a7a)||g['EMPTY_NODE'];}function jn(_0x1e6f26,_0x423ff8=_0x1e6f26['transactionQueueTree_']){if(_0x423ff8||Kn(_0x1e6f26,_0x423ff8),je(_0x423ff8)){const _0x28e123=da(_0x1e6f26,_0x423ff8);f(_0x28e123['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x28e123['every'](_0x53e807=>_0x53e807['status']===0x0)&&Dd(_0x1e6f26,Qt(_0x423ff8),_0x28e123);}else na(_0x423ff8)&&Gn(_0x423ff8,_0xdc60af=>{jn(_0x1e6f26,_0xdc60af);});}function Dd(_0x2b1c9f,_0x303659,_0x4df0e2){const _0x539f8c=_0x4df0e2['map'](_0x410b11=>_0x410b11['currentWriteId']),_0x48654a=Es(_0x2b1c9f,_0x303659,_0x539f8c);let _0x1e12c2=_0x48654a;const _0x3d3fe3=_0x48654a['hash']();for(let _0x5d8ce6=0x0;_0x5d8ce6<_0x4df0e2['length'];_0x5d8ce6++){const _0x23bf03=_0x4df0e2[_0x5d8ce6];f(_0x23bf03['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x23bf03['status']=0x1,_0x23bf03['retryCount']++;const _0x2628ba=F(_0x303659,_0x23bf03['path']);_0x1e12c2=_0x1e12c2['updateChild'](_0x2628ba,_0x23bf03['currentOutputSnapshotRaw']);}const _0x1f241a=_0x1e12c2['val'](!0x0),_0x432cd0=_0x303659;_0x2b1c9f['server_']['put'](_0x432cd0['toString'](),_0x1f241a,_0x1b23b8=>{gt(_0x2b1c9f,'transaction\x20put\x20response',{'path':_0x432cd0['toString'](),'status':_0x1b23b8});let _0x26bca7=[];if(_0x1b23b8==='ok'){const _0x51a576=[];for(let _0x4a0aff=0x0;_0x4a0aff<_0x4df0e2['length'];_0x4a0aff++)_0x4df0e2[_0x4a0aff]['status']=0x2,_0x26bca7=_0x26bca7['concat'](_e(_0x2b1c9f['serverSyncTree_'],_0x4df0e2[_0x4a0aff]['currentWriteId'])),_0x4df0e2[_0x4a0aff]['onComplete']&&_0x51a576['push'](()=>_0x4df0e2[_0x4a0aff]['onComplete'](null,!0x0,_0x4df0e2[_0x4a0aff]['currentOutputSnapshotResolved'])),_0x4df0e2[_0x4a0aff]['unwatcher']();Kn(_0x2b1c9f,$n(_0x2b1c9f['transactionQueueTree_'],_0x303659)),jn(_0x2b1c9f,_0x2b1c9f['transactionQueueTree_']),V(_0x2b1c9f['eventQueue_'],_0x303659,_0x26bca7);for(let _0x10f705=0x0;_0x10f705<_0x51a576['length'];_0x10f705++)ft(_0x51a576[_0x10f705]);}else{if(_0x1b23b8==='datastale'){for(let _0x5e3a4a=0x0;_0x5e3a4a<_0x4df0e2['length'];_0x5e3a4a++)_0x4df0e2[_0x5e3a4a]['status']===0x3?_0x4df0e2[_0x5e3a4a]['status']=0x4:_0x4df0e2[_0x5e3a4a]['status']=0x0;}else{U('transaction\x20at\x20'+_0x432cd0['toString']()+'\x20failed:\x20'+_0x1b23b8);for(let _0x1c45cc=0x0;_0x1c45cc<_0x4df0e2['length'];_0x1c45cc++)_0x4df0e2[_0x1c45cc]['status']=0x4,_0x4df0e2[_0x1c45cc]['abortReason']=_0x1b23b8;}ct(_0x2b1c9f,_0x303659);}},_0x3d3fe3);}function ct(_0xcb84d7,_0x44d810){const _0x13bdd8=ua(_0xcb84d7,_0x44d810),_0x2450a2=Qt(_0x13bdd8),_0x514f3a=da(_0xcb84d7,_0x13bdd8);return Md(_0xcb84d7,_0x514f3a,_0x2450a2),_0x2450a2;}function Md(_0x3a27d1,_0x4ddb73,_0x31551e){if(_0x4ddb73['length']===0x0)return;const _0x1f1e1a=[];let _0x27eb9c=[];const _0x1f1ed8=_0x4ddb73['filter'](_0x528421=>_0x528421['status']===0x0)['map'](_0x43c5a4=>_0x43c5a4['currentWriteId']);for(let _0x3b944f=0x0;_0x3b944f<_0x4ddb73['length'];_0x3b944f++){const _0x32a5d4=_0x4ddb73[_0x3b944f],_0x14361c=F(_0x31551e,_0x32a5d4['path']);let _0x1eaa72=!0x1,_0x57e3d1;if(f(_0x14361c!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x32a5d4['status']===0x4)_0x1eaa72=!0x0,_0x57e3d1=_0x32a5d4['abortReason'],_0x27eb9c=_0x27eb9c['concat'](_e(_0x3a27d1['serverSyncTree_'],_0x32a5d4['currentWriteId'],!0x0));else{if(_0x32a5d4['status']===0x0){if(_0x32a5d4['retryCount']>=yd)_0x1eaa72=!0x0,_0x57e3d1='maxretry',_0x27eb9c=_0x27eb9c['concat'](_e(_0x3a27d1['serverSyncTree_'],_0x32a5d4['currentWriteId'],!0x0));else{const _0x450fe8=Es(_0x3a27d1,_0x32a5d4['path'],_0x1f1ed8);_0x32a5d4['currentInputSnapshot']=_0x450fe8;const _0x2d39b6=_0x4ddb73[_0x3b944f]['update'](_0x450fe8['val']());if(_0x2d39b6!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x2d39b6,_0x32a5d4['path']);let _0x6d1f04=A(_0x2d39b6);typeof _0x2d39b6=='object'&&_0x2d39b6!=null&&Q(_0x2d39b6,'.priority')||(_0x6d1f04=_0x6d1f04['updatePriority'](_0x450fe8['getPriority']()));const _0x1b7dcc=_0x32a5d4['currentWriteId'],_0x17ae89=Xt(_0x3a27d1),_0x487e66=fs(_0x6d1f04,_0x450fe8,_0x17ae89);_0x32a5d4['currentOutputSnapshotRaw']=_0x6d1f04,_0x32a5d4['currentOutputSnapshotResolved']=_0x487e66,_0x32a5d4['currentWriteId']=zn(_0x3a27d1),_0x1f1ed8['splice'](_0x1f1ed8['indexOf'](_0x1b7dcc),0x1),_0x27eb9c=_0x27eb9c['concat'](as(_0x3a27d1['serverSyncTree_'],_0x32a5d4['path'],_0x487e66,_0x32a5d4['currentWriteId'],_0x32a5d4['applyLocally'])),_0x27eb9c=_0x27eb9c['concat'](_e(_0x3a27d1['serverSyncTree_'],_0x1b7dcc,!0x0));}else _0x1eaa72=!0x0,_0x57e3d1='nodata',_0x27eb9c=_0x27eb9c['concat'](_e(_0x3a27d1['serverSyncTree_'],_0x32a5d4['currentWriteId'],!0x0));}}}V(_0x3a27d1['eventQueue_'],_0x31551e,_0x27eb9c),_0x27eb9c=[],_0x1eaa72&&(_0x4ddb73[_0x3b944f]['status']=0x2,function(_0x1b4396){setTimeout(_0x1b4396,Math['floor'](0x0));}(_0x4ddb73[_0x3b944f]['unwatcher']),_0x4ddb73[_0x3b944f]['onComplete']&&(_0x57e3d1==='nodata'?_0x1f1e1a['push'](()=>_0x4ddb73[_0x3b944f]['onComplete'](null,!0x1,_0x4ddb73[_0x3b944f]['currentInputSnapshot'])):_0x1f1e1a['push'](()=>_0x4ddb73[_0x3b944f]['onComplete'](new Error(_0x57e3d1),!0x1,null))));}Kn(_0x3a27d1,_0x3a27d1['transactionQueueTree_']);for(let _0x424ab3=0x0;_0x424ab3<_0x1f1e1a['length'];_0x424ab3++)ft(_0x1f1e1a[_0x424ab3]);jn(_0x3a27d1,_0x3a27d1['transactionQueueTree_']);}function ua(_0x4c6db5,_0x5e86ca){let _0x480d9d,_0x59b7ce=_0x4c6db5['transactionQueueTree_'];for(_0x480d9d=y(_0x5e86ca);_0x480d9d!==null&&je(_0x59b7ce)===void 0x0;)_0x59b7ce=$n(_0x59b7ce,_0x480d9d),_0x5e86ca=S(_0x5e86ca),_0x480d9d=y(_0x5e86ca);return _0x59b7ce;}function da(_0x3d0a18,_0x836e3f){const _0x5eab7a=[];return fa(_0x3d0a18,_0x836e3f,_0x5eab7a),_0x5eab7a['sort']((_0x76fb8c,_0x28b82e)=>_0x76fb8c['order']-_0x28b82e['order']),_0x5eab7a;}function fa(_0x2b731,_0x15c488,_0x51c64d){const _0x253a1b=je(_0x15c488);if(_0x253a1b){for(let _0x4ffebf=0x0;_0x4ffebf<_0x253a1b['length'];_0x4ffebf++)_0x51c64d['push'](_0x253a1b[_0x4ffebf]);}Gn(_0x15c488,_0x85e503=>{fa(_0x2b731,_0x85e503,_0x51c64d);});}function Kn(_0xac191e,_0x56a423){const _0x38f143=je(_0x56a423);if(_0x38f143){let _0x5aa024=0x0;for(let _0x38a403=0x0;_0x38a403<_0x38f143['length'];_0x38a403++)_0x38f143[_0x38a403]['status']!==0x2&&(_0x38f143[_0x5aa024]=_0x38f143[_0x38a403],_0x5aa024++);_0x38f143['length']=_0x5aa024,gs(_0x56a423,_0x38f143['length']>0x0?_0x38f143:void 0x0);}Gn(_0x56a423,_0x8a6e27=>{Kn(_0xac191e,_0x8a6e27);});}function Is(_0x1f1267,_0x399a36){const _0x675b09=Qt(ua(_0x1f1267,_0x399a36)),_0x56fdbc=$n(_0x1f1267['transactionQueueTree_'],_0x399a36);return ad(_0x56fdbc,_0x30b2ed=>{di(_0x1f1267,_0x30b2ed);}),di(_0x1f1267,_0x56fdbc),ia(_0x56fdbc,_0x4cf31e=>{di(_0x1f1267,_0x4cf31e);}),_0x675b09;}function di(_0x4dc73d,_0x40c931){const _0x4d6cc0=je(_0x40c931);if(_0x4d6cc0){const _0x3e6f2a=[];let _0x524f4d=[],_0x308372=-0x1;for(let _0x507e31=0x0;_0x507e31<_0x4d6cc0['length'];_0x507e31++)_0x4d6cc0[_0x507e31]['status']===0x3||(_0x4d6cc0[_0x507e31]['status']===0x1?(f(_0x308372===_0x507e31-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x308372=_0x507e31,_0x4d6cc0[_0x507e31]['status']=0x3,_0x4d6cc0[_0x507e31]['abortReason']='set'):(f(_0x4d6cc0[_0x507e31]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x4d6cc0[_0x507e31]['unwatcher'](),_0x524f4d=_0x524f4d['concat'](_e(_0x4dc73d['serverSyncTree_'],_0x4d6cc0[_0x507e31]['currentWriteId'],!0x0)),_0x4d6cc0[_0x507e31]['onComplete']&&_0x3e6f2a['push'](_0x4d6cc0[_0x507e31]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x308372===-0x1?gs(_0x40c931,void 0x0):_0x4d6cc0['length']=_0x308372+0x1,V(_0x4dc73d['eventQueue_'],Qt(_0x40c931),_0x524f4d);for(let _0x10806c=0x0;_0x10806c<_0x3e6f2a['length'];_0x10806c++)ft(_0x3e6f2a[_0x10806c]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x5f5cef){let _0x4af838='';const _0x32ceaf=_0x5f5cef['split']('/');for(let _0x24116b=0x0;_0x24116b<_0x32ceaf['length'];_0x24116b++)if(_0x32ceaf[_0x24116b]['length']>0x0){let _0xe0b5d2=_0x32ceaf[_0x24116b];try{_0xe0b5d2=decodeURIComponent(_0xe0b5d2['replace'](/\+/g,'\x20'));}catch{}_0x4af838+='/'+_0xe0b5d2;}return _0x4af838;}function xd(_0x1f22c3){const _0x1eda38={};_0x1f22c3['charAt'](0x0)==='?'&&(_0x1f22c3=_0x1f22c3['substring'](0x1));for(const _0x2d8bcd of _0x1f22c3['split']('&')){if(_0x2d8bcd['length']===0x0)continue;const _0x152f30=_0x2d8bcd['split']('=');_0x152f30['length']===0x2?_0x1eda38[decodeURIComponent(_0x152f30[0x0])]=decodeURIComponent(_0x152f30[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x2d8bcd+'\x27\x20in\x20query\x20\x27'+_0x1f22c3+'\x27');}return _0x1eda38;}const vr=function(_0x373b7f,_0x37081e){const _0x568327=Fd(_0x373b7f),_0xc66c6e=_0x568327['namespace'];_0x568327['domain']==='firebase.com'&&ae(_0x568327['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0xc66c6e||_0xc66c6e==='undefined')&&_0x568327['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x568327['secure']||$l();const _0x9cacc8=_0x568327['scheme']==='ws'||_0x568327['scheme']==='wss';return{'repoInfo':new yo(_0x568327['host'],_0x568327['secure'],_0xc66c6e,_0x9cacc8,_0x37081e,'',_0xc66c6e!==_0x568327['subdomain']),'path':new C(_0x568327['pathString'])};},Fd=function(_0x2d0445){let _0x4e3e92='',_0x35f2db='',_0x26b682='',_0x4ef6f4='',_0x1c7aea='',_0xff42d4=!0x0,_0x15cf5f='https',_0x538c4d=0x1bb;if(typeof _0x2d0445=='string'){let _0x1ceef2=_0x2d0445['indexOf']('//');_0x1ceef2>=0x0&&(_0x15cf5f=_0x2d0445['substring'](0x0,_0x1ceef2-0x1),_0x2d0445=_0x2d0445['substring'](_0x1ceef2+0x2));let _0x350e51=_0x2d0445['indexOf']('/');_0x350e51===-0x1&&(_0x350e51=_0x2d0445['length']);let _0x4eeced=_0x2d0445['indexOf']('?');_0x4eeced===-0x1&&(_0x4eeced=_0x2d0445['length']),_0x4e3e92=_0x2d0445['substring'](0x0,Math['min'](_0x350e51,_0x4eeced)),_0x350e51<_0x4eeced&&(_0x4ef6f4=Ld(_0x2d0445['substring'](_0x350e51,_0x4eeced)));const _0x16f501=xd(_0x2d0445['substring'](Math['min'](_0x2d0445['length'],_0x4eeced)));_0x1ceef2=_0x4e3e92['indexOf'](':'),_0x1ceef2>=0x0?(_0xff42d4=_0x15cf5f==='https'||_0x15cf5f==='wss',_0x538c4d=parseInt(_0x4e3e92['substring'](_0x1ceef2+0x1),0xa)):_0x1ceef2=_0x4e3e92['length'];const _0x1a33ac=_0x4e3e92['slice'](0x0,_0x1ceef2);if(_0x1a33ac['toLowerCase']()==='localhost')_0x35f2db='localhost';else{if(_0x1a33ac['split']('.')['length']<=0x2)_0x35f2db=_0x1a33ac;else{const _0x24cce1=_0x4e3e92['indexOf']('.');_0x26b682=_0x4e3e92['substring'](0x0,_0x24cce1)['toLowerCase'](),_0x35f2db=_0x4e3e92['substring'](_0x24cce1+0x1),_0x1c7aea=_0x26b682;}}'ns'in _0x16f501&&(_0x1c7aea=_0x16f501['ns']);}return{'host':_0x4e3e92,'port':_0x538c4d,'domain':_0x35f2db,'subdomain':_0x26b682,'secure':_0xff42d4,'scheme':_0x15cf5f,'pathString':_0x4ef6f4,'namespace':_0x1c7aea};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x10b013=0x0;const _0x4efd08=[];return function(_0x4ca809){const _0xdc7e5c=_0x4ca809===_0x10b013;_0x10b013=_0x4ca809;let _0x5a0331;const _0x529b8a=new Array(0x8);for(_0x5a0331=0x7;_0x5a0331>=0x0;_0x5a0331--)_0x529b8a[_0x5a0331]=Er['charAt'](_0x4ca809%0x40),_0x4ca809=Math['floor'](_0x4ca809/0x40);f(_0x4ca809===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x5af99e=_0x529b8a['join']('');if(_0xdc7e5c){for(_0x5a0331=0xb;_0x5a0331>=0x0&&_0x4efd08[_0x5a0331]===0x3f;_0x5a0331--)_0x4efd08[_0x5a0331]=0x0;_0x4efd08[_0x5a0331]++;}else{for(_0x5a0331=0x0;_0x5a0331<0xc;_0x5a0331++)_0x4efd08[_0x5a0331]=Math['floor'](Math['random']()*0x40);}for(_0x5a0331=0x0;_0x5a0331<0xc;_0x5a0331++)_0x5af99e+=Er['charAt'](_0x4efd08[_0x5a0331]);return f(_0x5af99e['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x5af99e;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x7217d3,_0x2bda12,_0x51cf6a,_0x385689){this['eventType']=_0x7217d3,this['eventRegistration']=_0x2bda12,this['snapshot']=_0x51cf6a,this['prevName']=_0x385689;}['getPath'](){const _0x18794b=this['snapshot']['ref'];return this['eventType']==='value'?_0x18794b['_path']:_0x18794b['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x4fa1fd,_0x42eabb,_0x31b392){this['eventRegistration']=_0x4fa1fd,this['error']=_0x42eabb,this['path']=_0x31b392;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x176c0f,_0x563d19){this['snapshotCallback']=_0x176c0f,this['cancelCallback']=_0x563d19;}['onValue'](_0x9f394b,_0x1b39e6){this['snapshotCallback']['call'](null,_0x9f394b,_0x1b39e6);}['onCancel'](_0x55bbb9){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x55bbb9);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x5ece9a){return this['snapshotCallback']===_0x5ece9a['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x5ece9a['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x5ece9a['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x5a6160,_0x6137e5){this['_repo']=_0x5a6160,this['_path']=_0x6137e5;}['cancel'](){const _0x4bf8b2=new H();return bd(this['_repo'],this['_path'],_0x4bf8b2['wrapCallback'](()=>{})),_0x4bf8b2['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x3f6217=new H();return yr(this['_repo'],this['_path'],null,_0x3f6217['wrapCallback'](()=>{})),_0x3f6217['promise'];}['set'](_0x3b733d){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x3b733d,this['_path'],!0x1);const _0x35383d=new H();return yr(this['_repo'],this['_path'],_0x3b733d,_0x35383d['wrapCallback'](()=>{})),_0x35383d['promise'];}['setWithPriority'](_0x86640a,_0x59f492){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x86640a,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x59f492);const _0x25ff85=new H();return Rd(this['_repo'],this['_path'],_0x86640a,_0x59f492,_0x25ff85['wrapCallback'](()=>{})),_0x25ff85['promise'];}['update'](_0x452ebd){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x452ebd,this['_path']);const _0x505d65=new H();return Ad(this['_repo'],this['_path'],_0x452ebd,_0x505d65['wrapCallback'](()=>{})),_0x505d65['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x345458,_0xeddbde,_0x58ad1b,_0x5f3524){this['_repo']=_0x345458,this['_path']=_0xeddbde,this['_queryParams']=_0x58ad1b,this['_orderByCalled']=_0x5f3524;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x39e3dc=sr(this['_queryParams']),_0x5b7b4c=$i(_0x39e3dc);return _0x5b7b4c==='{}'?'default':_0x5b7b4c;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x4b01e1){if(_0x4b01e1=P(_0x4b01e1),!(_0x4b01e1 instanceof Ae))return!0x1;const _0x3502fc=this['_repo']===_0x4b01e1['_repo'],_0x4ad20d=Ki(this['_path'],_0x4b01e1['_path']),_0x14e69f=this['_queryIdentifier']===_0x4b01e1['_queryIdentifier'];return _0x3502fc&&_0x4ad20d&&_0x14e69f;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x16e4b0,_0x1787aa){if(_0x16e4b0['_orderByCalled']===!0x0)throw new Error(_0x1787aa+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x5ac9bd){let _0x4ad8c6=null,_0x1edcd5=null;if(_0x5ac9bd['hasStart']()&&(_0x4ad8c6=_0x5ac9bd['getIndexStartValue']()),_0x5ac9bd['hasEnd']()&&(_0x1edcd5=_0x5ac9bd['getIndexEndValue']()),_0x5ac9bd['getIndex']()===ve){const _0x69a3b4='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x5c3958='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x5ac9bd['hasStart']()){if(_0x5ac9bd['getIndexStartName']()!==We)throw new Error(_0x69a3b4);if(typeof _0x4ad8c6!='string')throw new Error(_0x5c3958);}if(_0x5ac9bd['hasEnd']()){if(_0x5ac9bd['getIndexEndName']()!==we)throw new Error(_0x69a3b4);if(typeof _0x1edcd5!='string')throw new Error(_0x5c3958);}}else{if(_0x5ac9bd['getIndex']()===R){if(_0x4ad8c6!=null&&!Bt(_0x4ad8c6)||_0x1edcd5!=null&&!Bt(_0x1edcd5))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x5ac9bd['getIndex']()instanceof Ji||_0x5ac9bd['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x4ad8c6!=null&&typeof _0x4ad8c6=='object'||_0x1edcd5!=null&&typeof _0x1edcd5=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x59e88e){if(_0x59e88e['hasStart']()&&_0x59e88e['hasEnd']()&&_0x59e88e['hasLimit']()&&!_0x59e88e['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x335433,_0x336029){super(_0x335433,_0x336029,new Zi(),!0x1);}get['parent'](){const _0x282fa1=Ro(this['_path']);return _0x282fa1===null?null:new ee(this['_repo'],_0x282fa1);}get['root'](){let _0x36618e=this;for(;_0x36618e['parent']!==null;)_0x36618e=_0x36618e['parent'];return _0x36618e;}}class lt{constructor(_0x9edc7f,_0x236eca,_0x90217d){this['_node']=_0x9edc7f,this['ref']=_0x236eca,this['_index']=_0x90217d;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0xfe13b0){const _0x58c2fa=new C(_0xfe13b0),_0x1c7889=Vt(this['ref'],_0xfe13b0);return new lt(this['_node']['getChild'](_0x58c2fa),_0x1c7889,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x40839a){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0xa69eba,_0x2faf75)=>_0x40839a(new lt(_0x2faf75,Vt(this['ref'],_0xa69eba),R)));}['hasChild'](_0x196d6d){const _0x33f1f2=new C(_0x196d6d);return!this['_node']['getChild'](_0x33f1f2)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x5e5f85,_0x190050){return _0x5e5f85=P(_0x5e5f85),_0x5e5f85['_checkNotDeleted']('ref'),_0x190050!==void 0x0?Vt(_0x5e5f85['_root'],_0x190050):_0x5e5f85['_root'];}function Vt(_0x514dde,_0x479ede){return _0x514dde=P(_0x514dde),y(_0x514dde['_path'])===null?pd('child','path',_0x479ede):ys('child','path',_0x479ede),new ee(_0x514dde['_repo'],k(_0x514dde['_path'],_0x479ede));}function v_(_0x429ccd){return _0x429ccd=P(_0x429ccd),new Vd(_0x429ccd['_repo'],_0x429ccd['_path']);}function E_(_0x5ae5af,_0x3b2528){_0x5ae5af=P(_0x5ae5af),Me('push',_0x5ae5af['_path']),He('push',_0x3b2528,_0x5ae5af['_path'],!0x0);const _0x4694a5=la(_0x5ae5af['_repo']),_0x42a65e=Ud(_0x4694a5),_0x5c0e66=Vt(_0x5ae5af,_0x42a65e),_0x50f737=Vt(_0x5ae5af,_0x42a65e);let _0x54bfb4;return _0x3b2528!=null?_0x54bfb4=Hd(_0x50f737,_0x3b2528)['then'](()=>_0x50f737):_0x54bfb4=Promise['resolve'](_0x50f737),_0x5c0e66['then']=_0x54bfb4['then']['bind'](_0x54bfb4),_0x5c0e66['catch']=_0x54bfb4['then']['bind'](_0x54bfb4,void 0x0),_0x5c0e66;}function Hd(_0x58ffe0,_0x1e7bc8){_0x58ffe0=P(_0x58ffe0),Me('set',_0x58ffe0['_path']),He('set',_0x1e7bc8,_0x58ffe0['_path'],!0x1);const _0x542792=new H();return Cd(_0x58ffe0['_repo'],_0x58ffe0['_path'],_0x1e7bc8,null,_0x542792['wrapCallback'](()=>{})),_0x542792['promise'];}function I_(_0x593760,_0x3f2222){ra('update',_0x3f2222,_0x593760['_path']);const _0x132d76=new H();return Td(_0x593760['_repo'],_0x593760['_path'],_0x3f2222,_0x132d76['wrapCallback'](()=>{})),_0x132d76['promise'];}function w_(_0x346dff){_0x346dff=P(_0x346dff);const _0x390b59=new pa(()=>{}),_0x195135=new Qn(_0x390b59);return wd(_0x346dff['_repo'],_0x346dff,_0x195135)['then'](_0x1a943f=>new lt(_0x1a943f,new ee(_0x346dff['_repo'],_0x346dff['_path']),_0x346dff['_queryParams']['getIndex']()));}class Qn{constructor(_0x7f677a){this['callbackContext']=_0x7f677a;}['respondsTo'](_0x27690d){return _0x27690d==='value';}['createEvent'](_0x3e49d9,_0x11db64){const _0x2fafeb=_0x11db64['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x3e49d9['snapshotNode'],new ee(_0x11db64['_repo'],_0x11db64['_path']),_0x2fafeb));}['getEventRunner'](_0x12387b){return _0x12387b['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x12387b['error']):()=>this['callbackContext']['onValue'](_0x12387b['snapshot'],null);}['createCancelEvent'](_0x5af309,_0x1b7e6c){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x5af309,_0x1b7e6c):null;}['matches'](_0x231921){return _0x231921 instanceof Qn?!_0x231921['callbackContext']||!this['callbackContext']?!0x0:_0x231921['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x21300a,_0x24b7c6,_0x184243,_0x4807b8,_0x10ed2d){const _0x4e6f20=new pa(_0x184243,void 0x0),_0x30d7c9=new Qn(_0x4e6f20);return kd(_0x21300a['_repo'],_0x21300a,_0x30d7c9),()=>Pd(_0x21300a['_repo'],_0x21300a,_0x30d7c9);}function Gd(_0x2ee943,_0x428aaa,_0x10a568,_0x5d0db7){return $d(_0x2ee943,'value',_0x428aaa);}class mt{}class ma extends mt{constructor(_0x54cec3,_0x1e4dfe){super(),this['_value']=_0x54cec3,this['_key']=_0x1e4dfe,this['type']='endAt';}['_apply'](_0x327186){He('endAt',this['_value'],_0x327186['_path'],!0x0);const _0x34e4a2=Jh(_0x327186['_queryParams'],this['_value'],this['_key']);if(ga(_0x34e4a2),Yn(_0x34e4a2),_0x327186['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x327186['_repo'],_0x327186['_path'],_0x34e4a2,_0x327186['_orderByCalled']);}}function C_(_0x236282,_0x48c1ed){return new ma(_0x236282,_0x48c1ed);}class ya extends mt{constructor(_0x4b1e88,_0x7abf0b){super(),this['_value']=_0x4b1e88,this['_key']=_0x7abf0b,this['type']='startAt';}['_apply'](_0x1d2628){He('startAt',this['_value'],_0x1d2628['_path'],!0x0);const _0x2201c4=Qh(_0x1d2628['_queryParams'],this['_value'],this['_key']);if(ga(_0x2201c4),Yn(_0x2201c4),_0x1d2628['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x1d2628['_repo'],_0x1d2628['_path'],_0x2201c4,_0x1d2628['_orderByCalled']);}}function T_(_0x1be298=null,_0x67a3b3){return new ya(_0x1be298,_0x67a3b3);}class qd extends mt{constructor(_0x1b3f68){super(),this['_limit']=_0x1b3f68,this['type']='limitToFirst';}['_apply'](_0x24bd00){if(_0x24bd00['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x24bd00['_repo'],_0x24bd00['_path'],Yh(_0x24bd00['_queryParams'],this['_limit']),_0x24bd00['_orderByCalled']);}}function S_(_0x3fd350){if(Math['floor'](_0x3fd350)!==_0x3fd350||_0x3fd350<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x3fd350);}class zd extends mt{constructor(_0x54acd2){super(),this['_path']=_0x54acd2,this['type']='orderByChild';}['_apply'](_0x58833b){_a(_0x58833b,'orderByChild');const _0x19cf46=new C(this['_path']);if(v(_0x19cf46))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x411954=new Ji(_0x19cf46),_0x5cab41=xo(_0x58833b['_queryParams'],_0x411954);return Yn(_0x5cab41),new Ae(_0x58833b['_repo'],_0x58833b['_path'],_0x5cab41,!0x0);}}function b_(_0x17b68a){if(_0x17b68a==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x17b68a==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x17b68a==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x17b68a),new zd(_0x17b68a);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x4f303c){_a(_0x4f303c,'orderByKey');const _0xe28b5c=xo(_0x4f303c['_queryParams'],ve);return Yn(_0xe28b5c),new Ae(_0x4f303c['_repo'],_0x4f303c['_path'],_0xe28b5c,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0xebe3f6,_0x3653ea){super(),this['_value']=_0xebe3f6,this['_key']=_0x3653ea,this['type']='equalTo';}['_apply'](_0x43e3ea){if(He('equalTo',this['_value'],_0x43e3ea['_path'],!0x1),_0x43e3ea['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x43e3ea['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x43e3ea));}}function A_(_0x1771c0,_0xbf3597){return new Kd(_0x1771c0,_0xbf3597);}function k_(_0x404cc5,..._0x2a067b){let _0x243a90=P(_0x404cc5);for(const _0x3a9766 of _0x2a067b)_0x243a90=_0x3a9766['_apply'](_0x243a90);return _0x243a90;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x40cae5,_0x518176,_0x2c28ee,_0x48da26){const _0x3747e0=_0x518176['lastIndexOf'](':'),_0x371e9f=_0x518176['substring'](0x0,_0x3747e0),_0x3979a0=qt(_0x371e9f);_0x40cae5['repoInfo_']=new yo(_0x518176,_0x3979a0,_0x40cae5['repoInfo_']['namespace'],_0x40cae5['repoInfo_']['webSocketOnly'],_0x40cae5['repoInfo_']['nodeAdmin'],_0x40cae5['repoInfo_']['persistenceKey'],_0x40cae5['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x2c28ee),_0x48da26&&(_0x40cae5['authTokenProvider_']=_0x48da26);}function Xd(_0x6392bc,_0x26bf41,_0x52a199,_0x344cd2,_0x2ff195){let _0x4be337=_0x344cd2||_0x6392bc['options']['databaseURL'];_0x4be337===void 0x0&&(_0x6392bc['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x6392bc['options']['projectId']),_0x4be337=_0x6392bc['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x331020=vr(_0x4be337,_0x2ff195),_0x3b2854=_0x331020['repoInfo'],_0x337436;typeof process<'u'&&Bs&&(_0x337436=Bs[Yd]),_0x337436?(_0x4be337='http://'+_0x337436+'?ns='+_0x3b2854['namespace'],_0x331020=vr(_0x4be337,_0x2ff195),_0x3b2854=_0x331020['repoInfo']):_0x331020['repoInfo']['secure'];const _0x34d3b6=new eh(_0x6392bc['name'],_0x6392bc['options'],_0x26bf41);_d('Invalid\x20Firebase\x20Database\x20URL',_0x331020),v(_0x331020['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x553659=ef(_0x3b2854,_0x6392bc,_0x34d3b6,new Zl(_0x6392bc,_0x52a199));return new tf(_0x553659,_0x6392bc);}function Zd(_0x5eb343,_0x215a0d){const _0x1f09f4=Di[_0x215a0d];(!_0x1f09f4||_0x1f09f4[_0x5eb343['key']]!==_0x5eb343)&&ae('Database\x20'+_0x215a0d+'('+_0x5eb343['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x5eb343),delete _0x1f09f4[_0x5eb343['key']];}function ef(_0x2ddf62,_0x261d7f,_0x15879f,_0x161615){let _0x50651b=Di[_0x261d7f['name']];_0x50651b||(_0x50651b={},Di[_0x261d7f['name']]=_0x50651b);let _0x11f555=_0x50651b[_0x2ddf62['toURLString']()];return _0x11f555&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x11f555=new vd(_0x2ddf62,Qd,_0x15879f,_0x161615),_0x50651b[_0x2ddf62['toURLString']()]=_0x11f555,_0x11f555;}class tf{constructor(_0x51aff3,_0x24b559){this['_repoInternal']=_0x51aff3,this['app']=_0x24b559,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x492db8){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x492db8+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0xf8df50=Zr(),_0x55dbfb){const _0x506721=Hi(_0xf8df50,'database')['getImmediate']({'identifier':_0x55dbfb});if(!_0x506721['_instanceStarted']){const _0x30e432=hc('database');_0x30e432&&nf(_0x506721,..._0x30e432);}return _0x506721;}function nf(_0x8ae8f6,_0x2e5209,_0x11d8d1,_0x3c23a6={}){_0x8ae8f6=P(_0x8ae8f6),_0x8ae8f6['_checkNotDeleted']('useEmulator');const _0x4b501f=_0x2e5209+':'+_0x11d8d1,_0x43ad4c=_0x8ae8f6['_repoInternal'];if(_0x8ae8f6['_instanceStarted']){if(_0x4b501f===_0x8ae8f6['_repoInternal']['repoInfo_']['host']&&xe(_0x3c23a6,_0x43ad4c['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x4c7703;if(_0x43ad4c['repoInfo_']['nodeAdmin'])_0x3c23a6['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x4c7703=new an(an['OWNER']);else{if(_0x3c23a6['mockUserToken']){const _0x176b5e=typeof _0x3c23a6['mockUserToken']=='string'?_0x3c23a6['mockUserToken']:uc(_0x3c23a6['mockUserToken'],_0x8ae8f6['app']['options']['projectId']);_0x4c7703=new an(_0x176b5e);}}qt(_0x2e5209)&&Qr(_0x2e5209),Jd(_0x43ad4c,_0x4b501f,_0x3c23a6,_0x4c7703);}function N_(_0x4ae77e){_0x4ae77e=P(_0x4ae77e),_0x4ae77e['_checkNotDeleted']('goOffline'),ha(_0x4ae77e['_repo']);}function O_(_0x40799f){_0x40799f=P(_0x40799f),_0x40799f['_checkNotDeleted']('goOnline'),Nd(_0x40799f['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x41f891){Ul(dt),st(new Fe('database',(_0x3d5fcd,{instanceIdentifier:_0x350321})=>{const _0x3edf60=_0x3d5fcd['getProvider']('app')['getImmediate'](),_0x13145f=_0x3d5fcd['getProvider']('auth-internal'),_0x2b3275=_0x3d5fcd['getProvider']('app-check-internal');return Xd(_0x3edf60,_0x13145f,_0x2b3275,_0x350321);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x41f891),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x2b6526,_0x556b55){this['committed']=_0x2b6526,this['snapshot']=_0x556b55;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0xcc7eef,_0x2cc4c1,_0x4042ca){if(_0xcc7eef=P(_0xcc7eef),Me('Reference.transaction',_0xcc7eef['_path']),_0xcc7eef['key']==='.length'||_0xcc7eef['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0xcc7eef['key']+'\x20is\x20a\x20read-only\x20object.';const _0x5aced4=!0x0,_0x51660f=new H(),_0x29e73b=(_0x13dcb8,_0x57e3e6,_0x10181a)=>{let _0x336092=null;_0x13dcb8?_0x51660f['reject'](_0x13dcb8):(_0x336092=new lt(_0x10181a,new ee(_0xcc7eef['_repo'],_0xcc7eef['_path']),R),_0x51660f['resolve'](new of(_0x57e3e6,_0x336092)));},_0x25f1ca=Gd(_0xcc7eef,()=>{});return Od(_0xcc7eef['_repo'],_0xcc7eef['_path'],_0x2cc4c1,_0x29e73b,_0x25f1ca,_0x5aced4),_0x51660f['promise'];}se['prototype']['simpleListen']=function(_0x5bdc37,_0x5e76b4){this['sendRequest']('q',{'p':_0x5bdc37},_0x5e76b4);},se['prototype']['echo']=function(_0x398fe3,_0x3dfb93){this['sendRequest']('echo',{'d':_0x398fe3},_0x3dfb93);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x5efbd0,..._0x15fb65){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x5efbd0,..._0x15fb65);}function cn(_0x4497ba,..._0x2d6933){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x4497ba,..._0x2d6933);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x23b3e2,..._0x1ee60e){throw ws(_0x23b3e2,..._0x1ee60e);}function X(_0x2249b0,..._0x1788fb){return ws(_0x2249b0,..._0x1788fb);}function Ia(_0x1bd7bb,_0x1580e3,_0x3a6acb){const _0x43be53={...af(),[_0x1580e3]:_0x3a6acb};return new Gt('auth','Firebase',_0x43be53)['create'](_0x1580e3,{'appName':_0x1bd7bb['name']});}function re(_0x4c0ba6){return Ia(_0x4c0ba6,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0xe181e2,..._0x706338){if(typeof _0xe181e2!='string'){const _0x510ad2=_0x706338[0x0],_0x17c7d0=[..._0x706338['slice'](0x1)];return _0x17c7d0[0x0]&&(_0x17c7d0[0x0]['appName']=_0xe181e2['name']),_0xe181e2['_errorFactory']['create'](_0x510ad2,..._0x17c7d0);}return Ea['create'](_0xe181e2,..._0x706338);}function m(_0x4d2542,_0x1cce01,..._0xadcb09){if(!_0x4d2542)throw ws(_0x1cce01,..._0xadcb09);}function ne(_0x5f3b71){const _0x4dc81b='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x5f3b71;throw cn(_0x4dc81b),new Error(_0x4dc81b);}function ce(_0x35ac60,_0x2db8f0){_0x35ac60||ne(_0x2db8f0);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x40a8ea;return typeof self<'u'&&((_0x40a8ea=self['location'])==null?void 0x0:_0x40a8ea['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x352a13;return typeof self<'u'&&((_0x352a13=self['location'])==null?void 0x0:_0x352a13['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x250d12=navigator;return _0x250d12['languages']&&_0x250d12['languages'][0x0]||_0x250d12['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x2bc39a,_0x5efffb){this['shortDelay']=_0x2bc39a,this['longDelay']=_0x5efffb,ce(_0x5efffb>_0x2bc39a,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x3c2482,_0x16fdd6){ce(_0x3c2482['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x5c400c}=_0x3c2482['emulator'];return _0x16fdd6?''+_0x5c400c+(_0x16fdd6['startsWith']('/')?_0x16fdd6['slice'](0x1):_0x16fdd6):_0x5c400c;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x3f17e0,_0x44a103,_0x207143){this['fetchImpl']=_0x3f17e0,_0x44a103&&(this['headersImpl']=_0x44a103),_0x207143&&(this['responseImpl']=_0x207143);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x118ddd,_0x33cc30){return _0x118ddd['tenantId']&&!_0x33cc30['tenantId']?{..._0x33cc30,'tenantId':_0x118ddd['tenantId']}:_0x33cc30;}async function Pe(_0x5adb4e,_0x5b9326,_0x426645,_0x9715e3,_0x99bf8f={}){return Ca(_0x5adb4e,_0x99bf8f,async()=>{let _0x2378ec={},_0x2c0473={};_0x9715e3&&(_0x5b9326==='GET'?_0x2c0473=_0x9715e3:_0x2378ec={'body':JSON['stringify'](_0x9715e3)});const _0x2d49f6=ut({..._0x2c0473,'key':_0x5adb4e['config']['apiKey']})['slice'](0x1),_0x143bfb=await _0x5adb4e['_getAdditionalHeaders']();_0x143bfb['Content-Type']='application/json',_0x5adb4e['languageCode']&&(_0x143bfb['X-Firebase-Locale']=_0x5adb4e['languageCode']);const _0x36fa13={'method':_0x5b9326,'headers':_0x143bfb,..._0x2378ec};return dc()||(_0x36fa13['referrerPolicy']='strict-origin-when-cross-origin'),_0x5adb4e['emulatorConfig']&&qt(_0x5adb4e['emulatorConfig']['host'])&&(_0x36fa13['credentials']='include'),wa['fetch']()(await Ta(_0x5adb4e,_0x5adb4e['config']['apiHost'],_0x426645,_0x2d49f6),_0x36fa13);});}async function Ca(_0x2e4f34,_0x15f122,_0x5cd6c5){_0x2e4f34['_canInitEmulator']=!0x1;const _0x216411={...df,..._0x15f122};try{const _0x52204b=new gf(_0x2e4f34),_0x45ee91=await Promise['race']([_0x5cd6c5(),_0x52204b['promise']]);_0x52204b['clearNetworkTimeout']();const _0x52fc0e=await _0x45ee91['json']();if('needConfirmation'in _0x52fc0e)throw on(_0x2e4f34,'account-exists-with-different-credential',_0x52fc0e);if(_0x45ee91['ok']&&!('errorMessage'in _0x52fc0e))return _0x52fc0e;{const _0x432ffb=_0x45ee91['ok']?_0x52fc0e['errorMessage']:_0x52fc0e['error']['message'],[_0xae63fb,_0x3aced3]=_0x432ffb['split']('\x20:\x20');if(_0xae63fb==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x2e4f34,'credential-already-in-use',_0x52fc0e);if(_0xae63fb==='EMAIL_EXISTS')throw on(_0x2e4f34,'email-already-in-use',_0x52fc0e);if(_0xae63fb==='USER_DISABLED')throw on(_0x2e4f34,'user-disabled',_0x52fc0e);const _0x18377b=_0x216411[_0xae63fb]||_0xae63fb['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x3aced3)throw Ia(_0x2e4f34,_0x18377b,_0x3aced3);Y(_0x2e4f34,_0x18377b);}}catch(_0x26bdba){if(_0x26bdba instanceof Re)throw _0x26bdba;Y(_0x2e4f34,'network-request-failed',{'message':String(_0x26bdba)});}}async function en(_0xfeb6ba,_0x17f5fd,_0x58a804,_0x310b7d,_0x1b640d={}){const _0x23364a=await Pe(_0xfeb6ba,_0x17f5fd,_0x58a804,_0x310b7d,_0x1b640d);return'mfaPendingCredential'in _0x23364a&&Y(_0xfeb6ba,'multi-factor-auth-required',{'_serverResponse':_0x23364a}),_0x23364a;}async function Ta(_0x56cdd1,_0x5db3dc,_0x598d08,_0xb4be5c){const _0x1404a2=''+_0x5db3dc+_0x598d08+'?'+_0xb4be5c,_0x2a830f=_0x56cdd1,_0x189a15=_0x2a830f['config']['emulator']?Cs(_0x56cdd1['config'],_0x1404a2):_0x56cdd1['config']['apiScheme']+'://'+_0x1404a2;return ff['includes'](_0x598d08)&&(await _0x2a830f['_persistenceManagerAvailable'],_0x2a830f['_getPersistenceType']()==='COOKIE')?_0x2a830f['_getPersistence']()['_getFinalTarget'](_0x189a15)['toString']():_0x189a15;}function _f(_0x425d58){switch(_0x425d58){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x3bd9fa){this['auth']=_0x3bd9fa,this['timer']=null,this['promise']=new Promise((_0xc87161,_0x53cc22)=>{this['timer']=setTimeout(()=>_0x53cc22(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x57c763,_0x2c7099,_0x4a0cf7){const _0x40d27d={'appName':_0x57c763['name']};_0x4a0cf7['email']&&(_0x40d27d['email']=_0x4a0cf7['email']),_0x4a0cf7['phoneNumber']&&(_0x40d27d['phoneNumber']=_0x4a0cf7['phoneNumber']);const _0x1b4abb=X(_0x57c763,_0x2c7099,_0x40d27d);return _0x1b4abb['customData']['_tokenResponse']=_0x4a0cf7,_0x1b4abb;}function wr(_0x22793d){return _0x22793d!==void 0x0&&_0x22793d['enterprise']!==void 0x0;}class mf{constructor(_0x590f27){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x590f27['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x590f27['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x590f27['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x46e044){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x45a95a of this['recaptchaEnforcementState'])if(_0x45a95a['provider']&&_0x45a95a['provider']===_0x46e044)return _f(_0x45a95a['enforcementState']);return null;}['isProviderEnabled'](_0x5c5e9c){return this['getProviderEnforcementState'](_0x5c5e9c)==='ENFORCE'||this['getProviderEnforcementState'](_0x5c5e9c)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x210a95,_0x144efe){return Pe(_0x210a95,'GET','/v2/recaptchaConfig',ke(_0x210a95,_0x144efe));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x1c7ab3,_0x4b636d){return Pe(_0x1c7ab3,'POST','/v1/accounts:delete',_0x4b636d);}async function Pn(_0x265d7e,_0xc11e58){return Pe(_0x265d7e,'POST','/v1/accounts:lookup',_0xc11e58);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x5c2d44){if(_0x5c2d44)try{const _0xd9e09d=new Date(Number(_0x5c2d44));if(!isNaN(_0xd9e09d['getTime']()))return _0xd9e09d['toUTCString']();}catch{}}async function Ef(_0x473316,_0x3ff4b7=!0x1){const _0x33c9bc=P(_0x473316),_0x4177bf=await _0x33c9bc['getIdToken'](_0x3ff4b7),_0x451019=Ts(_0x4177bf);m(_0x451019&&_0x451019['exp']&&_0x451019['auth_time']&&_0x451019['iat'],_0x33c9bc['auth'],'internal-error');const _0x2a43f6=typeof _0x451019['firebase']=='object'?_0x451019['firebase']:void 0x0,_0x4b0e8a=_0x2a43f6==null?void 0x0:_0x2a43f6['sign_in_provider'];return{'claims':_0x451019,'token':_0x4177bf,'authTime':Pt(fi(_0x451019['auth_time'])),'issuedAtTime':Pt(fi(_0x451019['iat'])),'expirationTime':Pt(fi(_0x451019['exp'])),'signInProvider':_0x4b0e8a||null,'signInSecondFactor':(_0x2a43f6==null?void 0x0:_0x2a43f6['sign_in_second_factor'])||null};}function fi(_0x5779a5){return Number(_0x5779a5)*0x3e8;}function Ts(_0x58956c){const [_0x53614a,_0x2e9d7,_0x22d8e8]=_0x58956c['split']('.');if(_0x53614a===void 0x0||_0x2e9d7===void 0x0||_0x22d8e8===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x269e13=fn(_0x2e9d7);return _0x269e13?JSON['parse'](_0x269e13):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x55f001){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x55f001==null?void 0x0:_0x55f001['toString']()),null;}}function Cr(_0x2596a3){const _0x2b9f7f=Ts(_0x2596a3);return m(_0x2b9f7f,'internal-error'),m(typeof _0x2b9f7f['exp']<'u','internal-error'),m(typeof _0x2b9f7f['iat']<'u','internal-error'),Number(_0x2b9f7f['exp'])-Number(_0x2b9f7f['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x511d80,_0x34dc1c,_0x57ec76=!0x1){if(_0x57ec76)return _0x34dc1c;try{return await _0x34dc1c;}catch(_0x3d05ad){throw _0x3d05ad instanceof Re&&If(_0x3d05ad)&&_0x511d80['auth']['currentUser']===_0x511d80&&await _0x511d80['auth']['signOut'](),_0x3d05ad;}}function If({code:_0x46266f}){return _0x46266f==='auth/user-disabled'||_0x46266f==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x237601){this['user']=_0x237601,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x2abd2b){if(_0x2abd2b){const _0x349a8a=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x349a8a;}else{this['errorBackoff']=0x7530;const _0x3638ca=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x3638ca);}}['schedule'](_0x5e2560=!0x1){if(!this['isRunning'])return;const _0x1c77c0=this['getInterval'](_0x5e2560);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x1c77c0);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0xd2b417){(_0xd2b417==null?void 0x0:_0xd2b417['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x2e60fc,_0x4732b3){this['createdAt']=_0x2e60fc,this['lastLoginAt']=_0x4732b3,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x18d26c){this['createdAt']=_0x18d26c['createdAt'],this['lastLoginAt']=_0x18d26c['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x5207e1){var _0x27e06b;const _0x316d80=_0x5207e1['auth'],_0x18203c=await _0x5207e1['getIdToken'](),_0x2a1260=await Ht(_0x5207e1,Pn(_0x316d80,{'idToken':_0x18203c}));m(_0x2a1260==null?void 0x0:_0x2a1260['users']['length'],_0x316d80,'internal-error');const _0x449b7e=_0x2a1260['users'][0x0];_0x5207e1['_notifyReloadListener'](_0x449b7e);const _0x47cb4e=(_0x27e06b=_0x449b7e['providerUserInfo'])!=null&&_0x27e06b['length']?Sa(_0x449b7e['providerUserInfo']):[],_0x446ebc=Tf(_0x5207e1['providerData'],_0x47cb4e),_0x8bf401=_0x5207e1['isAnonymous'],_0x1e2a48=!(_0x5207e1['email']&&_0x449b7e['passwordHash'])&&!(_0x446ebc!=null&&_0x446ebc['length']),_0x427f15=_0x8bf401?_0x1e2a48:!0x1,_0x290493={'uid':_0x449b7e['localId'],'displayName':_0x449b7e['displayName']||null,'photoURL':_0x449b7e['photoUrl']||null,'email':_0x449b7e['email']||null,'emailVerified':_0x449b7e['emailVerified']||!0x1,'phoneNumber':_0x449b7e['phoneNumber']||null,'tenantId':_0x449b7e['tenantId']||null,'providerData':_0x446ebc,'metadata':new Li(_0x449b7e['createdAt'],_0x449b7e['lastLoginAt']),'isAnonymous':_0x427f15};Object['assign'](_0x5207e1,_0x290493);}async function Cf(_0x1f2c52){const _0x56879d=P(_0x1f2c52);await Nn(_0x56879d),await _0x56879d['auth']['_persistUserIfCurrent'](_0x56879d),_0x56879d['auth']['_notifyListenersIfCurrent'](_0x56879d);}function Tf(_0x6af715,_0x32943a){return[..._0x6af715['filter'](_0x254918=>!_0x32943a['some'](_0x48e391=>_0x48e391['providerId']===_0x254918['providerId'])),..._0x32943a];}function Sa(_0x1487ce){return _0x1487ce['map'](({providerId:_0x33a702,..._0x2cdcd6})=>({'providerId':_0x33a702,'uid':_0x2cdcd6['rawId']||'','displayName':_0x2cdcd6['displayName']||null,'email':_0x2cdcd6['email']||null,'phoneNumber':_0x2cdcd6['phoneNumber']||null,'photoURL':_0x2cdcd6['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x23b842,_0x143e9b){const _0x59d8a0=await Ca(_0x23b842,{},async()=>{const _0x515ce9=ut({'grant_type':'refresh_token','refresh_token':_0x143e9b})['slice'](0x1),{tokenApiHost:_0x54f846,apiKey:_0x1d0539}=_0x23b842['config'],_0x1d41e5=await Ta(_0x23b842,_0x54f846,'/v1/token','key='+_0x1d0539),_0x2acb33=await _0x23b842['_getAdditionalHeaders']();_0x2acb33['Content-Type']='application/x-www-form-urlencoded';const _0x115b05={'method':'POST','headers':_0x2acb33,'body':_0x515ce9};return _0x23b842['emulatorConfig']&&qt(_0x23b842['emulatorConfig']['host'])&&(_0x115b05['credentials']='include'),wa['fetch']()(_0x1d41e5,_0x115b05);});return{'accessToken':_0x59d8a0['access_token'],'expiresIn':_0x59d8a0['expires_in'],'refreshToken':_0x59d8a0['refresh_token']};}async function bf(_0x22d072,_0x2adaba){return Pe(_0x22d072,'POST','/v2/accounts:revokeToken',ke(_0x22d072,_0x2adaba));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0xd9286c){m(_0xd9286c['idToken'],'internal-error'),m(typeof _0xd9286c['idToken']<'u','internal-error'),m(typeof _0xd9286c['refreshToken']<'u','internal-error');const _0x302a40='expiresIn'in _0xd9286c&&typeof _0xd9286c['expiresIn']<'u'?Number(_0xd9286c['expiresIn']):Cr(_0xd9286c['idToken']);this['updateTokensAndExpiration'](_0xd9286c['idToken'],_0xd9286c['refreshToken'],_0x302a40);}['updateFromIdToken'](_0x46a2f1){m(_0x46a2f1['length']!==0x0,'internal-error');const _0xafd806=Cr(_0x46a2f1);this['updateTokensAndExpiration'](_0x46a2f1,null,_0xafd806);}async['getToken'](_0x56a0c8,_0x3991d6=!0x1){return!_0x3991d6&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x56a0c8,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x56a0c8,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x5adbe5,_0x279de9){const {accessToken:_0x52b8f,refreshToken:_0x1451a0,expiresIn:_0x3a6b6c}=await Sf(_0x5adbe5,_0x279de9);this['updateTokensAndExpiration'](_0x52b8f,_0x1451a0,Number(_0x3a6b6c));}['updateTokensAndExpiration'](_0xbddec7,_0x380e95,_0x2b1dbe){this['refreshToken']=_0x380e95||null,this['accessToken']=_0xbddec7||null,this['expirationTime']=Date['now']()+_0x2b1dbe*0x3e8;}static['fromJSON'](_0x23543b,_0x530c48){const {refreshToken:_0x1b54b1,accessToken:_0x24a120,expirationTime:_0x52293d}=_0x530c48,_0x128cc0=new et();return _0x1b54b1&&(m(typeof _0x1b54b1=='string','internal-error',{'appName':_0x23543b}),_0x128cc0['refreshToken']=_0x1b54b1),_0x24a120&&(m(typeof _0x24a120=='string','internal-error',{'appName':_0x23543b}),_0x128cc0['accessToken']=_0x24a120),_0x52293d&&(m(typeof _0x52293d=='number','internal-error',{'appName':_0x23543b}),_0x128cc0['expirationTime']=_0x52293d),_0x128cc0;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x2605dc){this['accessToken']=_0x2605dc['accessToken'],this['refreshToken']=_0x2605dc['refreshToken'],this['expirationTime']=_0x2605dc['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x3a7a22,_0x26af53){m(typeof _0x3a7a22=='string'||typeof _0x3a7a22>'u','internal-error',{'appName':_0x26af53});}class j{constructor({uid:_0x35f42c,auth:_0x262afd,stsTokenManager:_0x2c5ac5,..._0x4abd8a}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x35f42c,this['auth']=_0x262afd,this['stsTokenManager']=_0x2c5ac5,this['accessToken']=_0x2c5ac5['accessToken'],this['displayName']=_0x4abd8a['displayName']||null,this['email']=_0x4abd8a['email']||null,this['emailVerified']=_0x4abd8a['emailVerified']||!0x1,this['phoneNumber']=_0x4abd8a['phoneNumber']||null,this['photoURL']=_0x4abd8a['photoURL']||null,this['isAnonymous']=_0x4abd8a['isAnonymous']||!0x1,this['tenantId']=_0x4abd8a['tenantId']||null,this['providerData']=_0x4abd8a['providerData']?[..._0x4abd8a['providerData']]:[],this['metadata']=new Li(_0x4abd8a['createdAt']||void 0x0,_0x4abd8a['lastLoginAt']||void 0x0);}async['getIdToken'](_0x228d21){const _0x9daaa2=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x228d21));return m(_0x9daaa2,this['auth'],'internal-error'),this['accessToken']!==_0x9daaa2&&(this['accessToken']=_0x9daaa2,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x9daaa2;}['getIdTokenResult'](_0x1de8ae){return Ef(this,_0x1de8ae);}['reload'](){return Cf(this);}['_assign'](_0x549c9e){this!==_0x549c9e&&(m(this['uid']===_0x549c9e['uid'],this['auth'],'internal-error'),this['displayName']=_0x549c9e['displayName'],this['photoURL']=_0x549c9e['photoURL'],this['email']=_0x549c9e['email'],this['emailVerified']=_0x549c9e['emailVerified'],this['phoneNumber']=_0x549c9e['phoneNumber'],this['isAnonymous']=_0x549c9e['isAnonymous'],this['tenantId']=_0x549c9e['tenantId'],this['providerData']=_0x549c9e['providerData']['map'](_0x369f17=>({..._0x369f17})),this['metadata']['_copy'](_0x549c9e['metadata']),this['stsTokenManager']['_assign'](_0x549c9e['stsTokenManager']));}['_clone'](_0x23f908){const _0x36853c=new j({...this,'auth':_0x23f908,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x36853c['metadata']['_copy'](this['metadata']),_0x36853c;}['_onReload'](_0x520877){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x520877,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x20b2d0){this['reloadListener']?this['reloadListener'](_0x20b2d0):this['reloadUserInfo']=_0x20b2d0;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0xd34f8,_0xfbd522=!0x1){let _0x517f17=!0x1;_0xd34f8['idToken']&&_0xd34f8['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0xd34f8),_0x517f17=!0x0),_0xfbd522&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x517f17&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x19831b=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x19831b})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x588dc6=>({..._0x588dc6})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x138dbf,_0x2b6177){const _0x95c5e2=_0x2b6177['displayName']??void 0x0,_0x1f96f1=_0x2b6177['email']??void 0x0,_0x3fd1cd=_0x2b6177['phoneNumber']??void 0x0,_0x510c91=_0x2b6177['photoURL']??void 0x0,_0x560878=_0x2b6177['tenantId']??void 0x0,_0x1bc2bd=_0x2b6177['_redirectEventId']??void 0x0,_0x2e27f7=_0x2b6177['createdAt']??void 0x0,_0x53e5a3=_0x2b6177['lastLoginAt']??void 0x0,{uid:_0x5e6879,emailVerified:_0x278e2e,isAnonymous:_0x909f5,providerData:_0x148843,stsTokenManager:_0x2a7e4f}=_0x2b6177;m(_0x5e6879&&_0x2a7e4f,_0x138dbf,'internal-error');const _0x12e81b=et['fromJSON'](this['name'],_0x2a7e4f);m(typeof _0x5e6879=='string',_0x138dbf,'internal-error'),le(_0x95c5e2,_0x138dbf['name']),le(_0x1f96f1,_0x138dbf['name']),m(typeof _0x278e2e=='boolean',_0x138dbf,'internal-error'),m(typeof _0x909f5=='boolean',_0x138dbf,'internal-error'),le(_0x3fd1cd,_0x138dbf['name']),le(_0x510c91,_0x138dbf['name']),le(_0x560878,_0x138dbf['name']),le(_0x1bc2bd,_0x138dbf['name']),le(_0x2e27f7,_0x138dbf['name']),le(_0x53e5a3,_0x138dbf['name']);const _0x3724cb=new j({'uid':_0x5e6879,'auth':_0x138dbf,'email':_0x1f96f1,'emailVerified':_0x278e2e,'displayName':_0x95c5e2,'isAnonymous':_0x909f5,'photoURL':_0x510c91,'phoneNumber':_0x3fd1cd,'tenantId':_0x560878,'stsTokenManager':_0x12e81b,'createdAt':_0x2e27f7,'lastLoginAt':_0x53e5a3});return _0x148843&&Array['isArray'](_0x148843)&&(_0x3724cb['providerData']=_0x148843['map'](_0x17f303=>({..._0x17f303}))),_0x1bc2bd&&(_0x3724cb['_redirectEventId']=_0x1bc2bd),_0x3724cb;}static async['_fromIdTokenResponse'](_0x21c986,_0x31cece,_0x4fcdd0=!0x1){const _0x22789c=new et();_0x22789c['updateFromServerResponse'](_0x31cece);const _0x16c165=new j({'uid':_0x31cece['localId'],'auth':_0x21c986,'stsTokenManager':_0x22789c,'isAnonymous':_0x4fcdd0});return await Nn(_0x16c165),_0x16c165;}static async['_fromGetAccountInfoResponse'](_0x9a747b,_0x3359e0,_0x4b6d34){const _0x11bf37=_0x3359e0['users'][0x0];m(_0x11bf37['localId']!==void 0x0,'internal-error');const _0x4ab7f3=_0x11bf37['providerUserInfo']!==void 0x0?Sa(_0x11bf37['providerUserInfo']):[],_0x532167=!(_0x11bf37['email']&&_0x11bf37['passwordHash'])&&!(_0x4ab7f3!=null&&_0x4ab7f3['length']),_0x50bf32=new et();_0x50bf32['updateFromIdToken'](_0x4b6d34);const _0x27a002=new j({'uid':_0x11bf37['localId'],'auth':_0x9a747b,'stsTokenManager':_0x50bf32,'isAnonymous':_0x532167}),_0x56c354={'uid':_0x11bf37['localId'],'displayName':_0x11bf37['displayName']||null,'photoURL':_0x11bf37['photoUrl']||null,'email':_0x11bf37['email']||null,'emailVerified':_0x11bf37['emailVerified']||!0x1,'phoneNumber':_0x11bf37['phoneNumber']||null,'tenantId':_0x11bf37['tenantId']||null,'providerData':_0x4ab7f3,'metadata':new Li(_0x11bf37['createdAt'],_0x11bf37['lastLoginAt']),'isAnonymous':!(_0x11bf37['email']&&_0x11bf37['passwordHash'])&&!(_0x4ab7f3!=null&&_0x4ab7f3['length'])};return Object['assign'](_0x27a002,_0x56c354),_0x27a002;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x411e83){ce(_0x411e83 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x216d7e=Tr['get'](_0x411e83);return _0x216d7e?(ce(_0x216d7e instanceof _0x411e83,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x216d7e):(_0x216d7e=new _0x411e83(),Tr['set'](_0x411e83,_0x216d7e),_0x216d7e);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x9a65b8,_0x132223){this['storage'][_0x9a65b8]=_0x132223;}async['_get'](_0x3d0599){const _0x46b32d=this['storage'][_0x3d0599];return _0x46b32d===void 0x0?null:_0x46b32d;}async['_remove'](_0x281b54){delete this['storage'][_0x281b54];}['_addListener'](_0x44c8ef,_0x2df5c){}['_removeListener'](_0x5be38b,_0x24f622){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x1c03c5,_0x496bb2,_0x5389f5){return'firebase:'+_0x1c03c5+':'+_0x496bb2+':'+_0x5389f5;}class tt{constructor(_0x3646c5,_0x5b6ab2,_0x39bae5){this['persistence']=_0x3646c5,this['auth']=_0x5b6ab2,this['userKey']=_0x39bae5;const {config:_0x21a6af,name:_0x2a600a}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x21a6af['apiKey'],_0x2a600a),this['fullPersistenceKey']=ln('persistence',_0x21a6af['apiKey'],_0x2a600a),this['boundEventHandler']=_0x5b6ab2['_onStorageEvent']['bind'](_0x5b6ab2),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0xd72b4b){return this['persistence']['_set'](this['fullUserKey'],_0xd72b4b['toJSON']());}async['getCurrentUser'](){const _0x3ddaeb=await this['persistence']['_get'](this['fullUserKey']);if(!_0x3ddaeb)return null;if(typeof _0x3ddaeb=='string'){const _0xde6e1b=await Pn(this['auth'],{'idToken':_0x3ddaeb})['catch'](()=>{});return _0xde6e1b?j['_fromGetAccountInfoResponse'](this['auth'],_0xde6e1b,_0x3ddaeb):null;}return j['_fromJSON'](this['auth'],_0x3ddaeb);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x603672){if(this['persistence']===_0x603672)return;const _0x2dad3f=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x603672,_0x2dad3f)return this['setCurrentUser'](_0x2dad3f);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0xd13d5b,_0x398d1b,_0x3c3126='authUser'){if(!_0x398d1b['length'])return new tt(ie(Sr),_0xd13d5b,_0x3c3126);const _0x3be2c5=(await Promise['all'](_0x398d1b['map'](async _0xdd463a=>{if(await _0xdd463a['_isAvailable']())return _0xdd463a;})))['filter'](_0x33f770=>_0x33f770);let _0x522538=_0x3be2c5[0x0]||ie(Sr);const _0x1a2108=ln(_0x3c3126,_0xd13d5b['config']['apiKey'],_0xd13d5b['name']);let _0x46d614=null;for(const _0x3921c8 of _0x398d1b)try{const _0xe3b2bf=await _0x3921c8['_get'](_0x1a2108);if(_0xe3b2bf){let _0x1c6219;if(typeof _0xe3b2bf=='string'){const _0x1ac416=await Pn(_0xd13d5b,{'idToken':_0xe3b2bf})['catch'](()=>{});if(!_0x1ac416)break;_0x1c6219=await j['_fromGetAccountInfoResponse'](_0xd13d5b,_0x1ac416,_0xe3b2bf);}else _0x1c6219=j['_fromJSON'](_0xd13d5b,_0xe3b2bf);_0x3921c8!==_0x522538&&(_0x46d614=_0x1c6219),_0x522538=_0x3921c8;break;}}catch{}const _0x5c37d9=_0x3be2c5['filter'](_0x382540=>_0x382540['_shouldAllowMigration']);return!_0x522538['_shouldAllowMigration']||!_0x5c37d9['length']?new tt(_0x522538,_0xd13d5b,_0x3c3126):(_0x522538=_0x5c37d9[0x0],_0x46d614&&await _0x522538['_set'](_0x1a2108,_0x46d614['toJSON']()),await Promise['all'](_0x398d1b['map'](async _0x2031b9=>{if(_0x2031b9!==_0x522538)try{await _0x2031b9['_remove'](_0x1a2108);}catch{}})),new tt(_0x522538,_0xd13d5b,_0x3c3126));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x429bd7){const _0x13d177=_0x429bd7['toLowerCase']();if(_0x13d177['includes']('opera/')||_0x13d177['includes']('opr/')||_0x13d177['includes']('opios/'))return'Opera';if(Pa(_0x13d177))return'IEMobile';if(_0x13d177['includes']('msie')||_0x13d177['includes']('trident/'))return'IE';if(_0x13d177['includes']('edge/'))return'Edge';if(Ra(_0x13d177))return'Firefox';if(_0x13d177['includes']('silk/'))return'Silk';if(Oa(_0x13d177))return'Blackberry';if(Da(_0x13d177))return'Webos';if(Aa(_0x13d177))return'Safari';if((_0x13d177['includes']('chrome/')||ka(_0x13d177))&&!_0x13d177['includes']('edge/'))return'Chrome';if(Na(_0x13d177))return'Android';{const _0x287d65=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x40fd51=_0x429bd7['match'](_0x287d65);if((_0x40fd51==null?void 0x0:_0x40fd51['length'])===0x2)return _0x40fd51[0x1];}return'Other';}function Ra(_0x1bb69e=W()){return/firefox\//i['test'](_0x1bb69e);}function Aa(_0x470a17=W()){const _0x5316d4=_0x470a17['toLowerCase']();return _0x5316d4['includes']('safari/')&&!_0x5316d4['includes']('chrome/')&&!_0x5316d4['includes']('crios/')&&!_0x5316d4['includes']('android');}function ka(_0x34b653=W()){return/crios\//i['test'](_0x34b653);}function Pa(_0x5a5996=W()){return/iemobile/i['test'](_0x5a5996);}function Na(_0x2911d2=W()){return/android/i['test'](_0x2911d2);}function Oa(_0x4df2fa=W()){return/blackberry/i['test'](_0x4df2fa);}function Da(_0x337da7=W()){return/webos/i['test'](_0x337da7);}function Ss(_0x5266df=W()){return/iphone|ipad|ipod/i['test'](_0x5266df)||/macintosh/i['test'](_0x5266df)&&/mobile/i['test'](_0x5266df);}function Rf(_0x2567f2=W()){var _0x344780;return Ss(_0x2567f2)&&!!((_0x344780=window['navigator'])!=null&&_0x344780['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x4c9dd3=W()){return Ss(_0x4c9dd3)||Na(_0x4c9dd3)||Da(_0x4c9dd3)||Oa(_0x4c9dd3)||/windows phone/i['test'](_0x4c9dd3)||Pa(_0x4c9dd3);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x94677b,_0xa6c643=[]){let _0x1c0819;switch(_0x94677b){case'Browser':_0x1c0819=br(W());break;case'Worker':_0x1c0819=br(W())+'-'+_0x94677b;break;default:_0x1c0819=_0x94677b;}const _0x17f069=_0xa6c643['length']?_0xa6c643['join'](','):'FirebaseCore-web';return _0x1c0819+'/JsCore/'+dt+'/'+_0x17f069;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0xa3dc22){this['auth']=_0xa3dc22,this['queue']=[];}['pushCallback'](_0x5906eb,_0x7f1ba8){const _0x744ff0=_0x18223c=>new Promise((_0x5ea7d0,_0x42bee9)=>{try{const _0x512646=_0x5906eb(_0x18223c);_0x5ea7d0(_0x512646);}catch(_0x2ccd05){_0x42bee9(_0x2ccd05);}});_0x744ff0['onAbort']=_0x7f1ba8,this['queue']['push'](_0x744ff0);const _0x1c4901=this['queue']['length']-0x1;return()=>{this['queue'][_0x1c4901]=()=>Promise['resolve']();};}async['runMiddleware'](_0x58287e){if(this['auth']['currentUser']===_0x58287e)return;const _0xafccaf=[];try{for(const _0x2c8cf1 of this['queue'])await _0x2c8cf1(_0x58287e),_0x2c8cf1['onAbort']&&_0xafccaf['push'](_0x2c8cf1['onAbort']);}catch(_0x24abbd){_0xafccaf['reverse']();for(const _0x4e0a5d of _0xafccaf)try{_0x4e0a5d();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x24abbd==null?void 0x0:_0x24abbd['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x2ff235,_0x38c309={}){return Pe(_0x2ff235,'GET','/v2/passwordPolicy',ke(_0x2ff235,_0x38c309));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x44221a){var _0x2d1849;const _0x12616f=_0x44221a['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x12616f['minPasswordLength']??Nf,_0x12616f['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x12616f['maxPasswordLength']),_0x12616f['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x12616f['containsLowercaseCharacter']),_0x12616f['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x12616f['containsUppercaseCharacter']),_0x12616f['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x12616f['containsNumericCharacter']),_0x12616f['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x12616f['containsNonAlphanumericCharacter']),this['enforcementState']=_0x44221a['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x2d1849=_0x44221a['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x2d1849['join'](''))??'',this['forceUpgradeOnSignin']=_0x44221a['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x44221a['schemaVersion'];}['validatePassword'](_0x1836e9){const _0x354c22={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x1836e9,_0x354c22),this['validatePasswordCharacterOptions'](_0x1836e9,_0x354c22),_0x354c22['isValid']&&(_0x354c22['isValid']=_0x354c22['meetsMinPasswordLength']??!0x0),_0x354c22['isValid']&&(_0x354c22['isValid']=_0x354c22['meetsMaxPasswordLength']??!0x0),_0x354c22['isValid']&&(_0x354c22['isValid']=_0x354c22['containsLowercaseLetter']??!0x0),_0x354c22['isValid']&&(_0x354c22['isValid']=_0x354c22['containsUppercaseLetter']??!0x0),_0x354c22['isValid']&&(_0x354c22['isValid']=_0x354c22['containsNumericCharacter']??!0x0),_0x354c22['isValid']&&(_0x354c22['isValid']=_0x354c22['containsNonAlphanumericCharacter']??!0x0),_0x354c22;}['validatePasswordLengthOptions'](_0x24c0a2,_0x33a89f){const _0x2c0ea8=this['customStrengthOptions']['minPasswordLength'],_0x284a46=this['customStrengthOptions']['maxPasswordLength'];_0x2c0ea8&&(_0x33a89f['meetsMinPasswordLength']=_0x24c0a2['length']>=_0x2c0ea8),_0x284a46&&(_0x33a89f['meetsMaxPasswordLength']=_0x24c0a2['length']<=_0x284a46);}['validatePasswordCharacterOptions'](_0x2a1edc,_0x30c258){this['updatePasswordCharacterOptionsStatuses'](_0x30c258,!0x1,!0x1,!0x1,!0x1);let _0x3608b8;for(let _0x306980=0x0;_0x306980<_0x2a1edc['length'];_0x306980++)_0x3608b8=_0x2a1edc['charAt'](_0x306980),this['updatePasswordCharacterOptionsStatuses'](_0x30c258,_0x3608b8>='a'&&_0x3608b8<='z',_0x3608b8>='A'&&_0x3608b8<='Z',_0x3608b8>='0'&&_0x3608b8<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x3608b8));}['updatePasswordCharacterOptionsStatuses'](_0x1a0af8,_0x398503,_0x128787,_0xa1b3b7,_0xca9f1b){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x1a0af8['containsLowercaseLetter']||(_0x1a0af8['containsLowercaseLetter']=_0x398503)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x1a0af8['containsUppercaseLetter']||(_0x1a0af8['containsUppercaseLetter']=_0x128787)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x1a0af8['containsNumericCharacter']||(_0x1a0af8['containsNumericCharacter']=_0xa1b3b7)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x1a0af8['containsNonAlphanumericCharacter']||(_0x1a0af8['containsNonAlphanumericCharacter']=_0xca9f1b));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x48928e,_0x5c6bc5,_0x37b90d,_0x4da17a){this['app']=_0x48928e,this['heartbeatServiceProvider']=_0x5c6bc5,this['appCheckServiceProvider']=_0x37b90d,this['config']=_0x4da17a,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x48928e['name'],this['clientVersion']=_0x4da17a['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0xe67405=>this['_resolvePersistenceManagerAvailable']=_0xe67405);}['_initializeWithPersistence'](_0x1de36c,_0x298b78){return _0x298b78&&(this['_popupRedirectResolver']=ie(_0x298b78)),this['_initializationPromise']=this['queue'](async()=>{var _0x24fa47,_0x13156b,_0xce8f2d;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x1de36c),(_0x24fa47=this['_resolvePersistenceManagerAvailable'])==null||_0x24fa47['call'](this),!this['_deleted'])){if((_0x13156b=this['_popupRedirectResolver'])!=null&&_0x13156b['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x298b78),this['lastNotifiedUid']=((_0xce8f2d=this['currentUser'])==null?void 0x0:_0xce8f2d['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x332a42=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x332a42)){if(this['currentUser']&&_0x332a42&&this['currentUser']['uid']===_0x332a42['uid']){this['_currentUser']['_assign'](_0x332a42),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x332a42,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x35a7cf){try{const _0x517959=await Pn(this,{'idToken':_0x35a7cf}),_0x3a30fa=await j['_fromGetAccountInfoResponse'](this,_0x517959,_0x35a7cf);await this['directlySetCurrentUser'](_0x3a30fa);}catch(_0x54535d){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x54535d),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0xa59ca5){var _0x4bfe28;if($(this['app'])){const _0x5290f5=this['app']['settings']['authIdToken'];return _0x5290f5?new Promise(_0x59fd7d=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x5290f5)['then'](_0x59fd7d,_0x59fd7d));}):this['directlySetCurrentUser'](null);}const _0x1647c0=await this['assertedPersistence']['getCurrentUser']();let _0x3fe2bf=_0x1647c0,_0x5695af=!0x1;if(_0xa59ca5&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x5a7836=(_0x4bfe28=this['redirectUser'])==null?void 0x0:_0x4bfe28['_redirectEventId'],_0x2dcb2b=_0x3fe2bf==null?void 0x0:_0x3fe2bf['_redirectEventId'],_0x1f1304=await this['tryRedirectSignIn'](_0xa59ca5);(!_0x5a7836||_0x5a7836===_0x2dcb2b)&&(_0x1f1304!=null&&_0x1f1304['user'])&&(_0x3fe2bf=_0x1f1304['user'],_0x5695af=!0x0);}if(!_0x3fe2bf)return this['directlySetCurrentUser'](null);if(!_0x3fe2bf['_redirectEventId']){if(_0x5695af)try{await this['beforeStateQueue']['runMiddleware'](_0x3fe2bf);}catch(_0x5863b8){_0x3fe2bf=_0x1647c0,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x5863b8));}return _0x3fe2bf?this['reloadAndSetCurrentUserOrClear'](_0x3fe2bf):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x3fe2bf['_redirectEventId']?this['directlySetCurrentUser'](_0x3fe2bf):this['reloadAndSetCurrentUserOrClear'](_0x3fe2bf);}async['tryRedirectSignIn'](_0x573af9){let _0x120540=null;try{_0x120540=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x573af9,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x120540;}async['reloadAndSetCurrentUserOrClear'](_0x4ec64b){try{await Nn(_0x4ec64b);}catch(_0x3abbe8){if((_0x3abbe8==null?void 0x0:_0x3abbe8['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x4ec64b);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x1260d3){if($(this['app']))return Promise['reject'](re(this));const _0x2f0edd=_0x1260d3?P(_0x1260d3):null;return _0x2f0edd&&m(_0x2f0edd['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x2f0edd&&_0x2f0edd['_clone'](this));}async['_updateCurrentUser'](_0x3a0cb1,_0x2591b7=!0x1){if(!this['_deleted'])return _0x3a0cb1&&m(this['tenantId']===_0x3a0cb1['tenantId'],this,'tenant-id-mismatch'),_0x2591b7||await this['beforeStateQueue']['runMiddleware'](_0x3a0cb1),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x3a0cb1),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x13491a){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x13491a));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x35185c){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x1b1cba=this['_getPasswordPolicyInternal']();return _0x1b1cba['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x1b1cba['validatePassword'](_0x35185c);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x1ce9ba=await Pf(this),_0x15ecd5=new Of(_0x1ce9ba);this['tenantId']===null?this['_projectPasswordPolicy']=_0x15ecd5:this['_tenantPasswordPolicies'][this['tenantId']]=_0x15ecd5;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x29c259){this['_errorFactory']=new Gt('auth','Firebase',_0x29c259());}['onAuthStateChanged'](_0x176048,_0x4f0c1f,_0x21c024){return this['registerStateListener'](this['authStateSubscription'],_0x176048,_0x4f0c1f,_0x21c024);}['beforeAuthStateChanged'](_0x410b08,_0x5780fe){return this['beforeStateQueue']['pushCallback'](_0x410b08,_0x5780fe);}['onIdTokenChanged'](_0x5793c7,_0x1f58b8,_0x564372){return this['registerStateListener'](this['idTokenSubscription'],_0x5793c7,_0x1f58b8,_0x564372);}['authStateReady'](){return new Promise((_0x3059f8,_0x5e0cac)=>{if(this['currentUser'])_0x3059f8();else{const _0x536cbd=this['onAuthStateChanged'](()=>{_0x536cbd(),_0x3059f8();},_0x5e0cac);}});}async['revokeAccessToken'](_0x1323c9){if(this['currentUser']){const _0x25badb=await this['currentUser']['getIdToken'](),_0x28b4d5={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x1323c9,'idToken':_0x25badb};this['tenantId']!=null&&(_0x28b4d5['tenantId']=this['tenantId']),await bf(this,_0x28b4d5);}}['toJSON'](){var _0x26bdf0;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x26bdf0=this['_currentUser'])==null?void 0x0:_0x26bdf0['toJSON']()};}async['_setRedirectUser'](_0x433ab1,_0x1cdd8b){const _0xd0ca3a=await this['getOrInitRedirectPersistenceManager'](_0x1cdd8b);return _0x433ab1===null?_0xd0ca3a['removeCurrentUser']():_0xd0ca3a['setCurrentUser'](_0x433ab1);}async['getOrInitRedirectPersistenceManager'](_0x5c3eb8){if(!this['redirectPersistenceManager']){const _0x105691=_0x5c3eb8&&ie(_0x5c3eb8)||this['_popupRedirectResolver'];m(_0x105691,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x105691['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x26e9c2){var _0x39426b,_0x2749fa;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x39426b=this['_currentUser'])==null?void 0x0:_0x39426b['_redirectEventId'])===_0x26e9c2?this['_currentUser']:((_0x2749fa=this['redirectUser'])==null?void 0x0:_0x2749fa['_redirectEventId'])===_0x26e9c2?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x244ed5){if(_0x244ed5===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x244ed5));}['_notifyListenersIfCurrent'](_0x21f8d6){_0x21f8d6===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x36a88a;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x36770e=((_0x36a88a=this['currentUser'])==null?void 0x0:_0x36a88a['uid'])??null;this['lastNotifiedUid']!==_0x36770e&&(this['lastNotifiedUid']=_0x36770e,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x15b461,_0x13b149,_0x1f41bf,_0xba8df9){if(this['_deleted'])return()=>{};const _0x42156e=typeof _0x13b149=='function'?_0x13b149:_0x13b149['next']['bind'](_0x13b149);let _0x2490a0=!0x1;const _0x2b3f6e=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x2b3f6e,this,'internal-error'),_0x2b3f6e['then'](()=>{_0x2490a0||_0x42156e(this['currentUser']);}),typeof _0x13b149=='function'){const _0x34f481=_0x15b461['addObserver'](_0x13b149,_0x1f41bf,_0xba8df9);return()=>{_0x2490a0=!0x0,_0x34f481();};}else{const _0x598b87=_0x15b461['addObserver'](_0x13b149);return()=>{_0x2490a0=!0x0,_0x598b87();};}}async['directlySetCurrentUser'](_0x437a53){this['currentUser']&&this['currentUser']!==_0x437a53&&this['_currentUser']['_stopProactiveRefresh'](),_0x437a53&&this['isProactiveRefreshEnabled']&&_0x437a53['_startProactiveRefresh'](),this['currentUser']=_0x437a53,_0x437a53?await this['assertedPersistence']['setCurrentUser'](_0x437a53):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x34ef3c){return this['operations']=this['operations']['then'](_0x34ef3c,_0x34ef3c),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x91a79){!_0x91a79||this['frameworks']['includes'](_0x91a79)||(this['frameworks']['push'](_0x91a79),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0xe8c9b2;const _0x11e969={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x11e969['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x282e36=await((_0xe8c9b2=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0xe8c9b2['getHeartbeatsHeader']());_0x282e36&&(_0x11e969['X-Firebase-Client']=_0x282e36);const _0x32d81e=await this['_getAppCheckToken']();return _0x32d81e&&(_0x11e969['X-Firebase-AppCheck']=_0x32d81e),_0x11e969;}async['_getAppCheckToken'](){var _0x4055c4;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x3eb598=await((_0x4055c4=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x4055c4['getToken']());return _0x3eb598!=null&&_0x3eb598['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x3eb598['error']),_0x3eb598==null?void 0x0:_0x3eb598['token'];}}function Ke(_0x4385be){return P(_0x4385be);}class Rr{constructor(_0x45d1ca){this['auth']=_0x45d1ca,this['observer']=null,this['addObserver']=Tc(_0x1565b1=>this['observer']=_0x1565b1);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x2314bb){Jn=_0x2314bb;}function xa(_0x5ad96d){return Jn['loadJS'](_0x5ad96d);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x10e356){return'__'+_0x10e356+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x5d95f2){_0x5d95f2();}['execute'](_0x517111,_0x561648){return Promise['resolve']('token');}['render'](_0x5d14ea,_0x41e96e){return'';}}class Wf{['ready'](_0x402a61){_0x402a61();}['execute'](_0x4490db,_0x23f33f){return Promise['resolve']('token');}['render'](_0x5bf4a5,_0x1404cf){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x4d4c2b){this['type']=Bf,this['auth']=Ke(_0x4d4c2b);}async['verify'](_0x16b244='verify',_0x57477d=!0x1){async function _0x4cde5b(_0x3de713){if(!_0x57477d){if(_0x3de713['tenantId']==null&&_0x3de713['_agentRecaptchaConfig']!=null)return _0x3de713['_agentRecaptchaConfig']['siteKey'];if(_0x3de713['tenantId']!=null&&_0x3de713['_tenantRecaptchaConfigs'][_0x3de713['tenantId']]!==void 0x0)return _0x3de713['_tenantRecaptchaConfigs'][_0x3de713['tenantId']]['siteKey'];}return new Promise(async(_0x1c43c3,_0x5d33d2)=>{yf(_0x3de713,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0xd4f118=>{if(_0xd4f118['recaptchaKey']===void 0x0)_0x5d33d2(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x2d07d6=new mf(_0xd4f118);return _0x3de713['tenantId']==null?_0x3de713['_agentRecaptchaConfig']=_0x2d07d6:_0x3de713['_tenantRecaptchaConfigs'][_0x3de713['tenantId']]=_0x2d07d6,_0x1c43c3(_0x2d07d6['siteKey']);}})['catch'](_0x2a3216=>{_0x5d33d2(_0x2a3216);});});}function _0x359544(_0x414182,_0x25669c,_0x45d7d0){const _0x25c3d5=window['grecaptcha'];wr(_0x25c3d5)?_0x25c3d5['enterprise']['ready'](()=>{_0x25c3d5['enterprise']['execute'](_0x414182,{'action':_0x16b244})['then'](_0x20416e=>{_0x25669c(_0x20416e);})['catch'](()=>{_0x25669c(Fa);});}):_0x45d7d0(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x440c68,_0xd041b2)=>{_0x4cde5b(this['auth'])['then'](async _0x305d2a=>{if(!_0x57477d&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x359544(_0x305d2a,_0x440c68,_0xd041b2);else{if(typeof window>'u'){_0xd041b2(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x7b58d0=Lf();_0x7b58d0['length']!==0x0&&(_0x7b58d0+=_0x305d2a+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x46d527;(_0x46d527=he['scriptInjectionDeferred'])==null||_0x46d527['resolve']();},xa(_0x7b58d0)['then'](()=>{var _0x31b28c;return(_0x31b28c=he['scriptInjectionDeferred'])==null?void 0x0:_0x31b28c['promise'];})['then'](()=>{_0x359544(_0x305d2a,_0x440c68,_0xd041b2);})['catch'](_0xddacdb=>{_0xd041b2(_0xddacdb);});}})['catch'](_0x5d5a00=>{_0xd041b2(_0x5d5a00);});});}}he['scriptInjectionDeferred']=null;async function kr(_0xdb3167,_0x304353,_0x1879b5,_0xd7562f=!0x1,_0x40b608=!0x1){const _0x1eaee0=new he(_0xdb3167);let _0x1a13d1;if(_0x40b608)_0x1a13d1=Fa;else try{_0x1a13d1=await _0x1eaee0['verify'](_0x1879b5);}catch{_0x1a13d1=await _0x1eaee0['verify'](_0x1879b5,!0x0);}const _0x21d653={..._0x304353};if(_0x1879b5==='mfaSmsEnrollment'||_0x1879b5==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x21d653){const _0x43dc29=_0x21d653['phoneEnrollmentInfo']['phoneNumber'],_0x27bfc3=_0x21d653['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x21d653,{'phoneEnrollmentInfo':{'phoneNumber':_0x43dc29,'recaptchaToken':_0x27bfc3,'captchaResponse':_0x1a13d1,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x21d653){const _0x336508=_0x21d653['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x21d653,{'phoneSignInInfo':{'recaptchaToken':_0x336508,'captchaResponse':_0x1a13d1,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x21d653;}return _0xd7562f?Object['assign'](_0x21d653,{'captchaResp':_0x1a13d1}):Object['assign'](_0x21d653,{'captchaResponse':_0x1a13d1}),Object['assign'](_0x21d653,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x21d653,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x21d653;}async function xi(_0x4b0e04,_0x267fbc,_0xb5ab37,_0x582460,_0x383707){var _0x48d218;if((_0x48d218=_0x4b0e04['_getRecaptchaConfig']())!=null&&_0x48d218['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x1bd243=await kr(_0x4b0e04,_0x267fbc,_0xb5ab37,_0xb5ab37==='getOobCode');return _0x582460(_0x4b0e04,_0x1bd243);}else return _0x582460(_0x4b0e04,_0x267fbc)['catch'](async _0xff84e5=>{if(_0xff84e5['code']==='auth/missing-recaptcha-token'){console['log'](_0xb5ab37+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x283bb9=await kr(_0x4b0e04,_0x267fbc,_0xb5ab37,_0xb5ab37==='getOobCode');return _0x582460(_0x4b0e04,_0x283bb9);}else return Promise['reject'](_0xff84e5);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x49869e,_0x40bcd6){const _0x4670b9=Hi(_0x49869e,'auth');if(_0x4670b9['isInitialized']()){const _0x17aa82=_0x4670b9['getImmediate'](),_0x12c2a6=_0x4670b9['getOptions']();if(xe(_0x12c2a6,_0x40bcd6??{}))return _0x17aa82;Y(_0x17aa82,'already-initialized');}return _0x4670b9['initialize']({'options':_0x40bcd6});}function Hf(_0x1a21a1,_0x31661d){const _0x2f6494=(_0x31661d==null?void 0x0:_0x31661d['persistence'])||[],_0x44ad49=(Array['isArray'](_0x2f6494)?_0x2f6494:[_0x2f6494])['map'](ie);_0x31661d!=null&&_0x31661d['errorMap']&&_0x1a21a1['_updateErrorMap'](_0x31661d['errorMap']),_0x1a21a1['_initializeWithPersistence'](_0x44ad49,_0x31661d==null?void 0x0:_0x31661d['popupRedirectResolver']);}function $f(_0x43c673,_0x15034e,_0x3a7f2e){const _0x567daf=Ke(_0x43c673);m(/^https?:\/\//['test'](_0x15034e),_0x567daf,'invalid-emulator-scheme');const _0x45fec1=!0x1,_0x7814f0=Ua(_0x15034e),{host:_0x3019d7,port:_0x5e9d77}=Gf(_0x15034e),_0x4d0a1a=_0x5e9d77===null?'':':'+_0x5e9d77,_0x3b1899={'url':_0x7814f0+'//'+_0x3019d7+_0x4d0a1a+'/'},_0x2761dc=Object['freeze']({'host':_0x3019d7,'port':_0x5e9d77,'protocol':_0x7814f0['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x45fec1})});if(!_0x567daf['_canInitEmulator']){m(_0x567daf['config']['emulator']&&_0x567daf['emulatorConfig'],_0x567daf,'emulator-config-failed'),m(xe(_0x3b1899,_0x567daf['config']['emulator'])&&xe(_0x2761dc,_0x567daf['emulatorConfig']),_0x567daf,'emulator-config-failed');return;}_0x567daf['config']['emulator']=_0x3b1899,_0x567daf['emulatorConfig']=_0x2761dc,_0x567daf['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x3019d7)?Qr(_0x7814f0+'//'+_0x3019d7+_0x4d0a1a):qf();}function Ua(_0x6e9607){const _0x58c3f3=_0x6e9607['indexOf'](':');return _0x58c3f3<0x0?'':_0x6e9607['substr'](0x0,_0x58c3f3+0x1);}function Gf(_0x19caf2){const _0x30d0b3=Ua(_0x19caf2),_0x23cd1d=/(\/\/)?([^?#/]+)/['exec'](_0x19caf2['substr'](_0x30d0b3['length']));if(!_0x23cd1d)return{'host':'','port':null};const _0x2f8852=_0x23cd1d[0x2]['split']('@')['pop']()||'',_0x2e339a=/^(\[[^\]]+\])(:|$)/['exec'](_0x2f8852);if(_0x2e339a){const _0x16bb52=_0x2e339a[0x1];return{'host':_0x16bb52,'port':Pr(_0x2f8852['substr'](_0x16bb52['length']+0x1))};}else{const [_0x35f5cb,_0x51b582]=_0x2f8852['split'](':');return{'host':_0x35f5cb,'port':Pr(_0x51b582)};}}function Pr(_0x493df9){if(!_0x493df9)return null;const _0x77f251=Number(_0x493df9);return isNaN(_0x77f251)?null:_0x77f251;}function qf(){function _0x255cff(){const _0xf7e510=document['createElement']('p'),_0x40d13d=_0xf7e510['style'];_0xf7e510['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x40d13d['position']='fixed',_0x40d13d['width']='100%',_0x40d13d['backgroundColor']='#ffffff',_0x40d13d['border']='.1em\x20solid\x20#000000',_0x40d13d['color']='#b50000',_0x40d13d['bottom']='0px',_0x40d13d['left']='0px',_0x40d13d['margin']='0px',_0x40d13d['zIndex']='10000',_0x40d13d['textAlign']='center',_0xf7e510['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0xf7e510);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x255cff):_0x255cff());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x5045fe,_0x122e12){this['providerId']=_0x5045fe,this['signInMethod']=_0x122e12;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0xd4caa7){return ne('not\x20implemented');}['_linkToIdToken'](_0x2dc37a,_0x31ea74){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0xa242d1){return ne('not\x20implemented');}}async function zf(_0x4aabfe,_0x26755b){return Pe(_0x4aabfe,'POST','/v1/accounts:signUp',_0x26755b);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0xd2516d,_0x391ce0){return en(_0xd2516d,'POST','/v1/accounts:signInWithPassword',ke(_0xd2516d,_0x391ce0));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x1f506f,_0x58d930){return en(_0x1f506f,'POST','/v1/accounts:signInWithEmailLink',ke(_0x1f506f,_0x58d930));}async function Yf(_0x3426c7,_0x578040){return en(_0x3426c7,'POST','/v1/accounts:signInWithEmailLink',ke(_0x3426c7,_0x578040));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x140423,_0x46b29e,_0xeb329c,_0x381203=null){super('password',_0xeb329c),this['_email']=_0x140423,this['_password']=_0x46b29e,this['_tenantId']=_0x381203;}static['_fromEmailAndPassword'](_0x587378,_0x7ffe24){return new $t(_0x587378,_0x7ffe24,'password');}static['_fromEmailAndCode'](_0x1f2565,_0x5cc741,_0xa3075b=null){return new $t(_0x1f2565,_0x5cc741,'emailLink',_0xa3075b);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x31eaa8){const _0x5c0f95=typeof _0x31eaa8=='string'?JSON['parse'](_0x31eaa8):_0x31eaa8;if(_0x5c0f95!=null&&_0x5c0f95['email']&&(_0x5c0f95!=null&&_0x5c0f95['password'])){if(_0x5c0f95['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x5c0f95['email'],_0x5c0f95['password']);if(_0x5c0f95['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x5c0f95['email'],_0x5c0f95['password'],_0x5c0f95['tenantId']);}return null;}async['_getIdTokenResponse'](_0x257fed){switch(this['signInMethod']){case'password':const _0x2a87de={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x257fed,_0x2a87de,'signInWithPassword',jf);case'emailLink':return Kf(_0x257fed,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x257fed,'internal-error');}}async['_linkToIdToken'](_0xcae438,_0x50226b){switch(this['signInMethod']){case'password':const _0x587bf5={'idToken':_0x50226b,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0xcae438,_0x587bf5,'signUpPassword',zf);case'emailLink':return Yf(_0xcae438,{'idToken':_0x50226b,'email':this['_email'],'oobCode':this['_password']});default:Y(_0xcae438,'internal-error');}}['_getReauthenticationResolver'](_0x54acd4){return this['_getIdTokenResponse'](_0x54acd4);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x3942bc,_0xb478f0){return en(_0x3942bc,'POST','/v1/accounts:signInWithIdp',ke(_0x3942bc,_0xb478f0));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x28b846){const _0x3fd7ba=new $e(_0x28b846['providerId'],_0x28b846['signInMethod']);return _0x28b846['idToken']||_0x28b846['accessToken']?(_0x28b846['idToken']&&(_0x3fd7ba['idToken']=_0x28b846['idToken']),_0x28b846['accessToken']&&(_0x3fd7ba['accessToken']=_0x28b846['accessToken']),_0x28b846['nonce']&&!_0x28b846['pendingToken']&&(_0x3fd7ba['nonce']=_0x28b846['nonce']),_0x28b846['pendingToken']&&(_0x3fd7ba['pendingToken']=_0x28b846['pendingToken'])):_0x28b846['oauthToken']&&_0x28b846['oauthTokenSecret']?(_0x3fd7ba['accessToken']=_0x28b846['oauthToken'],_0x3fd7ba['secret']=_0x28b846['oauthTokenSecret']):Y('argument-error'),_0x3fd7ba;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x105dbe){const _0x461f92=typeof _0x105dbe=='string'?JSON['parse'](_0x105dbe):_0x105dbe,{providerId:_0x4d50ab,signInMethod:_0x1ef8aa,..._0x5ef54c}=_0x461f92;if(!_0x4d50ab||!_0x1ef8aa)return null;const _0x26b3ba=new $e(_0x4d50ab,_0x1ef8aa);return _0x26b3ba['idToken']=_0x5ef54c['idToken']||void 0x0,_0x26b3ba['accessToken']=_0x5ef54c['accessToken']||void 0x0,_0x26b3ba['secret']=_0x5ef54c['secret'],_0x26b3ba['nonce']=_0x5ef54c['nonce'],_0x26b3ba['pendingToken']=_0x5ef54c['pendingToken']||null,_0x26b3ba;}['_getIdTokenResponse'](_0x54b8fb){const _0x118694=this['buildRequest']();return nt(_0x54b8fb,_0x118694);}['_linkToIdToken'](_0x521c36,_0x4fb8b8){const _0x2bc5b3=this['buildRequest']();return _0x2bc5b3['idToken']=_0x4fb8b8,nt(_0x521c36,_0x2bc5b3);}['_getReauthenticationResolver'](_0x4fd59f){const _0x357311=this['buildRequest']();return _0x357311['autoCreate']=!0x1,nt(_0x4fd59f,_0x357311);}['buildRequest'](){const _0x41241b={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x41241b['pendingToken']=this['pendingToken'];else{const _0x42dc6d={};this['idToken']&&(_0x42dc6d['id_token']=this['idToken']),this['accessToken']&&(_0x42dc6d['access_token']=this['accessToken']),this['secret']&&(_0x42dc6d['oauth_token_secret']=this['secret']),_0x42dc6d['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x42dc6d['nonce']=this['nonce']),_0x41241b['postBody']=ut(_0x42dc6d);}return _0x41241b;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x5f3b65){switch(_0x5f3b65){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x19dfe9){const _0x5479e2=Ct(Tt(_0x19dfe9))['link'],_0x31dc83=_0x5479e2?Ct(Tt(_0x5479e2))['deep_link_id']:null,_0x10b0da=Ct(Tt(_0x19dfe9))['deep_link_id'];return(_0x10b0da?Ct(Tt(_0x10b0da))['link']:null)||_0x10b0da||_0x31dc83||_0x5479e2||_0x19dfe9;}class Rs{constructor(_0x429bff){const _0x5df270=Ct(Tt(_0x429bff)),_0x5343b4=_0x5df270['apiKey']??null,_0x40fce6=_0x5df270['oobCode']??null,_0x1101e0=Jf(_0x5df270['mode']??null);m(_0x5343b4&&_0x40fce6&&_0x1101e0,'argument-error'),this['apiKey']=_0x5343b4,this['operation']=_0x1101e0,this['code']=_0x40fce6,this['continueUrl']=_0x5df270['continueUrl']??null,this['languageCode']=_0x5df270['lang']??null,this['tenantId']=_0x5df270['tenantId']??null;}static['parseLink'](_0xb22c0d){const _0x1200fe=Xf(_0xb22c0d);try{return new Rs(_0x1200fe);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x1b979f,_0x5c5c33){return $t['_fromEmailAndPassword'](_0x1b979f,_0x5c5c33);}static['credentialWithLink'](_0x11a795,_0x3827fa){const _0x5d69e4=Rs['parseLink'](_0x3827fa);return m(_0x5d69e4,'argument-error'),$t['_fromEmailAndCode'](_0x11a795,_0x5d69e4['code'],_0x5d69e4['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x419d92){this['providerId']=_0x419d92,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x28869c){this['defaultLanguageCode']=_0x28869c;}['setCustomParameters'](_0x352601){return this['customParameters']=_0x352601,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0xcff20c){return this['scopes']['includes'](_0xcff20c)||this['scopes']['push'](_0xcff20c),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x1fbc90){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x1fbc90});}static['credentialFromResult'](_0x44c146){return ue['credentialFromTaggedObject'](_0x44c146);}static['credentialFromError'](_0x42a57d){return ue['credentialFromTaggedObject'](_0x42a57d['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x133b0b}){if(!_0x133b0b||!('oauthAccessToken'in _0x133b0b)||!_0x133b0b['oauthAccessToken'])return null;try{return ue['credential'](_0x133b0b['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x44c2cd,_0x119fbd){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x44c2cd,'accessToken':_0x119fbd});}static['credentialFromResult'](_0x534444){return de['credentialFromTaggedObject'](_0x534444);}static['credentialFromError'](_0xb36eb){return de['credentialFromTaggedObject'](_0xb36eb['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x21dff4}){if(!_0x21dff4)return null;const {oauthIdToken:_0x679eab,oauthAccessToken:_0x136a41}=_0x21dff4;if(!_0x679eab&&!_0x136a41)return null;try{return de['credential'](_0x679eab,_0x136a41);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x1a04d0){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x1a04d0});}static['credentialFromResult'](_0x22902b){return fe['credentialFromTaggedObject'](_0x22902b);}static['credentialFromError'](_0x5c9366){return fe['credentialFromTaggedObject'](_0x5c9366['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x2e7901}){if(!_0x2e7901||!('oauthAccessToken'in _0x2e7901)||!_0x2e7901['oauthAccessToken'])return null;try{return fe['credential'](_0x2e7901['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x2c15ad,_0x24cebf){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x2c15ad,'oauthTokenSecret':_0x24cebf});}static['credentialFromResult'](_0x240644){return pe['credentialFromTaggedObject'](_0x240644);}static['credentialFromError'](_0x2e4c77){return pe['credentialFromTaggedObject'](_0x2e4c77['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5004c1}){if(!_0x5004c1)return null;const {oauthAccessToken:_0x390858,oauthTokenSecret:_0x1e16dd}=_0x5004c1;if(!_0x390858||!_0x1e16dd)return null;try{return pe['credential'](_0x390858,_0x1e16dd);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x56e6aa,_0x9ab48d){return en(_0x56e6aa,'POST','/v1/accounts:signUp',ke(_0x56e6aa,_0x9ab48d));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x114e72){this['user']=_0x114e72['user'],this['providerId']=_0x114e72['providerId'],this['_tokenResponse']=_0x114e72['_tokenResponse'],this['operationType']=_0x114e72['operationType'];}static async['_fromIdTokenResponse'](_0x46ca38,_0x5845a3,_0x2c85c8,_0x5aa739=!0x1){const _0x308986=await j['_fromIdTokenResponse'](_0x46ca38,_0x2c85c8,_0x5aa739),_0x326a65=Nr(_0x2c85c8);return new Ge({'user':_0x308986,'providerId':_0x326a65,'_tokenResponse':_0x2c85c8,'operationType':_0x5845a3});}static async['_forOperation'](_0x3bd21b,_0xe1b7fe,_0x1bf91c){await _0x3bd21b['_updateTokensIfNecessary'](_0x1bf91c,!0x0);const _0x580ce9=Nr(_0x1bf91c);return new Ge({'user':_0x3bd21b,'providerId':_0x580ce9,'_tokenResponse':_0x1bf91c,'operationType':_0xe1b7fe});}}function Nr(_0x5624bf){return _0x5624bf['providerId']?_0x5624bf['providerId']:'phoneNumber'in _0x5624bf?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x183376,_0x54e88b,_0x82d5e8,_0x1fcbad){super(_0x54e88b['code'],_0x54e88b['message']),this['operationType']=_0x82d5e8,this['user']=_0x1fcbad,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x183376['name'],'tenantId':_0x183376['tenantId']??void 0x0,'_serverResponse':_0x54e88b['customData']['_serverResponse'],'operationType':_0x82d5e8};}static['_fromErrorAndOperation'](_0x166e91,_0x2c010a,_0x12d056,_0xbdedc){return new On(_0x166e91,_0x2c010a,_0x12d056,_0xbdedc);}}function Ba(_0x4c36fb,_0x250ff2,_0x2ee245,_0x5a447d){return(_0x250ff2==='reauthenticate'?_0x2ee245['_getReauthenticationResolver'](_0x4c36fb):_0x2ee245['_getIdTokenResponse'](_0x4c36fb))['catch'](_0x10b794=>{throw _0x10b794['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x4c36fb,_0x10b794,_0x250ff2,_0x5a447d):_0x10b794;});}async function ep(_0x52fca3,_0x2083c1,_0x52f39f=!0x1){const _0x385901=await Ht(_0x52fca3,_0x2083c1['_linkToIdToken'](_0x52fca3['auth'],await _0x52fca3['getIdToken']()),_0x52f39f);return Ge['_forOperation'](_0x52fca3,'link',_0x385901);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x36a22c,_0x2aee48,_0x108e47=!0x1){const {auth:_0xf3e5a9}=_0x36a22c;if($(_0xf3e5a9['app']))return Promise['reject'](re(_0xf3e5a9));const _0x57e28e='reauthenticate';try{const _0x443e24=await Ht(_0x36a22c,Ba(_0xf3e5a9,_0x57e28e,_0x2aee48,_0x36a22c),_0x108e47);m(_0x443e24['idToken'],_0xf3e5a9,'internal-error');const _0x36239a=Ts(_0x443e24['idToken']);m(_0x36239a,_0xf3e5a9,'internal-error');const {sub:_0xd93079}=_0x36239a;return m(_0x36a22c['uid']===_0xd93079,_0xf3e5a9,'user-mismatch'),Ge['_forOperation'](_0x36a22c,_0x57e28e,_0x443e24);}catch(_0xbde7e2){throw(_0xbde7e2==null?void 0x0:_0xbde7e2['code'])==='auth/user-not-found'&&Y(_0xf3e5a9,'user-mismatch'),_0xbde7e2;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x59073d,_0x4da4b8,_0x20ebc6=!0x1){if($(_0x59073d['app']))return Promise['reject'](re(_0x59073d));const _0x54c416='signIn',_0x1edd9c=await Ba(_0x59073d,_0x54c416,_0x4da4b8),_0x1ad077=await Ge['_fromIdTokenResponse'](_0x59073d,_0x54c416,_0x1edd9c);return _0x20ebc6||await _0x59073d['_updateCurrentUser'](_0x1ad077['user']),_0x1ad077;}async function np(_0x506388,_0x52f719){return Va(Ke(_0x506388),_0x52f719);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x68291){const _0x34abd9=Ke(_0x68291);_0x34abd9['_getPasswordPolicyInternal']()&&await _0x34abd9['_updatePasswordPolicy']();}async function L_(_0x1530c1,_0x5e3f3,_0x5060da){if($(_0x1530c1['app']))return Promise['reject'](re(_0x1530c1));const _0x3a6598=Ke(_0x1530c1),_0x198e36=await xi(_0x3a6598,{'returnSecureToken':!0x0,'email':_0x5e3f3,'password':_0x5060da,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x28a62f=>{throw _0x28a62f['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x1530c1),_0x28a62f;}),_0x13a9fe=await Ge['_fromIdTokenResponse'](_0x3a6598,'signIn',_0x198e36);return await _0x3a6598['_updateCurrentUser'](_0x13a9fe['user']),_0x13a9fe;}function x_(_0x44c9ba,_0x1766c1,_0x436614){return $(_0x44c9ba['app'])?Promise['reject'](re(_0x44c9ba)):np(P(_0x44c9ba),yt['credential'](_0x1766c1,_0x436614))['catch'](async _0xef566d=>{throw _0xef566d['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x44c9ba),_0xef566d;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x38e054,_0x116e12){return P(_0x38e054)['setPersistence'](_0x116e12);}function ip(_0x5695a8,_0x4386f0,_0x1e6f2b,_0x58808f){return P(_0x5695a8)['onIdTokenChanged'](_0x4386f0,_0x1e6f2b,_0x58808f);}function sp(_0x29dcd6,_0x3c8df5,_0x1e6f8d){return P(_0x29dcd6)['beforeAuthStateChanged'](_0x3c8df5,_0x1e6f8d);}function U_(_0x164c17,_0x41a958,_0x3a6426,_0x3345fb){return P(_0x164c17)['onAuthStateChanged'](_0x41a958,_0x3a6426,_0x3345fb);}function W_(_0x153ded){return P(_0x153ded)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x238a3f,_0xd85c54){this['storageRetriever']=_0x238a3f,this['type']=_0xd85c54;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x38e284,_0x15e56d){return this['storage']['setItem'](_0x38e284,JSON['stringify'](_0x15e56d)),Promise['resolve']();}['_get'](_0x3acc09){const _0x34555d=this['storage']['getItem'](_0x3acc09);return Promise['resolve'](_0x34555d?JSON['parse'](_0x34555d):null);}['_remove'](_0x460527){return this['storage']['removeItem'](_0x460527),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x5b8bef,_0x29f486)=>this['onStorageEvent'](_0x5b8bef,_0x29f486),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x5e31d2){for(const _0x38c6af of Object['keys'](this['listeners'])){const _0x11be65=this['storage']['getItem'](_0x38c6af),_0x2ce351=this['localCache'][_0x38c6af];_0x11be65!==_0x2ce351&&_0x5e31d2(_0x38c6af,_0x2ce351,_0x11be65);}}['onStorageEvent'](_0x26b281,_0x50e075=!0x1){if(!_0x26b281['key']){this['forAllChangedKeys']((_0x2f04cf,_0x30c270,_0x4e1dcb)=>{this['notifyListeners'](_0x2f04cf,_0x4e1dcb);});return;}const _0x2d2dfc=_0x26b281['key'];_0x50e075?this['detachListener']():this['stopPolling']();const _0x311b6a=()=>{const _0x2c2c8c=this['storage']['getItem'](_0x2d2dfc);!_0x50e075&&this['localCache'][_0x2d2dfc]===_0x2c2c8c||this['notifyListeners'](_0x2d2dfc,_0x2c2c8c);},_0x4c12e6=this['storage']['getItem'](_0x2d2dfc);Af()&&_0x4c12e6!==_0x26b281['newValue']&&_0x26b281['newValue']!==_0x26b281['oldValue']?setTimeout(_0x311b6a,op):_0x311b6a();}['notifyListeners'](_0x2b69a8,_0x2e48c2){this['localCache'][_0x2b69a8]=_0x2e48c2;const _0x1800ca=this['listeners'][_0x2b69a8];if(_0x1800ca){for(const _0x449fab of Array['from'](_0x1800ca))_0x449fab(_0x2e48c2&&JSON['parse'](_0x2e48c2));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x3dbf79,_0x5d8762,_0x37cd07)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x3dbf79,'oldValue':_0x5d8762,'newValue':_0x37cd07}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x34ae78,_0x1c0b4a){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x34ae78]||(this['listeners'][_0x34ae78]=new Set(),this['localCache'][_0x34ae78]=this['storage']['getItem'](_0x34ae78)),this['listeners'][_0x34ae78]['add'](_0x1c0b4a);}['_removeListener'](_0x1bd970,_0xe0440e){this['listeners'][_0x1bd970]&&(this['listeners'][_0x1bd970]['delete'](_0xe0440e),this['listeners'][_0x1bd970]['size']===0x0&&delete this['listeners'][_0x1bd970]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x187958,_0xae8af){await super['_set'](_0x187958,_0xae8af),this['localCache'][_0x187958]=JSON['stringify'](_0xae8af);}async['_get'](_0xe2dcf5){const _0x275a58=await super['_get'](_0xe2dcf5);return this['localCache'][_0xe2dcf5]=JSON['stringify'](_0x275a58),_0x275a58;}async['_remove'](_0x3f4eb5){await super['_remove'](_0x3f4eb5),delete this['localCache'][_0x3f4eb5];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x2397c6,_0xb746fd){}['_removeListener'](_0x4ea1b9,_0x42ea2e){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x5bfceb){return Promise['all'](_0x5bfceb['map'](async _0x1addeb=>{try{return{'fulfilled':!0x0,'value':await _0x1addeb};}catch(_0x3007b2){return{'fulfilled':!0x1,'reason':_0x3007b2};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x1a053c){this['eventTarget']=_0x1a053c,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x4e38c2){const _0x1450c6=this['receivers']['find'](_0x156d4b=>_0x156d4b['isListeningto'](_0x4e38c2));if(_0x1450c6)return _0x1450c6;const _0x2c86f8=new Xn(_0x4e38c2);return this['receivers']['push'](_0x2c86f8),_0x2c86f8;}['isListeningto'](_0x818b01){return this['eventTarget']===_0x818b01;}async['handleEvent'](_0x39e9b3){const _0x471e17=_0x39e9b3,{eventId:_0x4bcbdb,eventType:_0x38c6b2,data:_0x2274ae}=_0x471e17['data'],_0x55e213=this['handlersMap'][_0x38c6b2];if(!(_0x55e213!=null&&_0x55e213['size']))return;_0x471e17['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x4bcbdb,'eventType':_0x38c6b2});const _0x2b37d5=Array['from'](_0x55e213)['map'](async _0x8b4c75=>_0x8b4c75(_0x471e17['origin'],_0x2274ae)),_0x2b621f=await cp(_0x2b37d5);_0x471e17['ports'][0x0]['postMessage']({'status':'done','eventId':_0x4bcbdb,'eventType':_0x38c6b2,'response':_0x2b621f});}['_subscribe'](_0x5cfdfe,_0x29fe6c){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x5cfdfe]||(this['handlersMap'][_0x5cfdfe]=new Set()),this['handlersMap'][_0x5cfdfe]['add'](_0x29fe6c);}['_unsubscribe'](_0x2b7827,_0x3fc78e){this['handlersMap'][_0x2b7827]&&_0x3fc78e&&this['handlersMap'][_0x2b7827]['delete'](_0x3fc78e),(!_0x3fc78e||this['handlersMap'][_0x2b7827]['size']===0x0)&&delete this['handlersMap'][_0x2b7827],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x29fe8d='',_0x422c4d=0xa){let _0x5889e6='';for(let _0x27ecd9=0x0;_0x27ecd9<_0x422c4d;_0x27ecd9++)_0x5889e6+=Math['floor'](Math['random']()*0xa);return _0x29fe8d+_0x5889e6;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x16c6c1){this['target']=_0x16c6c1,this['handlers']=new Set();}['removeMessageHandler'](_0x3225fd){_0x3225fd['messageChannel']&&(_0x3225fd['messageChannel']['port1']['removeEventListener']('message',_0x3225fd['onMessage']),_0x3225fd['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x3225fd);}async['_send'](_0x109ce6,_0x2ecd4a,_0x451a63=0x32){const _0x135fba=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x135fba)throw new Error('connection_unavailable');let _0x1022c0,_0x35714f;return new Promise((_0x13619f,_0x4a68d8)=>{const _0x33aa4c=As('',0x14);_0x135fba['port1']['start']();const _0x1912d2=setTimeout(()=>{_0x4a68d8(new Error('unsupported_event'));},_0x451a63);_0x35714f={'messageChannel':_0x135fba,'onMessage'(_0x150d04){const _0x171aa0=_0x150d04;if(_0x171aa0['data']['eventId']===_0x33aa4c)switch(_0x171aa0['data']['status']){case'ack':clearTimeout(_0x1912d2),_0x1022c0=setTimeout(()=>{_0x4a68d8(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x1022c0),_0x13619f(_0x171aa0['data']['response']);break;default:clearTimeout(_0x1912d2),clearTimeout(_0x1022c0),_0x4a68d8(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x35714f),_0x135fba['port1']['addEventListener']('message',_0x35714f['onMessage']),this['target']['postMessage']({'eventType':_0x109ce6,'eventId':_0x33aa4c,'data':_0x2ecd4a},[_0x135fba['port2']]);})['finally'](()=>{_0x35714f&&this['removeMessageHandler'](_0x35714f);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x299e1f){Z()['location']['href']=_0x299e1f;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x59750b;return((_0x59750b=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x59750b['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x149333){this['request']=_0x149333;}['toPromise'](){return new Promise((_0x39befa,_0x2c3a2e)=>{this['request']['addEventListener']('success',()=>{_0x39befa(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x2c3a2e(this['request']['error']);});});}}function Zn(_0x2cd45b,_0x5a0868){return _0x2cd45b['transaction']([Mn],_0x5a0868?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x27e4d1=indexedDB['deleteDatabase'](Ka);return new nn(_0x27e4d1)['toPromise']();}function Qa(){const _0x35673c=indexedDB['open'](Ka,pp);return new Promise((_0x30a7d9,_0x25427b)=>{_0x35673c['addEventListener']('error',()=>{_0x25427b(_0x35673c['error']);}),_0x35673c['addEventListener']('upgradeneeded',()=>{const _0x59ef8b=_0x35673c['result'];try{_0x59ef8b['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x3abb66){_0x25427b(_0x3abb66);}}),_0x35673c['addEventListener']('success',async()=>{const _0x16c7da=_0x35673c['result'];_0x16c7da['objectStoreNames']['contains'](Mn)?_0x30a7d9(_0x16c7da):(_0x16c7da['close'](),await _p(),_0x30a7d9(await Qa()));});});}async function Or(_0x1aae7c,_0x4e4e54,_0x2b06cb){const _0x21e8a1=Zn(_0x1aae7c,!0x0)['put']({[Ya]:_0x4e4e54,'value':_0x2b06cb});return new nn(_0x21e8a1)['toPromise']();}async function gp(_0x2daca2,_0x150f52){const _0xc6bac9=Zn(_0x2daca2,!0x1)['get'](_0x150f52),_0x4ff24f=await new nn(_0xc6bac9)['toPromise']();return _0x4ff24f===void 0x0?null:_0x4ff24f['value'];}function Dr(_0x250019,_0xa2202e){const _0x367bbd=Zn(_0x250019,!0x0)['delete'](_0xa2202e);return new nn(_0x367bbd)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x2661ae){let _0x4540c3=0x0;for(;;)try{const _0xd0a59e=await this['_openDb']();return await _0x2661ae(_0xd0a59e);}catch(_0x48d787){if(_0x4540c3++>yp)throw _0x48d787;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x510134,_0x4b2618)=>({'keyProcessed':(await this['_poll']())['includes'](_0x4b2618['key'])})),this['receiver']['_subscribe']('ping',async(_0x3effb2,_0x26a6bb)=>['keyChanged']);}async['initializeSender'](){var _0x165984,_0x287977;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x31a438=await this['sender']['_send']('ping',{},0x320);_0x31a438&&(_0x165984=_0x31a438[0x0])!=null&&_0x165984['fulfilled']&&(_0x287977=_0x31a438[0x0])!=null&&_0x287977['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x4ce020){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x4ce020},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x2be37a=>{await Or(_0x2be37a,Dn,'1'),await Dr(_0x2be37a,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x2bfe9b){this['pendingWrites']++;try{await _0x2bfe9b();}finally{this['pendingWrites']--;}}async['_set'](_0x1320b4,_0x595541){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x2e6964=>Or(_0x2e6964,_0x1320b4,_0x595541)),this['localCache'][_0x1320b4]=_0x595541,this['notifyServiceWorker'](_0x1320b4)));}async['_get'](_0x3e857b){const _0x11d0d5=await this['_withRetries'](_0x1a7d25=>gp(_0x1a7d25,_0x3e857b));return this['localCache'][_0x3e857b]=_0x11d0d5,_0x11d0d5;}async['_remove'](_0x49e12b){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x11ebbb=>Dr(_0x11ebbb,_0x49e12b)),delete this['localCache'][_0x49e12b],this['notifyServiceWorker'](_0x49e12b)));}async['_poll'](){const _0x4524fa=await this['_withRetries'](_0x55dd0f=>{const _0x4ceb95=Zn(_0x55dd0f,!0x1)['getAll']();return new nn(_0x4ceb95)['toPromise']();});if(!_0x4524fa)return[];if(this['pendingWrites']!==0x0)return[];const _0x935d4c=[],_0x3bfe9a=new Set();if(_0x4524fa['length']!==0x0){for(const {fbase_key:_0xe7eca5,value:_0x948f8a}of _0x4524fa)_0x3bfe9a['add'](_0xe7eca5),JSON['stringify'](this['localCache'][_0xe7eca5])!==JSON['stringify'](_0x948f8a)&&(this['notifyListeners'](_0xe7eca5,_0x948f8a),_0x935d4c['push'](_0xe7eca5));}for(const _0x180dd0 of Object['keys'](this['localCache']))this['localCache'][_0x180dd0]&&!_0x3bfe9a['has'](_0x180dd0)&&(this['notifyListeners'](_0x180dd0,null),_0x935d4c['push'](_0x180dd0));return _0x935d4c;}['notifyListeners'](_0x5c0de0,_0x4178c1){this['localCache'][_0x5c0de0]=_0x4178c1;const _0x658fbf=this['listeners'][_0x5c0de0];if(_0x658fbf){for(const _0x5deebb of Array['from'](_0x658fbf))_0x5deebb(_0x4178c1);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x4cd0bf,_0x90b2ff){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x4cd0bf]||(this['listeners'][_0x4cd0bf]=new Set(),this['_get'](_0x4cd0bf)),this['listeners'][_0x4cd0bf]['add'](_0x90b2ff);}['_removeListener'](_0x3e34cd,_0x41baa2){this['listeners'][_0x3e34cd]&&(this['listeners'][_0x3e34cd]['delete'](_0x41baa2),this['listeners'][_0x3e34cd]['size']===0x0&&delete this['listeners'][_0x3e34cd]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x207939,_0x2aa770){return _0x2aa770?ie(_0x2aa770):(m(_0x207939['_popupRedirectResolver'],_0x207939,'argument-error'),_0x207939['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x45ee9e){super('custom','custom'),this['params']=_0x45ee9e;}['_getIdTokenResponse'](_0x55e307){return nt(_0x55e307,this['_buildIdpRequest']());}['_linkToIdToken'](_0x169f6f,_0x1e0f57){return nt(_0x169f6f,this['_buildIdpRequest'](_0x1e0f57));}['_getReauthenticationResolver'](_0x59b4ac){return nt(_0x59b4ac,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x21987e){const _0x5e3181={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x21987e&&(_0x5e3181['idToken']=_0x21987e),_0x5e3181;}}function Ip(_0x54e42f){return Va(_0x54e42f['auth'],new ks(_0x54e42f),_0x54e42f['bypassAuthState']);}function wp(_0x3a7e2d){const {auth:_0x4185ba,user:_0xef7a2b}=_0x3a7e2d;return m(_0xef7a2b,_0x4185ba,'internal-error'),tp(_0xef7a2b,new ks(_0x3a7e2d),_0x3a7e2d['bypassAuthState']);}async function Cp(_0x2dccda){const {auth:_0x1eba34,user:_0x703e42}=_0x2dccda;return m(_0x703e42,_0x1eba34,'internal-error'),ep(_0x703e42,new ks(_0x2dccda),_0x2dccda['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x593486,_0x1f6f44,_0x4174f4,_0x2aa739,_0x4ddb87=!0x1){this['auth']=_0x593486,this['resolver']=_0x4174f4,this['user']=_0x2aa739,this['bypassAuthState']=_0x4ddb87,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x1f6f44)?_0x1f6f44:[_0x1f6f44];}['execute'](){return new Promise(async(_0xcb1a80,_0x5a20f2)=>{this['pendingPromise']={'resolve':_0xcb1a80,'reject':_0x5a20f2};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x3336d4){this['reject'](_0x3336d4);}});}async['onAuthEvent'](_0x429348){const {urlResponse:_0x1e870d,sessionId:_0x22c955,postBody:_0x341dbf,tenantId:_0x2985f0,error:_0x359293,type:_0x2af683}=_0x429348;if(_0x359293){this['reject'](_0x359293);return;}const _0x73b45d={'auth':this['auth'],'requestUri':_0x1e870d,'sessionId':_0x22c955,'tenantId':_0x2985f0||void 0x0,'postBody':_0x341dbf||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x2af683)(_0x73b45d));}catch(_0x572ad4){this['reject'](_0x572ad4);}}['onError'](_0x5ae3e2){this['reject'](_0x5ae3e2);}['getIdpTask'](_0x3d0e1d){switch(_0x3d0e1d){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x55ab7c){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x55ab7c),this['unregisterAndCleanUp']();}['reject'](_0x33646e){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x33646e),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x3c9ef0,_0xc083fb,_0x39e642,_0x5c04f8,_0xf9df38){super(_0x3c9ef0,_0xc083fb,_0x5c04f8,_0xf9df38),this['provider']=_0x39e642,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x3f00e3=await this['execute']();return m(_0x3f00e3,this['auth'],'internal-error'),_0x3f00e3;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x1781b8=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x1781b8),this['authWindow']['associatedEvent']=_0x1781b8,this['resolver']['_originValidation'](this['auth'])['catch'](_0x4e9cec=>{this['reject'](_0x4e9cec);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x258474=>{_0x258474||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x497b0c;return((_0x497b0c=this['authWindow'])==null?void 0x0:_0x497b0c['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x27b434=()=>{var _0x58a5dc,_0x3e437b;if((_0x3e437b=(_0x58a5dc=this['authWindow'])==null?void 0x0:_0x58a5dc['window'])!=null&&_0x3e437b['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x27b434,Tp['get']());};_0x27b434();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x52b520,_0x2dc24a,_0xb8a1ed=!0x1){super(_0x52b520,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x2dc24a,void 0x0,_0xb8a1ed),this['eventId']=null;}async['execute'](){let _0x2d9b9b=hn['get'](this['auth']['_key']());if(!_0x2d9b9b){try{const _0xa86cca=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x2d9b9b=()=>Promise['resolve'](_0xa86cca);}catch(_0x386dcd){_0x2d9b9b=()=>Promise['reject'](_0x386dcd);}hn['set'](this['auth']['_key'](),_0x2d9b9b);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x2d9b9b();}async['onAuthEvent'](_0x1a20f6){if(_0x1a20f6['type']==='signInViaRedirect')return super['onAuthEvent'](_0x1a20f6);if(_0x1a20f6['type']==='unknown'){this['resolve'](null);return;}if(_0x1a20f6['eventId']){const _0x4fc7e6=await this['auth']['_redirectUserForId'](_0x1a20f6['eventId']);if(_0x4fc7e6)return this['user']=_0x4fc7e6,super['onAuthEvent'](_0x1a20f6);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x3f38a6,_0x4512c1){const _0x2c11c0=Pp(_0x4512c1),_0x5a6d9d=kp(_0x3f38a6);if(!await _0x5a6d9d['_isAvailable']())return!0x1;const _0x4759b5=await _0x5a6d9d['_get'](_0x2c11c0)==='true';return await _0x5a6d9d['_remove'](_0x2c11c0),_0x4759b5;}function Ap(_0x1032a4,_0x12c32a){hn['set'](_0x1032a4['_key'](),_0x12c32a);}function kp(_0x549189){return ie(_0x549189['_redirectPersistence']);}function Pp(_0x199639){return ln(Sp,_0x199639['config']['apiKey'],_0x199639['name']);}async function Np(_0x443f2,_0x5ef636,_0x2c9e7e=!0x1){if($(_0x443f2['app']))return Promise['reject'](re(_0x443f2));const _0xa766a2=Ke(_0x443f2),_0x4f7698=Ep(_0xa766a2,_0x5ef636),_0x4e438e=await new bp(_0xa766a2,_0x4f7698,_0x2c9e7e)['execute']();return _0x4e438e&&!_0x2c9e7e&&(delete _0x4e438e['user']['_redirectEventId'],await _0xa766a2['_persistUserIfCurrent'](_0x4e438e['user']),await _0xa766a2['_setRedirectUser'](null,_0x5ef636)),_0x4e438e;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0xa8d0c2){this['auth']=_0xa8d0c2,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x1c1e0a){this['consumers']['add'](_0x1c1e0a),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x1c1e0a)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x1c1e0a),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x33edae){this['consumers']['delete'](_0x33edae);}['onEvent'](_0x5581e7){if(this['hasEventBeenHandled'](_0x5581e7))return!0x1;let _0x1aab08=!0x1;return this['consumers']['forEach'](_0x1ad5de=>{this['isEventForConsumer'](_0x5581e7,_0x1ad5de)&&(_0x1aab08=!0x0,this['sendToConsumer'](_0x5581e7,_0x1ad5de),this['saveEventToCache'](_0x5581e7));}),this['hasHandledPotentialRedirect']||!Mp(_0x5581e7)||(this['hasHandledPotentialRedirect']=!0x0,_0x1aab08||(this['queuedRedirectEvent']=_0x5581e7,_0x1aab08=!0x0)),_0x1aab08;}['sendToConsumer'](_0x1f58d1,_0x5a2bfc){var _0x1e2a69;if(_0x1f58d1['error']&&!Za(_0x1f58d1)){const _0xe9c559=((_0x1e2a69=_0x1f58d1['error']['code'])==null?void 0x0:_0x1e2a69['split']('auth/')[0x1])||'internal-error';_0x5a2bfc['onError'](X(this['auth'],_0xe9c559));}else _0x5a2bfc['onAuthEvent'](_0x1f58d1);}['isEventForConsumer'](_0x24fd32,_0x20f6d9){const _0x7adee7=_0x20f6d9['eventId']===null||!!_0x24fd32['eventId']&&_0x24fd32['eventId']===_0x20f6d9['eventId'];return _0x20f6d9['filter']['includes'](_0x24fd32['type'])&&_0x7adee7;}['hasEventBeenHandled'](_0x3463d5){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x3463d5));}['saveEventToCache'](_0x4b5459){this['cachedEventUids']['add'](Mr(_0x4b5459)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x4dcec4){return[_0x4dcec4['type'],_0x4dcec4['eventId'],_0x4dcec4['sessionId'],_0x4dcec4['tenantId']]['filter'](_0xb5d950=>_0xb5d950)['join']('-');}function Za({type:_0x35c1a1,error:_0x173c52}){return _0x35c1a1==='unknown'&&(_0x173c52==null?void 0x0:_0x173c52['code'])==='auth/no-auth-event';}function Mp(_0x2a2210){switch(_0x2a2210['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x2a2210);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x131c32,_0x316ea1={}){return Pe(_0x131c32,'GET','/v1/projects',_0x316ea1);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x10078c){if(_0x10078c['config']['emulator'])return;const {authorizedDomains:_0x2a2640}=await Lp(_0x10078c);for(const _0xc36fe6 of _0x2a2640)try{if(Wp(_0xc36fe6))return;}catch{}Y(_0x10078c,'unauthorized-domain');}function Wp(_0x5cb0f0){const _0x38846b=Mi(),{protocol:_0x412249,hostname:_0xf9507e}=new URL(_0x38846b);if(_0x5cb0f0['startsWith']('chrome-extension://')){const _0x1358cf=new URL(_0x5cb0f0);return _0x1358cf['hostname']===''&&_0xf9507e===''?_0x412249==='chrome-extension:'&&_0x5cb0f0['replace']('chrome-extension://','')===_0x38846b['replace']('chrome-extension://',''):_0x412249==='chrome-extension:'&&_0x1358cf['hostname']===_0xf9507e;}if(!Fp['test'](_0x412249))return!0x1;if(xp['test'](_0x5cb0f0))return _0xf9507e===_0x5cb0f0;const _0x6f2a9e=_0x5cb0f0['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x6f2a9e+'|'+_0x6f2a9e+')$','i')['test'](_0xf9507e);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x425f12=Z()['___jsl'];if(_0x425f12!=null&&_0x425f12['H']){for(const _0x49dc0b of Object['keys'](_0x425f12['H']))if(_0x425f12['H'][_0x49dc0b]['r']=_0x425f12['H'][_0x49dc0b]['r']||[],_0x425f12['H'][_0x49dc0b]['L']=_0x425f12['H'][_0x49dc0b]['L']||[],_0x425f12['H'][_0x49dc0b]['r']=[..._0x425f12['H'][_0x49dc0b]['L']],_0x425f12['CP']){for(let _0x309d37=0x0;_0x309d37<_0x425f12['CP']['length'];_0x309d37++)_0x425f12['CP'][_0x309d37]=null;}}}function Vp(_0x7f800c){return new Promise((_0x1f738a,_0x5ae79b)=>{var _0x539922,_0x5e9f2e,_0x4181bf;function _0xf42c75(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x1f738a(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x5ae79b(X(_0x7f800c,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x5e9f2e=(_0x539922=Z()['gapi'])==null?void 0x0:_0x539922['iframes'])!=null&&_0x5e9f2e['Iframe'])_0x1f738a(gapi['iframes']['getContext']());else{if((_0x4181bf=Z()['gapi'])!=null&&_0x4181bf['load'])_0xf42c75();else{const _0x5da918=Ff('iframefcb');return Z()[_0x5da918]=()=>{gapi['load']?_0xf42c75():_0x5ae79b(X(_0x7f800c,'network-request-failed'));},xa(xf()+'?onload='+_0x5da918)['catch'](_0x3ed3e7=>_0x5ae79b(_0x3ed3e7));}}})['catch'](_0x2892d4=>{throw un=null,_0x2892d4;});}let un=null;function Hp(_0x51ef70){return un=un||Vp(_0x51ef70),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x165eb9){const _0x575973=_0x165eb9['config'];m(_0x575973['authDomain'],_0x165eb9,'auth-domain-config-required');const _0x3a63bd=_0x575973['emulator']?Cs(_0x575973,qp):'https://'+_0x165eb9['config']['authDomain']+'/'+Gp,_0x3711cd={'apiKey':_0x575973['apiKey'],'appName':_0x165eb9['name'],'v':dt},_0x386b37=jp['get'](_0x165eb9['config']['apiHost']);_0x386b37&&(_0x3711cd['eid']=_0x386b37);const _0x3d0dee=_0x165eb9['_getFrameworks']();return _0x3d0dee['length']&&(_0x3711cd['fw']=_0x3d0dee['join'](',')),_0x3a63bd+'?'+ut(_0x3711cd)['slice'](0x1);}async function Yp(_0x17a737){const _0x1110b1=await Hp(_0x17a737),_0xb631d1=Z()['gapi'];return m(_0xb631d1,_0x17a737,'internal-error'),_0x1110b1['open']({'where':document['body'],'url':Kp(_0x17a737),'messageHandlersFilter':_0xb631d1['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x63e83b=>new Promise(async(_0x34f4b5,_0x3716df)=>{await _0x63e83b['restyle']({'setHideOnLeave':!0x1});const _0x4cc9ac=X(_0x17a737,'network-request-failed'),_0x187798=Z()['setTimeout'](()=>{_0x3716df(_0x4cc9ac);},$p['get']());function _0xe1ea28(){Z()['clearTimeout'](_0x187798),_0x34f4b5(_0x63e83b);}_0x63e83b['ping'](_0xe1ea28)['then'](_0xe1ea28,()=>{_0x3716df(_0x4cc9ac);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x4a2712){this['window']=_0x4a2712,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0xcab86,_0x5572ca,_0x29e917,_0x304d63=Jp,_0x4d8a34=Xp){const _0x450b52=Math['max']((window['screen']['availHeight']-_0x4d8a34)/0x2,0x0)['toString'](),_0x22f888=Math['max']((window['screen']['availWidth']-_0x304d63)/0x2,0x0)['toString']();let _0x50bd36='';const _0x129968={...Qp,'width':_0x304d63['toString'](),'height':_0x4d8a34['toString'](),'top':_0x450b52,'left':_0x22f888},_0x2df7da=W()['toLowerCase']();_0x29e917&&(_0x50bd36=ka(_0x2df7da)?Zp:_0x29e917),Ra(_0x2df7da)&&(_0x5572ca=_0x5572ca||e_,_0x129968['scrollbars']='yes');const _0x13439f=Object['entries'](_0x129968)['reduce']((_0xd23961,[_0x1e51d0,_0x5d4639])=>''+_0xd23961+_0x1e51d0+'='+_0x5d4639+',','');if(Rf(_0x2df7da)&&_0x50bd36!=='_self')return n_(_0x5572ca||'',_0x50bd36),new xr(null);const _0x2bf6c4=window['open'](_0x5572ca||'',_0x50bd36,_0x13439f);m(_0x2bf6c4,_0xcab86,'popup-blocked');try{_0x2bf6c4['focus']();}catch{}return new xr(_0x2bf6c4);}function n_(_0x4d3480,_0x2857f4){const _0x478c99=document['createElement']('a');_0x478c99['href']=_0x4d3480,_0x478c99['target']=_0x2857f4;const _0x39c697=document['createEvent']('MouseEvent');_0x39c697['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x478c99['dispatchEvent'](_0x39c697);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x127752,_0x2a3c69,_0x36902d,_0x2b9945,_0x50c7cd,_0x1d2793){m(_0x127752['config']['authDomain'],_0x127752,'auth-domain-config-required'),m(_0x127752['config']['apiKey'],_0x127752,'invalid-api-key');const _0x13d606={'apiKey':_0x127752['config']['apiKey'],'appName':_0x127752['name'],'authType':_0x36902d,'redirectUrl':_0x2b9945,'v':dt,'eventId':_0x50c7cd};if(_0x2a3c69 instanceof Wa){_0x2a3c69['setDefaultLanguage'](_0x127752['languageCode']),_0x13d606['providerId']=_0x2a3c69['providerId']||'',pn(_0x2a3c69['getCustomParameters']())||(_0x13d606['customParameters']=JSON['stringify'](_0x2a3c69['getCustomParameters']()));for(const [_0x4c98ba,_0x343732]of Object['entries']({}))_0x13d606[_0x4c98ba]=_0x343732;}if(_0x2a3c69 instanceof tn){const _0x1702e0=_0x2a3c69['getScopes']()['filter'](_0x1b9bfb=>_0x1b9bfb!=='');_0x1702e0['length']>0x0&&(_0x13d606['scopes']=_0x1702e0['join'](','));}_0x127752['tenantId']&&(_0x13d606['tid']=_0x127752['tenantId']);const _0x1d3b38=_0x13d606;for(const _0x21f9cd of Object['keys'](_0x1d3b38))_0x1d3b38[_0x21f9cd]===void 0x0&&delete _0x1d3b38[_0x21f9cd];const _0x1cdc54=await _0x127752['_getAppCheckToken'](),_0x29cb49=_0x1cdc54?'#'+r_+'='+encodeURIComponent(_0x1cdc54):'';return o_(_0x127752)+'?'+ut(_0x1d3b38)['slice'](0x1)+_0x29cb49;}function o_({config:_0x347c9a}){return _0x347c9a['emulator']?Cs(_0x347c9a,s_):'https://'+_0x347c9a['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x40c21b,_0x11cb49,_0x2ea833,_0x157041){var _0x10c09e;ce((_0x10c09e=this['eventManagers'][_0x40c21b['_key']()])==null?void 0x0:_0x10c09e['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x7191cd=await Fr(_0x40c21b,_0x11cb49,_0x2ea833,Mi(),_0x157041);return t_(_0x40c21b,_0x7191cd,As());}async['_openRedirect'](_0x44a060,_0x47c862,_0x4f3f33,_0x360219){await this['_originValidation'](_0x44a060);const _0x1d448d=await Fr(_0x44a060,_0x47c862,_0x4f3f33,Mi(),_0x360219);return hp(_0x1d448d),new Promise(()=>{});}['_initialize'](_0x11f6e7){const _0x25d237=_0x11f6e7['_key']();if(this['eventManagers'][_0x25d237]){const {manager:_0x215dad,promise:_0x4e13f0}=this['eventManagers'][_0x25d237];return _0x215dad?Promise['resolve'](_0x215dad):(ce(_0x4e13f0,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x4e13f0);}const _0x1618f4=this['initAndGetManager'](_0x11f6e7);return this['eventManagers'][_0x25d237]={'promise':_0x1618f4},_0x1618f4['catch'](()=>{delete this['eventManagers'][_0x25d237];}),_0x1618f4;}async['initAndGetManager'](_0x158089){const _0x34e2c8=await Yp(_0x158089),_0x357eb8=new Dp(_0x158089);return _0x34e2c8['register']('authEvent',_0x5178ef=>(m(_0x5178ef==null?void 0x0:_0x5178ef['authEvent'],_0x158089,'invalid-auth-event'),{'status':_0x357eb8['onEvent'](_0x5178ef['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x158089['_key']()]={'manager':_0x357eb8},this['iframes'][_0x158089['_key']()]=_0x34e2c8,_0x357eb8;}['_isIframeWebStorageSupported'](_0x197838,_0xd15dfc){this['iframes'][_0x197838['_key']()]['send'](pi,{'type':pi},_0x3f5cae=>{var _0x374412;const _0x857ddc=(_0x374412=_0x3f5cae==null?void 0x0:_0x3f5cae[0x0])==null?void 0x0:_0x374412[pi];_0x857ddc!==void 0x0&&_0xd15dfc(!!_0x857ddc),Y(_0x197838,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x1ce57b){const _0x3ee74c=_0x1ce57b['_key']();return this['originValidationPromises'][_0x3ee74c]||(this['originValidationPromises'][_0x3ee74c]=Up(_0x1ce57b)),this['originValidationPromises'][_0x3ee74c];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x3b04){this['auth']=_0x3b04,this['internalListeners']=new Map();}['getUid'](){var _0x32ffa2;return this['assertAuthConfigured'](),((_0x32ffa2=this['auth']['currentUser'])==null?void 0x0:_0x32ffa2['uid'])||null;}async['getToken'](_0x3eccb6){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x3eccb6)}:null;}['addAuthTokenListener'](_0x3245c3){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x3245c3))return;const _0x42e938=this['auth']['onIdTokenChanged'](_0x45614c=>{_0x3245c3((_0x45614c==null?void 0x0:_0x45614c['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x3245c3,_0x42e938),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x4a2075){this['assertAuthConfigured']();const _0x1547ee=this['internalListeners']['get'](_0x4a2075);_0x1547ee&&(this['internalListeners']['delete'](_0x4a2075),_0x1547ee(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x2195aa){switch(_0x2195aa){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x5aa583){st(new Fe('auth',(_0x55a789,{options:_0x8b1657})=>{const _0x36ab8e=_0x55a789['getProvider']('app')['getImmediate'](),_0x3b8378=_0x55a789['getProvider']('heartbeat'),_0x4b15d3=_0x55a789['getProvider']('app-check-internal'),{apiKey:_0x2b6b41,authDomain:_0x357f44}=_0x36ab8e['options'];m(_0x2b6b41&&!_0x2b6b41['includes'](':'),'invalid-api-key',{'appName':_0x36ab8e['name']});const _0x2dd6d5={'apiKey':_0x2b6b41,'authDomain':_0x357f44,'clientPlatform':_0x5aa583,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x5aa583)},_0x1d763b=new Df(_0x36ab8e,_0x3b8378,_0x4b15d3,_0x2dd6d5);return Hf(_0x1d763b,_0x8b1657),_0x1d763b;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x3c847d,_0xd80bb8,_0x575e54)=>{_0x3c847d['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0xfface=>{const _0x30d46d=Ke(_0xfface['getProvider']('auth')['getImmediate']());return(_0x331342=>new l_(_0x331342))(_0x30d46d);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x5aa583)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x2821e2=>async _0x741b5d=>{const _0x26d0bd=_0x741b5d&&await _0x741b5d['getIdTokenResult'](),_0x47e969=_0x26d0bd&&(new Date()['getTime']()-Date['parse'](_0x26d0bd['issuedAtTime']))/0x3e8;if(_0x47e969&&_0x47e969>f_)return;const _0x182780=_0x26d0bd==null?void 0x0:_0x26d0bd['token'];Br!==_0x182780&&(Br=_0x182780,await fetch(_0x2821e2,{'method':_0x182780?'POST':'DELETE','headers':_0x182780?{'Authorization':'Bearer\x20'+_0x182780}:{}}));};function B_(_0x5f3e18=Zr()){const _0x311329=Hi(_0x5f3e18,'auth');if(_0x311329['isInitialized']())return _0x311329['getImmediate']();const _0x283c46=Vf(_0x5f3e18,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x373627=jr('authTokenSyncURL');if(_0x373627&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x5d67a3=new URL(_0x373627,location['origin']);if(location['origin']===_0x5d67a3['origin']){const _0x5ae9b1=p_(_0x5d67a3['toString']());sp(_0x283c46,_0x5ae9b1,()=>_0x5ae9b1(_0x283c46['currentUser'])),ip(_0x283c46,_0x3678bd=>_0x5ae9b1(_0x3678bd));}}const _0x4f66b1=qr('auth');return _0x4f66b1&&$f(_0x283c46,'http://'+_0x4f66b1),_0x283c46;}function __(){var _0x2ea969;return((_0x2ea969=document['getElementsByTagName']('head'))==null?void 0x0:_0x2ea969[0x0])??document;}Mf({'loadJS'(_0x472825){return new Promise((_0x51052f,_0x4c0217)=>{const _0x4f67d1=document['createElement']('script');_0x4f67d1['setAttribute']('src',_0x472825),_0x4f67d1['onload']=_0x51052f,_0x4f67d1['onerror']=_0x27c85d=>{const _0x4bc62d=X('internal-error');_0x4bc62d['customData']=_0x27c85d,_0x4c0217(_0x4bc62d);},_0x4f67d1['type']='text/javascript',_0x4f67d1['charset']='UTF-8',__()['appendChild'](_0x4f67d1);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,B_ as a,ap as b,x_ as c,g_ as d,m_ as e,Zr as f,P_ as g,Hd as h,Sl as i,D_ as j,Gd as k,w_ as l,b_ as m,A_ as n,v_ as o,E_ as p,k_ as q,y_ as r,F_ as s,Vt as t,I_ as u,N_ as v,U_ as w,O_ as x,M_ as y,T_ as z};