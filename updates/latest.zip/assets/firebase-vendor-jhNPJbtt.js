const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x5879a7,_0x2ebdbb){if(!_0x5879a7)throw ht(_0x2ebdbb);},ht=function(_0x278bea){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x278bea);},Hr=function(_0x323294){const _0x17fe6a=[];let _0x16ff67=0x0;for(let _0x10c193=0x0;_0x10c193<_0x323294['length'];_0x10c193++){let _0x2680e9=_0x323294['charCodeAt'](_0x10c193);_0x2680e9<0x80?_0x17fe6a[_0x16ff67++]=_0x2680e9:_0x2680e9<0x800?(_0x17fe6a[_0x16ff67++]=_0x2680e9>>0x6|0xc0,_0x17fe6a[_0x16ff67++]=_0x2680e9&0x3f|0x80):(_0x2680e9&0xfc00)===0xd800&&_0x10c193+0x1<_0x323294['length']&&(_0x323294['charCodeAt'](_0x10c193+0x1)&0xfc00)===0xdc00?(_0x2680e9=0x10000+((_0x2680e9&0x3ff)<<0xa)+(_0x323294['charCodeAt'](++_0x10c193)&0x3ff),_0x17fe6a[_0x16ff67++]=_0x2680e9>>0x12|0xf0,_0x17fe6a[_0x16ff67++]=_0x2680e9>>0xc&0x3f|0x80,_0x17fe6a[_0x16ff67++]=_0x2680e9>>0x6&0x3f|0x80,_0x17fe6a[_0x16ff67++]=_0x2680e9&0x3f|0x80):(_0x17fe6a[_0x16ff67++]=_0x2680e9>>0xc|0xe0,_0x17fe6a[_0x16ff67++]=_0x2680e9>>0x6&0x3f|0x80,_0x17fe6a[_0x16ff67++]=_0x2680e9&0x3f|0x80);}return _0x17fe6a;},nc=function(_0x4f41cb){const _0x57e9b8=[];let _0x19502a=0x0,_0x1269a1=0x0;for(;_0x19502a<_0x4f41cb['length'];){const _0x337e64=_0x4f41cb[_0x19502a++];if(_0x337e64<0x80)_0x57e9b8[_0x1269a1++]=String['fromCharCode'](_0x337e64);else{if(_0x337e64>0xbf&&_0x337e64<0xe0){const _0x5ab788=_0x4f41cb[_0x19502a++];_0x57e9b8[_0x1269a1++]=String['fromCharCode']((_0x337e64&0x1f)<<0x6|_0x5ab788&0x3f);}else{if(_0x337e64>0xef&&_0x337e64<0x16d){const _0x1faeb9=_0x4f41cb[_0x19502a++],_0x6e989e=_0x4f41cb[_0x19502a++],_0x3e0aa5=_0x4f41cb[_0x19502a++],_0x1ea86b=((_0x337e64&0x7)<<0x12|(_0x1faeb9&0x3f)<<0xc|(_0x6e989e&0x3f)<<0x6|_0x3e0aa5&0x3f)-0x10000;_0x57e9b8[_0x1269a1++]=String['fromCharCode'](0xd800+(_0x1ea86b>>0xa)),_0x57e9b8[_0x1269a1++]=String['fromCharCode'](0xdc00+(_0x1ea86b&0x3ff));}else{const _0x4bca13=_0x4f41cb[_0x19502a++],_0x177498=_0x4f41cb[_0x19502a++];_0x57e9b8[_0x1269a1++]=String['fromCharCode']((_0x337e64&0xf)<<0xc|(_0x4bca13&0x3f)<<0x6|_0x177498&0x3f);}}}}return _0x57e9b8['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x40e008,_0x18582c){if(!Array['isArray'](_0x40e008))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x18ef3a=_0x18582c?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x4ed9f0=[];for(let _0x4d44bb=0x0;_0x4d44bb<_0x40e008['length'];_0x4d44bb+=0x3){const _0x4fdf2a=_0x40e008[_0x4d44bb],_0xe6331d=_0x4d44bb+0x1<_0x40e008['length'],_0x4fc82e=_0xe6331d?_0x40e008[_0x4d44bb+0x1]:0x0,_0x59be52=_0x4d44bb+0x2<_0x40e008['length'],_0x36c9ec=_0x59be52?_0x40e008[_0x4d44bb+0x2]:0x0,_0x9f57f2=_0x4fdf2a>>0x2,_0x164e5f=(_0x4fdf2a&0x3)<<0x4|_0x4fc82e>>0x4;let _0x28148f=(_0x4fc82e&0xf)<<0x2|_0x36c9ec>>0x6,_0x4e1ec5=_0x36c9ec&0x3f;_0x59be52||(_0x4e1ec5=0x40,_0xe6331d||(_0x28148f=0x40)),_0x4ed9f0['push'](_0x18ef3a[_0x9f57f2],_0x18ef3a[_0x164e5f],_0x18ef3a[_0x28148f],_0x18ef3a[_0x4e1ec5]);}return _0x4ed9f0['join']('');},'encodeString'(_0x4cd198,_0xd5d3e3){return this['HAS_NATIVE_SUPPORT']&&!_0xd5d3e3?btoa(_0x4cd198):this['encodeByteArray'](Hr(_0x4cd198),_0xd5d3e3);},'decodeString'(_0x57b635,_0x586103){return this['HAS_NATIVE_SUPPORT']&&!_0x586103?atob(_0x57b635):nc(this['decodeStringToByteArray'](_0x57b635,_0x586103));},'decodeStringToByteArray'(_0x111080,_0x396dff){this['init_']();const _0x15f2c9=_0x396dff?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x4da53b=[];for(let _0x58ce29=0x0;_0x58ce29<_0x111080['length'];){const _0x4b2522=_0x15f2c9[_0x111080['charAt'](_0x58ce29++)],_0x4aeaa0=_0x58ce29<_0x111080['length']?_0x15f2c9[_0x111080['charAt'](_0x58ce29)]:0x0;++_0x58ce29;const _0x5ed321=_0x58ce29<_0x111080['length']?_0x15f2c9[_0x111080['charAt'](_0x58ce29)]:0x40;++_0x58ce29;const _0xd82b6b=_0x58ce29<_0x111080['length']?_0x15f2c9[_0x111080['charAt'](_0x58ce29)]:0x40;if(++_0x58ce29,_0x4b2522==null||_0x4aeaa0==null||_0x5ed321==null||_0xd82b6b==null)throw new ic();const _0x29f2f9=_0x4b2522<<0x2|_0x4aeaa0>>0x4;if(_0x4da53b['push'](_0x29f2f9),_0x5ed321!==0x40){const _0x357da9=_0x4aeaa0<<0x4&0xf0|_0x5ed321>>0x2;if(_0x4da53b['push'](_0x357da9),_0xd82b6b!==0x40){const _0x55bb61=_0x5ed321<<0x6&0xc0|_0xd82b6b;_0x4da53b['push'](_0x55bb61);}}}return _0x4da53b;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x34b711=0x0;_0x34b711<this['ENCODED_VALS']['length'];_0x34b711++)this['byteToCharMap_'][_0x34b711]=this['ENCODED_VALS']['charAt'](_0x34b711),this['charToByteMap_'][this['byteToCharMap_'][_0x34b711]]=_0x34b711,this['byteToCharMapWebSafe_'][_0x34b711]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x34b711),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x34b711]]=_0x34b711,_0x34b711>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x34b711)]=_0x34b711,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x34b711)]=_0x34b711);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x2ce20b){const _0x347a84=Hr(_0x2ce20b);return Fi['encodeByteArray'](_0x347a84,!0x0);},dn=function(_0x58c283){return $r(_0x58c283)['replace'](/\./g,'');},fn=function(_0xefff3a){try{return Fi['decodeString'](_0xefff3a,!0x0);}catch(_0x1ef002){console['error']('base64Decode\x20failed:\x20',_0x1ef002);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x5534f0){return Gr(void 0x0,_0x5534f0);}function Gr(_0x50f2fe,_0x302e17){if(!(_0x302e17 instanceof Object))return _0x302e17;switch(_0x302e17['constructor']){case Date:const _0x158a73=_0x302e17;return new Date(_0x158a73['getTime']());case Object:_0x50f2fe===void 0x0&&(_0x50f2fe={});break;case Array:_0x50f2fe=[];break;default:return _0x302e17;}for(const _0x2131f5 in _0x302e17)!_0x302e17['hasOwnProperty'](_0x2131f5)||!rc(_0x2131f5)||(_0x50f2fe[_0x2131f5]=Gr(_0x50f2fe[_0x2131f5],_0x302e17[_0x2131f5]));return _0x50f2fe;}function rc(_0x3dfa74){return _0x3dfa74!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x1ee58f=Ps['__FIREBASE_DEFAULTS__'];if(_0x1ee58f)return JSON['parse'](_0x1ee58f);},lc=()=>{if(typeof document>'u')return;let _0x4a12b5;try{_0x4a12b5=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x2d74c7=_0x4a12b5&&fn(_0x4a12b5[0x1]);return _0x2d74c7&&JSON['parse'](_0x2d74c7);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x2b8cd2){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x2b8cd2);return;}},qr=_0x26af51=>{var _0x22a4e9,_0x4f7ef5;return(_0x4f7ef5=(_0x22a4e9=Ui())==null?void 0x0:_0x22a4e9['emulatorHosts'])==null?void 0x0:_0x4f7ef5[_0x26af51];},hc=_0x592701=>{const _0x7ca3f=qr(_0x592701);if(!_0x7ca3f)return;const _0x38d5bc=_0x7ca3f['lastIndexOf'](':');if(_0x38d5bc<=0x0||_0x38d5bc+0x1===_0x7ca3f['length'])throw new Error('Invalid\x20host\x20'+_0x7ca3f+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x562a9e=parseInt(_0x7ca3f['substring'](_0x38d5bc+0x1),0xa);return _0x7ca3f[0x0]==='['?[_0x7ca3f['substring'](0x1,_0x38d5bc-0x1),_0x562a9e]:[_0x7ca3f['substring'](0x0,_0x38d5bc),_0x562a9e];},zr=()=>{var _0x447686;return(_0x447686=Ui())==null?void 0x0:_0x447686['config'];},jr=_0x379230=>{var _0x4098b6;return(_0x4098b6=Ui())==null?void 0x0:_0x4098b6['_'+_0x379230];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x197d17,_0xb67354)=>{this['resolve']=_0x197d17,this['reject']=_0xb67354;});}['wrapCallback'](_0x6a0137){return(_0x4a0ca6,_0x159d61)=>{_0x4a0ca6?this['reject'](_0x4a0ca6):this['resolve'](_0x159d61),typeof _0x6a0137=='function'&&(this['promise']['catch'](()=>{}),_0x6a0137['length']===0x1?_0x6a0137(_0x4a0ca6):_0x6a0137(_0x4a0ca6,_0x159d61));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x371eeb,_0x48a809){if(_0x371eeb['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x7dee34={'alg':'none','type':'JWT'},_0x971227=_0x48a809||'demo-project',_0x5c44c3=_0x371eeb['iat']||0x0,_0x202f25=_0x371eeb['sub']||_0x371eeb['user_id'];if(!_0x202f25)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x2f2243={'iss':'https://securetoken.google.com/'+_0x971227,'aud':_0x971227,'iat':_0x5c44c3,'exp':_0x5c44c3+0xe10,'auth_time':_0x5c44c3,'sub':_0x202f25,'user_id':_0x202f25,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x371eeb};return[dn(JSON['stringify'](_0x7dee34)),dn(JSON['stringify'](_0x2f2243)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x263824=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x263824=='object'&&_0x263824['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0xa7db2c=W();return _0xa7db2c['indexOf']('MSIE\x20')>=0x0||_0xa7db2c['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x256f81,_0x499a53)=>{try{let _0x632313=!0x0;const _0x570230='validate-browser-context-for-indexeddb-analytics-module',_0x498486=self['indexedDB']['open'](_0x570230);_0x498486['onsuccess']=()=>{_0x498486['result']['close'](),_0x632313||self['indexedDB']['deleteDatabase'](_0x570230),_0x256f81(!0x0);},_0x498486['onupgradeneeded']=()=>{_0x632313=!0x1;},_0x498486['onerror']=()=>{var _0xed32eb;_0x499a53(((_0xed32eb=_0x498486['error'])==null?void 0x0:_0xed32eb['message'])||'');};}catch(_0x4a1373){_0x499a53(_0x4a1373);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x3b25ae,_0x3144cb,_0x178229){super(_0x3144cb),this['code']=_0x3b25ae,this['customData']=_0x178229,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x40180a,_0x192af0,_0x35c191){this['service']=_0x40180a,this['serviceName']=_0x192af0,this['errors']=_0x35c191;}['create'](_0x123726,..._0x229749){const _0x709de7=_0x229749[0x0]||{},_0x405917=this['service']+'/'+_0x123726,_0x189e61=this['errors'][_0x123726],_0x486d2e=_0x189e61?vc(_0x189e61,_0x709de7):'Error',_0x35db3a=this['serviceName']+':\x20'+_0x486d2e+'\x20('+_0x405917+').';return new Re(_0x405917,_0x35db3a,_0x709de7);}}function vc(_0xd642e1,_0x66b60d){return _0xd642e1['replace'](Ec,(_0x57bca1,_0x47a2af)=>{const _0x200a39=_0x66b60d[_0x47a2af];return _0x200a39!=null?String(_0x200a39):'<'+_0x47a2af+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x459ab9){return JSON['parse'](_0x459ab9);}function O(_0x3de2c3){return JSON['stringify'](_0x3de2c3);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x1aaa03){let _0x528f04={},_0x36f3eb={},_0x22df17={},_0x22797c='';try{const _0x4f9517=_0x1aaa03['split']('.');_0x528f04=Nt(fn(_0x4f9517[0x0])||''),_0x36f3eb=Nt(fn(_0x4f9517[0x1])||''),_0x22797c=_0x4f9517[0x2],_0x22df17=_0x36f3eb['d']||{},delete _0x36f3eb['d'];}catch{}return{'header':_0x528f04,'claims':_0x36f3eb,'data':_0x22df17,'signature':_0x22797c};},Ic=function(_0x21222f){const _0x21ddb2=Yr(_0x21222f),_0x491871=_0x21ddb2['claims'];return!!_0x491871&&typeof _0x491871=='object'&&_0x491871['hasOwnProperty']('iat');},wc=function(_0x249511){const _0x4eef99=Yr(_0x249511)['claims'];return typeof _0x4eef99=='object'&&_0x4eef99['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x16b4fc,_0x3e378b){return Object['prototype']['hasOwnProperty']['call'](_0x16b4fc,_0x3e378b);}function Le(_0x965cd6,_0x495d8f){if(Object['prototype']['hasOwnProperty']['call'](_0x965cd6,_0x495d8f))return _0x965cd6[_0x495d8f];}function pn(_0x35552c){for(const _0x4b8e29 in _0x35552c)if(Object['prototype']['hasOwnProperty']['call'](_0x35552c,_0x4b8e29))return!0x1;return!0x0;}function _n(_0x4ec891,_0x3282f2,_0x461774){const _0x1fea17={};for(const _0x17d075 in _0x4ec891)Object['prototype']['hasOwnProperty']['call'](_0x4ec891,_0x17d075)&&(_0x1fea17[_0x17d075]=_0x3282f2['call'](_0x461774,_0x4ec891[_0x17d075],_0x17d075,_0x4ec891));return _0x1fea17;}function xe(_0x31269f,_0x1d90cb){if(_0x31269f===_0x1d90cb)return!0x0;const _0x19a5db=Object['keys'](_0x31269f),_0x52866b=Object['keys'](_0x1d90cb);for(const _0x29276d of _0x19a5db){if(!_0x52866b['includes'](_0x29276d))return!0x1;const _0x5b4ecc=_0x31269f[_0x29276d],_0x349546=_0x1d90cb[_0x29276d];if(Ns(_0x5b4ecc)&&Ns(_0x349546)){if(!xe(_0x5b4ecc,_0x349546))return!0x1;}else{if(_0x5b4ecc!==_0x349546)return!0x1;}}for(const _0x23c628 of _0x52866b)if(!_0x19a5db['includes'](_0x23c628))return!0x1;return!0x0;}function Ns(_0x28e510){return _0x28e510!==null&&typeof _0x28e510=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x153b49){const _0x208c93=[];for(const [_0xcf1c03,_0x4e6840]of Object['entries'](_0x153b49))Array['isArray'](_0x4e6840)?_0x4e6840['forEach'](_0x16ff55=>{_0x208c93['push'](encodeURIComponent(_0xcf1c03)+'='+encodeURIComponent(_0x16ff55));}):_0x208c93['push'](encodeURIComponent(_0xcf1c03)+'='+encodeURIComponent(_0x4e6840));return _0x208c93['length']?'&'+_0x208c93['join']('&'):'';}function Ct(_0x91de3d){const _0x1baedb={};return _0x91de3d['replace'](/^\?/,'')['split']('&')['forEach'](_0x54e5a3=>{if(_0x54e5a3){const [_0x261de3,_0x298183]=_0x54e5a3['split']('=');_0x1baedb[decodeURIComponent(_0x261de3)]=decodeURIComponent(_0x298183);}}),_0x1baedb;}function Tt(_0x2987c3){const _0xe62250=_0x2987c3['indexOf']('?');if(!_0xe62250)return'';const _0x12eca9=_0x2987c3['indexOf']('#',_0xe62250);return _0x2987c3['substring'](_0xe62250,_0x12eca9>0x0?_0x12eca9:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x32658d=0x1;_0x32658d<this['blockSize'];++_0x32658d)this['pad_'][_0x32658d]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x463bec,_0x1e5c4e){_0x1e5c4e||(_0x1e5c4e=0x0);const _0x245562=this['W_'];if(typeof _0x463bec=='string'){for(let _0x4209f7=0x0;_0x4209f7<0x10;_0x4209f7++)_0x245562[_0x4209f7]=_0x463bec['charCodeAt'](_0x1e5c4e)<<0x18|_0x463bec['charCodeAt'](_0x1e5c4e+0x1)<<0x10|_0x463bec['charCodeAt'](_0x1e5c4e+0x2)<<0x8|_0x463bec['charCodeAt'](_0x1e5c4e+0x3),_0x1e5c4e+=0x4;}else{for(let _0x7e4bad=0x0;_0x7e4bad<0x10;_0x7e4bad++)_0x245562[_0x7e4bad]=_0x463bec[_0x1e5c4e]<<0x18|_0x463bec[_0x1e5c4e+0x1]<<0x10|_0x463bec[_0x1e5c4e+0x2]<<0x8|_0x463bec[_0x1e5c4e+0x3],_0x1e5c4e+=0x4;}for(let _0x43e46d=0x10;_0x43e46d<0x50;_0x43e46d++){const _0x52a02d=_0x245562[_0x43e46d-0x3]^_0x245562[_0x43e46d-0x8]^_0x245562[_0x43e46d-0xe]^_0x245562[_0x43e46d-0x10];_0x245562[_0x43e46d]=(_0x52a02d<<0x1|_0x52a02d>>>0x1f)&0xffffffff;}let _0x1f4413=this['chain_'][0x0],_0x5cbfb1=this['chain_'][0x1],_0x16d0ca=this['chain_'][0x2],_0x2a21d8=this['chain_'][0x3],_0x68386d=this['chain_'][0x4],_0x172d98,_0x5e0579;for(let _0x402cef=0x0;_0x402cef<0x50;_0x402cef++){_0x402cef<0x28?_0x402cef<0x14?(_0x172d98=_0x2a21d8^_0x5cbfb1&(_0x16d0ca^_0x2a21d8),_0x5e0579=0x5a827999):(_0x172d98=_0x5cbfb1^_0x16d0ca^_0x2a21d8,_0x5e0579=0x6ed9eba1):_0x402cef<0x3c?(_0x172d98=_0x5cbfb1&_0x16d0ca|_0x2a21d8&(_0x5cbfb1|_0x16d0ca),_0x5e0579=0x8f1bbcdc):(_0x172d98=_0x5cbfb1^_0x16d0ca^_0x2a21d8,_0x5e0579=0xca62c1d6);const _0x5282b6=(_0x1f4413<<0x5|_0x1f4413>>>0x1b)+_0x172d98+_0x68386d+_0x5e0579+_0x245562[_0x402cef]&0xffffffff;_0x68386d=_0x2a21d8,_0x2a21d8=_0x16d0ca,_0x16d0ca=(_0x5cbfb1<<0x1e|_0x5cbfb1>>>0x2)&0xffffffff,_0x5cbfb1=_0x1f4413,_0x1f4413=_0x5282b6;}this['chain_'][0x0]=this['chain_'][0x0]+_0x1f4413&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x5cbfb1&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x16d0ca&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x2a21d8&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x68386d&0xffffffff;}['update'](_0x431d14,_0x2df22e){if(_0x431d14==null)return;_0x2df22e===void 0x0&&(_0x2df22e=_0x431d14['length']);const _0x28f453=_0x2df22e-this['blockSize'];let _0x1a79d2=0x0;const _0x9ec498=this['buf_'];let _0x4b8a35=this['inbuf_'];for(;_0x1a79d2<_0x2df22e;){if(_0x4b8a35===0x0){for(;_0x1a79d2<=_0x28f453;)this['compress_'](_0x431d14,_0x1a79d2),_0x1a79d2+=this['blockSize'];}if(typeof _0x431d14=='string'){for(;_0x1a79d2<_0x2df22e;)if(_0x9ec498[_0x4b8a35]=_0x431d14['charCodeAt'](_0x1a79d2),++_0x4b8a35,++_0x1a79d2,_0x4b8a35===this['blockSize']){this['compress_'](_0x9ec498),_0x4b8a35=0x0;break;}}else{for(;_0x1a79d2<_0x2df22e;)if(_0x9ec498[_0x4b8a35]=_0x431d14[_0x1a79d2],++_0x4b8a35,++_0x1a79d2,_0x4b8a35===this['blockSize']){this['compress_'](_0x9ec498),_0x4b8a35=0x0;break;}}}this['inbuf_']=_0x4b8a35,this['total_']+=_0x2df22e;}['digest'](){const _0x51f0b3=[];let _0x1dfcdf=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x44dc9f=this['blockSize']-0x1;_0x44dc9f>=0x38;_0x44dc9f--)this['buf_'][_0x44dc9f]=_0x1dfcdf&0xff,_0x1dfcdf/=0x100;this['compress_'](this['buf_']);let _0x5e99a6=0x0;for(let _0x18e558=0x0;_0x18e558<0x5;_0x18e558++)for(let _0x2da780=0x18;_0x2da780>=0x0;_0x2da780-=0x8)_0x51f0b3[_0x5e99a6]=this['chain_'][_0x18e558]>>_0x2da780&0xff,++_0x5e99a6;return _0x51f0b3;}}function Tc(_0x224ac1,_0x125c2b){const _0x10edb7=new Sc(_0x224ac1,_0x125c2b);return _0x10edb7['subscribe']['bind'](_0x10edb7);}class Sc{constructor(_0x588d7a,_0xcacc2a){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0xcacc2a,this['task']['then'](()=>{_0x588d7a(this);})['catch'](_0x2872f4=>{this['error'](_0x2872f4);});}['next'](_0x39e4c0){this['forEachObserver'](_0x210430=>{_0x210430['next'](_0x39e4c0);});}['error'](_0x5c6564){this['forEachObserver'](_0x2f31a3=>{_0x2f31a3['error'](_0x5c6564);}),this['close'](_0x5c6564);}['complete'](){this['forEachObserver'](_0x155de8=>{_0x155de8['complete']();}),this['close']();}['subscribe'](_0x147a43,_0x1d30f0,_0x18af3e){let _0x5090c8;if(_0x147a43===void 0x0&&_0x1d30f0===void 0x0&&_0x18af3e===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x147a43,['next','error','complete'])?_0x5090c8=_0x147a43:_0x5090c8={'next':_0x147a43,'error':_0x1d30f0,'complete':_0x18af3e},_0x5090c8['next']===void 0x0&&(_0x5090c8['next']=ti),_0x5090c8['error']===void 0x0&&(_0x5090c8['error']=ti),_0x5090c8['complete']===void 0x0&&(_0x5090c8['complete']=ti);const _0x253b9d=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x5090c8['error'](this['finalError']):_0x5090c8['complete']();}catch{}}),this['observers']['push'](_0x5090c8),_0x253b9d;}['unsubscribeOne'](_0x46a714){this['observers']===void 0x0||this['observers'][_0x46a714]===void 0x0||(delete this['observers'][_0x46a714],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x138dde){if(!this['finalized']){for(let _0x12dd43=0x0;_0x12dd43<this['observers']['length'];_0x12dd43++)this['sendOne'](_0x12dd43,_0x138dde);}}['sendOne'](_0x27460f,_0x1a680a){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x27460f]!==void 0x0)try{_0x1a680a(this['observers'][_0x27460f]);}catch(_0x3e2942){typeof console<'u'&&console['error']&&console['error'](_0x3e2942);}});}['close'](_0x4ea261){this['finalized']||(this['finalized']=!0x0,_0x4ea261!==void 0x0&&(this['finalError']=_0x4ea261),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0xefc6a8,_0x1da6f0){if(typeof _0xefc6a8!='object'||_0xefc6a8===null)return!0x1;for(const _0x9c42b6 of _0x1da6f0)if(_0x9c42b6 in _0xefc6a8&&typeof _0xefc6a8[_0x9c42b6]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x4c3cd6,_0x202fb4){return _0x4c3cd6+'\x20failed:\x20'+_0x202fb4+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x41be6c){const _0x279057=[];let _0x27b96a=0x0;for(let _0x42397e=0x0;_0x42397e<_0x41be6c['length'];_0x42397e++){let _0x345408=_0x41be6c['charCodeAt'](_0x42397e);if(_0x345408>=0xd800&&_0x345408<=0xdbff){const _0xca8080=_0x345408-0xd800;_0x42397e++,f(_0x42397e<_0x41be6c['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x5383a3=_0x41be6c['charCodeAt'](_0x42397e)-0xdc00;_0x345408=0x10000+(_0xca8080<<0xa)+_0x5383a3;}_0x345408<0x80?_0x279057[_0x27b96a++]=_0x345408:_0x345408<0x800?(_0x279057[_0x27b96a++]=_0x345408>>0x6|0xc0,_0x279057[_0x27b96a++]=_0x345408&0x3f|0x80):_0x345408<0x10000?(_0x279057[_0x27b96a++]=_0x345408>>0xc|0xe0,_0x279057[_0x27b96a++]=_0x345408>>0x6&0x3f|0x80,_0x279057[_0x27b96a++]=_0x345408&0x3f|0x80):(_0x279057[_0x27b96a++]=_0x345408>>0x12|0xf0,_0x279057[_0x27b96a++]=_0x345408>>0xc&0x3f|0x80,_0x279057[_0x27b96a++]=_0x345408>>0x6&0x3f|0x80,_0x279057[_0x27b96a++]=_0x345408&0x3f|0x80);}return _0x279057;},Ln=function(_0x275708){let _0x4f0a0b=0x0;for(let _0x30b354=0x0;_0x30b354<_0x275708['length'];_0x30b354++){const _0x5d4a3c=_0x275708['charCodeAt'](_0x30b354);_0x5d4a3c<0x80?_0x4f0a0b++:_0x5d4a3c<0x800?_0x4f0a0b+=0x2:_0x5d4a3c>=0xd800&&_0x5d4a3c<=0xdbff?(_0x4f0a0b+=0x4,_0x30b354++):_0x4f0a0b+=0x3;}return _0x4f0a0b;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x33fc9e){return _0x33fc9e&&_0x33fc9e['_delegate']?_0x33fc9e['_delegate']:_0x33fc9e;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x1dbc78){try{return(_0x1dbc78['startsWith']('http://')||_0x1dbc78['startsWith']('https://')?new URL(_0x1dbc78)['hostname']:_0x1dbc78)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x24cd83){return(await fetch(_0x24cd83,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x34937c,_0x296d8e,_0x3540d9){this['name']=_0x34937c,this['instanceFactory']=_0x296d8e,this['type']=_0x3540d9,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x202c54){return this['instantiationMode']=_0x202c54,this;}['setMultipleInstances'](_0x3ebf79){return this['multipleInstances']=_0x3ebf79,this;}['setServiceProps'](_0x33c0bc){return this['serviceProps']=_0x33c0bc,this;}['setInstanceCreatedCallback'](_0x5a161e){return this['onInstanceCreated']=_0x5a161e,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x356a6d,_0x501bff){this['name']=_0x356a6d,this['container']=_0x501bff,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x1ad475){const _0x9bc738=this['normalizeInstanceIdentifier'](_0x1ad475);if(!this['instancesDeferred']['has'](_0x9bc738)){const _0x1aa8a8=new H();if(this['instancesDeferred']['set'](_0x9bc738,_0x1aa8a8),this['isInitialized'](_0x9bc738)||this['shouldAutoInitialize']())try{const _0x3c8492=this['getOrInitializeService']({'instanceIdentifier':_0x9bc738});_0x3c8492&&_0x1aa8a8['resolve'](_0x3c8492);}catch{}}return this['instancesDeferred']['get'](_0x9bc738)['promise'];}['getImmediate'](_0x56cfa5){const _0x333068=this['normalizeInstanceIdentifier'](_0x56cfa5==null?void 0x0:_0x56cfa5['identifier']),_0x4411df=(_0x56cfa5==null?void 0x0:_0x56cfa5['optional'])??!0x1;if(this['isInitialized'](_0x333068)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x333068});}catch(_0x22690f){if(_0x4411df)return null;throw _0x22690f;}else{if(_0x4411df)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x22e71c){if(_0x22e71c['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x22e71c['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x22e71c,!!this['shouldAutoInitialize']()){if(Pc(_0x22e71c))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x3338da,_0x5aac04]of this['instancesDeferred']['entries']()){const _0x108f4a=this['normalizeInstanceIdentifier'](_0x3338da);try{const _0x24d6d0=this['getOrInitializeService']({'instanceIdentifier':_0x108f4a});_0x5aac04['resolve'](_0x24d6d0);}catch{}}}}['clearInstance'](_0x4a4de6=Ne){this['instancesDeferred']['delete'](_0x4a4de6),this['instancesOptions']['delete'](_0x4a4de6),this['instances']['delete'](_0x4a4de6);}async['delete'](){const _0x5b8d70=Array['from'](this['instances']['values']());await Promise['all']([..._0x5b8d70['filter'](_0x488e7b=>'INTERNAL'in _0x488e7b)['map'](_0x308d17=>_0x308d17['INTERNAL']['delete']()),..._0x5b8d70['filter'](_0xe49f18=>'_delete'in _0xe49f18)['map'](_0xb107a8=>_0xb107a8['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x110f0c=Ne){return this['instances']['has'](_0x110f0c);}['getOptions'](_0x1d6aae=Ne){return this['instancesOptions']['get'](_0x1d6aae)||{};}['initialize'](_0x260c49={}){const {options:_0x1f42cf={}}=_0x260c49,_0x567ab4=this['normalizeInstanceIdentifier'](_0x260c49['instanceIdentifier']);if(this['isInitialized'](_0x567ab4))throw Error(this['name']+'('+_0x567ab4+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x1de726=this['getOrInitializeService']({'instanceIdentifier':_0x567ab4,'options':_0x1f42cf});for(const [_0x206ca0,_0x5c0769]of this['instancesDeferred']['entries']()){const _0x1345a2=this['normalizeInstanceIdentifier'](_0x206ca0);_0x567ab4===_0x1345a2&&_0x5c0769['resolve'](_0x1de726);}return _0x1de726;}['onInit'](_0xa6ba4e,_0x28435b){const _0x3c012b=this['normalizeInstanceIdentifier'](_0x28435b),_0x1ca3e2=this['onInitCallbacks']['get'](_0x3c012b)??new Set();_0x1ca3e2['add'](_0xa6ba4e),this['onInitCallbacks']['set'](_0x3c012b,_0x1ca3e2);const _0x2d8b81=this['instances']['get'](_0x3c012b);return _0x2d8b81&&_0xa6ba4e(_0x2d8b81,_0x3c012b),()=>{_0x1ca3e2['delete'](_0xa6ba4e);};}['invokeOnInitCallbacks'](_0x505a7b,_0x3a62d9){const _0x4f0870=this['onInitCallbacks']['get'](_0x3a62d9);if(_0x4f0870){for(const _0x45be69 of _0x4f0870)try{_0x45be69(_0x505a7b,_0x3a62d9);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x23da36,options:_0x577c25={}}){let _0x51fd78=this['instances']['get'](_0x23da36);if(!_0x51fd78&&this['component']&&(_0x51fd78=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x23da36),'options':_0x577c25}),this['instances']['set'](_0x23da36,_0x51fd78),this['instancesOptions']['set'](_0x23da36,_0x577c25),this['invokeOnInitCallbacks'](_0x51fd78,_0x23da36),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x23da36,_0x51fd78);}catch{}return _0x51fd78||null;}['normalizeInstanceIdentifier'](_0x13e0c1=Ne){return this['component']?this['component']['multipleInstances']?_0x13e0c1:Ne:_0x13e0c1;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x470f92){return _0x470f92===Ne?void 0x0:_0x470f92;}function Pc(_0x392f82){return _0x392f82['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x3a2fcd){this['name']=_0x3a2fcd,this['providers']=new Map();}['addComponent'](_0x37af11){const _0xeb5c1d=this['getProvider'](_0x37af11['name']);if(_0xeb5c1d['isComponentSet']())throw new Error('Component\x20'+_0x37af11['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0xeb5c1d['setComponent'](_0x37af11);}['addOrOverwriteComponent'](_0x2b8724){this['getProvider'](_0x2b8724['name'])['isComponentSet']()&&this['providers']['delete'](_0x2b8724['name']),this['addComponent'](_0x2b8724);}['getProvider'](_0x157161){if(this['providers']['has'](_0x157161))return this['providers']['get'](_0x157161);const _0x44b629=new Ac(_0x157161,this);return this['providers']['set'](_0x157161,_0x44b629),_0x44b629;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x16c959){_0x16c959[_0x16c959['DEBUG']=0x0]='DEBUG',_0x16c959[_0x16c959['VERBOSE']=0x1]='VERBOSE',_0x16c959[_0x16c959['INFO']=0x2]='INFO',_0x16c959[_0x16c959['WARN']=0x3]='WARN',_0x16c959[_0x16c959['ERROR']=0x4]='ERROR',_0x16c959[_0x16c959['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x322366,_0x515434,..._0xe6a856)=>{if(_0x515434<_0x322366['logLevel'])return;const _0x1528b9=new Date()['toISOString'](),_0x2c8af9=Mc[_0x515434];if(_0x2c8af9)console[_0x2c8af9]('['+_0x1528b9+']\x20\x20'+_0x322366['name']+':',..._0xe6a856);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x515434+')');};class Bi{constructor(_0x1e218b){this['name']=_0x1e218b,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x82982a){if(!(_0x82982a in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x82982a+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x82982a;}['setLogLevel'](_0x7e75aa){this['_logLevel']=typeof _0x7e75aa=='string'?Oc[_0x7e75aa]:_0x7e75aa;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x5929af){if(typeof _0x5929af!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x5929af;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x36d96f){this['_userLogHandler']=_0x36d96f;}['debug'](..._0x1d9999){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x1d9999),this['_logHandler'](this,T['DEBUG'],..._0x1d9999);}['log'](..._0x126d02){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x126d02),this['_logHandler'](this,T['VERBOSE'],..._0x126d02);}['info'](..._0x3634e6){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x3634e6),this['_logHandler'](this,T['INFO'],..._0x3634e6);}['warn'](..._0x164fbe){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x164fbe),this['_logHandler'](this,T['WARN'],..._0x164fbe);}['error'](..._0x3e73e0){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x3e73e0),this['_logHandler'](this,T['ERROR'],..._0x3e73e0);}}const xc=(_0x227416,_0x61460b)=>_0x61460b['some'](_0x2c2730=>_0x227416 instanceof _0x2c2730);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x3165ca){const _0x235147=new Promise((_0x40b89f,_0x240eff)=>{const _0x48a1b3=()=>{_0x3165ca['removeEventListener']('success',_0x37bbce),_0x3165ca['removeEventListener']('error',_0x4a47a0);},_0x37bbce=()=>{_0x40b89f(ge(_0x3165ca['result'])),_0x48a1b3();},_0x4a47a0=()=>{_0x240eff(_0x3165ca['error']),_0x48a1b3();};_0x3165ca['addEventListener']('success',_0x37bbce),_0x3165ca['addEventListener']('error',_0x4a47a0);});return _0x235147['then'](_0x3eb62e=>{_0x3eb62e instanceof IDBCursor&&Jr['set'](_0x3eb62e,_0x3165ca);})['catch'](()=>{}),Vi['set'](_0x235147,_0x3165ca),_0x235147;}function Bc(_0xe8fd5e){if(_i['has'](_0xe8fd5e))return;const _0x556f4c=new Promise((_0x7ee5e0,_0x4ba461)=>{const _0x68446c=()=>{_0xe8fd5e['removeEventListener']('complete',_0x72362a),_0xe8fd5e['removeEventListener']('error',_0x97cb18),_0xe8fd5e['removeEventListener']('abort',_0x97cb18);},_0x72362a=()=>{_0x7ee5e0(),_0x68446c();},_0x97cb18=()=>{_0x4ba461(_0xe8fd5e['error']||new DOMException('AbortError','AbortError')),_0x68446c();};_0xe8fd5e['addEventListener']('complete',_0x72362a),_0xe8fd5e['addEventListener']('error',_0x97cb18),_0xe8fd5e['addEventListener']('abort',_0x97cb18);});_i['set'](_0xe8fd5e,_0x556f4c);}let gi={'get'(_0x25c4cc,_0x576aa1,_0x2957ae){if(_0x25c4cc instanceof IDBTransaction){if(_0x576aa1==='done')return _i['get'](_0x25c4cc);if(_0x576aa1==='objectStoreNames')return _0x25c4cc['objectStoreNames']||Xr['get'](_0x25c4cc);if(_0x576aa1==='store')return _0x2957ae['objectStoreNames'][0x1]?void 0x0:_0x2957ae['objectStore'](_0x2957ae['objectStoreNames'][0x0]);}return ge(_0x25c4cc[_0x576aa1]);},'set'(_0x11a378,_0x314dd2,_0x3b5461){return _0x11a378[_0x314dd2]=_0x3b5461,!0x0;},'has'(_0x1bc8dc,_0x4fbb82){return _0x1bc8dc instanceof IDBTransaction&&(_0x4fbb82==='done'||_0x4fbb82==='store')?!0x0:_0x4fbb82 in _0x1bc8dc;}};function Vc(_0x1101c5){gi=_0x1101c5(gi);}function Hc(_0x4ecb01){return _0x4ecb01===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x5c7c00,..._0x28a287){const _0x566f12=_0x4ecb01['call'](ii(this),_0x5c7c00,..._0x28a287);return Xr['set'](_0x566f12,_0x5c7c00['sort']?_0x5c7c00['sort']():[_0x5c7c00]),ge(_0x566f12);}:Uc()['includes'](_0x4ecb01)?function(..._0x477282){return _0x4ecb01['apply'](ii(this),_0x477282),ge(Jr['get'](this));}:function(..._0x522518){return ge(_0x4ecb01['apply'](ii(this),_0x522518));};}function $c(_0x1a78cb){return typeof _0x1a78cb=='function'?Hc(_0x1a78cb):(_0x1a78cb instanceof IDBTransaction&&Bc(_0x1a78cb),xc(_0x1a78cb,Fc())?new Proxy(_0x1a78cb,gi):_0x1a78cb);}function ge(_0x2aa9ef){if(_0x2aa9ef instanceof IDBRequest)return Wc(_0x2aa9ef);if(ni['has'](_0x2aa9ef))return ni['get'](_0x2aa9ef);const _0x16e16c=$c(_0x2aa9ef);return _0x16e16c!==_0x2aa9ef&&(ni['set'](_0x2aa9ef,_0x16e16c),Vi['set'](_0x16e16c,_0x2aa9ef)),_0x16e16c;}const ii=_0x315218=>Vi['get'](_0x315218);function Gc(_0xd74c7a,_0x5ebf75,{blocked:_0x622897,upgrade:_0x522eb4,blocking:_0x47f606,terminated:_0x5928a9}={}){const _0x17e929=indexedDB['open'](_0xd74c7a,_0x5ebf75),_0x15fb82=ge(_0x17e929);return _0x522eb4&&_0x17e929['addEventListener']('upgradeneeded',_0x4b7693=>{_0x522eb4(ge(_0x17e929['result']),_0x4b7693['oldVersion'],_0x4b7693['newVersion'],ge(_0x17e929['transaction']),_0x4b7693);}),_0x622897&&_0x17e929['addEventListener']('blocked',_0x340250=>_0x622897(_0x340250['oldVersion'],_0x340250['newVersion'],_0x340250)),_0x15fb82['then'](_0x4ee877=>{_0x5928a9&&_0x4ee877['addEventListener']('close',()=>_0x5928a9()),_0x47f606&&_0x4ee877['addEventListener']('versionchange',_0x5d63af=>_0x47f606(_0x5d63af['oldVersion'],_0x5d63af['newVersion'],_0x5d63af));})['catch'](()=>{}),_0x15fb82;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x2a803d,_0x1ddbbc){if(!(_0x2a803d instanceof IDBDatabase&&!(_0x1ddbbc in _0x2a803d)&&typeof _0x1ddbbc=='string'))return;if(si['get'](_0x1ddbbc))return si['get'](_0x1ddbbc);const _0x43cf6f=_0x1ddbbc['replace'](/FromIndex$/,''),_0x492ef8=_0x1ddbbc!==_0x43cf6f,_0x240cac=zc['includes'](_0x43cf6f);if(!(_0x43cf6f in(_0x492ef8?IDBIndex:IDBObjectStore)['prototype'])||!(_0x240cac||qc['includes'](_0x43cf6f)))return;const _0x116674=async function(_0x1635b8,..._0x163e44){const _0x3ea421=this['transaction'](_0x1635b8,_0x240cac?'readwrite':'readonly');let _0x38abbd=_0x3ea421['store'];return _0x492ef8&&(_0x38abbd=_0x38abbd['index'](_0x163e44['shift']())),(await Promise['all']([_0x38abbd[_0x43cf6f](..._0x163e44),_0x240cac&&_0x3ea421['done']]))[0x0];};return si['set'](_0x1ddbbc,_0x116674),_0x116674;}Vc(_0x2936c2=>({..._0x2936c2,'get':(_0x4827d0,_0x380ba3,_0x51a198)=>Ms(_0x4827d0,_0x380ba3)||_0x2936c2['get'](_0x4827d0,_0x380ba3,_0x51a198),'has':(_0x2e39b1,_0x218b6e)=>!!Ms(_0x2e39b1,_0x218b6e)||_0x2936c2['has'](_0x2e39b1,_0x218b6e)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x344329){this['container']=_0x344329;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x323a24=>{if(Kc(_0x323a24)){const _0x311fb3=_0x323a24['getImmediate']();return _0x311fb3['library']+'/'+_0x311fb3['version'];}else return null;})['filter'](_0x34430=>_0x34430)['join']('\x20');}}function Kc(_0x437ace){const _0x1dd87d=_0x437ace['getComponent']();return(_0x1dd87d==null?void 0x0:_0x1dd87d['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x6e1984,_0x357951){try{_0x6e1984['container']['addComponent'](_0x357951);}catch(_0x35e184){oe['debug']('Component\x20'+_0x357951['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x6e1984['name'],_0x35e184);}}function st(_0x1c2238){const _0x5eacdd=_0x1c2238['name'];if(Ei['has'](_0x5eacdd))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x5eacdd+'.'),!0x1;Ei['set'](_0x5eacdd,_0x1c2238);for(const _0x5e3bd8 of Ue['values']())xs(_0x5e3bd8,_0x1c2238);for(const _0x3e6b28 of vi['values']())xs(_0x3e6b28,_0x1c2238);return!0x0;}function Hi(_0x23bc4c,_0x5914d2){const _0x32e435=_0x23bc4c['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x32e435&&_0x32e435['triggerHeartbeat'](),_0x23bc4c['container']['getProvider'](_0x5914d2);}function $(_0xc4e283){return _0xc4e283==null?!0x1:_0xc4e283['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x414e4c,_0x5a21c5,_0x3b639d){this['_isDeleted']=!0x1,this['_options']={..._0x414e4c},this['_config']={..._0x5a21c5},this['_name']=_0x5a21c5['name'],this['_automaticDataCollectionEnabled']=_0x5a21c5['automaticDataCollectionEnabled'],this['_container']=_0x3b639d,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x1e1734){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x1e1734;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x5bcbb4){this['_isDeleted']=_0x5bcbb4;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x2edf96,_0x374833={}){let _0xaa0d48=_0x2edf96;typeof _0x374833!='object'&&(_0x374833={'name':_0x374833});const _0x4ee7da={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x374833},_0x14f751=_0x4ee7da['name'];if(typeof _0x14f751!='string'||!_0x14f751)throw me['create']('bad-app-name',{'appName':String(_0x14f751)});if(_0xaa0d48||(_0xaa0d48=zr()),!_0xaa0d48)throw me['create']('no-options');const _0x182c03=Ue['get'](_0x14f751);if(_0x182c03){if(xe(_0xaa0d48,_0x182c03['options'])&&xe(_0x4ee7da,_0x182c03['config']))return _0x182c03;throw me['create']('duplicate-app',{'appName':_0x14f751});}const _0x269bdd=new Nc(_0x14f751);for(const _0x4fab80 of Ei['values']())_0x269bdd['addComponent'](_0x4fab80);const _0x24d535=new Tl(_0xaa0d48,_0x4ee7da,_0x269bdd);return Ue['set'](_0x14f751,_0x24d535),_0x24d535;}function Zr(_0x47e9be=yi){const _0x52b89e=Ue['get'](_0x47e9be);if(!_0x52b89e&&_0x47e9be===yi&&zr())return Sl();if(!_0x52b89e)throw me['create']('no-app',{'appName':_0x47e9be});return _0x52b89e;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x2ca6ac){let _0x1c5a7a=!0x1;const _0x22e570=_0x2ca6ac['name'];Ue['has'](_0x22e570)?(_0x1c5a7a=!0x0,Ue['delete'](_0x22e570)):vi['has'](_0x22e570)&&_0x2ca6ac['decRefCount']()<=0x0&&(vi['delete'](_0x22e570),_0x1c5a7a=!0x0),_0x1c5a7a&&(await Promise['all'](_0x2ca6ac['container']['getProviders']()['map'](_0x2ae6e2=>_0x2ae6e2['delete']())),_0x2ca6ac['isDeleted']=!0x0);}function ye(_0x44bb49,_0xc9db33,_0x44a602){let _0x481aa1=wl[_0x44bb49]??_0x44bb49;_0x44a602&&(_0x481aa1+='-'+_0x44a602);const _0x3d9f0a=_0x481aa1['match'](/\s|\//),_0x138697=_0xc9db33['match'](/\s|\//);if(_0x3d9f0a||_0x138697){const _0x2f0df4=['Unable\x20to\x20register\x20library\x20\x22'+_0x481aa1+'\x22\x20with\x20version\x20\x22'+_0xc9db33+'\x22:'];_0x3d9f0a&&_0x2f0df4['push']('library\x20name\x20\x22'+_0x481aa1+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x3d9f0a&&_0x138697&&_0x2f0df4['push']('and'),_0x138697&&_0x2f0df4['push']('version\x20name\x20\x22'+_0xc9db33+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x2f0df4['join']('\x20'));return;}st(new Fe(_0x481aa1+'-version',()=>({'library':_0x481aa1,'version':_0xc9db33}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x23a339,_0x429616)=>{switch(_0x429616){case 0x0:try{_0x23a339['createObjectStore'](Ot);}catch(_0x5596a2){console['warn'](_0x5596a2);}}}})['catch'](_0x4dd070=>{throw me['create']('idb-open',{'originalErrorMessage':_0x4dd070['message']});})),ri;}async function Al(_0x1ab80f){try{const _0x636f8c=(await eo())['transaction'](Ot),_0x31ec74=await _0x636f8c['objectStore'](Ot)['get'](to(_0x1ab80f));return await _0x636f8c['done'],_0x31ec74;}catch(_0x483614){if(_0x483614 instanceof Re)oe['warn'](_0x483614['message']);else{const _0x366076=me['create']('idb-get',{'originalErrorMessage':_0x483614==null?void 0x0:_0x483614['message']});oe['warn'](_0x366076['message']);}}}async function Fs(_0x78fd9d,_0xfd3a6f){try{const _0x17f298=(await eo())['transaction'](Ot,'readwrite');await _0x17f298['objectStore'](Ot)['put'](_0xfd3a6f,to(_0x78fd9d)),await _0x17f298['done'];}catch(_0x465866){if(_0x465866 instanceof Re)oe['warn'](_0x465866['message']);else{const _0xa1629=me['create']('idb-set',{'originalErrorMessage':_0x465866==null?void 0x0:_0x465866['message']});oe['warn'](_0xa1629['message']);}}}function to(_0x36eff5){return _0x36eff5['name']+'!'+_0x36eff5['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x339380){this['container']=_0x339380,this['_heartbeatsCache']=null;const _0x4a0290=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x4a0290),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x5ee445=>(this['_heartbeatsCache']=_0x5ee445,_0x5ee445));}async['triggerHeartbeat'](){var _0x1af15d,_0x35d898;try{const _0x590294=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x2624c0=Us();if(((_0x1af15d=this['_heartbeatsCache'])==null?void 0x0:_0x1af15d['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x35d898=this['_heartbeatsCache'])==null?void 0x0:_0x35d898['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x2624c0||this['_heartbeatsCache']['heartbeats']['some'](_0x546cdb=>_0x546cdb['date']===_0x2624c0))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x2624c0,'agent':_0x590294}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x5833f6=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x5833f6,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x3718f5){oe['warn'](_0x3718f5);}}async['getHeartbeatsHeader'](){var _0x5e8df0;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x5e8df0=this['_heartbeatsCache'])==null?void 0x0:_0x5e8df0['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x4e71ca=Us(),{heartbeatsToSend:_0x2666b9,unsentEntries:_0x8d9a6e}=Ol(this['_heartbeatsCache']['heartbeats']),_0x2a3b7e=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x2666b9}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x4e71ca,_0x8d9a6e['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x8d9a6e,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x2a3b7e;}catch(_0x4b31ae){return oe['warn'](_0x4b31ae),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x4099fe,_0x4d84e2=kl){const _0x28e969=[];let _0x1c026d=_0x4099fe['slice']();for(const _0x21d00b of _0x4099fe){const _0x53355e=_0x28e969['find'](_0x564790=>_0x564790['agent']===_0x21d00b['agent']);if(_0x53355e){if(_0x53355e['dates']['push'](_0x21d00b['date']),Ws(_0x28e969)>_0x4d84e2){_0x53355e['dates']['pop']();break;}}else{if(_0x28e969['push']({'agent':_0x21d00b['agent'],'dates':[_0x21d00b['date']]}),Ws(_0x28e969)>_0x4d84e2){_0x28e969['pop']();break;}}_0x1c026d=_0x1c026d['slice'](0x1);}return{'heartbeatsToSend':_0x28e969,'unsentEntries':_0x1c026d};}class Dl{constructor(_0x3da36e){this['app']=_0x3da36e,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x295184=await Al(this['app']);return _0x295184!=null&&_0x295184['heartbeats']?_0x295184:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x4671c3){if(await this['_canUseIndexedDBPromise']){const _0x36afec=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x4671c3['lastSentHeartbeatDate']??_0x36afec['lastSentHeartbeatDate'],'heartbeats':_0x4671c3['heartbeats']});}else return;}async['add'](_0x5b0bf9){if(await this['_canUseIndexedDBPromise']){const _0x9d2d0c=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x5b0bf9['lastSentHeartbeatDate']??_0x9d2d0c['lastSentHeartbeatDate'],'heartbeats':[..._0x9d2d0c['heartbeats'],..._0x5b0bf9['heartbeats']]});}else return;}}function Ws(_0x43dd64){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x43dd64}))['length'];}function Ml(_0xa0dc09){if(_0xa0dc09['length']===0x0)return-0x1;let _0x26d364=0x0,_0x564df7=_0xa0dc09[0x0]['date'];for(let _0x212d2c=0x1;_0x212d2c<_0xa0dc09['length'];_0x212d2c++)_0xa0dc09[_0x212d2c]['date']<_0x564df7&&(_0x564df7=_0xa0dc09[_0x212d2c]['date'],_0x26d364=_0x212d2c);return _0x26d364;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x2e7e5a){st(new Fe('platform-logger',_0x13a72a=>new jc(_0x13a72a),'PRIVATE')),st(new Fe('heartbeat',_0x371f34=>new Nl(_0x371f34),'PRIVATE')),ye(mi,Ls,_0x2e7e5a),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x5503bf){no=_0x5503bf;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x19941c){this['domStorage_']=_0x19941c,this['prefix_']='firebase:';}['set'](_0x58fec1,_0x25a129){_0x25a129==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x58fec1)):this['domStorage_']['setItem'](this['prefixedName_'](_0x58fec1),O(_0x25a129));}['get'](_0x2e22b3){const _0x241624=this['domStorage_']['getItem'](this['prefixedName_'](_0x2e22b3));return _0x241624==null?null:Nt(_0x241624);}['remove'](_0x25f23a){this['domStorage_']['removeItem'](this['prefixedName_'](_0x25f23a));}['prefixedName_'](_0x4161f6){return this['prefix_']+_0x4161f6;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x587c80,_0x4fbf36){_0x4fbf36==null?delete this['cache_'][_0x587c80]:this['cache_'][_0x587c80]=_0x4fbf36;}['get'](_0x4f6ab1){return Q(this['cache_'],_0x4f6ab1)?this['cache_'][_0x4f6ab1]:null;}['remove'](_0x4fd46f){delete this['cache_'][_0x4fd46f];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x4b2fc3){try{if(typeof window<'u'&&typeof window[_0x4b2fc3]<'u'){const _0x3c0b16=window[_0x4b2fc3];return _0x3c0b16['setItem']('firebase:sentinel','cache'),_0x3c0b16['removeItem']('firebase:sentinel'),new Wl(_0x3c0b16);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x108948=0x1;return function(){return _0x108948++;};}()),ro=function(_0xdc9c89){const _0x3a1c20=Rc(_0xdc9c89),_0x431071=new Cc();_0x431071['update'](_0x3a1c20);const _0x2aab7c=_0x431071['digest']();return Fi['encodeByteArray'](_0x2aab7c);},zt=function(..._0x311599){let _0x4a4122='';for(let _0x103e53=0x0;_0x103e53<_0x311599['length'];_0x103e53++){const _0x590a68=_0x311599[_0x103e53];Array['isArray'](_0x590a68)||_0x590a68&&typeof _0x590a68=='object'&&typeof _0x590a68['length']=='number'?_0x4a4122+=zt['apply'](null,_0x590a68):typeof _0x590a68=='object'?_0x4a4122+=O(_0x590a68):_0x4a4122+=_0x590a68,_0x4a4122+='\x20';}return _0x4a4122;};let St=null,$s=!0x0;const Hl=function(_0x395994,_0x42bb9f){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x5de8e4){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x21ebf7=zt['apply'](null,_0x5de8e4);St(_0x21ebf7);}},jt=function(_0x3cf9a8){return function(..._0x3d7d6c){L(_0x3cf9a8,..._0x3d7d6c);};},Ii=function(..._0x2f0415){const _0x1d7886='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x2f0415);Ze['error'](_0x1d7886);},ae=function(..._0x175852){const _0x398495='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x175852);throw Ze['error'](_0x398495),new Error(_0x398495);},U=function(..._0xde580b){const _0x37ca0d='FIREBASE\x20WARNING:\x20'+zt(..._0xde580b);Ze['warn'](_0x37ca0d);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x38ec50){return typeof _0x38ec50=='number'&&(_0x38ec50!==_0x38ec50||_0x38ec50===Number['POSITIVE_INFINITY']||_0x38ec50===Number['NEGATIVE_INFINITY']);},Gl=function(_0x3bb27e){if(document['readyState']==='complete')_0x3bb27e();else{let _0x9cfa84=!0x1;const _0x37c4ab=function(){if(!document['body']){setTimeout(_0x37c4ab,Math['floor'](0xa));return;}_0x9cfa84||(_0x9cfa84=!0x0,_0x3bb27e());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x37c4ab,!0x1),window['addEventListener']('load',_0x37c4ab,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x37c4ab();}),window['attachEvent']('onload',_0x37c4ab));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x5481ce,_0xe7a533){if(_0x5481ce===_0xe7a533)return 0x0;if(_0x5481ce===We||_0xe7a533===we)return-0x1;if(_0xe7a533===We||_0x5481ce===we)return 0x1;{const _0x47953a=Gs(_0x5481ce),_0x3b4a46=Gs(_0xe7a533);return _0x47953a!==null?_0x3b4a46!==null?_0x47953a-_0x3b4a46===0x0?_0x5481ce['length']-_0xe7a533['length']:_0x47953a-_0x3b4a46:-0x1:_0x3b4a46!==null?0x1:_0x5481ce<_0xe7a533?-0x1:0x1;}},ql=function(_0x3fbdfe,_0xdc949f){return _0x3fbdfe===_0xdc949f?0x0:_0x3fbdfe<_0xdc949f?-0x1:0x1;},vt=function(_0x5bbd6f,_0x238e1b){if(_0x238e1b&&_0x5bbd6f in _0x238e1b)return _0x238e1b[_0x5bbd6f];throw new Error('Missing\x20required\x20key\x20('+_0x5bbd6f+')\x20in\x20object:\x20'+O(_0x238e1b));},$i=function(_0x249a0f){if(typeof _0x249a0f!='object'||_0x249a0f===null)return O(_0x249a0f);const _0x3b1caa=[];for(const _0x2f55ff in _0x249a0f)_0x3b1caa['push'](_0x2f55ff);_0x3b1caa['sort']();let _0x58ddbb='{';for(let _0x23a86f=0x0;_0x23a86f<_0x3b1caa['length'];_0x23a86f++)_0x23a86f!==0x0&&(_0x58ddbb+=','),_0x58ddbb+=O(_0x3b1caa[_0x23a86f]),_0x58ddbb+=':',_0x58ddbb+=$i(_0x249a0f[_0x3b1caa[_0x23a86f]]);return _0x58ddbb+='}',_0x58ddbb;},oo=function(_0x2ea490,_0xf8ce0a){const _0x2c1148=_0x2ea490['length'];if(_0x2c1148<=_0xf8ce0a)return[_0x2ea490];const _0x418533=[];for(let _0x241f75=0x0;_0x241f75<_0x2c1148;_0x241f75+=_0xf8ce0a)_0x241f75+_0xf8ce0a>_0x2c1148?_0x418533['push'](_0x2ea490['substring'](_0x241f75,_0x2c1148)):_0x418533['push'](_0x2ea490['substring'](_0x241f75,_0x241f75+_0xf8ce0a));return _0x418533;};function x(_0x369dff,_0x3f3567){for(const _0x3c91a8 in _0x369dff)_0x369dff['hasOwnProperty'](_0x3c91a8)&&_0x3f3567(_0x3c91a8,_0x369dff[_0x3c91a8]);}const ao=function(_0x559518){f(!xn(_0x559518),'Invalid\x20JSON\x20number');const _0x432dda=0xb,_0x650050=0x34,_0x197ef7=(0x1<<_0x432dda-0x1)-0x1;let _0x421389,_0x2133c4,_0x5a7930,_0x4a6f56,_0x3dba8b;_0x559518===0x0?(_0x2133c4=0x0,_0x5a7930=0x0,_0x421389=0x1/_0x559518===-0x1/0x0?0x1:0x0):(_0x421389=_0x559518<0x0,_0x559518=Math['abs'](_0x559518),_0x559518>=Math['pow'](0x2,0x1-_0x197ef7)?(_0x4a6f56=Math['min'](Math['floor'](Math['log'](_0x559518)/Math['LN2']),_0x197ef7),_0x2133c4=_0x4a6f56+_0x197ef7,_0x5a7930=Math['round'](_0x559518*Math['pow'](0x2,_0x650050-_0x4a6f56)-Math['pow'](0x2,_0x650050))):(_0x2133c4=0x0,_0x5a7930=Math['round'](_0x559518/Math['pow'](0x2,0x1-_0x197ef7-_0x650050))));const _0x403555=[];for(_0x3dba8b=_0x650050;_0x3dba8b;_0x3dba8b-=0x1)_0x403555['push'](_0x5a7930%0x2?0x1:0x0),_0x5a7930=Math['floor'](_0x5a7930/0x2);for(_0x3dba8b=_0x432dda;_0x3dba8b;_0x3dba8b-=0x1)_0x403555['push'](_0x2133c4%0x2?0x1:0x0),_0x2133c4=Math['floor'](_0x2133c4/0x2);_0x403555['push'](_0x421389?0x1:0x0),_0x403555['reverse']();const _0x2a1752=_0x403555['join']('');let _0x29f24f='';for(_0x3dba8b=0x0;_0x3dba8b<0x40;_0x3dba8b+=0x8){let _0x2670bb=parseInt(_0x2a1752['substr'](_0x3dba8b,0x8),0x2)['toString'](0x10);_0x2670bb['length']===0x1&&(_0x2670bb='0'+_0x2670bb),_0x29f24f=_0x29f24f+_0x2670bb;}return _0x29f24f['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x2f976d,_0x5474a8){let _0x48e37c='Unknown\x20Error';_0x2f976d==='too_big'?_0x48e37c='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x2f976d==='permission_denied'?_0x48e37c='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x2f976d==='unavailable'&&(_0x48e37c='The\x20service\x20is\x20unavailable');const _0x17668a=new Error(_0x2f976d+'\x20at\x20'+_0x5474a8['_path']['toString']()+':\x20'+_0x48e37c);return _0x17668a['code']=_0x2f976d['toUpperCase'](),_0x17668a;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x31d546){if(Yl['test'](_0x31d546)){const _0x48f9c8=Number(_0x31d546);if(_0x48f9c8>=Ql&&_0x48f9c8<=Jl)return _0x48f9c8;}return null;},ft=function(_0x5bed7d){try{_0x5bed7d();}catch(_0x3b3d57){setTimeout(()=>{const _0x4996fb=_0x3b3d57['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x4996fb),_0x3b3d57;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x453028,_0x29a6bd){const _0x834ac9=setTimeout(_0x453028,_0x29a6bd);return typeof _0x834ac9=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x834ac9):typeof _0x834ac9=='object'&&_0x834ac9['unref']&&_0x834ac9['unref'](),_0x834ac9;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0xa4b4fe,_0x45a7ec){this['appCheckProvider']=_0x45a7ec,this['appName']=_0xa4b4fe['name'],$(_0xa4b4fe)&&_0xa4b4fe['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0xa4b4fe['settings']['appCheckToken']),this['appCheck']=_0x45a7ec==null?void 0x0:_0x45a7ec['getImmediate']({'optional':!0x0}),this['appCheck']||_0x45a7ec==null||_0x45a7ec['get']()['then'](_0x1c4198=>this['appCheck']=_0x1c4198);}['getToken'](_0x19f3f5){if(this['serverAppAppCheckToken']){if(_0x19f3f5)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x19f3f5):new Promise((_0x410d73,_0x63e532)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x19f3f5)['then'](_0x410d73,_0x63e532):_0x410d73(null);},0x0);});}['addTokenChangeListener'](_0x1ccd2c){var _0x5c76eb;(_0x5c76eb=this['appCheckProvider'])==null||_0x5c76eb['get']()['then'](_0x39e4da=>_0x39e4da['addTokenListener'](_0x1ccd2c));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x4de5aa,_0x2ce039,_0x361411){this['appName_']=_0x4de5aa,this['firebaseOptions_']=_0x2ce039,this['authProvider_']=_0x361411,this['auth_']=null,this['auth_']=_0x361411['getImmediate']({'optional':!0x0}),this['auth_']||_0x361411['onInit'](_0x4aefa5=>this['auth_']=_0x4aefa5);}['getToken'](_0x1211ca){return this['auth_']?this['auth_']['getToken'](_0x1211ca)['catch'](_0x4ff44d=>_0x4ff44d&&_0x4ff44d['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x4ff44d)):new Promise((_0x586ce5,_0x1d84fd)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x1211ca)['then'](_0x586ce5,_0x1d84fd):_0x586ce5(null);},0x0);});}['addTokenChangeListener'](_0x15f1b7){this['auth_']?this['auth_']['addAuthTokenListener'](_0x15f1b7):this['authProvider_']['get']()['then'](_0x3f5844=>_0x3f5844['addAuthTokenListener'](_0x15f1b7));}['removeTokenChangeListener'](_0x399234){this['authProvider_']['get']()['then'](_0x45f9f1=>_0x45f9f1['removeAuthTokenListener'](_0x399234));}['notifyForInvalidToken'](){let _0x12ab33='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x12ab33+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x12ab33+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x12ab33+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x12ab33);}}class an{constructor(_0x29f313){this['accessToken']=_0x29f313;}['getToken'](_0x54984c){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x119cca){_0x119cca(this['accessToken']);}['removeTokenChangeListener'](_0x214c4b){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x4e8601,_0x2d1594,_0x9cbde5,_0x206ee8,_0xad7d5c=!0x1,_0x57b7a3='',_0x1a573b=!0x1,_0x10ee2a=!0x1,_0x43b46f=null){this['secure']=_0x2d1594,this['namespace']=_0x9cbde5,this['webSocketOnly']=_0x206ee8,this['nodeAdmin']=_0xad7d5c,this['persistenceKey']=_0x57b7a3,this['includeNamespaceInQueryParams']=_0x1a573b,this['isUsingEmulator']=_0x10ee2a,this['emulatorOptions']=_0x43b46f,this['_host']=_0x4e8601['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x4e8601)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x1f7ab6){_0x1f7ab6!==this['internalHost']&&(this['internalHost']=_0x1f7ab6,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x17f9e1=this['toURLString']();return this['persistenceKey']&&(_0x17f9e1+='<'+this['persistenceKey']+'>'),_0x17f9e1;}['toURLString'](){const _0x2b6358=this['secure']?'https://':'http://',_0x363056=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x2b6358+this['host']+'/'+_0x363056;}}function th(_0x45dade){return _0x45dade['host']!==_0x45dade['internalHost']||_0x45dade['isCustomHost']()||_0x45dade['includeNamespaceInQueryParams'];}function vo(_0x273243,_0x58065c,_0x4b1b5f){f(typeof _0x58065c=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x4b1b5f=='object','typeof\x20params\x20must\x20==\x20object');let _0x2a80bf;if(_0x58065c===go)_0x2a80bf=(_0x273243['secure']?'wss://':'ws://')+_0x273243['internalHost']+'/.ws?';else{if(_0x58065c===mo)_0x2a80bf=(_0x273243['secure']?'https://':'http://')+_0x273243['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x58065c);}th(_0x273243)&&(_0x4b1b5f['ns']=_0x273243['namespace']);const _0x28b774=[];return x(_0x4b1b5f,(_0x3e7f33,_0x12e67e)=>{_0x28b774['push'](_0x3e7f33+'='+_0x12e67e);}),_0x2a80bf+_0x28b774['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x47310b,_0xa3e8a3=0x1){Q(this['counters_'],_0x47310b)||(this['counters_'][_0x47310b]=0x0),this['counters_'][_0x47310b]+=_0xa3e8a3;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0xd40470){const _0x40acda=_0xd40470['toString']();return oi[_0x40acda]||(oi[_0x40acda]=new nh()),oi[_0x40acda];}function ih(_0x38e978,_0x58a7f5){const _0x7a1010=_0x38e978['toString']();return ai[_0x7a1010]||(ai[_0x7a1010]=_0x58a7f5()),ai[_0x7a1010];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x3346f5){this['onMessage_']=_0x3346f5,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x3ade81,_0x465ccc){this['closeAfterResponse']=_0x3ade81,this['onClose']=_0x465ccc,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x1505cb,_0x3cf229){for(this['pendingResponses'][_0x1505cb]=_0x3cf229;this['pendingResponses'][this['currentResponseNum']];){const _0x28e941=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x69058a=0x0;_0x69058a<_0x28e941['length'];++_0x69058a)_0x28e941[_0x69058a]&&ft(()=>{this['onMessage_'](_0x28e941[_0x69058a]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x259eb9,_0x58103c,_0x55fccd,_0x42b7e0,_0x1594ef,_0x46680b,_0x57a628){this['connId']=_0x259eb9,this['repoInfo']=_0x58103c,this['applicationId']=_0x55fccd,this['appCheckToken']=_0x42b7e0,this['authToken']=_0x1594ef,this['transportSessionId']=_0x46680b,this['lastSessionId']=_0x57a628,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x259eb9),this['stats_']=qi(_0x58103c),this['urlFn']=_0x2ac787=>(this['appCheckToken']&&(_0x2ac787[wi]=this['appCheckToken']),vo(_0x58103c,mo,_0x2ac787));}['open'](_0x36159e,_0x2c1794){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x2c1794,this['myPacketOrderer']=new sh(_0x36159e),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x374498)=>{const [_0x4d5eee,_0x597257,_0x88e6dd,_0x3bb586,_0x426c07]=_0x374498;if(this['incrementIncomingBytes_'](_0x374498),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x4d5eee===qs)this['id']=_0x597257,this['password']=_0x88e6dd;else{if(_0x4d5eee===rh)_0x597257?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x597257,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x4d5eee);}}},(..._0x5eab43)=>{const [_0x38cd47,_0xf21796]=_0x5eab43;this['incrementIncomingBytes_'](_0x5eab43),this['myPacketOrderer']['handleResponse'](_0x38cd47,_0xf21796);},()=>{this['onClosed_']();},this['urlFn']);const _0x29a7dc={};_0x29a7dc[qs]='t',_0x29a7dc[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x29a7dc[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x29a7dc[co]=Gi,this['transportSessionId']&&(_0x29a7dc[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x29a7dc[po]=this['lastSessionId']),this['applicationId']&&(_0x29a7dc[_o]=this['applicationId']),this['appCheckToken']&&(_0x29a7dc[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x29a7dc[ho]=uo);const _0xa1fed6=this['urlFn'](_0x29a7dc);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0xa1fed6),this['scriptTagHolder']['addTag'](_0xa1fed6,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x5d75cb){const _0x442e19=O(_0x5d75cb);this['bytesSent']+=_0x442e19['length'],this['stats_']['incrementCounter']('bytes_sent',_0x442e19['length']);const _0x5c399e=$r(_0x442e19),_0x3d18c6=oo(_0x5c399e,fh);for(let _0x1fddab=0x0;_0x1fddab<_0x3d18c6['length'];_0x1fddab++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x3d18c6['length'],_0x3d18c6[_0x1fddab]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x4c38b5,_0x542e5c){this['myDisconnFrame']=document['createElement']('iframe');const _0x27b12d={};_0x27b12d[dh]='t',_0x27b12d[Eo]=_0x4c38b5,_0x27b12d[Io]=_0x542e5c,this['myDisconnFrame']['src']=this['urlFn'](_0x27b12d),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x9bc6ee){const _0x59bcc7=O(_0x9bc6ee)['length'];this['bytesReceived']+=_0x59bcc7,this['stats_']['incrementCounter']('bytes_received',_0x59bcc7);}}class zi{constructor(_0x22f35a,_0x3b1278,_0x5d3d07,_0x577c21){this['onDisconnect']=_0x5d3d07,this['urlFn']=_0x577c21,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x22f35a,window[ah+this['uniqueCallbackIdentifier']]=_0x3b1278,this['myIFrame']=zi['createIFrame_']();let _0xc7db6='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0xc7db6='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x4dd53c='<html><body>'+_0xc7db6+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x4dd53c),this['myIFrame']['doc']['close']();}catch(_0x944789){L('frame\x20writing\x20exception'),_0x944789['stack']&&L(_0x944789['stack']),L(_0x944789);}}}static['createIFrame_'](){const _0x2ee660=document['createElement']('iframe');if(_0x2ee660['style']['display']='none',document['body']){document['body']['appendChild'](_0x2ee660);try{_0x2ee660['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x1a83d0=document['domain'];_0x2ee660['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x1a83d0+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x2ee660['contentDocument']?_0x2ee660['doc']=_0x2ee660['contentDocument']:_0x2ee660['contentWindow']?_0x2ee660['doc']=_0x2ee660['contentWindow']['document']:_0x2ee660['document']&&(_0x2ee660['doc']=_0x2ee660['document']),_0x2ee660;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x467c2c=this['onDisconnect'];_0x467c2c&&(this['onDisconnect']=null,_0x467c2c());}['startLongPoll'](_0x52c80b,_0x3f418f){for(this['myID']=_0x52c80b,this['myPW']=_0x3f418f,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x997060={};_0x997060[Eo]=this['myID'],_0x997060[Io]=this['myPW'],_0x997060[wo]=this['currentSerial'];let _0x2fd7f9=this['urlFn'](_0x997060),_0x20cbe6='',_0x5d67fe=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x20cbe6['length']<=Co;){const _0x388e67=this['pendingSegs']['shift']();_0x20cbe6=_0x20cbe6+'&'+lh+_0x5d67fe+'='+_0x388e67['seg']+'&'+hh+_0x5d67fe+'='+_0x388e67['ts']+'&'+uh+_0x5d67fe+'='+_0x388e67['d'],_0x5d67fe++;}return _0x2fd7f9=_0x2fd7f9+_0x20cbe6,this['addLongPollTag_'](_0x2fd7f9,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x1434a1,_0x11cf99,_0x243e29){this['pendingSegs']['push']({'seg':_0x1434a1,'ts':_0x11cf99,'d':_0x243e29}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x2dec16,_0x321d6f){this['outstandingRequests']['add'](_0x321d6f);const _0x2aaa3d=()=>{this['outstandingRequests']['delete'](_0x321d6f),this['newRequest_']();},_0x3a5f4c=setTimeout(_0x2aaa3d,Math['floor'](ph)),_0x19b77f=()=>{clearTimeout(_0x3a5f4c),_0x2aaa3d();};this['addTag'](_0x2dec16,_0x19b77f);}['addTag'](_0x246a5a,_0x5361c5){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x2ad9a8=this['myIFrame']['doc']['createElement']('script');_0x2ad9a8['type']='text/javascript',_0x2ad9a8['async']=!0x0,_0x2ad9a8['src']=_0x246a5a,_0x2ad9a8['onload']=_0x2ad9a8['onreadystatechange']=function(){const _0x16a80c=_0x2ad9a8['readyState'];(!_0x16a80c||_0x16a80c==='loaded'||_0x16a80c==='complete')&&(_0x2ad9a8['onload']=_0x2ad9a8['onreadystatechange']=null,_0x2ad9a8['parentNode']&&_0x2ad9a8['parentNode']['removeChild'](_0x2ad9a8),_0x5361c5());},_0x2ad9a8['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x246a5a),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x2ad9a8);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x54fb91,_0x2d7cb7,_0x4b895d,_0x1e4d42,_0x2c3e54,_0x885b6e,_0x112a66){this['connId']=_0x54fb91,this['applicationId']=_0x4b895d,this['appCheckToken']=_0x1e4d42,this['authToken']=_0x2c3e54,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x2d7cb7),this['connURL']=q['connectionURL_'](_0x2d7cb7,_0x885b6e,_0x112a66,_0x1e4d42,_0x4b895d),this['nodeAdmin']=_0x2d7cb7['nodeAdmin'];}static['connectionURL_'](_0xc7e082,_0x3d40f9,_0x44d88d,_0x17d7ab,_0x54a527){const _0x38e2e7={};return _0x38e2e7[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x38e2e7[ho]=uo),_0x3d40f9&&(_0x38e2e7[lo]=_0x3d40f9),_0x44d88d&&(_0x38e2e7[po]=_0x44d88d),_0x17d7ab&&(_0x38e2e7[wi]=_0x17d7ab),_0x54a527&&(_0x38e2e7[_o]=_0x54a527),vo(_0xc7e082,go,_0x38e2e7);}['open'](_0x1863f6,_0x4cc959){this['onDisconnect']=_0x4cc959,this['onMessage']=_0x1863f6,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x531cc1;_c(),this['mySock']=new gn(this['connURL'],[],_0x531cc1);}catch(_0x49a2cf){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x120aea=_0x49a2cf['message']||_0x49a2cf['data'];_0x120aea&&this['log_'](_0x120aea),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x349dd9=>{this['handleIncomingFrame'](_0x349dd9);},this['mySock']['onerror']=_0x47c42a=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x35f6d5=_0x47c42a['message']||_0x47c42a['data'];_0x35f6d5&&this['log_'](_0x35f6d5),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x4cbb0e=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0xad010e=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x449504=navigator['userAgent']['match'](_0xad010e);_0x449504&&_0x449504['length']>0x1&&parseFloat(_0x449504[0x1])<4.4&&(_0x4cbb0e=!0x0);}return!_0x4cbb0e&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x4bc207){if(this['frames']['push'](_0x4bc207),this['frames']['length']===this['totalFrames']){const _0xe7474f=this['frames']['join']('');this['frames']=null;const _0x5cd9d2=Nt(_0xe7474f);this['onMessage'](_0x5cd9d2);}}['handleNewFrameCount_'](_0x243aab){this['totalFrames']=_0x243aab,this['frames']=[];}['extractFrameCount_'](_0x596ab7){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x596ab7['length']<=0x6){const _0x538045=Number(_0x596ab7);if(!isNaN(_0x538045))return this['handleNewFrameCount_'](_0x538045),null;}return this['handleNewFrameCount_'](0x1),_0x596ab7;}['handleIncomingFrame'](_0x5f1a3f){if(this['mySock']===null)return;const _0x260eaa=_0x5f1a3f['data'];if(this['bytesReceived']+=_0x260eaa['length'],this['stats_']['incrementCounter']('bytes_received',_0x260eaa['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x260eaa);else{const _0x2b21ea=this['extractFrameCount_'](_0x260eaa);_0x2b21ea!==null&&this['appendFrame_'](_0x2b21ea);}}['send'](_0x2d0009){this['resetKeepAlive']();const _0x267a27=O(_0x2d0009);this['bytesSent']+=_0x267a27['length'],this['stats_']['incrementCounter']('bytes_sent',_0x267a27['length']);const _0x33c48a=oo(_0x267a27,gh);_0x33c48a['length']>0x1&&this['sendString_'](String(_0x33c48a['length']));for(let _0x1da2ef=0x0;_0x1da2ef<_0x33c48a['length'];_0x1da2ef++)this['sendString_'](_0x33c48a[_0x1da2ef]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x4beb39){try{this['mySock']['send'](_0x4beb39);}catch(_0x524165){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x524165['message']||_0x524165['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x4f8093){this['initTransports_'](_0x4f8093);}['initTransports_'](_0xc55273){const _0x5cca47=q&&q['isAvailable']();let _0x41a0ca=_0x5cca47&&!q['previouslyFailed']();if(_0xc55273['webSocketOnly']&&(_0x5cca47||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x41a0ca=!0x0),_0x41a0ca)this['transports_']=[q];else{const _0x39fd13=this['transports_']=[];for(const _0x11d833 of Dt['ALL_TRANSPORTS'])_0x11d833&&_0x11d833['isAvailable']()&&_0x39fd13['push'](_0x11d833);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x2dfb93,_0x2ca78c,_0x5a58c4,_0x40faac,_0x42751f,_0xdc0dd7,_0x2a992a,_0x4be5ee,_0xef87d5,_0x5decb3){this['id']=_0x2dfb93,this['repoInfo_']=_0x2ca78c,this['applicationId_']=_0x5a58c4,this['appCheckToken_']=_0x40faac,this['authToken_']=_0x42751f,this['onMessage_']=_0xdc0dd7,this['onReady_']=_0x2a992a,this['onDisconnect_']=_0x4be5ee,this['onKill_']=_0xef87d5,this['lastSessionId']=_0x5decb3,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x2ca78c),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x2017eb=this['transportManager_']['initialTransport']();this['conn_']=new _0x2017eb(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x2017eb['responsesRequiredToBeHealthy']||0x0;const _0x4787be=this['connReceiver_'](this['conn_']),_0x53836a=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x4787be,_0x53836a);},Math['floor'](0x0));const _0x4a69f3=_0x2017eb['healthyTimeout']||0x0;_0x4a69f3>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x4a69f3)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x40cb6b){return _0x430bcd=>{_0x40cb6b===this['conn_']?this['onConnectionLost_'](_0x430bcd):_0x40cb6b===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x54638d){return _0xfab43e=>{this['state_']!==0x2&&(_0x54638d===this['rx_']?this['onPrimaryMessageReceived_'](_0xfab43e):_0x54638d===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0xfab43e):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x21b016){const _0x16ede4={'t':'d','d':_0x21b016};this['sendData_'](_0x16ede4);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x5b5a84){if(ci in _0x5b5a84){const _0x2673d9=_0x5b5a84[ci];_0x2673d9===Ys?this['upgradeIfSecondaryHealthy_']():_0x2673d9===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x2673d9===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x24d219){const _0x4518aa=vt('t',_0x24d219),_0x109adc=vt('d',_0x24d219);if(_0x4518aa==='c')this['onSecondaryControl_'](_0x109adc);else{if(_0x4518aa==='d')this['pendingDataMessages']['push'](_0x109adc);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x4518aa);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0xa013f1){const _0x450a9a=vt('t',_0xa013f1),_0x217742=vt('d',_0xa013f1);_0x450a9a==='c'?this['onControl_'](_0x217742):_0x450a9a==='d'&&this['onDataMessage_'](_0x217742);}['onDataMessage_'](_0x50c815){this['onPrimaryResponse_'](),this['onMessage_'](_0x50c815);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x3646ca){const _0x1a33ac=vt(ci,_0x3646ca);if(zs in _0x3646ca){const _0x4a74fe=_0x3646ca[zs];if(_0x1a33ac===Th){const _0xa1e438={..._0x4a74fe};this['repoInfo_']['isUsingEmulator']&&(_0xa1e438['h']=this['repoInfo_']['host']),this['onHandshake_'](_0xa1e438);}else{if(_0x1a33ac===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x10e422=0x0;_0x10e422<this['pendingDataMessages']['length'];++_0x10e422)this['onDataMessage_'](this['pendingDataMessages'][_0x10e422]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x1a33ac===wh?this['onConnectionShutdown_'](_0x4a74fe):_0x1a33ac===js?this['onReset_'](_0x4a74fe):_0x1a33ac===Ch?Ii('Server\x20Error:\x20'+_0x4a74fe):_0x1a33ac===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x1a33ac);}}}['onHandshake_'](_0x36d1a4){const _0x38ef41=_0x36d1a4['ts'],_0x3caced=_0x36d1a4['v'],_0xcbd994=_0x36d1a4['h'];this['sessionId']=_0x36d1a4['s'],this['repoInfo_']['host']=_0xcbd994,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x38ef41),Gi!==_0x3caced&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x5c5191=this['transportManager_']['upgradeTransport']();_0x5c5191&&this['startUpgrade_'](_0x5c5191);}['startUpgrade_'](_0x47fd96){this['secondaryConn_']=new _0x47fd96(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x47fd96['responsesRequiredToBeHealthy']||0x0;const _0x1da7cd=this['connReceiver_'](this['secondaryConn_']),_0x58ccff=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x1da7cd,_0x58ccff),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x38cb85){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x38cb85),this['repoInfo_']['host']=_0x38cb85,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x3b1eb1,_0x5e2f4a){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x3b1eb1,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x5e2f4a,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x57d5c5=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x57d5c5||this['rx_']===_0x57d5c5)&&this['close']();}['onConnectionLost_'](_0x8c3c6b){this['conn_']=null,!_0x8c3c6b&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x2f5b6d){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x2f5b6d),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x2cfd60){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x2cfd60);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x54caaa,_0xfea8a1,_0x4015d5,_0x53e253){}['merge'](_0x42c670,_0xf6f2f5,_0x2b946a,_0x5db081){}['refreshAuthToken'](_0x2adc98){}['refreshAppCheckToken'](_0x7222ab){}['onDisconnectPut'](_0x3f9b0f,_0x10f376,_0x2ea83c){}['onDisconnectMerge'](_0x51aa2e,_0x28aef3,_0x4e9bea){}['onDisconnectCancel'](_0x1e6703,_0x1de5b6){}['reportStats'](_0x4f2fdf){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x5851b6){this['allowedEvents_']=_0x5851b6,this['listeners_']={},f(Array['isArray'](_0x5851b6)&&_0x5851b6['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x1ca78e,..._0x539c73){if(Array['isArray'](this['listeners_'][_0x1ca78e])){const _0xb5a74f=[...this['listeners_'][_0x1ca78e]];for(let _0x37bbe3=0x0;_0x37bbe3<_0xb5a74f['length'];_0x37bbe3++)_0xb5a74f[_0x37bbe3]['callback']['apply'](_0xb5a74f[_0x37bbe3]['context'],_0x539c73);}}['on'](_0x3b4bae,_0x21d86f,_0x2456e1){this['validateEventType_'](_0x3b4bae),this['listeners_'][_0x3b4bae]=this['listeners_'][_0x3b4bae]||[],this['listeners_'][_0x3b4bae]['push']({'callback':_0x21d86f,'context':_0x2456e1});const _0xc66bf=this['getInitialEvent'](_0x3b4bae);_0xc66bf&&_0x21d86f['apply'](_0x2456e1,_0xc66bf);}['off'](_0x21cdb9,_0x3443c8,_0xced19b){this['validateEventType_'](_0x21cdb9);const _0xbb8d44=this['listeners_'][_0x21cdb9]||[];for(let _0x1a78d4=0x0;_0x1a78d4<_0xbb8d44['length'];_0x1a78d4++)if(_0xbb8d44[_0x1a78d4]['callback']===_0x3443c8&&(!_0xced19b||_0xced19b===_0xbb8d44[_0x1a78d4]['context'])){_0xbb8d44['splice'](_0x1a78d4,0x1);return;}}['validateEventType_'](_0x284a40){f(this['allowedEvents_']['find'](_0x287e17=>_0x287e17===_0x284a40),'Unknown\x20event:\x20'+_0x284a40);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x22760d){return f(_0x22760d==='online','Unknown\x20event\x20type:\x20'+_0x22760d),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x16dc8e,_0xe54d07){if(_0xe54d07===void 0x0){this['pieces_']=_0x16dc8e['split']('/');let _0x26c5dd=0x0;for(let _0x385da6=0x0;_0x385da6<this['pieces_']['length'];_0x385da6++)this['pieces_'][_0x385da6]['length']>0x0&&(this['pieces_'][_0x26c5dd]=this['pieces_'][_0x385da6],_0x26c5dd++);this['pieces_']['length']=_0x26c5dd,this['pieceNum_']=0x0;}else this['pieces_']=_0x16dc8e,this['pieceNum_']=_0xe54d07;}['toString'](){let _0x1e2536='';for(let _0x5d707c=this['pieceNum_'];_0x5d707c<this['pieces_']['length'];_0x5d707c++)this['pieces_'][_0x5d707c]!==''&&(_0x1e2536+='/'+this['pieces_'][_0x5d707c]);return _0x1e2536||'/';}}function w(){return new C('');}function y(_0x67bb67){return _0x67bb67['pieceNum_']>=_0x67bb67['pieces_']['length']?null:_0x67bb67['pieces_'][_0x67bb67['pieceNum_']];}function Ce(_0x766a93){return _0x766a93['pieces_']['length']-_0x766a93['pieceNum_'];}function S(_0x486270){let _0x309187=_0x486270['pieceNum_'];return _0x309187<_0x486270['pieces_']['length']&&_0x309187++,new C(_0x486270['pieces_'],_0x309187);}function ji(_0x264c4c){return _0x264c4c['pieceNum_']<_0x264c4c['pieces_']['length']?_0x264c4c['pieces_'][_0x264c4c['pieces_']['length']-0x1]:null;}function bh(_0x160cde){let _0x5d9d2a='';for(let _0x1ee0ca=_0x160cde['pieceNum_'];_0x1ee0ca<_0x160cde['pieces_']['length'];_0x1ee0ca++)_0x160cde['pieces_'][_0x1ee0ca]!==''&&(_0x5d9d2a+='/'+encodeURIComponent(String(_0x160cde['pieces_'][_0x1ee0ca])));return _0x5d9d2a||'/';}function Mt(_0x92e39d,_0x576b92=0x0){return _0x92e39d['pieces_']['slice'](_0x92e39d['pieceNum_']+_0x576b92);}function Ro(_0x34562d){if(_0x34562d['pieceNum_']>=_0x34562d['pieces_']['length'])return null;const _0x2a76c1=[];for(let _0x41a39b=_0x34562d['pieceNum_'];_0x41a39b<_0x34562d['pieces_']['length']-0x1;_0x41a39b++)_0x2a76c1['push'](_0x34562d['pieces_'][_0x41a39b]);return new C(_0x2a76c1,0x0);}function k(_0x34e076,_0x33184c){const _0x191f00=[];for(let _0x501946=_0x34e076['pieceNum_'];_0x501946<_0x34e076['pieces_']['length'];_0x501946++)_0x191f00['push'](_0x34e076['pieces_'][_0x501946]);if(_0x33184c instanceof C){for(let _0x5ab267=_0x33184c['pieceNum_'];_0x5ab267<_0x33184c['pieces_']['length'];_0x5ab267++)_0x191f00['push'](_0x33184c['pieces_'][_0x5ab267]);}else{const _0x1e3445=_0x33184c['split']('/');for(let _0x118606=0x0;_0x118606<_0x1e3445['length'];_0x118606++)_0x1e3445[_0x118606]['length']>0x0&&_0x191f00['push'](_0x1e3445[_0x118606]);}return new C(_0x191f00,0x0);}function v(_0x4830a5){return _0x4830a5['pieceNum_']>=_0x4830a5['pieces_']['length'];}function F(_0x19591f,_0x154c2f){const _0x4e066b=y(_0x19591f),_0x5ed850=y(_0x154c2f);if(_0x4e066b===null)return _0x154c2f;if(_0x4e066b===_0x5ed850)return F(S(_0x19591f),S(_0x154c2f));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x154c2f+')\x20is\x20not\x20within\x20outerPath\x20('+_0x19591f+')');}function Rh(_0x39294d,_0x58a5cb){const _0x55c451=Mt(_0x39294d,0x0),_0x3c6968=Mt(_0x58a5cb,0x0);for(let _0x27d13d=0x0;_0x27d13d<_0x55c451['length']&&_0x27d13d<_0x3c6968['length'];_0x27d13d++){const _0x13713a=qe(_0x55c451[_0x27d13d],_0x3c6968[_0x27d13d]);if(_0x13713a!==0x0)return _0x13713a;}return _0x55c451['length']===_0x3c6968['length']?0x0:_0x55c451['length']<_0x3c6968['length']?-0x1:0x1;}function Ki(_0x5f0e91,_0x3c1dd9){if(Ce(_0x5f0e91)!==Ce(_0x3c1dd9))return!0x1;for(let _0x3dd8c5=_0x5f0e91['pieceNum_'],_0x151013=_0x3c1dd9['pieceNum_'];_0x3dd8c5<=_0x5f0e91['pieces_']['length'];_0x3dd8c5++,_0x151013++)if(_0x5f0e91['pieces_'][_0x3dd8c5]!==_0x3c1dd9['pieces_'][_0x151013])return!0x1;return!0x0;}function G(_0x180243,_0x4f64c8){let _0x5c999d=_0x180243['pieceNum_'],_0x43a958=_0x4f64c8['pieceNum_'];if(Ce(_0x180243)>Ce(_0x4f64c8))return!0x1;for(;_0x5c999d<_0x180243['pieces_']['length'];){if(_0x180243['pieces_'][_0x5c999d]!==_0x4f64c8['pieces_'][_0x43a958])return!0x1;++_0x5c999d,++_0x43a958;}return!0x0;}class Ah{constructor(_0x80ed10,_0x4d7c46){this['errorPrefix_']=_0x4d7c46,this['parts_']=Mt(_0x80ed10,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x1ca43e=0x0;_0x1ca43e<this['parts_']['length'];_0x1ca43e++)this['byteLength_']+=Ln(this['parts_'][_0x1ca43e]);Ao(this);}}function kh(_0x4e1077,_0x339d41){_0x4e1077['parts_']['length']>0x0&&(_0x4e1077['byteLength_']+=0x1),_0x4e1077['parts_']['push'](_0x339d41),_0x4e1077['byteLength_']+=Ln(_0x339d41),Ao(_0x4e1077);}function Ph(_0x67b6c6){const _0x590ead=_0x67b6c6['parts_']['pop']();_0x67b6c6['byteLength_']-=Ln(_0x590ead),_0x67b6c6['parts_']['length']>0x0&&(_0x67b6c6['byteLength_']-=0x1);}function Ao(_0x4ea79d){if(_0x4ea79d['byteLength_']>Zs)throw new Error(_0x4ea79d['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x4ea79d['byteLength_']+').');if(_0x4ea79d['parts_']['length']>Xs)throw new Error(_0x4ea79d['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x4ea79d));}function Oe(_0x169aae){return _0x169aae['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x169aae['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x5a374e,_0x5705eb;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x5705eb='visibilitychange',_0x5a374e='hidden'):typeof document['mozHidden']<'u'?(_0x5705eb='mozvisibilitychange',_0x5a374e='mozHidden'):typeof document['msHidden']<'u'?(_0x5705eb='msvisibilitychange',_0x5a374e='msHidden'):typeof document['webkitHidden']<'u'&&(_0x5705eb='webkitvisibilitychange',_0x5a374e='webkitHidden')),this['visible_']=!0x0,_0x5705eb&&document['addEventListener'](_0x5705eb,()=>{const _0x452b45=!document[_0x5a374e];_0x452b45!==this['visible_']&&(this['visible_']=_0x452b45,this['trigger']('visible',_0x452b45));},!0x1);}['getInitialEvent'](_0x16f677){return f(_0x16f677==='visible','Unknown\x20event\x20type:\x20'+_0x16f677),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x3a3d2b,_0x54955c,_0x45defe,_0x37d838,_0xe57935,_0x4e9584,_0x3b3b8e,_0x21693b){if(super(),this['repoInfo_']=_0x3a3d2b,this['applicationId_']=_0x54955c,this['onDataUpdate_']=_0x45defe,this['onConnectStatus_']=_0x37d838,this['onServerInfoUpdate_']=_0xe57935,this['authTokenProvider_']=_0x4e9584,this['appCheckTokenProvider_']=_0x3b3b8e,this['authOverride_']=_0x21693b,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x21693b)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x3a3d2b['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x44b8d6,_0x2e1c4f,_0x13947a){const _0x1fa64b=++this['requestNumber_'],_0x4c264c={'r':_0x1fa64b,'a':_0x44b8d6,'b':_0x2e1c4f};this['log_'](O(_0x4c264c)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x4c264c),_0x13947a&&(this['requestCBHash_'][_0x1fa64b]=_0x13947a);}['get'](_0x44ab7a){this['initConnection_']();const _0x47305f=new H(),_0x3bdca1={'action':'g','request':{'p':_0x44ab7a['_path']['toString'](),'q':_0x44ab7a['_queryObject']},'onComplete':_0x183027=>{const _0x10640e=_0x183027['d'];_0x183027['s']==='ok'?_0x47305f['resolve'](_0x10640e):_0x47305f['reject'](_0x10640e);}};this['outstandingGets_']['push'](_0x3bdca1),this['outstandingGetCount_']++;const _0x2eb212=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x2eb212),_0x47305f['promise'];}['listen'](_0xf87c27,_0x2daea1,_0x1f33f5,_0x256c7c){this['initConnection_']();const _0x1c781b=_0xf87c27['_queryIdentifier'],_0x3cb15b=_0xf87c27['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x3cb15b+'\x20'+_0x1c781b),this['listens']['has'](_0x3cb15b)||this['listens']['set'](_0x3cb15b,new Map()),f(_0xf87c27['_queryParams']['isDefault']()||!_0xf87c27['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x3cb15b)['has'](_0x1c781b),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x2ee548={'onComplete':_0x256c7c,'hashFn':_0x2daea1,'query':_0xf87c27,'tag':_0x1f33f5};this['listens']['get'](_0x3cb15b)['set'](_0x1c781b,_0x2ee548),this['connected_']&&this['sendListen_'](_0x2ee548);}['sendGet_'](_0x5071a2){const _0x7166b4=this['outstandingGets_'][_0x5071a2];this['sendRequest']('g',_0x7166b4['request'],_0x5ae657=>{delete this['outstandingGets_'][_0x5071a2],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x7166b4['onComplete']&&_0x7166b4['onComplete'](_0x5ae657);});}['sendListen_'](_0x2cb1cf){const _0x535560=_0x2cb1cf['query'],_0x26d05e=_0x535560['_path']['toString'](),_0x31d66b=_0x535560['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x26d05e+'\x20for\x20'+_0x31d66b);const _0x3b48da={'p':_0x26d05e},_0x45edb4='q';_0x2cb1cf['tag']&&(_0x3b48da['q']=_0x535560['_queryObject'],_0x3b48da['t']=_0x2cb1cf['tag']),_0x3b48da['h']=_0x2cb1cf['hashFn'](),this['sendRequest'](_0x45edb4,_0x3b48da,_0x36d248=>{const _0x3aa9a2=_0x36d248['d'],_0x4acd56=_0x36d248['s'];se['warnOnListenWarnings_'](_0x3aa9a2,_0x535560),(this['listens']['get'](_0x26d05e)&&this['listens']['get'](_0x26d05e)['get'](_0x31d66b))===_0x2cb1cf&&(this['log_']('listen\x20response',_0x36d248),_0x4acd56!=='ok'&&this['removeListen_'](_0x26d05e,_0x31d66b),_0x2cb1cf['onComplete']&&_0x2cb1cf['onComplete'](_0x4acd56,_0x3aa9a2));});}static['warnOnListenWarnings_'](_0x14923b,_0x275ec1){if(_0x14923b&&typeof _0x14923b=='object'&&Q(_0x14923b,'w')){const _0x13075a=Le(_0x14923b,'w');if(Array['isArray'](_0x13075a)&&~_0x13075a['indexOf']('no_index')){const _0x20e0a7='\x22.indexOn\x22:\x20\x22'+_0x275ec1['_queryParams']['getIndex']()['toString']()+'\x22',_0x349622=_0x275ec1['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x20e0a7+'\x20at\x20'+_0x349622+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x61704e){this['authToken_']=_0x61704e,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x61704e);}['reduceReconnectDelayIfAdminCredential_'](_0x398c6a){(_0x398c6a&&_0x398c6a['length']===0x28||wc(_0x398c6a))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x1805f8){this['appCheckToken_']=_0x1805f8,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x43a18b=this['authToken_'],_0x5edc80=Ic(_0x43a18b)?'auth':'gauth',_0x2cb2cf={'cred':_0x43a18b};this['authOverride_']===null?_0x2cb2cf['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x2cb2cf['authvar']=this['authOverride_']),this['sendRequest'](_0x5edc80,_0x2cb2cf,_0x6ae839=>{const _0x3a763d=_0x6ae839['s'],_0x5667a8=_0x6ae839['d']||'error';this['authToken_']===_0x43a18b&&(_0x3a763d==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x3a763d,_0x5667a8));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x4dda5b=>{const _0x35a58c=_0x4dda5b['s'],_0xccc94f=_0x4dda5b['d']||'error';_0x35a58c==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x35a58c,_0xccc94f);});}['unlisten'](_0x339440,_0x1db899){const _0x533af0=_0x339440['_path']['toString'](),_0x12fa66=_0x339440['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x533af0+'\x20'+_0x12fa66),f(_0x339440['_queryParams']['isDefault']()||!_0x339440['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x533af0,_0x12fa66)&&this['connected_']&&this['sendUnlisten_'](_0x533af0,_0x12fa66,_0x339440['_queryObject'],_0x1db899);}['sendUnlisten_'](_0x14320f,_0x5e199f,_0x5ed142,_0x526d83){this['log_']('Unlisten\x20on\x20'+_0x14320f+'\x20for\x20'+_0x5e199f);const _0x24060d={'p':_0x14320f},_0x12bf48='n';_0x526d83&&(_0x24060d['q']=_0x5ed142,_0x24060d['t']=_0x526d83),this['sendRequest'](_0x12bf48,_0x24060d);}['onDisconnectPut'](_0x1ac4b0,_0x50b41c,_0x80554b){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x1ac4b0,_0x50b41c,_0x80554b):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1ac4b0,'action':'o','data':_0x50b41c,'onComplete':_0x80554b});}['onDisconnectMerge'](_0x10f528,_0x1e0ee4,_0x4cefb2){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x10f528,_0x1e0ee4,_0x4cefb2):this['onDisconnectRequestQueue_']['push']({'pathString':_0x10f528,'action':'om','data':_0x1e0ee4,'onComplete':_0x4cefb2});}['onDisconnectCancel'](_0x33cc26,_0x515ce8){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x33cc26,null,_0x515ce8):this['onDisconnectRequestQueue_']['push']({'pathString':_0x33cc26,'action':'oc','data':null,'onComplete':_0x515ce8});}['sendOnDisconnect_'](_0x533d27,_0x44b723,_0x446bac,_0x1ca670){const _0x33adbd={'p':_0x44b723,'d':_0x446bac};this['log_']('onDisconnect\x20'+_0x533d27,_0x33adbd),this['sendRequest'](_0x533d27,_0x33adbd,_0x2c3421=>{_0x1ca670&&setTimeout(()=>{_0x1ca670(_0x2c3421['s'],_0x2c3421['d']);},Math['floor'](0x0));});}['put'](_0x5be9f7,_0x49cc27,_0x26ae9c,_0x295e3c){this['putInternal']('p',_0x5be9f7,_0x49cc27,_0x26ae9c,_0x295e3c);}['merge'](_0x151e1a,_0x57de7e,_0x42644c,_0x11f576){this['putInternal']('m',_0x151e1a,_0x57de7e,_0x42644c,_0x11f576);}['putInternal'](_0x53c89d,_0x1d0244,_0x32c1ad,_0x2e8b4a,_0x144646){this['initConnection_']();const _0x109bab={'p':_0x1d0244,'d':_0x32c1ad};_0x144646!==void 0x0&&(_0x109bab['h']=_0x144646),this['outstandingPuts_']['push']({'action':_0x53c89d,'request':_0x109bab,'onComplete':_0x2e8b4a}),this['outstandingPutCount_']++;const _0x49cd5b=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x49cd5b):this['log_']('Buffering\x20put:\x20'+_0x1d0244);}['sendPut_'](_0x55febb){const _0x1eb8c3=this['outstandingPuts_'][_0x55febb]['action'],_0x1c4822=this['outstandingPuts_'][_0x55febb]['request'],_0xd4432a=this['outstandingPuts_'][_0x55febb]['onComplete'];this['outstandingPuts_'][_0x55febb]['queued']=this['connected_'],this['sendRequest'](_0x1eb8c3,_0x1c4822,_0x452209=>{this['log_'](_0x1eb8c3+'\x20response',_0x452209),delete this['outstandingPuts_'][_0x55febb],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0xd4432a&&_0xd4432a(_0x452209['s'],_0x452209['d']);});}['reportStats'](_0x5364ff){if(this['connected_']){const _0x3c5fb0={'c':_0x5364ff};this['log_']('reportStats',_0x3c5fb0),this['sendRequest']('s',_0x3c5fb0,_0x4f5ae5=>{if(_0x4f5ae5['s']!=='ok'){const _0x569ee1=_0x4f5ae5['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x569ee1);}});}}['onDataMessage_'](_0x599774){if('r'in _0x599774){this['log_']('from\x20server:\x20'+O(_0x599774));const _0x420e1e=_0x599774['r'],_0x154963=this['requestCBHash_'][_0x420e1e];_0x154963&&(delete this['requestCBHash_'][_0x420e1e],_0x154963(_0x599774['b']));}else{if('error'in _0x599774)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x599774['error'];'a'in _0x599774&&this['onDataPush_'](_0x599774['a'],_0x599774['b']);}}['onDataPush_'](_0x409f83,_0x33b1b0){this['log_']('handleServerMessage',_0x409f83,_0x33b1b0),_0x409f83==='d'?this['onDataUpdate_'](_0x33b1b0['p'],_0x33b1b0['d'],!0x1,_0x33b1b0['t']):_0x409f83==='m'?this['onDataUpdate_'](_0x33b1b0['p'],_0x33b1b0['d'],!0x0,_0x33b1b0['t']):_0x409f83==='c'?this['onListenRevoked_'](_0x33b1b0['p'],_0x33b1b0['q']):_0x409f83==='ac'?this['onAuthRevoked_'](_0x33b1b0['s'],_0x33b1b0['d']):_0x409f83==='apc'?this['onAppCheckRevoked_'](_0x33b1b0['s'],_0x33b1b0['d']):_0x409f83==='sd'?this['onSecurityDebugPacket_'](_0x33b1b0):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x409f83)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x23d6b6,_0xeec57d){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x23d6b6),this['lastSessionId']=_0xeec57d,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x4f9a60){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x4f9a60));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x193b70){_0x193b70&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x193b70;}['onOnline_'](_0x158462){_0x158462?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x125915=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x55cdf0=Math['max'](0x0,this['reconnectDelay_']-_0x125915);_0x55cdf0=Math['random']()*_0x55cdf0,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x55cdf0+'ms'),this['scheduleConnect_'](_0x55cdf0),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x4c771f=this['onDataMessage_']['bind'](this),_0x5aceed=this['onReady_']['bind'](this),_0x140d38=this['onRealtimeDisconnect_']['bind'](this),_0x3528f0=this['id']+':'+se['nextConnectionId_']++,_0x2766bc=this['lastSessionId'];let _0x157cdf=!0x1,_0x2c68e5=null;const _0x56154a=function(){_0x2c68e5?_0x2c68e5['close']():(_0x157cdf=!0x0,_0x140d38());},_0x49820c=function(_0x5ba36c){f(_0x2c68e5,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x2c68e5['sendRequest'](_0x5ba36c);};this['realtime_']={'close':_0x56154a,'sendRequest':_0x49820c};const _0x33d1f7=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x2b761e,_0x103bb6]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x33d1f7),this['appCheckTokenProvider_']['getToken'](_0x33d1f7)]);_0x157cdf?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x2b761e&&_0x2b761e['accessToken'],this['appCheckToken_']=_0x103bb6&&_0x103bb6['token'],_0x2c68e5=new Sh(_0x3528f0,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x4c771f,_0x5aceed,_0x140d38,_0x343078=>{U(_0x343078+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x2766bc));}catch(_0x1d26f8){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x1d26f8),_0x157cdf||(this['repoInfo_']['nodeAdmin']&&U(_0x1d26f8),_0x56154a());}}}['interrupt'](_0x2651b4){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x2651b4),this['interruptReasons_'][_0x2651b4]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x12f391){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x12f391),delete this['interruptReasons_'][_0x12f391],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x1dddc5){const _0x2267a7=_0x1dddc5-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x2267a7});}['cancelSentTransactions_'](){for(let _0x48f19c=0x0;_0x48f19c<this['outstandingPuts_']['length'];_0x48f19c++){const _0x498aef=this['outstandingPuts_'][_0x48f19c];_0x498aef&&'h'in _0x498aef['request']&&_0x498aef['queued']&&(_0x498aef['onComplete']&&_0x498aef['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x48f19c],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x3d166b,_0x24ca0c){let _0x475375;_0x24ca0c?_0x475375=_0x24ca0c['map'](_0x1a8198=>$i(_0x1a8198))['join']('$'):_0x475375='default';const _0x34506c=this['removeListen_'](_0x3d166b,_0x475375);_0x34506c&&_0x34506c['onComplete']&&_0x34506c['onComplete']('permission_denied');}['removeListen_'](_0xc9a10,_0x1f74a1){const _0x477d9e=new C(_0xc9a10)['toString']();let _0x4a2e3d;if(this['listens']['has'](_0x477d9e)){const _0x560bee=this['listens']['get'](_0x477d9e);_0x4a2e3d=_0x560bee['get'](_0x1f74a1),_0x560bee['delete'](_0x1f74a1),_0x560bee['size']===0x0&&this['listens']['delete'](_0x477d9e);}else _0x4a2e3d=void 0x0;return _0x4a2e3d;}['onAuthRevoked_'](_0x212d60,_0x24635e){L('Auth\x20token\x20revoked:\x20'+_0x212d60+'/'+_0x24635e),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x212d60==='invalid_token'||_0x212d60==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x38f065,_0x58acff){L('App\x20check\x20token\x20revoked:\x20'+_0x38f065+'/'+_0x58acff),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x38f065==='invalid_token'||_0x38f065==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x266e9c){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x266e9c):'msg'in _0x266e9c&&console['log']('FIREBASE:\x20'+_0x266e9c['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x48625d of this['listens']['values']())for(const _0x421de2 of _0x48625d['values']())this['sendListen_'](_0x421de2);for(let _0xc9b987=0x0;_0xc9b987<this['outstandingPuts_']['length'];_0xc9b987++)this['outstandingPuts_'][_0xc9b987]&&this['sendPut_'](_0xc9b987);for(;this['onDisconnectRequestQueue_']['length'];){const _0x2eb2be=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x2eb2be['action'],_0x2eb2be['pathString'],_0x2eb2be['data'],_0x2eb2be['onComplete']);}for(let _0x52e352=0x0;_0x52e352<this['outstandingGets_']['length'];_0x52e352++)this['outstandingGets_'][_0x52e352]&&this['sendGet_'](_0x52e352);}['sendConnectStats_'](){const _0xad3c5={};let _0x43a262='js';_0xad3c5['sdk.'+_0x43a262+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0xad3c5['framework.cordova']=0x1:Kr()&&(_0xad3c5['framework.reactnative']=0x1),this['reportStats'](_0xad3c5);}['shouldReconnect_'](){const _0x3683f8=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x3683f8;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x98f2ce,_0x1c3448){this['name']=_0x98f2ce,this['node']=_0x1c3448;}static['Wrap'](_0x25612d,_0x16574b){return new E(_0x25612d,_0x16574b);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x47ae0b,_0xe6a186){const _0x351390=new E(We,_0x47ae0b),_0x324f68=new E(We,_0xe6a186);return this['compare'](_0x351390,_0x324f68)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x43b5de){sn=_0x43b5de;}['compare'](_0x2f3ff1,_0x288b2c){return qe(_0x2f3ff1['name'],_0x288b2c['name']);}['isDefinedOn'](_0x3a2987){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x3e12ae,_0x5282c9){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0xe52007,_0x214e12){return f(typeof _0xe52007=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0xe52007,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x481bb1,_0x42c54a,_0x2ecf4f,_0x289fbe,_0x12046f=null){this['isReverse_']=_0x289fbe,this['resultGenerator_']=_0x12046f,this['nodeStack_']=[];let _0x48f4b4=0x1;for(;!_0x481bb1['isEmpty']();)if(_0x481bb1=_0x481bb1,_0x48f4b4=_0x42c54a?_0x2ecf4f(_0x481bb1['key'],_0x42c54a):0x1,_0x289fbe&&(_0x48f4b4*=-0x1),_0x48f4b4<0x0)this['isReverse_']?_0x481bb1=_0x481bb1['left']:_0x481bb1=_0x481bb1['right'];else{if(_0x48f4b4===0x0){this['nodeStack_']['push'](_0x481bb1);break;}else this['nodeStack_']['push'](_0x481bb1),this['isReverse_']?_0x481bb1=_0x481bb1['right']:_0x481bb1=_0x481bb1['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x55878c=this['nodeStack_']['pop'](),_0x503e35;if(this['resultGenerator_']?_0x503e35=this['resultGenerator_'](_0x55878c['key'],_0x55878c['value']):_0x503e35={'key':_0x55878c['key'],'value':_0x55878c['value']},this['isReverse_']){for(_0x55878c=_0x55878c['left'];!_0x55878c['isEmpty']();)this['nodeStack_']['push'](_0x55878c),_0x55878c=_0x55878c['right'];}else{for(_0x55878c=_0x55878c['right'];!_0x55878c['isEmpty']();)this['nodeStack_']['push'](_0x55878c),_0x55878c=_0x55878c['left'];}return _0x503e35;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x433a87=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x433a87['key'],_0x433a87['value']):{'key':_0x433a87['key'],'value':_0x433a87['value']};}}class M{constructor(_0x28956f,_0x5741cb,_0x50b63a,_0x2dce6f,_0x1c5325){this['key']=_0x28956f,this['value']=_0x5741cb,this['color']=_0x50b63a??M['RED'],this['left']=_0x2dce6f??B['EMPTY_NODE'],this['right']=_0x1c5325??B['EMPTY_NODE'];}['copy'](_0x3ea77c,_0x17e071,_0xb0a84c,_0x4f7901,_0x3e8206){return new M(_0x3ea77c??this['key'],_0x17e071??this['value'],_0xb0a84c??this['color'],_0x4f7901??this['left'],_0x3e8206??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x341c81){return this['left']['inorderTraversal'](_0x341c81)||!!_0x341c81(this['key'],this['value'])||this['right']['inorderTraversal'](_0x341c81);}['reverseTraversal'](_0x52aa90){return this['right']['reverseTraversal'](_0x52aa90)||_0x52aa90(this['key'],this['value'])||this['left']['reverseTraversal'](_0x52aa90);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x180b9c,_0x4a046b,_0x5c3fa9){let _0x37f771=this;const _0x257416=_0x5c3fa9(_0x180b9c,_0x37f771['key']);return _0x257416<0x0?_0x37f771=_0x37f771['copy'](null,null,null,_0x37f771['left']['insert'](_0x180b9c,_0x4a046b,_0x5c3fa9),null):_0x257416===0x0?_0x37f771=_0x37f771['copy'](null,_0x4a046b,null,null,null):_0x37f771=_0x37f771['copy'](null,null,null,null,_0x37f771['right']['insert'](_0x180b9c,_0x4a046b,_0x5c3fa9)),_0x37f771['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x26b6db=this;return!_0x26b6db['left']['isRed_']()&&!_0x26b6db['left']['left']['isRed_']()&&(_0x26b6db=_0x26b6db['moveRedLeft_']()),_0x26b6db=_0x26b6db['copy'](null,null,null,_0x26b6db['left']['removeMin_'](),null),_0x26b6db['fixUp_']();}['remove'](_0x5b514d,_0x38681b){let _0xeee1a3,_0x412d4b;if(_0xeee1a3=this,_0x38681b(_0x5b514d,_0xeee1a3['key'])<0x0)!_0xeee1a3['left']['isEmpty']()&&!_0xeee1a3['left']['isRed_']()&&!_0xeee1a3['left']['left']['isRed_']()&&(_0xeee1a3=_0xeee1a3['moveRedLeft_']()),_0xeee1a3=_0xeee1a3['copy'](null,null,null,_0xeee1a3['left']['remove'](_0x5b514d,_0x38681b),null);else{if(_0xeee1a3['left']['isRed_']()&&(_0xeee1a3=_0xeee1a3['rotateRight_']()),!_0xeee1a3['right']['isEmpty']()&&!_0xeee1a3['right']['isRed_']()&&!_0xeee1a3['right']['left']['isRed_']()&&(_0xeee1a3=_0xeee1a3['moveRedRight_']()),_0x38681b(_0x5b514d,_0xeee1a3['key'])===0x0){if(_0xeee1a3['right']['isEmpty']())return B['EMPTY_NODE'];_0x412d4b=_0xeee1a3['right']['min_'](),_0xeee1a3=_0xeee1a3['copy'](_0x412d4b['key'],_0x412d4b['value'],null,null,_0xeee1a3['right']['removeMin_']());}_0xeee1a3=_0xeee1a3['copy'](null,null,null,null,_0xeee1a3['right']['remove'](_0x5b514d,_0x38681b));}return _0xeee1a3['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x51b485=this;return _0x51b485['right']['isRed_']()&&!_0x51b485['left']['isRed_']()&&(_0x51b485=_0x51b485['rotateLeft_']()),_0x51b485['left']['isRed_']()&&_0x51b485['left']['left']['isRed_']()&&(_0x51b485=_0x51b485['rotateRight_']()),_0x51b485['left']['isRed_']()&&_0x51b485['right']['isRed_']()&&(_0x51b485=_0x51b485['colorFlip_']()),_0x51b485;}['moveRedLeft_'](){let _0x2648f6=this['colorFlip_']();return _0x2648f6['right']['left']['isRed_']()&&(_0x2648f6=_0x2648f6['copy'](null,null,null,null,_0x2648f6['right']['rotateRight_']()),_0x2648f6=_0x2648f6['rotateLeft_'](),_0x2648f6=_0x2648f6['colorFlip_']()),_0x2648f6;}['moveRedRight_'](){let _0xd4bb57=this['colorFlip_']();return _0xd4bb57['left']['left']['isRed_']()&&(_0xd4bb57=_0xd4bb57['rotateRight_'](),_0xd4bb57=_0xd4bb57['colorFlip_']()),_0xd4bb57;}['rotateLeft_'](){const _0x1154f0=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x1154f0,null);}['rotateRight_'](){const _0x1dc934=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x1dc934);}['colorFlip_'](){const _0x2628d8=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x188bac=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x2628d8,_0x188bac);}['checkMaxDepth_'](){const _0x57794e=this['check_']();return Math['pow'](0x2,_0x57794e)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x8edd76=this['left']['check_']();if(_0x8edd76!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x8edd76+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x25c32e,_0x197f9b,_0x1e43ab,_0x367e89,_0x34fd30){return this;}['insert'](_0x1e781c,_0x4f4b6e,_0x43daa0){return new M(_0x1e781c,_0x4f4b6e,null);}['remove'](_0x44682a,_0x5ce11d){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x2717cf){return!0x1;}['reverseTraversal'](_0x3c62e8){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x6ead4a,_0x4bdd0e=B['EMPTY_NODE']){this['comparator_']=_0x6ead4a,this['root_']=_0x4bdd0e;}['insert'](_0x11cca1,_0x9e197c){return new B(this['comparator_'],this['root_']['insert'](_0x11cca1,_0x9e197c,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x202a9c){return new B(this['comparator_'],this['root_']['remove'](_0x202a9c,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x2f49b8){let _0x1a3e11,_0x40350d=this['root_'];for(;!_0x40350d['isEmpty']();){if(_0x1a3e11=this['comparator_'](_0x2f49b8,_0x40350d['key']),_0x1a3e11===0x0)return _0x40350d['value'];_0x1a3e11<0x0?_0x40350d=_0x40350d['left']:_0x1a3e11>0x0&&(_0x40350d=_0x40350d['right']);}return null;}['getPredecessorKey'](_0x1dbe8c){let _0x52b09d,_0x906f1a=this['root_'],_0x19ae64=null;for(;!_0x906f1a['isEmpty']();)if(_0x52b09d=this['comparator_'](_0x1dbe8c,_0x906f1a['key']),_0x52b09d===0x0){if(_0x906f1a['left']['isEmpty']())return _0x19ae64?_0x19ae64['key']:null;for(_0x906f1a=_0x906f1a['left'];!_0x906f1a['right']['isEmpty']();)_0x906f1a=_0x906f1a['right'];return _0x906f1a['key'];}else _0x52b09d<0x0?_0x906f1a=_0x906f1a['left']:_0x52b09d>0x0&&(_0x19ae64=_0x906f1a,_0x906f1a=_0x906f1a['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x343ded){return this['root_']['inorderTraversal'](_0x343ded);}['reverseTraversal'](_0xc4e112){return this['root_']['reverseTraversal'](_0xc4e112);}['getIterator'](_0x97fe47){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x97fe47);}['getIteratorFrom'](_0x6702d8,_0x3a286c){return new rn(this['root_'],_0x6702d8,this['comparator_'],!0x1,_0x3a286c);}['getReverseIteratorFrom'](_0x403765,_0xb17bd3){return new rn(this['root_'],_0x403765,this['comparator_'],!0x0,_0xb17bd3);}['getReverseIterator'](_0xf320ea){return new rn(this['root_'],null,this['comparator_'],!0x0,_0xf320ea);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x1fe5f5,_0x568863){return qe(_0x1fe5f5['name'],_0x568863['name']);}function Qi(_0x414603,_0x9d4fb8){return qe(_0x414603,_0x9d4fb8);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x1559e1){Ci=_0x1559e1;}const Po=function(_0xb626cb){return typeof _0xb626cb=='number'?'number:'+ao(_0xb626cb):'string:'+_0xb626cb;},No=function(_0xc368b7){if(_0xc368b7['isLeafNode']()){const _0xd41011=_0xc368b7['val']();f(typeof _0xd41011=='string'||typeof _0xd41011=='number'||typeof _0xd41011=='object'&&Q(_0xd41011,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0xc368b7===Ci||_0xc368b7['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0xc368b7===Ci||_0xc368b7['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x358bdb){nr=_0x358bdb;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x5d3de3,_0x461ddd=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x5d3de3,this['priorityNode_']=_0x461ddd,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x51b223){return new D(this['value_'],_0x51b223);}['getImmediateChild'](_0x3f01b8){return _0x3f01b8==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x33887d){return v(_0x33887d)?this:y(_0x33887d)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x788c95,_0x264947){return null;}['updateImmediateChild'](_0x1d9942,_0x325c4a){return _0x1d9942==='.priority'?this['updatePriority'](_0x325c4a):_0x325c4a['isEmpty']()&&_0x1d9942!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x1d9942,_0x325c4a)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x305cb8,_0x2577f5){const _0x2158cf=y(_0x305cb8);return _0x2158cf===null?_0x2577f5:_0x2577f5['isEmpty']()&&_0x2158cf!=='.priority'?this:(f(_0x2158cf!=='.priority'||Ce(_0x305cb8)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x2158cf,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x305cb8),_0x2577f5)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x5013fa,_0x5dba75){return!0x1;}['val'](_0x6f9e01){return _0x6f9e01&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x187776='';this['priorityNode_']['isEmpty']()||(_0x187776+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x54112a=typeof this['value_'];_0x187776+=_0x54112a+':',_0x54112a==='number'?_0x187776+=ao(this['value_']):_0x187776+=this['value_'],this['lazyHash_']=ro(_0x187776);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x34a0e8){return _0x34a0e8===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x34a0e8 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x34a0e8['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x34a0e8));}['compareToLeafNode_'](_0x303861){const _0x142d7d=typeof _0x303861['value_'],_0x2fe319=typeof this['value_'],_0x491f87=D['VALUE_TYPE_ORDER']['indexOf'](_0x142d7d),_0x430d07=D['VALUE_TYPE_ORDER']['indexOf'](_0x2fe319);return f(_0x491f87>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x142d7d),f(_0x430d07>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x2fe319),_0x491f87===_0x430d07?_0x2fe319==='object'?0x0:this['value_']<_0x303861['value_']?-0x1:this['value_']===_0x303861['value_']?0x0:0x1:_0x430d07-_0x491f87;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x398f8f){if(_0x398f8f===this)return!0x0;if(_0x398f8f['isLeafNode']()){const _0x4b5b2b=_0x398f8f;return this['value_']===_0x4b5b2b['value_']&&this['priorityNode_']['equals'](_0x4b5b2b['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x5c86d2){Oo=_0x5c86d2;}function Wh(_0x27bd48){Do=_0x27bd48;}class Bh extends Fn{['compare'](_0x1107b7,_0x488153){const _0x15ab95=_0x1107b7['node']['getPriority'](),_0x14c99b=_0x488153['node']['getPriority'](),_0x25c398=_0x15ab95['compareTo'](_0x14c99b);return _0x25c398===0x0?qe(_0x1107b7['name'],_0x488153['name']):_0x25c398;}['isDefinedOn'](_0xe6faf5){return!_0xe6faf5['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x72c8ec,_0x2a89e8){return!_0x72c8ec['getPriority']()['equals'](_0x2a89e8['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x403100,_0x1e063b){const _0x46a2b6=Oo(_0x403100);return new E(_0x1e063b,new D('[PRIORITY-POST]',_0x46a2b6));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x35ad9d){const _0x3a065=_0x867ae7=>parseInt(Math['log'](_0x867ae7)/Vh,0xa),_0x4abe79=_0xa2a0ea=>parseInt(Array(_0xa2a0ea+0x1)['join']('1'),0x2);this['count']=_0x3a065(_0x35ad9d+0x1),this['current_']=this['count']-0x1;const _0x3f73e5=_0x4abe79(this['count']);this['bits_']=_0x35ad9d+0x1&_0x3f73e5;}['nextBitIsOne'](){const _0x11d58b=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x11d58b;}}const yn=function(_0x29b221,_0x56e605,_0x3260ae,_0x2918fd){_0x29b221['sort'](_0x56e605);const _0x3fc569=function(_0x3c8714,_0x18b23f){const _0x26cb25=_0x18b23f-_0x3c8714;let _0x2260d1,_0x2b291e;if(_0x26cb25===0x0)return null;if(_0x26cb25===0x1)return _0x2260d1=_0x29b221[_0x3c8714],_0x2b291e=_0x3260ae?_0x3260ae(_0x2260d1):_0x2260d1,new M(_0x2b291e,_0x2260d1['node'],M['BLACK'],null,null);{const _0x3b09e8=parseInt(_0x26cb25/0x2,0xa)+_0x3c8714,_0x59c56c=_0x3fc569(_0x3c8714,_0x3b09e8),_0x122bcc=_0x3fc569(_0x3b09e8+0x1,_0x18b23f);return _0x2260d1=_0x29b221[_0x3b09e8],_0x2b291e=_0x3260ae?_0x3260ae(_0x2260d1):_0x2260d1,new M(_0x2b291e,_0x2260d1['node'],M['BLACK'],_0x59c56c,_0x122bcc);}},_0x49db33=function(_0x203869){let _0x2ea1b2=null,_0x50edf5=null,_0x5bfb3a=_0x29b221['length'];const _0x3c17c9=function(_0x4d0701,_0x29a401){const _0x3a9e74=_0x5bfb3a-_0x4d0701,_0x43d0df=_0x5bfb3a;_0x5bfb3a-=_0x4d0701;const _0x267bfa=_0x3fc569(_0x3a9e74+0x1,_0x43d0df),_0x22f6ff=_0x29b221[_0x3a9e74],_0x512da1=_0x3260ae?_0x3260ae(_0x22f6ff):_0x22f6ff;_0x919884(new M(_0x512da1,_0x22f6ff['node'],_0x29a401,null,_0x267bfa));},_0x919884=function(_0x288b33){_0x2ea1b2?(_0x2ea1b2['left']=_0x288b33,_0x2ea1b2=_0x288b33):(_0x50edf5=_0x288b33,_0x2ea1b2=_0x288b33);};for(let _0x512f93=0x0;_0x512f93<_0x203869['count'];++_0x512f93){const _0x31f11d=_0x203869['nextBitIsOne'](),_0x2c2290=Math['pow'](0x2,_0x203869['count']-(_0x512f93+0x1));_0x31f11d?_0x3c17c9(_0x2c2290,M['BLACK']):(_0x3c17c9(_0x2c2290,M['BLACK']),_0x3c17c9(_0x2c2290,M['RED']));}return _0x50edf5;},_0x45f52a=new Hh(_0x29b221['length']),_0x4e9460=_0x49db33(_0x45f52a);return new B(_0x2918fd||_0x56e605,_0x4e9460);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x456eef,_0x17d1dc){this['indexes_']=_0x456eef,this['indexSet_']=_0x17d1dc;}['get'](_0x28f171){const _0x46b161=Le(this['indexes_'],_0x28f171);if(!_0x46b161)throw new Error('No\x20index\x20defined\x20for\x20'+_0x28f171);return _0x46b161 instanceof B?_0x46b161:null;}['hasIndex'](_0x4a217a){return Q(this['indexSet_'],_0x4a217a['toString']());}['addIndex'](_0x28821d,_0x3b7fa8){f(_0x28821d!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x23c0c7=[];let _0xcc0404=!0x1;const _0x2006ed=_0x3b7fa8['getIterator'](E['Wrap']);let _0x576911=_0x2006ed['getNext']();for(;_0x576911;)_0xcc0404=_0xcc0404||_0x28821d['isDefinedOn'](_0x576911['node']),_0x23c0c7['push'](_0x576911),_0x576911=_0x2006ed['getNext']();let _0x15c4a2;_0xcc0404?_0x15c4a2=yn(_0x23c0c7,_0x28821d['getCompare']()):_0x15c4a2=Qe;const _0x56b377=_0x28821d['toString'](),_0x186d06={...this['indexSet_']};_0x186d06[_0x56b377]=_0x28821d;const _0x153ace={...this['indexes_']};return _0x153ace[_0x56b377]=_0x15c4a2,new te(_0x153ace,_0x186d06);}['addToIndexes'](_0x97e715,_0x3ba3e3){const _0x2c277b=_n(this['indexes_'],(_0x3d05b9,_0x176d46)=>{const _0x39ccee=Le(this['indexSet_'],_0x176d46);if(f(_0x39ccee,'Missing\x20index\x20implementation\x20for\x20'+_0x176d46),_0x3d05b9===Qe){if(_0x39ccee['isDefinedOn'](_0x97e715['node'])){const _0x2a496d=[],_0x363ddc=_0x3ba3e3['getIterator'](E['Wrap']);let _0x17f56a=_0x363ddc['getNext']();for(;_0x17f56a;)_0x17f56a['name']!==_0x97e715['name']&&_0x2a496d['push'](_0x17f56a),_0x17f56a=_0x363ddc['getNext']();return _0x2a496d['push'](_0x97e715),yn(_0x2a496d,_0x39ccee['getCompare']());}else return Qe;}else{const _0x333916=_0x3ba3e3['get'](_0x97e715['name']);let _0x2121fa=_0x3d05b9;return _0x333916&&(_0x2121fa=_0x2121fa['remove'](new E(_0x97e715['name'],_0x333916))),_0x2121fa['insert'](_0x97e715,_0x97e715['node']);}});return new te(_0x2c277b,this['indexSet_']);}['removeFromIndexes'](_0x2e153b,_0x9a7a1d){const _0x52868c=_n(this['indexes_'],_0x21de12=>{if(_0x21de12===Qe)return _0x21de12;{const _0x54865e=_0x9a7a1d['get'](_0x2e153b['name']);return _0x54865e?_0x21de12['remove'](new E(_0x2e153b['name'],_0x54865e)):_0x21de12;}});return new te(_0x52868c,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x1e0d54,_0x200255,_0x445124){this['children_']=_0x1e0d54,this['priorityNode_']=_0x200255,this['indexMap_']=_0x445124,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x51cca7){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x51cca7,this['indexMap_']);}['getImmediateChild'](_0x3386bd){if(_0x3386bd==='.priority')return this['getPriority']();{const _0x221380=this['children_']['get'](_0x3386bd);return _0x221380===null?It:_0x221380;}}['getChild'](_0x15d4c3){const _0x20928b=y(_0x15d4c3);return _0x20928b===null?this:this['getImmediateChild'](_0x20928b)['getChild'](S(_0x15d4c3));}['hasChild'](_0x1911c0){return this['children_']['get'](_0x1911c0)!==null;}['updateImmediateChild'](_0x179fdf,_0x568ba9){if(f(_0x568ba9,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x179fdf==='.priority')return this['updatePriority'](_0x568ba9);{const _0x2f93e3=new E(_0x179fdf,_0x568ba9);let _0xe394e4,_0x48e8a0;_0x568ba9['isEmpty']()?(_0xe394e4=this['children_']['remove'](_0x179fdf),_0x48e8a0=this['indexMap_']['removeFromIndexes'](_0x2f93e3,this['children_'])):(_0xe394e4=this['children_']['insert'](_0x179fdf,_0x568ba9),_0x48e8a0=this['indexMap_']['addToIndexes'](_0x2f93e3,this['children_']));const _0x3b1524=_0xe394e4['isEmpty']()?It:this['priorityNode_'];return new g(_0xe394e4,_0x3b1524,_0x48e8a0);}}['updateChild'](_0x488458,_0x5ec22a){const _0x5dee53=y(_0x488458);if(_0x5dee53===null)return _0x5ec22a;{f(y(_0x488458)!=='.priority'||Ce(_0x488458)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x4a657d=this['getImmediateChild'](_0x5dee53)['updateChild'](S(_0x488458),_0x5ec22a);return this['updateImmediateChild'](_0x5dee53,_0x4a657d);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x1e6652){if(this['isEmpty']())return null;const _0x153493={};let _0x31fe74=0x0,_0x52643a=0x0,_0x376455=!0x0;if(this['forEachChild'](R,(_0x339b28,_0x462ec3)=>{_0x153493[_0x339b28]=_0x462ec3['val'](_0x1e6652),_0x31fe74++,_0x376455&&g['INTEGER_REGEXP_']['test'](_0x339b28)?_0x52643a=Math['max'](_0x52643a,Number(_0x339b28)):_0x376455=!0x1;}),!_0x1e6652&&_0x376455&&_0x52643a<0x2*_0x31fe74){const _0x5051d1=[];for(const _0x2b9744 in _0x153493)_0x5051d1[_0x2b9744]=_0x153493[_0x2b9744];return _0x5051d1;}else return _0x1e6652&&!this['getPriority']()['isEmpty']()&&(_0x153493['.priority']=this['getPriority']()['val']()),_0x153493;}['hash'](){if(this['lazyHash_']===null){let _0x4a423f='';this['getPriority']()['isEmpty']()||(_0x4a423f+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x43f1ac,_0x2a4b8d)=>{const _0x2cdb57=_0x2a4b8d['hash']();_0x2cdb57!==''&&(_0x4a423f+=':'+_0x43f1ac+':'+_0x2cdb57);}),this['lazyHash_']=_0x4a423f===''?'':ro(_0x4a423f);}return this['lazyHash_'];}['getPredecessorChildName'](_0x19be86,_0x1b74e0,_0x26f9de){const _0x4ef31e=this['resolveIndex_'](_0x26f9de);if(_0x4ef31e){const _0x466730=_0x4ef31e['getPredecessorKey'](new E(_0x19be86,_0x1b74e0));return _0x466730?_0x466730['name']:null;}else return this['children_']['getPredecessorKey'](_0x19be86);}['getFirstChildName'](_0x2b8ee6){const _0x4f112e=this['resolveIndex_'](_0x2b8ee6);if(_0x4f112e){const _0x242a62=_0x4f112e['minKey']();return _0x242a62&&_0x242a62['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x2f9852){const _0x3d257a=this['getFirstChildName'](_0x2f9852);return _0x3d257a?new E(_0x3d257a,this['children_']['get'](_0x3d257a)):null;}['getLastChildName'](_0x5ae053){const _0x446692=this['resolveIndex_'](_0x5ae053);if(_0x446692){const _0x33bba9=_0x446692['maxKey']();return _0x33bba9&&_0x33bba9['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x3ba94d){const _0x55ed4b=this['getLastChildName'](_0x3ba94d);return _0x55ed4b?new E(_0x55ed4b,this['children_']['get'](_0x55ed4b)):null;}['forEachChild'](_0x565864,_0x1468a6){const _0x265d13=this['resolveIndex_'](_0x565864);return _0x265d13?_0x265d13['inorderTraversal'](_0x5526e6=>_0x1468a6(_0x5526e6['name'],_0x5526e6['node'])):this['children_']['inorderTraversal'](_0x1468a6);}['getIterator'](_0x3192fa){return this['getIteratorFrom'](_0x3192fa['minPost'](),_0x3192fa);}['getIteratorFrom'](_0x170ecf,_0x34338b){const _0x5c0ca1=this['resolveIndex_'](_0x34338b);if(_0x5c0ca1)return _0x5c0ca1['getIteratorFrom'](_0x170ecf,_0x2c84da=>_0x2c84da);{const _0xb430cb=this['children_']['getIteratorFrom'](_0x170ecf['name'],E['Wrap']);let _0x133b03=_0xb430cb['peek']();for(;_0x133b03!=null&&_0x34338b['compare'](_0x133b03,_0x170ecf)<0x0;)_0xb430cb['getNext'](),_0x133b03=_0xb430cb['peek']();return _0xb430cb;}}['getReverseIterator'](_0x347cb8){return this['getReverseIteratorFrom'](_0x347cb8['maxPost'](),_0x347cb8);}['getReverseIteratorFrom'](_0x3baf19,_0x21cbaa){const _0x563e6b=this['resolveIndex_'](_0x21cbaa);if(_0x563e6b)return _0x563e6b['getReverseIteratorFrom'](_0x3baf19,_0x5c4065=>_0x5c4065);{const _0x2c9404=this['children_']['getReverseIteratorFrom'](_0x3baf19['name'],E['Wrap']);let _0x4fcb4e=_0x2c9404['peek']();for(;_0x4fcb4e!=null&&_0x21cbaa['compare'](_0x4fcb4e,_0x3baf19)>0x0;)_0x2c9404['getNext'](),_0x4fcb4e=_0x2c9404['peek']();return _0x2c9404;}}['compareTo'](_0x3c9182){return this['isEmpty']()?_0x3c9182['isEmpty']()?0x0:-0x1:_0x3c9182['isLeafNode']()||_0x3c9182['isEmpty']()?0x1:_0x3c9182===Kt?-0x1:0x0;}['withIndex'](_0x57bef5){if(_0x57bef5===ve||this['indexMap_']['hasIndex'](_0x57bef5))return this;{const _0x350037=this['indexMap_']['addIndex'](_0x57bef5,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x350037);}}['isIndexed'](_0x449a74){return _0x449a74===ve||this['indexMap_']['hasIndex'](_0x449a74);}['equals'](_0x3b200f){if(_0x3b200f===this)return!0x0;if(_0x3b200f['isLeafNode']())return!0x1;{const _0x2aae04=_0x3b200f;if(this['getPriority']()['equals'](_0x2aae04['getPriority']())){if(this['children_']['count']()===_0x2aae04['children_']['count']()){const _0x2c35d1=this['getIterator'](R),_0x49972b=_0x2aae04['getIterator'](R);let _0x18a9ad=_0x2c35d1['getNext'](),_0xd07aef=_0x49972b['getNext']();for(;_0x18a9ad&&_0xd07aef;){if(_0x18a9ad['name']!==_0xd07aef['name']||!_0x18a9ad['node']['equals'](_0xd07aef['node']))return!0x1;_0x18a9ad=_0x2c35d1['getNext'](),_0xd07aef=_0x49972b['getNext']();}return _0x18a9ad===null&&_0xd07aef===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x56440c){return _0x56440c===ve?null:this['indexMap_']['get'](_0x56440c['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x169700){return _0x169700===this?0x0:0x1;}['equals'](_0x1b2487){return _0x1b2487===this;}['getPriority'](){return this;}['getImmediateChild'](_0x14bd90){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0x1c5702,_0x147ed4=null){if(_0x1c5702===null)return g['EMPTY_NODE'];if(typeof _0x1c5702=='object'&&'.priority'in _0x1c5702&&(_0x147ed4=_0x1c5702['.priority']),f(_0x147ed4===null||typeof _0x147ed4=='string'||typeof _0x147ed4=='number'||typeof _0x147ed4=='object'&&'.sv'in _0x147ed4,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x147ed4),typeof _0x1c5702=='object'&&'.value'in _0x1c5702&&_0x1c5702['.value']!==null&&(_0x1c5702=_0x1c5702['.value']),typeof _0x1c5702!='object'||'.sv'in _0x1c5702){const _0x2eb8c7=_0x1c5702;return new D(_0x2eb8c7,A(_0x147ed4));}if(!(_0x1c5702 instanceof Array)&&Gh){const _0x59c46a=[];let _0x1feef8=!0x1;if(x(_0x1c5702,(_0x315c28,_0x4e4fa9)=>{if(_0x315c28['substring'](0x0,0x1)!=='.'){const _0x23bc7b=A(_0x4e4fa9);_0x23bc7b['isEmpty']()||(_0x1feef8=_0x1feef8||!_0x23bc7b['getPriority']()['isEmpty'](),_0x59c46a['push'](new E(_0x315c28,_0x23bc7b)));}}),_0x59c46a['length']===0x0)return g['EMPTY_NODE'];const _0x38370d=yn(_0x59c46a,xh,_0x17f4e8=>_0x17f4e8['name'],Qi);if(_0x1feef8){const _0x2708c2=yn(_0x59c46a,R['getCompare']());return new g(_0x38370d,A(_0x147ed4),new te({'.priority':_0x2708c2},{'.priority':R}));}else return new g(_0x38370d,A(_0x147ed4),te['Default']);}else{let _0x5f3535=g['EMPTY_NODE'];return x(_0x1c5702,(_0x3a677b,_0x4ff059)=>{if(Q(_0x1c5702,_0x3a677b)&&_0x3a677b['substring'](0x0,0x1)!=='.'){const _0x421912=A(_0x4ff059);(_0x421912['isLeafNode']()||!_0x421912['isEmpty']())&&(_0x5f3535=_0x5f3535['updateImmediateChild'](_0x3a677b,_0x421912));}}),_0x5f3535['updatePriority'](A(_0x147ed4));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x356f16){super(),this['indexPath_']=_0x356f16,f(!v(_0x356f16)&&y(_0x356f16)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x1aabfb){return _0x1aabfb['getChild'](this['indexPath_']);}['isDefinedOn'](_0x4076ad){return!_0x4076ad['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x5eedf4,_0x264327){const _0x4d89ae=this['extractChild'](_0x5eedf4['node']),_0x1b9c74=this['extractChild'](_0x264327['node']),_0x111b79=_0x4d89ae['compareTo'](_0x1b9c74);return _0x111b79===0x0?qe(_0x5eedf4['name'],_0x264327['name']):_0x111b79;}['makePost'](_0x2f7e36,_0x1e56c9){const _0x4bff68=A(_0x2f7e36),_0x2ad826=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x4bff68);return new E(_0x1e56c9,_0x2ad826);}['maxPost'](){const _0x168a7f=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x168a7f);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x1f61a0,_0x1ebf2d){const _0x49c798=_0x1f61a0['node']['compareTo'](_0x1ebf2d['node']);return _0x49c798===0x0?qe(_0x1f61a0['name'],_0x1ebf2d['name']):_0x49c798;}['isDefinedOn'](_0x4ae9f3){return!0x0;}['indexedValueChanged'](_0xf0b6d2,_0x293ac2){return!_0xf0b6d2['equals'](_0x293ac2);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x40faa2,_0x5b8118){const _0xc03f41=A(_0x40faa2);return new E(_0x5b8118,_0xc03f41);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x2f643d){return{'type':'value','snapshotNode':_0x2f643d};}function rt(_0x2896da,_0x59f4e0){return{'type':'child_added','snapshotNode':_0x59f4e0,'childName':_0x2896da};}function Lt(_0x2158d5,_0x39d299){return{'type':'child_removed','snapshotNode':_0x39d299,'childName':_0x2158d5};}function xt(_0x2d8897,_0x3b3e68,_0x2d3a23){return{'type':'child_changed','snapshotNode':_0x3b3e68,'childName':_0x2d8897,'oldSnap':_0x2d3a23};}function zh(_0x4a46a6,_0x445fd2){return{'type':'child_moved','snapshotNode':_0x445fd2,'childName':_0x4a46a6};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x3b9dcd){this['index_']=_0x3b9dcd;}['updateChild'](_0x7510fb,_0x2b02df,_0xdfc85a,_0x45802e,_0x26fd23,_0x29a917){f(_0x7510fb['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x29981b=_0x7510fb['getImmediateChild'](_0x2b02df);return _0x29981b['getChild'](_0x45802e)['equals'](_0xdfc85a['getChild'](_0x45802e))&&_0x29981b['isEmpty']()===_0xdfc85a['isEmpty']()||(_0x29a917!=null&&(_0xdfc85a['isEmpty']()?_0x7510fb['hasChild'](_0x2b02df)?_0x29a917['trackChildChange'](Lt(_0x2b02df,_0x29981b)):f(_0x7510fb['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x29981b['isEmpty']()?_0x29a917['trackChildChange'](rt(_0x2b02df,_0xdfc85a)):_0x29a917['trackChildChange'](xt(_0x2b02df,_0xdfc85a,_0x29981b))),_0x7510fb['isLeafNode']()&&_0xdfc85a['isEmpty']())?_0x7510fb:_0x7510fb['updateImmediateChild'](_0x2b02df,_0xdfc85a)['withIndex'](this['index_']);}['updateFullNode'](_0x430673,_0x58138a,_0xe8a155){return _0xe8a155!=null&&(_0x430673['isLeafNode']()||_0x430673['forEachChild'](R,(_0x12f561,_0xfdf5c2)=>{_0x58138a['hasChild'](_0x12f561)||_0xe8a155['trackChildChange'](Lt(_0x12f561,_0xfdf5c2));}),_0x58138a['isLeafNode']()||_0x58138a['forEachChild'](R,(_0x1acecb,_0x11eff9)=>{if(_0x430673['hasChild'](_0x1acecb)){const _0x12400b=_0x430673['getImmediateChild'](_0x1acecb);_0x12400b['equals'](_0x11eff9)||_0xe8a155['trackChildChange'](xt(_0x1acecb,_0x11eff9,_0x12400b));}else _0xe8a155['trackChildChange'](rt(_0x1acecb,_0x11eff9));})),_0x58138a['withIndex'](this['index_']);}['updatePriority'](_0x56d3e2,_0x2fdf22){return _0x56d3e2['isEmpty']()?g['EMPTY_NODE']:_0x56d3e2['updatePriority'](_0x2fdf22);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x2c575f){this['indexedFilter_']=new Xi(_0x2c575f['getIndex']()),this['index_']=_0x2c575f['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x2c575f),this['endPost_']=Ft['getEndPost_'](_0x2c575f),this['startIsInclusive_']=!_0x2c575f['startAfterSet_'],this['endIsInclusive_']=!_0x2c575f['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x932c69){const _0x373c78=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x932c69)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x932c69)<0x0,_0x31f992=this['endIsInclusive_']?this['index_']['compare'](_0x932c69,this['getEndPost']())<=0x0:this['index_']['compare'](_0x932c69,this['getEndPost']())<0x0;return _0x373c78&&_0x31f992;}['updateChild'](_0x332134,_0x521c7c,_0x5da8fe,_0x1edb7d,_0x338b64,_0x34026e){return this['matches'](new E(_0x521c7c,_0x5da8fe))||(_0x5da8fe=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x332134,_0x521c7c,_0x5da8fe,_0x1edb7d,_0x338b64,_0x34026e);}['updateFullNode'](_0x371de0,_0x2b9f94,_0x52d51b){_0x2b9f94['isLeafNode']()&&(_0x2b9f94=g['EMPTY_NODE']);let _0x3fcb72=_0x2b9f94['withIndex'](this['index_']);_0x3fcb72=_0x3fcb72['updatePriority'](g['EMPTY_NODE']);const _0x333e64=this;return _0x2b9f94['forEachChild'](R,(_0x43f9ce,_0x5bd29e)=>{_0x333e64['matches'](new E(_0x43f9ce,_0x5bd29e))||(_0x3fcb72=_0x3fcb72['updateImmediateChild'](_0x43f9ce,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x371de0,_0x3fcb72,_0x52d51b);}['updatePriority'](_0x414a88,_0x4cde3d){return _0x414a88;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x37f8f1){if(_0x37f8f1['hasStart']()){const _0x5b35f7=_0x37f8f1['getIndexStartName']();return _0x37f8f1['getIndex']()['makePost'](_0x37f8f1['getIndexStartValue'](),_0x5b35f7);}else return _0x37f8f1['getIndex']()['minPost']();}static['getEndPost_'](_0x330e45){if(_0x330e45['hasEnd']()){const _0x550525=_0x330e45['getIndexEndName']();return _0x330e45['getIndex']()['makePost'](_0x330e45['getIndexEndValue'](),_0x550525);}else return _0x330e45['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x504c42){this['withinDirectionalStart']=_0x1a4764=>this['reverse_']?this['withinEndPost'](_0x1a4764):this['withinStartPost'](_0x1a4764),this['withinDirectionalEnd']=_0x318ce5=>this['reverse_']?this['withinStartPost'](_0x318ce5):this['withinEndPost'](_0x318ce5),this['withinStartPost']=_0x533f7c=>{const _0x4fa66a=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x533f7c);return this['startIsInclusive_']?_0x4fa66a<=0x0:_0x4fa66a<0x0;},this['withinEndPost']=_0x193659=>{const _0x3161b1=this['index_']['compare'](_0x193659,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x3161b1<=0x0:_0x3161b1<0x0;},this['rangedFilter_']=new Ft(_0x504c42),this['index_']=_0x504c42['getIndex'](),this['limit_']=_0x504c42['getLimit'](),this['reverse_']=!_0x504c42['isViewFromLeft'](),this['startIsInclusive_']=!_0x504c42['startAfterSet_'],this['endIsInclusive_']=!_0x504c42['endBeforeSet_'];}['updateChild'](_0x2be799,_0x3ba629,_0xec4241,_0xc6ee0c,_0x35aef8,_0x4b1d6a){return this['rangedFilter_']['matches'](new E(_0x3ba629,_0xec4241))||(_0xec4241=g['EMPTY_NODE']),_0x2be799['getImmediateChild'](_0x3ba629)['equals'](_0xec4241)?_0x2be799:_0x2be799['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x2be799,_0x3ba629,_0xec4241,_0xc6ee0c,_0x35aef8,_0x4b1d6a):this['fullLimitUpdateChild_'](_0x2be799,_0x3ba629,_0xec4241,_0x35aef8,_0x4b1d6a);}['updateFullNode'](_0x31efe1,_0x4ec8f3,_0x1dfe73){let _0x750614;if(_0x4ec8f3['isLeafNode']()||_0x4ec8f3['isEmpty']())_0x750614=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x4ec8f3['numChildren']()&&_0x4ec8f3['isIndexed'](this['index_'])){_0x750614=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x213641;this['reverse_']?_0x213641=_0x4ec8f3['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x213641=_0x4ec8f3['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x2717a3=0x0;for(;_0x213641['hasNext']()&&_0x2717a3<this['limit_'];){const _0x5c42a8=_0x213641['getNext']();if(this['withinDirectionalStart'](_0x5c42a8)){if(this['withinDirectionalEnd'](_0x5c42a8))_0x750614=_0x750614['updateImmediateChild'](_0x5c42a8['name'],_0x5c42a8['node']),_0x2717a3++;else break;}else continue;}}else{_0x750614=_0x4ec8f3['withIndex'](this['index_']),_0x750614=_0x750614['updatePriority'](g['EMPTY_NODE']);let _0x1ae1b6;this['reverse_']?_0x1ae1b6=_0x750614['getReverseIterator'](this['index_']):_0x1ae1b6=_0x750614['getIterator'](this['index_']);let _0x2dc152=0x0;for(;_0x1ae1b6['hasNext']();){const _0x5ac74d=_0x1ae1b6['getNext']();_0x2dc152<this['limit_']&&this['withinDirectionalStart'](_0x5ac74d)&&this['withinDirectionalEnd'](_0x5ac74d)?_0x2dc152++:_0x750614=_0x750614['updateImmediateChild'](_0x5ac74d['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x31efe1,_0x750614,_0x1dfe73);}['updatePriority'](_0x480612,_0x30154c){return _0x480612;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x1391a6,_0x563535,_0x56045c,_0x543601,_0x4029ba){let _0x5b7355;if(this['reverse_']){const _0xe18d5f=this['index_']['getCompare']();_0x5b7355=(_0x23cdc5,_0x3929d0)=>_0xe18d5f(_0x3929d0,_0x23cdc5);}else _0x5b7355=this['index_']['getCompare']();const _0xd55b28=_0x1391a6;f(_0xd55b28['numChildren']()===this['limit_'],'');const _0x2438bc=new E(_0x563535,_0x56045c),_0x45cb8a=this['reverse_']?_0xd55b28['getFirstChild'](this['index_']):_0xd55b28['getLastChild'](this['index_']),_0x543ad5=this['rangedFilter_']['matches'](_0x2438bc);if(_0xd55b28['hasChild'](_0x563535)){const _0xf1344=_0xd55b28['getImmediateChild'](_0x563535);let _0x333c10=_0x543601['getChildAfterChild'](this['index_'],_0x45cb8a,this['reverse_']);for(;_0x333c10!=null&&(_0x333c10['name']===_0x563535||_0xd55b28['hasChild'](_0x333c10['name']));)_0x333c10=_0x543601['getChildAfterChild'](this['index_'],_0x333c10,this['reverse_']);const _0x4a9f9d=_0x333c10==null?0x1:_0x5b7355(_0x333c10,_0x2438bc);if(_0x543ad5&&!_0x56045c['isEmpty']()&&_0x4a9f9d>=0x0)return _0x4029ba!=null&&_0x4029ba['trackChildChange'](xt(_0x563535,_0x56045c,_0xf1344)),_0xd55b28['updateImmediateChild'](_0x563535,_0x56045c);{_0x4029ba!=null&&_0x4029ba['trackChildChange'](Lt(_0x563535,_0xf1344));const _0x3fdacf=_0xd55b28['updateImmediateChild'](_0x563535,g['EMPTY_NODE']);return _0x333c10!=null&&this['rangedFilter_']['matches'](_0x333c10)?(_0x4029ba!=null&&_0x4029ba['trackChildChange'](rt(_0x333c10['name'],_0x333c10['node'])),_0x3fdacf['updateImmediateChild'](_0x333c10['name'],_0x333c10['node'])):_0x3fdacf;}}else return _0x56045c['isEmpty']()?_0x1391a6:_0x543ad5&&_0x5b7355(_0x45cb8a,_0x2438bc)>=0x0?(_0x4029ba!=null&&(_0x4029ba['trackChildChange'](Lt(_0x45cb8a['name'],_0x45cb8a['node'])),_0x4029ba['trackChildChange'](rt(_0x563535,_0x56045c))),_0xd55b28['updateImmediateChild'](_0x563535,_0x56045c)['updateImmediateChild'](_0x45cb8a['name'],g['EMPTY_NODE'])):_0x1391a6;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x466647=new Zi();return _0x466647['limitSet_']=this['limitSet_'],_0x466647['limit_']=this['limit_'],_0x466647['startSet_']=this['startSet_'],_0x466647['startAfterSet_']=this['startAfterSet_'],_0x466647['indexStartValue_']=this['indexStartValue_'],_0x466647['startNameSet_']=this['startNameSet_'],_0x466647['indexStartName_']=this['indexStartName_'],_0x466647['endSet_']=this['endSet_'],_0x466647['endBeforeSet_']=this['endBeforeSet_'],_0x466647['indexEndValue_']=this['indexEndValue_'],_0x466647['endNameSet_']=this['endNameSet_'],_0x466647['indexEndName_']=this['indexEndName_'],_0x466647['index_']=this['index_'],_0x466647['viewFrom_']=this['viewFrom_'],_0x466647;}}function Kh(_0x2804f3){return _0x2804f3['loadsAllData']()?new Xi(_0x2804f3['getIndex']()):_0x2804f3['hasLimit']()?new jh(_0x2804f3):new Ft(_0x2804f3);}function Yh(_0x3bc6d2,_0x3e245b){const _0x2a8e9e=_0x3bc6d2['copy']();return _0x2a8e9e['limitSet_']=!0x0,_0x2a8e9e['limit_']=_0x3e245b,_0x2a8e9e['viewFrom_']='l',_0x2a8e9e;}function Qh(_0x3b0cc6,_0x44fcab,_0x5087f0){const _0x47334a=_0x3b0cc6['copy']();return _0x47334a['startSet_']=!0x0,_0x44fcab===void 0x0&&(_0x44fcab=null),_0x47334a['indexStartValue_']=_0x44fcab,_0x5087f0!=null?(_0x47334a['startNameSet_']=!0x0,_0x47334a['indexStartName_']=_0x5087f0):(_0x47334a['startNameSet_']=!0x1,_0x47334a['indexStartName_']=''),_0x47334a;}function Jh(_0x4f19c9,_0xfed0ff,_0x527eb8){const _0x2378b6=_0x4f19c9['copy']();return _0x2378b6['endSet_']=!0x0,_0xfed0ff===void 0x0&&(_0xfed0ff=null),_0x2378b6['indexEndValue_']=_0xfed0ff,_0x527eb8!==void 0x0?(_0x2378b6['endNameSet_']=!0x0,_0x2378b6['indexEndName_']=_0x527eb8):(_0x2378b6['endNameSet_']=!0x1,_0x2378b6['indexEndName_']=''),_0x2378b6;}function xo(_0x241a17,_0x3d0e44){const _0xb89f94=_0x241a17['copy']();return _0xb89f94['index_']=_0x3d0e44,_0xb89f94;}function ir(_0x373384){const _0x270702={};if(_0x373384['isDefault']())return _0x270702;let _0x2f4a0b;if(_0x373384['index_']===R?_0x2f4a0b='$priority':_0x373384['index_']===Mo?_0x2f4a0b='$value':_0x373384['index_']===ve?_0x2f4a0b='$key':(f(_0x373384['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x2f4a0b=_0x373384['index_']['toString']()),_0x270702['orderBy']=O(_0x2f4a0b),_0x373384['startSet_']){const _0x366737=_0x373384['startAfterSet_']?'startAfter':'startAt';_0x270702[_0x366737]=O(_0x373384['indexStartValue_']),_0x373384['startNameSet_']&&(_0x270702[_0x366737]+=','+O(_0x373384['indexStartName_']));}if(_0x373384['endSet_']){const _0x3db3ae=_0x373384['endBeforeSet_']?'endBefore':'endAt';_0x270702[_0x3db3ae]=O(_0x373384['indexEndValue_']),_0x373384['endNameSet_']&&(_0x270702[_0x3db3ae]+=','+O(_0x373384['indexEndName_']));}return _0x373384['limitSet_']&&(_0x373384['isViewFromLeft']()?_0x270702['limitToFirst']=_0x373384['limit_']:_0x270702['limitToLast']=_0x373384['limit_']),_0x270702;}function sr(_0xd44ae5){const _0x51b0e5={};if(_0xd44ae5['startSet_']&&(_0x51b0e5['sp']=_0xd44ae5['indexStartValue_'],_0xd44ae5['startNameSet_']&&(_0x51b0e5['sn']=_0xd44ae5['indexStartName_']),_0x51b0e5['sin']=!_0xd44ae5['startAfterSet_']),_0xd44ae5['endSet_']&&(_0x51b0e5['ep']=_0xd44ae5['indexEndValue_'],_0xd44ae5['endNameSet_']&&(_0x51b0e5['en']=_0xd44ae5['indexEndName_']),_0x51b0e5['ein']=!_0xd44ae5['endBeforeSet_']),_0xd44ae5['limitSet_']){_0x51b0e5['l']=_0xd44ae5['limit_'];let _0x236bb0=_0xd44ae5['viewFrom_'];_0x236bb0===''&&(_0xd44ae5['isViewFromLeft']()?_0x236bb0='l':_0x236bb0='r'),_0x51b0e5['vf']=_0x236bb0;}return _0xd44ae5['index_']!==R&&(_0x51b0e5['i']=_0xd44ae5['index_']['toString']()),_0x51b0e5;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x5c0446){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x53a1f6,_0x237ec4){return _0x237ec4!==void 0x0?'tag$'+_0x237ec4:(f(_0x53a1f6['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x53a1f6['_path']['toString']());}constructor(_0x20e96c,_0x417b05,_0x43b798,_0x1649a3){super(),this['repoInfo_']=_0x20e96c,this['onDataUpdate_']=_0x417b05,this['authTokenProvider_']=_0x43b798,this['appCheckTokenProvider_']=_0x1649a3,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x5d8243,_0x25ecba,_0x33ee5e,_0x27cb2c){const _0x412898=_0x5d8243['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x412898+'\x20'+_0x5d8243['_queryIdentifier']);const _0x236a06=vn['getListenId_'](_0x5d8243,_0x33ee5e),_0x58262c={};this['listens_'][_0x236a06]=_0x58262c;const _0x3a7677=ir(_0x5d8243['_queryParams']);this['restRequest_'](_0x412898+'.json',_0x3a7677,(_0x40f2b1,_0x2df2bf)=>{let _0x5cda7d=_0x2df2bf;if(_0x40f2b1===0x194&&(_0x5cda7d=null,_0x40f2b1=null),_0x40f2b1===null&&this['onDataUpdate_'](_0x412898,_0x5cda7d,!0x1,_0x33ee5e),Le(this['listens_'],_0x236a06)===_0x58262c){let _0x1f9265;_0x40f2b1?_0x40f2b1===0x191?_0x1f9265='permission_denied':_0x1f9265='rest_error:'+_0x40f2b1:_0x1f9265='ok',_0x27cb2c(_0x1f9265,null);}});}['unlisten'](_0x58e21e,_0x10758c){const _0x27e73b=vn['getListenId_'](_0x58e21e,_0x10758c);delete this['listens_'][_0x27e73b];}['get'](_0x343da7){const _0x47bab5=ir(_0x343da7['_queryParams']),_0x10323c=_0x343da7['_path']['toString'](),_0x5cb8b9=new H();return this['restRequest_'](_0x10323c+'.json',_0x47bab5,(_0xfe0648,_0x59cddd)=>{let _0x274af8=_0x59cddd;_0xfe0648===0x194&&(_0x274af8=null,_0xfe0648=null),_0xfe0648===null?(this['onDataUpdate_'](_0x10323c,_0x274af8,!0x1,null),_0x5cb8b9['resolve'](_0x274af8)):_0x5cb8b9['reject'](new Error(_0x274af8));}),_0x5cb8b9['promise'];}['refreshAuthToken'](_0x4fbc37){}['restRequest_'](_0x3d843c,_0x259119={},_0x155905){return _0x259119['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x11d066,_0x27d0d1])=>{_0x11d066&&_0x11d066['accessToken']&&(_0x259119['auth']=_0x11d066['accessToken']),_0x27d0d1&&_0x27d0d1['token']&&(_0x259119['ac']=_0x27d0d1['token']);const _0x57bd2c=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x3d843c+'?ns='+this['repoInfo_']['namespace']+ut(_0x259119);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x57bd2c);const _0x58daab=new XMLHttpRequest();_0x58daab['onreadystatechange']=()=>{if(_0x155905&&_0x58daab['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x57bd2c+'\x20received.\x20status:',_0x58daab['status'],'response:',_0x58daab['responseText']);let _0x13bb2f=null;if(_0x58daab['status']>=0xc8&&_0x58daab['status']<0x12c){try{_0x13bb2f=Nt(_0x58daab['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x57bd2c+':\x20'+_0x58daab['responseText']);}_0x155905(null,_0x13bb2f);}else _0x58daab['status']!==0x191&&_0x58daab['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x57bd2c+'\x20Status:\x20'+_0x58daab['status']),_0x155905(_0x58daab['status']);_0x155905=null;}},_0x58daab['open']('GET',_0x57bd2c,!0x0),_0x58daab['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x152698){return this['rootNode_']['getChild'](_0x152698);}['updateSnapshot'](_0x541e50,_0x422ece){this['rootNode_']=this['rootNode_']['updateChild'](_0x541e50,_0x422ece);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x20e087,_0x27e696,_0x3a6bca){if(v(_0x27e696))_0x20e087['value']=_0x3a6bca,_0x20e087['children']['clear']();else{if(_0x20e087['value']!==null)_0x20e087['value']=_0x20e087['value']['updateChild'](_0x27e696,_0x3a6bca);else{const _0x308e94=y(_0x27e696);_0x20e087['children']['has'](_0x308e94)||_0x20e087['children']['set'](_0x308e94,En());const _0x76c8d6=_0x20e087['children']['get'](_0x308e94);_0x27e696=S(_0x27e696),pt(_0x76c8d6,_0x27e696,_0x3a6bca);}}}function Ti(_0x3abb36,_0x13afb0){if(v(_0x13afb0))return _0x3abb36['value']=null,_0x3abb36['children']['clear'](),!0x0;if(_0x3abb36['value']!==null){if(_0x3abb36['value']['isLeafNode']())return!0x1;{const _0x298fd5=_0x3abb36['value'];return _0x3abb36['value']=null,_0x298fd5['forEachChild'](R,(_0x2b8612,_0x3d9f2a)=>{pt(_0x3abb36,new C(_0x2b8612),_0x3d9f2a);}),Ti(_0x3abb36,_0x13afb0);}}else{if(_0x3abb36['children']['size']>0x0){const _0x37045b=y(_0x13afb0);return _0x13afb0=S(_0x13afb0),_0x3abb36['children']['has'](_0x37045b)&&Ti(_0x3abb36['children']['get'](_0x37045b),_0x13afb0)&&_0x3abb36['children']['delete'](_0x37045b),_0x3abb36['children']['size']===0x0;}else return!0x0;}}function Si(_0x3133a0,_0xa58031,_0x2a5df8){_0x3133a0['value']!==null?_0x2a5df8(_0xa58031,_0x3133a0['value']):Zh(_0x3133a0,(_0x28441f,_0x4a619a)=>{const _0x193b2c=new C(_0xa58031['toString']()+'/'+_0x28441f);Si(_0x4a619a,_0x193b2c,_0x2a5df8);});}function Zh(_0x46d70b,_0xe800f4){_0x46d70b['children']['forEach']((_0x23c1fe,_0x1f7e85)=>{_0xe800f4(_0x1f7e85,_0x23c1fe);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x1c4386){this['collection_']=_0x1c4386,this['last_']=null;}['get'](){const _0x8f9cfa=this['collection_']['get'](),_0x47c149={..._0x8f9cfa};return this['last_']&&x(this['last_'],(_0x205c3c,_0x309cd8)=>{_0x47c149[_0x205c3c]=_0x47c149[_0x205c3c]-_0x309cd8;}),this['last_']=_0x8f9cfa,_0x47c149;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x2f13d9,_0x38b688){this['server_']=_0x38b688,this['statsToReport_']={},this['statsListener_']=new eu(_0x2f13d9);const _0x48ffad=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x48ffad));}['reportStats_'](){const _0x2ee6c4=this['statsListener_']['get'](),_0x1b41dc={};let _0x116b47=!0x1;x(_0x2ee6c4,(_0x367d67,_0x213094)=>{_0x213094>0x0&&Q(this['statsToReport_'],_0x367d67)&&(_0x1b41dc[_0x367d67]=_0x213094,_0x116b47=!0x0);}),_0x116b47&&this['server_']['reportStats'](_0x1b41dc),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x1dc76b){_0x1dc76b[_0x1dc76b['OVERWRITE']=0x0]='OVERWRITE',_0x1dc76b[_0x1dc76b['MERGE']=0x1]='MERGE',_0x1dc76b[_0x1dc76b['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x1dc76b[_0x1dc76b['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x56fee5){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x56fee5,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x322d73,_0x37c05e,_0x364dcd){this['path']=_0x322d73,this['affectedTree']=_0x37c05e,this['revert']=_0x364dcd,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x3fb641){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0xff7cd3=this['affectedTree']['subtree'](new C(_0x3fb641));return new In(w(),_0xff7cd3,this['revert']);}}else return f(y(this['path'])===_0x3fb641,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x397ec5,_0x58c52c){this['source']=_0x397ec5,this['path']=_0x58c52c,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x4c9346){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x3c4a5e,_0x1f8d58,_0x4b4340){this['source']=_0x3c4a5e,this['path']=_0x1f8d58,this['snap']=_0x4b4340,this['type']=z['OVERWRITE'];}['operationForChild'](_0x253d07){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x253d07)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x59aba6,_0x557f15,_0x8dab80){this['source']=_0x59aba6,this['path']=_0x557f15,this['children']=_0x8dab80,this['type']=z['MERGE'];}['operationForChild'](_0xd3879d){if(v(this['path'])){const _0x264a81=this['children']['subtree'](new C(_0xd3879d));return _0x264a81['isEmpty']()?null:_0x264a81['value']?new Be(this['source'],w(),_0x264a81['value']):new ot(this['source'],w(),_0x264a81);}else return f(y(this['path'])===_0xd3879d,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x45d9ef,_0x5abfa4,_0x3d323d){this['node_']=_0x45d9ef,this['fullyInitialized_']=_0x5abfa4,this['filtered_']=_0x3d323d;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0xd7ab96){if(v(_0xd7ab96))return this['isFullyInitialized']()&&!this['filtered_'];const _0x48a010=y(_0xd7ab96);return this['isCompleteForChild'](_0x48a010);}['isCompleteForChild'](_0xfd83fe){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0xfd83fe);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x573f6c){this['query_']=_0x573f6c,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x20a519,_0x555617,_0x17e8d5,_0x41e798){const _0x51f5b5=[],_0x4b2f36=[];return _0x555617['forEach'](_0x48f1b1=>{_0x48f1b1['type']==='child_changed'&&_0x20a519['index_']['indexedValueChanged'](_0x48f1b1['oldSnap'],_0x48f1b1['snapshotNode'])&&_0x4b2f36['push'](zh(_0x48f1b1['childName'],_0x48f1b1['snapshotNode']));}),wt(_0x20a519,_0x51f5b5,'child_removed',_0x555617,_0x41e798,_0x17e8d5),wt(_0x20a519,_0x51f5b5,'child_added',_0x555617,_0x41e798,_0x17e8d5),wt(_0x20a519,_0x51f5b5,'child_moved',_0x4b2f36,_0x41e798,_0x17e8d5),wt(_0x20a519,_0x51f5b5,'child_changed',_0x555617,_0x41e798,_0x17e8d5),wt(_0x20a519,_0x51f5b5,'value',_0x555617,_0x41e798,_0x17e8d5),_0x51f5b5;}function wt(_0x1ce1eb,_0x4a4695,_0x1eb5ae,_0x5e11ae,_0x4fe6ad,_0x542500){const _0xcbcf92=_0x5e11ae['filter'](_0x484754=>_0x484754['type']===_0x1eb5ae);_0xcbcf92['sort']((_0x3f8a0,_0x25cc7f)=>au(_0x1ce1eb,_0x3f8a0,_0x25cc7f)),_0xcbcf92['forEach'](_0x501d39=>{const _0x3787ed=ou(_0x1ce1eb,_0x501d39,_0x542500);_0x4fe6ad['forEach'](_0x28ca23=>{_0x28ca23['respondsTo'](_0x501d39['type'])&&_0x4a4695['push'](_0x28ca23['createEvent'](_0x3787ed,_0x1ce1eb['query_']));});});}function ou(_0x2d546b,_0x5d88ba,_0x197612){return _0x5d88ba['type']==='value'||_0x5d88ba['type']==='child_removed'||(_0x5d88ba['prevName']=_0x197612['getPredecessorChildName'](_0x5d88ba['childName'],_0x5d88ba['snapshotNode'],_0x2d546b['index_'])),_0x5d88ba;}function au(_0x3cc662,_0xf8b02c,_0x2d82c5){if(_0xf8b02c['childName']==null||_0x2d82c5['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x1a365f=new E(_0xf8b02c['childName'],_0xf8b02c['snapshotNode']),_0x42633c=new E(_0x2d82c5['childName'],_0x2d82c5['snapshotNode']);return _0x3cc662['index_']['compare'](_0x1a365f,_0x42633c);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x1a8784,_0xeda3c0){return{'eventCache':_0x1a8784,'serverCache':_0xeda3c0};}function Rt(_0x369ab4,_0x4252be,_0xd3c2e5,_0x5557f1){return Un(new Te(_0x4252be,_0xd3c2e5,_0x5557f1),_0x369ab4['serverCache']);}function Fo(_0x1e241b,_0x382893,_0xaf7fc3,_0x44f141){return Un(_0x1e241b['eventCache'],new Te(_0x382893,_0xaf7fc3,_0x44f141));}function wn(_0x549570){return _0x549570['eventCache']['isFullyInitialized']()?_0x549570['eventCache']['getNode']():null;}function Ve(_0x34d064){return _0x34d064['serverCache']['isFullyInitialized']()?_0x34d064['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x270dc4){let _0x19b422=new b(null);return x(_0x270dc4,(_0x1c9bd2,_0x1aa4d9)=>{_0x19b422=_0x19b422['set'](new C(_0x1c9bd2),_0x1aa4d9);}),_0x19b422;}constructor(_0x21f5d0,_0x445bab=cu()){this['value']=_0x21f5d0,this['children']=_0x445bab;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x576423,_0x35d5e4){if(this['value']!=null&&_0x35d5e4(this['value']))return{'path':w(),'value':this['value']};if(v(_0x576423))return null;{const _0xa774b=y(_0x576423),_0x57b8a2=this['children']['get'](_0xa774b);if(_0x57b8a2!==null){const _0x23090e=_0x57b8a2['findRootMostMatchingPathAndValue'](S(_0x576423),_0x35d5e4);return _0x23090e!=null?{'path':k(new C(_0xa774b),_0x23090e['path']),'value':_0x23090e['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x313c9d){return this['findRootMostMatchingPathAndValue'](_0x313c9d,()=>!0x0);}['subtree'](_0x37c153){if(v(_0x37c153))return this;{const _0x1dea27=y(_0x37c153),_0x403862=this['children']['get'](_0x1dea27);return _0x403862!==null?_0x403862['subtree'](S(_0x37c153)):new b(null);}}['set'](_0x32a883,_0x2d7960){if(v(_0x32a883))return new b(_0x2d7960,this['children']);{const _0x2c6bce=y(_0x32a883),_0x1d34a4=(this['children']['get'](_0x2c6bce)||new b(null))['set'](S(_0x32a883),_0x2d7960),_0x455016=this['children']['insert'](_0x2c6bce,_0x1d34a4);return new b(this['value'],_0x455016);}}['remove'](_0x20c965){if(v(_0x20c965))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x4c6aed=y(_0x20c965),_0x1326b9=this['children']['get'](_0x4c6aed);if(_0x1326b9){const _0x1a4531=_0x1326b9['remove'](S(_0x20c965));let _0x13d45e;return _0x1a4531['isEmpty']()?_0x13d45e=this['children']['remove'](_0x4c6aed):_0x13d45e=this['children']['insert'](_0x4c6aed,_0x1a4531),this['value']===null&&_0x13d45e['isEmpty']()?new b(null):new b(this['value'],_0x13d45e);}else return this;}}['get'](_0x10c37b){if(v(_0x10c37b))return this['value'];{const _0x404aa9=y(_0x10c37b),_0x18f9f2=this['children']['get'](_0x404aa9);return _0x18f9f2?_0x18f9f2['get'](S(_0x10c37b)):null;}}['setTree'](_0x59628e,_0x325070){if(v(_0x59628e))return _0x325070;{const _0x3b711e=y(_0x59628e),_0x59a3de=(this['children']['get'](_0x3b711e)||new b(null))['setTree'](S(_0x59628e),_0x325070);let _0x33a6bc;return _0x59a3de['isEmpty']()?_0x33a6bc=this['children']['remove'](_0x3b711e):_0x33a6bc=this['children']['insert'](_0x3b711e,_0x59a3de),new b(this['value'],_0x33a6bc);}}['fold'](_0x4b8e3e){return this['fold_'](w(),_0x4b8e3e);}['fold_'](_0x49bfd6,_0x1bdb24){const _0x3bf0ba={};return this['children']['inorderTraversal']((_0x36f168,_0x36c8aa)=>{_0x3bf0ba[_0x36f168]=_0x36c8aa['fold_'](k(_0x49bfd6,_0x36f168),_0x1bdb24);}),_0x1bdb24(_0x49bfd6,this['value'],_0x3bf0ba);}['findOnPath'](_0xb86f8a,_0x2b6a6f){return this['findOnPath_'](_0xb86f8a,w(),_0x2b6a6f);}['findOnPath_'](_0x433329,_0x1a8f21,_0x469ea2){const _0x11b8b7=this['value']?_0x469ea2(_0x1a8f21,this['value']):!0x1;if(_0x11b8b7)return _0x11b8b7;if(v(_0x433329))return null;{const _0x2cea52=y(_0x433329),_0x47ab02=this['children']['get'](_0x2cea52);return _0x47ab02?_0x47ab02['findOnPath_'](S(_0x433329),k(_0x1a8f21,_0x2cea52),_0x469ea2):null;}}['foreachOnPath'](_0x1b3e84,_0x25e762){return this['foreachOnPath_'](_0x1b3e84,w(),_0x25e762);}['foreachOnPath_'](_0x53d826,_0x40ae7e,_0x5e0513){if(v(_0x53d826))return this;{this['value']&&_0x5e0513(_0x40ae7e,this['value']);const _0x65dc14=y(_0x53d826),_0x315fbc=this['children']['get'](_0x65dc14);return _0x315fbc?_0x315fbc['foreachOnPath_'](S(_0x53d826),k(_0x40ae7e,_0x65dc14),_0x5e0513):new b(null);}}['foreach'](_0x109b16){this['foreach_'](w(),_0x109b16);}['foreach_'](_0x10a777,_0x20cfcd){this['children']['inorderTraversal']((_0x3f7c02,_0x1d54db)=>{_0x1d54db['foreach_'](k(_0x10a777,_0x3f7c02),_0x20cfcd);}),this['value']&&_0x20cfcd(_0x10a777,this['value']);}['foreachChild'](_0x466458){this['children']['inorderTraversal']((_0x564b76,_0xd277fb)=>{_0xd277fb['value']&&_0x466458(_0x564b76,_0xd277fb['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x48b9cc){this['writeTree_']=_0x48b9cc;}static['empty'](){return new K(new b(null));}}function At(_0x1fc9a0,_0x258c64,_0x4c4e70){if(v(_0x258c64))return new K(new b(_0x4c4e70));{const _0x5d969e=_0x1fc9a0['writeTree_']['findRootMostValueAndPath'](_0x258c64);if(_0x5d969e!=null){const _0x7b6b30=_0x5d969e['path'];let _0xdf0d55=_0x5d969e['value'];const _0x5ee2ba=F(_0x7b6b30,_0x258c64);return _0xdf0d55=_0xdf0d55['updateChild'](_0x5ee2ba,_0x4c4e70),new K(_0x1fc9a0['writeTree_']['set'](_0x7b6b30,_0xdf0d55));}else{const _0x7f4e54=new b(_0x4c4e70),_0x4965bd=_0x1fc9a0['writeTree_']['setTree'](_0x258c64,_0x7f4e54);return new K(_0x4965bd);}}}function bi(_0x5b6ad6,_0x4df3e7,_0x50f35a){let _0x3d1ec0=_0x5b6ad6;return x(_0x50f35a,(_0x40fbe6,_0x1f6b3e)=>{_0x3d1ec0=At(_0x3d1ec0,k(_0x4df3e7,_0x40fbe6),_0x1f6b3e);}),_0x3d1ec0;}function or(_0x49d0ab,_0xd1144d){if(v(_0xd1144d))return K['empty']();{const _0x295ed7=_0x49d0ab['writeTree_']['setTree'](_0xd1144d,new b(null));return new K(_0x295ed7);}}function Ri(_0x326e2d,_0xdb0bba){return ze(_0x326e2d,_0xdb0bba)!=null;}function ze(_0x182acc,_0x213f57){const _0x4e61ff=_0x182acc['writeTree_']['findRootMostValueAndPath'](_0x213f57);return _0x4e61ff!=null?_0x182acc['writeTree_']['get'](_0x4e61ff['path'])['getChild'](F(_0x4e61ff['path'],_0x213f57)):null;}function ar(_0x40afbd){const _0x2b454e=[],_0x7a09aa=_0x40afbd['writeTree_']['value'];return _0x7a09aa!=null?_0x7a09aa['isLeafNode']()||_0x7a09aa['forEachChild'](R,(_0x24faa7,_0xb6de7e)=>{_0x2b454e['push'](new E(_0x24faa7,_0xb6de7e));}):_0x40afbd['writeTree_']['children']['inorderTraversal']((_0x50c912,_0x5021f4)=>{_0x5021f4['value']!=null&&_0x2b454e['push'](new E(_0x50c912,_0x5021f4['value']));}),_0x2b454e;}function Ee(_0x46efe8,_0x314de8){if(v(_0x314de8))return _0x46efe8;{const _0x252cc1=ze(_0x46efe8,_0x314de8);return _0x252cc1!=null?new K(new b(_0x252cc1)):new K(_0x46efe8['writeTree_']['subtree'](_0x314de8));}}function Ai(_0x2cec49){return _0x2cec49['writeTree_']['isEmpty']();}function at(_0x3170cd,_0x13fe76){return Uo(w(),_0x3170cd['writeTree_'],_0x13fe76);}function Uo(_0x2ca1be,_0x1dc94c,_0x5ba5d7){if(_0x1dc94c['value']!=null)return _0x5ba5d7['updateChild'](_0x2ca1be,_0x1dc94c['value']);{let _0x49bfd7=null;return _0x1dc94c['children']['inorderTraversal']((_0x4e15ac,_0x1104dc)=>{_0x4e15ac==='.priority'?(f(_0x1104dc['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x49bfd7=_0x1104dc['value']):_0x5ba5d7=Uo(k(_0x2ca1be,_0x4e15ac),_0x1104dc,_0x5ba5d7);}),!_0x5ba5d7['getChild'](_0x2ca1be)['isEmpty']()&&_0x49bfd7!==null&&(_0x5ba5d7=_0x5ba5d7['updateChild'](k(_0x2ca1be,'.priority'),_0x49bfd7)),_0x5ba5d7;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x1c40a1,_0x22f09c){return Ho(_0x22f09c,_0x1c40a1);}function lu(_0x412dfc,_0x59f085,_0x115fc5,_0x38db4c,_0x287712){f(_0x38db4c>_0x412dfc['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x287712===void 0x0&&(_0x287712=!0x0),_0x412dfc['allWrites']['push']({'path':_0x59f085,'snap':_0x115fc5,'writeId':_0x38db4c,'visible':_0x287712}),_0x287712&&(_0x412dfc['visibleWrites']=At(_0x412dfc['visibleWrites'],_0x59f085,_0x115fc5)),_0x412dfc['lastWriteId']=_0x38db4c;}function hu(_0x204207,_0x45ca42,_0x5a6f73,_0x5864ea){f(_0x5864ea>_0x204207['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x204207['allWrites']['push']({'path':_0x45ca42,'children':_0x5a6f73,'writeId':_0x5864ea,'visible':!0x0}),_0x204207['visibleWrites']=bi(_0x204207['visibleWrites'],_0x45ca42,_0x5a6f73),_0x204207['lastWriteId']=_0x5864ea;}function uu(_0x56b14d,_0x33374e){for(let _0x335aa5=0x0;_0x335aa5<_0x56b14d['allWrites']['length'];_0x335aa5++){const _0x44b6df=_0x56b14d['allWrites'][_0x335aa5];if(_0x44b6df['writeId']===_0x33374e)return _0x44b6df;}return null;}function du(_0x4e3b8d,_0x5bcbaa){const _0x56862a=_0x4e3b8d['allWrites']['findIndex'](_0x117d4b=>_0x117d4b['writeId']===_0x5bcbaa);f(_0x56862a>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x1e6346=_0x4e3b8d['allWrites'][_0x56862a];_0x4e3b8d['allWrites']['splice'](_0x56862a,0x1);let _0x56a40e=_0x1e6346['visible'],_0x3affa1=!0x1,_0x466050=_0x4e3b8d['allWrites']['length']-0x1;for(;_0x56a40e&&_0x466050>=0x0;){const _0x3e91e0=_0x4e3b8d['allWrites'][_0x466050];_0x3e91e0['visible']&&(_0x466050>=_0x56862a&&fu(_0x3e91e0,_0x1e6346['path'])?_0x56a40e=!0x1:G(_0x1e6346['path'],_0x3e91e0['path'])&&(_0x3affa1=!0x0)),_0x466050--;}if(_0x56a40e){if(_0x3affa1)return pu(_0x4e3b8d),!0x0;if(_0x1e6346['snap'])_0x4e3b8d['visibleWrites']=or(_0x4e3b8d['visibleWrites'],_0x1e6346['path']);else{const _0x1d93b4=_0x1e6346['children'];x(_0x1d93b4,_0xb37fe8=>{_0x4e3b8d['visibleWrites']=or(_0x4e3b8d['visibleWrites'],k(_0x1e6346['path'],_0xb37fe8));});}return!0x0;}else return!0x1;}function fu(_0x3142be,_0x4a5aff){if(_0x3142be['snap'])return G(_0x3142be['path'],_0x4a5aff);for(const _0x5380bc in _0x3142be['children'])if(_0x3142be['children']['hasOwnProperty'](_0x5380bc)&&G(k(_0x3142be['path'],_0x5380bc),_0x4a5aff))return!0x0;return!0x1;}function pu(_0x36467f){_0x36467f['visibleWrites']=Wo(_0x36467f['allWrites'],_u,w()),_0x36467f['allWrites']['length']>0x0?_0x36467f['lastWriteId']=_0x36467f['allWrites'][_0x36467f['allWrites']['length']-0x1]['writeId']:_0x36467f['lastWriteId']=-0x1;}function _u(_0x311614){return _0x311614['visible'];}function Wo(_0xc09829,_0x1c39d3,_0x61d5cc){let _0x144982=K['empty']();for(let _0xbd7257=0x0;_0xbd7257<_0xc09829['length'];++_0xbd7257){const _0x8178c=_0xc09829[_0xbd7257];if(_0x1c39d3(_0x8178c)){const _0x460f1e=_0x8178c['path'];let _0x4cc762;if(_0x8178c['snap'])G(_0x61d5cc,_0x460f1e)?(_0x4cc762=F(_0x61d5cc,_0x460f1e),_0x144982=At(_0x144982,_0x4cc762,_0x8178c['snap'])):G(_0x460f1e,_0x61d5cc)&&(_0x4cc762=F(_0x460f1e,_0x61d5cc),_0x144982=At(_0x144982,w(),_0x8178c['snap']['getChild'](_0x4cc762)));else{if(_0x8178c['children']){if(G(_0x61d5cc,_0x460f1e))_0x4cc762=F(_0x61d5cc,_0x460f1e),_0x144982=bi(_0x144982,_0x4cc762,_0x8178c['children']);else{if(G(_0x460f1e,_0x61d5cc)){if(_0x4cc762=F(_0x460f1e,_0x61d5cc),v(_0x4cc762))_0x144982=bi(_0x144982,w(),_0x8178c['children']);else{const _0x527fb6=Le(_0x8178c['children'],y(_0x4cc762));if(_0x527fb6){const _0xe0fcee=_0x527fb6['getChild'](S(_0x4cc762));_0x144982=At(_0x144982,w(),_0xe0fcee);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x144982;}function Bo(_0x2086e7,_0x90bb82,_0x552840,_0x46498f,_0x5d6fcf){if(!_0x46498f&&!_0x5d6fcf){const _0x4e2ff8=ze(_0x2086e7['visibleWrites'],_0x90bb82);if(_0x4e2ff8!=null)return _0x4e2ff8;{const _0x596fcd=Ee(_0x2086e7['visibleWrites'],_0x90bb82);if(Ai(_0x596fcd))return _0x552840;if(_0x552840==null&&!Ri(_0x596fcd,w()))return null;{const _0x5e2a93=_0x552840||g['EMPTY_NODE'];return at(_0x596fcd,_0x5e2a93);}}}else{const _0x38afc9=Ee(_0x2086e7['visibleWrites'],_0x90bb82);if(!_0x5d6fcf&&Ai(_0x38afc9))return _0x552840;if(!_0x5d6fcf&&_0x552840==null&&!Ri(_0x38afc9,w()))return null;{const _0xfb57eb=function(_0x2717e0){return(_0x2717e0['visible']||_0x5d6fcf)&&(!_0x46498f||!~_0x46498f['indexOf'](_0x2717e0['writeId']))&&(G(_0x2717e0['path'],_0x90bb82)||G(_0x90bb82,_0x2717e0['path']));},_0x134fa0=Wo(_0x2086e7['allWrites'],_0xfb57eb,_0x90bb82),_0x10b1d8=_0x552840||g['EMPTY_NODE'];return at(_0x134fa0,_0x10b1d8);}}}function gu(_0x416378,_0x1cb860,_0x5d3d17){let _0x225a13=g['EMPTY_NODE'];const _0x5f287f=ze(_0x416378['visibleWrites'],_0x1cb860);if(_0x5f287f)return _0x5f287f['isLeafNode']()||_0x5f287f['forEachChild'](R,(_0x4a2574,_0x131bdb)=>{_0x225a13=_0x225a13['updateImmediateChild'](_0x4a2574,_0x131bdb);}),_0x225a13;if(_0x5d3d17){const _0x266e34=Ee(_0x416378['visibleWrites'],_0x1cb860);return _0x5d3d17['forEachChild'](R,(_0x5d754d,_0x161683)=>{const _0x427585=at(Ee(_0x266e34,new C(_0x5d754d)),_0x161683);_0x225a13=_0x225a13['updateImmediateChild'](_0x5d754d,_0x427585);}),ar(_0x266e34)['forEach'](_0x4b9c0f=>{_0x225a13=_0x225a13['updateImmediateChild'](_0x4b9c0f['name'],_0x4b9c0f['node']);}),_0x225a13;}else{const _0x4c89ed=Ee(_0x416378['visibleWrites'],_0x1cb860);return ar(_0x4c89ed)['forEach'](_0x1659f2=>{_0x225a13=_0x225a13['updateImmediateChild'](_0x1659f2['name'],_0x1659f2['node']);}),_0x225a13;}}function mu(_0x3e3d3b,_0x53a55c,_0x3136d3,_0x3517b6,_0x2cdeba){f(_0x3517b6||_0x2cdeba,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0xcb420c=k(_0x53a55c,_0x3136d3);if(Ri(_0x3e3d3b['visibleWrites'],_0xcb420c))return null;{const _0x3daff5=Ee(_0x3e3d3b['visibleWrites'],_0xcb420c);return Ai(_0x3daff5)?_0x2cdeba['getChild'](_0x3136d3):at(_0x3daff5,_0x2cdeba['getChild'](_0x3136d3));}}function yu(_0x4e48a8,_0x26608a,_0x1a37ba,_0x54c9f2){const _0x499316=k(_0x26608a,_0x1a37ba),_0x478c2b=ze(_0x4e48a8['visibleWrites'],_0x499316);if(_0x478c2b!=null)return _0x478c2b;if(_0x54c9f2['isCompleteForChild'](_0x1a37ba)){const _0x4ac9dd=Ee(_0x4e48a8['visibleWrites'],_0x499316);return at(_0x4ac9dd,_0x54c9f2['getNode']()['getImmediateChild'](_0x1a37ba));}else return null;}function vu(_0x2e8c84,_0x59815f){return ze(_0x2e8c84['visibleWrites'],_0x59815f);}function Eu(_0x456573,_0x321143,_0x3df0d4,_0x58f617,_0x584c3b,_0x16ba10,_0x43643d){let _0x5d9c8c;const _0x346a88=Ee(_0x456573['visibleWrites'],_0x321143),_0x2967b6=ze(_0x346a88,w());if(_0x2967b6!=null)_0x5d9c8c=_0x2967b6;else{if(_0x3df0d4!=null)_0x5d9c8c=at(_0x346a88,_0x3df0d4);else return[];}if(_0x5d9c8c=_0x5d9c8c['withIndex'](_0x43643d),!_0x5d9c8c['isEmpty']()&&!_0x5d9c8c['isLeafNode']()){const _0x46f640=[],_0x1d16ce=_0x43643d['getCompare'](),_0x951298=_0x16ba10?_0x5d9c8c['getReverseIteratorFrom'](_0x58f617,_0x43643d):_0x5d9c8c['getIteratorFrom'](_0x58f617,_0x43643d);let _0x1722c1=_0x951298['getNext']();for(;_0x1722c1&&_0x46f640['length']<_0x584c3b;)_0x1d16ce(_0x1722c1,_0x58f617)!==0x0&&_0x46f640['push'](_0x1722c1),_0x1722c1=_0x951298['getNext']();return _0x46f640;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x44e59d,_0x2be3af,_0x389ec8,_0x1d9b4b){return Bo(_0x44e59d['writeTree'],_0x44e59d['treePath'],_0x2be3af,_0x389ec8,_0x1d9b4b);}function is(_0x492537,_0x7b3f68){return gu(_0x492537['writeTree'],_0x492537['treePath'],_0x7b3f68);}function cr(_0x214754,_0x49ce75,_0x34ef1e,_0x153bc4){return mu(_0x214754['writeTree'],_0x214754['treePath'],_0x49ce75,_0x34ef1e,_0x153bc4);}function Tn(_0x33054d,_0x241b9a){return vu(_0x33054d['writeTree'],k(_0x33054d['treePath'],_0x241b9a));}function wu(_0x1ae73a,_0x449b2e,_0x6c0da1,_0x403b10,_0x4221db,_0xc6dabd){return Eu(_0x1ae73a['writeTree'],_0x1ae73a['treePath'],_0x449b2e,_0x6c0da1,_0x403b10,_0x4221db,_0xc6dabd);}function ss(_0x2aff9b,_0x114ddb,_0x582733){return yu(_0x2aff9b['writeTree'],_0x2aff9b['treePath'],_0x114ddb,_0x582733);}function Vo(_0x577cbe,_0x19dd39){return Ho(k(_0x577cbe['treePath'],_0x19dd39),_0x577cbe['writeTree']);}function Ho(_0xa56007,_0x450d22){return{'treePath':_0xa56007,'writeTree':_0x450d22};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x5884fe){const _0x1004d9=_0x5884fe['type'],_0x4709e7=_0x5884fe['childName'];f(_0x1004d9==='child_added'||_0x1004d9==='child_changed'||_0x1004d9==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x4709e7!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x1d924a=this['changeMap']['get'](_0x4709e7);if(_0x1d924a){const _0x5336c7=_0x1d924a['type'];if(_0x1004d9==='child_added'&&_0x5336c7==='child_removed')this['changeMap']['set'](_0x4709e7,xt(_0x4709e7,_0x5884fe['snapshotNode'],_0x1d924a['snapshotNode']));else{if(_0x1004d9==='child_removed'&&_0x5336c7==='child_added')this['changeMap']['delete'](_0x4709e7);else{if(_0x1004d9==='child_removed'&&_0x5336c7==='child_changed')this['changeMap']['set'](_0x4709e7,Lt(_0x4709e7,_0x1d924a['oldSnap']));else{if(_0x1004d9==='child_changed'&&_0x5336c7==='child_added')this['changeMap']['set'](_0x4709e7,rt(_0x4709e7,_0x5884fe['snapshotNode']));else{if(_0x1004d9==='child_changed'&&_0x5336c7==='child_changed')this['changeMap']['set'](_0x4709e7,xt(_0x4709e7,_0x5884fe['snapshotNode'],_0x1d924a['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x5884fe+'\x20occurred\x20after\x20'+_0x1d924a);}}}}}else this['changeMap']['set'](_0x4709e7,_0x5884fe);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x1e5275){return null;}['getChildAfterChild'](_0x780b3c,_0x45e17f,_0x5435ca){return null;}}const $o=new Tu();class rs{constructor(_0x156e95,_0x1c88bb,_0x2cd847=null){this['writes_']=_0x156e95,this['viewCache_']=_0x1c88bb,this['optCompleteServerCache_']=_0x2cd847;}['getCompleteChild'](_0x326d16){const _0x237016=this['viewCache_']['eventCache'];if(_0x237016['isCompleteForChild'](_0x326d16))return _0x237016['getNode']()['getImmediateChild'](_0x326d16);{const _0x397bff=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x326d16,_0x397bff);}}['getChildAfterChild'](_0x3064c0,_0x34171b,_0x242839){const _0x21d921=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x100ad5=wu(this['writes_'],_0x21d921,_0x34171b,0x1,_0x242839,_0x3064c0);return _0x100ad5['length']===0x0?null:_0x100ad5[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x52f3b4){return{'filter':_0x52f3b4};}function bu(_0x551dea,_0x102337){f(_0x102337['eventCache']['getNode']()['isIndexed'](_0x551dea['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x102337['serverCache']['getNode']()['isIndexed'](_0x551dea['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x43ba1,_0x22994e,_0x5c8f0c,_0x4c4da6,_0x57056c){const _0x252156=new Cu();let _0x315f7c,_0x9bf8f;if(_0x5c8f0c['type']===z['OVERWRITE']){const _0x1e447c=_0x5c8f0c;_0x1e447c['source']['fromUser']?_0x315f7c=ki(_0x43ba1,_0x22994e,_0x1e447c['path'],_0x1e447c['snap'],_0x4c4da6,_0x57056c,_0x252156):(f(_0x1e447c['source']['fromServer'],'Unknown\x20source.'),_0x9bf8f=_0x1e447c['source']['tagged']||_0x22994e['serverCache']['isFiltered']()&&!v(_0x1e447c['path']),_0x315f7c=Sn(_0x43ba1,_0x22994e,_0x1e447c['path'],_0x1e447c['snap'],_0x4c4da6,_0x57056c,_0x9bf8f,_0x252156));}else{if(_0x5c8f0c['type']===z['MERGE']){const _0x29ab22=_0x5c8f0c;_0x29ab22['source']['fromUser']?_0x315f7c=ku(_0x43ba1,_0x22994e,_0x29ab22['path'],_0x29ab22['children'],_0x4c4da6,_0x57056c,_0x252156):(f(_0x29ab22['source']['fromServer'],'Unknown\x20source.'),_0x9bf8f=_0x29ab22['source']['tagged']||_0x22994e['serverCache']['isFiltered'](),_0x315f7c=Pi(_0x43ba1,_0x22994e,_0x29ab22['path'],_0x29ab22['children'],_0x4c4da6,_0x57056c,_0x9bf8f,_0x252156));}else{if(_0x5c8f0c['type']===z['ACK_USER_WRITE']){const _0x908a0f=_0x5c8f0c;_0x908a0f['revert']?_0x315f7c=Ou(_0x43ba1,_0x22994e,_0x908a0f['path'],_0x4c4da6,_0x57056c,_0x252156):_0x315f7c=Pu(_0x43ba1,_0x22994e,_0x908a0f['path'],_0x908a0f['affectedTree'],_0x4c4da6,_0x57056c,_0x252156);}else{if(_0x5c8f0c['type']===z['LISTEN_COMPLETE'])_0x315f7c=Nu(_0x43ba1,_0x22994e,_0x5c8f0c['path'],_0x4c4da6,_0x252156);else throw ht('Unknown\x20operation\x20type:\x20'+_0x5c8f0c['type']);}}}const _0x2b1a6d=_0x252156['getChanges']();return Au(_0x22994e,_0x315f7c,_0x2b1a6d),{'viewCache':_0x315f7c,'changes':_0x2b1a6d};}function Au(_0x3351e7,_0x24a00b,_0x18cca7){const _0x363eeb=_0x24a00b['eventCache'];if(_0x363eeb['isFullyInitialized']()){const _0x7f6c15=_0x363eeb['getNode']()['isLeafNode']()||_0x363eeb['getNode']()['isEmpty'](),_0xa03a09=wn(_0x3351e7);(_0x18cca7['length']>0x0||!_0x3351e7['eventCache']['isFullyInitialized']()||_0x7f6c15&&!_0x363eeb['getNode']()['equals'](_0xa03a09)||!_0x363eeb['getNode']()['getPriority']()['equals'](_0xa03a09['getPriority']()))&&_0x18cca7['push'](Lo(wn(_0x24a00b)));}}function Go(_0x369195,_0x5a25db,_0x8e9b3e,_0x56d3f8,_0x5ccfff,_0x5d1ae5){const _0x4952e2=_0x5a25db['eventCache'];if(Tn(_0x56d3f8,_0x8e9b3e)!=null)return _0x5a25db;{let _0x28b95c,_0x41a16e;if(v(_0x8e9b3e)){if(f(_0x5a25db['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x5a25db['serverCache']['isFiltered']()){const _0x6acfc5=Ve(_0x5a25db),_0x172ef5=_0x6acfc5 instanceof g?_0x6acfc5:g['EMPTY_NODE'],_0x3a4408=is(_0x56d3f8,_0x172ef5);_0x28b95c=_0x369195['filter']['updateFullNode'](_0x5a25db['eventCache']['getNode'](),_0x3a4408,_0x5d1ae5);}else{const _0x3aa26f=Cn(_0x56d3f8,Ve(_0x5a25db));_0x28b95c=_0x369195['filter']['updateFullNode'](_0x5a25db['eventCache']['getNode'](),_0x3aa26f,_0x5d1ae5);}}else{const _0x145ba9=y(_0x8e9b3e);if(_0x145ba9==='.priority'){f(Ce(_0x8e9b3e)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x76d29b=_0x4952e2['getNode']();_0x41a16e=_0x5a25db['serverCache']['getNode']();const _0x31b847=cr(_0x56d3f8,_0x8e9b3e,_0x76d29b,_0x41a16e);_0x31b847!=null?_0x28b95c=_0x369195['filter']['updatePriority'](_0x76d29b,_0x31b847):_0x28b95c=_0x4952e2['getNode']();}else{const _0x4d516e=S(_0x8e9b3e);let _0x3a02b0;if(_0x4952e2['isCompleteForChild'](_0x145ba9)){_0x41a16e=_0x5a25db['serverCache']['getNode']();const _0x543df2=cr(_0x56d3f8,_0x8e9b3e,_0x4952e2['getNode'](),_0x41a16e);_0x543df2!=null?_0x3a02b0=_0x4952e2['getNode']()['getImmediateChild'](_0x145ba9)['updateChild'](_0x4d516e,_0x543df2):_0x3a02b0=_0x4952e2['getNode']()['getImmediateChild'](_0x145ba9);}else _0x3a02b0=ss(_0x56d3f8,_0x145ba9,_0x5a25db['serverCache']);_0x3a02b0!=null?_0x28b95c=_0x369195['filter']['updateChild'](_0x4952e2['getNode'](),_0x145ba9,_0x3a02b0,_0x4d516e,_0x5ccfff,_0x5d1ae5):_0x28b95c=_0x4952e2['getNode']();}}return Rt(_0x5a25db,_0x28b95c,_0x4952e2['isFullyInitialized']()||v(_0x8e9b3e),_0x369195['filter']['filtersNodes']());}}function Sn(_0x131fa6,_0x4be094,_0x336b79,_0x15892f,_0x114948,_0x5328a1,_0xb79103,_0x83d45c){const _0x93e99f=_0x4be094['serverCache'];let _0x4511e0;const _0x5f5727=_0xb79103?_0x131fa6['filter']:_0x131fa6['filter']['getIndexedFilter']();if(v(_0x336b79))_0x4511e0=_0x5f5727['updateFullNode'](_0x93e99f['getNode'](),_0x15892f,null);else{if(_0x5f5727['filtersNodes']()&&!_0x93e99f['isFiltered']()){const _0x4c03a9=_0x93e99f['getNode']()['updateChild'](_0x336b79,_0x15892f);_0x4511e0=_0x5f5727['updateFullNode'](_0x93e99f['getNode'](),_0x4c03a9,null);}else{const _0x124536=y(_0x336b79);if(!_0x93e99f['isCompleteForPath'](_0x336b79)&&Ce(_0x336b79)>0x1)return _0x4be094;const _0x316171=S(_0x336b79),_0x21e918=_0x93e99f['getNode']()['getImmediateChild'](_0x124536)['updateChild'](_0x316171,_0x15892f);_0x124536==='.priority'?_0x4511e0=_0x5f5727['updatePriority'](_0x93e99f['getNode'](),_0x21e918):_0x4511e0=_0x5f5727['updateChild'](_0x93e99f['getNode'](),_0x124536,_0x21e918,_0x316171,$o,null);}}const _0x5234bd=Fo(_0x4be094,_0x4511e0,_0x93e99f['isFullyInitialized']()||v(_0x336b79),_0x5f5727['filtersNodes']()),_0x2955cb=new rs(_0x114948,_0x5234bd,_0x5328a1);return Go(_0x131fa6,_0x5234bd,_0x336b79,_0x114948,_0x2955cb,_0x83d45c);}function ki(_0x2bacf5,_0x3cf609,_0x564a6e,_0x2a9780,_0x69568a,_0x1f1c21,_0x5b7ecc){const _0x29d08e=_0x3cf609['eventCache'];let _0xea22a0,_0x28fe47;const _0x2804f9=new rs(_0x69568a,_0x3cf609,_0x1f1c21);if(v(_0x564a6e))_0x28fe47=_0x2bacf5['filter']['updateFullNode'](_0x3cf609['eventCache']['getNode'](),_0x2a9780,_0x5b7ecc),_0xea22a0=Rt(_0x3cf609,_0x28fe47,!0x0,_0x2bacf5['filter']['filtersNodes']());else{const _0x177a63=y(_0x564a6e);if(_0x177a63==='.priority')_0x28fe47=_0x2bacf5['filter']['updatePriority'](_0x3cf609['eventCache']['getNode'](),_0x2a9780),_0xea22a0=Rt(_0x3cf609,_0x28fe47,_0x29d08e['isFullyInitialized'](),_0x29d08e['isFiltered']());else{const _0x46a8fe=S(_0x564a6e),_0x20433b=_0x29d08e['getNode']()['getImmediateChild'](_0x177a63);let _0x2929b9;if(v(_0x46a8fe))_0x2929b9=_0x2a9780;else{const _0x140b97=_0x2804f9['getCompleteChild'](_0x177a63);_0x140b97!=null?ji(_0x46a8fe)==='.priority'&&_0x140b97['getChild'](Ro(_0x46a8fe))['isEmpty']()?_0x2929b9=_0x140b97:_0x2929b9=_0x140b97['updateChild'](_0x46a8fe,_0x2a9780):_0x2929b9=g['EMPTY_NODE'];}if(_0x20433b['equals'](_0x2929b9))_0xea22a0=_0x3cf609;else{const _0x407b29=_0x2bacf5['filter']['updateChild'](_0x29d08e['getNode'](),_0x177a63,_0x2929b9,_0x46a8fe,_0x2804f9,_0x5b7ecc);_0xea22a0=Rt(_0x3cf609,_0x407b29,_0x29d08e['isFullyInitialized'](),_0x2bacf5['filter']['filtersNodes']());}}}return _0xea22a0;}function lr(_0x23db01,_0x1877be){return _0x23db01['eventCache']['isCompleteForChild'](_0x1877be);}function ku(_0x1d6fce,_0x514ac8,_0x584bbf,_0x5cb5dc,_0x470580,_0x4be0c1,_0x3bb407){let _0x307570=_0x514ac8;return _0x5cb5dc['foreach']((_0x4d63cc,_0xc5d6a)=>{const _0x10ce8a=k(_0x584bbf,_0x4d63cc);lr(_0x514ac8,y(_0x10ce8a))&&(_0x307570=ki(_0x1d6fce,_0x307570,_0x10ce8a,_0xc5d6a,_0x470580,_0x4be0c1,_0x3bb407));}),_0x5cb5dc['foreach']((_0x166005,_0x462be8)=>{const _0x4bdf49=k(_0x584bbf,_0x166005);lr(_0x514ac8,y(_0x4bdf49))||(_0x307570=ki(_0x1d6fce,_0x307570,_0x4bdf49,_0x462be8,_0x470580,_0x4be0c1,_0x3bb407));}),_0x307570;}function hr(_0x2dfe7c,_0x389442,_0x549f2f){return _0x549f2f['foreach']((_0x86b0e1,_0x19b2aa)=>{_0x389442=_0x389442['updateChild'](_0x86b0e1,_0x19b2aa);}),_0x389442;}function Pi(_0x3f1771,_0x350dc2,_0x2fb05b,_0x22c057,_0x2331ec,_0x59813c,_0x15b2a0,_0x53062a){if(_0x350dc2['serverCache']['getNode']()['isEmpty']()&&!_0x350dc2['serverCache']['isFullyInitialized']())return _0x350dc2;let _0xba82cf=_0x350dc2,_0x4f9c9e;v(_0x2fb05b)?_0x4f9c9e=_0x22c057:_0x4f9c9e=new b(null)['setTree'](_0x2fb05b,_0x22c057);const _0x34a865=_0x350dc2['serverCache']['getNode']();return _0x4f9c9e['children']['inorderTraversal']((_0x513293,_0x162b0c)=>{if(_0x34a865['hasChild'](_0x513293)){const _0x560973=_0x350dc2['serverCache']['getNode']()['getImmediateChild'](_0x513293),_0x27582c=hr(_0x3f1771,_0x560973,_0x162b0c);_0xba82cf=Sn(_0x3f1771,_0xba82cf,new C(_0x513293),_0x27582c,_0x2331ec,_0x59813c,_0x15b2a0,_0x53062a);}}),_0x4f9c9e['children']['inorderTraversal']((_0x107a65,_0x1023e9)=>{const _0x2a4de8=!_0x350dc2['serverCache']['isCompleteForChild'](_0x107a65)&&_0x1023e9['value']===null;if(!_0x34a865['hasChild'](_0x107a65)&&!_0x2a4de8){const _0x3f3eed=_0x350dc2['serverCache']['getNode']()['getImmediateChild'](_0x107a65),_0x4c17f7=hr(_0x3f1771,_0x3f3eed,_0x1023e9);_0xba82cf=Sn(_0x3f1771,_0xba82cf,new C(_0x107a65),_0x4c17f7,_0x2331ec,_0x59813c,_0x15b2a0,_0x53062a);}}),_0xba82cf;}function Pu(_0x1a3f69,_0x540a0f,_0x1c7700,_0x2d138b,_0xaed01e,_0x1ea1e1,_0x16d2f3){if(Tn(_0xaed01e,_0x1c7700)!=null)return _0x540a0f;const _0x35e02d=_0x540a0f['serverCache']['isFiltered'](),_0x37eb9f=_0x540a0f['serverCache'];if(_0x2d138b['value']!=null){if(v(_0x1c7700)&&_0x37eb9f['isFullyInitialized']()||_0x37eb9f['isCompleteForPath'](_0x1c7700))return Sn(_0x1a3f69,_0x540a0f,_0x1c7700,_0x37eb9f['getNode']()['getChild'](_0x1c7700),_0xaed01e,_0x1ea1e1,_0x35e02d,_0x16d2f3);if(v(_0x1c7700)){let _0x4874a1=new b(null);return _0x37eb9f['getNode']()['forEachChild'](ve,(_0x6ff269,_0x4e1d26)=>{_0x4874a1=_0x4874a1['set'](new C(_0x6ff269),_0x4e1d26);}),Pi(_0x1a3f69,_0x540a0f,_0x1c7700,_0x4874a1,_0xaed01e,_0x1ea1e1,_0x35e02d,_0x16d2f3);}else return _0x540a0f;}else{let _0x578fda=new b(null);return _0x2d138b['foreach']((_0x3c892f,_0x1d4abe)=>{const _0x92afb7=k(_0x1c7700,_0x3c892f);_0x37eb9f['isCompleteForPath'](_0x92afb7)&&(_0x578fda=_0x578fda['set'](_0x3c892f,_0x37eb9f['getNode']()['getChild'](_0x92afb7)));}),Pi(_0x1a3f69,_0x540a0f,_0x1c7700,_0x578fda,_0xaed01e,_0x1ea1e1,_0x35e02d,_0x16d2f3);}}function Nu(_0x397e5e,_0x1bac70,_0x50f9df,_0x3ba952,_0x1d32b1){const _0x289546=_0x1bac70['serverCache'],_0x192e3c=Fo(_0x1bac70,_0x289546['getNode'](),_0x289546['isFullyInitialized']()||v(_0x50f9df),_0x289546['isFiltered']());return Go(_0x397e5e,_0x192e3c,_0x50f9df,_0x3ba952,$o,_0x1d32b1);}function Ou(_0x3870e7,_0x1cc5d8,_0x50ea4d,_0x403a6f,_0x5efa78,_0x59e55e){let _0x454cd8;if(Tn(_0x403a6f,_0x50ea4d)!=null)return _0x1cc5d8;{const _0x2a131c=new rs(_0x403a6f,_0x1cc5d8,_0x5efa78),_0x18bd3f=_0x1cc5d8['eventCache']['getNode']();let _0x2179a6;if(v(_0x50ea4d)||y(_0x50ea4d)==='.priority'){let _0x4c2e35;if(_0x1cc5d8['serverCache']['isFullyInitialized']())_0x4c2e35=Cn(_0x403a6f,Ve(_0x1cc5d8));else{const _0x8a7ece=_0x1cc5d8['serverCache']['getNode']();f(_0x8a7ece instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x4c2e35=is(_0x403a6f,_0x8a7ece);}_0x4c2e35=_0x4c2e35,_0x2179a6=_0x3870e7['filter']['updateFullNode'](_0x18bd3f,_0x4c2e35,_0x59e55e);}else{const _0x2630dc=y(_0x50ea4d);let _0x57daba=ss(_0x403a6f,_0x2630dc,_0x1cc5d8['serverCache']);_0x57daba==null&&_0x1cc5d8['serverCache']['isCompleteForChild'](_0x2630dc)&&(_0x57daba=_0x18bd3f['getImmediateChild'](_0x2630dc)),_0x57daba!=null?_0x2179a6=_0x3870e7['filter']['updateChild'](_0x18bd3f,_0x2630dc,_0x57daba,S(_0x50ea4d),_0x2a131c,_0x59e55e):_0x1cc5d8['eventCache']['getNode']()['hasChild'](_0x2630dc)?_0x2179a6=_0x3870e7['filter']['updateChild'](_0x18bd3f,_0x2630dc,g['EMPTY_NODE'],S(_0x50ea4d),_0x2a131c,_0x59e55e):_0x2179a6=_0x18bd3f,_0x2179a6['isEmpty']()&&_0x1cc5d8['serverCache']['isFullyInitialized']()&&(_0x454cd8=Cn(_0x403a6f,Ve(_0x1cc5d8)),_0x454cd8['isLeafNode']()&&(_0x2179a6=_0x3870e7['filter']['updateFullNode'](_0x2179a6,_0x454cd8,_0x59e55e)));}return _0x454cd8=_0x1cc5d8['serverCache']['isFullyInitialized']()||Tn(_0x403a6f,w())!=null,Rt(_0x1cc5d8,_0x2179a6,_0x454cd8,_0x3870e7['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x137232,_0x49dcf4){this['query_']=_0x137232,this['eventRegistrations_']=[];const _0x2a1e27=this['query_']['_queryParams'],_0x13ecde=new Xi(_0x2a1e27['getIndex']()),_0x210299=Kh(_0x2a1e27);this['processor_']=Su(_0x210299);const _0xe5aea=_0x49dcf4['serverCache'],_0x14e580=_0x49dcf4['eventCache'],_0x276a8b=_0x13ecde['updateFullNode'](g['EMPTY_NODE'],_0xe5aea['getNode'](),null),_0x4bffcc=_0x210299['updateFullNode'](g['EMPTY_NODE'],_0x14e580['getNode'](),null),_0x12758c=new Te(_0x276a8b,_0xe5aea['isFullyInitialized'](),_0x13ecde['filtersNodes']()),_0x16116d=new Te(_0x4bffcc,_0x14e580['isFullyInitialized'](),_0x210299['filtersNodes']());this['viewCache_']=Un(_0x16116d,_0x12758c),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x13c16c){return _0x13c16c['viewCache_']['serverCache']['getNode']();}function Lu(_0x1451a9){return wn(_0x1451a9['viewCache_']);}function xu(_0x3943e4,_0x29de8d){const _0x25f2db=Ve(_0x3943e4['viewCache_']);return _0x25f2db&&(_0x3943e4['query']['_queryParams']['loadsAllData']()||!v(_0x29de8d)&&!_0x25f2db['getImmediateChild'](y(_0x29de8d))['isEmpty']())?_0x25f2db['getChild'](_0x29de8d):null;}function ur(_0x3e27d5){return _0x3e27d5['eventRegistrations_']['length']===0x0;}function Fu(_0x1636a5,_0x3e561f){_0x1636a5['eventRegistrations_']['push'](_0x3e561f);}function dr(_0x3bee17,_0x2f7fd3,_0x5bbe83){const _0x5407b1=[];if(_0x5bbe83){f(_0x2f7fd3==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x498d89=_0x3bee17['query']['_path'];_0x3bee17['eventRegistrations_']['forEach'](_0x40970d=>{const _0xbb70a1=_0x40970d['createCancelEvent'](_0x5bbe83,_0x498d89);_0xbb70a1&&_0x5407b1['push'](_0xbb70a1);});}if(_0x2f7fd3){let _0xd16c62=[];for(let _0x3a4a5c=0x0;_0x3a4a5c<_0x3bee17['eventRegistrations_']['length'];++_0x3a4a5c){const _0xf4578b=_0x3bee17['eventRegistrations_'][_0x3a4a5c];if(!_0xf4578b['matches'](_0x2f7fd3))_0xd16c62['push'](_0xf4578b);else{if(_0x2f7fd3['hasAnyCallback']()){_0xd16c62=_0xd16c62['concat'](_0x3bee17['eventRegistrations_']['slice'](_0x3a4a5c+0x1));break;}}}_0x3bee17['eventRegistrations_']=_0xd16c62;}else _0x3bee17['eventRegistrations_']=[];return _0x5407b1;}function fr(_0x51e255,_0x4d9909,_0x145ade,_0x42eca6){_0x4d9909['type']===z['MERGE']&&_0x4d9909['source']['queryId']!==null&&(f(Ve(_0x51e255['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x51e255['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x525ad4=_0x51e255['viewCache_'],_0x1cde3a=Ru(_0x51e255['processor_'],_0x525ad4,_0x4d9909,_0x145ade,_0x42eca6);return bu(_0x51e255['processor_'],_0x1cde3a['viewCache']),f(_0x1cde3a['viewCache']['serverCache']['isFullyInitialized']()||!_0x525ad4['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x51e255['viewCache_']=_0x1cde3a['viewCache'],qo(_0x51e255,_0x1cde3a['changes'],_0x1cde3a['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x33fcab,_0x230e2a){const _0x290f98=_0x33fcab['viewCache_']['eventCache'],_0x4a4d84=[];return _0x290f98['getNode']()['isLeafNode']()||_0x290f98['getNode']()['forEachChild'](R,(_0x339ea1,_0x2535c9)=>{_0x4a4d84['push'](rt(_0x339ea1,_0x2535c9));}),_0x290f98['isFullyInitialized']()&&_0x4a4d84['push'](Lo(_0x290f98['getNode']())),qo(_0x33fcab,_0x4a4d84,_0x290f98['getNode'](),_0x230e2a);}function qo(_0x2fdb5c,_0x20b698,_0x2c9b66,_0x578b74){const _0x4afe40=_0x578b74?[_0x578b74]:_0x2fdb5c['eventRegistrations_'];return ru(_0x2fdb5c['eventGenerator_'],_0x20b698,_0x2c9b66,_0x4afe40);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x52a53d){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x52a53d;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x571158){return _0x571158['views']['size']===0x0;}function os(_0x5d0628,_0x26ddfe,_0x40ed96,_0x57f669){const _0x451b6e=_0x26ddfe['source']['queryId'];if(_0x451b6e!==null){const _0x6795db=_0x5d0628['views']['get'](_0x451b6e);return f(_0x6795db!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x6795db,_0x26ddfe,_0x40ed96,_0x57f669);}else{let _0x5c1b62=[];for(const _0x25e787 of _0x5d0628['views']['values']())_0x5c1b62=_0x5c1b62['concat'](fr(_0x25e787,_0x26ddfe,_0x40ed96,_0x57f669));return _0x5c1b62;}}function jo(_0x5c54d3,_0x1a8063,_0x1d4b20,_0x566e81,_0x56f0f8){const _0x39ace2=_0x1a8063['_queryIdentifier'],_0x55bce3=_0x5c54d3['views']['get'](_0x39ace2);if(!_0x55bce3){let _0x5c0497=Cn(_0x1d4b20,_0x56f0f8?_0x566e81:null),_0x5056d6=!0x1;_0x5c0497?_0x5056d6=!0x0:_0x566e81 instanceof g?(_0x5c0497=is(_0x1d4b20,_0x566e81),_0x5056d6=!0x1):(_0x5c0497=g['EMPTY_NODE'],_0x5056d6=!0x1);const _0x26c293=Un(new Te(_0x5c0497,_0x5056d6,!0x1),new Te(_0x566e81,_0x56f0f8,!0x1));return new Du(_0x1a8063,_0x26c293);}return _0x55bce3;}function Hu(_0x32e0a5,_0x15b6f7,_0x20a195,_0x3ca11d,_0x56e6d7,_0x5b8477){const _0x1bc67e=jo(_0x32e0a5,_0x15b6f7,_0x3ca11d,_0x56e6d7,_0x5b8477);return _0x32e0a5['views']['has'](_0x15b6f7['_queryIdentifier'])||_0x32e0a5['views']['set'](_0x15b6f7['_queryIdentifier'],_0x1bc67e),Fu(_0x1bc67e,_0x20a195),Uu(_0x1bc67e,_0x20a195);}function $u(_0x53e230,_0x4a2951,_0x1c7d91,_0x1f0b8f){const _0x470553=_0x4a2951['_queryIdentifier'],_0xe64ebf=[];let _0x62ca61=[];const _0x2dfc56=Se(_0x53e230);if(_0x470553==='default'){for(const [_0x2064f7,_0x3ddfe9]of _0x53e230['views']['entries']())_0x62ca61=_0x62ca61['concat'](dr(_0x3ddfe9,_0x1c7d91,_0x1f0b8f)),ur(_0x3ddfe9)&&(_0x53e230['views']['delete'](_0x2064f7),_0x3ddfe9['query']['_queryParams']['loadsAllData']()||_0xe64ebf['push'](_0x3ddfe9['query']));}else{const _0x26b093=_0x53e230['views']['get'](_0x470553);_0x26b093&&(_0x62ca61=_0x62ca61['concat'](dr(_0x26b093,_0x1c7d91,_0x1f0b8f)),ur(_0x26b093)&&(_0x53e230['views']['delete'](_0x470553),_0x26b093['query']['_queryParams']['loadsAllData']()||_0xe64ebf['push'](_0x26b093['query'])));}return _0x2dfc56&&!Se(_0x53e230)&&_0xe64ebf['push'](new(Bu())(_0x4a2951['_repo'],_0x4a2951['_path'])),{'removed':_0xe64ebf,'events':_0x62ca61};}function Ko(_0x1c38c1){const _0x2de2fc=[];for(const _0x4a1e4e of _0x1c38c1['views']['values']())_0x4a1e4e['query']['_queryParams']['loadsAllData']()||_0x2de2fc['push'](_0x4a1e4e);return _0x2de2fc;}function Ie(_0x2f8056,_0x5cedfe){let _0x20108a=null;for(const _0x484ee3 of _0x2f8056['views']['values']())_0x20108a=_0x20108a||xu(_0x484ee3,_0x5cedfe);return _0x20108a;}function Yo(_0x59e6a9,_0x4a3201){if(_0x4a3201['_queryParams']['loadsAllData']())return Bn(_0x59e6a9);{const _0x5f0932=_0x4a3201['_queryIdentifier'];return _0x59e6a9['views']['get'](_0x5f0932);}}function Qo(_0x1bb239,_0x2426ff){return Yo(_0x1bb239,_0x2426ff)!=null;}function Se(_0x246980){return Bn(_0x246980)!=null;}function Bn(_0x1bab70){for(const _0x238de2 of _0x1bab70['views']['values']())if(_0x238de2['query']['_queryParams']['loadsAllData']())return _0x238de2;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x3e92a9){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x3e92a9;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0xe2af9a){this['listenProvider_']=_0xe2af9a,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x27b404,_0x5e4b86,_0x333300,_0x585e26,_0x2b19b9){return lu(_0x27b404['pendingWriteTree_'],_0x5e4b86,_0x333300,_0x585e26,_0x2b19b9),_0x2b19b9?_t(_0x27b404,new Be(es(),_0x5e4b86,_0x333300)):[];}function ju(_0x124efc,_0x3ee89f,_0x58b51b,_0xe01e2a){hu(_0x124efc['pendingWriteTree_'],_0x3ee89f,_0x58b51b,_0xe01e2a);const _0x2b01b4=b['fromObject'](_0x58b51b);return _t(_0x124efc,new ot(es(),_0x3ee89f,_0x2b01b4));}function _e(_0x3e7807,_0xd02d9e,_0x375857=!0x1){const _0xf40c8d=uu(_0x3e7807['pendingWriteTree_'],_0xd02d9e);if(du(_0x3e7807['pendingWriteTree_'],_0xd02d9e)){let _0x1cd194=new b(null);return _0xf40c8d['snap']!=null?_0x1cd194=_0x1cd194['set'](w(),!0x0):x(_0xf40c8d['children'],_0x3b059c=>{_0x1cd194=_0x1cd194['set'](new C(_0x3b059c),!0x0);}),_t(_0x3e7807,new In(_0xf40c8d['path'],_0x1cd194,_0x375857));}else return[];}function Yt(_0x3da0b7,_0x24ca9b,_0x5949f7){return _t(_0x3da0b7,new Be(ts(),_0x24ca9b,_0x5949f7));}function Ku(_0x247e24,_0x43d941,_0x509b49){const _0x280548=b['fromObject'](_0x509b49);return _t(_0x247e24,new ot(ts(),_0x43d941,_0x280548));}function Yu(_0x3b3c94,_0x448a3f){return _t(_0x3b3c94,new Ut(ts(),_0x448a3f));}function Qu(_0x293257,_0x5daa4a,_0x152502){const _0x57238e=cs(_0x293257,_0x152502);if(_0x57238e){const _0x4f46ed=ls(_0x57238e),_0x4ddb32=_0x4f46ed['path'],_0x1691f6=_0x4f46ed['queryId'],_0x57a013=F(_0x4ddb32,_0x5daa4a),_0x144811=new Ut(ns(_0x1691f6),_0x57a013);return hs(_0x293257,_0x4ddb32,_0x144811);}else return[];}function An(_0x1f8106,_0x111bb4,_0x5d6046,_0x3a1a24,_0x40c846=!0x1){const _0x526916=_0x111bb4['_path'],_0x581cd5=_0x1f8106['syncPointTree_']['get'](_0x526916);let _0x5c2ea4=[];if(_0x581cd5&&(_0x111bb4['_queryIdentifier']==='default'||Qo(_0x581cd5,_0x111bb4))){const _0x351729=$u(_0x581cd5,_0x111bb4,_0x5d6046,_0x3a1a24);Vu(_0x581cd5)&&(_0x1f8106['syncPointTree_']=_0x1f8106['syncPointTree_']['remove'](_0x526916));const _0x63a75b=_0x351729['removed'];if(_0x5c2ea4=_0x351729['events'],!_0x40c846){const _0xe5ce48=_0x63a75b['findIndex'](_0x5dda73=>_0x5dda73['_queryParams']['loadsAllData']())!==-0x1,_0x5af77c=_0x1f8106['syncPointTree_']['findOnPath'](_0x526916,(_0x3caf26,_0x859c59)=>Se(_0x859c59));if(_0xe5ce48&&!_0x5af77c){const _0x573220=_0x1f8106['syncPointTree_']['subtree'](_0x526916);if(!_0x573220['isEmpty']()){const _0x3d024c=Zu(_0x573220);for(let _0xbab2cf=0x0;_0xbab2cf<_0x3d024c['length'];++_0xbab2cf){const _0x63f492=_0x3d024c[_0xbab2cf],_0x2d0d9e=_0x63f492['query'],_0x378949=ea(_0x1f8106,_0x63f492);_0x1f8106['listenProvider_']['startListening'](kt(_0x2d0d9e),Wt(_0x1f8106,_0x2d0d9e),_0x378949['hashFn'],_0x378949['onComplete']);}}}!_0x5af77c&&_0x63a75b['length']>0x0&&!_0x3a1a24&&(_0xe5ce48?_0x1f8106['listenProvider_']['stopListening'](kt(_0x111bb4),null):_0x63a75b['forEach'](_0x49fa3a=>{const _0x469293=_0x1f8106['queryToTagMap']['get'](Hn(_0x49fa3a));_0x1f8106['listenProvider_']['stopListening'](kt(_0x49fa3a),_0x469293);}));}ed(_0x1f8106,_0x63a75b);}return _0x5c2ea4;}function Jo(_0x1f972e,_0x470d3d,_0x51b099,_0x431436){const _0x243846=cs(_0x1f972e,_0x431436);if(_0x243846!=null){const _0x4cb73b=ls(_0x243846),_0x5555ae=_0x4cb73b['path'],_0x4427f8=_0x4cb73b['queryId'],_0x803a3b=F(_0x5555ae,_0x470d3d),_0x17a334=new Be(ns(_0x4427f8),_0x803a3b,_0x51b099);return hs(_0x1f972e,_0x5555ae,_0x17a334);}else return[];}function Ju(_0x3ed28c,_0x9e51c6,_0x259c7b,_0x33a168){const _0x3e6972=cs(_0x3ed28c,_0x33a168);if(_0x3e6972){const _0x4a3753=ls(_0x3e6972),_0x59f409=_0x4a3753['path'],_0x35c626=_0x4a3753['queryId'],_0x2eaeac=F(_0x59f409,_0x9e51c6),_0x3152ba=b['fromObject'](_0x259c7b),_0x5118f5=new ot(ns(_0x35c626),_0x2eaeac,_0x3152ba);return hs(_0x3ed28c,_0x59f409,_0x5118f5);}else return[];}function Ni(_0x4e8c39,_0x51e7e8,_0x1d1776,_0x4c8efb=!0x1){const _0xde695e=_0x51e7e8['_path'];let _0x1efb54=null,_0x22bd9e=!0x1;_0x4e8c39['syncPointTree_']['foreachOnPath'](_0xde695e,(_0x459696,_0x19b885)=>{const _0x555e44=F(_0x459696,_0xde695e);_0x1efb54=_0x1efb54||Ie(_0x19b885,_0x555e44),_0x22bd9e=_0x22bd9e||Se(_0x19b885);});let _0x3bcb67=_0x4e8c39['syncPointTree_']['get'](_0xde695e);_0x3bcb67?(_0x22bd9e=_0x22bd9e||Se(_0x3bcb67),_0x1efb54=_0x1efb54||Ie(_0x3bcb67,w())):(_0x3bcb67=new zo(),_0x4e8c39['syncPointTree_']=_0x4e8c39['syncPointTree_']['set'](_0xde695e,_0x3bcb67));let _0x347215;_0x1efb54!=null?_0x347215=!0x0:(_0x347215=!0x1,_0x1efb54=g['EMPTY_NODE'],_0x4e8c39['syncPointTree_']['subtree'](_0xde695e)['foreachChild']((_0x232cee,_0x29e5b2)=>{const _0x1e36fe=Ie(_0x29e5b2,w());_0x1e36fe&&(_0x1efb54=_0x1efb54['updateImmediateChild'](_0x232cee,_0x1e36fe));}));const _0x4f15ad=Qo(_0x3bcb67,_0x51e7e8);if(!_0x4f15ad&&!_0x51e7e8['_queryParams']['loadsAllData']()){const _0x3a5219=Hn(_0x51e7e8);f(!_0x4e8c39['queryToTagMap']['has'](_0x3a5219),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x20345b=td();_0x4e8c39['queryToTagMap']['set'](_0x3a5219,_0x20345b),_0x4e8c39['tagToQueryMap']['set'](_0x20345b,_0x3a5219);}const _0x41f86a=Wn(_0x4e8c39['pendingWriteTree_'],_0xde695e);let _0x2f506b=Hu(_0x3bcb67,_0x51e7e8,_0x1d1776,_0x41f86a,_0x1efb54,_0x347215);if(!_0x4f15ad&&!_0x22bd9e&&!_0x4c8efb){const _0x4c5a88=Yo(_0x3bcb67,_0x51e7e8);_0x2f506b=_0x2f506b['concat'](nd(_0x4e8c39,_0x51e7e8,_0x4c5a88));}return _0x2f506b;}function Vn(_0x4dbb8e,_0x485c31,_0x1de45d){const _0x141a04=_0x4dbb8e['pendingWriteTree_'],_0xf6bef8=_0x4dbb8e['syncPointTree_']['findOnPath'](_0x485c31,(_0x3e7d3d,_0x23287f)=>{const _0x1982c1=F(_0x3e7d3d,_0x485c31),_0x21da11=Ie(_0x23287f,_0x1982c1);if(_0x21da11)return _0x21da11;});return Bo(_0x141a04,_0x485c31,_0xf6bef8,_0x1de45d,!0x0);}function Xu(_0x2d105b,_0x271c4b){const _0x443c9d=_0x271c4b['_path'];let _0x2985d3=null;_0x2d105b['syncPointTree_']['foreachOnPath'](_0x443c9d,(_0x6b604b,_0x408dfa)=>{const _0x58ba5b=F(_0x6b604b,_0x443c9d);_0x2985d3=_0x2985d3||Ie(_0x408dfa,_0x58ba5b);});let _0x5c112c=_0x2d105b['syncPointTree_']['get'](_0x443c9d);_0x5c112c?_0x2985d3=_0x2985d3||Ie(_0x5c112c,w()):(_0x5c112c=new zo(),_0x2d105b['syncPointTree_']=_0x2d105b['syncPointTree_']['set'](_0x443c9d,_0x5c112c));const _0x2ac659=_0x2985d3!=null,_0x523cc1=_0x2ac659?new Te(_0x2985d3,!0x0,!0x1):null,_0x1e9f58=Wn(_0x2d105b['pendingWriteTree_'],_0x271c4b['_path']),_0x47935e=jo(_0x5c112c,_0x271c4b,_0x1e9f58,_0x2ac659?_0x523cc1['getNode']():g['EMPTY_NODE'],_0x2ac659);return Lu(_0x47935e);}function _t(_0x523ef2,_0xb6118c){return Xo(_0xb6118c,_0x523ef2['syncPointTree_'],null,Wn(_0x523ef2['pendingWriteTree_'],w()));}function Xo(_0x391c98,_0x227626,_0xa42c24,_0x2bcaa7){if(v(_0x391c98['path']))return Zo(_0x391c98,_0x227626,_0xa42c24,_0x2bcaa7);{const _0x3f8762=_0x227626['get'](w());_0xa42c24==null&&_0x3f8762!=null&&(_0xa42c24=Ie(_0x3f8762,w()));let _0x514c11=[];const _0x4aefde=y(_0x391c98['path']),_0x38164f=_0x391c98['operationForChild'](_0x4aefde),_0x4e8d51=_0x227626['children']['get'](_0x4aefde);if(_0x4e8d51&&_0x38164f){const _0x43db7a=_0xa42c24?_0xa42c24['getImmediateChild'](_0x4aefde):null,_0x29d549=Vo(_0x2bcaa7,_0x4aefde);_0x514c11=_0x514c11['concat'](Xo(_0x38164f,_0x4e8d51,_0x43db7a,_0x29d549));}return _0x3f8762&&(_0x514c11=_0x514c11['concat'](os(_0x3f8762,_0x391c98,_0x2bcaa7,_0xa42c24))),_0x514c11;}}function Zo(_0x30b69d,_0x49fcd0,_0x14b298,_0x4c999d){const _0xff7e0a=_0x49fcd0['get'](w());_0x14b298==null&&_0xff7e0a!=null&&(_0x14b298=Ie(_0xff7e0a,w()));let _0x264382=[];return _0x49fcd0['children']['inorderTraversal']((_0x4d3ba7,_0x516eed)=>{const _0x1a6066=_0x14b298?_0x14b298['getImmediateChild'](_0x4d3ba7):null,_0x2308a3=Vo(_0x4c999d,_0x4d3ba7),_0x2f2401=_0x30b69d['operationForChild'](_0x4d3ba7);_0x2f2401&&(_0x264382=_0x264382['concat'](Zo(_0x2f2401,_0x516eed,_0x1a6066,_0x2308a3)));}),_0xff7e0a&&(_0x264382=_0x264382['concat'](os(_0xff7e0a,_0x30b69d,_0x4c999d,_0x14b298))),_0x264382;}function ea(_0x179e5c,_0x191578){const _0x14fc6d=_0x191578['query'],_0x5ba4db=Wt(_0x179e5c,_0x14fc6d);return{'hashFn':()=>(Mu(_0x191578)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x300138=>{if(_0x300138==='ok')return _0x5ba4db?Qu(_0x179e5c,_0x14fc6d['_path'],_0x5ba4db):Yu(_0x179e5c,_0x14fc6d['_path']);{const _0x28f8ae=Kl(_0x300138,_0x14fc6d);return An(_0x179e5c,_0x14fc6d,null,_0x28f8ae);}}};}function Wt(_0x1af285,_0x15cc63){const _0xbf4ad6=Hn(_0x15cc63);return _0x1af285['queryToTagMap']['get'](_0xbf4ad6);}function Hn(_0x2ddef2){return _0x2ddef2['_path']['toString']()+'$'+_0x2ddef2['_queryIdentifier'];}function cs(_0x471035,_0x3be756){return _0x471035['tagToQueryMap']['get'](_0x3be756);}function ls(_0x506d92){const _0x352d4a=_0x506d92['indexOf']('$');return f(_0x352d4a!==-0x1&&_0x352d4a<_0x506d92['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x506d92['substr'](_0x352d4a+0x1),'path':new C(_0x506d92['substr'](0x0,_0x352d4a))};}function hs(_0x1e7fb4,_0x22840f,_0x4d4983){const _0x152deb=_0x1e7fb4['syncPointTree_']['get'](_0x22840f);f(_0x152deb,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x5874df=Wn(_0x1e7fb4['pendingWriteTree_'],_0x22840f);return os(_0x152deb,_0x4d4983,_0x5874df,null);}function Zu(_0x304da4){return _0x304da4['fold']((_0x574b4f,_0x500ed2,_0xd98b52)=>{if(_0x500ed2&&Se(_0x500ed2))return[Bn(_0x500ed2)];{let _0x38ea51=[];return _0x500ed2&&(_0x38ea51=Ko(_0x500ed2)),x(_0xd98b52,(_0x4dcd83,_0x3c44bb)=>{_0x38ea51=_0x38ea51['concat'](_0x3c44bb);}),_0x38ea51;}});}function kt(_0x1f4814){return _0x1f4814['_queryParams']['loadsAllData']()&&!_0x1f4814['_queryParams']['isDefault']()?new(qu())(_0x1f4814['_repo'],_0x1f4814['_path']):_0x1f4814;}function ed(_0x18614e,_0x296db9){for(let _0x497d8f=0x0;_0x497d8f<_0x296db9['length'];++_0x497d8f){const _0x2912a8=_0x296db9[_0x497d8f];if(!_0x2912a8['_queryParams']['loadsAllData']()){const _0x529f78=Hn(_0x2912a8),_0x179564=_0x18614e['queryToTagMap']['get'](_0x529f78);_0x18614e['queryToTagMap']['delete'](_0x529f78),_0x18614e['tagToQueryMap']['delete'](_0x179564);}}}function td(){return zu++;}function nd(_0xc441d2,_0x3f3542,_0x354599){const _0x2d72df=_0x3f3542['_path'],_0x132097=Wt(_0xc441d2,_0x3f3542),_0x35addc=ea(_0xc441d2,_0x354599),_0x4a9bb9=_0xc441d2['listenProvider_']['startListening'](kt(_0x3f3542),_0x132097,_0x35addc['hashFn'],_0x35addc['onComplete']),_0xdda8ab=_0xc441d2['syncPointTree_']['subtree'](_0x2d72df);if(_0x132097)f(!Se(_0xdda8ab['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x52dea6=_0xdda8ab['fold']((_0x3e8e30,_0x6d472e,_0x2f0073)=>{if(!v(_0x3e8e30)&&_0x6d472e&&Se(_0x6d472e))return[Bn(_0x6d472e)['query']];{let _0x9b02d8=[];return _0x6d472e&&(_0x9b02d8=_0x9b02d8['concat'](Ko(_0x6d472e)['map'](_0x240a09=>_0x240a09['query']))),x(_0x2f0073,(_0x381430,_0x506468)=>{_0x9b02d8=_0x9b02d8['concat'](_0x506468);}),_0x9b02d8;}});for(let _0x8e9ed2=0x0;_0x8e9ed2<_0x52dea6['length'];++_0x8e9ed2){const _0x4f5243=_0x52dea6[_0x8e9ed2];_0xc441d2['listenProvider_']['stopListening'](kt(_0x4f5243),Wt(_0xc441d2,_0x4f5243));}}return _0x4a9bb9;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x498935){this['node_']=_0x498935;}['getImmediateChild'](_0x102a8b){const _0x16e8de=this['node_']['getImmediateChild'](_0x102a8b);return new us(_0x16e8de);}['node'](){return this['node_'];}}class ds{constructor(_0x442c05,_0x5e2d74){this['syncTree_']=_0x442c05,this['path_']=_0x5e2d74;}['getImmediateChild'](_0x505b99){const _0x36cbfb=k(this['path_'],_0x505b99);return new ds(this['syncTree_'],_0x36cbfb);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x526499){return _0x526499=_0x526499||{},_0x526499['timestamp']=_0x526499['timestamp']||new Date()['getTime'](),_0x526499;},_r=function(_0x11ee30,_0x353a9f,_0x127aa8){if(!_0x11ee30||typeof _0x11ee30!='object')return _0x11ee30;if(f('.sv'in _0x11ee30,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x11ee30['.sv']=='string')return sd(_0x11ee30['.sv'],_0x353a9f,_0x127aa8);if(typeof _0x11ee30['.sv']=='object')return rd(_0x11ee30['.sv'],_0x353a9f);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x11ee30,null,0x2));},sd=function(_0x1110ec,_0x575608,_0x7f454){switch(_0x1110ec){case'timestamp':return _0x7f454['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x1110ec);}},rd=function(_0x1b6349,_0x7cca60,_0x28886d){_0x1b6349['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x1b6349,null,0x2));const _0x2d2ba0=_0x1b6349['increment'];typeof _0x2d2ba0!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x2d2ba0);const _0x4b3860=_0x7cca60['node']();if(f(_0x4b3860!==null&&typeof _0x4b3860<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x4b3860['isLeafNode']())return _0x2d2ba0;const _0x36e483=_0x4b3860['getValue']();return typeof _0x36e483!='number'?_0x2d2ba0:_0x36e483+_0x2d2ba0;},ta=function(_0x4c94dc,_0x36d8b1,_0x3ef4ce,_0x2229d3){return ps(_0x36d8b1,new ds(_0x3ef4ce,_0x4c94dc),_0x2229d3);},fs=function(_0x11ee9a,_0x416f96,_0x105aee){return ps(_0x11ee9a,new us(_0x416f96),_0x105aee);};function ps(_0x393cac,_0x47977f,_0x5f11e5){const _0x1fd59b=_0x393cac['getPriority']()['val'](),_0x44c9df=_r(_0x1fd59b,_0x47977f['getImmediateChild']('.priority'),_0x5f11e5);let _0x54e8af;if(_0x393cac['isLeafNode']()){const _0x3ed6eb=_0x393cac,_0x34c4ca=_r(_0x3ed6eb['getValue'](),_0x47977f,_0x5f11e5);return _0x34c4ca!==_0x3ed6eb['getValue']()||_0x44c9df!==_0x3ed6eb['getPriority']()['val']()?new D(_0x34c4ca,A(_0x44c9df)):_0x393cac;}else{const _0xedb170=_0x393cac;return _0x54e8af=_0xedb170,_0x44c9df!==_0xedb170['getPriority']()['val']()&&(_0x54e8af=_0x54e8af['updatePriority'](new D(_0x44c9df))),_0xedb170['forEachChild'](R,(_0x5a1712,_0x4368a8)=>{const _0x312900=ps(_0x4368a8,_0x47977f['getImmediateChild'](_0x5a1712),_0x5f11e5);_0x312900!==_0x4368a8&&(_0x54e8af=_0x54e8af['updateImmediateChild'](_0x5a1712,_0x312900));}),_0x54e8af;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x581c83='',_0x5c9e62=null,_0x38568a={'children':{},'childCount':0x0}){this['name']=_0x581c83,this['parent']=_0x5c9e62,this['node']=_0x38568a;}}function $n(_0x202087,_0x5b6af8){let _0xf41bc9=_0x5b6af8 instanceof C?_0x5b6af8:new C(_0x5b6af8),_0x325f91=_0x202087,_0x30ccf2=y(_0xf41bc9);for(;_0x30ccf2!==null;){const _0x13463c=Le(_0x325f91['node']['children'],_0x30ccf2)||{'children':{},'childCount':0x0};_0x325f91=new _s(_0x30ccf2,_0x325f91,_0x13463c),_0xf41bc9=S(_0xf41bc9),_0x30ccf2=y(_0xf41bc9);}return _0x325f91;}function je(_0xf87a3a){return _0xf87a3a['node']['value'];}function gs(_0x931f9a,_0x331733){_0x931f9a['node']['value']=_0x331733,Oi(_0x931f9a);}function na(_0x533a5b){return _0x533a5b['node']['childCount']>0x0;}function od(_0x4eb935){return je(_0x4eb935)===void 0x0&&!na(_0x4eb935);}function Gn(_0x1b07c6,_0x488ea5){x(_0x1b07c6['node']['children'],(_0x479c1c,_0x241182)=>{_0x488ea5(new _s(_0x479c1c,_0x1b07c6,_0x241182));});}function ia(_0x27fe01,_0x5dac9d,_0x4ec81c,_0x1e555a){_0x4ec81c&&_0x5dac9d(_0x27fe01),Gn(_0x27fe01,_0x38b483=>{ia(_0x38b483,_0x5dac9d,!0x0);});}function ad(_0x71380d,_0x284aa5,_0x5ad43e){let _0x45430c=_0x71380d['parent'];for(;_0x45430c!==null;){if(_0x284aa5(_0x45430c))return!0x0;_0x45430c=_0x45430c['parent'];}return!0x1;}function Qt(_0x9e03fb){return new C(_0x9e03fb['parent']===null?_0x9e03fb['name']:Qt(_0x9e03fb['parent'])+'/'+_0x9e03fb['name']);}function Oi(_0xa174f0){_0xa174f0['parent']!==null&&cd(_0xa174f0['parent'],_0xa174f0['name'],_0xa174f0);}function cd(_0x42a1b7,_0x3c5bff,_0x2657e5){const _0x1982da=od(_0x2657e5),_0x49b7ff=Q(_0x42a1b7['node']['children'],_0x3c5bff);_0x1982da&&_0x49b7ff?(delete _0x42a1b7['node']['children'][_0x3c5bff],_0x42a1b7['node']['childCount']--,Oi(_0x42a1b7)):!_0x1982da&&!_0x49b7ff&&(_0x42a1b7['node']['children'][_0x3c5bff]=_0x2657e5['node'],_0x42a1b7['node']['childCount']++,Oi(_0x42a1b7));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x341af4){return typeof _0x341af4=='string'&&_0x341af4['length']!==0x0&&!ld['test'](_0x341af4);},sa=function(_0xe7c83c){return typeof _0xe7c83c=='string'&&_0xe7c83c['length']!==0x0&&!hd['test'](_0xe7c83c);},ud=function(_0x361bd6){return _0x361bd6&&(_0x361bd6=_0x361bd6['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x361bd6);},Bt=function(_0x195e0c){return _0x195e0c===null||typeof _0x195e0c=='string'||typeof _0x195e0c=='number'&&!xn(_0x195e0c)||_0x195e0c&&typeof _0x195e0c=='object'&&Q(_0x195e0c,'.sv');},He=function(_0x23deed,_0x194e51,_0x1884f6,_0x3b06f3){_0x3b06f3&&_0x194e51===void 0x0||Jt(it(_0x23deed,'value'),_0x194e51,_0x1884f6);},Jt=function(_0x474e2a,_0x2ed93e,_0x4a5bcc){const _0x110c88=_0x4a5bcc instanceof C?new Ah(_0x4a5bcc,_0x474e2a):_0x4a5bcc;if(_0x2ed93e===void 0x0)throw new Error(_0x474e2a+'contains\x20undefined\x20'+Oe(_0x110c88));if(typeof _0x2ed93e=='function')throw new Error(_0x474e2a+'contains\x20a\x20function\x20'+Oe(_0x110c88)+'\x20with\x20contents\x20=\x20'+_0x2ed93e['toString']());if(xn(_0x2ed93e))throw new Error(_0x474e2a+'contains\x20'+_0x2ed93e['toString']()+'\x20'+Oe(_0x110c88));if(typeof _0x2ed93e=='string'&&_0x2ed93e['length']>ui/0x3&&Ln(_0x2ed93e)>ui)throw new Error(_0x474e2a+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x110c88)+'\x20(\x27'+_0x2ed93e['substring'](0x0,0x32)+'...\x27)');if(_0x2ed93e&&typeof _0x2ed93e=='object'){let _0x127439=!0x1,_0xf8de2=!0x1;if(x(_0x2ed93e,(_0x369480,_0x5b393c)=>{if(_0x369480==='.value')_0x127439=!0x0;else{if(_0x369480!=='.priority'&&_0x369480!=='.sv'&&(_0xf8de2=!0x0,!ms(_0x369480)))throw new Error(_0x474e2a+'\x20contains\x20an\x20invalid\x20key\x20('+_0x369480+')\x20'+Oe(_0x110c88)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x110c88,_0x369480),Jt(_0x474e2a,_0x5b393c,_0x110c88),Ph(_0x110c88);}),_0x127439&&_0xf8de2)throw new Error(_0x474e2a+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x110c88)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x2d86e6,_0x161899){let _0xb34be9,_0x38eaa8;for(_0xb34be9=0x0;_0xb34be9<_0x161899['length'];_0xb34be9++){_0x38eaa8=_0x161899[_0xb34be9];const _0x34b2d6=Mt(_0x38eaa8);for(let _0x5f3a10=0x0;_0x5f3a10<_0x34b2d6['length'];_0x5f3a10++)if(!(_0x34b2d6[_0x5f3a10]==='.priority'&&_0x5f3a10===_0x34b2d6['length']-0x1)){if(!ms(_0x34b2d6[_0x5f3a10]))throw new Error(_0x2d86e6+'contains\x20an\x20invalid\x20key\x20('+_0x34b2d6[_0x5f3a10]+')\x20in\x20path\x20'+_0x38eaa8['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x161899['sort'](Rh);let _0x5062bd=null;for(_0xb34be9=0x0;_0xb34be9<_0x161899['length'];_0xb34be9++){if(_0x38eaa8=_0x161899[_0xb34be9],_0x5062bd!==null&&G(_0x5062bd,_0x38eaa8))throw new Error(_0x2d86e6+'contains\x20a\x20path\x20'+_0x5062bd['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x38eaa8['toString']());_0x5062bd=_0x38eaa8;}},ra=function(_0x4c24e5,_0x2b5f46,_0x5eab66,_0x50c1de){const _0x30f7c1=it(_0x4c24e5,'values');if(!(_0x2b5f46&&typeof _0x2b5f46=='object')||Array['isArray'](_0x2b5f46))throw new Error(_0x30f7c1+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x405d66=[];x(_0x2b5f46,(_0x70a328,_0x1119bc)=>{const _0x1e652d=new C(_0x70a328);if(Jt(_0x30f7c1,_0x1119bc,k(_0x5eab66,_0x1e652d)),ji(_0x1e652d)==='.priority'&&!Bt(_0x1119bc))throw new Error(_0x30f7c1+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x1e652d['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x405d66['push'](_0x1e652d);}),dd(_0x30f7c1,_0x405d66);},fd=function(_0x32eeec,_0x566715,_0x43f8d7){if(xn(_0x566715))throw new Error(it(_0x32eeec,'priority')+'is\x20'+_0x566715['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x566715))throw new Error(it(_0x32eeec,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x18fd8b,_0x4890ec,_0x509002,_0x326a61){if(!sa(_0x509002))throw new Error(it(_0x18fd8b,_0x4890ec)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x509002+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x1bb4bb,_0x55caef,_0x27e399,_0x2c4d9b){_0x27e399&&(_0x27e399=_0x27e399['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x1bb4bb,_0x55caef,_0x27e399);},Me=function(_0x466862,_0xc72afd){if(y(_0xc72afd)==='.info')throw new Error(_0x466862+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x5974d8,_0x184352){const _0x4885b1=_0x184352['path']['toString']();if(typeof _0x184352['repoInfo']['host']!='string'||_0x184352['repoInfo']['host']['length']===0x0||!ms(_0x184352['repoInfo']['namespace'])&&_0x184352['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x4885b1['length']!==0x0&&!ud(_0x4885b1))throw new Error(it(_0x5974d8,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x2fb88d,_0x5f346c){let _0x3374d2=null;for(let _0x5e6ca1=0x0;_0x5e6ca1<_0x5f346c['length'];_0x5e6ca1++){const _0x1f51d3=_0x5f346c[_0x5e6ca1],_0xa9a5fc=_0x1f51d3['getPath']();_0x3374d2!==null&&!Ki(_0xa9a5fc,_0x3374d2['path'])&&(_0x2fb88d['eventLists_']['push'](_0x3374d2),_0x3374d2=null),_0x3374d2===null&&(_0x3374d2={'events':[],'path':_0xa9a5fc}),_0x3374d2['events']['push'](_0x1f51d3);}_0x3374d2&&_0x2fb88d['eventLists_']['push'](_0x3374d2);}function oa(_0x3b21d5,_0x441b5c,_0x50affb){qn(_0x3b21d5,_0x50affb),aa(_0x3b21d5,_0x1ca949=>Ki(_0x1ca949,_0x441b5c));}function V(_0xf2b4d7,_0xd09b6d,_0x18463f){qn(_0xf2b4d7,_0x18463f),aa(_0xf2b4d7,_0x39ddc8=>G(_0x39ddc8,_0xd09b6d)||G(_0xd09b6d,_0x39ddc8));}function aa(_0x34093f,_0x25d8c3){_0x34093f['recursionDepth_']++;let _0x10bef5=!0x0;for(let _0x272708=0x0;_0x272708<_0x34093f['eventLists_']['length'];_0x272708++){const _0x37ba88=_0x34093f['eventLists_'][_0x272708];if(_0x37ba88){const _0x2a72d8=_0x37ba88['path'];_0x25d8c3(_0x2a72d8)?(md(_0x34093f['eventLists_'][_0x272708]),_0x34093f['eventLists_'][_0x272708]=null):_0x10bef5=!0x1;}}_0x10bef5&&(_0x34093f['eventLists_']=[]),_0x34093f['recursionDepth_']--;}function md(_0x3f4b96){for(let _0x2fb0b2=0x0;_0x2fb0b2<_0x3f4b96['events']['length'];_0x2fb0b2++){const _0xfd586a=_0x3f4b96['events'][_0x2fb0b2];if(_0xfd586a!==null){_0x3f4b96['events'][_0x2fb0b2]=null;const _0x29b41c=_0xfd586a['getEventRunner']();St&&L('event:\x20'+_0xfd586a['toString']()),ft(_0x29b41c);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x166262,_0x1ecd86,_0x7be227,_0x10e10b){this['repoInfo_']=_0x166262,this['forceRestClient_']=_0x1ecd86,this['authTokenProvider_']=_0x7be227,this['appCheckProvider_']=_0x10e10b,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x367828,_0x1b1658,_0x1533a7){if(_0x367828['stats_']=qi(_0x367828['repoInfo_']),_0x367828['forceRestClient_']||Xl())_0x367828['server_']=new vn(_0x367828['repoInfo_'],(_0x1b9db1,_0x3b49cd,_0x48f986,_0x4d9f0c)=>{gr(_0x367828,_0x1b9db1,_0x3b49cd,_0x48f986,_0x4d9f0c);},_0x367828['authTokenProvider_'],_0x367828['appCheckProvider_']),setTimeout(()=>mr(_0x367828,!0x0),0x0);else{if(typeof _0x1533a7<'u'&&_0x1533a7!==null){if(typeof _0x1533a7!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x1533a7);}catch(_0x4890c8){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x4890c8);}}_0x367828['persistentConnection_']=new se(_0x367828['repoInfo_'],_0x1b1658,(_0x552a40,_0x119f51,_0x530790,_0x51ac3b)=>{gr(_0x367828,_0x552a40,_0x119f51,_0x530790,_0x51ac3b);},_0x4bbadd=>{mr(_0x367828,_0x4bbadd);},_0x269755=>{Id(_0x367828,_0x269755);},_0x367828['authTokenProvider_'],_0x367828['appCheckProvider_'],_0x1533a7),_0x367828['server_']=_0x367828['persistentConnection_'];}_0x367828['authTokenProvider_']['addTokenChangeListener'](_0x33ae09=>{_0x367828['server_']['refreshAuthToken'](_0x33ae09);}),_0x367828['appCheckProvider_']['addTokenChangeListener'](_0x4027c4=>{_0x367828['server_']['refreshAppCheckToken'](_0x4027c4['token']);}),_0x367828['statsReporter_']=ih(_0x367828['repoInfo_'],()=>new iu(_0x367828['stats_'],_0x367828['server_'])),_0x367828['infoData_']=new Xh(),_0x367828['infoSyncTree_']=new pr({'startListening':(_0x4490f4,_0x32a1c7,_0x4f1f51,_0x4cd059)=>{let _0x59acc3=[];const _0xc5de35=_0x367828['infoData_']['getNode'](_0x4490f4['_path']);return _0xc5de35['isEmpty']()||(_0x59acc3=Yt(_0x367828['infoSyncTree_'],_0x4490f4['_path'],_0xc5de35),setTimeout(()=>{_0x4cd059('ok');},0x0)),_0x59acc3;},'stopListening':()=>{}}),vs(_0x367828,'connected',!0x1),_0x367828['serverSyncTree_']=new pr({'startListening':(_0x38f19a,_0x526d7e,_0x570fa6,_0x532a4c)=>(_0x367828['server_']['listen'](_0x38f19a,_0x570fa6,_0x526d7e,(_0x4617ed,_0xb0695a)=>{const _0x42d7d9=_0x532a4c(_0x4617ed,_0xb0695a);V(_0x367828['eventQueue_'],_0x38f19a['_path'],_0x42d7d9);}),[]),'stopListening':(_0x122123,_0x5ca13c)=>{_0x367828['server_']['unlisten'](_0x122123,_0x5ca13c);}});}function la(_0x573c7a){const _0x1b2e7f=_0x573c7a['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x1b2e7f;}function Xt(_0x1aab6e){return id({'timestamp':la(_0x1aab6e)});}function gr(_0x10391e,_0x25f27b,_0x2be6c9,_0x4c8e68,_0x404ad1){_0x10391e['dataUpdateCount']++;const _0x31b04f=new C(_0x25f27b);_0x2be6c9=_0x10391e['interceptServerDataCallback_']?_0x10391e['interceptServerDataCallback_'](_0x25f27b,_0x2be6c9):_0x2be6c9;let _0x1b2feb=[];if(_0x404ad1){if(_0x4c8e68){const _0x4e7610=_n(_0x2be6c9,_0x3283ca=>A(_0x3283ca));_0x1b2feb=Ju(_0x10391e['serverSyncTree_'],_0x31b04f,_0x4e7610,_0x404ad1);}else{const _0x2da2bd=A(_0x2be6c9);_0x1b2feb=Jo(_0x10391e['serverSyncTree_'],_0x31b04f,_0x2da2bd,_0x404ad1);}}else{if(_0x4c8e68){const _0x5c4683=_n(_0x2be6c9,_0x4abdef=>A(_0x4abdef));_0x1b2feb=Ku(_0x10391e['serverSyncTree_'],_0x31b04f,_0x5c4683);}else{const _0x41b233=A(_0x2be6c9);_0x1b2feb=Yt(_0x10391e['serverSyncTree_'],_0x31b04f,_0x41b233);}}let _0x49b712=_0x31b04f;_0x1b2feb['length']>0x0&&(_0x49b712=ct(_0x10391e,_0x31b04f)),V(_0x10391e['eventQueue_'],_0x49b712,_0x1b2feb);}function mr(_0x12b4a0,_0x22ca7f){vs(_0x12b4a0,'connected',_0x22ca7f),_0x22ca7f===!0x1&&Sd(_0x12b4a0);}function Id(_0x5e7929,_0x5bdf5e){x(_0x5bdf5e,(_0x215bf5,_0x25b510)=>{vs(_0x5e7929,_0x215bf5,_0x25b510);});}function vs(_0x389c62,_0x94b897,_0x504253){const _0x17de1d=new C('/.info/'+_0x94b897),_0x18f11a=A(_0x504253);_0x389c62['infoData_']['updateSnapshot'](_0x17de1d,_0x18f11a);const _0x4c02ab=Yt(_0x389c62['infoSyncTree_'],_0x17de1d,_0x18f11a);V(_0x389c62['eventQueue_'],_0x17de1d,_0x4c02ab);}function zn(_0x1d1de2){return _0x1d1de2['nextWriteId_']++;}function wd(_0x4e2c85,_0x9c8dd9,_0x4c53e4){const _0x5ad8e2=Xu(_0x4e2c85['serverSyncTree_'],_0x9c8dd9);return _0x5ad8e2!=null?Promise['resolve'](_0x5ad8e2):_0x4e2c85['server_']['get'](_0x9c8dd9)['then'](_0x8ea5f2=>{const _0x16e4d3=A(_0x8ea5f2)['withIndex'](_0x9c8dd9['_queryParams']['getIndex']());Ni(_0x4e2c85['serverSyncTree_'],_0x9c8dd9,_0x4c53e4,!0x0);let _0xecaac2;if(_0x9c8dd9['_queryParams']['loadsAllData']())_0xecaac2=Yt(_0x4e2c85['serverSyncTree_'],_0x9c8dd9['_path'],_0x16e4d3);else{const _0xcebab8=Wt(_0x4e2c85['serverSyncTree_'],_0x9c8dd9);_0xecaac2=Jo(_0x4e2c85['serverSyncTree_'],_0x9c8dd9['_path'],_0x16e4d3,_0xcebab8);}return V(_0x4e2c85['eventQueue_'],_0x9c8dd9['_path'],_0xecaac2),An(_0x4e2c85['serverSyncTree_'],_0x9c8dd9,_0x4c53e4,null,!0x0),_0x16e4d3;},_0x380729=>(gt(_0x4e2c85,'get\x20for\x20query\x20'+O(_0x9c8dd9)+'\x20failed:\x20'+_0x380729),Promise['reject'](new Error(_0x380729))));}function Cd(_0x11a480,_0x39c1b1,_0x48df24,_0xca13a5,_0x4df942){gt(_0x11a480,'set',{'path':_0x39c1b1['toString'](),'value':_0x48df24,'priority':_0xca13a5});const _0xfdda02=Xt(_0x11a480),_0x41b0e1=A(_0x48df24,_0xca13a5),_0x541acc=Vn(_0x11a480['serverSyncTree_'],_0x39c1b1),_0x1dc69a=fs(_0x41b0e1,_0x541acc,_0xfdda02),_0x4d6a6c=zn(_0x11a480),_0x577f7e=as(_0x11a480['serverSyncTree_'],_0x39c1b1,_0x1dc69a,_0x4d6a6c,!0x0);qn(_0x11a480['eventQueue_'],_0x577f7e),_0x11a480['server_']['put'](_0x39c1b1['toString'](),_0x41b0e1['val'](!0x0),(_0x2adb87,_0x57078e)=>{const _0x346eb5=_0x2adb87==='ok';_0x346eb5||U('set\x20at\x20'+_0x39c1b1+'\x20failed:\x20'+_0x2adb87);const _0x4b208c=_e(_0x11a480['serverSyncTree_'],_0x4d6a6c,!_0x346eb5);V(_0x11a480['eventQueue_'],_0x39c1b1,_0x4b208c),be(_0x11a480,_0x4df942,_0x2adb87,_0x57078e);});const _0x1bbe60=Is(_0x11a480,_0x39c1b1);ct(_0x11a480,_0x1bbe60),V(_0x11a480['eventQueue_'],_0x1bbe60,[]);}function Td(_0x27aa7b,_0xe9d717,_0x14825d,_0x28f4a0){gt(_0x27aa7b,'update',{'path':_0xe9d717['toString'](),'value':_0x14825d});let _0x4374e7=!0x0;const _0x2a8a9d=Xt(_0x27aa7b),_0x47ea64={};if(x(_0x14825d,(_0x67207d,_0x36b428)=>{_0x4374e7=!0x1,_0x47ea64[_0x67207d]=ta(k(_0xe9d717,_0x67207d),A(_0x36b428),_0x27aa7b['serverSyncTree_'],_0x2a8a9d);}),_0x4374e7)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x27aa7b,_0x28f4a0,'ok',void 0x0);else{const _0x1536a7=zn(_0x27aa7b),_0xa2e453=ju(_0x27aa7b['serverSyncTree_'],_0xe9d717,_0x47ea64,_0x1536a7);qn(_0x27aa7b['eventQueue_'],_0xa2e453),_0x27aa7b['server_']['merge'](_0xe9d717['toString'](),_0x14825d,(_0x46e7bf,_0x4d09bf)=>{const _0xf9a4ab=_0x46e7bf==='ok';_0xf9a4ab||U('update\x20at\x20'+_0xe9d717+'\x20failed:\x20'+_0x46e7bf);const _0x4b384a=_e(_0x27aa7b['serverSyncTree_'],_0x1536a7,!_0xf9a4ab),_0x124cff=_0x4b384a['length']>0x0?ct(_0x27aa7b,_0xe9d717):_0xe9d717;V(_0x27aa7b['eventQueue_'],_0x124cff,_0x4b384a),be(_0x27aa7b,_0x28f4a0,_0x46e7bf,_0x4d09bf);}),x(_0x14825d,_0x3a7854=>{const _0x452d05=Is(_0x27aa7b,k(_0xe9d717,_0x3a7854));ct(_0x27aa7b,_0x452d05);}),V(_0x27aa7b['eventQueue_'],_0xe9d717,[]);}}function Sd(_0x298dff){gt(_0x298dff,'onDisconnectEvents');const _0x2efce6=Xt(_0x298dff),_0x4aa3a3=En();Si(_0x298dff['onDisconnect_'],w(),(_0x406530,_0x3e39e7)=>{const _0x200060=ta(_0x406530,_0x3e39e7,_0x298dff['serverSyncTree_'],_0x2efce6);pt(_0x4aa3a3,_0x406530,_0x200060);});let _0x3a18ba=[];Si(_0x4aa3a3,w(),(_0x47ce48,_0x55239b)=>{_0x3a18ba=_0x3a18ba['concat'](Yt(_0x298dff['serverSyncTree_'],_0x47ce48,_0x55239b));const _0x35da89=Is(_0x298dff,_0x47ce48);ct(_0x298dff,_0x35da89);}),_0x298dff['onDisconnect_']=En(),V(_0x298dff['eventQueue_'],w(),_0x3a18ba);}function bd(_0x3b7935,_0x391051,_0x48300e){_0x3b7935['server_']['onDisconnectCancel'](_0x391051['toString'](),(_0x1ef73d,_0x57d82e)=>{_0x1ef73d==='ok'&&Ti(_0x3b7935['onDisconnect_'],_0x391051),be(_0x3b7935,_0x48300e,_0x1ef73d,_0x57d82e);});}function yr(_0x48bff0,_0x48c110,_0x1bad6a,_0x156cdf){const _0x2c3a4b=A(_0x1bad6a);_0x48bff0['server_']['onDisconnectPut'](_0x48c110['toString'](),_0x2c3a4b['val'](!0x0),(_0x3dd634,_0xe7f684)=>{_0x3dd634==='ok'&&pt(_0x48bff0['onDisconnect_'],_0x48c110,_0x2c3a4b),be(_0x48bff0,_0x156cdf,_0x3dd634,_0xe7f684);});}function Rd(_0x48b2d6,_0x2f103b,_0x581ef4,_0x5b7de6,_0x9a86da){const _0x500ecd=A(_0x581ef4,_0x5b7de6);_0x48b2d6['server_']['onDisconnectPut'](_0x2f103b['toString'](),_0x500ecd['val'](!0x0),(_0x431a50,_0x12f541)=>{_0x431a50==='ok'&&pt(_0x48b2d6['onDisconnect_'],_0x2f103b,_0x500ecd),be(_0x48b2d6,_0x9a86da,_0x431a50,_0x12f541);});}function Ad(_0x123cc0,_0x56e8e6,_0x13eb13,_0x1ec1a9){if(pn(_0x13eb13)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x123cc0,_0x1ec1a9,'ok',void 0x0);return;}_0x123cc0['server_']['onDisconnectMerge'](_0x56e8e6['toString'](),_0x13eb13,(_0x23fb7c,_0x35977d)=>{_0x23fb7c==='ok'&&x(_0x13eb13,(_0x2372df,_0x4c62f5)=>{const _0x38ee35=A(_0x4c62f5);pt(_0x123cc0['onDisconnect_'],k(_0x56e8e6,_0x2372df),_0x38ee35);}),be(_0x123cc0,_0x1ec1a9,_0x23fb7c,_0x35977d);});}function kd(_0x5c008e,_0x289644,_0x4cbeba){let _0x39906e;y(_0x289644['_path'])==='.info'?_0x39906e=Ni(_0x5c008e['infoSyncTree_'],_0x289644,_0x4cbeba):_0x39906e=Ni(_0x5c008e['serverSyncTree_'],_0x289644,_0x4cbeba),oa(_0x5c008e['eventQueue_'],_0x289644['_path'],_0x39906e);}function Pd(_0x4985b2,_0x421ef8,_0x3319fb){let _0x71c1b5;y(_0x421ef8['_path'])==='.info'?_0x71c1b5=An(_0x4985b2['infoSyncTree_'],_0x421ef8,_0x3319fb):_0x71c1b5=An(_0x4985b2['serverSyncTree_'],_0x421ef8,_0x3319fb),oa(_0x4985b2['eventQueue_'],_0x421ef8['_path'],_0x71c1b5);}function ha(_0x2cebd0){_0x2cebd0['persistentConnection_']&&_0x2cebd0['persistentConnection_']['interrupt'](ca);}function Nd(_0x1d0488){_0x1d0488['persistentConnection_']&&_0x1d0488['persistentConnection_']['resume'](ca);}function gt(_0x27a469,..._0x8f1e77){let _0x2060df='';_0x27a469['persistentConnection_']&&(_0x2060df=_0x27a469['persistentConnection_']['id']+':'),L(_0x2060df,..._0x8f1e77);}function be(_0x1595c0,_0xf1c8a1,_0x57adeb,_0x3357db){_0xf1c8a1&&ft(()=>{if(_0x57adeb==='ok')_0xf1c8a1(null);else{const _0x11395b=(_0x57adeb||'error')['toUpperCase']();let _0x43a697=_0x11395b;_0x3357db&&(_0x43a697+=':\x20'+_0x3357db);const _0x52c74a=new Error(_0x43a697);_0x52c74a['code']=_0x11395b,_0xf1c8a1(_0x52c74a);}});}function Od(_0x57e0cb,_0x22781b,_0x4febdd,_0x4b80a6,_0x409f7b,_0x32231b){gt(_0x57e0cb,'transaction\x20on\x20'+_0x22781b);const _0x20516b={'path':_0x22781b,'update':_0x4febdd,'onComplete':_0x4b80a6,'status':null,'order':so(),'applyLocally':_0x32231b,'retryCount':0x0,'unwatcher':_0x409f7b,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x2adac9=Es(_0x57e0cb,_0x22781b,void 0x0);_0x20516b['currentInputSnapshot']=_0x2adac9;const _0x533744=_0x20516b['update'](_0x2adac9['val']());if(_0x533744===void 0x0)_0x20516b['unwatcher'](),_0x20516b['currentOutputSnapshotRaw']=null,_0x20516b['currentOutputSnapshotResolved']=null,_0x20516b['onComplete']&&_0x20516b['onComplete'](null,!0x1,_0x20516b['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x533744,_0x20516b['path']),_0x20516b['status']=0x0;const _0xcfb8a5=$n(_0x57e0cb['transactionQueueTree_'],_0x22781b),_0x584ffd=je(_0xcfb8a5)||[];_0x584ffd['push'](_0x20516b),gs(_0xcfb8a5,_0x584ffd);let _0x1225f9;typeof _0x533744=='object'&&_0x533744!==null&&Q(_0x533744,'.priority')?(_0x1225f9=Le(_0x533744,'.priority'),f(Bt(_0x1225f9),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x1225f9=(Vn(_0x57e0cb['serverSyncTree_'],_0x22781b)||g['EMPTY_NODE'])['getPriority']()['val']();const _0xaa952f=Xt(_0x57e0cb),_0x272be8=A(_0x533744,_0x1225f9),_0x404667=fs(_0x272be8,_0x2adac9,_0xaa952f);_0x20516b['currentOutputSnapshotRaw']=_0x272be8,_0x20516b['currentOutputSnapshotResolved']=_0x404667,_0x20516b['currentWriteId']=zn(_0x57e0cb);const _0x308249=as(_0x57e0cb['serverSyncTree_'],_0x22781b,_0x404667,_0x20516b['currentWriteId'],_0x20516b['applyLocally']);V(_0x57e0cb['eventQueue_'],_0x22781b,_0x308249),jn(_0x57e0cb,_0x57e0cb['transactionQueueTree_']);}}function Es(_0x50960f,_0x555685,_0x20fe4e){return Vn(_0x50960f['serverSyncTree_'],_0x555685,_0x20fe4e)||g['EMPTY_NODE'];}function jn(_0x1eb98a,_0x5da540=_0x1eb98a['transactionQueueTree_']){if(_0x5da540||Kn(_0x1eb98a,_0x5da540),je(_0x5da540)){const _0x373c1a=da(_0x1eb98a,_0x5da540);f(_0x373c1a['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x373c1a['every'](_0x55f61a=>_0x55f61a['status']===0x0)&&Dd(_0x1eb98a,Qt(_0x5da540),_0x373c1a);}else na(_0x5da540)&&Gn(_0x5da540,_0x188bc6=>{jn(_0x1eb98a,_0x188bc6);});}function Dd(_0x6d64b2,_0x12a736,_0x374249){const _0x31d436=_0x374249['map'](_0x415e19=>_0x415e19['currentWriteId']),_0x384e71=Es(_0x6d64b2,_0x12a736,_0x31d436);let _0x588ca5=_0x384e71;const _0x5cda1d=_0x384e71['hash']();for(let _0x5e143f=0x0;_0x5e143f<_0x374249['length'];_0x5e143f++){const _0x2f505f=_0x374249[_0x5e143f];f(_0x2f505f['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x2f505f['status']=0x1,_0x2f505f['retryCount']++;const _0x58a7df=F(_0x12a736,_0x2f505f['path']);_0x588ca5=_0x588ca5['updateChild'](_0x58a7df,_0x2f505f['currentOutputSnapshotRaw']);}const _0x1b9b87=_0x588ca5['val'](!0x0),_0x3b05b0=_0x12a736;_0x6d64b2['server_']['put'](_0x3b05b0['toString'](),_0x1b9b87,_0x3b402c=>{gt(_0x6d64b2,'transaction\x20put\x20response',{'path':_0x3b05b0['toString'](),'status':_0x3b402c});let _0x47202d=[];if(_0x3b402c==='ok'){const _0xbefc3e=[];for(let _0x4a11d2=0x0;_0x4a11d2<_0x374249['length'];_0x4a11d2++)_0x374249[_0x4a11d2]['status']=0x2,_0x47202d=_0x47202d['concat'](_e(_0x6d64b2['serverSyncTree_'],_0x374249[_0x4a11d2]['currentWriteId'])),_0x374249[_0x4a11d2]['onComplete']&&_0xbefc3e['push'](()=>_0x374249[_0x4a11d2]['onComplete'](null,!0x0,_0x374249[_0x4a11d2]['currentOutputSnapshotResolved'])),_0x374249[_0x4a11d2]['unwatcher']();Kn(_0x6d64b2,$n(_0x6d64b2['transactionQueueTree_'],_0x12a736)),jn(_0x6d64b2,_0x6d64b2['transactionQueueTree_']),V(_0x6d64b2['eventQueue_'],_0x12a736,_0x47202d);for(let _0xcb3ccb=0x0;_0xcb3ccb<_0xbefc3e['length'];_0xcb3ccb++)ft(_0xbefc3e[_0xcb3ccb]);}else{if(_0x3b402c==='datastale'){for(let _0x543151=0x0;_0x543151<_0x374249['length'];_0x543151++)_0x374249[_0x543151]['status']===0x3?_0x374249[_0x543151]['status']=0x4:_0x374249[_0x543151]['status']=0x0;}else{U('transaction\x20at\x20'+_0x3b05b0['toString']()+'\x20failed:\x20'+_0x3b402c);for(let _0x2b0e24=0x0;_0x2b0e24<_0x374249['length'];_0x2b0e24++)_0x374249[_0x2b0e24]['status']=0x4,_0x374249[_0x2b0e24]['abortReason']=_0x3b402c;}ct(_0x6d64b2,_0x12a736);}},_0x5cda1d);}function ct(_0x2fcd6a,_0x41ea63){const _0x265dc7=ua(_0x2fcd6a,_0x41ea63),_0x7cead0=Qt(_0x265dc7),_0x1d7efd=da(_0x2fcd6a,_0x265dc7);return Md(_0x2fcd6a,_0x1d7efd,_0x7cead0),_0x7cead0;}function Md(_0x499332,_0x36661f,_0x4738b1){if(_0x36661f['length']===0x0)return;const _0x29e50d=[];let _0x1b3206=[];const _0x49ca63=_0x36661f['filter'](_0x4e4517=>_0x4e4517['status']===0x0)['map'](_0x16dd67=>_0x16dd67['currentWriteId']);for(let _0x147efe=0x0;_0x147efe<_0x36661f['length'];_0x147efe++){const _0x2e04c=_0x36661f[_0x147efe],_0x4463a9=F(_0x4738b1,_0x2e04c['path']);let _0x3f204c=!0x1,_0x39a05f;if(f(_0x4463a9!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x2e04c['status']===0x4)_0x3f204c=!0x0,_0x39a05f=_0x2e04c['abortReason'],_0x1b3206=_0x1b3206['concat'](_e(_0x499332['serverSyncTree_'],_0x2e04c['currentWriteId'],!0x0));else{if(_0x2e04c['status']===0x0){if(_0x2e04c['retryCount']>=yd)_0x3f204c=!0x0,_0x39a05f='maxretry',_0x1b3206=_0x1b3206['concat'](_e(_0x499332['serverSyncTree_'],_0x2e04c['currentWriteId'],!0x0));else{const _0x40bed1=Es(_0x499332,_0x2e04c['path'],_0x49ca63);_0x2e04c['currentInputSnapshot']=_0x40bed1;const _0x170846=_0x36661f[_0x147efe]['update'](_0x40bed1['val']());if(_0x170846!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x170846,_0x2e04c['path']);let _0x1e3bd3=A(_0x170846);typeof _0x170846=='object'&&_0x170846!=null&&Q(_0x170846,'.priority')||(_0x1e3bd3=_0x1e3bd3['updatePriority'](_0x40bed1['getPriority']()));const _0x38b35a=_0x2e04c['currentWriteId'],_0x221ac8=Xt(_0x499332),_0x3a674b=fs(_0x1e3bd3,_0x40bed1,_0x221ac8);_0x2e04c['currentOutputSnapshotRaw']=_0x1e3bd3,_0x2e04c['currentOutputSnapshotResolved']=_0x3a674b,_0x2e04c['currentWriteId']=zn(_0x499332),_0x49ca63['splice'](_0x49ca63['indexOf'](_0x38b35a),0x1),_0x1b3206=_0x1b3206['concat'](as(_0x499332['serverSyncTree_'],_0x2e04c['path'],_0x3a674b,_0x2e04c['currentWriteId'],_0x2e04c['applyLocally'])),_0x1b3206=_0x1b3206['concat'](_e(_0x499332['serverSyncTree_'],_0x38b35a,!0x0));}else _0x3f204c=!0x0,_0x39a05f='nodata',_0x1b3206=_0x1b3206['concat'](_e(_0x499332['serverSyncTree_'],_0x2e04c['currentWriteId'],!0x0));}}}V(_0x499332['eventQueue_'],_0x4738b1,_0x1b3206),_0x1b3206=[],_0x3f204c&&(_0x36661f[_0x147efe]['status']=0x2,function(_0x5e4518){setTimeout(_0x5e4518,Math['floor'](0x0));}(_0x36661f[_0x147efe]['unwatcher']),_0x36661f[_0x147efe]['onComplete']&&(_0x39a05f==='nodata'?_0x29e50d['push'](()=>_0x36661f[_0x147efe]['onComplete'](null,!0x1,_0x36661f[_0x147efe]['currentInputSnapshot'])):_0x29e50d['push'](()=>_0x36661f[_0x147efe]['onComplete'](new Error(_0x39a05f),!0x1,null))));}Kn(_0x499332,_0x499332['transactionQueueTree_']);for(let _0x3ecc65=0x0;_0x3ecc65<_0x29e50d['length'];_0x3ecc65++)ft(_0x29e50d[_0x3ecc65]);jn(_0x499332,_0x499332['transactionQueueTree_']);}function ua(_0x4f7eff,_0x10d5dd){let _0x1c01a2,_0x40c7d0=_0x4f7eff['transactionQueueTree_'];for(_0x1c01a2=y(_0x10d5dd);_0x1c01a2!==null&&je(_0x40c7d0)===void 0x0;)_0x40c7d0=$n(_0x40c7d0,_0x1c01a2),_0x10d5dd=S(_0x10d5dd),_0x1c01a2=y(_0x10d5dd);return _0x40c7d0;}function da(_0x4b3a49,_0x7413e5){const _0x26e7eb=[];return fa(_0x4b3a49,_0x7413e5,_0x26e7eb),_0x26e7eb['sort']((_0x535e05,_0x35c19d)=>_0x535e05['order']-_0x35c19d['order']),_0x26e7eb;}function fa(_0x4fc4bf,_0x40e252,_0x3686ed){const _0x1cea8b=je(_0x40e252);if(_0x1cea8b){for(let _0x54addf=0x0;_0x54addf<_0x1cea8b['length'];_0x54addf++)_0x3686ed['push'](_0x1cea8b[_0x54addf]);}Gn(_0x40e252,_0x327c25=>{fa(_0x4fc4bf,_0x327c25,_0x3686ed);});}function Kn(_0x8a74cf,_0x30cef2){const _0xa77ce7=je(_0x30cef2);if(_0xa77ce7){let _0x4ca062=0x0;for(let _0x4aea7b=0x0;_0x4aea7b<_0xa77ce7['length'];_0x4aea7b++)_0xa77ce7[_0x4aea7b]['status']!==0x2&&(_0xa77ce7[_0x4ca062]=_0xa77ce7[_0x4aea7b],_0x4ca062++);_0xa77ce7['length']=_0x4ca062,gs(_0x30cef2,_0xa77ce7['length']>0x0?_0xa77ce7:void 0x0);}Gn(_0x30cef2,_0x55b529=>{Kn(_0x8a74cf,_0x55b529);});}function Is(_0x136450,_0x24a26e){const _0x1040a9=Qt(ua(_0x136450,_0x24a26e)),_0x21bc69=$n(_0x136450['transactionQueueTree_'],_0x24a26e);return ad(_0x21bc69,_0x3f3fc1=>{di(_0x136450,_0x3f3fc1);}),di(_0x136450,_0x21bc69),ia(_0x21bc69,_0xb8445c=>{di(_0x136450,_0xb8445c);}),_0x1040a9;}function di(_0x59420b,_0x1f766e){const _0x2c9e52=je(_0x1f766e);if(_0x2c9e52){const _0x21e40f=[];let _0x2e2cd0=[],_0x1f7960=-0x1;for(let _0x463e73=0x0;_0x463e73<_0x2c9e52['length'];_0x463e73++)_0x2c9e52[_0x463e73]['status']===0x3||(_0x2c9e52[_0x463e73]['status']===0x1?(f(_0x1f7960===_0x463e73-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x1f7960=_0x463e73,_0x2c9e52[_0x463e73]['status']=0x3,_0x2c9e52[_0x463e73]['abortReason']='set'):(f(_0x2c9e52[_0x463e73]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x2c9e52[_0x463e73]['unwatcher'](),_0x2e2cd0=_0x2e2cd0['concat'](_e(_0x59420b['serverSyncTree_'],_0x2c9e52[_0x463e73]['currentWriteId'],!0x0)),_0x2c9e52[_0x463e73]['onComplete']&&_0x21e40f['push'](_0x2c9e52[_0x463e73]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x1f7960===-0x1?gs(_0x1f766e,void 0x0):_0x2c9e52['length']=_0x1f7960+0x1,V(_0x59420b['eventQueue_'],Qt(_0x1f766e),_0x2e2cd0);for(let _0x3ba36c=0x0;_0x3ba36c<_0x21e40f['length'];_0x3ba36c++)ft(_0x21e40f[_0x3ba36c]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x4837c3){let _0x2d7fcc='';const _0x21f2d7=_0x4837c3['split']('/');for(let _0xfabad0=0x0;_0xfabad0<_0x21f2d7['length'];_0xfabad0++)if(_0x21f2d7[_0xfabad0]['length']>0x0){let _0x31d84d=_0x21f2d7[_0xfabad0];try{_0x31d84d=decodeURIComponent(_0x31d84d['replace'](/\+/g,'\x20'));}catch{}_0x2d7fcc+='/'+_0x31d84d;}return _0x2d7fcc;}function xd(_0xc18db9){const _0x3b9122={};_0xc18db9['charAt'](0x0)==='?'&&(_0xc18db9=_0xc18db9['substring'](0x1));for(const _0x2d3f0b of _0xc18db9['split']('&')){if(_0x2d3f0b['length']===0x0)continue;const _0x440fbf=_0x2d3f0b['split']('=');_0x440fbf['length']===0x2?_0x3b9122[decodeURIComponent(_0x440fbf[0x0])]=decodeURIComponent(_0x440fbf[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x2d3f0b+'\x27\x20in\x20query\x20\x27'+_0xc18db9+'\x27');}return _0x3b9122;}const vr=function(_0x261105,_0x444aa5){const _0x575abb=Fd(_0x261105),_0x49e6c5=_0x575abb['namespace'];_0x575abb['domain']==='firebase.com'&&ae(_0x575abb['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x49e6c5||_0x49e6c5==='undefined')&&_0x575abb['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x575abb['secure']||$l();const _0x628b47=_0x575abb['scheme']==='ws'||_0x575abb['scheme']==='wss';return{'repoInfo':new yo(_0x575abb['host'],_0x575abb['secure'],_0x49e6c5,_0x628b47,_0x444aa5,'',_0x49e6c5!==_0x575abb['subdomain']),'path':new C(_0x575abb['pathString'])};},Fd=function(_0x2bd03b){let _0x496ac7='',_0x1ff680='',_0x18158f='',_0x143e9f='',_0x497703='',_0x5c49d2=!0x0,_0x235d8b='https',_0x4f7bcc=0x1bb;if(typeof _0x2bd03b=='string'){let _0xafd763=_0x2bd03b['indexOf']('//');_0xafd763>=0x0&&(_0x235d8b=_0x2bd03b['substring'](0x0,_0xafd763-0x1),_0x2bd03b=_0x2bd03b['substring'](_0xafd763+0x2));let _0x4450fa=_0x2bd03b['indexOf']('/');_0x4450fa===-0x1&&(_0x4450fa=_0x2bd03b['length']);let _0x128cee=_0x2bd03b['indexOf']('?');_0x128cee===-0x1&&(_0x128cee=_0x2bd03b['length']),_0x496ac7=_0x2bd03b['substring'](0x0,Math['min'](_0x4450fa,_0x128cee)),_0x4450fa<_0x128cee&&(_0x143e9f=Ld(_0x2bd03b['substring'](_0x4450fa,_0x128cee)));const _0x1e37c3=xd(_0x2bd03b['substring'](Math['min'](_0x2bd03b['length'],_0x128cee)));_0xafd763=_0x496ac7['indexOf'](':'),_0xafd763>=0x0?(_0x5c49d2=_0x235d8b==='https'||_0x235d8b==='wss',_0x4f7bcc=parseInt(_0x496ac7['substring'](_0xafd763+0x1),0xa)):_0xafd763=_0x496ac7['length'];const _0x104499=_0x496ac7['slice'](0x0,_0xafd763);if(_0x104499['toLowerCase']()==='localhost')_0x1ff680='localhost';else{if(_0x104499['split']('.')['length']<=0x2)_0x1ff680=_0x104499;else{const _0x69ba56=_0x496ac7['indexOf']('.');_0x18158f=_0x496ac7['substring'](0x0,_0x69ba56)['toLowerCase'](),_0x1ff680=_0x496ac7['substring'](_0x69ba56+0x1),_0x497703=_0x18158f;}}'ns'in _0x1e37c3&&(_0x497703=_0x1e37c3['ns']);}return{'host':_0x496ac7,'port':_0x4f7bcc,'domain':_0x1ff680,'subdomain':_0x18158f,'secure':_0x5c49d2,'scheme':_0x235d8b,'pathString':_0x143e9f,'namespace':_0x497703};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x2a7a38=0x0;const _0x41bf52=[];return function(_0x3ede3c){const _0x16d713=_0x3ede3c===_0x2a7a38;_0x2a7a38=_0x3ede3c;let _0x5d44c8;const _0x3119aa=new Array(0x8);for(_0x5d44c8=0x7;_0x5d44c8>=0x0;_0x5d44c8--)_0x3119aa[_0x5d44c8]=Er['charAt'](_0x3ede3c%0x40),_0x3ede3c=Math['floor'](_0x3ede3c/0x40);f(_0x3ede3c===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x4b9c84=_0x3119aa['join']('');if(_0x16d713){for(_0x5d44c8=0xb;_0x5d44c8>=0x0&&_0x41bf52[_0x5d44c8]===0x3f;_0x5d44c8--)_0x41bf52[_0x5d44c8]=0x0;_0x41bf52[_0x5d44c8]++;}else{for(_0x5d44c8=0x0;_0x5d44c8<0xc;_0x5d44c8++)_0x41bf52[_0x5d44c8]=Math['floor'](Math['random']()*0x40);}for(_0x5d44c8=0x0;_0x5d44c8<0xc;_0x5d44c8++)_0x4b9c84+=Er['charAt'](_0x41bf52[_0x5d44c8]);return f(_0x4b9c84['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x4b9c84;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x1854ba,_0xe4a85f,_0x3fc3ec,_0x15165b){this['eventType']=_0x1854ba,this['eventRegistration']=_0xe4a85f,this['snapshot']=_0x3fc3ec,this['prevName']=_0x15165b;}['getPath'](){const _0x3ee440=this['snapshot']['ref'];return this['eventType']==='value'?_0x3ee440['_path']:_0x3ee440['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x4b36e4,_0x4cfdec,_0x41584f){this['eventRegistration']=_0x4b36e4,this['error']=_0x4cfdec,this['path']=_0x41584f;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x12c829,_0x298f09){this['snapshotCallback']=_0x12c829,this['cancelCallback']=_0x298f09;}['onValue'](_0x4791ee,_0x4a9f77){this['snapshotCallback']['call'](null,_0x4791ee,_0x4a9f77);}['onCancel'](_0x4b33bb){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x4b33bb);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x42567d){return this['snapshotCallback']===_0x42567d['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x42567d['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x42567d['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x3f580c,_0x416aec){this['_repo']=_0x3f580c,this['_path']=_0x416aec;}['cancel'](){const _0x221181=new H();return bd(this['_repo'],this['_path'],_0x221181['wrapCallback'](()=>{})),_0x221181['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x30079b=new H();return yr(this['_repo'],this['_path'],null,_0x30079b['wrapCallback'](()=>{})),_0x30079b['promise'];}['set'](_0x24970c){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x24970c,this['_path'],!0x1);const _0x342ce1=new H();return yr(this['_repo'],this['_path'],_0x24970c,_0x342ce1['wrapCallback'](()=>{})),_0x342ce1['promise'];}['setWithPriority'](_0x486a9b,_0x354dde){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x486a9b,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x354dde);const _0x5003c7=new H();return Rd(this['_repo'],this['_path'],_0x486a9b,_0x354dde,_0x5003c7['wrapCallback'](()=>{})),_0x5003c7['promise'];}['update'](_0x5b0cb6){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x5b0cb6,this['_path']);const _0x5095d7=new H();return Ad(this['_repo'],this['_path'],_0x5b0cb6,_0x5095d7['wrapCallback'](()=>{})),_0x5095d7['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x18d9a6,_0x334faf,_0x3e79fb,_0x165ba5){this['_repo']=_0x18d9a6,this['_path']=_0x334faf,this['_queryParams']=_0x3e79fb,this['_orderByCalled']=_0x165ba5;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x2afe03=sr(this['_queryParams']),_0x287786=$i(_0x2afe03);return _0x287786==='{}'?'default':_0x287786;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x3ef8f8){if(_0x3ef8f8=P(_0x3ef8f8),!(_0x3ef8f8 instanceof Ae))return!0x1;const _0x49c692=this['_repo']===_0x3ef8f8['_repo'],_0x2d7689=Ki(this['_path'],_0x3ef8f8['_path']),_0x3fd2fd=this['_queryIdentifier']===_0x3ef8f8['_queryIdentifier'];return _0x49c692&&_0x2d7689&&_0x3fd2fd;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x153a76,_0x435fc4){if(_0x153a76['_orderByCalled']===!0x0)throw new Error(_0x435fc4+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x2533f5){let _0x28c20b=null,_0x5ca645=null;if(_0x2533f5['hasStart']()&&(_0x28c20b=_0x2533f5['getIndexStartValue']()),_0x2533f5['hasEnd']()&&(_0x5ca645=_0x2533f5['getIndexEndValue']()),_0x2533f5['getIndex']()===ve){const _0xd48b1f='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x1623dc='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x2533f5['hasStart']()){if(_0x2533f5['getIndexStartName']()!==We)throw new Error(_0xd48b1f);if(typeof _0x28c20b!='string')throw new Error(_0x1623dc);}if(_0x2533f5['hasEnd']()){if(_0x2533f5['getIndexEndName']()!==we)throw new Error(_0xd48b1f);if(typeof _0x5ca645!='string')throw new Error(_0x1623dc);}}else{if(_0x2533f5['getIndex']()===R){if(_0x28c20b!=null&&!Bt(_0x28c20b)||_0x5ca645!=null&&!Bt(_0x5ca645))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x2533f5['getIndex']()instanceof Ji||_0x2533f5['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x28c20b!=null&&typeof _0x28c20b=='object'||_0x5ca645!=null&&typeof _0x5ca645=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x55ad82){if(_0x55ad82['hasStart']()&&_0x55ad82['hasEnd']()&&_0x55ad82['hasLimit']()&&!_0x55ad82['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x5b8c2a,_0xec64ab){super(_0x5b8c2a,_0xec64ab,new Zi(),!0x1);}get['parent'](){const _0x4a31cc=Ro(this['_path']);return _0x4a31cc===null?null:new ee(this['_repo'],_0x4a31cc);}get['root'](){let _0x2fcde3=this;for(;_0x2fcde3['parent']!==null;)_0x2fcde3=_0x2fcde3['parent'];return _0x2fcde3;}}class lt{constructor(_0x3b2199,_0x112050,_0x55b486){this['_node']=_0x3b2199,this['ref']=_0x112050,this['_index']=_0x55b486;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x4eb7b8){const _0x1d2ebd=new C(_0x4eb7b8),_0xd41fac=Vt(this['ref'],_0x4eb7b8);return new lt(this['_node']['getChild'](_0x1d2ebd),_0xd41fac,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x7c9cf8){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x2e1ff2,_0x1193d2)=>_0x7c9cf8(new lt(_0x1193d2,Vt(this['ref'],_0x2e1ff2),R)));}['hasChild'](_0x49b73f){const _0xa561d8=new C(_0x49b73f);return!this['_node']['getChild'](_0xa561d8)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x28b696,_0x5c22a4){return _0x28b696=P(_0x28b696),_0x28b696['_checkNotDeleted']('ref'),_0x5c22a4!==void 0x0?Vt(_0x28b696['_root'],_0x5c22a4):_0x28b696['_root'];}function Vt(_0x5080db,_0x2157cf){return _0x5080db=P(_0x5080db),y(_0x5080db['_path'])===null?pd('child','path',_0x2157cf):ys('child','path',_0x2157cf),new ee(_0x5080db['_repo'],k(_0x5080db['_path'],_0x2157cf));}function v_(_0x412aec){return _0x412aec=P(_0x412aec),new Vd(_0x412aec['_repo'],_0x412aec['_path']);}function E_(_0x524e3d,_0x2683e5){_0x524e3d=P(_0x524e3d),Me('push',_0x524e3d['_path']),He('push',_0x2683e5,_0x524e3d['_path'],!0x0);const _0xa91019=la(_0x524e3d['_repo']),_0x517144=Ud(_0xa91019),_0x595095=Vt(_0x524e3d,_0x517144),_0xe42404=Vt(_0x524e3d,_0x517144);let _0x85cd28;return _0x2683e5!=null?_0x85cd28=Hd(_0xe42404,_0x2683e5)['then'](()=>_0xe42404):_0x85cd28=Promise['resolve'](_0xe42404),_0x595095['then']=_0x85cd28['then']['bind'](_0x85cd28),_0x595095['catch']=_0x85cd28['then']['bind'](_0x85cd28,void 0x0),_0x595095;}function Hd(_0x51381b,_0x1195c3){_0x51381b=P(_0x51381b),Me('set',_0x51381b['_path']),He('set',_0x1195c3,_0x51381b['_path'],!0x1);const _0x1a8e0b=new H();return Cd(_0x51381b['_repo'],_0x51381b['_path'],_0x1195c3,null,_0x1a8e0b['wrapCallback'](()=>{})),_0x1a8e0b['promise'];}function I_(_0x5bec6a,_0xeb23b5){ra('update',_0xeb23b5,_0x5bec6a['_path']);const _0x3eeb0b=new H();return Td(_0x5bec6a['_repo'],_0x5bec6a['_path'],_0xeb23b5,_0x3eeb0b['wrapCallback'](()=>{})),_0x3eeb0b['promise'];}function w_(_0x2102f2){_0x2102f2=P(_0x2102f2);const _0x27ccaf=new pa(()=>{}),_0xa5218e=new Qn(_0x27ccaf);return wd(_0x2102f2['_repo'],_0x2102f2,_0xa5218e)['then'](_0x5d5754=>new lt(_0x5d5754,new ee(_0x2102f2['_repo'],_0x2102f2['_path']),_0x2102f2['_queryParams']['getIndex']()));}class Qn{constructor(_0x347ff3){this['callbackContext']=_0x347ff3;}['respondsTo'](_0x32b084){return _0x32b084==='value';}['createEvent'](_0x73cba6,_0x36e2df){const _0x2ad394=_0x36e2df['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x73cba6['snapshotNode'],new ee(_0x36e2df['_repo'],_0x36e2df['_path']),_0x2ad394));}['getEventRunner'](_0x5c4bb3){return _0x5c4bb3['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x5c4bb3['error']):()=>this['callbackContext']['onValue'](_0x5c4bb3['snapshot'],null);}['createCancelEvent'](_0x4f1446,_0x34810e){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x4f1446,_0x34810e):null;}['matches'](_0x25f37a){return _0x25f37a instanceof Qn?!_0x25f37a['callbackContext']||!this['callbackContext']?!0x0:_0x25f37a['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x2310ab,_0x1ee76a,_0x1c9e34,_0x8eabff,_0x226c74){const _0x3bc214=new pa(_0x1c9e34,void 0x0),_0xbc5b7=new Qn(_0x3bc214);return kd(_0x2310ab['_repo'],_0x2310ab,_0xbc5b7),()=>Pd(_0x2310ab['_repo'],_0x2310ab,_0xbc5b7);}function Gd(_0x3b1c60,_0x35a877,_0x86b44f,_0x4be7c1){return $d(_0x3b1c60,'value',_0x35a877);}class mt{}class ma extends mt{constructor(_0x47f1de,_0x1f35b0){super(),this['_value']=_0x47f1de,this['_key']=_0x1f35b0,this['type']='endAt';}['_apply'](_0x1f473b){He('endAt',this['_value'],_0x1f473b['_path'],!0x0);const _0x32c8af=Jh(_0x1f473b['_queryParams'],this['_value'],this['_key']);if(ga(_0x32c8af),Yn(_0x32c8af),_0x1f473b['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x1f473b['_repo'],_0x1f473b['_path'],_0x32c8af,_0x1f473b['_orderByCalled']);}}function C_(_0x44000e,_0x271157){return new ma(_0x44000e,_0x271157);}class ya extends mt{constructor(_0x90ade6,_0x1fe598){super(),this['_value']=_0x90ade6,this['_key']=_0x1fe598,this['type']='startAt';}['_apply'](_0x128f83){He('startAt',this['_value'],_0x128f83['_path'],!0x0);const _0x4010d3=Qh(_0x128f83['_queryParams'],this['_value'],this['_key']);if(ga(_0x4010d3),Yn(_0x4010d3),_0x128f83['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x128f83['_repo'],_0x128f83['_path'],_0x4010d3,_0x128f83['_orderByCalled']);}}function T_(_0x34e321=null,_0x36a32d){return new ya(_0x34e321,_0x36a32d);}class qd extends mt{constructor(_0x15cc2a){super(),this['_limit']=_0x15cc2a,this['type']='limitToFirst';}['_apply'](_0x1bcaa4){if(_0x1bcaa4['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x1bcaa4['_repo'],_0x1bcaa4['_path'],Yh(_0x1bcaa4['_queryParams'],this['_limit']),_0x1bcaa4['_orderByCalled']);}}function S_(_0x522559){if(Math['floor'](_0x522559)!==_0x522559||_0x522559<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x522559);}class zd extends mt{constructor(_0x4467b0){super(),this['_path']=_0x4467b0,this['type']='orderByChild';}['_apply'](_0x216c12){_a(_0x216c12,'orderByChild');const _0x4bd071=new C(this['_path']);if(v(_0x4bd071))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x2cf9e6=new Ji(_0x4bd071),_0x38284e=xo(_0x216c12['_queryParams'],_0x2cf9e6);return Yn(_0x38284e),new Ae(_0x216c12['_repo'],_0x216c12['_path'],_0x38284e,!0x0);}}function b_(_0x5d4e3f){if(_0x5d4e3f==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x5d4e3f==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x5d4e3f==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x5d4e3f),new zd(_0x5d4e3f);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x57edda){_a(_0x57edda,'orderByKey');const _0x4e4500=xo(_0x57edda['_queryParams'],ve);return Yn(_0x4e4500),new Ae(_0x57edda['_repo'],_0x57edda['_path'],_0x4e4500,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x32d3b1,_0x431d03){super(),this['_value']=_0x32d3b1,this['_key']=_0x431d03,this['type']='equalTo';}['_apply'](_0x148269){if(He('equalTo',this['_value'],_0x148269['_path'],!0x1),_0x148269['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x148269['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x148269));}}function A_(_0x3a746e,_0x49662c){return new Kd(_0x3a746e,_0x49662c);}function k_(_0x4a0051,..._0x4e5162){let _0x59ec63=P(_0x4a0051);for(const _0x1cf874 of _0x4e5162)_0x59ec63=_0x1cf874['_apply'](_0x59ec63);return _0x59ec63;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x398dfe,_0x57c7d2,_0x19804e,_0xa1669f){const _0x19def0=_0x57c7d2['lastIndexOf'](':'),_0x3d4f70=_0x57c7d2['substring'](0x0,_0x19def0),_0x43d0f4=qt(_0x3d4f70);_0x398dfe['repoInfo_']=new yo(_0x57c7d2,_0x43d0f4,_0x398dfe['repoInfo_']['namespace'],_0x398dfe['repoInfo_']['webSocketOnly'],_0x398dfe['repoInfo_']['nodeAdmin'],_0x398dfe['repoInfo_']['persistenceKey'],_0x398dfe['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x19804e),_0xa1669f&&(_0x398dfe['authTokenProvider_']=_0xa1669f);}function Xd(_0x225853,_0x214ac0,_0x285db7,_0x3e7d62,_0x1cbdae){let _0x2270bc=_0x3e7d62||_0x225853['options']['databaseURL'];_0x2270bc===void 0x0&&(_0x225853['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x225853['options']['projectId']),_0x2270bc=_0x225853['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x450c61=vr(_0x2270bc,_0x1cbdae),_0x159587=_0x450c61['repoInfo'],_0x5ae8b2;typeof process<'u'&&Bs&&(_0x5ae8b2=Bs[Yd]),_0x5ae8b2?(_0x2270bc='http://'+_0x5ae8b2+'?ns='+_0x159587['namespace'],_0x450c61=vr(_0x2270bc,_0x1cbdae),_0x159587=_0x450c61['repoInfo']):_0x450c61['repoInfo']['secure'];const _0x3034ac=new eh(_0x225853['name'],_0x225853['options'],_0x214ac0);_d('Invalid\x20Firebase\x20Database\x20URL',_0x450c61),v(_0x450c61['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x3e82cd=ef(_0x159587,_0x225853,_0x3034ac,new Zl(_0x225853,_0x285db7));return new tf(_0x3e82cd,_0x225853);}function Zd(_0x3d05e4,_0x1657fe){const _0x368155=Di[_0x1657fe];(!_0x368155||_0x368155[_0x3d05e4['key']]!==_0x3d05e4)&&ae('Database\x20'+_0x1657fe+'('+_0x3d05e4['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x3d05e4),delete _0x368155[_0x3d05e4['key']];}function ef(_0x27acaf,_0x150c62,_0x1000ce,_0x22bd57){let _0x3981f4=Di[_0x150c62['name']];_0x3981f4||(_0x3981f4={},Di[_0x150c62['name']]=_0x3981f4);let _0x27edc9=_0x3981f4[_0x27acaf['toURLString']()];return _0x27edc9&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x27edc9=new vd(_0x27acaf,Qd,_0x1000ce,_0x22bd57),_0x3981f4[_0x27acaf['toURLString']()]=_0x27edc9,_0x27edc9;}class tf{constructor(_0x332e87,_0x336118){this['_repoInternal']=_0x332e87,this['app']=_0x336118,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x10bc16){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x10bc16+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x8492cd=Zr(),_0x263edd){const _0x5cb30a=Hi(_0x8492cd,'database')['getImmediate']({'identifier':_0x263edd});if(!_0x5cb30a['_instanceStarted']){const _0x2ed8ff=hc('database');_0x2ed8ff&&nf(_0x5cb30a,..._0x2ed8ff);}return _0x5cb30a;}function nf(_0x4f6eb7,_0x3e98f7,_0x321364,_0x579dac={}){_0x4f6eb7=P(_0x4f6eb7),_0x4f6eb7['_checkNotDeleted']('useEmulator');const _0x57f36f=_0x3e98f7+':'+_0x321364,_0x4eb2b1=_0x4f6eb7['_repoInternal'];if(_0x4f6eb7['_instanceStarted']){if(_0x57f36f===_0x4f6eb7['_repoInternal']['repoInfo_']['host']&&xe(_0x579dac,_0x4eb2b1['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x12167d;if(_0x4eb2b1['repoInfo_']['nodeAdmin'])_0x579dac['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x12167d=new an(an['OWNER']);else{if(_0x579dac['mockUserToken']){const _0x1b656a=typeof _0x579dac['mockUserToken']=='string'?_0x579dac['mockUserToken']:uc(_0x579dac['mockUserToken'],_0x4f6eb7['app']['options']['projectId']);_0x12167d=new an(_0x1b656a);}}qt(_0x3e98f7)&&Qr(_0x3e98f7),Jd(_0x4eb2b1,_0x57f36f,_0x579dac,_0x12167d);}function N_(_0x31348e){_0x31348e=P(_0x31348e),_0x31348e['_checkNotDeleted']('goOffline'),ha(_0x31348e['_repo']);}function O_(_0x272a9e){_0x272a9e=P(_0x272a9e),_0x272a9e['_checkNotDeleted']('goOnline'),Nd(_0x272a9e['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x49a891){Ul(dt),st(new Fe('database',(_0x212db0,{instanceIdentifier:_0x55e0c1})=>{const _0x1df76e=_0x212db0['getProvider']('app')['getImmediate'](),_0x59605c=_0x212db0['getProvider']('auth-internal'),_0x5b5db2=_0x212db0['getProvider']('app-check-internal');return Xd(_0x1df76e,_0x59605c,_0x5b5db2,_0x55e0c1);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x49a891),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x5813ee,_0xbd7bba){this['committed']=_0x5813ee,this['snapshot']=_0xbd7bba;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x22c68c,_0x2a2e8b,_0x4d943a){if(_0x22c68c=P(_0x22c68c),Me('Reference.transaction',_0x22c68c['_path']),_0x22c68c['key']==='.length'||_0x22c68c['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x22c68c['key']+'\x20is\x20a\x20read-only\x20object.';const _0x3a27a2=!0x0,_0x16a6d9=new H(),_0x31c5df=(_0x7b51c9,_0x4d430b,_0x24bdfa)=>{let _0x412baa=null;_0x7b51c9?_0x16a6d9['reject'](_0x7b51c9):(_0x412baa=new lt(_0x24bdfa,new ee(_0x22c68c['_repo'],_0x22c68c['_path']),R),_0x16a6d9['resolve'](new of(_0x4d430b,_0x412baa)));},_0x45418c=Gd(_0x22c68c,()=>{});return Od(_0x22c68c['_repo'],_0x22c68c['_path'],_0x2a2e8b,_0x31c5df,_0x45418c,_0x3a27a2),_0x16a6d9['promise'];}se['prototype']['simpleListen']=function(_0x2a734e,_0x30cebf){this['sendRequest']('q',{'p':_0x2a734e},_0x30cebf);},se['prototype']['echo']=function(_0x20a191,_0x4f3227){this['sendRequest']('echo',{'d':_0x20a191},_0x4f3227);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x338acc,..._0x27b87d){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x338acc,..._0x27b87d);}function cn(_0x4931f8,..._0x306f52){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x4931f8,..._0x306f52);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x3559b6,..._0x3df191){throw ws(_0x3559b6,..._0x3df191);}function X(_0x232f92,..._0x14161d){return ws(_0x232f92,..._0x14161d);}function Ia(_0x258f28,_0x32f555,_0x458487){const _0x2a9629={...af(),[_0x32f555]:_0x458487};return new Gt('auth','Firebase',_0x2a9629)['create'](_0x32f555,{'appName':_0x258f28['name']});}function re(_0x24948a){return Ia(_0x24948a,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x542664,..._0x198ef6){if(typeof _0x542664!='string'){const _0x2bd362=_0x198ef6[0x0],_0x494ce2=[..._0x198ef6['slice'](0x1)];return _0x494ce2[0x0]&&(_0x494ce2[0x0]['appName']=_0x542664['name']),_0x542664['_errorFactory']['create'](_0x2bd362,..._0x494ce2);}return Ea['create'](_0x542664,..._0x198ef6);}function m(_0x573683,_0x523136,..._0x403528){if(!_0x573683)throw ws(_0x523136,..._0x403528);}function ne(_0x167a88){const _0x363737='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x167a88;throw cn(_0x363737),new Error(_0x363737);}function ce(_0x4d7e71,_0x2c10c1){_0x4d7e71||ne(_0x2c10c1);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x8531fc;return typeof self<'u'&&((_0x8531fc=self['location'])==null?void 0x0:_0x8531fc['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x5684f3;return typeof self<'u'&&((_0x5684f3=self['location'])==null?void 0x0:_0x5684f3['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x599044=navigator;return _0x599044['languages']&&_0x599044['languages'][0x0]||_0x599044['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x3d96df,_0xf99ae1){this['shortDelay']=_0x3d96df,this['longDelay']=_0xf99ae1,ce(_0xf99ae1>_0x3d96df,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x494f50,_0x20cea8){ce(_0x494f50['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x41b757}=_0x494f50['emulator'];return _0x20cea8?''+_0x41b757+(_0x20cea8['startsWith']('/')?_0x20cea8['slice'](0x1):_0x20cea8):_0x41b757;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x37f69d,_0x1c5b72,_0x3a49e0){this['fetchImpl']=_0x37f69d,_0x1c5b72&&(this['headersImpl']=_0x1c5b72),_0x3a49e0&&(this['responseImpl']=_0x3a49e0);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x4c0dcc,_0xadd9){return _0x4c0dcc['tenantId']&&!_0xadd9['tenantId']?{..._0xadd9,'tenantId':_0x4c0dcc['tenantId']}:_0xadd9;}async function Pe(_0x2bef75,_0x117efc,_0x54c357,_0x278e0d,_0x564205={}){return Ca(_0x2bef75,_0x564205,async()=>{let _0x3db6a6={},_0x2acd5d={};_0x278e0d&&(_0x117efc==='GET'?_0x2acd5d=_0x278e0d:_0x3db6a6={'body':JSON['stringify'](_0x278e0d)});const _0x40b025=ut({..._0x2acd5d,'key':_0x2bef75['config']['apiKey']})['slice'](0x1),_0x4e2890=await _0x2bef75['_getAdditionalHeaders']();_0x4e2890['Content-Type']='application/json',_0x2bef75['languageCode']&&(_0x4e2890['X-Firebase-Locale']=_0x2bef75['languageCode']);const _0xb745b6={'method':_0x117efc,'headers':_0x4e2890,..._0x3db6a6};return dc()||(_0xb745b6['referrerPolicy']='strict-origin-when-cross-origin'),_0x2bef75['emulatorConfig']&&qt(_0x2bef75['emulatorConfig']['host'])&&(_0xb745b6['credentials']='include'),wa['fetch']()(await Ta(_0x2bef75,_0x2bef75['config']['apiHost'],_0x54c357,_0x40b025),_0xb745b6);});}async function Ca(_0x532247,_0x4743f2,_0x5d3759){_0x532247['_canInitEmulator']=!0x1;const _0x438bb7={...df,..._0x4743f2};try{const _0x3f4469=new gf(_0x532247),_0x4b8609=await Promise['race']([_0x5d3759(),_0x3f4469['promise']]);_0x3f4469['clearNetworkTimeout']();const _0x22b5f5=await _0x4b8609['json']();if('needConfirmation'in _0x22b5f5)throw on(_0x532247,'account-exists-with-different-credential',_0x22b5f5);if(_0x4b8609['ok']&&!('errorMessage'in _0x22b5f5))return _0x22b5f5;{const _0xfafd2b=_0x4b8609['ok']?_0x22b5f5['errorMessage']:_0x22b5f5['error']['message'],[_0x5991d5,_0x36aec1]=_0xfafd2b['split']('\x20:\x20');if(_0x5991d5==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x532247,'credential-already-in-use',_0x22b5f5);if(_0x5991d5==='EMAIL_EXISTS')throw on(_0x532247,'email-already-in-use',_0x22b5f5);if(_0x5991d5==='USER_DISABLED')throw on(_0x532247,'user-disabled',_0x22b5f5);const _0x31a07d=_0x438bb7[_0x5991d5]||_0x5991d5['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x36aec1)throw Ia(_0x532247,_0x31a07d,_0x36aec1);Y(_0x532247,_0x31a07d);}}catch(_0x3d7bde){if(_0x3d7bde instanceof Re)throw _0x3d7bde;Y(_0x532247,'network-request-failed',{'message':String(_0x3d7bde)});}}async function en(_0x4a5980,_0x418bea,_0x3fb0d4,_0x47225e,_0x19fcff={}){const _0x1a13ec=await Pe(_0x4a5980,_0x418bea,_0x3fb0d4,_0x47225e,_0x19fcff);return'mfaPendingCredential'in _0x1a13ec&&Y(_0x4a5980,'multi-factor-auth-required',{'_serverResponse':_0x1a13ec}),_0x1a13ec;}async function Ta(_0xcd10b4,_0x1c9226,_0x3f0890,_0x4e855e){const _0x1cdd70=''+_0x1c9226+_0x3f0890+'?'+_0x4e855e,_0x217569=_0xcd10b4,_0x29ea46=_0x217569['config']['emulator']?Cs(_0xcd10b4['config'],_0x1cdd70):_0xcd10b4['config']['apiScheme']+'://'+_0x1cdd70;return ff['includes'](_0x3f0890)&&(await _0x217569['_persistenceManagerAvailable'],_0x217569['_getPersistenceType']()==='COOKIE')?_0x217569['_getPersistence']()['_getFinalTarget'](_0x29ea46)['toString']():_0x29ea46;}function _f(_0x1d04ea){switch(_0x1d04ea){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x4c65a4){this['auth']=_0x4c65a4,this['timer']=null,this['promise']=new Promise((_0x25fac0,_0x2897e3)=>{this['timer']=setTimeout(()=>_0x2897e3(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x18242f,_0x35c49c,_0x555ea2){const _0x54129d={'appName':_0x18242f['name']};_0x555ea2['email']&&(_0x54129d['email']=_0x555ea2['email']),_0x555ea2['phoneNumber']&&(_0x54129d['phoneNumber']=_0x555ea2['phoneNumber']);const _0x3405c1=X(_0x18242f,_0x35c49c,_0x54129d);return _0x3405c1['customData']['_tokenResponse']=_0x555ea2,_0x3405c1;}function wr(_0x14c38a){return _0x14c38a!==void 0x0&&_0x14c38a['enterprise']!==void 0x0;}class mf{constructor(_0x2ccbaf){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x2ccbaf['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x2ccbaf['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x2ccbaf['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x243e61){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0xfad898 of this['recaptchaEnforcementState'])if(_0xfad898['provider']&&_0xfad898['provider']===_0x243e61)return _f(_0xfad898['enforcementState']);return null;}['isProviderEnabled'](_0x5aebba){return this['getProviderEnforcementState'](_0x5aebba)==='ENFORCE'||this['getProviderEnforcementState'](_0x5aebba)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x221074,_0x23847b){return Pe(_0x221074,'GET','/v2/recaptchaConfig',ke(_0x221074,_0x23847b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x4712a1,_0x54fba6){return Pe(_0x4712a1,'POST','/v1/accounts:delete',_0x54fba6);}async function Pn(_0x535f0c,_0x131d78){return Pe(_0x535f0c,'POST','/v1/accounts:lookup',_0x131d78);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x537e11){if(_0x537e11)try{const _0x32202c=new Date(Number(_0x537e11));if(!isNaN(_0x32202c['getTime']()))return _0x32202c['toUTCString']();}catch{}}async function Ef(_0x34bfc9,_0x2ecbbf=!0x1){const _0x10bd41=P(_0x34bfc9),_0x9f13f3=await _0x10bd41['getIdToken'](_0x2ecbbf),_0x44d206=Ts(_0x9f13f3);m(_0x44d206&&_0x44d206['exp']&&_0x44d206['auth_time']&&_0x44d206['iat'],_0x10bd41['auth'],'internal-error');const _0x400385=typeof _0x44d206['firebase']=='object'?_0x44d206['firebase']:void 0x0,_0x4eb7ba=_0x400385==null?void 0x0:_0x400385['sign_in_provider'];return{'claims':_0x44d206,'token':_0x9f13f3,'authTime':Pt(fi(_0x44d206['auth_time'])),'issuedAtTime':Pt(fi(_0x44d206['iat'])),'expirationTime':Pt(fi(_0x44d206['exp'])),'signInProvider':_0x4eb7ba||null,'signInSecondFactor':(_0x400385==null?void 0x0:_0x400385['sign_in_second_factor'])||null};}function fi(_0x304fb3){return Number(_0x304fb3)*0x3e8;}function Ts(_0x43a3cc){const [_0x46245b,_0x279ab1,_0x5115be]=_0x43a3cc['split']('.');if(_0x46245b===void 0x0||_0x279ab1===void 0x0||_0x5115be===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x50e254=fn(_0x279ab1);return _0x50e254?JSON['parse'](_0x50e254):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x16848b){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x16848b==null?void 0x0:_0x16848b['toString']()),null;}}function Cr(_0xa1a3df){const _0x1e6c53=Ts(_0xa1a3df);return m(_0x1e6c53,'internal-error'),m(typeof _0x1e6c53['exp']<'u','internal-error'),m(typeof _0x1e6c53['iat']<'u','internal-error'),Number(_0x1e6c53['exp'])-Number(_0x1e6c53['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x2aae11,_0x473db7,_0x49d76b=!0x1){if(_0x49d76b)return _0x473db7;try{return await _0x473db7;}catch(_0x5c4cff){throw _0x5c4cff instanceof Re&&If(_0x5c4cff)&&_0x2aae11['auth']['currentUser']===_0x2aae11&&await _0x2aae11['auth']['signOut'](),_0x5c4cff;}}function If({code:_0x2e4457}){return _0x2e4457==='auth/user-disabled'||_0x2e4457==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x419424){this['user']=_0x419424,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x168f43){if(_0x168f43){const _0xb8211d=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0xb8211d;}else{this['errorBackoff']=0x7530;const _0x312067=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x312067);}}['schedule'](_0x26f75d=!0x1){if(!this['isRunning'])return;const _0x5c4dc9=this['getInterval'](_0x26f75d);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x5c4dc9);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x23f87f){(_0x23f87f==null?void 0x0:_0x23f87f['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x2fc642,_0x2aea64){this['createdAt']=_0x2fc642,this['lastLoginAt']=_0x2aea64,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x2bc077){this['createdAt']=_0x2bc077['createdAt'],this['lastLoginAt']=_0x2bc077['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x5c4c8e){var _0x5f3338;const _0x5be263=_0x5c4c8e['auth'],_0x48665e=await _0x5c4c8e['getIdToken'](),_0x4e2c6a=await Ht(_0x5c4c8e,Pn(_0x5be263,{'idToken':_0x48665e}));m(_0x4e2c6a==null?void 0x0:_0x4e2c6a['users']['length'],_0x5be263,'internal-error');const _0x42d821=_0x4e2c6a['users'][0x0];_0x5c4c8e['_notifyReloadListener'](_0x42d821);const _0x129aa7=(_0x5f3338=_0x42d821['providerUserInfo'])!=null&&_0x5f3338['length']?Sa(_0x42d821['providerUserInfo']):[],_0x26ca57=Tf(_0x5c4c8e['providerData'],_0x129aa7),_0x25923f=_0x5c4c8e['isAnonymous'],_0x5b4359=!(_0x5c4c8e['email']&&_0x42d821['passwordHash'])&&!(_0x26ca57!=null&&_0x26ca57['length']),_0x12e4a4=_0x25923f?_0x5b4359:!0x1,_0x683cfa={'uid':_0x42d821['localId'],'displayName':_0x42d821['displayName']||null,'photoURL':_0x42d821['photoUrl']||null,'email':_0x42d821['email']||null,'emailVerified':_0x42d821['emailVerified']||!0x1,'phoneNumber':_0x42d821['phoneNumber']||null,'tenantId':_0x42d821['tenantId']||null,'providerData':_0x26ca57,'metadata':new Li(_0x42d821['createdAt'],_0x42d821['lastLoginAt']),'isAnonymous':_0x12e4a4};Object['assign'](_0x5c4c8e,_0x683cfa);}async function Cf(_0x336f5d){const _0x285864=P(_0x336f5d);await Nn(_0x285864),await _0x285864['auth']['_persistUserIfCurrent'](_0x285864),_0x285864['auth']['_notifyListenersIfCurrent'](_0x285864);}function Tf(_0x2e9c0b,_0x2bb51e){return[..._0x2e9c0b['filter'](_0x42d445=>!_0x2bb51e['some'](_0x194b50=>_0x194b50['providerId']===_0x42d445['providerId'])),..._0x2bb51e];}function Sa(_0x28da12){return _0x28da12['map'](({providerId:_0x46aac1,..._0xe7166e})=>({'providerId':_0x46aac1,'uid':_0xe7166e['rawId']||'','displayName':_0xe7166e['displayName']||null,'email':_0xe7166e['email']||null,'phoneNumber':_0xe7166e['phoneNumber']||null,'photoURL':_0xe7166e['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x4726ca,_0x39a176){const _0x585a2c=await Ca(_0x4726ca,{},async()=>{const _0x1b5b23=ut({'grant_type':'refresh_token','refresh_token':_0x39a176})['slice'](0x1),{tokenApiHost:_0xec75ed,apiKey:_0x412f25}=_0x4726ca['config'],_0x5cb56c=await Ta(_0x4726ca,_0xec75ed,'/v1/token','key='+_0x412f25),_0x553155=await _0x4726ca['_getAdditionalHeaders']();_0x553155['Content-Type']='application/x-www-form-urlencoded';const _0x2b6518={'method':'POST','headers':_0x553155,'body':_0x1b5b23};return _0x4726ca['emulatorConfig']&&qt(_0x4726ca['emulatorConfig']['host'])&&(_0x2b6518['credentials']='include'),wa['fetch']()(_0x5cb56c,_0x2b6518);});return{'accessToken':_0x585a2c['access_token'],'expiresIn':_0x585a2c['expires_in'],'refreshToken':_0x585a2c['refresh_token']};}async function bf(_0x330963,_0x9aa256){return Pe(_0x330963,'POST','/v2/accounts:revokeToken',ke(_0x330963,_0x9aa256));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x2f77d4){m(_0x2f77d4['idToken'],'internal-error'),m(typeof _0x2f77d4['idToken']<'u','internal-error'),m(typeof _0x2f77d4['refreshToken']<'u','internal-error');const _0x183894='expiresIn'in _0x2f77d4&&typeof _0x2f77d4['expiresIn']<'u'?Number(_0x2f77d4['expiresIn']):Cr(_0x2f77d4['idToken']);this['updateTokensAndExpiration'](_0x2f77d4['idToken'],_0x2f77d4['refreshToken'],_0x183894);}['updateFromIdToken'](_0x45a5dc){m(_0x45a5dc['length']!==0x0,'internal-error');const _0x397de0=Cr(_0x45a5dc);this['updateTokensAndExpiration'](_0x45a5dc,null,_0x397de0);}async['getToken'](_0x1453fc,_0xcff926=!0x1){return!_0xcff926&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x1453fc,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x1453fc,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x4bb939,_0x58c779){const {accessToken:_0x14b870,refreshToken:_0x29a8db,expiresIn:_0x208eae}=await Sf(_0x4bb939,_0x58c779);this['updateTokensAndExpiration'](_0x14b870,_0x29a8db,Number(_0x208eae));}['updateTokensAndExpiration'](_0x4f45dd,_0x12805d,_0xa88a0c){this['refreshToken']=_0x12805d||null,this['accessToken']=_0x4f45dd||null,this['expirationTime']=Date['now']()+_0xa88a0c*0x3e8;}static['fromJSON'](_0x54a2cc,_0x423033){const {refreshToken:_0x1a5292,accessToken:_0x1ed650,expirationTime:_0x41a8de}=_0x423033,_0x2365e4=new et();return _0x1a5292&&(m(typeof _0x1a5292=='string','internal-error',{'appName':_0x54a2cc}),_0x2365e4['refreshToken']=_0x1a5292),_0x1ed650&&(m(typeof _0x1ed650=='string','internal-error',{'appName':_0x54a2cc}),_0x2365e4['accessToken']=_0x1ed650),_0x41a8de&&(m(typeof _0x41a8de=='number','internal-error',{'appName':_0x54a2cc}),_0x2365e4['expirationTime']=_0x41a8de),_0x2365e4;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x335358){this['accessToken']=_0x335358['accessToken'],this['refreshToken']=_0x335358['refreshToken'],this['expirationTime']=_0x335358['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x565255,_0x29032f){m(typeof _0x565255=='string'||typeof _0x565255>'u','internal-error',{'appName':_0x29032f});}class j{constructor({uid:_0x589fb8,auth:_0x111d95,stsTokenManager:_0x5dd7b9,..._0x58e9d8}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x589fb8,this['auth']=_0x111d95,this['stsTokenManager']=_0x5dd7b9,this['accessToken']=_0x5dd7b9['accessToken'],this['displayName']=_0x58e9d8['displayName']||null,this['email']=_0x58e9d8['email']||null,this['emailVerified']=_0x58e9d8['emailVerified']||!0x1,this['phoneNumber']=_0x58e9d8['phoneNumber']||null,this['photoURL']=_0x58e9d8['photoURL']||null,this['isAnonymous']=_0x58e9d8['isAnonymous']||!0x1,this['tenantId']=_0x58e9d8['tenantId']||null,this['providerData']=_0x58e9d8['providerData']?[..._0x58e9d8['providerData']]:[],this['metadata']=new Li(_0x58e9d8['createdAt']||void 0x0,_0x58e9d8['lastLoginAt']||void 0x0);}async['getIdToken'](_0x5b4eb4){const _0x3488e4=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x5b4eb4));return m(_0x3488e4,this['auth'],'internal-error'),this['accessToken']!==_0x3488e4&&(this['accessToken']=_0x3488e4,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x3488e4;}['getIdTokenResult'](_0x3ebf1f){return Ef(this,_0x3ebf1f);}['reload'](){return Cf(this);}['_assign'](_0x40cedb){this!==_0x40cedb&&(m(this['uid']===_0x40cedb['uid'],this['auth'],'internal-error'),this['displayName']=_0x40cedb['displayName'],this['photoURL']=_0x40cedb['photoURL'],this['email']=_0x40cedb['email'],this['emailVerified']=_0x40cedb['emailVerified'],this['phoneNumber']=_0x40cedb['phoneNumber'],this['isAnonymous']=_0x40cedb['isAnonymous'],this['tenantId']=_0x40cedb['tenantId'],this['providerData']=_0x40cedb['providerData']['map'](_0x2f6261=>({..._0x2f6261})),this['metadata']['_copy'](_0x40cedb['metadata']),this['stsTokenManager']['_assign'](_0x40cedb['stsTokenManager']));}['_clone'](_0x1d39ac){const _0x228f2a=new j({...this,'auth':_0x1d39ac,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x228f2a['metadata']['_copy'](this['metadata']),_0x228f2a;}['_onReload'](_0x317b85){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x317b85,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x5031d0){this['reloadListener']?this['reloadListener'](_0x5031d0):this['reloadUserInfo']=_0x5031d0;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x213e85,_0x571fdb=!0x1){let _0x28321a=!0x1;_0x213e85['idToken']&&_0x213e85['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x213e85),_0x28321a=!0x0),_0x571fdb&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x28321a&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x2ef771=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x2ef771})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x210bd6=>({..._0x210bd6})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x552050,_0x320018){const _0x25c856=_0x320018['displayName']??void 0x0,_0x39ac97=_0x320018['email']??void 0x0,_0x44d6a7=_0x320018['phoneNumber']??void 0x0,_0x5c7b6c=_0x320018['photoURL']??void 0x0,_0x552045=_0x320018['tenantId']??void 0x0,_0x1a687c=_0x320018['_redirectEventId']??void 0x0,_0x332610=_0x320018['createdAt']??void 0x0,_0x3fce8f=_0x320018['lastLoginAt']??void 0x0,{uid:_0x1c2d91,emailVerified:_0x1c35e6,isAnonymous:_0x500d13,providerData:_0x4544d8,stsTokenManager:_0x59624d}=_0x320018;m(_0x1c2d91&&_0x59624d,_0x552050,'internal-error');const _0x27d793=et['fromJSON'](this['name'],_0x59624d);m(typeof _0x1c2d91=='string',_0x552050,'internal-error'),le(_0x25c856,_0x552050['name']),le(_0x39ac97,_0x552050['name']),m(typeof _0x1c35e6=='boolean',_0x552050,'internal-error'),m(typeof _0x500d13=='boolean',_0x552050,'internal-error'),le(_0x44d6a7,_0x552050['name']),le(_0x5c7b6c,_0x552050['name']),le(_0x552045,_0x552050['name']),le(_0x1a687c,_0x552050['name']),le(_0x332610,_0x552050['name']),le(_0x3fce8f,_0x552050['name']);const _0x4d706a=new j({'uid':_0x1c2d91,'auth':_0x552050,'email':_0x39ac97,'emailVerified':_0x1c35e6,'displayName':_0x25c856,'isAnonymous':_0x500d13,'photoURL':_0x5c7b6c,'phoneNumber':_0x44d6a7,'tenantId':_0x552045,'stsTokenManager':_0x27d793,'createdAt':_0x332610,'lastLoginAt':_0x3fce8f});return _0x4544d8&&Array['isArray'](_0x4544d8)&&(_0x4d706a['providerData']=_0x4544d8['map'](_0x12a257=>({..._0x12a257}))),_0x1a687c&&(_0x4d706a['_redirectEventId']=_0x1a687c),_0x4d706a;}static async['_fromIdTokenResponse'](_0x15f6a0,_0x263dfb,_0x3d34e7=!0x1){const _0x5f2b98=new et();_0x5f2b98['updateFromServerResponse'](_0x263dfb);const _0x1b46ee=new j({'uid':_0x263dfb['localId'],'auth':_0x15f6a0,'stsTokenManager':_0x5f2b98,'isAnonymous':_0x3d34e7});return await Nn(_0x1b46ee),_0x1b46ee;}static async['_fromGetAccountInfoResponse'](_0x4fe18b,_0x4c5b2e,_0xc79f99){const _0x2a34fb=_0x4c5b2e['users'][0x0];m(_0x2a34fb['localId']!==void 0x0,'internal-error');const _0x170f42=_0x2a34fb['providerUserInfo']!==void 0x0?Sa(_0x2a34fb['providerUserInfo']):[],_0x444403=!(_0x2a34fb['email']&&_0x2a34fb['passwordHash'])&&!(_0x170f42!=null&&_0x170f42['length']),_0x173445=new et();_0x173445['updateFromIdToken'](_0xc79f99);const _0x1328e6=new j({'uid':_0x2a34fb['localId'],'auth':_0x4fe18b,'stsTokenManager':_0x173445,'isAnonymous':_0x444403}),_0x2d9167={'uid':_0x2a34fb['localId'],'displayName':_0x2a34fb['displayName']||null,'photoURL':_0x2a34fb['photoUrl']||null,'email':_0x2a34fb['email']||null,'emailVerified':_0x2a34fb['emailVerified']||!0x1,'phoneNumber':_0x2a34fb['phoneNumber']||null,'tenantId':_0x2a34fb['tenantId']||null,'providerData':_0x170f42,'metadata':new Li(_0x2a34fb['createdAt'],_0x2a34fb['lastLoginAt']),'isAnonymous':!(_0x2a34fb['email']&&_0x2a34fb['passwordHash'])&&!(_0x170f42!=null&&_0x170f42['length'])};return Object['assign'](_0x1328e6,_0x2d9167),_0x1328e6;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x16af0f){ce(_0x16af0f instanceof Function,'Expected\x20a\x20class\x20definition');let _0x4e2d3a=Tr['get'](_0x16af0f);return _0x4e2d3a?(ce(_0x4e2d3a instanceof _0x16af0f,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x4e2d3a):(_0x4e2d3a=new _0x16af0f(),Tr['set'](_0x16af0f,_0x4e2d3a),_0x4e2d3a);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x1faac5,_0x5f363e){this['storage'][_0x1faac5]=_0x5f363e;}async['_get'](_0x3d45b3){const _0x578f23=this['storage'][_0x3d45b3];return _0x578f23===void 0x0?null:_0x578f23;}async['_remove'](_0x5e3ea1){delete this['storage'][_0x5e3ea1];}['_addListener'](_0x5a6ecb,_0x5ab4ca){}['_removeListener'](_0x54141c,_0x46658f){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x41cc36,_0x384751,_0x26ec1e){return'firebase:'+_0x41cc36+':'+_0x384751+':'+_0x26ec1e;}class tt{constructor(_0xb798e5,_0x621e1c,_0x579279){this['persistence']=_0xb798e5,this['auth']=_0x621e1c,this['userKey']=_0x579279;const {config:_0xa44288,name:_0x3a0d98}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0xa44288['apiKey'],_0x3a0d98),this['fullPersistenceKey']=ln('persistence',_0xa44288['apiKey'],_0x3a0d98),this['boundEventHandler']=_0x621e1c['_onStorageEvent']['bind'](_0x621e1c),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x3c54e0){return this['persistence']['_set'](this['fullUserKey'],_0x3c54e0['toJSON']());}async['getCurrentUser'](){const _0x458b6e=await this['persistence']['_get'](this['fullUserKey']);if(!_0x458b6e)return null;if(typeof _0x458b6e=='string'){const _0x286377=await Pn(this['auth'],{'idToken':_0x458b6e})['catch'](()=>{});return _0x286377?j['_fromGetAccountInfoResponse'](this['auth'],_0x286377,_0x458b6e):null;}return j['_fromJSON'](this['auth'],_0x458b6e);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x5047f2){if(this['persistence']===_0x5047f2)return;const _0x4e8203=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x5047f2,_0x4e8203)return this['setCurrentUser'](_0x4e8203);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x220386,_0x4f54f3,_0x4bd37e='authUser'){if(!_0x4f54f3['length'])return new tt(ie(Sr),_0x220386,_0x4bd37e);const _0x26f6d2=(await Promise['all'](_0x4f54f3['map'](async _0x1284f0=>{if(await _0x1284f0['_isAvailable']())return _0x1284f0;})))['filter'](_0x5c3df9=>_0x5c3df9);let _0x2099f6=_0x26f6d2[0x0]||ie(Sr);const _0x160839=ln(_0x4bd37e,_0x220386['config']['apiKey'],_0x220386['name']);let _0x24b0e8=null;for(const _0x455717 of _0x4f54f3)try{const _0x2fde46=await _0x455717['_get'](_0x160839);if(_0x2fde46){let _0x2bb687;if(typeof _0x2fde46=='string'){const _0x1ec06b=await Pn(_0x220386,{'idToken':_0x2fde46})['catch'](()=>{});if(!_0x1ec06b)break;_0x2bb687=await j['_fromGetAccountInfoResponse'](_0x220386,_0x1ec06b,_0x2fde46);}else _0x2bb687=j['_fromJSON'](_0x220386,_0x2fde46);_0x455717!==_0x2099f6&&(_0x24b0e8=_0x2bb687),_0x2099f6=_0x455717;break;}}catch{}const _0x30695d=_0x26f6d2['filter'](_0x19184d=>_0x19184d['_shouldAllowMigration']);return!_0x2099f6['_shouldAllowMigration']||!_0x30695d['length']?new tt(_0x2099f6,_0x220386,_0x4bd37e):(_0x2099f6=_0x30695d[0x0],_0x24b0e8&&await _0x2099f6['_set'](_0x160839,_0x24b0e8['toJSON']()),await Promise['all'](_0x4f54f3['map'](async _0xdd6503=>{if(_0xdd6503!==_0x2099f6)try{await _0xdd6503['_remove'](_0x160839);}catch{}})),new tt(_0x2099f6,_0x220386,_0x4bd37e));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x334dfd){const _0x400a3b=_0x334dfd['toLowerCase']();if(_0x400a3b['includes']('opera/')||_0x400a3b['includes']('opr/')||_0x400a3b['includes']('opios/'))return'Opera';if(Pa(_0x400a3b))return'IEMobile';if(_0x400a3b['includes']('msie')||_0x400a3b['includes']('trident/'))return'IE';if(_0x400a3b['includes']('edge/'))return'Edge';if(Ra(_0x400a3b))return'Firefox';if(_0x400a3b['includes']('silk/'))return'Silk';if(Oa(_0x400a3b))return'Blackberry';if(Da(_0x400a3b))return'Webos';if(Aa(_0x400a3b))return'Safari';if((_0x400a3b['includes']('chrome/')||ka(_0x400a3b))&&!_0x400a3b['includes']('edge/'))return'Chrome';if(Na(_0x400a3b))return'Android';{const _0x5088ae=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x4811b5=_0x334dfd['match'](_0x5088ae);if((_0x4811b5==null?void 0x0:_0x4811b5['length'])===0x2)return _0x4811b5[0x1];}return'Other';}function Ra(_0x3ea805=W()){return/firefox\//i['test'](_0x3ea805);}function Aa(_0x5ce3bc=W()){const _0x304e83=_0x5ce3bc['toLowerCase']();return _0x304e83['includes']('safari/')&&!_0x304e83['includes']('chrome/')&&!_0x304e83['includes']('crios/')&&!_0x304e83['includes']('android');}function ka(_0x51fc0a=W()){return/crios\//i['test'](_0x51fc0a);}function Pa(_0x4451bb=W()){return/iemobile/i['test'](_0x4451bb);}function Na(_0x4fd8dd=W()){return/android/i['test'](_0x4fd8dd);}function Oa(_0x11d922=W()){return/blackberry/i['test'](_0x11d922);}function Da(_0x30bf83=W()){return/webos/i['test'](_0x30bf83);}function Ss(_0x312d9a=W()){return/iphone|ipad|ipod/i['test'](_0x312d9a)||/macintosh/i['test'](_0x312d9a)&&/mobile/i['test'](_0x312d9a);}function Rf(_0x13abc2=W()){var _0x60861b;return Ss(_0x13abc2)&&!!((_0x60861b=window['navigator'])!=null&&_0x60861b['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x5bfd19=W()){return Ss(_0x5bfd19)||Na(_0x5bfd19)||Da(_0x5bfd19)||Oa(_0x5bfd19)||/windows phone/i['test'](_0x5bfd19)||Pa(_0x5bfd19);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x851907,_0x23cd96=[]){let _0x5ebe7b;switch(_0x851907){case'Browser':_0x5ebe7b=br(W());break;case'Worker':_0x5ebe7b=br(W())+'-'+_0x851907;break;default:_0x5ebe7b=_0x851907;}const _0x5a18f0=_0x23cd96['length']?_0x23cd96['join'](','):'FirebaseCore-web';return _0x5ebe7b+'/JsCore/'+dt+'/'+_0x5a18f0;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x1953d2){this['auth']=_0x1953d2,this['queue']=[];}['pushCallback'](_0xe564,_0x1e4cec){const _0xf4c3db=_0x27b234=>new Promise((_0x24b554,_0x59e024)=>{try{const _0x243a1d=_0xe564(_0x27b234);_0x24b554(_0x243a1d);}catch(_0x13b7c7){_0x59e024(_0x13b7c7);}});_0xf4c3db['onAbort']=_0x1e4cec,this['queue']['push'](_0xf4c3db);const _0x119a21=this['queue']['length']-0x1;return()=>{this['queue'][_0x119a21]=()=>Promise['resolve']();};}async['runMiddleware'](_0x474b78){if(this['auth']['currentUser']===_0x474b78)return;const _0x4d9727=[];try{for(const _0x86ade of this['queue'])await _0x86ade(_0x474b78),_0x86ade['onAbort']&&_0x4d9727['push'](_0x86ade['onAbort']);}catch(_0x56083e){_0x4d9727['reverse']();for(const _0x5e3787 of _0x4d9727)try{_0x5e3787();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x56083e==null?void 0x0:_0x56083e['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x14f3b0,_0x3030fd={}){return Pe(_0x14f3b0,'GET','/v2/passwordPolicy',ke(_0x14f3b0,_0x3030fd));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x2b9a04){var _0x572cc7;const _0x21a9f2=_0x2b9a04['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x21a9f2['minPasswordLength']??Nf,_0x21a9f2['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x21a9f2['maxPasswordLength']),_0x21a9f2['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x21a9f2['containsLowercaseCharacter']),_0x21a9f2['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x21a9f2['containsUppercaseCharacter']),_0x21a9f2['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x21a9f2['containsNumericCharacter']),_0x21a9f2['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x21a9f2['containsNonAlphanumericCharacter']),this['enforcementState']=_0x2b9a04['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x572cc7=_0x2b9a04['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x572cc7['join'](''))??'',this['forceUpgradeOnSignin']=_0x2b9a04['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x2b9a04['schemaVersion'];}['validatePassword'](_0x43216b){const _0x5ab829={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x43216b,_0x5ab829),this['validatePasswordCharacterOptions'](_0x43216b,_0x5ab829),_0x5ab829['isValid']&&(_0x5ab829['isValid']=_0x5ab829['meetsMinPasswordLength']??!0x0),_0x5ab829['isValid']&&(_0x5ab829['isValid']=_0x5ab829['meetsMaxPasswordLength']??!0x0),_0x5ab829['isValid']&&(_0x5ab829['isValid']=_0x5ab829['containsLowercaseLetter']??!0x0),_0x5ab829['isValid']&&(_0x5ab829['isValid']=_0x5ab829['containsUppercaseLetter']??!0x0),_0x5ab829['isValid']&&(_0x5ab829['isValid']=_0x5ab829['containsNumericCharacter']??!0x0),_0x5ab829['isValid']&&(_0x5ab829['isValid']=_0x5ab829['containsNonAlphanumericCharacter']??!0x0),_0x5ab829;}['validatePasswordLengthOptions'](_0x3fd6ae,_0x1d9bc4){const _0x53c773=this['customStrengthOptions']['minPasswordLength'],_0x302431=this['customStrengthOptions']['maxPasswordLength'];_0x53c773&&(_0x1d9bc4['meetsMinPasswordLength']=_0x3fd6ae['length']>=_0x53c773),_0x302431&&(_0x1d9bc4['meetsMaxPasswordLength']=_0x3fd6ae['length']<=_0x302431);}['validatePasswordCharacterOptions'](_0x5e7ecb,_0x357edd){this['updatePasswordCharacterOptionsStatuses'](_0x357edd,!0x1,!0x1,!0x1,!0x1);let _0x49c914;for(let _0xdc41dc=0x0;_0xdc41dc<_0x5e7ecb['length'];_0xdc41dc++)_0x49c914=_0x5e7ecb['charAt'](_0xdc41dc),this['updatePasswordCharacterOptionsStatuses'](_0x357edd,_0x49c914>='a'&&_0x49c914<='z',_0x49c914>='A'&&_0x49c914<='Z',_0x49c914>='0'&&_0x49c914<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x49c914));}['updatePasswordCharacterOptionsStatuses'](_0x2d8beb,_0x3cd890,_0xf79008,_0x14645f,_0x53495f){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x2d8beb['containsLowercaseLetter']||(_0x2d8beb['containsLowercaseLetter']=_0x3cd890)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x2d8beb['containsUppercaseLetter']||(_0x2d8beb['containsUppercaseLetter']=_0xf79008)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x2d8beb['containsNumericCharacter']||(_0x2d8beb['containsNumericCharacter']=_0x14645f)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x2d8beb['containsNonAlphanumericCharacter']||(_0x2d8beb['containsNonAlphanumericCharacter']=_0x53495f));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x3ac8df,_0x3982d6,_0x398338,_0x27df45){this['app']=_0x3ac8df,this['heartbeatServiceProvider']=_0x3982d6,this['appCheckServiceProvider']=_0x398338,this['config']=_0x27df45,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x3ac8df['name'],this['clientVersion']=_0x27df45['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x5e6081=>this['_resolvePersistenceManagerAvailable']=_0x5e6081);}['_initializeWithPersistence'](_0x4112db,_0x4b1bbd){return _0x4b1bbd&&(this['_popupRedirectResolver']=ie(_0x4b1bbd)),this['_initializationPromise']=this['queue'](async()=>{var _0x13a027,_0x455bd2,_0x3621cf;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x4112db),(_0x13a027=this['_resolvePersistenceManagerAvailable'])==null||_0x13a027['call'](this),!this['_deleted'])){if((_0x455bd2=this['_popupRedirectResolver'])!=null&&_0x455bd2['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x4b1bbd),this['lastNotifiedUid']=((_0x3621cf=this['currentUser'])==null?void 0x0:_0x3621cf['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0xc0561f=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0xc0561f)){if(this['currentUser']&&_0xc0561f&&this['currentUser']['uid']===_0xc0561f['uid']){this['_currentUser']['_assign'](_0xc0561f),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0xc0561f,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x590b35){try{const _0x23a281=await Pn(this,{'idToken':_0x590b35}),_0x4316b5=await j['_fromGetAccountInfoResponse'](this,_0x23a281,_0x590b35);await this['directlySetCurrentUser'](_0x4316b5);}catch(_0x699f00){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x699f00),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x196bf3){var _0x111dc5;if($(this['app'])){const _0x1d26ea=this['app']['settings']['authIdToken'];return _0x1d26ea?new Promise(_0x1fad5e=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x1d26ea)['then'](_0x1fad5e,_0x1fad5e));}):this['directlySetCurrentUser'](null);}const _0x41a5fd=await this['assertedPersistence']['getCurrentUser']();let _0x32aef6=_0x41a5fd,_0x223e80=!0x1;if(_0x196bf3&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x36f61f=(_0x111dc5=this['redirectUser'])==null?void 0x0:_0x111dc5['_redirectEventId'],_0xf0a2d8=_0x32aef6==null?void 0x0:_0x32aef6['_redirectEventId'],_0x1343ac=await this['tryRedirectSignIn'](_0x196bf3);(!_0x36f61f||_0x36f61f===_0xf0a2d8)&&(_0x1343ac!=null&&_0x1343ac['user'])&&(_0x32aef6=_0x1343ac['user'],_0x223e80=!0x0);}if(!_0x32aef6)return this['directlySetCurrentUser'](null);if(!_0x32aef6['_redirectEventId']){if(_0x223e80)try{await this['beforeStateQueue']['runMiddleware'](_0x32aef6);}catch(_0x1bd30b){_0x32aef6=_0x41a5fd,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x1bd30b));}return _0x32aef6?this['reloadAndSetCurrentUserOrClear'](_0x32aef6):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x32aef6['_redirectEventId']?this['directlySetCurrentUser'](_0x32aef6):this['reloadAndSetCurrentUserOrClear'](_0x32aef6);}async['tryRedirectSignIn'](_0x404f8f){let _0x1f9e8a=null;try{_0x1f9e8a=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x404f8f,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x1f9e8a;}async['reloadAndSetCurrentUserOrClear'](_0x5d60ee){try{await Nn(_0x5d60ee);}catch(_0xd146a3){if((_0xd146a3==null?void 0x0:_0xd146a3['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x5d60ee);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x9c9c0f){if($(this['app']))return Promise['reject'](re(this));const _0x2fd160=_0x9c9c0f?P(_0x9c9c0f):null;return _0x2fd160&&m(_0x2fd160['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x2fd160&&_0x2fd160['_clone'](this));}async['_updateCurrentUser'](_0x2f6343,_0x86b550=!0x1){if(!this['_deleted'])return _0x2f6343&&m(this['tenantId']===_0x2f6343['tenantId'],this,'tenant-id-mismatch'),_0x86b550||await this['beforeStateQueue']['runMiddleware'](_0x2f6343),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x2f6343),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x1652b9){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x1652b9));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x67a036){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x428198=this['_getPasswordPolicyInternal']();return _0x428198['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x428198['validatePassword'](_0x67a036);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x2bd541=await Pf(this),_0xeba1ad=new Of(_0x2bd541);this['tenantId']===null?this['_projectPasswordPolicy']=_0xeba1ad:this['_tenantPasswordPolicies'][this['tenantId']]=_0xeba1ad;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x18d10d){this['_errorFactory']=new Gt('auth','Firebase',_0x18d10d());}['onAuthStateChanged'](_0x19a31f,_0x414575,_0x319781){return this['registerStateListener'](this['authStateSubscription'],_0x19a31f,_0x414575,_0x319781);}['beforeAuthStateChanged'](_0xe85970,_0x1ffb02){return this['beforeStateQueue']['pushCallback'](_0xe85970,_0x1ffb02);}['onIdTokenChanged'](_0x3c7278,_0xba2ea6,_0x222fee){return this['registerStateListener'](this['idTokenSubscription'],_0x3c7278,_0xba2ea6,_0x222fee);}['authStateReady'](){return new Promise((_0x558d7b,_0x170cca)=>{if(this['currentUser'])_0x558d7b();else{const _0x50f08e=this['onAuthStateChanged'](()=>{_0x50f08e(),_0x558d7b();},_0x170cca);}});}async['revokeAccessToken'](_0x3ea5c0){if(this['currentUser']){const _0x26ec21=await this['currentUser']['getIdToken'](),_0x17f0c9={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x3ea5c0,'idToken':_0x26ec21};this['tenantId']!=null&&(_0x17f0c9['tenantId']=this['tenantId']),await bf(this,_0x17f0c9);}}['toJSON'](){var _0x198add;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x198add=this['_currentUser'])==null?void 0x0:_0x198add['toJSON']()};}async['_setRedirectUser'](_0x248b2a,_0x350edf){const _0x3e119f=await this['getOrInitRedirectPersistenceManager'](_0x350edf);return _0x248b2a===null?_0x3e119f['removeCurrentUser']():_0x3e119f['setCurrentUser'](_0x248b2a);}async['getOrInitRedirectPersistenceManager'](_0x407c1f){if(!this['redirectPersistenceManager']){const _0x5ebdfb=_0x407c1f&&ie(_0x407c1f)||this['_popupRedirectResolver'];m(_0x5ebdfb,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x5ebdfb['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0xd365a4){var _0x4549fb,_0x5936f8;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x4549fb=this['_currentUser'])==null?void 0x0:_0x4549fb['_redirectEventId'])===_0xd365a4?this['_currentUser']:((_0x5936f8=this['redirectUser'])==null?void 0x0:_0x5936f8['_redirectEventId'])===_0xd365a4?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x67efdd){if(_0x67efdd===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x67efdd));}['_notifyListenersIfCurrent'](_0x1146f9){_0x1146f9===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x20a9be;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x3680ca=((_0x20a9be=this['currentUser'])==null?void 0x0:_0x20a9be['uid'])??null;this['lastNotifiedUid']!==_0x3680ca&&(this['lastNotifiedUid']=_0x3680ca,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x3ef2e7,_0x8a6d98,_0x44c0f6,_0x42ee4b){if(this['_deleted'])return()=>{};const _0x2fa706=typeof _0x8a6d98=='function'?_0x8a6d98:_0x8a6d98['next']['bind'](_0x8a6d98);let _0x3b2307=!0x1;const _0xe21077=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0xe21077,this,'internal-error'),_0xe21077['then'](()=>{_0x3b2307||_0x2fa706(this['currentUser']);}),typeof _0x8a6d98=='function'){const _0x31c9e0=_0x3ef2e7['addObserver'](_0x8a6d98,_0x44c0f6,_0x42ee4b);return()=>{_0x3b2307=!0x0,_0x31c9e0();};}else{const _0x3f804c=_0x3ef2e7['addObserver'](_0x8a6d98);return()=>{_0x3b2307=!0x0,_0x3f804c();};}}async['directlySetCurrentUser'](_0x131270){this['currentUser']&&this['currentUser']!==_0x131270&&this['_currentUser']['_stopProactiveRefresh'](),_0x131270&&this['isProactiveRefreshEnabled']&&_0x131270['_startProactiveRefresh'](),this['currentUser']=_0x131270,_0x131270?await this['assertedPersistence']['setCurrentUser'](_0x131270):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x2879d2){return this['operations']=this['operations']['then'](_0x2879d2,_0x2879d2),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x35d601){!_0x35d601||this['frameworks']['includes'](_0x35d601)||(this['frameworks']['push'](_0x35d601),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x33f286;const _0x16b0aa={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x16b0aa['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x3657da=await((_0x33f286=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x33f286['getHeartbeatsHeader']());_0x3657da&&(_0x16b0aa['X-Firebase-Client']=_0x3657da);const _0x554d10=await this['_getAppCheckToken']();return _0x554d10&&(_0x16b0aa['X-Firebase-AppCheck']=_0x554d10),_0x16b0aa;}async['_getAppCheckToken'](){var _0x128598;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x39265b=await((_0x128598=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x128598['getToken']());return _0x39265b!=null&&_0x39265b['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x39265b['error']),_0x39265b==null?void 0x0:_0x39265b['token'];}}function Ke(_0x4b0311){return P(_0x4b0311);}class Rr{constructor(_0x2a456d){this['auth']=_0x2a456d,this['observer']=null,this['addObserver']=Tc(_0x31c8ef=>this['observer']=_0x31c8ef);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x1fdb01){Jn=_0x1fdb01;}function xa(_0x41d0b8){return Jn['loadJS'](_0x41d0b8);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x2f7e2f){return'__'+_0x2f7e2f+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x48b2e3){_0x48b2e3();}['execute'](_0x4749e4,_0x5f3efa){return Promise['resolve']('token');}['render'](_0x2d598e,_0x6312b4){return'';}}class Wf{['ready'](_0x4f24f8){_0x4f24f8();}['execute'](_0x1b3bba,_0xd5e82d){return Promise['resolve']('token');}['render'](_0x1807bf,_0x1668cf){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x2758d2){this['type']=Bf,this['auth']=Ke(_0x2758d2);}async['verify'](_0x5e3d04='verify',_0x20a5a3=!0x1){async function _0x5b8663(_0x4c94fb){if(!_0x20a5a3){if(_0x4c94fb['tenantId']==null&&_0x4c94fb['_agentRecaptchaConfig']!=null)return _0x4c94fb['_agentRecaptchaConfig']['siteKey'];if(_0x4c94fb['tenantId']!=null&&_0x4c94fb['_tenantRecaptchaConfigs'][_0x4c94fb['tenantId']]!==void 0x0)return _0x4c94fb['_tenantRecaptchaConfigs'][_0x4c94fb['tenantId']]['siteKey'];}return new Promise(async(_0x3ec932,_0x46facd)=>{yf(_0x4c94fb,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x4af983=>{if(_0x4af983['recaptchaKey']===void 0x0)_0x46facd(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x4a2039=new mf(_0x4af983);return _0x4c94fb['tenantId']==null?_0x4c94fb['_agentRecaptchaConfig']=_0x4a2039:_0x4c94fb['_tenantRecaptchaConfigs'][_0x4c94fb['tenantId']]=_0x4a2039,_0x3ec932(_0x4a2039['siteKey']);}})['catch'](_0x4b65b9=>{_0x46facd(_0x4b65b9);});});}function _0x91bb5f(_0x385519,_0x50ae8e,_0x35177c){const _0x6c22b5=window['grecaptcha'];wr(_0x6c22b5)?_0x6c22b5['enterprise']['ready'](()=>{_0x6c22b5['enterprise']['execute'](_0x385519,{'action':_0x5e3d04})['then'](_0x135ca6=>{_0x50ae8e(_0x135ca6);})['catch'](()=>{_0x50ae8e(Fa);});}):_0x35177c(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x4e811d,_0x12640a)=>{_0x5b8663(this['auth'])['then'](async _0x3952ec=>{if(!_0x20a5a3&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x91bb5f(_0x3952ec,_0x4e811d,_0x12640a);else{if(typeof window>'u'){_0x12640a(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x17bf2b=Lf();_0x17bf2b['length']!==0x0&&(_0x17bf2b+=_0x3952ec+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x38a951;(_0x38a951=he['scriptInjectionDeferred'])==null||_0x38a951['resolve']();},xa(_0x17bf2b)['then'](()=>{var _0x345fce;return(_0x345fce=he['scriptInjectionDeferred'])==null?void 0x0:_0x345fce['promise'];})['then'](()=>{_0x91bb5f(_0x3952ec,_0x4e811d,_0x12640a);})['catch'](_0x380d4d=>{_0x12640a(_0x380d4d);});}})['catch'](_0x9d9117=>{_0x12640a(_0x9d9117);});});}}he['scriptInjectionDeferred']=null;async function kr(_0xbb437a,_0x4fd7b2,_0x314123,_0x41988e=!0x1,_0x563173=!0x1){const _0x5b324b=new he(_0xbb437a);let _0x477db0;if(_0x563173)_0x477db0=Fa;else try{_0x477db0=await _0x5b324b['verify'](_0x314123);}catch{_0x477db0=await _0x5b324b['verify'](_0x314123,!0x0);}const _0x35736e={..._0x4fd7b2};if(_0x314123==='mfaSmsEnrollment'||_0x314123==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x35736e){const _0x39c6b6=_0x35736e['phoneEnrollmentInfo']['phoneNumber'],_0x6aeaed=_0x35736e['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x35736e,{'phoneEnrollmentInfo':{'phoneNumber':_0x39c6b6,'recaptchaToken':_0x6aeaed,'captchaResponse':_0x477db0,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x35736e){const _0x134619=_0x35736e['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x35736e,{'phoneSignInInfo':{'recaptchaToken':_0x134619,'captchaResponse':_0x477db0,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x35736e;}return _0x41988e?Object['assign'](_0x35736e,{'captchaResp':_0x477db0}):Object['assign'](_0x35736e,{'captchaResponse':_0x477db0}),Object['assign'](_0x35736e,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x35736e,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x35736e;}async function xi(_0x3933e9,_0x3c6066,_0x5e28e7,_0x426b2b,_0x46598b){var _0x25ebbf;if((_0x25ebbf=_0x3933e9['_getRecaptchaConfig']())!=null&&_0x25ebbf['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x3e85ab=await kr(_0x3933e9,_0x3c6066,_0x5e28e7,_0x5e28e7==='getOobCode');return _0x426b2b(_0x3933e9,_0x3e85ab);}else return _0x426b2b(_0x3933e9,_0x3c6066)['catch'](async _0x3cfb7c=>{if(_0x3cfb7c['code']==='auth/missing-recaptcha-token'){console['log'](_0x5e28e7+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0xdc8fa7=await kr(_0x3933e9,_0x3c6066,_0x5e28e7,_0x5e28e7==='getOobCode');return _0x426b2b(_0x3933e9,_0xdc8fa7);}else return Promise['reject'](_0x3cfb7c);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x696d8c,_0x4f0f40){const _0x3b2692=Hi(_0x696d8c,'auth');if(_0x3b2692['isInitialized']()){const _0x1b1bc1=_0x3b2692['getImmediate'](),_0x263352=_0x3b2692['getOptions']();if(xe(_0x263352,_0x4f0f40??{}))return _0x1b1bc1;Y(_0x1b1bc1,'already-initialized');}return _0x3b2692['initialize']({'options':_0x4f0f40});}function Hf(_0x54c2e6,_0xea4137){const _0x4e6def=(_0xea4137==null?void 0x0:_0xea4137['persistence'])||[],_0x19fd29=(Array['isArray'](_0x4e6def)?_0x4e6def:[_0x4e6def])['map'](ie);_0xea4137!=null&&_0xea4137['errorMap']&&_0x54c2e6['_updateErrorMap'](_0xea4137['errorMap']),_0x54c2e6['_initializeWithPersistence'](_0x19fd29,_0xea4137==null?void 0x0:_0xea4137['popupRedirectResolver']);}function $f(_0x48474b,_0x40ec86,_0x1d44a6){const _0x2576ab=Ke(_0x48474b);m(/^https?:\/\//['test'](_0x40ec86),_0x2576ab,'invalid-emulator-scheme');const _0x575056=!0x1,_0x45f6dc=Ua(_0x40ec86),{host:_0x2ea039,port:_0x13f5eb}=Gf(_0x40ec86),_0x1af1a0=_0x13f5eb===null?'':':'+_0x13f5eb,_0x398611={'url':_0x45f6dc+'//'+_0x2ea039+_0x1af1a0+'/'},_0xaeb5de=Object['freeze']({'host':_0x2ea039,'port':_0x13f5eb,'protocol':_0x45f6dc['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x575056})});if(!_0x2576ab['_canInitEmulator']){m(_0x2576ab['config']['emulator']&&_0x2576ab['emulatorConfig'],_0x2576ab,'emulator-config-failed'),m(xe(_0x398611,_0x2576ab['config']['emulator'])&&xe(_0xaeb5de,_0x2576ab['emulatorConfig']),_0x2576ab,'emulator-config-failed');return;}_0x2576ab['config']['emulator']=_0x398611,_0x2576ab['emulatorConfig']=_0xaeb5de,_0x2576ab['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x2ea039)?Qr(_0x45f6dc+'//'+_0x2ea039+_0x1af1a0):qf();}function Ua(_0x1d0ac3){const _0x9e78be=_0x1d0ac3['indexOf'](':');return _0x9e78be<0x0?'':_0x1d0ac3['substr'](0x0,_0x9e78be+0x1);}function Gf(_0x3c64ab){const _0x459026=Ua(_0x3c64ab),_0x4499c1=/(\/\/)?([^?#/]+)/['exec'](_0x3c64ab['substr'](_0x459026['length']));if(!_0x4499c1)return{'host':'','port':null};const _0x4a9fdc=_0x4499c1[0x2]['split']('@')['pop']()||'',_0xbff3d2=/^(\[[^\]]+\])(:|$)/['exec'](_0x4a9fdc);if(_0xbff3d2){const _0x18e4a2=_0xbff3d2[0x1];return{'host':_0x18e4a2,'port':Pr(_0x4a9fdc['substr'](_0x18e4a2['length']+0x1))};}else{const [_0x45fe5d,_0x3af327]=_0x4a9fdc['split'](':');return{'host':_0x45fe5d,'port':Pr(_0x3af327)};}}function Pr(_0xb6bb8a){if(!_0xb6bb8a)return null;const _0x2cd33d=Number(_0xb6bb8a);return isNaN(_0x2cd33d)?null:_0x2cd33d;}function qf(){function _0x7fbda6(){const _0x5bbe4f=document['createElement']('p'),_0x2ef7c8=_0x5bbe4f['style'];_0x5bbe4f['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x2ef7c8['position']='fixed',_0x2ef7c8['width']='100%',_0x2ef7c8['backgroundColor']='#ffffff',_0x2ef7c8['border']='.1em\x20solid\x20#000000',_0x2ef7c8['color']='#b50000',_0x2ef7c8['bottom']='0px',_0x2ef7c8['left']='0px',_0x2ef7c8['margin']='0px',_0x2ef7c8['zIndex']='10000',_0x2ef7c8['textAlign']='center',_0x5bbe4f['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x5bbe4f);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x7fbda6):_0x7fbda6());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x241d5b,_0x4111ac){this['providerId']=_0x241d5b,this['signInMethod']=_0x4111ac;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x31c071){return ne('not\x20implemented');}['_linkToIdToken'](_0x576cee,_0x5a3eb9){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x2043bf){return ne('not\x20implemented');}}async function zf(_0x5da4b5,_0x3e7faf){return Pe(_0x5da4b5,'POST','/v1/accounts:signUp',_0x3e7faf);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x1c0b2d,_0x42a932){return en(_0x1c0b2d,'POST','/v1/accounts:signInWithPassword',ke(_0x1c0b2d,_0x42a932));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x4b9c5d,_0x58f4ac){return en(_0x4b9c5d,'POST','/v1/accounts:signInWithEmailLink',ke(_0x4b9c5d,_0x58f4ac));}async function Yf(_0x58ed8e,_0x1b3855){return en(_0x58ed8e,'POST','/v1/accounts:signInWithEmailLink',ke(_0x58ed8e,_0x1b3855));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x3e609b,_0xf1a59e,_0x48ee1d,_0x27cd27=null){super('password',_0x48ee1d),this['_email']=_0x3e609b,this['_password']=_0xf1a59e,this['_tenantId']=_0x27cd27;}static['_fromEmailAndPassword'](_0x1c016e,_0x2a4f4e){return new $t(_0x1c016e,_0x2a4f4e,'password');}static['_fromEmailAndCode'](_0x451a23,_0x590d2f,_0xf21848=null){return new $t(_0x451a23,_0x590d2f,'emailLink',_0xf21848);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x4c4662){const _0x5c2ec1=typeof _0x4c4662=='string'?JSON['parse'](_0x4c4662):_0x4c4662;if(_0x5c2ec1!=null&&_0x5c2ec1['email']&&(_0x5c2ec1!=null&&_0x5c2ec1['password'])){if(_0x5c2ec1['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x5c2ec1['email'],_0x5c2ec1['password']);if(_0x5c2ec1['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x5c2ec1['email'],_0x5c2ec1['password'],_0x5c2ec1['tenantId']);}return null;}async['_getIdTokenResponse'](_0x1190da){switch(this['signInMethod']){case'password':const _0x561e24={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x1190da,_0x561e24,'signInWithPassword',jf);case'emailLink':return Kf(_0x1190da,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x1190da,'internal-error');}}async['_linkToIdToken'](_0x42f556,_0x51bc3b){switch(this['signInMethod']){case'password':const _0x2a68dd={'idToken':_0x51bc3b,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x42f556,_0x2a68dd,'signUpPassword',zf);case'emailLink':return Yf(_0x42f556,{'idToken':_0x51bc3b,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x42f556,'internal-error');}}['_getReauthenticationResolver'](_0x2a4a11){return this['_getIdTokenResponse'](_0x2a4a11);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x32e9e5,_0x517b42){return en(_0x32e9e5,'POST','/v1/accounts:signInWithIdp',ke(_0x32e9e5,_0x517b42));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x4101f3){const _0x2c19c3=new $e(_0x4101f3['providerId'],_0x4101f3['signInMethod']);return _0x4101f3['idToken']||_0x4101f3['accessToken']?(_0x4101f3['idToken']&&(_0x2c19c3['idToken']=_0x4101f3['idToken']),_0x4101f3['accessToken']&&(_0x2c19c3['accessToken']=_0x4101f3['accessToken']),_0x4101f3['nonce']&&!_0x4101f3['pendingToken']&&(_0x2c19c3['nonce']=_0x4101f3['nonce']),_0x4101f3['pendingToken']&&(_0x2c19c3['pendingToken']=_0x4101f3['pendingToken'])):_0x4101f3['oauthToken']&&_0x4101f3['oauthTokenSecret']?(_0x2c19c3['accessToken']=_0x4101f3['oauthToken'],_0x2c19c3['secret']=_0x4101f3['oauthTokenSecret']):Y('argument-error'),_0x2c19c3;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x363064){const _0x165282=typeof _0x363064=='string'?JSON['parse'](_0x363064):_0x363064,{providerId:_0xad9a81,signInMethod:_0x37742a,..._0x1dd32f}=_0x165282;if(!_0xad9a81||!_0x37742a)return null;const _0x245676=new $e(_0xad9a81,_0x37742a);return _0x245676['idToken']=_0x1dd32f['idToken']||void 0x0,_0x245676['accessToken']=_0x1dd32f['accessToken']||void 0x0,_0x245676['secret']=_0x1dd32f['secret'],_0x245676['nonce']=_0x1dd32f['nonce'],_0x245676['pendingToken']=_0x1dd32f['pendingToken']||null,_0x245676;}['_getIdTokenResponse'](_0x40329d){const _0x9e78fd=this['buildRequest']();return nt(_0x40329d,_0x9e78fd);}['_linkToIdToken'](_0x14e676,_0x2d319c){const _0xbd27a8=this['buildRequest']();return _0xbd27a8['idToken']=_0x2d319c,nt(_0x14e676,_0xbd27a8);}['_getReauthenticationResolver'](_0x1ac7ae){const _0x1e1579=this['buildRequest']();return _0x1e1579['autoCreate']=!0x1,nt(_0x1ac7ae,_0x1e1579);}['buildRequest'](){const _0x1d7e09={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x1d7e09['pendingToken']=this['pendingToken'];else{const _0x5c404c={};this['idToken']&&(_0x5c404c['id_token']=this['idToken']),this['accessToken']&&(_0x5c404c['access_token']=this['accessToken']),this['secret']&&(_0x5c404c['oauth_token_secret']=this['secret']),_0x5c404c['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x5c404c['nonce']=this['nonce']),_0x1d7e09['postBody']=ut(_0x5c404c);}return _0x1d7e09;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x4ee599){switch(_0x4ee599){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x22b93a){const _0x4e6849=Ct(Tt(_0x22b93a))['link'],_0x5b2d2f=_0x4e6849?Ct(Tt(_0x4e6849))['deep_link_id']:null,_0x589134=Ct(Tt(_0x22b93a))['deep_link_id'];return(_0x589134?Ct(Tt(_0x589134))['link']:null)||_0x589134||_0x5b2d2f||_0x4e6849||_0x22b93a;}class Rs{constructor(_0x2f924f){const _0xe284ed=Ct(Tt(_0x2f924f)),_0x1cc990=_0xe284ed['apiKey']??null,_0xdd89f9=_0xe284ed['oobCode']??null,_0x3aea21=Jf(_0xe284ed['mode']??null);m(_0x1cc990&&_0xdd89f9&&_0x3aea21,'argument-error'),this['apiKey']=_0x1cc990,this['operation']=_0x3aea21,this['code']=_0xdd89f9,this['continueUrl']=_0xe284ed['continueUrl']??null,this['languageCode']=_0xe284ed['lang']??null,this['tenantId']=_0xe284ed['tenantId']??null;}static['parseLink'](_0x3a58ab){const _0x3300bc=Xf(_0x3a58ab);try{return new Rs(_0x3300bc);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x55dce4,_0x25559a){return $t['_fromEmailAndPassword'](_0x55dce4,_0x25559a);}static['credentialWithLink'](_0x3eaaaa,_0x4f8f8b){const _0x1fb21b=Rs['parseLink'](_0x4f8f8b);return m(_0x1fb21b,'argument-error'),$t['_fromEmailAndCode'](_0x3eaaaa,_0x1fb21b['code'],_0x1fb21b['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x467b59){this['providerId']=_0x467b59,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x4012c0){this['defaultLanguageCode']=_0x4012c0;}['setCustomParameters'](_0x30c142){return this['customParameters']=_0x30c142,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x28aa73){return this['scopes']['includes'](_0x28aa73)||this['scopes']['push'](_0x28aa73),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x589978){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x589978});}static['credentialFromResult'](_0x4f8e01){return ue['credentialFromTaggedObject'](_0x4f8e01);}static['credentialFromError'](_0x2c9cc1){return ue['credentialFromTaggedObject'](_0x2c9cc1['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1472e6}){if(!_0x1472e6||!('oauthAccessToken'in _0x1472e6)||!_0x1472e6['oauthAccessToken'])return null;try{return ue['credential'](_0x1472e6['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x3e4ec3,_0x115623){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x3e4ec3,'accessToken':_0x115623});}static['credentialFromResult'](_0x48865a){return de['credentialFromTaggedObject'](_0x48865a);}static['credentialFromError'](_0xe7bf53){return de['credentialFromTaggedObject'](_0xe7bf53['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x5d544d}){if(!_0x5d544d)return null;const {oauthIdToken:_0x5f4108,oauthAccessToken:_0x2c5e31}=_0x5d544d;if(!_0x5f4108&&!_0x2c5e31)return null;try{return de['credential'](_0x5f4108,_0x2c5e31);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x34f646){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x34f646});}static['credentialFromResult'](_0x1090a4){return fe['credentialFromTaggedObject'](_0x1090a4);}static['credentialFromError'](_0x49c25d){return fe['credentialFromTaggedObject'](_0x49c25d['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x542212}){if(!_0x542212||!('oauthAccessToken'in _0x542212)||!_0x542212['oauthAccessToken'])return null;try{return fe['credential'](_0x542212['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x1c9071,_0x550e63){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x1c9071,'oauthTokenSecret':_0x550e63});}static['credentialFromResult'](_0x3dcf53){return pe['credentialFromTaggedObject'](_0x3dcf53);}static['credentialFromError'](_0xa631cb){return pe['credentialFromTaggedObject'](_0xa631cb['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x2450c8}){if(!_0x2450c8)return null;const {oauthAccessToken:_0x2f84c9,oauthTokenSecret:_0x1ae9cb}=_0x2450c8;if(!_0x2f84c9||!_0x1ae9cb)return null;try{return pe['credential'](_0x2f84c9,_0x1ae9cb);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x1394bc,_0x25b791){return en(_0x1394bc,'POST','/v1/accounts:signUp',ke(_0x1394bc,_0x25b791));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x206146){this['user']=_0x206146['user'],this['providerId']=_0x206146['providerId'],this['_tokenResponse']=_0x206146['_tokenResponse'],this['operationType']=_0x206146['operationType'];}static async['_fromIdTokenResponse'](_0x43ea56,_0x21c690,_0x311a9f,_0x51ea3d=!0x1){const _0x1dd02e=await j['_fromIdTokenResponse'](_0x43ea56,_0x311a9f,_0x51ea3d),_0x3a84fa=Nr(_0x311a9f);return new Ge({'user':_0x1dd02e,'providerId':_0x3a84fa,'_tokenResponse':_0x311a9f,'operationType':_0x21c690});}static async['_forOperation'](_0x2b0ade,_0x4e2343,_0x3c1240){await _0x2b0ade['_updateTokensIfNecessary'](_0x3c1240,!0x0);const _0x412d22=Nr(_0x3c1240);return new Ge({'user':_0x2b0ade,'providerId':_0x412d22,'_tokenResponse':_0x3c1240,'operationType':_0x4e2343});}}function Nr(_0x14c0bb){return _0x14c0bb['providerId']?_0x14c0bb['providerId']:'phoneNumber'in _0x14c0bb?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x43441c,_0x3f8285,_0x175f02,_0x2b6705){super(_0x3f8285['code'],_0x3f8285['message']),this['operationType']=_0x175f02,this['user']=_0x2b6705,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x43441c['name'],'tenantId':_0x43441c['tenantId']??void 0x0,'_serverResponse':_0x3f8285['customData']['_serverResponse'],'operationType':_0x175f02};}static['_fromErrorAndOperation'](_0x20f25a,_0x4ef21c,_0x4897e7,_0x48f98c){return new On(_0x20f25a,_0x4ef21c,_0x4897e7,_0x48f98c);}}function Ba(_0x236d03,_0x5a4e7f,_0x4ffe7a,_0x3ffd1c){return(_0x5a4e7f==='reauthenticate'?_0x4ffe7a['_getReauthenticationResolver'](_0x236d03):_0x4ffe7a['_getIdTokenResponse'](_0x236d03))['catch'](_0xc52beb=>{throw _0xc52beb['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x236d03,_0xc52beb,_0x5a4e7f,_0x3ffd1c):_0xc52beb;});}async function ep(_0x161bc6,_0x438540,_0x522450=!0x1){const _0x20c49a=await Ht(_0x161bc6,_0x438540['_linkToIdToken'](_0x161bc6['auth'],await _0x161bc6['getIdToken']()),_0x522450);return Ge['_forOperation'](_0x161bc6,'link',_0x20c49a);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x2b02fb,_0x586160,_0x4cfcb3=!0x1){const {auth:_0x1fac59}=_0x2b02fb;if($(_0x1fac59['app']))return Promise['reject'](re(_0x1fac59));const _0xa05fc8='reauthenticate';try{const _0xbf838e=await Ht(_0x2b02fb,Ba(_0x1fac59,_0xa05fc8,_0x586160,_0x2b02fb),_0x4cfcb3);m(_0xbf838e['idToken'],_0x1fac59,'internal-error');const _0x1accab=Ts(_0xbf838e['idToken']);m(_0x1accab,_0x1fac59,'internal-error');const {sub:_0x112f5c}=_0x1accab;return m(_0x2b02fb['uid']===_0x112f5c,_0x1fac59,'user-mismatch'),Ge['_forOperation'](_0x2b02fb,_0xa05fc8,_0xbf838e);}catch(_0x4c2251){throw(_0x4c2251==null?void 0x0:_0x4c2251['code'])==='auth/user-not-found'&&Y(_0x1fac59,'user-mismatch'),_0x4c2251;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x507877,_0x425b49,_0x36bcfd=!0x1){if($(_0x507877['app']))return Promise['reject'](re(_0x507877));const _0xda3a3c='signIn',_0x502299=await Ba(_0x507877,_0xda3a3c,_0x425b49),_0x531819=await Ge['_fromIdTokenResponse'](_0x507877,_0xda3a3c,_0x502299);return _0x36bcfd||await _0x507877['_updateCurrentUser'](_0x531819['user']),_0x531819;}async function np(_0x3f0f33,_0x1c1616){return Va(Ke(_0x3f0f33),_0x1c1616);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x2df66f){const _0x131228=Ke(_0x2df66f);_0x131228['_getPasswordPolicyInternal']()&&await _0x131228['_updatePasswordPolicy']();}async function L_(_0x17b1e0,_0x4650f4,_0x266077){if($(_0x17b1e0['app']))return Promise['reject'](re(_0x17b1e0));const _0x5cfad1=Ke(_0x17b1e0),_0x50d07e=await xi(_0x5cfad1,{'returnSecureToken':!0x0,'email':_0x4650f4,'password':_0x266077,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x473eff=>{throw _0x473eff['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x17b1e0),_0x473eff;}),_0x4cff25=await Ge['_fromIdTokenResponse'](_0x5cfad1,'signIn',_0x50d07e);return await _0x5cfad1['_updateCurrentUser'](_0x4cff25['user']),_0x4cff25;}function x_(_0xa74f99,_0x9ad7e5,_0x45e55f){return $(_0xa74f99['app'])?Promise['reject'](re(_0xa74f99)):np(P(_0xa74f99),yt['credential'](_0x9ad7e5,_0x45e55f))['catch'](async _0x335727=>{throw _0x335727['code']==='auth/password-does-not-meet-requirements'&&Ha(_0xa74f99),_0x335727;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0xb98ec2,_0x857d2b){return P(_0xb98ec2)['setPersistence'](_0x857d2b);}function ip(_0x41f627,_0x46aa7f,_0x2dc925,_0x128b71){return P(_0x41f627)['onIdTokenChanged'](_0x46aa7f,_0x2dc925,_0x128b71);}function sp(_0x28e16c,_0x2465e9,_0x297934){return P(_0x28e16c)['beforeAuthStateChanged'](_0x2465e9,_0x297934);}function U_(_0x3192d3,_0x50a288,_0x292c74,_0x5d93f7){return P(_0x3192d3)['onAuthStateChanged'](_0x50a288,_0x292c74,_0x5d93f7);}function W_(_0x49726f){return P(_0x49726f)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x26652e,_0x47d749){this['storageRetriever']=_0x26652e,this['type']=_0x47d749;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x1d83d4,_0xc1e4f9){return this['storage']['setItem'](_0x1d83d4,JSON['stringify'](_0xc1e4f9)),Promise['resolve']();}['_get'](_0x26eb3d){const _0x5a3a86=this['storage']['getItem'](_0x26eb3d);return Promise['resolve'](_0x5a3a86?JSON['parse'](_0x5a3a86):null);}['_remove'](_0x68e026){return this['storage']['removeItem'](_0x68e026),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x1b729e,_0x32b4b3)=>this['onStorageEvent'](_0x1b729e,_0x32b4b3),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x1e4547){for(const _0x3aa067 of Object['keys'](this['listeners'])){const _0xfaf389=this['storage']['getItem'](_0x3aa067),_0x4d446c=this['localCache'][_0x3aa067];_0xfaf389!==_0x4d446c&&_0x1e4547(_0x3aa067,_0x4d446c,_0xfaf389);}}['onStorageEvent'](_0x585be4,_0xf5b618=!0x1){if(!_0x585be4['key']){this['forAllChangedKeys']((_0x39914e,_0x52411f,_0x545c41)=>{this['notifyListeners'](_0x39914e,_0x545c41);});return;}const _0x22aec0=_0x585be4['key'];_0xf5b618?this['detachListener']():this['stopPolling']();const _0x377384=()=>{const _0x33bdd8=this['storage']['getItem'](_0x22aec0);!_0xf5b618&&this['localCache'][_0x22aec0]===_0x33bdd8||this['notifyListeners'](_0x22aec0,_0x33bdd8);},_0x19264d=this['storage']['getItem'](_0x22aec0);Af()&&_0x19264d!==_0x585be4['newValue']&&_0x585be4['newValue']!==_0x585be4['oldValue']?setTimeout(_0x377384,op):_0x377384();}['notifyListeners'](_0x559584,_0x3b958e){this['localCache'][_0x559584]=_0x3b958e;const _0x576491=this['listeners'][_0x559584];if(_0x576491){for(const _0x1e0619 of Array['from'](_0x576491))_0x1e0619(_0x3b958e&&JSON['parse'](_0x3b958e));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x205c9d,_0x2835fd,_0x2fab3e)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x205c9d,'oldValue':_0x2835fd,'newValue':_0x2fab3e}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x175450,_0x1ae064){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x175450]||(this['listeners'][_0x175450]=new Set(),this['localCache'][_0x175450]=this['storage']['getItem'](_0x175450)),this['listeners'][_0x175450]['add'](_0x1ae064);}['_removeListener'](_0x4301b0,_0x5bb8c7){this['listeners'][_0x4301b0]&&(this['listeners'][_0x4301b0]['delete'](_0x5bb8c7),this['listeners'][_0x4301b0]['size']===0x0&&delete this['listeners'][_0x4301b0]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x2b1040,_0x5c4c11){await super['_set'](_0x2b1040,_0x5c4c11),this['localCache'][_0x2b1040]=JSON['stringify'](_0x5c4c11);}async['_get'](_0x2da304){const _0x35ca87=await super['_get'](_0x2da304);return this['localCache'][_0x2da304]=JSON['stringify'](_0x35ca87),_0x35ca87;}async['_remove'](_0x370c67){await super['_remove'](_0x370c67),delete this['localCache'][_0x370c67];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x1e42bc,_0x540213){}['_removeListener'](_0x104108,_0x4b8080){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x27659b){return Promise['all'](_0x27659b['map'](async _0x3fc831=>{try{return{'fulfilled':!0x0,'value':await _0x3fc831};}catch(_0x622626){return{'fulfilled':!0x1,'reason':_0x622626};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x1064c5){this['eventTarget']=_0x1064c5,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x428a89){const _0x4f72ed=this['receivers']['find'](_0x5642a5=>_0x5642a5['isListeningto'](_0x428a89));if(_0x4f72ed)return _0x4f72ed;const _0x55c88c=new Xn(_0x428a89);return this['receivers']['push'](_0x55c88c),_0x55c88c;}['isListeningto'](_0x44c15c){return this['eventTarget']===_0x44c15c;}async['handleEvent'](_0x380675){const _0x48be74=_0x380675,{eventId:_0x5cbd5d,eventType:_0x33bfd4,data:_0x205e4e}=_0x48be74['data'],_0x434064=this['handlersMap'][_0x33bfd4];if(!(_0x434064!=null&&_0x434064['size']))return;_0x48be74['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x5cbd5d,'eventType':_0x33bfd4});const _0x203530=Array['from'](_0x434064)['map'](async _0x5b6a19=>_0x5b6a19(_0x48be74['origin'],_0x205e4e)),_0x35ec60=await cp(_0x203530);_0x48be74['ports'][0x0]['postMessage']({'status':'done','eventId':_0x5cbd5d,'eventType':_0x33bfd4,'response':_0x35ec60});}['_subscribe'](_0x47657d,_0x57f3f4){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x47657d]||(this['handlersMap'][_0x47657d]=new Set()),this['handlersMap'][_0x47657d]['add'](_0x57f3f4);}['_unsubscribe'](_0x296fe5,_0x521004){this['handlersMap'][_0x296fe5]&&_0x521004&&this['handlersMap'][_0x296fe5]['delete'](_0x521004),(!_0x521004||this['handlersMap'][_0x296fe5]['size']===0x0)&&delete this['handlersMap'][_0x296fe5],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x17ac42='',_0x2f3e27=0xa){let _0x47e33c='';for(let _0x566780=0x0;_0x566780<_0x2f3e27;_0x566780++)_0x47e33c+=Math['floor'](Math['random']()*0xa);return _0x17ac42+_0x47e33c;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x1e12d2){this['target']=_0x1e12d2,this['handlers']=new Set();}['removeMessageHandler'](_0x4ff2ea){_0x4ff2ea['messageChannel']&&(_0x4ff2ea['messageChannel']['port1']['removeEventListener']('message',_0x4ff2ea['onMessage']),_0x4ff2ea['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x4ff2ea);}async['_send'](_0x58b9ea,_0x5e4e40,_0x3f2ea0=0x32){const _0x765648=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x765648)throw new Error('connection_unavailable');let _0xc7bbb9,_0x312ebb;return new Promise((_0x350c97,_0x3f9a84)=>{const _0x57be49=As('',0x14);_0x765648['port1']['start']();const _0x3d964c=setTimeout(()=>{_0x3f9a84(new Error('unsupported_event'));},_0x3f2ea0);_0x312ebb={'messageChannel':_0x765648,'onMessage'(_0x21db9f){const _0x44f4b7=_0x21db9f;if(_0x44f4b7['data']['eventId']===_0x57be49)switch(_0x44f4b7['data']['status']){case'ack':clearTimeout(_0x3d964c),_0xc7bbb9=setTimeout(()=>{_0x3f9a84(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0xc7bbb9),_0x350c97(_0x44f4b7['data']['response']);break;default:clearTimeout(_0x3d964c),clearTimeout(_0xc7bbb9),_0x3f9a84(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x312ebb),_0x765648['port1']['addEventListener']('message',_0x312ebb['onMessage']),this['target']['postMessage']({'eventType':_0x58b9ea,'eventId':_0x57be49,'data':_0x5e4e40},[_0x765648['port2']]);})['finally'](()=>{_0x312ebb&&this['removeMessageHandler'](_0x312ebb);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x47177f){Z()['location']['href']=_0x47177f;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x52a043;return((_0x52a043=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x52a043['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x3a9b0c){this['request']=_0x3a9b0c;}['toPromise'](){return new Promise((_0x3897bb,_0x16d709)=>{this['request']['addEventListener']('success',()=>{_0x3897bb(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x16d709(this['request']['error']);});});}}function Zn(_0x5d3d5f,_0x2778bd){return _0x5d3d5f['transaction']([Mn],_0x2778bd?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x17fb8a=indexedDB['deleteDatabase'](Ka);return new nn(_0x17fb8a)['toPromise']();}function Qa(){const _0x2fa799=indexedDB['open'](Ka,pp);return new Promise((_0x487704,_0x1e9c3a)=>{_0x2fa799['addEventListener']('error',()=>{_0x1e9c3a(_0x2fa799['error']);}),_0x2fa799['addEventListener']('upgradeneeded',()=>{const _0x5ed9cc=_0x2fa799['result'];try{_0x5ed9cc['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x446b6a){_0x1e9c3a(_0x446b6a);}}),_0x2fa799['addEventListener']('success',async()=>{const _0x4e10bb=_0x2fa799['result'];_0x4e10bb['objectStoreNames']['contains'](Mn)?_0x487704(_0x4e10bb):(_0x4e10bb['close'](),await _p(),_0x487704(await Qa()));});});}async function Or(_0x313bc3,_0x111b8f,_0xf7d4ae){const _0x469060=Zn(_0x313bc3,!0x0)['put']({[Ya]:_0x111b8f,'value':_0xf7d4ae});return new nn(_0x469060)['toPromise']();}async function gp(_0x30172b,_0x2cb715){const _0x5f0296=Zn(_0x30172b,!0x1)['get'](_0x2cb715),_0x51c69c=await new nn(_0x5f0296)['toPromise']();return _0x51c69c===void 0x0?null:_0x51c69c['value'];}function Dr(_0x1b516d,_0x2b359f){const _0x12b36b=Zn(_0x1b516d,!0x0)['delete'](_0x2b359f);return new nn(_0x12b36b)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x5a3807){let _0x1405ea=0x0;for(;;)try{const _0x2d9bee=await this['_openDb']();return await _0x5a3807(_0x2d9bee);}catch(_0x18d024){if(_0x1405ea++>yp)throw _0x18d024;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x298adf,_0x29e37f)=>({'keyProcessed':(await this['_poll']())['includes'](_0x29e37f['key'])})),this['receiver']['_subscribe']('ping',async(_0x2e393e,_0x4b8f98)=>['keyChanged']);}async['initializeSender'](){var _0x4a84e9,_0x5308c1;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x6dde42=await this['sender']['_send']('ping',{},0x320);_0x6dde42&&(_0x4a84e9=_0x6dde42[0x0])!=null&&_0x4a84e9['fulfilled']&&(_0x5308c1=_0x6dde42[0x0])!=null&&_0x5308c1['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x559931){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x559931},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x246643=>{await Or(_0x246643,Dn,'1'),await Dr(_0x246643,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x79a844){this['pendingWrites']++;try{await _0x79a844();}finally{this['pendingWrites']--;}}async['_set'](_0x52ecbf,_0x35607d){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x3cb337=>Or(_0x3cb337,_0x52ecbf,_0x35607d)),this['localCache'][_0x52ecbf]=_0x35607d,this['notifyServiceWorker'](_0x52ecbf)));}async['_get'](_0x4da443){const _0x38d3b6=await this['_withRetries'](_0x335ca1=>gp(_0x335ca1,_0x4da443));return this['localCache'][_0x4da443]=_0x38d3b6,_0x38d3b6;}async['_remove'](_0x28b0ab){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x5165a3=>Dr(_0x5165a3,_0x28b0ab)),delete this['localCache'][_0x28b0ab],this['notifyServiceWorker'](_0x28b0ab)));}async['_poll'](){const _0x1d9c5c=await this['_withRetries'](_0x1f0901=>{const _0x2a5124=Zn(_0x1f0901,!0x1)['getAll']();return new nn(_0x2a5124)['toPromise']();});if(!_0x1d9c5c)return[];if(this['pendingWrites']!==0x0)return[];const _0xa960af=[],_0x432ef4=new Set();if(_0x1d9c5c['length']!==0x0){for(const {fbase_key:_0x142dee,value:_0x2d9ac7}of _0x1d9c5c)_0x432ef4['add'](_0x142dee),JSON['stringify'](this['localCache'][_0x142dee])!==JSON['stringify'](_0x2d9ac7)&&(this['notifyListeners'](_0x142dee,_0x2d9ac7),_0xa960af['push'](_0x142dee));}for(const _0x3888ea of Object['keys'](this['localCache']))this['localCache'][_0x3888ea]&&!_0x432ef4['has'](_0x3888ea)&&(this['notifyListeners'](_0x3888ea,null),_0xa960af['push'](_0x3888ea));return _0xa960af;}['notifyListeners'](_0x174a0c,_0x3cf09a){this['localCache'][_0x174a0c]=_0x3cf09a;const _0x47e2b3=this['listeners'][_0x174a0c];if(_0x47e2b3){for(const _0x1c6540 of Array['from'](_0x47e2b3))_0x1c6540(_0x3cf09a);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x575d5a,_0x5332b8){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x575d5a]||(this['listeners'][_0x575d5a]=new Set(),this['_get'](_0x575d5a)),this['listeners'][_0x575d5a]['add'](_0x5332b8);}['_removeListener'](_0x1675ff,_0x407bd5){this['listeners'][_0x1675ff]&&(this['listeners'][_0x1675ff]['delete'](_0x407bd5),this['listeners'][_0x1675ff]['size']===0x0&&delete this['listeners'][_0x1675ff]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x452661,_0xf86a9d){return _0xf86a9d?ie(_0xf86a9d):(m(_0x452661['_popupRedirectResolver'],_0x452661,'argument-error'),_0x452661['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x1fd644){super('custom','custom'),this['params']=_0x1fd644;}['_getIdTokenResponse'](_0x12dcb7){return nt(_0x12dcb7,this['_buildIdpRequest']());}['_linkToIdToken'](_0x41f07c,_0x2e5c91){return nt(_0x41f07c,this['_buildIdpRequest'](_0x2e5c91));}['_getReauthenticationResolver'](_0x3bdafe){return nt(_0x3bdafe,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x256cd2){const _0x2a29e2={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x256cd2&&(_0x2a29e2['idToken']=_0x256cd2),_0x2a29e2;}}function Ip(_0x28c693){return Va(_0x28c693['auth'],new ks(_0x28c693),_0x28c693['bypassAuthState']);}function wp(_0x1fe97a){const {auth:_0x5ebdd3,user:_0x1bccf5}=_0x1fe97a;return m(_0x1bccf5,_0x5ebdd3,'internal-error'),tp(_0x1bccf5,new ks(_0x1fe97a),_0x1fe97a['bypassAuthState']);}async function Cp(_0x5b6688){const {auth:_0xa32eee,user:_0x307a8a}=_0x5b6688;return m(_0x307a8a,_0xa32eee,'internal-error'),ep(_0x307a8a,new ks(_0x5b6688),_0x5b6688['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x25be9c,_0x467608,_0x2aa368,_0x48d9b1,_0x2720c5=!0x1){this['auth']=_0x25be9c,this['resolver']=_0x2aa368,this['user']=_0x48d9b1,this['bypassAuthState']=_0x2720c5,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x467608)?_0x467608:[_0x467608];}['execute'](){return new Promise(async(_0x42abbf,_0x37ed5c)=>{this['pendingPromise']={'resolve':_0x42abbf,'reject':_0x37ed5c};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x12cba8){this['reject'](_0x12cba8);}});}async['onAuthEvent'](_0x2f321b){const {urlResponse:_0x1b2ddc,sessionId:_0x53e439,postBody:_0x5b98c9,tenantId:_0x3e7e3a,error:_0x1f1ffd,type:_0x10fea7}=_0x2f321b;if(_0x1f1ffd){this['reject'](_0x1f1ffd);return;}const _0x434a97={'auth':this['auth'],'requestUri':_0x1b2ddc,'sessionId':_0x53e439,'tenantId':_0x3e7e3a||void 0x0,'postBody':_0x5b98c9||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x10fea7)(_0x434a97));}catch(_0x1d4447){this['reject'](_0x1d4447);}}['onError'](_0x5e955a){this['reject'](_0x5e955a);}['getIdpTask'](_0x45134c){switch(_0x45134c){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x1cbc5e){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x1cbc5e),this['unregisterAndCleanUp']();}['reject'](_0x73c969){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x73c969),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x721041,_0x1fe2bd,_0xfeaec5,_0x54e285,_0x2fe48){super(_0x721041,_0x1fe2bd,_0x54e285,_0x2fe48),this['provider']=_0xfeaec5,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x1e9404=await this['execute']();return m(_0x1e9404,this['auth'],'internal-error'),_0x1e9404;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x18862d=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x18862d),this['authWindow']['associatedEvent']=_0x18862d,this['resolver']['_originValidation'](this['auth'])['catch'](_0x11e5d9=>{this['reject'](_0x11e5d9);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x5588e0=>{_0x5588e0||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x4ce62d;return((_0x4ce62d=this['authWindow'])==null?void 0x0:_0x4ce62d['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x1d773e=()=>{var _0x11d9fa,_0x839843;if((_0x839843=(_0x11d9fa=this['authWindow'])==null?void 0x0:_0x11d9fa['window'])!=null&&_0x839843['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x1d773e,Tp['get']());};_0x1d773e();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x597fc6,_0x3add40,_0xc4bb42=!0x1){super(_0x597fc6,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x3add40,void 0x0,_0xc4bb42),this['eventId']=null;}async['execute'](){let _0x31e4d7=hn['get'](this['auth']['_key']());if(!_0x31e4d7){try{const _0x3c8be8=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x31e4d7=()=>Promise['resolve'](_0x3c8be8);}catch(_0x37ccb0){_0x31e4d7=()=>Promise['reject'](_0x37ccb0);}hn['set'](this['auth']['_key'](),_0x31e4d7);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x31e4d7();}async['onAuthEvent'](_0x4e6a96){if(_0x4e6a96['type']==='signInViaRedirect')return super['onAuthEvent'](_0x4e6a96);if(_0x4e6a96['type']==='unknown'){this['resolve'](null);return;}if(_0x4e6a96['eventId']){const _0x3e24d3=await this['auth']['_redirectUserForId'](_0x4e6a96['eventId']);if(_0x3e24d3)return this['user']=_0x3e24d3,super['onAuthEvent'](_0x4e6a96);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x2012ae,_0x47246e){const _0x2b2097=Pp(_0x47246e),_0x437ecf=kp(_0x2012ae);if(!await _0x437ecf['_isAvailable']())return!0x1;const _0x2876a3=await _0x437ecf['_get'](_0x2b2097)==='true';return await _0x437ecf['_remove'](_0x2b2097),_0x2876a3;}function Ap(_0x3bbd1a,_0x41568a){hn['set'](_0x3bbd1a['_key'](),_0x41568a);}function kp(_0xc2e12e){return ie(_0xc2e12e['_redirectPersistence']);}function Pp(_0x8c05a1){return ln(Sp,_0x8c05a1['config']['apiKey'],_0x8c05a1['name']);}async function Np(_0x76a0c0,_0xebef5f,_0x5f455a=!0x1){if($(_0x76a0c0['app']))return Promise['reject'](re(_0x76a0c0));const _0x2c5047=Ke(_0x76a0c0),_0xdb8d0f=Ep(_0x2c5047,_0xebef5f),_0x3aa321=await new bp(_0x2c5047,_0xdb8d0f,_0x5f455a)['execute']();return _0x3aa321&&!_0x5f455a&&(delete _0x3aa321['user']['_redirectEventId'],await _0x2c5047['_persistUserIfCurrent'](_0x3aa321['user']),await _0x2c5047['_setRedirectUser'](null,_0xebef5f)),_0x3aa321;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x3169a8){this['auth']=_0x3169a8,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x299f95){this['consumers']['add'](_0x299f95),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x299f95)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x299f95),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x3df848){this['consumers']['delete'](_0x3df848);}['onEvent'](_0x3b76e7){if(this['hasEventBeenHandled'](_0x3b76e7))return!0x1;let _0x16b055=!0x1;return this['consumers']['forEach'](_0x5436ec=>{this['isEventForConsumer'](_0x3b76e7,_0x5436ec)&&(_0x16b055=!0x0,this['sendToConsumer'](_0x3b76e7,_0x5436ec),this['saveEventToCache'](_0x3b76e7));}),this['hasHandledPotentialRedirect']||!Mp(_0x3b76e7)||(this['hasHandledPotentialRedirect']=!0x0,_0x16b055||(this['queuedRedirectEvent']=_0x3b76e7,_0x16b055=!0x0)),_0x16b055;}['sendToConsumer'](_0x396022,_0x418a11){var _0x1de33d;if(_0x396022['error']&&!Za(_0x396022)){const _0x462e25=((_0x1de33d=_0x396022['error']['code'])==null?void 0x0:_0x1de33d['split']('auth/')[0x1])||'internal-error';_0x418a11['onError'](X(this['auth'],_0x462e25));}else _0x418a11['onAuthEvent'](_0x396022);}['isEventForConsumer'](_0x4cb7f6,_0x496051){const _0xa4b5d9=_0x496051['eventId']===null||!!_0x4cb7f6['eventId']&&_0x4cb7f6['eventId']===_0x496051['eventId'];return _0x496051['filter']['includes'](_0x4cb7f6['type'])&&_0xa4b5d9;}['hasEventBeenHandled'](_0x23d942){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x23d942));}['saveEventToCache'](_0x42fe23){this['cachedEventUids']['add'](Mr(_0x42fe23)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x25e51f){return[_0x25e51f['type'],_0x25e51f['eventId'],_0x25e51f['sessionId'],_0x25e51f['tenantId']]['filter'](_0x35f43c=>_0x35f43c)['join']('-');}function Za({type:_0x5987ba,error:_0x41d71}){return _0x5987ba==='unknown'&&(_0x41d71==null?void 0x0:_0x41d71['code'])==='auth/no-auth-event';}function Mp(_0x11cb50){switch(_0x11cb50['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x11cb50);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x1d0116,_0xbe1ca9={}){return Pe(_0x1d0116,'GET','/v1/projects',_0xbe1ca9);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x35bdce){if(_0x35bdce['config']['emulator'])return;const {authorizedDomains:_0x53f1fc}=await Lp(_0x35bdce);for(const _0x149034 of _0x53f1fc)try{if(Wp(_0x149034))return;}catch{}Y(_0x35bdce,'unauthorized-domain');}function Wp(_0x19df32){const _0x4c2b9c=Mi(),{protocol:_0x354ef8,hostname:_0x363882}=new URL(_0x4c2b9c);if(_0x19df32['startsWith']('chrome-extension://')){const _0x6b4e87=new URL(_0x19df32);return _0x6b4e87['hostname']===''&&_0x363882===''?_0x354ef8==='chrome-extension:'&&_0x19df32['replace']('chrome-extension://','')===_0x4c2b9c['replace']('chrome-extension://',''):_0x354ef8==='chrome-extension:'&&_0x6b4e87['hostname']===_0x363882;}if(!Fp['test'](_0x354ef8))return!0x1;if(xp['test'](_0x19df32))return _0x363882===_0x19df32;const _0x361afe=_0x19df32['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x361afe+'|'+_0x361afe+')$','i')['test'](_0x363882);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x2088f5=Z()['___jsl'];if(_0x2088f5!=null&&_0x2088f5['H']){for(const _0x2dc607 of Object['keys'](_0x2088f5['H']))if(_0x2088f5['H'][_0x2dc607]['r']=_0x2088f5['H'][_0x2dc607]['r']||[],_0x2088f5['H'][_0x2dc607]['L']=_0x2088f5['H'][_0x2dc607]['L']||[],_0x2088f5['H'][_0x2dc607]['r']=[..._0x2088f5['H'][_0x2dc607]['L']],_0x2088f5['CP']){for(let _0x5bc158=0x0;_0x5bc158<_0x2088f5['CP']['length'];_0x5bc158++)_0x2088f5['CP'][_0x5bc158]=null;}}}function Vp(_0x23cbea){return new Promise((_0x2d7d12,_0x4f6f9e)=>{var _0x29d0fc,_0xb233d4,_0x5a681f;function _0x2e4248(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x2d7d12(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x4f6f9e(X(_0x23cbea,'network-request-failed'));},'timeout':Bp['get']()});}if((_0xb233d4=(_0x29d0fc=Z()['gapi'])==null?void 0x0:_0x29d0fc['iframes'])!=null&&_0xb233d4['Iframe'])_0x2d7d12(gapi['iframes']['getContext']());else{if((_0x5a681f=Z()['gapi'])!=null&&_0x5a681f['load'])_0x2e4248();else{const _0x14288f=Ff('iframefcb');return Z()[_0x14288f]=()=>{gapi['load']?_0x2e4248():_0x4f6f9e(X(_0x23cbea,'network-request-failed'));},xa(xf()+'?onload='+_0x14288f)['catch'](_0x327cd8=>_0x4f6f9e(_0x327cd8));}}})['catch'](_0x2653f4=>{throw un=null,_0x2653f4;});}let un=null;function Hp(_0x5ab9bd){return un=un||Vp(_0x5ab9bd),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x1fb552){const _0x492d0e=_0x1fb552['config'];m(_0x492d0e['authDomain'],_0x1fb552,'auth-domain-config-required');const _0x126272=_0x492d0e['emulator']?Cs(_0x492d0e,qp):'https://'+_0x1fb552['config']['authDomain']+'/'+Gp,_0x3715ee={'apiKey':_0x492d0e['apiKey'],'appName':_0x1fb552['name'],'v':dt},_0xcfa1d0=jp['get'](_0x1fb552['config']['apiHost']);_0xcfa1d0&&(_0x3715ee['eid']=_0xcfa1d0);const _0x148ef9=_0x1fb552['_getFrameworks']();return _0x148ef9['length']&&(_0x3715ee['fw']=_0x148ef9['join'](',')),_0x126272+'?'+ut(_0x3715ee)['slice'](0x1);}async function Yp(_0x135570){const _0x360531=await Hp(_0x135570),_0x2fd1da=Z()['gapi'];return m(_0x2fd1da,_0x135570,'internal-error'),_0x360531['open']({'where':document['body'],'url':Kp(_0x135570),'messageHandlersFilter':_0x2fd1da['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x5a8228=>new Promise(async(_0x5e5d95,_0x4c3d3f)=>{await _0x5a8228['restyle']({'setHideOnLeave':!0x1});const _0x9acc87=X(_0x135570,'network-request-failed'),_0x5bc4b1=Z()['setTimeout'](()=>{_0x4c3d3f(_0x9acc87);},$p['get']());function _0x1e3ce2(){Z()['clearTimeout'](_0x5bc4b1),_0x5e5d95(_0x5a8228);}_0x5a8228['ping'](_0x1e3ce2)['then'](_0x1e3ce2,()=>{_0x4c3d3f(_0x9acc87);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x3b8847){this['window']=_0x3b8847,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x4bcf67,_0x91d1eb,_0x4e8c95,_0x26e08d=Jp,_0x25b1e9=Xp){const _0x4dccd1=Math['max']((window['screen']['availHeight']-_0x25b1e9)/0x2,0x0)['toString'](),_0x21437f=Math['max']((window['screen']['availWidth']-_0x26e08d)/0x2,0x0)['toString']();let _0x461991='';const _0x2fe9be={...Qp,'width':_0x26e08d['toString'](),'height':_0x25b1e9['toString'](),'top':_0x4dccd1,'left':_0x21437f},_0x1e4679=W()['toLowerCase']();_0x4e8c95&&(_0x461991=ka(_0x1e4679)?Zp:_0x4e8c95),Ra(_0x1e4679)&&(_0x91d1eb=_0x91d1eb||e_,_0x2fe9be['scrollbars']='yes');const _0x821d12=Object['entries'](_0x2fe9be)['reduce']((_0x26237d,[_0x4cfcab,_0x3aca3f])=>''+_0x26237d+_0x4cfcab+'='+_0x3aca3f+',','');if(Rf(_0x1e4679)&&_0x461991!=='_self')return n_(_0x91d1eb||'',_0x461991),new xr(null);const _0x1ef029=window['open'](_0x91d1eb||'',_0x461991,_0x821d12);m(_0x1ef029,_0x4bcf67,'popup-blocked');try{_0x1ef029['focus']();}catch{}return new xr(_0x1ef029);}function n_(_0xcf26d5,_0x566f68){const _0x286695=document['createElement']('a');_0x286695['href']=_0xcf26d5,_0x286695['target']=_0x566f68;const _0x2e4450=document['createEvent']('MouseEvent');_0x2e4450['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x286695['dispatchEvent'](_0x2e4450);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x52473a,_0x2b9339,_0x2b4784,_0x1c8c3a,_0x26c126,_0x1b3300){m(_0x52473a['config']['authDomain'],_0x52473a,'auth-domain-config-required'),m(_0x52473a['config']['apiKey'],_0x52473a,'invalid-api-key');const _0x5dafe3={'apiKey':_0x52473a['config']['apiKey'],'appName':_0x52473a['name'],'authType':_0x2b4784,'redirectUrl':_0x1c8c3a,'v':dt,'eventId':_0x26c126};if(_0x2b9339 instanceof Wa){_0x2b9339['setDefaultLanguage'](_0x52473a['languageCode']),_0x5dafe3['providerId']=_0x2b9339['providerId']||'',pn(_0x2b9339['getCustomParameters']())||(_0x5dafe3['customParameters']=JSON['stringify'](_0x2b9339['getCustomParameters']()));for(const [_0x288b36,_0x480592]of Object['entries']({}))_0x5dafe3[_0x288b36]=_0x480592;}if(_0x2b9339 instanceof tn){const _0x2b13c7=_0x2b9339['getScopes']()['filter'](_0x409950=>_0x409950!=='');_0x2b13c7['length']>0x0&&(_0x5dafe3['scopes']=_0x2b13c7['join'](','));}_0x52473a['tenantId']&&(_0x5dafe3['tid']=_0x52473a['tenantId']);const _0xe8ac39=_0x5dafe3;for(const _0x2ee638 of Object['keys'](_0xe8ac39))_0xe8ac39[_0x2ee638]===void 0x0&&delete _0xe8ac39[_0x2ee638];const _0x11a171=await _0x52473a['_getAppCheckToken'](),_0x2283ff=_0x11a171?'#'+r_+'='+encodeURIComponent(_0x11a171):'';return o_(_0x52473a)+'?'+ut(_0xe8ac39)['slice'](0x1)+_0x2283ff;}function o_({config:_0x33a7ae}){return _0x33a7ae['emulator']?Cs(_0x33a7ae,s_):'https://'+_0x33a7ae['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0xb93645,_0xdc7a74,_0x596008,_0xc4821c){var _0x258336;ce((_0x258336=this['eventManagers'][_0xb93645['_key']()])==null?void 0x0:_0x258336['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x297d8a=await Fr(_0xb93645,_0xdc7a74,_0x596008,Mi(),_0xc4821c);return t_(_0xb93645,_0x297d8a,As());}async['_openRedirect'](_0x488a65,_0x5a3e45,_0x1345c8,_0x12c29a){await this['_originValidation'](_0x488a65);const _0x44eacd=await Fr(_0x488a65,_0x5a3e45,_0x1345c8,Mi(),_0x12c29a);return hp(_0x44eacd),new Promise(()=>{});}['_initialize'](_0x4d516a){const _0x280b2e=_0x4d516a['_key']();if(this['eventManagers'][_0x280b2e]){const {manager:_0xc6db8a,promise:_0xb7dacb}=this['eventManagers'][_0x280b2e];return _0xc6db8a?Promise['resolve'](_0xc6db8a):(ce(_0xb7dacb,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0xb7dacb);}const _0x9598a6=this['initAndGetManager'](_0x4d516a);return this['eventManagers'][_0x280b2e]={'promise':_0x9598a6},_0x9598a6['catch'](()=>{delete this['eventManagers'][_0x280b2e];}),_0x9598a6;}async['initAndGetManager'](_0x5041d5){const _0x29e253=await Yp(_0x5041d5),_0x190792=new Dp(_0x5041d5);return _0x29e253['register']('authEvent',_0x5708a6=>(m(_0x5708a6==null?void 0x0:_0x5708a6['authEvent'],_0x5041d5,'invalid-auth-event'),{'status':_0x190792['onEvent'](_0x5708a6['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x5041d5['_key']()]={'manager':_0x190792},this['iframes'][_0x5041d5['_key']()]=_0x29e253,_0x190792;}['_isIframeWebStorageSupported'](_0x21d834,_0x42ee63){this['iframes'][_0x21d834['_key']()]['send'](pi,{'type':pi},_0x556c09=>{var _0x38f0e2;const _0x1de189=(_0x38f0e2=_0x556c09==null?void 0x0:_0x556c09[0x0])==null?void 0x0:_0x38f0e2[pi];_0x1de189!==void 0x0&&_0x42ee63(!!_0x1de189),Y(_0x21d834,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x3a7cfa){const _0x47af32=_0x3a7cfa['_key']();return this['originValidationPromises'][_0x47af32]||(this['originValidationPromises'][_0x47af32]=Up(_0x3a7cfa)),this['originValidationPromises'][_0x47af32];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x12e0d5){this['auth']=_0x12e0d5,this['internalListeners']=new Map();}['getUid'](){var _0x5225ab;return this['assertAuthConfigured'](),((_0x5225ab=this['auth']['currentUser'])==null?void 0x0:_0x5225ab['uid'])||null;}async['getToken'](_0x3b76f2){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x3b76f2)}:null;}['addAuthTokenListener'](_0x70e8cb){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x70e8cb))return;const _0x1a2db5=this['auth']['onIdTokenChanged'](_0x54236c=>{_0x70e8cb((_0x54236c==null?void 0x0:_0x54236c['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x70e8cb,_0x1a2db5),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x1f1692){this['assertAuthConfigured']();const _0x3e8460=this['internalListeners']['get'](_0x1f1692);_0x3e8460&&(this['internalListeners']['delete'](_0x1f1692),_0x3e8460(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x480af6){switch(_0x480af6){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x234932){st(new Fe('auth',(_0x2f40af,{options:_0xcf3f20})=>{const _0x29bfce=_0x2f40af['getProvider']('app')['getImmediate'](),_0x887e15=_0x2f40af['getProvider']('heartbeat'),_0x11a962=_0x2f40af['getProvider']('app-check-internal'),{apiKey:_0x592dd3,authDomain:_0x3814b8}=_0x29bfce['options'];m(_0x592dd3&&!_0x592dd3['includes'](':'),'invalid-api-key',{'appName':_0x29bfce['name']});const _0x5a537a={'apiKey':_0x592dd3,'authDomain':_0x3814b8,'clientPlatform':_0x234932,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x234932)},_0x86cb50=new Df(_0x29bfce,_0x887e15,_0x11a962,_0x5a537a);return Hf(_0x86cb50,_0xcf3f20),_0x86cb50;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x4f29fd,_0x4b8b77,_0x571f09)=>{_0x4f29fd['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x55b51f=>{const _0x292ea2=Ke(_0x55b51f['getProvider']('auth')['getImmediate']());return(_0x14f15c=>new l_(_0x14f15c))(_0x292ea2);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x234932)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x59270c=>async _0x571c10=>{const _0x32ed72=_0x571c10&&await _0x571c10['getIdTokenResult'](),_0x2dfcad=_0x32ed72&&(new Date()['getTime']()-Date['parse'](_0x32ed72['issuedAtTime']))/0x3e8;if(_0x2dfcad&&_0x2dfcad>f_)return;const _0x82a09f=_0x32ed72==null?void 0x0:_0x32ed72['token'];Br!==_0x82a09f&&(Br=_0x82a09f,await fetch(_0x59270c,{'method':_0x82a09f?'POST':'DELETE','headers':_0x82a09f?{'Authorization':'Bearer\x20'+_0x82a09f}:{}}));};function B_(_0x2a0de9=Zr()){const _0x39fcb5=Hi(_0x2a0de9,'auth');if(_0x39fcb5['isInitialized']())return _0x39fcb5['getImmediate']();const _0x4f1d19=Vf(_0x2a0de9,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x1d8782=jr('authTokenSyncURL');if(_0x1d8782&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x34e3c8=new URL(_0x1d8782,location['origin']);if(location['origin']===_0x34e3c8['origin']){const _0x24f2a3=p_(_0x34e3c8['toString']());sp(_0x4f1d19,_0x24f2a3,()=>_0x24f2a3(_0x4f1d19['currentUser'])),ip(_0x4f1d19,_0x6c277e=>_0x24f2a3(_0x6c277e));}}const _0x14ded7=qr('auth');return _0x14ded7&&$f(_0x4f1d19,'http://'+_0x14ded7),_0x4f1d19;}function __(){var _0x343109;return((_0x343109=document['getElementsByTagName']('head'))==null?void 0x0:_0x343109[0x0])??document;}Mf({'loadJS'(_0x396ee1){return new Promise((_0x41f741,_0x8b3eb5)=>{const _0x555fba=document['createElement']('script');_0x555fba['setAttribute']('src',_0x396ee1),_0x555fba['onload']=_0x41f741,_0x555fba['onerror']=_0x34be55=>{const _0x39e49b=X('internal-error');_0x39e49b['customData']=_0x34be55,_0x8b3eb5(_0x39e49b);},_0x555fba['type']='text/javascript',_0x555fba['charset']='UTF-8',__()['appendChild'](_0x555fba);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,B_ as a,ap as b,x_ as c,g_ as d,m_ as e,Zr as f,P_ as g,Hd as h,Sl as i,D_ as j,Gd as k,w_ as l,b_ as m,A_ as n,v_ as o,E_ as p,k_ as q,y_ as r,F_ as s,Vt as t,I_ as u,N_ as v,U_ as w,O_ as x,M_ as y,T_ as z};