const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x13aac0,_0x1d541f){if(!_0x13aac0)throw ht(_0x1d541f);},ht=function(_0x1e75f2){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x1e75f2);},Hr=function(_0x127803){const _0x2edaba=[];let _0x464548=0x0;for(let _0x3eb688=0x0;_0x3eb688<_0x127803['length'];_0x3eb688++){let _0xf0fa52=_0x127803['charCodeAt'](_0x3eb688);_0xf0fa52<0x80?_0x2edaba[_0x464548++]=_0xf0fa52:_0xf0fa52<0x800?(_0x2edaba[_0x464548++]=_0xf0fa52>>0x6|0xc0,_0x2edaba[_0x464548++]=_0xf0fa52&0x3f|0x80):(_0xf0fa52&0xfc00)===0xd800&&_0x3eb688+0x1<_0x127803['length']&&(_0x127803['charCodeAt'](_0x3eb688+0x1)&0xfc00)===0xdc00?(_0xf0fa52=0x10000+((_0xf0fa52&0x3ff)<<0xa)+(_0x127803['charCodeAt'](++_0x3eb688)&0x3ff),_0x2edaba[_0x464548++]=_0xf0fa52>>0x12|0xf0,_0x2edaba[_0x464548++]=_0xf0fa52>>0xc&0x3f|0x80,_0x2edaba[_0x464548++]=_0xf0fa52>>0x6&0x3f|0x80,_0x2edaba[_0x464548++]=_0xf0fa52&0x3f|0x80):(_0x2edaba[_0x464548++]=_0xf0fa52>>0xc|0xe0,_0x2edaba[_0x464548++]=_0xf0fa52>>0x6&0x3f|0x80,_0x2edaba[_0x464548++]=_0xf0fa52&0x3f|0x80);}return _0x2edaba;},nc=function(_0x1345b3){const _0x14afa9=[];let _0x4654fc=0x0,_0x5b6457=0x0;for(;_0x4654fc<_0x1345b3['length'];){const _0x2067c7=_0x1345b3[_0x4654fc++];if(_0x2067c7<0x80)_0x14afa9[_0x5b6457++]=String['fromCharCode'](_0x2067c7);else{if(_0x2067c7>0xbf&&_0x2067c7<0xe0){const _0x502f82=_0x1345b3[_0x4654fc++];_0x14afa9[_0x5b6457++]=String['fromCharCode']((_0x2067c7&0x1f)<<0x6|_0x502f82&0x3f);}else{if(_0x2067c7>0xef&&_0x2067c7<0x16d){const _0x3ea25f=_0x1345b3[_0x4654fc++],_0x3ae0e7=_0x1345b3[_0x4654fc++],_0x21be57=_0x1345b3[_0x4654fc++],_0x1f1a2f=((_0x2067c7&0x7)<<0x12|(_0x3ea25f&0x3f)<<0xc|(_0x3ae0e7&0x3f)<<0x6|_0x21be57&0x3f)-0x10000;_0x14afa9[_0x5b6457++]=String['fromCharCode'](0xd800+(_0x1f1a2f>>0xa)),_0x14afa9[_0x5b6457++]=String['fromCharCode'](0xdc00+(_0x1f1a2f&0x3ff));}else{const _0x9d133c=_0x1345b3[_0x4654fc++],_0x5eb521=_0x1345b3[_0x4654fc++];_0x14afa9[_0x5b6457++]=String['fromCharCode']((_0x2067c7&0xf)<<0xc|(_0x9d133c&0x3f)<<0x6|_0x5eb521&0x3f);}}}}return _0x14afa9['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x252e5a,_0x33175f){if(!Array['isArray'](_0x252e5a))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x2e9931=_0x33175f?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x5c57db=[];for(let _0x476a75=0x0;_0x476a75<_0x252e5a['length'];_0x476a75+=0x3){const _0x251c0a=_0x252e5a[_0x476a75],_0x460f47=_0x476a75+0x1<_0x252e5a['length'],_0x1b44f2=_0x460f47?_0x252e5a[_0x476a75+0x1]:0x0,_0x4561a5=_0x476a75+0x2<_0x252e5a['length'],_0x25997d=_0x4561a5?_0x252e5a[_0x476a75+0x2]:0x0,_0x5e63cc=_0x251c0a>>0x2,_0x24ebaf=(_0x251c0a&0x3)<<0x4|_0x1b44f2>>0x4;let _0x6d045b=(_0x1b44f2&0xf)<<0x2|_0x25997d>>0x6,_0x1a522b=_0x25997d&0x3f;_0x4561a5||(_0x1a522b=0x40,_0x460f47||(_0x6d045b=0x40)),_0x5c57db['push'](_0x2e9931[_0x5e63cc],_0x2e9931[_0x24ebaf],_0x2e9931[_0x6d045b],_0x2e9931[_0x1a522b]);}return _0x5c57db['join']('');},'encodeString'(_0x29467d,_0x89d7b5){return this['HAS_NATIVE_SUPPORT']&&!_0x89d7b5?btoa(_0x29467d):this['encodeByteArray'](Hr(_0x29467d),_0x89d7b5);},'decodeString'(_0x5f1fd6,_0x46b044){return this['HAS_NATIVE_SUPPORT']&&!_0x46b044?atob(_0x5f1fd6):nc(this['decodeStringToByteArray'](_0x5f1fd6,_0x46b044));},'decodeStringToByteArray'(_0x588b9b,_0x2e9cfa){this['init_']();const _0x3c86e9=_0x2e9cfa?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x593ca7=[];for(let _0x63d8e7=0x0;_0x63d8e7<_0x588b9b['length'];){const _0x3ad5ad=_0x3c86e9[_0x588b9b['charAt'](_0x63d8e7++)],_0xf98fbb=_0x63d8e7<_0x588b9b['length']?_0x3c86e9[_0x588b9b['charAt'](_0x63d8e7)]:0x0;++_0x63d8e7;const _0xa2cbb9=_0x63d8e7<_0x588b9b['length']?_0x3c86e9[_0x588b9b['charAt'](_0x63d8e7)]:0x40;++_0x63d8e7;const _0x40033e=_0x63d8e7<_0x588b9b['length']?_0x3c86e9[_0x588b9b['charAt'](_0x63d8e7)]:0x40;if(++_0x63d8e7,_0x3ad5ad==null||_0xf98fbb==null||_0xa2cbb9==null||_0x40033e==null)throw new ic();const _0x20e8bf=_0x3ad5ad<<0x2|_0xf98fbb>>0x4;if(_0x593ca7['push'](_0x20e8bf),_0xa2cbb9!==0x40){const _0x3fca3b=_0xf98fbb<<0x4&0xf0|_0xa2cbb9>>0x2;if(_0x593ca7['push'](_0x3fca3b),_0x40033e!==0x40){const _0x5e0237=_0xa2cbb9<<0x6&0xc0|_0x40033e;_0x593ca7['push'](_0x5e0237);}}}return _0x593ca7;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x1227e6=0x0;_0x1227e6<this['ENCODED_VALS']['length'];_0x1227e6++)this['byteToCharMap_'][_0x1227e6]=this['ENCODED_VALS']['charAt'](_0x1227e6),this['charToByteMap_'][this['byteToCharMap_'][_0x1227e6]]=_0x1227e6,this['byteToCharMapWebSafe_'][_0x1227e6]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x1227e6),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x1227e6]]=_0x1227e6,_0x1227e6>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x1227e6)]=_0x1227e6,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x1227e6)]=_0x1227e6);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x29e600){const _0x527f73=Hr(_0x29e600);return Fi['encodeByteArray'](_0x527f73,!0x0);},dn=function(_0x520f98){return $r(_0x520f98)['replace'](/\./g,'');},fn=function(_0x290e94){try{return Fi['decodeString'](_0x290e94,!0x0);}catch(_0x569bc6){console['error']('base64Decode\x20failed:\x20',_0x569bc6);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x15ae97){return Gr(void 0x0,_0x15ae97);}function Gr(_0x1af5cc,_0x3db492){if(!(_0x3db492 instanceof Object))return _0x3db492;switch(_0x3db492['constructor']){case Date:const _0x4fef37=_0x3db492;return new Date(_0x4fef37['getTime']());case Object:_0x1af5cc===void 0x0&&(_0x1af5cc={});break;case Array:_0x1af5cc=[];break;default:return _0x3db492;}for(const _0x42a005 in _0x3db492)!_0x3db492['hasOwnProperty'](_0x42a005)||!rc(_0x42a005)||(_0x1af5cc[_0x42a005]=Gr(_0x1af5cc[_0x42a005],_0x3db492[_0x42a005]));return _0x1af5cc;}function rc(_0x51838f){return _0x51838f!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0xba4672=Ps['__FIREBASE_DEFAULTS__'];if(_0xba4672)return JSON['parse'](_0xba4672);},lc=()=>{if(typeof document>'u')return;let _0x53949a;try{_0x53949a=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x314cbe=_0x53949a&&fn(_0x53949a[0x1]);return _0x314cbe&&JSON['parse'](_0x314cbe);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x5af099){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x5af099);return;}},qr=_0x43e49a=>{var _0x49886d,_0x365c3c;return(_0x365c3c=(_0x49886d=Ui())==null?void 0x0:_0x49886d['emulatorHosts'])==null?void 0x0:_0x365c3c[_0x43e49a];},hc=_0x39a854=>{const _0x3759b0=qr(_0x39a854);if(!_0x3759b0)return;const _0x4813dc=_0x3759b0['lastIndexOf'](':');if(_0x4813dc<=0x0||_0x4813dc+0x1===_0x3759b0['length'])throw new Error('Invalid\x20host\x20'+_0x3759b0+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x229f0c=parseInt(_0x3759b0['substring'](_0x4813dc+0x1),0xa);return _0x3759b0[0x0]==='['?[_0x3759b0['substring'](0x1,_0x4813dc-0x1),_0x229f0c]:[_0x3759b0['substring'](0x0,_0x4813dc),_0x229f0c];},zr=()=>{var _0x6d8c62;return(_0x6d8c62=Ui())==null?void 0x0:_0x6d8c62['config'];},jr=_0x5c1dd8=>{var _0x2e54c8;return(_0x2e54c8=Ui())==null?void 0x0:_0x2e54c8['_'+_0x5c1dd8];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x399e18,_0x54e92c)=>{this['resolve']=_0x399e18,this['reject']=_0x54e92c;});}['wrapCallback'](_0x2349ea){return(_0xe7a6a4,_0x131352)=>{_0xe7a6a4?this['reject'](_0xe7a6a4):this['resolve'](_0x131352),typeof _0x2349ea=='function'&&(this['promise']['catch'](()=>{}),_0x2349ea['length']===0x1?_0x2349ea(_0xe7a6a4):_0x2349ea(_0xe7a6a4,_0x131352));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x46e306,_0x1a1744){if(_0x46e306['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x596955={'alg':'none','type':'JWT'},_0x184ecb=_0x1a1744||'demo-project',_0x16b8b5=_0x46e306['iat']||0x0,_0x4906a5=_0x46e306['sub']||_0x46e306['user_id'];if(!_0x4906a5)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x1bc8b0={'iss':'https://securetoken.google.com/'+_0x184ecb,'aud':_0x184ecb,'iat':_0x16b8b5,'exp':_0x16b8b5+0xe10,'auth_time':_0x16b8b5,'sub':_0x4906a5,'user_id':_0x4906a5,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x46e306};return[dn(JSON['stringify'](_0x596955)),dn(JSON['stringify'](_0x1bc8b0)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x1b6c48=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x1b6c48=='object'&&_0x1b6c48['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x2adcb1=W();return _0x2adcb1['indexOf']('MSIE\x20')>=0x0||_0x2adcb1['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x28d73f,_0x579652)=>{try{let _0x47b17e=!0x0;const _0x57358c='validate-browser-context-for-indexeddb-analytics-module',_0x3b9782=self['indexedDB']['open'](_0x57358c);_0x3b9782['onsuccess']=()=>{_0x3b9782['result']['close'](),_0x47b17e||self['indexedDB']['deleteDatabase'](_0x57358c),_0x28d73f(!0x0);},_0x3b9782['onupgradeneeded']=()=>{_0x47b17e=!0x1;},_0x3b9782['onerror']=()=>{var _0x258f07;_0x579652(((_0x258f07=_0x3b9782['error'])==null?void 0x0:_0x258f07['message'])||'');};}catch(_0x31bf34){_0x579652(_0x31bf34);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x48bf1d,_0x413f05,_0xee42d){super(_0x413f05),this['code']=_0x48bf1d,this['customData']=_0xee42d,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x4cf485,_0x333de4,_0x2b820d){this['service']=_0x4cf485,this['serviceName']=_0x333de4,this['errors']=_0x2b820d;}['create'](_0x13c670,..._0x19248d){const _0x4cf228=_0x19248d[0x0]||{},_0x4a3689=this['service']+'/'+_0x13c670,_0x2dc086=this['errors'][_0x13c670],_0x32baee=_0x2dc086?vc(_0x2dc086,_0x4cf228):'Error',_0x3ca0d3=this['serviceName']+':\x20'+_0x32baee+'\x20('+_0x4a3689+').';return new Re(_0x4a3689,_0x3ca0d3,_0x4cf228);}}function vc(_0x5847ab,_0x40ad0b){return _0x5847ab['replace'](Ec,(_0x1b3671,_0x5d7223)=>{const _0x4e882e=_0x40ad0b[_0x5d7223];return _0x4e882e!=null?String(_0x4e882e):'<'+_0x5d7223+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x2bc375){return JSON['parse'](_0x2bc375);}function O(_0x5d5331){return JSON['stringify'](_0x5d5331);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x41a0d5){let _0x3d502e={},_0xdaac55={},_0x453aee={},_0x7a6916='';try{const _0x37186a=_0x41a0d5['split']('.');_0x3d502e=Nt(fn(_0x37186a[0x0])||''),_0xdaac55=Nt(fn(_0x37186a[0x1])||''),_0x7a6916=_0x37186a[0x2],_0x453aee=_0xdaac55['d']||{},delete _0xdaac55['d'];}catch{}return{'header':_0x3d502e,'claims':_0xdaac55,'data':_0x453aee,'signature':_0x7a6916};},Ic=function(_0x558a6c){const _0x51b20a=Yr(_0x558a6c),_0x1a7589=_0x51b20a['claims'];return!!_0x1a7589&&typeof _0x1a7589=='object'&&_0x1a7589['hasOwnProperty']('iat');},wc=function(_0x588f14){const _0x3b40e2=Yr(_0x588f14)['claims'];return typeof _0x3b40e2=='object'&&_0x3b40e2['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x44158b,_0x3d8699){return Object['prototype']['hasOwnProperty']['call'](_0x44158b,_0x3d8699);}function Le(_0x3175b8,_0xc3d78f){if(Object['prototype']['hasOwnProperty']['call'](_0x3175b8,_0xc3d78f))return _0x3175b8[_0xc3d78f];}function pn(_0x922b9c){for(const _0x129a22 in _0x922b9c)if(Object['prototype']['hasOwnProperty']['call'](_0x922b9c,_0x129a22))return!0x1;return!0x0;}function _n(_0x12c31b,_0x2a2c84,_0x13b14a){const _0x24cc1a={};for(const _0x52b38d in _0x12c31b)Object['prototype']['hasOwnProperty']['call'](_0x12c31b,_0x52b38d)&&(_0x24cc1a[_0x52b38d]=_0x2a2c84['call'](_0x13b14a,_0x12c31b[_0x52b38d],_0x52b38d,_0x12c31b));return _0x24cc1a;}function xe(_0x1f8b2a,_0x342077){if(_0x1f8b2a===_0x342077)return!0x0;const _0x3badd3=Object['keys'](_0x1f8b2a),_0x5a2246=Object['keys'](_0x342077);for(const _0x2f7571 of _0x3badd3){if(!_0x5a2246['includes'](_0x2f7571))return!0x1;const _0x463c57=_0x1f8b2a[_0x2f7571],_0x26116d=_0x342077[_0x2f7571];if(Ns(_0x463c57)&&Ns(_0x26116d)){if(!xe(_0x463c57,_0x26116d))return!0x1;}else{if(_0x463c57!==_0x26116d)return!0x1;}}for(const _0x3eff66 of _0x5a2246)if(!_0x3badd3['includes'](_0x3eff66))return!0x1;return!0x0;}function Ns(_0x1e64b0){return _0x1e64b0!==null&&typeof _0x1e64b0=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x4c8525){const _0x4be4fa=[];for(const [_0x3252b9,_0x2ff0d3]of Object['entries'](_0x4c8525))Array['isArray'](_0x2ff0d3)?_0x2ff0d3['forEach'](_0x1cb05b=>{_0x4be4fa['push'](encodeURIComponent(_0x3252b9)+'='+encodeURIComponent(_0x1cb05b));}):_0x4be4fa['push'](encodeURIComponent(_0x3252b9)+'='+encodeURIComponent(_0x2ff0d3));return _0x4be4fa['length']?'&'+_0x4be4fa['join']('&'):'';}function Ct(_0x488b21){const _0x2e6b36={};return _0x488b21['replace'](/^\?/,'')['split']('&')['forEach'](_0x271f96=>{if(_0x271f96){const [_0x8ade6f,_0x354e5d]=_0x271f96['split']('=');_0x2e6b36[decodeURIComponent(_0x8ade6f)]=decodeURIComponent(_0x354e5d);}}),_0x2e6b36;}function Tt(_0x22ec3f){const _0xbbb3fd=_0x22ec3f['indexOf']('?');if(!_0xbbb3fd)return'';const _0x4ac689=_0x22ec3f['indexOf']('#',_0xbbb3fd);return _0x22ec3f['substring'](_0xbbb3fd,_0x4ac689>0x0?_0x4ac689:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x3d24a7=0x1;_0x3d24a7<this['blockSize'];++_0x3d24a7)this['pad_'][_0x3d24a7]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x57d611,_0x5f48e3){_0x5f48e3||(_0x5f48e3=0x0);const _0x385c5d=this['W_'];if(typeof _0x57d611=='string'){for(let _0x7df50b=0x0;_0x7df50b<0x10;_0x7df50b++)_0x385c5d[_0x7df50b]=_0x57d611['charCodeAt'](_0x5f48e3)<<0x18|_0x57d611['charCodeAt'](_0x5f48e3+0x1)<<0x10|_0x57d611['charCodeAt'](_0x5f48e3+0x2)<<0x8|_0x57d611['charCodeAt'](_0x5f48e3+0x3),_0x5f48e3+=0x4;}else{for(let _0x27129f=0x0;_0x27129f<0x10;_0x27129f++)_0x385c5d[_0x27129f]=_0x57d611[_0x5f48e3]<<0x18|_0x57d611[_0x5f48e3+0x1]<<0x10|_0x57d611[_0x5f48e3+0x2]<<0x8|_0x57d611[_0x5f48e3+0x3],_0x5f48e3+=0x4;}for(let _0x40c05b=0x10;_0x40c05b<0x50;_0x40c05b++){const _0x3fb354=_0x385c5d[_0x40c05b-0x3]^_0x385c5d[_0x40c05b-0x8]^_0x385c5d[_0x40c05b-0xe]^_0x385c5d[_0x40c05b-0x10];_0x385c5d[_0x40c05b]=(_0x3fb354<<0x1|_0x3fb354>>>0x1f)&0xffffffff;}let _0x860fb=this['chain_'][0x0],_0x1c2ba2=this['chain_'][0x1],_0x40fb3c=this['chain_'][0x2],_0x596173=this['chain_'][0x3],_0x45fced=this['chain_'][0x4],_0x3b53ae,_0x30c28f;for(let _0x4d5883=0x0;_0x4d5883<0x50;_0x4d5883++){_0x4d5883<0x28?_0x4d5883<0x14?(_0x3b53ae=_0x596173^_0x1c2ba2&(_0x40fb3c^_0x596173),_0x30c28f=0x5a827999):(_0x3b53ae=_0x1c2ba2^_0x40fb3c^_0x596173,_0x30c28f=0x6ed9eba1):_0x4d5883<0x3c?(_0x3b53ae=_0x1c2ba2&_0x40fb3c|_0x596173&(_0x1c2ba2|_0x40fb3c),_0x30c28f=0x8f1bbcdc):(_0x3b53ae=_0x1c2ba2^_0x40fb3c^_0x596173,_0x30c28f=0xca62c1d6);const _0x2dfdd8=(_0x860fb<<0x5|_0x860fb>>>0x1b)+_0x3b53ae+_0x45fced+_0x30c28f+_0x385c5d[_0x4d5883]&0xffffffff;_0x45fced=_0x596173,_0x596173=_0x40fb3c,_0x40fb3c=(_0x1c2ba2<<0x1e|_0x1c2ba2>>>0x2)&0xffffffff,_0x1c2ba2=_0x860fb,_0x860fb=_0x2dfdd8;}this['chain_'][0x0]=this['chain_'][0x0]+_0x860fb&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x1c2ba2&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x40fb3c&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x596173&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x45fced&0xffffffff;}['update'](_0x3e7fb8,_0x4a8e2e){if(_0x3e7fb8==null)return;_0x4a8e2e===void 0x0&&(_0x4a8e2e=_0x3e7fb8['length']);const _0x48568e=_0x4a8e2e-this['blockSize'];let _0x48ac8c=0x0;const _0x2f886e=this['buf_'];let _0x5a8404=this['inbuf_'];for(;_0x48ac8c<_0x4a8e2e;){if(_0x5a8404===0x0){for(;_0x48ac8c<=_0x48568e;)this['compress_'](_0x3e7fb8,_0x48ac8c),_0x48ac8c+=this['blockSize'];}if(typeof _0x3e7fb8=='string'){for(;_0x48ac8c<_0x4a8e2e;)if(_0x2f886e[_0x5a8404]=_0x3e7fb8['charCodeAt'](_0x48ac8c),++_0x5a8404,++_0x48ac8c,_0x5a8404===this['blockSize']){this['compress_'](_0x2f886e),_0x5a8404=0x0;break;}}else{for(;_0x48ac8c<_0x4a8e2e;)if(_0x2f886e[_0x5a8404]=_0x3e7fb8[_0x48ac8c],++_0x5a8404,++_0x48ac8c,_0x5a8404===this['blockSize']){this['compress_'](_0x2f886e),_0x5a8404=0x0;break;}}}this['inbuf_']=_0x5a8404,this['total_']+=_0x4a8e2e;}['digest'](){const _0x430ac0=[];let _0x4254b4=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x183726=this['blockSize']-0x1;_0x183726>=0x38;_0x183726--)this['buf_'][_0x183726]=_0x4254b4&0xff,_0x4254b4/=0x100;this['compress_'](this['buf_']);let _0x3e2fe5=0x0;for(let _0x125661=0x0;_0x125661<0x5;_0x125661++)for(let _0x43e208=0x18;_0x43e208>=0x0;_0x43e208-=0x8)_0x430ac0[_0x3e2fe5]=this['chain_'][_0x125661]>>_0x43e208&0xff,++_0x3e2fe5;return _0x430ac0;}}function Tc(_0xc45589,_0x4ad1ee){const _0x18ae21=new Sc(_0xc45589,_0x4ad1ee);return _0x18ae21['subscribe']['bind'](_0x18ae21);}class Sc{constructor(_0x260709,_0x57adf5){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x57adf5,this['task']['then'](()=>{_0x260709(this);})['catch'](_0x7a39d4=>{this['error'](_0x7a39d4);});}['next'](_0x3f25dd){this['forEachObserver'](_0x2f5e16=>{_0x2f5e16['next'](_0x3f25dd);});}['error'](_0x353dab){this['forEachObserver'](_0x27c665=>{_0x27c665['error'](_0x353dab);}),this['close'](_0x353dab);}['complete'](){this['forEachObserver'](_0x157626=>{_0x157626['complete']();}),this['close']();}['subscribe'](_0x278c97,_0x3ef98a,_0x1336c8){let _0x5ee9e2;if(_0x278c97===void 0x0&&_0x3ef98a===void 0x0&&_0x1336c8===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x278c97,['next','error','complete'])?_0x5ee9e2=_0x278c97:_0x5ee9e2={'next':_0x278c97,'error':_0x3ef98a,'complete':_0x1336c8},_0x5ee9e2['next']===void 0x0&&(_0x5ee9e2['next']=ti),_0x5ee9e2['error']===void 0x0&&(_0x5ee9e2['error']=ti),_0x5ee9e2['complete']===void 0x0&&(_0x5ee9e2['complete']=ti);const _0x112681=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x5ee9e2['error'](this['finalError']):_0x5ee9e2['complete']();}catch{}}),this['observers']['push'](_0x5ee9e2),_0x112681;}['unsubscribeOne'](_0x199625){this['observers']===void 0x0||this['observers'][_0x199625]===void 0x0||(delete this['observers'][_0x199625],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x4889ec){if(!this['finalized']){for(let _0x3611ad=0x0;_0x3611ad<this['observers']['length'];_0x3611ad++)this['sendOne'](_0x3611ad,_0x4889ec);}}['sendOne'](_0x57f26a,_0x3bc057){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x57f26a]!==void 0x0)try{_0x3bc057(this['observers'][_0x57f26a]);}catch(_0x2ae89b){typeof console<'u'&&console['error']&&console['error'](_0x2ae89b);}});}['close'](_0x2afd32){this['finalized']||(this['finalized']=!0x0,_0x2afd32!==void 0x0&&(this['finalError']=_0x2afd32),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x3604b3,_0x4209df){if(typeof _0x3604b3!='object'||_0x3604b3===null)return!0x1;for(const _0x499344 of _0x4209df)if(_0x499344 in _0x3604b3&&typeof _0x3604b3[_0x499344]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x4385c4,_0x46f4a0){return _0x4385c4+'\x20failed:\x20'+_0x46f4a0+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x16c7e4){const _0x1fbfd8=[];let _0x670486=0x0;for(let _0xbfb974=0x0;_0xbfb974<_0x16c7e4['length'];_0xbfb974++){let _0x5d4f51=_0x16c7e4['charCodeAt'](_0xbfb974);if(_0x5d4f51>=0xd800&&_0x5d4f51<=0xdbff){const _0x3c990f=_0x5d4f51-0xd800;_0xbfb974++,f(_0xbfb974<_0x16c7e4['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x26742f=_0x16c7e4['charCodeAt'](_0xbfb974)-0xdc00;_0x5d4f51=0x10000+(_0x3c990f<<0xa)+_0x26742f;}_0x5d4f51<0x80?_0x1fbfd8[_0x670486++]=_0x5d4f51:_0x5d4f51<0x800?(_0x1fbfd8[_0x670486++]=_0x5d4f51>>0x6|0xc0,_0x1fbfd8[_0x670486++]=_0x5d4f51&0x3f|0x80):_0x5d4f51<0x10000?(_0x1fbfd8[_0x670486++]=_0x5d4f51>>0xc|0xe0,_0x1fbfd8[_0x670486++]=_0x5d4f51>>0x6&0x3f|0x80,_0x1fbfd8[_0x670486++]=_0x5d4f51&0x3f|0x80):(_0x1fbfd8[_0x670486++]=_0x5d4f51>>0x12|0xf0,_0x1fbfd8[_0x670486++]=_0x5d4f51>>0xc&0x3f|0x80,_0x1fbfd8[_0x670486++]=_0x5d4f51>>0x6&0x3f|0x80,_0x1fbfd8[_0x670486++]=_0x5d4f51&0x3f|0x80);}return _0x1fbfd8;},Ln=function(_0x2fd5c7){let _0x42ce18=0x0;for(let _0x264566=0x0;_0x264566<_0x2fd5c7['length'];_0x264566++){const _0x325dec=_0x2fd5c7['charCodeAt'](_0x264566);_0x325dec<0x80?_0x42ce18++:_0x325dec<0x800?_0x42ce18+=0x2:_0x325dec>=0xd800&&_0x325dec<=0xdbff?(_0x42ce18+=0x4,_0x264566++):_0x42ce18+=0x3;}return _0x42ce18;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x2e666b){return _0x2e666b&&_0x2e666b['_delegate']?_0x2e666b['_delegate']:_0x2e666b;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x2e5abd){try{return(_0x2e5abd['startsWith']('http://')||_0x2e5abd['startsWith']('https://')?new URL(_0x2e5abd)['hostname']:_0x2e5abd)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x183eaf){return(await fetch(_0x183eaf,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x185db4,_0x20f009,_0x220a85){this['name']=_0x185db4,this['instanceFactory']=_0x20f009,this['type']=_0x220a85,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x17933c){return this['instantiationMode']=_0x17933c,this;}['setMultipleInstances'](_0x357fcb){return this['multipleInstances']=_0x357fcb,this;}['setServiceProps'](_0x29a132){return this['serviceProps']=_0x29a132,this;}['setInstanceCreatedCallback'](_0x274761){return this['onInstanceCreated']=_0x274761,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x3891d5,_0x34dd71){this['name']=_0x3891d5,this['container']=_0x34dd71,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x5d0f5c){const _0xe13069=this['normalizeInstanceIdentifier'](_0x5d0f5c);if(!this['instancesDeferred']['has'](_0xe13069)){const _0x1c08ea=new H();if(this['instancesDeferred']['set'](_0xe13069,_0x1c08ea),this['isInitialized'](_0xe13069)||this['shouldAutoInitialize']())try{const _0x323750=this['getOrInitializeService']({'instanceIdentifier':_0xe13069});_0x323750&&_0x1c08ea['resolve'](_0x323750);}catch{}}return this['instancesDeferred']['get'](_0xe13069)['promise'];}['getImmediate'](_0x2bc1){const _0x1c84e3=this['normalizeInstanceIdentifier'](_0x2bc1==null?void 0x0:_0x2bc1['identifier']),_0x28b091=(_0x2bc1==null?void 0x0:_0x2bc1['optional'])??!0x1;if(this['isInitialized'](_0x1c84e3)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x1c84e3});}catch(_0x55e6d0){if(_0x28b091)return null;throw _0x55e6d0;}else{if(_0x28b091)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x251841){if(_0x251841['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x251841['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x251841,!!this['shouldAutoInitialize']()){if(Pc(_0x251841))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x360ddb,_0xe6093f]of this['instancesDeferred']['entries']()){const _0x350524=this['normalizeInstanceIdentifier'](_0x360ddb);try{const _0x28e508=this['getOrInitializeService']({'instanceIdentifier':_0x350524});_0xe6093f['resolve'](_0x28e508);}catch{}}}}['clearInstance'](_0x46c7c0=Ne){this['instancesDeferred']['delete'](_0x46c7c0),this['instancesOptions']['delete'](_0x46c7c0),this['instances']['delete'](_0x46c7c0);}async['delete'](){const _0x2a24a4=Array['from'](this['instances']['values']());await Promise['all']([..._0x2a24a4['filter'](_0x4bce36=>'INTERNAL'in _0x4bce36)['map'](_0x35e29b=>_0x35e29b['INTERNAL']['delete']()),..._0x2a24a4['filter'](_0x5d6fd5=>'_delete'in _0x5d6fd5)['map'](_0x7d969e=>_0x7d969e['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x2e0de8=Ne){return this['instances']['has'](_0x2e0de8);}['getOptions'](_0x36ef2f=Ne){return this['instancesOptions']['get'](_0x36ef2f)||{};}['initialize'](_0x45095b={}){const {options:_0x546bc2={}}=_0x45095b,_0x5d3212=this['normalizeInstanceIdentifier'](_0x45095b['instanceIdentifier']);if(this['isInitialized'](_0x5d3212))throw Error(this['name']+'('+_0x5d3212+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x4fc242=this['getOrInitializeService']({'instanceIdentifier':_0x5d3212,'options':_0x546bc2});for(const [_0x2277fc,_0x5b1d8f]of this['instancesDeferred']['entries']()){const _0x231f7e=this['normalizeInstanceIdentifier'](_0x2277fc);_0x5d3212===_0x231f7e&&_0x5b1d8f['resolve'](_0x4fc242);}return _0x4fc242;}['onInit'](_0x99f2b8,_0x5b8dd4){const _0x310270=this['normalizeInstanceIdentifier'](_0x5b8dd4),_0x3d9aa1=this['onInitCallbacks']['get'](_0x310270)??new Set();_0x3d9aa1['add'](_0x99f2b8),this['onInitCallbacks']['set'](_0x310270,_0x3d9aa1);const _0x611f21=this['instances']['get'](_0x310270);return _0x611f21&&_0x99f2b8(_0x611f21,_0x310270),()=>{_0x3d9aa1['delete'](_0x99f2b8);};}['invokeOnInitCallbacks'](_0x1b5cea,_0x4dd7f8){const _0x2a2c49=this['onInitCallbacks']['get'](_0x4dd7f8);if(_0x2a2c49){for(const _0x39e349 of _0x2a2c49)try{_0x39e349(_0x1b5cea,_0x4dd7f8);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x3fad54,options:_0x530dd4={}}){let _0x2e26dd=this['instances']['get'](_0x3fad54);if(!_0x2e26dd&&this['component']&&(_0x2e26dd=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x3fad54),'options':_0x530dd4}),this['instances']['set'](_0x3fad54,_0x2e26dd),this['instancesOptions']['set'](_0x3fad54,_0x530dd4),this['invokeOnInitCallbacks'](_0x2e26dd,_0x3fad54),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x3fad54,_0x2e26dd);}catch{}return _0x2e26dd||null;}['normalizeInstanceIdentifier'](_0x1f2cb3=Ne){return this['component']?this['component']['multipleInstances']?_0x1f2cb3:Ne:_0x1f2cb3;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x49ac80){return _0x49ac80===Ne?void 0x0:_0x49ac80;}function Pc(_0x45570c){return _0x45570c['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x5f5ca7){this['name']=_0x5f5ca7,this['providers']=new Map();}['addComponent'](_0x30d7e2){const _0x190b8d=this['getProvider'](_0x30d7e2['name']);if(_0x190b8d['isComponentSet']())throw new Error('Component\x20'+_0x30d7e2['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x190b8d['setComponent'](_0x30d7e2);}['addOrOverwriteComponent'](_0x29b75b){this['getProvider'](_0x29b75b['name'])['isComponentSet']()&&this['providers']['delete'](_0x29b75b['name']),this['addComponent'](_0x29b75b);}['getProvider'](_0x3c13df){if(this['providers']['has'](_0x3c13df))return this['providers']['get'](_0x3c13df);const _0x26e9cd=new Ac(_0x3c13df,this);return this['providers']['set'](_0x3c13df,_0x26e9cd),_0x26e9cd;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x50b850){_0x50b850[_0x50b850['DEBUG']=0x0]='DEBUG',_0x50b850[_0x50b850['VERBOSE']=0x1]='VERBOSE',_0x50b850[_0x50b850['INFO']=0x2]='INFO',_0x50b850[_0x50b850['WARN']=0x3]='WARN',_0x50b850[_0x50b850['ERROR']=0x4]='ERROR',_0x50b850[_0x50b850['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x2fcacb,_0x5e5f44,..._0x424ff1)=>{if(_0x5e5f44<_0x2fcacb['logLevel'])return;const _0x3b125c=new Date()['toISOString'](),_0x5cdefa=Mc[_0x5e5f44];if(_0x5cdefa)console[_0x5cdefa]('['+_0x3b125c+']\x20\x20'+_0x2fcacb['name']+':',..._0x424ff1);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x5e5f44+')');};class Bi{constructor(_0x823c17){this['name']=_0x823c17,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x414784){if(!(_0x414784 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x414784+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x414784;}['setLogLevel'](_0x2a6773){this['_logLevel']=typeof _0x2a6773=='string'?Oc[_0x2a6773]:_0x2a6773;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x5e0933){if(typeof _0x5e0933!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x5e0933;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x409a94){this['_userLogHandler']=_0x409a94;}['debug'](..._0x39122f){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x39122f),this['_logHandler'](this,T['DEBUG'],..._0x39122f);}['log'](..._0x5e0cb9){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x5e0cb9),this['_logHandler'](this,T['VERBOSE'],..._0x5e0cb9);}['info'](..._0xaf1058){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0xaf1058),this['_logHandler'](this,T['INFO'],..._0xaf1058);}['warn'](..._0x1854d7){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x1854d7),this['_logHandler'](this,T['WARN'],..._0x1854d7);}['error'](..._0x52da9d){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x52da9d),this['_logHandler'](this,T['ERROR'],..._0x52da9d);}}const xc=(_0x3c7e7f,_0x4ee7c7)=>_0x4ee7c7['some'](_0x5d36aa=>_0x3c7e7f instanceof _0x5d36aa);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x52ced9){const _0xfaf8e0=new Promise((_0x1e488d,_0x39e139)=>{const _0x4977df=()=>{_0x52ced9['removeEventListener']('success',_0x424c3c),_0x52ced9['removeEventListener']('error',_0x3ae9ed);},_0x424c3c=()=>{_0x1e488d(ge(_0x52ced9['result'])),_0x4977df();},_0x3ae9ed=()=>{_0x39e139(_0x52ced9['error']),_0x4977df();};_0x52ced9['addEventListener']('success',_0x424c3c),_0x52ced9['addEventListener']('error',_0x3ae9ed);});return _0xfaf8e0['then'](_0x416d26=>{_0x416d26 instanceof IDBCursor&&Jr['set'](_0x416d26,_0x52ced9);})['catch'](()=>{}),Vi['set'](_0xfaf8e0,_0x52ced9),_0xfaf8e0;}function Bc(_0x45115f){if(_i['has'](_0x45115f))return;const _0x2d09fd=new Promise((_0x4735d5,_0x1489b3)=>{const _0xa5d58b=()=>{_0x45115f['removeEventListener']('complete',_0x2d0936),_0x45115f['removeEventListener']('error',_0x4043d5),_0x45115f['removeEventListener']('abort',_0x4043d5);},_0x2d0936=()=>{_0x4735d5(),_0xa5d58b();},_0x4043d5=()=>{_0x1489b3(_0x45115f['error']||new DOMException('AbortError','AbortError')),_0xa5d58b();};_0x45115f['addEventListener']('complete',_0x2d0936),_0x45115f['addEventListener']('error',_0x4043d5),_0x45115f['addEventListener']('abort',_0x4043d5);});_i['set'](_0x45115f,_0x2d09fd);}let gi={'get'(_0x2f6413,_0x334a5c,_0x144215){if(_0x2f6413 instanceof IDBTransaction){if(_0x334a5c==='done')return _i['get'](_0x2f6413);if(_0x334a5c==='objectStoreNames')return _0x2f6413['objectStoreNames']||Xr['get'](_0x2f6413);if(_0x334a5c==='store')return _0x144215['objectStoreNames'][0x1]?void 0x0:_0x144215['objectStore'](_0x144215['objectStoreNames'][0x0]);}return ge(_0x2f6413[_0x334a5c]);},'set'(_0x493355,_0x3a05b8,_0x1b5ba4){return _0x493355[_0x3a05b8]=_0x1b5ba4,!0x0;},'has'(_0x4b53c0,_0x530313){return _0x4b53c0 instanceof IDBTransaction&&(_0x530313==='done'||_0x530313==='store')?!0x0:_0x530313 in _0x4b53c0;}};function Vc(_0x14150d){gi=_0x14150d(gi);}function Hc(_0x267a55){return _0x267a55===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x1fda61,..._0x359f69){const _0x2114a8=_0x267a55['call'](ii(this),_0x1fda61,..._0x359f69);return Xr['set'](_0x2114a8,_0x1fda61['sort']?_0x1fda61['sort']():[_0x1fda61]),ge(_0x2114a8);}:Uc()['includes'](_0x267a55)?function(..._0x171602){return _0x267a55['apply'](ii(this),_0x171602),ge(Jr['get'](this));}:function(..._0x47397b){return ge(_0x267a55['apply'](ii(this),_0x47397b));};}function $c(_0x362b45){return typeof _0x362b45=='function'?Hc(_0x362b45):(_0x362b45 instanceof IDBTransaction&&Bc(_0x362b45),xc(_0x362b45,Fc())?new Proxy(_0x362b45,gi):_0x362b45);}function ge(_0x5531ed){if(_0x5531ed instanceof IDBRequest)return Wc(_0x5531ed);if(ni['has'](_0x5531ed))return ni['get'](_0x5531ed);const _0x105781=$c(_0x5531ed);return _0x105781!==_0x5531ed&&(ni['set'](_0x5531ed,_0x105781),Vi['set'](_0x105781,_0x5531ed)),_0x105781;}const ii=_0x5cdea2=>Vi['get'](_0x5cdea2);function Gc(_0x4512d7,_0xd2f798,{blocked:_0x378f73,upgrade:_0x5d537c,blocking:_0x6465fb,terminated:_0x34b17c}={}){const _0x288976=indexedDB['open'](_0x4512d7,_0xd2f798),_0x50742b=ge(_0x288976);return _0x5d537c&&_0x288976['addEventListener']('upgradeneeded',_0x4c99e9=>{_0x5d537c(ge(_0x288976['result']),_0x4c99e9['oldVersion'],_0x4c99e9['newVersion'],ge(_0x288976['transaction']),_0x4c99e9);}),_0x378f73&&_0x288976['addEventListener']('blocked',_0x5643f=>_0x378f73(_0x5643f['oldVersion'],_0x5643f['newVersion'],_0x5643f)),_0x50742b['then'](_0x538ae7=>{_0x34b17c&&_0x538ae7['addEventListener']('close',()=>_0x34b17c()),_0x6465fb&&_0x538ae7['addEventListener']('versionchange',_0x22caf8=>_0x6465fb(_0x22caf8['oldVersion'],_0x22caf8['newVersion'],_0x22caf8));})['catch'](()=>{}),_0x50742b;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x41e8bc,_0x651e9d){if(!(_0x41e8bc instanceof IDBDatabase&&!(_0x651e9d in _0x41e8bc)&&typeof _0x651e9d=='string'))return;if(si['get'](_0x651e9d))return si['get'](_0x651e9d);const _0x49a797=_0x651e9d['replace'](/FromIndex$/,''),_0x4eb966=_0x651e9d!==_0x49a797,_0x23d043=zc['includes'](_0x49a797);if(!(_0x49a797 in(_0x4eb966?IDBIndex:IDBObjectStore)['prototype'])||!(_0x23d043||qc['includes'](_0x49a797)))return;const _0x478c6a=async function(_0x4b6292,..._0x26d3c9){const _0x303af0=this['transaction'](_0x4b6292,_0x23d043?'readwrite':'readonly');let _0x452225=_0x303af0['store'];return _0x4eb966&&(_0x452225=_0x452225['index'](_0x26d3c9['shift']())),(await Promise['all']([_0x452225[_0x49a797](..._0x26d3c9),_0x23d043&&_0x303af0['done']]))[0x0];};return si['set'](_0x651e9d,_0x478c6a),_0x478c6a;}Vc(_0x43a1e2=>({..._0x43a1e2,'get':(_0x296253,_0x38bf6b,_0x34f68c)=>Ms(_0x296253,_0x38bf6b)||_0x43a1e2['get'](_0x296253,_0x38bf6b,_0x34f68c),'has':(_0x54cc83,_0x52eabc)=>!!Ms(_0x54cc83,_0x52eabc)||_0x43a1e2['has'](_0x54cc83,_0x52eabc)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x563633){this['container']=_0x563633;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x386132=>{if(Kc(_0x386132)){const _0x56076c=_0x386132['getImmediate']();return _0x56076c['library']+'/'+_0x56076c['version'];}else return null;})['filter'](_0x52f04c=>_0x52f04c)['join']('\x20');}}function Kc(_0x9488e2){const _0x107ed8=_0x9488e2['getComponent']();return(_0x107ed8==null?void 0x0:_0x107ed8['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0x540f40,_0x56977f){try{_0x540f40['container']['addComponent'](_0x56977f);}catch(_0x4a3fb6){oe['debug']('Component\x20'+_0x56977f['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x540f40['name'],_0x4a3fb6);}}function st(_0x475cd2){const _0x47f495=_0x475cd2['name'];if(Ei['has'](_0x47f495))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x47f495+'.'),!0x1;Ei['set'](_0x47f495,_0x475cd2);for(const _0x40484e of Ue['values']())xs(_0x40484e,_0x475cd2);for(const _0x2ad0c0 of vi['values']())xs(_0x2ad0c0,_0x475cd2);return!0x0;}function Hi(_0x517954,_0x379a1f){const _0xad43eb=_0x517954['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0xad43eb&&_0xad43eb['triggerHeartbeat'](),_0x517954['container']['getProvider'](_0x379a1f);}function $(_0x1ead12){return _0x1ead12==null?!0x1:_0x1ead12['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x48e7c9,_0x379d7a,_0x36f51c){this['_isDeleted']=!0x1,this['_options']={..._0x48e7c9},this['_config']={..._0x379d7a},this['_name']=_0x379d7a['name'],this['_automaticDataCollectionEnabled']=_0x379d7a['automaticDataCollectionEnabled'],this['_container']=_0x36f51c,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x30f543){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x30f543;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x2acd9a){this['_isDeleted']=_0x2acd9a;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x3db5f7,_0x50357f={}){let _0x4f0f19=_0x3db5f7;typeof _0x50357f!='object'&&(_0x50357f={'name':_0x50357f});const _0xc9d7da={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x50357f},_0x85f74b=_0xc9d7da['name'];if(typeof _0x85f74b!='string'||!_0x85f74b)throw me['create']('bad-app-name',{'appName':String(_0x85f74b)});if(_0x4f0f19||(_0x4f0f19=zr()),!_0x4f0f19)throw me['create']('no-options');const _0x448a75=Ue['get'](_0x85f74b);if(_0x448a75){if(xe(_0x4f0f19,_0x448a75['options'])&&xe(_0xc9d7da,_0x448a75['config']))return _0x448a75;throw me['create']('duplicate-app',{'appName':_0x85f74b});}const _0x40505d=new Nc(_0x85f74b);for(const _0xd8ef1 of Ei['values']())_0x40505d['addComponent'](_0xd8ef1);const _0x42d263=new Tl(_0x4f0f19,_0xc9d7da,_0x40505d);return Ue['set'](_0x85f74b,_0x42d263),_0x42d263;}function Zr(_0x5b6fa6=yi){const _0x1b0c1a=Ue['get'](_0x5b6fa6);if(!_0x1b0c1a&&_0x5b6fa6===yi&&zr())return Sl();if(!_0x1b0c1a)throw me['create']('no-app',{'appName':_0x5b6fa6});return _0x1b0c1a;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x332a68){let _0xd2aa46=!0x1;const _0x36d871=_0x332a68['name'];Ue['has'](_0x36d871)?(_0xd2aa46=!0x0,Ue['delete'](_0x36d871)):vi['has'](_0x36d871)&&_0x332a68['decRefCount']()<=0x0&&(vi['delete'](_0x36d871),_0xd2aa46=!0x0),_0xd2aa46&&(await Promise['all'](_0x332a68['container']['getProviders']()['map'](_0x1a0bc5=>_0x1a0bc5['delete']())),_0x332a68['isDeleted']=!0x0);}function ye(_0x2bba11,_0x4fb237,_0x16f810){let _0x5b2ef7=wl[_0x2bba11]??_0x2bba11;_0x16f810&&(_0x5b2ef7+='-'+_0x16f810);const _0x2ecc9c=_0x5b2ef7['match'](/\s|\//),_0x4a067e=_0x4fb237['match'](/\s|\//);if(_0x2ecc9c||_0x4a067e){const _0x1c6190=['Unable\x20to\x20register\x20library\x20\x22'+_0x5b2ef7+'\x22\x20with\x20version\x20\x22'+_0x4fb237+'\x22:'];_0x2ecc9c&&_0x1c6190['push']('library\x20name\x20\x22'+_0x5b2ef7+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x2ecc9c&&_0x4a067e&&_0x1c6190['push']('and'),_0x4a067e&&_0x1c6190['push']('version\x20name\x20\x22'+_0x4fb237+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x1c6190['join']('\x20'));return;}st(new Fe(_0x5b2ef7+'-version',()=>({'library':_0x5b2ef7,'version':_0x4fb237}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x1a70b9,_0x3216ac)=>{switch(_0x3216ac){case 0x0:try{_0x1a70b9['createObjectStore'](Ot);}catch(_0x140ac6){console['warn'](_0x140ac6);}}}})['catch'](_0x3349a8=>{throw me['create']('idb-open',{'originalErrorMessage':_0x3349a8['message']});})),ri;}async function Al(_0x3d52d6){try{const _0x4a7998=(await eo())['transaction'](Ot),_0x4437f2=await _0x4a7998['objectStore'](Ot)['get'](to(_0x3d52d6));return await _0x4a7998['done'],_0x4437f2;}catch(_0x44fa3b){if(_0x44fa3b instanceof Re)oe['warn'](_0x44fa3b['message']);else{const _0x321166=me['create']('idb-get',{'originalErrorMessage':_0x44fa3b==null?void 0x0:_0x44fa3b['message']});oe['warn'](_0x321166['message']);}}}async function Fs(_0x3d259e,_0x1f8bff){try{const _0x407692=(await eo())['transaction'](Ot,'readwrite');await _0x407692['objectStore'](Ot)['put'](_0x1f8bff,to(_0x3d259e)),await _0x407692['done'];}catch(_0x4130d5){if(_0x4130d5 instanceof Re)oe['warn'](_0x4130d5['message']);else{const _0x22c0d5=me['create']('idb-set',{'originalErrorMessage':_0x4130d5==null?void 0x0:_0x4130d5['message']});oe['warn'](_0x22c0d5['message']);}}}function to(_0x321f11){return _0x321f11['name']+'!'+_0x321f11['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x8e21aa){this['container']=_0x8e21aa,this['_heartbeatsCache']=null;const _0x3187e7=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x3187e7),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x27eb6c=>(this['_heartbeatsCache']=_0x27eb6c,_0x27eb6c));}async['triggerHeartbeat'](){var _0x3a720e,_0x384cfd;try{const _0x583212=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x23556e=Us();if(((_0x3a720e=this['_heartbeatsCache'])==null?void 0x0:_0x3a720e['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x384cfd=this['_heartbeatsCache'])==null?void 0x0:_0x384cfd['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x23556e||this['_heartbeatsCache']['heartbeats']['some'](_0x20e246=>_0x20e246['date']===_0x23556e))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x23556e,'agent':_0x583212}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x408f5e=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x408f5e,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x443422){oe['warn'](_0x443422);}}async['getHeartbeatsHeader'](){var _0x360863;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x360863=this['_heartbeatsCache'])==null?void 0x0:_0x360863['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0xe69592=Us(),{heartbeatsToSend:_0x291145,unsentEntries:_0x59a0ed}=Ol(this['_heartbeatsCache']['heartbeats']),_0x551824=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x291145}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0xe69592,_0x59a0ed['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x59a0ed,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x551824;}catch(_0x5a3b65){return oe['warn'](_0x5a3b65),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x542def,_0x30b71b=kl){const _0xe7f4c=[];let _0x25653b=_0x542def['slice']();for(const _0xa0a53d of _0x542def){const _0x1b2119=_0xe7f4c['find'](_0x1a8a86=>_0x1a8a86['agent']===_0xa0a53d['agent']);if(_0x1b2119){if(_0x1b2119['dates']['push'](_0xa0a53d['date']),Ws(_0xe7f4c)>_0x30b71b){_0x1b2119['dates']['pop']();break;}}else{if(_0xe7f4c['push']({'agent':_0xa0a53d['agent'],'dates':[_0xa0a53d['date']]}),Ws(_0xe7f4c)>_0x30b71b){_0xe7f4c['pop']();break;}}_0x25653b=_0x25653b['slice'](0x1);}return{'heartbeatsToSend':_0xe7f4c,'unsentEntries':_0x25653b};}class Dl{constructor(_0x532e81){this['app']=_0x532e81,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x164de3=await Al(this['app']);return _0x164de3!=null&&_0x164de3['heartbeats']?_0x164de3:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x4c37f2){if(await this['_canUseIndexedDBPromise']){const _0x11bb2d=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x4c37f2['lastSentHeartbeatDate']??_0x11bb2d['lastSentHeartbeatDate'],'heartbeats':_0x4c37f2['heartbeats']});}else return;}async['add'](_0x134624){if(await this['_canUseIndexedDBPromise']){const _0x17a6f6=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x134624['lastSentHeartbeatDate']??_0x17a6f6['lastSentHeartbeatDate'],'heartbeats':[..._0x17a6f6['heartbeats'],..._0x134624['heartbeats']]});}else return;}}function Ws(_0x166d84){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x166d84}))['length'];}function Ml(_0x544817){if(_0x544817['length']===0x0)return-0x1;let _0x17c4a3=0x0,_0x494460=_0x544817[0x0]['date'];for(let _0xdd58b2=0x1;_0xdd58b2<_0x544817['length'];_0xdd58b2++)_0x544817[_0xdd58b2]['date']<_0x494460&&(_0x494460=_0x544817[_0xdd58b2]['date'],_0x17c4a3=_0xdd58b2);return _0x17c4a3;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x471bee){st(new Fe('platform-logger',_0x161ebf=>new jc(_0x161ebf),'PRIVATE')),st(new Fe('heartbeat',_0x2bd62d=>new Nl(_0x2bd62d),'PRIVATE')),ye(mi,Ls,_0x471bee),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x1b08fe){no=_0x1b08fe;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x3be931){this['domStorage_']=_0x3be931,this['prefix_']='firebase:';}['set'](_0x70fb3e,_0x665ad8){_0x665ad8==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x70fb3e)):this['domStorage_']['setItem'](this['prefixedName_'](_0x70fb3e),O(_0x665ad8));}['get'](_0x8ba564){const _0x4a2769=this['domStorage_']['getItem'](this['prefixedName_'](_0x8ba564));return _0x4a2769==null?null:Nt(_0x4a2769);}['remove'](_0x57205e){this['domStorage_']['removeItem'](this['prefixedName_'](_0x57205e));}['prefixedName_'](_0x10f263){return this['prefix_']+_0x10f263;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0xe58fee,_0x49261b){_0x49261b==null?delete this['cache_'][_0xe58fee]:this['cache_'][_0xe58fee]=_0x49261b;}['get'](_0x4bed4c){return Q(this['cache_'],_0x4bed4c)?this['cache_'][_0x4bed4c]:null;}['remove'](_0x5d921e){delete this['cache_'][_0x5d921e];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x27e756){try{if(typeof window<'u'&&typeof window[_0x27e756]<'u'){const _0x15c18f=window[_0x27e756];return _0x15c18f['setItem']('firebase:sentinel','cache'),_0x15c18f['removeItem']('firebase:sentinel'),new Wl(_0x15c18f);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x37e69d=0x1;return function(){return _0x37e69d++;};}()),ro=function(_0x2214c4){const _0x236303=Rc(_0x2214c4),_0x189ad4=new Cc();_0x189ad4['update'](_0x236303);const _0xf4cc24=_0x189ad4['digest']();return Fi['encodeByteArray'](_0xf4cc24);},zt=function(..._0x51f85b){let _0xa7781f='';for(let _0x1e8a5e=0x0;_0x1e8a5e<_0x51f85b['length'];_0x1e8a5e++){const _0x592ae5=_0x51f85b[_0x1e8a5e];Array['isArray'](_0x592ae5)||_0x592ae5&&typeof _0x592ae5=='object'&&typeof _0x592ae5['length']=='number'?_0xa7781f+=zt['apply'](null,_0x592ae5):typeof _0x592ae5=='object'?_0xa7781f+=O(_0x592ae5):_0xa7781f+=_0x592ae5,_0xa7781f+='\x20';}return _0xa7781f;};let St=null,$s=!0x0;const Hl=function(_0x3b438c,_0x1d3bb2){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0xa9805){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x263863=zt['apply'](null,_0xa9805);St(_0x263863);}},jt=function(_0x10d72d){return function(..._0x3bda6a){L(_0x10d72d,..._0x3bda6a);};},Ii=function(..._0x4f558b){const _0x5c3356='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x4f558b);Ze['error'](_0x5c3356);},ae=function(..._0x4192d0){const _0x2acdef='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x4192d0);throw Ze['error'](_0x2acdef),new Error(_0x2acdef);},U=function(..._0x15ae58){const _0x325a0b='FIREBASE\x20WARNING:\x20'+zt(..._0x15ae58);Ze['warn'](_0x325a0b);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x32ad79){return typeof _0x32ad79=='number'&&(_0x32ad79!==_0x32ad79||_0x32ad79===Number['POSITIVE_INFINITY']||_0x32ad79===Number['NEGATIVE_INFINITY']);},Gl=function(_0x316535){if(document['readyState']==='complete')_0x316535();else{let _0x2f42a8=!0x1;const _0x5c3c93=function(){if(!document['body']){setTimeout(_0x5c3c93,Math['floor'](0xa));return;}_0x2f42a8||(_0x2f42a8=!0x0,_0x316535());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x5c3c93,!0x1),window['addEventListener']('load',_0x5c3c93,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x5c3c93();}),window['attachEvent']('onload',_0x5c3c93));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x22ae0c,_0x21c31a){if(_0x22ae0c===_0x21c31a)return 0x0;if(_0x22ae0c===We||_0x21c31a===we)return-0x1;if(_0x21c31a===We||_0x22ae0c===we)return 0x1;{const _0x50046e=Gs(_0x22ae0c),_0x50b1d7=Gs(_0x21c31a);return _0x50046e!==null?_0x50b1d7!==null?_0x50046e-_0x50b1d7===0x0?_0x22ae0c['length']-_0x21c31a['length']:_0x50046e-_0x50b1d7:-0x1:_0x50b1d7!==null?0x1:_0x22ae0c<_0x21c31a?-0x1:0x1;}},ql=function(_0x163e7b,_0x189409){return _0x163e7b===_0x189409?0x0:_0x163e7b<_0x189409?-0x1:0x1;},vt=function(_0xd9059a,_0x41bec5){if(_0x41bec5&&_0xd9059a in _0x41bec5)return _0x41bec5[_0xd9059a];throw new Error('Missing\x20required\x20key\x20('+_0xd9059a+')\x20in\x20object:\x20'+O(_0x41bec5));},$i=function(_0x20e8b6){if(typeof _0x20e8b6!='object'||_0x20e8b6===null)return O(_0x20e8b6);const _0x55f153=[];for(const _0x52360a in _0x20e8b6)_0x55f153['push'](_0x52360a);_0x55f153['sort']();let _0x3a1d77='{';for(let _0x366b49=0x0;_0x366b49<_0x55f153['length'];_0x366b49++)_0x366b49!==0x0&&(_0x3a1d77+=','),_0x3a1d77+=O(_0x55f153[_0x366b49]),_0x3a1d77+=':',_0x3a1d77+=$i(_0x20e8b6[_0x55f153[_0x366b49]]);return _0x3a1d77+='}',_0x3a1d77;},oo=function(_0x17027c,_0x3f4e76){const _0x137247=_0x17027c['length'];if(_0x137247<=_0x3f4e76)return[_0x17027c];const _0x165adf=[];for(let _0x9bc93a=0x0;_0x9bc93a<_0x137247;_0x9bc93a+=_0x3f4e76)_0x9bc93a+_0x3f4e76>_0x137247?_0x165adf['push'](_0x17027c['substring'](_0x9bc93a,_0x137247)):_0x165adf['push'](_0x17027c['substring'](_0x9bc93a,_0x9bc93a+_0x3f4e76));return _0x165adf;};function x(_0x4d86cb,_0x4d8d24){for(const _0x52eeb8 in _0x4d86cb)_0x4d86cb['hasOwnProperty'](_0x52eeb8)&&_0x4d8d24(_0x52eeb8,_0x4d86cb[_0x52eeb8]);}const ao=function(_0x56bc37){f(!xn(_0x56bc37),'Invalid\x20JSON\x20number');const _0x360c04=0xb,_0x397151=0x34,_0x19bc38=(0x1<<_0x360c04-0x1)-0x1;let _0xabb04a,_0x43f839,_0x9205c5,_0x297185,_0x403762;_0x56bc37===0x0?(_0x43f839=0x0,_0x9205c5=0x0,_0xabb04a=0x1/_0x56bc37===-0x1/0x0?0x1:0x0):(_0xabb04a=_0x56bc37<0x0,_0x56bc37=Math['abs'](_0x56bc37),_0x56bc37>=Math['pow'](0x2,0x1-_0x19bc38)?(_0x297185=Math['min'](Math['floor'](Math['log'](_0x56bc37)/Math['LN2']),_0x19bc38),_0x43f839=_0x297185+_0x19bc38,_0x9205c5=Math['round'](_0x56bc37*Math['pow'](0x2,_0x397151-_0x297185)-Math['pow'](0x2,_0x397151))):(_0x43f839=0x0,_0x9205c5=Math['round'](_0x56bc37/Math['pow'](0x2,0x1-_0x19bc38-_0x397151))));const _0xa9e821=[];for(_0x403762=_0x397151;_0x403762;_0x403762-=0x1)_0xa9e821['push'](_0x9205c5%0x2?0x1:0x0),_0x9205c5=Math['floor'](_0x9205c5/0x2);for(_0x403762=_0x360c04;_0x403762;_0x403762-=0x1)_0xa9e821['push'](_0x43f839%0x2?0x1:0x0),_0x43f839=Math['floor'](_0x43f839/0x2);_0xa9e821['push'](_0xabb04a?0x1:0x0),_0xa9e821['reverse']();const _0x4ddb73=_0xa9e821['join']('');let _0x1a67da='';for(_0x403762=0x0;_0x403762<0x40;_0x403762+=0x8){let _0x11839a=parseInt(_0x4ddb73['substr'](_0x403762,0x8),0x2)['toString'](0x10);_0x11839a['length']===0x1&&(_0x11839a='0'+_0x11839a),_0x1a67da=_0x1a67da+_0x11839a;}return _0x1a67da['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x1d46e7,_0x190c30){let _0x521572='Unknown\x20Error';_0x1d46e7==='too_big'?_0x521572='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x1d46e7==='permission_denied'?_0x521572='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x1d46e7==='unavailable'&&(_0x521572='The\x20service\x20is\x20unavailable');const _0x163377=new Error(_0x1d46e7+'\x20at\x20'+_0x190c30['_path']['toString']()+':\x20'+_0x521572);return _0x163377['code']=_0x1d46e7['toUpperCase'](),_0x163377;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x1e734d){if(Yl['test'](_0x1e734d)){const _0x11a157=Number(_0x1e734d);if(_0x11a157>=Ql&&_0x11a157<=Jl)return _0x11a157;}return null;},ft=function(_0x2f5ea9){try{_0x2f5ea9();}catch(_0x5d60a0){setTimeout(()=>{const _0x1e57da=_0x5d60a0['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x1e57da),_0x5d60a0;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x324b18,_0x2508d7){const _0x4ff2b1=setTimeout(_0x324b18,_0x2508d7);return typeof _0x4ff2b1=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x4ff2b1):typeof _0x4ff2b1=='object'&&_0x4ff2b1['unref']&&_0x4ff2b1['unref'](),_0x4ff2b1;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x13ae45,_0x229ab1){this['appCheckProvider']=_0x229ab1,this['appName']=_0x13ae45['name'],$(_0x13ae45)&&_0x13ae45['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x13ae45['settings']['appCheckToken']),this['appCheck']=_0x229ab1==null?void 0x0:_0x229ab1['getImmediate']({'optional':!0x0}),this['appCheck']||_0x229ab1==null||_0x229ab1['get']()['then'](_0x72e483=>this['appCheck']=_0x72e483);}['getToken'](_0xd7a613){if(this['serverAppAppCheckToken']){if(_0xd7a613)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0xd7a613):new Promise((_0x247438,_0x1e3a55)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0xd7a613)['then'](_0x247438,_0x1e3a55):_0x247438(null);},0x0);});}['addTokenChangeListener'](_0x7593d9){var _0x67dcdd;(_0x67dcdd=this['appCheckProvider'])==null||_0x67dcdd['get']()['then'](_0x467dff=>_0x467dff['addTokenListener'](_0x7593d9));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x368184,_0x3f69f0,_0x39d517){this['appName_']=_0x368184,this['firebaseOptions_']=_0x3f69f0,this['authProvider_']=_0x39d517,this['auth_']=null,this['auth_']=_0x39d517['getImmediate']({'optional':!0x0}),this['auth_']||_0x39d517['onInit'](_0x6bd4e9=>this['auth_']=_0x6bd4e9);}['getToken'](_0x3f9651){return this['auth_']?this['auth_']['getToken'](_0x3f9651)['catch'](_0x387b3d=>_0x387b3d&&_0x387b3d['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x387b3d)):new Promise((_0x111e26,_0x343000)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x3f9651)['then'](_0x111e26,_0x343000):_0x111e26(null);},0x0);});}['addTokenChangeListener'](_0x945ccc){this['auth_']?this['auth_']['addAuthTokenListener'](_0x945ccc):this['authProvider_']['get']()['then'](_0x7f82c4=>_0x7f82c4['addAuthTokenListener'](_0x945ccc));}['removeTokenChangeListener'](_0x15e27d){this['authProvider_']['get']()['then'](_0x29a08e=>_0x29a08e['removeAuthTokenListener'](_0x15e27d));}['notifyForInvalidToken'](){let _0x285746='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x285746+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x285746+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x285746+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x285746);}}class an{constructor(_0x1c0725){this['accessToken']=_0x1c0725;}['getToken'](_0x133790){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x543712){_0x543712(this['accessToken']);}['removeTokenChangeListener'](_0xae3ba3){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x4a8bdd,_0x53c963,_0x51b022,_0x2a4161,_0x23de54=!0x1,_0x1692fa='',_0x54ee65=!0x1,_0x35cead=!0x1,_0x41ca34=null){this['secure']=_0x53c963,this['namespace']=_0x51b022,this['webSocketOnly']=_0x2a4161,this['nodeAdmin']=_0x23de54,this['persistenceKey']=_0x1692fa,this['includeNamespaceInQueryParams']=_0x54ee65,this['isUsingEmulator']=_0x35cead,this['emulatorOptions']=_0x41ca34,this['_host']=_0x4a8bdd['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x4a8bdd)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x42a768){_0x42a768!==this['internalHost']&&(this['internalHost']=_0x42a768,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x4355f9=this['toURLString']();return this['persistenceKey']&&(_0x4355f9+='<'+this['persistenceKey']+'>'),_0x4355f9;}['toURLString'](){const _0x30c532=this['secure']?'https://':'http://',_0x573040=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x30c532+this['host']+'/'+_0x573040;}}function th(_0x4626ec){return _0x4626ec['host']!==_0x4626ec['internalHost']||_0x4626ec['isCustomHost']()||_0x4626ec['includeNamespaceInQueryParams'];}function vo(_0x59c9b2,_0x5ba3e6,_0x1a3951){f(typeof _0x5ba3e6=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x1a3951=='object','typeof\x20params\x20must\x20==\x20object');let _0x48c1e1;if(_0x5ba3e6===go)_0x48c1e1=(_0x59c9b2['secure']?'wss://':'ws://')+_0x59c9b2['internalHost']+'/.ws?';else{if(_0x5ba3e6===mo)_0x48c1e1=(_0x59c9b2['secure']?'https://':'http://')+_0x59c9b2['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x5ba3e6);}th(_0x59c9b2)&&(_0x1a3951['ns']=_0x59c9b2['namespace']);const _0x3408af=[];return x(_0x1a3951,(_0x269287,_0x3fcfe8)=>{_0x3408af['push'](_0x269287+'='+_0x3fcfe8);}),_0x48c1e1+_0x3408af['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x46423c,_0x44bfe6=0x1){Q(this['counters_'],_0x46423c)||(this['counters_'][_0x46423c]=0x0),this['counters_'][_0x46423c]+=_0x44bfe6;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x2b951c){const _0x53e7c1=_0x2b951c['toString']();return oi[_0x53e7c1]||(oi[_0x53e7c1]=new nh()),oi[_0x53e7c1];}function ih(_0x162105,_0x161de9){const _0x4f34af=_0x162105['toString']();return ai[_0x4f34af]||(ai[_0x4f34af]=_0x161de9()),ai[_0x4f34af];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x4af377){this['onMessage_']=_0x4af377,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0xa4c68a,_0x3a2eee){this['closeAfterResponse']=_0xa4c68a,this['onClose']=_0x3a2eee,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x2ec6e2,_0x224c25){for(this['pendingResponses'][_0x2ec6e2]=_0x224c25;this['pendingResponses'][this['currentResponseNum']];){const _0xd8003d=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0xd4970f=0x0;_0xd4970f<_0xd8003d['length'];++_0xd4970f)_0xd8003d[_0xd4970f]&&ft(()=>{this['onMessage_'](_0xd8003d[_0xd4970f]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x48466a,_0x51c466,_0x187ec1,_0x4e91e3,_0x95a42,_0x26140d,_0x20099e){this['connId']=_0x48466a,this['repoInfo']=_0x51c466,this['applicationId']=_0x187ec1,this['appCheckToken']=_0x4e91e3,this['authToken']=_0x95a42,this['transportSessionId']=_0x26140d,this['lastSessionId']=_0x20099e,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x48466a),this['stats_']=qi(_0x51c466),this['urlFn']=_0x15cf19=>(this['appCheckToken']&&(_0x15cf19[wi]=this['appCheckToken']),vo(_0x51c466,mo,_0x15cf19));}['open'](_0x327a40,_0x447b32){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x447b32,this['myPacketOrderer']=new sh(_0x327a40),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x2dc885)=>{const [_0x5aba36,_0x19ba30,_0x436c81,_0x2c4f0f,_0x4fad8c]=_0x2dc885;if(this['incrementIncomingBytes_'](_0x2dc885),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x5aba36===qs)this['id']=_0x19ba30,this['password']=_0x436c81;else{if(_0x5aba36===rh)_0x19ba30?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x19ba30,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x5aba36);}}},(..._0x392d8d)=>{const [_0x27d278,_0x584c45]=_0x392d8d;this['incrementIncomingBytes_'](_0x392d8d),this['myPacketOrderer']['handleResponse'](_0x27d278,_0x584c45);},()=>{this['onClosed_']();},this['urlFn']);const _0x4e71e7={};_0x4e71e7[qs]='t',_0x4e71e7[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x4e71e7[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x4e71e7[co]=Gi,this['transportSessionId']&&(_0x4e71e7[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x4e71e7[po]=this['lastSessionId']),this['applicationId']&&(_0x4e71e7[_o]=this['applicationId']),this['appCheckToken']&&(_0x4e71e7[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x4e71e7[ho]=uo);const _0x429961=this['urlFn'](_0x4e71e7);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x429961),this['scriptTagHolder']['addTag'](_0x429961,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x1b08e3){const _0xfee185=O(_0x1b08e3);this['bytesSent']+=_0xfee185['length'],this['stats_']['incrementCounter']('bytes_sent',_0xfee185['length']);const _0x181480=$r(_0xfee185),_0x503fda=oo(_0x181480,fh);for(let _0x4a83b3=0x0;_0x4a83b3<_0x503fda['length'];_0x4a83b3++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x503fda['length'],_0x503fda[_0x4a83b3]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x40d1de,_0x257878){this['myDisconnFrame']=document['createElement']('iframe');const _0x57c86b={};_0x57c86b[dh]='t',_0x57c86b[Eo]=_0x40d1de,_0x57c86b[Io]=_0x257878,this['myDisconnFrame']['src']=this['urlFn'](_0x57c86b),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x44e80b){const _0x12e486=O(_0x44e80b)['length'];this['bytesReceived']+=_0x12e486,this['stats_']['incrementCounter']('bytes_received',_0x12e486);}}class zi{constructor(_0x51597e,_0x54dcab,_0x508c42,_0x24bedf){this['onDisconnect']=_0x508c42,this['urlFn']=_0x24bedf,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x51597e,window[ah+this['uniqueCallbackIdentifier']]=_0x54dcab,this['myIFrame']=zi['createIFrame_']();let _0x4f0733='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x4f0733='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x68f12e='<html><body>'+_0x4f0733+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x68f12e),this['myIFrame']['doc']['close']();}catch(_0x126903){L('frame\x20writing\x20exception'),_0x126903['stack']&&L(_0x126903['stack']),L(_0x126903);}}}static['createIFrame_'](){const _0x4a8833=document['createElement']('iframe');if(_0x4a8833['style']['display']='none',document['body']){document['body']['appendChild'](_0x4a8833);try{_0x4a8833['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x1443a3=document['domain'];_0x4a8833['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x1443a3+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x4a8833['contentDocument']?_0x4a8833['doc']=_0x4a8833['contentDocument']:_0x4a8833['contentWindow']?_0x4a8833['doc']=_0x4a8833['contentWindow']['document']:_0x4a8833['document']&&(_0x4a8833['doc']=_0x4a8833['document']),_0x4a8833;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x15f037=this['onDisconnect'];_0x15f037&&(this['onDisconnect']=null,_0x15f037());}['startLongPoll'](_0x17326d,_0x47f51f){for(this['myID']=_0x17326d,this['myPW']=_0x47f51f,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x255bad={};_0x255bad[Eo]=this['myID'],_0x255bad[Io]=this['myPW'],_0x255bad[wo]=this['currentSerial'];let _0x341d65=this['urlFn'](_0x255bad),_0x5b5db1='',_0x3285d3=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x5b5db1['length']<=Co;){const _0x285b25=this['pendingSegs']['shift']();_0x5b5db1=_0x5b5db1+'&'+lh+_0x3285d3+'='+_0x285b25['seg']+'&'+hh+_0x3285d3+'='+_0x285b25['ts']+'&'+uh+_0x3285d3+'='+_0x285b25['d'],_0x3285d3++;}return _0x341d65=_0x341d65+_0x5b5db1,this['addLongPollTag_'](_0x341d65,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x7f746b,_0x97939f,_0x55029c){this['pendingSegs']['push']({'seg':_0x7f746b,'ts':_0x97939f,'d':_0x55029c}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x1f676e,_0x2e0df7){this['outstandingRequests']['add'](_0x2e0df7);const _0x4fd8ec=()=>{this['outstandingRequests']['delete'](_0x2e0df7),this['newRequest_']();},_0xda4ada=setTimeout(_0x4fd8ec,Math['floor'](ph)),_0x29141f=()=>{clearTimeout(_0xda4ada),_0x4fd8ec();};this['addTag'](_0x1f676e,_0x29141f);}['addTag'](_0x42037d,_0x54eaf5){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x4ee75e=this['myIFrame']['doc']['createElement']('script');_0x4ee75e['type']='text/javascript',_0x4ee75e['async']=!0x0,_0x4ee75e['src']=_0x42037d,_0x4ee75e['onload']=_0x4ee75e['onreadystatechange']=function(){const _0x54a900=_0x4ee75e['readyState'];(!_0x54a900||_0x54a900==='loaded'||_0x54a900==='complete')&&(_0x4ee75e['onload']=_0x4ee75e['onreadystatechange']=null,_0x4ee75e['parentNode']&&_0x4ee75e['parentNode']['removeChild'](_0x4ee75e),_0x54eaf5());},_0x4ee75e['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x42037d),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x4ee75e);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x43d517,_0x526df2,_0x585b4d,_0x2144f1,_0x254c35,_0x3959a0,_0x47e1d7){this['connId']=_0x43d517,this['applicationId']=_0x585b4d,this['appCheckToken']=_0x2144f1,this['authToken']=_0x254c35,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x526df2),this['connURL']=q['connectionURL_'](_0x526df2,_0x3959a0,_0x47e1d7,_0x2144f1,_0x585b4d),this['nodeAdmin']=_0x526df2['nodeAdmin'];}static['connectionURL_'](_0x79d0ab,_0x4af491,_0x3893fb,_0x21c234,_0x1742d5){const _0x17d025={};return _0x17d025[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x17d025[ho]=uo),_0x4af491&&(_0x17d025[lo]=_0x4af491),_0x3893fb&&(_0x17d025[po]=_0x3893fb),_0x21c234&&(_0x17d025[wi]=_0x21c234),_0x1742d5&&(_0x17d025[_o]=_0x1742d5),vo(_0x79d0ab,go,_0x17d025);}['open'](_0x2b40d5,_0x297246){this['onDisconnect']=_0x297246,this['onMessage']=_0x2b40d5,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x1904e3;_c(),this['mySock']=new gn(this['connURL'],[],_0x1904e3);}catch(_0x224573){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x59cb7f=_0x224573['message']||_0x224573['data'];_0x59cb7f&&this['log_'](_0x59cb7f),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x2f319f=>{this['handleIncomingFrame'](_0x2f319f);},this['mySock']['onerror']=_0x59e102=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x845c90=_0x59e102['message']||_0x59e102['data'];_0x845c90&&this['log_'](_0x845c90),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x119887=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x4a4b74=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x4d1a5e=navigator['userAgent']['match'](_0x4a4b74);_0x4d1a5e&&_0x4d1a5e['length']>0x1&&parseFloat(_0x4d1a5e[0x1])<4.4&&(_0x119887=!0x0);}return!_0x119887&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x36f9d6){if(this['frames']['push'](_0x36f9d6),this['frames']['length']===this['totalFrames']){const _0x28e0ca=this['frames']['join']('');this['frames']=null;const _0x4e9d09=Nt(_0x28e0ca);this['onMessage'](_0x4e9d09);}}['handleNewFrameCount_'](_0x1d4f43){this['totalFrames']=_0x1d4f43,this['frames']=[];}['extractFrameCount_'](_0x168822){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x168822['length']<=0x6){const _0x48523e=Number(_0x168822);if(!isNaN(_0x48523e))return this['handleNewFrameCount_'](_0x48523e),null;}return this['handleNewFrameCount_'](0x1),_0x168822;}['handleIncomingFrame'](_0x2661cd){if(this['mySock']===null)return;const _0x2e1f1f=_0x2661cd['data'];if(this['bytesReceived']+=_0x2e1f1f['length'],this['stats_']['incrementCounter']('bytes_received',_0x2e1f1f['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x2e1f1f);else{const _0x3c7900=this['extractFrameCount_'](_0x2e1f1f);_0x3c7900!==null&&this['appendFrame_'](_0x3c7900);}}['send'](_0x3e49f5){this['resetKeepAlive']();const _0x338164=O(_0x3e49f5);this['bytesSent']+=_0x338164['length'],this['stats_']['incrementCounter']('bytes_sent',_0x338164['length']);const _0x47de53=oo(_0x338164,gh);_0x47de53['length']>0x1&&this['sendString_'](String(_0x47de53['length']));for(let _0x54807a=0x0;_0x54807a<_0x47de53['length'];_0x54807a++)this['sendString_'](_0x47de53[_0x54807a]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0xb40ed0){try{this['mySock']['send'](_0xb40ed0);}catch(_0x43bc9c){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x43bc9c['message']||_0x43bc9c['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x582497){this['initTransports_'](_0x582497);}['initTransports_'](_0x345574){const _0xed59af=q&&q['isAvailable']();let _0x5afae4=_0xed59af&&!q['previouslyFailed']();if(_0x345574['webSocketOnly']&&(_0xed59af||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x5afae4=!0x0),_0x5afae4)this['transports_']=[q];else{const _0x149e04=this['transports_']=[];for(const _0x125cfd of Dt['ALL_TRANSPORTS'])_0x125cfd&&_0x125cfd['isAvailable']()&&_0x149e04['push'](_0x125cfd);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x3d256b,_0x553637,_0x3cdded,_0x524888,_0x3cb2b0,_0x17523b,_0x4dd5e0,_0x40486a,_0x24a9fe,_0x321864){this['id']=_0x3d256b,this['repoInfo_']=_0x553637,this['applicationId_']=_0x3cdded,this['appCheckToken_']=_0x524888,this['authToken_']=_0x3cb2b0,this['onMessage_']=_0x17523b,this['onReady_']=_0x4dd5e0,this['onDisconnect_']=_0x40486a,this['onKill_']=_0x24a9fe,this['lastSessionId']=_0x321864,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x553637),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x202627=this['transportManager_']['initialTransport']();this['conn_']=new _0x202627(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x202627['responsesRequiredToBeHealthy']||0x0;const _0x5f1414=this['connReceiver_'](this['conn_']),_0x5ed360=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x5f1414,_0x5ed360);},Math['floor'](0x0));const _0x3f509f=_0x202627['healthyTimeout']||0x0;_0x3f509f>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x3f509f)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x51329f){return _0x742aaa=>{_0x51329f===this['conn_']?this['onConnectionLost_'](_0x742aaa):_0x51329f===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x5aa918){return _0x54bd1d=>{this['state_']!==0x2&&(_0x5aa918===this['rx_']?this['onPrimaryMessageReceived_'](_0x54bd1d):_0x5aa918===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x54bd1d):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x4ce140){const _0x1cf288={'t':'d','d':_0x4ce140};this['sendData_'](_0x1cf288);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x3bd7ce){if(ci in _0x3bd7ce){const _0xc77607=_0x3bd7ce[ci];_0xc77607===Ys?this['upgradeIfSecondaryHealthy_']():_0xc77607===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0xc77607===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x3793e2){const _0x47be70=vt('t',_0x3793e2),_0x1c2339=vt('d',_0x3793e2);if(_0x47be70==='c')this['onSecondaryControl_'](_0x1c2339);else{if(_0x47be70==='d')this['pendingDataMessages']['push'](_0x1c2339);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x47be70);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x2d2e61){const _0xc1d8f8=vt('t',_0x2d2e61),_0x42a23c=vt('d',_0x2d2e61);_0xc1d8f8==='c'?this['onControl_'](_0x42a23c):_0xc1d8f8==='d'&&this['onDataMessage_'](_0x42a23c);}['onDataMessage_'](_0x3e11b6){this['onPrimaryResponse_'](),this['onMessage_'](_0x3e11b6);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x4a9fba){const _0x2fbe68=vt(ci,_0x4a9fba);if(zs in _0x4a9fba){const _0x1a2d84=_0x4a9fba[zs];if(_0x2fbe68===Th){const _0x2fe404={..._0x1a2d84};this['repoInfo_']['isUsingEmulator']&&(_0x2fe404['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x2fe404);}else{if(_0x2fbe68===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x51cfd5=0x0;_0x51cfd5<this['pendingDataMessages']['length'];++_0x51cfd5)this['onDataMessage_'](this['pendingDataMessages'][_0x51cfd5]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x2fbe68===wh?this['onConnectionShutdown_'](_0x1a2d84):_0x2fbe68===js?this['onReset_'](_0x1a2d84):_0x2fbe68===Ch?Ii('Server\x20Error:\x20'+_0x1a2d84):_0x2fbe68===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x2fbe68);}}}['onHandshake_'](_0x2b4530){const _0x6b4008=_0x2b4530['ts'],_0x5ebd2d=_0x2b4530['v'],_0x15324c=_0x2b4530['h'];this['sessionId']=_0x2b4530['s'],this['repoInfo_']['host']=_0x15324c,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x6b4008),Gi!==_0x5ebd2d&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x336825=this['transportManager_']['upgradeTransport']();_0x336825&&this['startUpgrade_'](_0x336825);}['startUpgrade_'](_0x882c29){this['secondaryConn_']=new _0x882c29(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x882c29['responsesRequiredToBeHealthy']||0x0;const _0x5079e9=this['connReceiver_'](this['secondaryConn_']),_0x1b24db=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x5079e9,_0x1b24db),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x5d57d6){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x5d57d6),this['repoInfo_']['host']=_0x5d57d6,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x4ef93f,_0x2fb9df){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x4ef93f,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x2fb9df,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x2fe9ac=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x2fe9ac||this['rx_']===_0x2fe9ac)&&this['close']();}['onConnectionLost_'](_0x2b7f73){this['conn_']=null,!_0x2b7f73&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x415227){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x415227),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x12c555){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x12c555);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x16ba47,_0x4b5bd0,_0x1fbc78,_0x429d59){}['merge'](_0x5a459c,_0x28ca23,_0x3c6989,_0xc7e58){}['refreshAuthToken'](_0x5c77eb){}['refreshAppCheckToken'](_0x158a80){}['onDisconnectPut'](_0x5c289e,_0x2ab8cd,_0x2d6455){}['onDisconnectMerge'](_0x3cbc60,_0x48a064,_0x42a354){}['onDisconnectCancel'](_0x62ec8c,_0x4ed9cf){}['reportStats'](_0x5d3b7e){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x9bac16){this['allowedEvents_']=_0x9bac16,this['listeners_']={},f(Array['isArray'](_0x9bac16)&&_0x9bac16['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x147bca,..._0x208408){if(Array['isArray'](this['listeners_'][_0x147bca])){const _0x2174c9=[...this['listeners_'][_0x147bca]];for(let _0xdba60f=0x0;_0xdba60f<_0x2174c9['length'];_0xdba60f++)_0x2174c9[_0xdba60f]['callback']['apply'](_0x2174c9[_0xdba60f]['context'],_0x208408);}}['on'](_0x20db78,_0x450632,_0x22e45c){this['validateEventType_'](_0x20db78),this['listeners_'][_0x20db78]=this['listeners_'][_0x20db78]||[],this['listeners_'][_0x20db78]['push']({'callback':_0x450632,'context':_0x22e45c});const _0x1433a9=this['getInitialEvent'](_0x20db78);_0x1433a9&&_0x450632['apply'](_0x22e45c,_0x1433a9);}['off'](_0xc6c6a9,_0x4a0c27,_0x27f3ea){this['validateEventType_'](_0xc6c6a9);const _0x4a6bd0=this['listeners_'][_0xc6c6a9]||[];for(let _0xa703a2=0x0;_0xa703a2<_0x4a6bd0['length'];_0xa703a2++)if(_0x4a6bd0[_0xa703a2]['callback']===_0x4a0c27&&(!_0x27f3ea||_0x27f3ea===_0x4a6bd0[_0xa703a2]['context'])){_0x4a6bd0['splice'](_0xa703a2,0x1);return;}}['validateEventType_'](_0x21db92){f(this['allowedEvents_']['find'](_0x57bf30=>_0x57bf30===_0x21db92),'Unknown\x20event:\x20'+_0x21db92);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x46254d){return f(_0x46254d==='online','Unknown\x20event\x20type:\x20'+_0x46254d),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x260b19,_0x200683){if(_0x200683===void 0x0){this['pieces_']=_0x260b19['split']('/');let _0x16425d=0x0;for(let _0x30b158=0x0;_0x30b158<this['pieces_']['length'];_0x30b158++)this['pieces_'][_0x30b158]['length']>0x0&&(this['pieces_'][_0x16425d]=this['pieces_'][_0x30b158],_0x16425d++);this['pieces_']['length']=_0x16425d,this['pieceNum_']=0x0;}else this['pieces_']=_0x260b19,this['pieceNum_']=_0x200683;}['toString'](){let _0x4b6982='';for(let _0x2fa84c=this['pieceNum_'];_0x2fa84c<this['pieces_']['length'];_0x2fa84c++)this['pieces_'][_0x2fa84c]!==''&&(_0x4b6982+='/'+this['pieces_'][_0x2fa84c]);return _0x4b6982||'/';}}function w(){return new C('');}function y(_0x5d5390){return _0x5d5390['pieceNum_']>=_0x5d5390['pieces_']['length']?null:_0x5d5390['pieces_'][_0x5d5390['pieceNum_']];}function Ce(_0x16d5da){return _0x16d5da['pieces_']['length']-_0x16d5da['pieceNum_'];}function S(_0x544597){let _0x32a4dc=_0x544597['pieceNum_'];return _0x32a4dc<_0x544597['pieces_']['length']&&_0x32a4dc++,new C(_0x544597['pieces_'],_0x32a4dc);}function ji(_0x59f40d){return _0x59f40d['pieceNum_']<_0x59f40d['pieces_']['length']?_0x59f40d['pieces_'][_0x59f40d['pieces_']['length']-0x1]:null;}function bh(_0x282a64){let _0x112341='';for(let _0x2d8b25=_0x282a64['pieceNum_'];_0x2d8b25<_0x282a64['pieces_']['length'];_0x2d8b25++)_0x282a64['pieces_'][_0x2d8b25]!==''&&(_0x112341+='/'+encodeURIComponent(String(_0x282a64['pieces_'][_0x2d8b25])));return _0x112341||'/';}function Mt(_0x65d947,_0x505c2c=0x0){return _0x65d947['pieces_']['slice'](_0x65d947['pieceNum_']+_0x505c2c);}function Ro(_0x1a7bdc){if(_0x1a7bdc['pieceNum_']>=_0x1a7bdc['pieces_']['length'])return null;const _0x2cc3bf=[];for(let _0x1b3953=_0x1a7bdc['pieceNum_'];_0x1b3953<_0x1a7bdc['pieces_']['length']-0x1;_0x1b3953++)_0x2cc3bf['push'](_0x1a7bdc['pieces_'][_0x1b3953]);return new C(_0x2cc3bf,0x0);}function k(_0x139bd8,_0x2203bd){const _0x18eb4f=[];for(let _0x4434bd=_0x139bd8['pieceNum_'];_0x4434bd<_0x139bd8['pieces_']['length'];_0x4434bd++)_0x18eb4f['push'](_0x139bd8['pieces_'][_0x4434bd]);if(_0x2203bd instanceof C){for(let _0x580761=_0x2203bd['pieceNum_'];_0x580761<_0x2203bd['pieces_']['length'];_0x580761++)_0x18eb4f['push'](_0x2203bd['pieces_'][_0x580761]);}else{const _0x3ae5f5=_0x2203bd['split']('/');for(let _0x8502e1=0x0;_0x8502e1<_0x3ae5f5['length'];_0x8502e1++)_0x3ae5f5[_0x8502e1]['length']>0x0&&_0x18eb4f['push'](_0x3ae5f5[_0x8502e1]);}return new C(_0x18eb4f,0x0);}function v(_0xf5204c){return _0xf5204c['pieceNum_']>=_0xf5204c['pieces_']['length'];}function F(_0x387876,_0x53238c){const _0x41d577=y(_0x387876),_0x2d2364=y(_0x53238c);if(_0x41d577===null)return _0x53238c;if(_0x41d577===_0x2d2364)return F(S(_0x387876),S(_0x53238c));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x53238c+')\x20is\x20not\x20within\x20outerPath\x20('+_0x387876+')');}function Rh(_0x9d112,_0x208fcb){const _0x3c3811=Mt(_0x9d112,0x0),_0x1592a8=Mt(_0x208fcb,0x0);for(let _0x37ff3c=0x0;_0x37ff3c<_0x3c3811['length']&&_0x37ff3c<_0x1592a8['length'];_0x37ff3c++){const _0x5f3c03=qe(_0x3c3811[_0x37ff3c],_0x1592a8[_0x37ff3c]);if(_0x5f3c03!==0x0)return _0x5f3c03;}return _0x3c3811['length']===_0x1592a8['length']?0x0:_0x3c3811['length']<_0x1592a8['length']?-0x1:0x1;}function Ki(_0x22c3a3,_0x5a96de){if(Ce(_0x22c3a3)!==Ce(_0x5a96de))return!0x1;for(let _0x532f07=_0x22c3a3['pieceNum_'],_0x4d1772=_0x5a96de['pieceNum_'];_0x532f07<=_0x22c3a3['pieces_']['length'];_0x532f07++,_0x4d1772++)if(_0x22c3a3['pieces_'][_0x532f07]!==_0x5a96de['pieces_'][_0x4d1772])return!0x1;return!0x0;}function G(_0x4eaf10,_0x317187){let _0x4da20e=_0x4eaf10['pieceNum_'],_0x5ef5f3=_0x317187['pieceNum_'];if(Ce(_0x4eaf10)>Ce(_0x317187))return!0x1;for(;_0x4da20e<_0x4eaf10['pieces_']['length'];){if(_0x4eaf10['pieces_'][_0x4da20e]!==_0x317187['pieces_'][_0x5ef5f3])return!0x1;++_0x4da20e,++_0x5ef5f3;}return!0x0;}class Ah{constructor(_0x177b72,_0x5be78e){this['errorPrefix_']=_0x5be78e,this['parts_']=Mt(_0x177b72,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x35b6db=0x0;_0x35b6db<this['parts_']['length'];_0x35b6db++)this['byteLength_']+=Ln(this['parts_'][_0x35b6db]);Ao(this);}}function kh(_0x84fb94,_0x5110f8){_0x84fb94['parts_']['length']>0x0&&(_0x84fb94['byteLength_']+=0x1),_0x84fb94['parts_']['push'](_0x5110f8),_0x84fb94['byteLength_']+=Ln(_0x5110f8),Ao(_0x84fb94);}function Ph(_0x6c71e6){const _0x5ccc5f=_0x6c71e6['parts_']['pop']();_0x6c71e6['byteLength_']-=Ln(_0x5ccc5f),_0x6c71e6['parts_']['length']>0x0&&(_0x6c71e6['byteLength_']-=0x1);}function Ao(_0x25f955){if(_0x25f955['byteLength_']>Zs)throw new Error(_0x25f955['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0x25f955['byteLength_']+').');if(_0x25f955['parts_']['length']>Xs)throw new Error(_0x25f955['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0x25f955));}function Oe(_0x2670c7){return _0x2670c7['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x2670c7['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x31668d,_0x35c19b;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x35c19b='visibilitychange',_0x31668d='hidden'):typeof document['mozHidden']<'u'?(_0x35c19b='mozvisibilitychange',_0x31668d='mozHidden'):typeof document['msHidden']<'u'?(_0x35c19b='msvisibilitychange',_0x31668d='msHidden'):typeof document['webkitHidden']<'u'&&(_0x35c19b='webkitvisibilitychange',_0x31668d='webkitHidden')),this['visible_']=!0x0,_0x35c19b&&document['addEventListener'](_0x35c19b,()=>{const _0x1e3e7d=!document[_0x31668d];_0x1e3e7d!==this['visible_']&&(this['visible_']=_0x1e3e7d,this['trigger']('visible',_0x1e3e7d));},!0x1);}['getInitialEvent'](_0x3bf3a2){return f(_0x3bf3a2==='visible','Unknown\x20event\x20type:\x20'+_0x3bf3a2),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x4f3331,_0x197abf,_0x46a89c,_0xcd40ba,_0x20c10a,_0x521701,_0x3e89f4,_0x4cb2c5){if(super(),this['repoInfo_']=_0x4f3331,this['applicationId_']=_0x197abf,this['onDataUpdate_']=_0x46a89c,this['onConnectStatus_']=_0xcd40ba,this['onServerInfoUpdate_']=_0x20c10a,this['authTokenProvider_']=_0x521701,this['appCheckTokenProvider_']=_0x3e89f4,this['authOverride_']=_0x4cb2c5,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x4cb2c5)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x4f3331['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x287fbb,_0x34e18d,_0x4b4111){const _0x402022=++this['requestNumber_'],_0x35a01f={'r':_0x402022,'a':_0x287fbb,'b':_0x34e18d};this['log_'](O(_0x35a01f)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x35a01f),_0x4b4111&&(this['requestCBHash_'][_0x402022]=_0x4b4111);}['get'](_0x2cfeb2){this['initConnection_']();const _0x1f04d6=new H(),_0x37dc2c={'action':'g','request':{'p':_0x2cfeb2['_path']['toString'](),'q':_0x2cfeb2['_queryObject']},'onComplete':_0x5bf5a2=>{const _0x5108b1=_0x5bf5a2['d'];_0x5bf5a2['s']==='ok'?_0x1f04d6['resolve'](_0x5108b1):_0x1f04d6['reject'](_0x5108b1);}};this['outstandingGets_']['push'](_0x37dc2c),this['outstandingGetCount_']++;const _0x2304f1=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x2304f1),_0x1f04d6['promise'];}['listen'](_0x5a90a8,_0x21bbd0,_0x255698,_0x33e1fb){this['initConnection_']();const _0x534529=_0x5a90a8['_queryIdentifier'],_0xb3788b=_0x5a90a8['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0xb3788b+'\x20'+_0x534529),this['listens']['has'](_0xb3788b)||this['listens']['set'](_0xb3788b,new Map()),f(_0x5a90a8['_queryParams']['isDefault']()||!_0x5a90a8['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0xb3788b)['has'](_0x534529),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x44602a={'onComplete':_0x33e1fb,'hashFn':_0x21bbd0,'query':_0x5a90a8,'tag':_0x255698};this['listens']['get'](_0xb3788b)['set'](_0x534529,_0x44602a),this['connected_']&&this['sendListen_'](_0x44602a);}['sendGet_'](_0x55d7b3){const _0x5cc437=this['outstandingGets_'][_0x55d7b3];this['sendRequest']('g',_0x5cc437['request'],_0x3bf40b=>{delete this['outstandingGets_'][_0x55d7b3],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x5cc437['onComplete']&&_0x5cc437['onComplete'](_0x3bf40b);});}['sendListen_'](_0x4acadb){const _0x5ee13c=_0x4acadb['query'],_0x17039c=_0x5ee13c['_path']['toString'](),_0x4f2313=_0x5ee13c['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x17039c+'\x20for\x20'+_0x4f2313);const _0x5bf80d={'p':_0x17039c},_0x2c7b22='q';_0x4acadb['tag']&&(_0x5bf80d['q']=_0x5ee13c['_queryObject'],_0x5bf80d['t']=_0x4acadb['tag']),_0x5bf80d['h']=_0x4acadb['hashFn'](),this['sendRequest'](_0x2c7b22,_0x5bf80d,_0x2781fa=>{const _0x146f4e=_0x2781fa['d'],_0x2416e2=_0x2781fa['s'];se['warnOnListenWarnings_'](_0x146f4e,_0x5ee13c),(this['listens']['get'](_0x17039c)&&this['listens']['get'](_0x17039c)['get'](_0x4f2313))===_0x4acadb&&(this['log_']('listen\x20response',_0x2781fa),_0x2416e2!=='ok'&&this['removeListen_'](_0x17039c,_0x4f2313),_0x4acadb['onComplete']&&_0x4acadb['onComplete'](_0x2416e2,_0x146f4e));});}static['warnOnListenWarnings_'](_0x568146,_0x167f06){if(_0x568146&&typeof _0x568146=='object'&&Q(_0x568146,'w')){const _0x4c4ea5=Le(_0x568146,'w');if(Array['isArray'](_0x4c4ea5)&&~_0x4c4ea5['indexOf']('no_index')){const _0x41a3d7='\x22.indexOn\x22:\x20\x22'+_0x167f06['_queryParams']['getIndex']()['toString']()+'\x22',_0x4632a4=_0x167f06['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x41a3d7+'\x20at\x20'+_0x4632a4+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x323c2a){this['authToken_']=_0x323c2a,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x323c2a);}['reduceReconnectDelayIfAdminCredential_'](_0x30f542){(_0x30f542&&_0x30f542['length']===0x28||wc(_0x30f542))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x3bd93f){this['appCheckToken_']=_0x3bd93f,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x221401=this['authToken_'],_0x39b32c=Ic(_0x221401)?'auth':'gauth',_0x23b7da={'cred':_0x221401};this['authOverride_']===null?_0x23b7da['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x23b7da['authvar']=this['authOverride_']),this['sendRequest'](_0x39b32c,_0x23b7da,_0x11d7bb=>{const _0x35a01e=_0x11d7bb['s'],_0x3a708f=_0x11d7bb['d']||'error';this['authToken_']===_0x221401&&(_0x35a01e==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x35a01e,_0x3a708f));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x141098=>{const _0x2d9430=_0x141098['s'],_0x5e2a87=_0x141098['d']||'error';_0x2d9430==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x2d9430,_0x5e2a87);});}['unlisten'](_0x487fbe,_0x57fb54){const _0x5d6b9c=_0x487fbe['_path']['toString'](),_0x28407d=_0x487fbe['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x5d6b9c+'\x20'+_0x28407d),f(_0x487fbe['_queryParams']['isDefault']()||!_0x487fbe['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x5d6b9c,_0x28407d)&&this['connected_']&&this['sendUnlisten_'](_0x5d6b9c,_0x28407d,_0x487fbe['_queryObject'],_0x57fb54);}['sendUnlisten_'](_0x243607,_0xd5e23e,_0x45d525,_0x4445a0){this['log_']('Unlisten\x20on\x20'+_0x243607+'\x20for\x20'+_0xd5e23e);const _0x49c492={'p':_0x243607},_0x119b61='n';_0x4445a0&&(_0x49c492['q']=_0x45d525,_0x49c492['t']=_0x4445a0),this['sendRequest'](_0x119b61,_0x49c492);}['onDisconnectPut'](_0x58a554,_0x559b0a,_0x135832){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x58a554,_0x559b0a,_0x135832):this['onDisconnectRequestQueue_']['push']({'pathString':_0x58a554,'action':'o','data':_0x559b0a,'onComplete':_0x135832});}['onDisconnectMerge'](_0x1af579,_0x2ff141,_0xf31ccf){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x1af579,_0x2ff141,_0xf31ccf):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1af579,'action':'om','data':_0x2ff141,'onComplete':_0xf31ccf});}['onDisconnectCancel'](_0x539b61,_0xc71fb8){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x539b61,null,_0xc71fb8):this['onDisconnectRequestQueue_']['push']({'pathString':_0x539b61,'action':'oc','data':null,'onComplete':_0xc71fb8});}['sendOnDisconnect_'](_0x1d9d49,_0x506ec3,_0x361de3,_0x111049){const _0x3c1d56={'p':_0x506ec3,'d':_0x361de3};this['log_']('onDisconnect\x20'+_0x1d9d49,_0x3c1d56),this['sendRequest'](_0x1d9d49,_0x3c1d56,_0x54bd10=>{_0x111049&&setTimeout(()=>{_0x111049(_0x54bd10['s'],_0x54bd10['d']);},Math['floor'](0x0));});}['put'](_0x5f3482,_0x31bf91,_0x4250d4,_0x1e5d01){this['putInternal']('p',_0x5f3482,_0x31bf91,_0x4250d4,_0x1e5d01);}['merge'](_0x562978,_0x1b8808,_0x352492,_0x81239d){this['putInternal']('m',_0x562978,_0x1b8808,_0x352492,_0x81239d);}['putInternal'](_0x2812c6,_0x19df8e,_0x27d098,_0x34a9cb,_0x211615){this['initConnection_']();const _0x1d705e={'p':_0x19df8e,'d':_0x27d098};_0x211615!==void 0x0&&(_0x1d705e['h']=_0x211615),this['outstandingPuts_']['push']({'action':_0x2812c6,'request':_0x1d705e,'onComplete':_0x34a9cb}),this['outstandingPutCount_']++;const _0x4788bb=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x4788bb):this['log_']('Buffering\x20put:\x20'+_0x19df8e);}['sendPut_'](_0x2cdddc){const _0xc4208c=this['outstandingPuts_'][_0x2cdddc]['action'],_0x3d6a62=this['outstandingPuts_'][_0x2cdddc]['request'],_0x551a7d=this['outstandingPuts_'][_0x2cdddc]['onComplete'];this['outstandingPuts_'][_0x2cdddc]['queued']=this['connected_'],this['sendRequest'](_0xc4208c,_0x3d6a62,_0x3dbca1=>{this['log_'](_0xc4208c+'\x20response',_0x3dbca1),delete this['outstandingPuts_'][_0x2cdddc],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x551a7d&&_0x551a7d(_0x3dbca1['s'],_0x3dbca1['d']);});}['reportStats'](_0x582d00){if(this['connected_']){const _0x3d4735={'c':_0x582d00};this['log_']('reportStats',_0x3d4735),this['sendRequest']('s',_0x3d4735,_0x1c9669=>{if(_0x1c9669['s']!=='ok'){const _0x3b8414=_0x1c9669['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x3b8414);}});}}['onDataMessage_'](_0x434b5e){if('r'in _0x434b5e){this['log_']('from\x20server:\x20'+O(_0x434b5e));const _0x554d6f=_0x434b5e['r'],_0x4869c2=this['requestCBHash_'][_0x554d6f];_0x4869c2&&(delete this['requestCBHash_'][_0x554d6f],_0x4869c2(_0x434b5e['b']));}else{if('error'in _0x434b5e)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x434b5e['error'];'a'in _0x434b5e&&this['onDataPush_'](_0x434b5e['a'],_0x434b5e['b']);}}['onDataPush_'](_0x5b7d3f,_0x5ea8d1){this['log_']('handleServerMessage',_0x5b7d3f,_0x5ea8d1),_0x5b7d3f==='d'?this['onDataUpdate_'](_0x5ea8d1['p'],_0x5ea8d1['d'],!0x1,_0x5ea8d1['t']):_0x5b7d3f==='m'?this['onDataUpdate_'](_0x5ea8d1['p'],_0x5ea8d1['d'],!0x0,_0x5ea8d1['t']):_0x5b7d3f==='c'?this['onListenRevoked_'](_0x5ea8d1['p'],_0x5ea8d1['q']):_0x5b7d3f==='ac'?this['onAuthRevoked_'](_0x5ea8d1['s'],_0x5ea8d1['d']):_0x5b7d3f==='apc'?this['onAppCheckRevoked_'](_0x5ea8d1['s'],_0x5ea8d1['d']):_0x5b7d3f==='sd'?this['onSecurityDebugPacket_'](_0x5ea8d1):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x5b7d3f)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x369050,_0x45ac4f){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x369050),this['lastSessionId']=_0x45ac4f,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x3fafa2){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x3fafa2));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x45a806){_0x45a806&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x45a806;}['onOnline_'](_0x402cd9){_0x402cd9?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x114f95=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x4b91fd=Math['max'](0x0,this['reconnectDelay_']-_0x114f95);_0x4b91fd=Math['random']()*_0x4b91fd,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x4b91fd+'ms'),this['scheduleConnect_'](_0x4b91fd),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x315aff=this['onDataMessage_']['bind'](this),_0x283c34=this['onReady_']['bind'](this),_0x5b4017=this['onRealtimeDisconnect_']['bind'](this),_0x70107d=this['id']+':'+se['nextConnectionId_']++,_0x17d5a5=this['lastSessionId'];let _0xcc2fbc=!0x1,_0x199f63=null;const _0x1845d4=function(){_0x199f63?_0x199f63['close']():(_0xcc2fbc=!0x0,_0x5b4017());},_0x12e590=function(_0x3ce07e){f(_0x199f63,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x199f63['sendRequest'](_0x3ce07e);};this['realtime_']={'close':_0x1845d4,'sendRequest':_0x12e590};const _0x70de1f=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0xa82098,_0xc398f9]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x70de1f),this['appCheckTokenProvider_']['getToken'](_0x70de1f)]);_0xcc2fbc?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0xa82098&&_0xa82098['accessToken'],this['appCheckToken_']=_0xc398f9&&_0xc398f9['token'],_0x199f63=new Sh(_0x70107d,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x315aff,_0x283c34,_0x5b4017,_0x26af31=>{U(_0x26af31+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x17d5a5));}catch(_0x1a22bb){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x1a22bb),_0xcc2fbc||(this['repoInfo_']['nodeAdmin']&&U(_0x1a22bb),_0x1845d4());}}}['interrupt'](_0x52a8f2){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x52a8f2),this['interruptReasons_'][_0x52a8f2]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x547935){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x547935),delete this['interruptReasons_'][_0x547935],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x318d8e){const _0x41d4c6=_0x318d8e-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x41d4c6});}['cancelSentTransactions_'](){for(let _0x30e0d3=0x0;_0x30e0d3<this['outstandingPuts_']['length'];_0x30e0d3++){const _0x3a69d3=this['outstandingPuts_'][_0x30e0d3];_0x3a69d3&&'h'in _0x3a69d3['request']&&_0x3a69d3['queued']&&(_0x3a69d3['onComplete']&&_0x3a69d3['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x30e0d3],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x3c0771,_0x2032f7){let _0x4f3f89;_0x2032f7?_0x4f3f89=_0x2032f7['map'](_0x52d218=>$i(_0x52d218))['join']('$'):_0x4f3f89='default';const _0x53aed4=this['removeListen_'](_0x3c0771,_0x4f3f89);_0x53aed4&&_0x53aed4['onComplete']&&_0x53aed4['onComplete']('permission_denied');}['removeListen_'](_0x3c0a91,_0x1c6a48){const _0x486abc=new C(_0x3c0a91)['toString']();let _0x5f086f;if(this['listens']['has'](_0x486abc)){const _0x44e44d=this['listens']['get'](_0x486abc);_0x5f086f=_0x44e44d['get'](_0x1c6a48),_0x44e44d['delete'](_0x1c6a48),_0x44e44d['size']===0x0&&this['listens']['delete'](_0x486abc);}else _0x5f086f=void 0x0;return _0x5f086f;}['onAuthRevoked_'](_0x3351b4,_0x1661b8){L('Auth\x20token\x20revoked:\x20'+_0x3351b4+'/'+_0x1661b8),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x3351b4==='invalid_token'||_0x3351b4==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0xfa7ec3,_0x3354ce){L('App\x20check\x20token\x20revoked:\x20'+_0xfa7ec3+'/'+_0x3354ce),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0xfa7ec3==='invalid_token'||_0xfa7ec3==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x8a2f63){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x8a2f63):'msg'in _0x8a2f63&&console['log']('FIREBASE:\x20'+_0x8a2f63['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x161453 of this['listens']['values']())for(const _0x40f3b5 of _0x161453['values']())this['sendListen_'](_0x40f3b5);for(let _0xc3d842=0x0;_0xc3d842<this['outstandingPuts_']['length'];_0xc3d842++)this['outstandingPuts_'][_0xc3d842]&&this['sendPut_'](_0xc3d842);for(;this['onDisconnectRequestQueue_']['length'];){const _0x12116d=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x12116d['action'],_0x12116d['pathString'],_0x12116d['data'],_0x12116d['onComplete']);}for(let _0x50b33a=0x0;_0x50b33a<this['outstandingGets_']['length'];_0x50b33a++)this['outstandingGets_'][_0x50b33a]&&this['sendGet_'](_0x50b33a);}['sendConnectStats_'](){const _0x222637={};let _0x2cf85c='js';_0x222637['sdk.'+_0x2cf85c+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x222637['framework.cordova']=0x1:Kr()&&(_0x222637['framework.reactnative']=0x1),this['reportStats'](_0x222637);}['shouldReconnect_'](){const _0x429002=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x429002;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x19c135,_0x45c7bb){this['name']=_0x19c135,this['node']=_0x45c7bb;}static['Wrap'](_0x17a23f,_0x1eb2d0){return new E(_0x17a23f,_0x1eb2d0);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x12f352,_0x399124){const _0x433f5a=new E(We,_0x12f352),_0x33e962=new E(We,_0x399124);return this['compare'](_0x433f5a,_0x33e962)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x4cef4e){sn=_0x4cef4e;}['compare'](_0x2f9bbb,_0x19a17a){return qe(_0x2f9bbb['name'],_0x19a17a['name']);}['isDefinedOn'](_0x981289){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x597c94,_0x339752){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0xbce963,_0x904a9){return f(typeof _0xbce963=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0xbce963,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0x5f546d,_0x327559,_0x7365ac,_0x403c7a,_0x3714f5=null){this['isReverse_']=_0x403c7a,this['resultGenerator_']=_0x3714f5,this['nodeStack_']=[];let _0x2bfd09=0x1;for(;!_0x5f546d['isEmpty']();)if(_0x5f546d=_0x5f546d,_0x2bfd09=_0x327559?_0x7365ac(_0x5f546d['key'],_0x327559):0x1,_0x403c7a&&(_0x2bfd09*=-0x1),_0x2bfd09<0x0)this['isReverse_']?_0x5f546d=_0x5f546d['left']:_0x5f546d=_0x5f546d['right'];else{if(_0x2bfd09===0x0){this['nodeStack_']['push'](_0x5f546d);break;}else this['nodeStack_']['push'](_0x5f546d),this['isReverse_']?_0x5f546d=_0x5f546d['right']:_0x5f546d=_0x5f546d['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x726824=this['nodeStack_']['pop'](),_0x247a95;if(this['resultGenerator_']?_0x247a95=this['resultGenerator_'](_0x726824['key'],_0x726824['value']):_0x247a95={'key':_0x726824['key'],'value':_0x726824['value']},this['isReverse_']){for(_0x726824=_0x726824['left'];!_0x726824['isEmpty']();)this['nodeStack_']['push'](_0x726824),_0x726824=_0x726824['right'];}else{for(_0x726824=_0x726824['right'];!_0x726824['isEmpty']();)this['nodeStack_']['push'](_0x726824),_0x726824=_0x726824['left'];}return _0x247a95;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x3e3555=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x3e3555['key'],_0x3e3555['value']):{'key':_0x3e3555['key'],'value':_0x3e3555['value']};}}class M{constructor(_0x9ea81a,_0x302244,_0xc00d95,_0x5d4a71,_0x2b8d42){this['key']=_0x9ea81a,this['value']=_0x302244,this['color']=_0xc00d95??M['RED'],this['left']=_0x5d4a71??B['EMPTY_NODE'],this['right']=_0x2b8d42??B['EMPTY_NODE'];}['copy'](_0x56e624,_0x7bc75c,_0x3222d3,_0xfda677,_0xa87d4b){return new M(_0x56e624??this['key'],_0x7bc75c??this['value'],_0x3222d3??this['color'],_0xfda677??this['left'],_0xa87d4b??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x5a54e5){return this['left']['inorderTraversal'](_0x5a54e5)||!!_0x5a54e5(this['key'],this['value'])||this['right']['inorderTraversal'](_0x5a54e5);}['reverseTraversal'](_0x1b9928){return this['right']['reverseTraversal'](_0x1b9928)||_0x1b9928(this['key'],this['value'])||this['left']['reverseTraversal'](_0x1b9928);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x39f072,_0x1b8d63,_0x1a795a){let _0x2d0abd=this;const _0xfc986e=_0x1a795a(_0x39f072,_0x2d0abd['key']);return _0xfc986e<0x0?_0x2d0abd=_0x2d0abd['copy'](null,null,null,_0x2d0abd['left']['insert'](_0x39f072,_0x1b8d63,_0x1a795a),null):_0xfc986e===0x0?_0x2d0abd=_0x2d0abd['copy'](null,_0x1b8d63,null,null,null):_0x2d0abd=_0x2d0abd['copy'](null,null,null,null,_0x2d0abd['right']['insert'](_0x39f072,_0x1b8d63,_0x1a795a)),_0x2d0abd['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x1e1b02=this;return!_0x1e1b02['left']['isRed_']()&&!_0x1e1b02['left']['left']['isRed_']()&&(_0x1e1b02=_0x1e1b02['moveRedLeft_']()),_0x1e1b02=_0x1e1b02['copy'](null,null,null,_0x1e1b02['left']['removeMin_'](),null),_0x1e1b02['fixUp_']();}['remove'](_0x4aa83c,_0x2a8e0d){let _0x384001,_0xc83812;if(_0x384001=this,_0x2a8e0d(_0x4aa83c,_0x384001['key'])<0x0)!_0x384001['left']['isEmpty']()&&!_0x384001['left']['isRed_']()&&!_0x384001['left']['left']['isRed_']()&&(_0x384001=_0x384001['moveRedLeft_']()),_0x384001=_0x384001['copy'](null,null,null,_0x384001['left']['remove'](_0x4aa83c,_0x2a8e0d),null);else{if(_0x384001['left']['isRed_']()&&(_0x384001=_0x384001['rotateRight_']()),!_0x384001['right']['isEmpty']()&&!_0x384001['right']['isRed_']()&&!_0x384001['right']['left']['isRed_']()&&(_0x384001=_0x384001['moveRedRight_']()),_0x2a8e0d(_0x4aa83c,_0x384001['key'])===0x0){if(_0x384001['right']['isEmpty']())return B['EMPTY_NODE'];_0xc83812=_0x384001['right']['min_'](),_0x384001=_0x384001['copy'](_0xc83812['key'],_0xc83812['value'],null,null,_0x384001['right']['removeMin_']());}_0x384001=_0x384001['copy'](null,null,null,null,_0x384001['right']['remove'](_0x4aa83c,_0x2a8e0d));}return _0x384001['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x354286=this;return _0x354286['right']['isRed_']()&&!_0x354286['left']['isRed_']()&&(_0x354286=_0x354286['rotateLeft_']()),_0x354286['left']['isRed_']()&&_0x354286['left']['left']['isRed_']()&&(_0x354286=_0x354286['rotateRight_']()),_0x354286['left']['isRed_']()&&_0x354286['right']['isRed_']()&&(_0x354286=_0x354286['colorFlip_']()),_0x354286;}['moveRedLeft_'](){let _0x2933b2=this['colorFlip_']();return _0x2933b2['right']['left']['isRed_']()&&(_0x2933b2=_0x2933b2['copy'](null,null,null,null,_0x2933b2['right']['rotateRight_']()),_0x2933b2=_0x2933b2['rotateLeft_'](),_0x2933b2=_0x2933b2['colorFlip_']()),_0x2933b2;}['moveRedRight_'](){let _0x4112bf=this['colorFlip_']();return _0x4112bf['left']['left']['isRed_']()&&(_0x4112bf=_0x4112bf['rotateRight_'](),_0x4112bf=_0x4112bf['colorFlip_']()),_0x4112bf;}['rotateLeft_'](){const _0x4af153=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x4af153,null);}['rotateRight_'](){const _0x32446c=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x32446c);}['colorFlip_'](){const _0x12a56b=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x3a43d3=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x12a56b,_0x3a43d3);}['checkMaxDepth_'](){const _0x743f5=this['check_']();return Math['pow'](0x2,_0x743f5)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x425d76=this['left']['check_']();if(_0x425d76!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x425d76+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x2d4ddf,_0x1a7685,_0x12408b,_0x38d37a,_0x5f584d){return this;}['insert'](_0x1ebc56,_0x4c8cca,_0x55baa0){return new M(_0x1ebc56,_0x4c8cca,null);}['remove'](_0xa34f00,_0x4d5e40){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x3acdf1){return!0x1;}['reverseTraversal'](_0x4d10fa){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x293656,_0x1344dd=B['EMPTY_NODE']){this['comparator_']=_0x293656,this['root_']=_0x1344dd;}['insert'](_0x962520,_0x1855f3){return new B(this['comparator_'],this['root_']['insert'](_0x962520,_0x1855f3,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x252ba1){return new B(this['comparator_'],this['root_']['remove'](_0x252ba1,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x1b74d3){let _0xc5f43a,_0x1f3dfb=this['root_'];for(;!_0x1f3dfb['isEmpty']();){if(_0xc5f43a=this['comparator_'](_0x1b74d3,_0x1f3dfb['key']),_0xc5f43a===0x0)return _0x1f3dfb['value'];_0xc5f43a<0x0?_0x1f3dfb=_0x1f3dfb['left']:_0xc5f43a>0x0&&(_0x1f3dfb=_0x1f3dfb['right']);}return null;}['getPredecessorKey'](_0x4dd703){let _0x22ae12,_0x484788=this['root_'],_0x17d404=null;for(;!_0x484788['isEmpty']();)if(_0x22ae12=this['comparator_'](_0x4dd703,_0x484788['key']),_0x22ae12===0x0){if(_0x484788['left']['isEmpty']())return _0x17d404?_0x17d404['key']:null;for(_0x484788=_0x484788['left'];!_0x484788['right']['isEmpty']();)_0x484788=_0x484788['right'];return _0x484788['key'];}else _0x22ae12<0x0?_0x484788=_0x484788['left']:_0x22ae12>0x0&&(_0x17d404=_0x484788,_0x484788=_0x484788['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x20d19e){return this['root_']['inorderTraversal'](_0x20d19e);}['reverseTraversal'](_0x1b3a67){return this['root_']['reverseTraversal'](_0x1b3a67);}['getIterator'](_0x40db37){return new rn(this['root_'],null,this['comparator_'],!0x1,_0x40db37);}['getIteratorFrom'](_0x11758d,_0xba7a32){return new rn(this['root_'],_0x11758d,this['comparator_'],!0x1,_0xba7a32);}['getReverseIteratorFrom'](_0x268c12,_0x53a516){return new rn(this['root_'],_0x268c12,this['comparator_'],!0x0,_0x53a516);}['getReverseIterator'](_0x2e76c8){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x2e76c8);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x40978e,_0x312f85){return qe(_0x40978e['name'],_0x312f85['name']);}function Qi(_0x16cd9e,_0x56ed9e){return qe(_0x16cd9e,_0x56ed9e);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x3f59b5){Ci=_0x3f59b5;}const Po=function(_0x473033){return typeof _0x473033=='number'?'number:'+ao(_0x473033):'string:'+_0x473033;},No=function(_0x542ab0){if(_0x542ab0['isLeafNode']()){const _0x32d9ee=_0x542ab0['val']();f(typeof _0x32d9ee=='string'||typeof _0x32d9ee=='number'||typeof _0x32d9ee=='object'&&Q(_0x32d9ee,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x542ab0===Ci||_0x542ab0['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x542ab0===Ci||_0x542ab0['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x38f94c){nr=_0x38f94c;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x39c6a0,_0x454a3f=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x39c6a0,this['priorityNode_']=_0x454a3f,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x4615da){return new D(this['value_'],_0x4615da);}['getImmediateChild'](_0x29b9d5){return _0x29b9d5==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x6a9f3){return v(_0x6a9f3)?this:y(_0x6a9f3)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x230f48,_0x469960){return null;}['updateImmediateChild'](_0x141708,_0x37747a){return _0x141708==='.priority'?this['updatePriority'](_0x37747a):_0x37747a['isEmpty']()&&_0x141708!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x141708,_0x37747a)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x55a046,_0x5d6d50){const _0x3d5a57=y(_0x55a046);return _0x3d5a57===null?_0x5d6d50:_0x5d6d50['isEmpty']()&&_0x3d5a57!=='.priority'?this:(f(_0x3d5a57!=='.priority'||Ce(_0x55a046)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x3d5a57,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x55a046),_0x5d6d50)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x4e78c1,_0x10ea18){return!0x1;}['val'](_0x40a5e6){return _0x40a5e6&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x13b086='';this['priorityNode_']['isEmpty']()||(_0x13b086+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x4da22c=typeof this['value_'];_0x13b086+=_0x4da22c+':',_0x4da22c==='number'?_0x13b086+=ao(this['value_']):_0x13b086+=this['value_'],this['lazyHash_']=ro(_0x13b086);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x378a06){return _0x378a06===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x378a06 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x378a06['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x378a06));}['compareToLeafNode_'](_0x367204){const _0x7f94fd=typeof _0x367204['value_'],_0x2f3ad1=typeof this['value_'],_0xce2e35=D['VALUE_TYPE_ORDER']['indexOf'](_0x7f94fd),_0x3b7d01=D['VALUE_TYPE_ORDER']['indexOf'](_0x2f3ad1);return f(_0xce2e35>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x7f94fd),f(_0x3b7d01>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x2f3ad1),_0xce2e35===_0x3b7d01?_0x2f3ad1==='object'?0x0:this['value_']<_0x367204['value_']?-0x1:this['value_']===_0x367204['value_']?0x0:0x1:_0x3b7d01-_0xce2e35;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x55fc0f){if(_0x55fc0f===this)return!0x0;if(_0x55fc0f['isLeafNode']()){const _0x5f3b75=_0x55fc0f;return this['value_']===_0x5f3b75['value_']&&this['priorityNode_']['equals'](_0x5f3b75['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x5e6322){Oo=_0x5e6322;}function Wh(_0x5e5236){Do=_0x5e5236;}class Bh extends Fn{['compare'](_0x3f003d,_0x1e837e){const _0x4e64ed=_0x3f003d['node']['getPriority'](),_0x4cf8ec=_0x1e837e['node']['getPriority'](),_0x88a518=_0x4e64ed['compareTo'](_0x4cf8ec);return _0x88a518===0x0?qe(_0x3f003d['name'],_0x1e837e['name']):_0x88a518;}['isDefinedOn'](_0x11f967){return!_0x11f967['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x4d4107,_0x4b2aff){return!_0x4d4107['getPriority']()['equals'](_0x4b2aff['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x4ef58a,_0x2f0203){const _0x303e7c=Oo(_0x4ef58a);return new E(_0x2f0203,new D('[PRIORITY-POST]',_0x303e7c));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x31734d){const _0x50139a=_0x4fc271=>parseInt(Math['log'](_0x4fc271)/Vh,0xa),_0xaa4ca6=_0x662709=>parseInt(Array(_0x662709+0x1)['join']('1'),0x2);this['count']=_0x50139a(_0x31734d+0x1),this['current_']=this['count']-0x1;const _0xf10bed=_0xaa4ca6(this['count']);this['bits_']=_0x31734d+0x1&_0xf10bed;}['nextBitIsOne'](){const _0x3941c3=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x3941c3;}}const yn=function(_0xaeb5a7,_0x3d2ae,_0x351d44,_0x406a1b){_0xaeb5a7['sort'](_0x3d2ae);const _0x47d3b0=function(_0x16f241,_0x3e209b){const _0x57a2e2=_0x3e209b-_0x16f241;let _0x1754d6,_0x289594;if(_0x57a2e2===0x0)return null;if(_0x57a2e2===0x1)return _0x1754d6=_0xaeb5a7[_0x16f241],_0x289594=_0x351d44?_0x351d44(_0x1754d6):_0x1754d6,new M(_0x289594,_0x1754d6['node'],M['BLACK'],null,null);{const _0x2d99b8=parseInt(_0x57a2e2/0x2,0xa)+_0x16f241,_0xfcff95=_0x47d3b0(_0x16f241,_0x2d99b8),_0xa0ca93=_0x47d3b0(_0x2d99b8+0x1,_0x3e209b);return _0x1754d6=_0xaeb5a7[_0x2d99b8],_0x289594=_0x351d44?_0x351d44(_0x1754d6):_0x1754d6,new M(_0x289594,_0x1754d6['node'],M['BLACK'],_0xfcff95,_0xa0ca93);}},_0x299234=function(_0x3938fc){let _0x509657=null,_0x1e5e4a=null,_0x453df9=_0xaeb5a7['length'];const _0x56ca04=function(_0x500b49,_0x10a4e2){const _0x256619=_0x453df9-_0x500b49,_0x56c1f2=_0x453df9;_0x453df9-=_0x500b49;const _0x2b253f=_0x47d3b0(_0x256619+0x1,_0x56c1f2),_0x388b52=_0xaeb5a7[_0x256619],_0x147f23=_0x351d44?_0x351d44(_0x388b52):_0x388b52;_0x3dcd8c(new M(_0x147f23,_0x388b52['node'],_0x10a4e2,null,_0x2b253f));},_0x3dcd8c=function(_0x3d88ca){_0x509657?(_0x509657['left']=_0x3d88ca,_0x509657=_0x3d88ca):(_0x1e5e4a=_0x3d88ca,_0x509657=_0x3d88ca);};for(let _0x50afe0=0x0;_0x50afe0<_0x3938fc['count'];++_0x50afe0){const _0x3c773b=_0x3938fc['nextBitIsOne'](),_0x172cc9=Math['pow'](0x2,_0x3938fc['count']-(_0x50afe0+0x1));_0x3c773b?_0x56ca04(_0x172cc9,M['BLACK']):(_0x56ca04(_0x172cc9,M['BLACK']),_0x56ca04(_0x172cc9,M['RED']));}return _0x1e5e4a;},_0x4a0166=new Hh(_0xaeb5a7['length']),_0x4b8fe7=_0x299234(_0x4a0166);return new B(_0x406a1b||_0x3d2ae,_0x4b8fe7);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x4b6877,_0x44aab7){this['indexes_']=_0x4b6877,this['indexSet_']=_0x44aab7;}['get'](_0x50c6c7){const _0x12add8=Le(this['indexes_'],_0x50c6c7);if(!_0x12add8)throw new Error('No\x20index\x20defined\x20for\x20'+_0x50c6c7);return _0x12add8 instanceof B?_0x12add8:null;}['hasIndex'](_0x590d2d){return Q(this['indexSet_'],_0x590d2d['toString']());}['addIndex'](_0x12194f,_0x1286af){f(_0x12194f!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x306ddc=[];let _0x4170cc=!0x1;const _0x5e4baf=_0x1286af['getIterator'](E['Wrap']);let _0x4b0d91=_0x5e4baf['getNext']();for(;_0x4b0d91;)_0x4170cc=_0x4170cc||_0x12194f['isDefinedOn'](_0x4b0d91['node']),_0x306ddc['push'](_0x4b0d91),_0x4b0d91=_0x5e4baf['getNext']();let _0x1bebc0;_0x4170cc?_0x1bebc0=yn(_0x306ddc,_0x12194f['getCompare']()):_0x1bebc0=Qe;const _0x5ccef5=_0x12194f['toString'](),_0x15296e={...this['indexSet_']};_0x15296e[_0x5ccef5]=_0x12194f;const _0x5d2c59={...this['indexes_']};return _0x5d2c59[_0x5ccef5]=_0x1bebc0,new te(_0x5d2c59,_0x15296e);}['addToIndexes'](_0x2e5aa9,_0x1dee1e){const _0x2b9c53=_n(this['indexes_'],(_0xc7d394,_0x3dc73d)=>{const _0x4d09e4=Le(this['indexSet_'],_0x3dc73d);if(f(_0x4d09e4,'Missing\x20index\x20implementation\x20for\x20'+_0x3dc73d),_0xc7d394===Qe){if(_0x4d09e4['isDefinedOn'](_0x2e5aa9['node'])){const _0x4a55b1=[],_0x301561=_0x1dee1e['getIterator'](E['Wrap']);let _0x118ecc=_0x301561['getNext']();for(;_0x118ecc;)_0x118ecc['name']!==_0x2e5aa9['name']&&_0x4a55b1['push'](_0x118ecc),_0x118ecc=_0x301561['getNext']();return _0x4a55b1['push'](_0x2e5aa9),yn(_0x4a55b1,_0x4d09e4['getCompare']());}else return Qe;}else{const _0xf25855=_0x1dee1e['get'](_0x2e5aa9['name']);let _0x1cbf1c=_0xc7d394;return _0xf25855&&(_0x1cbf1c=_0x1cbf1c['remove'](new E(_0x2e5aa9['name'],_0xf25855))),_0x1cbf1c['insert'](_0x2e5aa9,_0x2e5aa9['node']);}});return new te(_0x2b9c53,this['indexSet_']);}['removeFromIndexes'](_0x186e00,_0xa21075){const _0x5b3dd3=_n(this['indexes_'],_0x41b2dc=>{if(_0x41b2dc===Qe)return _0x41b2dc;{const _0x5003a6=_0xa21075['get'](_0x186e00['name']);return _0x5003a6?_0x41b2dc['remove'](new E(_0x186e00['name'],_0x5003a6)):_0x41b2dc;}});return new te(_0x5b3dd3,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x4ef964,_0x12e4eb,_0x453cd8){this['children_']=_0x4ef964,this['priorityNode_']=_0x12e4eb,this['indexMap_']=_0x453cd8,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x328218){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x328218,this['indexMap_']);}['getImmediateChild'](_0x544972){if(_0x544972==='.priority')return this['getPriority']();{const _0x1fe007=this['children_']['get'](_0x544972);return _0x1fe007===null?It:_0x1fe007;}}['getChild'](_0x5f0e72){const _0x14fde1=y(_0x5f0e72);return _0x14fde1===null?this:this['getImmediateChild'](_0x14fde1)['getChild'](S(_0x5f0e72));}['hasChild'](_0x50904c){return this['children_']['get'](_0x50904c)!==null;}['updateImmediateChild'](_0xb3ab69,_0x3647a3){if(f(_0x3647a3,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0xb3ab69==='.priority')return this['updatePriority'](_0x3647a3);{const _0x40b70b=new E(_0xb3ab69,_0x3647a3);let _0x561fe3,_0x58c33f;_0x3647a3['isEmpty']()?(_0x561fe3=this['children_']['remove'](_0xb3ab69),_0x58c33f=this['indexMap_']['removeFromIndexes'](_0x40b70b,this['children_'])):(_0x561fe3=this['children_']['insert'](_0xb3ab69,_0x3647a3),_0x58c33f=this['indexMap_']['addToIndexes'](_0x40b70b,this['children_']));const _0x1aece3=_0x561fe3['isEmpty']()?It:this['priorityNode_'];return new g(_0x561fe3,_0x1aece3,_0x58c33f);}}['updateChild'](_0x3dbb68,_0x40897f){const _0x5253f8=y(_0x3dbb68);if(_0x5253f8===null)return _0x40897f;{f(y(_0x3dbb68)!=='.priority'||Ce(_0x3dbb68)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x1cd061=this['getImmediateChild'](_0x5253f8)['updateChild'](S(_0x3dbb68),_0x40897f);return this['updateImmediateChild'](_0x5253f8,_0x1cd061);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0xa7cc4a){if(this['isEmpty']())return null;const _0x4eef0a={};let _0x97a874=0x0,_0x1ebd1c=0x0,_0x3513ca=!0x0;if(this['forEachChild'](R,(_0x6231fb,_0x3bd476)=>{_0x4eef0a[_0x6231fb]=_0x3bd476['val'](_0xa7cc4a),_0x97a874++,_0x3513ca&&g['INTEGER_REGEXP_']['test'](_0x6231fb)?_0x1ebd1c=Math['max'](_0x1ebd1c,Number(_0x6231fb)):_0x3513ca=!0x1;}),!_0xa7cc4a&&_0x3513ca&&_0x1ebd1c<0x2*_0x97a874){const _0x1054ee=[];for(const _0x26be0a in _0x4eef0a)_0x1054ee[_0x26be0a]=_0x4eef0a[_0x26be0a];return _0x1054ee;}else return _0xa7cc4a&&!this['getPriority']()['isEmpty']()&&(_0x4eef0a['.priority']=this['getPriority']()['val']()),_0x4eef0a;}['hash'](){if(this['lazyHash_']===null){let _0x101467='';this['getPriority']()['isEmpty']()||(_0x101467+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x4d8ce0,_0x5ae749)=>{const _0x1a8e22=_0x5ae749['hash']();_0x1a8e22!==''&&(_0x101467+=':'+_0x4d8ce0+':'+_0x1a8e22);}),this['lazyHash_']=_0x101467===''?'':ro(_0x101467);}return this['lazyHash_'];}['getPredecessorChildName'](_0x238d10,_0x1ef4d2,_0x344366){const _0xb7be95=this['resolveIndex_'](_0x344366);if(_0xb7be95){const _0x3e7e7d=_0xb7be95['getPredecessorKey'](new E(_0x238d10,_0x1ef4d2));return _0x3e7e7d?_0x3e7e7d['name']:null;}else return this['children_']['getPredecessorKey'](_0x238d10);}['getFirstChildName'](_0x32df3e){const _0x99147c=this['resolveIndex_'](_0x32df3e);if(_0x99147c){const _0x33adb3=_0x99147c['minKey']();return _0x33adb3&&_0x33adb3['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x8f4e03){const _0x4728f8=this['getFirstChildName'](_0x8f4e03);return _0x4728f8?new E(_0x4728f8,this['children_']['get'](_0x4728f8)):null;}['getLastChildName'](_0x44c5b2){const _0x2bf0c5=this['resolveIndex_'](_0x44c5b2);if(_0x2bf0c5){const _0x262c1f=_0x2bf0c5['maxKey']();return _0x262c1f&&_0x262c1f['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x1a77ad){const _0xada3e0=this['getLastChildName'](_0x1a77ad);return _0xada3e0?new E(_0xada3e0,this['children_']['get'](_0xada3e0)):null;}['forEachChild'](_0x3f2a74,_0x628a77){const _0x178c36=this['resolveIndex_'](_0x3f2a74);return _0x178c36?_0x178c36['inorderTraversal'](_0x49298a=>_0x628a77(_0x49298a['name'],_0x49298a['node'])):this['children_']['inorderTraversal'](_0x628a77);}['getIterator'](_0x1c9704){return this['getIteratorFrom'](_0x1c9704['minPost'](),_0x1c9704);}['getIteratorFrom'](_0x35ac6f,_0x42afab){const _0xbe427f=this['resolveIndex_'](_0x42afab);if(_0xbe427f)return _0xbe427f['getIteratorFrom'](_0x35ac6f,_0x431c36=>_0x431c36);{const _0xbd8029=this['children_']['getIteratorFrom'](_0x35ac6f['name'],E['Wrap']);let _0x976b96=_0xbd8029['peek']();for(;_0x976b96!=null&&_0x42afab['compare'](_0x976b96,_0x35ac6f)<0x0;)_0xbd8029['getNext'](),_0x976b96=_0xbd8029['peek']();return _0xbd8029;}}['getReverseIterator'](_0x56f95e){return this['getReverseIteratorFrom'](_0x56f95e['maxPost'](),_0x56f95e);}['getReverseIteratorFrom'](_0x47c897,_0x310d8c){const _0x161041=this['resolveIndex_'](_0x310d8c);if(_0x161041)return _0x161041['getReverseIteratorFrom'](_0x47c897,_0x570969=>_0x570969);{const _0x5500fe=this['children_']['getReverseIteratorFrom'](_0x47c897['name'],E['Wrap']);let _0x1ec71e=_0x5500fe['peek']();for(;_0x1ec71e!=null&&_0x310d8c['compare'](_0x1ec71e,_0x47c897)>0x0;)_0x5500fe['getNext'](),_0x1ec71e=_0x5500fe['peek']();return _0x5500fe;}}['compareTo'](_0x520136){return this['isEmpty']()?_0x520136['isEmpty']()?0x0:-0x1:_0x520136['isLeafNode']()||_0x520136['isEmpty']()?0x1:_0x520136===Kt?-0x1:0x0;}['withIndex'](_0x2a0937){if(_0x2a0937===ve||this['indexMap_']['hasIndex'](_0x2a0937))return this;{const _0xb494c9=this['indexMap_']['addIndex'](_0x2a0937,this['children_']);return new g(this['children_'],this['priorityNode_'],_0xb494c9);}}['isIndexed'](_0x444a97){return _0x444a97===ve||this['indexMap_']['hasIndex'](_0x444a97);}['equals'](_0x4864b2){if(_0x4864b2===this)return!0x0;if(_0x4864b2['isLeafNode']())return!0x1;{const _0x55002f=_0x4864b2;if(this['getPriority']()['equals'](_0x55002f['getPriority']())){if(this['children_']['count']()===_0x55002f['children_']['count']()){const _0x14b2e3=this['getIterator'](R),_0x192d31=_0x55002f['getIterator'](R);let _0x518a39=_0x14b2e3['getNext'](),_0x170952=_0x192d31['getNext']();for(;_0x518a39&&_0x170952;){if(_0x518a39['name']!==_0x170952['name']||!_0x518a39['node']['equals'](_0x170952['node']))return!0x1;_0x518a39=_0x14b2e3['getNext'](),_0x170952=_0x192d31['getNext']();}return _0x518a39===null&&_0x170952===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x2dc3d0){return _0x2dc3d0===ve?null:this['indexMap_']['get'](_0x2dc3d0['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x597bff){return _0x597bff===this?0x0:0x1;}['equals'](_0x1bf4ac){return _0x1bf4ac===this;}['getPriority'](){return this;}['getImmediateChild'](_0x6612d4){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0xc76263,_0x5d0d72=null){if(_0xc76263===null)return g['EMPTY_NODE'];if(typeof _0xc76263=='object'&&'.priority'in _0xc76263&&(_0x5d0d72=_0xc76263['.priority']),f(_0x5d0d72===null||typeof _0x5d0d72=='string'||typeof _0x5d0d72=='number'||typeof _0x5d0d72=='object'&&'.sv'in _0x5d0d72,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x5d0d72),typeof _0xc76263=='object'&&'.value'in _0xc76263&&_0xc76263['.value']!==null&&(_0xc76263=_0xc76263['.value']),typeof _0xc76263!='object'||'.sv'in _0xc76263){const _0x24c140=_0xc76263;return new D(_0x24c140,A(_0x5d0d72));}if(!(_0xc76263 instanceof Array)&&Gh){const _0x35d603=[];let _0x119e28=!0x1;if(x(_0xc76263,(_0x315d83,_0x508725)=>{if(_0x315d83['substring'](0x0,0x1)!=='.'){const _0x561ca8=A(_0x508725);_0x561ca8['isEmpty']()||(_0x119e28=_0x119e28||!_0x561ca8['getPriority']()['isEmpty'](),_0x35d603['push'](new E(_0x315d83,_0x561ca8)));}}),_0x35d603['length']===0x0)return g['EMPTY_NODE'];const _0x412217=yn(_0x35d603,xh,_0x55309d=>_0x55309d['name'],Qi);if(_0x119e28){const _0x283d7d=yn(_0x35d603,R['getCompare']());return new g(_0x412217,A(_0x5d0d72),new te({'.priority':_0x283d7d},{'.priority':R}));}else return new g(_0x412217,A(_0x5d0d72),te['Default']);}else{let _0x55a8f6=g['EMPTY_NODE'];return x(_0xc76263,(_0x19623b,_0x443a53)=>{if(Q(_0xc76263,_0x19623b)&&_0x19623b['substring'](0x0,0x1)!=='.'){const _0xab53f8=A(_0x443a53);(_0xab53f8['isLeafNode']()||!_0xab53f8['isEmpty']())&&(_0x55a8f6=_0x55a8f6['updateImmediateChild'](_0x19623b,_0xab53f8));}}),_0x55a8f6['updatePriority'](A(_0x5d0d72));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x539331){super(),this['indexPath_']=_0x539331,f(!v(_0x539331)&&y(_0x539331)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x244cf5){return _0x244cf5['getChild'](this['indexPath_']);}['isDefinedOn'](_0x42f622){return!_0x42f622['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x5aec8c,_0x36e7f3){const _0x58499d=this['extractChild'](_0x5aec8c['node']),_0x375fc5=this['extractChild'](_0x36e7f3['node']),_0x226e9c=_0x58499d['compareTo'](_0x375fc5);return _0x226e9c===0x0?qe(_0x5aec8c['name'],_0x36e7f3['name']):_0x226e9c;}['makePost'](_0x4c4064,_0x185428){const _0x18ff04=A(_0x4c4064),_0x2cdb60=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x18ff04);return new E(_0x185428,_0x2cdb60);}['maxPost'](){const _0x269a54=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x269a54);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x4880ff,_0x369f9a){const _0x5d7fce=_0x4880ff['node']['compareTo'](_0x369f9a['node']);return _0x5d7fce===0x0?qe(_0x4880ff['name'],_0x369f9a['name']):_0x5d7fce;}['isDefinedOn'](_0x4a101f){return!0x0;}['indexedValueChanged'](_0x422632,_0x258764){return!_0x422632['equals'](_0x258764);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x5718d6,_0x559952){const _0x474178=A(_0x5718d6);return new E(_0x559952,_0x474178);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x111136){return{'type':'value','snapshotNode':_0x111136};}function rt(_0x8ec6be,_0xf8de01){return{'type':'child_added','snapshotNode':_0xf8de01,'childName':_0x8ec6be};}function Lt(_0x2600f9,_0x5d576c){return{'type':'child_removed','snapshotNode':_0x5d576c,'childName':_0x2600f9};}function xt(_0x531024,_0x6647cf,_0x526131){return{'type':'child_changed','snapshotNode':_0x6647cf,'childName':_0x531024,'oldSnap':_0x526131};}function zh(_0x371fcf,_0x55acce){return{'type':'child_moved','snapshotNode':_0x55acce,'childName':_0x371fcf};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x4e77d9){this['index_']=_0x4e77d9;}['updateChild'](_0x3e1eb4,_0x5d12fc,_0x1d4d3c,_0x5dbc76,_0x1d8736,_0x314fe4){f(_0x3e1eb4['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x41e011=_0x3e1eb4['getImmediateChild'](_0x5d12fc);return _0x41e011['getChild'](_0x5dbc76)['equals'](_0x1d4d3c['getChild'](_0x5dbc76))&&_0x41e011['isEmpty']()===_0x1d4d3c['isEmpty']()||(_0x314fe4!=null&&(_0x1d4d3c['isEmpty']()?_0x3e1eb4['hasChild'](_0x5d12fc)?_0x314fe4['trackChildChange'](Lt(_0x5d12fc,_0x41e011)):f(_0x3e1eb4['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x41e011['isEmpty']()?_0x314fe4['trackChildChange'](rt(_0x5d12fc,_0x1d4d3c)):_0x314fe4['trackChildChange'](xt(_0x5d12fc,_0x1d4d3c,_0x41e011))),_0x3e1eb4['isLeafNode']()&&_0x1d4d3c['isEmpty']())?_0x3e1eb4:_0x3e1eb4['updateImmediateChild'](_0x5d12fc,_0x1d4d3c)['withIndex'](this['index_']);}['updateFullNode'](_0x3f5bef,_0x137f97,_0x2f1c92){return _0x2f1c92!=null&&(_0x3f5bef['isLeafNode']()||_0x3f5bef['forEachChild'](R,(_0x5f54c3,_0x506de2)=>{_0x137f97['hasChild'](_0x5f54c3)||_0x2f1c92['trackChildChange'](Lt(_0x5f54c3,_0x506de2));}),_0x137f97['isLeafNode']()||_0x137f97['forEachChild'](R,(_0x5f0ea8,_0x3bea0e)=>{if(_0x3f5bef['hasChild'](_0x5f0ea8)){const _0x33768b=_0x3f5bef['getImmediateChild'](_0x5f0ea8);_0x33768b['equals'](_0x3bea0e)||_0x2f1c92['trackChildChange'](xt(_0x5f0ea8,_0x3bea0e,_0x33768b));}else _0x2f1c92['trackChildChange'](rt(_0x5f0ea8,_0x3bea0e));})),_0x137f97['withIndex'](this['index_']);}['updatePriority'](_0x4e28a0,_0x1010fc){return _0x4e28a0['isEmpty']()?g['EMPTY_NODE']:_0x4e28a0['updatePriority'](_0x1010fc);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0x4e3af2){this['indexedFilter_']=new Xi(_0x4e3af2['getIndex']()),this['index_']=_0x4e3af2['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0x4e3af2),this['endPost_']=Ft['getEndPost_'](_0x4e3af2),this['startIsInclusive_']=!_0x4e3af2['startAfterSet_'],this['endIsInclusive_']=!_0x4e3af2['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x4d65be){const _0x2684da=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x4d65be)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x4d65be)<0x0,_0x555abe=this['endIsInclusive_']?this['index_']['compare'](_0x4d65be,this['getEndPost']())<=0x0:this['index_']['compare'](_0x4d65be,this['getEndPost']())<0x0;return _0x2684da&&_0x555abe;}['updateChild'](_0x4ad63a,_0x5a5b07,_0x2df2f9,_0x17276b,_0x2100bb,_0x37b1ec){return this['matches'](new E(_0x5a5b07,_0x2df2f9))||(_0x2df2f9=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x4ad63a,_0x5a5b07,_0x2df2f9,_0x17276b,_0x2100bb,_0x37b1ec);}['updateFullNode'](_0x23af42,_0x492ecc,_0x405051){_0x492ecc['isLeafNode']()&&(_0x492ecc=g['EMPTY_NODE']);let _0x60e049=_0x492ecc['withIndex'](this['index_']);_0x60e049=_0x60e049['updatePriority'](g['EMPTY_NODE']);const _0x59a46a=this;return _0x492ecc['forEachChild'](R,(_0x2b1a8e,_0x1e76ce)=>{_0x59a46a['matches'](new E(_0x2b1a8e,_0x1e76ce))||(_0x60e049=_0x60e049['updateImmediateChild'](_0x2b1a8e,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x23af42,_0x60e049,_0x405051);}['updatePriority'](_0x565c89,_0x126dc0){return _0x565c89;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x4922d9){if(_0x4922d9['hasStart']()){const _0x19cdd6=_0x4922d9['getIndexStartName']();return _0x4922d9['getIndex']()['makePost'](_0x4922d9['getIndexStartValue'](),_0x19cdd6);}else return _0x4922d9['getIndex']()['minPost']();}static['getEndPost_'](_0x15c75b){if(_0x15c75b['hasEnd']()){const _0x4d0598=_0x15c75b['getIndexEndName']();return _0x15c75b['getIndex']()['makePost'](_0x15c75b['getIndexEndValue'](),_0x4d0598);}else return _0x15c75b['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x18a2d6){this['withinDirectionalStart']=_0x2025fe=>this['reverse_']?this['withinEndPost'](_0x2025fe):this['withinStartPost'](_0x2025fe),this['withinDirectionalEnd']=_0x5b8ef2=>this['reverse_']?this['withinStartPost'](_0x5b8ef2):this['withinEndPost'](_0x5b8ef2),this['withinStartPost']=_0x1ca384=>{const _0x6d6183=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x1ca384);return this['startIsInclusive_']?_0x6d6183<=0x0:_0x6d6183<0x0;},this['withinEndPost']=_0x5d6c81=>{const _0xc02be6=this['index_']['compare'](_0x5d6c81,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0xc02be6<=0x0:_0xc02be6<0x0;},this['rangedFilter_']=new Ft(_0x18a2d6),this['index_']=_0x18a2d6['getIndex'](),this['limit_']=_0x18a2d6['getLimit'](),this['reverse_']=!_0x18a2d6['isViewFromLeft'](),this['startIsInclusive_']=!_0x18a2d6['startAfterSet_'],this['endIsInclusive_']=!_0x18a2d6['endBeforeSet_'];}['updateChild'](_0xb6660c,_0x2828a5,_0x173f4a,_0x32ce67,_0x459ace,_0x1cd1d5){return this['rangedFilter_']['matches'](new E(_0x2828a5,_0x173f4a))||(_0x173f4a=g['EMPTY_NODE']),_0xb6660c['getImmediateChild'](_0x2828a5)['equals'](_0x173f4a)?_0xb6660c:_0xb6660c['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0xb6660c,_0x2828a5,_0x173f4a,_0x32ce67,_0x459ace,_0x1cd1d5):this['fullLimitUpdateChild_'](_0xb6660c,_0x2828a5,_0x173f4a,_0x459ace,_0x1cd1d5);}['updateFullNode'](_0x59e5a7,_0x19f8b9,_0x2465ad){let _0x4f2ca0;if(_0x19f8b9['isLeafNode']()||_0x19f8b9['isEmpty']())_0x4f2ca0=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x19f8b9['numChildren']()&&_0x19f8b9['isIndexed'](this['index_'])){_0x4f2ca0=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x1a0a07;this['reverse_']?_0x1a0a07=_0x19f8b9['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x1a0a07=_0x19f8b9['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x2b62c2=0x0;for(;_0x1a0a07['hasNext']()&&_0x2b62c2<this['limit_'];){const _0x3390c2=_0x1a0a07['getNext']();if(this['withinDirectionalStart'](_0x3390c2)){if(this['withinDirectionalEnd'](_0x3390c2))_0x4f2ca0=_0x4f2ca0['updateImmediateChild'](_0x3390c2['name'],_0x3390c2['node']),_0x2b62c2++;else break;}else continue;}}else{_0x4f2ca0=_0x19f8b9['withIndex'](this['index_']),_0x4f2ca0=_0x4f2ca0['updatePriority'](g['EMPTY_NODE']);let _0x3d342e;this['reverse_']?_0x3d342e=_0x4f2ca0['getReverseIterator'](this['index_']):_0x3d342e=_0x4f2ca0['getIterator'](this['index_']);let _0x444ca0=0x0;for(;_0x3d342e['hasNext']();){const _0x111f7b=_0x3d342e['getNext']();_0x444ca0<this['limit_']&&this['withinDirectionalStart'](_0x111f7b)&&this['withinDirectionalEnd'](_0x111f7b)?_0x444ca0++:_0x4f2ca0=_0x4f2ca0['updateImmediateChild'](_0x111f7b['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x59e5a7,_0x4f2ca0,_0x2465ad);}['updatePriority'](_0x32a194,_0x2ff5d3){return _0x32a194;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x3b8192,_0x1d2651,_0x17f881,_0x1011c4,_0x374ccb){let _0x1b0efd;if(this['reverse_']){const _0xb4ae03=this['index_']['getCompare']();_0x1b0efd=(_0x50ef56,_0x515466)=>_0xb4ae03(_0x515466,_0x50ef56);}else _0x1b0efd=this['index_']['getCompare']();const _0x36ad58=_0x3b8192;f(_0x36ad58['numChildren']()===this['limit_'],'');const _0x397e88=new E(_0x1d2651,_0x17f881),_0x547c0e=this['reverse_']?_0x36ad58['getFirstChild'](this['index_']):_0x36ad58['getLastChild'](this['index_']),_0x50d8f8=this['rangedFilter_']['matches'](_0x397e88);if(_0x36ad58['hasChild'](_0x1d2651)){const _0x580ed5=_0x36ad58['getImmediateChild'](_0x1d2651);let _0x4f3700=_0x1011c4['getChildAfterChild'](this['index_'],_0x547c0e,this['reverse_']);for(;_0x4f3700!=null&&(_0x4f3700['name']===_0x1d2651||_0x36ad58['hasChild'](_0x4f3700['name']));)_0x4f3700=_0x1011c4['getChildAfterChild'](this['index_'],_0x4f3700,this['reverse_']);const _0x26597e=_0x4f3700==null?0x1:_0x1b0efd(_0x4f3700,_0x397e88);if(_0x50d8f8&&!_0x17f881['isEmpty']()&&_0x26597e>=0x0)return _0x374ccb!=null&&_0x374ccb['trackChildChange'](xt(_0x1d2651,_0x17f881,_0x580ed5)),_0x36ad58['updateImmediateChild'](_0x1d2651,_0x17f881);{_0x374ccb!=null&&_0x374ccb['trackChildChange'](Lt(_0x1d2651,_0x580ed5));const _0x4d9f23=_0x36ad58['updateImmediateChild'](_0x1d2651,g['EMPTY_NODE']);return _0x4f3700!=null&&this['rangedFilter_']['matches'](_0x4f3700)?(_0x374ccb!=null&&_0x374ccb['trackChildChange'](rt(_0x4f3700['name'],_0x4f3700['node'])),_0x4d9f23['updateImmediateChild'](_0x4f3700['name'],_0x4f3700['node'])):_0x4d9f23;}}else return _0x17f881['isEmpty']()?_0x3b8192:_0x50d8f8&&_0x1b0efd(_0x547c0e,_0x397e88)>=0x0?(_0x374ccb!=null&&(_0x374ccb['trackChildChange'](Lt(_0x547c0e['name'],_0x547c0e['node'])),_0x374ccb['trackChildChange'](rt(_0x1d2651,_0x17f881))),_0x36ad58['updateImmediateChild'](_0x1d2651,_0x17f881)['updateImmediateChild'](_0x547c0e['name'],g['EMPTY_NODE'])):_0x3b8192;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x4decc4=new Zi();return _0x4decc4['limitSet_']=this['limitSet_'],_0x4decc4['limit_']=this['limit_'],_0x4decc4['startSet_']=this['startSet_'],_0x4decc4['startAfterSet_']=this['startAfterSet_'],_0x4decc4['indexStartValue_']=this['indexStartValue_'],_0x4decc4['startNameSet_']=this['startNameSet_'],_0x4decc4['indexStartName_']=this['indexStartName_'],_0x4decc4['endSet_']=this['endSet_'],_0x4decc4['endBeforeSet_']=this['endBeforeSet_'],_0x4decc4['indexEndValue_']=this['indexEndValue_'],_0x4decc4['endNameSet_']=this['endNameSet_'],_0x4decc4['indexEndName_']=this['indexEndName_'],_0x4decc4['index_']=this['index_'],_0x4decc4['viewFrom_']=this['viewFrom_'],_0x4decc4;}}function Kh(_0x4ba747){return _0x4ba747['loadsAllData']()?new Xi(_0x4ba747['getIndex']()):_0x4ba747['hasLimit']()?new jh(_0x4ba747):new Ft(_0x4ba747);}function Yh(_0x79ab3e,_0x5ef522){const _0x22cbd1=_0x79ab3e['copy']();return _0x22cbd1['limitSet_']=!0x0,_0x22cbd1['limit_']=_0x5ef522,_0x22cbd1['viewFrom_']='l',_0x22cbd1;}function Qh(_0x63f5a2,_0x174267,_0x347b67){const _0x4c1740=_0x63f5a2['copy']();return _0x4c1740['startSet_']=!0x0,_0x174267===void 0x0&&(_0x174267=null),_0x4c1740['indexStartValue_']=_0x174267,_0x347b67!=null?(_0x4c1740['startNameSet_']=!0x0,_0x4c1740['indexStartName_']=_0x347b67):(_0x4c1740['startNameSet_']=!0x1,_0x4c1740['indexStartName_']=''),_0x4c1740;}function Jh(_0x12ac00,_0x36ccf5,_0x13b8ba){const _0x225327=_0x12ac00['copy']();return _0x225327['endSet_']=!0x0,_0x36ccf5===void 0x0&&(_0x36ccf5=null),_0x225327['indexEndValue_']=_0x36ccf5,_0x13b8ba!==void 0x0?(_0x225327['endNameSet_']=!0x0,_0x225327['indexEndName_']=_0x13b8ba):(_0x225327['endNameSet_']=!0x1,_0x225327['indexEndName_']=''),_0x225327;}function xo(_0x3c22a3,_0x3043f9){const _0x486a96=_0x3c22a3['copy']();return _0x486a96['index_']=_0x3043f9,_0x486a96;}function ir(_0x38d615){const _0x4579e2={};if(_0x38d615['isDefault']())return _0x4579e2;let _0x522a96;if(_0x38d615['index_']===R?_0x522a96='$priority':_0x38d615['index_']===Mo?_0x522a96='$value':_0x38d615['index_']===ve?_0x522a96='$key':(f(_0x38d615['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x522a96=_0x38d615['index_']['toString']()),_0x4579e2['orderBy']=O(_0x522a96),_0x38d615['startSet_']){const _0x286a19=_0x38d615['startAfterSet_']?'startAfter':'startAt';_0x4579e2[_0x286a19]=O(_0x38d615['indexStartValue_']),_0x38d615['startNameSet_']&&(_0x4579e2[_0x286a19]+=','+O(_0x38d615['indexStartName_']));}if(_0x38d615['endSet_']){const _0x1fccfa=_0x38d615['endBeforeSet_']?'endBefore':'endAt';_0x4579e2[_0x1fccfa]=O(_0x38d615['indexEndValue_']),_0x38d615['endNameSet_']&&(_0x4579e2[_0x1fccfa]+=','+O(_0x38d615['indexEndName_']));}return _0x38d615['limitSet_']&&(_0x38d615['isViewFromLeft']()?_0x4579e2['limitToFirst']=_0x38d615['limit_']:_0x4579e2['limitToLast']=_0x38d615['limit_']),_0x4579e2;}function sr(_0x4c470f){const _0x44ff89={};if(_0x4c470f['startSet_']&&(_0x44ff89['sp']=_0x4c470f['indexStartValue_'],_0x4c470f['startNameSet_']&&(_0x44ff89['sn']=_0x4c470f['indexStartName_']),_0x44ff89['sin']=!_0x4c470f['startAfterSet_']),_0x4c470f['endSet_']&&(_0x44ff89['ep']=_0x4c470f['indexEndValue_'],_0x4c470f['endNameSet_']&&(_0x44ff89['en']=_0x4c470f['indexEndName_']),_0x44ff89['ein']=!_0x4c470f['endBeforeSet_']),_0x4c470f['limitSet_']){_0x44ff89['l']=_0x4c470f['limit_'];let _0x119f35=_0x4c470f['viewFrom_'];_0x119f35===''&&(_0x4c470f['isViewFromLeft']()?_0x119f35='l':_0x119f35='r'),_0x44ff89['vf']=_0x119f35;}return _0x4c470f['index_']!==R&&(_0x44ff89['i']=_0x4c470f['index_']['toString']()),_0x44ff89;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0x101a7a){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x1dd081,_0x585349){return _0x585349!==void 0x0?'tag$'+_0x585349:(f(_0x1dd081['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x1dd081['_path']['toString']());}constructor(_0x346b31,_0x33a400,_0x23df86,_0x5301ea){super(),this['repoInfo_']=_0x346b31,this['onDataUpdate_']=_0x33a400,this['authTokenProvider_']=_0x23df86,this['appCheckTokenProvider_']=_0x5301ea,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x162c2b,_0x329c31,_0x122066,_0x1bfbd7){const _0x292eda=_0x162c2b['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x292eda+'\x20'+_0x162c2b['_queryIdentifier']);const _0x1b1086=vn['getListenId_'](_0x162c2b,_0x122066),_0x1655ce={};this['listens_'][_0x1b1086]=_0x1655ce;const _0x38d2c6=ir(_0x162c2b['_queryParams']);this['restRequest_'](_0x292eda+'.json',_0x38d2c6,(_0x4f9d5a,_0x33dec5)=>{let _0x385ca2=_0x33dec5;if(_0x4f9d5a===0x194&&(_0x385ca2=null,_0x4f9d5a=null),_0x4f9d5a===null&&this['onDataUpdate_'](_0x292eda,_0x385ca2,!0x1,_0x122066),Le(this['listens_'],_0x1b1086)===_0x1655ce){let _0x1ddd4f;_0x4f9d5a?_0x4f9d5a===0x191?_0x1ddd4f='permission_denied':_0x1ddd4f='rest_error:'+_0x4f9d5a:_0x1ddd4f='ok',_0x1bfbd7(_0x1ddd4f,null);}});}['unlisten'](_0x332ce6,_0x5e07ad){const _0x5b525d=vn['getListenId_'](_0x332ce6,_0x5e07ad);delete this['listens_'][_0x5b525d];}['get'](_0x5902c3){const _0x1d6524=ir(_0x5902c3['_queryParams']),_0x5a0fce=_0x5902c3['_path']['toString'](),_0x471dd4=new H();return this['restRequest_'](_0x5a0fce+'.json',_0x1d6524,(_0x4caed4,_0x151fb9)=>{let _0xe046f3=_0x151fb9;_0x4caed4===0x194&&(_0xe046f3=null,_0x4caed4=null),_0x4caed4===null?(this['onDataUpdate_'](_0x5a0fce,_0xe046f3,!0x1,null),_0x471dd4['resolve'](_0xe046f3)):_0x471dd4['reject'](new Error(_0xe046f3));}),_0x471dd4['promise'];}['refreshAuthToken'](_0x39e27f){}['restRequest_'](_0x5dd91b,_0x33a686={},_0x2a371e){return _0x33a686['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x9184fa,_0x52b901])=>{_0x9184fa&&_0x9184fa['accessToken']&&(_0x33a686['auth']=_0x9184fa['accessToken']),_0x52b901&&_0x52b901['token']&&(_0x33a686['ac']=_0x52b901['token']);const _0x4b1ab8=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x5dd91b+'?ns='+this['repoInfo_']['namespace']+ut(_0x33a686);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x4b1ab8);const _0x57106a=new XMLHttpRequest();_0x57106a['onreadystatechange']=()=>{if(_0x2a371e&&_0x57106a['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x4b1ab8+'\x20received.\x20status:',_0x57106a['status'],'response:',_0x57106a['responseText']);let _0x3a6221=null;if(_0x57106a['status']>=0xc8&&_0x57106a['status']<0x12c){try{_0x3a6221=Nt(_0x57106a['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x4b1ab8+':\x20'+_0x57106a['responseText']);}_0x2a371e(null,_0x3a6221);}else _0x57106a['status']!==0x191&&_0x57106a['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x4b1ab8+'\x20Status:\x20'+_0x57106a['status']),_0x2a371e(_0x57106a['status']);_0x2a371e=null;}},_0x57106a['open']('GET',_0x4b1ab8,!0x0),_0x57106a['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x7ac5ff){return this['rootNode_']['getChild'](_0x7ac5ff);}['updateSnapshot'](_0x2e6f1c,_0x4db692){this['rootNode_']=this['rootNode_']['updateChild'](_0x2e6f1c,_0x4db692);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x435930,_0x3e47c8,_0x5987e7){if(v(_0x3e47c8))_0x435930['value']=_0x5987e7,_0x435930['children']['clear']();else{if(_0x435930['value']!==null)_0x435930['value']=_0x435930['value']['updateChild'](_0x3e47c8,_0x5987e7);else{const _0x212f82=y(_0x3e47c8);_0x435930['children']['has'](_0x212f82)||_0x435930['children']['set'](_0x212f82,En());const _0x124e51=_0x435930['children']['get'](_0x212f82);_0x3e47c8=S(_0x3e47c8),pt(_0x124e51,_0x3e47c8,_0x5987e7);}}}function Ti(_0x14ec77,_0xe7f767){if(v(_0xe7f767))return _0x14ec77['value']=null,_0x14ec77['children']['clear'](),!0x0;if(_0x14ec77['value']!==null){if(_0x14ec77['value']['isLeafNode']())return!0x1;{const _0x3a8e8d=_0x14ec77['value'];return _0x14ec77['value']=null,_0x3a8e8d['forEachChild'](R,(_0x2d8378,_0x49af55)=>{pt(_0x14ec77,new C(_0x2d8378),_0x49af55);}),Ti(_0x14ec77,_0xe7f767);}}else{if(_0x14ec77['children']['size']>0x0){const _0x489862=y(_0xe7f767);return _0xe7f767=S(_0xe7f767),_0x14ec77['children']['has'](_0x489862)&&Ti(_0x14ec77['children']['get'](_0x489862),_0xe7f767)&&_0x14ec77['children']['delete'](_0x489862),_0x14ec77['children']['size']===0x0;}else return!0x0;}}function Si(_0x4f93a0,_0x1481ae,_0x4f6b3d){_0x4f93a0['value']!==null?_0x4f6b3d(_0x1481ae,_0x4f93a0['value']):Zh(_0x4f93a0,(_0x1b5cc9,_0x18bcb9)=>{const _0x160d12=new C(_0x1481ae['toString']()+'/'+_0x1b5cc9);Si(_0x18bcb9,_0x160d12,_0x4f6b3d);});}function Zh(_0x4a82ab,_0x1edb09){_0x4a82ab['children']['forEach']((_0xbf8816,_0x57be3b)=>{_0x1edb09(_0x57be3b,_0xbf8816);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x573939){this['collection_']=_0x573939,this['last_']=null;}['get'](){const _0x526f7f=this['collection_']['get'](),_0x19782b={..._0x526f7f};return this['last_']&&x(this['last_'],(_0x30a475,_0x32fdba)=>{_0x19782b[_0x30a475]=_0x19782b[_0x30a475]-_0x32fdba;}),this['last_']=_0x526f7f,_0x19782b;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x375ea5,_0x1d4500){this['server_']=_0x1d4500,this['statsToReport_']={},this['statsListener_']=new eu(_0x375ea5);const _0x29dbec=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x29dbec));}['reportStats_'](){const _0x36cbf7=this['statsListener_']['get'](),_0x4344db={};let _0x5c7911=!0x1;x(_0x36cbf7,(_0x57ec40,_0x46bbae)=>{_0x46bbae>0x0&&Q(this['statsToReport_'],_0x57ec40)&&(_0x4344db[_0x57ec40]=_0x46bbae,_0x5c7911=!0x0);}),_0x5c7911&&this['server_']['reportStats'](_0x4344db),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x2bb804){_0x2bb804[_0x2bb804['OVERWRITE']=0x0]='OVERWRITE',_0x2bb804[_0x2bb804['MERGE']=0x1]='MERGE',_0x2bb804[_0x2bb804['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x2bb804[_0x2bb804['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0xaaad40){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0xaaad40,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x3b77d2,_0x17ecc4,_0x16976e){this['path']=_0x3b77d2,this['affectedTree']=_0x17ecc4,this['revert']=_0x16976e,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x3c9bee){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x4416e5=this['affectedTree']['subtree'](new C(_0x3c9bee));return new In(w(),_0x4416e5,this['revert']);}}else return f(y(this['path'])===_0x3c9bee,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x512d5c,_0xe1498f){this['source']=_0x512d5c,this['path']=_0xe1498f,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x3f0d74){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x53090c,_0x18d255,_0x5ae75e){this['source']=_0x53090c,this['path']=_0x18d255,this['snap']=_0x5ae75e,this['type']=z['OVERWRITE'];}['operationForChild'](_0x39adc0){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x39adc0)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x36b1f8,_0x2ea113,_0x365390){this['source']=_0x36b1f8,this['path']=_0x2ea113,this['children']=_0x365390,this['type']=z['MERGE'];}['operationForChild'](_0x24e72b){if(v(this['path'])){const _0x5ea374=this['children']['subtree'](new C(_0x24e72b));return _0x5ea374['isEmpty']()?null:_0x5ea374['value']?new Be(this['source'],w(),_0x5ea374['value']):new ot(this['source'],w(),_0x5ea374);}else return f(y(this['path'])===_0x24e72b,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x51fd19,_0x3e8670,_0x5606a2){this['node_']=_0x51fd19,this['fullyInitialized_']=_0x3e8670,this['filtered_']=_0x5606a2;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x15ab36){if(v(_0x15ab36))return this['isFullyInitialized']()&&!this['filtered_'];const _0x82c57b=y(_0x15ab36);return this['isCompleteForChild'](_0x82c57b);}['isCompleteForChild'](_0x5b95f4){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x5b95f4);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x57a937){this['query_']=_0x57a937,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x5af091,_0x4856b7,_0x59b1a4,_0x402be7){const _0x22a979=[],_0x18c678=[];return _0x4856b7['forEach'](_0x40b62d=>{_0x40b62d['type']==='child_changed'&&_0x5af091['index_']['indexedValueChanged'](_0x40b62d['oldSnap'],_0x40b62d['snapshotNode'])&&_0x18c678['push'](zh(_0x40b62d['childName'],_0x40b62d['snapshotNode']));}),wt(_0x5af091,_0x22a979,'child_removed',_0x4856b7,_0x402be7,_0x59b1a4),wt(_0x5af091,_0x22a979,'child_added',_0x4856b7,_0x402be7,_0x59b1a4),wt(_0x5af091,_0x22a979,'child_moved',_0x18c678,_0x402be7,_0x59b1a4),wt(_0x5af091,_0x22a979,'child_changed',_0x4856b7,_0x402be7,_0x59b1a4),wt(_0x5af091,_0x22a979,'value',_0x4856b7,_0x402be7,_0x59b1a4),_0x22a979;}function wt(_0x38abb9,_0x19e4e8,_0x159149,_0x288cb4,_0x5eb2ef,_0x475174){const _0x259dc4=_0x288cb4['filter'](_0x3bcd13=>_0x3bcd13['type']===_0x159149);_0x259dc4['sort']((_0x2b946f,_0x2820c3)=>au(_0x38abb9,_0x2b946f,_0x2820c3)),_0x259dc4['forEach'](_0x3a1e78=>{const _0x80acb6=ou(_0x38abb9,_0x3a1e78,_0x475174);_0x5eb2ef['forEach'](_0x3bfeb8=>{_0x3bfeb8['respondsTo'](_0x3a1e78['type'])&&_0x19e4e8['push'](_0x3bfeb8['createEvent'](_0x80acb6,_0x38abb9['query_']));});});}function ou(_0x5ee055,_0x49daa9,_0x188039){return _0x49daa9['type']==='value'||_0x49daa9['type']==='child_removed'||(_0x49daa9['prevName']=_0x188039['getPredecessorChildName'](_0x49daa9['childName'],_0x49daa9['snapshotNode'],_0x5ee055['index_'])),_0x49daa9;}function au(_0x319978,_0x121563,_0x42cdb8){if(_0x121563['childName']==null||_0x42cdb8['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x203e25=new E(_0x121563['childName'],_0x121563['snapshotNode']),_0x41eb91=new E(_0x42cdb8['childName'],_0x42cdb8['snapshotNode']);return _0x319978['index_']['compare'](_0x203e25,_0x41eb91);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x3b1711,_0x22e5bc){return{'eventCache':_0x3b1711,'serverCache':_0x22e5bc};}function Rt(_0x581428,_0x21d21e,_0x237881,_0x6b38bf){return Un(new Te(_0x21d21e,_0x237881,_0x6b38bf),_0x581428['serverCache']);}function Fo(_0x1f1191,_0x260bc1,_0x9d21fe,_0x1453cb){return Un(_0x1f1191['eventCache'],new Te(_0x260bc1,_0x9d21fe,_0x1453cb));}function wn(_0x2f2866){return _0x2f2866['eventCache']['isFullyInitialized']()?_0x2f2866['eventCache']['getNode']():null;}function Ve(_0x302862){return _0x302862['serverCache']['isFullyInitialized']()?_0x302862['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0x277031){let _0x30606c=new b(null);return x(_0x277031,(_0x1e8409,_0x3d47b0)=>{_0x30606c=_0x30606c['set'](new C(_0x1e8409),_0x3d47b0);}),_0x30606c;}constructor(_0x4ed6d5,_0x6b6f98=cu()){this['value']=_0x4ed6d5,this['children']=_0x6b6f98;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x1c5996,_0x27bd18){if(this['value']!=null&&_0x27bd18(this['value']))return{'path':w(),'value':this['value']};if(v(_0x1c5996))return null;{const _0x255ffd=y(_0x1c5996),_0x31957d=this['children']['get'](_0x255ffd);if(_0x31957d!==null){const _0x5d1d40=_0x31957d['findRootMostMatchingPathAndValue'](S(_0x1c5996),_0x27bd18);return _0x5d1d40!=null?{'path':k(new C(_0x255ffd),_0x5d1d40['path']),'value':_0x5d1d40['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x5598ec){return this['findRootMostMatchingPathAndValue'](_0x5598ec,()=>!0x0);}['subtree'](_0x5dba83){if(v(_0x5dba83))return this;{const _0x36fa31=y(_0x5dba83),_0x4cd8f6=this['children']['get'](_0x36fa31);return _0x4cd8f6!==null?_0x4cd8f6['subtree'](S(_0x5dba83)):new b(null);}}['set'](_0x33ce8c,_0x7649ca){if(v(_0x33ce8c))return new b(_0x7649ca,this['children']);{const _0x4cc7cf=y(_0x33ce8c),_0x1e3b7f=(this['children']['get'](_0x4cc7cf)||new b(null))['set'](S(_0x33ce8c),_0x7649ca),_0x52ae65=this['children']['insert'](_0x4cc7cf,_0x1e3b7f);return new b(this['value'],_0x52ae65);}}['remove'](_0x2fcaaf){if(v(_0x2fcaaf))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0xe99d63=y(_0x2fcaaf),_0x267f23=this['children']['get'](_0xe99d63);if(_0x267f23){const _0x3532ae=_0x267f23['remove'](S(_0x2fcaaf));let _0x4b0946;return _0x3532ae['isEmpty']()?_0x4b0946=this['children']['remove'](_0xe99d63):_0x4b0946=this['children']['insert'](_0xe99d63,_0x3532ae),this['value']===null&&_0x4b0946['isEmpty']()?new b(null):new b(this['value'],_0x4b0946);}else return this;}}['get'](_0x2a1b3a){if(v(_0x2a1b3a))return this['value'];{const _0xfe402b=y(_0x2a1b3a),_0x1a3c50=this['children']['get'](_0xfe402b);return _0x1a3c50?_0x1a3c50['get'](S(_0x2a1b3a)):null;}}['setTree'](_0x2b8116,_0x1d5209){if(v(_0x2b8116))return _0x1d5209;{const _0x53b8fd=y(_0x2b8116),_0x4ea05f=(this['children']['get'](_0x53b8fd)||new b(null))['setTree'](S(_0x2b8116),_0x1d5209);let _0x3ef02b;return _0x4ea05f['isEmpty']()?_0x3ef02b=this['children']['remove'](_0x53b8fd):_0x3ef02b=this['children']['insert'](_0x53b8fd,_0x4ea05f),new b(this['value'],_0x3ef02b);}}['fold'](_0x225b0e){return this['fold_'](w(),_0x225b0e);}['fold_'](_0x25d82e,_0x1b0097){const _0x629dcb={};return this['children']['inorderTraversal']((_0x2f3822,_0xd63c19)=>{_0x629dcb[_0x2f3822]=_0xd63c19['fold_'](k(_0x25d82e,_0x2f3822),_0x1b0097);}),_0x1b0097(_0x25d82e,this['value'],_0x629dcb);}['findOnPath'](_0x2dba9a,_0x47ca7a){return this['findOnPath_'](_0x2dba9a,w(),_0x47ca7a);}['findOnPath_'](_0x4896ae,_0x3f8993,_0x398bd3){const _0x529482=this['value']?_0x398bd3(_0x3f8993,this['value']):!0x1;if(_0x529482)return _0x529482;if(v(_0x4896ae))return null;{const _0x3a97a0=y(_0x4896ae),_0x5bfbc7=this['children']['get'](_0x3a97a0);return _0x5bfbc7?_0x5bfbc7['findOnPath_'](S(_0x4896ae),k(_0x3f8993,_0x3a97a0),_0x398bd3):null;}}['foreachOnPath'](_0x4d7964,_0x59d839){return this['foreachOnPath_'](_0x4d7964,w(),_0x59d839);}['foreachOnPath_'](_0x4a859f,_0x552ed9,_0x2e8779){if(v(_0x4a859f))return this;{this['value']&&_0x2e8779(_0x552ed9,this['value']);const _0x18e64f=y(_0x4a859f),_0x32ae43=this['children']['get'](_0x18e64f);return _0x32ae43?_0x32ae43['foreachOnPath_'](S(_0x4a859f),k(_0x552ed9,_0x18e64f),_0x2e8779):new b(null);}}['foreach'](_0x4e5c28){this['foreach_'](w(),_0x4e5c28);}['foreach_'](_0x588a72,_0x1cb6d3){this['children']['inorderTraversal']((_0x476eb2,_0x4e671a)=>{_0x4e671a['foreach_'](k(_0x588a72,_0x476eb2),_0x1cb6d3);}),this['value']&&_0x1cb6d3(_0x588a72,this['value']);}['foreachChild'](_0x28830b){this['children']['inorderTraversal']((_0x2e877c,_0xfd8453)=>{_0xfd8453['value']&&_0x28830b(_0x2e877c,_0xfd8453['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x1ed0bc){this['writeTree_']=_0x1ed0bc;}static['empty'](){return new K(new b(null));}}function At(_0x5a8574,_0x36aab2,_0x249c87){if(v(_0x36aab2))return new K(new b(_0x249c87));{const _0x219b76=_0x5a8574['writeTree_']['findRootMostValueAndPath'](_0x36aab2);if(_0x219b76!=null){const _0x464b98=_0x219b76['path'];let _0x3a7c9a=_0x219b76['value'];const _0x3d4383=F(_0x464b98,_0x36aab2);return _0x3a7c9a=_0x3a7c9a['updateChild'](_0x3d4383,_0x249c87),new K(_0x5a8574['writeTree_']['set'](_0x464b98,_0x3a7c9a));}else{const _0x212e90=new b(_0x249c87),_0xedcef4=_0x5a8574['writeTree_']['setTree'](_0x36aab2,_0x212e90);return new K(_0xedcef4);}}}function bi(_0x5826d3,_0x42fd53,_0xc90d9){let _0xfb1bb5=_0x5826d3;return x(_0xc90d9,(_0x53f232,_0x553b87)=>{_0xfb1bb5=At(_0xfb1bb5,k(_0x42fd53,_0x53f232),_0x553b87);}),_0xfb1bb5;}function or(_0x3f769b,_0x5aa257){if(v(_0x5aa257))return K['empty']();{const _0x4a3b68=_0x3f769b['writeTree_']['setTree'](_0x5aa257,new b(null));return new K(_0x4a3b68);}}function Ri(_0x5436b1,_0x4eb753){return ze(_0x5436b1,_0x4eb753)!=null;}function ze(_0x4f9308,_0x2ae44e){const _0x309aa4=_0x4f9308['writeTree_']['findRootMostValueAndPath'](_0x2ae44e);return _0x309aa4!=null?_0x4f9308['writeTree_']['get'](_0x309aa4['path'])['getChild'](F(_0x309aa4['path'],_0x2ae44e)):null;}function ar(_0x360ce4){const _0x34d45c=[],_0x13ab6d=_0x360ce4['writeTree_']['value'];return _0x13ab6d!=null?_0x13ab6d['isLeafNode']()||_0x13ab6d['forEachChild'](R,(_0x223de9,_0x428cda)=>{_0x34d45c['push'](new E(_0x223de9,_0x428cda));}):_0x360ce4['writeTree_']['children']['inorderTraversal']((_0x272452,_0x59f15e)=>{_0x59f15e['value']!=null&&_0x34d45c['push'](new E(_0x272452,_0x59f15e['value']));}),_0x34d45c;}function Ee(_0x10c8d4,_0xe8f672){if(v(_0xe8f672))return _0x10c8d4;{const _0x3bd041=ze(_0x10c8d4,_0xe8f672);return _0x3bd041!=null?new K(new b(_0x3bd041)):new K(_0x10c8d4['writeTree_']['subtree'](_0xe8f672));}}function Ai(_0x29a263){return _0x29a263['writeTree_']['isEmpty']();}function at(_0x45b40c,_0x400690){return Uo(w(),_0x45b40c['writeTree_'],_0x400690);}function Uo(_0x3e7d99,_0x16a69b,_0xf12715){if(_0x16a69b['value']!=null)return _0xf12715['updateChild'](_0x3e7d99,_0x16a69b['value']);{let _0x58eeb6=null;return _0x16a69b['children']['inorderTraversal']((_0x4a9dc1,_0x36f5ce)=>{_0x4a9dc1==='.priority'?(f(_0x36f5ce['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x58eeb6=_0x36f5ce['value']):_0xf12715=Uo(k(_0x3e7d99,_0x4a9dc1),_0x36f5ce,_0xf12715);}),!_0xf12715['getChild'](_0x3e7d99)['isEmpty']()&&_0x58eeb6!==null&&(_0xf12715=_0xf12715['updateChild'](k(_0x3e7d99,'.priority'),_0x58eeb6)),_0xf12715;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x51716e,_0xa3e6d6){return Ho(_0xa3e6d6,_0x51716e);}function lu(_0xf1969c,_0x1b1e0e,_0x3f419c,_0x407763,_0x529ee6){f(_0x407763>_0xf1969c['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x529ee6===void 0x0&&(_0x529ee6=!0x0),_0xf1969c['allWrites']['push']({'path':_0x1b1e0e,'snap':_0x3f419c,'writeId':_0x407763,'visible':_0x529ee6}),_0x529ee6&&(_0xf1969c['visibleWrites']=At(_0xf1969c['visibleWrites'],_0x1b1e0e,_0x3f419c)),_0xf1969c['lastWriteId']=_0x407763;}function hu(_0x4f200a,_0x14e3ad,_0x1e5fc8,_0x117910){f(_0x117910>_0x4f200a['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x4f200a['allWrites']['push']({'path':_0x14e3ad,'children':_0x1e5fc8,'writeId':_0x117910,'visible':!0x0}),_0x4f200a['visibleWrites']=bi(_0x4f200a['visibleWrites'],_0x14e3ad,_0x1e5fc8),_0x4f200a['lastWriteId']=_0x117910;}function uu(_0x2bff15,_0x108b52){for(let _0x539353=0x0;_0x539353<_0x2bff15['allWrites']['length'];_0x539353++){const _0x46b7c5=_0x2bff15['allWrites'][_0x539353];if(_0x46b7c5['writeId']===_0x108b52)return _0x46b7c5;}return null;}function du(_0x151502,_0x3d1caa){const _0x143890=_0x151502['allWrites']['findIndex'](_0x117033=>_0x117033['writeId']===_0x3d1caa);f(_0x143890>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x53dc59=_0x151502['allWrites'][_0x143890];_0x151502['allWrites']['splice'](_0x143890,0x1);let _0x1664c2=_0x53dc59['visible'],_0x470649=!0x1,_0x5c3ea7=_0x151502['allWrites']['length']-0x1;for(;_0x1664c2&&_0x5c3ea7>=0x0;){const _0x227366=_0x151502['allWrites'][_0x5c3ea7];_0x227366['visible']&&(_0x5c3ea7>=_0x143890&&fu(_0x227366,_0x53dc59['path'])?_0x1664c2=!0x1:G(_0x53dc59['path'],_0x227366['path'])&&(_0x470649=!0x0)),_0x5c3ea7--;}if(_0x1664c2){if(_0x470649)return pu(_0x151502),!0x0;if(_0x53dc59['snap'])_0x151502['visibleWrites']=or(_0x151502['visibleWrites'],_0x53dc59['path']);else{const _0x482598=_0x53dc59['children'];x(_0x482598,_0x5026b7=>{_0x151502['visibleWrites']=or(_0x151502['visibleWrites'],k(_0x53dc59['path'],_0x5026b7));});}return!0x0;}else return!0x1;}function fu(_0x31de84,_0x283ee4){if(_0x31de84['snap'])return G(_0x31de84['path'],_0x283ee4);for(const _0x75db55 in _0x31de84['children'])if(_0x31de84['children']['hasOwnProperty'](_0x75db55)&&G(k(_0x31de84['path'],_0x75db55),_0x283ee4))return!0x0;return!0x1;}function pu(_0x1141ec){_0x1141ec['visibleWrites']=Wo(_0x1141ec['allWrites'],_u,w()),_0x1141ec['allWrites']['length']>0x0?_0x1141ec['lastWriteId']=_0x1141ec['allWrites'][_0x1141ec['allWrites']['length']-0x1]['writeId']:_0x1141ec['lastWriteId']=-0x1;}function _u(_0x10c89d){return _0x10c89d['visible'];}function Wo(_0x4d4418,_0x1ec651,_0x1e87a1){let _0x1b363e=K['empty']();for(let _0x50a7f1=0x0;_0x50a7f1<_0x4d4418['length'];++_0x50a7f1){const _0x551abd=_0x4d4418[_0x50a7f1];if(_0x1ec651(_0x551abd)){const _0x2fc7b8=_0x551abd['path'];let _0x4e44b7;if(_0x551abd['snap'])G(_0x1e87a1,_0x2fc7b8)?(_0x4e44b7=F(_0x1e87a1,_0x2fc7b8),_0x1b363e=At(_0x1b363e,_0x4e44b7,_0x551abd['snap'])):G(_0x2fc7b8,_0x1e87a1)&&(_0x4e44b7=F(_0x2fc7b8,_0x1e87a1),_0x1b363e=At(_0x1b363e,w(),_0x551abd['snap']['getChild'](_0x4e44b7)));else{if(_0x551abd['children']){if(G(_0x1e87a1,_0x2fc7b8))_0x4e44b7=F(_0x1e87a1,_0x2fc7b8),_0x1b363e=bi(_0x1b363e,_0x4e44b7,_0x551abd['children']);else{if(G(_0x2fc7b8,_0x1e87a1)){if(_0x4e44b7=F(_0x2fc7b8,_0x1e87a1),v(_0x4e44b7))_0x1b363e=bi(_0x1b363e,w(),_0x551abd['children']);else{const _0x39a231=Le(_0x551abd['children'],y(_0x4e44b7));if(_0x39a231){const _0x42a457=_0x39a231['getChild'](S(_0x4e44b7));_0x1b363e=At(_0x1b363e,w(),_0x42a457);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x1b363e;}function Bo(_0x1a0034,_0x49771e,_0x1d3209,_0x4270b1,_0x3789fe){if(!_0x4270b1&&!_0x3789fe){const _0x302305=ze(_0x1a0034['visibleWrites'],_0x49771e);if(_0x302305!=null)return _0x302305;{const _0x3c1241=Ee(_0x1a0034['visibleWrites'],_0x49771e);if(Ai(_0x3c1241))return _0x1d3209;if(_0x1d3209==null&&!Ri(_0x3c1241,w()))return null;{const _0x1ee9d3=_0x1d3209||g['EMPTY_NODE'];return at(_0x3c1241,_0x1ee9d3);}}}else{const _0x387e76=Ee(_0x1a0034['visibleWrites'],_0x49771e);if(!_0x3789fe&&Ai(_0x387e76))return _0x1d3209;if(!_0x3789fe&&_0x1d3209==null&&!Ri(_0x387e76,w()))return null;{const _0x278813=function(_0x38ffd9){return(_0x38ffd9['visible']||_0x3789fe)&&(!_0x4270b1||!~_0x4270b1['indexOf'](_0x38ffd9['writeId']))&&(G(_0x38ffd9['path'],_0x49771e)||G(_0x49771e,_0x38ffd9['path']));},_0x11d1f=Wo(_0x1a0034['allWrites'],_0x278813,_0x49771e),_0x3d3024=_0x1d3209||g['EMPTY_NODE'];return at(_0x11d1f,_0x3d3024);}}}function gu(_0x34f2b6,_0x5e094f,_0xf90f28){let _0x1e0853=g['EMPTY_NODE'];const _0x42ce1b=ze(_0x34f2b6['visibleWrites'],_0x5e094f);if(_0x42ce1b)return _0x42ce1b['isLeafNode']()||_0x42ce1b['forEachChild'](R,(_0x308ca8,_0x3831ce)=>{_0x1e0853=_0x1e0853['updateImmediateChild'](_0x308ca8,_0x3831ce);}),_0x1e0853;if(_0xf90f28){const _0x266458=Ee(_0x34f2b6['visibleWrites'],_0x5e094f);return _0xf90f28['forEachChild'](R,(_0x6e5cfc,_0x56735d)=>{const _0x648195=at(Ee(_0x266458,new C(_0x6e5cfc)),_0x56735d);_0x1e0853=_0x1e0853['updateImmediateChild'](_0x6e5cfc,_0x648195);}),ar(_0x266458)['forEach'](_0x5ad0f5=>{_0x1e0853=_0x1e0853['updateImmediateChild'](_0x5ad0f5['name'],_0x5ad0f5['node']);}),_0x1e0853;}else{const _0x59dc05=Ee(_0x34f2b6['visibleWrites'],_0x5e094f);return ar(_0x59dc05)['forEach'](_0x239f8b=>{_0x1e0853=_0x1e0853['updateImmediateChild'](_0x239f8b['name'],_0x239f8b['node']);}),_0x1e0853;}}function mu(_0x16244f,_0x25e785,_0x47f2bc,_0x4f186d,_0x41f93a){f(_0x4f186d||_0x41f93a,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x5c7d12=k(_0x25e785,_0x47f2bc);if(Ri(_0x16244f['visibleWrites'],_0x5c7d12))return null;{const _0x5c50e6=Ee(_0x16244f['visibleWrites'],_0x5c7d12);return Ai(_0x5c50e6)?_0x41f93a['getChild'](_0x47f2bc):at(_0x5c50e6,_0x41f93a['getChild'](_0x47f2bc));}}function yu(_0x47a50e,_0x1875c3,_0x3e4955,_0x2b0d23){const _0x48281e=k(_0x1875c3,_0x3e4955),_0x5032f0=ze(_0x47a50e['visibleWrites'],_0x48281e);if(_0x5032f0!=null)return _0x5032f0;if(_0x2b0d23['isCompleteForChild'](_0x3e4955)){const _0x36c033=Ee(_0x47a50e['visibleWrites'],_0x48281e);return at(_0x36c033,_0x2b0d23['getNode']()['getImmediateChild'](_0x3e4955));}else return null;}function vu(_0x2eb94d,_0x520e92){return ze(_0x2eb94d['visibleWrites'],_0x520e92);}function Eu(_0x4b7623,_0x2ea1c7,_0x148665,_0x20dde3,_0x51c11f,_0x38654e,_0x323c30){let _0x3642f4;const _0x44f231=Ee(_0x4b7623['visibleWrites'],_0x2ea1c7),_0x2d5058=ze(_0x44f231,w());if(_0x2d5058!=null)_0x3642f4=_0x2d5058;else{if(_0x148665!=null)_0x3642f4=at(_0x44f231,_0x148665);else return[];}if(_0x3642f4=_0x3642f4['withIndex'](_0x323c30),!_0x3642f4['isEmpty']()&&!_0x3642f4['isLeafNode']()){const _0x4822fe=[],_0x35d449=_0x323c30['getCompare'](),_0x3e01d8=_0x38654e?_0x3642f4['getReverseIteratorFrom'](_0x20dde3,_0x323c30):_0x3642f4['getIteratorFrom'](_0x20dde3,_0x323c30);let _0x141eb9=_0x3e01d8['getNext']();for(;_0x141eb9&&_0x4822fe['length']<_0x51c11f;)_0x35d449(_0x141eb9,_0x20dde3)!==0x0&&_0x4822fe['push'](_0x141eb9),_0x141eb9=_0x3e01d8['getNext']();return _0x4822fe;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x15f5b6,_0x391aea,_0x1ea2c4,_0x27eaf1){return Bo(_0x15f5b6['writeTree'],_0x15f5b6['treePath'],_0x391aea,_0x1ea2c4,_0x27eaf1);}function is(_0xf254fc,_0x1d7f2e){return gu(_0xf254fc['writeTree'],_0xf254fc['treePath'],_0x1d7f2e);}function cr(_0x8a8d83,_0x175b90,_0x53d854,_0x3b40c3){return mu(_0x8a8d83['writeTree'],_0x8a8d83['treePath'],_0x175b90,_0x53d854,_0x3b40c3);}function Tn(_0x477214,_0x19d2c7){return vu(_0x477214['writeTree'],k(_0x477214['treePath'],_0x19d2c7));}function wu(_0x3b32c5,_0x16bfdd,_0x57ddfb,_0x14ae39,_0x564b39,_0x438c3e){return Eu(_0x3b32c5['writeTree'],_0x3b32c5['treePath'],_0x16bfdd,_0x57ddfb,_0x14ae39,_0x564b39,_0x438c3e);}function ss(_0x3d930e,_0x1e1ff6,_0x33b9fc){return yu(_0x3d930e['writeTree'],_0x3d930e['treePath'],_0x1e1ff6,_0x33b9fc);}function Vo(_0x2bcd9b,_0x50e219){return Ho(k(_0x2bcd9b['treePath'],_0x50e219),_0x2bcd9b['writeTree']);}function Ho(_0x9ac6f3,_0x4b6e88){return{'treePath':_0x9ac6f3,'writeTree':_0x4b6e88};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x25e5fd){const _0x13df9b=_0x25e5fd['type'],_0x3f78ee=_0x25e5fd['childName'];f(_0x13df9b==='child_added'||_0x13df9b==='child_changed'||_0x13df9b==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x3f78ee!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x523f03=this['changeMap']['get'](_0x3f78ee);if(_0x523f03){const _0xcb70ef=_0x523f03['type'];if(_0x13df9b==='child_added'&&_0xcb70ef==='child_removed')this['changeMap']['set'](_0x3f78ee,xt(_0x3f78ee,_0x25e5fd['snapshotNode'],_0x523f03['snapshotNode']));else{if(_0x13df9b==='child_removed'&&_0xcb70ef==='child_added')this['changeMap']['delete'](_0x3f78ee);else{if(_0x13df9b==='child_removed'&&_0xcb70ef==='child_changed')this['changeMap']['set'](_0x3f78ee,Lt(_0x3f78ee,_0x523f03['oldSnap']));else{if(_0x13df9b==='child_changed'&&_0xcb70ef==='child_added')this['changeMap']['set'](_0x3f78ee,rt(_0x3f78ee,_0x25e5fd['snapshotNode']));else{if(_0x13df9b==='child_changed'&&_0xcb70ef==='child_changed')this['changeMap']['set'](_0x3f78ee,xt(_0x3f78ee,_0x25e5fd['snapshotNode'],_0x523f03['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x25e5fd+'\x20occurred\x20after\x20'+_0x523f03);}}}}}else this['changeMap']['set'](_0x3f78ee,_0x25e5fd);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x343202){return null;}['getChildAfterChild'](_0x9e9609,_0x1cfe41,_0x4d8a77){return null;}}const $o=new Tu();class rs{constructor(_0xebe47d,_0x44ab67,_0x3a898c=null){this['writes_']=_0xebe47d,this['viewCache_']=_0x44ab67,this['optCompleteServerCache_']=_0x3a898c;}['getCompleteChild'](_0x1baa82){const _0x3e31ca=this['viewCache_']['eventCache'];if(_0x3e31ca['isCompleteForChild'](_0x1baa82))return _0x3e31ca['getNode']()['getImmediateChild'](_0x1baa82);{const _0x154ae6=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x1baa82,_0x154ae6);}}['getChildAfterChild'](_0x3ed1d3,_0x19b24d,_0x584199){const _0xc00b84=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x52bd37=wu(this['writes_'],_0xc00b84,_0x19b24d,0x1,_0x584199,_0x3ed1d3);return _0x52bd37['length']===0x0?null:_0x52bd37[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x5f0b1e){return{'filter':_0x5f0b1e};}function bu(_0x43e089,_0x4309f8){f(_0x4309f8['eventCache']['getNode']()['isIndexed'](_0x43e089['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x4309f8['serverCache']['getNode']()['isIndexed'](_0x43e089['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x2d0ea9,_0x54fb35,_0x3c4a40,_0x98b1fa,_0x11095a){const _0x49c140=new Cu();let _0x356058,_0x18f4c2;if(_0x3c4a40['type']===z['OVERWRITE']){const _0x18ab3f=_0x3c4a40;_0x18ab3f['source']['fromUser']?_0x356058=ki(_0x2d0ea9,_0x54fb35,_0x18ab3f['path'],_0x18ab3f['snap'],_0x98b1fa,_0x11095a,_0x49c140):(f(_0x18ab3f['source']['fromServer'],'Unknown\x20source.'),_0x18f4c2=_0x18ab3f['source']['tagged']||_0x54fb35['serverCache']['isFiltered']()&&!v(_0x18ab3f['path']),_0x356058=Sn(_0x2d0ea9,_0x54fb35,_0x18ab3f['path'],_0x18ab3f['snap'],_0x98b1fa,_0x11095a,_0x18f4c2,_0x49c140));}else{if(_0x3c4a40['type']===z['MERGE']){const _0x589352=_0x3c4a40;_0x589352['source']['fromUser']?_0x356058=ku(_0x2d0ea9,_0x54fb35,_0x589352['path'],_0x589352['children'],_0x98b1fa,_0x11095a,_0x49c140):(f(_0x589352['source']['fromServer'],'Unknown\x20source.'),_0x18f4c2=_0x589352['source']['tagged']||_0x54fb35['serverCache']['isFiltered'](),_0x356058=Pi(_0x2d0ea9,_0x54fb35,_0x589352['path'],_0x589352['children'],_0x98b1fa,_0x11095a,_0x18f4c2,_0x49c140));}else{if(_0x3c4a40['type']===z['ACK_USER_WRITE']){const _0x144b81=_0x3c4a40;_0x144b81['revert']?_0x356058=Ou(_0x2d0ea9,_0x54fb35,_0x144b81['path'],_0x98b1fa,_0x11095a,_0x49c140):_0x356058=Pu(_0x2d0ea9,_0x54fb35,_0x144b81['path'],_0x144b81['affectedTree'],_0x98b1fa,_0x11095a,_0x49c140);}else{if(_0x3c4a40['type']===z['LISTEN_COMPLETE'])_0x356058=Nu(_0x2d0ea9,_0x54fb35,_0x3c4a40['path'],_0x98b1fa,_0x49c140);else throw ht('Unknown\x20operation\x20type:\x20'+_0x3c4a40['type']);}}}const _0x4fc7ba=_0x49c140['getChanges']();return Au(_0x54fb35,_0x356058,_0x4fc7ba),{'viewCache':_0x356058,'changes':_0x4fc7ba};}function Au(_0x7fd9e0,_0x20c943,_0x314c8f){const _0xb74c23=_0x20c943['eventCache'];if(_0xb74c23['isFullyInitialized']()){const _0x344774=_0xb74c23['getNode']()['isLeafNode']()||_0xb74c23['getNode']()['isEmpty'](),_0x3460e5=wn(_0x7fd9e0);(_0x314c8f['length']>0x0||!_0x7fd9e0['eventCache']['isFullyInitialized']()||_0x344774&&!_0xb74c23['getNode']()['equals'](_0x3460e5)||!_0xb74c23['getNode']()['getPriority']()['equals'](_0x3460e5['getPriority']()))&&_0x314c8f['push'](Lo(wn(_0x20c943)));}}function Go(_0x5093d7,_0x3501b9,_0x4b614c,_0x4293b0,_0x347972,_0x36d068){const _0x16556b=_0x3501b9['eventCache'];if(Tn(_0x4293b0,_0x4b614c)!=null)return _0x3501b9;{let _0x2c1de6,_0x2148ed;if(v(_0x4b614c)){if(f(_0x3501b9['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x3501b9['serverCache']['isFiltered']()){const _0x4051cd=Ve(_0x3501b9),_0x3bfac1=_0x4051cd instanceof g?_0x4051cd:g['EMPTY_NODE'],_0xe0b8f1=is(_0x4293b0,_0x3bfac1);_0x2c1de6=_0x5093d7['filter']['updateFullNode'](_0x3501b9['eventCache']['getNode'](),_0xe0b8f1,_0x36d068);}else{const _0x5e8e8e=Cn(_0x4293b0,Ve(_0x3501b9));_0x2c1de6=_0x5093d7['filter']['updateFullNode'](_0x3501b9['eventCache']['getNode'](),_0x5e8e8e,_0x36d068);}}else{const _0x25423a=y(_0x4b614c);if(_0x25423a==='.priority'){f(Ce(_0x4b614c)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x2668d2=_0x16556b['getNode']();_0x2148ed=_0x3501b9['serverCache']['getNode']();const _0x2caee4=cr(_0x4293b0,_0x4b614c,_0x2668d2,_0x2148ed);_0x2caee4!=null?_0x2c1de6=_0x5093d7['filter']['updatePriority'](_0x2668d2,_0x2caee4):_0x2c1de6=_0x16556b['getNode']();}else{const _0x3a7085=S(_0x4b614c);let _0x55e836;if(_0x16556b['isCompleteForChild'](_0x25423a)){_0x2148ed=_0x3501b9['serverCache']['getNode']();const _0x4f3323=cr(_0x4293b0,_0x4b614c,_0x16556b['getNode'](),_0x2148ed);_0x4f3323!=null?_0x55e836=_0x16556b['getNode']()['getImmediateChild'](_0x25423a)['updateChild'](_0x3a7085,_0x4f3323):_0x55e836=_0x16556b['getNode']()['getImmediateChild'](_0x25423a);}else _0x55e836=ss(_0x4293b0,_0x25423a,_0x3501b9['serverCache']);_0x55e836!=null?_0x2c1de6=_0x5093d7['filter']['updateChild'](_0x16556b['getNode'](),_0x25423a,_0x55e836,_0x3a7085,_0x347972,_0x36d068):_0x2c1de6=_0x16556b['getNode']();}}return Rt(_0x3501b9,_0x2c1de6,_0x16556b['isFullyInitialized']()||v(_0x4b614c),_0x5093d7['filter']['filtersNodes']());}}function Sn(_0x2da135,_0x46476e,_0x9faa1e,_0xb2ccc,_0x1b94a9,_0xe2a732,_0x4128c6,_0x42ad89){const _0x17700e=_0x46476e['serverCache'];let _0x461e22;const _0xd6e606=_0x4128c6?_0x2da135['filter']:_0x2da135['filter']['getIndexedFilter']();if(v(_0x9faa1e))_0x461e22=_0xd6e606['updateFullNode'](_0x17700e['getNode'](),_0xb2ccc,null);else{if(_0xd6e606['filtersNodes']()&&!_0x17700e['isFiltered']()){const _0x31bef8=_0x17700e['getNode']()['updateChild'](_0x9faa1e,_0xb2ccc);_0x461e22=_0xd6e606['updateFullNode'](_0x17700e['getNode'](),_0x31bef8,null);}else{const _0x77bc7d=y(_0x9faa1e);if(!_0x17700e['isCompleteForPath'](_0x9faa1e)&&Ce(_0x9faa1e)>0x1)return _0x46476e;const _0x22ad4e=S(_0x9faa1e),_0x143f88=_0x17700e['getNode']()['getImmediateChild'](_0x77bc7d)['updateChild'](_0x22ad4e,_0xb2ccc);_0x77bc7d==='.priority'?_0x461e22=_0xd6e606['updatePriority'](_0x17700e['getNode'](),_0x143f88):_0x461e22=_0xd6e606['updateChild'](_0x17700e['getNode'](),_0x77bc7d,_0x143f88,_0x22ad4e,$o,null);}}const _0x2d038c=Fo(_0x46476e,_0x461e22,_0x17700e['isFullyInitialized']()||v(_0x9faa1e),_0xd6e606['filtersNodes']()),_0x30b2e6=new rs(_0x1b94a9,_0x2d038c,_0xe2a732);return Go(_0x2da135,_0x2d038c,_0x9faa1e,_0x1b94a9,_0x30b2e6,_0x42ad89);}function ki(_0x303b97,_0x3cef81,_0x3defad,_0x2d8636,_0x5ba788,_0x2257f9,_0x5bad92){const _0x54bf8b=_0x3cef81['eventCache'];let _0x6550ba,_0x41c052;const _0x5503ef=new rs(_0x5ba788,_0x3cef81,_0x2257f9);if(v(_0x3defad))_0x41c052=_0x303b97['filter']['updateFullNode'](_0x3cef81['eventCache']['getNode'](),_0x2d8636,_0x5bad92),_0x6550ba=Rt(_0x3cef81,_0x41c052,!0x0,_0x303b97['filter']['filtersNodes']());else{const _0x348d64=y(_0x3defad);if(_0x348d64==='.priority')_0x41c052=_0x303b97['filter']['updatePriority'](_0x3cef81['eventCache']['getNode'](),_0x2d8636),_0x6550ba=Rt(_0x3cef81,_0x41c052,_0x54bf8b['isFullyInitialized'](),_0x54bf8b['isFiltered']());else{const _0x21e530=S(_0x3defad),_0x963ce0=_0x54bf8b['getNode']()['getImmediateChild'](_0x348d64);let _0x1886aa;if(v(_0x21e530))_0x1886aa=_0x2d8636;else{const _0x23d385=_0x5503ef['getCompleteChild'](_0x348d64);_0x23d385!=null?ji(_0x21e530)==='.priority'&&_0x23d385['getChild'](Ro(_0x21e530))['isEmpty']()?_0x1886aa=_0x23d385:_0x1886aa=_0x23d385['updateChild'](_0x21e530,_0x2d8636):_0x1886aa=g['EMPTY_NODE'];}if(_0x963ce0['equals'](_0x1886aa))_0x6550ba=_0x3cef81;else{const _0x401d98=_0x303b97['filter']['updateChild'](_0x54bf8b['getNode'](),_0x348d64,_0x1886aa,_0x21e530,_0x5503ef,_0x5bad92);_0x6550ba=Rt(_0x3cef81,_0x401d98,_0x54bf8b['isFullyInitialized'](),_0x303b97['filter']['filtersNodes']());}}}return _0x6550ba;}function lr(_0x893dd,_0x495464){return _0x893dd['eventCache']['isCompleteForChild'](_0x495464);}function ku(_0x562e4c,_0x1ffe71,_0xe41393,_0x2f5220,_0x24ae8e,_0xe8e1cd,_0x4dce61){let _0x2c25b1=_0x1ffe71;return _0x2f5220['foreach']((_0x503a19,_0x9b8213)=>{const _0x1911ad=k(_0xe41393,_0x503a19);lr(_0x1ffe71,y(_0x1911ad))&&(_0x2c25b1=ki(_0x562e4c,_0x2c25b1,_0x1911ad,_0x9b8213,_0x24ae8e,_0xe8e1cd,_0x4dce61));}),_0x2f5220['foreach']((_0x4050fe,_0x11ca9d)=>{const _0x34c4ed=k(_0xe41393,_0x4050fe);lr(_0x1ffe71,y(_0x34c4ed))||(_0x2c25b1=ki(_0x562e4c,_0x2c25b1,_0x34c4ed,_0x11ca9d,_0x24ae8e,_0xe8e1cd,_0x4dce61));}),_0x2c25b1;}function hr(_0x19c44a,_0x38144c,_0x2ce41c){return _0x2ce41c['foreach']((_0x59accc,_0x2b2ff9)=>{_0x38144c=_0x38144c['updateChild'](_0x59accc,_0x2b2ff9);}),_0x38144c;}function Pi(_0x5b5cea,_0x5bd8b6,_0x325bc5,_0x5ed471,_0x2338ee,_0x1ef916,_0x455c96,_0x4d85fa){if(_0x5bd8b6['serverCache']['getNode']()['isEmpty']()&&!_0x5bd8b6['serverCache']['isFullyInitialized']())return _0x5bd8b6;let _0x1ce6d3=_0x5bd8b6,_0x22515f;v(_0x325bc5)?_0x22515f=_0x5ed471:_0x22515f=new b(null)['setTree'](_0x325bc5,_0x5ed471);const _0x46f88d=_0x5bd8b6['serverCache']['getNode']();return _0x22515f['children']['inorderTraversal']((_0x35a67e,_0x381aba)=>{if(_0x46f88d['hasChild'](_0x35a67e)){const _0x2b7373=_0x5bd8b6['serverCache']['getNode']()['getImmediateChild'](_0x35a67e),_0x466cbd=hr(_0x5b5cea,_0x2b7373,_0x381aba);_0x1ce6d3=Sn(_0x5b5cea,_0x1ce6d3,new C(_0x35a67e),_0x466cbd,_0x2338ee,_0x1ef916,_0x455c96,_0x4d85fa);}}),_0x22515f['children']['inorderTraversal']((_0x642930,_0x1ba31d)=>{const _0x309c54=!_0x5bd8b6['serverCache']['isCompleteForChild'](_0x642930)&&_0x1ba31d['value']===null;if(!_0x46f88d['hasChild'](_0x642930)&&!_0x309c54){const _0x274179=_0x5bd8b6['serverCache']['getNode']()['getImmediateChild'](_0x642930),_0x5df448=hr(_0x5b5cea,_0x274179,_0x1ba31d);_0x1ce6d3=Sn(_0x5b5cea,_0x1ce6d3,new C(_0x642930),_0x5df448,_0x2338ee,_0x1ef916,_0x455c96,_0x4d85fa);}}),_0x1ce6d3;}function Pu(_0x43afca,_0x4bbfa2,_0x101f1c,_0x5a0bd5,_0x3b0851,_0x5bb0c5,_0x166cd6){if(Tn(_0x3b0851,_0x101f1c)!=null)return _0x4bbfa2;const _0xe02d3b=_0x4bbfa2['serverCache']['isFiltered'](),_0x2689d1=_0x4bbfa2['serverCache'];if(_0x5a0bd5['value']!=null){if(v(_0x101f1c)&&_0x2689d1['isFullyInitialized']()||_0x2689d1['isCompleteForPath'](_0x101f1c))return Sn(_0x43afca,_0x4bbfa2,_0x101f1c,_0x2689d1['getNode']()['getChild'](_0x101f1c),_0x3b0851,_0x5bb0c5,_0xe02d3b,_0x166cd6);if(v(_0x101f1c)){let _0xc77b2=new b(null);return _0x2689d1['getNode']()['forEachChild'](ve,(_0x1f7a76,_0x10140a)=>{_0xc77b2=_0xc77b2['set'](new C(_0x1f7a76),_0x10140a);}),Pi(_0x43afca,_0x4bbfa2,_0x101f1c,_0xc77b2,_0x3b0851,_0x5bb0c5,_0xe02d3b,_0x166cd6);}else return _0x4bbfa2;}else{let _0x2f1f32=new b(null);return _0x5a0bd5['foreach']((_0x152271,_0x5d13cd)=>{const _0x5e6920=k(_0x101f1c,_0x152271);_0x2689d1['isCompleteForPath'](_0x5e6920)&&(_0x2f1f32=_0x2f1f32['set'](_0x152271,_0x2689d1['getNode']()['getChild'](_0x5e6920)));}),Pi(_0x43afca,_0x4bbfa2,_0x101f1c,_0x2f1f32,_0x3b0851,_0x5bb0c5,_0xe02d3b,_0x166cd6);}}function Nu(_0x107183,_0x2fc17d,_0x336db7,_0x2f74b1,_0x3ba3d3){const _0x4831ee=_0x2fc17d['serverCache'],_0x5a53b7=Fo(_0x2fc17d,_0x4831ee['getNode'](),_0x4831ee['isFullyInitialized']()||v(_0x336db7),_0x4831ee['isFiltered']());return Go(_0x107183,_0x5a53b7,_0x336db7,_0x2f74b1,$o,_0x3ba3d3);}function Ou(_0xe19817,_0x5c12d3,_0x1a1038,_0x2d16d3,_0x2e9e55,_0x4b2ef5){let _0x2b2bb1;if(Tn(_0x2d16d3,_0x1a1038)!=null)return _0x5c12d3;{const _0x5674ce=new rs(_0x2d16d3,_0x5c12d3,_0x2e9e55),_0x52520d=_0x5c12d3['eventCache']['getNode']();let _0x45a051;if(v(_0x1a1038)||y(_0x1a1038)==='.priority'){let _0x572918;if(_0x5c12d3['serverCache']['isFullyInitialized']())_0x572918=Cn(_0x2d16d3,Ve(_0x5c12d3));else{const _0x392890=_0x5c12d3['serverCache']['getNode']();f(_0x392890 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x572918=is(_0x2d16d3,_0x392890);}_0x572918=_0x572918,_0x45a051=_0xe19817['filter']['updateFullNode'](_0x52520d,_0x572918,_0x4b2ef5);}else{const _0x5de9d7=y(_0x1a1038);let _0x46fb1d=ss(_0x2d16d3,_0x5de9d7,_0x5c12d3['serverCache']);_0x46fb1d==null&&_0x5c12d3['serverCache']['isCompleteForChild'](_0x5de9d7)&&(_0x46fb1d=_0x52520d['getImmediateChild'](_0x5de9d7)),_0x46fb1d!=null?_0x45a051=_0xe19817['filter']['updateChild'](_0x52520d,_0x5de9d7,_0x46fb1d,S(_0x1a1038),_0x5674ce,_0x4b2ef5):_0x5c12d3['eventCache']['getNode']()['hasChild'](_0x5de9d7)?_0x45a051=_0xe19817['filter']['updateChild'](_0x52520d,_0x5de9d7,g['EMPTY_NODE'],S(_0x1a1038),_0x5674ce,_0x4b2ef5):_0x45a051=_0x52520d,_0x45a051['isEmpty']()&&_0x5c12d3['serverCache']['isFullyInitialized']()&&(_0x2b2bb1=Cn(_0x2d16d3,Ve(_0x5c12d3)),_0x2b2bb1['isLeafNode']()&&(_0x45a051=_0xe19817['filter']['updateFullNode'](_0x45a051,_0x2b2bb1,_0x4b2ef5)));}return _0x2b2bb1=_0x5c12d3['serverCache']['isFullyInitialized']()||Tn(_0x2d16d3,w())!=null,Rt(_0x5c12d3,_0x45a051,_0x2b2bb1,_0xe19817['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x52f8c0,_0x38220d){this['query_']=_0x52f8c0,this['eventRegistrations_']=[];const _0x18b2ba=this['query_']['_queryParams'],_0x13a4fb=new Xi(_0x18b2ba['getIndex']()),_0xfc2096=Kh(_0x18b2ba);this['processor_']=Su(_0xfc2096);const _0x5246b1=_0x38220d['serverCache'],_0x1e1a74=_0x38220d['eventCache'],_0x151687=_0x13a4fb['updateFullNode'](g['EMPTY_NODE'],_0x5246b1['getNode'](),null),_0x58425b=_0xfc2096['updateFullNode'](g['EMPTY_NODE'],_0x1e1a74['getNode'](),null),_0x59f789=new Te(_0x151687,_0x5246b1['isFullyInitialized'](),_0x13a4fb['filtersNodes']()),_0x57299d=new Te(_0x58425b,_0x1e1a74['isFullyInitialized'](),_0xfc2096['filtersNodes']());this['viewCache_']=Un(_0x57299d,_0x59f789),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x24bd44){return _0x24bd44['viewCache_']['serverCache']['getNode']();}function Lu(_0x3092f5){return wn(_0x3092f5['viewCache_']);}function xu(_0x128b58,_0x5e4d22){const _0x3bf20d=Ve(_0x128b58['viewCache_']);return _0x3bf20d&&(_0x128b58['query']['_queryParams']['loadsAllData']()||!v(_0x5e4d22)&&!_0x3bf20d['getImmediateChild'](y(_0x5e4d22))['isEmpty']())?_0x3bf20d['getChild'](_0x5e4d22):null;}function ur(_0x4c92b8){return _0x4c92b8['eventRegistrations_']['length']===0x0;}function Fu(_0x14c6a5,_0x415fcb){_0x14c6a5['eventRegistrations_']['push'](_0x415fcb);}function dr(_0x5a685d,_0x4818ac,_0xccb99e){const _0x3ec07d=[];if(_0xccb99e){f(_0x4818ac==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x24c5d9=_0x5a685d['query']['_path'];_0x5a685d['eventRegistrations_']['forEach'](_0x40862c=>{const _0x4071b3=_0x40862c['createCancelEvent'](_0xccb99e,_0x24c5d9);_0x4071b3&&_0x3ec07d['push'](_0x4071b3);});}if(_0x4818ac){let _0x3875e2=[];for(let _0x2d9b77=0x0;_0x2d9b77<_0x5a685d['eventRegistrations_']['length'];++_0x2d9b77){const _0x411f19=_0x5a685d['eventRegistrations_'][_0x2d9b77];if(!_0x411f19['matches'](_0x4818ac))_0x3875e2['push'](_0x411f19);else{if(_0x4818ac['hasAnyCallback']()){_0x3875e2=_0x3875e2['concat'](_0x5a685d['eventRegistrations_']['slice'](_0x2d9b77+0x1));break;}}}_0x5a685d['eventRegistrations_']=_0x3875e2;}else _0x5a685d['eventRegistrations_']=[];return _0x3ec07d;}function fr(_0x132bef,_0x7b3614,_0x26f143,_0x50773e){_0x7b3614['type']===z['MERGE']&&_0x7b3614['source']['queryId']!==null&&(f(Ve(_0x132bef['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x132bef['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x306acf=_0x132bef['viewCache_'],_0xf8774f=Ru(_0x132bef['processor_'],_0x306acf,_0x7b3614,_0x26f143,_0x50773e);return bu(_0x132bef['processor_'],_0xf8774f['viewCache']),f(_0xf8774f['viewCache']['serverCache']['isFullyInitialized']()||!_0x306acf['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x132bef['viewCache_']=_0xf8774f['viewCache'],qo(_0x132bef,_0xf8774f['changes'],_0xf8774f['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x586726,_0x469e7e){const _0x38d368=_0x586726['viewCache_']['eventCache'],_0x371ee9=[];return _0x38d368['getNode']()['isLeafNode']()||_0x38d368['getNode']()['forEachChild'](R,(_0x2fceb9,_0x52a275)=>{_0x371ee9['push'](rt(_0x2fceb9,_0x52a275));}),_0x38d368['isFullyInitialized']()&&_0x371ee9['push'](Lo(_0x38d368['getNode']())),qo(_0x586726,_0x371ee9,_0x38d368['getNode'](),_0x469e7e);}function qo(_0x3de64c,_0x54259d,_0x258b5f,_0x173f70){const _0x5774bb=_0x173f70?[_0x173f70]:_0x3de64c['eventRegistrations_'];return ru(_0x3de64c['eventGenerator_'],_0x54259d,_0x258b5f,_0x5774bb);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x24e39e){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x24e39e;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x536489){return _0x536489['views']['size']===0x0;}function os(_0x8f546e,_0x3829b9,_0x584807,_0x19f223){const _0x39d47a=_0x3829b9['source']['queryId'];if(_0x39d47a!==null){const _0x2b5ebf=_0x8f546e['views']['get'](_0x39d47a);return f(_0x2b5ebf!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x2b5ebf,_0x3829b9,_0x584807,_0x19f223);}else{let _0x56007b=[];for(const _0x2b90a6 of _0x8f546e['views']['values']())_0x56007b=_0x56007b['concat'](fr(_0x2b90a6,_0x3829b9,_0x584807,_0x19f223));return _0x56007b;}}function jo(_0x1bbc46,_0x212437,_0x290465,_0x140354,_0x4ba529){const _0x4a55e5=_0x212437['_queryIdentifier'],_0x406ce5=_0x1bbc46['views']['get'](_0x4a55e5);if(!_0x406ce5){let _0x278c92=Cn(_0x290465,_0x4ba529?_0x140354:null),_0x1c7892=!0x1;_0x278c92?_0x1c7892=!0x0:_0x140354 instanceof g?(_0x278c92=is(_0x290465,_0x140354),_0x1c7892=!0x1):(_0x278c92=g['EMPTY_NODE'],_0x1c7892=!0x1);const _0xbe8483=Un(new Te(_0x278c92,_0x1c7892,!0x1),new Te(_0x140354,_0x4ba529,!0x1));return new Du(_0x212437,_0xbe8483);}return _0x406ce5;}function Hu(_0x4cc533,_0x3dd2bf,_0x11a2e0,_0x4c247b,_0x24ad7c,_0x255685){const _0x407413=jo(_0x4cc533,_0x3dd2bf,_0x4c247b,_0x24ad7c,_0x255685);return _0x4cc533['views']['has'](_0x3dd2bf['_queryIdentifier'])||_0x4cc533['views']['set'](_0x3dd2bf['_queryIdentifier'],_0x407413),Fu(_0x407413,_0x11a2e0),Uu(_0x407413,_0x11a2e0);}function $u(_0x226722,_0x3f3c59,_0x236a90,_0x5ed26a){const _0x3d1ff9=_0x3f3c59['_queryIdentifier'],_0x31cd49=[];let _0x184310=[];const _0x116177=Se(_0x226722);if(_0x3d1ff9==='default'){for(const [_0x5ea561,_0x57bcaa]of _0x226722['views']['entries']())_0x184310=_0x184310['concat'](dr(_0x57bcaa,_0x236a90,_0x5ed26a)),ur(_0x57bcaa)&&(_0x226722['views']['delete'](_0x5ea561),_0x57bcaa['query']['_queryParams']['loadsAllData']()||_0x31cd49['push'](_0x57bcaa['query']));}else{const _0x48e092=_0x226722['views']['get'](_0x3d1ff9);_0x48e092&&(_0x184310=_0x184310['concat'](dr(_0x48e092,_0x236a90,_0x5ed26a)),ur(_0x48e092)&&(_0x226722['views']['delete'](_0x3d1ff9),_0x48e092['query']['_queryParams']['loadsAllData']()||_0x31cd49['push'](_0x48e092['query'])));}return _0x116177&&!Se(_0x226722)&&_0x31cd49['push'](new(Bu())(_0x3f3c59['_repo'],_0x3f3c59['_path'])),{'removed':_0x31cd49,'events':_0x184310};}function Ko(_0x2dbed3){const _0x3a9b51=[];for(const _0x4173e5 of _0x2dbed3['views']['values']())_0x4173e5['query']['_queryParams']['loadsAllData']()||_0x3a9b51['push'](_0x4173e5);return _0x3a9b51;}function Ie(_0x3a95b8,_0xf017de){let _0x5ea592=null;for(const _0x1fdbad of _0x3a95b8['views']['values']())_0x5ea592=_0x5ea592||xu(_0x1fdbad,_0xf017de);return _0x5ea592;}function Yo(_0x3ceb20,_0x428033){if(_0x428033['_queryParams']['loadsAllData']())return Bn(_0x3ceb20);{const _0x5571f6=_0x428033['_queryIdentifier'];return _0x3ceb20['views']['get'](_0x5571f6);}}function Qo(_0x32b01f,_0x3a7b4a){return Yo(_0x32b01f,_0x3a7b4a)!=null;}function Se(_0x20f230){return Bn(_0x20f230)!=null;}function Bn(_0x1b527e){for(const _0x2088c7 of _0x1b527e['views']['values']())if(_0x2088c7['query']['_queryParams']['loadsAllData']())return _0x2088c7;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x3e7e9c){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x3e7e9c;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0xd898c0){this['listenProvider_']=_0xd898c0,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0xb5794e,_0x12ebf5,_0x5a31ac,_0x5f2c72,_0x5c334e){return lu(_0xb5794e['pendingWriteTree_'],_0x12ebf5,_0x5a31ac,_0x5f2c72,_0x5c334e),_0x5c334e?_t(_0xb5794e,new Be(es(),_0x12ebf5,_0x5a31ac)):[];}function ju(_0x1ba752,_0x4bace4,_0x43f827,_0x16d2d6){hu(_0x1ba752['pendingWriteTree_'],_0x4bace4,_0x43f827,_0x16d2d6);const _0x20eb79=b['fromObject'](_0x43f827);return _t(_0x1ba752,new ot(es(),_0x4bace4,_0x20eb79));}function _e(_0x4d79ea,_0x51af1f,_0x21ba93=!0x1){const _0x32eab4=uu(_0x4d79ea['pendingWriteTree_'],_0x51af1f);if(du(_0x4d79ea['pendingWriteTree_'],_0x51af1f)){let _0x5a4880=new b(null);return _0x32eab4['snap']!=null?_0x5a4880=_0x5a4880['set'](w(),!0x0):x(_0x32eab4['children'],_0xd8d578=>{_0x5a4880=_0x5a4880['set'](new C(_0xd8d578),!0x0);}),_t(_0x4d79ea,new In(_0x32eab4['path'],_0x5a4880,_0x21ba93));}else return[];}function Yt(_0x384034,_0xf454b6,_0x3d65da){return _t(_0x384034,new Be(ts(),_0xf454b6,_0x3d65da));}function Ku(_0x1f52f4,_0x5d0104,_0x5b9192){const _0x18dcb6=b['fromObject'](_0x5b9192);return _t(_0x1f52f4,new ot(ts(),_0x5d0104,_0x18dcb6));}function Yu(_0x56a37a,_0x28484a){return _t(_0x56a37a,new Ut(ts(),_0x28484a));}function Qu(_0x4edb35,_0x1f3b7b,_0x2cbc21){const _0x11b001=cs(_0x4edb35,_0x2cbc21);if(_0x11b001){const _0x3cc3f2=ls(_0x11b001),_0x5b626f=_0x3cc3f2['path'],_0x4806a7=_0x3cc3f2['queryId'],_0x4715bc=F(_0x5b626f,_0x1f3b7b),_0x2f651f=new Ut(ns(_0x4806a7),_0x4715bc);return hs(_0x4edb35,_0x5b626f,_0x2f651f);}else return[];}function An(_0x23b8e6,_0x49e924,_0x3b212c,_0x1b25f5,_0x2255e8=!0x1){const _0xb5606f=_0x49e924['_path'],_0x223958=_0x23b8e6['syncPointTree_']['get'](_0xb5606f);let _0x4ab66e=[];if(_0x223958&&(_0x49e924['_queryIdentifier']==='default'||Qo(_0x223958,_0x49e924))){const _0x395156=$u(_0x223958,_0x49e924,_0x3b212c,_0x1b25f5);Vu(_0x223958)&&(_0x23b8e6['syncPointTree_']=_0x23b8e6['syncPointTree_']['remove'](_0xb5606f));const _0x288e8b=_0x395156['removed'];if(_0x4ab66e=_0x395156['events'],!_0x2255e8){const _0x1e2a2c=_0x288e8b['findIndex'](_0x37dd50=>_0x37dd50['_queryParams']['loadsAllData']())!==-0x1,_0x33e6c2=_0x23b8e6['syncPointTree_']['findOnPath'](_0xb5606f,(_0x14468c,_0x220c72)=>Se(_0x220c72));if(_0x1e2a2c&&!_0x33e6c2){const _0x15fcda=_0x23b8e6['syncPointTree_']['subtree'](_0xb5606f);if(!_0x15fcda['isEmpty']()){const _0x374aeb=Zu(_0x15fcda);for(let _0x5a7b68=0x0;_0x5a7b68<_0x374aeb['length'];++_0x5a7b68){const _0x30cb37=_0x374aeb[_0x5a7b68],_0x26c411=_0x30cb37['query'],_0xc5675f=ea(_0x23b8e6,_0x30cb37);_0x23b8e6['listenProvider_']['startListening'](kt(_0x26c411),Wt(_0x23b8e6,_0x26c411),_0xc5675f['hashFn'],_0xc5675f['onComplete']);}}}!_0x33e6c2&&_0x288e8b['length']>0x0&&!_0x1b25f5&&(_0x1e2a2c?_0x23b8e6['listenProvider_']['stopListening'](kt(_0x49e924),null):_0x288e8b['forEach'](_0x300367=>{const _0x4dfe7c=_0x23b8e6['queryToTagMap']['get'](Hn(_0x300367));_0x23b8e6['listenProvider_']['stopListening'](kt(_0x300367),_0x4dfe7c);}));}ed(_0x23b8e6,_0x288e8b);}return _0x4ab66e;}function Jo(_0x2dba14,_0x5812cb,_0x413ec2,_0x4fdd3a){const _0x33868a=cs(_0x2dba14,_0x4fdd3a);if(_0x33868a!=null){const _0x6e9a7=ls(_0x33868a),_0xdfac6c=_0x6e9a7['path'],_0x321e19=_0x6e9a7['queryId'],_0x10f0d7=F(_0xdfac6c,_0x5812cb),_0x371b7e=new Be(ns(_0x321e19),_0x10f0d7,_0x413ec2);return hs(_0x2dba14,_0xdfac6c,_0x371b7e);}else return[];}function Ju(_0x33c8d9,_0x2b1772,_0x2835a7,_0x5a5a1b){const _0x48a6d9=cs(_0x33c8d9,_0x5a5a1b);if(_0x48a6d9){const _0x3c02eb=ls(_0x48a6d9),_0x3488df=_0x3c02eb['path'],_0x913497=_0x3c02eb['queryId'],_0x56800a=F(_0x3488df,_0x2b1772),_0x286077=b['fromObject'](_0x2835a7),_0x5ef3d2=new ot(ns(_0x913497),_0x56800a,_0x286077);return hs(_0x33c8d9,_0x3488df,_0x5ef3d2);}else return[];}function Ni(_0x8b05ea,_0x36002b,_0x47e5ea,_0x110c51=!0x1){const _0x3cc7f8=_0x36002b['_path'];let _0x56f0a4=null,_0x251796=!0x1;_0x8b05ea['syncPointTree_']['foreachOnPath'](_0x3cc7f8,(_0x231774,_0x5a038d)=>{const _0x4cf0de=F(_0x231774,_0x3cc7f8);_0x56f0a4=_0x56f0a4||Ie(_0x5a038d,_0x4cf0de),_0x251796=_0x251796||Se(_0x5a038d);});let _0x3b079c=_0x8b05ea['syncPointTree_']['get'](_0x3cc7f8);_0x3b079c?(_0x251796=_0x251796||Se(_0x3b079c),_0x56f0a4=_0x56f0a4||Ie(_0x3b079c,w())):(_0x3b079c=new zo(),_0x8b05ea['syncPointTree_']=_0x8b05ea['syncPointTree_']['set'](_0x3cc7f8,_0x3b079c));let _0x39abbd;_0x56f0a4!=null?_0x39abbd=!0x0:(_0x39abbd=!0x1,_0x56f0a4=g['EMPTY_NODE'],_0x8b05ea['syncPointTree_']['subtree'](_0x3cc7f8)['foreachChild']((_0x401edd,_0x28c226)=>{const _0x4eab39=Ie(_0x28c226,w());_0x4eab39&&(_0x56f0a4=_0x56f0a4['updateImmediateChild'](_0x401edd,_0x4eab39));}));const _0x45b199=Qo(_0x3b079c,_0x36002b);if(!_0x45b199&&!_0x36002b['_queryParams']['loadsAllData']()){const _0x6fd301=Hn(_0x36002b);f(!_0x8b05ea['queryToTagMap']['has'](_0x6fd301),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x2c57ea=td();_0x8b05ea['queryToTagMap']['set'](_0x6fd301,_0x2c57ea),_0x8b05ea['tagToQueryMap']['set'](_0x2c57ea,_0x6fd301);}const _0x56d0a8=Wn(_0x8b05ea['pendingWriteTree_'],_0x3cc7f8);let _0x310682=Hu(_0x3b079c,_0x36002b,_0x47e5ea,_0x56d0a8,_0x56f0a4,_0x39abbd);if(!_0x45b199&&!_0x251796&&!_0x110c51){const _0x3d60ee=Yo(_0x3b079c,_0x36002b);_0x310682=_0x310682['concat'](nd(_0x8b05ea,_0x36002b,_0x3d60ee));}return _0x310682;}function Vn(_0x44ea88,_0x16dd09,_0x18f179){const _0x441a8c=_0x44ea88['pendingWriteTree_'],_0x1f706b=_0x44ea88['syncPointTree_']['findOnPath'](_0x16dd09,(_0x29eb0c,_0x2d6f29)=>{const _0x5455bf=F(_0x29eb0c,_0x16dd09),_0x10c4c2=Ie(_0x2d6f29,_0x5455bf);if(_0x10c4c2)return _0x10c4c2;});return Bo(_0x441a8c,_0x16dd09,_0x1f706b,_0x18f179,!0x0);}function Xu(_0x3c2eac,_0x11b95a){const _0x421546=_0x11b95a['_path'];let _0x4664a6=null;_0x3c2eac['syncPointTree_']['foreachOnPath'](_0x421546,(_0x16e34c,_0x3bad57)=>{const _0x31bb6e=F(_0x16e34c,_0x421546);_0x4664a6=_0x4664a6||Ie(_0x3bad57,_0x31bb6e);});let _0x48abd9=_0x3c2eac['syncPointTree_']['get'](_0x421546);_0x48abd9?_0x4664a6=_0x4664a6||Ie(_0x48abd9,w()):(_0x48abd9=new zo(),_0x3c2eac['syncPointTree_']=_0x3c2eac['syncPointTree_']['set'](_0x421546,_0x48abd9));const _0x5142a5=_0x4664a6!=null,_0x31981c=_0x5142a5?new Te(_0x4664a6,!0x0,!0x1):null,_0x18cecf=Wn(_0x3c2eac['pendingWriteTree_'],_0x11b95a['_path']),_0x5297b6=jo(_0x48abd9,_0x11b95a,_0x18cecf,_0x5142a5?_0x31981c['getNode']():g['EMPTY_NODE'],_0x5142a5);return Lu(_0x5297b6);}function _t(_0x394a5a,_0x1e07b4){return Xo(_0x1e07b4,_0x394a5a['syncPointTree_'],null,Wn(_0x394a5a['pendingWriteTree_'],w()));}function Xo(_0x118306,_0x5b340d,_0x3e9a26,_0x55e9b9){if(v(_0x118306['path']))return Zo(_0x118306,_0x5b340d,_0x3e9a26,_0x55e9b9);{const _0xff8020=_0x5b340d['get'](w());_0x3e9a26==null&&_0xff8020!=null&&(_0x3e9a26=Ie(_0xff8020,w()));let _0x36be57=[];const _0x349ec0=y(_0x118306['path']),_0x335c28=_0x118306['operationForChild'](_0x349ec0),_0x31d462=_0x5b340d['children']['get'](_0x349ec0);if(_0x31d462&&_0x335c28){const _0x563557=_0x3e9a26?_0x3e9a26['getImmediateChild'](_0x349ec0):null,_0x476182=Vo(_0x55e9b9,_0x349ec0);_0x36be57=_0x36be57['concat'](Xo(_0x335c28,_0x31d462,_0x563557,_0x476182));}return _0xff8020&&(_0x36be57=_0x36be57['concat'](os(_0xff8020,_0x118306,_0x55e9b9,_0x3e9a26))),_0x36be57;}}function Zo(_0x199ff5,_0x353380,_0x1621bd,_0x1c8ac2){const _0x154f2e=_0x353380['get'](w());_0x1621bd==null&&_0x154f2e!=null&&(_0x1621bd=Ie(_0x154f2e,w()));let _0x1a51e1=[];return _0x353380['children']['inorderTraversal']((_0x2ee23a,_0x17d076)=>{const _0x1a9ebb=_0x1621bd?_0x1621bd['getImmediateChild'](_0x2ee23a):null,_0x43f474=Vo(_0x1c8ac2,_0x2ee23a),_0x133728=_0x199ff5['operationForChild'](_0x2ee23a);_0x133728&&(_0x1a51e1=_0x1a51e1['concat'](Zo(_0x133728,_0x17d076,_0x1a9ebb,_0x43f474)));}),_0x154f2e&&(_0x1a51e1=_0x1a51e1['concat'](os(_0x154f2e,_0x199ff5,_0x1c8ac2,_0x1621bd))),_0x1a51e1;}function ea(_0x1ad4e9,_0x44a9d7){const _0x404083=_0x44a9d7['query'],_0x55d0dd=Wt(_0x1ad4e9,_0x404083);return{'hashFn':()=>(Mu(_0x44a9d7)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x47cb33=>{if(_0x47cb33==='ok')return _0x55d0dd?Qu(_0x1ad4e9,_0x404083['_path'],_0x55d0dd):Yu(_0x1ad4e9,_0x404083['_path']);{const _0x23106b=Kl(_0x47cb33,_0x404083);return An(_0x1ad4e9,_0x404083,null,_0x23106b);}}};}function Wt(_0x29fc88,_0x487178){const _0x20ed61=Hn(_0x487178);return _0x29fc88['queryToTagMap']['get'](_0x20ed61);}function Hn(_0x403f76){return _0x403f76['_path']['toString']()+'$'+_0x403f76['_queryIdentifier'];}function cs(_0x2a5771,_0x227cd9){return _0x2a5771['tagToQueryMap']['get'](_0x227cd9);}function ls(_0x877580){const _0xc417a4=_0x877580['indexOf']('$');return f(_0xc417a4!==-0x1&&_0xc417a4<_0x877580['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x877580['substr'](_0xc417a4+0x1),'path':new C(_0x877580['substr'](0x0,_0xc417a4))};}function hs(_0x909a70,_0x2cec85,_0x236a68){const _0x42dcb5=_0x909a70['syncPointTree_']['get'](_0x2cec85);f(_0x42dcb5,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x3ebc26=Wn(_0x909a70['pendingWriteTree_'],_0x2cec85);return os(_0x42dcb5,_0x236a68,_0x3ebc26,null);}function Zu(_0x4c3d96){return _0x4c3d96['fold']((_0x5da3ef,_0x25f0db,_0x580a02)=>{if(_0x25f0db&&Se(_0x25f0db))return[Bn(_0x25f0db)];{let _0x484c7d=[];return _0x25f0db&&(_0x484c7d=Ko(_0x25f0db)),x(_0x580a02,(_0x598aeb,_0x2ceacd)=>{_0x484c7d=_0x484c7d['concat'](_0x2ceacd);}),_0x484c7d;}});}function kt(_0x207c43){return _0x207c43['_queryParams']['loadsAllData']()&&!_0x207c43['_queryParams']['isDefault']()?new(qu())(_0x207c43['_repo'],_0x207c43['_path']):_0x207c43;}function ed(_0x4c8085,_0x2dad5d){for(let _0x43ed39=0x0;_0x43ed39<_0x2dad5d['length'];++_0x43ed39){const _0x3cdc4d=_0x2dad5d[_0x43ed39];if(!_0x3cdc4d['_queryParams']['loadsAllData']()){const _0x3e0605=Hn(_0x3cdc4d),_0x193372=_0x4c8085['queryToTagMap']['get'](_0x3e0605);_0x4c8085['queryToTagMap']['delete'](_0x3e0605),_0x4c8085['tagToQueryMap']['delete'](_0x193372);}}}function td(){return zu++;}function nd(_0x224f4a,_0x4b1934,_0x52ea9d){const _0x27b7e2=_0x4b1934['_path'],_0x35a8e3=Wt(_0x224f4a,_0x4b1934),_0x4e526f=ea(_0x224f4a,_0x52ea9d),_0x5be55a=_0x224f4a['listenProvider_']['startListening'](kt(_0x4b1934),_0x35a8e3,_0x4e526f['hashFn'],_0x4e526f['onComplete']),_0x1aba1b=_0x224f4a['syncPointTree_']['subtree'](_0x27b7e2);if(_0x35a8e3)f(!Se(_0x1aba1b['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x4dd717=_0x1aba1b['fold']((_0x1f317e,_0x17e7a7,_0xb8077f)=>{if(!v(_0x1f317e)&&_0x17e7a7&&Se(_0x17e7a7))return[Bn(_0x17e7a7)['query']];{let _0x41dfc9=[];return _0x17e7a7&&(_0x41dfc9=_0x41dfc9['concat'](Ko(_0x17e7a7)['map'](_0x1cfed7=>_0x1cfed7['query']))),x(_0xb8077f,(_0x3f9c32,_0x14d25c)=>{_0x41dfc9=_0x41dfc9['concat'](_0x14d25c);}),_0x41dfc9;}});for(let _0x25f4a6=0x0;_0x25f4a6<_0x4dd717['length'];++_0x25f4a6){const _0x4a9648=_0x4dd717[_0x25f4a6];_0x224f4a['listenProvider_']['stopListening'](kt(_0x4a9648),Wt(_0x224f4a,_0x4a9648));}}return _0x5be55a;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x3e466d){this['node_']=_0x3e466d;}['getImmediateChild'](_0x3f6966){const _0x127e74=this['node_']['getImmediateChild'](_0x3f6966);return new us(_0x127e74);}['node'](){return this['node_'];}}class ds{constructor(_0x241aff,_0x233ac3){this['syncTree_']=_0x241aff,this['path_']=_0x233ac3;}['getImmediateChild'](_0x5d4790){const _0x3f6f3b=k(this['path_'],_0x5d4790);return new ds(this['syncTree_'],_0x3f6f3b);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x569790){return _0x569790=_0x569790||{},_0x569790['timestamp']=_0x569790['timestamp']||new Date()['getTime'](),_0x569790;},_r=function(_0x35562d,_0x2804f2,_0x5d7fdb){if(!_0x35562d||typeof _0x35562d!='object')return _0x35562d;if(f('.sv'in _0x35562d,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x35562d['.sv']=='string')return sd(_0x35562d['.sv'],_0x2804f2,_0x5d7fdb);if(typeof _0x35562d['.sv']=='object')return rd(_0x35562d['.sv'],_0x2804f2);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x35562d,null,0x2));},sd=function(_0x1becc8,_0x26aa80,_0x3c0984){switch(_0x1becc8){case'timestamp':return _0x3c0984['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x1becc8);}},rd=function(_0x4ab0e5,_0x437684,_0x1db338){_0x4ab0e5['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x4ab0e5,null,0x2));const _0xaa8ba3=_0x4ab0e5['increment'];typeof _0xaa8ba3!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0xaa8ba3);const _0x1fd109=_0x437684['node']();if(f(_0x1fd109!==null&&typeof _0x1fd109<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x1fd109['isLeafNode']())return _0xaa8ba3;const _0x36b9a4=_0x1fd109['getValue']();return typeof _0x36b9a4!='number'?_0xaa8ba3:_0x36b9a4+_0xaa8ba3;},ta=function(_0x2416a8,_0x47c5b0,_0x4b3afd,_0x56968e){return ps(_0x47c5b0,new ds(_0x4b3afd,_0x2416a8),_0x56968e);},fs=function(_0x47a369,_0x1d5ba7,_0x31a46a){return ps(_0x47a369,new us(_0x1d5ba7),_0x31a46a);};function ps(_0x36d2b8,_0x2a4053,_0x29291e){const _0x22d63d=_0x36d2b8['getPriority']()['val'](),_0x34102b=_r(_0x22d63d,_0x2a4053['getImmediateChild']('.priority'),_0x29291e);let _0x2762ef;if(_0x36d2b8['isLeafNode']()){const _0x5855f0=_0x36d2b8,_0x3b7c91=_r(_0x5855f0['getValue'](),_0x2a4053,_0x29291e);return _0x3b7c91!==_0x5855f0['getValue']()||_0x34102b!==_0x5855f0['getPriority']()['val']()?new D(_0x3b7c91,A(_0x34102b)):_0x36d2b8;}else{const _0xbb0f0f=_0x36d2b8;return _0x2762ef=_0xbb0f0f,_0x34102b!==_0xbb0f0f['getPriority']()['val']()&&(_0x2762ef=_0x2762ef['updatePriority'](new D(_0x34102b))),_0xbb0f0f['forEachChild'](R,(_0x329d5f,_0x2fd320)=>{const _0x226250=ps(_0x2fd320,_0x2a4053['getImmediateChild'](_0x329d5f),_0x29291e);_0x226250!==_0x2fd320&&(_0x2762ef=_0x2762ef['updateImmediateChild'](_0x329d5f,_0x226250));}),_0x2762ef;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x371b65='',_0x255690=null,_0x43793f={'children':{},'childCount':0x0}){this['name']=_0x371b65,this['parent']=_0x255690,this['node']=_0x43793f;}}function $n(_0x131aab,_0x10c0f1){let _0x294b94=_0x10c0f1 instanceof C?_0x10c0f1:new C(_0x10c0f1),_0x3752bb=_0x131aab,_0x1933ea=y(_0x294b94);for(;_0x1933ea!==null;){const _0x1e51b5=Le(_0x3752bb['node']['children'],_0x1933ea)||{'children':{},'childCount':0x0};_0x3752bb=new _s(_0x1933ea,_0x3752bb,_0x1e51b5),_0x294b94=S(_0x294b94),_0x1933ea=y(_0x294b94);}return _0x3752bb;}function je(_0x4563e3){return _0x4563e3['node']['value'];}function gs(_0x40c472,_0x19d6bf){_0x40c472['node']['value']=_0x19d6bf,Oi(_0x40c472);}function na(_0x170d21){return _0x170d21['node']['childCount']>0x0;}function od(_0x4dbb9c){return je(_0x4dbb9c)===void 0x0&&!na(_0x4dbb9c);}function Gn(_0x3289b7,_0xe032c){x(_0x3289b7['node']['children'],(_0x5a1839,_0x46b2d4)=>{_0xe032c(new _s(_0x5a1839,_0x3289b7,_0x46b2d4));});}function ia(_0xe93ced,_0x22a249,_0x338a66,_0x450591){_0x338a66&&_0x22a249(_0xe93ced),Gn(_0xe93ced,_0x3a6a30=>{ia(_0x3a6a30,_0x22a249,!0x0);});}function ad(_0x4a3386,_0x2b2f69,_0x2f0f5a){let _0x14271a=_0x4a3386['parent'];for(;_0x14271a!==null;){if(_0x2b2f69(_0x14271a))return!0x0;_0x14271a=_0x14271a['parent'];}return!0x1;}function Qt(_0x3a9f51){return new C(_0x3a9f51['parent']===null?_0x3a9f51['name']:Qt(_0x3a9f51['parent'])+'/'+_0x3a9f51['name']);}function Oi(_0x3acf7e){_0x3acf7e['parent']!==null&&cd(_0x3acf7e['parent'],_0x3acf7e['name'],_0x3acf7e);}function cd(_0x1e2023,_0x47a242,_0x2631f9){const _0xf33d06=od(_0x2631f9),_0x7e7b9d=Q(_0x1e2023['node']['children'],_0x47a242);_0xf33d06&&_0x7e7b9d?(delete _0x1e2023['node']['children'][_0x47a242],_0x1e2023['node']['childCount']--,Oi(_0x1e2023)):!_0xf33d06&&!_0x7e7b9d&&(_0x1e2023['node']['children'][_0x47a242]=_0x2631f9['node'],_0x1e2023['node']['childCount']++,Oi(_0x1e2023));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x1113be){return typeof _0x1113be=='string'&&_0x1113be['length']!==0x0&&!ld['test'](_0x1113be);},sa=function(_0x2406b6){return typeof _0x2406b6=='string'&&_0x2406b6['length']!==0x0&&!hd['test'](_0x2406b6);},ud=function(_0x6d3c44){return _0x6d3c44&&(_0x6d3c44=_0x6d3c44['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x6d3c44);},Bt=function(_0x938226){return _0x938226===null||typeof _0x938226=='string'||typeof _0x938226=='number'&&!xn(_0x938226)||_0x938226&&typeof _0x938226=='object'&&Q(_0x938226,'.sv');},He=function(_0xff7fa0,_0x5992f3,_0x117faa,_0x933ec3){_0x933ec3&&_0x5992f3===void 0x0||Jt(it(_0xff7fa0,'value'),_0x5992f3,_0x117faa);},Jt=function(_0x4cf438,_0x3611fc,_0x4a2190){const _0x507ce4=_0x4a2190 instanceof C?new Ah(_0x4a2190,_0x4cf438):_0x4a2190;if(_0x3611fc===void 0x0)throw new Error(_0x4cf438+'contains\x20undefined\x20'+Oe(_0x507ce4));if(typeof _0x3611fc=='function')throw new Error(_0x4cf438+'contains\x20a\x20function\x20'+Oe(_0x507ce4)+'\x20with\x20contents\x20=\x20'+_0x3611fc['toString']());if(xn(_0x3611fc))throw new Error(_0x4cf438+'contains\x20'+_0x3611fc['toString']()+'\x20'+Oe(_0x507ce4));if(typeof _0x3611fc=='string'&&_0x3611fc['length']>ui/0x3&&Ln(_0x3611fc)>ui)throw new Error(_0x4cf438+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x507ce4)+'\x20(\x27'+_0x3611fc['substring'](0x0,0x32)+'...\x27)');if(_0x3611fc&&typeof _0x3611fc=='object'){let _0x405c03=!0x1,_0x1743be=!0x1;if(x(_0x3611fc,(_0x50a8e1,_0x2eb1ef)=>{if(_0x50a8e1==='.value')_0x405c03=!0x0;else{if(_0x50a8e1!=='.priority'&&_0x50a8e1!=='.sv'&&(_0x1743be=!0x0,!ms(_0x50a8e1)))throw new Error(_0x4cf438+'\x20contains\x20an\x20invalid\x20key\x20('+_0x50a8e1+')\x20'+Oe(_0x507ce4)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x507ce4,_0x50a8e1),Jt(_0x4cf438,_0x2eb1ef,_0x507ce4),Ph(_0x507ce4);}),_0x405c03&&_0x1743be)throw new Error(_0x4cf438+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x507ce4)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x2d3d49,_0x3fc043){let _0x349d85,_0x53dcfe;for(_0x349d85=0x0;_0x349d85<_0x3fc043['length'];_0x349d85++){_0x53dcfe=_0x3fc043[_0x349d85];const _0xef8c29=Mt(_0x53dcfe);for(let _0xf9545a=0x0;_0xf9545a<_0xef8c29['length'];_0xf9545a++)if(!(_0xef8c29[_0xf9545a]==='.priority'&&_0xf9545a===_0xef8c29['length']-0x1)){if(!ms(_0xef8c29[_0xf9545a]))throw new Error(_0x2d3d49+'contains\x20an\x20invalid\x20key\x20('+_0xef8c29[_0xf9545a]+')\x20in\x20path\x20'+_0x53dcfe['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x3fc043['sort'](Rh);let _0x115f02=null;for(_0x349d85=0x0;_0x349d85<_0x3fc043['length'];_0x349d85++){if(_0x53dcfe=_0x3fc043[_0x349d85],_0x115f02!==null&&G(_0x115f02,_0x53dcfe))throw new Error(_0x2d3d49+'contains\x20a\x20path\x20'+_0x115f02['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x53dcfe['toString']());_0x115f02=_0x53dcfe;}},ra=function(_0x21102d,_0x2ef0a9,_0x3da13c,_0x2b5ef7){const _0x30fea3=it(_0x21102d,'values');if(!(_0x2ef0a9&&typeof _0x2ef0a9=='object')||Array['isArray'](_0x2ef0a9))throw new Error(_0x30fea3+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x240b6a=[];x(_0x2ef0a9,(_0x222ebb,_0x412597)=>{const _0x34ff8f=new C(_0x222ebb);if(Jt(_0x30fea3,_0x412597,k(_0x3da13c,_0x34ff8f)),ji(_0x34ff8f)==='.priority'&&!Bt(_0x412597))throw new Error(_0x30fea3+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x34ff8f['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x240b6a['push'](_0x34ff8f);}),dd(_0x30fea3,_0x240b6a);},fd=function(_0x49a5ce,_0x447976,_0x447fb6){if(xn(_0x447976))throw new Error(it(_0x49a5ce,'priority')+'is\x20'+_0x447976['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x447976))throw new Error(it(_0x49a5ce,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x429aa5,_0x3d938f,_0x44833f,_0x53d060){if(!sa(_0x44833f))throw new Error(it(_0x429aa5,_0x3d938f)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x44833f+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0xeada00,_0x1d7d2e,_0x55e650,_0x258e2f){_0x55e650&&(_0x55e650=_0x55e650['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0xeada00,_0x1d7d2e,_0x55e650);},Me=function(_0x7d9d3d,_0x43363b){if(y(_0x43363b)==='.info')throw new Error(_0x7d9d3d+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x1234d4,_0xbc5b3d){const _0x55b5b7=_0xbc5b3d['path']['toString']();if(typeof _0xbc5b3d['repoInfo']['host']!='string'||_0xbc5b3d['repoInfo']['host']['length']===0x0||!ms(_0xbc5b3d['repoInfo']['namespace'])&&_0xbc5b3d['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x55b5b7['length']!==0x0&&!ud(_0x55b5b7))throw new Error(it(_0x1234d4,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x439707,_0x55d9ba){let _0x105c95=null;for(let _0x543486=0x0;_0x543486<_0x55d9ba['length'];_0x543486++){const _0x3269cb=_0x55d9ba[_0x543486],_0x2560ef=_0x3269cb['getPath']();_0x105c95!==null&&!Ki(_0x2560ef,_0x105c95['path'])&&(_0x439707['eventLists_']['push'](_0x105c95),_0x105c95=null),_0x105c95===null&&(_0x105c95={'events':[],'path':_0x2560ef}),_0x105c95['events']['push'](_0x3269cb);}_0x105c95&&_0x439707['eventLists_']['push'](_0x105c95);}function oa(_0x4e98c3,_0xd3b5b7,_0x15f6d2){qn(_0x4e98c3,_0x15f6d2),aa(_0x4e98c3,_0x2ad321=>Ki(_0x2ad321,_0xd3b5b7));}function V(_0x50a460,_0x4d001b,_0x475bd0){qn(_0x50a460,_0x475bd0),aa(_0x50a460,_0x4a5625=>G(_0x4a5625,_0x4d001b)||G(_0x4d001b,_0x4a5625));}function aa(_0x3c9e11,_0x48ce52){_0x3c9e11['recursionDepth_']++;let _0x3ac5f1=!0x0;for(let _0xdbe0e2=0x0;_0xdbe0e2<_0x3c9e11['eventLists_']['length'];_0xdbe0e2++){const _0x2c0d9d=_0x3c9e11['eventLists_'][_0xdbe0e2];if(_0x2c0d9d){const _0x131c5b=_0x2c0d9d['path'];_0x48ce52(_0x131c5b)?(md(_0x3c9e11['eventLists_'][_0xdbe0e2]),_0x3c9e11['eventLists_'][_0xdbe0e2]=null):_0x3ac5f1=!0x1;}}_0x3ac5f1&&(_0x3c9e11['eventLists_']=[]),_0x3c9e11['recursionDepth_']--;}function md(_0x560fda){for(let _0x30289d=0x0;_0x30289d<_0x560fda['events']['length'];_0x30289d++){const _0x14b065=_0x560fda['events'][_0x30289d];if(_0x14b065!==null){_0x560fda['events'][_0x30289d]=null;const _0x287821=_0x14b065['getEventRunner']();St&&L('event:\x20'+_0x14b065['toString']()),ft(_0x287821);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x4da3d7,_0x605c0a,_0xb573a2,_0x5e4add){this['repoInfo_']=_0x4da3d7,this['forceRestClient_']=_0x605c0a,this['authTokenProvider_']=_0xb573a2,this['appCheckProvider_']=_0x5e4add,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x30b39f,_0x5f47aa,_0x25921a){if(_0x30b39f['stats_']=qi(_0x30b39f['repoInfo_']),_0x30b39f['forceRestClient_']||Xl())_0x30b39f['server_']=new vn(_0x30b39f['repoInfo_'],(_0x17dcf4,_0x382e97,_0x110e34,_0x401b84)=>{gr(_0x30b39f,_0x17dcf4,_0x382e97,_0x110e34,_0x401b84);},_0x30b39f['authTokenProvider_'],_0x30b39f['appCheckProvider_']),setTimeout(()=>mr(_0x30b39f,!0x0),0x0);else{if(typeof _0x25921a<'u'&&_0x25921a!==null){if(typeof _0x25921a!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x25921a);}catch(_0x343b3b){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x343b3b);}}_0x30b39f['persistentConnection_']=new se(_0x30b39f['repoInfo_'],_0x5f47aa,(_0x4c06d6,_0x4fcaeb,_0x29cff0,_0x2cd08d)=>{gr(_0x30b39f,_0x4c06d6,_0x4fcaeb,_0x29cff0,_0x2cd08d);},_0xde87e0=>{mr(_0x30b39f,_0xde87e0);},_0x31514b=>{Id(_0x30b39f,_0x31514b);},_0x30b39f['authTokenProvider_'],_0x30b39f['appCheckProvider_'],_0x25921a),_0x30b39f['server_']=_0x30b39f['persistentConnection_'];}_0x30b39f['authTokenProvider_']['addTokenChangeListener'](_0x553595=>{_0x30b39f['server_']['refreshAuthToken'](_0x553595);}),_0x30b39f['appCheckProvider_']['addTokenChangeListener'](_0x3ddea1=>{_0x30b39f['server_']['refreshAppCheckToken'](_0x3ddea1['token']);}),_0x30b39f['statsReporter_']=ih(_0x30b39f['repoInfo_'],()=>new iu(_0x30b39f['stats_'],_0x30b39f['server_'])),_0x30b39f['infoData_']=new Xh(),_0x30b39f['infoSyncTree_']=new pr({'startListening':(_0x2a28c1,_0x33fc06,_0x3866b4,_0x3a9e91)=>{let _0x57b672=[];const _0x44db6f=_0x30b39f['infoData_']['getNode'](_0x2a28c1['_path']);return _0x44db6f['isEmpty']()||(_0x57b672=Yt(_0x30b39f['infoSyncTree_'],_0x2a28c1['_path'],_0x44db6f),setTimeout(()=>{_0x3a9e91('ok');},0x0)),_0x57b672;},'stopListening':()=>{}}),vs(_0x30b39f,'connected',!0x1),_0x30b39f['serverSyncTree_']=new pr({'startListening':(_0x22ed24,_0x49cbd9,_0x38d266,_0xe1ee35)=>(_0x30b39f['server_']['listen'](_0x22ed24,_0x38d266,_0x49cbd9,(_0x14e48e,_0x464245)=>{const _0x26478d=_0xe1ee35(_0x14e48e,_0x464245);V(_0x30b39f['eventQueue_'],_0x22ed24['_path'],_0x26478d);}),[]),'stopListening':(_0x127284,_0x14e004)=>{_0x30b39f['server_']['unlisten'](_0x127284,_0x14e004);}});}function la(_0x2a3d15){const _0x15f753=_0x2a3d15['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x15f753;}function Xt(_0x5bb0aa){return id({'timestamp':la(_0x5bb0aa)});}function gr(_0x3bf84f,_0x4a63e3,_0x43caad,_0x22c120,_0x5cef10){_0x3bf84f['dataUpdateCount']++;const _0x53fe35=new C(_0x4a63e3);_0x43caad=_0x3bf84f['interceptServerDataCallback_']?_0x3bf84f['interceptServerDataCallback_'](_0x4a63e3,_0x43caad):_0x43caad;let _0x296140=[];if(_0x5cef10){if(_0x22c120){const _0x1088c0=_n(_0x43caad,_0x14bc9d=>A(_0x14bc9d));_0x296140=Ju(_0x3bf84f['serverSyncTree_'],_0x53fe35,_0x1088c0,_0x5cef10);}else{const _0x523619=A(_0x43caad);_0x296140=Jo(_0x3bf84f['serverSyncTree_'],_0x53fe35,_0x523619,_0x5cef10);}}else{if(_0x22c120){const _0x2a43f9=_n(_0x43caad,_0x2f1af7=>A(_0x2f1af7));_0x296140=Ku(_0x3bf84f['serverSyncTree_'],_0x53fe35,_0x2a43f9);}else{const _0x32925d=A(_0x43caad);_0x296140=Yt(_0x3bf84f['serverSyncTree_'],_0x53fe35,_0x32925d);}}let _0x22c45c=_0x53fe35;_0x296140['length']>0x0&&(_0x22c45c=ct(_0x3bf84f,_0x53fe35)),V(_0x3bf84f['eventQueue_'],_0x22c45c,_0x296140);}function mr(_0x2097a9,_0xd289b7){vs(_0x2097a9,'connected',_0xd289b7),_0xd289b7===!0x1&&Sd(_0x2097a9);}function Id(_0x3cfad3,_0x41482a){x(_0x41482a,(_0x4ccf31,_0x4c55b5)=>{vs(_0x3cfad3,_0x4ccf31,_0x4c55b5);});}function vs(_0x1a5c1d,_0x3f7caa,_0x2fa372){const _0x51c356=new C('/.info/'+_0x3f7caa),_0x55f00a=A(_0x2fa372);_0x1a5c1d['infoData_']['updateSnapshot'](_0x51c356,_0x55f00a);const _0x365bc1=Yt(_0x1a5c1d['infoSyncTree_'],_0x51c356,_0x55f00a);V(_0x1a5c1d['eventQueue_'],_0x51c356,_0x365bc1);}function zn(_0x422374){return _0x422374['nextWriteId_']++;}function wd(_0x20b4a0,_0x52e1e1,_0x53a374){const _0x5b5fcb=Xu(_0x20b4a0['serverSyncTree_'],_0x52e1e1);return _0x5b5fcb!=null?Promise['resolve'](_0x5b5fcb):_0x20b4a0['server_']['get'](_0x52e1e1)['then'](_0x30e25f=>{const _0x176ce4=A(_0x30e25f)['withIndex'](_0x52e1e1['_queryParams']['getIndex']());Ni(_0x20b4a0['serverSyncTree_'],_0x52e1e1,_0x53a374,!0x0);let _0x45bec9;if(_0x52e1e1['_queryParams']['loadsAllData']())_0x45bec9=Yt(_0x20b4a0['serverSyncTree_'],_0x52e1e1['_path'],_0x176ce4);else{const _0x230164=Wt(_0x20b4a0['serverSyncTree_'],_0x52e1e1);_0x45bec9=Jo(_0x20b4a0['serverSyncTree_'],_0x52e1e1['_path'],_0x176ce4,_0x230164);}return V(_0x20b4a0['eventQueue_'],_0x52e1e1['_path'],_0x45bec9),An(_0x20b4a0['serverSyncTree_'],_0x52e1e1,_0x53a374,null,!0x0),_0x176ce4;},_0x4b5880=>(gt(_0x20b4a0,'get\x20for\x20query\x20'+O(_0x52e1e1)+'\x20failed:\x20'+_0x4b5880),Promise['reject'](new Error(_0x4b5880))));}function Cd(_0x2e3383,_0x275917,_0x364098,_0x1ccf01,_0xc8fe5c){gt(_0x2e3383,'set',{'path':_0x275917['toString'](),'value':_0x364098,'priority':_0x1ccf01});const _0x32b19e=Xt(_0x2e3383),_0x32289d=A(_0x364098,_0x1ccf01),_0x51340b=Vn(_0x2e3383['serverSyncTree_'],_0x275917),_0x29a3bf=fs(_0x32289d,_0x51340b,_0x32b19e),_0xfdc3ff=zn(_0x2e3383),_0x23a2bf=as(_0x2e3383['serverSyncTree_'],_0x275917,_0x29a3bf,_0xfdc3ff,!0x0);qn(_0x2e3383['eventQueue_'],_0x23a2bf),_0x2e3383['server_']['put'](_0x275917['toString'](),_0x32289d['val'](!0x0),(_0x1433f7,_0x4ecde7)=>{const _0x2dfc87=_0x1433f7==='ok';_0x2dfc87||U('set\x20at\x20'+_0x275917+'\x20failed:\x20'+_0x1433f7);const _0x39a3f8=_e(_0x2e3383['serverSyncTree_'],_0xfdc3ff,!_0x2dfc87);V(_0x2e3383['eventQueue_'],_0x275917,_0x39a3f8),be(_0x2e3383,_0xc8fe5c,_0x1433f7,_0x4ecde7);});const _0x328fef=Is(_0x2e3383,_0x275917);ct(_0x2e3383,_0x328fef),V(_0x2e3383['eventQueue_'],_0x328fef,[]);}function Td(_0x219152,_0x14caa5,_0x30723e,_0x4ca493){gt(_0x219152,'update',{'path':_0x14caa5['toString'](),'value':_0x30723e});let _0x3d2e39=!0x0;const _0x26ba60=Xt(_0x219152),_0x5a60b8={};if(x(_0x30723e,(_0x3ec20c,_0x5835dd)=>{_0x3d2e39=!0x1,_0x5a60b8[_0x3ec20c]=ta(k(_0x14caa5,_0x3ec20c),A(_0x5835dd),_0x219152['serverSyncTree_'],_0x26ba60);}),_0x3d2e39)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x219152,_0x4ca493,'ok',void 0x0);else{const _0x2a735d=zn(_0x219152),_0x119c78=ju(_0x219152['serverSyncTree_'],_0x14caa5,_0x5a60b8,_0x2a735d);qn(_0x219152['eventQueue_'],_0x119c78),_0x219152['server_']['merge'](_0x14caa5['toString'](),_0x30723e,(_0x5d1d75,_0x1491ee)=>{const _0x442e66=_0x5d1d75==='ok';_0x442e66||U('update\x20at\x20'+_0x14caa5+'\x20failed:\x20'+_0x5d1d75);const _0x254e96=_e(_0x219152['serverSyncTree_'],_0x2a735d,!_0x442e66),_0x39d007=_0x254e96['length']>0x0?ct(_0x219152,_0x14caa5):_0x14caa5;V(_0x219152['eventQueue_'],_0x39d007,_0x254e96),be(_0x219152,_0x4ca493,_0x5d1d75,_0x1491ee);}),x(_0x30723e,_0x172d8f=>{const _0x3feb80=Is(_0x219152,k(_0x14caa5,_0x172d8f));ct(_0x219152,_0x3feb80);}),V(_0x219152['eventQueue_'],_0x14caa5,[]);}}function Sd(_0x1f50ba){gt(_0x1f50ba,'onDisconnectEvents');const _0x1a9583=Xt(_0x1f50ba),_0x1b441d=En();Si(_0x1f50ba['onDisconnect_'],w(),(_0x2849e4,_0xd74d8d)=>{const _0x37e2bb=ta(_0x2849e4,_0xd74d8d,_0x1f50ba['serverSyncTree_'],_0x1a9583);pt(_0x1b441d,_0x2849e4,_0x37e2bb);});let _0x5428bd=[];Si(_0x1b441d,w(),(_0x3e566c,_0x460f53)=>{_0x5428bd=_0x5428bd['concat'](Yt(_0x1f50ba['serverSyncTree_'],_0x3e566c,_0x460f53));const _0x53d74d=Is(_0x1f50ba,_0x3e566c);ct(_0x1f50ba,_0x53d74d);}),_0x1f50ba['onDisconnect_']=En(),V(_0x1f50ba['eventQueue_'],w(),_0x5428bd);}function bd(_0x4c8916,_0x47e4a3,_0x5442b1){_0x4c8916['server_']['onDisconnectCancel'](_0x47e4a3['toString'](),(_0x1ae4fa,_0x31be0f)=>{_0x1ae4fa==='ok'&&Ti(_0x4c8916['onDisconnect_'],_0x47e4a3),be(_0x4c8916,_0x5442b1,_0x1ae4fa,_0x31be0f);});}function yr(_0x59e8b0,_0x50deb8,_0x392ca5,_0x49c4fd){const _0x5431bc=A(_0x392ca5);_0x59e8b0['server_']['onDisconnectPut'](_0x50deb8['toString'](),_0x5431bc['val'](!0x0),(_0x28018b,_0x49498c)=>{_0x28018b==='ok'&&pt(_0x59e8b0['onDisconnect_'],_0x50deb8,_0x5431bc),be(_0x59e8b0,_0x49c4fd,_0x28018b,_0x49498c);});}function Rd(_0x14ffb2,_0x2191c3,_0x4a9915,_0x42dd4c,_0x22eef7){const _0x54404e=A(_0x4a9915,_0x42dd4c);_0x14ffb2['server_']['onDisconnectPut'](_0x2191c3['toString'](),_0x54404e['val'](!0x0),(_0x701d48,_0x19dddc)=>{_0x701d48==='ok'&&pt(_0x14ffb2['onDisconnect_'],_0x2191c3,_0x54404e),be(_0x14ffb2,_0x22eef7,_0x701d48,_0x19dddc);});}function Ad(_0x41d1d0,_0x4117a9,_0x33d33b,_0x5f2a74){if(pn(_0x33d33b)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x41d1d0,_0x5f2a74,'ok',void 0x0);return;}_0x41d1d0['server_']['onDisconnectMerge'](_0x4117a9['toString'](),_0x33d33b,(_0x4a37f0,_0x2c1235)=>{_0x4a37f0==='ok'&&x(_0x33d33b,(_0x5ac00b,_0x5e9db1)=>{const _0x40c149=A(_0x5e9db1);pt(_0x41d1d0['onDisconnect_'],k(_0x4117a9,_0x5ac00b),_0x40c149);}),be(_0x41d1d0,_0x5f2a74,_0x4a37f0,_0x2c1235);});}function kd(_0x477b90,_0x312d4b,_0x3a7267){let _0x1ef869;y(_0x312d4b['_path'])==='.info'?_0x1ef869=Ni(_0x477b90['infoSyncTree_'],_0x312d4b,_0x3a7267):_0x1ef869=Ni(_0x477b90['serverSyncTree_'],_0x312d4b,_0x3a7267),oa(_0x477b90['eventQueue_'],_0x312d4b['_path'],_0x1ef869);}function Pd(_0x1d8d40,_0x5d5f4f,_0x3a9833){let _0x38b73a;y(_0x5d5f4f['_path'])==='.info'?_0x38b73a=An(_0x1d8d40['infoSyncTree_'],_0x5d5f4f,_0x3a9833):_0x38b73a=An(_0x1d8d40['serverSyncTree_'],_0x5d5f4f,_0x3a9833),oa(_0x1d8d40['eventQueue_'],_0x5d5f4f['_path'],_0x38b73a);}function ha(_0x2ed036){_0x2ed036['persistentConnection_']&&_0x2ed036['persistentConnection_']['interrupt'](ca);}function Nd(_0x18de69){_0x18de69['persistentConnection_']&&_0x18de69['persistentConnection_']['resume'](ca);}function gt(_0x5e3111,..._0x335f0f){let _0x36503f='';_0x5e3111['persistentConnection_']&&(_0x36503f=_0x5e3111['persistentConnection_']['id']+':'),L(_0x36503f,..._0x335f0f);}function be(_0x420f2c,_0x497a34,_0x444063,_0x4d6ba7){_0x497a34&&ft(()=>{if(_0x444063==='ok')_0x497a34(null);else{const _0x1b2cbb=(_0x444063||'error')['toUpperCase']();let _0x1a2370=_0x1b2cbb;_0x4d6ba7&&(_0x1a2370+=':\x20'+_0x4d6ba7);const _0xfc3041=new Error(_0x1a2370);_0xfc3041['code']=_0x1b2cbb,_0x497a34(_0xfc3041);}});}function Od(_0x37285b,_0x51cd70,_0x48a2a3,_0x53d62e,_0x25b783,_0x1300a9){gt(_0x37285b,'transaction\x20on\x20'+_0x51cd70);const _0x19efa7={'path':_0x51cd70,'update':_0x48a2a3,'onComplete':_0x53d62e,'status':null,'order':so(),'applyLocally':_0x1300a9,'retryCount':0x0,'unwatcher':_0x25b783,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x128596=Es(_0x37285b,_0x51cd70,void 0x0);_0x19efa7['currentInputSnapshot']=_0x128596;const _0x5e8a08=_0x19efa7['update'](_0x128596['val']());if(_0x5e8a08===void 0x0)_0x19efa7['unwatcher'](),_0x19efa7['currentOutputSnapshotRaw']=null,_0x19efa7['currentOutputSnapshotResolved']=null,_0x19efa7['onComplete']&&_0x19efa7['onComplete'](null,!0x1,_0x19efa7['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x5e8a08,_0x19efa7['path']),_0x19efa7['status']=0x0;const _0x33e836=$n(_0x37285b['transactionQueueTree_'],_0x51cd70),_0x37521f=je(_0x33e836)||[];_0x37521f['push'](_0x19efa7),gs(_0x33e836,_0x37521f);let _0x58de4f;typeof _0x5e8a08=='object'&&_0x5e8a08!==null&&Q(_0x5e8a08,'.priority')?(_0x58de4f=Le(_0x5e8a08,'.priority'),f(Bt(_0x58de4f),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x58de4f=(Vn(_0x37285b['serverSyncTree_'],_0x51cd70)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x378216=Xt(_0x37285b),_0x1dba1d=A(_0x5e8a08,_0x58de4f),_0x3ecbe6=fs(_0x1dba1d,_0x128596,_0x378216);_0x19efa7['currentOutputSnapshotRaw']=_0x1dba1d,_0x19efa7['currentOutputSnapshotResolved']=_0x3ecbe6,_0x19efa7['currentWriteId']=zn(_0x37285b);const _0x12aa50=as(_0x37285b['serverSyncTree_'],_0x51cd70,_0x3ecbe6,_0x19efa7['currentWriteId'],_0x19efa7['applyLocally']);V(_0x37285b['eventQueue_'],_0x51cd70,_0x12aa50),jn(_0x37285b,_0x37285b['transactionQueueTree_']);}}function Es(_0x306e1c,_0x4996f4,_0x2c3e84){return Vn(_0x306e1c['serverSyncTree_'],_0x4996f4,_0x2c3e84)||g['EMPTY_NODE'];}function jn(_0x30be21,_0x2ad549=_0x30be21['transactionQueueTree_']){if(_0x2ad549||Kn(_0x30be21,_0x2ad549),je(_0x2ad549)){const _0x52231c=da(_0x30be21,_0x2ad549);f(_0x52231c['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x52231c['every'](_0x43affa=>_0x43affa['status']===0x0)&&Dd(_0x30be21,Qt(_0x2ad549),_0x52231c);}else na(_0x2ad549)&&Gn(_0x2ad549,_0x3eb32c=>{jn(_0x30be21,_0x3eb32c);});}function Dd(_0x146509,_0x15788f,_0x2358a5){const _0x5afb75=_0x2358a5['map'](_0x42fe32=>_0x42fe32['currentWriteId']),_0x372371=Es(_0x146509,_0x15788f,_0x5afb75);let _0x3321a7=_0x372371;const _0x190dea=_0x372371['hash']();for(let _0x1517a9=0x0;_0x1517a9<_0x2358a5['length'];_0x1517a9++){const _0x2f915c=_0x2358a5[_0x1517a9];f(_0x2f915c['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x2f915c['status']=0x1,_0x2f915c['retryCount']++;const _0x47db78=F(_0x15788f,_0x2f915c['path']);_0x3321a7=_0x3321a7['updateChild'](_0x47db78,_0x2f915c['currentOutputSnapshotRaw']);}const _0x310e85=_0x3321a7['val'](!0x0),_0xe41ee5=_0x15788f;_0x146509['server_']['put'](_0xe41ee5['toString'](),_0x310e85,_0x355b4a=>{gt(_0x146509,'transaction\x20put\x20response',{'path':_0xe41ee5['toString'](),'status':_0x355b4a});let _0x1d6c0a=[];if(_0x355b4a==='ok'){const _0x5eed64=[];for(let _0x208aec=0x0;_0x208aec<_0x2358a5['length'];_0x208aec++)_0x2358a5[_0x208aec]['status']=0x2,_0x1d6c0a=_0x1d6c0a['concat'](_e(_0x146509['serverSyncTree_'],_0x2358a5[_0x208aec]['currentWriteId'])),_0x2358a5[_0x208aec]['onComplete']&&_0x5eed64['push'](()=>_0x2358a5[_0x208aec]['onComplete'](null,!0x0,_0x2358a5[_0x208aec]['currentOutputSnapshotResolved'])),_0x2358a5[_0x208aec]['unwatcher']();Kn(_0x146509,$n(_0x146509['transactionQueueTree_'],_0x15788f)),jn(_0x146509,_0x146509['transactionQueueTree_']),V(_0x146509['eventQueue_'],_0x15788f,_0x1d6c0a);for(let _0x3f4eaa=0x0;_0x3f4eaa<_0x5eed64['length'];_0x3f4eaa++)ft(_0x5eed64[_0x3f4eaa]);}else{if(_0x355b4a==='datastale'){for(let _0x7cff3b=0x0;_0x7cff3b<_0x2358a5['length'];_0x7cff3b++)_0x2358a5[_0x7cff3b]['status']===0x3?_0x2358a5[_0x7cff3b]['status']=0x4:_0x2358a5[_0x7cff3b]['status']=0x0;}else{U('transaction\x20at\x20'+_0xe41ee5['toString']()+'\x20failed:\x20'+_0x355b4a);for(let _0x359c68=0x0;_0x359c68<_0x2358a5['length'];_0x359c68++)_0x2358a5[_0x359c68]['status']=0x4,_0x2358a5[_0x359c68]['abortReason']=_0x355b4a;}ct(_0x146509,_0x15788f);}},_0x190dea);}function ct(_0x324626,_0x47f820){const _0x2eb320=ua(_0x324626,_0x47f820),_0x1b5deb=Qt(_0x2eb320),_0x321ad9=da(_0x324626,_0x2eb320);return Md(_0x324626,_0x321ad9,_0x1b5deb),_0x1b5deb;}function Md(_0x13ea76,_0x84d643,_0x10eaaa){if(_0x84d643['length']===0x0)return;const _0x619473=[];let _0x310609=[];const _0x18f9be=_0x84d643['filter'](_0x58f924=>_0x58f924['status']===0x0)['map'](_0x4bf957=>_0x4bf957['currentWriteId']);for(let _0x147478=0x0;_0x147478<_0x84d643['length'];_0x147478++){const _0x312e58=_0x84d643[_0x147478],_0x22e95c=F(_0x10eaaa,_0x312e58['path']);let _0x4ed4f7=!0x1,_0x43b48e;if(f(_0x22e95c!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x312e58['status']===0x4)_0x4ed4f7=!0x0,_0x43b48e=_0x312e58['abortReason'],_0x310609=_0x310609['concat'](_e(_0x13ea76['serverSyncTree_'],_0x312e58['currentWriteId'],!0x0));else{if(_0x312e58['status']===0x0){if(_0x312e58['retryCount']>=yd)_0x4ed4f7=!0x0,_0x43b48e='maxretry',_0x310609=_0x310609['concat'](_e(_0x13ea76['serverSyncTree_'],_0x312e58['currentWriteId'],!0x0));else{const _0x593275=Es(_0x13ea76,_0x312e58['path'],_0x18f9be);_0x312e58['currentInputSnapshot']=_0x593275;const _0x451772=_0x84d643[_0x147478]['update'](_0x593275['val']());if(_0x451772!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x451772,_0x312e58['path']);let _0x3a3080=A(_0x451772);typeof _0x451772=='object'&&_0x451772!=null&&Q(_0x451772,'.priority')||(_0x3a3080=_0x3a3080['updatePriority'](_0x593275['getPriority']()));const _0x27e871=_0x312e58['currentWriteId'],_0x592347=Xt(_0x13ea76),_0x8f8f87=fs(_0x3a3080,_0x593275,_0x592347);_0x312e58['currentOutputSnapshotRaw']=_0x3a3080,_0x312e58['currentOutputSnapshotResolved']=_0x8f8f87,_0x312e58['currentWriteId']=zn(_0x13ea76),_0x18f9be['splice'](_0x18f9be['indexOf'](_0x27e871),0x1),_0x310609=_0x310609['concat'](as(_0x13ea76['serverSyncTree_'],_0x312e58['path'],_0x8f8f87,_0x312e58['currentWriteId'],_0x312e58['applyLocally'])),_0x310609=_0x310609['concat'](_e(_0x13ea76['serverSyncTree_'],_0x27e871,!0x0));}else _0x4ed4f7=!0x0,_0x43b48e='nodata',_0x310609=_0x310609['concat'](_e(_0x13ea76['serverSyncTree_'],_0x312e58['currentWriteId'],!0x0));}}}V(_0x13ea76['eventQueue_'],_0x10eaaa,_0x310609),_0x310609=[],_0x4ed4f7&&(_0x84d643[_0x147478]['status']=0x2,function(_0x1f6c5e){setTimeout(_0x1f6c5e,Math['floor'](0x0));}(_0x84d643[_0x147478]['unwatcher']),_0x84d643[_0x147478]['onComplete']&&(_0x43b48e==='nodata'?_0x619473['push'](()=>_0x84d643[_0x147478]['onComplete'](null,!0x1,_0x84d643[_0x147478]['currentInputSnapshot'])):_0x619473['push'](()=>_0x84d643[_0x147478]['onComplete'](new Error(_0x43b48e),!0x1,null))));}Kn(_0x13ea76,_0x13ea76['transactionQueueTree_']);for(let _0x5c1a7b=0x0;_0x5c1a7b<_0x619473['length'];_0x5c1a7b++)ft(_0x619473[_0x5c1a7b]);jn(_0x13ea76,_0x13ea76['transactionQueueTree_']);}function ua(_0x42e65b,_0x5a417d){let _0xc4a91c,_0x51e5d6=_0x42e65b['transactionQueueTree_'];for(_0xc4a91c=y(_0x5a417d);_0xc4a91c!==null&&je(_0x51e5d6)===void 0x0;)_0x51e5d6=$n(_0x51e5d6,_0xc4a91c),_0x5a417d=S(_0x5a417d),_0xc4a91c=y(_0x5a417d);return _0x51e5d6;}function da(_0x44444b,_0x1aa5f5){const _0x2edc8b=[];return fa(_0x44444b,_0x1aa5f5,_0x2edc8b),_0x2edc8b['sort']((_0x5c98cb,_0x59b0b9)=>_0x5c98cb['order']-_0x59b0b9['order']),_0x2edc8b;}function fa(_0x4e99c3,_0x839ab8,_0x1a7afa){const _0x34cc92=je(_0x839ab8);if(_0x34cc92){for(let _0x1d5248=0x0;_0x1d5248<_0x34cc92['length'];_0x1d5248++)_0x1a7afa['push'](_0x34cc92[_0x1d5248]);}Gn(_0x839ab8,_0x39ca88=>{fa(_0x4e99c3,_0x39ca88,_0x1a7afa);});}function Kn(_0x11227a,_0x7a3935){const _0x28d8f9=je(_0x7a3935);if(_0x28d8f9){let _0x429668=0x0;for(let _0x398b1e=0x0;_0x398b1e<_0x28d8f9['length'];_0x398b1e++)_0x28d8f9[_0x398b1e]['status']!==0x2&&(_0x28d8f9[_0x429668]=_0x28d8f9[_0x398b1e],_0x429668++);_0x28d8f9['length']=_0x429668,gs(_0x7a3935,_0x28d8f9['length']>0x0?_0x28d8f9:void 0x0);}Gn(_0x7a3935,_0x162d59=>{Kn(_0x11227a,_0x162d59);});}function Is(_0x442999,_0x64e54d){const _0x6df973=Qt(ua(_0x442999,_0x64e54d)),_0x2c7fd=$n(_0x442999['transactionQueueTree_'],_0x64e54d);return ad(_0x2c7fd,_0x33eb23=>{di(_0x442999,_0x33eb23);}),di(_0x442999,_0x2c7fd),ia(_0x2c7fd,_0x5ec4a0=>{di(_0x442999,_0x5ec4a0);}),_0x6df973;}function di(_0xb17489,_0x54a81e){const _0x48ad41=je(_0x54a81e);if(_0x48ad41){const _0x2c28f4=[];let _0xca0fd1=[],_0x350620=-0x1;for(let _0x3e9c40=0x0;_0x3e9c40<_0x48ad41['length'];_0x3e9c40++)_0x48ad41[_0x3e9c40]['status']===0x3||(_0x48ad41[_0x3e9c40]['status']===0x1?(f(_0x350620===_0x3e9c40-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x350620=_0x3e9c40,_0x48ad41[_0x3e9c40]['status']=0x3,_0x48ad41[_0x3e9c40]['abortReason']='set'):(f(_0x48ad41[_0x3e9c40]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x48ad41[_0x3e9c40]['unwatcher'](),_0xca0fd1=_0xca0fd1['concat'](_e(_0xb17489['serverSyncTree_'],_0x48ad41[_0x3e9c40]['currentWriteId'],!0x0)),_0x48ad41[_0x3e9c40]['onComplete']&&_0x2c28f4['push'](_0x48ad41[_0x3e9c40]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x350620===-0x1?gs(_0x54a81e,void 0x0):_0x48ad41['length']=_0x350620+0x1,V(_0xb17489['eventQueue_'],Qt(_0x54a81e),_0xca0fd1);for(let _0x93b261=0x0;_0x93b261<_0x2c28f4['length'];_0x93b261++)ft(_0x2c28f4[_0x93b261]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x7b4d53){let _0x3434e7='';const _0x108464=_0x7b4d53['split']('/');for(let _0x3bc273=0x0;_0x3bc273<_0x108464['length'];_0x3bc273++)if(_0x108464[_0x3bc273]['length']>0x0){let _0x22a9af=_0x108464[_0x3bc273];try{_0x22a9af=decodeURIComponent(_0x22a9af['replace'](/\+/g,'\x20'));}catch{}_0x3434e7+='/'+_0x22a9af;}return _0x3434e7;}function xd(_0x24abb1){const _0x215806={};_0x24abb1['charAt'](0x0)==='?'&&(_0x24abb1=_0x24abb1['substring'](0x1));for(const _0xb9acb3 of _0x24abb1['split']('&')){if(_0xb9acb3['length']===0x0)continue;const _0x5ee2dc=_0xb9acb3['split']('=');_0x5ee2dc['length']===0x2?_0x215806[decodeURIComponent(_0x5ee2dc[0x0])]=decodeURIComponent(_0x5ee2dc[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0xb9acb3+'\x27\x20in\x20query\x20\x27'+_0x24abb1+'\x27');}return _0x215806;}const vr=function(_0x1f9edc,_0x1a0e80){const _0x2622db=Fd(_0x1f9edc),_0x56e964=_0x2622db['namespace'];_0x2622db['domain']==='firebase.com'&&ae(_0x2622db['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x56e964||_0x56e964==='undefined')&&_0x2622db['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x2622db['secure']||$l();const _0xa1f47a=_0x2622db['scheme']==='ws'||_0x2622db['scheme']==='wss';return{'repoInfo':new yo(_0x2622db['host'],_0x2622db['secure'],_0x56e964,_0xa1f47a,_0x1a0e80,'',_0x56e964!==_0x2622db['subdomain']),'path':new C(_0x2622db['pathString'])};},Fd=function(_0x36fc0c){let _0x5ce69a='',_0x5d8047='',_0x5e044a='',_0x1cb078='',_0x30d594='',_0x16b0a4=!0x0,_0x2c1176='https',_0x55c2f1=0x1bb;if(typeof _0x36fc0c=='string'){let _0x38678f=_0x36fc0c['indexOf']('//');_0x38678f>=0x0&&(_0x2c1176=_0x36fc0c['substring'](0x0,_0x38678f-0x1),_0x36fc0c=_0x36fc0c['substring'](_0x38678f+0x2));let _0x153d19=_0x36fc0c['indexOf']('/');_0x153d19===-0x1&&(_0x153d19=_0x36fc0c['length']);let _0x1ef05b=_0x36fc0c['indexOf']('?');_0x1ef05b===-0x1&&(_0x1ef05b=_0x36fc0c['length']),_0x5ce69a=_0x36fc0c['substring'](0x0,Math['min'](_0x153d19,_0x1ef05b)),_0x153d19<_0x1ef05b&&(_0x1cb078=Ld(_0x36fc0c['substring'](_0x153d19,_0x1ef05b)));const _0x4c7244=xd(_0x36fc0c['substring'](Math['min'](_0x36fc0c['length'],_0x1ef05b)));_0x38678f=_0x5ce69a['indexOf'](':'),_0x38678f>=0x0?(_0x16b0a4=_0x2c1176==='https'||_0x2c1176==='wss',_0x55c2f1=parseInt(_0x5ce69a['substring'](_0x38678f+0x1),0xa)):_0x38678f=_0x5ce69a['length'];const _0x1978e8=_0x5ce69a['slice'](0x0,_0x38678f);if(_0x1978e8['toLowerCase']()==='localhost')_0x5d8047='localhost';else{if(_0x1978e8['split']('.')['length']<=0x2)_0x5d8047=_0x1978e8;else{const _0x266d9e=_0x5ce69a['indexOf']('.');_0x5e044a=_0x5ce69a['substring'](0x0,_0x266d9e)['toLowerCase'](),_0x5d8047=_0x5ce69a['substring'](_0x266d9e+0x1),_0x30d594=_0x5e044a;}}'ns'in _0x4c7244&&(_0x30d594=_0x4c7244['ns']);}return{'host':_0x5ce69a,'port':_0x55c2f1,'domain':_0x5d8047,'subdomain':_0x5e044a,'secure':_0x16b0a4,'scheme':_0x2c1176,'pathString':_0x1cb078,'namespace':_0x30d594};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x185d75=0x0;const _0x2c7e83=[];return function(_0x5aab77){const _0x19b6ca=_0x5aab77===_0x185d75;_0x185d75=_0x5aab77;let _0x411ad1;const _0x5a2a0e=new Array(0x8);for(_0x411ad1=0x7;_0x411ad1>=0x0;_0x411ad1--)_0x5a2a0e[_0x411ad1]=Er['charAt'](_0x5aab77%0x40),_0x5aab77=Math['floor'](_0x5aab77/0x40);f(_0x5aab77===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x5a4ecf=_0x5a2a0e['join']('');if(_0x19b6ca){for(_0x411ad1=0xb;_0x411ad1>=0x0&&_0x2c7e83[_0x411ad1]===0x3f;_0x411ad1--)_0x2c7e83[_0x411ad1]=0x0;_0x2c7e83[_0x411ad1]++;}else{for(_0x411ad1=0x0;_0x411ad1<0xc;_0x411ad1++)_0x2c7e83[_0x411ad1]=Math['floor'](Math['random']()*0x40);}for(_0x411ad1=0x0;_0x411ad1<0xc;_0x411ad1++)_0x5a4ecf+=Er['charAt'](_0x2c7e83[_0x411ad1]);return f(_0x5a4ecf['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x5a4ecf;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x43e723,_0x542bf4,_0x16fabb,_0x1c4eec){this['eventType']=_0x43e723,this['eventRegistration']=_0x542bf4,this['snapshot']=_0x16fabb,this['prevName']=_0x1c4eec;}['getPath'](){const _0x52edb9=this['snapshot']['ref'];return this['eventType']==='value'?_0x52edb9['_path']:_0x52edb9['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x5b90f4,_0x18ac9c,_0x9efda9){this['eventRegistration']=_0x5b90f4,this['error']=_0x18ac9c,this['path']=_0x9efda9;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x1969e5,_0x550cdf){this['snapshotCallback']=_0x1969e5,this['cancelCallback']=_0x550cdf;}['onValue'](_0x4c6d6c,_0x438764){this['snapshotCallback']['call'](null,_0x4c6d6c,_0x438764);}['onCancel'](_0x514946){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x514946);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x37f9cb){return this['snapshotCallback']===_0x37f9cb['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x37f9cb['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x37f9cb['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x5c5ed6,_0x1963f7){this['_repo']=_0x5c5ed6,this['_path']=_0x1963f7;}['cancel'](){const _0x10bfa8=new H();return bd(this['_repo'],this['_path'],_0x10bfa8['wrapCallback'](()=>{})),_0x10bfa8['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0x340a67=new H();return yr(this['_repo'],this['_path'],null,_0x340a67['wrapCallback'](()=>{})),_0x340a67['promise'];}['set'](_0x2cea87){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x2cea87,this['_path'],!0x1);const _0x11ffda=new H();return yr(this['_repo'],this['_path'],_0x2cea87,_0x11ffda['wrapCallback'](()=>{})),_0x11ffda['promise'];}['setWithPriority'](_0x5cefad,_0x265c03){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x5cefad,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x265c03);const _0xe1ea1a=new H();return Rd(this['_repo'],this['_path'],_0x5cefad,_0x265c03,_0xe1ea1a['wrapCallback'](()=>{})),_0xe1ea1a['promise'];}['update'](_0x28393e){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x28393e,this['_path']);const _0x3f261d=new H();return Ad(this['_repo'],this['_path'],_0x28393e,_0x3f261d['wrapCallback'](()=>{})),_0x3f261d['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x536f1b,_0x39e36d,_0xacf4d9,_0x1ec559){this['_repo']=_0x536f1b,this['_path']=_0x39e36d,this['_queryParams']=_0xacf4d9,this['_orderByCalled']=_0x1ec559;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x5d3242=sr(this['_queryParams']),_0x52cd48=$i(_0x5d3242);return _0x52cd48==='{}'?'default':_0x52cd48;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0x15f5a8){if(_0x15f5a8=P(_0x15f5a8),!(_0x15f5a8 instanceof Ae))return!0x1;const _0x568dc6=this['_repo']===_0x15f5a8['_repo'],_0x22aee4=Ki(this['_path'],_0x15f5a8['_path']),_0x131a9b=this['_queryIdentifier']===_0x15f5a8['_queryIdentifier'];return _0x568dc6&&_0x22aee4&&_0x131a9b;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x4f3e32,_0x1ad3ea){if(_0x4f3e32['_orderByCalled']===!0x0)throw new Error(_0x1ad3ea+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0xea6dc1){let _0x4ff3d5=null,_0x3bb8c5=null;if(_0xea6dc1['hasStart']()&&(_0x4ff3d5=_0xea6dc1['getIndexStartValue']()),_0xea6dc1['hasEnd']()&&(_0x3bb8c5=_0xea6dc1['getIndexEndValue']()),_0xea6dc1['getIndex']()===ve){const _0x3b59ad='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x4dcf28='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0xea6dc1['hasStart']()){if(_0xea6dc1['getIndexStartName']()!==We)throw new Error(_0x3b59ad);if(typeof _0x4ff3d5!='string')throw new Error(_0x4dcf28);}if(_0xea6dc1['hasEnd']()){if(_0xea6dc1['getIndexEndName']()!==we)throw new Error(_0x3b59ad);if(typeof _0x3bb8c5!='string')throw new Error(_0x4dcf28);}}else{if(_0xea6dc1['getIndex']()===R){if(_0x4ff3d5!=null&&!Bt(_0x4ff3d5)||_0x3bb8c5!=null&&!Bt(_0x3bb8c5))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0xea6dc1['getIndex']()instanceof Ji||_0xea6dc1['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x4ff3d5!=null&&typeof _0x4ff3d5=='object'||_0x3bb8c5!=null&&typeof _0x3bb8c5=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x3f0314){if(_0x3f0314['hasStart']()&&_0x3f0314['hasEnd']()&&_0x3f0314['hasLimit']()&&!_0x3f0314['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x36f6da,_0x4e5682){super(_0x36f6da,_0x4e5682,new Zi(),!0x1);}get['parent'](){const _0x35a96c=Ro(this['_path']);return _0x35a96c===null?null:new ee(this['_repo'],_0x35a96c);}get['root'](){let _0x432057=this;for(;_0x432057['parent']!==null;)_0x432057=_0x432057['parent'];return _0x432057;}}class lt{constructor(_0x2f5987,_0x430f7e,_0x40ac7a){this['_node']=_0x2f5987,this['ref']=_0x430f7e,this['_index']=_0x40ac7a;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x56ecc4){const _0x2690a2=new C(_0x56ecc4),_0x5b4145=Vt(this['ref'],_0x56ecc4);return new lt(this['_node']['getChild'](_0x2690a2),_0x5b4145,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x16d687){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x1efd14,_0x43bf07)=>_0x16d687(new lt(_0x43bf07,Vt(this['ref'],_0x1efd14),R)));}['hasChild'](_0x30041b){const _0x1109ab=new C(_0x30041b);return!this['_node']['getChild'](_0x1109ab)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x3f7275,_0x2885c8){return _0x3f7275=P(_0x3f7275),_0x3f7275['_checkNotDeleted']('ref'),_0x2885c8!==void 0x0?Vt(_0x3f7275['_root'],_0x2885c8):_0x3f7275['_root'];}function Vt(_0x47ee9c,_0x1704e3){return _0x47ee9c=P(_0x47ee9c),y(_0x47ee9c['_path'])===null?pd('child','path',_0x1704e3):ys('child','path',_0x1704e3),new ee(_0x47ee9c['_repo'],k(_0x47ee9c['_path'],_0x1704e3));}function v_(_0x308560){return _0x308560=P(_0x308560),new Vd(_0x308560['_repo'],_0x308560['_path']);}function E_(_0x2c80ac,_0x6ae243){_0x2c80ac=P(_0x2c80ac),Me('push',_0x2c80ac['_path']),He('push',_0x6ae243,_0x2c80ac['_path'],!0x0);const _0x3c8daa=la(_0x2c80ac['_repo']),_0xa6c871=Ud(_0x3c8daa),_0x535f78=Vt(_0x2c80ac,_0xa6c871),_0x3f55eb=Vt(_0x2c80ac,_0xa6c871);let _0x144c1a;return _0x6ae243!=null?_0x144c1a=Hd(_0x3f55eb,_0x6ae243)['then'](()=>_0x3f55eb):_0x144c1a=Promise['resolve'](_0x3f55eb),_0x535f78['then']=_0x144c1a['then']['bind'](_0x144c1a),_0x535f78['catch']=_0x144c1a['then']['bind'](_0x144c1a,void 0x0),_0x535f78;}function Hd(_0x3edee2,_0x21b89f){_0x3edee2=P(_0x3edee2),Me('set',_0x3edee2['_path']),He('set',_0x21b89f,_0x3edee2['_path'],!0x1);const _0x47cede=new H();return Cd(_0x3edee2['_repo'],_0x3edee2['_path'],_0x21b89f,null,_0x47cede['wrapCallback'](()=>{})),_0x47cede['promise'];}function I_(_0x67fd91,_0x4ca578){ra('update',_0x4ca578,_0x67fd91['_path']);const _0x1c3946=new H();return Td(_0x67fd91['_repo'],_0x67fd91['_path'],_0x4ca578,_0x1c3946['wrapCallback'](()=>{})),_0x1c3946['promise'];}function w_(_0x40741f){_0x40741f=P(_0x40741f);const _0x2baff3=new pa(()=>{}),_0x6d3e70=new Qn(_0x2baff3);return wd(_0x40741f['_repo'],_0x40741f,_0x6d3e70)['then'](_0x17df58=>new lt(_0x17df58,new ee(_0x40741f['_repo'],_0x40741f['_path']),_0x40741f['_queryParams']['getIndex']()));}class Qn{constructor(_0x521888){this['callbackContext']=_0x521888;}['respondsTo'](_0x28bf05){return _0x28bf05==='value';}['createEvent'](_0x44a281,_0x49a4b0){const _0x33803c=_0x49a4b0['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x44a281['snapshotNode'],new ee(_0x49a4b0['_repo'],_0x49a4b0['_path']),_0x33803c));}['getEventRunner'](_0x1b2a04){return _0x1b2a04['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x1b2a04['error']):()=>this['callbackContext']['onValue'](_0x1b2a04['snapshot'],null);}['createCancelEvent'](_0x300d62,_0x486a57){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x300d62,_0x486a57):null;}['matches'](_0x218b73){return _0x218b73 instanceof Qn?!_0x218b73['callbackContext']||!this['callbackContext']?!0x0:_0x218b73['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x19bbda,_0x13b22d,_0x16b905,_0x1264f1,_0x37b9cc){const _0x4a80b4=new pa(_0x16b905,void 0x0),_0x43ff82=new Qn(_0x4a80b4);return kd(_0x19bbda['_repo'],_0x19bbda,_0x43ff82),()=>Pd(_0x19bbda['_repo'],_0x19bbda,_0x43ff82);}function Gd(_0x3514db,_0x50da36,_0x36a104,_0x54dc51){return $d(_0x3514db,'value',_0x50da36);}class mt{}class ma extends mt{constructor(_0xd6ae62,_0x5cf196){super(),this['_value']=_0xd6ae62,this['_key']=_0x5cf196,this['type']='endAt';}['_apply'](_0x39b478){He('endAt',this['_value'],_0x39b478['_path'],!0x0);const _0x1eccaa=Jh(_0x39b478['_queryParams'],this['_value'],this['_key']);if(ga(_0x1eccaa),Yn(_0x1eccaa),_0x39b478['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0x39b478['_repo'],_0x39b478['_path'],_0x1eccaa,_0x39b478['_orderByCalled']);}}function C_(_0x26cb39,_0x227405){return new ma(_0x26cb39,_0x227405);}class ya extends mt{constructor(_0x26c290,_0x5f0299){super(),this['_value']=_0x26c290,this['_key']=_0x5f0299,this['type']='startAt';}['_apply'](_0x40ddae){He('startAt',this['_value'],_0x40ddae['_path'],!0x0);const _0x218c5d=Qh(_0x40ddae['_queryParams'],this['_value'],this['_key']);if(ga(_0x218c5d),Yn(_0x218c5d),_0x40ddae['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x40ddae['_repo'],_0x40ddae['_path'],_0x218c5d,_0x40ddae['_orderByCalled']);}}function T_(_0x164b2d=null,_0xd83701){return new ya(_0x164b2d,_0xd83701);}class qd extends mt{constructor(_0x52d7d5){super(),this['_limit']=_0x52d7d5,this['type']='limitToFirst';}['_apply'](_0x3b47ca){if(_0x3b47ca['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x3b47ca['_repo'],_0x3b47ca['_path'],Yh(_0x3b47ca['_queryParams'],this['_limit']),_0x3b47ca['_orderByCalled']);}}function S_(_0x287d76){if(Math['floor'](_0x287d76)!==_0x287d76||_0x287d76<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x287d76);}class zd extends mt{constructor(_0x30864d){super(),this['_path']=_0x30864d,this['type']='orderByChild';}['_apply'](_0x456c74){_a(_0x456c74,'orderByChild');const _0x40116e=new C(this['_path']);if(v(_0x40116e))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x445703=new Ji(_0x40116e),_0x480041=xo(_0x456c74['_queryParams'],_0x445703);return Yn(_0x480041),new Ae(_0x456c74['_repo'],_0x456c74['_path'],_0x480041,!0x0);}}function b_(_0x2de7c4){if(_0x2de7c4==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x2de7c4==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x2de7c4==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x2de7c4),new zd(_0x2de7c4);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x20817e){_a(_0x20817e,'orderByKey');const _0x163a6e=xo(_0x20817e['_queryParams'],ve);return Yn(_0x163a6e),new Ae(_0x20817e['_repo'],_0x20817e['_path'],_0x163a6e,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x3fe1fc,_0x38d5be){super(),this['_value']=_0x3fe1fc,this['_key']=_0x38d5be,this['type']='equalTo';}['_apply'](_0x1a2a9b){if(He('equalTo',this['_value'],_0x1a2a9b['_path'],!0x1),_0x1a2a9b['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x1a2a9b['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x1a2a9b));}}function A_(_0x274878,_0x510de0){return new Kd(_0x274878,_0x510de0);}function k_(_0x35c62f,..._0x11d359){let _0x412f50=P(_0x35c62f);for(const _0x37342f of _0x11d359)_0x412f50=_0x37342f['_apply'](_0x412f50);return _0x412f50;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x222d2e,_0x3f9c78,_0x4a2654,_0x5a8197){const _0x56784b=_0x3f9c78['lastIndexOf'](':'),_0x124ff4=_0x3f9c78['substring'](0x0,_0x56784b),_0x254cbe=qt(_0x124ff4);_0x222d2e['repoInfo_']=new yo(_0x3f9c78,_0x254cbe,_0x222d2e['repoInfo_']['namespace'],_0x222d2e['repoInfo_']['webSocketOnly'],_0x222d2e['repoInfo_']['nodeAdmin'],_0x222d2e['repoInfo_']['persistenceKey'],_0x222d2e['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x4a2654),_0x5a8197&&(_0x222d2e['authTokenProvider_']=_0x5a8197);}function Xd(_0x43eab6,_0x2e1ff9,_0x524787,_0x413b4f,_0xfc0589){let _0xc2235f=_0x413b4f||_0x43eab6['options']['databaseURL'];_0xc2235f===void 0x0&&(_0x43eab6['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x43eab6['options']['projectId']),_0xc2235f=_0x43eab6['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x36d395=vr(_0xc2235f,_0xfc0589),_0x59e014=_0x36d395['repoInfo'],_0x3bc7fe;typeof process<'u'&&Bs&&(_0x3bc7fe=Bs[Yd]),_0x3bc7fe?(_0xc2235f='http://'+_0x3bc7fe+'?ns='+_0x59e014['namespace'],_0x36d395=vr(_0xc2235f,_0xfc0589),_0x59e014=_0x36d395['repoInfo']):_0x36d395['repoInfo']['secure'];const _0x468043=new eh(_0x43eab6['name'],_0x43eab6['options'],_0x2e1ff9);_d('Invalid\x20Firebase\x20Database\x20URL',_0x36d395),v(_0x36d395['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x4d34aa=ef(_0x59e014,_0x43eab6,_0x468043,new Zl(_0x43eab6,_0x524787));return new tf(_0x4d34aa,_0x43eab6);}function Zd(_0x2b287c,_0x2ed269){const _0x57037e=Di[_0x2ed269];(!_0x57037e||_0x57037e[_0x2b287c['key']]!==_0x2b287c)&&ae('Database\x20'+_0x2ed269+'('+_0x2b287c['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x2b287c),delete _0x57037e[_0x2b287c['key']];}function ef(_0x1a917a,_0x18a2f2,_0x75a683,_0x1f6e5d){let _0x5259fe=Di[_0x18a2f2['name']];_0x5259fe||(_0x5259fe={},Di[_0x18a2f2['name']]=_0x5259fe);let _0x72d54d=_0x5259fe[_0x1a917a['toURLString']()];return _0x72d54d&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x72d54d=new vd(_0x1a917a,Qd,_0x75a683,_0x1f6e5d),_0x5259fe[_0x1a917a['toURLString']()]=_0x72d54d,_0x72d54d;}class tf{constructor(_0x2f8f50,_0x480c8a){this['_repoInternal']=_0x2f8f50,this['app']=_0x480c8a,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x300ad9){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x300ad9+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x175243=Zr(),_0x3c0936){const _0x214371=Hi(_0x175243,'database')['getImmediate']({'identifier':_0x3c0936});if(!_0x214371['_instanceStarted']){const _0x4c0507=hc('database');_0x4c0507&&nf(_0x214371,..._0x4c0507);}return _0x214371;}function nf(_0x5c18f6,_0x4ae637,_0x4ea322,_0x1ad324={}){_0x5c18f6=P(_0x5c18f6),_0x5c18f6['_checkNotDeleted']('useEmulator');const _0x1f4956=_0x4ae637+':'+_0x4ea322,_0x5daffc=_0x5c18f6['_repoInternal'];if(_0x5c18f6['_instanceStarted']){if(_0x1f4956===_0x5c18f6['_repoInternal']['repoInfo_']['host']&&xe(_0x1ad324,_0x5daffc['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x3d3a9a;if(_0x5daffc['repoInfo_']['nodeAdmin'])_0x1ad324['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x3d3a9a=new an(an['OWNER']);else{if(_0x1ad324['mockUserToken']){const _0x8e7a94=typeof _0x1ad324['mockUserToken']=='string'?_0x1ad324['mockUserToken']:uc(_0x1ad324['mockUserToken'],_0x5c18f6['app']['options']['projectId']);_0x3d3a9a=new an(_0x8e7a94);}}qt(_0x4ae637)&&Qr(_0x4ae637),Jd(_0x5daffc,_0x1f4956,_0x1ad324,_0x3d3a9a);}function N_(_0x5e1b47){_0x5e1b47=P(_0x5e1b47),_0x5e1b47['_checkNotDeleted']('goOffline'),ha(_0x5e1b47['_repo']);}function O_(_0xa8a2ea){_0xa8a2ea=P(_0xa8a2ea),_0xa8a2ea['_checkNotDeleted']('goOnline'),Nd(_0xa8a2ea['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x2c02cd){Ul(dt),st(new Fe('database',(_0x5efd50,{instanceIdentifier:_0x1080f6})=>{const _0x23bbbb=_0x5efd50['getProvider']('app')['getImmediate'](),_0x4d1e1b=_0x5efd50['getProvider']('auth-internal'),_0x4f22df=_0x5efd50['getProvider']('app-check-internal');return Xd(_0x23bbbb,_0x4d1e1b,_0x4f22df,_0x1080f6);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x2c02cd),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x570596,_0x2d2a77){this['committed']=_0x570596,this['snapshot']=_0x2d2a77;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x5389cd,_0x26a735,_0x2ecfe3){if(_0x5389cd=P(_0x5389cd),Me('Reference.transaction',_0x5389cd['_path']),_0x5389cd['key']==='.length'||_0x5389cd['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x5389cd['key']+'\x20is\x20a\x20read-only\x20object.';const _0xfdfa2e=!0x0,_0x3d39fe=new H(),_0x22dfe9=(_0x5b9b8b,_0x2861e8,_0x404791)=>{let _0x288176=null;_0x5b9b8b?_0x3d39fe['reject'](_0x5b9b8b):(_0x288176=new lt(_0x404791,new ee(_0x5389cd['_repo'],_0x5389cd['_path']),R),_0x3d39fe['resolve'](new of(_0x2861e8,_0x288176)));},_0x2a98fb=Gd(_0x5389cd,()=>{});return Od(_0x5389cd['_repo'],_0x5389cd['_path'],_0x26a735,_0x22dfe9,_0x2a98fb,_0xfdfa2e),_0x3d39fe['promise'];}se['prototype']['simpleListen']=function(_0xa3f59d,_0x3e8403){this['sendRequest']('q',{'p':_0xa3f59d},_0x3e8403);},se['prototype']['echo']=function(_0xbb23f1,_0x4b0c9c){this['sendRequest']('echo',{'d':_0xbb23f1},_0x4b0c9c);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x155915,..._0x41d05e){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x155915,..._0x41d05e);}function cn(_0x5ea8e8,..._0x590ecf){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x5ea8e8,..._0x590ecf);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x1fe693,..._0x3c9ae2){throw ws(_0x1fe693,..._0x3c9ae2);}function X(_0x4bbc2e,..._0x399fa7){return ws(_0x4bbc2e,..._0x399fa7);}function Ia(_0x3b6212,_0x2d06a1,_0x40d1e0){const _0xe545cd={...af(),[_0x2d06a1]:_0x40d1e0};return new Gt('auth','Firebase',_0xe545cd)['create'](_0x2d06a1,{'appName':_0x3b6212['name']});}function re(_0x292e94){return Ia(_0x292e94,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x4f92e2,..._0x3fb8db){if(typeof _0x4f92e2!='string'){const _0xabc2c4=_0x3fb8db[0x0],_0x295ab6=[..._0x3fb8db['slice'](0x1)];return _0x295ab6[0x0]&&(_0x295ab6[0x0]['appName']=_0x4f92e2['name']),_0x4f92e2['_errorFactory']['create'](_0xabc2c4,..._0x295ab6);}return Ea['create'](_0x4f92e2,..._0x3fb8db);}function m(_0x5eeb05,_0x324990,..._0x266035){if(!_0x5eeb05)throw ws(_0x324990,..._0x266035);}function ne(_0xaf4e95){const _0x4f43f3='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0xaf4e95;throw cn(_0x4f43f3),new Error(_0x4f43f3);}function ce(_0x1e94e3,_0x4388b5){_0x1e94e3||ne(_0x4388b5);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x155b84;return typeof self<'u'&&((_0x155b84=self['location'])==null?void 0x0:_0x155b84['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x36df5c;return typeof self<'u'&&((_0x36df5c=self['location'])==null?void 0x0:_0x36df5c['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x2670fd=navigator;return _0x2670fd['languages']&&_0x2670fd['languages'][0x0]||_0x2670fd['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x8c4def,_0x439337){this['shortDelay']=_0x8c4def,this['longDelay']=_0x439337,ce(_0x439337>_0x8c4def,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x20219f,_0x56be77){ce(_0x20219f['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x321931}=_0x20219f['emulator'];return _0x56be77?''+_0x321931+(_0x56be77['startsWith']('/')?_0x56be77['slice'](0x1):_0x56be77):_0x321931;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x206ac7,_0x4342ef,_0x3b825c){this['fetchImpl']=_0x206ac7,_0x4342ef&&(this['headersImpl']=_0x4342ef),_0x3b825c&&(this['responseImpl']=_0x3b825c);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x1e061c,_0x543535){return _0x1e061c['tenantId']&&!_0x543535['tenantId']?{..._0x543535,'tenantId':_0x1e061c['tenantId']}:_0x543535;}async function Pe(_0x39db51,_0x309559,_0x37f961,_0x1d327c,_0x3f653d={}){return Ca(_0x39db51,_0x3f653d,async()=>{let _0x20ae71={},_0x546d86={};_0x1d327c&&(_0x309559==='GET'?_0x546d86=_0x1d327c:_0x20ae71={'body':JSON['stringify'](_0x1d327c)});const _0x40f254=ut({..._0x546d86,'key':_0x39db51['config']['apiKey']})['slice'](0x1),_0xb9f9f0=await _0x39db51['_getAdditionalHeaders']();_0xb9f9f0['Content-Type']='application/json',_0x39db51['languageCode']&&(_0xb9f9f0['X-Firebase-Locale']=_0x39db51['languageCode']);const _0x175b96={'method':_0x309559,'headers':_0xb9f9f0,..._0x20ae71};return dc()||(_0x175b96['referrerPolicy']='strict-origin-when-cross-origin'),_0x39db51['emulatorConfig']&&qt(_0x39db51['emulatorConfig']['host'])&&(_0x175b96['credentials']='include'),wa['fetch']()(await Ta(_0x39db51,_0x39db51['config']['apiHost'],_0x37f961,_0x40f254),_0x175b96);});}async function Ca(_0x336429,_0x480ac6,_0x5195f4){_0x336429['_canInitEmulator']=!0x1;const _0x26f497={...df,..._0x480ac6};try{const _0x20855b=new gf(_0x336429),_0x23f019=await Promise['race']([_0x5195f4(),_0x20855b['promise']]);_0x20855b['clearNetworkTimeout']();const _0x1a93e3=await _0x23f019['json']();if('needConfirmation'in _0x1a93e3)throw on(_0x336429,'account-exists-with-different-credential',_0x1a93e3);if(_0x23f019['ok']&&!('errorMessage'in _0x1a93e3))return _0x1a93e3;{const _0x17a68f=_0x23f019['ok']?_0x1a93e3['errorMessage']:_0x1a93e3['error']['message'],[_0x538824,_0x1c698f]=_0x17a68f['split']('\x20:\x20');if(_0x538824==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x336429,'credential-already-in-use',_0x1a93e3);if(_0x538824==='EMAIL_EXISTS')throw on(_0x336429,'email-already-in-use',_0x1a93e3);if(_0x538824==='USER_DISABLED')throw on(_0x336429,'user-disabled',_0x1a93e3);const _0x567e6a=_0x26f497[_0x538824]||_0x538824['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x1c698f)throw Ia(_0x336429,_0x567e6a,_0x1c698f);Y(_0x336429,_0x567e6a);}}catch(_0x100068){if(_0x100068 instanceof Re)throw _0x100068;Y(_0x336429,'network-request-failed',{'message':String(_0x100068)});}}async function en(_0x23b3d4,_0x1de46d,_0x10232c,_0x3af6f7,_0x41a3a7={}){const _0x555b36=await Pe(_0x23b3d4,_0x1de46d,_0x10232c,_0x3af6f7,_0x41a3a7);return'mfaPendingCredential'in _0x555b36&&Y(_0x23b3d4,'multi-factor-auth-required',{'_serverResponse':_0x555b36}),_0x555b36;}async function Ta(_0x227395,_0x153c71,_0x1174cf,_0x44dc28){const _0x42562b=''+_0x153c71+_0x1174cf+'?'+_0x44dc28,_0x5e5a3c=_0x227395,_0xf2545c=_0x5e5a3c['config']['emulator']?Cs(_0x227395['config'],_0x42562b):_0x227395['config']['apiScheme']+'://'+_0x42562b;return ff['includes'](_0x1174cf)&&(await _0x5e5a3c['_persistenceManagerAvailable'],_0x5e5a3c['_getPersistenceType']()==='COOKIE')?_0x5e5a3c['_getPersistence']()['_getFinalTarget'](_0xf2545c)['toString']():_0xf2545c;}function _f(_0x4d2ca0){switch(_0x4d2ca0){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x4fc186){this['auth']=_0x4fc186,this['timer']=null,this['promise']=new Promise((_0x1658f9,_0xf22859)=>{this['timer']=setTimeout(()=>_0xf22859(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x4c22f1,_0x150288,_0x185d91){const _0x1dd2dc={'appName':_0x4c22f1['name']};_0x185d91['email']&&(_0x1dd2dc['email']=_0x185d91['email']),_0x185d91['phoneNumber']&&(_0x1dd2dc['phoneNumber']=_0x185d91['phoneNumber']);const _0x580231=X(_0x4c22f1,_0x150288,_0x1dd2dc);return _0x580231['customData']['_tokenResponse']=_0x185d91,_0x580231;}function wr(_0x20d023){return _0x20d023!==void 0x0&&_0x20d023['enterprise']!==void 0x0;}class mf{constructor(_0x3725a1){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x3725a1['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x3725a1['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x3725a1['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x4aacfa){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x11d4ea of this['recaptchaEnforcementState'])if(_0x11d4ea['provider']&&_0x11d4ea['provider']===_0x4aacfa)return _f(_0x11d4ea['enforcementState']);return null;}['isProviderEnabled'](_0x5b472f){return this['getProviderEnforcementState'](_0x5b472f)==='ENFORCE'||this['getProviderEnforcementState'](_0x5b472f)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x2a6756,_0x864dfb){return Pe(_0x2a6756,'GET','/v2/recaptchaConfig',ke(_0x2a6756,_0x864dfb));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x5b69af,_0x3dcd7a){return Pe(_0x5b69af,'POST','/v1/accounts:delete',_0x3dcd7a);}async function Pn(_0x2ba620,_0x327a8e){return Pe(_0x2ba620,'POST','/v1/accounts:lookup',_0x327a8e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x1973f9){if(_0x1973f9)try{const _0x2f87f9=new Date(Number(_0x1973f9));if(!isNaN(_0x2f87f9['getTime']()))return _0x2f87f9['toUTCString']();}catch{}}async function Ef(_0x1aed7b,_0x2ea793=!0x1){const _0x46bb5a=P(_0x1aed7b),_0x4b4506=await _0x46bb5a['getIdToken'](_0x2ea793),_0x189f8d=Ts(_0x4b4506);m(_0x189f8d&&_0x189f8d['exp']&&_0x189f8d['auth_time']&&_0x189f8d['iat'],_0x46bb5a['auth'],'internal-error');const _0x36dc37=typeof _0x189f8d['firebase']=='object'?_0x189f8d['firebase']:void 0x0,_0x1f6723=_0x36dc37==null?void 0x0:_0x36dc37['sign_in_provider'];return{'claims':_0x189f8d,'token':_0x4b4506,'authTime':Pt(fi(_0x189f8d['auth_time'])),'issuedAtTime':Pt(fi(_0x189f8d['iat'])),'expirationTime':Pt(fi(_0x189f8d['exp'])),'signInProvider':_0x1f6723||null,'signInSecondFactor':(_0x36dc37==null?void 0x0:_0x36dc37['sign_in_second_factor'])||null};}function fi(_0x52f064){return Number(_0x52f064)*0x3e8;}function Ts(_0x529055){const [_0x4b3a93,_0x35d16d,_0x1fa49c]=_0x529055['split']('.');if(_0x4b3a93===void 0x0||_0x35d16d===void 0x0||_0x1fa49c===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x47252c=fn(_0x35d16d);return _0x47252c?JSON['parse'](_0x47252c):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x567d2c){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x567d2c==null?void 0x0:_0x567d2c['toString']()),null;}}function Cr(_0xa66249){const _0x203080=Ts(_0xa66249);return m(_0x203080,'internal-error'),m(typeof _0x203080['exp']<'u','internal-error'),m(typeof _0x203080['iat']<'u','internal-error'),Number(_0x203080['exp'])-Number(_0x203080['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x45bd04,_0x18ed6d,_0x471a2d=!0x1){if(_0x471a2d)return _0x18ed6d;try{return await _0x18ed6d;}catch(_0x3655be){throw _0x3655be instanceof Re&&If(_0x3655be)&&_0x45bd04['auth']['currentUser']===_0x45bd04&&await _0x45bd04['auth']['signOut'](),_0x3655be;}}function If({code:_0x270ef3}){return _0x270ef3==='auth/user-disabled'||_0x270ef3==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0x14b7bb){this['user']=_0x14b7bb,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x8431b1){if(_0x8431b1){const _0xda2b7c=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0xda2b7c;}else{this['errorBackoff']=0x7530;const _0x219c32=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x219c32);}}['schedule'](_0x507153=!0x1){if(!this['isRunning'])return;const _0x1edba2=this['getInterval'](_0x507153);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x1edba2);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x6fc8f2){(_0x6fc8f2==null?void 0x0:_0x6fc8f2['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x16643d,_0x4c9526){this['createdAt']=_0x16643d,this['lastLoginAt']=_0x4c9526,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x7718fc){this['createdAt']=_0x7718fc['createdAt'],this['lastLoginAt']=_0x7718fc['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x7a4533){var _0x1a1901;const _0x49216d=_0x7a4533['auth'],_0x37fe17=await _0x7a4533['getIdToken'](),_0x3a8c41=await Ht(_0x7a4533,Pn(_0x49216d,{'idToken':_0x37fe17}));m(_0x3a8c41==null?void 0x0:_0x3a8c41['users']['length'],_0x49216d,'internal-error');const _0x136455=_0x3a8c41['users'][0x0];_0x7a4533['_notifyReloadListener'](_0x136455);const _0x255e2b=(_0x1a1901=_0x136455['providerUserInfo'])!=null&&_0x1a1901['length']?Sa(_0x136455['providerUserInfo']):[],_0x2728f3=Tf(_0x7a4533['providerData'],_0x255e2b),_0x23dc41=_0x7a4533['isAnonymous'],_0x460c22=!(_0x7a4533['email']&&_0x136455['passwordHash'])&&!(_0x2728f3!=null&&_0x2728f3['length']),_0x18aadf=_0x23dc41?_0x460c22:!0x1,_0x5e99ec={'uid':_0x136455['localId'],'displayName':_0x136455['displayName']||null,'photoURL':_0x136455['photoUrl']||null,'email':_0x136455['email']||null,'emailVerified':_0x136455['emailVerified']||!0x1,'phoneNumber':_0x136455['phoneNumber']||null,'tenantId':_0x136455['tenantId']||null,'providerData':_0x2728f3,'metadata':new Li(_0x136455['createdAt'],_0x136455['lastLoginAt']),'isAnonymous':_0x18aadf};Object['assign'](_0x7a4533,_0x5e99ec);}async function Cf(_0x1c02ca){const _0x446345=P(_0x1c02ca);await Nn(_0x446345),await _0x446345['auth']['_persistUserIfCurrent'](_0x446345),_0x446345['auth']['_notifyListenersIfCurrent'](_0x446345);}function Tf(_0x498b5e,_0x33f19d){return[..._0x498b5e['filter'](_0x23f96c=>!_0x33f19d['some'](_0x3e7fbc=>_0x3e7fbc['providerId']===_0x23f96c['providerId'])),..._0x33f19d];}function Sa(_0x367693){return _0x367693['map'](({providerId:_0xcd3751,..._0x586013})=>({'providerId':_0xcd3751,'uid':_0x586013['rawId']||'','displayName':_0x586013['displayName']||null,'email':_0x586013['email']||null,'phoneNumber':_0x586013['phoneNumber']||null,'photoURL':_0x586013['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x3eaeb8,_0x57eaca){const _0x4512d8=await Ca(_0x3eaeb8,{},async()=>{const _0x2c2a55=ut({'grant_type':'refresh_token','refresh_token':_0x57eaca})['slice'](0x1),{tokenApiHost:_0x334b13,apiKey:_0x424c76}=_0x3eaeb8['config'],_0x24ef9e=await Ta(_0x3eaeb8,_0x334b13,'/v1/token','key='+_0x424c76),_0x389dde=await _0x3eaeb8['_getAdditionalHeaders']();_0x389dde['Content-Type']='application/x-www-form-urlencoded';const _0xb82eea={'method':'POST','headers':_0x389dde,'body':_0x2c2a55};return _0x3eaeb8['emulatorConfig']&&qt(_0x3eaeb8['emulatorConfig']['host'])&&(_0xb82eea['credentials']='include'),wa['fetch']()(_0x24ef9e,_0xb82eea);});return{'accessToken':_0x4512d8['access_token'],'expiresIn':_0x4512d8['expires_in'],'refreshToken':_0x4512d8['refresh_token']};}async function bf(_0x5a4841,_0x561acf){return Pe(_0x5a4841,'POST','/v2/accounts:revokeToken',ke(_0x5a4841,_0x561acf));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x83aeba){m(_0x83aeba['idToken'],'internal-error'),m(typeof _0x83aeba['idToken']<'u','internal-error'),m(typeof _0x83aeba['refreshToken']<'u','internal-error');const _0x21d5d6='expiresIn'in _0x83aeba&&typeof _0x83aeba['expiresIn']<'u'?Number(_0x83aeba['expiresIn']):Cr(_0x83aeba['idToken']);this['updateTokensAndExpiration'](_0x83aeba['idToken'],_0x83aeba['refreshToken'],_0x21d5d6);}['updateFromIdToken'](_0x33fe4a){m(_0x33fe4a['length']!==0x0,'internal-error');const _0x35d240=Cr(_0x33fe4a);this['updateTokensAndExpiration'](_0x33fe4a,null,_0x35d240);}async['getToken'](_0x1fc674,_0x3b1c03=!0x1){return!_0x3b1c03&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x1fc674,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x1fc674,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x1fb751,_0x59f77c){const {accessToken:_0x19f9ac,refreshToken:_0x125683,expiresIn:_0x1cd824}=await Sf(_0x1fb751,_0x59f77c);this['updateTokensAndExpiration'](_0x19f9ac,_0x125683,Number(_0x1cd824));}['updateTokensAndExpiration'](_0x214d08,_0x183931,_0x2280e8){this['refreshToken']=_0x183931||null,this['accessToken']=_0x214d08||null,this['expirationTime']=Date['now']()+_0x2280e8*0x3e8;}static['fromJSON'](_0x3ffbb2,_0x945f61){const {refreshToken:_0x5747bd,accessToken:_0x221d46,expirationTime:_0x22ffac}=_0x945f61,_0x18a4d7=new et();return _0x5747bd&&(m(typeof _0x5747bd=='string','internal-error',{'appName':_0x3ffbb2}),_0x18a4d7['refreshToken']=_0x5747bd),_0x221d46&&(m(typeof _0x221d46=='string','internal-error',{'appName':_0x3ffbb2}),_0x18a4d7['accessToken']=_0x221d46),_0x22ffac&&(m(typeof _0x22ffac=='number','internal-error',{'appName':_0x3ffbb2}),_0x18a4d7['expirationTime']=_0x22ffac),_0x18a4d7;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x5f5b59){this['accessToken']=_0x5f5b59['accessToken'],this['refreshToken']=_0x5f5b59['refreshToken'],this['expirationTime']=_0x5f5b59['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x4d69a7,_0x4b4246){m(typeof _0x4d69a7=='string'||typeof _0x4d69a7>'u','internal-error',{'appName':_0x4b4246});}class j{constructor({uid:_0x5c1f02,auth:_0x11c813,stsTokenManager:_0x205789,..._0x2deb6f}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x5c1f02,this['auth']=_0x11c813,this['stsTokenManager']=_0x205789,this['accessToken']=_0x205789['accessToken'],this['displayName']=_0x2deb6f['displayName']||null,this['email']=_0x2deb6f['email']||null,this['emailVerified']=_0x2deb6f['emailVerified']||!0x1,this['phoneNumber']=_0x2deb6f['phoneNumber']||null,this['photoURL']=_0x2deb6f['photoURL']||null,this['isAnonymous']=_0x2deb6f['isAnonymous']||!0x1,this['tenantId']=_0x2deb6f['tenantId']||null,this['providerData']=_0x2deb6f['providerData']?[..._0x2deb6f['providerData']]:[],this['metadata']=new Li(_0x2deb6f['createdAt']||void 0x0,_0x2deb6f['lastLoginAt']||void 0x0);}async['getIdToken'](_0x1bc88a){const _0x12c70a=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x1bc88a));return m(_0x12c70a,this['auth'],'internal-error'),this['accessToken']!==_0x12c70a&&(this['accessToken']=_0x12c70a,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x12c70a;}['getIdTokenResult'](_0x31b169){return Ef(this,_0x31b169);}['reload'](){return Cf(this);}['_assign'](_0x54d7cf){this!==_0x54d7cf&&(m(this['uid']===_0x54d7cf['uid'],this['auth'],'internal-error'),this['displayName']=_0x54d7cf['displayName'],this['photoURL']=_0x54d7cf['photoURL'],this['email']=_0x54d7cf['email'],this['emailVerified']=_0x54d7cf['emailVerified'],this['phoneNumber']=_0x54d7cf['phoneNumber'],this['isAnonymous']=_0x54d7cf['isAnonymous'],this['tenantId']=_0x54d7cf['tenantId'],this['providerData']=_0x54d7cf['providerData']['map'](_0x3f4bf8=>({..._0x3f4bf8})),this['metadata']['_copy'](_0x54d7cf['metadata']),this['stsTokenManager']['_assign'](_0x54d7cf['stsTokenManager']));}['_clone'](_0x79164d){const _0x4c0cd4=new j({...this,'auth':_0x79164d,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x4c0cd4['metadata']['_copy'](this['metadata']),_0x4c0cd4;}['_onReload'](_0x25baa3){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x25baa3,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x40e3c8){this['reloadListener']?this['reloadListener'](_0x40e3c8):this['reloadUserInfo']=_0x40e3c8;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x423bec,_0x20134d=!0x1){let _0x99974c=!0x1;_0x423bec['idToken']&&_0x423bec['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x423bec),_0x99974c=!0x0),_0x20134d&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x99974c&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x3df97b=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x3df97b})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x2844d4=>({..._0x2844d4})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x45c15d,_0x471ace){const _0x56ce76=_0x471ace['displayName']??void 0x0,_0x3f9d6b=_0x471ace['email']??void 0x0,_0x126915=_0x471ace['phoneNumber']??void 0x0,_0x5929ba=_0x471ace['photoURL']??void 0x0,_0x46aed8=_0x471ace['tenantId']??void 0x0,_0x95905f=_0x471ace['_redirectEventId']??void 0x0,_0x5c7b87=_0x471ace['createdAt']??void 0x0,_0x3c92f0=_0x471ace['lastLoginAt']??void 0x0,{uid:_0x111a7f,emailVerified:_0x244f1a,isAnonymous:_0x2bba7,providerData:_0x31e354,stsTokenManager:_0x2d7323}=_0x471ace;m(_0x111a7f&&_0x2d7323,_0x45c15d,'internal-error');const _0x5d57ee=et['fromJSON'](this['name'],_0x2d7323);m(typeof _0x111a7f=='string',_0x45c15d,'internal-error'),le(_0x56ce76,_0x45c15d['name']),le(_0x3f9d6b,_0x45c15d['name']),m(typeof _0x244f1a=='boolean',_0x45c15d,'internal-error'),m(typeof _0x2bba7=='boolean',_0x45c15d,'internal-error'),le(_0x126915,_0x45c15d['name']),le(_0x5929ba,_0x45c15d['name']),le(_0x46aed8,_0x45c15d['name']),le(_0x95905f,_0x45c15d['name']),le(_0x5c7b87,_0x45c15d['name']),le(_0x3c92f0,_0x45c15d['name']);const _0x4764ad=new j({'uid':_0x111a7f,'auth':_0x45c15d,'email':_0x3f9d6b,'emailVerified':_0x244f1a,'displayName':_0x56ce76,'isAnonymous':_0x2bba7,'photoURL':_0x5929ba,'phoneNumber':_0x126915,'tenantId':_0x46aed8,'stsTokenManager':_0x5d57ee,'createdAt':_0x5c7b87,'lastLoginAt':_0x3c92f0});return _0x31e354&&Array['isArray'](_0x31e354)&&(_0x4764ad['providerData']=_0x31e354['map'](_0x57057f=>({..._0x57057f}))),_0x95905f&&(_0x4764ad['_redirectEventId']=_0x95905f),_0x4764ad;}static async['_fromIdTokenResponse'](_0x4b3f54,_0x1978a1,_0x2daa79=!0x1){const _0xf5939d=new et();_0xf5939d['updateFromServerResponse'](_0x1978a1);const _0x31cee8=new j({'uid':_0x1978a1['localId'],'auth':_0x4b3f54,'stsTokenManager':_0xf5939d,'isAnonymous':_0x2daa79});return await Nn(_0x31cee8),_0x31cee8;}static async['_fromGetAccountInfoResponse'](_0x3c38fb,_0x5722a0,_0x38790e){const _0x4e2253=_0x5722a0['users'][0x0];m(_0x4e2253['localId']!==void 0x0,'internal-error');const _0x25846f=_0x4e2253['providerUserInfo']!==void 0x0?Sa(_0x4e2253['providerUserInfo']):[],_0x36e1cf=!(_0x4e2253['email']&&_0x4e2253['passwordHash'])&&!(_0x25846f!=null&&_0x25846f['length']),_0x290cd4=new et();_0x290cd4['updateFromIdToken'](_0x38790e);const _0x46d7e8=new j({'uid':_0x4e2253['localId'],'auth':_0x3c38fb,'stsTokenManager':_0x290cd4,'isAnonymous':_0x36e1cf}),_0x1ceaf8={'uid':_0x4e2253['localId'],'displayName':_0x4e2253['displayName']||null,'photoURL':_0x4e2253['photoUrl']||null,'email':_0x4e2253['email']||null,'emailVerified':_0x4e2253['emailVerified']||!0x1,'phoneNumber':_0x4e2253['phoneNumber']||null,'tenantId':_0x4e2253['tenantId']||null,'providerData':_0x25846f,'metadata':new Li(_0x4e2253['createdAt'],_0x4e2253['lastLoginAt']),'isAnonymous':!(_0x4e2253['email']&&_0x4e2253['passwordHash'])&&!(_0x25846f!=null&&_0x25846f['length'])};return Object['assign'](_0x46d7e8,_0x1ceaf8),_0x46d7e8;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x341441){ce(_0x341441 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x5a8204=Tr['get'](_0x341441);return _0x5a8204?(ce(_0x5a8204 instanceof _0x341441,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x5a8204):(_0x5a8204=new _0x341441(),Tr['set'](_0x341441,_0x5a8204),_0x5a8204);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x3f3317,_0x4f076f){this['storage'][_0x3f3317]=_0x4f076f;}async['_get'](_0x8054cc){const _0x403eb5=this['storage'][_0x8054cc];return _0x403eb5===void 0x0?null:_0x403eb5;}async['_remove'](_0x14017b){delete this['storage'][_0x14017b];}['_addListener'](_0x377bf,_0x16e98f){}['_removeListener'](_0x4f5bb8,_0x918322){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x4c209a,_0x3ffc3a,_0x153c03){return'firebase:'+_0x4c209a+':'+_0x3ffc3a+':'+_0x153c03;}class tt{constructor(_0x246a2e,_0x51c989,_0x5cbad1){this['persistence']=_0x246a2e,this['auth']=_0x51c989,this['userKey']=_0x5cbad1;const {config:_0x1a44c2,name:_0x58c8d8}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x1a44c2['apiKey'],_0x58c8d8),this['fullPersistenceKey']=ln('persistence',_0x1a44c2['apiKey'],_0x58c8d8),this['boundEventHandler']=_0x51c989['_onStorageEvent']['bind'](_0x51c989),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x1b337f){return this['persistence']['_set'](this['fullUserKey'],_0x1b337f['toJSON']());}async['getCurrentUser'](){const _0x272743=await this['persistence']['_get'](this['fullUserKey']);if(!_0x272743)return null;if(typeof _0x272743=='string'){const _0x541706=await Pn(this['auth'],{'idToken':_0x272743})['catch'](()=>{});return _0x541706?j['_fromGetAccountInfoResponse'](this['auth'],_0x541706,_0x272743):null;}return j['_fromJSON'](this['auth'],_0x272743);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x503687){if(this['persistence']===_0x503687)return;const _0x9e8d7=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x503687,_0x9e8d7)return this['setCurrentUser'](_0x9e8d7);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x4fc4e3,_0x441249,_0x3983d8='authUser'){if(!_0x441249['length'])return new tt(ie(Sr),_0x4fc4e3,_0x3983d8);const _0x12d922=(await Promise['all'](_0x441249['map'](async _0xe34807=>{if(await _0xe34807['_isAvailable']())return _0xe34807;})))['filter'](_0x1dc824=>_0x1dc824);let _0x3bbe00=_0x12d922[0x0]||ie(Sr);const _0xb1b573=ln(_0x3983d8,_0x4fc4e3['config']['apiKey'],_0x4fc4e3['name']);let _0x4db993=null;for(const _0x48214e of _0x441249)try{const _0x4744ba=await _0x48214e['_get'](_0xb1b573);if(_0x4744ba){let _0x41715e;if(typeof _0x4744ba=='string'){const _0x463429=await Pn(_0x4fc4e3,{'idToken':_0x4744ba})['catch'](()=>{});if(!_0x463429)break;_0x41715e=await j['_fromGetAccountInfoResponse'](_0x4fc4e3,_0x463429,_0x4744ba);}else _0x41715e=j['_fromJSON'](_0x4fc4e3,_0x4744ba);_0x48214e!==_0x3bbe00&&(_0x4db993=_0x41715e),_0x3bbe00=_0x48214e;break;}}catch{}const _0x529f69=_0x12d922['filter'](_0x2102f5=>_0x2102f5['_shouldAllowMigration']);return!_0x3bbe00['_shouldAllowMigration']||!_0x529f69['length']?new tt(_0x3bbe00,_0x4fc4e3,_0x3983d8):(_0x3bbe00=_0x529f69[0x0],_0x4db993&&await _0x3bbe00['_set'](_0xb1b573,_0x4db993['toJSON']()),await Promise['all'](_0x441249['map'](async _0xc9659=>{if(_0xc9659!==_0x3bbe00)try{await _0xc9659['_remove'](_0xb1b573);}catch{}})),new tt(_0x3bbe00,_0x4fc4e3,_0x3983d8));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x482571){const _0x502a19=_0x482571['toLowerCase']();if(_0x502a19['includes']('opera/')||_0x502a19['includes']('opr/')||_0x502a19['includes']('opios/'))return'Opera';if(Pa(_0x502a19))return'IEMobile';if(_0x502a19['includes']('msie')||_0x502a19['includes']('trident/'))return'IE';if(_0x502a19['includes']('edge/'))return'Edge';if(Ra(_0x502a19))return'Firefox';if(_0x502a19['includes']('silk/'))return'Silk';if(Oa(_0x502a19))return'Blackberry';if(Da(_0x502a19))return'Webos';if(Aa(_0x502a19))return'Safari';if((_0x502a19['includes']('chrome/')||ka(_0x502a19))&&!_0x502a19['includes']('edge/'))return'Chrome';if(Na(_0x502a19))return'Android';{const _0x217c82=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x8fd4c4=_0x482571['match'](_0x217c82);if((_0x8fd4c4==null?void 0x0:_0x8fd4c4['length'])===0x2)return _0x8fd4c4[0x1];}return'Other';}function Ra(_0x1a707a=W()){return/firefox\//i['test'](_0x1a707a);}function Aa(_0x3f6d8f=W()){const _0x1b4cea=_0x3f6d8f['toLowerCase']();return _0x1b4cea['includes']('safari/')&&!_0x1b4cea['includes']('chrome/')&&!_0x1b4cea['includes']('crios/')&&!_0x1b4cea['includes']('android');}function ka(_0x2eae82=W()){return/crios\//i['test'](_0x2eae82);}function Pa(_0x352ca7=W()){return/iemobile/i['test'](_0x352ca7);}function Na(_0x493d26=W()){return/android/i['test'](_0x493d26);}function Oa(_0x7db415=W()){return/blackberry/i['test'](_0x7db415);}function Da(_0x54d88c=W()){return/webos/i['test'](_0x54d88c);}function Ss(_0x23fd82=W()){return/iphone|ipad|ipod/i['test'](_0x23fd82)||/macintosh/i['test'](_0x23fd82)&&/mobile/i['test'](_0x23fd82);}function Rf(_0x5458dd=W()){var _0x1da969;return Ss(_0x5458dd)&&!!((_0x1da969=window['navigator'])!=null&&_0x1da969['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x411457=W()){return Ss(_0x411457)||Na(_0x411457)||Da(_0x411457)||Oa(_0x411457)||/windows phone/i['test'](_0x411457)||Pa(_0x411457);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x19607c,_0x5b4f98=[]){let _0x5e3488;switch(_0x19607c){case'Browser':_0x5e3488=br(W());break;case'Worker':_0x5e3488=br(W())+'-'+_0x19607c;break;default:_0x5e3488=_0x19607c;}const _0x4e0c69=_0x5b4f98['length']?_0x5b4f98['join'](','):'FirebaseCore-web';return _0x5e3488+'/JsCore/'+dt+'/'+_0x4e0c69;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x6b96e3){this['auth']=_0x6b96e3,this['queue']=[];}['pushCallback'](_0x485283,_0x1fb0b6){const _0x15b03e=_0x5253dc=>new Promise((_0xf07274,_0x1dec30)=>{try{const _0x5eb574=_0x485283(_0x5253dc);_0xf07274(_0x5eb574);}catch(_0x47afb4){_0x1dec30(_0x47afb4);}});_0x15b03e['onAbort']=_0x1fb0b6,this['queue']['push'](_0x15b03e);const _0x18eb23=this['queue']['length']-0x1;return()=>{this['queue'][_0x18eb23]=()=>Promise['resolve']();};}async['runMiddleware'](_0x1c4161){if(this['auth']['currentUser']===_0x1c4161)return;const _0x363ec1=[];try{for(const _0x27d257 of this['queue'])await _0x27d257(_0x1c4161),_0x27d257['onAbort']&&_0x363ec1['push'](_0x27d257['onAbort']);}catch(_0x2ebde6){_0x363ec1['reverse']();for(const _0x19f2a5 of _0x363ec1)try{_0x19f2a5();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x2ebde6==null?void 0x0:_0x2ebde6['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x85e6f2,_0xa5b264={}){return Pe(_0x85e6f2,'GET','/v2/passwordPolicy',ke(_0x85e6f2,_0xa5b264));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x3d9550){var _0xf4fa6c;const _0x31d070=_0x3d9550['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x31d070['minPasswordLength']??Nf,_0x31d070['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x31d070['maxPasswordLength']),_0x31d070['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x31d070['containsLowercaseCharacter']),_0x31d070['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x31d070['containsUppercaseCharacter']),_0x31d070['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x31d070['containsNumericCharacter']),_0x31d070['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x31d070['containsNonAlphanumericCharacter']),this['enforcementState']=_0x3d9550['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0xf4fa6c=_0x3d9550['allowedNonAlphanumericCharacters'])==null?void 0x0:_0xf4fa6c['join'](''))??'',this['forceUpgradeOnSignin']=_0x3d9550['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x3d9550['schemaVersion'];}['validatePassword'](_0x13025c){const _0x7dbd09={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x13025c,_0x7dbd09),this['validatePasswordCharacterOptions'](_0x13025c,_0x7dbd09),_0x7dbd09['isValid']&&(_0x7dbd09['isValid']=_0x7dbd09['meetsMinPasswordLength']??!0x0),_0x7dbd09['isValid']&&(_0x7dbd09['isValid']=_0x7dbd09['meetsMaxPasswordLength']??!0x0),_0x7dbd09['isValid']&&(_0x7dbd09['isValid']=_0x7dbd09['containsLowercaseLetter']??!0x0),_0x7dbd09['isValid']&&(_0x7dbd09['isValid']=_0x7dbd09['containsUppercaseLetter']??!0x0),_0x7dbd09['isValid']&&(_0x7dbd09['isValid']=_0x7dbd09['containsNumericCharacter']??!0x0),_0x7dbd09['isValid']&&(_0x7dbd09['isValid']=_0x7dbd09['containsNonAlphanumericCharacter']??!0x0),_0x7dbd09;}['validatePasswordLengthOptions'](_0x4cf332,_0x7274aa){const _0x521aef=this['customStrengthOptions']['minPasswordLength'],_0x479694=this['customStrengthOptions']['maxPasswordLength'];_0x521aef&&(_0x7274aa['meetsMinPasswordLength']=_0x4cf332['length']>=_0x521aef),_0x479694&&(_0x7274aa['meetsMaxPasswordLength']=_0x4cf332['length']<=_0x479694);}['validatePasswordCharacterOptions'](_0x37c6ec,_0x27cc29){this['updatePasswordCharacterOptionsStatuses'](_0x27cc29,!0x1,!0x1,!0x1,!0x1);let _0x24b2a3;for(let _0x3f920b=0x0;_0x3f920b<_0x37c6ec['length'];_0x3f920b++)_0x24b2a3=_0x37c6ec['charAt'](_0x3f920b),this['updatePasswordCharacterOptionsStatuses'](_0x27cc29,_0x24b2a3>='a'&&_0x24b2a3<='z',_0x24b2a3>='A'&&_0x24b2a3<='Z',_0x24b2a3>='0'&&_0x24b2a3<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x24b2a3));}['updatePasswordCharacterOptionsStatuses'](_0x2d5198,_0x43eb2f,_0x4851a3,_0x2e0a32,_0x5466b5){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x2d5198['containsLowercaseLetter']||(_0x2d5198['containsLowercaseLetter']=_0x43eb2f)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x2d5198['containsUppercaseLetter']||(_0x2d5198['containsUppercaseLetter']=_0x4851a3)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x2d5198['containsNumericCharacter']||(_0x2d5198['containsNumericCharacter']=_0x2e0a32)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x2d5198['containsNonAlphanumericCharacter']||(_0x2d5198['containsNonAlphanumericCharacter']=_0x5466b5));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x164ef1,_0x3d6d62,_0x4d857b,_0x2eb6b8){this['app']=_0x164ef1,this['heartbeatServiceProvider']=_0x3d6d62,this['appCheckServiceProvider']=_0x4d857b,this['config']=_0x2eb6b8,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x164ef1['name'],this['clientVersion']=_0x2eb6b8['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x12102a=>this['_resolvePersistenceManagerAvailable']=_0x12102a);}['_initializeWithPersistence'](_0x4f7ed9,_0x18109c){return _0x18109c&&(this['_popupRedirectResolver']=ie(_0x18109c)),this['_initializationPromise']=this['queue'](async()=>{var _0x14e3fa,_0x325f36,_0x5aae95;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x4f7ed9),(_0x14e3fa=this['_resolvePersistenceManagerAvailable'])==null||_0x14e3fa['call'](this),!this['_deleted'])){if((_0x325f36=this['_popupRedirectResolver'])!=null&&_0x325f36['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x18109c),this['lastNotifiedUid']=((_0x5aae95=this['currentUser'])==null?void 0x0:_0x5aae95['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x20276a=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x20276a)){if(this['currentUser']&&_0x20276a&&this['currentUser']['uid']===_0x20276a['uid']){this['_currentUser']['_assign'](_0x20276a),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x20276a,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x58a43b){try{const _0x5977b=await Pn(this,{'idToken':_0x58a43b}),_0x3df440=await j['_fromGetAccountInfoResponse'](this,_0x5977b,_0x58a43b);await this['directlySetCurrentUser'](_0x3df440);}catch(_0x5e5aef){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x5e5aef),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x33a380){var _0xe5d249;if($(this['app'])){const _0x3fafda=this['app']['settings']['authIdToken'];return _0x3fafda?new Promise(_0x22753b=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x3fafda)['then'](_0x22753b,_0x22753b));}):this['directlySetCurrentUser'](null);}const _0x55ce8c=await this['assertedPersistence']['getCurrentUser']();let _0x3538b1=_0x55ce8c,_0x28e94d=!0x1;if(_0x33a380&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x29e581=(_0xe5d249=this['redirectUser'])==null?void 0x0:_0xe5d249['_redirectEventId'],_0x10847e=_0x3538b1==null?void 0x0:_0x3538b1['_redirectEventId'],_0x32df0a=await this['tryRedirectSignIn'](_0x33a380);(!_0x29e581||_0x29e581===_0x10847e)&&(_0x32df0a!=null&&_0x32df0a['user'])&&(_0x3538b1=_0x32df0a['user'],_0x28e94d=!0x0);}if(!_0x3538b1)return this['directlySetCurrentUser'](null);if(!_0x3538b1['_redirectEventId']){if(_0x28e94d)try{await this['beforeStateQueue']['runMiddleware'](_0x3538b1);}catch(_0x259acb){_0x3538b1=_0x55ce8c,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x259acb));}return _0x3538b1?this['reloadAndSetCurrentUserOrClear'](_0x3538b1):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x3538b1['_redirectEventId']?this['directlySetCurrentUser'](_0x3538b1):this['reloadAndSetCurrentUserOrClear'](_0x3538b1);}async['tryRedirectSignIn'](_0x3f75d7){let _0x2595c0=null;try{_0x2595c0=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x3f75d7,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x2595c0;}async['reloadAndSetCurrentUserOrClear'](_0x5960f3){try{await Nn(_0x5960f3);}catch(_0x2e870e){if((_0x2e870e==null?void 0x0:_0x2e870e['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x5960f3);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x2bd1fe){if($(this['app']))return Promise['reject'](re(this));const _0x2d3b8a=_0x2bd1fe?P(_0x2bd1fe):null;return _0x2d3b8a&&m(_0x2d3b8a['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x2d3b8a&&_0x2d3b8a['_clone'](this));}async['_updateCurrentUser'](_0xe51648,_0x5d393b=!0x1){if(!this['_deleted'])return _0xe51648&&m(this['tenantId']===_0xe51648['tenantId'],this,'tenant-id-mismatch'),_0x5d393b||await this['beforeStateQueue']['runMiddleware'](_0xe51648),this['queue'](async()=>{await this['directlySetCurrentUser'](_0xe51648),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x5d98c4){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x5d98c4));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x1a42c2){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x2d8a4c=this['_getPasswordPolicyInternal']();return _0x2d8a4c['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x2d8a4c['validatePassword'](_0x1a42c2);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x3e6edc=await Pf(this),_0x4f5f4b=new Of(_0x3e6edc);this['tenantId']===null?this['_projectPasswordPolicy']=_0x4f5f4b:this['_tenantPasswordPolicies'][this['tenantId']]=_0x4f5f4b;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x326024){this['_errorFactory']=new Gt('auth','Firebase',_0x326024());}['onAuthStateChanged'](_0x33c0ae,_0x100c21,_0x4d0768){return this['registerStateListener'](this['authStateSubscription'],_0x33c0ae,_0x100c21,_0x4d0768);}['beforeAuthStateChanged'](_0xdc8a0f,_0x18caac){return this['beforeStateQueue']['pushCallback'](_0xdc8a0f,_0x18caac);}['onIdTokenChanged'](_0x35b27d,_0x561d66,_0x212b6e){return this['registerStateListener'](this['idTokenSubscription'],_0x35b27d,_0x561d66,_0x212b6e);}['authStateReady'](){return new Promise((_0x2c98c2,_0x1f1886)=>{if(this['currentUser'])_0x2c98c2();else{const _0x1f850c=this['onAuthStateChanged'](()=>{_0x1f850c(),_0x2c98c2();},_0x1f1886);}});}async['revokeAccessToken'](_0x2eeadc){if(this['currentUser']){const _0x22f20b=await this['currentUser']['getIdToken'](),_0x1b4009={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x2eeadc,'idToken':_0x22f20b};this['tenantId']!=null&&(_0x1b4009['tenantId']=this['tenantId']),await bf(this,_0x1b4009);}}['toJSON'](){var _0x2f1c8a;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x2f1c8a=this['_currentUser'])==null?void 0x0:_0x2f1c8a['toJSON']()};}async['_setRedirectUser'](_0x555dfb,_0x33c95d){const _0x3304c4=await this['getOrInitRedirectPersistenceManager'](_0x33c95d);return _0x555dfb===null?_0x3304c4['removeCurrentUser']():_0x3304c4['setCurrentUser'](_0x555dfb);}async['getOrInitRedirectPersistenceManager'](_0x48bb4f){if(!this['redirectPersistenceManager']){const _0x27536e=_0x48bb4f&&ie(_0x48bb4f)||this['_popupRedirectResolver'];m(_0x27536e,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x27536e['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x2cd7b2){var _0x509dc2,_0x13bd58;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x509dc2=this['_currentUser'])==null?void 0x0:_0x509dc2['_redirectEventId'])===_0x2cd7b2?this['_currentUser']:((_0x13bd58=this['redirectUser'])==null?void 0x0:_0x13bd58['_redirectEventId'])===_0x2cd7b2?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x1ee2ca){if(_0x1ee2ca===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x1ee2ca));}['_notifyListenersIfCurrent'](_0x4ab59c){_0x4ab59c===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x1b92ea;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x1fcb5a=((_0x1b92ea=this['currentUser'])==null?void 0x0:_0x1b92ea['uid'])??null;this['lastNotifiedUid']!==_0x1fcb5a&&(this['lastNotifiedUid']=_0x1fcb5a,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x5b52f7,_0x271fe6,_0x536f36,_0x2f9a9e){if(this['_deleted'])return()=>{};const _0x1d0182=typeof _0x271fe6=='function'?_0x271fe6:_0x271fe6['next']['bind'](_0x271fe6);let _0x5b572e=!0x1;const _0x5e4726=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x5e4726,this,'internal-error'),_0x5e4726['then'](()=>{_0x5b572e||_0x1d0182(this['currentUser']);}),typeof _0x271fe6=='function'){const _0x3c4bd1=_0x5b52f7['addObserver'](_0x271fe6,_0x536f36,_0x2f9a9e);return()=>{_0x5b572e=!0x0,_0x3c4bd1();};}else{const _0xe1c9f7=_0x5b52f7['addObserver'](_0x271fe6);return()=>{_0x5b572e=!0x0,_0xe1c9f7();};}}async['directlySetCurrentUser'](_0x32ec50){this['currentUser']&&this['currentUser']!==_0x32ec50&&this['_currentUser']['_stopProactiveRefresh'](),_0x32ec50&&this['isProactiveRefreshEnabled']&&_0x32ec50['_startProactiveRefresh'](),this['currentUser']=_0x32ec50,_0x32ec50?await this['assertedPersistence']['setCurrentUser'](_0x32ec50):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x48f9b7){return this['operations']=this['operations']['then'](_0x48f9b7,_0x48f9b7),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x5496a9){!_0x5496a9||this['frameworks']['includes'](_0x5496a9)||(this['frameworks']['push'](_0x5496a9),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x46669d;const _0x36dbd5={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x36dbd5['X-Firebase-gmpid']=this['app']['options']['appId']);const _0xd4d4cb=await((_0x46669d=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x46669d['getHeartbeatsHeader']());_0xd4d4cb&&(_0x36dbd5['X-Firebase-Client']=_0xd4d4cb);const _0xbbe735=await this['_getAppCheckToken']();return _0xbbe735&&(_0x36dbd5['X-Firebase-AppCheck']=_0xbbe735),_0x36dbd5;}async['_getAppCheckToken'](){var _0x1da633;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x45d3bd=await((_0x1da633=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x1da633['getToken']());return _0x45d3bd!=null&&_0x45d3bd['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x45d3bd['error']),_0x45d3bd==null?void 0x0:_0x45d3bd['token'];}}function Ke(_0x1d222b){return P(_0x1d222b);}class Rr{constructor(_0x63cb41){this['auth']=_0x63cb41,this['observer']=null,this['addObserver']=Tc(_0x19fc9b=>this['observer']=_0x19fc9b);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x383f78){Jn=_0x383f78;}function xa(_0x1b9232){return Jn['loadJS'](_0x1b9232);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0x10e8c4){return'__'+_0x10e8c4+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x26ea42){_0x26ea42();}['execute'](_0x35f4ae,_0x557919){return Promise['resolve']('token');}['render'](_0x2873b2,_0x15e132){return'';}}class Wf{['ready'](_0x442c0f){_0x442c0f();}['execute'](_0x4a79ad,_0x105589){return Promise['resolve']('token');}['render'](_0x102008,_0x4098d3){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x1e07ce){this['type']=Bf,this['auth']=Ke(_0x1e07ce);}async['verify'](_0x30ad8f='verify',_0x418286=!0x1){async function _0x340708(_0x415e19){if(!_0x418286){if(_0x415e19['tenantId']==null&&_0x415e19['_agentRecaptchaConfig']!=null)return _0x415e19['_agentRecaptchaConfig']['siteKey'];if(_0x415e19['tenantId']!=null&&_0x415e19['_tenantRecaptchaConfigs'][_0x415e19['tenantId']]!==void 0x0)return _0x415e19['_tenantRecaptchaConfigs'][_0x415e19['tenantId']]['siteKey'];}return new Promise(async(_0x487d02,_0x41d541)=>{yf(_0x415e19,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x408fba=>{if(_0x408fba['recaptchaKey']===void 0x0)_0x41d541(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x17430b=new mf(_0x408fba);return _0x415e19['tenantId']==null?_0x415e19['_agentRecaptchaConfig']=_0x17430b:_0x415e19['_tenantRecaptchaConfigs'][_0x415e19['tenantId']]=_0x17430b,_0x487d02(_0x17430b['siteKey']);}})['catch'](_0x19e876=>{_0x41d541(_0x19e876);});});}function _0x2cb51e(_0x2a6fb8,_0xa1a16b,_0x32829d){const _0x393d0d=window['grecaptcha'];wr(_0x393d0d)?_0x393d0d['enterprise']['ready'](()=>{_0x393d0d['enterprise']['execute'](_0x2a6fb8,{'action':_0x30ad8f})['then'](_0x4537a3=>{_0xa1a16b(_0x4537a3);})['catch'](()=>{_0xa1a16b(Fa);});}):_0x32829d(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x2b12f2,_0x374ef6)=>{_0x340708(this['auth'])['then'](async _0x437cb4=>{if(!_0x418286&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x2cb51e(_0x437cb4,_0x2b12f2,_0x374ef6);else{if(typeof window>'u'){_0x374ef6(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0xbdb9c2=Lf();_0xbdb9c2['length']!==0x0&&(_0xbdb9c2+=_0x437cb4+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x3c1d52;(_0x3c1d52=he['scriptInjectionDeferred'])==null||_0x3c1d52['resolve']();},xa(_0xbdb9c2)['then'](()=>{var _0x8d5982;return(_0x8d5982=he['scriptInjectionDeferred'])==null?void 0x0:_0x8d5982['promise'];})['then'](()=>{_0x2cb51e(_0x437cb4,_0x2b12f2,_0x374ef6);})['catch'](_0x262ba9=>{_0x374ef6(_0x262ba9);});}})['catch'](_0x525db9=>{_0x374ef6(_0x525db9);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x3b8b56,_0x1987ee,_0x403156,_0x483603=!0x1,_0x3828ed=!0x1){const _0x52cb77=new he(_0x3b8b56);let _0x1212e3;if(_0x3828ed)_0x1212e3=Fa;else try{_0x1212e3=await _0x52cb77['verify'](_0x403156);}catch{_0x1212e3=await _0x52cb77['verify'](_0x403156,!0x0);}const _0x37576f={..._0x1987ee};if(_0x403156==='mfaSmsEnrollment'||_0x403156==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x37576f){const _0xbf30fa=_0x37576f['phoneEnrollmentInfo']['phoneNumber'],_0x361eb3=_0x37576f['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x37576f,{'phoneEnrollmentInfo':{'phoneNumber':_0xbf30fa,'recaptchaToken':_0x361eb3,'captchaResponse':_0x1212e3,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x37576f){const _0x174c95=_0x37576f['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x37576f,{'phoneSignInInfo':{'recaptchaToken':_0x174c95,'captchaResponse':_0x1212e3,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x37576f;}return _0x483603?Object['assign'](_0x37576f,{'captchaResp':_0x1212e3}):Object['assign'](_0x37576f,{'captchaResponse':_0x1212e3}),Object['assign'](_0x37576f,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x37576f,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x37576f;}async function xi(_0x4040bf,_0x2fac09,_0x2df2fa,_0x29ee76,_0x5748fa){var _0x3a03f6;if((_0x3a03f6=_0x4040bf['_getRecaptchaConfig']())!=null&&_0x3a03f6['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x439af6=await kr(_0x4040bf,_0x2fac09,_0x2df2fa,_0x2df2fa==='getOobCode');return _0x29ee76(_0x4040bf,_0x439af6);}else return _0x29ee76(_0x4040bf,_0x2fac09)['catch'](async _0x34ee12=>{if(_0x34ee12['code']==='auth/missing-recaptcha-token'){console['log'](_0x2df2fa+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x397732=await kr(_0x4040bf,_0x2fac09,_0x2df2fa,_0x2df2fa==='getOobCode');return _0x29ee76(_0x4040bf,_0x397732);}else return Promise['reject'](_0x34ee12);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x1d044a,_0x28c722){const _0x5b7ccc=Hi(_0x1d044a,'auth');if(_0x5b7ccc['isInitialized']()){const _0x47e290=_0x5b7ccc['getImmediate'](),_0xe2e666=_0x5b7ccc['getOptions']();if(xe(_0xe2e666,_0x28c722??{}))return _0x47e290;Y(_0x47e290,'already-initialized');}return _0x5b7ccc['initialize']({'options':_0x28c722});}function Hf(_0x3e85f1,_0x4a4bbc){const _0x25a620=(_0x4a4bbc==null?void 0x0:_0x4a4bbc['persistence'])||[],_0x5a154b=(Array['isArray'](_0x25a620)?_0x25a620:[_0x25a620])['map'](ie);_0x4a4bbc!=null&&_0x4a4bbc['errorMap']&&_0x3e85f1['_updateErrorMap'](_0x4a4bbc['errorMap']),_0x3e85f1['_initializeWithPersistence'](_0x5a154b,_0x4a4bbc==null?void 0x0:_0x4a4bbc['popupRedirectResolver']);}function $f(_0x19d29b,_0x4e1280,_0x2f9a00){const _0x319af0=Ke(_0x19d29b);m(/^https?:\/\//['test'](_0x4e1280),_0x319af0,'invalid-emulator-scheme');const _0x328b57=!0x1,_0x49b7eb=Ua(_0x4e1280),{host:_0x23f0c3,port:_0x44c00e}=Gf(_0x4e1280),_0x17df8d=_0x44c00e===null?'':':'+_0x44c00e,_0x51d7f5={'url':_0x49b7eb+'//'+_0x23f0c3+_0x17df8d+'/'},_0x5d31e2=Object['freeze']({'host':_0x23f0c3,'port':_0x44c00e,'protocol':_0x49b7eb['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x328b57})});if(!_0x319af0['_canInitEmulator']){m(_0x319af0['config']['emulator']&&_0x319af0['emulatorConfig'],_0x319af0,'emulator-config-failed'),m(xe(_0x51d7f5,_0x319af0['config']['emulator'])&&xe(_0x5d31e2,_0x319af0['emulatorConfig']),_0x319af0,'emulator-config-failed');return;}_0x319af0['config']['emulator']=_0x51d7f5,_0x319af0['emulatorConfig']=_0x5d31e2,_0x319af0['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x23f0c3)?Qr(_0x49b7eb+'//'+_0x23f0c3+_0x17df8d):qf();}function Ua(_0x7a7b2c){const _0x230ecd=_0x7a7b2c['indexOf'](':');return _0x230ecd<0x0?'':_0x7a7b2c['substr'](0x0,_0x230ecd+0x1);}function Gf(_0xed2f4){const _0xdaa952=Ua(_0xed2f4),_0x500f9f=/(\/\/)?([^?#/]+)/['exec'](_0xed2f4['substr'](_0xdaa952['length']));if(!_0x500f9f)return{'host':'','port':null};const _0x5df0ff=_0x500f9f[0x2]['split']('@')['pop']()||'',_0x19c4b7=/^(\[[^\]]+\])(:|$)/['exec'](_0x5df0ff);if(_0x19c4b7){const _0x18fe6e=_0x19c4b7[0x1];return{'host':_0x18fe6e,'port':Pr(_0x5df0ff['substr'](_0x18fe6e['length']+0x1))};}else{const [_0x3d82ec,_0x2a7240]=_0x5df0ff['split'](':');return{'host':_0x3d82ec,'port':Pr(_0x2a7240)};}}function Pr(_0xd65866){if(!_0xd65866)return null;const _0x69eabf=Number(_0xd65866);return isNaN(_0x69eabf)?null:_0x69eabf;}function qf(){function _0x2a64ea(){const _0x3aab90=document['createElement']('p'),_0x39f928=_0x3aab90['style'];_0x3aab90['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x39f928['position']='fixed',_0x39f928['width']='100%',_0x39f928['backgroundColor']='#ffffff',_0x39f928['border']='.1em\x20solid\x20#000000',_0x39f928['color']='#b50000',_0x39f928['bottom']='0px',_0x39f928['left']='0px',_0x39f928['margin']='0px',_0x39f928['zIndex']='10000',_0x39f928['textAlign']='center',_0x3aab90['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x3aab90);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x2a64ea):_0x2a64ea());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x55954c,_0x4c204e){this['providerId']=_0x55954c,this['signInMethod']=_0x4c204e;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x5c7a1c){return ne('not\x20implemented');}['_linkToIdToken'](_0xd5ae1d,_0x5a9429){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x25f8cf){return ne('not\x20implemented');}}async function zf(_0x498eba,_0x1f3b29){return Pe(_0x498eba,'POST','/v1/accounts:signUp',_0x1f3b29);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x231015,_0x5a516e){return en(_0x231015,'POST','/v1/accounts:signInWithPassword',ke(_0x231015,_0x5a516e));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0x3fb531,_0x4d0c61){return en(_0x3fb531,'POST','/v1/accounts:signInWithEmailLink',ke(_0x3fb531,_0x4d0c61));}async function Yf(_0x29b59a,_0x308439){return en(_0x29b59a,'POST','/v1/accounts:signInWithEmailLink',ke(_0x29b59a,_0x308439));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x13dbf1,_0x2dce09,_0x475854,_0x32dc6d=null){super('password',_0x475854),this['_email']=_0x13dbf1,this['_password']=_0x2dce09,this['_tenantId']=_0x32dc6d;}static['_fromEmailAndPassword'](_0x4d8165,_0x163380){return new $t(_0x4d8165,_0x163380,'password');}static['_fromEmailAndCode'](_0x395275,_0x23cd46,_0x695d5f=null){return new $t(_0x395275,_0x23cd46,'emailLink',_0x695d5f);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x34305c){const _0x230d10=typeof _0x34305c=='string'?JSON['parse'](_0x34305c):_0x34305c;if(_0x230d10!=null&&_0x230d10['email']&&(_0x230d10!=null&&_0x230d10['password'])){if(_0x230d10['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x230d10['email'],_0x230d10['password']);if(_0x230d10['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x230d10['email'],_0x230d10['password'],_0x230d10['tenantId']);}return null;}async['_getIdTokenResponse'](_0x584268){switch(this['signInMethod']){case'password':const _0x2595cf={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x584268,_0x2595cf,'signInWithPassword',jf);case'emailLink':return Kf(_0x584268,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x584268,'internal-error');}}async['_linkToIdToken'](_0x51c73c,_0x69f280){switch(this['signInMethod']){case'password':const _0x405c10={'idToken':_0x69f280,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x51c73c,_0x405c10,'signUpPassword',zf);case'emailLink':return Yf(_0x51c73c,{'idToken':_0x69f280,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x51c73c,'internal-error');}}['_getReauthenticationResolver'](_0x50035f){return this['_getIdTokenResponse'](_0x50035f);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x47be1f,_0x1bb178){return en(_0x47be1f,'POST','/v1/accounts:signInWithIdp',ke(_0x47be1f,_0x1bb178));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x193a76){const _0x1c7bd3=new $e(_0x193a76['providerId'],_0x193a76['signInMethod']);return _0x193a76['idToken']||_0x193a76['accessToken']?(_0x193a76['idToken']&&(_0x1c7bd3['idToken']=_0x193a76['idToken']),_0x193a76['accessToken']&&(_0x1c7bd3['accessToken']=_0x193a76['accessToken']),_0x193a76['nonce']&&!_0x193a76['pendingToken']&&(_0x1c7bd3['nonce']=_0x193a76['nonce']),_0x193a76['pendingToken']&&(_0x1c7bd3['pendingToken']=_0x193a76['pendingToken'])):_0x193a76['oauthToken']&&_0x193a76['oauthTokenSecret']?(_0x1c7bd3['accessToken']=_0x193a76['oauthToken'],_0x1c7bd3['secret']=_0x193a76['oauthTokenSecret']):Y('argument-error'),_0x1c7bd3;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0xe18251){const _0x341ed3=typeof _0xe18251=='string'?JSON['parse'](_0xe18251):_0xe18251,{providerId:_0x5c9fa4,signInMethod:_0x9d0bb7,..._0x48d49b}=_0x341ed3;if(!_0x5c9fa4||!_0x9d0bb7)return null;const _0xe65fb=new $e(_0x5c9fa4,_0x9d0bb7);return _0xe65fb['idToken']=_0x48d49b['idToken']||void 0x0,_0xe65fb['accessToken']=_0x48d49b['accessToken']||void 0x0,_0xe65fb['secret']=_0x48d49b['secret'],_0xe65fb['nonce']=_0x48d49b['nonce'],_0xe65fb['pendingToken']=_0x48d49b['pendingToken']||null,_0xe65fb;}['_getIdTokenResponse'](_0x4ef887){const _0x419fcc=this['buildRequest']();return nt(_0x4ef887,_0x419fcc);}['_linkToIdToken'](_0x344632,_0x43cbd1){const _0x50edc7=this['buildRequest']();return _0x50edc7['idToken']=_0x43cbd1,nt(_0x344632,_0x50edc7);}['_getReauthenticationResolver'](_0xf0254){const _0x5422fc=this['buildRequest']();return _0x5422fc['autoCreate']=!0x1,nt(_0xf0254,_0x5422fc);}['buildRequest'](){const _0x54c872={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x54c872['pendingToken']=this['pendingToken'];else{const _0x53be80={};this['idToken']&&(_0x53be80['id_token']=this['idToken']),this['accessToken']&&(_0x53be80['access_token']=this['accessToken']),this['secret']&&(_0x53be80['oauth_token_secret']=this['secret']),_0x53be80['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x53be80['nonce']=this['nonce']),_0x54c872['postBody']=ut(_0x53be80);}return _0x54c872;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x49ed8c){switch(_0x49ed8c){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x36e81c){const _0x43c095=Ct(Tt(_0x36e81c))['link'],_0x532931=_0x43c095?Ct(Tt(_0x43c095))['deep_link_id']:null,_0xf36601=Ct(Tt(_0x36e81c))['deep_link_id'];return(_0xf36601?Ct(Tt(_0xf36601))['link']:null)||_0xf36601||_0x532931||_0x43c095||_0x36e81c;}class Rs{constructor(_0x1de4f9){const _0x3bf403=Ct(Tt(_0x1de4f9)),_0x4bbb34=_0x3bf403['apiKey']??null,_0x826ac2=_0x3bf403['oobCode']??null,_0x4ab38d=Jf(_0x3bf403['mode']??null);m(_0x4bbb34&&_0x826ac2&&_0x4ab38d,'argument-error'),this['apiKey']=_0x4bbb34,this['operation']=_0x4ab38d,this['code']=_0x826ac2,this['continueUrl']=_0x3bf403['continueUrl']??null,this['languageCode']=_0x3bf403['lang']??null,this['tenantId']=_0x3bf403['tenantId']??null;}static['parseLink'](_0x5c52fb){const _0x4ed6c8=Xf(_0x5c52fb);try{return new Rs(_0x4ed6c8);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0x17e8d9,_0x14e442){return $t['_fromEmailAndPassword'](_0x17e8d9,_0x14e442);}static['credentialWithLink'](_0x986e0c,_0x120ac7){const _0x1e6db3=Rs['parseLink'](_0x120ac7);return m(_0x1e6db3,'argument-error'),$t['_fromEmailAndCode'](_0x986e0c,_0x1e6db3['code'],_0x1e6db3['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x14ddd4){this['providerId']=_0x14ddd4,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x5d6f41){this['defaultLanguageCode']=_0x5d6f41;}['setCustomParameters'](_0x48bfdc){return this['customParameters']=_0x48bfdc,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x58112c){return this['scopes']['includes'](_0x58112c)||this['scopes']['push'](_0x58112c),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x2c26a8){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x2c26a8});}static['credentialFromResult'](_0x101c09){return ue['credentialFromTaggedObject'](_0x101c09);}static['credentialFromError'](_0x1beb52){return ue['credentialFromTaggedObject'](_0x1beb52['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x52a38c}){if(!_0x52a38c||!('oauthAccessToken'in _0x52a38c)||!_0x52a38c['oauthAccessToken'])return null;try{return ue['credential'](_0x52a38c['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x29d73a,_0x562846){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x29d73a,'accessToken':_0x562846});}static['credentialFromResult'](_0x51d2bb){return de['credentialFromTaggedObject'](_0x51d2bb);}static['credentialFromError'](_0x5d9250){return de['credentialFromTaggedObject'](_0x5d9250['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x55c0a1}){if(!_0x55c0a1)return null;const {oauthIdToken:_0x491492,oauthAccessToken:_0x310ca0}=_0x55c0a1;if(!_0x491492&&!_0x310ca0)return null;try{return de['credential'](_0x491492,_0x310ca0);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x487e39){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x487e39});}static['credentialFromResult'](_0x445f60){return fe['credentialFromTaggedObject'](_0x445f60);}static['credentialFromError'](_0x26bacc){return fe['credentialFromTaggedObject'](_0x26bacc['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4cb6cc}){if(!_0x4cb6cc||!('oauthAccessToken'in _0x4cb6cc)||!_0x4cb6cc['oauthAccessToken'])return null;try{return fe['credential'](_0x4cb6cc['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x1beec8,_0x4ab7b4){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x1beec8,'oauthTokenSecret':_0x4ab7b4});}static['credentialFromResult'](_0x266d84){return pe['credentialFromTaggedObject'](_0x266d84);}static['credentialFromError'](_0x4eab52){return pe['credentialFromTaggedObject'](_0x4eab52['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x28ce5e}){if(!_0x28ce5e)return null;const {oauthAccessToken:_0x488953,oauthTokenSecret:_0x1d6e34}=_0x28ce5e;if(!_0x488953||!_0x1d6e34)return null;try{return pe['credential'](_0x488953,_0x1d6e34);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x5461ea,_0x11aa0d){return en(_0x5461ea,'POST','/v1/accounts:signUp',ke(_0x5461ea,_0x11aa0d));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x5d2988){this['user']=_0x5d2988['user'],this['providerId']=_0x5d2988['providerId'],this['_tokenResponse']=_0x5d2988['_tokenResponse'],this['operationType']=_0x5d2988['operationType'];}static async['_fromIdTokenResponse'](_0xb662c1,_0x3b4a84,_0x30ee19,_0x3caf83=!0x1){const _0x366edb=await j['_fromIdTokenResponse'](_0xb662c1,_0x30ee19,_0x3caf83),_0x96a900=Nr(_0x30ee19);return new Ge({'user':_0x366edb,'providerId':_0x96a900,'_tokenResponse':_0x30ee19,'operationType':_0x3b4a84});}static async['_forOperation'](_0x3238fe,_0x268d00,_0x42484f){await _0x3238fe['_updateTokensIfNecessary'](_0x42484f,!0x0);const _0x217600=Nr(_0x42484f);return new Ge({'user':_0x3238fe,'providerId':_0x217600,'_tokenResponse':_0x42484f,'operationType':_0x268d00});}}function Nr(_0x52b8f2){return _0x52b8f2['providerId']?_0x52b8f2['providerId']:'phoneNumber'in _0x52b8f2?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x131933,_0x9e2c84,_0x2c13a9,_0x1d8733){super(_0x9e2c84['code'],_0x9e2c84['message']),this['operationType']=_0x2c13a9,this['user']=_0x1d8733,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x131933['name'],'tenantId':_0x131933['tenantId']??void 0x0,'_serverResponse':_0x9e2c84['customData']['_serverResponse'],'operationType':_0x2c13a9};}static['_fromErrorAndOperation'](_0x40466b,_0x5312b1,_0x4ee525,_0x102cae){return new On(_0x40466b,_0x5312b1,_0x4ee525,_0x102cae);}}function Ba(_0x6fae67,_0x519970,_0x59705e,_0x6c135e){return(_0x519970==='reauthenticate'?_0x59705e['_getReauthenticationResolver'](_0x6fae67):_0x59705e['_getIdTokenResponse'](_0x6fae67))['catch'](_0x130aaf=>{throw _0x130aaf['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x6fae67,_0x130aaf,_0x519970,_0x6c135e):_0x130aaf;});}async function ep(_0xefd1aa,_0x4cf9e2,_0x321570=!0x1){const _0x16c042=await Ht(_0xefd1aa,_0x4cf9e2['_linkToIdToken'](_0xefd1aa['auth'],await _0xefd1aa['getIdToken']()),_0x321570);return Ge['_forOperation'](_0xefd1aa,'link',_0x16c042);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x3af989,_0x5b5ea0,_0x5ef9fe=!0x1){const {auth:_0x1caada}=_0x3af989;if($(_0x1caada['app']))return Promise['reject'](re(_0x1caada));const _0x2abc24='reauthenticate';try{const _0x28576e=await Ht(_0x3af989,Ba(_0x1caada,_0x2abc24,_0x5b5ea0,_0x3af989),_0x5ef9fe);m(_0x28576e['idToken'],_0x1caada,'internal-error');const _0x1a8b5f=Ts(_0x28576e['idToken']);m(_0x1a8b5f,_0x1caada,'internal-error');const {sub:_0x4758c8}=_0x1a8b5f;return m(_0x3af989['uid']===_0x4758c8,_0x1caada,'user-mismatch'),Ge['_forOperation'](_0x3af989,_0x2abc24,_0x28576e);}catch(_0x251509){throw(_0x251509==null?void 0x0:_0x251509['code'])==='auth/user-not-found'&&Y(_0x1caada,'user-mismatch'),_0x251509;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x51557b,_0x5cd791,_0x4bef06=!0x1){if($(_0x51557b['app']))return Promise['reject'](re(_0x51557b));const _0x33fa33='signIn',_0x5dffd1=await Ba(_0x51557b,_0x33fa33,_0x5cd791),_0x1378c4=await Ge['_fromIdTokenResponse'](_0x51557b,_0x33fa33,_0x5dffd1);return _0x4bef06||await _0x51557b['_updateCurrentUser'](_0x1378c4['user']),_0x1378c4;}async function np(_0x7bb3e0,_0x2e5b50){return Va(Ke(_0x7bb3e0),_0x2e5b50);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x5827ff){const _0x3783c0=Ke(_0x5827ff);_0x3783c0['_getPasswordPolicyInternal']()&&await _0x3783c0['_updatePasswordPolicy']();}async function L_(_0x396066,_0x474fa5,_0x52077a){if($(_0x396066['app']))return Promise['reject'](re(_0x396066));const _0x4c9bd0=Ke(_0x396066),_0x59587c=await xi(_0x4c9bd0,{'returnSecureToken':!0x0,'email':_0x474fa5,'password':_0x52077a,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x3b991f=>{throw _0x3b991f['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x396066),_0x3b991f;}),_0x2e45fb=await Ge['_fromIdTokenResponse'](_0x4c9bd0,'signIn',_0x59587c);return await _0x4c9bd0['_updateCurrentUser'](_0x2e45fb['user']),_0x2e45fb;}function x_(_0x3adf0c,_0x5d9720,_0x446ffb){return $(_0x3adf0c['app'])?Promise['reject'](re(_0x3adf0c)):np(P(_0x3adf0c),yt['credential'](_0x5d9720,_0x446ffb))['catch'](async _0x2174e6=>{throw _0x2174e6['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x3adf0c),_0x2174e6;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x4653ab,_0x38100c){return P(_0x4653ab)['setPersistence'](_0x38100c);}function ip(_0x2a8003,_0x559409,_0x372aaf,_0x196bcd){return P(_0x2a8003)['onIdTokenChanged'](_0x559409,_0x372aaf,_0x196bcd);}function sp(_0x5a88cc,_0x47bb41,_0x2858f3){return P(_0x5a88cc)['beforeAuthStateChanged'](_0x47bb41,_0x2858f3);}function U_(_0x21258c,_0x1a21c8,_0x5a29ca,_0x5c4ce4){return P(_0x21258c)['onAuthStateChanged'](_0x1a21c8,_0x5a29ca,_0x5c4ce4);}function W_(_0x1cb43b){return P(_0x1cb43b)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x3424c6,_0x43518a){this['storageRetriever']=_0x3424c6,this['type']=_0x43518a;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x1cd0df,_0x320abb){return this['storage']['setItem'](_0x1cd0df,JSON['stringify'](_0x320abb)),Promise['resolve']();}['_get'](_0x59b9c7){const _0x33e62e=this['storage']['getItem'](_0x59b9c7);return Promise['resolve'](_0x33e62e?JSON['parse'](_0x33e62e):null);}['_remove'](_0x295846){return this['storage']['removeItem'](_0x295846),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x12c4bd,_0x3a5c18)=>this['onStorageEvent'](_0x12c4bd,_0x3a5c18),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x51408b){for(const _0x207460 of Object['keys'](this['listeners'])){const _0x1af2a0=this['storage']['getItem'](_0x207460),_0x2d2f94=this['localCache'][_0x207460];_0x1af2a0!==_0x2d2f94&&_0x51408b(_0x207460,_0x2d2f94,_0x1af2a0);}}['onStorageEvent'](_0x1e78ea,_0x5d0022=!0x1){if(!_0x1e78ea['key']){this['forAllChangedKeys']((_0x1f6fef,_0x5d5efb,_0x403da3)=>{this['notifyListeners'](_0x1f6fef,_0x403da3);});return;}const _0x57558f=_0x1e78ea['key'];_0x5d0022?this['detachListener']():this['stopPolling']();const _0x5a1985=()=>{const _0x14e03b=this['storage']['getItem'](_0x57558f);!_0x5d0022&&this['localCache'][_0x57558f]===_0x14e03b||this['notifyListeners'](_0x57558f,_0x14e03b);},_0x3eda56=this['storage']['getItem'](_0x57558f);Af()&&_0x3eda56!==_0x1e78ea['newValue']&&_0x1e78ea['newValue']!==_0x1e78ea['oldValue']?setTimeout(_0x5a1985,op):_0x5a1985();}['notifyListeners'](_0xd68627,_0x1464b9){this['localCache'][_0xd68627]=_0x1464b9;const _0x3f252b=this['listeners'][_0xd68627];if(_0x3f252b){for(const _0x34bb0c of Array['from'](_0x3f252b))_0x34bb0c(_0x1464b9&&JSON['parse'](_0x1464b9));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x3f1cee,_0x34575e,_0x2f8019)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x3f1cee,'oldValue':_0x34575e,'newValue':_0x2f8019}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x9bfa9d,_0x2977bd){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x9bfa9d]||(this['listeners'][_0x9bfa9d]=new Set(),this['localCache'][_0x9bfa9d]=this['storage']['getItem'](_0x9bfa9d)),this['listeners'][_0x9bfa9d]['add'](_0x2977bd);}['_removeListener'](_0x2532ea,_0x497be1){this['listeners'][_0x2532ea]&&(this['listeners'][_0x2532ea]['delete'](_0x497be1),this['listeners'][_0x2532ea]['size']===0x0&&delete this['listeners'][_0x2532ea]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x22b961,_0xfba4b4){await super['_set'](_0x22b961,_0xfba4b4),this['localCache'][_0x22b961]=JSON['stringify'](_0xfba4b4);}async['_get'](_0x1e83cb){const _0x4ad03e=await super['_get'](_0x1e83cb);return this['localCache'][_0x1e83cb]=JSON['stringify'](_0x4ad03e),_0x4ad03e;}async['_remove'](_0x2f1714){await super['_remove'](_0x2f1714),delete this['localCache'][_0x2f1714];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x39dec9,_0x4cf33b){}['_removeListener'](_0x1ead52,_0x3a11d2){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x59abd8){return Promise['all'](_0x59abd8['map'](async _0x3908da=>{try{return{'fulfilled':!0x0,'value':await _0x3908da};}catch(_0x109f9c){return{'fulfilled':!0x1,'reason':_0x109f9c};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0xea188f){this['eventTarget']=_0xea188f,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x3c4a6c){const _0x1a187b=this['receivers']['find'](_0x454075=>_0x454075['isListeningto'](_0x3c4a6c));if(_0x1a187b)return _0x1a187b;const _0x135cbc=new Xn(_0x3c4a6c);return this['receivers']['push'](_0x135cbc),_0x135cbc;}['isListeningto'](_0x1cdb3d){return this['eventTarget']===_0x1cdb3d;}async['handleEvent'](_0x5b4f45){const _0x5d50fe=_0x5b4f45,{eventId:_0x270547,eventType:_0x3e6482,data:_0x534423}=_0x5d50fe['data'],_0x6e733=this['handlersMap'][_0x3e6482];if(!(_0x6e733!=null&&_0x6e733['size']))return;_0x5d50fe['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x270547,'eventType':_0x3e6482});const _0x1219bc=Array['from'](_0x6e733)['map'](async _0x2823f6=>_0x2823f6(_0x5d50fe['origin'],_0x534423)),_0x5a3bf9=await cp(_0x1219bc);_0x5d50fe['ports'][0x0]['postMessage']({'status':'done','eventId':_0x270547,'eventType':_0x3e6482,'response':_0x5a3bf9});}['_subscribe'](_0x3ee5e5,_0xca3358){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x3ee5e5]||(this['handlersMap'][_0x3ee5e5]=new Set()),this['handlersMap'][_0x3ee5e5]['add'](_0xca3358);}['_unsubscribe'](_0x1ff99a,_0x58ec2a){this['handlersMap'][_0x1ff99a]&&_0x58ec2a&&this['handlersMap'][_0x1ff99a]['delete'](_0x58ec2a),(!_0x58ec2a||this['handlersMap'][_0x1ff99a]['size']===0x0)&&delete this['handlersMap'][_0x1ff99a],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x30d9a8='',_0x1de341=0xa){let _0x47ec4e='';for(let _0x2dc986=0x0;_0x2dc986<_0x1de341;_0x2dc986++)_0x47ec4e+=Math['floor'](Math['random']()*0xa);return _0x30d9a8+_0x47ec4e;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x348acc){this['target']=_0x348acc,this['handlers']=new Set();}['removeMessageHandler'](_0x2979d5){_0x2979d5['messageChannel']&&(_0x2979d5['messageChannel']['port1']['removeEventListener']('message',_0x2979d5['onMessage']),_0x2979d5['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x2979d5);}async['_send'](_0x18e22a,_0x14f2b1,_0x162ef9=0x32){const _0x451966=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x451966)throw new Error('connection_unavailable');let _0x4f65cf,_0x2f1329;return new Promise((_0x2585cb,_0x2272dd)=>{const _0x7b651e=As('',0x14);_0x451966['port1']['start']();const _0x10f0fd=setTimeout(()=>{_0x2272dd(new Error('unsupported_event'));},_0x162ef9);_0x2f1329={'messageChannel':_0x451966,'onMessage'(_0xd44440){const _0x480c09=_0xd44440;if(_0x480c09['data']['eventId']===_0x7b651e)switch(_0x480c09['data']['status']){case'ack':clearTimeout(_0x10f0fd),_0x4f65cf=setTimeout(()=>{_0x2272dd(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x4f65cf),_0x2585cb(_0x480c09['data']['response']);break;default:clearTimeout(_0x10f0fd),clearTimeout(_0x4f65cf),_0x2272dd(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x2f1329),_0x451966['port1']['addEventListener']('message',_0x2f1329['onMessage']),this['target']['postMessage']({'eventType':_0x18e22a,'eventId':_0x7b651e,'data':_0x14f2b1},[_0x451966['port2']]);})['finally'](()=>{_0x2f1329&&this['removeMessageHandler'](_0x2f1329);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x354cf2){Z()['location']['href']=_0x354cf2;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x20ac56;return((_0x20ac56=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x20ac56['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x4bad05){this['request']=_0x4bad05;}['toPromise'](){return new Promise((_0xcc0d1,_0x222ad5)=>{this['request']['addEventListener']('success',()=>{_0xcc0d1(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x222ad5(this['request']['error']);});});}}function Zn(_0x57e24f,_0x523aa1){return _0x57e24f['transaction']([Mn],_0x523aa1?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x34b2c7=indexedDB['deleteDatabase'](Ka);return new nn(_0x34b2c7)['toPromise']();}function Qa(){const _0x26e998=indexedDB['open'](Ka,pp);return new Promise((_0x29743e,_0x30c8ef)=>{_0x26e998['addEventListener']('error',()=>{_0x30c8ef(_0x26e998['error']);}),_0x26e998['addEventListener']('upgradeneeded',()=>{const _0x2f2e8b=_0x26e998['result'];try{_0x2f2e8b['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x34b38c){_0x30c8ef(_0x34b38c);}}),_0x26e998['addEventListener']('success',async()=>{const _0x27ffb8=_0x26e998['result'];_0x27ffb8['objectStoreNames']['contains'](Mn)?_0x29743e(_0x27ffb8):(_0x27ffb8['close'](),await _p(),_0x29743e(await Qa()));});});}async function Or(_0x2312a9,_0x1d369e,_0x505de1){const _0x44b6c3=Zn(_0x2312a9,!0x0)['put']({[Ya]:_0x1d369e,'value':_0x505de1});return new nn(_0x44b6c3)['toPromise']();}async function gp(_0x41ad54,_0x186b2c){const _0xdf8c16=Zn(_0x41ad54,!0x1)['get'](_0x186b2c),_0x22be3c=await new nn(_0xdf8c16)['toPromise']();return _0x22be3c===void 0x0?null:_0x22be3c['value'];}function Dr(_0x2be8fa,_0x286000){const _0x1a44e2=Zn(_0x2be8fa,!0x0)['delete'](_0x286000);return new nn(_0x1a44e2)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x5547af){let _0x473b47=0x0;for(;;)try{const _0x27746a=await this['_openDb']();return await _0x5547af(_0x27746a);}catch(_0x24ce4d){if(_0x473b47++>yp)throw _0x24ce4d;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0xad5ce7,_0x1ec2a5)=>({'keyProcessed':(await this['_poll']())['includes'](_0x1ec2a5['key'])})),this['receiver']['_subscribe']('ping',async(_0x1a2683,_0xfce586)=>['keyChanged']);}async['initializeSender'](){var _0x40d8a1,_0x258ff5;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x294ae9=await this['sender']['_send']('ping',{},0x320);_0x294ae9&&(_0x40d8a1=_0x294ae9[0x0])!=null&&_0x40d8a1['fulfilled']&&(_0x258ff5=_0x294ae9[0x0])!=null&&_0x258ff5['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x1e929c){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x1e929c},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x6f1250=>{await Or(_0x6f1250,Dn,'1'),await Dr(_0x6f1250,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x51fdcd){this['pendingWrites']++;try{await _0x51fdcd();}finally{this['pendingWrites']--;}}async['_set'](_0xe295c1,_0x1aeb50){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x48383b=>Or(_0x48383b,_0xe295c1,_0x1aeb50)),this['localCache'][_0xe295c1]=_0x1aeb50,this['notifyServiceWorker'](_0xe295c1)));}async['_get'](_0x480257){const _0x42fb38=await this['_withRetries'](_0x37d91a=>gp(_0x37d91a,_0x480257));return this['localCache'][_0x480257]=_0x42fb38,_0x42fb38;}async['_remove'](_0xab7c28){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x4fddc1=>Dr(_0x4fddc1,_0xab7c28)),delete this['localCache'][_0xab7c28],this['notifyServiceWorker'](_0xab7c28)));}async['_poll'](){const _0x54028a=await this['_withRetries'](_0x2b6a47=>{const _0x25cb65=Zn(_0x2b6a47,!0x1)['getAll']();return new nn(_0x25cb65)['toPromise']();});if(!_0x54028a)return[];if(this['pendingWrites']!==0x0)return[];const _0x36295f=[],_0x47eace=new Set();if(_0x54028a['length']!==0x0){for(const {fbase_key:_0x4e0550,value:_0x5ae797}of _0x54028a)_0x47eace['add'](_0x4e0550),JSON['stringify'](this['localCache'][_0x4e0550])!==JSON['stringify'](_0x5ae797)&&(this['notifyListeners'](_0x4e0550,_0x5ae797),_0x36295f['push'](_0x4e0550));}for(const _0x434aab of Object['keys'](this['localCache']))this['localCache'][_0x434aab]&&!_0x47eace['has'](_0x434aab)&&(this['notifyListeners'](_0x434aab,null),_0x36295f['push'](_0x434aab));return _0x36295f;}['notifyListeners'](_0xf726a7,_0x3365f6){this['localCache'][_0xf726a7]=_0x3365f6;const _0x43c4f8=this['listeners'][_0xf726a7];if(_0x43c4f8){for(const _0x1ca175 of Array['from'](_0x43c4f8))_0x1ca175(_0x3365f6);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x13666e,_0x1da9bb){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x13666e]||(this['listeners'][_0x13666e]=new Set(),this['_get'](_0x13666e)),this['listeners'][_0x13666e]['add'](_0x1da9bb);}['_removeListener'](_0x360d4a,_0x3f8790){this['listeners'][_0x360d4a]&&(this['listeners'][_0x360d4a]['delete'](_0x3f8790),this['listeners'][_0x360d4a]['size']===0x0&&delete this['listeners'][_0x360d4a]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0xbbfa2c,_0x381d8f){return _0x381d8f?ie(_0x381d8f):(m(_0xbbfa2c['_popupRedirectResolver'],_0xbbfa2c,'argument-error'),_0xbbfa2c['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x5166c2){super('custom','custom'),this['params']=_0x5166c2;}['_getIdTokenResponse'](_0x585ea8){return nt(_0x585ea8,this['_buildIdpRequest']());}['_linkToIdToken'](_0x239067,_0x20d00a){return nt(_0x239067,this['_buildIdpRequest'](_0x20d00a));}['_getReauthenticationResolver'](_0x5495d0){return nt(_0x5495d0,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x3d45c5){const _0x58d4d2={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x3d45c5&&(_0x58d4d2['idToken']=_0x3d45c5),_0x58d4d2;}}function Ip(_0x64d890){return Va(_0x64d890['auth'],new ks(_0x64d890),_0x64d890['bypassAuthState']);}function wp(_0x487c9b){const {auth:_0x562e09,user:_0x164295}=_0x487c9b;return m(_0x164295,_0x562e09,'internal-error'),tp(_0x164295,new ks(_0x487c9b),_0x487c9b['bypassAuthState']);}async function Cp(_0x39b6f7){const {auth:_0x1ae11e,user:_0x185b5b}=_0x39b6f7;return m(_0x185b5b,_0x1ae11e,'internal-error'),ep(_0x185b5b,new ks(_0x39b6f7),_0x39b6f7['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0x110256,_0x4aa01f,_0x356586,_0x20c2a8,_0x3a3e0a=!0x1){this['auth']=_0x110256,this['resolver']=_0x356586,this['user']=_0x20c2a8,this['bypassAuthState']=_0x3a3e0a,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x4aa01f)?_0x4aa01f:[_0x4aa01f];}['execute'](){return new Promise(async(_0x1c5fb2,_0x2a904)=>{this['pendingPromise']={'resolve':_0x1c5fb2,'reject':_0x2a904};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x5376d9){this['reject'](_0x5376d9);}});}async['onAuthEvent'](_0x1aee67){const {urlResponse:_0x558b3a,sessionId:_0x1fe07b,postBody:_0x1f7eef,tenantId:_0x340a29,error:_0x2f617b,type:_0x40ad63}=_0x1aee67;if(_0x2f617b){this['reject'](_0x2f617b);return;}const _0x19814c={'auth':this['auth'],'requestUri':_0x558b3a,'sessionId':_0x1fe07b,'tenantId':_0x340a29||void 0x0,'postBody':_0x1f7eef||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x40ad63)(_0x19814c));}catch(_0x6613ee){this['reject'](_0x6613ee);}}['onError'](_0x3d636a){this['reject'](_0x3d636a);}['getIdpTask'](_0x127a58){switch(_0x127a58){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x5a5bb7){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x5a5bb7),this['unregisterAndCleanUp']();}['reject'](_0x40f32c){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x40f32c),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x4e57bd,_0x227c68,_0x33b6dd,_0x6eafb4,_0x31920f){super(_0x4e57bd,_0x227c68,_0x6eafb4,_0x31920f),this['provider']=_0x33b6dd,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x3d9fcb=await this['execute']();return m(_0x3d9fcb,this['auth'],'internal-error'),_0x3d9fcb;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x50ad77=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x50ad77),this['authWindow']['associatedEvent']=_0x50ad77,this['resolver']['_originValidation'](this['auth'])['catch'](_0x37c4ec=>{this['reject'](_0x37c4ec);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x1488f4=>{_0x1488f4||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0xc3f37a;return((_0xc3f37a=this['authWindow'])==null?void 0x0:_0xc3f37a['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x4544c2=()=>{var _0x2c1ded,_0x5ed739;if((_0x5ed739=(_0x2c1ded=this['authWindow'])==null?void 0x0:_0x2c1ded['window'])!=null&&_0x5ed739['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x4544c2,Tp['get']());};_0x4544c2();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x571e62,_0x3da704,_0x2bf7d0=!0x1){super(_0x571e62,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x3da704,void 0x0,_0x2bf7d0),this['eventId']=null;}async['execute'](){let _0x325a14=hn['get'](this['auth']['_key']());if(!_0x325a14){try{const _0x2a5f3b=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x325a14=()=>Promise['resolve'](_0x2a5f3b);}catch(_0x349f3b){_0x325a14=()=>Promise['reject'](_0x349f3b);}hn['set'](this['auth']['_key'](),_0x325a14);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x325a14();}async['onAuthEvent'](_0x41c8fc){if(_0x41c8fc['type']==='signInViaRedirect')return super['onAuthEvent'](_0x41c8fc);if(_0x41c8fc['type']==='unknown'){this['resolve'](null);return;}if(_0x41c8fc['eventId']){const _0x3cfce5=await this['auth']['_redirectUserForId'](_0x41c8fc['eventId']);if(_0x3cfce5)return this['user']=_0x3cfce5,super['onAuthEvent'](_0x41c8fc);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x259717,_0xb6c224){const _0x22de96=Pp(_0xb6c224),_0x6849df=kp(_0x259717);if(!await _0x6849df['_isAvailable']())return!0x1;const _0x1cd04a=await _0x6849df['_get'](_0x22de96)==='true';return await _0x6849df['_remove'](_0x22de96),_0x1cd04a;}function Ap(_0x304ff6,_0x414cbf){hn['set'](_0x304ff6['_key'](),_0x414cbf);}function kp(_0x501b8c){return ie(_0x501b8c['_redirectPersistence']);}function Pp(_0x2b838a){return ln(Sp,_0x2b838a['config']['apiKey'],_0x2b838a['name']);}async function Np(_0x26aeb8,_0x3a595d,_0x57bff2=!0x1){if($(_0x26aeb8['app']))return Promise['reject'](re(_0x26aeb8));const _0x515e54=Ke(_0x26aeb8),_0x30cdb4=Ep(_0x515e54,_0x3a595d),_0x5ab958=await new bp(_0x515e54,_0x30cdb4,_0x57bff2)['execute']();return _0x5ab958&&!_0x57bff2&&(delete _0x5ab958['user']['_redirectEventId'],await _0x515e54['_persistUserIfCurrent'](_0x5ab958['user']),await _0x515e54['_setRedirectUser'](null,_0x3a595d)),_0x5ab958;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x3047f0){this['auth']=_0x3047f0,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x4576d5){this['consumers']['add'](_0x4576d5),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x4576d5)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x4576d5),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x369034){this['consumers']['delete'](_0x369034);}['onEvent'](_0x263561){if(this['hasEventBeenHandled'](_0x263561))return!0x1;let _0x5b341b=!0x1;return this['consumers']['forEach'](_0x13db29=>{this['isEventForConsumer'](_0x263561,_0x13db29)&&(_0x5b341b=!0x0,this['sendToConsumer'](_0x263561,_0x13db29),this['saveEventToCache'](_0x263561));}),this['hasHandledPotentialRedirect']||!Mp(_0x263561)||(this['hasHandledPotentialRedirect']=!0x0,_0x5b341b||(this['queuedRedirectEvent']=_0x263561,_0x5b341b=!0x0)),_0x5b341b;}['sendToConsumer'](_0x166735,_0x4ca060){var _0x3de60f;if(_0x166735['error']&&!Za(_0x166735)){const _0x43a92f=((_0x3de60f=_0x166735['error']['code'])==null?void 0x0:_0x3de60f['split']('auth/')[0x1])||'internal-error';_0x4ca060['onError'](X(this['auth'],_0x43a92f));}else _0x4ca060['onAuthEvent'](_0x166735);}['isEventForConsumer'](_0x3901d3,_0x8eef5a){const _0x1c7d7c=_0x8eef5a['eventId']===null||!!_0x3901d3['eventId']&&_0x3901d3['eventId']===_0x8eef5a['eventId'];return _0x8eef5a['filter']['includes'](_0x3901d3['type'])&&_0x1c7d7c;}['hasEventBeenHandled'](_0xb0a71a){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0xb0a71a));}['saveEventToCache'](_0x59d982){this['cachedEventUids']['add'](Mr(_0x59d982)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x399f16){return[_0x399f16['type'],_0x399f16['eventId'],_0x399f16['sessionId'],_0x399f16['tenantId']]['filter'](_0x32f57b=>_0x32f57b)['join']('-');}function Za({type:_0x53f565,error:_0x3aa566}){return _0x53f565==='unknown'&&(_0x3aa566==null?void 0x0:_0x3aa566['code'])==='auth/no-auth-event';}function Mp(_0x3b9aad){switch(_0x3b9aad['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x3b9aad);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0x5bc256,_0x3a9c3a={}){return Pe(_0x5bc256,'GET','/v1/projects',_0x3a9c3a);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x372b7f){if(_0x372b7f['config']['emulator'])return;const {authorizedDomains:_0x57dbeb}=await Lp(_0x372b7f);for(const _0x150320 of _0x57dbeb)try{if(Wp(_0x150320))return;}catch{}Y(_0x372b7f,'unauthorized-domain');}function Wp(_0x32b60c){const _0x44e529=Mi(),{protocol:_0x2147fe,hostname:_0x186434}=new URL(_0x44e529);if(_0x32b60c['startsWith']('chrome-extension://')){const _0x1c3263=new URL(_0x32b60c);return _0x1c3263['hostname']===''&&_0x186434===''?_0x2147fe==='chrome-extension:'&&_0x32b60c['replace']('chrome-extension://','')===_0x44e529['replace']('chrome-extension://',''):_0x2147fe==='chrome-extension:'&&_0x1c3263['hostname']===_0x186434;}if(!Fp['test'](_0x2147fe))return!0x1;if(xp['test'](_0x32b60c))return _0x186434===_0x32b60c;const _0x52e794=_0x32b60c['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x52e794+'|'+_0x52e794+')$','i')['test'](_0x186434);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x350681=Z()['___jsl'];if(_0x350681!=null&&_0x350681['H']){for(const _0x4469f0 of Object['keys'](_0x350681['H']))if(_0x350681['H'][_0x4469f0]['r']=_0x350681['H'][_0x4469f0]['r']||[],_0x350681['H'][_0x4469f0]['L']=_0x350681['H'][_0x4469f0]['L']||[],_0x350681['H'][_0x4469f0]['r']=[..._0x350681['H'][_0x4469f0]['L']],_0x350681['CP']){for(let _0x20d2c7=0x0;_0x20d2c7<_0x350681['CP']['length'];_0x20d2c7++)_0x350681['CP'][_0x20d2c7]=null;}}}function Vp(_0x11d570){return new Promise((_0xdd0360,_0x1e21e7)=>{var _0x5b5833,_0x45fbeb,_0x4af221;function _0x5d7fd7(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0xdd0360(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x1e21e7(X(_0x11d570,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x45fbeb=(_0x5b5833=Z()['gapi'])==null?void 0x0:_0x5b5833['iframes'])!=null&&_0x45fbeb['Iframe'])_0xdd0360(gapi['iframes']['getContext']());else{if((_0x4af221=Z()['gapi'])!=null&&_0x4af221['load'])_0x5d7fd7();else{const _0x3c0e6a=Ff('iframefcb');return Z()[_0x3c0e6a]=()=>{gapi['load']?_0x5d7fd7():_0x1e21e7(X(_0x11d570,'network-request-failed'));},xa(xf()+'?onload='+_0x3c0e6a)['catch'](_0x512302=>_0x1e21e7(_0x512302));}}})['catch'](_0x4323f7=>{throw un=null,_0x4323f7;});}let un=null;function Hp(_0x518b01){return un=un||Vp(_0x518b01),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x5ac1a8){const _0x20ff9b=_0x5ac1a8['config'];m(_0x20ff9b['authDomain'],_0x5ac1a8,'auth-domain-config-required');const _0x55b64a=_0x20ff9b['emulator']?Cs(_0x20ff9b,qp):'https://'+_0x5ac1a8['config']['authDomain']+'/'+Gp,_0x288afc={'apiKey':_0x20ff9b['apiKey'],'appName':_0x5ac1a8['name'],'v':dt},_0x590a13=jp['get'](_0x5ac1a8['config']['apiHost']);_0x590a13&&(_0x288afc['eid']=_0x590a13);const _0x1a9c9a=_0x5ac1a8['_getFrameworks']();return _0x1a9c9a['length']&&(_0x288afc['fw']=_0x1a9c9a['join'](',')),_0x55b64a+'?'+ut(_0x288afc)['slice'](0x1);}async function Yp(_0x2ed549){const _0x2af941=await Hp(_0x2ed549),_0x5eb643=Z()['gapi'];return m(_0x5eb643,_0x2ed549,'internal-error'),_0x2af941['open']({'where':document['body'],'url':Kp(_0x2ed549),'messageHandlersFilter':_0x5eb643['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x2b785a=>new Promise(async(_0x2489ae,_0x3b30c1)=>{await _0x2b785a['restyle']({'setHideOnLeave':!0x1});const _0x3702aa=X(_0x2ed549,'network-request-failed'),_0x3ad312=Z()['setTimeout'](()=>{_0x3b30c1(_0x3702aa);},$p['get']());function _0x337154(){Z()['clearTimeout'](_0x3ad312),_0x2489ae(_0x2b785a);}_0x2b785a['ping'](_0x337154)['then'](_0x337154,()=>{_0x3b30c1(_0x3702aa);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x11592d){this['window']=_0x11592d,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0xce2169,_0x582e7f,_0x3c585a,_0x4f840=Jp,_0x556b57=Xp){const _0x55323b=Math['max']((window['screen']['availHeight']-_0x556b57)/0x2,0x0)['toString'](),_0x2b9fd7=Math['max']((window['screen']['availWidth']-_0x4f840)/0x2,0x0)['toString']();let _0x2fe850='';const _0x31f836={...Qp,'width':_0x4f840['toString'](),'height':_0x556b57['toString'](),'top':_0x55323b,'left':_0x2b9fd7},_0x135b6f=W()['toLowerCase']();_0x3c585a&&(_0x2fe850=ka(_0x135b6f)?Zp:_0x3c585a),Ra(_0x135b6f)&&(_0x582e7f=_0x582e7f||e_,_0x31f836['scrollbars']='yes');const _0x153379=Object['entries'](_0x31f836)['reduce']((_0x22dd6e,[_0xcf3c84,_0xbb7a03])=>''+_0x22dd6e+_0xcf3c84+'='+_0xbb7a03+',','');if(Rf(_0x135b6f)&&_0x2fe850!=='_self')return n_(_0x582e7f||'',_0x2fe850),new xr(null);const _0x536899=window['open'](_0x582e7f||'',_0x2fe850,_0x153379);m(_0x536899,_0xce2169,'popup-blocked');try{_0x536899['focus']();}catch{}return new xr(_0x536899);}function n_(_0xf1138b,_0x14d2cd){const _0x470c72=document['createElement']('a');_0x470c72['href']=_0xf1138b,_0x470c72['target']=_0x14d2cd;const _0x25e1a0=document['createEvent']('MouseEvent');_0x25e1a0['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x470c72['dispatchEvent'](_0x25e1a0);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x3ded63,_0x79d8f1,_0x4687ce,_0x2c72a7,_0x38d739,_0x31cb0c){m(_0x3ded63['config']['authDomain'],_0x3ded63,'auth-domain-config-required'),m(_0x3ded63['config']['apiKey'],_0x3ded63,'invalid-api-key');const _0x3145e6={'apiKey':_0x3ded63['config']['apiKey'],'appName':_0x3ded63['name'],'authType':_0x4687ce,'redirectUrl':_0x2c72a7,'v':dt,'eventId':_0x38d739};if(_0x79d8f1 instanceof Wa){_0x79d8f1['setDefaultLanguage'](_0x3ded63['languageCode']),_0x3145e6['providerId']=_0x79d8f1['providerId']||'',pn(_0x79d8f1['getCustomParameters']())||(_0x3145e6['customParameters']=JSON['stringify'](_0x79d8f1['getCustomParameters']()));for(const [_0x118c3f,_0x261479]of Object['entries']({}))_0x3145e6[_0x118c3f]=_0x261479;}if(_0x79d8f1 instanceof tn){const _0x261fc9=_0x79d8f1['getScopes']()['filter'](_0x8a0876=>_0x8a0876!=='');_0x261fc9['length']>0x0&&(_0x3145e6['scopes']=_0x261fc9['join'](','));}_0x3ded63['tenantId']&&(_0x3145e6['tid']=_0x3ded63['tenantId']);const _0x5284e4=_0x3145e6;for(const _0x461211 of Object['keys'](_0x5284e4))_0x5284e4[_0x461211]===void 0x0&&delete _0x5284e4[_0x461211];const _0x31535d=await _0x3ded63['_getAppCheckToken'](),_0x47bb87=_0x31535d?'#'+r_+'='+encodeURIComponent(_0x31535d):'';return o_(_0x3ded63)+'?'+ut(_0x5284e4)['slice'](0x1)+_0x47bb87;}function o_({config:_0x596d46}){return _0x596d46['emulator']?Cs(_0x596d46,s_):'https://'+_0x596d46['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x24b5c4,_0xfd7596,_0x118137,_0x5e64b9){var _0x7f365a;ce((_0x7f365a=this['eventManagers'][_0x24b5c4['_key']()])==null?void 0x0:_0x7f365a['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x551a3f=await Fr(_0x24b5c4,_0xfd7596,_0x118137,Mi(),_0x5e64b9);return t_(_0x24b5c4,_0x551a3f,As());}async['_openRedirect'](_0x1ad01b,_0x50b6b2,_0x58ac9c,_0x309f4c){await this['_originValidation'](_0x1ad01b);const _0x43affc=await Fr(_0x1ad01b,_0x50b6b2,_0x58ac9c,Mi(),_0x309f4c);return hp(_0x43affc),new Promise(()=>{});}['_initialize'](_0x123342){const _0x598582=_0x123342['_key']();if(this['eventManagers'][_0x598582]){const {manager:_0x54d738,promise:_0x5e5766}=this['eventManagers'][_0x598582];return _0x54d738?Promise['resolve'](_0x54d738):(ce(_0x5e5766,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x5e5766);}const _0x31427c=this['initAndGetManager'](_0x123342);return this['eventManagers'][_0x598582]={'promise':_0x31427c},_0x31427c['catch'](()=>{delete this['eventManagers'][_0x598582];}),_0x31427c;}async['initAndGetManager'](_0x323a6b){const _0x383331=await Yp(_0x323a6b),_0x32c510=new Dp(_0x323a6b);return _0x383331['register']('authEvent',_0x242cf3=>(m(_0x242cf3==null?void 0x0:_0x242cf3['authEvent'],_0x323a6b,'invalid-auth-event'),{'status':_0x32c510['onEvent'](_0x242cf3['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x323a6b['_key']()]={'manager':_0x32c510},this['iframes'][_0x323a6b['_key']()]=_0x383331,_0x32c510;}['_isIframeWebStorageSupported'](_0x32e2d2,_0x4eda3a){this['iframes'][_0x32e2d2['_key']()]['send'](pi,{'type':pi},_0x46a503=>{var _0xd3c982;const _0x3db33c=(_0xd3c982=_0x46a503==null?void 0x0:_0x46a503[0x0])==null?void 0x0:_0xd3c982[pi];_0x3db33c!==void 0x0&&_0x4eda3a(!!_0x3db33c),Y(_0x32e2d2,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x59b3a5){const _0x21663f=_0x59b3a5['_key']();return this['originValidationPromises'][_0x21663f]||(this['originValidationPromises'][_0x21663f]=Up(_0x59b3a5)),this['originValidationPromises'][_0x21663f];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x55e191){this['auth']=_0x55e191,this['internalListeners']=new Map();}['getUid'](){var _0x3bfd2b;return this['assertAuthConfigured'](),((_0x3bfd2b=this['auth']['currentUser'])==null?void 0x0:_0x3bfd2b['uid'])||null;}async['getToken'](_0x3e8390){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x3e8390)}:null;}['addAuthTokenListener'](_0x29a686){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x29a686))return;const _0x3ad661=this['auth']['onIdTokenChanged'](_0x2551a4=>{_0x29a686((_0x2551a4==null?void 0x0:_0x2551a4['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x29a686,_0x3ad661),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x3f3cb3){this['assertAuthConfigured']();const _0xb2c147=this['internalListeners']['get'](_0x3f3cb3);_0xb2c147&&(this['internalListeners']['delete'](_0x3f3cb3),_0xb2c147(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x5cb8c9){switch(_0x5cb8c9){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x33c910){st(new Fe('auth',(_0x479356,{options:_0x43b93f})=>{const _0x4ba642=_0x479356['getProvider']('app')['getImmediate'](),_0x1a8440=_0x479356['getProvider']('heartbeat'),_0x47eed1=_0x479356['getProvider']('app-check-internal'),{apiKey:_0x2fc6a0,authDomain:_0x4f4230}=_0x4ba642['options'];m(_0x2fc6a0&&!_0x2fc6a0['includes'](':'),'invalid-api-key',{'appName':_0x4ba642['name']});const _0x1594ee={'apiKey':_0x2fc6a0,'authDomain':_0x4f4230,'clientPlatform':_0x33c910,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x33c910)},_0x44f19e=new Df(_0x4ba642,_0x1a8440,_0x47eed1,_0x1594ee);return Hf(_0x44f19e,_0x43b93f),_0x44f19e;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x53dc70,_0x44f642,_0x39ea6a)=>{_0x53dc70['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x2749fc=>{const _0x2d186a=Ke(_0x2749fc['getProvider']('auth')['getImmediate']());return(_0x447ca8=>new l_(_0x447ca8))(_0x2d186a);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x33c910)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x3e828b=>async _0x1e5323=>{const _0x20fbf6=_0x1e5323&&await _0x1e5323['getIdTokenResult'](),_0x3aa502=_0x20fbf6&&(new Date()['getTime']()-Date['parse'](_0x20fbf6['issuedAtTime']))/0x3e8;if(_0x3aa502&&_0x3aa502>f_)return;const _0x5097b6=_0x20fbf6==null?void 0x0:_0x20fbf6['token'];Br!==_0x5097b6&&(Br=_0x5097b6,await fetch(_0x3e828b,{'method':_0x5097b6?'POST':'DELETE','headers':_0x5097b6?{'Authorization':'Bearer\x20'+_0x5097b6}:{}}));};function B_(_0x49ce46=Zr()){const _0x4902c1=Hi(_0x49ce46,'auth');if(_0x4902c1['isInitialized']())return _0x4902c1['getImmediate']();const _0x14aa27=Vf(_0x49ce46,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x51c867=jr('authTokenSyncURL');if(_0x51c867&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x202d3f=new URL(_0x51c867,location['origin']);if(location['origin']===_0x202d3f['origin']){const _0x125f01=p_(_0x202d3f['toString']());sp(_0x14aa27,_0x125f01,()=>_0x125f01(_0x14aa27['currentUser'])),ip(_0x14aa27,_0x20e684=>_0x125f01(_0x20e684));}}const _0x8f9685=qr('auth');return _0x8f9685&&$f(_0x14aa27,'http://'+_0x8f9685),_0x14aa27;}function __(){var _0x3979f2;return((_0x3979f2=document['getElementsByTagName']('head'))==null?void 0x0:_0x3979f2[0x0])??document;}Mf({'loadJS'(_0x106067){return new Promise((_0x521831,_0x59039d)=>{const _0x51d6a4=document['createElement']('script');_0x51d6a4['setAttribute']('src',_0x106067),_0x51d6a4['onload']=_0x521831,_0x51d6a4['onerror']=_0x4a2d23=>{const _0x50223f=X('internal-error');_0x50223f['customData']=_0x4a2d23,_0x59039d(_0x50223f);},_0x51d6a4['type']='text/javascript',_0x51d6a4['charset']='UTF-8',__()['appendChild'](_0x51d6a4);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,B_ as a,ap as b,x_ as c,g_ as d,m_ as e,Zr as f,P_ as g,Hd as h,Sl as i,D_ as j,Gd as k,w_ as l,b_ as m,A_ as n,v_ as o,E_ as p,k_ as q,y_ as r,F_ as s,Vt as t,I_ as u,N_ as v,U_ as w,O_ as x,M_ as y,T_ as z};