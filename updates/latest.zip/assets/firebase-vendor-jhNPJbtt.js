const tc=()=>{};var Ps={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Vr={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x2bb1e8,_0x1b738f){if(!_0x2bb1e8)throw ht(_0x1b738f);},ht=function(_0x44c723){return new Error('Firebase\x20Database\x20('+Vr['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x44c723);},Hr=function(_0x2ebbbb){const _0x262882=[];let _0x394584=0x0;for(let _0x274434=0x0;_0x274434<_0x2ebbbb['length'];_0x274434++){let _0x432c91=_0x2ebbbb['charCodeAt'](_0x274434);_0x432c91<0x80?_0x262882[_0x394584++]=_0x432c91:_0x432c91<0x800?(_0x262882[_0x394584++]=_0x432c91>>0x6|0xc0,_0x262882[_0x394584++]=_0x432c91&0x3f|0x80):(_0x432c91&0xfc00)===0xd800&&_0x274434+0x1<_0x2ebbbb['length']&&(_0x2ebbbb['charCodeAt'](_0x274434+0x1)&0xfc00)===0xdc00?(_0x432c91=0x10000+((_0x432c91&0x3ff)<<0xa)+(_0x2ebbbb['charCodeAt'](++_0x274434)&0x3ff),_0x262882[_0x394584++]=_0x432c91>>0x12|0xf0,_0x262882[_0x394584++]=_0x432c91>>0xc&0x3f|0x80,_0x262882[_0x394584++]=_0x432c91>>0x6&0x3f|0x80,_0x262882[_0x394584++]=_0x432c91&0x3f|0x80):(_0x262882[_0x394584++]=_0x432c91>>0xc|0xe0,_0x262882[_0x394584++]=_0x432c91>>0x6&0x3f|0x80,_0x262882[_0x394584++]=_0x432c91&0x3f|0x80);}return _0x262882;},nc=function(_0x160c8f){const _0x4437e6=[];let _0x1661ec=0x0,_0x666d7f=0x0;for(;_0x1661ec<_0x160c8f['length'];){const _0xd7fc1b=_0x160c8f[_0x1661ec++];if(_0xd7fc1b<0x80)_0x4437e6[_0x666d7f++]=String['fromCharCode'](_0xd7fc1b);else{if(_0xd7fc1b>0xbf&&_0xd7fc1b<0xe0){const _0x513941=_0x160c8f[_0x1661ec++];_0x4437e6[_0x666d7f++]=String['fromCharCode']((_0xd7fc1b&0x1f)<<0x6|_0x513941&0x3f);}else{if(_0xd7fc1b>0xef&&_0xd7fc1b<0x16d){const _0x54c26=_0x160c8f[_0x1661ec++],_0x318231=_0x160c8f[_0x1661ec++],_0x4e2283=_0x160c8f[_0x1661ec++],_0x16f454=((_0xd7fc1b&0x7)<<0x12|(_0x54c26&0x3f)<<0xc|(_0x318231&0x3f)<<0x6|_0x4e2283&0x3f)-0x10000;_0x4437e6[_0x666d7f++]=String['fromCharCode'](0xd800+(_0x16f454>>0xa)),_0x4437e6[_0x666d7f++]=String['fromCharCode'](0xdc00+(_0x16f454&0x3ff));}else{const _0x47c5ce=_0x160c8f[_0x1661ec++],_0x4f4fce=_0x160c8f[_0x1661ec++];_0x4437e6[_0x666d7f++]=String['fromCharCode']((_0xd7fc1b&0xf)<<0xc|(_0x47c5ce&0x3f)<<0x6|_0x4f4fce&0x3f);}}}}return _0x4437e6['join']('');},Fi={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x36ebdf,_0x3052da){if(!Array['isArray'](_0x36ebdf))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x5bed07=_0x3052da?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x16b624=[];for(let _0x241ade=0x0;_0x241ade<_0x36ebdf['length'];_0x241ade+=0x3){const _0x3db331=_0x36ebdf[_0x241ade],_0x21ab05=_0x241ade+0x1<_0x36ebdf['length'],_0x569f59=_0x21ab05?_0x36ebdf[_0x241ade+0x1]:0x0,_0x1c4bcc=_0x241ade+0x2<_0x36ebdf['length'],_0xda84b5=_0x1c4bcc?_0x36ebdf[_0x241ade+0x2]:0x0,_0x27b4ba=_0x3db331>>0x2,_0x26a7bd=(_0x3db331&0x3)<<0x4|_0x569f59>>0x4;let _0x1d6f5e=(_0x569f59&0xf)<<0x2|_0xda84b5>>0x6,_0x8265cf=_0xda84b5&0x3f;_0x1c4bcc||(_0x8265cf=0x40,_0x21ab05||(_0x1d6f5e=0x40)),_0x16b624['push'](_0x5bed07[_0x27b4ba],_0x5bed07[_0x26a7bd],_0x5bed07[_0x1d6f5e],_0x5bed07[_0x8265cf]);}return _0x16b624['join']('');},'encodeString'(_0x5294c0,_0x40f7e6){return this['HAS_NATIVE_SUPPORT']&&!_0x40f7e6?btoa(_0x5294c0):this['encodeByteArray'](Hr(_0x5294c0),_0x40f7e6);},'decodeString'(_0x4d142d,_0x505d9e){return this['HAS_NATIVE_SUPPORT']&&!_0x505d9e?atob(_0x4d142d):nc(this['decodeStringToByteArray'](_0x4d142d,_0x505d9e));},'decodeStringToByteArray'(_0x5425b0,_0x2f6509){this['init_']();const _0x26b99c=_0x2f6509?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x444ec3=[];for(let _0x4d580b=0x0;_0x4d580b<_0x5425b0['length'];){const _0x840621=_0x26b99c[_0x5425b0['charAt'](_0x4d580b++)],_0x5a9862=_0x4d580b<_0x5425b0['length']?_0x26b99c[_0x5425b0['charAt'](_0x4d580b)]:0x0;++_0x4d580b;const _0x4a0388=_0x4d580b<_0x5425b0['length']?_0x26b99c[_0x5425b0['charAt'](_0x4d580b)]:0x40;++_0x4d580b;const _0x28528a=_0x4d580b<_0x5425b0['length']?_0x26b99c[_0x5425b0['charAt'](_0x4d580b)]:0x40;if(++_0x4d580b,_0x840621==null||_0x5a9862==null||_0x4a0388==null||_0x28528a==null)throw new ic();const _0x210769=_0x840621<<0x2|_0x5a9862>>0x4;if(_0x444ec3['push'](_0x210769),_0x4a0388!==0x40){const _0x12c864=_0x5a9862<<0x4&0xf0|_0x4a0388>>0x2;if(_0x444ec3['push'](_0x12c864),_0x28528a!==0x40){const _0x29e968=_0x4a0388<<0x6&0xc0|_0x28528a;_0x444ec3['push'](_0x29e968);}}}return _0x444ec3;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x737939=0x0;_0x737939<this['ENCODED_VALS']['length'];_0x737939++)this['byteToCharMap_'][_0x737939]=this['ENCODED_VALS']['charAt'](_0x737939),this['charToByteMap_'][this['byteToCharMap_'][_0x737939]]=_0x737939,this['byteToCharMapWebSafe_'][_0x737939]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x737939),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x737939]]=_0x737939,_0x737939>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x737939)]=_0x737939,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x737939)]=_0x737939);}}};class ic extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const $r=function(_0x12d7bb){const _0x4cf733=Hr(_0x12d7bb);return Fi['encodeByteArray'](_0x4cf733,!0x0);},dn=function(_0x37814b){return $r(_0x37814b)['replace'](/\./g,'');},fn=function(_0x30ad26){try{return Fi['decodeString'](_0x30ad26,!0x0);}catch(_0x34c22c){console['error']('base64Decode\x20failed:\x20',_0x34c22c);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(_0x327921){return Gr(void 0x0,_0x327921);}function Gr(_0x8d8bbc,_0x171aaf){if(!(_0x171aaf instanceof Object))return _0x171aaf;switch(_0x171aaf['constructor']){case Date:const _0x5bd7dd=_0x171aaf;return new Date(_0x5bd7dd['getTime']());case Object:_0x8d8bbc===void 0x0&&(_0x8d8bbc={});break;case Array:_0x8d8bbc=[];break;default:return _0x171aaf;}for(const _0x2498b3 in _0x171aaf)!_0x171aaf['hasOwnProperty'](_0x2498b3)||!rc(_0x2498b3)||(_0x8d8bbc[_0x2498b3]=Gr(_0x8d8bbc[_0x2498b3],_0x171aaf[_0x2498b3]));return _0x8d8bbc;}function rc(_0x4a3ed4){return _0x4a3ed4!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function oc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ac=()=>oc()['__FIREBASE_DEFAULTS__'],cc=()=>{if(typeof process>'u'||typeof Ps>'u')return;const _0x59a247=Ps['__FIREBASE_DEFAULTS__'];if(_0x59a247)return JSON['parse'](_0x59a247);},lc=()=>{if(typeof document>'u')return;let _0x35f5c1;try{_0x35f5c1=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x1855ac=_0x35f5c1&&fn(_0x35f5c1[0x1]);return _0x1855ac&&JSON['parse'](_0x1855ac);},Ui=()=>{try{return tc()||ac()||cc()||lc();}catch(_0x56ff4b){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x56ff4b);return;}},qr=_0x5bdf7a=>{var _0x133216,_0x510c2d;return(_0x510c2d=(_0x133216=Ui())==null?void 0x0:_0x133216['emulatorHosts'])==null?void 0x0:_0x510c2d[_0x5bdf7a];},hc=_0x4dcff0=>{const _0x1068da=qr(_0x4dcff0);if(!_0x1068da)return;const _0x483680=_0x1068da['lastIndexOf'](':');if(_0x483680<=0x0||_0x483680+0x1===_0x1068da['length'])throw new Error('Invalid\x20host\x20'+_0x1068da+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x1ef7da=parseInt(_0x1068da['substring'](_0x483680+0x1),0xa);return _0x1068da[0x0]==='['?[_0x1068da['substring'](0x1,_0x483680-0x1),_0x1ef7da]:[_0x1068da['substring'](0x0,_0x483680),_0x1ef7da];},zr=()=>{var _0x52cc50;return(_0x52cc50=Ui())==null?void 0x0:_0x52cc50['config'];},jr=_0x338736=>{var _0x4ca3e6;return(_0x4ca3e6=Ui())==null?void 0x0:_0x4ca3e6['_'+_0x338736];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class H{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x130014,_0x34fea2)=>{this['resolve']=_0x130014,this['reject']=_0x34fea2;});}['wrapCallback'](_0x304d4b){return(_0x7f1727,_0x18379f)=>{_0x7f1727?this['reject'](_0x7f1727):this['resolve'](_0x18379f),typeof _0x304d4b=='function'&&(this['promise']['catch'](()=>{}),_0x304d4b['length']===0x1?_0x304d4b(_0x7f1727):_0x304d4b(_0x7f1727,_0x18379f));};}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function uc(_0x37d578,_0x1edee5){if(_0x37d578['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x326db4={'alg':'none','type':'JWT'},_0x1d555f=_0x1edee5||'demo-project',_0x1b9415=_0x37d578['iat']||0x0,_0x573293=_0x37d578['sub']||_0x37d578['user_id'];if(!_0x573293)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x37032a={'iss':'https://securetoken.google.com/'+_0x1d555f,'aud':_0x1d555f,'iat':_0x1b9415,'exp':_0x1b9415+0xe10,'auth_time':_0x1b9415,'sub':_0x573293,'user_id':_0x573293,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x37d578};return[dn(JSON['stringify'](_0x326db4)),dn(JSON['stringify'](_0x37032a)),'']['join']('.');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Wi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x4b332f=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x4b332f=='object'&&_0x4b332f['id']!==void 0x0;}function Kr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x3d42b5=W();return _0x3d42b5['indexOf']('MSIE\x20')>=0x0||_0x3d42b5['indexOf']('Trident/')>=0x0;}function _c(){return Vr['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x126f58,_0x4378db)=>{try{let _0x4c7113=!0x0;const _0x4d4556='validate-browser-context-for-indexeddb-analytics-module',_0x4d1d01=self['indexedDB']['open'](_0x4d4556);_0x4d1d01['onsuccess']=()=>{_0x4d1d01['result']['close'](),_0x4c7113||self['indexedDB']['deleteDatabase'](_0x4d4556),_0x126f58(!0x0);},_0x4d1d01['onupgradeneeded']=()=>{_0x4c7113=!0x1;},_0x4d1d01['onerror']=()=>{var _0x55062e;_0x4378db(((_0x55062e=_0x4d1d01['error'])==null?void 0x0:_0x55062e['message'])||'');};}catch(_0x163fca){_0x4378db(_0x163fca);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Re extends Error{constructor(_0x327303,_0xda686,_0x1b3579){super(_0xda686),this['code']=_0x327303,this['customData']=_0x1b3579,this['name']=yc,Object['setPrototypeOf'](this,Re['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Gt['prototype']['create']);}}class Gt{constructor(_0x1e0738,_0x1bd9c3,_0x3f2cb4){this['service']=_0x1e0738,this['serviceName']=_0x1bd9c3,this['errors']=_0x3f2cb4;}['create'](_0x4b6325,..._0x50b82d){const _0x5c9f1f=_0x50b82d[0x0]||{},_0x4c9829=this['service']+'/'+_0x4b6325,_0x4f305f=this['errors'][_0x4b6325],_0x7547f6=_0x4f305f?vc(_0x4f305f,_0x5c9f1f):'Error',_0x534551=this['serviceName']+':\x20'+_0x7547f6+'\x20('+_0x4c9829+').';return new Re(_0x4c9829,_0x534551,_0x5c9f1f);}}function vc(_0x2ac08a,_0x1e30e1){return _0x2ac08a['replace'](Ec,(_0x2be02b,_0x168370)=>{const _0x4cbc5e=_0x1e30e1[_0x168370];return _0x4cbc5e!=null?String(_0x4cbc5e):'<'+_0x168370+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Nt(_0x481711){return JSON['parse'](_0x481711);}function O(_0x450c30){return JSON['stringify'](_0x450c30);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yr=function(_0x1fccf2){let _0x57ddbf={},_0x535ed4={},_0x510cda={},_0xbb0515='';try{const _0x314b36=_0x1fccf2['split']('.');_0x57ddbf=Nt(fn(_0x314b36[0x0])||''),_0x535ed4=Nt(fn(_0x314b36[0x1])||''),_0xbb0515=_0x314b36[0x2],_0x510cda=_0x535ed4['d']||{},delete _0x535ed4['d'];}catch{}return{'header':_0x57ddbf,'claims':_0x535ed4,'data':_0x510cda,'signature':_0xbb0515};},Ic=function(_0x563405){const _0x4557ff=Yr(_0x563405),_0x2d0d37=_0x4557ff['claims'];return!!_0x2d0d37&&typeof _0x2d0d37=='object'&&_0x2d0d37['hasOwnProperty']('iat');},wc=function(_0x42b143){const _0x133141=Yr(_0x42b143)['claims'];return typeof _0x133141=='object'&&_0x133141['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x2fac49,_0x153024){return Object['prototype']['hasOwnProperty']['call'](_0x2fac49,_0x153024);}function Le(_0x1d7be7,_0x228d64){if(Object['prototype']['hasOwnProperty']['call'](_0x1d7be7,_0x228d64))return _0x1d7be7[_0x228d64];}function pn(_0x52be08){for(const _0x33ac3e in _0x52be08)if(Object['prototype']['hasOwnProperty']['call'](_0x52be08,_0x33ac3e))return!0x1;return!0x0;}function _n(_0x4f5b96,_0x5cda44,_0x5a56ab){const _0x4da67a={};for(const _0x52f517 in _0x4f5b96)Object['prototype']['hasOwnProperty']['call'](_0x4f5b96,_0x52f517)&&(_0x4da67a[_0x52f517]=_0x5cda44['call'](_0x5a56ab,_0x4f5b96[_0x52f517],_0x52f517,_0x4f5b96));return _0x4da67a;}function xe(_0x116f6d,_0x21d2bd){if(_0x116f6d===_0x21d2bd)return!0x0;const _0x134f7c=Object['keys'](_0x116f6d),_0x38d6d0=Object['keys'](_0x21d2bd);for(const _0x1ed554 of _0x134f7c){if(!_0x38d6d0['includes'](_0x1ed554))return!0x1;const _0x164a38=_0x116f6d[_0x1ed554],_0x1a73f6=_0x21d2bd[_0x1ed554];if(Ns(_0x164a38)&&Ns(_0x1a73f6)){if(!xe(_0x164a38,_0x1a73f6))return!0x1;}else{if(_0x164a38!==_0x1a73f6)return!0x1;}}for(const _0x1dc712 of _0x38d6d0)if(!_0x134f7c['includes'](_0x1dc712))return!0x1;return!0x0;}function Ns(_0x2c68da){return _0x2c68da!==null&&typeof _0x2c68da=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ut(_0x36fa0e){const _0x478b68=[];for(const [_0x337667,_0x29185f]of Object['entries'](_0x36fa0e))Array['isArray'](_0x29185f)?_0x29185f['forEach'](_0x230e5a=>{_0x478b68['push'](encodeURIComponent(_0x337667)+'='+encodeURIComponent(_0x230e5a));}):_0x478b68['push'](encodeURIComponent(_0x337667)+'='+encodeURIComponent(_0x29185f));return _0x478b68['length']?'&'+_0x478b68['join']('&'):'';}function Ct(_0x2aa769){const _0x1442f3={};return _0x2aa769['replace'](/^\?/,'')['split']('&')['forEach'](_0x4cff65=>{if(_0x4cff65){const [_0x55c2ef,_0x4a8868]=_0x4cff65['split']('=');_0x1442f3[decodeURIComponent(_0x55c2ef)]=decodeURIComponent(_0x4a8868);}}),_0x1442f3;}function Tt(_0x2e8aac){const _0x34e777=_0x2e8aac['indexOf']('?');if(!_0x34e777)return'';const _0x22ac6c=_0x2e8aac['indexOf']('#',_0x34e777);return _0x2e8aac['substring'](_0x34e777,_0x22ac6c>0x0?_0x22ac6c:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x29cc64=0x1;_0x29cc64<this['blockSize'];++_0x29cc64)this['pad_'][_0x29cc64]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x57e3f1,_0x5a03cc){_0x5a03cc||(_0x5a03cc=0x0);const _0x3b823a=this['W_'];if(typeof _0x57e3f1=='string'){for(let _0x300573=0x0;_0x300573<0x10;_0x300573++)_0x3b823a[_0x300573]=_0x57e3f1['charCodeAt'](_0x5a03cc)<<0x18|_0x57e3f1['charCodeAt'](_0x5a03cc+0x1)<<0x10|_0x57e3f1['charCodeAt'](_0x5a03cc+0x2)<<0x8|_0x57e3f1['charCodeAt'](_0x5a03cc+0x3),_0x5a03cc+=0x4;}else{for(let _0x2bed38=0x0;_0x2bed38<0x10;_0x2bed38++)_0x3b823a[_0x2bed38]=_0x57e3f1[_0x5a03cc]<<0x18|_0x57e3f1[_0x5a03cc+0x1]<<0x10|_0x57e3f1[_0x5a03cc+0x2]<<0x8|_0x57e3f1[_0x5a03cc+0x3],_0x5a03cc+=0x4;}for(let _0x151ecf=0x10;_0x151ecf<0x50;_0x151ecf++){const _0x4c3a11=_0x3b823a[_0x151ecf-0x3]^_0x3b823a[_0x151ecf-0x8]^_0x3b823a[_0x151ecf-0xe]^_0x3b823a[_0x151ecf-0x10];_0x3b823a[_0x151ecf]=(_0x4c3a11<<0x1|_0x4c3a11>>>0x1f)&0xffffffff;}let _0x555893=this['chain_'][0x0],_0x177d9f=this['chain_'][0x1],_0xa48607=this['chain_'][0x2],_0x36a912=this['chain_'][0x3],_0x51b961=this['chain_'][0x4],_0x44a93d,_0x5dea1d;for(let _0x2300e5=0x0;_0x2300e5<0x50;_0x2300e5++){_0x2300e5<0x28?_0x2300e5<0x14?(_0x44a93d=_0x36a912^_0x177d9f&(_0xa48607^_0x36a912),_0x5dea1d=0x5a827999):(_0x44a93d=_0x177d9f^_0xa48607^_0x36a912,_0x5dea1d=0x6ed9eba1):_0x2300e5<0x3c?(_0x44a93d=_0x177d9f&_0xa48607|_0x36a912&(_0x177d9f|_0xa48607),_0x5dea1d=0x8f1bbcdc):(_0x44a93d=_0x177d9f^_0xa48607^_0x36a912,_0x5dea1d=0xca62c1d6);const _0x2c677f=(_0x555893<<0x5|_0x555893>>>0x1b)+_0x44a93d+_0x51b961+_0x5dea1d+_0x3b823a[_0x2300e5]&0xffffffff;_0x51b961=_0x36a912,_0x36a912=_0xa48607,_0xa48607=(_0x177d9f<<0x1e|_0x177d9f>>>0x2)&0xffffffff,_0x177d9f=_0x555893,_0x555893=_0x2c677f;}this['chain_'][0x0]=this['chain_'][0x0]+_0x555893&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x177d9f&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0xa48607&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x36a912&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x51b961&0xffffffff;}['update'](_0xf4b56e,_0x5e744c){if(_0xf4b56e==null)return;_0x5e744c===void 0x0&&(_0x5e744c=_0xf4b56e['length']);const _0x39e813=_0x5e744c-this['blockSize'];let _0x30b687=0x0;const _0x11e455=this['buf_'];let _0x1d7ca7=this['inbuf_'];for(;_0x30b687<_0x5e744c;){if(_0x1d7ca7===0x0){for(;_0x30b687<=_0x39e813;)this['compress_'](_0xf4b56e,_0x30b687),_0x30b687+=this['blockSize'];}if(typeof _0xf4b56e=='string'){for(;_0x30b687<_0x5e744c;)if(_0x11e455[_0x1d7ca7]=_0xf4b56e['charCodeAt'](_0x30b687),++_0x1d7ca7,++_0x30b687,_0x1d7ca7===this['blockSize']){this['compress_'](_0x11e455),_0x1d7ca7=0x0;break;}}else{for(;_0x30b687<_0x5e744c;)if(_0x11e455[_0x1d7ca7]=_0xf4b56e[_0x30b687],++_0x1d7ca7,++_0x30b687,_0x1d7ca7===this['blockSize']){this['compress_'](_0x11e455),_0x1d7ca7=0x0;break;}}}this['inbuf_']=_0x1d7ca7,this['total_']+=_0x5e744c;}['digest'](){const _0x1118a8=[];let _0x3104f5=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x5e437a=this['blockSize']-0x1;_0x5e437a>=0x38;_0x5e437a--)this['buf_'][_0x5e437a]=_0x3104f5&0xff,_0x3104f5/=0x100;this['compress_'](this['buf_']);let _0x168c87=0x0;for(let _0x463a96=0x0;_0x463a96<0x5;_0x463a96++)for(let _0x5d8213=0x18;_0x5d8213>=0x0;_0x5d8213-=0x8)_0x1118a8[_0x168c87]=this['chain_'][_0x463a96]>>_0x5d8213&0xff,++_0x168c87;return _0x1118a8;}}function Tc(_0x30b94b,_0x16118b){const _0x4bcb16=new Sc(_0x30b94b,_0x16118b);return _0x4bcb16['subscribe']['bind'](_0x4bcb16);}class Sc{constructor(_0x5ccea7,_0x20e0e6){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x20e0e6,this['task']['then'](()=>{_0x5ccea7(this);})['catch'](_0x371efa=>{this['error'](_0x371efa);});}['next'](_0x5647ca){this['forEachObserver'](_0xe98c08=>{_0xe98c08['next'](_0x5647ca);});}['error'](_0x435298){this['forEachObserver'](_0x2d03bc=>{_0x2d03bc['error'](_0x435298);}),this['close'](_0x435298);}['complete'](){this['forEachObserver'](_0x4ca6f6=>{_0x4ca6f6['complete']();}),this['close']();}['subscribe'](_0x365ee5,_0x4149be,_0x49e44b){let _0x64e956;if(_0x365ee5===void 0x0&&_0x4149be===void 0x0&&_0x49e44b===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x365ee5,['next','error','complete'])?_0x64e956=_0x365ee5:_0x64e956={'next':_0x365ee5,'error':_0x4149be,'complete':_0x49e44b},_0x64e956['next']===void 0x0&&(_0x64e956['next']=ti),_0x64e956['error']===void 0x0&&(_0x64e956['error']=ti),_0x64e956['complete']===void 0x0&&(_0x64e956['complete']=ti);const _0x4afd6d=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x64e956['error'](this['finalError']):_0x64e956['complete']();}catch{}}),this['observers']['push'](_0x64e956),_0x4afd6d;}['unsubscribeOne'](_0x5998e6){this['observers']===void 0x0||this['observers'][_0x5998e6]===void 0x0||(delete this['observers'][_0x5998e6],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x1bf265){if(!this['finalized']){for(let _0x168b92=0x0;_0x168b92<this['observers']['length'];_0x168b92++)this['sendOne'](_0x168b92,_0x1bf265);}}['sendOne'](_0x1ccc42,_0x90431b){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x1ccc42]!==void 0x0)try{_0x90431b(this['observers'][_0x1ccc42]);}catch(_0x1723e4){typeof console<'u'&&console['error']&&console['error'](_0x1723e4);}});}['close'](_0x23f111){this['finalized']||(this['finalized']=!0x0,_0x23f111!==void 0x0&&(this['finalError']=_0x23f111),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x1f6ce6,_0x23d1a8){if(typeof _0x1f6ce6!='object'||_0x1f6ce6===null)return!0x1;for(const _0x139d90 of _0x23d1a8)if(_0x139d90 in _0x1f6ce6&&typeof _0x1f6ce6[_0x139d90]=='function')return!0x0;return!0x1;}function ti(){}function it(_0x1ac4f1,_0x2ca9a9){return _0x1ac4f1+'\x20failed:\x20'+_0x2ca9a9+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x4b4dbc){const _0x491992=[];let _0x1d9e56=0x0;for(let _0x5ea37c=0x0;_0x5ea37c<_0x4b4dbc['length'];_0x5ea37c++){let _0x4eb839=_0x4b4dbc['charCodeAt'](_0x5ea37c);if(_0x4eb839>=0xd800&&_0x4eb839<=0xdbff){const _0x167b12=_0x4eb839-0xd800;_0x5ea37c++,f(_0x5ea37c<_0x4b4dbc['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x2a1221=_0x4b4dbc['charCodeAt'](_0x5ea37c)-0xdc00;_0x4eb839=0x10000+(_0x167b12<<0xa)+_0x2a1221;}_0x4eb839<0x80?_0x491992[_0x1d9e56++]=_0x4eb839:_0x4eb839<0x800?(_0x491992[_0x1d9e56++]=_0x4eb839>>0x6|0xc0,_0x491992[_0x1d9e56++]=_0x4eb839&0x3f|0x80):_0x4eb839<0x10000?(_0x491992[_0x1d9e56++]=_0x4eb839>>0xc|0xe0,_0x491992[_0x1d9e56++]=_0x4eb839>>0x6&0x3f|0x80,_0x491992[_0x1d9e56++]=_0x4eb839&0x3f|0x80):(_0x491992[_0x1d9e56++]=_0x4eb839>>0x12|0xf0,_0x491992[_0x1d9e56++]=_0x4eb839>>0xc&0x3f|0x80,_0x491992[_0x1d9e56++]=_0x4eb839>>0x6&0x3f|0x80,_0x491992[_0x1d9e56++]=_0x4eb839&0x3f|0x80);}return _0x491992;},Ln=function(_0x2b87ed){let _0x56431d=0x0;for(let _0x390bba=0x0;_0x390bba<_0x2b87ed['length'];_0x390bba++){const _0x47ecf4=_0x2b87ed['charCodeAt'](_0x390bba);_0x47ecf4<0x80?_0x56431d++:_0x47ecf4<0x800?_0x56431d+=0x2:_0x47ecf4>=0xd800&&_0x47ecf4<=0xdbff?(_0x56431d+=0x4,_0x390bba++):_0x56431d+=0x3;}return _0x56431d;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function P(_0x5cdd27){return _0x5cdd27&&_0x5cdd27['_delegate']?_0x5cdd27['_delegate']:_0x5cdd27;}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function qt(_0x725f9d){try{return(_0x725f9d['startsWith']('http://')||_0x725f9d['startsWith']('https://')?new URL(_0x725f9d)['hostname']:_0x725f9d)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function Qr(_0x4fc090){return(await fetch(_0x4fc090,{'credentials':'include'}))['ok'];}class Fe{constructor(_0x99412f,_0x45db97,_0x9495e0){this['name']=_0x99412f,this['instanceFactory']=_0x45db97,this['type']=_0x9495e0,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x3605f9){return this['instantiationMode']=_0x3605f9,this;}['setMultipleInstances'](_0x5f58ef){return this['multipleInstances']=_0x5f58ef,this;}['setServiceProps'](_0x1a007b){return this['serviceProps']=_0x1a007b,this;}['setInstanceCreatedCallback'](_0x29591e){return this['onInstanceCreated']=_0x29591e,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x4018f5,_0x30aae5){this['name']=_0x4018f5,this['container']=_0x30aae5,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x23ed2c){const _0x2cea8b=this['normalizeInstanceIdentifier'](_0x23ed2c);if(!this['instancesDeferred']['has'](_0x2cea8b)){const _0x321d55=new H();if(this['instancesDeferred']['set'](_0x2cea8b,_0x321d55),this['isInitialized'](_0x2cea8b)||this['shouldAutoInitialize']())try{const _0x43d597=this['getOrInitializeService']({'instanceIdentifier':_0x2cea8b});_0x43d597&&_0x321d55['resolve'](_0x43d597);}catch{}}return this['instancesDeferred']['get'](_0x2cea8b)['promise'];}['getImmediate'](_0x209c75){const _0x3cc4ac=this['normalizeInstanceIdentifier'](_0x209c75==null?void 0x0:_0x209c75['identifier']),_0x48aac1=(_0x209c75==null?void 0x0:_0x209c75['optional'])??!0x1;if(this['isInitialized'](_0x3cc4ac)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x3cc4ac});}catch(_0x562035){if(_0x48aac1)return null;throw _0x562035;}else{if(_0x48aac1)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x538824){if(_0x538824['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x538824['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x538824,!!this['shouldAutoInitialize']()){if(Pc(_0x538824))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x4056de,_0x2c68b9]of this['instancesDeferred']['entries']()){const _0x69b087=this['normalizeInstanceIdentifier'](_0x4056de);try{const _0x596dde=this['getOrInitializeService']({'instanceIdentifier':_0x69b087});_0x2c68b9['resolve'](_0x596dde);}catch{}}}}['clearInstance'](_0x2383d6=Ne){this['instancesDeferred']['delete'](_0x2383d6),this['instancesOptions']['delete'](_0x2383d6),this['instances']['delete'](_0x2383d6);}async['delete'](){const _0x5b5847=Array['from'](this['instances']['values']());await Promise['all']([..._0x5b5847['filter'](_0x162beb=>'INTERNAL'in _0x162beb)['map'](_0x3a6c24=>_0x3a6c24['INTERNAL']['delete']()),..._0x5b5847['filter'](_0x5eccbf=>'_delete'in _0x5eccbf)['map'](_0x68ed99=>_0x68ed99['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x4f2734=Ne){return this['instances']['has'](_0x4f2734);}['getOptions'](_0x1c01ad=Ne){return this['instancesOptions']['get'](_0x1c01ad)||{};}['initialize'](_0x51844e={}){const {options:_0x7ab71={}}=_0x51844e,_0x1f549b=this['normalizeInstanceIdentifier'](_0x51844e['instanceIdentifier']);if(this['isInitialized'](_0x1f549b))throw Error(this['name']+'('+_0x1f549b+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x3988d1=this['getOrInitializeService']({'instanceIdentifier':_0x1f549b,'options':_0x7ab71});for(const [_0x453de0,_0x14f746]of this['instancesDeferred']['entries']()){const _0x438df9=this['normalizeInstanceIdentifier'](_0x453de0);_0x1f549b===_0x438df9&&_0x14f746['resolve'](_0x3988d1);}return _0x3988d1;}['onInit'](_0x35873c,_0x433c5a){const _0xe0069f=this['normalizeInstanceIdentifier'](_0x433c5a),_0x236e6d=this['onInitCallbacks']['get'](_0xe0069f)??new Set();_0x236e6d['add'](_0x35873c),this['onInitCallbacks']['set'](_0xe0069f,_0x236e6d);const _0x409543=this['instances']['get'](_0xe0069f);return _0x409543&&_0x35873c(_0x409543,_0xe0069f),()=>{_0x236e6d['delete'](_0x35873c);};}['invokeOnInitCallbacks'](_0x44bcc8,_0x180f08){const _0x3ef0c9=this['onInitCallbacks']['get'](_0x180f08);if(_0x3ef0c9){for(const _0x494c6 of _0x3ef0c9)try{_0x494c6(_0x44bcc8,_0x180f08);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x46e0d6,options:_0x91bb2c={}}){let _0x937d5a=this['instances']['get'](_0x46e0d6);if(!_0x937d5a&&this['component']&&(_0x937d5a=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x46e0d6),'options':_0x91bb2c}),this['instances']['set'](_0x46e0d6,_0x937d5a),this['instancesOptions']['set'](_0x46e0d6,_0x91bb2c),this['invokeOnInitCallbacks'](_0x937d5a,_0x46e0d6),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x46e0d6,_0x937d5a);}catch{}return _0x937d5a||null;}['normalizeInstanceIdentifier'](_0x2c5de5=Ne){return this['component']?this['component']['multipleInstances']?_0x2c5de5:Ne:_0x2c5de5;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x5942bc){return _0x5942bc===Ne?void 0x0:_0x5942bc;}function Pc(_0x399aca){return _0x399aca['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nc{constructor(_0x425b0e){this['name']=_0x425b0e,this['providers']=new Map();}['addComponent'](_0x433e8d){const _0x29fc22=this['getProvider'](_0x433e8d['name']);if(_0x29fc22['isComponentSet']())throw new Error('Component\x20'+_0x433e8d['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x29fc22['setComponent'](_0x433e8d);}['addOrOverwriteComponent'](_0x46e409){this['getProvider'](_0x46e409['name'])['isComponentSet']()&&this['providers']['delete'](_0x46e409['name']),this['addComponent'](_0x46e409);}['getProvider'](_0xb38ebb){if(this['providers']['has'](_0xb38ebb))return this['providers']['get'](_0xb38ebb);const _0x410275=new Ac(_0xb38ebb,this);return this['providers']['set'](_0xb38ebb,_0x410275),_0x410275;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x50312c){_0x50312c[_0x50312c['DEBUG']=0x0]='DEBUG',_0x50312c[_0x50312c['VERBOSE']=0x1]='VERBOSE',_0x50312c[_0x50312c['INFO']=0x2]='INFO',_0x50312c[_0x50312c['WARN']=0x3]='WARN',_0x50312c[_0x50312c['ERROR']=0x4]='ERROR',_0x50312c[_0x50312c['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x12e822,_0x568913,..._0x4dedc7)=>{if(_0x568913<_0x12e822['logLevel'])return;const _0x2eef04=new Date()['toISOString'](),_0x4ba7fe=Mc[_0x568913];if(_0x4ba7fe)console[_0x4ba7fe]('['+_0x2eef04+']\x20\x20'+_0x12e822['name']+':',..._0x4dedc7);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x568913+')');};class Bi{constructor(_0x5bc548){this['name']=_0x5bc548,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x41e6d3){if(!(_0x41e6d3 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x41e6d3+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x41e6d3;}['setLogLevel'](_0x52f827){this['_logLevel']=typeof _0x52f827=='string'?Oc[_0x52f827]:_0x52f827;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x2d522a){if(typeof _0x2d522a!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x2d522a;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x526433){this['_userLogHandler']=_0x526433;}['debug'](..._0x781cb8){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x781cb8),this['_logHandler'](this,T['DEBUG'],..._0x781cb8);}['log'](..._0x5a9457){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x5a9457),this['_logHandler'](this,T['VERBOSE'],..._0x5a9457);}['info'](..._0xd7c52d){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0xd7c52d),this['_logHandler'](this,T['INFO'],..._0xd7c52d);}['warn'](..._0x353f7c){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x353f7c),this['_logHandler'](this,T['WARN'],..._0x353f7c);}['error'](..._0x1f8636){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x1f8636),this['_logHandler'](this,T['ERROR'],..._0x1f8636);}}const xc=(_0x58db09,_0x3d458f)=>_0x3d458f['some'](_0x4e829e=>_0x58db09 instanceof _0x4e829e);let Os,Ds;function Fc(){return Os||(Os=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ds||(Ds=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),_i=new WeakMap(),Xr=new WeakMap(),ni=new WeakMap(),Vi=new WeakMap();function Wc(_0x5c31f4){const _0x10dbbc=new Promise((_0x3805f2,_0x5d7600)=>{const _0x178c6a=()=>{_0x5c31f4['removeEventListener']('success',_0x5e7306),_0x5c31f4['removeEventListener']('error',_0x1457d4);},_0x5e7306=()=>{_0x3805f2(ge(_0x5c31f4['result'])),_0x178c6a();},_0x1457d4=()=>{_0x5d7600(_0x5c31f4['error']),_0x178c6a();};_0x5c31f4['addEventListener']('success',_0x5e7306),_0x5c31f4['addEventListener']('error',_0x1457d4);});return _0x10dbbc['then'](_0x5de5ec=>{_0x5de5ec instanceof IDBCursor&&Jr['set'](_0x5de5ec,_0x5c31f4);})['catch'](()=>{}),Vi['set'](_0x10dbbc,_0x5c31f4),_0x10dbbc;}function Bc(_0x11f276){if(_i['has'](_0x11f276))return;const _0x56fec6=new Promise((_0x358163,_0x7dc1dd)=>{const _0x5cc47b=()=>{_0x11f276['removeEventListener']('complete',_0x44cb2e),_0x11f276['removeEventListener']('error',_0x2681cc),_0x11f276['removeEventListener']('abort',_0x2681cc);},_0x44cb2e=()=>{_0x358163(),_0x5cc47b();},_0x2681cc=()=>{_0x7dc1dd(_0x11f276['error']||new DOMException('AbortError','AbortError')),_0x5cc47b();};_0x11f276['addEventListener']('complete',_0x44cb2e),_0x11f276['addEventListener']('error',_0x2681cc),_0x11f276['addEventListener']('abort',_0x2681cc);});_i['set'](_0x11f276,_0x56fec6);}let gi={'get'(_0xb3b001,_0x4b751a,_0x319a9a){if(_0xb3b001 instanceof IDBTransaction){if(_0x4b751a==='done')return _i['get'](_0xb3b001);if(_0x4b751a==='objectStoreNames')return _0xb3b001['objectStoreNames']||Xr['get'](_0xb3b001);if(_0x4b751a==='store')return _0x319a9a['objectStoreNames'][0x1]?void 0x0:_0x319a9a['objectStore'](_0x319a9a['objectStoreNames'][0x0]);}return ge(_0xb3b001[_0x4b751a]);},'set'(_0x5e13b7,_0x24856b,_0x50fda1){return _0x5e13b7[_0x24856b]=_0x50fda1,!0x0;},'has'(_0x2b2311,_0x1c4ff3){return _0x2b2311 instanceof IDBTransaction&&(_0x1c4ff3==='done'||_0x1c4ff3==='store')?!0x0:_0x1c4ff3 in _0x2b2311;}};function Vc(_0xe8f1e0){gi=_0xe8f1e0(gi);}function Hc(_0xa813a9){return _0xa813a9===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x283167,..._0x5ce1c9){const _0x44865d=_0xa813a9['call'](ii(this),_0x283167,..._0x5ce1c9);return Xr['set'](_0x44865d,_0x283167['sort']?_0x283167['sort']():[_0x283167]),ge(_0x44865d);}:Uc()['includes'](_0xa813a9)?function(..._0x1c4362){return _0xa813a9['apply'](ii(this),_0x1c4362),ge(Jr['get'](this));}:function(..._0x24f13a){return ge(_0xa813a9['apply'](ii(this),_0x24f13a));};}function $c(_0x1fe114){return typeof _0x1fe114=='function'?Hc(_0x1fe114):(_0x1fe114 instanceof IDBTransaction&&Bc(_0x1fe114),xc(_0x1fe114,Fc())?new Proxy(_0x1fe114,gi):_0x1fe114);}function ge(_0x239c07){if(_0x239c07 instanceof IDBRequest)return Wc(_0x239c07);if(ni['has'](_0x239c07))return ni['get'](_0x239c07);const _0x3f0bdc=$c(_0x239c07);return _0x3f0bdc!==_0x239c07&&(ni['set'](_0x239c07,_0x3f0bdc),Vi['set'](_0x3f0bdc,_0x239c07)),_0x3f0bdc;}const ii=_0x48ebe5=>Vi['get'](_0x48ebe5);function Gc(_0x5abb97,_0x200fbe,{blocked:_0x50f70e,upgrade:_0x3bb481,blocking:_0x76304d,terminated:_0x50ce50}={}){const _0x2161f3=indexedDB['open'](_0x5abb97,_0x200fbe),_0x124831=ge(_0x2161f3);return _0x3bb481&&_0x2161f3['addEventListener']('upgradeneeded',_0x21500c=>{_0x3bb481(ge(_0x2161f3['result']),_0x21500c['oldVersion'],_0x21500c['newVersion'],ge(_0x2161f3['transaction']),_0x21500c);}),_0x50f70e&&_0x2161f3['addEventListener']('blocked',_0x133060=>_0x50f70e(_0x133060['oldVersion'],_0x133060['newVersion'],_0x133060)),_0x124831['then'](_0x50fc61=>{_0x50ce50&&_0x50fc61['addEventListener']('close',()=>_0x50ce50()),_0x76304d&&_0x50fc61['addEventListener']('versionchange',_0x277dc3=>_0x76304d(_0x277dc3['oldVersion'],_0x277dc3['newVersion'],_0x277dc3));})['catch'](()=>{}),_0x124831;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],si=new Map();function Ms(_0x45e169,_0x4bed45){if(!(_0x45e169 instanceof IDBDatabase&&!(_0x4bed45 in _0x45e169)&&typeof _0x4bed45=='string'))return;if(si['get'](_0x4bed45))return si['get'](_0x4bed45);const _0xab3a76=_0x4bed45['replace'](/FromIndex$/,''),_0x130cee=_0x4bed45!==_0xab3a76,_0x5708c5=zc['includes'](_0xab3a76);if(!(_0xab3a76 in(_0x130cee?IDBIndex:IDBObjectStore)['prototype'])||!(_0x5708c5||qc['includes'](_0xab3a76)))return;const _0x4597da=async function(_0x4da80f,..._0x1b5400){const _0x3b46bc=this['transaction'](_0x4da80f,_0x5708c5?'readwrite':'readonly');let _0x443501=_0x3b46bc['store'];return _0x130cee&&(_0x443501=_0x443501['index'](_0x1b5400['shift']())),(await Promise['all']([_0x443501[_0xab3a76](..._0x1b5400),_0x5708c5&&_0x3b46bc['done']]))[0x0];};return si['set'](_0x4bed45,_0x4597da),_0x4597da;}Vc(_0x7cbeae=>({..._0x7cbeae,'get':(_0x1d6286,_0x14b67e,_0x2c3af6)=>Ms(_0x1d6286,_0x14b67e)||_0x7cbeae['get'](_0x1d6286,_0x14b67e,_0x2c3af6),'has':(_0x2a3aba,_0x2b6229)=>!!Ms(_0x2a3aba,_0x2b6229)||_0x7cbeae['has'](_0x2a3aba,_0x2b6229)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x4872fb){this['container']=_0x4872fb;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0xfcb932=>{if(Kc(_0xfcb932)){const _0x3720e7=_0xfcb932['getImmediate']();return _0x3720e7['library']+'/'+_0x3720e7['version'];}else return null;})['filter'](_0x1751df=>_0x1751df)['join']('\x20');}}function Kc(_0x4bcaef){const _0x323b12=_0x4bcaef['getComponent']();return(_0x323b12==null?void 0x0:_0x323b12['type'])==='VERSION';}const mi='@firebase/app',Ls='0.15.1',oe=new Bi('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.16.0',yi='[DEFAULT]',wl={[mi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},Ue=new Map(),vi=new Map(),Ei=new Map();function xs(_0xcb30fc,_0x467a4d){try{_0xcb30fc['container']['addComponent'](_0x467a4d);}catch(_0x1ea0b0){oe['debug']('Component\x20'+_0x467a4d['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0xcb30fc['name'],_0x1ea0b0);}}function st(_0x2f12f9){const _0x25bef7=_0x2f12f9['name'];if(Ei['has'](_0x25bef7))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x25bef7+'.'),!0x1;Ei['set'](_0x25bef7,_0x2f12f9);for(const _0x597723 of Ue['values']())xs(_0x597723,_0x2f12f9);for(const _0x46c9e8 of vi['values']())xs(_0x46c9e8,_0x2f12f9);return!0x0;}function Hi(_0x1f252f,_0x4f8d27){const _0x5f5d21=_0x1f252f['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x5f5d21&&_0x5f5d21['triggerHeartbeat'](),_0x1f252f['container']['getProvider'](_0x4f8d27);}function $(_0x58db6d){return _0x58db6d==null?!0x1:_0x58db6d['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},me=new Gt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x1d9037,_0x4f5562,_0x24549d){this['_isDeleted']=!0x1,this['_options']={..._0x1d9037},this['_config']={..._0x4f5562},this['_name']=_0x4f5562['name'],this['_automaticDataCollectionEnabled']=_0x4f5562['automaticDataCollectionEnabled'],this['_container']=_0x24549d,this['container']['addComponent'](new Fe('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0xc8efda){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0xc8efda;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x323af1){this['_isDeleted']=_0x323af1;}['checkDestroyed'](){if(this['isDeleted'])throw me['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const dt=Il;function Sl(_0x50fb10,_0x9cefad={}){let _0x431a4e=_0x50fb10;typeof _0x9cefad!='object'&&(_0x9cefad={'name':_0x9cefad});const _0x131b69={'name':yi,'automaticDataCollectionEnabled':!0x0,..._0x9cefad},_0x29f370=_0x131b69['name'];if(typeof _0x29f370!='string'||!_0x29f370)throw me['create']('bad-app-name',{'appName':String(_0x29f370)});if(_0x431a4e||(_0x431a4e=zr()),!_0x431a4e)throw me['create']('no-options');const _0x5403a9=Ue['get'](_0x29f370);if(_0x5403a9){if(xe(_0x431a4e,_0x5403a9['options'])&&xe(_0x131b69,_0x5403a9['config']))return _0x5403a9;throw me['create']('duplicate-app',{'appName':_0x29f370});}const _0x2fe132=new Nc(_0x29f370);for(const _0x40c771 of Ei['values']())_0x2fe132['addComponent'](_0x40c771);const _0x445e89=new Tl(_0x431a4e,_0x131b69,_0x2fe132);return Ue['set'](_0x29f370,_0x445e89),_0x445e89;}function Zr(_0x27cd74=yi){const _0x5cd72a=Ue['get'](_0x27cd74);if(!_0x5cd72a&&_0x27cd74===yi&&zr())return Sl();if(!_0x5cd72a)throw me['create']('no-app',{'appName':_0x27cd74});return _0x5cd72a;}function g_(){return Array['from'](Ue['values']());}async function m_(_0x256f3d){let _0x5c4d31=!0x1;const _0x39ef6b=_0x256f3d['name'];Ue['has'](_0x39ef6b)?(_0x5c4d31=!0x0,Ue['delete'](_0x39ef6b)):vi['has'](_0x39ef6b)&&_0x256f3d['decRefCount']()<=0x0&&(vi['delete'](_0x39ef6b),_0x5c4d31=!0x0),_0x5c4d31&&(await Promise['all'](_0x256f3d['container']['getProviders']()['map'](_0x2e7109=>_0x2e7109['delete']())),_0x256f3d['isDeleted']=!0x0);}function ye(_0x41dab8,_0x31390b,_0x4b2cdd){let _0x5946a0=wl[_0x41dab8]??_0x41dab8;_0x4b2cdd&&(_0x5946a0+='-'+_0x4b2cdd);const _0x4025f1=_0x5946a0['match'](/\s|\//),_0x1e3506=_0x31390b['match'](/\s|\//);if(_0x4025f1||_0x1e3506){const _0x3f781b=['Unable\x20to\x20register\x20library\x20\x22'+_0x5946a0+'\x22\x20with\x20version\x20\x22'+_0x31390b+'\x22:'];_0x4025f1&&_0x3f781b['push']('library\x20name\x20\x22'+_0x5946a0+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x4025f1&&_0x1e3506&&_0x3f781b['push']('and'),_0x1e3506&&_0x3f781b['push']('version\x20name\x20\x22'+_0x31390b+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x3f781b['join']('\x20'));return;}st(new Fe(_0x5946a0+'-version',()=>({'library':_0x5946a0,'version':_0x31390b}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,Ot='firebase-heartbeat-store';let ri=null;function eo(){return ri||(ri=Gc(bl,Rl,{'upgrade':(_0x3360e5,_0x130618)=>{switch(_0x130618){case 0x0:try{_0x3360e5['createObjectStore'](Ot);}catch(_0x16ef0c){console['warn'](_0x16ef0c);}}}})['catch'](_0x2fc2a8=>{throw me['create']('idb-open',{'originalErrorMessage':_0x2fc2a8['message']});})),ri;}async function Al(_0x3e3c0d){try{const _0x469e1f=(await eo())['transaction'](Ot),_0x554464=await _0x469e1f['objectStore'](Ot)['get'](to(_0x3e3c0d));return await _0x469e1f['done'],_0x554464;}catch(_0x38fddf){if(_0x38fddf instanceof Re)oe['warn'](_0x38fddf['message']);else{const _0x46113a=me['create']('idb-get',{'originalErrorMessage':_0x38fddf==null?void 0x0:_0x38fddf['message']});oe['warn'](_0x46113a['message']);}}}async function Fs(_0x3e6be6,_0x11b7f2){try{const _0x306e9a=(await eo())['transaction'](Ot,'readwrite');await _0x306e9a['objectStore'](Ot)['put'](_0x11b7f2,to(_0x3e6be6)),await _0x306e9a['done'];}catch(_0x3c18e3){if(_0x3c18e3 instanceof Re)oe['warn'](_0x3c18e3['message']);else{const _0x5f63cb=me['create']('idb-set',{'originalErrorMessage':_0x3c18e3==null?void 0x0:_0x3c18e3['message']});oe['warn'](_0x5f63cb['message']);}}}function to(_0x3e0828){return _0x3e0828['name']+'!'+_0x3e0828['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Pl=0x1e;class Nl{constructor(_0x4f550b){this['container']=_0x4f550b,this['_heartbeatsCache']=null;const _0x4b2c02=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x4b2c02),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x56b7cd=>(this['_heartbeatsCache']=_0x56b7cd,_0x56b7cd));}async['triggerHeartbeat'](){var _0x1a7bea,_0x4d5314;try{const _0x785146=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x43cea4=Us();if(((_0x1a7bea=this['_heartbeatsCache'])==null?void 0x0:_0x1a7bea['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x4d5314=this['_heartbeatsCache'])==null?void 0x0:_0x4d5314['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x43cea4||this['_heartbeatsCache']['heartbeats']['some'](_0x4bf4ef=>_0x4bf4ef['date']===_0x43cea4))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x43cea4,'agent':_0x785146}),this['_heartbeatsCache']['heartbeats']['length']>Pl){const _0x594031=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x594031,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x417d0d){oe['warn'](_0x417d0d);}}async['getHeartbeatsHeader'](){var _0x41809e;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x41809e=this['_heartbeatsCache'])==null?void 0x0:_0x41809e['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x5de4a1=Us(),{heartbeatsToSend:_0x381ce0,unsentEntries:_0x46adf9}=Ol(this['_heartbeatsCache']['heartbeats']),_0xfedd3d=dn(JSON['stringify']({'version':0x2,'heartbeats':_0x381ce0}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x5de4a1,_0x46adf9['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x46adf9,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0xfedd3d;}catch(_0x4ff6bb){return oe['warn'](_0x4ff6bb),'';}}}function Us(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x10000d,_0x50aaca=kl){const _0x203a97=[];let _0x5e9fd6=_0x10000d['slice']();for(const _0x1725d9 of _0x10000d){const _0x28ce0e=_0x203a97['find'](_0x53bc65=>_0x53bc65['agent']===_0x1725d9['agent']);if(_0x28ce0e){if(_0x28ce0e['dates']['push'](_0x1725d9['date']),Ws(_0x203a97)>_0x50aaca){_0x28ce0e['dates']['pop']();break;}}else{if(_0x203a97['push']({'agent':_0x1725d9['agent'],'dates':[_0x1725d9['date']]}),Ws(_0x203a97)>_0x50aaca){_0x203a97['pop']();break;}}_0x5e9fd6=_0x5e9fd6['slice'](0x1);}return{'heartbeatsToSend':_0x203a97,'unsentEntries':_0x5e9fd6};}class Dl{constructor(_0x1a639e){this['app']=_0x1a639e,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x5ce843=await Al(this['app']);return _0x5ce843!=null&&_0x5ce843['heartbeats']?_0x5ce843:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x1450ce){if(await this['_canUseIndexedDBPromise']){const _0xa2156e=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0x1450ce['lastSentHeartbeatDate']??_0xa2156e['lastSentHeartbeatDate'],'heartbeats':_0x1450ce['heartbeats']});}else return;}async['add'](_0xf674f1){if(await this['_canUseIndexedDBPromise']){const _0x239c7e=await this['read']();return Fs(this['app'],{'lastSentHeartbeatDate':_0xf674f1['lastSentHeartbeatDate']??_0x239c7e['lastSentHeartbeatDate'],'heartbeats':[..._0x239c7e['heartbeats'],..._0xf674f1['heartbeats']]});}else return;}}function Ws(_0x1c632a){return dn(JSON['stringify']({'version':0x2,'heartbeats':_0x1c632a}))['length'];}function Ml(_0x286321){if(_0x286321['length']===0x0)return-0x1;let _0xbf8d61=0x0,_0x408028=_0x286321[0x0]['date'];for(let _0x4ddd45=0x1;_0x4ddd45<_0x286321['length'];_0x4ddd45++)_0x286321[_0x4ddd45]['date']<_0x408028&&(_0x408028=_0x286321[_0x4ddd45]['date'],_0xbf8d61=_0x4ddd45);return _0xbf8d61;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x3e41f1){st(new Fe('platform-logger',_0x4b9900=>new jc(_0x4b9900),'PRIVATE')),st(new Fe('heartbeat',_0x1bae95=>new Nl(_0x1bae95),'PRIVATE')),ye(mi,Ls,_0x3e41f1),ye(mi,Ls,'esm2020'),ye('fire-js','');}Ll('');var xl='firebase',Fl='12.16.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
ye(xl,Fl,'app');var Bs={};const Vs='@firebase/database',Hs='1.1.3';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x38aa22){no=_0x38aa22;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x1810c3){this['domStorage_']=_0x1810c3,this['prefix_']='firebase:';}['set'](_0x33b00e,_0x558931){_0x558931==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x33b00e)):this['domStorage_']['setItem'](this['prefixedName_'](_0x33b00e),O(_0x558931));}['get'](_0x1f533b){const _0x2ebe02=this['domStorage_']['getItem'](this['prefixedName_'](_0x1f533b));return _0x2ebe02==null?null:Nt(_0x2ebe02);}['remove'](_0x49468c){this['domStorage_']['removeItem'](this['prefixedName_'](_0x49468c));}['prefixedName_'](_0x37b472){return this['prefix_']+_0x37b472;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x37e3ca,_0xc16b1a){_0xc16b1a==null?delete this['cache_'][_0x37e3ca]:this['cache_'][_0x37e3ca]=_0xc16b1a;}['get'](_0x9da1af){return Q(this['cache_'],_0x9da1af)?this['cache_'][_0x9da1af]:null;}['remove'](_0x31bd34){delete this['cache_'][_0x31bd34];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x3091ea){try{if(typeof window<'u'&&typeof window[_0x3091ea]<'u'){const _0x444c38=window[_0x3091ea];return _0x444c38['setItem']('firebase:sentinel','cache'),_0x444c38['removeItem']('firebase:sentinel'),new Wl(_0x444c38);}}catch{}return new Bl();},De=io('localStorage'),Vl=io('sessionStorage'),Ze=new Bi('@firebase/database'),so=(function(){let _0x8bf34e=0x1;return function(){return _0x8bf34e++;};}()),ro=function(_0x573433){const _0x3e0043=Rc(_0x573433),_0x47cc70=new Cc();_0x47cc70['update'](_0x3e0043);const _0x2043a2=_0x47cc70['digest']();return Fi['encodeByteArray'](_0x2043a2);},zt=function(..._0x4b3ef3){let _0x436d7b='';for(let _0x4e2aae=0x0;_0x4e2aae<_0x4b3ef3['length'];_0x4e2aae++){const _0x457db2=_0x4b3ef3[_0x4e2aae];Array['isArray'](_0x457db2)||_0x457db2&&typeof _0x457db2=='object'&&typeof _0x457db2['length']=='number'?_0x436d7b+=zt['apply'](null,_0x457db2):typeof _0x457db2=='object'?_0x436d7b+=O(_0x457db2):_0x436d7b+=_0x457db2,_0x436d7b+='\x20';}return _0x436d7b;};let St=null,$s=!0x0;const Hl=function(_0x522b6c,_0x2872d9){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ze['logLevel']=T['VERBOSE'],St=Ze['log']['bind'](Ze);},L=function(..._0x1bdd4d){if($s===!0x0&&($s=!0x1,St===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),St){const _0x2cc3d7=zt['apply'](null,_0x1bdd4d);St(_0x2cc3d7);}},jt=function(_0x508cc5){return function(..._0x8aa018){L(_0x508cc5,..._0x8aa018);};},Ii=function(..._0x5c22ca){const _0x2c77ae='FIREBASE\x20INTERNAL\x20ERROR:\x20'+zt(..._0x5c22ca);Ze['error'](_0x2c77ae);},ae=function(..._0x6de1ff){const _0x54f8c0='FIREBASE\x20FATAL\x20ERROR:\x20'+zt(..._0x6de1ff);throw Ze['error'](_0x54f8c0),new Error(_0x54f8c0);},U=function(..._0x2e9779){const _0x105126='FIREBASE\x20WARNING:\x20'+zt(..._0x2e9779);Ze['warn'](_0x105126);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},xn=function(_0x5a823e){return typeof _0x5a823e=='number'&&(_0x5a823e!==_0x5a823e||_0x5a823e===Number['POSITIVE_INFINITY']||_0x5a823e===Number['NEGATIVE_INFINITY']);},Gl=function(_0x43c70b){if(document['readyState']==='complete')_0x43c70b();else{let _0x271a44=!0x1;const _0x6c36dd=function(){if(!document['body']){setTimeout(_0x6c36dd,Math['floor'](0xa));return;}_0x271a44||(_0x271a44=!0x0,_0x43c70b());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x6c36dd,!0x1),window['addEventListener']('load',_0x6c36dd,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x6c36dd();}),window['attachEvent']('onload',_0x6c36dd));}},We='[MIN_NAME]',we='[MAX_NAME]',qe=function(_0x16b5b2,_0x1c3979){if(_0x16b5b2===_0x1c3979)return 0x0;if(_0x16b5b2===We||_0x1c3979===we)return-0x1;if(_0x1c3979===We||_0x16b5b2===we)return 0x1;{const _0x212e34=Gs(_0x16b5b2),_0x463471=Gs(_0x1c3979);return _0x212e34!==null?_0x463471!==null?_0x212e34-_0x463471===0x0?_0x16b5b2['length']-_0x1c3979['length']:_0x212e34-_0x463471:-0x1:_0x463471!==null?0x1:_0x16b5b2<_0x1c3979?-0x1:0x1;}},ql=function(_0x10f041,_0xf98d39){return _0x10f041===_0xf98d39?0x0:_0x10f041<_0xf98d39?-0x1:0x1;},vt=function(_0x4af5a0,_0x1581bf){if(_0x1581bf&&_0x4af5a0 in _0x1581bf)return _0x1581bf[_0x4af5a0];throw new Error('Missing\x20required\x20key\x20('+_0x4af5a0+')\x20in\x20object:\x20'+O(_0x1581bf));},$i=function(_0x1cd005){if(typeof _0x1cd005!='object'||_0x1cd005===null)return O(_0x1cd005);const _0x46e016=[];for(const _0x52bf79 in _0x1cd005)_0x46e016['push'](_0x52bf79);_0x46e016['sort']();let _0x2531ee='{';for(let _0x1af14d=0x0;_0x1af14d<_0x46e016['length'];_0x1af14d++)_0x1af14d!==0x0&&(_0x2531ee+=','),_0x2531ee+=O(_0x46e016[_0x1af14d]),_0x2531ee+=':',_0x2531ee+=$i(_0x1cd005[_0x46e016[_0x1af14d]]);return _0x2531ee+='}',_0x2531ee;},oo=function(_0x5629f2,_0x2ce754){const _0x408d53=_0x5629f2['length'];if(_0x408d53<=_0x2ce754)return[_0x5629f2];const _0x599f9b=[];for(let _0x7ad73e=0x0;_0x7ad73e<_0x408d53;_0x7ad73e+=_0x2ce754)_0x7ad73e+_0x2ce754>_0x408d53?_0x599f9b['push'](_0x5629f2['substring'](_0x7ad73e,_0x408d53)):_0x599f9b['push'](_0x5629f2['substring'](_0x7ad73e,_0x7ad73e+_0x2ce754));return _0x599f9b;};function x(_0x2b01b4,_0x62fa29){for(const _0x2f7575 in _0x2b01b4)_0x2b01b4['hasOwnProperty'](_0x2f7575)&&_0x62fa29(_0x2f7575,_0x2b01b4[_0x2f7575]);}const ao=function(_0x5ddfc5){f(!xn(_0x5ddfc5),'Invalid\x20JSON\x20number');const _0x2e3b51=0xb,_0x596a92=0x34,_0x64c9b2=(0x1<<_0x2e3b51-0x1)-0x1;let _0x13d683,_0x1fcd31,_0x25dbd2,_0xfc01e2,_0x168969;_0x5ddfc5===0x0?(_0x1fcd31=0x0,_0x25dbd2=0x0,_0x13d683=0x1/_0x5ddfc5===-0x1/0x0?0x1:0x0):(_0x13d683=_0x5ddfc5<0x0,_0x5ddfc5=Math['abs'](_0x5ddfc5),_0x5ddfc5>=Math['pow'](0x2,0x1-_0x64c9b2)?(_0xfc01e2=Math['min'](Math['floor'](Math['log'](_0x5ddfc5)/Math['LN2']),_0x64c9b2),_0x1fcd31=_0xfc01e2+_0x64c9b2,_0x25dbd2=Math['round'](_0x5ddfc5*Math['pow'](0x2,_0x596a92-_0xfc01e2)-Math['pow'](0x2,_0x596a92))):(_0x1fcd31=0x0,_0x25dbd2=Math['round'](_0x5ddfc5/Math['pow'](0x2,0x1-_0x64c9b2-_0x596a92))));const _0x5241a7=[];for(_0x168969=_0x596a92;_0x168969;_0x168969-=0x1)_0x5241a7['push'](_0x25dbd2%0x2?0x1:0x0),_0x25dbd2=Math['floor'](_0x25dbd2/0x2);for(_0x168969=_0x2e3b51;_0x168969;_0x168969-=0x1)_0x5241a7['push'](_0x1fcd31%0x2?0x1:0x0),_0x1fcd31=Math['floor'](_0x1fcd31/0x2);_0x5241a7['push'](_0x13d683?0x1:0x0),_0x5241a7['reverse']();const _0x4bfe2e=_0x5241a7['join']('');let _0x58170f='';for(_0x168969=0x0;_0x168969<0x40;_0x168969+=0x8){let _0x32fcfa=parseInt(_0x4bfe2e['substr'](_0x168969,0x8),0x2)['toString'](0x10);_0x32fcfa['length']===0x1&&(_0x32fcfa='0'+_0x32fcfa),_0x58170f=_0x58170f+_0x32fcfa;}return _0x58170f['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x1e230d,_0x257363){let _0x352c1c='Unknown\x20Error';_0x1e230d==='too_big'?_0x352c1c='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x1e230d==='permission_denied'?_0x352c1c='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x1e230d==='unavailable'&&(_0x352c1c='The\x20service\x20is\x20unavailable');const _0x3255c6=new Error(_0x1e230d+'\x20at\x20'+_0x257363['_path']['toString']()+':\x20'+_0x352c1c);return _0x3255c6['code']=_0x1e230d['toUpperCase'](),_0x3255c6;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,Gs=function(_0x4b46ae){if(Yl['test'](_0x4b46ae)){const _0x2c4960=Number(_0x4b46ae);if(_0x2c4960>=Ql&&_0x2c4960<=Jl)return _0x2c4960;}return null;},ft=function(_0x22a6ae){try{_0x22a6ae();}catch(_0xd1fe61){setTimeout(()=>{const _0x47f01b=_0xd1fe61['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x47f01b),_0xd1fe61;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},bt=function(_0x4b8106,_0x37f4f9){const _0x238056=setTimeout(_0x4b8106,_0x37f4f9);return typeof _0x238056=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x238056):typeof _0x238056=='object'&&_0x238056['unref']&&_0x238056['unref'](),_0x238056;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x3b34a6,_0x505147){this['appCheckProvider']=_0x505147,this['appName']=_0x3b34a6['name'],$(_0x3b34a6)&&_0x3b34a6['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x3b34a6['settings']['appCheckToken']),this['appCheck']=_0x505147==null?void 0x0:_0x505147['getImmediate']({'optional':!0x0}),this['appCheck']||_0x505147==null||_0x505147['get']()['then'](_0x4fcd1c=>this['appCheck']=_0x4fcd1c);}['getToken'](_0x54d5db){if(this['serverAppAppCheckToken']){if(_0x54d5db)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x54d5db):new Promise((_0x101a8d,_0x1c0b74)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x54d5db)['then'](_0x101a8d,_0x1c0b74):_0x101a8d(null);},0x0);});}['addTokenChangeListener'](_0x5d0549){var _0x55f2b3;(_0x55f2b3=this['appCheckProvider'])==null||_0x55f2b3['get']()['then'](_0x5353e9=>_0x5353e9['addTokenListener'](_0x5d0549));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x4333c3,_0x40ca06,_0x4c24e6){this['appName_']=_0x4333c3,this['firebaseOptions_']=_0x40ca06,this['authProvider_']=_0x4c24e6,this['auth_']=null,this['auth_']=_0x4c24e6['getImmediate']({'optional':!0x0}),this['auth_']||_0x4c24e6['onInit'](_0x2098a5=>this['auth_']=_0x2098a5);}['getToken'](_0x3d7c4a){return this['auth_']?this['auth_']['getToken'](_0x3d7c4a)['catch'](_0x31f971=>_0x31f971&&_0x31f971['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x31f971)):new Promise((_0x597ead,_0x5487e8)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x3d7c4a)['then'](_0x597ead,_0x5487e8):_0x597ead(null);},0x0);});}['addTokenChangeListener'](_0x3d6ed4){this['auth_']?this['auth_']['addAuthTokenListener'](_0x3d6ed4):this['authProvider_']['get']()['then'](_0x1a5ae2=>_0x1a5ae2['addAuthTokenListener'](_0x3d6ed4));}['removeTokenChangeListener'](_0x5d9d1){this['authProvider_']['get']()['then'](_0x251986=>_0x251986['removeAuthTokenListener'](_0x5d9d1));}['notifyForInvalidToken'](){let _0x17b7f0='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x17b7f0+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x17b7f0+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x17b7f0+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x17b7f0);}}class an{constructor(_0x35e6fb){this['accessToken']=_0x35e6fb;}['getToken'](_0x27031d){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x4e9754){_0x4e9754(this['accessToken']);}['removeTokenChangeListener'](_0x19b4fb){}['notifyForInvalidToken'](){}}an['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gi='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',wi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x30fb44,_0x35d152,_0x4ba82d,_0x57acbe,_0x35a3be=!0x1,_0x385042='',_0x1fdf70=!0x1,_0x3c672a=!0x1,_0x8bc856=null){this['secure']=_0x35d152,this['namespace']=_0x4ba82d,this['webSocketOnly']=_0x57acbe,this['nodeAdmin']=_0x35a3be,this['persistenceKey']=_0x385042,this['includeNamespaceInQueryParams']=_0x1fdf70,this['isUsingEmulator']=_0x3c672a,this['emulatorOptions']=_0x8bc856,this['_host']=_0x30fb44['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=De['get']('host:'+_0x30fb44)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x3338fe){_0x3338fe!==this['internalHost']&&(this['internalHost']=_0x3338fe,this['isCacheableHost']()&&De['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x1eb1b2=this['toURLString']();return this['persistenceKey']&&(_0x1eb1b2+='<'+this['persistenceKey']+'>'),_0x1eb1b2;}['toURLString'](){const _0x3dea2f=this['secure']?'https://':'http://',_0x2e3444=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x3dea2f+this['host']+'/'+_0x2e3444;}}function th(_0x559a93){return _0x559a93['host']!==_0x559a93['internalHost']||_0x559a93['isCustomHost']()||_0x559a93['includeNamespaceInQueryParams'];}function vo(_0x19cc03,_0x54af4e,_0x3d0878){f(typeof _0x54af4e=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x3d0878=='object','typeof\x20params\x20must\x20==\x20object');let _0x10cc43;if(_0x54af4e===go)_0x10cc43=(_0x19cc03['secure']?'wss://':'ws://')+_0x19cc03['internalHost']+'/.ws?';else{if(_0x54af4e===mo)_0x10cc43=(_0x19cc03['secure']?'https://':'http://')+_0x19cc03['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x54af4e);}th(_0x19cc03)&&(_0x3d0878['ns']=_0x19cc03['namespace']);const _0x34313a=[];return x(_0x3d0878,(_0x52a796,_0x336d1a)=>{_0x34313a['push'](_0x52a796+'='+_0x336d1a);}),_0x10cc43+_0x34313a['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x80ad4b,_0x533862=0x1){Q(this['counters_'],_0x80ad4b)||(this['counters_'][_0x80ad4b]=0x0),this['counters_'][_0x80ad4b]+=_0x533862;}['get'](){return sc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const oi={},ai={};function qi(_0x19eb5e){const _0x18615c=_0x19eb5e['toString']();return oi[_0x18615c]||(oi[_0x18615c]=new nh()),oi[_0x18615c];}function ih(_0x5a792a,_0x16b840){const _0x2534f1=_0x5a792a['toString']();return ai[_0x2534f1]||(ai[_0x2534f1]=_0x16b840()),ai[_0x2534f1];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x34ccb9){this['onMessage_']=_0x34ccb9,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x297182,_0x352210){this['closeAfterResponse']=_0x297182,this['onClose']=_0x352210,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x4e9ff9,_0x5cd213){for(this['pendingResponses'][_0x4e9ff9]=_0x5cd213;this['pendingResponses'][this['currentResponseNum']];){const _0x172490=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x5dd433=0x0;_0x5dd433<_0x172490['length'];++_0x5dd433)_0x172490[_0x5dd433]&&ft(()=>{this['onMessage_'](_0x172490[_0x5dd433]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class Je{constructor(_0x277814,_0x40878c,_0xec7262,_0x39642,_0x1547a7,_0xda0df3,_0x57e674){this['connId']=_0x277814,this['repoInfo']=_0x40878c,this['applicationId']=_0xec7262,this['appCheckToken']=_0x39642,this['authToken']=_0x1547a7,this['transportSessionId']=_0xda0df3,this['lastSessionId']=_0x57e674,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=jt(_0x277814),this['stats_']=qi(_0x40878c),this['urlFn']=_0x54bb1c=>(this['appCheckToken']&&(_0x54bb1c[wi]=this['appCheckToken']),vo(_0x40878c,mo,_0x54bb1c));}['open'](_0x34892c,_0x1841fb){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x1841fb,this['myPacketOrderer']=new sh(_0x34892c),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new zi((..._0x305c76)=>{const [_0x2cacb3,_0x43009d,_0x10cf4a,_0x562c14,_0x53e481]=_0x305c76;if(this['incrementIncomingBytes_'](_0x305c76),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x2cacb3===qs)this['id']=_0x43009d,this['password']=_0x10cf4a;else{if(_0x2cacb3===rh)_0x43009d?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x43009d,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x2cacb3);}}},(..._0x50e71d)=>{const [_0x394266,_0x48bb70]=_0x50e71d;this['incrementIncomingBytes_'](_0x50e71d),this['myPacketOrderer']['handleResponse'](_0x394266,_0x48bb70);},()=>{this['onClosed_']();},this['urlFn']);const _0x4cf4a0={};_0x4cf4a0[qs]='t',_0x4cf4a0[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x4cf4a0[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x4cf4a0[co]=Gi,this['transportSessionId']&&(_0x4cf4a0[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x4cf4a0[po]=this['lastSessionId']),this['applicationId']&&(_0x4cf4a0[_o]=this['applicationId']),this['appCheckToken']&&(_0x4cf4a0[wi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x4cf4a0[ho]=uo);const _0x5da851=this['urlFn'](_0x4cf4a0);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x5da851),this['scriptTagHolder']['addTag'](_0x5da851,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){Je['forceAllow_']=!0x0;}static['forceDisallow'](){Je['forceDisallow_']=!0x0;}static['isAvailable'](){return Je['forceAllow_']?!0x0:!Je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x4afc82){const _0x22f33b=O(_0x4afc82);this['bytesSent']+=_0x22f33b['length'],this['stats_']['incrementCounter']('bytes_sent',_0x22f33b['length']);const _0x415379=$r(_0x22f33b),_0x44f38d=oo(_0x415379,fh);for(let _0x500dfb=0x0;_0x500dfb<_0x44f38d['length'];_0x500dfb++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x44f38d['length'],_0x44f38d[_0x500dfb]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x59eb58,_0x158467){this['myDisconnFrame']=document['createElement']('iframe');const _0x5b6dce={};_0x5b6dce[dh]='t',_0x5b6dce[Eo]=_0x59eb58,_0x5b6dce[Io]=_0x158467,this['myDisconnFrame']['src']=this['urlFn'](_0x5b6dce),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x2b5472){const _0x5e26ab=O(_0x2b5472)['length'];this['bytesReceived']+=_0x5e26ab,this['stats_']['incrementCounter']('bytes_received',_0x5e26ab);}}class zi{constructor(_0x13ed39,_0x531874,_0x3bda5f,_0x592949){this['onDisconnect']=_0x3bda5f,this['urlFn']=_0x592949,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x13ed39,window[ah+this['uniqueCallbackIdentifier']]=_0x531874,this['myIFrame']=zi['createIFrame_']();let _0x497741='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x497741='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x4ac8ff='<html><body>'+_0x497741+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x4ac8ff),this['myIFrame']['doc']['close']();}catch(_0x5a9a66){L('frame\x20writing\x20exception'),_0x5a9a66['stack']&&L(_0x5a9a66['stack']),L(_0x5a9a66);}}}static['createIFrame_'](){const _0x230610=document['createElement']('iframe');if(_0x230610['style']['display']='none',document['body']){document['body']['appendChild'](_0x230610);try{_0x230610['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x52ee52=document['domain'];_0x230610['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x52ee52+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x230610['contentDocument']?_0x230610['doc']=_0x230610['contentDocument']:_0x230610['contentWindow']?_0x230610['doc']=_0x230610['contentWindow']['document']:_0x230610['document']&&(_0x230610['doc']=_0x230610['document']),_0x230610;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x22fe77=this['onDisconnect'];_0x22fe77&&(this['onDisconnect']=null,_0x22fe77());}['startLongPoll'](_0x29dc40,_0x539c77){for(this['myID']=_0x29dc40,this['myPW']=_0x539c77,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x16a7d3={};_0x16a7d3[Eo]=this['myID'],_0x16a7d3[Io]=this['myPW'],_0x16a7d3[wo]=this['currentSerial'];let _0x353775=this['urlFn'](_0x16a7d3),_0x56561a='',_0xba038d=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x56561a['length']<=Co;){const _0x23bc0a=this['pendingSegs']['shift']();_0x56561a=_0x56561a+'&'+lh+_0xba038d+'='+_0x23bc0a['seg']+'&'+hh+_0xba038d+'='+_0x23bc0a['ts']+'&'+uh+_0xba038d+'='+_0x23bc0a['d'],_0xba038d++;}return _0x353775=_0x353775+_0x56561a,this['addLongPollTag_'](_0x353775,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x15f175,_0xb32df2,_0x318fbc){this['pendingSegs']['push']({'seg':_0x15f175,'ts':_0xb32df2,'d':_0x318fbc}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x4548be,_0x47c864){this['outstandingRequests']['add'](_0x47c864);const _0x1ca573=()=>{this['outstandingRequests']['delete'](_0x47c864),this['newRequest_']();},_0x273900=setTimeout(_0x1ca573,Math['floor'](ph)),_0x6233bb=()=>{clearTimeout(_0x273900),_0x1ca573();};this['addTag'](_0x4548be,_0x6233bb);}['addTag'](_0x374f42,_0x3ccd0b){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x2ff3ac=this['myIFrame']['doc']['createElement']('script');_0x2ff3ac['type']='text/javascript',_0x2ff3ac['async']=!0x0,_0x2ff3ac['src']=_0x374f42,_0x2ff3ac['onload']=_0x2ff3ac['onreadystatechange']=function(){const _0x5a0315=_0x2ff3ac['readyState'];(!_0x5a0315||_0x5a0315==='loaded'||_0x5a0315==='complete')&&(_0x2ff3ac['onload']=_0x2ff3ac['onreadystatechange']=null,_0x2ff3ac['parentNode']&&_0x2ff3ac['parentNode']['removeChild'](_0x2ff3ac),_0x3ccd0b());},_0x2ff3ac['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x374f42),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x2ff3ac);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let gn=null;typeof MozWebSocket<'u'?gn=MozWebSocket:typeof WebSocket<'u'&&(gn=WebSocket);class q{constructor(_0x2c45f6,_0x525372,_0x3efaa1,_0x395509,_0x2e2344,_0x29a3a0,_0x54766c){this['connId']=_0x2c45f6,this['applicationId']=_0x3efaa1,this['appCheckToken']=_0x395509,this['authToken']=_0x2e2344,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=jt(this['connId']),this['stats_']=qi(_0x525372),this['connURL']=q['connectionURL_'](_0x525372,_0x29a3a0,_0x54766c,_0x395509,_0x3efaa1),this['nodeAdmin']=_0x525372['nodeAdmin'];}static['connectionURL_'](_0x5cf6de,_0x40e55e,_0x48b0c4,_0x217297,_0x22672c){const _0x3da460={};return _0x3da460[co]=Gi,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x3da460[ho]=uo),_0x40e55e&&(_0x3da460[lo]=_0x40e55e),_0x48b0c4&&(_0x3da460[po]=_0x48b0c4),_0x217297&&(_0x3da460[wi]=_0x217297),_0x22672c&&(_0x3da460[_o]=_0x22672c),vo(_0x5cf6de,go,_0x3da460);}['open'](_0x16a623,_0x1bcf34){this['onDisconnect']=_0x1bcf34,this['onMessage']=_0x16a623,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,De['set']('previous_websocket_failure',!0x0);try{let _0x3198de;_c(),this['mySock']=new gn(this['connURL'],[],_0x3198de);}catch(_0x11f31a){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x16c4f3=_0x11f31a['message']||_0x11f31a['data'];_0x16c4f3&&this['log_'](_0x16c4f3),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x17d8a1=>{this['handleIncomingFrame'](_0x17d8a1);},this['mySock']['onerror']=_0x2594f4=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0xc8a893=_0x2594f4['message']||_0x2594f4['data'];_0xc8a893&&this['log_'](_0xc8a893),this['onClosed_']();};}['start'](){}static['forceDisallow'](){q['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x5c9b13=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x768f7c=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x524ff9=navigator['userAgent']['match'](_0x768f7c);_0x524ff9&&_0x524ff9['length']>0x1&&parseFloat(_0x524ff9[0x1])<4.4&&(_0x5c9b13=!0x0);}return!_0x5c9b13&&gn!==null&&!q['forceDisallow_'];}static['previouslyFailed'](){return De['isInMemoryStorage']||De['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){De['remove']('previous_websocket_failure');}['appendFrame_'](_0x3403a4){if(this['frames']['push'](_0x3403a4),this['frames']['length']===this['totalFrames']){const _0xa29d8d=this['frames']['join']('');this['frames']=null;const _0x274bb5=Nt(_0xa29d8d);this['onMessage'](_0x274bb5);}}['handleNewFrameCount_'](_0x4cdf76){this['totalFrames']=_0x4cdf76,this['frames']=[];}['extractFrameCount_'](_0x5ccf37){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x5ccf37['length']<=0x6){const _0x8fe57=Number(_0x5ccf37);if(!isNaN(_0x8fe57))return this['handleNewFrameCount_'](_0x8fe57),null;}return this['handleNewFrameCount_'](0x1),_0x5ccf37;}['handleIncomingFrame'](_0x738e6e){if(this['mySock']===null)return;const _0x4f9003=_0x738e6e['data'];if(this['bytesReceived']+=_0x4f9003['length'],this['stats_']['incrementCounter']('bytes_received',_0x4f9003['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x4f9003);else{const _0x33aaf0=this['extractFrameCount_'](_0x4f9003);_0x33aaf0!==null&&this['appendFrame_'](_0x33aaf0);}}['send'](_0x3f9350){this['resetKeepAlive']();const _0x237653=O(_0x3f9350);this['bytesSent']+=_0x237653['length'],this['stats_']['incrementCounter']('bytes_sent',_0x237653['length']);const _0x3d6614=oo(_0x237653,gh);_0x3d6614['length']>0x1&&this['sendString_'](String(_0x3d6614['length']));for(let _0x1246ce=0x0;_0x1246ce<_0x3d6614['length'];_0x1246ce++)this['sendString_'](_0x3d6614[_0x1246ce]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x357516){try{this['mySock']['send'](_0x357516);}catch(_0xa17ca6){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0xa17ca6['message']||_0xa17ca6['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}q['responsesRequiredToBeHealthy']=0x2,q['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dt{static get['ALL_TRANSPORTS'](){return[Je,q];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x5178c4){this['initTransports_'](_0x5178c4);}['initTransports_'](_0x79481){const _0x42dc56=q&&q['isAvailable']();let _0x11b161=_0x42dc56&&!q['previouslyFailed']();if(_0x79481['webSocketOnly']&&(_0x42dc56||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x11b161=!0x0),_0x11b161)this['transports_']=[q];else{const _0x2fd3f8=this['transports_']=[];for(const _0x51c939 of Dt['ALL_TRANSPORTS'])_0x51c939&&_0x51c939['isAvailable']()&&_0x2fd3f8['push'](_0x51c939);Dt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Dt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,ci='t',zs='d',wh='s',js='r',Ch='e',Ks='o',Ys='a',Qs='n',Js='p',Th='h';class Sh{constructor(_0x185694,_0x3e2e50,_0x48f195,_0x1ba1dc,_0xcf8d47,_0x261016,_0x13d579,_0x15991b,_0x384919,_0x410a1c){this['id']=_0x185694,this['repoInfo_']=_0x3e2e50,this['applicationId_']=_0x48f195,this['appCheckToken_']=_0x1ba1dc,this['authToken_']=_0xcf8d47,this['onMessage_']=_0x261016,this['onReady_']=_0x13d579,this['onDisconnect_']=_0x15991b,this['onKill_']=_0x384919,this['lastSessionId']=_0x410a1c,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=jt('c:'+this['id']+':'),this['transportManager_']=new Dt(_0x3e2e50),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x167319=this['transportManager_']['initialTransport']();this['conn_']=new _0x167319(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x167319['responsesRequiredToBeHealthy']||0x0;const _0x247360=this['connReceiver_'](this['conn_']),_0x34d8ad=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x247360,_0x34d8ad);},Math['floor'](0x0));const _0x2e083d=_0x167319['healthyTimeout']||0x0;_0x2e083d>0x0&&(this['healthyTimeout_']=bt(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x2e083d)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x2bf74a){return _0x594dac=>{_0x2bf74a===this['conn_']?this['onConnectionLost_'](_0x594dac):_0x2bf74a===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x1b6ab4){return _0x2e509c=>{this['state_']!==0x2&&(_0x1b6ab4===this['rx_']?this['onPrimaryMessageReceived_'](_0x2e509c):_0x1b6ab4===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x2e509c):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x1ad433){const _0x1f8927={'t':'d','d':_0x1ad433};this['sendData_'](_0x1f8927);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x3809a6){if(ci in _0x3809a6){const _0x325fc9=_0x3809a6[ci];_0x325fc9===Ys?this['upgradeIfSecondaryHealthy_']():_0x325fc9===js?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x325fc9===Ks&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x12b56f){const _0x5d86bb=vt('t',_0x12b56f),_0x8260e9=vt('d',_0x12b56f);if(_0x5d86bb==='c')this['onSecondaryControl_'](_0x8260e9);else{if(_0x5d86bb==='d')this['pendingDataMessages']['push'](_0x8260e9);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x5d86bb);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Js,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Ys,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x130a72){const _0x402d07=vt('t',_0x130a72),_0x3ea32=vt('d',_0x130a72);_0x402d07==='c'?this['onControl_'](_0x3ea32):_0x402d07==='d'&&this['onDataMessage_'](_0x3ea32);}['onDataMessage_'](_0xf84e7e){this['onPrimaryResponse_'](),this['onMessage_'](_0xf84e7e);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x20f358){const _0x55eff6=vt(ci,_0x20f358);if(zs in _0x20f358){const _0x5a7bde=_0x20f358[zs];if(_0x55eff6===Th){const _0x2c0a65={..._0x5a7bde};this['repoInfo_']['isUsingEmulator']&&(_0x2c0a65['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x2c0a65);}else{if(_0x55eff6===Qs){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x408ad8=0x0;_0x408ad8<this['pendingDataMessages']['length'];++_0x408ad8)this['onDataMessage_'](this['pendingDataMessages'][_0x408ad8]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x55eff6===wh?this['onConnectionShutdown_'](_0x5a7bde):_0x55eff6===js?this['onReset_'](_0x5a7bde):_0x55eff6===Ch?Ii('Server\x20Error:\x20'+_0x5a7bde):_0x55eff6===Ks?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):Ii('Unknown\x20control\x20packet\x20command:\x20'+_0x55eff6);}}}['onHandshake_'](_0x37b67a){const _0xd006cc=_0x37b67a['ts'],_0x693b5d=_0x37b67a['v'],_0x133a32=_0x37b67a['h'];this['sessionId']=_0x37b67a['s'],this['repoInfo_']['host']=_0x133a32,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0xd006cc),Gi!==_0x693b5d&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x5ffaa0=this['transportManager_']['upgradeTransport']();_0x5ffaa0&&this['startUpgrade_'](_0x5ffaa0);}['startUpgrade_'](_0x5ce6ba){this['secondaryConn_']=new _0x5ce6ba(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x5ce6ba['responsesRequiredToBeHealthy']||0x0;const _0x3d75a8=this['connReceiver_'](this['secondaryConn_']),_0x1fef33=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x3d75a8,_0x1fef33),bt(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x5ac754){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x5ac754),this['repoInfo_']['host']=_0x5ac754,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x39c0ce,_0x44e6b0){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x39c0ce,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x44e6b0,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):bt(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Js,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x9f279e=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x9f279e||this['rx_']===_0x9f279e)&&this['close']();}['onConnectionLost_'](_0x30ec6b){this['conn_']=null,!_0x30ec6b&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(De['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x3d27a7){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x3d27a7),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x3a1b85){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x3a1b85);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x4cbef4,_0x235758,_0x3c10ae,_0x127499){}['merge'](_0x18a64a,_0x5a3e1b,_0x4ef58c,_0x526ee7){}['refreshAuthToken'](_0xe407ec){}['refreshAppCheckToken'](_0xa3605d){}['onDisconnectPut'](_0xc134c7,_0x524914,_0x5637f3){}['onDisconnectMerge'](_0x2058d4,_0x1049ca,_0x4f5b3c){}['onDisconnectCancel'](_0x32cbfe,_0x22d112){}['reportStats'](_0xa004c){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x26ea5d){this['allowedEvents_']=_0x26ea5d,this['listeners_']={},f(Array['isArray'](_0x26ea5d)&&_0x26ea5d['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x5cd386,..._0x388396){if(Array['isArray'](this['listeners_'][_0x5cd386])){const _0x32b068=[...this['listeners_'][_0x5cd386]];for(let _0x7d4d07=0x0;_0x7d4d07<_0x32b068['length'];_0x7d4d07++)_0x32b068[_0x7d4d07]['callback']['apply'](_0x32b068[_0x7d4d07]['context'],_0x388396);}}['on'](_0x99a73f,_0x1f3f5d,_0x1215c8){this['validateEventType_'](_0x99a73f),this['listeners_'][_0x99a73f]=this['listeners_'][_0x99a73f]||[],this['listeners_'][_0x99a73f]['push']({'callback':_0x1f3f5d,'context':_0x1215c8});const _0x352bb8=this['getInitialEvent'](_0x99a73f);_0x352bb8&&_0x1f3f5d['apply'](_0x1215c8,_0x352bb8);}['off'](_0x538576,_0xc51186,_0x3a8fc5){this['validateEventType_'](_0x538576);const _0x107c89=this['listeners_'][_0x538576]||[];for(let _0x12fe48=0x0;_0x12fe48<_0x107c89['length'];_0x12fe48++)if(_0x107c89[_0x12fe48]['callback']===_0xc51186&&(!_0x3a8fc5||_0x3a8fc5===_0x107c89[_0x12fe48]['context'])){_0x107c89['splice'](_0x12fe48,0x1);return;}}['validateEventType_'](_0x4c0700){f(this['allowedEvents_']['find'](_0x1a5977=>_0x1a5977===_0x4c0700),'Unknown\x20event:\x20'+_0x4c0700);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class mn extends bo{static['getInstance'](){return new mn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Wi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x206bc4){return f(_0x206bc4==='online','Unknown\x20event\x20type:\x20'+_0x206bc4),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Xs=0x20,Zs=0x300;class C{constructor(_0x380dfe,_0x20a44a){if(_0x20a44a===void 0x0){this['pieces_']=_0x380dfe['split']('/');let _0x541366=0x0;for(let _0x49fb1a=0x0;_0x49fb1a<this['pieces_']['length'];_0x49fb1a++)this['pieces_'][_0x49fb1a]['length']>0x0&&(this['pieces_'][_0x541366]=this['pieces_'][_0x49fb1a],_0x541366++);this['pieces_']['length']=_0x541366,this['pieceNum_']=0x0;}else this['pieces_']=_0x380dfe,this['pieceNum_']=_0x20a44a;}['toString'](){let _0x65410b='';for(let _0x5a1b6b=this['pieceNum_'];_0x5a1b6b<this['pieces_']['length'];_0x5a1b6b++)this['pieces_'][_0x5a1b6b]!==''&&(_0x65410b+='/'+this['pieces_'][_0x5a1b6b]);return _0x65410b||'/';}}function w(){return new C('');}function y(_0x59839c){return _0x59839c['pieceNum_']>=_0x59839c['pieces_']['length']?null:_0x59839c['pieces_'][_0x59839c['pieceNum_']];}function Ce(_0x2bc4dd){return _0x2bc4dd['pieces_']['length']-_0x2bc4dd['pieceNum_'];}function S(_0x594686){let _0x5508ce=_0x594686['pieceNum_'];return _0x5508ce<_0x594686['pieces_']['length']&&_0x5508ce++,new C(_0x594686['pieces_'],_0x5508ce);}function ji(_0x111910){return _0x111910['pieceNum_']<_0x111910['pieces_']['length']?_0x111910['pieces_'][_0x111910['pieces_']['length']-0x1]:null;}function bh(_0x24d7ec){let _0x440aca='';for(let _0x53f555=_0x24d7ec['pieceNum_'];_0x53f555<_0x24d7ec['pieces_']['length'];_0x53f555++)_0x24d7ec['pieces_'][_0x53f555]!==''&&(_0x440aca+='/'+encodeURIComponent(String(_0x24d7ec['pieces_'][_0x53f555])));return _0x440aca||'/';}function Mt(_0x10705e,_0x1bf882=0x0){return _0x10705e['pieces_']['slice'](_0x10705e['pieceNum_']+_0x1bf882);}function Ro(_0x5361ea){if(_0x5361ea['pieceNum_']>=_0x5361ea['pieces_']['length'])return null;const _0x4f296b=[];for(let _0x3865c8=_0x5361ea['pieceNum_'];_0x3865c8<_0x5361ea['pieces_']['length']-0x1;_0x3865c8++)_0x4f296b['push'](_0x5361ea['pieces_'][_0x3865c8]);return new C(_0x4f296b,0x0);}function k(_0x1b44e7,_0x2112e4){const _0x387982=[];for(let _0x290311=_0x1b44e7['pieceNum_'];_0x290311<_0x1b44e7['pieces_']['length'];_0x290311++)_0x387982['push'](_0x1b44e7['pieces_'][_0x290311]);if(_0x2112e4 instanceof C){for(let _0x1feb0a=_0x2112e4['pieceNum_'];_0x1feb0a<_0x2112e4['pieces_']['length'];_0x1feb0a++)_0x387982['push'](_0x2112e4['pieces_'][_0x1feb0a]);}else{const _0x3882cb=_0x2112e4['split']('/');for(let _0x21a7c8=0x0;_0x21a7c8<_0x3882cb['length'];_0x21a7c8++)_0x3882cb[_0x21a7c8]['length']>0x0&&_0x387982['push'](_0x3882cb[_0x21a7c8]);}return new C(_0x387982,0x0);}function v(_0x42fc9e){return _0x42fc9e['pieceNum_']>=_0x42fc9e['pieces_']['length'];}function F(_0x559fdb,_0x5e341e){const _0x4db720=y(_0x559fdb),_0x2a7bc1=y(_0x5e341e);if(_0x4db720===null)return _0x5e341e;if(_0x4db720===_0x2a7bc1)return F(S(_0x559fdb),S(_0x5e341e));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x5e341e+')\x20is\x20not\x20within\x20outerPath\x20('+_0x559fdb+')');}function Rh(_0x62c797,_0x596ca5){const _0x5a760a=Mt(_0x62c797,0x0),_0xbe7e9d=Mt(_0x596ca5,0x0);for(let _0x23b1c2=0x0;_0x23b1c2<_0x5a760a['length']&&_0x23b1c2<_0xbe7e9d['length'];_0x23b1c2++){const _0x152b03=qe(_0x5a760a[_0x23b1c2],_0xbe7e9d[_0x23b1c2]);if(_0x152b03!==0x0)return _0x152b03;}return _0x5a760a['length']===_0xbe7e9d['length']?0x0:_0x5a760a['length']<_0xbe7e9d['length']?-0x1:0x1;}function Ki(_0x2c5410,_0x3fd72e){if(Ce(_0x2c5410)!==Ce(_0x3fd72e))return!0x1;for(let _0x42eea4=_0x2c5410['pieceNum_'],_0x3cd740=_0x3fd72e['pieceNum_'];_0x42eea4<=_0x2c5410['pieces_']['length'];_0x42eea4++,_0x3cd740++)if(_0x2c5410['pieces_'][_0x42eea4]!==_0x3fd72e['pieces_'][_0x3cd740])return!0x1;return!0x0;}function G(_0x3d2e32,_0x59b61d){let _0x57421e=_0x3d2e32['pieceNum_'],_0x4235b8=_0x59b61d['pieceNum_'];if(Ce(_0x3d2e32)>Ce(_0x59b61d))return!0x1;for(;_0x57421e<_0x3d2e32['pieces_']['length'];){if(_0x3d2e32['pieces_'][_0x57421e]!==_0x59b61d['pieces_'][_0x4235b8])return!0x1;++_0x57421e,++_0x4235b8;}return!0x0;}class Ah{constructor(_0x2f0cfa,_0x50a8f5){this['errorPrefix_']=_0x50a8f5,this['parts_']=Mt(_0x2f0cfa,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x5870e0=0x0;_0x5870e0<this['parts_']['length'];_0x5870e0++)this['byteLength_']+=Ln(this['parts_'][_0x5870e0]);Ao(this);}}function kh(_0x3699b4,_0x2ad006){_0x3699b4['parts_']['length']>0x0&&(_0x3699b4['byteLength_']+=0x1),_0x3699b4['parts_']['push'](_0x2ad006),_0x3699b4['byteLength_']+=Ln(_0x2ad006),Ao(_0x3699b4);}function Ph(_0x2000bd){const _0x238d18=_0x2000bd['parts_']['pop']();_0x2000bd['byteLength_']-=Ln(_0x238d18),_0x2000bd['parts_']['length']>0x0&&(_0x2000bd['byteLength_']-=0x1);}function Ao(_0xc6fc3c){if(_0xc6fc3c['byteLength_']>Zs)throw new Error(_0xc6fc3c['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+Zs+'\x20bytes\x20('+_0xc6fc3c['byteLength_']+').');if(_0xc6fc3c['parts_']['length']>Xs)throw new Error(_0xc6fc3c['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Xs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Oe(_0xc6fc3c));}function Oe(_0x2ac564){return _0x2ac564['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x2ac564['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yi extends bo{static['getInstance'](){return new Yi();}constructor(){super(['visible']);let _0x10df1a,_0x40d605;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x40d605='visibilitychange',_0x10df1a='hidden'):typeof document['mozHidden']<'u'?(_0x40d605='mozvisibilitychange',_0x10df1a='mozHidden'):typeof document['msHidden']<'u'?(_0x40d605='msvisibilitychange',_0x10df1a='msHidden'):typeof document['webkitHidden']<'u'&&(_0x40d605='webkitvisibilitychange',_0x10df1a='webkitHidden')),this['visible_']=!0x0,_0x40d605&&document['addEventListener'](_0x40d605,()=>{const _0x39ece3=!document[_0x10df1a];_0x39ece3!==this['visible_']&&(this['visible_']=_0x39ece3,this['trigger']('visible',_0x39ece3));},!0x1);}['getInitialEvent'](_0x1f1c16){return f(_0x1f1c16==='visible','Unknown\x20event\x20type:\x20'+_0x1f1c16),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Et=0x3e8,Nh=0x12c*0x3e8,er=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',tr=0x3;class se extends So{constructor(_0x23efbb,_0x34258b,_0x6e13d1,_0x2d1c58,_0xe26ad2,_0x4f5445,_0x266d0a,_0x3c8c3a){if(super(),this['repoInfo_']=_0x23efbb,this['applicationId_']=_0x34258b,this['onDataUpdate_']=_0x6e13d1,this['onConnectStatus_']=_0x2d1c58,this['onServerInfoUpdate_']=_0xe26ad2,this['authTokenProvider_']=_0x4f5445,this['appCheckTokenProvider_']=_0x266d0a,this['authOverride_']=_0x3c8c3a,this['id']=se['nextPersistentConnectionId_']++,this['log_']=jt('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=Et,this['maxReconnectDelay_']=Nh,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x3c8c3a)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Yi['getInstance']()['on']('visible',this['onVisible_'],this),_0x23efbb['host']['indexOf']('fblocal')===-0x1&&mn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x28ab74,_0x3a163e,_0x3f45bd){const _0x4bff91=++this['requestNumber_'],_0x3778c8={'r':_0x4bff91,'a':_0x28ab74,'b':_0x3a163e};this['log_'](O(_0x3778c8)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x3778c8),_0x3f45bd&&(this['requestCBHash_'][_0x4bff91]=_0x3f45bd);}['get'](_0x13ca0c){this['initConnection_']();const _0xcac449=new H(),_0x3d793c={'action':'g','request':{'p':_0x13ca0c['_path']['toString'](),'q':_0x13ca0c['_queryObject']},'onComplete':_0x5b8af7=>{const _0x46a516=_0x5b8af7['d'];_0x5b8af7['s']==='ok'?_0xcac449['resolve'](_0x46a516):_0xcac449['reject'](_0x46a516);}};this['outstandingGets_']['push'](_0x3d793c),this['outstandingGetCount_']++;const _0x4b3f08=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x4b3f08),_0xcac449['promise'];}['listen'](_0x34b113,_0x31eae1,_0x56beb8,_0x4f129e){this['initConnection_']();const _0x3c0e69=_0x34b113['_queryIdentifier'],_0x54a33e=_0x34b113['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x54a33e+'\x20'+_0x3c0e69),this['listens']['has'](_0x54a33e)||this['listens']['set'](_0x54a33e,new Map()),f(_0x34b113['_queryParams']['isDefault']()||!_0x34b113['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x54a33e)['has'](_0x3c0e69),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x51df13={'onComplete':_0x4f129e,'hashFn':_0x31eae1,'query':_0x34b113,'tag':_0x56beb8};this['listens']['get'](_0x54a33e)['set'](_0x3c0e69,_0x51df13),this['connected_']&&this['sendListen_'](_0x51df13);}['sendGet_'](_0xc937c8){const _0x57705a=this['outstandingGets_'][_0xc937c8];this['sendRequest']('g',_0x57705a['request'],_0x588fe3=>{delete this['outstandingGets_'][_0xc937c8],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x57705a['onComplete']&&_0x57705a['onComplete'](_0x588fe3);});}['sendListen_'](_0x129ea8){const _0x25c93e=_0x129ea8['query'],_0x1352b0=_0x25c93e['_path']['toString'](),_0x287b9d=_0x25c93e['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x1352b0+'\x20for\x20'+_0x287b9d);const _0x5e4e96={'p':_0x1352b0},_0x301cca='q';_0x129ea8['tag']&&(_0x5e4e96['q']=_0x25c93e['_queryObject'],_0x5e4e96['t']=_0x129ea8['tag']),_0x5e4e96['h']=_0x129ea8['hashFn'](),this['sendRequest'](_0x301cca,_0x5e4e96,_0x17bf3e=>{const _0x18873e=_0x17bf3e['d'],_0x43eb5b=_0x17bf3e['s'];se['warnOnListenWarnings_'](_0x18873e,_0x25c93e),(this['listens']['get'](_0x1352b0)&&this['listens']['get'](_0x1352b0)['get'](_0x287b9d))===_0x129ea8&&(this['log_']('listen\x20response',_0x17bf3e),_0x43eb5b!=='ok'&&this['removeListen_'](_0x1352b0,_0x287b9d),_0x129ea8['onComplete']&&_0x129ea8['onComplete'](_0x43eb5b,_0x18873e));});}static['warnOnListenWarnings_'](_0x3c37b5,_0x4429bd){if(_0x3c37b5&&typeof _0x3c37b5=='object'&&Q(_0x3c37b5,'w')){const _0x12a18b=Le(_0x3c37b5,'w');if(Array['isArray'](_0x12a18b)&&~_0x12a18b['indexOf']('no_index')){const _0x10619c='\x22.indexOn\x22:\x20\x22'+_0x4429bd['_queryParams']['getIndex']()['toString']()+'\x22',_0x54fb04=_0x4429bd['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x10619c+'\x20at\x20'+_0x54fb04+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x58afe1){this['authToken_']=_0x58afe1,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x58afe1);}['reduceReconnectDelayIfAdminCredential_'](_0x295b82){(_0x295b82&&_0x295b82['length']===0x28||wc(_0x295b82))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=er);}['refreshAppCheckToken'](_0x4f9cba){this['appCheckToken_']=_0x4f9cba,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x19045a=this['authToken_'],_0x3cb8ea=Ic(_0x19045a)?'auth':'gauth',_0x355fbc={'cred':_0x19045a};this['authOverride_']===null?_0x355fbc['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x355fbc['authvar']=this['authOverride_']),this['sendRequest'](_0x3cb8ea,_0x355fbc,_0x310971=>{const _0x23e686=_0x310971['s'],_0x2d648e=_0x310971['d']||'error';this['authToken_']===_0x19045a&&(_0x23e686==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x23e686,_0x2d648e));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x41e7fe=>{const _0x2eedb1=_0x41e7fe['s'],_0x37d12f=_0x41e7fe['d']||'error';_0x2eedb1==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x2eedb1,_0x37d12f);});}['unlisten'](_0x504768,_0x2d934c){const _0x4466c7=_0x504768['_path']['toString'](),_0x1043b5=_0x504768['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x4466c7+'\x20'+_0x1043b5),f(_0x504768['_queryParams']['isDefault']()||!_0x504768['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x4466c7,_0x1043b5)&&this['connected_']&&this['sendUnlisten_'](_0x4466c7,_0x1043b5,_0x504768['_queryObject'],_0x2d934c);}['sendUnlisten_'](_0x1ff086,_0x4d5f8e,_0x1562db,_0x82b2c4){this['log_']('Unlisten\x20on\x20'+_0x1ff086+'\x20for\x20'+_0x4d5f8e);const _0x244f16={'p':_0x1ff086},_0x340eb3='n';_0x82b2c4&&(_0x244f16['q']=_0x1562db,_0x244f16['t']=_0x82b2c4),this['sendRequest'](_0x340eb3,_0x244f16);}['onDisconnectPut'](_0x3861b1,_0x23a40,_0x52333f){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x3861b1,_0x23a40,_0x52333f):this['onDisconnectRequestQueue_']['push']({'pathString':_0x3861b1,'action':'o','data':_0x23a40,'onComplete':_0x52333f});}['onDisconnectMerge'](_0x23635b,_0x2eca02,_0x32555e){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x23635b,_0x2eca02,_0x32555e):this['onDisconnectRequestQueue_']['push']({'pathString':_0x23635b,'action':'om','data':_0x2eca02,'onComplete':_0x32555e});}['onDisconnectCancel'](_0x1afe94,_0x1a0b74){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x1afe94,null,_0x1a0b74):this['onDisconnectRequestQueue_']['push']({'pathString':_0x1afe94,'action':'oc','data':null,'onComplete':_0x1a0b74});}['sendOnDisconnect_'](_0x13eae0,_0x18cb9a,_0x2b6fbf,_0x31d8c7){const _0x37535a={'p':_0x18cb9a,'d':_0x2b6fbf};this['log_']('onDisconnect\x20'+_0x13eae0,_0x37535a),this['sendRequest'](_0x13eae0,_0x37535a,_0x28cfc2=>{_0x31d8c7&&setTimeout(()=>{_0x31d8c7(_0x28cfc2['s'],_0x28cfc2['d']);},Math['floor'](0x0));});}['put'](_0x582125,_0x34d0d6,_0xaa1857,_0x25a500){this['putInternal']('p',_0x582125,_0x34d0d6,_0xaa1857,_0x25a500);}['merge'](_0x3268c1,_0x12493c,_0x158a94,_0x4f41b7){this['putInternal']('m',_0x3268c1,_0x12493c,_0x158a94,_0x4f41b7);}['putInternal'](_0x26dcd6,_0x410af6,_0x50c8c7,_0x8f0acb,_0xfb02bf){this['initConnection_']();const _0x33c6b7={'p':_0x410af6,'d':_0x50c8c7};_0xfb02bf!==void 0x0&&(_0x33c6b7['h']=_0xfb02bf),this['outstandingPuts_']['push']({'action':_0x26dcd6,'request':_0x33c6b7,'onComplete':_0x8f0acb}),this['outstandingPutCount_']++;const _0xcae0e4=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0xcae0e4):this['log_']('Buffering\x20put:\x20'+_0x410af6);}['sendPut_'](_0x5ec654){const _0x5196f9=this['outstandingPuts_'][_0x5ec654]['action'],_0x3c41db=this['outstandingPuts_'][_0x5ec654]['request'],_0xa2f9fc=this['outstandingPuts_'][_0x5ec654]['onComplete'];this['outstandingPuts_'][_0x5ec654]['queued']=this['connected_'],this['sendRequest'](_0x5196f9,_0x3c41db,_0x1428b7=>{this['log_'](_0x5196f9+'\x20response',_0x1428b7),delete this['outstandingPuts_'][_0x5ec654],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0xa2f9fc&&_0xa2f9fc(_0x1428b7['s'],_0x1428b7['d']);});}['reportStats'](_0x435ccf){if(this['connected_']){const _0x78e108={'c':_0x435ccf};this['log_']('reportStats',_0x78e108),this['sendRequest']('s',_0x78e108,_0x50a2c1=>{if(_0x50a2c1['s']!=='ok'){const _0x5137b7=_0x50a2c1['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x5137b7);}});}}['onDataMessage_'](_0x4406e6){if('r'in _0x4406e6){this['log_']('from\x20server:\x20'+O(_0x4406e6));const _0x4cde47=_0x4406e6['r'],_0x5993bb=this['requestCBHash_'][_0x4cde47];_0x5993bb&&(delete this['requestCBHash_'][_0x4cde47],_0x5993bb(_0x4406e6['b']));}else{if('error'in _0x4406e6)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x4406e6['error'];'a'in _0x4406e6&&this['onDataPush_'](_0x4406e6['a'],_0x4406e6['b']);}}['onDataPush_'](_0x28e37e,_0x2b4b87){this['log_']('handleServerMessage',_0x28e37e,_0x2b4b87),_0x28e37e==='d'?this['onDataUpdate_'](_0x2b4b87['p'],_0x2b4b87['d'],!0x1,_0x2b4b87['t']):_0x28e37e==='m'?this['onDataUpdate_'](_0x2b4b87['p'],_0x2b4b87['d'],!0x0,_0x2b4b87['t']):_0x28e37e==='c'?this['onListenRevoked_'](_0x2b4b87['p'],_0x2b4b87['q']):_0x28e37e==='ac'?this['onAuthRevoked_'](_0x2b4b87['s'],_0x2b4b87['d']):_0x28e37e==='apc'?this['onAppCheckRevoked_'](_0x2b4b87['s'],_0x2b4b87['d']):_0x28e37e==='sd'?this['onSecurityDebugPacket_'](_0x2b4b87):Ii('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x28e37e)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x10a051,_0x455234){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x10a051),this['lastSessionId']=_0x455234,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x251bd7){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x251bd7));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x447067){_0x447067&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x447067;}['onOnline_'](_0x1479f4){_0x1479f4?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=Et),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x5b4108=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x70ada3=Math['max'](0x0,this['reconnectDelay_']-_0x5b4108);_0x70ada3=Math['random']()*_0x70ada3,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x70ada3+'ms'),this['scheduleConnect_'](_0x70ada3),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x3012ce=this['onDataMessage_']['bind'](this),_0x5d0efb=this['onReady_']['bind'](this),_0x57ea4d=this['onRealtimeDisconnect_']['bind'](this),_0x2f011d=this['id']+':'+se['nextConnectionId_']++,_0x3d9e63=this['lastSessionId'];let _0x233b2a=!0x1,_0x320fc7=null;const _0xf4ebcd=function(){_0x320fc7?_0x320fc7['close']():(_0x233b2a=!0x0,_0x57ea4d());},_0x2fe102=function(_0x3e2272){f(_0x320fc7,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x320fc7['sendRequest'](_0x3e2272);};this['realtime_']={'close':_0xf4ebcd,'sendRequest':_0x2fe102};const _0x3a69d6=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x11f1a6,_0x473306]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x3a69d6),this['appCheckTokenProvider_']['getToken'](_0x3a69d6)]);_0x233b2a?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x11f1a6&&_0x11f1a6['accessToken'],this['appCheckToken_']=_0x473306&&_0x473306['token'],_0x320fc7=new Sh(_0x2f011d,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x3012ce,_0x5d0efb,_0x57ea4d,_0x1ad9eb=>{U(_0x1ad9eb+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x3d9e63));}catch(_0x1e86a6){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x1e86a6),_0x233b2a||(this['repoInfo_']['nodeAdmin']&&U(_0x1e86a6),_0xf4ebcd());}}}['interrupt'](_0x180a91){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x180a91),this['interruptReasons_'][_0x180a91]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x49fcf9){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x49fcf9),delete this['interruptReasons_'][_0x49fcf9],pn(this['interruptReasons_'])&&(this['reconnectDelay_']=Et,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x4491c2){const _0x3a627d=_0x4491c2-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x3a627d});}['cancelSentTransactions_'](){for(let _0x397abc=0x0;_0x397abc<this['outstandingPuts_']['length'];_0x397abc++){const _0x454363=this['outstandingPuts_'][_0x397abc];_0x454363&&'h'in _0x454363['request']&&_0x454363['queued']&&(_0x454363['onComplete']&&_0x454363['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x397abc],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x8c0b3a,_0x30bb0c){let _0x30ffe4;_0x30bb0c?_0x30ffe4=_0x30bb0c['map'](_0x56c014=>$i(_0x56c014))['join']('$'):_0x30ffe4='default';const _0x328321=this['removeListen_'](_0x8c0b3a,_0x30ffe4);_0x328321&&_0x328321['onComplete']&&_0x328321['onComplete']('permission_denied');}['removeListen_'](_0x357d03,_0x601626){const _0x2798fc=new C(_0x357d03)['toString']();let _0x284891;if(this['listens']['has'](_0x2798fc)){const _0x122810=this['listens']['get'](_0x2798fc);_0x284891=_0x122810['get'](_0x601626),_0x122810['delete'](_0x601626),_0x122810['size']===0x0&&this['listens']['delete'](_0x2798fc);}else _0x284891=void 0x0;return _0x284891;}['onAuthRevoked_'](_0xb48b47,_0x2bae20){L('Auth\x20token\x20revoked:\x20'+_0xb48b47+'/'+_0x2bae20),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0xb48b47==='invalid_token'||_0xb48b47==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=tr&&(this['reconnectDelay_']=er,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x44badd,_0x52408f){L('App\x20check\x20token\x20revoked:\x20'+_0x44badd+'/'+_0x52408f),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x44badd==='invalid_token'||_0x44badd==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=tr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x4781d6){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x4781d6):'msg'in _0x4781d6&&console['log']('FIREBASE:\x20'+_0x4781d6['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x40a846 of this['listens']['values']())for(const _0x3aca65 of _0x40a846['values']())this['sendListen_'](_0x3aca65);for(let _0x4855a3=0x0;_0x4855a3<this['outstandingPuts_']['length'];_0x4855a3++)this['outstandingPuts_'][_0x4855a3]&&this['sendPut_'](_0x4855a3);for(;this['onDisconnectRequestQueue_']['length'];){const _0x1972c6=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x1972c6['action'],_0x1972c6['pathString'],_0x1972c6['data'],_0x1972c6['onComplete']);}for(let _0x28a503=0x0;_0x28a503<this['outstandingGets_']['length'];_0x28a503++)this['outstandingGets_'][_0x28a503]&&this['sendGet_'](_0x28a503);}['sendConnectStats_'](){const _0x397b57={};let _0x406b67='js';_0x397b57['sdk.'+_0x406b67+'.'+no['replace'](/\./g,'-')]=0x1,Wi()?_0x397b57['framework.cordova']=0x1:Kr()&&(_0x397b57['framework.reactnative']=0x1),this['reportStats'](_0x397b57);}['shouldReconnect_'](){const _0x6ab021=mn['getInstance']()['currentlyOnline']();return pn(this['interruptReasons_'])&&_0x6ab021;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0xf5ee66,_0x152368){this['name']=_0xf5ee66,this['node']=_0x152368;}static['Wrap'](_0x5916f5,_0x2ac9b2){return new E(_0x5916f5,_0x2ac9b2);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Fn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x153c6f,_0xc7a338){const _0x3664b8=new E(We,_0x153c6f),_0xaf30ff=new E(We,_0xc7a338);return this['compare'](_0x3664b8,_0xaf30ff)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let sn;class ko extends Fn{static get['__EMPTY_NODE'](){return sn;}static set['__EMPTY_NODE'](_0x2c6af2){sn=_0x2c6af2;}['compare'](_0x5762e4,_0x49e563){return qe(_0x5762e4['name'],_0x49e563['name']);}['isDefinedOn'](_0x442e89){throw ht('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x20322a,_0x10c9b2){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,sn);}['makePost'](_0x518726,_0x44663d){return f(typeof _0x518726=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x518726,sn);}['toString'](){return'.key';}}const ve=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class rn{constructor(_0xcbad8e,_0x1d0e32,_0x29a3a5,_0x17d584,_0x41af44=null){this['isReverse_']=_0x17d584,this['resultGenerator_']=_0x41af44,this['nodeStack_']=[];let _0x568228=0x1;for(;!_0xcbad8e['isEmpty']();)if(_0xcbad8e=_0xcbad8e,_0x568228=_0x1d0e32?_0x29a3a5(_0xcbad8e['key'],_0x1d0e32):0x1,_0x17d584&&(_0x568228*=-0x1),_0x568228<0x0)this['isReverse_']?_0xcbad8e=_0xcbad8e['left']:_0xcbad8e=_0xcbad8e['right'];else{if(_0x568228===0x0){this['nodeStack_']['push'](_0xcbad8e);break;}else this['nodeStack_']['push'](_0xcbad8e),this['isReverse_']?_0xcbad8e=_0xcbad8e['right']:_0xcbad8e=_0xcbad8e['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x2e76c8=this['nodeStack_']['pop'](),_0x4d3c55;if(this['resultGenerator_']?_0x4d3c55=this['resultGenerator_'](_0x2e76c8['key'],_0x2e76c8['value']):_0x4d3c55={'key':_0x2e76c8['key'],'value':_0x2e76c8['value']},this['isReverse_']){for(_0x2e76c8=_0x2e76c8['left'];!_0x2e76c8['isEmpty']();)this['nodeStack_']['push'](_0x2e76c8),_0x2e76c8=_0x2e76c8['right'];}else{for(_0x2e76c8=_0x2e76c8['right'];!_0x2e76c8['isEmpty']();)this['nodeStack_']['push'](_0x2e76c8),_0x2e76c8=_0x2e76c8['left'];}return _0x4d3c55;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x4a3831=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x4a3831['key'],_0x4a3831['value']):{'key':_0x4a3831['key'],'value':_0x4a3831['value']};}}class M{constructor(_0x4703cd,_0x22a86f,_0x1d22c4,_0x2a1f92,_0x546219){this['key']=_0x4703cd,this['value']=_0x22a86f,this['color']=_0x1d22c4??M['RED'],this['left']=_0x2a1f92??B['EMPTY_NODE'],this['right']=_0x546219??B['EMPTY_NODE'];}['copy'](_0x1ace08,_0x5d90d3,_0x2d62a2,_0x324773,_0x4b7bcc){return new M(_0x1ace08??this['key'],_0x5d90d3??this['value'],_0x2d62a2??this['color'],_0x324773??this['left'],_0x4b7bcc??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x4ac271){return this['left']['inorderTraversal'](_0x4ac271)||!!_0x4ac271(this['key'],this['value'])||this['right']['inorderTraversal'](_0x4ac271);}['reverseTraversal'](_0x3508bc){return this['right']['reverseTraversal'](_0x3508bc)||_0x3508bc(this['key'],this['value'])||this['left']['reverseTraversal'](_0x3508bc);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x4f8d3f,_0x2d994a,_0xd0c1a5){let _0x54a830=this;const _0x6ea1a8=_0xd0c1a5(_0x4f8d3f,_0x54a830['key']);return _0x6ea1a8<0x0?_0x54a830=_0x54a830['copy'](null,null,null,_0x54a830['left']['insert'](_0x4f8d3f,_0x2d994a,_0xd0c1a5),null):_0x6ea1a8===0x0?_0x54a830=_0x54a830['copy'](null,_0x2d994a,null,null,null):_0x54a830=_0x54a830['copy'](null,null,null,null,_0x54a830['right']['insert'](_0x4f8d3f,_0x2d994a,_0xd0c1a5)),_0x54a830['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x10bc50=this;return!_0x10bc50['left']['isRed_']()&&!_0x10bc50['left']['left']['isRed_']()&&(_0x10bc50=_0x10bc50['moveRedLeft_']()),_0x10bc50=_0x10bc50['copy'](null,null,null,_0x10bc50['left']['removeMin_'](),null),_0x10bc50['fixUp_']();}['remove'](_0x570593,_0x39495a){let _0x557c07,_0x1bd946;if(_0x557c07=this,_0x39495a(_0x570593,_0x557c07['key'])<0x0)!_0x557c07['left']['isEmpty']()&&!_0x557c07['left']['isRed_']()&&!_0x557c07['left']['left']['isRed_']()&&(_0x557c07=_0x557c07['moveRedLeft_']()),_0x557c07=_0x557c07['copy'](null,null,null,_0x557c07['left']['remove'](_0x570593,_0x39495a),null);else{if(_0x557c07['left']['isRed_']()&&(_0x557c07=_0x557c07['rotateRight_']()),!_0x557c07['right']['isEmpty']()&&!_0x557c07['right']['isRed_']()&&!_0x557c07['right']['left']['isRed_']()&&(_0x557c07=_0x557c07['moveRedRight_']()),_0x39495a(_0x570593,_0x557c07['key'])===0x0){if(_0x557c07['right']['isEmpty']())return B['EMPTY_NODE'];_0x1bd946=_0x557c07['right']['min_'](),_0x557c07=_0x557c07['copy'](_0x1bd946['key'],_0x1bd946['value'],null,null,_0x557c07['right']['removeMin_']());}_0x557c07=_0x557c07['copy'](null,null,null,null,_0x557c07['right']['remove'](_0x570593,_0x39495a));}return _0x557c07['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0xf25d51=this;return _0xf25d51['right']['isRed_']()&&!_0xf25d51['left']['isRed_']()&&(_0xf25d51=_0xf25d51['rotateLeft_']()),_0xf25d51['left']['isRed_']()&&_0xf25d51['left']['left']['isRed_']()&&(_0xf25d51=_0xf25d51['rotateRight_']()),_0xf25d51['left']['isRed_']()&&_0xf25d51['right']['isRed_']()&&(_0xf25d51=_0xf25d51['colorFlip_']()),_0xf25d51;}['moveRedLeft_'](){let _0x5ea208=this['colorFlip_']();return _0x5ea208['right']['left']['isRed_']()&&(_0x5ea208=_0x5ea208['copy'](null,null,null,null,_0x5ea208['right']['rotateRight_']()),_0x5ea208=_0x5ea208['rotateLeft_'](),_0x5ea208=_0x5ea208['colorFlip_']()),_0x5ea208;}['moveRedRight_'](){let _0x260736=this['colorFlip_']();return _0x260736['left']['left']['isRed_']()&&(_0x260736=_0x260736['rotateRight_'](),_0x260736=_0x260736['colorFlip_']()),_0x260736;}['rotateLeft_'](){const _0x129333=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x129333,null);}['rotateRight_'](){const _0x1e615c=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x1e615c);}['colorFlip_'](){const _0x1204bf=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x4d602f=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x1204bf,_0x4d602f);}['checkMaxDepth_'](){const _0x4556dc=this['check_']();return Math['pow'](0x2,_0x4556dc)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x1f8b5a=this['left']['check_']();if(_0x1f8b5a!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x1f8b5a+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x1bc6f5,_0x169807,_0x5d2d0d,_0x1f9bfd,_0xb7489b){return this;}['insert'](_0x4479bd,_0xcc28e2,_0x30ac5f){return new M(_0x4479bd,_0xcc28e2,null);}['remove'](_0xcae19c,_0x168f7e){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x301075){return!0x1;}['reverseTraversal'](_0x21d75e){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x11e717,_0x1ff9cb=B['EMPTY_NODE']){this['comparator_']=_0x11e717,this['root_']=_0x1ff9cb;}['insert'](_0x53471f,_0x152e31){return new B(this['comparator_'],this['root_']['insert'](_0x53471f,_0x152e31,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x8571fe){return new B(this['comparator_'],this['root_']['remove'](_0x8571fe,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x6a4e0d){let _0x421bee,_0x16ccdb=this['root_'];for(;!_0x16ccdb['isEmpty']();){if(_0x421bee=this['comparator_'](_0x6a4e0d,_0x16ccdb['key']),_0x421bee===0x0)return _0x16ccdb['value'];_0x421bee<0x0?_0x16ccdb=_0x16ccdb['left']:_0x421bee>0x0&&(_0x16ccdb=_0x16ccdb['right']);}return null;}['getPredecessorKey'](_0x149e9e){let _0x1a6200,_0x5d94f9=this['root_'],_0x5caad8=null;for(;!_0x5d94f9['isEmpty']();)if(_0x1a6200=this['comparator_'](_0x149e9e,_0x5d94f9['key']),_0x1a6200===0x0){if(_0x5d94f9['left']['isEmpty']())return _0x5caad8?_0x5caad8['key']:null;for(_0x5d94f9=_0x5d94f9['left'];!_0x5d94f9['right']['isEmpty']();)_0x5d94f9=_0x5d94f9['right'];return _0x5d94f9['key'];}else _0x1a6200<0x0?_0x5d94f9=_0x5d94f9['left']:_0x1a6200>0x0&&(_0x5caad8=_0x5d94f9,_0x5d94f9=_0x5d94f9['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x405311){return this['root_']['inorderTraversal'](_0x405311);}['reverseTraversal'](_0x50f87f){return this['root_']['reverseTraversal'](_0x50f87f);}['getIterator'](_0xf536f5){return new rn(this['root_'],null,this['comparator_'],!0x1,_0xf536f5);}['getIteratorFrom'](_0x18a5f9,_0xa9269b){return new rn(this['root_'],_0x18a5f9,this['comparator_'],!0x1,_0xa9269b);}['getReverseIteratorFrom'](_0xdb5c7c,_0x576c68){return new rn(this['root_'],_0xdb5c7c,this['comparator_'],!0x0,_0x576c68);}['getReverseIterator'](_0x4cf6ac){return new rn(this['root_'],null,this['comparator_'],!0x0,_0x4cf6ac);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x211268,_0x280921){return qe(_0x211268['name'],_0x280921['name']);}function Qi(_0x39c632,_0x5e74aa){return qe(_0x39c632,_0x5e74aa);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ci;function Fh(_0x15ac07){Ci=_0x15ac07;}const Po=function(_0x442609){return typeof _0x442609=='number'?'number:'+ao(_0x442609):'string:'+_0x442609;},No=function(_0x3a22a2){if(_0x3a22a2['isLeafNode']()){const _0x490b59=_0x3a22a2['val']();f(typeof _0x490b59=='string'||typeof _0x490b59=='number'||typeof _0x490b59=='object'&&Q(_0x490b59,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x3a22a2===Ci||_0x3a22a2['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x3a22a2===Ci||_0x3a22a2['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let nr;class D{static set['__childrenNodeConstructor'](_0x382d5f){nr=_0x382d5f;}static get['__childrenNodeConstructor'](){return nr;}constructor(_0x1026d4,_0x391d98=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x1026d4,this['priorityNode_']=_0x391d98,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),No(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x5074b5){return new D(this['value_'],_0x5074b5);}['getImmediateChild'](_0x1cb7ce){return _0x1cb7ce==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x2cf635){return v(_0x2cf635)?this:y(_0x2cf635)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x4e4ae5,_0x4c3e5b){return null;}['updateImmediateChild'](_0x110087,_0x329e43){return _0x110087==='.priority'?this['updatePriority'](_0x329e43):_0x329e43['isEmpty']()&&_0x110087!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x110087,_0x329e43)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x166859,_0x179da6){const _0xae3897=y(_0x166859);return _0xae3897===null?_0x179da6:_0x179da6['isEmpty']()&&_0xae3897!=='.priority'?this:(f(_0xae3897!=='.priority'||Ce(_0x166859)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0xae3897,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](S(_0x166859),_0x179da6)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x3a7eb8,_0x25a7d1){return!0x1;}['val'](_0x4a16ed){return _0x4a16ed&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x5bd780='';this['priorityNode_']['isEmpty']()||(_0x5bd780+='priority:'+Po(this['priorityNode_']['val']())+':');const _0x3961ce=typeof this['value_'];_0x5bd780+=_0x3961ce+':',_0x3961ce==='number'?_0x5bd780+=ao(this['value_']):_0x5bd780+=this['value_'],this['lazyHash_']=ro(_0x5bd780);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x49a997){return _0x49a997===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x49a997 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x49a997['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x49a997));}['compareToLeafNode_'](_0x2f4a1f){const _0x1ebf06=typeof _0x2f4a1f['value_'],_0x273832=typeof this['value_'],_0x38c496=D['VALUE_TYPE_ORDER']['indexOf'](_0x1ebf06),_0x4fc6ee=D['VALUE_TYPE_ORDER']['indexOf'](_0x273832);return f(_0x38c496>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x1ebf06),f(_0x4fc6ee>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x273832),_0x38c496===_0x4fc6ee?_0x273832==='object'?0x0:this['value_']<_0x2f4a1f['value_']?-0x1:this['value_']===_0x2f4a1f['value_']?0x0:0x1:_0x4fc6ee-_0x38c496;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x3c3b89){if(_0x3c3b89===this)return!0x0;if(_0x3c3b89['isLeafNode']()){const _0x39f6e1=_0x3c3b89;return this['value_']===_0x39f6e1['value_']&&this['priorityNode_']['equals'](_0x39f6e1['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x170afa){Oo=_0x170afa;}function Wh(_0xfa926a){Do=_0xfa926a;}class Bh extends Fn{['compare'](_0x530286,_0x413cbe){const _0x3b674f=_0x530286['node']['getPriority'](),_0x541ac4=_0x413cbe['node']['getPriority'](),_0x400fb4=_0x3b674f['compareTo'](_0x541ac4);return _0x400fb4===0x0?qe(_0x530286['name'],_0x413cbe['name']):_0x400fb4;}['isDefinedOn'](_0x385a31){return!_0x385a31['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x8fbd7e,_0x33a52c){return!_0x8fbd7e['getPriority']()['equals'](_0x33a52c['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(we,new D('[PRIORITY-POST]',Do));}['makePost'](_0x38f8d0,_0x276704){const _0x29e435=Oo(_0x38f8d0);return new E(_0x276704,new D('[PRIORITY-POST]',_0x29e435));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x4ea5db){const _0x1a1fa3=_0x3d55d5=>parseInt(Math['log'](_0x3d55d5)/Vh,0xa),_0x29ee1c=_0xb63e4d=>parseInt(Array(_0xb63e4d+0x1)['join']('1'),0x2);this['count']=_0x1a1fa3(_0x4ea5db+0x1),this['current_']=this['count']-0x1;const _0x5e8d53=_0x29ee1c(this['count']);this['bits_']=_0x4ea5db+0x1&_0x5e8d53;}['nextBitIsOne'](){const _0x45b631=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x45b631;}}const yn=function(_0x247c9c,_0x17eb37,_0xa57490,_0x3f100f){_0x247c9c['sort'](_0x17eb37);const _0x5e4b4b=function(_0x4ef37a,_0x57d97b){const _0x33614c=_0x57d97b-_0x4ef37a;let _0x4fc9d6,_0x1d1b33;if(_0x33614c===0x0)return null;if(_0x33614c===0x1)return _0x4fc9d6=_0x247c9c[_0x4ef37a],_0x1d1b33=_0xa57490?_0xa57490(_0x4fc9d6):_0x4fc9d6,new M(_0x1d1b33,_0x4fc9d6['node'],M['BLACK'],null,null);{const _0x17a73e=parseInt(_0x33614c/0x2,0xa)+_0x4ef37a,_0x276bfd=_0x5e4b4b(_0x4ef37a,_0x17a73e),_0x3cf760=_0x5e4b4b(_0x17a73e+0x1,_0x57d97b);return _0x4fc9d6=_0x247c9c[_0x17a73e],_0x1d1b33=_0xa57490?_0xa57490(_0x4fc9d6):_0x4fc9d6,new M(_0x1d1b33,_0x4fc9d6['node'],M['BLACK'],_0x276bfd,_0x3cf760);}},_0x4572eb=function(_0xc31a6f){let _0x5862ad=null,_0x426bb7=null,_0x10fb0d=_0x247c9c['length'];const _0x101a02=function(_0x4e875f,_0x62fe28){const _0xd0bfca=_0x10fb0d-_0x4e875f,_0x24aed5=_0x10fb0d;_0x10fb0d-=_0x4e875f;const _0x38ce8c=_0x5e4b4b(_0xd0bfca+0x1,_0x24aed5),_0x1a7492=_0x247c9c[_0xd0bfca],_0x2bd73b=_0xa57490?_0xa57490(_0x1a7492):_0x1a7492;_0x17e125(new M(_0x2bd73b,_0x1a7492['node'],_0x62fe28,null,_0x38ce8c));},_0x17e125=function(_0x26be10){_0x5862ad?(_0x5862ad['left']=_0x26be10,_0x5862ad=_0x26be10):(_0x426bb7=_0x26be10,_0x5862ad=_0x26be10);};for(let _0x18960f=0x0;_0x18960f<_0xc31a6f['count'];++_0x18960f){const _0x2e5b2e=_0xc31a6f['nextBitIsOne'](),_0x175b6e=Math['pow'](0x2,_0xc31a6f['count']-(_0x18960f+0x1));_0x2e5b2e?_0x101a02(_0x175b6e,M['BLACK']):(_0x101a02(_0x175b6e,M['BLACK']),_0x101a02(_0x175b6e,M['RED']));}return _0x426bb7;},_0x5a299c=new Hh(_0x247c9c['length']),_0x51fe87=_0x4572eb(_0x5a299c);return new B(_0x3f100f||_0x17eb37,_0x51fe87);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let li;const Qe={};class te{static get['Default'](){return f(Qe&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),li=li||new te({'.priority':Qe},{'.priority':R}),li;}constructor(_0x24803a,_0x915fcb){this['indexes_']=_0x24803a,this['indexSet_']=_0x915fcb;}['get'](_0x11ac4e){const _0x2c2cb3=Le(this['indexes_'],_0x11ac4e);if(!_0x2c2cb3)throw new Error('No\x20index\x20defined\x20for\x20'+_0x11ac4e);return _0x2c2cb3 instanceof B?_0x2c2cb3:null;}['hasIndex'](_0x15359c){return Q(this['indexSet_'],_0x15359c['toString']());}['addIndex'](_0x12fe0e,_0x513ce1){f(_0x12fe0e!==ve,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x307009=[];let _0x4ec0d1=!0x1;const _0x42ffbd=_0x513ce1['getIterator'](E['Wrap']);let _0x18f249=_0x42ffbd['getNext']();for(;_0x18f249;)_0x4ec0d1=_0x4ec0d1||_0x12fe0e['isDefinedOn'](_0x18f249['node']),_0x307009['push'](_0x18f249),_0x18f249=_0x42ffbd['getNext']();let _0x30540d;_0x4ec0d1?_0x30540d=yn(_0x307009,_0x12fe0e['getCompare']()):_0x30540d=Qe;const _0x488183=_0x12fe0e['toString'](),_0x43f4f8={...this['indexSet_']};_0x43f4f8[_0x488183]=_0x12fe0e;const _0x2d3c33={...this['indexes_']};return _0x2d3c33[_0x488183]=_0x30540d,new te(_0x2d3c33,_0x43f4f8);}['addToIndexes'](_0x422dc5,_0x5f4da7){const _0x38a1e4=_n(this['indexes_'],(_0x47f53a,_0x26009b)=>{const _0xe914ef=Le(this['indexSet_'],_0x26009b);if(f(_0xe914ef,'Missing\x20index\x20implementation\x20for\x20'+_0x26009b),_0x47f53a===Qe){if(_0xe914ef['isDefinedOn'](_0x422dc5['node'])){const _0x448f6b=[],_0xaa5400=_0x5f4da7['getIterator'](E['Wrap']);let _0x287bda=_0xaa5400['getNext']();for(;_0x287bda;)_0x287bda['name']!==_0x422dc5['name']&&_0x448f6b['push'](_0x287bda),_0x287bda=_0xaa5400['getNext']();return _0x448f6b['push'](_0x422dc5),yn(_0x448f6b,_0xe914ef['getCompare']());}else return Qe;}else{const _0x2754de=_0x5f4da7['get'](_0x422dc5['name']);let _0x12f9eb=_0x47f53a;return _0x2754de&&(_0x12f9eb=_0x12f9eb['remove'](new E(_0x422dc5['name'],_0x2754de))),_0x12f9eb['insert'](_0x422dc5,_0x422dc5['node']);}});return new te(_0x38a1e4,this['indexSet_']);}['removeFromIndexes'](_0x55c310,_0xbfabca){const _0xd2f8c5=_n(this['indexes_'],_0x2d65f6=>{if(_0x2d65f6===Qe)return _0x2d65f6;{const _0x4a1727=_0xbfabca['get'](_0x55c310['name']);return _0x4a1727?_0x2d65f6['remove'](new E(_0x55c310['name'],_0x4a1727)):_0x2d65f6;}});return new te(_0xd2f8c5,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let It;class g{static get['EMPTY_NODE'](){return It||(It=new g(new B(Qi),null,te['Default']));}constructor(_0x5ee2d5,_0x53fd2e,_0x3432f5){this['children_']=_0x5ee2d5,this['priorityNode_']=_0x53fd2e,this['indexMap_']=_0x3432f5,this['lazyHash_']=null,this['priorityNode_']&&No(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||It;}['updatePriority'](_0x3efcb0){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x3efcb0,this['indexMap_']);}['getImmediateChild'](_0x27fc07){if(_0x27fc07==='.priority')return this['getPriority']();{const _0x3406d5=this['children_']['get'](_0x27fc07);return _0x3406d5===null?It:_0x3406d5;}}['getChild'](_0x43fc5a){const _0x287a64=y(_0x43fc5a);return _0x287a64===null?this:this['getImmediateChild'](_0x287a64)['getChild'](S(_0x43fc5a));}['hasChild'](_0x408f51){return this['children_']['get'](_0x408f51)!==null;}['updateImmediateChild'](_0x5cec4c,_0x2eaf37){if(f(_0x2eaf37,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x5cec4c==='.priority')return this['updatePriority'](_0x2eaf37);{const _0xd1885d=new E(_0x5cec4c,_0x2eaf37);let _0x1cd4c6,_0x422fe9;_0x2eaf37['isEmpty']()?(_0x1cd4c6=this['children_']['remove'](_0x5cec4c),_0x422fe9=this['indexMap_']['removeFromIndexes'](_0xd1885d,this['children_'])):(_0x1cd4c6=this['children_']['insert'](_0x5cec4c,_0x2eaf37),_0x422fe9=this['indexMap_']['addToIndexes'](_0xd1885d,this['children_']));const _0x461b34=_0x1cd4c6['isEmpty']()?It:this['priorityNode_'];return new g(_0x1cd4c6,_0x461b34,_0x422fe9);}}['updateChild'](_0x4f7490,_0x3445e3){const _0x22b99f=y(_0x4f7490);if(_0x22b99f===null)return _0x3445e3;{f(y(_0x4f7490)!=='.priority'||Ce(_0x4f7490)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x5d13ab=this['getImmediateChild'](_0x22b99f)['updateChild'](S(_0x4f7490),_0x3445e3);return this['updateImmediateChild'](_0x22b99f,_0x5d13ab);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x219a03){if(this['isEmpty']())return null;const _0x36f646={};let _0x9ad08f=0x0,_0x2ff5b3=0x0,_0x43404e=!0x0;if(this['forEachChild'](R,(_0x3a2bd7,_0x290435)=>{_0x36f646[_0x3a2bd7]=_0x290435['val'](_0x219a03),_0x9ad08f++,_0x43404e&&g['INTEGER_REGEXP_']['test'](_0x3a2bd7)?_0x2ff5b3=Math['max'](_0x2ff5b3,Number(_0x3a2bd7)):_0x43404e=!0x1;}),!_0x219a03&&_0x43404e&&_0x2ff5b3<0x2*_0x9ad08f){const _0x28370c=[];for(const _0x2fafdb in _0x36f646)_0x28370c[_0x2fafdb]=_0x36f646[_0x2fafdb];return _0x28370c;}else return _0x219a03&&!this['getPriority']()['isEmpty']()&&(_0x36f646['.priority']=this['getPriority']()['val']()),_0x36f646;}['hash'](){if(this['lazyHash_']===null){let _0x11ce8b='';this['getPriority']()['isEmpty']()||(_0x11ce8b+='priority:'+Po(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x23793d,_0x3a6b63)=>{const _0x2a16e1=_0x3a6b63['hash']();_0x2a16e1!==''&&(_0x11ce8b+=':'+_0x23793d+':'+_0x2a16e1);}),this['lazyHash_']=_0x11ce8b===''?'':ro(_0x11ce8b);}return this['lazyHash_'];}['getPredecessorChildName'](_0xd909e8,_0xa8face,_0x70a3ea){const _0x1ab7d5=this['resolveIndex_'](_0x70a3ea);if(_0x1ab7d5){const _0x3aa8bb=_0x1ab7d5['getPredecessorKey'](new E(_0xd909e8,_0xa8face));return _0x3aa8bb?_0x3aa8bb['name']:null;}else return this['children_']['getPredecessorKey'](_0xd909e8);}['getFirstChildName'](_0x1c2e2d){const _0x4c54e7=this['resolveIndex_'](_0x1c2e2d);if(_0x4c54e7){const _0x296b57=_0x4c54e7['minKey']();return _0x296b57&&_0x296b57['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x24c1ac){const _0x4e2c7f=this['getFirstChildName'](_0x24c1ac);return _0x4e2c7f?new E(_0x4e2c7f,this['children_']['get'](_0x4e2c7f)):null;}['getLastChildName'](_0x2d9abd){const _0x5e2908=this['resolveIndex_'](_0x2d9abd);if(_0x5e2908){const _0x2f28c2=_0x5e2908['maxKey']();return _0x2f28c2&&_0x2f28c2['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0xfe2efe){const _0x1e54c6=this['getLastChildName'](_0xfe2efe);return _0x1e54c6?new E(_0x1e54c6,this['children_']['get'](_0x1e54c6)):null;}['forEachChild'](_0x13d29e,_0x1c8174){const _0x3f3f41=this['resolveIndex_'](_0x13d29e);return _0x3f3f41?_0x3f3f41['inorderTraversal'](_0x3061d0=>_0x1c8174(_0x3061d0['name'],_0x3061d0['node'])):this['children_']['inorderTraversal'](_0x1c8174);}['getIterator'](_0x517d28){return this['getIteratorFrom'](_0x517d28['minPost'](),_0x517d28);}['getIteratorFrom'](_0x446659,_0xb591d3){const _0x21e243=this['resolveIndex_'](_0xb591d3);if(_0x21e243)return _0x21e243['getIteratorFrom'](_0x446659,_0x2d9ae3=>_0x2d9ae3);{const _0x5e779a=this['children_']['getIteratorFrom'](_0x446659['name'],E['Wrap']);let _0x594c06=_0x5e779a['peek']();for(;_0x594c06!=null&&_0xb591d3['compare'](_0x594c06,_0x446659)<0x0;)_0x5e779a['getNext'](),_0x594c06=_0x5e779a['peek']();return _0x5e779a;}}['getReverseIterator'](_0x195542){return this['getReverseIteratorFrom'](_0x195542['maxPost'](),_0x195542);}['getReverseIteratorFrom'](_0x60492b,_0x2f87c6){const _0x350b15=this['resolveIndex_'](_0x2f87c6);if(_0x350b15)return _0x350b15['getReverseIteratorFrom'](_0x60492b,_0x287652=>_0x287652);{const _0x4ea9e2=this['children_']['getReverseIteratorFrom'](_0x60492b['name'],E['Wrap']);let _0x1accd2=_0x4ea9e2['peek']();for(;_0x1accd2!=null&&_0x2f87c6['compare'](_0x1accd2,_0x60492b)>0x0;)_0x4ea9e2['getNext'](),_0x1accd2=_0x4ea9e2['peek']();return _0x4ea9e2;}}['compareTo'](_0x504e0f){return this['isEmpty']()?_0x504e0f['isEmpty']()?0x0:-0x1:_0x504e0f['isLeafNode']()||_0x504e0f['isEmpty']()?0x1:_0x504e0f===Kt?-0x1:0x0;}['withIndex'](_0x20b2c8){if(_0x20b2c8===ve||this['indexMap_']['hasIndex'](_0x20b2c8))return this;{const _0x396f64=this['indexMap_']['addIndex'](_0x20b2c8,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x396f64);}}['isIndexed'](_0x516f16){return _0x516f16===ve||this['indexMap_']['hasIndex'](_0x516f16);}['equals'](_0x3b336f){if(_0x3b336f===this)return!0x0;if(_0x3b336f['isLeafNode']())return!0x1;{const _0x56a695=_0x3b336f;if(this['getPriority']()['equals'](_0x56a695['getPriority']())){if(this['children_']['count']()===_0x56a695['children_']['count']()){const _0x48c5ce=this['getIterator'](R),_0x22a1aa=_0x56a695['getIterator'](R);let _0x10c724=_0x48c5ce['getNext'](),_0x146863=_0x22a1aa['getNext']();for(;_0x10c724&&_0x146863;){if(_0x10c724['name']!==_0x146863['name']||!_0x10c724['node']['equals'](_0x146863['node']))return!0x1;_0x10c724=_0x48c5ce['getNext'](),_0x146863=_0x22a1aa['getNext']();}return _0x10c724===null&&_0x146863===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x77d4d4){return _0x77d4d4===ve?null:this['indexMap_']['get'](_0x77d4d4['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Qi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x52acf5){return _0x52acf5===this?0x0:0x1;}['equals'](_0x5ed05c){return _0x5ed05c===this;}['getPriority'](){return this;}['getImmediateChild'](_0x190774){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const Kt=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(We,g['EMPTY_NODE'])},'MAX':{'value':new E(we,Kt)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh(Kt),Wh(Kt);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function A(_0xb62b74,_0x3de2ee=null){if(_0xb62b74===null)return g['EMPTY_NODE'];if(typeof _0xb62b74=='object'&&'.priority'in _0xb62b74&&(_0x3de2ee=_0xb62b74['.priority']),f(_0x3de2ee===null||typeof _0x3de2ee=='string'||typeof _0x3de2ee=='number'||typeof _0x3de2ee=='object'&&'.sv'in _0x3de2ee,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x3de2ee),typeof _0xb62b74=='object'&&'.value'in _0xb62b74&&_0xb62b74['.value']!==null&&(_0xb62b74=_0xb62b74['.value']),typeof _0xb62b74!='object'||'.sv'in _0xb62b74){const _0x3a578c=_0xb62b74;return new D(_0x3a578c,A(_0x3de2ee));}if(!(_0xb62b74 instanceof Array)&&Gh){const _0x42c68f=[];let _0x57a3b3=!0x1;if(x(_0xb62b74,(_0x321c50,_0x23e246)=>{if(_0x321c50['substring'](0x0,0x1)!=='.'){const _0x185690=A(_0x23e246);_0x185690['isEmpty']()||(_0x57a3b3=_0x57a3b3||!_0x185690['getPriority']()['isEmpty'](),_0x42c68f['push'](new E(_0x321c50,_0x185690)));}}),_0x42c68f['length']===0x0)return g['EMPTY_NODE'];const _0x259a86=yn(_0x42c68f,xh,_0x44ca94=>_0x44ca94['name'],Qi);if(_0x57a3b3){const _0x5e5c26=yn(_0x42c68f,R['getCompare']());return new g(_0x259a86,A(_0x3de2ee),new te({'.priority':_0x5e5c26},{'.priority':R}));}else return new g(_0x259a86,A(_0x3de2ee),te['Default']);}else{let _0x3278fc=g['EMPTY_NODE'];return x(_0xb62b74,(_0x1a7d70,_0x269feb)=>{if(Q(_0xb62b74,_0x1a7d70)&&_0x1a7d70['substring'](0x0,0x1)!=='.'){const _0x334843=A(_0x269feb);(_0x334843['isLeafNode']()||!_0x334843['isEmpty']())&&(_0x3278fc=_0x3278fc['updateImmediateChild'](_0x1a7d70,_0x334843));}}),_0x3278fc['updatePriority'](A(_0x3de2ee));}}Uh(A);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji extends Fn{constructor(_0x99b611){super(),this['indexPath_']=_0x99b611,f(!v(_0x99b611)&&y(_0x99b611)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x311697){return _0x311697['getChild'](this['indexPath_']);}['isDefinedOn'](_0x1fb40c){return!_0x1fb40c['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x4a69aa,_0x41032a){const _0x4dc578=this['extractChild'](_0x4a69aa['node']),_0x22a6f5=this['extractChild'](_0x41032a['node']),_0x238550=_0x4dc578['compareTo'](_0x22a6f5);return _0x238550===0x0?qe(_0x4a69aa['name'],_0x41032a['name']):_0x238550;}['makePost'](_0x589df2,_0x141d94){const _0x836347=A(_0x589df2),_0xafd30e=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x836347);return new E(_0x141d94,_0xafd30e);}['maxPost'](){const _0x545a74=g['EMPTY_NODE']['updateChild'](this['indexPath_'],Kt);return new E(we,_0x545a74);}['toString'](){return Mt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Fn{['compare'](_0x26bf91,_0x2278d5){const _0x10a05f=_0x26bf91['node']['compareTo'](_0x2278d5['node']);return _0x10a05f===0x0?qe(_0x26bf91['name'],_0x2278d5['name']):_0x10a05f;}['isDefinedOn'](_0x3709c0){return!0x0;}['indexedValueChanged'](_0x2ec64a,_0x522901){return!_0x2ec64a['equals'](_0x522901);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x932160,_0xad26cd){const _0x5ea947=A(_0x932160);return new E(_0xad26cd,_0x5ea947);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x3262e4){return{'type':'value','snapshotNode':_0x3262e4};}function rt(_0x2386f7,_0x562ec5){return{'type':'child_added','snapshotNode':_0x562ec5,'childName':_0x2386f7};}function Lt(_0x284fb6,_0x540cb7){return{'type':'child_removed','snapshotNode':_0x540cb7,'childName':_0x284fb6};}function xt(_0x2e0ff0,_0x515859,_0x27dd1f){return{'type':'child_changed','snapshotNode':_0x515859,'childName':_0x2e0ff0,'oldSnap':_0x27dd1f};}function zh(_0x3bd8c0,_0x3da99c){return{'type':'child_moved','snapshotNode':_0x3da99c,'childName':_0x3bd8c0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(_0x17c785){this['index_']=_0x17c785;}['updateChild'](_0x33db5e,_0x1e45d3,_0x537bf4,_0xb63344,_0x1f90f1,_0x5d9bf7){f(_0x33db5e['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x123bfb=_0x33db5e['getImmediateChild'](_0x1e45d3);return _0x123bfb['getChild'](_0xb63344)['equals'](_0x537bf4['getChild'](_0xb63344))&&_0x123bfb['isEmpty']()===_0x537bf4['isEmpty']()||(_0x5d9bf7!=null&&(_0x537bf4['isEmpty']()?_0x33db5e['hasChild'](_0x1e45d3)?_0x5d9bf7['trackChildChange'](Lt(_0x1e45d3,_0x123bfb)):f(_0x33db5e['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x123bfb['isEmpty']()?_0x5d9bf7['trackChildChange'](rt(_0x1e45d3,_0x537bf4)):_0x5d9bf7['trackChildChange'](xt(_0x1e45d3,_0x537bf4,_0x123bfb))),_0x33db5e['isLeafNode']()&&_0x537bf4['isEmpty']())?_0x33db5e:_0x33db5e['updateImmediateChild'](_0x1e45d3,_0x537bf4)['withIndex'](this['index_']);}['updateFullNode'](_0x4dd54f,_0xc95f8f,_0x59b01b){return _0x59b01b!=null&&(_0x4dd54f['isLeafNode']()||_0x4dd54f['forEachChild'](R,(_0x208cbd,_0x467f45)=>{_0xc95f8f['hasChild'](_0x208cbd)||_0x59b01b['trackChildChange'](Lt(_0x208cbd,_0x467f45));}),_0xc95f8f['isLeafNode']()||_0xc95f8f['forEachChild'](R,(_0x133ca6,_0x586c0e)=>{if(_0x4dd54f['hasChild'](_0x133ca6)){const _0x266448=_0x4dd54f['getImmediateChild'](_0x133ca6);_0x266448['equals'](_0x586c0e)||_0x59b01b['trackChildChange'](xt(_0x133ca6,_0x586c0e,_0x266448));}else _0x59b01b['trackChildChange'](rt(_0x133ca6,_0x586c0e));})),_0xc95f8f['withIndex'](this['index_']);}['updatePriority'](_0x4cf599,_0x1b25ce){return _0x4cf599['isEmpty']()?g['EMPTY_NODE']:_0x4cf599['updatePriority'](_0x1b25ce);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ft{constructor(_0xad8a72){this['indexedFilter_']=new Xi(_0xad8a72['getIndex']()),this['index_']=_0xad8a72['getIndex'](),this['startPost_']=Ft['getStartPost_'](_0xad8a72),this['endPost_']=Ft['getEndPost_'](_0xad8a72),this['startIsInclusive_']=!_0xad8a72['startAfterSet_'],this['endIsInclusive_']=!_0xad8a72['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x3420de){const _0x31613f=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x3420de)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x3420de)<0x0,_0x139ebc=this['endIsInclusive_']?this['index_']['compare'](_0x3420de,this['getEndPost']())<=0x0:this['index_']['compare'](_0x3420de,this['getEndPost']())<0x0;return _0x31613f&&_0x139ebc;}['updateChild'](_0x522e13,_0x2ea211,_0x3c7a4b,_0x5aa35c,_0x52ac51,_0x55784d){return this['matches'](new E(_0x2ea211,_0x3c7a4b))||(_0x3c7a4b=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x522e13,_0x2ea211,_0x3c7a4b,_0x5aa35c,_0x52ac51,_0x55784d);}['updateFullNode'](_0x5cba73,_0x19d00a,_0xa9a8cf){_0x19d00a['isLeafNode']()&&(_0x19d00a=g['EMPTY_NODE']);let _0x22123c=_0x19d00a['withIndex'](this['index_']);_0x22123c=_0x22123c['updatePriority'](g['EMPTY_NODE']);const _0x4328de=this;return _0x19d00a['forEachChild'](R,(_0x8cf520,_0x241ccb)=>{_0x4328de['matches'](new E(_0x8cf520,_0x241ccb))||(_0x22123c=_0x22123c['updateImmediateChild'](_0x8cf520,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x5cba73,_0x22123c,_0xa9a8cf);}['updatePriority'](_0x4d88b9,_0x4a723a){return _0x4d88b9;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0xb7fef7){if(_0xb7fef7['hasStart']()){const _0x449f0b=_0xb7fef7['getIndexStartName']();return _0xb7fef7['getIndex']()['makePost'](_0xb7fef7['getIndexStartValue'](),_0x449f0b);}else return _0xb7fef7['getIndex']()['minPost']();}static['getEndPost_'](_0xc4dbd4){if(_0xc4dbd4['hasEnd']()){const _0xb8dc2e=_0xc4dbd4['getIndexEndName']();return _0xc4dbd4['getIndex']()['makePost'](_0xc4dbd4['getIndexEndValue'](),_0xb8dc2e);}else return _0xc4dbd4['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x304344){this['withinDirectionalStart']=_0x2f3692=>this['reverse_']?this['withinEndPost'](_0x2f3692):this['withinStartPost'](_0x2f3692),this['withinDirectionalEnd']=_0x2fbbd6=>this['reverse_']?this['withinStartPost'](_0x2fbbd6):this['withinEndPost'](_0x2fbbd6),this['withinStartPost']=_0xd22e0a=>{const _0x2bb956=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0xd22e0a);return this['startIsInclusive_']?_0x2bb956<=0x0:_0x2bb956<0x0;},this['withinEndPost']=_0x360b3e=>{const _0x2179a7=this['index_']['compare'](_0x360b3e,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x2179a7<=0x0:_0x2179a7<0x0;},this['rangedFilter_']=new Ft(_0x304344),this['index_']=_0x304344['getIndex'](),this['limit_']=_0x304344['getLimit'](),this['reverse_']=!_0x304344['isViewFromLeft'](),this['startIsInclusive_']=!_0x304344['startAfterSet_'],this['endIsInclusive_']=!_0x304344['endBeforeSet_'];}['updateChild'](_0x5847fc,_0xf65c2b,_0x3345e1,_0x541b68,_0x3b4570,_0x540b02){return this['rangedFilter_']['matches'](new E(_0xf65c2b,_0x3345e1))||(_0x3345e1=g['EMPTY_NODE']),_0x5847fc['getImmediateChild'](_0xf65c2b)['equals'](_0x3345e1)?_0x5847fc:_0x5847fc['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x5847fc,_0xf65c2b,_0x3345e1,_0x541b68,_0x3b4570,_0x540b02):this['fullLimitUpdateChild_'](_0x5847fc,_0xf65c2b,_0x3345e1,_0x3b4570,_0x540b02);}['updateFullNode'](_0x4e3392,_0x30fa74,_0x210251){let _0x4a23aa;if(_0x30fa74['isLeafNode']()||_0x30fa74['isEmpty']())_0x4a23aa=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x30fa74['numChildren']()&&_0x30fa74['isIndexed'](this['index_'])){_0x4a23aa=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x22007d;this['reverse_']?_0x22007d=_0x30fa74['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x22007d=_0x30fa74['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x156946=0x0;for(;_0x22007d['hasNext']()&&_0x156946<this['limit_'];){const _0x43164c=_0x22007d['getNext']();if(this['withinDirectionalStart'](_0x43164c)){if(this['withinDirectionalEnd'](_0x43164c))_0x4a23aa=_0x4a23aa['updateImmediateChild'](_0x43164c['name'],_0x43164c['node']),_0x156946++;else break;}else continue;}}else{_0x4a23aa=_0x30fa74['withIndex'](this['index_']),_0x4a23aa=_0x4a23aa['updatePriority'](g['EMPTY_NODE']);let _0x55f57f;this['reverse_']?_0x55f57f=_0x4a23aa['getReverseIterator'](this['index_']):_0x55f57f=_0x4a23aa['getIterator'](this['index_']);let _0x270ad4=0x0;for(;_0x55f57f['hasNext']();){const _0x383876=_0x55f57f['getNext']();_0x270ad4<this['limit_']&&this['withinDirectionalStart'](_0x383876)&&this['withinDirectionalEnd'](_0x383876)?_0x270ad4++:_0x4a23aa=_0x4a23aa['updateImmediateChild'](_0x383876['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x4e3392,_0x4a23aa,_0x210251);}['updatePriority'](_0xe9e574,_0x4ca568){return _0xe9e574;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x278fc2,_0x24660d,_0x3ad021,_0x30c4f3,_0x4d1004){let _0x36fc67;if(this['reverse_']){const _0x1ed9d7=this['index_']['getCompare']();_0x36fc67=(_0x128b16,_0x5f3132)=>_0x1ed9d7(_0x5f3132,_0x128b16);}else _0x36fc67=this['index_']['getCompare']();const _0x25333d=_0x278fc2;f(_0x25333d['numChildren']()===this['limit_'],'');const _0x52dfd9=new E(_0x24660d,_0x3ad021),_0x479cbd=this['reverse_']?_0x25333d['getFirstChild'](this['index_']):_0x25333d['getLastChild'](this['index_']),_0x679b91=this['rangedFilter_']['matches'](_0x52dfd9);if(_0x25333d['hasChild'](_0x24660d)){const _0x126cde=_0x25333d['getImmediateChild'](_0x24660d);let _0x40dea4=_0x30c4f3['getChildAfterChild'](this['index_'],_0x479cbd,this['reverse_']);for(;_0x40dea4!=null&&(_0x40dea4['name']===_0x24660d||_0x25333d['hasChild'](_0x40dea4['name']));)_0x40dea4=_0x30c4f3['getChildAfterChild'](this['index_'],_0x40dea4,this['reverse_']);const _0x4fa547=_0x40dea4==null?0x1:_0x36fc67(_0x40dea4,_0x52dfd9);if(_0x679b91&&!_0x3ad021['isEmpty']()&&_0x4fa547>=0x0)return _0x4d1004!=null&&_0x4d1004['trackChildChange'](xt(_0x24660d,_0x3ad021,_0x126cde)),_0x25333d['updateImmediateChild'](_0x24660d,_0x3ad021);{_0x4d1004!=null&&_0x4d1004['trackChildChange'](Lt(_0x24660d,_0x126cde));const _0x8cde3c=_0x25333d['updateImmediateChild'](_0x24660d,g['EMPTY_NODE']);return _0x40dea4!=null&&this['rangedFilter_']['matches'](_0x40dea4)?(_0x4d1004!=null&&_0x4d1004['trackChildChange'](rt(_0x40dea4['name'],_0x40dea4['node'])),_0x8cde3c['updateImmediateChild'](_0x40dea4['name'],_0x40dea4['node'])):_0x8cde3c;}}else return _0x3ad021['isEmpty']()?_0x278fc2:_0x679b91&&_0x36fc67(_0x479cbd,_0x52dfd9)>=0x0?(_0x4d1004!=null&&(_0x4d1004['trackChildChange'](Lt(_0x479cbd['name'],_0x479cbd['node'])),_0x4d1004['trackChildChange'](rt(_0x24660d,_0x3ad021))),_0x25333d['updateImmediateChild'](_0x24660d,_0x3ad021)['updateImmediateChild'](_0x479cbd['name'],g['EMPTY_NODE'])):_0x278fc2;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:We;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:we;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x486a8d=new Zi();return _0x486a8d['limitSet_']=this['limitSet_'],_0x486a8d['limit_']=this['limit_'],_0x486a8d['startSet_']=this['startSet_'],_0x486a8d['startAfterSet_']=this['startAfterSet_'],_0x486a8d['indexStartValue_']=this['indexStartValue_'],_0x486a8d['startNameSet_']=this['startNameSet_'],_0x486a8d['indexStartName_']=this['indexStartName_'],_0x486a8d['endSet_']=this['endSet_'],_0x486a8d['endBeforeSet_']=this['endBeforeSet_'],_0x486a8d['indexEndValue_']=this['indexEndValue_'],_0x486a8d['endNameSet_']=this['endNameSet_'],_0x486a8d['indexEndName_']=this['indexEndName_'],_0x486a8d['index_']=this['index_'],_0x486a8d['viewFrom_']=this['viewFrom_'],_0x486a8d;}}function Kh(_0xe11cb7){return _0xe11cb7['loadsAllData']()?new Xi(_0xe11cb7['getIndex']()):_0xe11cb7['hasLimit']()?new jh(_0xe11cb7):new Ft(_0xe11cb7);}function Yh(_0x57e388,_0x306704){const _0x418ffb=_0x57e388['copy']();return _0x418ffb['limitSet_']=!0x0,_0x418ffb['limit_']=_0x306704,_0x418ffb['viewFrom_']='l',_0x418ffb;}function Qh(_0x40a04b,_0x270353,_0x242e31){const _0x3f4737=_0x40a04b['copy']();return _0x3f4737['startSet_']=!0x0,_0x270353===void 0x0&&(_0x270353=null),_0x3f4737['indexStartValue_']=_0x270353,_0x242e31!=null?(_0x3f4737['startNameSet_']=!0x0,_0x3f4737['indexStartName_']=_0x242e31):(_0x3f4737['startNameSet_']=!0x1,_0x3f4737['indexStartName_']=''),_0x3f4737;}function Jh(_0x27c458,_0x1d7fa2,_0x35106d){const _0x174070=_0x27c458['copy']();return _0x174070['endSet_']=!0x0,_0x1d7fa2===void 0x0&&(_0x1d7fa2=null),_0x174070['indexEndValue_']=_0x1d7fa2,_0x35106d!==void 0x0?(_0x174070['endNameSet_']=!0x0,_0x174070['indexEndName_']=_0x35106d):(_0x174070['endNameSet_']=!0x1,_0x174070['indexEndName_']=''),_0x174070;}function xo(_0x3a2be1,_0x4c0f7b){const _0x360259=_0x3a2be1['copy']();return _0x360259['index_']=_0x4c0f7b,_0x360259;}function ir(_0x522860){const _0x2d0c8c={};if(_0x522860['isDefault']())return _0x2d0c8c;let _0x4dde09;if(_0x522860['index_']===R?_0x4dde09='$priority':_0x522860['index_']===Mo?_0x4dde09='$value':_0x522860['index_']===ve?_0x4dde09='$key':(f(_0x522860['index_']instanceof Ji,'Unrecognized\x20index\x20type!'),_0x4dde09=_0x522860['index_']['toString']()),_0x2d0c8c['orderBy']=O(_0x4dde09),_0x522860['startSet_']){const _0x186c8c=_0x522860['startAfterSet_']?'startAfter':'startAt';_0x2d0c8c[_0x186c8c]=O(_0x522860['indexStartValue_']),_0x522860['startNameSet_']&&(_0x2d0c8c[_0x186c8c]+=','+O(_0x522860['indexStartName_']));}if(_0x522860['endSet_']){const _0x130061=_0x522860['endBeforeSet_']?'endBefore':'endAt';_0x2d0c8c[_0x130061]=O(_0x522860['indexEndValue_']),_0x522860['endNameSet_']&&(_0x2d0c8c[_0x130061]+=','+O(_0x522860['indexEndName_']));}return _0x522860['limitSet_']&&(_0x522860['isViewFromLeft']()?_0x2d0c8c['limitToFirst']=_0x522860['limit_']:_0x2d0c8c['limitToLast']=_0x522860['limit_']),_0x2d0c8c;}function sr(_0x101b38){const _0x28c9a2={};if(_0x101b38['startSet_']&&(_0x28c9a2['sp']=_0x101b38['indexStartValue_'],_0x101b38['startNameSet_']&&(_0x28c9a2['sn']=_0x101b38['indexStartName_']),_0x28c9a2['sin']=!_0x101b38['startAfterSet_']),_0x101b38['endSet_']&&(_0x28c9a2['ep']=_0x101b38['indexEndValue_'],_0x101b38['endNameSet_']&&(_0x28c9a2['en']=_0x101b38['indexEndName_']),_0x28c9a2['ein']=!_0x101b38['endBeforeSet_']),_0x101b38['limitSet_']){_0x28c9a2['l']=_0x101b38['limit_'];let _0x1114e8=_0x101b38['viewFrom_'];_0x1114e8===''&&(_0x101b38['isViewFromLeft']()?_0x1114e8='l':_0x1114e8='r'),_0x28c9a2['vf']=_0x1114e8;}return _0x101b38['index_']!==R&&(_0x28c9a2['i']=_0x101b38['index_']['toString']()),_0x28c9a2;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class vn extends So{['reportStats'](_0xed5e8c){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x29a212,_0x37fe6d){return _0x37fe6d!==void 0x0?'tag$'+_0x37fe6d:(f(_0x29a212['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x29a212['_path']['toString']());}constructor(_0x2cea59,_0x4c549f,_0x496251,_0xd91f0){super(),this['repoInfo_']=_0x2cea59,this['onDataUpdate_']=_0x4c549f,this['authTokenProvider_']=_0x496251,this['appCheckTokenProvider_']=_0xd91f0,this['log_']=jt('p:rest:'),this['listens_']={};}['listen'](_0x44b0e6,_0x12e92,_0x2fb1d3,_0xfff376){const _0x3f9696=_0x44b0e6['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x3f9696+'\x20'+_0x44b0e6['_queryIdentifier']);const _0x26b730=vn['getListenId_'](_0x44b0e6,_0x2fb1d3),_0xb0710d={};this['listens_'][_0x26b730]=_0xb0710d;const _0x302cfa=ir(_0x44b0e6['_queryParams']);this['restRequest_'](_0x3f9696+'.json',_0x302cfa,(_0x5a4062,_0x359385)=>{let _0x46fbde=_0x359385;if(_0x5a4062===0x194&&(_0x46fbde=null,_0x5a4062=null),_0x5a4062===null&&this['onDataUpdate_'](_0x3f9696,_0x46fbde,!0x1,_0x2fb1d3),Le(this['listens_'],_0x26b730)===_0xb0710d){let _0x192f92;_0x5a4062?_0x5a4062===0x191?_0x192f92='permission_denied':_0x192f92='rest_error:'+_0x5a4062:_0x192f92='ok',_0xfff376(_0x192f92,null);}});}['unlisten'](_0x2d1fb1,_0x3d1bc7){const _0x556c53=vn['getListenId_'](_0x2d1fb1,_0x3d1bc7);delete this['listens_'][_0x556c53];}['get'](_0x4c6692){const _0x3b3add=ir(_0x4c6692['_queryParams']),_0x55ed6b=_0x4c6692['_path']['toString'](),_0x288188=new H();return this['restRequest_'](_0x55ed6b+'.json',_0x3b3add,(_0x4f9e3b,_0x44b740)=>{let _0x4721f2=_0x44b740;_0x4f9e3b===0x194&&(_0x4721f2=null,_0x4f9e3b=null),_0x4f9e3b===null?(this['onDataUpdate_'](_0x55ed6b,_0x4721f2,!0x1,null),_0x288188['resolve'](_0x4721f2)):_0x288188['reject'](new Error(_0x4721f2));}),_0x288188['promise'];}['refreshAuthToken'](_0x3e646d){}['restRequest_'](_0x7555f,_0xb476b0={},_0xeef95b){return _0xb476b0['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x5267dc,_0x3718f1])=>{_0x5267dc&&_0x5267dc['accessToken']&&(_0xb476b0['auth']=_0x5267dc['accessToken']),_0x3718f1&&_0x3718f1['token']&&(_0xb476b0['ac']=_0x3718f1['token']);const _0x597780=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x7555f+'?ns='+this['repoInfo_']['namespace']+ut(_0xb476b0);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x597780);const _0x18075d=new XMLHttpRequest();_0x18075d['onreadystatechange']=()=>{if(_0xeef95b&&_0x18075d['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x597780+'\x20received.\x20status:',_0x18075d['status'],'response:',_0x18075d['responseText']);let _0x38ebfc=null;if(_0x18075d['status']>=0xc8&&_0x18075d['status']<0x12c){try{_0x38ebfc=Nt(_0x18075d['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x597780+':\x20'+_0x18075d['responseText']);}_0xeef95b(null,_0x38ebfc);}else _0x18075d['status']!==0x191&&_0x18075d['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x597780+'\x20Status:\x20'+_0x18075d['status']),_0xeef95b(_0x18075d['status']);_0xeef95b=null;}},_0x18075d['open']('GET',_0x597780,!0x0),_0x18075d['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0xbb41be){return this['rootNode_']['getChild'](_0xbb41be);}['updateSnapshot'](_0x15e585,_0x16cf5d){this['rootNode_']=this['rootNode_']['updateChild'](_0x15e585,_0x16cf5d);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function En(){return{'value':null,'children':new Map()};}function pt(_0x2a756b,_0x116fc3,_0x5f011e){if(v(_0x116fc3))_0x2a756b['value']=_0x5f011e,_0x2a756b['children']['clear']();else{if(_0x2a756b['value']!==null)_0x2a756b['value']=_0x2a756b['value']['updateChild'](_0x116fc3,_0x5f011e);else{const _0x1092d4=y(_0x116fc3);_0x2a756b['children']['has'](_0x1092d4)||_0x2a756b['children']['set'](_0x1092d4,En());const _0xc87191=_0x2a756b['children']['get'](_0x1092d4);_0x116fc3=S(_0x116fc3),pt(_0xc87191,_0x116fc3,_0x5f011e);}}}function Ti(_0x3949da,_0x3acebe){if(v(_0x3acebe))return _0x3949da['value']=null,_0x3949da['children']['clear'](),!0x0;if(_0x3949da['value']!==null){if(_0x3949da['value']['isLeafNode']())return!0x1;{const _0x3021c3=_0x3949da['value'];return _0x3949da['value']=null,_0x3021c3['forEachChild'](R,(_0x234142,_0x2ab460)=>{pt(_0x3949da,new C(_0x234142),_0x2ab460);}),Ti(_0x3949da,_0x3acebe);}}else{if(_0x3949da['children']['size']>0x0){const _0x17ff42=y(_0x3acebe);return _0x3acebe=S(_0x3acebe),_0x3949da['children']['has'](_0x17ff42)&&Ti(_0x3949da['children']['get'](_0x17ff42),_0x3acebe)&&_0x3949da['children']['delete'](_0x17ff42),_0x3949da['children']['size']===0x0;}else return!0x0;}}function Si(_0x5f369e,_0x48cc1b,_0x1cd500){_0x5f369e['value']!==null?_0x1cd500(_0x48cc1b,_0x5f369e['value']):Zh(_0x5f369e,(_0x2a7d08,_0x2c7c67)=>{const _0x54a8a3=new C(_0x48cc1b['toString']()+'/'+_0x2a7d08);Si(_0x2c7c67,_0x54a8a3,_0x1cd500);});}function Zh(_0x3e113b,_0x44734b){_0x3e113b['children']['forEach']((_0x1e9cbd,_0x144ba9)=>{_0x44734b(_0x144ba9,_0x1e9cbd);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x15033f){this['collection_']=_0x15033f,this['last_']=null;}['get'](){const _0x31e27c=this['collection_']['get'](),_0x4cb42c={..._0x31e27c};return this['last_']&&x(this['last_'],(_0x1bb598,_0x2beb1d)=>{_0x4cb42c[_0x1bb598]=_0x4cb42c[_0x1bb598]-_0x2beb1d;}),this['last_']=_0x31e27c,_0x4cb42c;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rr=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x38c96b,_0x23bcdc){this['server_']=_0x23bcdc,this['statsToReport_']={},this['statsListener_']=new eu(_0x38c96b);const _0x56950f=rr+(tu-rr)*Math['random']();bt(this['reportStats_']['bind'](this),Math['floor'](_0x56950f));}['reportStats_'](){const _0x3b2aac=this['statsListener_']['get'](),_0x46abf7={};let _0x58fa79=!0x1;x(_0x3b2aac,(_0x34152b,_0x33bc27)=>{_0x33bc27>0x0&&Q(this['statsToReport_'],_0x34152b)&&(_0x46abf7[_0x34152b]=_0x33bc27,_0x58fa79=!0x0);}),_0x58fa79&&this['server_']['reportStats'](_0x46abf7),bt(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var z;(function(_0x55980e){_0x55980e[_0x55980e['OVERWRITE']=0x0]='OVERWRITE',_0x55980e[_0x55980e['MERGE']=0x1]='MERGE',_0x55980e[_0x55980e['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x55980e[_0x55980e['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(z||(z={})));function es(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function ts(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ns(_0x293a0b){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x293a0b,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class In{constructor(_0x26c22d,_0x14e455,_0x504777){this['path']=_0x26c22d,this['affectedTree']=_0x14e455,this['revert']=_0x504777,this['type']=z['ACK_USER_WRITE'],this['source']=es();}['operationForChild'](_0x3678d4){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x33337b=this['affectedTree']['subtree'](new C(_0x3678d4));return new In(w(),_0x33337b,this['revert']);}}else return f(y(this['path'])===_0x3678d4,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new In(S(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ut{constructor(_0x97347f,_0x1b5832){this['source']=_0x97347f,this['path']=_0x1b5832,this['type']=z['LISTEN_COMPLETE'];}['operationForChild'](_0x5ac873){return v(this['path'])?new Ut(this['source'],w()):new Ut(this['source'],S(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Be{constructor(_0x246b8b,_0x32a7d3,_0x1909aa){this['source']=_0x246b8b,this['path']=_0x32a7d3,this['snap']=_0x1909aa,this['type']=z['OVERWRITE'];}['operationForChild'](_0x205f71){return v(this['path'])?new Be(this['source'],w(),this['snap']['getImmediateChild'](_0x205f71)):new Be(this['source'],S(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(_0x4de93a,_0x11ddad,_0x15654e){this['source']=_0x4de93a,this['path']=_0x11ddad,this['children']=_0x15654e,this['type']=z['MERGE'];}['operationForChild'](_0x1700bf){if(v(this['path'])){const _0x2c22f9=this['children']['subtree'](new C(_0x1700bf));return _0x2c22f9['isEmpty']()?null:_0x2c22f9['value']?new Be(this['source'],w(),_0x2c22f9['value']):new ot(this['source'],w(),_0x2c22f9);}else return f(y(this['path'])===_0x1700bf,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new ot(this['source'],S(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Te{constructor(_0x311760,_0x3cfda6,_0x550ecf){this['node_']=_0x311760,this['fullyInitialized_']=_0x3cfda6,this['filtered_']=_0x550ecf;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x4de663){if(v(_0x4de663))return this['isFullyInitialized']()&&!this['filtered_'];const _0x568f84=y(_0x4de663);return this['isCompleteForChild'](_0x568f84);}['isCompleteForChild'](_0x1ffc22){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x1ffc22);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x289588){this['query_']=_0x289588,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x390afc,_0x3330d7,_0x470062,_0xcd6d5c){const _0x36d8d4=[],_0x34dbd4=[];return _0x3330d7['forEach'](_0x3ebaa9=>{_0x3ebaa9['type']==='child_changed'&&_0x390afc['index_']['indexedValueChanged'](_0x3ebaa9['oldSnap'],_0x3ebaa9['snapshotNode'])&&_0x34dbd4['push'](zh(_0x3ebaa9['childName'],_0x3ebaa9['snapshotNode']));}),wt(_0x390afc,_0x36d8d4,'child_removed',_0x3330d7,_0xcd6d5c,_0x470062),wt(_0x390afc,_0x36d8d4,'child_added',_0x3330d7,_0xcd6d5c,_0x470062),wt(_0x390afc,_0x36d8d4,'child_moved',_0x34dbd4,_0xcd6d5c,_0x470062),wt(_0x390afc,_0x36d8d4,'child_changed',_0x3330d7,_0xcd6d5c,_0x470062),wt(_0x390afc,_0x36d8d4,'value',_0x3330d7,_0xcd6d5c,_0x470062),_0x36d8d4;}function wt(_0x32a8ee,_0x163b18,_0x57aa91,_0x1c638c,_0x3272f6,_0x56b709){const _0xa28284=_0x1c638c['filter'](_0x481513=>_0x481513['type']===_0x57aa91);_0xa28284['sort']((_0x5e08c1,_0x124a2f)=>au(_0x32a8ee,_0x5e08c1,_0x124a2f)),_0xa28284['forEach'](_0x4c0410=>{const _0x23f143=ou(_0x32a8ee,_0x4c0410,_0x56b709);_0x3272f6['forEach'](_0x322ede=>{_0x322ede['respondsTo'](_0x4c0410['type'])&&_0x163b18['push'](_0x322ede['createEvent'](_0x23f143,_0x32a8ee['query_']));});});}function ou(_0x4ee47a,_0x573ab1,_0x1c838b){return _0x573ab1['type']==='value'||_0x573ab1['type']==='child_removed'||(_0x573ab1['prevName']=_0x1c838b['getPredecessorChildName'](_0x573ab1['childName'],_0x573ab1['snapshotNode'],_0x4ee47a['index_'])),_0x573ab1;}function au(_0x2a90b0,_0x3af172,_0xa4620e){if(_0x3af172['childName']==null||_0xa4620e['childName']==null)throw ht('Should\x20only\x20compare\x20child_\x20events.');const _0x535241=new E(_0x3af172['childName'],_0x3af172['snapshotNode']),_0x14bc6c=new E(_0xa4620e['childName'],_0xa4620e['snapshotNode']);return _0x2a90b0['index_']['compare'](_0x535241,_0x14bc6c);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Un(_0x5066ce,_0x57abf7){return{'eventCache':_0x5066ce,'serverCache':_0x57abf7};}function Rt(_0x144e71,_0x4df472,_0x207cb2,_0x5c84ec){return Un(new Te(_0x4df472,_0x207cb2,_0x5c84ec),_0x144e71['serverCache']);}function Fo(_0x91e623,_0x4bce72,_0x1382c1,_0x170772){return Un(_0x91e623['eventCache'],new Te(_0x4bce72,_0x1382c1,_0x170772));}function wn(_0x351a3b){return _0x351a3b['eventCache']['isFullyInitialized']()?_0x351a3b['eventCache']['getNode']():null;}function Ve(_0x41f688){return _0x41f688['serverCache']['isFullyInitialized']()?_0x41f688['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let hi;const cu=()=>(hi||(hi=new B(ql)),hi);class b{static['fromObject'](_0xc1cfad){let _0x4fac46=new b(null);return x(_0xc1cfad,(_0x4bb3f7,_0x10effc)=>{_0x4fac46=_0x4fac46['set'](new C(_0x4bb3f7),_0x10effc);}),_0x4fac46;}constructor(_0x46cbce,_0x322e7c=cu()){this['value']=_0x46cbce,this['children']=_0x322e7c;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x249300,_0x43815a){if(this['value']!=null&&_0x43815a(this['value']))return{'path':w(),'value':this['value']};if(v(_0x249300))return null;{const _0x1b0fc5=y(_0x249300),_0x32c707=this['children']['get'](_0x1b0fc5);if(_0x32c707!==null){const _0x361718=_0x32c707['findRootMostMatchingPathAndValue'](S(_0x249300),_0x43815a);return _0x361718!=null?{'path':k(new C(_0x1b0fc5),_0x361718['path']),'value':_0x361718['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x97e2e7){return this['findRootMostMatchingPathAndValue'](_0x97e2e7,()=>!0x0);}['subtree'](_0x253003){if(v(_0x253003))return this;{const _0x5b1f14=y(_0x253003),_0x2f3575=this['children']['get'](_0x5b1f14);return _0x2f3575!==null?_0x2f3575['subtree'](S(_0x253003)):new b(null);}}['set'](_0xf651bf,_0x1ac443){if(v(_0xf651bf))return new b(_0x1ac443,this['children']);{const _0x317a45=y(_0xf651bf),_0x2d2529=(this['children']['get'](_0x317a45)||new b(null))['set'](S(_0xf651bf),_0x1ac443),_0x1826de=this['children']['insert'](_0x317a45,_0x2d2529);return new b(this['value'],_0x1826de);}}['remove'](_0x20bb91){if(v(_0x20bb91))return this['children']['isEmpty']()?new b(null):new b(null,this['children']);{const _0x547721=y(_0x20bb91),_0x46adea=this['children']['get'](_0x547721);if(_0x46adea){const _0x17d0c4=_0x46adea['remove'](S(_0x20bb91));let _0xa9406d;return _0x17d0c4['isEmpty']()?_0xa9406d=this['children']['remove'](_0x547721):_0xa9406d=this['children']['insert'](_0x547721,_0x17d0c4),this['value']===null&&_0xa9406d['isEmpty']()?new b(null):new b(this['value'],_0xa9406d);}else return this;}}['get'](_0x851bba){if(v(_0x851bba))return this['value'];{const _0x1feb1f=y(_0x851bba),_0x29c43c=this['children']['get'](_0x1feb1f);return _0x29c43c?_0x29c43c['get'](S(_0x851bba)):null;}}['setTree'](_0x3d153a,_0x56d08e){if(v(_0x3d153a))return _0x56d08e;{const _0x575fc7=y(_0x3d153a),_0x5459ae=(this['children']['get'](_0x575fc7)||new b(null))['setTree'](S(_0x3d153a),_0x56d08e);let _0x11f1d5;return _0x5459ae['isEmpty']()?_0x11f1d5=this['children']['remove'](_0x575fc7):_0x11f1d5=this['children']['insert'](_0x575fc7,_0x5459ae),new b(this['value'],_0x11f1d5);}}['fold'](_0xa10efd){return this['fold_'](w(),_0xa10efd);}['fold_'](_0x2078cd,_0x2cdd21){const _0x550f9d={};return this['children']['inorderTraversal']((_0x49eae5,_0x1d9b2a)=>{_0x550f9d[_0x49eae5]=_0x1d9b2a['fold_'](k(_0x2078cd,_0x49eae5),_0x2cdd21);}),_0x2cdd21(_0x2078cd,this['value'],_0x550f9d);}['findOnPath'](_0x3386b5,_0x409700){return this['findOnPath_'](_0x3386b5,w(),_0x409700);}['findOnPath_'](_0x183377,_0x4240f6,_0x266f39){const _0x13c357=this['value']?_0x266f39(_0x4240f6,this['value']):!0x1;if(_0x13c357)return _0x13c357;if(v(_0x183377))return null;{const _0x24c588=y(_0x183377),_0x5ced23=this['children']['get'](_0x24c588);return _0x5ced23?_0x5ced23['findOnPath_'](S(_0x183377),k(_0x4240f6,_0x24c588),_0x266f39):null;}}['foreachOnPath'](_0x1d48c4,_0x2e0f39){return this['foreachOnPath_'](_0x1d48c4,w(),_0x2e0f39);}['foreachOnPath_'](_0x4b40c2,_0x5acaae,_0x5319e0){if(v(_0x4b40c2))return this;{this['value']&&_0x5319e0(_0x5acaae,this['value']);const _0x5ed04a=y(_0x4b40c2),_0x1cc600=this['children']['get'](_0x5ed04a);return _0x1cc600?_0x1cc600['foreachOnPath_'](S(_0x4b40c2),k(_0x5acaae,_0x5ed04a),_0x5319e0):new b(null);}}['foreach'](_0x5041e1){this['foreach_'](w(),_0x5041e1);}['foreach_'](_0x11e1ef,_0x3274ee){this['children']['inorderTraversal']((_0x38d0cf,_0x5674fa)=>{_0x5674fa['foreach_'](k(_0x11e1ef,_0x38d0cf),_0x3274ee);}),this['value']&&_0x3274ee(_0x11e1ef,this['value']);}['foreachChild'](_0x303b8e){this['children']['inorderTraversal']((_0x4260b0,_0x26c7b8)=>{_0x26c7b8['value']&&_0x303b8e(_0x4260b0,_0x26c7b8['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class K{constructor(_0x42794d){this['writeTree_']=_0x42794d;}static['empty'](){return new K(new b(null));}}function At(_0x496fe3,_0x20eaa5,_0x2b43e8){if(v(_0x20eaa5))return new K(new b(_0x2b43e8));{const _0x4eb6d4=_0x496fe3['writeTree_']['findRootMostValueAndPath'](_0x20eaa5);if(_0x4eb6d4!=null){const _0x5086f5=_0x4eb6d4['path'];let _0x576842=_0x4eb6d4['value'];const _0x17cac7=F(_0x5086f5,_0x20eaa5);return _0x576842=_0x576842['updateChild'](_0x17cac7,_0x2b43e8),new K(_0x496fe3['writeTree_']['set'](_0x5086f5,_0x576842));}else{const _0x37b42c=new b(_0x2b43e8),_0xb1e88a=_0x496fe3['writeTree_']['setTree'](_0x20eaa5,_0x37b42c);return new K(_0xb1e88a);}}}function bi(_0x4c2dc4,_0x397b5d,_0x4b4024){let _0x28e101=_0x4c2dc4;return x(_0x4b4024,(_0x658790,_0x427130)=>{_0x28e101=At(_0x28e101,k(_0x397b5d,_0x658790),_0x427130);}),_0x28e101;}function or(_0x4d30c8,_0x50ba3c){if(v(_0x50ba3c))return K['empty']();{const _0x1637f1=_0x4d30c8['writeTree_']['setTree'](_0x50ba3c,new b(null));return new K(_0x1637f1);}}function Ri(_0x4ce288,_0x4ac074){return ze(_0x4ce288,_0x4ac074)!=null;}function ze(_0x1253e3,_0x1407c8){const _0x3e00b8=_0x1253e3['writeTree_']['findRootMostValueAndPath'](_0x1407c8);return _0x3e00b8!=null?_0x1253e3['writeTree_']['get'](_0x3e00b8['path'])['getChild'](F(_0x3e00b8['path'],_0x1407c8)):null;}function ar(_0x42836e){const _0x2e82dd=[],_0x59db22=_0x42836e['writeTree_']['value'];return _0x59db22!=null?_0x59db22['isLeafNode']()||_0x59db22['forEachChild'](R,(_0x4e082e,_0x225e8f)=>{_0x2e82dd['push'](new E(_0x4e082e,_0x225e8f));}):_0x42836e['writeTree_']['children']['inorderTraversal']((_0x35f0d0,_0x14607a)=>{_0x14607a['value']!=null&&_0x2e82dd['push'](new E(_0x35f0d0,_0x14607a['value']));}),_0x2e82dd;}function Ee(_0x4feb07,_0x3722b9){if(v(_0x3722b9))return _0x4feb07;{const _0x213a79=ze(_0x4feb07,_0x3722b9);return _0x213a79!=null?new K(new b(_0x213a79)):new K(_0x4feb07['writeTree_']['subtree'](_0x3722b9));}}function Ai(_0x526399){return _0x526399['writeTree_']['isEmpty']();}function at(_0x3562d8,_0x3abed7){return Uo(w(),_0x3562d8['writeTree_'],_0x3abed7);}function Uo(_0x13b42f,_0x24a5de,_0x1ad609){if(_0x24a5de['value']!=null)return _0x1ad609['updateChild'](_0x13b42f,_0x24a5de['value']);{let _0x9013ce=null;return _0x24a5de['children']['inorderTraversal']((_0x479a43,_0x44b0e7)=>{_0x479a43==='.priority'?(f(_0x44b0e7['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x9013ce=_0x44b0e7['value']):_0x1ad609=Uo(k(_0x13b42f,_0x479a43),_0x44b0e7,_0x1ad609);}),!_0x1ad609['getChild'](_0x13b42f)['isEmpty']()&&_0x9013ce!==null&&(_0x1ad609=_0x1ad609['updateChild'](k(_0x13b42f,'.priority'),_0x9013ce)),_0x1ad609;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Wn(_0x593f09,_0x407237){return Ho(_0x407237,_0x593f09);}function lu(_0x137f7e,_0x11e767,_0x809261,_0x24ffd7,_0x2b0645){f(_0x24ffd7>_0x137f7e['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x2b0645===void 0x0&&(_0x2b0645=!0x0),_0x137f7e['allWrites']['push']({'path':_0x11e767,'snap':_0x809261,'writeId':_0x24ffd7,'visible':_0x2b0645}),_0x2b0645&&(_0x137f7e['visibleWrites']=At(_0x137f7e['visibleWrites'],_0x11e767,_0x809261)),_0x137f7e['lastWriteId']=_0x24ffd7;}function hu(_0x23deb8,_0x16cad7,_0x36d613,_0x11d9c0){f(_0x11d9c0>_0x23deb8['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x23deb8['allWrites']['push']({'path':_0x16cad7,'children':_0x36d613,'writeId':_0x11d9c0,'visible':!0x0}),_0x23deb8['visibleWrites']=bi(_0x23deb8['visibleWrites'],_0x16cad7,_0x36d613),_0x23deb8['lastWriteId']=_0x11d9c0;}function uu(_0x7b0d56,_0x3a67cb){for(let _0x296e86=0x0;_0x296e86<_0x7b0d56['allWrites']['length'];_0x296e86++){const _0x3577fe=_0x7b0d56['allWrites'][_0x296e86];if(_0x3577fe['writeId']===_0x3a67cb)return _0x3577fe;}return null;}function du(_0x3fdc39,_0x205d78){const _0x11b06f=_0x3fdc39['allWrites']['findIndex'](_0x22701a=>_0x22701a['writeId']===_0x205d78);f(_0x11b06f>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x29e49d=_0x3fdc39['allWrites'][_0x11b06f];_0x3fdc39['allWrites']['splice'](_0x11b06f,0x1);let _0x4c06e4=_0x29e49d['visible'],_0x2c7b7a=!0x1,_0xa523ab=_0x3fdc39['allWrites']['length']-0x1;for(;_0x4c06e4&&_0xa523ab>=0x0;){const _0x41690d=_0x3fdc39['allWrites'][_0xa523ab];_0x41690d['visible']&&(_0xa523ab>=_0x11b06f&&fu(_0x41690d,_0x29e49d['path'])?_0x4c06e4=!0x1:G(_0x29e49d['path'],_0x41690d['path'])&&(_0x2c7b7a=!0x0)),_0xa523ab--;}if(_0x4c06e4){if(_0x2c7b7a)return pu(_0x3fdc39),!0x0;if(_0x29e49d['snap'])_0x3fdc39['visibleWrites']=or(_0x3fdc39['visibleWrites'],_0x29e49d['path']);else{const _0x5bae39=_0x29e49d['children'];x(_0x5bae39,_0x207080=>{_0x3fdc39['visibleWrites']=or(_0x3fdc39['visibleWrites'],k(_0x29e49d['path'],_0x207080));});}return!0x0;}else return!0x1;}function fu(_0x1fc5ff,_0x3da68e){if(_0x1fc5ff['snap'])return G(_0x1fc5ff['path'],_0x3da68e);for(const _0x116f2a in _0x1fc5ff['children'])if(_0x1fc5ff['children']['hasOwnProperty'](_0x116f2a)&&G(k(_0x1fc5ff['path'],_0x116f2a),_0x3da68e))return!0x0;return!0x1;}function pu(_0x4ef96e){_0x4ef96e['visibleWrites']=Wo(_0x4ef96e['allWrites'],_u,w()),_0x4ef96e['allWrites']['length']>0x0?_0x4ef96e['lastWriteId']=_0x4ef96e['allWrites'][_0x4ef96e['allWrites']['length']-0x1]['writeId']:_0x4ef96e['lastWriteId']=-0x1;}function _u(_0x21d8f2){return _0x21d8f2['visible'];}function Wo(_0x5bee0c,_0x4a293c,_0x1faa90){let _0x39b029=K['empty']();for(let _0x55d446=0x0;_0x55d446<_0x5bee0c['length'];++_0x55d446){const _0x446ecc=_0x5bee0c[_0x55d446];if(_0x4a293c(_0x446ecc)){const _0x5ec887=_0x446ecc['path'];let _0x4354b6;if(_0x446ecc['snap'])G(_0x1faa90,_0x5ec887)?(_0x4354b6=F(_0x1faa90,_0x5ec887),_0x39b029=At(_0x39b029,_0x4354b6,_0x446ecc['snap'])):G(_0x5ec887,_0x1faa90)&&(_0x4354b6=F(_0x5ec887,_0x1faa90),_0x39b029=At(_0x39b029,w(),_0x446ecc['snap']['getChild'](_0x4354b6)));else{if(_0x446ecc['children']){if(G(_0x1faa90,_0x5ec887))_0x4354b6=F(_0x1faa90,_0x5ec887),_0x39b029=bi(_0x39b029,_0x4354b6,_0x446ecc['children']);else{if(G(_0x5ec887,_0x1faa90)){if(_0x4354b6=F(_0x5ec887,_0x1faa90),v(_0x4354b6))_0x39b029=bi(_0x39b029,w(),_0x446ecc['children']);else{const _0x5ba99f=Le(_0x446ecc['children'],y(_0x4354b6));if(_0x5ba99f){const _0x2bfc80=_0x5ba99f['getChild'](S(_0x4354b6));_0x39b029=At(_0x39b029,w(),_0x2bfc80);}}}}}else throw ht('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x39b029;}function Bo(_0x2739fa,_0x50646d,_0x50094a,_0x1af708,_0x4a093f){if(!_0x1af708&&!_0x4a093f){const _0xa158d5=ze(_0x2739fa['visibleWrites'],_0x50646d);if(_0xa158d5!=null)return _0xa158d5;{const _0x587b49=Ee(_0x2739fa['visibleWrites'],_0x50646d);if(Ai(_0x587b49))return _0x50094a;if(_0x50094a==null&&!Ri(_0x587b49,w()))return null;{const _0x4528fe=_0x50094a||g['EMPTY_NODE'];return at(_0x587b49,_0x4528fe);}}}else{const _0x149934=Ee(_0x2739fa['visibleWrites'],_0x50646d);if(!_0x4a093f&&Ai(_0x149934))return _0x50094a;if(!_0x4a093f&&_0x50094a==null&&!Ri(_0x149934,w()))return null;{const _0x723a73=function(_0x9a1aa0){return(_0x9a1aa0['visible']||_0x4a093f)&&(!_0x1af708||!~_0x1af708['indexOf'](_0x9a1aa0['writeId']))&&(G(_0x9a1aa0['path'],_0x50646d)||G(_0x50646d,_0x9a1aa0['path']));},_0x1cd6d2=Wo(_0x2739fa['allWrites'],_0x723a73,_0x50646d),_0x1861c7=_0x50094a||g['EMPTY_NODE'];return at(_0x1cd6d2,_0x1861c7);}}}function gu(_0x33939e,_0x55c3c2,_0x1c0d59){let _0x658a67=g['EMPTY_NODE'];const _0x15ce29=ze(_0x33939e['visibleWrites'],_0x55c3c2);if(_0x15ce29)return _0x15ce29['isLeafNode']()||_0x15ce29['forEachChild'](R,(_0x1c0539,_0x3cc3f0)=>{_0x658a67=_0x658a67['updateImmediateChild'](_0x1c0539,_0x3cc3f0);}),_0x658a67;if(_0x1c0d59){const _0x355918=Ee(_0x33939e['visibleWrites'],_0x55c3c2);return _0x1c0d59['forEachChild'](R,(_0x31f04e,_0x2c7c51)=>{const _0x4c55a4=at(Ee(_0x355918,new C(_0x31f04e)),_0x2c7c51);_0x658a67=_0x658a67['updateImmediateChild'](_0x31f04e,_0x4c55a4);}),ar(_0x355918)['forEach'](_0x1b0227=>{_0x658a67=_0x658a67['updateImmediateChild'](_0x1b0227['name'],_0x1b0227['node']);}),_0x658a67;}else{const _0x28d8e2=Ee(_0x33939e['visibleWrites'],_0x55c3c2);return ar(_0x28d8e2)['forEach'](_0x7b9cd3=>{_0x658a67=_0x658a67['updateImmediateChild'](_0x7b9cd3['name'],_0x7b9cd3['node']);}),_0x658a67;}}function mu(_0x10ef39,_0x13d949,_0x146da9,_0x2a9a51,_0x354349){f(_0x2a9a51||_0x354349,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x9b1d1f=k(_0x13d949,_0x146da9);if(Ri(_0x10ef39['visibleWrites'],_0x9b1d1f))return null;{const _0x2e4c08=Ee(_0x10ef39['visibleWrites'],_0x9b1d1f);return Ai(_0x2e4c08)?_0x354349['getChild'](_0x146da9):at(_0x2e4c08,_0x354349['getChild'](_0x146da9));}}function yu(_0x52452e,_0x521b54,_0x178728,_0x15de49){const _0x18357f=k(_0x521b54,_0x178728),_0x3a84d2=ze(_0x52452e['visibleWrites'],_0x18357f);if(_0x3a84d2!=null)return _0x3a84d2;if(_0x15de49['isCompleteForChild'](_0x178728)){const _0x177842=Ee(_0x52452e['visibleWrites'],_0x18357f);return at(_0x177842,_0x15de49['getNode']()['getImmediateChild'](_0x178728));}else return null;}function vu(_0x93a55,_0x43a548){return ze(_0x93a55['visibleWrites'],_0x43a548);}function Eu(_0xd0e848,_0x399e08,_0x12ca48,_0x1f6056,_0x76a7a6,_0x4cb441,_0x566238){let _0x2fd221;const _0x20a8e6=Ee(_0xd0e848['visibleWrites'],_0x399e08),_0x145614=ze(_0x20a8e6,w());if(_0x145614!=null)_0x2fd221=_0x145614;else{if(_0x12ca48!=null)_0x2fd221=at(_0x20a8e6,_0x12ca48);else return[];}if(_0x2fd221=_0x2fd221['withIndex'](_0x566238),!_0x2fd221['isEmpty']()&&!_0x2fd221['isLeafNode']()){const _0x2c36d6=[],_0x1361c8=_0x566238['getCompare'](),_0x2f55c4=_0x4cb441?_0x2fd221['getReverseIteratorFrom'](_0x1f6056,_0x566238):_0x2fd221['getIteratorFrom'](_0x1f6056,_0x566238);let _0x19efa9=_0x2f55c4['getNext']();for(;_0x19efa9&&_0x2c36d6['length']<_0x76a7a6;)_0x1361c8(_0x19efa9,_0x1f6056)!==0x0&&_0x2c36d6['push'](_0x19efa9),_0x19efa9=_0x2f55c4['getNext']();return _0x2c36d6;}else return[];}function Iu(){return{'visibleWrites':K['empty'](),'allWrites':[],'lastWriteId':-0x1};}function Cn(_0x2e5330,_0x447ccf,_0x1f6bb2,_0xb58ea){return Bo(_0x2e5330['writeTree'],_0x2e5330['treePath'],_0x447ccf,_0x1f6bb2,_0xb58ea);}function is(_0x4e08cb,_0x8804ca){return gu(_0x4e08cb['writeTree'],_0x4e08cb['treePath'],_0x8804ca);}function cr(_0x535142,_0x2aa314,_0x4119cc,_0x268f8f){return mu(_0x535142['writeTree'],_0x535142['treePath'],_0x2aa314,_0x4119cc,_0x268f8f);}function Tn(_0x230463,_0x166220){return vu(_0x230463['writeTree'],k(_0x230463['treePath'],_0x166220));}function wu(_0x4745b4,_0x382c25,_0x2c7915,_0x27ed81,_0x55eb53,_0x49ea72){return Eu(_0x4745b4['writeTree'],_0x4745b4['treePath'],_0x382c25,_0x2c7915,_0x27ed81,_0x55eb53,_0x49ea72);}function ss(_0x31b9ed,_0x28a853,_0x2eb40b){return yu(_0x31b9ed['writeTree'],_0x31b9ed['treePath'],_0x28a853,_0x2eb40b);}function Vo(_0x17a880,_0x5d4ce7){return Ho(k(_0x17a880['treePath'],_0x5d4ce7),_0x17a880['writeTree']);}function Ho(_0x3040ff,_0x1cda90){return{'treePath':_0x3040ff,'writeTree':_0x1cda90};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x252ddb){const _0x365513=_0x252ddb['type'],_0x4ef4d7=_0x252ddb['childName'];f(_0x365513==='child_added'||_0x365513==='child_changed'||_0x365513==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x4ef4d7!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x38b11e=this['changeMap']['get'](_0x4ef4d7);if(_0x38b11e){const _0x4d091e=_0x38b11e['type'];if(_0x365513==='child_added'&&_0x4d091e==='child_removed')this['changeMap']['set'](_0x4ef4d7,xt(_0x4ef4d7,_0x252ddb['snapshotNode'],_0x38b11e['snapshotNode']));else{if(_0x365513==='child_removed'&&_0x4d091e==='child_added')this['changeMap']['delete'](_0x4ef4d7);else{if(_0x365513==='child_removed'&&_0x4d091e==='child_changed')this['changeMap']['set'](_0x4ef4d7,Lt(_0x4ef4d7,_0x38b11e['oldSnap']));else{if(_0x365513==='child_changed'&&_0x4d091e==='child_added')this['changeMap']['set'](_0x4ef4d7,rt(_0x4ef4d7,_0x252ddb['snapshotNode']));else{if(_0x365513==='child_changed'&&_0x4d091e==='child_changed')this['changeMap']['set'](_0x4ef4d7,xt(_0x4ef4d7,_0x252ddb['snapshotNode'],_0x38b11e['oldSnap']));else throw ht('Illegal\x20combination\x20of\x20changes:\x20'+_0x252ddb+'\x20occurred\x20after\x20'+_0x38b11e);}}}}}else this['changeMap']['set'](_0x4ef4d7,_0x252ddb);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x638d75){return null;}['getChildAfterChild'](_0x309742,_0x5ec792,_0x12ad27){return null;}}const $o=new Tu();class rs{constructor(_0xc84ffa,_0x4b9fc6,_0x12e4ba=null){this['writes_']=_0xc84ffa,this['viewCache_']=_0x4b9fc6,this['optCompleteServerCache_']=_0x12e4ba;}['getCompleteChild'](_0x2a788f){const _0x5d7d94=this['viewCache_']['eventCache'];if(_0x5d7d94['isCompleteForChild'](_0x2a788f))return _0x5d7d94['getNode']()['getImmediateChild'](_0x2a788f);{const _0xa8a9e9=this['optCompleteServerCache_']!=null?new Te(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return ss(this['writes_'],_0x2a788f,_0xa8a9e9);}}['getChildAfterChild'](_0x59e092,_0xd2895a,_0x264d00){const _0x5e2749=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:Ve(this['viewCache_']),_0x53f8a3=wu(this['writes_'],_0x5e2749,_0xd2895a,0x1,_0x264d00,_0x59e092);return _0x53f8a3['length']===0x0?null:_0x53f8a3[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x4a03b8){return{'filter':_0x4a03b8};}function bu(_0x48e391,_0x9b9ed2){f(_0x9b9ed2['eventCache']['getNode']()['isIndexed'](_0x48e391['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x9b9ed2['serverCache']['getNode']()['isIndexed'](_0x48e391['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x127708,_0x2b2022,_0x49035b,_0x43ea43,_0x1d2aa4){const _0x2b7299=new Cu();let _0xa3ac45,_0x186f3f;if(_0x49035b['type']===z['OVERWRITE']){const _0x41dfea=_0x49035b;_0x41dfea['source']['fromUser']?_0xa3ac45=ki(_0x127708,_0x2b2022,_0x41dfea['path'],_0x41dfea['snap'],_0x43ea43,_0x1d2aa4,_0x2b7299):(f(_0x41dfea['source']['fromServer'],'Unknown\x20source.'),_0x186f3f=_0x41dfea['source']['tagged']||_0x2b2022['serverCache']['isFiltered']()&&!v(_0x41dfea['path']),_0xa3ac45=Sn(_0x127708,_0x2b2022,_0x41dfea['path'],_0x41dfea['snap'],_0x43ea43,_0x1d2aa4,_0x186f3f,_0x2b7299));}else{if(_0x49035b['type']===z['MERGE']){const _0x4acf9c=_0x49035b;_0x4acf9c['source']['fromUser']?_0xa3ac45=ku(_0x127708,_0x2b2022,_0x4acf9c['path'],_0x4acf9c['children'],_0x43ea43,_0x1d2aa4,_0x2b7299):(f(_0x4acf9c['source']['fromServer'],'Unknown\x20source.'),_0x186f3f=_0x4acf9c['source']['tagged']||_0x2b2022['serverCache']['isFiltered'](),_0xa3ac45=Pi(_0x127708,_0x2b2022,_0x4acf9c['path'],_0x4acf9c['children'],_0x43ea43,_0x1d2aa4,_0x186f3f,_0x2b7299));}else{if(_0x49035b['type']===z['ACK_USER_WRITE']){const _0x3ee473=_0x49035b;_0x3ee473['revert']?_0xa3ac45=Ou(_0x127708,_0x2b2022,_0x3ee473['path'],_0x43ea43,_0x1d2aa4,_0x2b7299):_0xa3ac45=Pu(_0x127708,_0x2b2022,_0x3ee473['path'],_0x3ee473['affectedTree'],_0x43ea43,_0x1d2aa4,_0x2b7299);}else{if(_0x49035b['type']===z['LISTEN_COMPLETE'])_0xa3ac45=Nu(_0x127708,_0x2b2022,_0x49035b['path'],_0x43ea43,_0x2b7299);else throw ht('Unknown\x20operation\x20type:\x20'+_0x49035b['type']);}}}const _0x3484e6=_0x2b7299['getChanges']();return Au(_0x2b2022,_0xa3ac45,_0x3484e6),{'viewCache':_0xa3ac45,'changes':_0x3484e6};}function Au(_0x3e36b4,_0x217bfe,_0x41bcb5){const _0x141580=_0x217bfe['eventCache'];if(_0x141580['isFullyInitialized']()){const _0x4734b3=_0x141580['getNode']()['isLeafNode']()||_0x141580['getNode']()['isEmpty'](),_0x258614=wn(_0x3e36b4);(_0x41bcb5['length']>0x0||!_0x3e36b4['eventCache']['isFullyInitialized']()||_0x4734b3&&!_0x141580['getNode']()['equals'](_0x258614)||!_0x141580['getNode']()['getPriority']()['equals'](_0x258614['getPriority']()))&&_0x41bcb5['push'](Lo(wn(_0x217bfe)));}}function Go(_0x182e59,_0x247af9,_0x5be594,_0x520931,_0x493484,_0x5053f6){const _0x40300d=_0x247af9['eventCache'];if(Tn(_0x520931,_0x5be594)!=null)return _0x247af9;{let _0x3ced76,_0x12ac87;if(v(_0x5be594)){if(f(_0x247af9['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x247af9['serverCache']['isFiltered']()){const _0x578081=Ve(_0x247af9),_0x587af0=_0x578081 instanceof g?_0x578081:g['EMPTY_NODE'],_0x1a4523=is(_0x520931,_0x587af0);_0x3ced76=_0x182e59['filter']['updateFullNode'](_0x247af9['eventCache']['getNode'](),_0x1a4523,_0x5053f6);}else{const _0xa52964=Cn(_0x520931,Ve(_0x247af9));_0x3ced76=_0x182e59['filter']['updateFullNode'](_0x247af9['eventCache']['getNode'](),_0xa52964,_0x5053f6);}}else{const _0x39036b=y(_0x5be594);if(_0x39036b==='.priority'){f(Ce(_0x5be594)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x1ad9a1=_0x40300d['getNode']();_0x12ac87=_0x247af9['serverCache']['getNode']();const _0x2cd136=cr(_0x520931,_0x5be594,_0x1ad9a1,_0x12ac87);_0x2cd136!=null?_0x3ced76=_0x182e59['filter']['updatePriority'](_0x1ad9a1,_0x2cd136):_0x3ced76=_0x40300d['getNode']();}else{const _0x57035e=S(_0x5be594);let _0x18b1ea;if(_0x40300d['isCompleteForChild'](_0x39036b)){_0x12ac87=_0x247af9['serverCache']['getNode']();const _0x4fd84e=cr(_0x520931,_0x5be594,_0x40300d['getNode'](),_0x12ac87);_0x4fd84e!=null?_0x18b1ea=_0x40300d['getNode']()['getImmediateChild'](_0x39036b)['updateChild'](_0x57035e,_0x4fd84e):_0x18b1ea=_0x40300d['getNode']()['getImmediateChild'](_0x39036b);}else _0x18b1ea=ss(_0x520931,_0x39036b,_0x247af9['serverCache']);_0x18b1ea!=null?_0x3ced76=_0x182e59['filter']['updateChild'](_0x40300d['getNode'](),_0x39036b,_0x18b1ea,_0x57035e,_0x493484,_0x5053f6):_0x3ced76=_0x40300d['getNode']();}}return Rt(_0x247af9,_0x3ced76,_0x40300d['isFullyInitialized']()||v(_0x5be594),_0x182e59['filter']['filtersNodes']());}}function Sn(_0x5e69db,_0x46473,_0x313033,_0x559578,_0x5b96ad,_0x560037,_0x236f66,_0x3b086e){const _0xc43350=_0x46473['serverCache'];let _0x48cd93;const _0x3306f8=_0x236f66?_0x5e69db['filter']:_0x5e69db['filter']['getIndexedFilter']();if(v(_0x313033))_0x48cd93=_0x3306f8['updateFullNode'](_0xc43350['getNode'](),_0x559578,null);else{if(_0x3306f8['filtersNodes']()&&!_0xc43350['isFiltered']()){const _0x2a7a8d=_0xc43350['getNode']()['updateChild'](_0x313033,_0x559578);_0x48cd93=_0x3306f8['updateFullNode'](_0xc43350['getNode'](),_0x2a7a8d,null);}else{const _0x50998c=y(_0x313033);if(!_0xc43350['isCompleteForPath'](_0x313033)&&Ce(_0x313033)>0x1)return _0x46473;const _0x156729=S(_0x313033),_0x4b84f4=_0xc43350['getNode']()['getImmediateChild'](_0x50998c)['updateChild'](_0x156729,_0x559578);_0x50998c==='.priority'?_0x48cd93=_0x3306f8['updatePriority'](_0xc43350['getNode'](),_0x4b84f4):_0x48cd93=_0x3306f8['updateChild'](_0xc43350['getNode'](),_0x50998c,_0x4b84f4,_0x156729,$o,null);}}const _0x15dd78=Fo(_0x46473,_0x48cd93,_0xc43350['isFullyInitialized']()||v(_0x313033),_0x3306f8['filtersNodes']()),_0x4bf23f=new rs(_0x5b96ad,_0x15dd78,_0x560037);return Go(_0x5e69db,_0x15dd78,_0x313033,_0x5b96ad,_0x4bf23f,_0x3b086e);}function ki(_0x40d418,_0x1ec4e4,_0x36f304,_0x118b14,_0x46b39b,_0x4f8ff6,_0x1a6e12){const _0xa47593=_0x1ec4e4['eventCache'];let _0xd39b7,_0x5141f5;const _0x495022=new rs(_0x46b39b,_0x1ec4e4,_0x4f8ff6);if(v(_0x36f304))_0x5141f5=_0x40d418['filter']['updateFullNode'](_0x1ec4e4['eventCache']['getNode'](),_0x118b14,_0x1a6e12),_0xd39b7=Rt(_0x1ec4e4,_0x5141f5,!0x0,_0x40d418['filter']['filtersNodes']());else{const _0x188fb2=y(_0x36f304);if(_0x188fb2==='.priority')_0x5141f5=_0x40d418['filter']['updatePriority'](_0x1ec4e4['eventCache']['getNode'](),_0x118b14),_0xd39b7=Rt(_0x1ec4e4,_0x5141f5,_0xa47593['isFullyInitialized'](),_0xa47593['isFiltered']());else{const _0x1a1db4=S(_0x36f304),_0x4277b5=_0xa47593['getNode']()['getImmediateChild'](_0x188fb2);let _0x298f1c;if(v(_0x1a1db4))_0x298f1c=_0x118b14;else{const _0x1c76ac=_0x495022['getCompleteChild'](_0x188fb2);_0x1c76ac!=null?ji(_0x1a1db4)==='.priority'&&_0x1c76ac['getChild'](Ro(_0x1a1db4))['isEmpty']()?_0x298f1c=_0x1c76ac:_0x298f1c=_0x1c76ac['updateChild'](_0x1a1db4,_0x118b14):_0x298f1c=g['EMPTY_NODE'];}if(_0x4277b5['equals'](_0x298f1c))_0xd39b7=_0x1ec4e4;else{const _0x3661b6=_0x40d418['filter']['updateChild'](_0xa47593['getNode'](),_0x188fb2,_0x298f1c,_0x1a1db4,_0x495022,_0x1a6e12);_0xd39b7=Rt(_0x1ec4e4,_0x3661b6,_0xa47593['isFullyInitialized'](),_0x40d418['filter']['filtersNodes']());}}}return _0xd39b7;}function lr(_0x50b9b7,_0x9645e9){return _0x50b9b7['eventCache']['isCompleteForChild'](_0x9645e9);}function ku(_0xad83de,_0x48dbc6,_0x3be5dc,_0x18f1eb,_0x561184,_0x44c023,_0x4ca6b4){let _0xa85709=_0x48dbc6;return _0x18f1eb['foreach']((_0x5ea4f4,_0x397f2e)=>{const _0x4d4063=k(_0x3be5dc,_0x5ea4f4);lr(_0x48dbc6,y(_0x4d4063))&&(_0xa85709=ki(_0xad83de,_0xa85709,_0x4d4063,_0x397f2e,_0x561184,_0x44c023,_0x4ca6b4));}),_0x18f1eb['foreach']((_0x333328,_0x5d249b)=>{const _0x5cebe0=k(_0x3be5dc,_0x333328);lr(_0x48dbc6,y(_0x5cebe0))||(_0xa85709=ki(_0xad83de,_0xa85709,_0x5cebe0,_0x5d249b,_0x561184,_0x44c023,_0x4ca6b4));}),_0xa85709;}function hr(_0x38af1b,_0x267d33,_0x303bf6){return _0x303bf6['foreach']((_0x3afcc4,_0x48bd0b)=>{_0x267d33=_0x267d33['updateChild'](_0x3afcc4,_0x48bd0b);}),_0x267d33;}function Pi(_0x24c901,_0x121326,_0x18350f,_0x2bc925,_0x15d082,_0x266673,_0x7593e1,_0x53e2cf){if(_0x121326['serverCache']['getNode']()['isEmpty']()&&!_0x121326['serverCache']['isFullyInitialized']())return _0x121326;let _0x1466cf=_0x121326,_0x37dbf2;v(_0x18350f)?_0x37dbf2=_0x2bc925:_0x37dbf2=new b(null)['setTree'](_0x18350f,_0x2bc925);const _0x30f67e=_0x121326['serverCache']['getNode']();return _0x37dbf2['children']['inorderTraversal']((_0x5c1ed7,_0x53eb9c)=>{if(_0x30f67e['hasChild'](_0x5c1ed7)){const _0x1ef550=_0x121326['serverCache']['getNode']()['getImmediateChild'](_0x5c1ed7),_0x1e272a=hr(_0x24c901,_0x1ef550,_0x53eb9c);_0x1466cf=Sn(_0x24c901,_0x1466cf,new C(_0x5c1ed7),_0x1e272a,_0x15d082,_0x266673,_0x7593e1,_0x53e2cf);}}),_0x37dbf2['children']['inorderTraversal']((_0x4f11d4,_0x2472f4)=>{const _0x24ca9d=!_0x121326['serverCache']['isCompleteForChild'](_0x4f11d4)&&_0x2472f4['value']===null;if(!_0x30f67e['hasChild'](_0x4f11d4)&&!_0x24ca9d){const _0x2f9fef=_0x121326['serverCache']['getNode']()['getImmediateChild'](_0x4f11d4),_0x29343a=hr(_0x24c901,_0x2f9fef,_0x2472f4);_0x1466cf=Sn(_0x24c901,_0x1466cf,new C(_0x4f11d4),_0x29343a,_0x15d082,_0x266673,_0x7593e1,_0x53e2cf);}}),_0x1466cf;}function Pu(_0x334993,_0x5159d9,_0x435593,_0x1372d8,_0x1206b3,_0x5b36c7,_0x31ba67){if(Tn(_0x1206b3,_0x435593)!=null)return _0x5159d9;const _0x75d9d2=_0x5159d9['serverCache']['isFiltered'](),_0x354ff9=_0x5159d9['serverCache'];if(_0x1372d8['value']!=null){if(v(_0x435593)&&_0x354ff9['isFullyInitialized']()||_0x354ff9['isCompleteForPath'](_0x435593))return Sn(_0x334993,_0x5159d9,_0x435593,_0x354ff9['getNode']()['getChild'](_0x435593),_0x1206b3,_0x5b36c7,_0x75d9d2,_0x31ba67);if(v(_0x435593)){let _0x47f0a1=new b(null);return _0x354ff9['getNode']()['forEachChild'](ve,(_0x3d1909,_0x592026)=>{_0x47f0a1=_0x47f0a1['set'](new C(_0x3d1909),_0x592026);}),Pi(_0x334993,_0x5159d9,_0x435593,_0x47f0a1,_0x1206b3,_0x5b36c7,_0x75d9d2,_0x31ba67);}else return _0x5159d9;}else{let _0x199cc6=new b(null);return _0x1372d8['foreach']((_0x5adf2d,_0x489f37)=>{const _0x4a07b1=k(_0x435593,_0x5adf2d);_0x354ff9['isCompleteForPath'](_0x4a07b1)&&(_0x199cc6=_0x199cc6['set'](_0x5adf2d,_0x354ff9['getNode']()['getChild'](_0x4a07b1)));}),Pi(_0x334993,_0x5159d9,_0x435593,_0x199cc6,_0x1206b3,_0x5b36c7,_0x75d9d2,_0x31ba67);}}function Nu(_0x4efa2b,_0x11cfb7,_0xbafa48,_0x46c123,_0x4a0b2d){const _0x1d8e9d=_0x11cfb7['serverCache'],_0x12cb55=Fo(_0x11cfb7,_0x1d8e9d['getNode'](),_0x1d8e9d['isFullyInitialized']()||v(_0xbafa48),_0x1d8e9d['isFiltered']());return Go(_0x4efa2b,_0x12cb55,_0xbafa48,_0x46c123,$o,_0x4a0b2d);}function Ou(_0x3bdb8a,_0x81b151,_0x5ba72e,_0x216fe4,_0x1f70de,_0x11ea89){let _0x20d11f;if(Tn(_0x216fe4,_0x5ba72e)!=null)return _0x81b151;{const _0x417dc8=new rs(_0x216fe4,_0x81b151,_0x1f70de),_0x4b3253=_0x81b151['eventCache']['getNode']();let _0x4a9d9f;if(v(_0x5ba72e)||y(_0x5ba72e)==='.priority'){let _0x221763;if(_0x81b151['serverCache']['isFullyInitialized']())_0x221763=Cn(_0x216fe4,Ve(_0x81b151));else{const _0x7e2e50=_0x81b151['serverCache']['getNode']();f(_0x7e2e50 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x221763=is(_0x216fe4,_0x7e2e50);}_0x221763=_0x221763,_0x4a9d9f=_0x3bdb8a['filter']['updateFullNode'](_0x4b3253,_0x221763,_0x11ea89);}else{const _0x502f19=y(_0x5ba72e);let _0x33a0ef=ss(_0x216fe4,_0x502f19,_0x81b151['serverCache']);_0x33a0ef==null&&_0x81b151['serverCache']['isCompleteForChild'](_0x502f19)&&(_0x33a0ef=_0x4b3253['getImmediateChild'](_0x502f19)),_0x33a0ef!=null?_0x4a9d9f=_0x3bdb8a['filter']['updateChild'](_0x4b3253,_0x502f19,_0x33a0ef,S(_0x5ba72e),_0x417dc8,_0x11ea89):_0x81b151['eventCache']['getNode']()['hasChild'](_0x502f19)?_0x4a9d9f=_0x3bdb8a['filter']['updateChild'](_0x4b3253,_0x502f19,g['EMPTY_NODE'],S(_0x5ba72e),_0x417dc8,_0x11ea89):_0x4a9d9f=_0x4b3253,_0x4a9d9f['isEmpty']()&&_0x81b151['serverCache']['isFullyInitialized']()&&(_0x20d11f=Cn(_0x216fe4,Ve(_0x81b151)),_0x20d11f['isLeafNode']()&&(_0x4a9d9f=_0x3bdb8a['filter']['updateFullNode'](_0x4a9d9f,_0x20d11f,_0x11ea89)));}return _0x20d11f=_0x81b151['serverCache']['isFullyInitialized']()||Tn(_0x216fe4,w())!=null,Rt(_0x81b151,_0x4a9d9f,_0x20d11f,_0x3bdb8a['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x1293ea,_0x26a64f){this['query_']=_0x1293ea,this['eventRegistrations_']=[];const _0x28bc60=this['query_']['_queryParams'],_0x4a4dab=new Xi(_0x28bc60['getIndex']()),_0x5340eb=Kh(_0x28bc60);this['processor_']=Su(_0x5340eb);const _0x43aa6b=_0x26a64f['serverCache'],_0x30dcaf=_0x26a64f['eventCache'],_0x47ab7a=_0x4a4dab['updateFullNode'](g['EMPTY_NODE'],_0x43aa6b['getNode'](),null),_0x292928=_0x5340eb['updateFullNode'](g['EMPTY_NODE'],_0x30dcaf['getNode'](),null),_0x582640=new Te(_0x47ab7a,_0x43aa6b['isFullyInitialized'](),_0x4a4dab['filtersNodes']()),_0x28b878=new Te(_0x292928,_0x30dcaf['isFullyInitialized'](),_0x5340eb['filtersNodes']());this['viewCache_']=Un(_0x28b878,_0x582640),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x14a9d8){return _0x14a9d8['viewCache_']['serverCache']['getNode']();}function Lu(_0x282b30){return wn(_0x282b30['viewCache_']);}function xu(_0x2938e4,_0x27da39){const _0x4ce117=Ve(_0x2938e4['viewCache_']);return _0x4ce117&&(_0x2938e4['query']['_queryParams']['loadsAllData']()||!v(_0x27da39)&&!_0x4ce117['getImmediateChild'](y(_0x27da39))['isEmpty']())?_0x4ce117['getChild'](_0x27da39):null;}function ur(_0x5ae517){return _0x5ae517['eventRegistrations_']['length']===0x0;}function Fu(_0x3e2862,_0x40f635){_0x3e2862['eventRegistrations_']['push'](_0x40f635);}function dr(_0x30850f,_0x196b0d,_0x146c71){const _0x116e73=[];if(_0x146c71){f(_0x196b0d==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x1a4255=_0x30850f['query']['_path'];_0x30850f['eventRegistrations_']['forEach'](_0x1e6c74=>{const _0x36486f=_0x1e6c74['createCancelEvent'](_0x146c71,_0x1a4255);_0x36486f&&_0x116e73['push'](_0x36486f);});}if(_0x196b0d){let _0x306be2=[];for(let _0x83f393=0x0;_0x83f393<_0x30850f['eventRegistrations_']['length'];++_0x83f393){const _0x4a2aa6=_0x30850f['eventRegistrations_'][_0x83f393];if(!_0x4a2aa6['matches'](_0x196b0d))_0x306be2['push'](_0x4a2aa6);else{if(_0x196b0d['hasAnyCallback']()){_0x306be2=_0x306be2['concat'](_0x30850f['eventRegistrations_']['slice'](_0x83f393+0x1));break;}}}_0x30850f['eventRegistrations_']=_0x306be2;}else _0x30850f['eventRegistrations_']=[];return _0x116e73;}function fr(_0x41bf73,_0x25fb8a,_0x3f1e54,_0xa86550){_0x25fb8a['type']===z['MERGE']&&_0x25fb8a['source']['queryId']!==null&&(f(Ve(_0x41bf73['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(wn(_0x41bf73['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x3e8cb2=_0x41bf73['viewCache_'],_0xb2cdc1=Ru(_0x41bf73['processor_'],_0x3e8cb2,_0x25fb8a,_0x3f1e54,_0xa86550);return bu(_0x41bf73['processor_'],_0xb2cdc1['viewCache']),f(_0xb2cdc1['viewCache']['serverCache']['isFullyInitialized']()||!_0x3e8cb2['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x41bf73['viewCache_']=_0xb2cdc1['viewCache'],qo(_0x41bf73,_0xb2cdc1['changes'],_0xb2cdc1['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x5c9576,_0x1023e5){const _0xe7d447=_0x5c9576['viewCache_']['eventCache'],_0x35202e=[];return _0xe7d447['getNode']()['isLeafNode']()||_0xe7d447['getNode']()['forEachChild'](R,(_0x5981cd,_0x10f70e)=>{_0x35202e['push'](rt(_0x5981cd,_0x10f70e));}),_0xe7d447['isFullyInitialized']()&&_0x35202e['push'](Lo(_0xe7d447['getNode']())),qo(_0x5c9576,_0x35202e,_0xe7d447['getNode'](),_0x1023e5);}function qo(_0x518086,_0x58bc91,_0x597894,_0x21754c){const _0x12489b=_0x21754c?[_0x21754c]:_0x518086['eventRegistrations_'];return ru(_0x518086['eventGenerator_'],_0x58bc91,_0x597894,_0x12489b);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let bn;class zo{constructor(){this['views']=new Map();}}function Wu(_0x52927e){f(!bn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),bn=_0x52927e;}function Bu(){return f(bn,'Reference.ts\x20has\x20not\x20been\x20loaded'),bn;}function Vu(_0x38ef1c){return _0x38ef1c['views']['size']===0x0;}function os(_0x557c37,_0x1bf168,_0x28c041,_0x59375c){const _0x3b583d=_0x1bf168['source']['queryId'];if(_0x3b583d!==null){const _0x4a567a=_0x557c37['views']['get'](_0x3b583d);return f(_0x4a567a!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),fr(_0x4a567a,_0x1bf168,_0x28c041,_0x59375c);}else{let _0x14a597=[];for(const _0x296359 of _0x557c37['views']['values']())_0x14a597=_0x14a597['concat'](fr(_0x296359,_0x1bf168,_0x28c041,_0x59375c));return _0x14a597;}}function jo(_0x4a84d6,_0x59d10a,_0x5869ec,_0x24b34e,_0x135dc9){const _0x5904e1=_0x59d10a['_queryIdentifier'],_0x3445a9=_0x4a84d6['views']['get'](_0x5904e1);if(!_0x3445a9){let _0x20d975=Cn(_0x5869ec,_0x135dc9?_0x24b34e:null),_0x21482f=!0x1;_0x20d975?_0x21482f=!0x0:_0x24b34e instanceof g?(_0x20d975=is(_0x5869ec,_0x24b34e),_0x21482f=!0x1):(_0x20d975=g['EMPTY_NODE'],_0x21482f=!0x1);const _0xf98b40=Un(new Te(_0x20d975,_0x21482f,!0x1),new Te(_0x24b34e,_0x135dc9,!0x1));return new Du(_0x59d10a,_0xf98b40);}return _0x3445a9;}function Hu(_0x52e8f8,_0x5c7ba1,_0x2390a3,_0x13df05,_0xde0b59,_0x28c250){const _0x5d76fb=jo(_0x52e8f8,_0x5c7ba1,_0x13df05,_0xde0b59,_0x28c250);return _0x52e8f8['views']['has'](_0x5c7ba1['_queryIdentifier'])||_0x52e8f8['views']['set'](_0x5c7ba1['_queryIdentifier'],_0x5d76fb),Fu(_0x5d76fb,_0x2390a3),Uu(_0x5d76fb,_0x2390a3);}function $u(_0x18dc0f,_0x125781,_0x359444,_0xa0f929){const _0x22c24b=_0x125781['_queryIdentifier'],_0x225a74=[];let _0x3dd32c=[];const _0x2bf830=Se(_0x18dc0f);if(_0x22c24b==='default'){for(const [_0x1b4a73,_0x460974]of _0x18dc0f['views']['entries']())_0x3dd32c=_0x3dd32c['concat'](dr(_0x460974,_0x359444,_0xa0f929)),ur(_0x460974)&&(_0x18dc0f['views']['delete'](_0x1b4a73),_0x460974['query']['_queryParams']['loadsAllData']()||_0x225a74['push'](_0x460974['query']));}else{const _0x3e5893=_0x18dc0f['views']['get'](_0x22c24b);_0x3e5893&&(_0x3dd32c=_0x3dd32c['concat'](dr(_0x3e5893,_0x359444,_0xa0f929)),ur(_0x3e5893)&&(_0x18dc0f['views']['delete'](_0x22c24b),_0x3e5893['query']['_queryParams']['loadsAllData']()||_0x225a74['push'](_0x3e5893['query'])));}return _0x2bf830&&!Se(_0x18dc0f)&&_0x225a74['push'](new(Bu())(_0x125781['_repo'],_0x125781['_path'])),{'removed':_0x225a74,'events':_0x3dd32c};}function Ko(_0x23f464){const _0xd952f3=[];for(const _0x1dee1a of _0x23f464['views']['values']())_0x1dee1a['query']['_queryParams']['loadsAllData']()||_0xd952f3['push'](_0x1dee1a);return _0xd952f3;}function Ie(_0x555a93,_0x35d53e){let _0xa5eea6=null;for(const _0x1c0b04 of _0x555a93['views']['values']())_0xa5eea6=_0xa5eea6||xu(_0x1c0b04,_0x35d53e);return _0xa5eea6;}function Yo(_0x16239e,_0x138006){if(_0x138006['_queryParams']['loadsAllData']())return Bn(_0x16239e);{const _0xb5b08a=_0x138006['_queryIdentifier'];return _0x16239e['views']['get'](_0xb5b08a);}}function Qo(_0x571953,_0x27d32e){return Yo(_0x571953,_0x27d32e)!=null;}function Se(_0x5bd66c){return Bn(_0x5bd66c)!=null;}function Bn(_0x141456){for(const _0x3ab25b of _0x141456['views']['values']())if(_0x3ab25b['query']['_queryParams']['loadsAllData']())return _0x3ab25b;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Rn;function Gu(_0x4cd96a){f(!Rn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),Rn=_0x4cd96a;}function qu(){return f(Rn,'Reference.ts\x20has\x20not\x20been\x20loaded'),Rn;}let zu=0x1;class pr{constructor(_0x46a37c){this['listenProvider_']=_0x46a37c,this['syncPointTree_']=new b(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function as(_0x130b7c,_0x18182d,_0x2bcbc8,_0x3d91d0,_0x35b336){return lu(_0x130b7c['pendingWriteTree_'],_0x18182d,_0x2bcbc8,_0x3d91d0,_0x35b336),_0x35b336?_t(_0x130b7c,new Be(es(),_0x18182d,_0x2bcbc8)):[];}function ju(_0x15ce01,_0xb76d96,_0x195be5,_0x8bb14f){hu(_0x15ce01['pendingWriteTree_'],_0xb76d96,_0x195be5,_0x8bb14f);const _0x14a9e9=b['fromObject'](_0x195be5);return _t(_0x15ce01,new ot(es(),_0xb76d96,_0x14a9e9));}function _e(_0x376b77,_0x5d7de5,_0x3defcb=!0x1){const _0x244326=uu(_0x376b77['pendingWriteTree_'],_0x5d7de5);if(du(_0x376b77['pendingWriteTree_'],_0x5d7de5)){let _0xe49b3a=new b(null);return _0x244326['snap']!=null?_0xe49b3a=_0xe49b3a['set'](w(),!0x0):x(_0x244326['children'],_0xb74aba=>{_0xe49b3a=_0xe49b3a['set'](new C(_0xb74aba),!0x0);}),_t(_0x376b77,new In(_0x244326['path'],_0xe49b3a,_0x3defcb));}else return[];}function Yt(_0xfe8b52,_0x4f44fe,_0x18e782){return _t(_0xfe8b52,new Be(ts(),_0x4f44fe,_0x18e782));}function Ku(_0xc4a659,_0xce9eb,_0x49a192){const _0x498d33=b['fromObject'](_0x49a192);return _t(_0xc4a659,new ot(ts(),_0xce9eb,_0x498d33));}function Yu(_0x8235e,_0x50aac5){return _t(_0x8235e,new Ut(ts(),_0x50aac5));}function Qu(_0x30d91b,_0x1cc2bd,_0x1c272e){const _0x33c487=cs(_0x30d91b,_0x1c272e);if(_0x33c487){const _0x300c02=ls(_0x33c487),_0x2d5b84=_0x300c02['path'],_0x125076=_0x300c02['queryId'],_0x353b2e=F(_0x2d5b84,_0x1cc2bd),_0x5a8352=new Ut(ns(_0x125076),_0x353b2e);return hs(_0x30d91b,_0x2d5b84,_0x5a8352);}else return[];}function An(_0x27d7de,_0x55316f,_0x248334,_0x593ec3,_0x10ebcd=!0x1){const _0x201462=_0x55316f['_path'],_0x3c2d42=_0x27d7de['syncPointTree_']['get'](_0x201462);let _0x1584f3=[];if(_0x3c2d42&&(_0x55316f['_queryIdentifier']==='default'||Qo(_0x3c2d42,_0x55316f))){const _0x33b354=$u(_0x3c2d42,_0x55316f,_0x248334,_0x593ec3);Vu(_0x3c2d42)&&(_0x27d7de['syncPointTree_']=_0x27d7de['syncPointTree_']['remove'](_0x201462));const _0x131f5d=_0x33b354['removed'];if(_0x1584f3=_0x33b354['events'],!_0x10ebcd){const _0x12725e=_0x131f5d['findIndex'](_0x305dda=>_0x305dda['_queryParams']['loadsAllData']())!==-0x1,_0xbf4dd7=_0x27d7de['syncPointTree_']['findOnPath'](_0x201462,(_0x46741b,_0x57c614)=>Se(_0x57c614));if(_0x12725e&&!_0xbf4dd7){const _0x51113f=_0x27d7de['syncPointTree_']['subtree'](_0x201462);if(!_0x51113f['isEmpty']()){const _0x33d18d=Zu(_0x51113f);for(let _0x42c5c7=0x0;_0x42c5c7<_0x33d18d['length'];++_0x42c5c7){const _0x4919e7=_0x33d18d[_0x42c5c7],_0x56f6fa=_0x4919e7['query'],_0x6841f8=ea(_0x27d7de,_0x4919e7);_0x27d7de['listenProvider_']['startListening'](kt(_0x56f6fa),Wt(_0x27d7de,_0x56f6fa),_0x6841f8['hashFn'],_0x6841f8['onComplete']);}}}!_0xbf4dd7&&_0x131f5d['length']>0x0&&!_0x593ec3&&(_0x12725e?_0x27d7de['listenProvider_']['stopListening'](kt(_0x55316f),null):_0x131f5d['forEach'](_0x5045fc=>{const _0x4b27bc=_0x27d7de['queryToTagMap']['get'](Hn(_0x5045fc));_0x27d7de['listenProvider_']['stopListening'](kt(_0x5045fc),_0x4b27bc);}));}ed(_0x27d7de,_0x131f5d);}return _0x1584f3;}function Jo(_0x352de5,_0x56dadb,_0x2e03a8,_0x2105a3){const _0x5b1889=cs(_0x352de5,_0x2105a3);if(_0x5b1889!=null){const _0x3a22da=ls(_0x5b1889),_0x5b105f=_0x3a22da['path'],_0x5e979b=_0x3a22da['queryId'],_0x49d50f=F(_0x5b105f,_0x56dadb),_0x115c8b=new Be(ns(_0x5e979b),_0x49d50f,_0x2e03a8);return hs(_0x352de5,_0x5b105f,_0x115c8b);}else return[];}function Ju(_0x36a487,_0xa969b0,_0x837805,_0xf89622){const _0x39f93c=cs(_0x36a487,_0xf89622);if(_0x39f93c){const _0x34a577=ls(_0x39f93c),_0x2dc5e7=_0x34a577['path'],_0x499189=_0x34a577['queryId'],_0x2a4ff4=F(_0x2dc5e7,_0xa969b0),_0x1af832=b['fromObject'](_0x837805),_0x6e9b6c=new ot(ns(_0x499189),_0x2a4ff4,_0x1af832);return hs(_0x36a487,_0x2dc5e7,_0x6e9b6c);}else return[];}function Ni(_0x51627a,_0x2e2171,_0x19b4aa,_0x3e31dc=!0x1){const _0x293a4d=_0x2e2171['_path'];let _0x13611c=null,_0x2139e3=!0x1;_0x51627a['syncPointTree_']['foreachOnPath'](_0x293a4d,(_0x1a186e,_0x1c7fc4)=>{const _0x4d4514=F(_0x1a186e,_0x293a4d);_0x13611c=_0x13611c||Ie(_0x1c7fc4,_0x4d4514),_0x2139e3=_0x2139e3||Se(_0x1c7fc4);});let _0x551460=_0x51627a['syncPointTree_']['get'](_0x293a4d);_0x551460?(_0x2139e3=_0x2139e3||Se(_0x551460),_0x13611c=_0x13611c||Ie(_0x551460,w())):(_0x551460=new zo(),_0x51627a['syncPointTree_']=_0x51627a['syncPointTree_']['set'](_0x293a4d,_0x551460));let _0x1c929a;_0x13611c!=null?_0x1c929a=!0x0:(_0x1c929a=!0x1,_0x13611c=g['EMPTY_NODE'],_0x51627a['syncPointTree_']['subtree'](_0x293a4d)['foreachChild']((_0x232dac,_0x3916ad)=>{const _0xcaa816=Ie(_0x3916ad,w());_0xcaa816&&(_0x13611c=_0x13611c['updateImmediateChild'](_0x232dac,_0xcaa816));}));const _0x2d88d2=Qo(_0x551460,_0x2e2171);if(!_0x2d88d2&&!_0x2e2171['_queryParams']['loadsAllData']()){const _0x37d529=Hn(_0x2e2171);f(!_0x51627a['queryToTagMap']['has'](_0x37d529),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x144354=td();_0x51627a['queryToTagMap']['set'](_0x37d529,_0x144354),_0x51627a['tagToQueryMap']['set'](_0x144354,_0x37d529);}const _0x548e25=Wn(_0x51627a['pendingWriteTree_'],_0x293a4d);let _0x251e86=Hu(_0x551460,_0x2e2171,_0x19b4aa,_0x548e25,_0x13611c,_0x1c929a);if(!_0x2d88d2&&!_0x2139e3&&!_0x3e31dc){const _0x1ea05=Yo(_0x551460,_0x2e2171);_0x251e86=_0x251e86['concat'](nd(_0x51627a,_0x2e2171,_0x1ea05));}return _0x251e86;}function Vn(_0x47b76a,_0x5c8833,_0x55b794){const _0x40f6b1=_0x47b76a['pendingWriteTree_'],_0x9d5cf7=_0x47b76a['syncPointTree_']['findOnPath'](_0x5c8833,(_0x11675f,_0x3da228)=>{const _0x7c8001=F(_0x11675f,_0x5c8833),_0x4d1d4f=Ie(_0x3da228,_0x7c8001);if(_0x4d1d4f)return _0x4d1d4f;});return Bo(_0x40f6b1,_0x5c8833,_0x9d5cf7,_0x55b794,!0x0);}function Xu(_0x4cc475,_0xe4715a){const _0x54fe75=_0xe4715a['_path'];let _0x17ed54=null;_0x4cc475['syncPointTree_']['foreachOnPath'](_0x54fe75,(_0x38f488,_0x285b2b)=>{const _0x1efa5a=F(_0x38f488,_0x54fe75);_0x17ed54=_0x17ed54||Ie(_0x285b2b,_0x1efa5a);});let _0x24c5e8=_0x4cc475['syncPointTree_']['get'](_0x54fe75);_0x24c5e8?_0x17ed54=_0x17ed54||Ie(_0x24c5e8,w()):(_0x24c5e8=new zo(),_0x4cc475['syncPointTree_']=_0x4cc475['syncPointTree_']['set'](_0x54fe75,_0x24c5e8));const _0x1b1811=_0x17ed54!=null,_0x1cc69a=_0x1b1811?new Te(_0x17ed54,!0x0,!0x1):null,_0x39a80d=Wn(_0x4cc475['pendingWriteTree_'],_0xe4715a['_path']),_0x3516d2=jo(_0x24c5e8,_0xe4715a,_0x39a80d,_0x1b1811?_0x1cc69a['getNode']():g['EMPTY_NODE'],_0x1b1811);return Lu(_0x3516d2);}function _t(_0x4950ff,_0x3a0f0b){return Xo(_0x3a0f0b,_0x4950ff['syncPointTree_'],null,Wn(_0x4950ff['pendingWriteTree_'],w()));}function Xo(_0x131c76,_0x292116,_0x2b8414,_0x547c20){if(v(_0x131c76['path']))return Zo(_0x131c76,_0x292116,_0x2b8414,_0x547c20);{const _0x5012ab=_0x292116['get'](w());_0x2b8414==null&&_0x5012ab!=null&&(_0x2b8414=Ie(_0x5012ab,w()));let _0x31d912=[];const _0x52077a=y(_0x131c76['path']),_0xc00cb3=_0x131c76['operationForChild'](_0x52077a),_0x1c76b7=_0x292116['children']['get'](_0x52077a);if(_0x1c76b7&&_0xc00cb3){const _0x1ddcbc=_0x2b8414?_0x2b8414['getImmediateChild'](_0x52077a):null,_0x36ebb4=Vo(_0x547c20,_0x52077a);_0x31d912=_0x31d912['concat'](Xo(_0xc00cb3,_0x1c76b7,_0x1ddcbc,_0x36ebb4));}return _0x5012ab&&(_0x31d912=_0x31d912['concat'](os(_0x5012ab,_0x131c76,_0x547c20,_0x2b8414))),_0x31d912;}}function Zo(_0x4a8e39,_0x2f1689,_0x3e1c0d,_0x520f71){const _0x459664=_0x2f1689['get'](w());_0x3e1c0d==null&&_0x459664!=null&&(_0x3e1c0d=Ie(_0x459664,w()));let _0x1fe9fd=[];return _0x2f1689['children']['inorderTraversal']((_0x43d2b1,_0xf68e36)=>{const _0x239fec=_0x3e1c0d?_0x3e1c0d['getImmediateChild'](_0x43d2b1):null,_0x443095=Vo(_0x520f71,_0x43d2b1),_0x4ba593=_0x4a8e39['operationForChild'](_0x43d2b1);_0x4ba593&&(_0x1fe9fd=_0x1fe9fd['concat'](Zo(_0x4ba593,_0xf68e36,_0x239fec,_0x443095)));}),_0x459664&&(_0x1fe9fd=_0x1fe9fd['concat'](os(_0x459664,_0x4a8e39,_0x520f71,_0x3e1c0d))),_0x1fe9fd;}function ea(_0x533559,_0x180f61){const _0x54d938=_0x180f61['query'],_0x30c054=Wt(_0x533559,_0x54d938);return{'hashFn':()=>(Mu(_0x180f61)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x1fd1af=>{if(_0x1fd1af==='ok')return _0x30c054?Qu(_0x533559,_0x54d938['_path'],_0x30c054):Yu(_0x533559,_0x54d938['_path']);{const _0x1a4ace=Kl(_0x1fd1af,_0x54d938);return An(_0x533559,_0x54d938,null,_0x1a4ace);}}};}function Wt(_0x363b4b,_0x319c84){const _0x1424fa=Hn(_0x319c84);return _0x363b4b['queryToTagMap']['get'](_0x1424fa);}function Hn(_0x3981dd){return _0x3981dd['_path']['toString']()+'$'+_0x3981dd['_queryIdentifier'];}function cs(_0x28a18c,_0x24a3ca){return _0x28a18c['tagToQueryMap']['get'](_0x24a3ca);}function ls(_0x3489bb){const _0x5dd307=_0x3489bb['indexOf']('$');return f(_0x5dd307!==-0x1&&_0x5dd307<_0x3489bb['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x3489bb['substr'](_0x5dd307+0x1),'path':new C(_0x3489bb['substr'](0x0,_0x5dd307))};}function hs(_0x587ee4,_0x3c5e7a,_0x36272f){const _0x2bfdfb=_0x587ee4['syncPointTree_']['get'](_0x3c5e7a);f(_0x2bfdfb,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x287a5a=Wn(_0x587ee4['pendingWriteTree_'],_0x3c5e7a);return os(_0x2bfdfb,_0x36272f,_0x287a5a,null);}function Zu(_0x477c4a){return _0x477c4a['fold']((_0x368a3a,_0xb3b07c,_0x3fb2dc)=>{if(_0xb3b07c&&Se(_0xb3b07c))return[Bn(_0xb3b07c)];{let _0x4d8495=[];return _0xb3b07c&&(_0x4d8495=Ko(_0xb3b07c)),x(_0x3fb2dc,(_0xb23c34,_0x11db46)=>{_0x4d8495=_0x4d8495['concat'](_0x11db46);}),_0x4d8495;}});}function kt(_0x476b6d){return _0x476b6d['_queryParams']['loadsAllData']()&&!_0x476b6d['_queryParams']['isDefault']()?new(qu())(_0x476b6d['_repo'],_0x476b6d['_path']):_0x476b6d;}function ed(_0x32d00f,_0x323724){for(let _0x1330be=0x0;_0x1330be<_0x323724['length'];++_0x1330be){const _0x50829d=_0x323724[_0x1330be];if(!_0x50829d['_queryParams']['loadsAllData']()){const _0x5d2b31=Hn(_0x50829d),_0x42e89c=_0x32d00f['queryToTagMap']['get'](_0x5d2b31);_0x32d00f['queryToTagMap']['delete'](_0x5d2b31),_0x32d00f['tagToQueryMap']['delete'](_0x42e89c);}}}function td(){return zu++;}function nd(_0x24da66,_0x10dd4e,_0x2ea9d6){const _0x3eae13=_0x10dd4e['_path'],_0x573d97=Wt(_0x24da66,_0x10dd4e),_0x1b10a1=ea(_0x24da66,_0x2ea9d6),_0x2b547f=_0x24da66['listenProvider_']['startListening'](kt(_0x10dd4e),_0x573d97,_0x1b10a1['hashFn'],_0x1b10a1['onComplete']),_0x3ca733=_0x24da66['syncPointTree_']['subtree'](_0x3eae13);if(_0x573d97)f(!Se(_0x3ca733['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x191383=_0x3ca733['fold']((_0x49e641,_0x2a40c0,_0x293b17)=>{if(!v(_0x49e641)&&_0x2a40c0&&Se(_0x2a40c0))return[Bn(_0x2a40c0)['query']];{let _0x56c641=[];return _0x2a40c0&&(_0x56c641=_0x56c641['concat'](Ko(_0x2a40c0)['map'](_0x58f23a=>_0x58f23a['query']))),x(_0x293b17,(_0x2b9cf6,_0x2cea9e)=>{_0x56c641=_0x56c641['concat'](_0x2cea9e);}),_0x56c641;}});for(let _0x195a4c=0x0;_0x195a4c<_0x191383['length'];++_0x195a4c){const _0x284a41=_0x191383[_0x195a4c];_0x24da66['listenProvider_']['stopListening'](kt(_0x284a41),Wt(_0x24da66,_0x284a41));}}return _0x2b547f;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class us{constructor(_0x290b6f){this['node_']=_0x290b6f;}['getImmediateChild'](_0x32fff2){const _0x59722f=this['node_']['getImmediateChild'](_0x32fff2);return new us(_0x59722f);}['node'](){return this['node_'];}}class ds{constructor(_0xf5aa1d,_0x32ccc5){this['syncTree_']=_0xf5aa1d,this['path_']=_0x32ccc5;}['getImmediateChild'](_0x5bbdaf){const _0x41e6ad=k(this['path_'],_0x5bbdaf);return new ds(this['syncTree_'],_0x41e6ad);}['node'](){return Vn(this['syncTree_'],this['path_']);}}const id=function(_0x894c09){return _0x894c09=_0x894c09||{},_0x894c09['timestamp']=_0x894c09['timestamp']||new Date()['getTime'](),_0x894c09;},_r=function(_0x46f84c,_0x2e3722,_0x5c7c7c){if(!_0x46f84c||typeof _0x46f84c!='object')return _0x46f84c;if(f('.sv'in _0x46f84c,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x46f84c['.sv']=='string')return sd(_0x46f84c['.sv'],_0x2e3722,_0x5c7c7c);if(typeof _0x46f84c['.sv']=='object')return rd(_0x46f84c['.sv'],_0x2e3722);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x46f84c,null,0x2));},sd=function(_0x3790cd,_0xb0d09,_0x1663c5){switch(_0x3790cd){case'timestamp':return _0x1663c5['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x3790cd);}},rd=function(_0x3b037d,_0x3620ff,_0x2f186a){_0x3b037d['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x3b037d,null,0x2));const _0x35ff61=_0x3b037d['increment'];typeof _0x35ff61!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x35ff61);const _0x2661ed=_0x3620ff['node']();if(f(_0x2661ed!==null&&typeof _0x2661ed<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x2661ed['isLeafNode']())return _0x35ff61;const _0xeec378=_0x2661ed['getValue']();return typeof _0xeec378!='number'?_0x35ff61:_0xeec378+_0x35ff61;},ta=function(_0x2228e1,_0x7e93ea,_0x5001d0,_0x1945ce){return ps(_0x7e93ea,new ds(_0x5001d0,_0x2228e1),_0x1945ce);},fs=function(_0x2fbbc5,_0x322773,_0x5b7064){return ps(_0x2fbbc5,new us(_0x322773),_0x5b7064);};function ps(_0x1e4d3e,_0x259395,_0x22b227){const _0x412d80=_0x1e4d3e['getPriority']()['val'](),_0x5e11a2=_r(_0x412d80,_0x259395['getImmediateChild']('.priority'),_0x22b227);let _0x31bffb;if(_0x1e4d3e['isLeafNode']()){const _0x3deb50=_0x1e4d3e,_0x121b31=_r(_0x3deb50['getValue'](),_0x259395,_0x22b227);return _0x121b31!==_0x3deb50['getValue']()||_0x5e11a2!==_0x3deb50['getPriority']()['val']()?new D(_0x121b31,A(_0x5e11a2)):_0x1e4d3e;}else{const _0x5c391a=_0x1e4d3e;return _0x31bffb=_0x5c391a,_0x5e11a2!==_0x5c391a['getPriority']()['val']()&&(_0x31bffb=_0x31bffb['updatePriority'](new D(_0x5e11a2))),_0x5c391a['forEachChild'](R,(_0x3c7144,_0x11077e)=>{const _0x49089f=ps(_0x11077e,_0x259395['getImmediateChild'](_0x3c7144),_0x22b227);_0x49089f!==_0x11077e&&(_0x31bffb=_0x31bffb['updateImmediateChild'](_0x3c7144,_0x49089f));}),_0x31bffb;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class _s{constructor(_0x57ca17='',_0x342ba6=null,_0x4bd4ef={'children':{},'childCount':0x0}){this['name']=_0x57ca17,this['parent']=_0x342ba6,this['node']=_0x4bd4ef;}}function $n(_0x2f21aa,_0xa4c97e){let _0xddd58b=_0xa4c97e instanceof C?_0xa4c97e:new C(_0xa4c97e),_0x59be15=_0x2f21aa,_0x52792b=y(_0xddd58b);for(;_0x52792b!==null;){const _0x2da416=Le(_0x59be15['node']['children'],_0x52792b)||{'children':{},'childCount':0x0};_0x59be15=new _s(_0x52792b,_0x59be15,_0x2da416),_0xddd58b=S(_0xddd58b),_0x52792b=y(_0xddd58b);}return _0x59be15;}function je(_0x7660ee){return _0x7660ee['node']['value'];}function gs(_0x55b9f4,_0x15e14d){_0x55b9f4['node']['value']=_0x15e14d,Oi(_0x55b9f4);}function na(_0x1a6484){return _0x1a6484['node']['childCount']>0x0;}function od(_0x2a67df){return je(_0x2a67df)===void 0x0&&!na(_0x2a67df);}function Gn(_0x195759,_0x2b610e){x(_0x195759['node']['children'],(_0x143711,_0x2035f3)=>{_0x2b610e(new _s(_0x143711,_0x195759,_0x2035f3));});}function ia(_0x202dfe,_0x7b5cc5,_0x391d0c,_0x416bda){_0x391d0c&&_0x7b5cc5(_0x202dfe),Gn(_0x202dfe,_0x2fcde6=>{ia(_0x2fcde6,_0x7b5cc5,!0x0);});}function ad(_0x143f33,_0x4416ba,_0x34803c){let _0x560bb2=_0x143f33['parent'];for(;_0x560bb2!==null;){if(_0x4416ba(_0x560bb2))return!0x0;_0x560bb2=_0x560bb2['parent'];}return!0x1;}function Qt(_0x10dbbd){return new C(_0x10dbbd['parent']===null?_0x10dbbd['name']:Qt(_0x10dbbd['parent'])+'/'+_0x10dbbd['name']);}function Oi(_0x5bd8e5){_0x5bd8e5['parent']!==null&&cd(_0x5bd8e5['parent'],_0x5bd8e5['name'],_0x5bd8e5);}function cd(_0x3834a4,_0x4b04cb,_0x4881e6){const _0x1e006e=od(_0x4881e6),_0x158ea0=Q(_0x3834a4['node']['children'],_0x4b04cb);_0x1e006e&&_0x158ea0?(delete _0x3834a4['node']['children'][_0x4b04cb],_0x3834a4['node']['childCount']--,Oi(_0x3834a4)):!_0x1e006e&&!_0x158ea0&&(_0x3834a4['node']['children'][_0x4b04cb]=_0x4881e6['node'],_0x3834a4['node']['childCount']++,Oi(_0x3834a4));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ui=0xa*0x400*0x400,ms=function(_0x4c5bfe){return typeof _0x4c5bfe=='string'&&_0x4c5bfe['length']!==0x0&&!ld['test'](_0x4c5bfe);},sa=function(_0x3634b6){return typeof _0x3634b6=='string'&&_0x3634b6['length']!==0x0&&!hd['test'](_0x3634b6);},ud=function(_0x56deb0){return _0x56deb0&&(_0x56deb0=_0x56deb0['replace'](/^\/*\.info(\/|$)/,'/')),sa(_0x56deb0);},Bt=function(_0x532df8){return _0x532df8===null||typeof _0x532df8=='string'||typeof _0x532df8=='number'&&!xn(_0x532df8)||_0x532df8&&typeof _0x532df8=='object'&&Q(_0x532df8,'.sv');},He=function(_0x39bbb5,_0x39a0b6,_0xcd9bae,_0x2389f9){_0x2389f9&&_0x39a0b6===void 0x0||Jt(it(_0x39bbb5,'value'),_0x39a0b6,_0xcd9bae);},Jt=function(_0x17beb3,_0x2bee20,_0xf00eba){const _0x13e9c6=_0xf00eba instanceof C?new Ah(_0xf00eba,_0x17beb3):_0xf00eba;if(_0x2bee20===void 0x0)throw new Error(_0x17beb3+'contains\x20undefined\x20'+Oe(_0x13e9c6));if(typeof _0x2bee20=='function')throw new Error(_0x17beb3+'contains\x20a\x20function\x20'+Oe(_0x13e9c6)+'\x20with\x20contents\x20=\x20'+_0x2bee20['toString']());if(xn(_0x2bee20))throw new Error(_0x17beb3+'contains\x20'+_0x2bee20['toString']()+'\x20'+Oe(_0x13e9c6));if(typeof _0x2bee20=='string'&&_0x2bee20['length']>ui/0x3&&Ln(_0x2bee20)>ui)throw new Error(_0x17beb3+'contains\x20a\x20string\x20greater\x20than\x20'+ui+'\x20utf8\x20bytes\x20'+Oe(_0x13e9c6)+'\x20(\x27'+_0x2bee20['substring'](0x0,0x32)+'...\x27)');if(_0x2bee20&&typeof _0x2bee20=='object'){let _0x358a79=!0x1,_0x1e7b8e=!0x1;if(x(_0x2bee20,(_0xec7955,_0x49107c)=>{if(_0xec7955==='.value')_0x358a79=!0x0;else{if(_0xec7955!=='.priority'&&_0xec7955!=='.sv'&&(_0x1e7b8e=!0x0,!ms(_0xec7955)))throw new Error(_0x17beb3+'\x20contains\x20an\x20invalid\x20key\x20('+_0xec7955+')\x20'+Oe(_0x13e9c6)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x13e9c6,_0xec7955),Jt(_0x17beb3,_0x49107c,_0x13e9c6),Ph(_0x13e9c6);}),_0x358a79&&_0x1e7b8e)throw new Error(_0x17beb3+'\x20contains\x20\x22.value\x22\x20child\x20'+Oe(_0x13e9c6)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x278567,_0x49c6f5){let _0x3328e7,_0x3e64b5;for(_0x3328e7=0x0;_0x3328e7<_0x49c6f5['length'];_0x3328e7++){_0x3e64b5=_0x49c6f5[_0x3328e7];const _0x1ae547=Mt(_0x3e64b5);for(let _0x3d4b55=0x0;_0x3d4b55<_0x1ae547['length'];_0x3d4b55++)if(!(_0x1ae547[_0x3d4b55]==='.priority'&&_0x3d4b55===_0x1ae547['length']-0x1)){if(!ms(_0x1ae547[_0x3d4b55]))throw new Error(_0x278567+'contains\x20an\x20invalid\x20key\x20('+_0x1ae547[_0x3d4b55]+')\x20in\x20path\x20'+_0x3e64b5['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x49c6f5['sort'](Rh);let _0x596505=null;for(_0x3328e7=0x0;_0x3328e7<_0x49c6f5['length'];_0x3328e7++){if(_0x3e64b5=_0x49c6f5[_0x3328e7],_0x596505!==null&&G(_0x596505,_0x3e64b5))throw new Error(_0x278567+'contains\x20a\x20path\x20'+_0x596505['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x3e64b5['toString']());_0x596505=_0x3e64b5;}},ra=function(_0x10967b,_0x45abbd,_0x4d59a2,_0x53d465){const _0x39b5fd=it(_0x10967b,'values');if(!(_0x45abbd&&typeof _0x45abbd=='object')||Array['isArray'](_0x45abbd))throw new Error(_0x39b5fd+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x3fb65f=[];x(_0x45abbd,(_0x1286fd,_0x26f8a6)=>{const _0x1ff2fd=new C(_0x1286fd);if(Jt(_0x39b5fd,_0x26f8a6,k(_0x4d59a2,_0x1ff2fd)),ji(_0x1ff2fd)==='.priority'&&!Bt(_0x26f8a6))throw new Error(_0x39b5fd+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x1ff2fd['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x3fb65f['push'](_0x1ff2fd);}),dd(_0x39b5fd,_0x3fb65f);},fd=function(_0x5f258b,_0x2d2be8,_0x234cc9){if(xn(_0x2d2be8))throw new Error(it(_0x5f258b,'priority')+'is\x20'+_0x2d2be8['toString']()+',\x20but\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');if(!Bt(_0x2d2be8))throw new Error(it(_0x5f258b,'priority')+'must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');},ys=function(_0x43e697,_0x4fa666,_0x37e32d,_0x5d9011){if(!sa(_0x37e32d))throw new Error(it(_0x43e697,_0x4fa666)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x37e32d+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x4e222b,_0x36df0a,_0x49d54d,_0x348d4f){_0x49d54d&&(_0x49d54d=_0x49d54d['replace'](/^\/*\.info(\/|$)/,'/')),ys(_0x4e222b,_0x36df0a,_0x49d54d);},Me=function(_0xf36a61,_0x49abea){if(y(_0x49abea)==='.info')throw new Error(_0xf36a61+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x2aea4d,_0x338ce3){const _0x4b0044=_0x338ce3['path']['toString']();if(typeof _0x338ce3['repoInfo']['host']!='string'||_0x338ce3['repoInfo']['host']['length']===0x0||!ms(_0x338ce3['repoInfo']['namespace'])&&_0x338ce3['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x4b0044['length']!==0x0&&!ud(_0x4b0044))throw new Error(it(_0x2aea4d,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function qn(_0x17535b,_0x151967){let _0x23ab1=null;for(let _0x498b7b=0x0;_0x498b7b<_0x151967['length'];_0x498b7b++){const _0x9bd8ba=_0x151967[_0x498b7b],_0x497ec7=_0x9bd8ba['getPath']();_0x23ab1!==null&&!Ki(_0x497ec7,_0x23ab1['path'])&&(_0x17535b['eventLists_']['push'](_0x23ab1),_0x23ab1=null),_0x23ab1===null&&(_0x23ab1={'events':[],'path':_0x497ec7}),_0x23ab1['events']['push'](_0x9bd8ba);}_0x23ab1&&_0x17535b['eventLists_']['push'](_0x23ab1);}function oa(_0x4ff6f5,_0x17ea15,_0xdaddb5){qn(_0x4ff6f5,_0xdaddb5),aa(_0x4ff6f5,_0x453ead=>Ki(_0x453ead,_0x17ea15));}function V(_0x245552,_0x46f1f8,_0x4ef66a){qn(_0x245552,_0x4ef66a),aa(_0x245552,_0x58cc4d=>G(_0x58cc4d,_0x46f1f8)||G(_0x46f1f8,_0x58cc4d));}function aa(_0x2dde96,_0x49289f){_0x2dde96['recursionDepth_']++;let _0x4b2d1a=!0x0;for(let _0x226d2c=0x0;_0x226d2c<_0x2dde96['eventLists_']['length'];_0x226d2c++){const _0x420b6d=_0x2dde96['eventLists_'][_0x226d2c];if(_0x420b6d){const _0x42220e=_0x420b6d['path'];_0x49289f(_0x42220e)?(md(_0x2dde96['eventLists_'][_0x226d2c]),_0x2dde96['eventLists_'][_0x226d2c]=null):_0x4b2d1a=!0x1;}}_0x4b2d1a&&(_0x2dde96['eventLists_']=[]),_0x2dde96['recursionDepth_']--;}function md(_0x213a64){for(let _0x1be64a=0x0;_0x1be64a<_0x213a64['events']['length'];_0x1be64a++){const _0x1a2d14=_0x213a64['events'][_0x1be64a];if(_0x1a2d14!==null){_0x213a64['events'][_0x1be64a]=null;const _0x302158=_0x1a2d14['getEventRunner']();St&&L('event:\x20'+_0x1a2d14['toString']()),ft(_0x302158);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x84441b,_0x13f1d7,_0x3f35d4,_0x13805f){this['repoInfo_']=_0x84441b,this['forceRestClient_']=_0x13f1d7,this['authTokenProvider_']=_0x3f35d4,this['appCheckProvider_']=_0x13805f,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=En(),this['transactionQueueTree_']=new _s(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x13e8a2,_0x5a6de6,_0x5c534b){if(_0x13e8a2['stats_']=qi(_0x13e8a2['repoInfo_']),_0x13e8a2['forceRestClient_']||Xl())_0x13e8a2['server_']=new vn(_0x13e8a2['repoInfo_'],(_0x4ae79b,_0x242283,_0x27f8bb,_0x3c6022)=>{gr(_0x13e8a2,_0x4ae79b,_0x242283,_0x27f8bb,_0x3c6022);},_0x13e8a2['authTokenProvider_'],_0x13e8a2['appCheckProvider_']),setTimeout(()=>mr(_0x13e8a2,!0x0),0x0);else{if(typeof _0x5c534b<'u'&&_0x5c534b!==null){if(typeof _0x5c534b!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x5c534b);}catch(_0x187fe6){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x187fe6);}}_0x13e8a2['persistentConnection_']=new se(_0x13e8a2['repoInfo_'],_0x5a6de6,(_0xd77fe8,_0x311bb9,_0xdd839c,_0x5a6aa6)=>{gr(_0x13e8a2,_0xd77fe8,_0x311bb9,_0xdd839c,_0x5a6aa6);},_0x3ef3cb=>{mr(_0x13e8a2,_0x3ef3cb);},_0x5e033f=>{Id(_0x13e8a2,_0x5e033f);},_0x13e8a2['authTokenProvider_'],_0x13e8a2['appCheckProvider_'],_0x5c534b),_0x13e8a2['server_']=_0x13e8a2['persistentConnection_'];}_0x13e8a2['authTokenProvider_']['addTokenChangeListener'](_0x271738=>{_0x13e8a2['server_']['refreshAuthToken'](_0x271738);}),_0x13e8a2['appCheckProvider_']['addTokenChangeListener'](_0x593098=>{_0x13e8a2['server_']['refreshAppCheckToken'](_0x593098['token']);}),_0x13e8a2['statsReporter_']=ih(_0x13e8a2['repoInfo_'],()=>new iu(_0x13e8a2['stats_'],_0x13e8a2['server_'])),_0x13e8a2['infoData_']=new Xh(),_0x13e8a2['infoSyncTree_']=new pr({'startListening':(_0x41f012,_0x17fbe5,_0x2074e9,_0x111403)=>{let _0x208331=[];const _0x99864a=_0x13e8a2['infoData_']['getNode'](_0x41f012['_path']);return _0x99864a['isEmpty']()||(_0x208331=Yt(_0x13e8a2['infoSyncTree_'],_0x41f012['_path'],_0x99864a),setTimeout(()=>{_0x111403('ok');},0x0)),_0x208331;},'stopListening':()=>{}}),vs(_0x13e8a2,'connected',!0x1),_0x13e8a2['serverSyncTree_']=new pr({'startListening':(_0xf77849,_0x29249d,_0x2dc008,_0x561321)=>(_0x13e8a2['server_']['listen'](_0xf77849,_0x2dc008,_0x29249d,(_0xe346a8,_0x924e35)=>{const _0x2bd56d=_0x561321(_0xe346a8,_0x924e35);V(_0x13e8a2['eventQueue_'],_0xf77849['_path'],_0x2bd56d);}),[]),'stopListening':(_0x588666,_0x3b7d07)=>{_0x13e8a2['server_']['unlisten'](_0x588666,_0x3b7d07);}});}function la(_0x42fcef){const _0x17a13f=_0x42fcef['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x17a13f;}function Xt(_0x595e52){return id({'timestamp':la(_0x595e52)});}function gr(_0x452f43,_0xe8622,_0x3ad04f,_0x319a4d,_0x337acd){_0x452f43['dataUpdateCount']++;const _0x5b4dfe=new C(_0xe8622);_0x3ad04f=_0x452f43['interceptServerDataCallback_']?_0x452f43['interceptServerDataCallback_'](_0xe8622,_0x3ad04f):_0x3ad04f;let _0x525052=[];if(_0x337acd){if(_0x319a4d){const _0x3f5b6f=_n(_0x3ad04f,_0x52a752=>A(_0x52a752));_0x525052=Ju(_0x452f43['serverSyncTree_'],_0x5b4dfe,_0x3f5b6f,_0x337acd);}else{const _0x4c5fac=A(_0x3ad04f);_0x525052=Jo(_0x452f43['serverSyncTree_'],_0x5b4dfe,_0x4c5fac,_0x337acd);}}else{if(_0x319a4d){const _0x386767=_n(_0x3ad04f,_0x3a22bc=>A(_0x3a22bc));_0x525052=Ku(_0x452f43['serverSyncTree_'],_0x5b4dfe,_0x386767);}else{const _0x2543ab=A(_0x3ad04f);_0x525052=Yt(_0x452f43['serverSyncTree_'],_0x5b4dfe,_0x2543ab);}}let _0xcf09ac=_0x5b4dfe;_0x525052['length']>0x0&&(_0xcf09ac=ct(_0x452f43,_0x5b4dfe)),V(_0x452f43['eventQueue_'],_0xcf09ac,_0x525052);}function mr(_0x793460,_0x1ca6eb){vs(_0x793460,'connected',_0x1ca6eb),_0x1ca6eb===!0x1&&Sd(_0x793460);}function Id(_0x2f41e7,_0x5db809){x(_0x5db809,(_0x57a4b6,_0x38cf20)=>{vs(_0x2f41e7,_0x57a4b6,_0x38cf20);});}function vs(_0x105e9e,_0x3b696c,_0x3dcc29){const _0x30aaf2=new C('/.info/'+_0x3b696c),_0x3d3cda=A(_0x3dcc29);_0x105e9e['infoData_']['updateSnapshot'](_0x30aaf2,_0x3d3cda);const _0x5b0dad=Yt(_0x105e9e['infoSyncTree_'],_0x30aaf2,_0x3d3cda);V(_0x105e9e['eventQueue_'],_0x30aaf2,_0x5b0dad);}function zn(_0x2f054b){return _0x2f054b['nextWriteId_']++;}function wd(_0x28e513,_0x1b0d21,_0x418def){const _0x597763=Xu(_0x28e513['serverSyncTree_'],_0x1b0d21);return _0x597763!=null?Promise['resolve'](_0x597763):_0x28e513['server_']['get'](_0x1b0d21)['then'](_0x44a52e=>{const _0x3814a0=A(_0x44a52e)['withIndex'](_0x1b0d21['_queryParams']['getIndex']());Ni(_0x28e513['serverSyncTree_'],_0x1b0d21,_0x418def,!0x0);let _0x2150e5;if(_0x1b0d21['_queryParams']['loadsAllData']())_0x2150e5=Yt(_0x28e513['serverSyncTree_'],_0x1b0d21['_path'],_0x3814a0);else{const _0x2eed91=Wt(_0x28e513['serverSyncTree_'],_0x1b0d21);_0x2150e5=Jo(_0x28e513['serverSyncTree_'],_0x1b0d21['_path'],_0x3814a0,_0x2eed91);}return V(_0x28e513['eventQueue_'],_0x1b0d21['_path'],_0x2150e5),An(_0x28e513['serverSyncTree_'],_0x1b0d21,_0x418def,null,!0x0),_0x3814a0;},_0x3e3bd3=>(gt(_0x28e513,'get\x20for\x20query\x20'+O(_0x1b0d21)+'\x20failed:\x20'+_0x3e3bd3),Promise['reject'](new Error(_0x3e3bd3))));}function Cd(_0x5a8d39,_0x3abb2a,_0x53553e,_0x255cad,_0x217690){gt(_0x5a8d39,'set',{'path':_0x3abb2a['toString'](),'value':_0x53553e,'priority':_0x255cad});const _0x1279c1=Xt(_0x5a8d39),_0x46985f=A(_0x53553e,_0x255cad),_0x4cd4ad=Vn(_0x5a8d39['serverSyncTree_'],_0x3abb2a),_0x1b587a=fs(_0x46985f,_0x4cd4ad,_0x1279c1),_0x26d396=zn(_0x5a8d39),_0x24d17a=as(_0x5a8d39['serverSyncTree_'],_0x3abb2a,_0x1b587a,_0x26d396,!0x0);qn(_0x5a8d39['eventQueue_'],_0x24d17a),_0x5a8d39['server_']['put'](_0x3abb2a['toString'](),_0x46985f['val'](!0x0),(_0xd94692,_0x398d3b)=>{const _0x2e58f9=_0xd94692==='ok';_0x2e58f9||U('set\x20at\x20'+_0x3abb2a+'\x20failed:\x20'+_0xd94692);const _0x3cddd0=_e(_0x5a8d39['serverSyncTree_'],_0x26d396,!_0x2e58f9);V(_0x5a8d39['eventQueue_'],_0x3abb2a,_0x3cddd0),be(_0x5a8d39,_0x217690,_0xd94692,_0x398d3b);});const _0x233925=Is(_0x5a8d39,_0x3abb2a);ct(_0x5a8d39,_0x233925),V(_0x5a8d39['eventQueue_'],_0x233925,[]);}function Td(_0x19c06a,_0x55f130,_0x1e5025,_0x578dc3){gt(_0x19c06a,'update',{'path':_0x55f130['toString'](),'value':_0x1e5025});let _0x82d66a=!0x0;const _0x56d5b0=Xt(_0x19c06a),_0x2db3e2={};if(x(_0x1e5025,(_0x33aac6,_0x183827)=>{_0x82d66a=!0x1,_0x2db3e2[_0x33aac6]=ta(k(_0x55f130,_0x33aac6),A(_0x183827),_0x19c06a['serverSyncTree_'],_0x56d5b0);}),_0x82d66a)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x19c06a,_0x578dc3,'ok',void 0x0);else{const _0x4afadb=zn(_0x19c06a),_0x69e4d=ju(_0x19c06a['serverSyncTree_'],_0x55f130,_0x2db3e2,_0x4afadb);qn(_0x19c06a['eventQueue_'],_0x69e4d),_0x19c06a['server_']['merge'](_0x55f130['toString'](),_0x1e5025,(_0x538bcd,_0x1821c9)=>{const _0x121ae7=_0x538bcd==='ok';_0x121ae7||U('update\x20at\x20'+_0x55f130+'\x20failed:\x20'+_0x538bcd);const _0x13e6e3=_e(_0x19c06a['serverSyncTree_'],_0x4afadb,!_0x121ae7),_0xd36711=_0x13e6e3['length']>0x0?ct(_0x19c06a,_0x55f130):_0x55f130;V(_0x19c06a['eventQueue_'],_0xd36711,_0x13e6e3),be(_0x19c06a,_0x578dc3,_0x538bcd,_0x1821c9);}),x(_0x1e5025,_0x54fdfa=>{const _0x324618=Is(_0x19c06a,k(_0x55f130,_0x54fdfa));ct(_0x19c06a,_0x324618);}),V(_0x19c06a['eventQueue_'],_0x55f130,[]);}}function Sd(_0x46ba2b){gt(_0x46ba2b,'onDisconnectEvents');const _0x3d26f0=Xt(_0x46ba2b),_0x3de883=En();Si(_0x46ba2b['onDisconnect_'],w(),(_0x15b7d2,_0x58c4cb)=>{const _0x23e973=ta(_0x15b7d2,_0x58c4cb,_0x46ba2b['serverSyncTree_'],_0x3d26f0);pt(_0x3de883,_0x15b7d2,_0x23e973);});let _0x226561=[];Si(_0x3de883,w(),(_0x59aa97,_0xf4fd1d)=>{_0x226561=_0x226561['concat'](Yt(_0x46ba2b['serverSyncTree_'],_0x59aa97,_0xf4fd1d));const _0x24374a=Is(_0x46ba2b,_0x59aa97);ct(_0x46ba2b,_0x24374a);}),_0x46ba2b['onDisconnect_']=En(),V(_0x46ba2b['eventQueue_'],w(),_0x226561);}function bd(_0x5e267b,_0x10e5b3,_0x2d2a04){_0x5e267b['server_']['onDisconnectCancel'](_0x10e5b3['toString'](),(_0x205eea,_0x5bcac1)=>{_0x205eea==='ok'&&Ti(_0x5e267b['onDisconnect_'],_0x10e5b3),be(_0x5e267b,_0x2d2a04,_0x205eea,_0x5bcac1);});}function yr(_0x15f83d,_0x536581,_0x2c70d7,_0x4a8d42){const _0x1dc890=A(_0x2c70d7);_0x15f83d['server_']['onDisconnectPut'](_0x536581['toString'](),_0x1dc890['val'](!0x0),(_0x20f2a4,_0x4b3971)=>{_0x20f2a4==='ok'&&pt(_0x15f83d['onDisconnect_'],_0x536581,_0x1dc890),be(_0x15f83d,_0x4a8d42,_0x20f2a4,_0x4b3971);});}function Rd(_0x1d7cc1,_0x538dd1,_0x2c3a47,_0x538e94,_0xcc25d5){const _0x3fd6f5=A(_0x2c3a47,_0x538e94);_0x1d7cc1['server_']['onDisconnectPut'](_0x538dd1['toString'](),_0x3fd6f5['val'](!0x0),(_0x4f51a3,_0x51bf65)=>{_0x4f51a3==='ok'&&pt(_0x1d7cc1['onDisconnect_'],_0x538dd1,_0x3fd6f5),be(_0x1d7cc1,_0xcc25d5,_0x4f51a3,_0x51bf65);});}function Ad(_0x416a0f,_0x251d6d,_0x5e8d8f,_0x18292f){if(pn(_0x5e8d8f)){L('onDisconnect().update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),be(_0x416a0f,_0x18292f,'ok',void 0x0);return;}_0x416a0f['server_']['onDisconnectMerge'](_0x251d6d['toString'](),_0x5e8d8f,(_0x5d3d7f,_0x2997c1)=>{_0x5d3d7f==='ok'&&x(_0x5e8d8f,(_0x5ed70d,_0x4c7f15)=>{const _0x469a2a=A(_0x4c7f15);pt(_0x416a0f['onDisconnect_'],k(_0x251d6d,_0x5ed70d),_0x469a2a);}),be(_0x416a0f,_0x18292f,_0x5d3d7f,_0x2997c1);});}function kd(_0x46e1c4,_0x326fbd,_0x25fb5c){let _0xa8362a;y(_0x326fbd['_path'])==='.info'?_0xa8362a=Ni(_0x46e1c4['infoSyncTree_'],_0x326fbd,_0x25fb5c):_0xa8362a=Ni(_0x46e1c4['serverSyncTree_'],_0x326fbd,_0x25fb5c),oa(_0x46e1c4['eventQueue_'],_0x326fbd['_path'],_0xa8362a);}function Pd(_0x34b89d,_0x263260,_0x372d20){let _0x5e4e00;y(_0x263260['_path'])==='.info'?_0x5e4e00=An(_0x34b89d['infoSyncTree_'],_0x263260,_0x372d20):_0x5e4e00=An(_0x34b89d['serverSyncTree_'],_0x263260,_0x372d20),oa(_0x34b89d['eventQueue_'],_0x263260['_path'],_0x5e4e00);}function ha(_0x433d38){_0x433d38['persistentConnection_']&&_0x433d38['persistentConnection_']['interrupt'](ca);}function Nd(_0x5d04c3){_0x5d04c3['persistentConnection_']&&_0x5d04c3['persistentConnection_']['resume'](ca);}function gt(_0x5c189d,..._0x126451){let _0x24230b='';_0x5c189d['persistentConnection_']&&(_0x24230b=_0x5c189d['persistentConnection_']['id']+':'),L(_0x24230b,..._0x126451);}function be(_0x8ac6ed,_0xda7b44,_0x193776,_0x259e10){_0xda7b44&&ft(()=>{if(_0x193776==='ok')_0xda7b44(null);else{const _0x582bf9=(_0x193776||'error')['toUpperCase']();let _0x231413=_0x582bf9;_0x259e10&&(_0x231413+=':\x20'+_0x259e10);const _0x4e0443=new Error(_0x231413);_0x4e0443['code']=_0x582bf9,_0xda7b44(_0x4e0443);}});}function Od(_0x3a06a5,_0x4dfec2,_0x3c99d7,_0xa882ed,_0x512385,_0x298a27){gt(_0x3a06a5,'transaction\x20on\x20'+_0x4dfec2);const _0x3cce0d={'path':_0x4dfec2,'update':_0x3c99d7,'onComplete':_0xa882ed,'status':null,'order':so(),'applyLocally':_0x298a27,'retryCount':0x0,'unwatcher':_0x512385,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x8d5d53=Es(_0x3a06a5,_0x4dfec2,void 0x0);_0x3cce0d['currentInputSnapshot']=_0x8d5d53;const _0x29eac4=_0x3cce0d['update'](_0x8d5d53['val']());if(_0x29eac4===void 0x0)_0x3cce0d['unwatcher'](),_0x3cce0d['currentOutputSnapshotRaw']=null,_0x3cce0d['currentOutputSnapshotResolved']=null,_0x3cce0d['onComplete']&&_0x3cce0d['onComplete'](null,!0x1,_0x3cce0d['currentInputSnapshot']);else{Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x29eac4,_0x3cce0d['path']),_0x3cce0d['status']=0x0;const _0x2f5261=$n(_0x3a06a5['transactionQueueTree_'],_0x4dfec2),_0x3361ce=je(_0x2f5261)||[];_0x3361ce['push'](_0x3cce0d),gs(_0x2f5261,_0x3361ce);let _0x5eba77;typeof _0x29eac4=='object'&&_0x29eac4!==null&&Q(_0x29eac4,'.priority')?(_0x5eba77=Le(_0x29eac4,'.priority'),f(Bt(_0x5eba77),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x5eba77=(Vn(_0x3a06a5['serverSyncTree_'],_0x4dfec2)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x41442b=Xt(_0x3a06a5),_0x48f8a9=A(_0x29eac4,_0x5eba77),_0x56fe1f=fs(_0x48f8a9,_0x8d5d53,_0x41442b);_0x3cce0d['currentOutputSnapshotRaw']=_0x48f8a9,_0x3cce0d['currentOutputSnapshotResolved']=_0x56fe1f,_0x3cce0d['currentWriteId']=zn(_0x3a06a5);const _0x2fed03=as(_0x3a06a5['serverSyncTree_'],_0x4dfec2,_0x56fe1f,_0x3cce0d['currentWriteId'],_0x3cce0d['applyLocally']);V(_0x3a06a5['eventQueue_'],_0x4dfec2,_0x2fed03),jn(_0x3a06a5,_0x3a06a5['transactionQueueTree_']);}}function Es(_0x17e5c8,_0x50a560,_0x28909c){return Vn(_0x17e5c8['serverSyncTree_'],_0x50a560,_0x28909c)||g['EMPTY_NODE'];}function jn(_0x592202,_0x3ee8b8=_0x592202['transactionQueueTree_']){if(_0x3ee8b8||Kn(_0x592202,_0x3ee8b8),je(_0x3ee8b8)){const _0x12c572=da(_0x592202,_0x3ee8b8);f(_0x12c572['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x12c572['every'](_0x5e6f2d=>_0x5e6f2d['status']===0x0)&&Dd(_0x592202,Qt(_0x3ee8b8),_0x12c572);}else na(_0x3ee8b8)&&Gn(_0x3ee8b8,_0x2e8643=>{jn(_0x592202,_0x2e8643);});}function Dd(_0xb1143a,_0x1c96ce,_0x22364c){const _0x445b0d=_0x22364c['map'](_0x4e8264=>_0x4e8264['currentWriteId']),_0xd91b7d=Es(_0xb1143a,_0x1c96ce,_0x445b0d);let _0x137264=_0xd91b7d;const _0xec78cf=_0xd91b7d['hash']();for(let _0x21150f=0x0;_0x21150f<_0x22364c['length'];_0x21150f++){const _0x269cf3=_0x22364c[_0x21150f];f(_0x269cf3['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x269cf3['status']=0x1,_0x269cf3['retryCount']++;const _0x268077=F(_0x1c96ce,_0x269cf3['path']);_0x137264=_0x137264['updateChild'](_0x268077,_0x269cf3['currentOutputSnapshotRaw']);}const _0x2ac91c=_0x137264['val'](!0x0),_0xa1da83=_0x1c96ce;_0xb1143a['server_']['put'](_0xa1da83['toString'](),_0x2ac91c,_0x4a7730=>{gt(_0xb1143a,'transaction\x20put\x20response',{'path':_0xa1da83['toString'](),'status':_0x4a7730});let _0x15b519=[];if(_0x4a7730==='ok'){const _0xc6d044=[];for(let _0x26db54=0x0;_0x26db54<_0x22364c['length'];_0x26db54++)_0x22364c[_0x26db54]['status']=0x2,_0x15b519=_0x15b519['concat'](_e(_0xb1143a['serverSyncTree_'],_0x22364c[_0x26db54]['currentWriteId'])),_0x22364c[_0x26db54]['onComplete']&&_0xc6d044['push'](()=>_0x22364c[_0x26db54]['onComplete'](null,!0x0,_0x22364c[_0x26db54]['currentOutputSnapshotResolved'])),_0x22364c[_0x26db54]['unwatcher']();Kn(_0xb1143a,$n(_0xb1143a['transactionQueueTree_'],_0x1c96ce)),jn(_0xb1143a,_0xb1143a['transactionQueueTree_']),V(_0xb1143a['eventQueue_'],_0x1c96ce,_0x15b519);for(let _0x2268e2=0x0;_0x2268e2<_0xc6d044['length'];_0x2268e2++)ft(_0xc6d044[_0x2268e2]);}else{if(_0x4a7730==='datastale'){for(let _0x20d657=0x0;_0x20d657<_0x22364c['length'];_0x20d657++)_0x22364c[_0x20d657]['status']===0x3?_0x22364c[_0x20d657]['status']=0x4:_0x22364c[_0x20d657]['status']=0x0;}else{U('transaction\x20at\x20'+_0xa1da83['toString']()+'\x20failed:\x20'+_0x4a7730);for(let _0x5e9bcc=0x0;_0x5e9bcc<_0x22364c['length'];_0x5e9bcc++)_0x22364c[_0x5e9bcc]['status']=0x4,_0x22364c[_0x5e9bcc]['abortReason']=_0x4a7730;}ct(_0xb1143a,_0x1c96ce);}},_0xec78cf);}function ct(_0x5ad5ad,_0x2470c4){const _0x409474=ua(_0x5ad5ad,_0x2470c4),_0x37174b=Qt(_0x409474),_0x16c91d=da(_0x5ad5ad,_0x409474);return Md(_0x5ad5ad,_0x16c91d,_0x37174b),_0x37174b;}function Md(_0x3c0840,_0x428cc6,_0x47ca5b){if(_0x428cc6['length']===0x0)return;const _0xa41a8a=[];let _0x353deb=[];const _0xab14a5=_0x428cc6['filter'](_0x3937a3=>_0x3937a3['status']===0x0)['map'](_0x397c66=>_0x397c66['currentWriteId']);for(let _0x515e45=0x0;_0x515e45<_0x428cc6['length'];_0x515e45++){const _0x2c2566=_0x428cc6[_0x515e45],_0x9be2cb=F(_0x47ca5b,_0x2c2566['path']);let _0x197d9e=!0x1,_0x1f65e9;if(f(_0x9be2cb!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x2c2566['status']===0x4)_0x197d9e=!0x0,_0x1f65e9=_0x2c2566['abortReason'],_0x353deb=_0x353deb['concat'](_e(_0x3c0840['serverSyncTree_'],_0x2c2566['currentWriteId'],!0x0));else{if(_0x2c2566['status']===0x0){if(_0x2c2566['retryCount']>=yd)_0x197d9e=!0x0,_0x1f65e9='maxretry',_0x353deb=_0x353deb['concat'](_e(_0x3c0840['serverSyncTree_'],_0x2c2566['currentWriteId'],!0x0));else{const _0x1eed83=Es(_0x3c0840,_0x2c2566['path'],_0xab14a5);_0x2c2566['currentInputSnapshot']=_0x1eed83;const _0x1cbaa2=_0x428cc6[_0x515e45]['update'](_0x1eed83['val']());if(_0x1cbaa2!==void 0x0){Jt('transaction\x20failed:\x20Data\x20returned\x20',_0x1cbaa2,_0x2c2566['path']);let _0x4d677d=A(_0x1cbaa2);typeof _0x1cbaa2=='object'&&_0x1cbaa2!=null&&Q(_0x1cbaa2,'.priority')||(_0x4d677d=_0x4d677d['updatePriority'](_0x1eed83['getPriority']()));const _0x17c056=_0x2c2566['currentWriteId'],_0x13ba07=Xt(_0x3c0840),_0x5bf5bb=fs(_0x4d677d,_0x1eed83,_0x13ba07);_0x2c2566['currentOutputSnapshotRaw']=_0x4d677d,_0x2c2566['currentOutputSnapshotResolved']=_0x5bf5bb,_0x2c2566['currentWriteId']=zn(_0x3c0840),_0xab14a5['splice'](_0xab14a5['indexOf'](_0x17c056),0x1),_0x353deb=_0x353deb['concat'](as(_0x3c0840['serverSyncTree_'],_0x2c2566['path'],_0x5bf5bb,_0x2c2566['currentWriteId'],_0x2c2566['applyLocally'])),_0x353deb=_0x353deb['concat'](_e(_0x3c0840['serverSyncTree_'],_0x17c056,!0x0));}else _0x197d9e=!0x0,_0x1f65e9='nodata',_0x353deb=_0x353deb['concat'](_e(_0x3c0840['serverSyncTree_'],_0x2c2566['currentWriteId'],!0x0));}}}V(_0x3c0840['eventQueue_'],_0x47ca5b,_0x353deb),_0x353deb=[],_0x197d9e&&(_0x428cc6[_0x515e45]['status']=0x2,function(_0x2d398b){setTimeout(_0x2d398b,Math['floor'](0x0));}(_0x428cc6[_0x515e45]['unwatcher']),_0x428cc6[_0x515e45]['onComplete']&&(_0x1f65e9==='nodata'?_0xa41a8a['push'](()=>_0x428cc6[_0x515e45]['onComplete'](null,!0x1,_0x428cc6[_0x515e45]['currentInputSnapshot'])):_0xa41a8a['push'](()=>_0x428cc6[_0x515e45]['onComplete'](new Error(_0x1f65e9),!0x1,null))));}Kn(_0x3c0840,_0x3c0840['transactionQueueTree_']);for(let _0x44fae9=0x0;_0x44fae9<_0xa41a8a['length'];_0x44fae9++)ft(_0xa41a8a[_0x44fae9]);jn(_0x3c0840,_0x3c0840['transactionQueueTree_']);}function ua(_0x4687c9,_0x5bf0f0){let _0x32e2cf,_0x5f55d5=_0x4687c9['transactionQueueTree_'];for(_0x32e2cf=y(_0x5bf0f0);_0x32e2cf!==null&&je(_0x5f55d5)===void 0x0;)_0x5f55d5=$n(_0x5f55d5,_0x32e2cf),_0x5bf0f0=S(_0x5bf0f0),_0x32e2cf=y(_0x5bf0f0);return _0x5f55d5;}function da(_0x3bd733,_0x147037){const _0x3434ff=[];return fa(_0x3bd733,_0x147037,_0x3434ff),_0x3434ff['sort']((_0x37d07b,_0x408be8)=>_0x37d07b['order']-_0x408be8['order']),_0x3434ff;}function fa(_0x6fcc66,_0x18a81e,_0x231ab3){const _0x1d63a2=je(_0x18a81e);if(_0x1d63a2){for(let _0x3d0c2b=0x0;_0x3d0c2b<_0x1d63a2['length'];_0x3d0c2b++)_0x231ab3['push'](_0x1d63a2[_0x3d0c2b]);}Gn(_0x18a81e,_0x5572e2=>{fa(_0x6fcc66,_0x5572e2,_0x231ab3);});}function Kn(_0x2d8bd7,_0x497c2d){const _0x2ce463=je(_0x497c2d);if(_0x2ce463){let _0x4f815c=0x0;for(let _0x45ec0a=0x0;_0x45ec0a<_0x2ce463['length'];_0x45ec0a++)_0x2ce463[_0x45ec0a]['status']!==0x2&&(_0x2ce463[_0x4f815c]=_0x2ce463[_0x45ec0a],_0x4f815c++);_0x2ce463['length']=_0x4f815c,gs(_0x497c2d,_0x2ce463['length']>0x0?_0x2ce463:void 0x0);}Gn(_0x497c2d,_0x4739c7=>{Kn(_0x2d8bd7,_0x4739c7);});}function Is(_0x3ead0f,_0x4dc268){const _0x1170ee=Qt(ua(_0x3ead0f,_0x4dc268)),_0x258f1f=$n(_0x3ead0f['transactionQueueTree_'],_0x4dc268);return ad(_0x258f1f,_0x25db29=>{di(_0x3ead0f,_0x25db29);}),di(_0x3ead0f,_0x258f1f),ia(_0x258f1f,_0x5047d6=>{di(_0x3ead0f,_0x5047d6);}),_0x1170ee;}function di(_0x420073,_0x1eb8ad){const _0x35a8be=je(_0x1eb8ad);if(_0x35a8be){const _0xd67da2=[];let _0x3c329f=[],_0x40c8ea=-0x1;for(let _0x4b4380=0x0;_0x4b4380<_0x35a8be['length'];_0x4b4380++)_0x35a8be[_0x4b4380]['status']===0x3||(_0x35a8be[_0x4b4380]['status']===0x1?(f(_0x40c8ea===_0x4b4380-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x40c8ea=_0x4b4380,_0x35a8be[_0x4b4380]['status']=0x3,_0x35a8be[_0x4b4380]['abortReason']='set'):(f(_0x35a8be[_0x4b4380]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x35a8be[_0x4b4380]['unwatcher'](),_0x3c329f=_0x3c329f['concat'](_e(_0x420073['serverSyncTree_'],_0x35a8be[_0x4b4380]['currentWriteId'],!0x0)),_0x35a8be[_0x4b4380]['onComplete']&&_0xd67da2['push'](_0x35a8be[_0x4b4380]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x40c8ea===-0x1?gs(_0x1eb8ad,void 0x0):_0x35a8be['length']=_0x40c8ea+0x1,V(_0x420073['eventQueue_'],Qt(_0x1eb8ad),_0x3c329f);for(let _0x4f70bf=0x0;_0x4f70bf<_0xd67da2['length'];_0x4f70bf++)ft(_0xd67da2[_0x4f70bf]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ld(_0x3d8dd6){let _0x124fbf='';const _0x56b480=_0x3d8dd6['split']('/');for(let _0x52ae5d=0x0;_0x52ae5d<_0x56b480['length'];_0x52ae5d++)if(_0x56b480[_0x52ae5d]['length']>0x0){let _0x192c67=_0x56b480[_0x52ae5d];try{_0x192c67=decodeURIComponent(_0x192c67['replace'](/\+/g,'\x20'));}catch{}_0x124fbf+='/'+_0x192c67;}return _0x124fbf;}function xd(_0x2e1c28){const _0x10cedc={};_0x2e1c28['charAt'](0x0)==='?'&&(_0x2e1c28=_0x2e1c28['substring'](0x1));for(const _0x4ac110 of _0x2e1c28['split']('&')){if(_0x4ac110['length']===0x0)continue;const _0x174772=_0x4ac110['split']('=');_0x174772['length']===0x2?_0x10cedc[decodeURIComponent(_0x174772[0x0])]=decodeURIComponent(_0x174772[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x4ac110+'\x27\x20in\x20query\x20\x27'+_0x2e1c28+'\x27');}return _0x10cedc;}const vr=function(_0x4ea73e,_0x38d5ee){const _0xf6b581=Fd(_0x4ea73e),_0x13bab7=_0xf6b581['namespace'];_0xf6b581['domain']==='firebase.com'&&ae(_0xf6b581['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x13bab7||_0x13bab7==='undefined')&&_0xf6b581['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0xf6b581['secure']||$l();const _0x39f216=_0xf6b581['scheme']==='ws'||_0xf6b581['scheme']==='wss';return{'repoInfo':new yo(_0xf6b581['host'],_0xf6b581['secure'],_0x13bab7,_0x39f216,_0x38d5ee,'',_0x13bab7!==_0xf6b581['subdomain']),'path':new C(_0xf6b581['pathString'])};},Fd=function(_0x296ecf){let _0x14a95b='',_0x5b138b='',_0x4aa660='',_0x2089d7='',_0x1a63f3='',_0x4ead03=!0x0,_0x3e7a4f='https',_0x1573ea=0x1bb;if(typeof _0x296ecf=='string'){let _0x5c3bc8=_0x296ecf['indexOf']('//');_0x5c3bc8>=0x0&&(_0x3e7a4f=_0x296ecf['substring'](0x0,_0x5c3bc8-0x1),_0x296ecf=_0x296ecf['substring'](_0x5c3bc8+0x2));let _0x17d986=_0x296ecf['indexOf']('/');_0x17d986===-0x1&&(_0x17d986=_0x296ecf['length']);let _0x3d4de3=_0x296ecf['indexOf']('?');_0x3d4de3===-0x1&&(_0x3d4de3=_0x296ecf['length']),_0x14a95b=_0x296ecf['substring'](0x0,Math['min'](_0x17d986,_0x3d4de3)),_0x17d986<_0x3d4de3&&(_0x2089d7=Ld(_0x296ecf['substring'](_0x17d986,_0x3d4de3)));const _0x6e87d6=xd(_0x296ecf['substring'](Math['min'](_0x296ecf['length'],_0x3d4de3)));_0x5c3bc8=_0x14a95b['indexOf'](':'),_0x5c3bc8>=0x0?(_0x4ead03=_0x3e7a4f==='https'||_0x3e7a4f==='wss',_0x1573ea=parseInt(_0x14a95b['substring'](_0x5c3bc8+0x1),0xa)):_0x5c3bc8=_0x14a95b['length'];const _0x3d548c=_0x14a95b['slice'](0x0,_0x5c3bc8);if(_0x3d548c['toLowerCase']()==='localhost')_0x5b138b='localhost';else{if(_0x3d548c['split']('.')['length']<=0x2)_0x5b138b=_0x3d548c;else{const _0x656b91=_0x14a95b['indexOf']('.');_0x4aa660=_0x14a95b['substring'](0x0,_0x656b91)['toLowerCase'](),_0x5b138b=_0x14a95b['substring'](_0x656b91+0x1),_0x1a63f3=_0x4aa660;}}'ns'in _0x6e87d6&&(_0x1a63f3=_0x6e87d6['ns']);}return{'host':_0x14a95b,'port':_0x1573ea,'domain':_0x5b138b,'subdomain':_0x4aa660,'secure':_0x4ead03,'scheme':_0x3e7a4f,'pathString':_0x2089d7,'namespace':_0x1a63f3};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ud=(function(){let _0x8064b5=0x0;const _0x1b5962=[];return function(_0x2a3216){const _0x3dcc3e=_0x2a3216===_0x8064b5;_0x8064b5=_0x2a3216;let _0x3e3e2e;const _0x144920=new Array(0x8);for(_0x3e3e2e=0x7;_0x3e3e2e>=0x0;_0x3e3e2e--)_0x144920[_0x3e3e2e]=Er['charAt'](_0x2a3216%0x40),_0x2a3216=Math['floor'](_0x2a3216/0x40);f(_0x2a3216===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x18f6b9=_0x144920['join']('');if(_0x3dcc3e){for(_0x3e3e2e=0xb;_0x3e3e2e>=0x0&&_0x1b5962[_0x3e3e2e]===0x3f;_0x3e3e2e--)_0x1b5962[_0x3e3e2e]=0x0;_0x1b5962[_0x3e3e2e]++;}else{for(_0x3e3e2e=0x0;_0x3e3e2e<0xc;_0x3e3e2e++)_0x1b5962[_0x3e3e2e]=Math['floor'](Math['random']()*0x40);}for(_0x3e3e2e=0x0;_0x3e3e2e<0xc;_0x3e3e2e++)_0x18f6b9+=Er['charAt'](_0x1b5962[_0x3e3e2e]);return f(_0x18f6b9['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x18f6b9;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wd{constructor(_0x336a78,_0x4b2534,_0x1324c9,_0x35b15e){this['eventType']=_0x336a78,this['eventRegistration']=_0x4b2534,this['snapshot']=_0x1324c9,this['prevName']=_0x35b15e;}['getPath'](){const _0x1adaf3=this['snapshot']['ref'];return this['eventType']==='value'?_0x1adaf3['_path']:_0x1adaf3['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Bd{constructor(_0x539921,_0x369e9f,_0x55142a){this['eventRegistration']=_0x539921,this['error']=_0x369e9f,this['path']=_0x55142a;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x11f7fa,_0x5071f6){this['snapshotCallback']=_0x11f7fa,this['cancelCallback']=_0x5071f6;}['onValue'](_0x481dab,_0x3a71ad){this['snapshotCallback']['call'](null,_0x481dab,_0x3a71ad);}['onCancel'](_0x4a49e6){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x4a49e6);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x33b755){return this['snapshotCallback']===_0x33b755['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x33b755['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x33b755['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Vd{constructor(_0x486eb5,_0x425de9){this['_repo']=_0x486eb5,this['_path']=_0x425de9;}['cancel'](){const _0x3f4440=new H();return bd(this['_repo'],this['_path'],_0x3f4440['wrapCallback'](()=>{})),_0x3f4440['promise'];}['remove'](){Me('OnDisconnect.remove',this['_path']);const _0xb4e563=new H();return yr(this['_repo'],this['_path'],null,_0xb4e563['wrapCallback'](()=>{})),_0xb4e563['promise'];}['set'](_0x2486c9){Me('OnDisconnect.set',this['_path']),He('OnDisconnect.set',_0x2486c9,this['_path'],!0x1);const _0x3a8648=new H();return yr(this['_repo'],this['_path'],_0x2486c9,_0x3a8648['wrapCallback'](()=>{})),_0x3a8648['promise'];}['setWithPriority'](_0x243bba,_0x524bb3){Me('OnDisconnect.setWithPriority',this['_path']),He('OnDisconnect.setWithPriority',_0x243bba,this['_path'],!0x1),fd('OnDisconnect.setWithPriority',_0x524bb3);const _0x56bc83=new H();return Rd(this['_repo'],this['_path'],_0x243bba,_0x524bb3,_0x56bc83['wrapCallback'](()=>{})),_0x56bc83['promise'];}['update'](_0x413070){Me('OnDisconnect.update',this['_path']),ra('OnDisconnect.update',_0x413070,this['_path']);const _0x240aee=new H();return Ad(this['_repo'],this['_path'],_0x413070,_0x240aee['wrapCallback'](()=>{})),_0x240aee['promise'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ae{constructor(_0x152c3e,_0x16f837,_0x452282,_0xf9a0ce){this['_repo']=_0x152c3e,this['_path']=_0x16f837,this['_queryParams']=_0x452282,this['_orderByCalled']=_0xf9a0ce;}get['key'](){return v(this['_path'])?null:ji(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x42628b=sr(this['_queryParams']),_0x23355c=$i(_0x42628b);return _0x23355c==='{}'?'default':_0x23355c;}get['_queryObject'](){return sr(this['_queryParams']);}['isEqual'](_0xb7a15e){if(_0xb7a15e=P(_0xb7a15e),!(_0xb7a15e instanceof Ae))return!0x1;const _0x2bd8b5=this['_repo']===_0xb7a15e['_repo'],_0x3587b0=Ki(this['_path'],_0xb7a15e['_path']),_0x2333b4=this['_queryIdentifier']===_0xb7a15e['_queryIdentifier'];return _0x2bd8b5&&_0x3587b0&&_0x2333b4;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x42380a,_0x88ce99){if(_0x42380a['_orderByCalled']===!0x0)throw new Error(_0x88ce99+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function Yn(_0x4f90b7){let _0x26b644=null,_0x45d8d8=null;if(_0x4f90b7['hasStart']()&&(_0x26b644=_0x4f90b7['getIndexStartValue']()),_0x4f90b7['hasEnd']()&&(_0x45d8d8=_0x4f90b7['getIndexEndValue']()),_0x4f90b7['getIndex']()===ve){const _0x48caed='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x1a9089='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x4f90b7['hasStart']()){if(_0x4f90b7['getIndexStartName']()!==We)throw new Error(_0x48caed);if(typeof _0x26b644!='string')throw new Error(_0x1a9089);}if(_0x4f90b7['hasEnd']()){if(_0x4f90b7['getIndexEndName']()!==we)throw new Error(_0x48caed);if(typeof _0x45d8d8!='string')throw new Error(_0x1a9089);}}else{if(_0x4f90b7['getIndex']()===R){if(_0x26b644!=null&&!Bt(_0x26b644)||_0x45d8d8!=null&&!Bt(_0x45d8d8))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x4f90b7['getIndex']()instanceof Ji||_0x4f90b7['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x26b644!=null&&typeof _0x26b644=='object'||_0x45d8d8!=null&&typeof _0x45d8d8=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x3a78d0){if(_0x3a78d0['hasStart']()&&_0x3a78d0['hasEnd']()&&_0x3a78d0['hasLimit']()&&!_0x3a78d0['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends Ae{constructor(_0x3f99ef,_0x346fcb){super(_0x3f99ef,_0x346fcb,new Zi(),!0x1);}get['parent'](){const _0x40bebb=Ro(this['_path']);return _0x40bebb===null?null:new ee(this['_repo'],_0x40bebb);}get['root'](){let _0x27df73=this;for(;_0x27df73['parent']!==null;)_0x27df73=_0x27df73['parent'];return _0x27df73;}}class lt{constructor(_0x458d67,_0x392106,_0x4d1c50){this['_node']=_0x458d67,this['ref']=_0x392106,this['_index']=_0x4d1c50;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x2c2714){const _0x338250=new C(_0x2c2714),_0x20ea75=Vt(this['ref'],_0x2c2714);return new lt(this['_node']['getChild'](_0x338250),_0x20ea75,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x533c34){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x69ca32,_0x402986)=>_0x533c34(new lt(_0x402986,Vt(this['ref'],_0x69ca32),R)));}['hasChild'](_0x37cf8d){const _0x4b141f=new C(_0x37cf8d);return!this['_node']['getChild'](_0x4b141f)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function y_(_0x4f306c,_0x48c315){return _0x4f306c=P(_0x4f306c),_0x4f306c['_checkNotDeleted']('ref'),_0x48c315!==void 0x0?Vt(_0x4f306c['_root'],_0x48c315):_0x4f306c['_root'];}function Vt(_0x2987df,_0x1884bd){return _0x2987df=P(_0x2987df),y(_0x2987df['_path'])===null?pd('child','path',_0x1884bd):ys('child','path',_0x1884bd),new ee(_0x2987df['_repo'],k(_0x2987df['_path'],_0x1884bd));}function v_(_0x5f1c8b){return _0x5f1c8b=P(_0x5f1c8b),new Vd(_0x5f1c8b['_repo'],_0x5f1c8b['_path']);}function E_(_0x11179f,_0x3f785e){_0x11179f=P(_0x11179f),Me('push',_0x11179f['_path']),He('push',_0x3f785e,_0x11179f['_path'],!0x0);const _0x29c72d=la(_0x11179f['_repo']),_0x1bfbd9=Ud(_0x29c72d),_0x50407b=Vt(_0x11179f,_0x1bfbd9),_0x45fcad=Vt(_0x11179f,_0x1bfbd9);let _0xc4dabc;return _0x3f785e!=null?_0xc4dabc=Hd(_0x45fcad,_0x3f785e)['then'](()=>_0x45fcad):_0xc4dabc=Promise['resolve'](_0x45fcad),_0x50407b['then']=_0xc4dabc['then']['bind'](_0xc4dabc),_0x50407b['catch']=_0xc4dabc['then']['bind'](_0xc4dabc,void 0x0),_0x50407b;}function Hd(_0x9d3037,_0xbdfb6c){_0x9d3037=P(_0x9d3037),Me('set',_0x9d3037['_path']),He('set',_0xbdfb6c,_0x9d3037['_path'],!0x1);const _0x5e4c61=new H();return Cd(_0x9d3037['_repo'],_0x9d3037['_path'],_0xbdfb6c,null,_0x5e4c61['wrapCallback'](()=>{})),_0x5e4c61['promise'];}function I_(_0x11020a,_0x5070b8){ra('update',_0x5070b8,_0x11020a['_path']);const _0x576e74=new H();return Td(_0x11020a['_repo'],_0x11020a['_path'],_0x5070b8,_0x576e74['wrapCallback'](()=>{})),_0x576e74['promise'];}function w_(_0xe9f506){_0xe9f506=P(_0xe9f506);const _0x278bb1=new pa(()=>{}),_0x56d0d8=new Qn(_0x278bb1);return wd(_0xe9f506['_repo'],_0xe9f506,_0x56d0d8)['then'](_0x554ded=>new lt(_0x554ded,new ee(_0xe9f506['_repo'],_0xe9f506['_path']),_0xe9f506['_queryParams']['getIndex']()));}class Qn{constructor(_0x5f58d7){this['callbackContext']=_0x5f58d7;}['respondsTo'](_0xd17c11){return _0xd17c11==='value';}['createEvent'](_0x4ba84f,_0x3af3e0){const _0x10d7aa=_0x3af3e0['_queryParams']['getIndex']();return new Wd('value',this,new lt(_0x4ba84f['snapshotNode'],new ee(_0x3af3e0['_repo'],_0x3af3e0['_path']),_0x10d7aa));}['getEventRunner'](_0x2d35ff){return _0x2d35ff['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x2d35ff['error']):()=>this['callbackContext']['onValue'](_0x2d35ff['snapshot'],null);}['createCancelEvent'](_0x4ea18c,_0x48c9d9){return this['callbackContext']['hasCancelCallback']?new Bd(this,_0x4ea18c,_0x48c9d9):null;}['matches'](_0x42cb7d){return _0x42cb7d instanceof Qn?!_0x42cb7d['callbackContext']||!this['callbackContext']?!0x0:_0x42cb7d['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function $d(_0x583765,_0x421f47,_0x3cef58,_0x1d1be9,_0x130707){const _0x1c021f=new pa(_0x3cef58,void 0x0),_0x1aaeee=new Qn(_0x1c021f);return kd(_0x583765['_repo'],_0x583765,_0x1aaeee),()=>Pd(_0x583765['_repo'],_0x583765,_0x1aaeee);}function Gd(_0x2cc166,_0x361282,_0x1bf57f,_0x3861ea){return $d(_0x2cc166,'value',_0x361282);}class mt{}class ma extends mt{constructor(_0x4b44ba,_0x1eca8f){super(),this['_value']=_0x4b44ba,this['_key']=_0x1eca8f,this['type']='endAt';}['_apply'](_0xbb7cec){He('endAt',this['_value'],_0xbb7cec['_path'],!0x0);const _0x43ea93=Jh(_0xbb7cec['_queryParams'],this['_value'],this['_key']);if(ga(_0x43ea93),Yn(_0x43ea93),_0xbb7cec['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new Ae(_0xbb7cec['_repo'],_0xbb7cec['_path'],_0x43ea93,_0xbb7cec['_orderByCalled']);}}function C_(_0x207573,_0x4db638){return new ma(_0x207573,_0x4db638);}class ya extends mt{constructor(_0x13f997,_0x5569a1){super(),this['_value']=_0x13f997,this['_key']=_0x5569a1,this['type']='startAt';}['_apply'](_0x2845e8){He('startAt',this['_value'],_0x2845e8['_path'],!0x0);const _0x3e519a=Qh(_0x2845e8['_queryParams'],this['_value'],this['_key']);if(ga(_0x3e519a),Yn(_0x3e519a),_0x2845e8['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new Ae(_0x2845e8['_repo'],_0x2845e8['_path'],_0x3e519a,_0x2845e8['_orderByCalled']);}}function T_(_0x1f6a62=null,_0x578492){return new ya(_0x1f6a62,_0x578492);}class qd extends mt{constructor(_0xdb86a4){super(),this['_limit']=_0xdb86a4,this['type']='limitToFirst';}['_apply'](_0x37f945){if(_0x37f945['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new Ae(_0x37f945['_repo'],_0x37f945['_path'],Yh(_0x37f945['_queryParams'],this['_limit']),_0x37f945['_orderByCalled']);}}function S_(_0x3e2393){if(Math['floor'](_0x3e2393)!==_0x3e2393||_0x3e2393<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new qd(_0x3e2393);}class zd extends mt{constructor(_0x558200){super(),this['_path']=_0x558200,this['type']='orderByChild';}['_apply'](_0x11b96c){_a(_0x11b96c,'orderByChild');const _0x8bcf21=new C(this['_path']);if(v(_0x8bcf21))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x29a625=new Ji(_0x8bcf21),_0x5a7658=xo(_0x11b96c['_queryParams'],_0x29a625);return Yn(_0x5a7658),new Ae(_0x11b96c['_repo'],_0x11b96c['_path'],_0x5a7658,!0x0);}}function b_(_0x3bdfef){if(_0x3bdfef==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x3bdfef==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x3bdfef==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ys('orderByChild','path',_0x3bdfef),new zd(_0x3bdfef);}class jd extends mt{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x3506a2){_a(_0x3506a2,'orderByKey');const _0x9af4d6=xo(_0x3506a2['_queryParams'],ve);return Yn(_0x9af4d6),new Ae(_0x3506a2['_repo'],_0x3506a2['_path'],_0x9af4d6,!0x0);}}function R_(){return new jd();}class Kd extends mt{constructor(_0x4aa58d,_0x14f43e){super(),this['_value']=_0x4aa58d,this['_key']=_0x14f43e,this['type']='equalTo';}['_apply'](_0xd7ddb3){if(He('equalTo',this['_value'],_0xd7ddb3['_path'],!0x1),_0xd7ddb3['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0xd7ddb3['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0xd7ddb3));}}function A_(_0x1068d1,_0x21b1a1){return new Kd(_0x1068d1,_0x21b1a1);}function k_(_0xa5e8d1,..._0x26c2a0){let _0x4e599b=P(_0xa5e8d1);for(const _0x57adcd of _0x26c2a0)_0x4e599b=_0x57adcd['_apply'](_0x4e599b);return _0x4e599b;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Yd='FIREBASE_DATABASE_EMULATOR_HOST',Di={};let Qd=!0x1;function Jd(_0x306b9b,_0x47969f,_0x21bb06,_0xa6d090){const _0x4397b4=_0x47969f['lastIndexOf'](':'),_0xb76b61=_0x47969f['substring'](0x0,_0x4397b4),_0x573c32=qt(_0xb76b61);_0x306b9b['repoInfo_']=new yo(_0x47969f,_0x573c32,_0x306b9b['repoInfo_']['namespace'],_0x306b9b['repoInfo_']['webSocketOnly'],_0x306b9b['repoInfo_']['nodeAdmin'],_0x306b9b['repoInfo_']['persistenceKey'],_0x306b9b['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x21bb06),_0xa6d090&&(_0x306b9b['authTokenProvider_']=_0xa6d090);}function Xd(_0x2de567,_0x191593,_0x39bef2,_0xf4fa82,_0x3ed41c){let _0x2c51ca=_0xf4fa82||_0x2de567['options']['databaseURL'];_0x2c51ca===void 0x0&&(_0x2de567['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x2de567['options']['projectId']),_0x2c51ca=_0x2de567['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x4437dc=vr(_0x2c51ca,_0x3ed41c),_0x588cd5=_0x4437dc['repoInfo'],_0xe88e85;typeof process<'u'&&Bs&&(_0xe88e85=Bs[Yd]),_0xe88e85?(_0x2c51ca='http://'+_0xe88e85+'?ns='+_0x588cd5['namespace'],_0x4437dc=vr(_0x2c51ca,_0x3ed41c),_0x588cd5=_0x4437dc['repoInfo']):_0x4437dc['repoInfo']['secure'];const _0x5ca488=new eh(_0x2de567['name'],_0x2de567['options'],_0x191593);_d('Invalid\x20Firebase\x20Database\x20URL',_0x4437dc),v(_0x4437dc['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x259897=ef(_0x588cd5,_0x2de567,_0x5ca488,new Zl(_0x2de567,_0x39bef2));return new tf(_0x259897,_0x2de567);}function Zd(_0x342e89,_0x576d5e){const _0x46db88=Di[_0x576d5e];(!_0x46db88||_0x46db88[_0x342e89['key']]!==_0x342e89)&&ae('Database\x20'+_0x576d5e+'('+_0x342e89['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x342e89),delete _0x46db88[_0x342e89['key']];}function ef(_0x3ec425,_0x330fb1,_0x16e858,_0x14aeec){let _0x4bcb70=Di[_0x330fb1['name']];_0x4bcb70||(_0x4bcb70={},Di[_0x330fb1['name']]=_0x4bcb70);let _0x1c1a8f=_0x4bcb70[_0x3ec425['toURLString']()];return _0x1c1a8f&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x1c1a8f=new vd(_0x3ec425,Qd,_0x16e858,_0x14aeec),_0x4bcb70[_0x3ec425['toURLString']()]=_0x1c1a8f,_0x1c1a8f;}class tf{constructor(_0x6009e3,_0x29cad3){this['_repoInternal']=_0x6009e3,this['app']=_0x29cad3,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Zd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x2040e8){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x2040e8+'\x20on\x20a\x20deleted\x20database.');}}function P_(_0x3acb33=Zr(),_0x37fa86){const _0x38c398=Hi(_0x3acb33,'database')['getImmediate']({'identifier':_0x37fa86});if(!_0x38c398['_instanceStarted']){const _0x4bcf36=hc('database');_0x4bcf36&&nf(_0x38c398,..._0x4bcf36);}return _0x38c398;}function nf(_0x4d8aff,_0x42e8ef,_0x56c1ae,_0x6dbf2e={}){_0x4d8aff=P(_0x4d8aff),_0x4d8aff['_checkNotDeleted']('useEmulator');const _0x41921d=_0x42e8ef+':'+_0x56c1ae,_0x702f3d=_0x4d8aff['_repoInternal'];if(_0x4d8aff['_instanceStarted']){if(_0x41921d===_0x4d8aff['_repoInternal']['repoInfo_']['host']&&xe(_0x6dbf2e,_0x702f3d['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x4a3a67;if(_0x702f3d['repoInfo_']['nodeAdmin'])_0x6dbf2e['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x4a3a67=new an(an['OWNER']);else{if(_0x6dbf2e['mockUserToken']){const _0x4fd91a=typeof _0x6dbf2e['mockUserToken']=='string'?_0x6dbf2e['mockUserToken']:uc(_0x6dbf2e['mockUserToken'],_0x4d8aff['app']['options']['projectId']);_0x4a3a67=new an(_0x4fd91a);}}qt(_0x42e8ef)&&Qr(_0x42e8ef),Jd(_0x702f3d,_0x41921d,_0x6dbf2e,_0x4a3a67);}function N_(_0x58c9c7){_0x58c9c7=P(_0x58c9c7),_0x58c9c7['_checkNotDeleted']('goOffline'),ha(_0x58c9c7['_repo']);}function O_(_0x1cd443){_0x1cd443=P(_0x1cd443),_0x1cd443['_checkNotDeleted']('goOnline'),Nd(_0x1cd443['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sf(_0x39fb41){Ul(dt),st(new Fe('database',(_0x48dadb,{instanceIdentifier:_0x4efa67})=>{const _0x267f36=_0x48dadb['getProvider']('app')['getImmediate'](),_0xb4eb31=_0x48dadb['getProvider']('auth-internal'),_0x2c8b54=_0x48dadb['getProvider']('app-check-internal');return Xd(_0x267f36,_0xb4eb31,_0x2c8b54,_0x4efa67);},'PUBLIC')['setMultipleInstances'](!0x0)),ye(Vs,Hs,_0x39fb41),ye(Vs,Hs,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rf={'.sv':'timestamp'};function D_(){return rf;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class of{constructor(_0x42b55d,_0x147872){this['committed']=_0x42b55d,this['snapshot']=_0x147872;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function M_(_0x5b80b5,_0x238e89,_0x504d7c){if(_0x5b80b5=P(_0x5b80b5),Me('Reference.transaction',_0x5b80b5['_path']),_0x5b80b5['key']==='.length'||_0x5b80b5['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x5b80b5['key']+'\x20is\x20a\x20read-only\x20object.';const _0x5281a3=!0x0,_0x2e187b=new H(),_0x4d73f7=(_0x25d298,_0x496883,_0x5bfb38)=>{let _0x24af22=null;_0x25d298?_0x2e187b['reject'](_0x25d298):(_0x24af22=new lt(_0x5bfb38,new ee(_0x5b80b5['_repo'],_0x5b80b5['_path']),R),_0x2e187b['resolve'](new of(_0x496883,_0x24af22)));},_0x598d2b=Gd(_0x5b80b5,()=>{});return Od(_0x5b80b5['_repo'],_0x5b80b5['_path'],_0x238e89,_0x4d73f7,_0x598d2b,_0x5281a3),_0x2e187b['promise'];}se['prototype']['simpleListen']=function(_0x66f818,_0x9a36a8){this['sendRequest']('q',{'p':_0x66f818},_0x9a36a8);},se['prototype']['echo']=function(_0x372c20,_0x2cf78a){this['sendRequest']('echo',{'d':_0x372c20},_0x2cf78a);},sf();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const af=va,Ea=new Gt('auth','Firebase',va()),kn=new Bi('@firebase/auth');function cf(_0x549e66,..._0x47b0c3){kn['logLevel']<=T['WARN']&&kn['warn']('Auth\x20('+dt+'):\x20'+_0x549e66,..._0x47b0c3);}function cn(_0x29d105,..._0x273bc4){kn['logLevel']<=T['ERROR']&&kn['error']('Auth\x20('+dt+'):\x20'+_0x29d105,..._0x273bc4);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Y(_0x451152,..._0x24b481){throw ws(_0x451152,..._0x24b481);}function X(_0x33492f,..._0x11f1bc){return ws(_0x33492f,..._0x11f1bc);}function Ia(_0x59604f,_0x9680b4,_0x2c46a2){const _0x5c3915={...af(),[_0x9680b4]:_0x2c46a2};return new Gt('auth','Firebase',_0x5c3915)['create'](_0x9680b4,{'appName':_0x59604f['name']});}function re(_0x2466ff){return Ia(_0x2466ff,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x124497,..._0x416922){if(typeof _0x124497!='string'){const _0x31779a=_0x416922[0x0],_0x338d17=[..._0x416922['slice'](0x1)];return _0x338d17[0x0]&&(_0x338d17[0x0]['appName']=_0x124497['name']),_0x124497['_errorFactory']['create'](_0x31779a,..._0x338d17);}return Ea['create'](_0x124497,..._0x416922);}function m(_0x5b3160,_0x4d4607,..._0x100e45){if(!_0x5b3160)throw ws(_0x4d4607,..._0x100e45);}function ne(_0x49f922){const _0x11083a='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x49f922;throw cn(_0x11083a),new Error(_0x11083a);}function ce(_0x2adff0,_0x2c6886){_0x2adff0||ne(_0x2c6886);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mi(){var _0x490347;return typeof self<'u'&&((_0x490347=self['location'])==null?void 0x0:_0x490347['href'])||'';}function lf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x2bf6ac;return typeof self<'u'&&((_0x2bf6ac=self['location'])==null?void 0x0:_0x2bf6ac['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function hf(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(lf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function uf(){if(typeof navigator>'u')return null;const _0x57fe36=navigator;return _0x57fe36['languages']&&_0x57fe36['languages'][0x0]||_0x57fe36['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zt{constructor(_0x45f7d3,_0x5681f8){this['shortDelay']=_0x45f7d3,this['longDelay']=_0x5681f8,ce(_0x5681f8>_0x45f7d3,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Wi()||Kr();}['get'](){return hf()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x44a4df,_0x5ff5b3){ce(_0x44a4df['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x1c4f43}=_0x44a4df['emulator'];return _0x5ff5b3?''+_0x1c4f43+(_0x5ff5b3['startsWith']('/')?_0x5ff5b3['slice'](0x1):_0x5ff5b3):_0x1c4f43;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x11f88f,_0x46d41e,_0x4773bd){this['fetchImpl']=_0x11f88f,_0x46d41e&&(this['headersImpl']=_0x46d41e),_0x4773bd&&(this['responseImpl']=_0x4773bd);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const df={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},ff=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],pf=new Zt(0x7530,0xea60);function ke(_0x1cc078,_0x85a13e){return _0x1cc078['tenantId']&&!_0x85a13e['tenantId']?{..._0x85a13e,'tenantId':_0x1cc078['tenantId']}:_0x85a13e;}async function Pe(_0x3bc88c,_0xe13cfc,_0x3d4a69,_0x38c309,_0x14e119={}){return Ca(_0x3bc88c,_0x14e119,async()=>{let _0x1ad584={},_0x3b4ec5={};_0x38c309&&(_0xe13cfc==='GET'?_0x3b4ec5=_0x38c309:_0x1ad584={'body':JSON['stringify'](_0x38c309)});const _0x55443c=ut({..._0x3b4ec5,'key':_0x3bc88c['config']['apiKey']})['slice'](0x1),_0x49d5a3=await _0x3bc88c['_getAdditionalHeaders']();_0x49d5a3['Content-Type']='application/json',_0x3bc88c['languageCode']&&(_0x49d5a3['X-Firebase-Locale']=_0x3bc88c['languageCode']);const _0x262c41={'method':_0xe13cfc,'headers':_0x49d5a3,..._0x1ad584};return dc()||(_0x262c41['referrerPolicy']='strict-origin-when-cross-origin'),_0x3bc88c['emulatorConfig']&&qt(_0x3bc88c['emulatorConfig']['host'])&&(_0x262c41['credentials']='include'),wa['fetch']()(await Ta(_0x3bc88c,_0x3bc88c['config']['apiHost'],_0x3d4a69,_0x55443c),_0x262c41);});}async function Ca(_0x28334e,_0x4430c5,_0x10aaa6){_0x28334e['_canInitEmulator']=!0x1;const _0x182f4f={...df,..._0x4430c5};try{const _0x138ded=new gf(_0x28334e),_0x1481d4=await Promise['race']([_0x10aaa6(),_0x138ded['promise']]);_0x138ded['clearNetworkTimeout']();const _0x15776f=await _0x1481d4['json']();if('needConfirmation'in _0x15776f)throw on(_0x28334e,'account-exists-with-different-credential',_0x15776f);if(_0x1481d4['ok']&&!('errorMessage'in _0x15776f))return _0x15776f;{const _0x49c078=_0x1481d4['ok']?_0x15776f['errorMessage']:_0x15776f['error']['message'],[_0x2757f0,_0x5d0594]=_0x49c078['split']('\x20:\x20');if(_0x2757f0==='FEDERATED_USER_ID_ALREADY_LINKED')throw on(_0x28334e,'credential-already-in-use',_0x15776f);if(_0x2757f0==='EMAIL_EXISTS')throw on(_0x28334e,'email-already-in-use',_0x15776f);if(_0x2757f0==='USER_DISABLED')throw on(_0x28334e,'user-disabled',_0x15776f);const _0xb415bd=_0x182f4f[_0x2757f0]||_0x2757f0['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x5d0594)throw Ia(_0x28334e,_0xb415bd,_0x5d0594);Y(_0x28334e,_0xb415bd);}}catch(_0x1cfa65){if(_0x1cfa65 instanceof Re)throw _0x1cfa65;Y(_0x28334e,'network-request-failed',{'message':String(_0x1cfa65)});}}async function en(_0x507657,_0x311f53,_0x56ea32,_0x347ed7,_0xabb0a1={}){const _0x3ac7c5=await Pe(_0x507657,_0x311f53,_0x56ea32,_0x347ed7,_0xabb0a1);return'mfaPendingCredential'in _0x3ac7c5&&Y(_0x507657,'multi-factor-auth-required',{'_serverResponse':_0x3ac7c5}),_0x3ac7c5;}async function Ta(_0x21b7f2,_0x4b7fd2,_0x120c9f,_0x19a10f){const _0x375b29=''+_0x4b7fd2+_0x120c9f+'?'+_0x19a10f,_0x1f501f=_0x21b7f2,_0x3e1a3d=_0x1f501f['config']['emulator']?Cs(_0x21b7f2['config'],_0x375b29):_0x21b7f2['config']['apiScheme']+'://'+_0x375b29;return ff['includes'](_0x120c9f)&&(await _0x1f501f['_persistenceManagerAvailable'],_0x1f501f['_getPersistenceType']()==='COOKIE')?_0x1f501f['_getPersistence']()['_getFinalTarget'](_0x3e1a3d)['toString']():_0x3e1a3d;}function _f(_0x56de83){switch(_0x56de83){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class gf{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x5719a3){this['auth']=_0x5719a3,this['timer']=null,this['promise']=new Promise((_0x56f9c1,_0x1f22a2)=>{this['timer']=setTimeout(()=>_0x1f22a2(X(this['auth'],'network-request-failed')),pf['get']());});}}function on(_0x5b210a,_0x2695eb,_0x2d9ee4){const _0x5e640e={'appName':_0x5b210a['name']};_0x2d9ee4['email']&&(_0x5e640e['email']=_0x2d9ee4['email']),_0x2d9ee4['phoneNumber']&&(_0x5e640e['phoneNumber']=_0x2d9ee4['phoneNumber']);const _0x5783ea=X(_0x5b210a,_0x2695eb,_0x5e640e);return _0x5783ea['customData']['_tokenResponse']=_0x2d9ee4,_0x5783ea;}function wr(_0x14e54f){return _0x14e54f!==void 0x0&&_0x14e54f['enterprise']!==void 0x0;}class mf{constructor(_0x4100df){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x4100df['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x4100df['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x4100df['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x4b63cd){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x56ea10 of this['recaptchaEnforcementState'])if(_0x56ea10['provider']&&_0x56ea10['provider']===_0x4b63cd)return _f(_0x56ea10['enforcementState']);return null;}['isProviderEnabled'](_0x2019aa){return this['getProviderEnforcementState'](_0x2019aa)==='ENFORCE'||this['getProviderEnforcementState'](_0x2019aa)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function yf(_0x5c6121,_0x2dc86b){return Pe(_0x5c6121,'GET','/v2/recaptchaConfig',ke(_0x5c6121,_0x2dc86b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function vf(_0x2892bd,_0x3ce9c3){return Pe(_0x2892bd,'POST','/v1/accounts:delete',_0x3ce9c3);}async function Pn(_0x377400,_0x3e0cdb){return Pe(_0x377400,'POST','/v1/accounts:lookup',_0x3e0cdb);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pt(_0x3c9647){if(_0x3c9647)try{const _0x9faa2d=new Date(Number(_0x3c9647));if(!isNaN(_0x9faa2d['getTime']()))return _0x9faa2d['toUTCString']();}catch{}}async function Ef(_0x3ac79b,_0x55b192=!0x1){const _0x420193=P(_0x3ac79b),_0x36da7c=await _0x420193['getIdToken'](_0x55b192),_0x73796d=Ts(_0x36da7c);m(_0x73796d&&_0x73796d['exp']&&_0x73796d['auth_time']&&_0x73796d['iat'],_0x420193['auth'],'internal-error');const _0x4fc63a=typeof _0x73796d['firebase']=='object'?_0x73796d['firebase']:void 0x0,_0x481c45=_0x4fc63a==null?void 0x0:_0x4fc63a['sign_in_provider'];return{'claims':_0x73796d,'token':_0x36da7c,'authTime':Pt(fi(_0x73796d['auth_time'])),'issuedAtTime':Pt(fi(_0x73796d['iat'])),'expirationTime':Pt(fi(_0x73796d['exp'])),'signInProvider':_0x481c45||null,'signInSecondFactor':(_0x4fc63a==null?void 0x0:_0x4fc63a['sign_in_second_factor'])||null};}function fi(_0x218686){return Number(_0x218686)*0x3e8;}function Ts(_0x45c01f){const [_0x5ac24f,_0x30f90a,_0x24a1c6]=_0x45c01f['split']('.');if(_0x5ac24f===void 0x0||_0x30f90a===void 0x0||_0x24a1c6===void 0x0)return cn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x6d3f4=fn(_0x30f90a);return _0x6d3f4?JSON['parse'](_0x6d3f4):(cn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x5ddcaa){return cn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x5ddcaa==null?void 0x0:_0x5ddcaa['toString']()),null;}}function Cr(_0x44f82e){const _0x1fb5ec=Ts(_0x44f82e);return m(_0x1fb5ec,'internal-error'),m(typeof _0x1fb5ec['exp']<'u','internal-error'),m(typeof _0x1fb5ec['iat']<'u','internal-error'),Number(_0x1fb5ec['exp'])-Number(_0x1fb5ec['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ht(_0x5eb585,_0x42d023,_0x209c14=!0x1){if(_0x209c14)return _0x42d023;try{return await _0x42d023;}catch(_0x319d8b){throw _0x319d8b instanceof Re&&If(_0x319d8b)&&_0x5eb585['auth']['currentUser']===_0x5eb585&&await _0x5eb585['auth']['signOut'](),_0x319d8b;}}function If({code:_0x3e01ce}){return _0x3e01ce==='auth/user-disabled'||_0x3e01ce==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wf{constructor(_0xd843af){this['user']=_0xd843af,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0xccedfc){if(_0xccedfc){const _0x1a0c03=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x1a0c03;}else{this['errorBackoff']=0x7530;const _0x10a2bf=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x10a2bf);}}['schedule'](_0x2679ba=!0x1){if(!this['isRunning'])return;const _0x4935da=this['getInterval'](_0x2679ba);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x4935da);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x317967){(_0x317967==null?void 0x0:_0x317967['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Li{constructor(_0x4511d7,_0x1ef8a8){this['createdAt']=_0x4511d7,this['lastLoginAt']=_0x1ef8a8,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Pt(this['lastLoginAt']),this['creationTime']=Pt(this['createdAt']);}['_copy'](_0x2ac0a2){this['createdAt']=_0x2ac0a2['createdAt'],this['lastLoginAt']=_0x2ac0a2['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Nn(_0x179579){var _0x292ba4;const _0x28e4c1=_0x179579['auth'],_0x40cb8f=await _0x179579['getIdToken'](),_0x913f90=await Ht(_0x179579,Pn(_0x28e4c1,{'idToken':_0x40cb8f}));m(_0x913f90==null?void 0x0:_0x913f90['users']['length'],_0x28e4c1,'internal-error');const _0x1fe94c=_0x913f90['users'][0x0];_0x179579['_notifyReloadListener'](_0x1fe94c);const _0x3daa3a=(_0x292ba4=_0x1fe94c['providerUserInfo'])!=null&&_0x292ba4['length']?Sa(_0x1fe94c['providerUserInfo']):[],_0x44b59b=Tf(_0x179579['providerData'],_0x3daa3a),_0x4a61fd=_0x179579['isAnonymous'],_0x177224=!(_0x179579['email']&&_0x1fe94c['passwordHash'])&&!(_0x44b59b!=null&&_0x44b59b['length']),_0x1166b2=_0x4a61fd?_0x177224:!0x1,_0x29edad={'uid':_0x1fe94c['localId'],'displayName':_0x1fe94c['displayName']||null,'photoURL':_0x1fe94c['photoUrl']||null,'email':_0x1fe94c['email']||null,'emailVerified':_0x1fe94c['emailVerified']||!0x1,'phoneNumber':_0x1fe94c['phoneNumber']||null,'tenantId':_0x1fe94c['tenantId']||null,'providerData':_0x44b59b,'metadata':new Li(_0x1fe94c['createdAt'],_0x1fe94c['lastLoginAt']),'isAnonymous':_0x1166b2};Object['assign'](_0x179579,_0x29edad);}async function Cf(_0x37c050){const _0x37cec8=P(_0x37c050);await Nn(_0x37cec8),await _0x37cec8['auth']['_persistUserIfCurrent'](_0x37cec8),_0x37cec8['auth']['_notifyListenersIfCurrent'](_0x37cec8);}function Tf(_0x5f321c,_0x26eb50){return[..._0x5f321c['filter'](_0xc094fa=>!_0x26eb50['some'](_0x1b4403=>_0x1b4403['providerId']===_0xc094fa['providerId'])),..._0x26eb50];}function Sa(_0x399b9e){return _0x399b9e['map'](({providerId:_0x1c62f1,..._0x2693d5})=>({'providerId':_0x1c62f1,'uid':_0x2693d5['rawId']||'','displayName':_0x2693d5['displayName']||null,'email':_0x2693d5['email']||null,'phoneNumber':_0x2693d5['phoneNumber']||null,'photoURL':_0x2693d5['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Sf(_0x54847a,_0x5c51b3){const _0x5284c0=await Ca(_0x54847a,{},async()=>{const _0x3f62b8=ut({'grant_type':'refresh_token','refresh_token':_0x5c51b3})['slice'](0x1),{tokenApiHost:_0x3ad47c,apiKey:_0x58e19e}=_0x54847a['config'],_0x161ba7=await Ta(_0x54847a,_0x3ad47c,'/v1/token','key='+_0x58e19e),_0x89d3e8=await _0x54847a['_getAdditionalHeaders']();_0x89d3e8['Content-Type']='application/x-www-form-urlencoded';const _0x3859c8={'method':'POST','headers':_0x89d3e8,'body':_0x3f62b8};return _0x54847a['emulatorConfig']&&qt(_0x54847a['emulatorConfig']['host'])&&(_0x3859c8['credentials']='include'),wa['fetch']()(_0x161ba7,_0x3859c8);});return{'accessToken':_0x5284c0['access_token'],'expiresIn':_0x5284c0['expires_in'],'refreshToken':_0x5284c0['refresh_token']};}async function bf(_0x53a80c,_0xb6c1ef){return Pe(_0x53a80c,'POST','/v2/accounts:revokeToken',ke(_0x53a80c,_0xb6c1ef));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class et{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x4a6cb6){m(_0x4a6cb6['idToken'],'internal-error'),m(typeof _0x4a6cb6['idToken']<'u','internal-error'),m(typeof _0x4a6cb6['refreshToken']<'u','internal-error');const _0x23b7e2='expiresIn'in _0x4a6cb6&&typeof _0x4a6cb6['expiresIn']<'u'?Number(_0x4a6cb6['expiresIn']):Cr(_0x4a6cb6['idToken']);this['updateTokensAndExpiration'](_0x4a6cb6['idToken'],_0x4a6cb6['refreshToken'],_0x23b7e2);}['updateFromIdToken'](_0x319c54){m(_0x319c54['length']!==0x0,'internal-error');const _0x87aafe=Cr(_0x319c54);this['updateTokensAndExpiration'](_0x319c54,null,_0x87aafe);}async['getToken'](_0x4b23fe,_0x6e4ade=!0x1){return!_0x6e4ade&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x4b23fe,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x4b23fe,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x181e78,_0x4e1ff6){const {accessToken:_0x2adab8,refreshToken:_0x2655ea,expiresIn:_0xb01af7}=await Sf(_0x181e78,_0x4e1ff6);this['updateTokensAndExpiration'](_0x2adab8,_0x2655ea,Number(_0xb01af7));}['updateTokensAndExpiration'](_0x4bc062,_0x24dfbf,_0x5e500a){this['refreshToken']=_0x24dfbf||null,this['accessToken']=_0x4bc062||null,this['expirationTime']=Date['now']()+_0x5e500a*0x3e8;}static['fromJSON'](_0x1e4ca0,_0x181333){const {refreshToken:_0x300865,accessToken:_0x2469f8,expirationTime:_0x505d36}=_0x181333,_0x16e4b5=new et();return _0x300865&&(m(typeof _0x300865=='string','internal-error',{'appName':_0x1e4ca0}),_0x16e4b5['refreshToken']=_0x300865),_0x2469f8&&(m(typeof _0x2469f8=='string','internal-error',{'appName':_0x1e4ca0}),_0x16e4b5['accessToken']=_0x2469f8),_0x505d36&&(m(typeof _0x505d36=='number','internal-error',{'appName':_0x1e4ca0}),_0x16e4b5['expirationTime']=_0x505d36),_0x16e4b5;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x4628f6){this['accessToken']=_0x4628f6['accessToken'],this['refreshToken']=_0x4628f6['refreshToken'],this['expirationTime']=_0x4628f6['expirationTime'];}['_clone'](){return Object['assign'](new et(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x233967,_0x289ad4){m(typeof _0x233967=='string'||typeof _0x233967>'u','internal-error',{'appName':_0x289ad4});}class j{constructor({uid:_0x147573,auth:_0x5145ca,stsTokenManager:_0x4ca098,..._0x43fba6}){this['providerId']='firebase',this['proactiveRefresh']=new wf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x147573,this['auth']=_0x5145ca,this['stsTokenManager']=_0x4ca098,this['accessToken']=_0x4ca098['accessToken'],this['displayName']=_0x43fba6['displayName']||null,this['email']=_0x43fba6['email']||null,this['emailVerified']=_0x43fba6['emailVerified']||!0x1,this['phoneNumber']=_0x43fba6['phoneNumber']||null,this['photoURL']=_0x43fba6['photoURL']||null,this['isAnonymous']=_0x43fba6['isAnonymous']||!0x1,this['tenantId']=_0x43fba6['tenantId']||null,this['providerData']=_0x43fba6['providerData']?[..._0x43fba6['providerData']]:[],this['metadata']=new Li(_0x43fba6['createdAt']||void 0x0,_0x43fba6['lastLoginAt']||void 0x0);}async['getIdToken'](_0x55c799){const _0x1e85a1=await Ht(this,this['stsTokenManager']['getToken'](this['auth'],_0x55c799));return m(_0x1e85a1,this['auth'],'internal-error'),this['accessToken']!==_0x1e85a1&&(this['accessToken']=_0x1e85a1,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x1e85a1;}['getIdTokenResult'](_0x103a7d){return Ef(this,_0x103a7d);}['reload'](){return Cf(this);}['_assign'](_0x40ff0f){this!==_0x40ff0f&&(m(this['uid']===_0x40ff0f['uid'],this['auth'],'internal-error'),this['displayName']=_0x40ff0f['displayName'],this['photoURL']=_0x40ff0f['photoURL'],this['email']=_0x40ff0f['email'],this['emailVerified']=_0x40ff0f['emailVerified'],this['phoneNumber']=_0x40ff0f['phoneNumber'],this['isAnonymous']=_0x40ff0f['isAnonymous'],this['tenantId']=_0x40ff0f['tenantId'],this['providerData']=_0x40ff0f['providerData']['map'](_0x3d30cb=>({..._0x3d30cb})),this['metadata']['_copy'](_0x40ff0f['metadata']),this['stsTokenManager']['_assign'](_0x40ff0f['stsTokenManager']));}['_clone'](_0x569aae){const _0x265948=new j({...this,'auth':_0x569aae,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x265948['metadata']['_copy'](this['metadata']),_0x265948;}['_onReload'](_0x56c939){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x56c939,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x2fd16a){this['reloadListener']?this['reloadListener'](_0x2fd16a):this['reloadUserInfo']=_0x2fd16a;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x3bc5a9,_0x3ae0ca=!0x1){let _0x4cf668=!0x1;_0x3bc5a9['idToken']&&_0x3bc5a9['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x3bc5a9),_0x4cf668=!0x0),_0x3ae0ca&&await Nn(this),await this['auth']['_persistUserIfCurrent'](this),_0x4cf668&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x41f411=await this['getIdToken']();return await Ht(this,vf(this['auth'],{'idToken':_0x41f411})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x2995b5=>({..._0x2995b5})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x4a9119,_0x39f129){const _0x55bc57=_0x39f129['displayName']??void 0x0,_0x251a03=_0x39f129['email']??void 0x0,_0x501152=_0x39f129['phoneNumber']??void 0x0,_0x1decf7=_0x39f129['photoURL']??void 0x0,_0x118e3d=_0x39f129['tenantId']??void 0x0,_0x370bfe=_0x39f129['_redirectEventId']??void 0x0,_0x266398=_0x39f129['createdAt']??void 0x0,_0x29bb4e=_0x39f129['lastLoginAt']??void 0x0,{uid:_0x6a034e,emailVerified:_0x1d20e3,isAnonymous:_0x268ce3,providerData:_0x1d7984,stsTokenManager:_0x2d98a3}=_0x39f129;m(_0x6a034e&&_0x2d98a3,_0x4a9119,'internal-error');const _0x1bfa77=et['fromJSON'](this['name'],_0x2d98a3);m(typeof _0x6a034e=='string',_0x4a9119,'internal-error'),le(_0x55bc57,_0x4a9119['name']),le(_0x251a03,_0x4a9119['name']),m(typeof _0x1d20e3=='boolean',_0x4a9119,'internal-error'),m(typeof _0x268ce3=='boolean',_0x4a9119,'internal-error'),le(_0x501152,_0x4a9119['name']),le(_0x1decf7,_0x4a9119['name']),le(_0x118e3d,_0x4a9119['name']),le(_0x370bfe,_0x4a9119['name']),le(_0x266398,_0x4a9119['name']),le(_0x29bb4e,_0x4a9119['name']);const _0xa2032c=new j({'uid':_0x6a034e,'auth':_0x4a9119,'email':_0x251a03,'emailVerified':_0x1d20e3,'displayName':_0x55bc57,'isAnonymous':_0x268ce3,'photoURL':_0x1decf7,'phoneNumber':_0x501152,'tenantId':_0x118e3d,'stsTokenManager':_0x1bfa77,'createdAt':_0x266398,'lastLoginAt':_0x29bb4e});return _0x1d7984&&Array['isArray'](_0x1d7984)&&(_0xa2032c['providerData']=_0x1d7984['map'](_0x1fef1a=>({..._0x1fef1a}))),_0x370bfe&&(_0xa2032c['_redirectEventId']=_0x370bfe),_0xa2032c;}static async['_fromIdTokenResponse'](_0x23fa1b,_0x58d7af,_0x37970d=!0x1){const _0x394bb6=new et();_0x394bb6['updateFromServerResponse'](_0x58d7af);const _0x4c4128=new j({'uid':_0x58d7af['localId'],'auth':_0x23fa1b,'stsTokenManager':_0x394bb6,'isAnonymous':_0x37970d});return await Nn(_0x4c4128),_0x4c4128;}static async['_fromGetAccountInfoResponse'](_0x1d3183,_0x472ed2,_0x18e158){const _0x4d7d02=_0x472ed2['users'][0x0];m(_0x4d7d02['localId']!==void 0x0,'internal-error');const _0x249d71=_0x4d7d02['providerUserInfo']!==void 0x0?Sa(_0x4d7d02['providerUserInfo']):[],_0x448650=!(_0x4d7d02['email']&&_0x4d7d02['passwordHash'])&&!(_0x249d71!=null&&_0x249d71['length']),_0x624def=new et();_0x624def['updateFromIdToken'](_0x18e158);const _0x50634e=new j({'uid':_0x4d7d02['localId'],'auth':_0x1d3183,'stsTokenManager':_0x624def,'isAnonymous':_0x448650}),_0xaac4e5={'uid':_0x4d7d02['localId'],'displayName':_0x4d7d02['displayName']||null,'photoURL':_0x4d7d02['photoUrl']||null,'email':_0x4d7d02['email']||null,'emailVerified':_0x4d7d02['emailVerified']||!0x1,'phoneNumber':_0x4d7d02['phoneNumber']||null,'tenantId':_0x4d7d02['tenantId']||null,'providerData':_0x249d71,'metadata':new Li(_0x4d7d02['createdAt'],_0x4d7d02['lastLoginAt']),'isAnonymous':!(_0x4d7d02['email']&&_0x4d7d02['passwordHash'])&&!(_0x249d71!=null&&_0x249d71['length'])};return Object['assign'](_0x50634e,_0xaac4e5),_0x50634e;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x5f22b5){ce(_0x5f22b5 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x2d511c=Tr['get'](_0x5f22b5);return _0x2d511c?(ce(_0x2d511c instanceof _0x5f22b5,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x2d511c):(_0x2d511c=new _0x5f22b5(),Tr['set'](_0x5f22b5,_0x2d511c),_0x2d511c);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x668252,_0x1e47e5){this['storage'][_0x668252]=_0x1e47e5;}async['_get'](_0x1a3b5d){const _0x1bdc9c=this['storage'][_0x1a3b5d];return _0x1bdc9c===void 0x0?null:_0x1bdc9c;}async['_remove'](_0x522a5d){delete this['storage'][_0x522a5d];}['_addListener'](_0x3a7d9c,_0xad0170){}['_removeListener'](_0x3a8c04,_0x1cb439){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ln(_0x5afd93,_0x4aeb1b,_0x285131){return'firebase:'+_0x5afd93+':'+_0x4aeb1b+':'+_0x285131;}class tt{constructor(_0x1b9f2b,_0x4c1121,_0x355fb5){this['persistence']=_0x1b9f2b,this['auth']=_0x4c1121,this['userKey']=_0x355fb5;const {config:_0x40d523,name:_0x160f4c}=this['auth'];this['fullUserKey']=ln(this['userKey'],_0x40d523['apiKey'],_0x160f4c),this['fullPersistenceKey']=ln('persistence',_0x40d523['apiKey'],_0x160f4c),this['boundEventHandler']=_0x4c1121['_onStorageEvent']['bind'](_0x4c1121),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x9f65fa){return this['persistence']['_set'](this['fullUserKey'],_0x9f65fa['toJSON']());}async['getCurrentUser'](){const _0x19435f=await this['persistence']['_get'](this['fullUserKey']);if(!_0x19435f)return null;if(typeof _0x19435f=='string'){const _0x5048fe=await Pn(this['auth'],{'idToken':_0x19435f})['catch'](()=>{});return _0x5048fe?j['_fromGetAccountInfoResponse'](this['auth'],_0x5048fe,_0x19435f):null;}return j['_fromJSON'](this['auth'],_0x19435f);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x15bb8e){if(this['persistence']===_0x15bb8e)return;const _0x42c464=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x15bb8e,_0x42c464)return this['setCurrentUser'](_0x42c464);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x242f74,_0x45eb8b,_0x2e69d5='authUser'){if(!_0x45eb8b['length'])return new tt(ie(Sr),_0x242f74,_0x2e69d5);const _0x51efa5=(await Promise['all'](_0x45eb8b['map'](async _0xb1403c=>{if(await _0xb1403c['_isAvailable']())return _0xb1403c;})))['filter'](_0x60658e=>_0x60658e);let _0x42face=_0x51efa5[0x0]||ie(Sr);const _0x32e7c9=ln(_0x2e69d5,_0x242f74['config']['apiKey'],_0x242f74['name']);let _0x251b39=null;for(const _0x4a30c1 of _0x45eb8b)try{const _0x3f4843=await _0x4a30c1['_get'](_0x32e7c9);if(_0x3f4843){let _0x187aeb;if(typeof _0x3f4843=='string'){const _0x10bc3d=await Pn(_0x242f74,{'idToken':_0x3f4843})['catch'](()=>{});if(!_0x10bc3d)break;_0x187aeb=await j['_fromGetAccountInfoResponse'](_0x242f74,_0x10bc3d,_0x3f4843);}else _0x187aeb=j['_fromJSON'](_0x242f74,_0x3f4843);_0x4a30c1!==_0x42face&&(_0x251b39=_0x187aeb),_0x42face=_0x4a30c1;break;}}catch{}const _0x366070=_0x51efa5['filter'](_0x5e3da4=>_0x5e3da4['_shouldAllowMigration']);return!_0x42face['_shouldAllowMigration']||!_0x366070['length']?new tt(_0x42face,_0x242f74,_0x2e69d5):(_0x42face=_0x366070[0x0],_0x251b39&&await _0x42face['_set'](_0x32e7c9,_0x251b39['toJSON']()),await Promise['all'](_0x45eb8b['map'](async _0x564358=>{if(_0x564358!==_0x42face)try{await _0x564358['_remove'](_0x32e7c9);}catch{}})),new tt(_0x42face,_0x242f74,_0x2e69d5));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x145dd2){const _0x594562=_0x145dd2['toLowerCase']();if(_0x594562['includes']('opera/')||_0x594562['includes']('opr/')||_0x594562['includes']('opios/'))return'Opera';if(Pa(_0x594562))return'IEMobile';if(_0x594562['includes']('msie')||_0x594562['includes']('trident/'))return'IE';if(_0x594562['includes']('edge/'))return'Edge';if(Ra(_0x594562))return'Firefox';if(_0x594562['includes']('silk/'))return'Silk';if(Oa(_0x594562))return'Blackberry';if(Da(_0x594562))return'Webos';if(Aa(_0x594562))return'Safari';if((_0x594562['includes']('chrome/')||ka(_0x594562))&&!_0x594562['includes']('edge/'))return'Chrome';if(Na(_0x594562))return'Android';{const _0x4dae7c=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x4a0424=_0x145dd2['match'](_0x4dae7c);if((_0x4a0424==null?void 0x0:_0x4a0424['length'])===0x2)return _0x4a0424[0x1];}return'Other';}function Ra(_0x5a22ac=W()){return/firefox\//i['test'](_0x5a22ac);}function Aa(_0x6c9d58=W()){const _0x46e5ab=_0x6c9d58['toLowerCase']();return _0x46e5ab['includes']('safari/')&&!_0x46e5ab['includes']('chrome/')&&!_0x46e5ab['includes']('crios/')&&!_0x46e5ab['includes']('android');}function ka(_0x4cbbb3=W()){return/crios\//i['test'](_0x4cbbb3);}function Pa(_0x38ea4a=W()){return/iemobile/i['test'](_0x38ea4a);}function Na(_0x111b04=W()){return/android/i['test'](_0x111b04);}function Oa(_0x1cd6e7=W()){return/blackberry/i['test'](_0x1cd6e7);}function Da(_0x44720c=W()){return/webos/i['test'](_0x44720c);}function Ss(_0x43b5d4=W()){return/iphone|ipad|ipod/i['test'](_0x43b5d4)||/macintosh/i['test'](_0x43b5d4)&&/mobile/i['test'](_0x43b5d4);}function Rf(_0x3a96df=W()){var _0x418c1a;return Ss(_0x3a96df)&&!!((_0x418c1a=window['navigator'])!=null&&_0x418c1a['standalone']);}function Af(){return pc()&&document['documentMode']===0xa;}function Ma(_0x2d4aba=W()){return Ss(_0x2d4aba)||Na(_0x2d4aba)||Da(_0x2d4aba)||Oa(_0x2d4aba)||/windows phone/i['test'](_0x2d4aba)||Pa(_0x2d4aba);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x1dbfec,_0x42bfd2=[]){let _0x438cfb;switch(_0x1dbfec){case'Browser':_0x438cfb=br(W());break;case'Worker':_0x438cfb=br(W())+'-'+_0x1dbfec;break;default:_0x438cfb=_0x1dbfec;}const _0x5c25a3=_0x42bfd2['length']?_0x42bfd2['join'](','):'FirebaseCore-web';return _0x438cfb+'/JsCore/'+dt+'/'+_0x5c25a3;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x5f4642){this['auth']=_0x5f4642,this['queue']=[];}['pushCallback'](_0xa6e87,_0x2768a6){const _0x40a288=_0xc07bb0=>new Promise((_0x316dc3,_0x598fe7)=>{try{const _0x555dcf=_0xa6e87(_0xc07bb0);_0x316dc3(_0x555dcf);}catch(_0x570b7d){_0x598fe7(_0x570b7d);}});_0x40a288['onAbort']=_0x2768a6,this['queue']['push'](_0x40a288);const _0x2a1193=this['queue']['length']-0x1;return()=>{this['queue'][_0x2a1193]=()=>Promise['resolve']();};}async['runMiddleware'](_0x5057fb){if(this['auth']['currentUser']===_0x5057fb)return;const _0x17653c=[];try{for(const _0x57d125 of this['queue'])await _0x57d125(_0x5057fb),_0x57d125['onAbort']&&_0x17653c['push'](_0x57d125['onAbort']);}catch(_0x33cea3){_0x17653c['reverse']();for(const _0x514957 of _0x17653c)try{_0x514957();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x33cea3==null?void 0x0:_0x33cea3['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Pf(_0x3fb2f3,_0x2e3b40={}){return Pe(_0x3fb2f3,'GET','/v2/passwordPolicy',ke(_0x3fb2f3,_0x2e3b40));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Nf=0x6;class Of{constructor(_0x11d6b9){var _0x42d637;const _0x5d4374=_0x11d6b9['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x5d4374['minPasswordLength']??Nf,_0x5d4374['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x5d4374['maxPasswordLength']),_0x5d4374['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x5d4374['containsLowercaseCharacter']),_0x5d4374['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x5d4374['containsUppercaseCharacter']),_0x5d4374['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x5d4374['containsNumericCharacter']),_0x5d4374['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x5d4374['containsNonAlphanumericCharacter']),this['enforcementState']=_0x11d6b9['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x42d637=_0x11d6b9['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x42d637['join'](''))??'',this['forceUpgradeOnSignin']=_0x11d6b9['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x11d6b9['schemaVersion'];}['validatePassword'](_0x4d42c2){const _0x47ef74={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x4d42c2,_0x47ef74),this['validatePasswordCharacterOptions'](_0x4d42c2,_0x47ef74),_0x47ef74['isValid']&&(_0x47ef74['isValid']=_0x47ef74['meetsMinPasswordLength']??!0x0),_0x47ef74['isValid']&&(_0x47ef74['isValid']=_0x47ef74['meetsMaxPasswordLength']??!0x0),_0x47ef74['isValid']&&(_0x47ef74['isValid']=_0x47ef74['containsLowercaseLetter']??!0x0),_0x47ef74['isValid']&&(_0x47ef74['isValid']=_0x47ef74['containsUppercaseLetter']??!0x0),_0x47ef74['isValid']&&(_0x47ef74['isValid']=_0x47ef74['containsNumericCharacter']??!0x0),_0x47ef74['isValid']&&(_0x47ef74['isValid']=_0x47ef74['containsNonAlphanumericCharacter']??!0x0),_0x47ef74;}['validatePasswordLengthOptions'](_0x107d76,_0x3172c2){const _0xea1429=this['customStrengthOptions']['minPasswordLength'],_0x768209=this['customStrengthOptions']['maxPasswordLength'];_0xea1429&&(_0x3172c2['meetsMinPasswordLength']=_0x107d76['length']>=_0xea1429),_0x768209&&(_0x3172c2['meetsMaxPasswordLength']=_0x107d76['length']<=_0x768209);}['validatePasswordCharacterOptions'](_0x3c9724,_0x1583c3){this['updatePasswordCharacterOptionsStatuses'](_0x1583c3,!0x1,!0x1,!0x1,!0x1);let _0x580ba8;for(let _0x26a518=0x0;_0x26a518<_0x3c9724['length'];_0x26a518++)_0x580ba8=_0x3c9724['charAt'](_0x26a518),this['updatePasswordCharacterOptionsStatuses'](_0x1583c3,_0x580ba8>='a'&&_0x580ba8<='z',_0x580ba8>='A'&&_0x580ba8<='Z',_0x580ba8>='0'&&_0x580ba8<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x580ba8));}['updatePasswordCharacterOptionsStatuses'](_0x1c5575,_0x4686ff,_0x521349,_0x1ca1c5,_0x11bbad){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x1c5575['containsLowercaseLetter']||(_0x1c5575['containsLowercaseLetter']=_0x4686ff)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x1c5575['containsUppercaseLetter']||(_0x1c5575['containsUppercaseLetter']=_0x521349)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x1c5575['containsNumericCharacter']||(_0x1c5575['containsNumericCharacter']=_0x1ca1c5)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x1c5575['containsNonAlphanumericCharacter']||(_0x1c5575['containsNonAlphanumericCharacter']=_0x11bbad));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Df{constructor(_0x36d3dd,_0x1b1722,_0x3be9d3,_0x31ee8f){this['app']=_0x36d3dd,this['heartbeatServiceProvider']=_0x1b1722,this['appCheckServiceProvider']=_0x3be9d3,this['config']=_0x31ee8f,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new kf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x36d3dd['name'],this['clientVersion']=_0x31ee8f['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x3249b1=>this['_resolvePersistenceManagerAvailable']=_0x3249b1);}['_initializeWithPersistence'](_0x4b4a9c,_0x367ddd){return _0x367ddd&&(this['_popupRedirectResolver']=ie(_0x367ddd)),this['_initializationPromise']=this['queue'](async()=>{var _0x533b65,_0x48607d,_0x3b6957;if(!this['_deleted']&&(this['persistenceManager']=await tt['create'](this,_0x4b4a9c),(_0x533b65=this['_resolvePersistenceManagerAvailable'])==null||_0x533b65['call'](this),!this['_deleted'])){if((_0x48607d=this['_popupRedirectResolver'])!=null&&_0x48607d['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x367ddd),this['lastNotifiedUid']=((_0x3b6957=this['currentUser'])==null?void 0x0:_0x3b6957['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x42b537=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x42b537)){if(this['currentUser']&&_0x42b537&&this['currentUser']['uid']===_0x42b537['uid']){this['_currentUser']['_assign'](_0x42b537),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x42b537,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x495e54){try{const _0x67a55d=await Pn(this,{'idToken':_0x495e54}),_0x22cb47=await j['_fromGetAccountInfoResponse'](this,_0x67a55d,_0x495e54);await this['directlySetCurrentUser'](_0x22cb47);}catch(_0x33b8f7){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x33b8f7),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x1b5ab5){var _0x7dfd50;if($(this['app'])){const _0x3aba15=this['app']['settings']['authIdToken'];return _0x3aba15?new Promise(_0x2085d4=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x3aba15)['then'](_0x2085d4,_0x2085d4));}):this['directlySetCurrentUser'](null);}const _0x164116=await this['assertedPersistence']['getCurrentUser']();let _0x5d5df6=_0x164116,_0x5f0be0=!0x1;if(_0x1b5ab5&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x3f7524=(_0x7dfd50=this['redirectUser'])==null?void 0x0:_0x7dfd50['_redirectEventId'],_0x1c7869=_0x5d5df6==null?void 0x0:_0x5d5df6['_redirectEventId'],_0x3ab7f3=await this['tryRedirectSignIn'](_0x1b5ab5);(!_0x3f7524||_0x3f7524===_0x1c7869)&&(_0x3ab7f3!=null&&_0x3ab7f3['user'])&&(_0x5d5df6=_0x3ab7f3['user'],_0x5f0be0=!0x0);}if(!_0x5d5df6)return this['directlySetCurrentUser'](null);if(!_0x5d5df6['_redirectEventId']){if(_0x5f0be0)try{await this['beforeStateQueue']['runMiddleware'](_0x5d5df6);}catch(_0x3ad38f){_0x5d5df6=_0x164116,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x3ad38f));}return _0x5d5df6?this['reloadAndSetCurrentUserOrClear'](_0x5d5df6):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x5d5df6['_redirectEventId']?this['directlySetCurrentUser'](_0x5d5df6):this['reloadAndSetCurrentUserOrClear'](_0x5d5df6);}async['tryRedirectSignIn'](_0x50abcf){let _0x411c50=null;try{_0x411c50=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x50abcf,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x411c50;}async['reloadAndSetCurrentUserOrClear'](_0x411c36){try{await Nn(_0x411c36);}catch(_0x557e22){if((_0x557e22==null?void 0x0:_0x557e22['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x411c36);}['useDeviceLanguage'](){this['languageCode']=uf();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x3c66fc){if($(this['app']))return Promise['reject'](re(this));const _0x4fd870=_0x3c66fc?P(_0x3c66fc):null;return _0x4fd870&&m(_0x4fd870['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x4fd870&&_0x4fd870['_clone'](this));}async['_updateCurrentUser'](_0x19f1ec,_0x3ae296=!0x1){if(!this['_deleted'])return _0x19f1ec&&m(this['tenantId']===_0x19f1ec['tenantId'],this,'tenant-id-mismatch'),_0x3ae296||await this['beforeStateQueue']['runMiddleware'](_0x19f1ec),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x19f1ec),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x33b8a2){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x33b8a2));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x21654c){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x58cffc=this['_getPasswordPolicyInternal']();return _0x58cffc['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x58cffc['validatePassword'](_0x21654c);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x326870=await Pf(this),_0x3f1dff=new Of(_0x326870);this['tenantId']===null?this['_projectPasswordPolicy']=_0x3f1dff:this['_tenantPasswordPolicies'][this['tenantId']]=_0x3f1dff;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x513a4d){this['_errorFactory']=new Gt('auth','Firebase',_0x513a4d());}['onAuthStateChanged'](_0x586c86,_0x4fe791,_0x235ec8){return this['registerStateListener'](this['authStateSubscription'],_0x586c86,_0x4fe791,_0x235ec8);}['beforeAuthStateChanged'](_0x395a82,_0x22565d){return this['beforeStateQueue']['pushCallback'](_0x395a82,_0x22565d);}['onIdTokenChanged'](_0x561ca8,_0x4a8087,_0x4711cb){return this['registerStateListener'](this['idTokenSubscription'],_0x561ca8,_0x4a8087,_0x4711cb);}['authStateReady'](){return new Promise((_0xa94b49,_0x960d6c)=>{if(this['currentUser'])_0xa94b49();else{const _0x8befa9=this['onAuthStateChanged'](()=>{_0x8befa9(),_0xa94b49();},_0x960d6c);}});}async['revokeAccessToken'](_0x3ea0b6){if(this['currentUser']){const _0x3b2944=await this['currentUser']['getIdToken'](),_0x2db4ad={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x3ea0b6,'idToken':_0x3b2944};this['tenantId']!=null&&(_0x2db4ad['tenantId']=this['tenantId']),await bf(this,_0x2db4ad);}}['toJSON'](){var _0x544adc;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x544adc=this['_currentUser'])==null?void 0x0:_0x544adc['toJSON']()};}async['_setRedirectUser'](_0x4fc52b,_0x36501f){const _0x59bdbd=await this['getOrInitRedirectPersistenceManager'](_0x36501f);return _0x4fc52b===null?_0x59bdbd['removeCurrentUser']():_0x59bdbd['setCurrentUser'](_0x4fc52b);}async['getOrInitRedirectPersistenceManager'](_0x4ff969){if(!this['redirectPersistenceManager']){const _0x331680=_0x4ff969&&ie(_0x4ff969)||this['_popupRedirectResolver'];m(_0x331680,this,'argument-error'),this['redirectPersistenceManager']=await tt['create'](this,[ie(_0x331680['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x1ca13f){var _0x4f4feb,_0x2b2b2b;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x4f4feb=this['_currentUser'])==null?void 0x0:_0x4f4feb['_redirectEventId'])===_0x1ca13f?this['_currentUser']:((_0x2b2b2b=this['redirectUser'])==null?void 0x0:_0x2b2b2b['_redirectEventId'])===_0x1ca13f?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x57078a){if(_0x57078a===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x57078a));}['_notifyListenersIfCurrent'](_0x1d8eea){_0x1d8eea===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x2550b1;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x2b69d0=((_0x2550b1=this['currentUser'])==null?void 0x0:_0x2550b1['uid'])??null;this['lastNotifiedUid']!==_0x2b69d0&&(this['lastNotifiedUid']=_0x2b69d0,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x34b65b,_0x228aaf,_0x2a8c52,_0x4c6544){if(this['_deleted'])return()=>{};const _0x708105=typeof _0x228aaf=='function'?_0x228aaf:_0x228aaf['next']['bind'](_0x228aaf);let _0x16b6e0=!0x1;const _0x4f12ac=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x4f12ac,this,'internal-error'),_0x4f12ac['then'](()=>{_0x16b6e0||_0x708105(this['currentUser']);}),typeof _0x228aaf=='function'){const _0x2e906e=_0x34b65b['addObserver'](_0x228aaf,_0x2a8c52,_0x4c6544);return()=>{_0x16b6e0=!0x0,_0x2e906e();};}else{const _0x19fa99=_0x34b65b['addObserver'](_0x228aaf);return()=>{_0x16b6e0=!0x0,_0x19fa99();};}}async['directlySetCurrentUser'](_0x36cd36){this['currentUser']&&this['currentUser']!==_0x36cd36&&this['_currentUser']['_stopProactiveRefresh'](),_0x36cd36&&this['isProactiveRefreshEnabled']&&_0x36cd36['_startProactiveRefresh'](),this['currentUser']=_0x36cd36,_0x36cd36?await this['assertedPersistence']['setCurrentUser'](_0x36cd36):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x3caf6e){return this['operations']=this['operations']['then'](_0x3caf6e,_0x3caf6e),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x5eb975){!_0x5eb975||this['frameworks']['includes'](_0x5eb975)||(this['frameworks']['push'](_0x5eb975),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x1f8373;const _0x5c6959={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x5c6959['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x58adee=await((_0x1f8373=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x1f8373['getHeartbeatsHeader']());_0x58adee&&(_0x5c6959['X-Firebase-Client']=_0x58adee);const _0x51dab2=await this['_getAppCheckToken']();return _0x51dab2&&(_0x5c6959['X-Firebase-AppCheck']=_0x51dab2),_0x5c6959;}async['_getAppCheckToken'](){var _0x8cbafa;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x187b70=await((_0x8cbafa=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x8cbafa['getToken']());return _0x187b70!=null&&_0x187b70['error']&&cf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x187b70['error']),_0x187b70==null?void 0x0:_0x187b70['token'];}}function Ke(_0x47c99c){return P(_0x47c99c);}class Rr{constructor(_0x5ac638){this['auth']=_0x5ac638,this['observer']=null,this['addObserver']=Tc(_0x590d47=>this['observer']=_0x590d47);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Mf(_0x368089){Jn=_0x368089;}function xa(_0x2bc647){return Jn['loadJS'](_0x2bc647);}function Lf(){return Jn['recaptchaEnterpriseScript'];}function xf(){return Jn['gapiScript'];}function Ff(_0xf841d1){return'__'+_0xf841d1+Math['floor'](Math['random']()*0xf4240);}class Uf{constructor(){this['enterprise']=new Wf();}['ready'](_0x657505){_0x657505();}['execute'](_0x27a169,_0x32a651){return Promise['resolve']('token');}['render'](_0x4d043d,_0xf99b0c){return'';}}class Wf{['ready'](_0x408843){_0x408843();}['execute'](_0x711b15,_0x5e8bda){return Promise['resolve']('token');}['render'](_0x5788da,_0xa19501){return'';}}const Bf='recaptcha-enterprise',Fa='NO_RECAPTCHA',Ar='onFirebaseAuthREInstanceReady';class he{constructor(_0x4eb4c8){this['type']=Bf,this['auth']=Ke(_0x4eb4c8);}async['verify'](_0x1ce308='verify',_0x52c56d=!0x1){async function _0x1896ae(_0x4e9ece){if(!_0x52c56d){if(_0x4e9ece['tenantId']==null&&_0x4e9ece['_agentRecaptchaConfig']!=null)return _0x4e9ece['_agentRecaptchaConfig']['siteKey'];if(_0x4e9ece['tenantId']!=null&&_0x4e9ece['_tenantRecaptchaConfigs'][_0x4e9ece['tenantId']]!==void 0x0)return _0x4e9ece['_tenantRecaptchaConfigs'][_0x4e9ece['tenantId']]['siteKey'];}return new Promise(async(_0x5b2905,_0x3383b0)=>{yf(_0x4e9ece,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x59b067=>{if(_0x59b067['recaptchaKey']===void 0x0)_0x3383b0(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x7d0981=new mf(_0x59b067);return _0x4e9ece['tenantId']==null?_0x4e9ece['_agentRecaptchaConfig']=_0x7d0981:_0x4e9ece['_tenantRecaptchaConfigs'][_0x4e9ece['tenantId']]=_0x7d0981,_0x5b2905(_0x7d0981['siteKey']);}})['catch'](_0x1367db=>{_0x3383b0(_0x1367db);});});}function _0x14d1cb(_0x71e67f,_0x1d3f48,_0x5ee48a){const _0x3cf8c3=window['grecaptcha'];wr(_0x3cf8c3)?_0x3cf8c3['enterprise']['ready'](()=>{_0x3cf8c3['enterprise']['execute'](_0x71e67f,{'action':_0x1ce308})['then'](_0x44de44=>{_0x1d3f48(_0x44de44);})['catch'](()=>{_0x1d3f48(Fa);});}):_0x5ee48a(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Uf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x1b3930,_0x59880d)=>{_0x1896ae(this['auth'])['then'](async _0x14ec42=>{if(!_0x52c56d&&wr(window['grecaptcha'])&&he['scriptInjectionDeferred'])await he['scriptInjectionDeferred']['promise'],_0x14d1cb(_0x14ec42,_0x1b3930,_0x59880d);else{if(typeof window>'u'){_0x59880d(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0xfe2a6b=Lf();_0xfe2a6b['length']!==0x0&&(_0xfe2a6b+=_0x14ec42+('&onload='+Ar)),he['scriptInjectionDeferred']=new H(),window[Ar]=()=>{var _0x24b060;(_0x24b060=he['scriptInjectionDeferred'])==null||_0x24b060['resolve']();},xa(_0xfe2a6b)['then'](()=>{var _0x268ac2;return(_0x268ac2=he['scriptInjectionDeferred'])==null?void 0x0:_0x268ac2['promise'];})['then'](()=>{_0x14d1cb(_0x14ec42,_0x1b3930,_0x59880d);})['catch'](_0x4a04d1=>{_0x59880d(_0x4a04d1);});}})['catch'](_0x45d03a=>{_0x59880d(_0x45d03a);});});}}he['scriptInjectionDeferred']=null;async function kr(_0x361895,_0x49ad19,_0x57de35,_0x5e49f4=!0x1,_0x3c4909=!0x1){const _0xe2bafd=new he(_0x361895);let _0x31b8e0;if(_0x3c4909)_0x31b8e0=Fa;else try{_0x31b8e0=await _0xe2bafd['verify'](_0x57de35);}catch{_0x31b8e0=await _0xe2bafd['verify'](_0x57de35,!0x0);}const _0x3b9398={..._0x49ad19};if(_0x57de35==='mfaSmsEnrollment'||_0x57de35==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x3b9398){const _0x1f4186=_0x3b9398['phoneEnrollmentInfo']['phoneNumber'],_0x2ac5ea=_0x3b9398['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x3b9398,{'phoneEnrollmentInfo':{'phoneNumber':_0x1f4186,'recaptchaToken':_0x2ac5ea,'captchaResponse':_0x31b8e0,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x3b9398){const _0x2b692e=_0x3b9398['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x3b9398,{'phoneSignInInfo':{'recaptchaToken':_0x2b692e,'captchaResponse':_0x31b8e0,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x3b9398;}return _0x5e49f4?Object['assign'](_0x3b9398,{'captchaResp':_0x31b8e0}):Object['assign'](_0x3b9398,{'captchaResponse':_0x31b8e0}),Object['assign'](_0x3b9398,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x3b9398,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x3b9398;}async function xi(_0x4cf935,_0x4ff5cd,_0x182569,_0x80d63f,_0x1106c3){var _0x1c3f13;if((_0x1c3f13=_0x4cf935['_getRecaptchaConfig']())!=null&&_0x1c3f13['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x589645=await kr(_0x4cf935,_0x4ff5cd,_0x182569,_0x182569==='getOobCode');return _0x80d63f(_0x4cf935,_0x589645);}else return _0x80d63f(_0x4cf935,_0x4ff5cd)['catch'](async _0x532a9d=>{if(_0x532a9d['code']==='auth/missing-recaptcha-token'){console['log'](_0x182569+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x44965=await kr(_0x4cf935,_0x4ff5cd,_0x182569,_0x182569==='getOobCode');return _0x80d63f(_0x4cf935,_0x44965);}else return Promise['reject'](_0x532a9d);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Vf(_0x5f3745,_0x589af9){const _0xa211be=Hi(_0x5f3745,'auth');if(_0xa211be['isInitialized']()){const _0xa82e3c=_0xa211be['getImmediate'](),_0x55d5e5=_0xa211be['getOptions']();if(xe(_0x55d5e5,_0x589af9??{}))return _0xa82e3c;Y(_0xa82e3c,'already-initialized');}return _0xa211be['initialize']({'options':_0x589af9});}function Hf(_0x470f40,_0x443855){const _0x36917d=(_0x443855==null?void 0x0:_0x443855['persistence'])||[],_0x2b1c4a=(Array['isArray'](_0x36917d)?_0x36917d:[_0x36917d])['map'](ie);_0x443855!=null&&_0x443855['errorMap']&&_0x470f40['_updateErrorMap'](_0x443855['errorMap']),_0x470f40['_initializeWithPersistence'](_0x2b1c4a,_0x443855==null?void 0x0:_0x443855['popupRedirectResolver']);}function $f(_0x325340,_0x5dedb9,_0x4a6bcc){const _0x139bfd=Ke(_0x325340);m(/^https?:\/\//['test'](_0x5dedb9),_0x139bfd,'invalid-emulator-scheme');const _0x57011b=!0x1,_0x4e7a80=Ua(_0x5dedb9),{host:_0x5bc216,port:_0x405617}=Gf(_0x5dedb9),_0x1622b4=_0x405617===null?'':':'+_0x405617,_0x5e82d5={'url':_0x4e7a80+'//'+_0x5bc216+_0x1622b4+'/'},_0x12f0ee=Object['freeze']({'host':_0x5bc216,'port':_0x405617,'protocol':_0x4e7a80['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x57011b})});if(!_0x139bfd['_canInitEmulator']){m(_0x139bfd['config']['emulator']&&_0x139bfd['emulatorConfig'],_0x139bfd,'emulator-config-failed'),m(xe(_0x5e82d5,_0x139bfd['config']['emulator'])&&xe(_0x12f0ee,_0x139bfd['emulatorConfig']),_0x139bfd,'emulator-config-failed');return;}_0x139bfd['config']['emulator']=_0x5e82d5,_0x139bfd['emulatorConfig']=_0x12f0ee,_0x139bfd['settings']['appVerificationDisabledForTesting']=!0x0,qt(_0x5bc216)?Qr(_0x4e7a80+'//'+_0x5bc216+_0x1622b4):qf();}function Ua(_0x40f63f){const _0x590c6b=_0x40f63f['indexOf'](':');return _0x590c6b<0x0?'':_0x40f63f['substr'](0x0,_0x590c6b+0x1);}function Gf(_0x2db8f0){const _0x207941=Ua(_0x2db8f0),_0x25fdfb=/(\/\/)?([^?#/]+)/['exec'](_0x2db8f0['substr'](_0x207941['length']));if(!_0x25fdfb)return{'host':'','port':null};const _0x104798=_0x25fdfb[0x2]['split']('@')['pop']()||'',_0x4ce094=/^(\[[^\]]+\])(:|$)/['exec'](_0x104798);if(_0x4ce094){const _0x5ce41b=_0x4ce094[0x1];return{'host':_0x5ce41b,'port':Pr(_0x104798['substr'](_0x5ce41b['length']+0x1))};}else{const [_0x20496f,_0x44d09d]=_0x104798['split'](':');return{'host':_0x20496f,'port':Pr(_0x44d09d)};}}function Pr(_0xb74413){if(!_0xb74413)return null;const _0x30e02d=Number(_0xb74413);return isNaN(_0x30e02d)?null:_0x30e02d;}function qf(){function _0x59818e(){const _0x5827dd=document['createElement']('p'),_0x279aef=_0x5827dd['style'];_0x5827dd['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x279aef['position']='fixed',_0x279aef['width']='100%',_0x279aef['backgroundColor']='#ffffff',_0x279aef['border']='.1em\x20solid\x20#000000',_0x279aef['color']='#b50000',_0x279aef['bottom']='0px',_0x279aef['left']='0px',_0x279aef['margin']='0px',_0x279aef['zIndex']='10000',_0x279aef['textAlign']='center',_0x5827dd['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x5827dd);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x59818e):_0x59818e());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x1e7f38,_0xdcc5ed){this['providerId']=_0x1e7f38,this['signInMethod']=_0xdcc5ed;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x538fab){return ne('not\x20implemented');}['_linkToIdToken'](_0x1ce91d,_0x1c0278){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x14d7d6){return ne('not\x20implemented');}}async function zf(_0x3ccc2d,_0x2b9d92){return Pe(_0x3ccc2d,'POST','/v1/accounts:signUp',_0x2b9d92);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function jf(_0x3e57b0,_0x22b608){return en(_0x3e57b0,'POST','/v1/accounts:signInWithPassword',ke(_0x3e57b0,_0x22b608));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Kf(_0xfc5227,_0x23ca9c){return en(_0xfc5227,'POST','/v1/accounts:signInWithEmailLink',ke(_0xfc5227,_0x23ca9c));}async function Yf(_0x298030,_0x59be0b){return en(_0x298030,'POST','/v1/accounts:signInWithEmailLink',ke(_0x298030,_0x59be0b));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $t extends bs{constructor(_0x3b248d,_0x265d01,_0x33269e,_0x44c483=null){super('password',_0x33269e),this['_email']=_0x3b248d,this['_password']=_0x265d01,this['_tenantId']=_0x44c483;}static['_fromEmailAndPassword'](_0x1373e0,_0x7285d3){return new $t(_0x1373e0,_0x7285d3,'password');}static['_fromEmailAndCode'](_0x401877,_0x1af082,_0x24bd48=null){return new $t(_0x401877,_0x1af082,'emailLink',_0x24bd48);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x4321d2){const _0x4489b2=typeof _0x4321d2=='string'?JSON['parse'](_0x4321d2):_0x4321d2;if(_0x4489b2!=null&&_0x4489b2['email']&&(_0x4489b2!=null&&_0x4489b2['password'])){if(_0x4489b2['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x4489b2['email'],_0x4489b2['password']);if(_0x4489b2['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x4489b2['email'],_0x4489b2['password'],_0x4489b2['tenantId']);}return null;}async['_getIdTokenResponse'](_0x3a6e1b){switch(this['signInMethod']){case'password':const _0x346253={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x3a6e1b,_0x346253,'signInWithPassword',jf);case'emailLink':return Kf(_0x3a6e1b,{'email':this['_email'],'oobCode':this['_password']});default:Y(_0x3a6e1b,'internal-error');}}async['_linkToIdToken'](_0x221672,_0x543fb4){switch(this['signInMethod']){case'password':const _0x307032={'idToken':_0x543fb4,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return xi(_0x221672,_0x307032,'signUpPassword',zf);case'emailLink':return Yf(_0x221672,{'idToken':_0x543fb4,'email':this['_email'],'oobCode':this['_password']});default:Y(_0x221672,'internal-error');}}['_getReauthenticationResolver'](_0x3f7a54){return this['_getIdTokenResponse'](_0x3f7a54);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function nt(_0x1cacd4,_0x530f62){return en(_0x1cacd4,'POST','/v1/accounts:signInWithIdp',ke(_0x1cacd4,_0x530f62));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qf='http://localhost';class $e extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x2f2695){const _0x56110f=new $e(_0x2f2695['providerId'],_0x2f2695['signInMethod']);return _0x2f2695['idToken']||_0x2f2695['accessToken']?(_0x2f2695['idToken']&&(_0x56110f['idToken']=_0x2f2695['idToken']),_0x2f2695['accessToken']&&(_0x56110f['accessToken']=_0x2f2695['accessToken']),_0x2f2695['nonce']&&!_0x2f2695['pendingToken']&&(_0x56110f['nonce']=_0x2f2695['nonce']),_0x2f2695['pendingToken']&&(_0x56110f['pendingToken']=_0x2f2695['pendingToken'])):_0x2f2695['oauthToken']&&_0x2f2695['oauthTokenSecret']?(_0x56110f['accessToken']=_0x2f2695['oauthToken'],_0x56110f['secret']=_0x2f2695['oauthTokenSecret']):Y('argument-error'),_0x56110f;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x43dc99){const _0x75f35=typeof _0x43dc99=='string'?JSON['parse'](_0x43dc99):_0x43dc99,{providerId:_0x2689db,signInMethod:_0x3b58c9,..._0x359e3e}=_0x75f35;if(!_0x2689db||!_0x3b58c9)return null;const _0x4f2e16=new $e(_0x2689db,_0x3b58c9);return _0x4f2e16['idToken']=_0x359e3e['idToken']||void 0x0,_0x4f2e16['accessToken']=_0x359e3e['accessToken']||void 0x0,_0x4f2e16['secret']=_0x359e3e['secret'],_0x4f2e16['nonce']=_0x359e3e['nonce'],_0x4f2e16['pendingToken']=_0x359e3e['pendingToken']||null,_0x4f2e16;}['_getIdTokenResponse'](_0x1d2d8d){const _0x7ffa84=this['buildRequest']();return nt(_0x1d2d8d,_0x7ffa84);}['_linkToIdToken'](_0x424a2f,_0x1a4a06){const _0x4b5ff1=this['buildRequest']();return _0x4b5ff1['idToken']=_0x1a4a06,nt(_0x424a2f,_0x4b5ff1);}['_getReauthenticationResolver'](_0x2be9c5){const _0x42663b=this['buildRequest']();return _0x42663b['autoCreate']=!0x1,nt(_0x2be9c5,_0x42663b);}['buildRequest'](){const _0x92b99a={'requestUri':Qf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x92b99a['pendingToken']=this['pendingToken'];else{const _0x46ae36={};this['idToken']&&(_0x46ae36['id_token']=this['idToken']),this['accessToken']&&(_0x46ae36['access_token']=this['accessToken']),this['secret']&&(_0x46ae36['oauth_token_secret']=this['secret']),_0x46ae36['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x46ae36['nonce']=this['nonce']),_0x92b99a['postBody']=ut(_0x46ae36);}return _0x92b99a;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Jf(_0x2a48bc){switch(_0x2a48bc){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Xf(_0x2f0ebc){const _0x3dbae9=Ct(Tt(_0x2f0ebc))['link'],_0x38c713=_0x3dbae9?Ct(Tt(_0x3dbae9))['deep_link_id']:null,_0x4c7d5a=Ct(Tt(_0x2f0ebc))['deep_link_id'];return(_0x4c7d5a?Ct(Tt(_0x4c7d5a))['link']:null)||_0x4c7d5a||_0x38c713||_0x3dbae9||_0x2f0ebc;}class Rs{constructor(_0x42dea0){const _0x36bda5=Ct(Tt(_0x42dea0)),_0x3f36e0=_0x36bda5['apiKey']??null,_0x5a1ad4=_0x36bda5['oobCode']??null,_0x34c254=Jf(_0x36bda5['mode']??null);m(_0x3f36e0&&_0x5a1ad4&&_0x34c254,'argument-error'),this['apiKey']=_0x3f36e0,this['operation']=_0x34c254,this['code']=_0x5a1ad4,this['continueUrl']=_0x36bda5['continueUrl']??null,this['languageCode']=_0x36bda5['lang']??null,this['tenantId']=_0x36bda5['tenantId']??null;}static['parseLink'](_0x5e61f2){const _0x121040=Xf(_0x5e61f2);try{return new Rs(_0x121040);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yt{constructor(){this['providerId']=yt['PROVIDER_ID'];}static['credential'](_0xa0e673,_0x5a3cc5){return $t['_fromEmailAndPassword'](_0xa0e673,_0x5a3cc5);}static['credentialWithLink'](_0x1f6fd9,_0x5d3e10){const _0x1e432e=Rs['parseLink'](_0x5d3e10);return m(_0x1e432e,'argument-error'),$t['_fromEmailAndCode'](_0x1f6fd9,_0x1e432e['code'],_0x1e432e['tenantId']);}}yt['PROVIDER_ID']='password',yt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',yt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x4bc9e4){this['providerId']=_0x4bc9e4,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x317386){this['defaultLanguageCode']=_0x317386;}['setCustomParameters'](_0x4bd08d){return this['customParameters']=_0x4bd08d,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tn extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x3ea4d1){return this['scopes']['includes'](_0x3ea4d1)||this['scopes']['push'](_0x3ea4d1),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends tn{constructor(){super('facebook.com');}static['credential'](_0x475776){return $e['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x475776});}static['credentialFromResult'](_0x19d1d3){return ue['credentialFromTaggedObject'](_0x19d1d3);}static['credentialFromError'](_0x524fc3){return ue['credentialFromTaggedObject'](_0x524fc3['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1ab0ab}){if(!_0x1ab0ab||!('oauthAccessToken'in _0x1ab0ab)||!_0x1ab0ab['oauthAccessToken'])return null;try{return ue['credential'](_0x1ab0ab['oauthAccessToken']);}catch{return null;}}}ue['FACEBOOK_SIGN_IN_METHOD']='facebook.com',ue['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends tn{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x30e623,_0x47e98d){return $e['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x30e623,'accessToken':_0x47e98d});}static['credentialFromResult'](_0x38a1c7){return de['credentialFromTaggedObject'](_0x38a1c7);}static['credentialFromError'](_0x572801){return de['credentialFromTaggedObject'](_0x572801['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x59bf67}){if(!_0x59bf67)return null;const {oauthIdToken:_0x52a4ac,oauthAccessToken:_0x313903}=_0x59bf67;if(!_0x52a4ac&&!_0x313903)return null;try{return de['credential'](_0x52a4ac,_0x313903);}catch{return null;}}}de['GOOGLE_SIGN_IN_METHOD']='google.com',de['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends tn{constructor(){super('github.com');}static['credential'](_0x39b1fd){return $e['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x39b1fd});}static['credentialFromResult'](_0x3ebfb6){return fe['credentialFromTaggedObject'](_0x3ebfb6);}static['credentialFromError'](_0x5cdf53){return fe['credentialFromTaggedObject'](_0x5cdf53['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x6a7c6f}){if(!_0x6a7c6f||!('oauthAccessToken'in _0x6a7c6f)||!_0x6a7c6f['oauthAccessToken'])return null;try{return fe['credential'](_0x6a7c6f['oauthAccessToken']);}catch{return null;}}}fe['GITHUB_SIGN_IN_METHOD']='github.com',fe['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pe extends tn{constructor(){super('twitter.com');}static['credential'](_0x43dda0,_0x28e00a){return $e['_fromParams']({'providerId':pe['PROVIDER_ID'],'signInMethod':pe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x43dda0,'oauthTokenSecret':_0x28e00a});}static['credentialFromResult'](_0x5f26a1){return pe['credentialFromTaggedObject'](_0x5f26a1);}static['credentialFromError'](_0x5a6486){return pe['credentialFromTaggedObject'](_0x5a6486['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x534d5f}){if(!_0x534d5f)return null;const {oauthAccessToken:_0x18edd3,oauthTokenSecret:_0x5137c7}=_0x534d5f;if(!_0x18edd3||!_0x5137c7)return null;try{return pe['credential'](_0x18edd3,_0x5137c7);}catch{return null;}}}pe['TWITTER_SIGN_IN_METHOD']='twitter.com',pe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Zf(_0x5a7655,_0x51fd02){return en(_0x5a7655,'POST','/v1/accounts:signUp',ke(_0x5a7655,_0x51fd02));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ge{constructor(_0x168543){this['user']=_0x168543['user'],this['providerId']=_0x168543['providerId'],this['_tokenResponse']=_0x168543['_tokenResponse'],this['operationType']=_0x168543['operationType'];}static async['_fromIdTokenResponse'](_0x2403aa,_0x2bb7c1,_0xa9904,_0x44c286=!0x1){const _0x47ea44=await j['_fromIdTokenResponse'](_0x2403aa,_0xa9904,_0x44c286),_0x299d72=Nr(_0xa9904);return new Ge({'user':_0x47ea44,'providerId':_0x299d72,'_tokenResponse':_0xa9904,'operationType':_0x2bb7c1});}static async['_forOperation'](_0x4445cb,_0x36767c,_0xf2d7d4){await _0x4445cb['_updateTokensIfNecessary'](_0xf2d7d4,!0x0);const _0x39824b=Nr(_0xf2d7d4);return new Ge({'user':_0x4445cb,'providerId':_0x39824b,'_tokenResponse':_0xf2d7d4,'operationType':_0x36767c});}}function Nr(_0x44fb8e){return _0x44fb8e['providerId']?_0x44fb8e['providerId']:'phoneNumber'in _0x44fb8e?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class On extends Re{constructor(_0x1cc95b,_0x630ed5,_0x4283f4,_0x412970){super(_0x630ed5['code'],_0x630ed5['message']),this['operationType']=_0x4283f4,this['user']=_0x412970,Object['setPrototypeOf'](this,On['prototype']),this['customData']={'appName':_0x1cc95b['name'],'tenantId':_0x1cc95b['tenantId']??void 0x0,'_serverResponse':_0x630ed5['customData']['_serverResponse'],'operationType':_0x4283f4};}static['_fromErrorAndOperation'](_0x7426ae,_0x2d8f22,_0x9393fa,_0x56dda3){return new On(_0x7426ae,_0x2d8f22,_0x9393fa,_0x56dda3);}}function Ba(_0x496d26,_0x400a65,_0x1e45af,_0x10f1b6){return(_0x400a65==='reauthenticate'?_0x1e45af['_getReauthenticationResolver'](_0x496d26):_0x1e45af['_getIdTokenResponse'](_0x496d26))['catch'](_0x56d3ca=>{throw _0x56d3ca['code']==='auth/multi-factor-auth-required'?On['_fromErrorAndOperation'](_0x496d26,_0x56d3ca,_0x400a65,_0x10f1b6):_0x56d3ca;});}async function ep(_0x44a4e8,_0x5143a7,_0x56263c=!0x1){const _0x40376e=await Ht(_0x44a4e8,_0x5143a7['_linkToIdToken'](_0x44a4e8['auth'],await _0x44a4e8['getIdToken']()),_0x56263c);return Ge['_forOperation'](_0x44a4e8,'link',_0x40376e);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function tp(_0x3f193e,_0x6e2fa0,_0x286599=!0x1){const {auth:_0x43ccb5}=_0x3f193e;if($(_0x43ccb5['app']))return Promise['reject'](re(_0x43ccb5));const _0x4980c7='reauthenticate';try{const _0x214de3=await Ht(_0x3f193e,Ba(_0x43ccb5,_0x4980c7,_0x6e2fa0,_0x3f193e),_0x286599);m(_0x214de3['idToken'],_0x43ccb5,'internal-error');const _0x600cc7=Ts(_0x214de3['idToken']);m(_0x600cc7,_0x43ccb5,'internal-error');const {sub:_0x31a190}=_0x600cc7;return m(_0x3f193e['uid']===_0x31a190,_0x43ccb5,'user-mismatch'),Ge['_forOperation'](_0x3f193e,_0x4980c7,_0x214de3);}catch(_0x5295fe){throw(_0x5295fe==null?void 0x0:_0x5295fe['code'])==='auth/user-not-found'&&Y(_0x43ccb5,'user-mismatch'),_0x5295fe;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x2e588d,_0x10d49e,_0x2b45a4=!0x1){if($(_0x2e588d['app']))return Promise['reject'](re(_0x2e588d));const _0x26ae25='signIn',_0x56d4e6=await Ba(_0x2e588d,_0x26ae25,_0x10d49e),_0x22097d=await Ge['_fromIdTokenResponse'](_0x2e588d,_0x26ae25,_0x56d4e6);return _0x2b45a4||await _0x2e588d['_updateCurrentUser'](_0x22097d['user']),_0x22097d;}async function np(_0xcca32d,_0x3a7c8e){return Va(Ke(_0xcca32d),_0x3a7c8e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0xb04e19){const _0x247c75=Ke(_0xb04e19);_0x247c75['_getPasswordPolicyInternal']()&&await _0x247c75['_updatePasswordPolicy']();}async function L_(_0x27542a,_0x2cd67c,_0x4033bd){if($(_0x27542a['app']))return Promise['reject'](re(_0x27542a));const _0x80131f=Ke(_0x27542a),_0x154250=await xi(_0x80131f,{'returnSecureToken':!0x0,'email':_0x2cd67c,'password':_0x4033bd,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Zf)['catch'](_0x1c8548=>{throw _0x1c8548['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x27542a),_0x1c8548;}),_0x4a39b9=await Ge['_fromIdTokenResponse'](_0x80131f,'signIn',_0x154250);return await _0x80131f['_updateCurrentUser'](_0x4a39b9['user']),_0x4a39b9;}function x_(_0x4d4431,_0x20c3b7,_0x3ce081){return $(_0x4d4431['app'])?Promise['reject'](re(_0x4d4431)):np(P(_0x4d4431),yt['credential'](_0x20c3b7,_0x3ce081))['catch'](async _0x239663=>{throw _0x239663['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x4d4431),_0x239663;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function F_(_0x377424,_0x2fc6fa){return P(_0x377424)['setPersistence'](_0x2fc6fa);}function ip(_0x43ac70,_0x7a3034,_0x567ed4,_0x115a9c){return P(_0x43ac70)['onIdTokenChanged'](_0x7a3034,_0x567ed4,_0x115a9c);}function sp(_0x39bb66,_0x8c45bb,_0x279771){return P(_0x39bb66)['beforeAuthStateChanged'](_0x8c45bb,_0x279771);}function U_(_0x126aeb,_0xe5f32d,_0x4a31fe,_0x4810bc){return P(_0x126aeb)['onAuthStateChanged'](_0xe5f32d,_0x4a31fe,_0x4810bc);}function W_(_0x435aeb){return P(_0x435aeb)['signOut']();}const Dn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x5584ce,_0x515df0){this['storageRetriever']=_0x5584ce,this['type']=_0x515df0;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](Dn,'1'),this['storage']['removeItem'](Dn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x4cb65e,_0x170839){return this['storage']['setItem'](_0x4cb65e,JSON['stringify'](_0x170839)),Promise['resolve']();}['_get'](_0x485cb4){const _0x21ff52=this['storage']['getItem'](_0x485cb4);return Promise['resolve'](_0x21ff52?JSON['parse'](_0x21ff52):null);}['_remove'](_0x5a7ea4){return this['storage']['removeItem'](_0x5a7ea4),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rp=0x3e8,op=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x4c7d49,_0x570bca)=>this['onStorageEvent'](_0x4c7d49,_0x570bca),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x476e62){for(const _0x4e2dd8 of Object['keys'](this['listeners'])){const _0x257b1a=this['storage']['getItem'](_0x4e2dd8),_0x484e20=this['localCache'][_0x4e2dd8];_0x257b1a!==_0x484e20&&_0x476e62(_0x4e2dd8,_0x484e20,_0x257b1a);}}['onStorageEvent'](_0x29515a,_0x3d5902=!0x1){if(!_0x29515a['key']){this['forAllChangedKeys']((_0x2a5e65,_0x423b3c,_0x1c3eb2)=>{this['notifyListeners'](_0x2a5e65,_0x1c3eb2);});return;}const _0x1dc916=_0x29515a['key'];_0x3d5902?this['detachListener']():this['stopPolling']();const _0x17b28d=()=>{const _0x32cbfd=this['storage']['getItem'](_0x1dc916);!_0x3d5902&&this['localCache'][_0x1dc916]===_0x32cbfd||this['notifyListeners'](_0x1dc916,_0x32cbfd);},_0x1c5762=this['storage']['getItem'](_0x1dc916);Af()&&_0x1c5762!==_0x29515a['newValue']&&_0x29515a['newValue']!==_0x29515a['oldValue']?setTimeout(_0x17b28d,op):_0x17b28d();}['notifyListeners'](_0x653bee,_0x479a64){this['localCache'][_0x653bee]=_0x479a64;const _0x182a15=this['listeners'][_0x653bee];if(_0x182a15){for(const _0x34cebe of Array['from'](_0x182a15))_0x34cebe(_0x479a64&&JSON['parse'](_0x479a64));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0xc38d36,_0xd995e2,_0x19850f)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0xc38d36,'oldValue':_0xd995e2,'newValue':_0x19850f}),!0x0);});},rp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x37a97f,_0x28b1e5){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x37a97f]||(this['listeners'][_0x37a97f]=new Set(),this['localCache'][_0x37a97f]=this['storage']['getItem'](_0x37a97f)),this['listeners'][_0x37a97f]['add'](_0x28b1e5);}['_removeListener'](_0x5f00aa,_0x4fd2a8){this['listeners'][_0x5f00aa]&&(this['listeners'][_0x5f00aa]['delete'](_0x4fd2a8),this['listeners'][_0x5f00aa]['size']===0x0&&delete this['listeners'][_0x5f00aa]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x21156d,_0x5f0d4d){await super['_set'](_0x21156d,_0x5f0d4d),this['localCache'][_0x21156d]=JSON['stringify'](_0x5f0d4d);}async['_get'](_0xee4d6c){const _0x5bb961=await super['_get'](_0xee4d6c);return this['localCache'][_0xee4d6c]=JSON['stringify'](_0x5bb961),_0x5bb961;}async['_remove'](_0x297c25){await super['_remove'](_0x297c25),delete this['localCache'][_0x297c25];}}Ga['type']='LOCAL';const ap=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x56db2d,_0x16bd0b){}['_removeListener'](_0x20a575,_0x27cdcc){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function cp(_0x323384){return Promise['all'](_0x323384['map'](async _0x38bf8d=>{try{return{'fulfilled':!0x0,'value':await _0x38bf8d};}catch(_0x551431){return{'fulfilled':!0x1,'reason':_0x551431};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xn{constructor(_0x50bd4c){this['eventTarget']=_0x50bd4c,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x1ca60b){const _0x562a39=this['receivers']['find'](_0x5caf49=>_0x5caf49['isListeningto'](_0x1ca60b));if(_0x562a39)return _0x562a39;const _0x46ba1a=new Xn(_0x1ca60b);return this['receivers']['push'](_0x46ba1a),_0x46ba1a;}['isListeningto'](_0x17ae5f){return this['eventTarget']===_0x17ae5f;}async['handleEvent'](_0x337e87){const _0x56f8e6=_0x337e87,{eventId:_0x20328c,eventType:_0x29b952,data:_0x5cb133}=_0x56f8e6['data'],_0x44132d=this['handlersMap'][_0x29b952];if(!(_0x44132d!=null&&_0x44132d['size']))return;_0x56f8e6['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x20328c,'eventType':_0x29b952});const _0x29bcb6=Array['from'](_0x44132d)['map'](async _0x492a2c=>_0x492a2c(_0x56f8e6['origin'],_0x5cb133)),_0x35d22a=await cp(_0x29bcb6);_0x56f8e6['ports'][0x0]['postMessage']({'status':'done','eventId':_0x20328c,'eventType':_0x29b952,'response':_0x35d22a});}['_subscribe'](_0x526707,_0x20f144){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x526707]||(this['handlersMap'][_0x526707]=new Set()),this['handlersMap'][_0x526707]['add'](_0x20f144);}['_unsubscribe'](_0x2601d8,_0x505e75){this['handlersMap'][_0x2601d8]&&_0x505e75&&this['handlersMap'][_0x2601d8]['delete'](_0x505e75),(!_0x505e75||this['handlersMap'][_0x2601d8]['size']===0x0)&&delete this['handlersMap'][_0x2601d8],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Xn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x58bc74='',_0x103f74=0xa){let _0x3d9ba2='';for(let _0x31b822=0x0;_0x31b822<_0x103f74;_0x31b822++)_0x3d9ba2+=Math['floor'](Math['random']()*0xa);return _0x58bc74+_0x3d9ba2;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class lp{constructor(_0x410d36){this['target']=_0x410d36,this['handlers']=new Set();}['removeMessageHandler'](_0x341be2){_0x341be2['messageChannel']&&(_0x341be2['messageChannel']['port1']['removeEventListener']('message',_0x341be2['onMessage']),_0x341be2['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x341be2);}async['_send'](_0x104a56,_0x165b01,_0x4f5737=0x32){const _0x124be7=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x124be7)throw new Error('connection_unavailable');let _0x2080d2,_0x326da6;return new Promise((_0x4e789b,_0x2dbee7)=>{const _0x63554c=As('',0x14);_0x124be7['port1']['start']();const _0x5195b8=setTimeout(()=>{_0x2dbee7(new Error('unsupported_event'));},_0x4f5737);_0x326da6={'messageChannel':_0x124be7,'onMessage'(_0x2d5d82){const _0x4ddfa5=_0x2d5d82;if(_0x4ddfa5['data']['eventId']===_0x63554c)switch(_0x4ddfa5['data']['status']){case'ack':clearTimeout(_0x5195b8),_0x2080d2=setTimeout(()=>{_0x2dbee7(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x2080d2),_0x4e789b(_0x4ddfa5['data']['response']);break;default:clearTimeout(_0x5195b8),clearTimeout(_0x2080d2),_0x2dbee7(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x326da6),_0x124be7['port1']['addEventListener']('message',_0x326da6['onMessage']),this['target']['postMessage']({'eventType':_0x104a56,'eventId':_0x63554c,'data':_0x165b01},[_0x124be7['port2']]);})['finally'](()=>{_0x326da6&&this['removeMessageHandler'](_0x326da6);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function hp(_0x18e5f4){Z()['location']['href']=_0x18e5f4;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function up(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function dp(){var _0x5a21c2;return((_0x5a21c2=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x5a21c2['controller'])||null;}function fp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',pp=0x1,Mn='firebaseLocalStorage',Ya='fbase_key';class nn{constructor(_0x13523f){this['request']=_0x13523f;}['toPromise'](){return new Promise((_0x115b2a,_0x1054c8)=>{this['request']['addEventListener']('success',()=>{_0x115b2a(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x1054c8(this['request']['error']);});});}}function Zn(_0x47002d,_0x49b5bb){return _0x47002d['transaction']([Mn],_0x49b5bb?'readwrite':'readonly')['objectStore'](Mn);}function _p(){const _0x2a8a47=indexedDB['deleteDatabase'](Ka);return new nn(_0x2a8a47)['toPromise']();}function Qa(){const _0x51ddba=indexedDB['open'](Ka,pp);return new Promise((_0x3bfc05,_0xb030a5)=>{_0x51ddba['addEventListener']('error',()=>{_0xb030a5(_0x51ddba['error']);}),_0x51ddba['addEventListener']('upgradeneeded',()=>{const _0x19f50c=_0x51ddba['result'];try{_0x19f50c['createObjectStore'](Mn,{'keyPath':Ya});}catch(_0x4abf76){_0xb030a5(_0x4abf76);}}),_0x51ddba['addEventListener']('success',async()=>{const _0x35fe34=_0x51ddba['result'];_0x35fe34['objectStoreNames']['contains'](Mn)?_0x3bfc05(_0x35fe34):(_0x35fe34['close'](),await _p(),_0x3bfc05(await Qa()));});});}async function Or(_0x5070c3,_0xaf7db,_0x5f0203){const _0x192499=Zn(_0x5070c3,!0x0)['put']({[Ya]:_0xaf7db,'value':_0x5f0203});return new nn(_0x192499)['toPromise']();}async function gp(_0x387e49,_0x2bc1ee){const _0x357879=Zn(_0x387e49,!0x1)['get'](_0x2bc1ee),_0x3347fa=await new nn(_0x357879)['toPromise']();return _0x3347fa===void 0x0?null:_0x3347fa['value'];}function Dr(_0x226738,_0x168879){const _0x1e3cff=Zn(_0x226738,!0x0)['delete'](_0x168879);return new nn(_0x1e3cff)['toPromise']();}const mp=0x320,yp=0x3;class Ja{constructor(){this['type']='LOCAL',this['dbPromise']=null,this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['dbPromise']?this['dbPromise']:(this['dbPromise']=Qa(),this['dbPromise']['catch'](()=>{this['dbPromise']=null;}),this['dbPromise']);}async['_withRetries'](_0x264692){let _0x38708e=0x0;for(;;)try{const _0x400abb=await this['_openDb']();return await _0x264692(_0x400abb);}catch(_0x3ebcbd){if(_0x38708e++>yp)throw _0x3ebcbd;this['dbPromise']&&((await this['dbPromise'])['close'](),this['dbPromise']=null);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Xn['_getInstance'](fp()),this['receiver']['_subscribe']('keyChanged',async(_0x531470,_0x13bb2e)=>({'keyProcessed':(await this['_poll']())['includes'](_0x13bb2e['key'])})),this['receiver']['_subscribe']('ping',async(_0x25d2cc,_0x4306c0)=>['keyChanged']);}async['initializeSender'](){var _0x1b9890,_0x1e8f3e;if(this['activeServiceWorker']=await up(),!this['activeServiceWorker'])return;this['sender']=new lp(this['activeServiceWorker']);const _0x94bc7a=await this['sender']['_send']('ping',{},0x320);_0x94bc7a&&(_0x1b9890=_0x94bc7a[0x0])!=null&&_0x1b9890['fulfilled']&&(_0x1e8f3e=_0x94bc7a[0x0])!=null&&_0x1e8f3e['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x326ad5){if(!(!this['sender']||!this['activeServiceWorker']||dp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x326ad5},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{return indexedDB?(await this['_withRetries'](async _0x339564=>{await Or(_0x339564,Dn,'1'),await Dr(_0x339564,Dn);}),!0x0):!0x1;}catch{}return!0x1;}async['_withPendingWrite'](_0x464b5f){this['pendingWrites']++;try{await _0x464b5f();}finally{this['pendingWrites']--;}}async['_set'](_0x47951d,_0x4066e4){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x5d05ed=>Or(_0x5d05ed,_0x47951d,_0x4066e4)),this['localCache'][_0x47951d]=_0x4066e4,this['notifyServiceWorker'](_0x47951d)));}async['_get'](_0x2f1857){const _0x2e5121=await this['_withRetries'](_0x505896=>gp(_0x505896,_0x2f1857));return this['localCache'][_0x2f1857]=_0x2e5121,_0x2e5121;}async['_remove'](_0x2cc1b2){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x299f16=>Dr(_0x299f16,_0x2cc1b2)),delete this['localCache'][_0x2cc1b2],this['notifyServiceWorker'](_0x2cc1b2)));}async['_poll'](){const _0xe1c072=await this['_withRetries'](_0x5f2b2c=>{const _0x76d19a=Zn(_0x5f2b2c,!0x1)['getAll']();return new nn(_0x76d19a)['toPromise']();});if(!_0xe1c072)return[];if(this['pendingWrites']!==0x0)return[];const _0x1e1a49=[],_0x1ad83a=new Set();if(_0xe1c072['length']!==0x0){for(const {fbase_key:_0x12f88c,value:_0x3696ee}of _0xe1c072)_0x1ad83a['add'](_0x12f88c),JSON['stringify'](this['localCache'][_0x12f88c])!==JSON['stringify'](_0x3696ee)&&(this['notifyListeners'](_0x12f88c,_0x3696ee),_0x1e1a49['push'](_0x12f88c));}for(const _0x330459 of Object['keys'](this['localCache']))this['localCache'][_0x330459]&&!_0x1ad83a['has'](_0x330459)&&(this['notifyListeners'](_0x330459,null),_0x1e1a49['push'](_0x330459));return _0x1e1a49;}['notifyListeners'](_0x5aa5c5,_0x3f6837){this['localCache'][_0x5aa5c5]=_0x3f6837;const _0x50ef6a=this['listeners'][_0x5aa5c5];if(_0x50ef6a){for(const _0x89d311 of Array['from'](_0x50ef6a))_0x89d311(_0x3f6837);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),mp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x139c2e,_0x43ca0b){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x139c2e]||(this['listeners'][_0x139c2e]=new Set(),this['_get'](_0x139c2e)),this['listeners'][_0x139c2e]['add'](_0x43ca0b);}['_removeListener'](_0x4afa3e,_0xef28a){this['listeners'][_0x4afa3e]&&(this['listeners'][_0x4afa3e]['delete'](_0xef28a),this['listeners'][_0x4afa3e]['size']===0x0&&delete this['listeners'][_0x4afa3e]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Ja['type']='LOCAL';const vp=Ja;new Zt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ep(_0x47ee90,_0x1a12a0){return _0x1a12a0?ie(_0x1a12a0):(m(_0x47ee90['_popupRedirectResolver'],_0x47ee90,'argument-error'),_0x47ee90['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x241659){super('custom','custom'),this['params']=_0x241659;}['_getIdTokenResponse'](_0x141f7d){return nt(_0x141f7d,this['_buildIdpRequest']());}['_linkToIdToken'](_0x85df26,_0x59d3a5){return nt(_0x85df26,this['_buildIdpRequest'](_0x59d3a5));}['_getReauthenticationResolver'](_0x1ef09a){return nt(_0x1ef09a,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x438048){const _0x361463={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x438048&&(_0x361463['idToken']=_0x438048),_0x361463;}}function Ip(_0x44e9a5){return Va(_0x44e9a5['auth'],new ks(_0x44e9a5),_0x44e9a5['bypassAuthState']);}function wp(_0x510a29){const {auth:_0xebfea5,user:_0x4b66a1}=_0x510a29;return m(_0x4b66a1,_0xebfea5,'internal-error'),tp(_0x4b66a1,new ks(_0x510a29),_0x510a29['bypassAuthState']);}async function Cp(_0x2a19d2){const {auth:_0x4b4afb,user:_0x11cef7}=_0x2a19d2;return m(_0x11cef7,_0x4b4afb,'internal-error'),ep(_0x11cef7,new ks(_0x2a19d2),_0x2a19d2['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xa{constructor(_0xea0a2c,_0x186c49,_0x35b69a,_0x109831,_0x564d3f=!0x1){this['auth']=_0xea0a2c,this['resolver']=_0x35b69a,this['user']=_0x109831,this['bypassAuthState']=_0x564d3f,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x186c49)?_0x186c49:[_0x186c49];}['execute'](){return new Promise(async(_0x1157cb,_0x262e45)=>{this['pendingPromise']={'resolve':_0x1157cb,'reject':_0x262e45};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x5cfe44){this['reject'](_0x5cfe44);}});}async['onAuthEvent'](_0x476585){const {urlResponse:_0x168c2a,sessionId:_0x1e1d4e,postBody:_0x1cd11a,tenantId:_0x2258ea,error:_0x594eab,type:_0x224c3e}=_0x476585;if(_0x594eab){this['reject'](_0x594eab);return;}const _0x4daa80={'auth':this['auth'],'requestUri':_0x168c2a,'sessionId':_0x1e1d4e,'tenantId':_0x2258ea||void 0x0,'postBody':_0x1cd11a||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x224c3e)(_0x4daa80));}catch(_0x17c269){this['reject'](_0x17c269);}}['onError'](_0x3aed60){this['reject'](_0x3aed60);}['getIdpTask'](_0x34e0b7){switch(_0x34e0b7){case'signInViaPopup':case'signInViaRedirect':return Ip;case'linkViaPopup':case'linkViaRedirect':return Cp;case'reauthViaPopup':case'reauthViaRedirect':return wp;default:Y(this['auth'],'internal-error');}}['resolve'](_0x4ad490){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x4ad490),this['unregisterAndCleanUp']();}['reject'](_0x552be9){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x552be9),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tp=new Zt(0x7d0,0x2710);class Xe extends Xa{constructor(_0x361ac0,_0x19a001,_0x191d7,_0x15281f,_0x474df4){super(_0x361ac0,_0x19a001,_0x15281f,_0x474df4),this['provider']=_0x191d7,this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']&&Xe['currentPopupAction']['cancel'](),Xe['currentPopupAction']=this;}async['executeNotNull'](){const _0x30536a=await this['execute']();return m(_0x30536a,this['auth'],'internal-error'),_0x30536a;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x4d0fb6=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x4d0fb6),this['authWindow']['associatedEvent']=_0x4d0fb6,this['resolver']['_originValidation'](this['auth'])['catch'](_0x10b2af=>{this['reject'](_0x10b2af);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x4a8a2d=>{_0x4a8a2d||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x1b69ee;return((_0x1b69ee=this['authWindow'])==null?void 0x0:_0x1b69ee['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Xe['currentPopupAction']=null;}['pollUserCancellation'](){const _0x54a4ca=()=>{var _0x46c4b5,_0x4d24c7;if((_0x4d24c7=(_0x46c4b5=this['authWindow'])==null?void 0x0:_0x46c4b5['window'])!=null&&_0x4d24c7['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x54a4ca,Tp['get']());};_0x54a4ca();}}Xe['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Sp='pendingRedirect',hn=new Map();class bp extends Xa{constructor(_0x5ee7c0,_0x24cebd,_0xa50290=!0x1){super(_0x5ee7c0,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x24cebd,void 0x0,_0xa50290),this['eventId']=null;}async['execute'](){let _0x86977f=hn['get'](this['auth']['_key']());if(!_0x86977f){try{const _0x2129b7=await Rp(this['resolver'],this['auth'])?await super['execute']():null;_0x86977f=()=>Promise['resolve'](_0x2129b7);}catch(_0x554a31){_0x86977f=()=>Promise['reject'](_0x554a31);}hn['set'](this['auth']['_key'](),_0x86977f);}return this['bypassAuthState']||hn['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x86977f();}async['onAuthEvent'](_0x1f5d58){if(_0x1f5d58['type']==='signInViaRedirect')return super['onAuthEvent'](_0x1f5d58);if(_0x1f5d58['type']==='unknown'){this['resolve'](null);return;}if(_0x1f5d58['eventId']){const _0x57d733=await this['auth']['_redirectUserForId'](_0x1f5d58['eventId']);if(_0x57d733)return this['user']=_0x57d733,super['onAuthEvent'](_0x1f5d58);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Rp(_0x3f80bc,_0x2a3894){const _0x2e4c00=Pp(_0x2a3894),_0x14c8d8=kp(_0x3f80bc);if(!await _0x14c8d8['_isAvailable']())return!0x1;const _0x40f188=await _0x14c8d8['_get'](_0x2e4c00)==='true';return await _0x14c8d8['_remove'](_0x2e4c00),_0x40f188;}function Ap(_0x250028,_0x373c62){hn['set'](_0x250028['_key'](),_0x373c62);}function kp(_0x58945b){return ie(_0x58945b['_redirectPersistence']);}function Pp(_0x2a9a84){return ln(Sp,_0x2a9a84['config']['apiKey'],_0x2a9a84['name']);}async function Np(_0x335de1,_0x286389,_0x53692d=!0x1){if($(_0x335de1['app']))return Promise['reject'](re(_0x335de1));const _0x5d51fd=Ke(_0x335de1),_0x50b6ce=Ep(_0x5d51fd,_0x286389),_0x1c2c51=await new bp(_0x5d51fd,_0x50b6ce,_0x53692d)['execute']();return _0x1c2c51&&!_0x53692d&&(delete _0x1c2c51['user']['_redirectEventId'],await _0x5d51fd['_persistUserIfCurrent'](_0x1c2c51['user']),await _0x5d51fd['_setRedirectUser'](null,_0x286389)),_0x1c2c51;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Op=0x258*0x3e8;class Dp{constructor(_0x2d4a78){this['auth']=_0x2d4a78,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x3a4edc){this['consumers']['add'](_0x3a4edc),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x3a4edc)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x3a4edc),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x1f302a){this['consumers']['delete'](_0x1f302a);}['onEvent'](_0x19b123){if(this['hasEventBeenHandled'](_0x19b123))return!0x1;let _0x3b39bf=!0x1;return this['consumers']['forEach'](_0x30a2be=>{this['isEventForConsumer'](_0x19b123,_0x30a2be)&&(_0x3b39bf=!0x0,this['sendToConsumer'](_0x19b123,_0x30a2be),this['saveEventToCache'](_0x19b123));}),this['hasHandledPotentialRedirect']||!Mp(_0x19b123)||(this['hasHandledPotentialRedirect']=!0x0,_0x3b39bf||(this['queuedRedirectEvent']=_0x19b123,_0x3b39bf=!0x0)),_0x3b39bf;}['sendToConsumer'](_0x495d01,_0x34918c){var _0x338304;if(_0x495d01['error']&&!Za(_0x495d01)){const _0x9a6cac=((_0x338304=_0x495d01['error']['code'])==null?void 0x0:_0x338304['split']('auth/')[0x1])||'internal-error';_0x34918c['onError'](X(this['auth'],_0x9a6cac));}else _0x34918c['onAuthEvent'](_0x495d01);}['isEventForConsumer'](_0x36cf92,_0x1723ec){const _0x3becd7=_0x1723ec['eventId']===null||!!_0x36cf92['eventId']&&_0x36cf92['eventId']===_0x1723ec['eventId'];return _0x1723ec['filter']['includes'](_0x36cf92['type'])&&_0x3becd7;}['hasEventBeenHandled'](_0x180c21){return Date['now']()-this['lastProcessedEventTime']>=Op&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Mr(_0x180c21));}['saveEventToCache'](_0x216241){this['cachedEventUids']['add'](Mr(_0x216241)),this['lastProcessedEventTime']=Date['now']();}}function Mr(_0x57f433){return[_0x57f433['type'],_0x57f433['eventId'],_0x57f433['sessionId'],_0x57f433['tenantId']]['filter'](_0x3cbd81=>_0x3cbd81)['join']('-');}function Za({type:_0x22711c,error:_0x41a898}){return _0x22711c==='unknown'&&(_0x41a898==null?void 0x0:_0x41a898['code'])==='auth/no-auth-event';}function Mp(_0x1c5a25){switch(_0x1c5a25['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Za(_0x1c5a25);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Lp(_0xb81e2e,_0x26a014={}){return Pe(_0xb81e2e,'GET','/v1/projects',_0x26a014);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const xp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Fp=/^https?/;async function Up(_0x54d82e){if(_0x54d82e['config']['emulator'])return;const {authorizedDomains:_0x37c880}=await Lp(_0x54d82e);for(const _0x24028c of _0x37c880)try{if(Wp(_0x24028c))return;}catch{}Y(_0x54d82e,'unauthorized-domain');}function Wp(_0x5e69a3){const _0x1f721f=Mi(),{protocol:_0x11ee98,hostname:_0x48fbc4}=new URL(_0x1f721f);if(_0x5e69a3['startsWith']('chrome-extension://')){const _0x3fb172=new URL(_0x5e69a3);return _0x3fb172['hostname']===''&&_0x48fbc4===''?_0x11ee98==='chrome-extension:'&&_0x5e69a3['replace']('chrome-extension://','')===_0x1f721f['replace']('chrome-extension://',''):_0x11ee98==='chrome-extension:'&&_0x3fb172['hostname']===_0x48fbc4;}if(!Fp['test'](_0x11ee98))return!0x1;if(xp['test'](_0x5e69a3))return _0x48fbc4===_0x5e69a3;const _0x51b5bc=_0x5e69a3['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x51b5bc+'|'+_0x51b5bc+')$','i')['test'](_0x48fbc4);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Zt(0x7530,0xea60);function Lr(){const _0x84829c=Z()['___jsl'];if(_0x84829c!=null&&_0x84829c['H']){for(const _0x24b954 of Object['keys'](_0x84829c['H']))if(_0x84829c['H'][_0x24b954]['r']=_0x84829c['H'][_0x24b954]['r']||[],_0x84829c['H'][_0x24b954]['L']=_0x84829c['H'][_0x24b954]['L']||[],_0x84829c['H'][_0x24b954]['r']=[..._0x84829c['H'][_0x24b954]['L']],_0x84829c['CP']){for(let _0x3c9dcd=0x0;_0x3c9dcd<_0x84829c['CP']['length'];_0x3c9dcd++)_0x84829c['CP'][_0x3c9dcd]=null;}}}function Vp(_0x15f81a){return new Promise((_0x411dc8,_0x308f5b)=>{var _0x287c1a,_0x794179,_0xf48fa9;function _0x5745cf(){Lr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x411dc8(gapi['iframes']['getContext']());},'ontimeout':()=>{Lr(),_0x308f5b(X(_0x15f81a,'network-request-failed'));},'timeout':Bp['get']()});}if((_0x794179=(_0x287c1a=Z()['gapi'])==null?void 0x0:_0x287c1a['iframes'])!=null&&_0x794179['Iframe'])_0x411dc8(gapi['iframes']['getContext']());else{if((_0xf48fa9=Z()['gapi'])!=null&&_0xf48fa9['load'])_0x5745cf();else{const _0x38e378=Ff('iframefcb');return Z()[_0x38e378]=()=>{gapi['load']?_0x5745cf():_0x308f5b(X(_0x15f81a,'network-request-failed'));},xa(xf()+'?onload='+_0x38e378)['catch'](_0x1f8cb1=>_0x308f5b(_0x1f8cb1));}}})['catch'](_0x56f315=>{throw un=null,_0x56f315;});}let un=null;function Hp(_0x3b9a75){return un=un||Vp(_0x3b9a75),un;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $p=new Zt(0x1388,0x3a98),Gp='__/auth/iframe',qp='emulator/auth/iframe',zp={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},jp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function Kp(_0x242706){const _0x3b679f=_0x242706['config'];m(_0x3b679f['authDomain'],_0x242706,'auth-domain-config-required');const _0x32806d=_0x3b679f['emulator']?Cs(_0x3b679f,qp):'https://'+_0x242706['config']['authDomain']+'/'+Gp,_0x55774b={'apiKey':_0x3b679f['apiKey'],'appName':_0x242706['name'],'v':dt},_0x1bc098=jp['get'](_0x242706['config']['apiHost']);_0x1bc098&&(_0x55774b['eid']=_0x1bc098);const _0x209d27=_0x242706['_getFrameworks']();return _0x209d27['length']&&(_0x55774b['fw']=_0x209d27['join'](',')),_0x32806d+'?'+ut(_0x55774b)['slice'](0x1);}async function Yp(_0x11cca7){const _0x189355=await Hp(_0x11cca7),_0x53a34c=Z()['gapi'];return m(_0x53a34c,_0x11cca7,'internal-error'),_0x189355['open']({'where':document['body'],'url':Kp(_0x11cca7),'messageHandlersFilter':_0x53a34c['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':zp,'dontclear':!0x0},_0x1f015b=>new Promise(async(_0xea2359,_0x345d52)=>{await _0x1f015b['restyle']({'setHideOnLeave':!0x1});const _0x50a2c3=X(_0x11cca7,'network-request-failed'),_0x43f98d=Z()['setTimeout'](()=>{_0x345d52(_0x50a2c3);},$p['get']());function _0x4e06b0(){Z()['clearTimeout'](_0x43f98d),_0xea2359(_0x1f015b);}_0x1f015b['ping'](_0x4e06b0)['then'](_0x4e06b0,()=>{_0x345d52(_0x50a2c3);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Jp=0x1f4,Xp=0x258,Zp='_blank',e_='http://localhost';class xr{constructor(_0x405cf1){this['window']=_0x405cf1,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function t_(_0x5ce10e,_0x5c3c7b,_0xfa07d5,_0xc327bd=Jp,_0xde90fe=Xp){const _0x4acac8=Math['max']((window['screen']['availHeight']-_0xde90fe)/0x2,0x0)['toString'](),_0x16335a=Math['max']((window['screen']['availWidth']-_0xc327bd)/0x2,0x0)['toString']();let _0x3bce0c='';const _0x3a0ec8={...Qp,'width':_0xc327bd['toString'](),'height':_0xde90fe['toString'](),'top':_0x4acac8,'left':_0x16335a},_0x4dbbd7=W()['toLowerCase']();_0xfa07d5&&(_0x3bce0c=ka(_0x4dbbd7)?Zp:_0xfa07d5),Ra(_0x4dbbd7)&&(_0x5c3c7b=_0x5c3c7b||e_,_0x3a0ec8['scrollbars']='yes');const _0xf92113=Object['entries'](_0x3a0ec8)['reduce']((_0xe2578,[_0x5c15e2,_0x648c9e])=>''+_0xe2578+_0x5c15e2+'='+_0x648c9e+',','');if(Rf(_0x4dbbd7)&&_0x3bce0c!=='_self')return n_(_0x5c3c7b||'',_0x3bce0c),new xr(null);const _0xde4d=window['open'](_0x5c3c7b||'',_0x3bce0c,_0xf92113);m(_0xde4d,_0x5ce10e,'popup-blocked');try{_0xde4d['focus']();}catch{}return new xr(_0xde4d);}function n_(_0x4759d6,_0x23cd5c){const _0x23b932=document['createElement']('a');_0x23b932['href']=_0x4759d6,_0x23b932['target']=_0x23cd5c;const _0x37f84c=document['createEvent']('MouseEvent');_0x37f84c['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x23b932['dispatchEvent'](_0x37f84c);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const i_='__/auth/handler',s_='emulator/auth/handler',r_=encodeURIComponent('fac');async function Fr(_0x507c27,_0x18f2a5,_0x363a4a,_0x116b86,_0x45fd41,_0x3e9216){m(_0x507c27['config']['authDomain'],_0x507c27,'auth-domain-config-required'),m(_0x507c27['config']['apiKey'],_0x507c27,'invalid-api-key');const _0x4ec916={'apiKey':_0x507c27['config']['apiKey'],'appName':_0x507c27['name'],'authType':_0x363a4a,'redirectUrl':_0x116b86,'v':dt,'eventId':_0x45fd41};if(_0x18f2a5 instanceof Wa){_0x18f2a5['setDefaultLanguage'](_0x507c27['languageCode']),_0x4ec916['providerId']=_0x18f2a5['providerId']||'',pn(_0x18f2a5['getCustomParameters']())||(_0x4ec916['customParameters']=JSON['stringify'](_0x18f2a5['getCustomParameters']()));for(const [_0xf31399,_0x23d037]of Object['entries']({}))_0x4ec916[_0xf31399]=_0x23d037;}if(_0x18f2a5 instanceof tn){const _0x1a0387=_0x18f2a5['getScopes']()['filter'](_0x1222ab=>_0x1222ab!=='');_0x1a0387['length']>0x0&&(_0x4ec916['scopes']=_0x1a0387['join'](','));}_0x507c27['tenantId']&&(_0x4ec916['tid']=_0x507c27['tenantId']);const _0x23de58=_0x4ec916;for(const _0x3da96a of Object['keys'](_0x23de58))_0x23de58[_0x3da96a]===void 0x0&&delete _0x23de58[_0x3da96a];const _0x3d4acd=await _0x507c27['_getAppCheckToken'](),_0x247937=_0x3d4acd?'#'+r_+'='+encodeURIComponent(_0x3d4acd):'';return o_(_0x507c27)+'?'+ut(_0x23de58)['slice'](0x1)+_0x247937;}function o_({config:_0x50eb10}){return _0x50eb10['emulator']?Cs(_0x50eb10,s_):'https://'+_0x50eb10['authDomain']+'/'+i_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const pi='webStorageSupport';class a_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Np,this['_overrideRedirectResult']=Ap;}async['_openPopup'](_0x2faf2d,_0x2359c6,_0x5538a2,_0x481c2a){var _0x7b2c0c;ce((_0x7b2c0c=this['eventManagers'][_0x2faf2d['_key']()])==null?void 0x0:_0x7b2c0c['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x2e3c04=await Fr(_0x2faf2d,_0x2359c6,_0x5538a2,Mi(),_0x481c2a);return t_(_0x2faf2d,_0x2e3c04,As());}async['_openRedirect'](_0x1dde4f,_0x51b107,_0x2be17b,_0x3e6e6a){await this['_originValidation'](_0x1dde4f);const _0x16bf4f=await Fr(_0x1dde4f,_0x51b107,_0x2be17b,Mi(),_0x3e6e6a);return hp(_0x16bf4f),new Promise(()=>{});}['_initialize'](_0xf433d){const _0x679105=_0xf433d['_key']();if(this['eventManagers'][_0x679105]){const {manager:_0x406bd5,promise:_0x4da781}=this['eventManagers'][_0x679105];return _0x406bd5?Promise['resolve'](_0x406bd5):(ce(_0x4da781,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x4da781);}const _0x1822b9=this['initAndGetManager'](_0xf433d);return this['eventManagers'][_0x679105]={'promise':_0x1822b9},_0x1822b9['catch'](()=>{delete this['eventManagers'][_0x679105];}),_0x1822b9;}async['initAndGetManager'](_0x1c8729){const _0x3278c4=await Yp(_0x1c8729),_0x3ef417=new Dp(_0x1c8729);return _0x3278c4['register']('authEvent',_0x2f802d=>(m(_0x2f802d==null?void 0x0:_0x2f802d['authEvent'],_0x1c8729,'invalid-auth-event'),{'status':_0x3ef417['onEvent'](_0x2f802d['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x1c8729['_key']()]={'manager':_0x3ef417},this['iframes'][_0x1c8729['_key']()]=_0x3278c4,_0x3ef417;}['_isIframeWebStorageSupported'](_0x105448,_0xda7be8){this['iframes'][_0x105448['_key']()]['send'](pi,{'type':pi},_0x329a7d=>{var _0xd292bf;const _0x3f9d47=(_0xd292bf=_0x329a7d==null?void 0x0:_0x329a7d[0x0])==null?void 0x0:_0xd292bf[pi];_0x3f9d47!==void 0x0&&_0xda7be8(!!_0x3f9d47),Y(_0x105448,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x34f1d7){const _0x4564d1=_0x34f1d7['_key']();return this['originValidationPromises'][_0x4564d1]||(this['originValidationPromises'][_0x4564d1]=Up(_0x34f1d7)),this['originValidationPromises'][_0x4564d1];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const c_=a_;var Ur='@firebase/auth',Wr='1.13.3';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class l_{constructor(_0x44cd06){this['auth']=_0x44cd06,this['internalListeners']=new Map();}['getUid'](){var _0x153c27;return this['assertAuthConfigured'](),((_0x153c27=this['auth']['currentUser'])==null?void 0x0:_0x153c27['uid'])||null;}async['getToken'](_0x2ef089){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x2ef089)}:null;}['addAuthTokenListener'](_0x2642a5){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x2642a5))return;const _0x2f4c94=this['auth']['onIdTokenChanged'](_0x3c7abe=>{_0x2642a5((_0x3c7abe==null?void 0x0:_0x3c7abe['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x2642a5,_0x2f4c94),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x2c8d70){this['assertAuthConfigured']();const _0x361f66=this['internalListeners']['get'](_0x2c8d70);_0x361f66&&(this['internalListeners']['delete'](_0x2c8d70),_0x361f66(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function h_(_0x346d9a){switch(_0x346d9a){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function u_(_0x1f50bd){st(new Fe('auth',(_0x49f3d9,{options:_0x2fff3c})=>{const _0x47aaa6=_0x49f3d9['getProvider']('app')['getImmediate'](),_0x347559=_0x49f3d9['getProvider']('heartbeat'),_0xaa4122=_0x49f3d9['getProvider']('app-check-internal'),{apiKey:_0x432c57,authDomain:_0x1df9f4}=_0x47aaa6['options'];m(_0x432c57&&!_0x432c57['includes'](':'),'invalid-api-key',{'appName':_0x47aaa6['name']});const _0x40efef={'apiKey':_0x432c57,'authDomain':_0x1df9f4,'clientPlatform':_0x1f50bd,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x1f50bd)},_0x2341ff=new Df(_0x47aaa6,_0x347559,_0xaa4122,_0x40efef);return Hf(_0x2341ff,_0x2fff3c),_0x2341ff;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x102ab1,_0x5f0cc6,_0x2b35ff)=>{_0x102ab1['getProvider']('auth-internal')['initialize']();})),st(new Fe('auth-internal',_0x147efe=>{const _0x52d1ea=Ke(_0x147efe['getProvider']('auth')['getImmediate']());return(_0x1777e0=>new l_(_0x1777e0))(_0x52d1ea);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),ye(Ur,Wr,h_(_0x1f50bd)),ye(Ur,Wr,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const d_=0x12c,f_=jr('authIdTokenMaxAge')||d_;let Br=null;const p_=_0x5f3a98=>async _0x32a805=>{const _0x22201e=_0x32a805&&await _0x32a805['getIdTokenResult'](),_0x4c1dca=_0x22201e&&(new Date()['getTime']()-Date['parse'](_0x22201e['issuedAtTime']))/0x3e8;if(_0x4c1dca&&_0x4c1dca>f_)return;const _0x397535=_0x22201e==null?void 0x0:_0x22201e['token'];Br!==_0x397535&&(Br=_0x397535,await fetch(_0x5f3a98,{'method':_0x397535?'POST':'DELETE','headers':_0x397535?{'Authorization':'Bearer\x20'+_0x397535}:{}}));};function B_(_0x31e5e9=Zr()){const _0x3afcff=Hi(_0x31e5e9,'auth');if(_0x3afcff['isInitialized']())return _0x3afcff['getImmediate']();const _0x3a5b41=Vf(_0x31e5e9,{'popupRedirectResolver':c_,'persistence':[vp,ap,za]}),_0x20ae83=jr('authTokenSyncURL');if(_0x20ae83&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x15e034=new URL(_0x20ae83,location['origin']);if(location['origin']===_0x15e034['origin']){const _0x10c1df=p_(_0x15e034['toString']());sp(_0x3a5b41,_0x10c1df,()=>_0x10c1df(_0x3a5b41['currentUser'])),ip(_0x3a5b41,_0x32c635=>_0x10c1df(_0x32c635));}}const _0x9373ad=qr('auth');return _0x9373ad&&$f(_0x3a5b41,'http://'+_0x9373ad),_0x3a5b41;}function __(){var _0x124aea;return((_0x124aea=document['getElementsByTagName']('head'))==null?void 0x0:_0x124aea[0x0])??document;}Mf({'loadJS'(_0x1aa6bd){return new Promise((_0x4b38a8,_0x26b396)=>{const _0x5b1660=document['createElement']('script');_0x5b1660['setAttribute']('src',_0x1aa6bd),_0x5b1660['onload']=_0x4b38a8,_0x5b1660['onerror']=_0x35a246=>{const _0x3f2cb0=X('internal-error');_0x3f2cb0['customData']=_0x35a246,_0x26b396(_0x3f2cb0);},_0x5b1660['type']='text/javascript',_0x5b1660['charset']='UTF-8',__()['appendChild'](_0x5b1660);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),u_('Browser');export{C_ as A,S_ as B,L_ as C,W_ as D,R_ as E,B_ as a,ap as b,x_ as c,g_ as d,m_ as e,Zr as f,P_ as g,Hd as h,Sl as i,D_ as j,Gd as k,w_ as l,b_ as m,A_ as n,v_ as o,E_ as p,k_ as q,y_ as r,F_ as s,Vt as t,I_ as u,N_ as v,U_ as w,O_ as x,M_ as y,T_ as z};