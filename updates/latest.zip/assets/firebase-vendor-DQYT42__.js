const Za=()=>{};var Ns={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Br={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x523e04,_0x3f7783){if(!_0x523e04)throw rt(_0x3f7783);},rt=function(_0xd830fe){return new Error('Firebase\x20Database\x20('+Br['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0xd830fe);},Vr=function(_0x4b1a52){const _0x395d1c=[];let _0x5e6fc4=0x0;for(let _0x4a8051=0x0;_0x4a8051<_0x4b1a52['length'];_0x4a8051++){let _0x104dda=_0x4b1a52['charCodeAt'](_0x4a8051);_0x104dda<0x80?_0x395d1c[_0x5e6fc4++]=_0x104dda:_0x104dda<0x800?(_0x395d1c[_0x5e6fc4++]=_0x104dda>>0x6|0xc0,_0x395d1c[_0x5e6fc4++]=_0x104dda&0x3f|0x80):(_0x104dda&0xfc00)===0xd800&&_0x4a8051+0x1<_0x4b1a52['length']&&(_0x4b1a52['charCodeAt'](_0x4a8051+0x1)&0xfc00)===0xdc00?(_0x104dda=0x10000+((_0x104dda&0x3ff)<<0xa)+(_0x4b1a52['charCodeAt'](++_0x4a8051)&0x3ff),_0x395d1c[_0x5e6fc4++]=_0x104dda>>0x12|0xf0,_0x395d1c[_0x5e6fc4++]=_0x104dda>>0xc&0x3f|0x80,_0x395d1c[_0x5e6fc4++]=_0x104dda>>0x6&0x3f|0x80,_0x395d1c[_0x5e6fc4++]=_0x104dda&0x3f|0x80):(_0x395d1c[_0x5e6fc4++]=_0x104dda>>0xc|0xe0,_0x395d1c[_0x5e6fc4++]=_0x104dda>>0x6&0x3f|0x80,_0x395d1c[_0x5e6fc4++]=_0x104dda&0x3f|0x80);}return _0x395d1c;},ec=function(_0xee7a7c){const _0x37aa0c=[];let _0x24fd16=0x0,_0x461bcf=0x0;for(;_0x24fd16<_0xee7a7c['length'];){const _0x165e04=_0xee7a7c[_0x24fd16++];if(_0x165e04<0x80)_0x37aa0c[_0x461bcf++]=String['fromCharCode'](_0x165e04);else{if(_0x165e04>0xbf&&_0x165e04<0xe0){const _0xe78ff1=_0xee7a7c[_0x24fd16++];_0x37aa0c[_0x461bcf++]=String['fromCharCode']((_0x165e04&0x1f)<<0x6|_0xe78ff1&0x3f);}else{if(_0x165e04>0xef&&_0x165e04<0x16d){const _0x15a490=_0xee7a7c[_0x24fd16++],_0x23c8c3=_0xee7a7c[_0x24fd16++],_0xb5e5bd=_0xee7a7c[_0x24fd16++],_0x517750=((_0x165e04&0x7)<<0x12|(_0x15a490&0x3f)<<0xc|(_0x23c8c3&0x3f)<<0x6|_0xb5e5bd&0x3f)-0x10000;_0x37aa0c[_0x461bcf++]=String['fromCharCode'](0xd800+(_0x517750>>0xa)),_0x37aa0c[_0x461bcf++]=String['fromCharCode'](0xdc00+(_0x517750&0x3ff));}else{const _0x9f590c=_0xee7a7c[_0x24fd16++],_0x443cdc=_0xee7a7c[_0x24fd16++];_0x37aa0c[_0x461bcf++]=String['fromCharCode']((_0x165e04&0xf)<<0xc|(_0x9f590c&0x3f)<<0x6|_0x443cdc&0x3f);}}}}return _0x37aa0c['join']('');},Li={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x127b5f,_0x1df503){if(!Array['isArray'](_0x127b5f))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x44373e=_0x1df503?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x42eaa7=[];for(let _0x537ccf=0x0;_0x537ccf<_0x127b5f['length'];_0x537ccf+=0x3){const _0x431327=_0x127b5f[_0x537ccf],_0x24167d=_0x537ccf+0x1<_0x127b5f['length'],_0x342452=_0x24167d?_0x127b5f[_0x537ccf+0x1]:0x0,_0x236015=_0x537ccf+0x2<_0x127b5f['length'],_0x530fae=_0x236015?_0x127b5f[_0x537ccf+0x2]:0x0,_0x37b001=_0x431327>>0x2,_0x456867=(_0x431327&0x3)<<0x4|_0x342452>>0x4;let _0x59bd0d=(_0x342452&0xf)<<0x2|_0x530fae>>0x6,_0x4bcc0b=_0x530fae&0x3f;_0x236015||(_0x4bcc0b=0x40,_0x24167d||(_0x59bd0d=0x40)),_0x42eaa7['push'](_0x44373e[_0x37b001],_0x44373e[_0x456867],_0x44373e[_0x59bd0d],_0x44373e[_0x4bcc0b]);}return _0x42eaa7['join']('');},'encodeString'(_0x371c22,_0x3833d9){return this['HAS_NATIVE_SUPPORT']&&!_0x3833d9?btoa(_0x371c22):this['encodeByteArray'](Vr(_0x371c22),_0x3833d9);},'decodeString'(_0x297bbc,_0xc52122){return this['HAS_NATIVE_SUPPORT']&&!_0xc52122?atob(_0x297bbc):ec(this['decodeStringToByteArray'](_0x297bbc,_0xc52122));},'decodeStringToByteArray'(_0x1460f3,_0x192df3){this['init_']();const _0x4a95f5=_0x192df3?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x52e37c=[];for(let _0xf2c017=0x0;_0xf2c017<_0x1460f3['length'];){const _0xa1773e=_0x4a95f5[_0x1460f3['charAt'](_0xf2c017++)],_0x6c56c5=_0xf2c017<_0x1460f3['length']?_0x4a95f5[_0x1460f3['charAt'](_0xf2c017)]:0x0;++_0xf2c017;const _0x38cb3e=_0xf2c017<_0x1460f3['length']?_0x4a95f5[_0x1460f3['charAt'](_0xf2c017)]:0x40;++_0xf2c017;const _0x34082c=_0xf2c017<_0x1460f3['length']?_0x4a95f5[_0x1460f3['charAt'](_0xf2c017)]:0x40;if(++_0xf2c017,_0xa1773e==null||_0x6c56c5==null||_0x38cb3e==null||_0x34082c==null)throw new tc();const _0x197802=_0xa1773e<<0x2|_0x6c56c5>>0x4;if(_0x52e37c['push'](_0x197802),_0x38cb3e!==0x40){const _0x2d6000=_0x6c56c5<<0x4&0xf0|_0x38cb3e>>0x2;if(_0x52e37c['push'](_0x2d6000),_0x34082c!==0x40){const _0x3a090b=_0x38cb3e<<0x6&0xc0|_0x34082c;_0x52e37c['push'](_0x3a090b);}}}return _0x52e37c;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x1bf2b8=0x0;_0x1bf2b8<this['ENCODED_VALS']['length'];_0x1bf2b8++)this['byteToCharMap_'][_0x1bf2b8]=this['ENCODED_VALS']['charAt'](_0x1bf2b8),this['charToByteMap_'][this['byteToCharMap_'][_0x1bf2b8]]=_0x1bf2b8,this['byteToCharMapWebSafe_'][_0x1bf2b8]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x1bf2b8),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x1bf2b8]]=_0x1bf2b8,_0x1bf2b8>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x1bf2b8)]=_0x1bf2b8,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x1bf2b8)]=_0x1bf2b8);}}};class tc extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Hr=function(_0x1273d7){const _0x48d59a=Vr(_0x1273d7);return Li['encodeByteArray'](_0x48d59a,!0x0);},cn=function(_0x1a03d7){return Hr(_0x1a03d7)['replace'](/\./g,'');},ln=function(_0x114a1f){try{return Li['decodeString'](_0x114a1f,!0x0);}catch(_0x59e6de){console['error']('base64Decode\x20failed:\x20',_0x59e6de);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nc(_0x5abb39){return $r(void 0x0,_0x5abb39);}function $r(_0x39c028,_0x33bf68){if(!(_0x33bf68 instanceof Object))return _0x33bf68;switch(_0x33bf68['constructor']){case Date:const _0x4bc159=_0x33bf68;return new Date(_0x4bc159['getTime']());case Object:_0x39c028===void 0x0&&(_0x39c028={});break;case Array:_0x39c028=[];break;default:return _0x33bf68;}for(const _0x3bb9a2 in _0x33bf68)!_0x33bf68['hasOwnProperty'](_0x3bb9a2)||!ic(_0x3bb9a2)||(_0x39c028[_0x3bb9a2]=$r(_0x39c028[_0x3bb9a2],_0x33bf68[_0x3bb9a2]));return _0x39c028;}function ic(_0xb13715){return _0xb13715!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rc=()=>sc()['__FIREBASE_DEFAULTS__'],oc=()=>{if(typeof process>'u'||typeof Ns>'u')return;const _0x3351de=Ns['__FIREBASE_DEFAULTS__'];if(_0x3351de)return JSON['parse'](_0x3351de);},ac=()=>{if(typeof document>'u')return;let _0xfaaf43;try{_0xfaaf43=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x231c94=_0xfaaf43&&ln(_0xfaaf43[0x1]);return _0x231c94&&JSON['parse'](_0x231c94);},xi=()=>{try{return Za()||rc()||oc()||ac();}catch(_0x3112e4){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x3112e4);return;}},Gr=_0x43ac1e=>{var _0x58149b,_0x2ef4bd;return(_0x2ef4bd=(_0x58149b=xi())==null?void 0x0:_0x58149b['emulatorHosts'])==null?void 0x0:_0x2ef4bd[_0x43ac1e];},cc=_0x269229=>{const _0x56a04f=Gr(_0x269229);if(!_0x56a04f)return;const _0x5bcda9=_0x56a04f['lastIndexOf'](':');if(_0x5bcda9<=0x0||_0x5bcda9+0x1===_0x56a04f['length'])throw new Error('Invalid\x20host\x20'+_0x56a04f+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x5de2c4=parseInt(_0x56a04f['substring'](_0x5bcda9+0x1),0xa);return _0x56a04f[0x0]==='['?[_0x56a04f['substring'](0x1,_0x5bcda9-0x1),_0x5de2c4]:[_0x56a04f['substring'](0x0,_0x5bcda9),_0x5de2c4];},qr=()=>{var _0x565aec;return(_0x565aec=xi())==null?void 0x0:_0x565aec['config'];},zr=_0x3a3b80=>{var _0x2259e0;return(_0x2259e0=xi())==null?void 0x0:_0x2259e0['_'+_0x3a3b80];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x427a28,_0x5043e8)=>{this['resolve']=_0x427a28,this['reject']=_0x5043e8;});}['wrapCallback'](_0x97c2a2){return(_0x4d7f67,_0x42d5a9)=>{_0x4d7f67?this['reject'](_0x4d7f67):this['resolve'](_0x42d5a9),typeof _0x97c2a2=='function'&&(this['promise']['catch'](()=>{}),_0x97c2a2['length']===0x1?_0x97c2a2(_0x4d7f67):_0x97c2a2(_0x4d7f67,_0x42d5a9));};}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x56826c){try{return(_0x56826c['startsWith']('http://')||_0x56826c['startsWith']('https://')?new URL(_0x56826c)['hostname']:_0x56826c)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x1d9c18){return(await fetch(_0x1d9c18,{'credentials':'include'}))['ok'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function lc(_0x1edec1,_0x2c54f2){if(_0x1edec1['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x4fce0d={'alg':'none','type':'JWT'},_0x461c14=_0x2c54f2||'demo-project',_0x39ea1d=_0x1edec1['iat']||0x0,_0x14ea84=_0x1edec1['sub']||_0x1edec1['user_id'];if(!_0x14ea84)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x1d3481={'iss':'https://securetoken.google.com/'+_0x461c14,'aud':_0x461c14,'iat':_0x39ea1d,'exp':_0x39ea1d+0xe10,'auth_time':_0x39ea1d,'sub':_0x14ea84,'user_id':_0x14ea84,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x1edec1};return[cn(JSON['stringify'](_0x4fce0d)),cn(JSON['stringify'](_0x1d3481)),'']['join']('.');}const It={};function hc(){const _0x3a2888={'prod':[],'emulator':[]};for(const _0x379648 of Object['keys'](It))It[_0x379648]?_0x3a2888['emulator']['push'](_0x379648):_0x3a2888['prod']['push'](_0x379648);return _0x3a2888;}function uc(_0x2afc79){let _0x14060c=document['getElementById'](_0x2afc79),_0x833f8e=!0x1;return _0x14060c||(_0x14060c=document['createElement']('div'),_0x14060c['setAttribute']('id',_0x2afc79),_0x833f8e=!0x0),{'created':_0x833f8e,'element':_0x14060c};}let Ps=!0x1;function Kr(_0x3dff0e,_0x5c4279){if(typeof window>'u'||typeof document>'u'||!at(window['location']['host'])||It[_0x3dff0e]===_0x5c4279||It[_0x3dff0e]||Ps)return;It[_0x3dff0e]=_0x5c4279;function _0x487960(_0x195063){return'__firebase__banner__'+_0x195063;}const _0x5a02f2='__firebase__banner',_0x5cee5c=hc()['prod']['length']>0x0;function _0x522def(){const _0x5e25d0=document['getElementById'](_0x5a02f2);_0x5e25d0&&_0x5e25d0['remove']();}function _0x2065d6(_0x345b0b){_0x345b0b['style']['display']='flex',_0x345b0b['style']['background']='#7faaf0',_0x345b0b['style']['position']='fixed',_0x345b0b['style']['bottom']='5px',_0x345b0b['style']['left']='5px',_0x345b0b['style']['padding']='.5em',_0x345b0b['style']['borderRadius']='5px',_0x345b0b['style']['alignItems']='center';}function _0x401357(_0x4c8fc5,_0x2d816d){_0x4c8fc5['setAttribute']('width','24'),_0x4c8fc5['setAttribute']('id',_0x2d816d),_0x4c8fc5['setAttribute']('height','24'),_0x4c8fc5['setAttribute']('viewBox','0\x200\x2024\x2024'),_0x4c8fc5['setAttribute']('fill','none'),_0x4c8fc5['style']['marginLeft']='-6px';}function _0x634122(){const _0x59daab=document['createElement']('span');return _0x59daab['style']['cursor']='pointer',_0x59daab['style']['marginLeft']='16px',_0x59daab['style']['fontSize']='24px',_0x59daab['innerHTML']='\x20&times;',_0x59daab['onclick']=()=>{Ps=!0x0,_0x522def();},_0x59daab;}function _0xdd5f43(_0x328a0d,_0x5d6248){_0x328a0d['setAttribute']('id',_0x5d6248),_0x328a0d['innerText']='Learn\x20more',_0x328a0d['href']='https://firebase.google.com/docs/studio/preview-apps#preview-backend',_0x328a0d['setAttribute']('target','__blank'),_0x328a0d['style']['paddingLeft']='5px',_0x328a0d['style']['textDecoration']='underline';}function _0x55ae61(){const _0x11cc35=uc(_0x5a02f2),_0x2ffac7=_0x487960('text'),_0x541528=document['getElementById'](_0x2ffac7)||document['createElement']('span'),_0x1cba47=_0x487960('learnmore'),_0x2ef2a9=document['getElementById'](_0x1cba47)||document['createElement']('a'),_0x243ea6=_0x487960('preprendIcon'),_0x161f87=document['getElementById'](_0x243ea6)||document['createElementNS']('http://www.w3.org/2000/svg','svg');if(_0x11cc35['created']){const _0x5e99bd=_0x11cc35['element'];_0x2065d6(_0x5e99bd),_0xdd5f43(_0x2ef2a9,_0x1cba47);const _0xdc0ee6=_0x634122();_0x401357(_0x161f87,_0x243ea6),_0x5e99bd['append'](_0x161f87,_0x541528,_0x2ef2a9,_0xdc0ee6),document['body']['appendChild'](_0x5e99bd);}_0x5cee5c?(_0x541528['innerText']='Preview\x20backend\x20disconnected.',_0x161f87['innerHTML']='<g\x20clip-path=\x22url(#clip0_6013_33858)\x22>\x0a<path\x20d=\x22M4.8\x2017.6L12\x205.6L19.2\x2017.6H4.8ZM6.91667\x2016.4H17.0833L12\x207.93333L6.91667\x2016.4ZM12\x2015.6C12.1667\x2015.6\x2012.3056\x2015.5444\x2012.4167\x2015.4333C12.5389\x2015.3111\x2012.6\x2015.1667\x2012.6\x2015C12.6\x2014.8333\x2012.5389\x2014.6944\x2012.4167\x2014.5833C12.3056\x2014.4611\x2012.1667\x2014.4\x2012\x2014.4C11.8333\x2014.4\x2011.6889\x2014.4611\x2011.5667\x2014.5833C11.4556\x2014.6944\x2011.4\x2014.8333\x2011.4\x2015C11.4\x2015.1667\x2011.4556\x2015.3111\x2011.5667\x2015.4333C11.6889\x2015.5444\x2011.8333\x2015.6\x2012\x2015.6ZM11.4\x2013.6H12.6V10.4H11.4V13.6Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6013_33858\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>'):(_0x161f87['innerHTML']='<g\x20clip-path=\x22url(#clip0_6083_34804)\x22>\x0a<path\x20d=\x22M11.4\x2015.2H12.6V11.2H11.4V15.2ZM12\x2010C12.1667\x2010\x2012.3056\x209.94444\x2012.4167\x209.83333C12.5389\x209.71111\x2012.6\x209.56667\x2012.6\x209.4C12.6\x209.23333\x2012.5389\x209.09444\x2012.4167\x208.98333C12.3056\x208.86111\x2012.1667\x208.8\x2012\x208.8C11.8333\x208.8\x2011.6889\x208.86111\x2011.5667\x208.98333C11.4556\x209.09444\x2011.4\x209.23333\x2011.4\x209.4C11.4\x209.56667\x2011.4556\x209.71111\x2011.5667\x209.83333C11.6889\x209.94444\x2011.8333\x2010\x2012\x2010ZM12\x2018.4C11.1222\x2018.4\x2010.2944\x2018.2333\x209.51667\x2017.9C8.73889\x2017.5667\x208.05556\x2017.1111\x207.46667\x2016.5333C6.88889\x2015.9444\x206.43333\x2015.2611\x206.1\x2014.4833C5.76667\x2013.7056\x205.6\x2012.8778\x205.6\x2012C5.6\x2011.1111\x205.76667\x2010.2833\x206.1\x209.51667C6.43333\x208.73889\x206.88889\x208.06111\x207.46667\x207.48333C8.05556\x206.89444\x208.73889\x206.43333\x209.51667\x206.1C10.2944\x205.76667\x2011.1222\x205.6\x2012\x205.6C12.8889\x205.6\x2013.7167\x205.76667\x2014.4833\x206.1C15.2611\x206.43333\x2015.9389\x206.89444\x2016.5167\x207.48333C17.1056\x208.06111\x2017.5667\x208.73889\x2017.9\x209.51667C18.2333\x2010.2833\x2018.4\x2011.1111\x2018.4\x2012C18.4\x2012.8778\x2018.2333\x2013.7056\x2017.9\x2014.4833C17.5667\x2015.2611\x2017.1056\x2015.9444\x2016.5167\x2016.5333C15.9389\x2017.1111\x2015.2611\x2017.5667\x2014.4833\x2017.9C13.7167\x2018.2333\x2012.8889\x2018.4\x2012\x2018.4ZM12\x2017.2C13.4444\x2017.2\x2014.6722\x2016.6944\x2015.6833\x2015.6833C16.6944\x2014.6722\x2017.2\x2013.4444\x2017.2\x2012C17.2\x2010.5556\x2016.6944\x209.32778\x2015.6833\x208.31667C14.6722\x207.30555\x2013.4444\x206.8\x2012\x206.8C10.5556\x206.8\x209.32778\x207.30555\x208.31667\x208.31667C7.30556\x209.32778\x206.8\x2010.5556\x206.8\x2012C6.8\x2013.4444\x207.30556\x2014.6722\x208.31667\x2015.6833C9.32778\x2016.6944\x2010.5556\x2017.2\x2012\x2017.2Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6083_34804\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>',_0x541528['innerText']='Preview\x20backend\x20running\x20in\x20this\x20workspace.'),_0x541528['setAttribute']('id',_0x2ffac7);}document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x55ae61):_0x55ae61();}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Fi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x33d91f=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x33d91f=='object'&&_0x33d91f['id']!==void 0x0;}function Yr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x3670bf=W();return _0x3670bf['indexOf']('MSIE\x20')>=0x0||_0x3670bf['indexOf']('Trident/')>=0x0;}function _c(){return Br['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0xd4f546,_0x4da834)=>{try{let _0x44464f=!0x0;const _0x471551='validate-browser-context-for-indexeddb-analytics-module',_0x57ae84=self['indexedDB']['open'](_0x471551);_0x57ae84['onsuccess']=()=>{_0x57ae84['result']['close'](),_0x44464f||self['indexedDB']['deleteDatabase'](_0x471551),_0xd4f546(!0x0);},_0x57ae84['onupgradeneeded']=()=>{_0x44464f=!0x1;},_0x57ae84['onerror']=()=>{var _0x128e6f;_0x4da834(((_0x128e6f=_0x57ae84['error'])==null?void 0x0:_0x128e6f['message'])||'');};}catch(_0x1d1879){_0x4da834(_0x1d1879);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Se extends Error{constructor(_0x175ba7,_0x142bd0,_0x5700f3){super(_0x142bd0),this['code']=_0x175ba7,this['customData']=_0x5700f3,this['name']=yc,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Bt['prototype']['create']);}}class Bt{constructor(_0x3243a2,_0x385536,_0x143c3b){this['service']=_0x3243a2,this['serviceName']=_0x385536,this['errors']=_0x143c3b;}['create'](_0x1f5139,..._0x1e124b){const _0x4234c1=_0x1e124b[0x0]||{},_0x450e16=this['service']+'/'+_0x1f5139,_0x5834e0=this['errors'][_0x1f5139],_0x74fa4e=_0x5834e0?vc(_0x5834e0,_0x4234c1):'Error',_0x184d53=this['serviceName']+':\x20'+_0x74fa4e+'\x20('+_0x450e16+').';return new Se(_0x450e16,_0x184d53,_0x4234c1);}}function vc(_0x5da5ce,_0x13e828){return _0x5da5ce['replace'](Ec,(_0x58b7ec,_0xcc9405)=>{const _0x2109ed=_0x13e828[_0xcc9405];return _0x2109ed!=null?String(_0x2109ed):'<'+_0xcc9405+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function At(_0xe8bef1){return JSON['parse'](_0xe8bef1);}function O(_0x302afc){return JSON['stringify'](_0x302afc);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qr=function(_0x4e2ce7){let _0x7af535={},_0x2c635f={},_0x527288={},_0x436a12='';try{const _0x145c52=_0x4e2ce7['split']('.');_0x7af535=At(ln(_0x145c52[0x0])||''),_0x2c635f=At(ln(_0x145c52[0x1])||''),_0x436a12=_0x145c52[0x2],_0x527288=_0x2c635f['d']||{},delete _0x2c635f['d'];}catch{}return{'header':_0x7af535,'claims':_0x2c635f,'data':_0x527288,'signature':_0x436a12};},Ic=function(_0x1fc4d4){const _0x19d26d=Qr(_0x1fc4d4),_0x395bc1=_0x19d26d['claims'];return!!_0x395bc1&&typeof _0x395bc1=='object'&&_0x395bc1['hasOwnProperty']('iat');},wc=function(_0x2b544f){const _0x2f30db=Qr(_0x2b544f)['claims'];return typeof _0x2f30db=='object'&&_0x2f30db['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function J(_0x403629,_0x15286e){return Object['prototype']['hasOwnProperty']['call'](_0x403629,_0x15286e);}function De(_0x30779f,_0x467e1a){if(Object['prototype']['hasOwnProperty']['call'](_0x30779f,_0x467e1a))return _0x30779f[_0x467e1a];}function ui(_0x4f4564){for(const _0x4b4433 in _0x4f4564)if(Object['prototype']['hasOwnProperty']['call'](_0x4f4564,_0x4b4433))return!0x1;return!0x0;}function hn(_0x43f736,_0x2c3084,_0x4e40ff){const _0x58fb24={};for(const _0x5947d3 in _0x43f736)Object['prototype']['hasOwnProperty']['call'](_0x43f736,_0x5947d3)&&(_0x58fb24[_0x5947d3]=_0x2c3084['call'](_0x4e40ff,_0x43f736[_0x5947d3],_0x5947d3,_0x43f736));return _0x58fb24;}function Me(_0x295efd,_0x4ea05a){if(_0x295efd===_0x4ea05a)return!0x0;const _0x2a3ab1=Object['keys'](_0x295efd),_0xcd7fd4=Object['keys'](_0x4ea05a);for(const _0xc7d220 of _0x2a3ab1){if(!_0xcd7fd4['includes'](_0xc7d220))return!0x1;const _0x2bbca0=_0x295efd[_0xc7d220],_0x9d42fc=_0x4ea05a[_0xc7d220];if(Os(_0x2bbca0)&&Os(_0x9d42fc)){if(!Me(_0x2bbca0,_0x9d42fc))return!0x1;}else{if(_0x2bbca0!==_0x9d42fc)return!0x1;}}for(const _0x502359 of _0xcd7fd4)if(!_0x2a3ab1['includes'](_0x502359))return!0x1;return!0x0;}function Os(_0x2c26ab){return _0x2c26ab!==null&&typeof _0x2c26ab=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ct(_0x4e3d7a){const _0x369cfd=[];for(const [_0x1f93a8,_0x35f9fb]of Object['entries'](_0x4e3d7a))Array['isArray'](_0x35f9fb)?_0x35f9fb['forEach'](_0x136f9e=>{_0x369cfd['push'](encodeURIComponent(_0x1f93a8)+'='+encodeURIComponent(_0x136f9e));}):_0x369cfd['push'](encodeURIComponent(_0x1f93a8)+'='+encodeURIComponent(_0x35f9fb));return _0x369cfd['length']?'&'+_0x369cfd['join']('&'):'';}function vt(_0x379617){const _0x403de1={};return _0x379617['replace'](/^\?/,'')['split']('&')['forEach'](_0x4d7b6e=>{if(_0x4d7b6e){const [_0xdeaf89,_0x4c9ce2]=_0x4d7b6e['split']('=');_0x403de1[decodeURIComponent(_0xdeaf89)]=decodeURIComponent(_0x4c9ce2);}}),_0x403de1;}function Et(_0x177378){const _0x331875=_0x177378['indexOf']('?');if(!_0x331875)return'';const _0x4881f5=_0x177378['indexOf']('#',_0x331875);return _0x177378['substring'](_0x331875,_0x4881f5>0x0?_0x4881f5:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0xffd35a=0x1;_0xffd35a<this['blockSize'];++_0xffd35a)this['pad_'][_0xffd35a]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x56fb4b,_0x50ead0){_0x50ead0||(_0x50ead0=0x0);const _0x2654f4=this['W_'];if(typeof _0x56fb4b=='string'){for(let _0x517c1d=0x0;_0x517c1d<0x10;_0x517c1d++)_0x2654f4[_0x517c1d]=_0x56fb4b['charCodeAt'](_0x50ead0)<<0x18|_0x56fb4b['charCodeAt'](_0x50ead0+0x1)<<0x10|_0x56fb4b['charCodeAt'](_0x50ead0+0x2)<<0x8|_0x56fb4b['charCodeAt'](_0x50ead0+0x3),_0x50ead0+=0x4;}else{for(let _0x4c426d=0x0;_0x4c426d<0x10;_0x4c426d++)_0x2654f4[_0x4c426d]=_0x56fb4b[_0x50ead0]<<0x18|_0x56fb4b[_0x50ead0+0x1]<<0x10|_0x56fb4b[_0x50ead0+0x2]<<0x8|_0x56fb4b[_0x50ead0+0x3],_0x50ead0+=0x4;}for(let _0x2bed70=0x10;_0x2bed70<0x50;_0x2bed70++){const _0x5b3298=_0x2654f4[_0x2bed70-0x3]^_0x2654f4[_0x2bed70-0x8]^_0x2654f4[_0x2bed70-0xe]^_0x2654f4[_0x2bed70-0x10];_0x2654f4[_0x2bed70]=(_0x5b3298<<0x1|_0x5b3298>>>0x1f)&0xffffffff;}let _0x1a07b8=this['chain_'][0x0],_0x365f29=this['chain_'][0x1],_0x3caa2b=this['chain_'][0x2],_0x5d11a=this['chain_'][0x3],_0x468bdf=this['chain_'][0x4],_0x1116a8,_0xe0852a;for(let _0x25f22f=0x0;_0x25f22f<0x50;_0x25f22f++){_0x25f22f<0x28?_0x25f22f<0x14?(_0x1116a8=_0x5d11a^_0x365f29&(_0x3caa2b^_0x5d11a),_0xe0852a=0x5a827999):(_0x1116a8=_0x365f29^_0x3caa2b^_0x5d11a,_0xe0852a=0x6ed9eba1):_0x25f22f<0x3c?(_0x1116a8=_0x365f29&_0x3caa2b|_0x5d11a&(_0x365f29|_0x3caa2b),_0xe0852a=0x8f1bbcdc):(_0x1116a8=_0x365f29^_0x3caa2b^_0x5d11a,_0xe0852a=0xca62c1d6);const _0x3fdd19=(_0x1a07b8<<0x5|_0x1a07b8>>>0x1b)+_0x1116a8+_0x468bdf+_0xe0852a+_0x2654f4[_0x25f22f]&0xffffffff;_0x468bdf=_0x5d11a,_0x5d11a=_0x3caa2b,_0x3caa2b=(_0x365f29<<0x1e|_0x365f29>>>0x2)&0xffffffff,_0x365f29=_0x1a07b8,_0x1a07b8=_0x3fdd19;}this['chain_'][0x0]=this['chain_'][0x0]+_0x1a07b8&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x365f29&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x3caa2b&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x5d11a&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x468bdf&0xffffffff;}['update'](_0x5e0db6,_0x2dda13){if(_0x5e0db6==null)return;_0x2dda13===void 0x0&&(_0x2dda13=_0x5e0db6['length']);const _0x482b10=_0x2dda13-this['blockSize'];let _0x19a47d=0x0;const _0x514faf=this['buf_'];let _0x40969c=this['inbuf_'];for(;_0x19a47d<_0x2dda13;){if(_0x40969c===0x0){for(;_0x19a47d<=_0x482b10;)this['compress_'](_0x5e0db6,_0x19a47d),_0x19a47d+=this['blockSize'];}if(typeof _0x5e0db6=='string'){for(;_0x19a47d<_0x2dda13;)if(_0x514faf[_0x40969c]=_0x5e0db6['charCodeAt'](_0x19a47d),++_0x40969c,++_0x19a47d,_0x40969c===this['blockSize']){this['compress_'](_0x514faf),_0x40969c=0x0;break;}}else{for(;_0x19a47d<_0x2dda13;)if(_0x514faf[_0x40969c]=_0x5e0db6[_0x19a47d],++_0x40969c,++_0x19a47d,_0x40969c===this['blockSize']){this['compress_'](_0x514faf),_0x40969c=0x0;break;}}}this['inbuf_']=_0x40969c,this['total_']+=_0x2dda13;}['digest'](){const _0xa6cdf4=[];let _0x5d0821=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x9c42f0=this['blockSize']-0x1;_0x9c42f0>=0x38;_0x9c42f0--)this['buf_'][_0x9c42f0]=_0x5d0821&0xff,_0x5d0821/=0x100;this['compress_'](this['buf_']);let _0x2318c2=0x0;for(let _0x2c5e69=0x0;_0x2c5e69<0x5;_0x2c5e69++)for(let _0x320d45=0x18;_0x320d45>=0x0;_0x320d45-=0x8)_0xa6cdf4[_0x2318c2]=this['chain_'][_0x2c5e69]>>_0x320d45&0xff,++_0x2318c2;return _0xa6cdf4;}}function Tc(_0x4a088a,_0x30aa88){const _0x5c08d2=new Sc(_0x4a088a,_0x30aa88);return _0x5c08d2['subscribe']['bind'](_0x5c08d2);}class Sc{constructor(_0x4db565,_0x19b79a){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x19b79a,this['task']['then'](()=>{_0x4db565(this);})['catch'](_0x5178b5=>{this['error'](_0x5178b5);});}['next'](_0x2fab89){this['forEachObserver'](_0x2e42ba=>{_0x2e42ba['next'](_0x2fab89);});}['error'](_0x90f116){this['forEachObserver'](_0x5dafd1=>{_0x5dafd1['error'](_0x90f116);}),this['close'](_0x90f116);}['complete'](){this['forEachObserver'](_0x1854cd=>{_0x1854cd['complete']();}),this['close']();}['subscribe'](_0x57139c,_0x15557d,_0x11594a){let _0xef1bfb;if(_0x57139c===void 0x0&&_0x15557d===void 0x0&&_0x11594a===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x57139c,['next','error','complete'])?_0xef1bfb=_0x57139c:_0xef1bfb={'next':_0x57139c,'error':_0x15557d,'complete':_0x11594a},_0xef1bfb['next']===void 0x0&&(_0xef1bfb['next']=Jn),_0xef1bfb['error']===void 0x0&&(_0xef1bfb['error']=Jn),_0xef1bfb['complete']===void 0x0&&(_0xef1bfb['complete']=Jn);const _0x259bef=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0xef1bfb['error'](this['finalError']):_0xef1bfb['complete']();}catch{}}),this['observers']['push'](_0xef1bfb),_0x259bef;}['unsubscribeOne'](_0x777a6b){this['observers']===void 0x0||this['observers'][_0x777a6b]===void 0x0||(delete this['observers'][_0x777a6b],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x5b97e){if(!this['finalized']){for(let _0xd6122b=0x0;_0xd6122b<this['observers']['length'];_0xd6122b++)this['sendOne'](_0xd6122b,_0x5b97e);}}['sendOne'](_0x3a3d1a,_0x28b783){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x3a3d1a]!==void 0x0)try{_0x28b783(this['observers'][_0x3a3d1a]);}catch(_0x536a4a){typeof console<'u'&&console['error']&&console['error'](_0x536a4a);}});}['close'](_0x5c9569){this['finalized']||(this['finalized']=!0x0,_0x5c9569!==void 0x0&&(this['finalError']=_0x5c9569),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x4a458f,_0x2b2a6f){if(typeof _0x4a458f!='object'||_0x4a458f===null)return!0x1;for(const _0x4eece3 of _0x2b2a6f)if(_0x4eece3 in _0x4a458f&&typeof _0x4a458f[_0x4eece3]=='function')return!0x0;return!0x1;}function Jn(){}function Pn(_0x4bf868,_0x35aa7a){return _0x4bf868+'\x20failed:\x20'+_0x35aa7a+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x45e0c3){const _0x3186c4=[];let _0x148df4=0x0;for(let _0x1783ea=0x0;_0x1783ea<_0x45e0c3['length'];_0x1783ea++){let _0x1e7c82=_0x45e0c3['charCodeAt'](_0x1783ea);if(_0x1e7c82>=0xd800&&_0x1e7c82<=0xdbff){const _0x849bca=_0x1e7c82-0xd800;_0x1783ea++,f(_0x1783ea<_0x45e0c3['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x3fe778=_0x45e0c3['charCodeAt'](_0x1783ea)-0xdc00;_0x1e7c82=0x10000+(_0x849bca<<0xa)+_0x3fe778;}_0x1e7c82<0x80?_0x3186c4[_0x148df4++]=_0x1e7c82:_0x1e7c82<0x800?(_0x3186c4[_0x148df4++]=_0x1e7c82>>0x6|0xc0,_0x3186c4[_0x148df4++]=_0x1e7c82&0x3f|0x80):_0x1e7c82<0x10000?(_0x3186c4[_0x148df4++]=_0x1e7c82>>0xc|0xe0,_0x3186c4[_0x148df4++]=_0x1e7c82>>0x6&0x3f|0x80,_0x3186c4[_0x148df4++]=_0x1e7c82&0x3f|0x80):(_0x3186c4[_0x148df4++]=_0x1e7c82>>0x12|0xf0,_0x3186c4[_0x148df4++]=_0x1e7c82>>0xc&0x3f|0x80,_0x3186c4[_0x148df4++]=_0x1e7c82>>0x6&0x3f|0x80,_0x3186c4[_0x148df4++]=_0x1e7c82&0x3f|0x80);}return _0x3186c4;},On=function(_0x5767d3){let _0x5b078e=0x0;for(let _0x91b680=0x0;_0x91b680<_0x5767d3['length'];_0x91b680++){const _0x34e07c=_0x5767d3['charCodeAt'](_0x91b680);_0x34e07c<0x80?_0x5b078e++:_0x34e07c<0x800?_0x5b078e+=0x2:_0x34e07c>=0xd800&&_0x34e07c<=0xdbff?(_0x5b078e+=0x4,_0x91b680++):_0x5b078e+=0x3;}return _0x5b078e;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function N(_0x41670e){return _0x41670e&&_0x41670e['_delegate']?_0x41670e['_delegate']:_0x41670e;}class Le{constructor(_0x4ffac4,_0x34013e,_0x43032a){this['name']=_0x4ffac4,this['instanceFactory']=_0x34013e,this['type']=_0x43032a,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x244a4f){return this['instantiationMode']=_0x244a4f,this;}['setMultipleInstances'](_0x9efddc){return this['multipleInstances']=_0x9efddc,this;}['setServiceProps'](_0x32e22c){return this['serviceProps']=_0x32e22c,this;}['setInstanceCreatedCallback'](_0x356696){return this['onInstanceCreated']=_0x356696,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x34c05a,_0x90fde4){this['name']=_0x34c05a,this['container']=_0x90fde4,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x512a4f){const _0x418570=this['normalizeInstanceIdentifier'](_0x512a4f);if(!this['instancesDeferred']['has'](_0x418570)){const _0x1883d7=new ot();if(this['instancesDeferred']['set'](_0x418570,_0x1883d7),this['isInitialized'](_0x418570)||this['shouldAutoInitialize']())try{const _0x2a44ba=this['getOrInitializeService']({'instanceIdentifier':_0x418570});_0x2a44ba&&_0x1883d7['resolve'](_0x2a44ba);}catch{}}return this['instancesDeferred']['get'](_0x418570)['promise'];}['getImmediate'](_0x1506db){const _0x40cf79=this['normalizeInstanceIdentifier'](_0x1506db==null?void 0x0:_0x1506db['identifier']),_0x5cea65=(_0x1506db==null?void 0x0:_0x1506db['optional'])??!0x1;if(this['isInitialized'](_0x40cf79)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x40cf79});}catch(_0x3d75c1){if(_0x5cea65)return null;throw _0x3d75c1;}else{if(_0x5cea65)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x588176){if(_0x588176['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x588176['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x588176,!!this['shouldAutoInitialize']()){if(Nc(_0x588176))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x2f199e,_0x46465a]of this['instancesDeferred']['entries']()){const _0x2e151a=this['normalizeInstanceIdentifier'](_0x2f199e);try{const _0x5bd259=this['getOrInitializeService']({'instanceIdentifier':_0x2e151a});_0x46465a['resolve'](_0x5bd259);}catch{}}}}['clearInstance'](_0xa25103=Ne){this['instancesDeferred']['delete'](_0xa25103),this['instancesOptions']['delete'](_0xa25103),this['instances']['delete'](_0xa25103);}async['delete'](){const _0x47b501=Array['from'](this['instances']['values']());await Promise['all']([..._0x47b501['filter'](_0x5cf3ab=>'INTERNAL'in _0x5cf3ab)['map'](_0x367595=>_0x367595['INTERNAL']['delete']()),..._0x47b501['filter'](_0x157dfc=>'_delete'in _0x157dfc)['map'](_0x1bf034=>_0x1bf034['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x2ca4da=Ne){return this['instances']['has'](_0x2ca4da);}['getOptions'](_0x38dd1b=Ne){return this['instancesOptions']['get'](_0x38dd1b)||{};}['initialize'](_0x14cc7a={}){const {options:_0x4b5b86={}}=_0x14cc7a,_0xbfe994=this['normalizeInstanceIdentifier'](_0x14cc7a['instanceIdentifier']);if(this['isInitialized'](_0xbfe994))throw Error(this['name']+'('+_0xbfe994+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x5b48ca=this['getOrInitializeService']({'instanceIdentifier':_0xbfe994,'options':_0x4b5b86});for(const [_0x2e28aa,_0x32fe3d]of this['instancesDeferred']['entries']()){const _0x280eeb=this['normalizeInstanceIdentifier'](_0x2e28aa);_0xbfe994===_0x280eeb&&_0x32fe3d['resolve'](_0x5b48ca);}return _0x5b48ca;}['onInit'](_0x1c5f25,_0x544515){const _0x530422=this['normalizeInstanceIdentifier'](_0x544515),_0x2b799d=this['onInitCallbacks']['get'](_0x530422)??new Set();_0x2b799d['add'](_0x1c5f25),this['onInitCallbacks']['set'](_0x530422,_0x2b799d);const _0x1dc1a5=this['instances']['get'](_0x530422);return _0x1dc1a5&&_0x1c5f25(_0x1dc1a5,_0x530422),()=>{_0x2b799d['delete'](_0x1c5f25);};}['invokeOnInitCallbacks'](_0x5395cb,_0x2dfba8){const _0x42b286=this['onInitCallbacks']['get'](_0x2dfba8);if(_0x42b286){for(const _0x3601ea of _0x42b286)try{_0x3601ea(_0x5395cb,_0x2dfba8);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x991407,options:_0x3515e1={}}){let _0x2292e1=this['instances']['get'](_0x991407);if(!_0x2292e1&&this['component']&&(_0x2292e1=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x991407),'options':_0x3515e1}),this['instances']['set'](_0x991407,_0x2292e1),this['instancesOptions']['set'](_0x991407,_0x3515e1),this['invokeOnInitCallbacks'](_0x2292e1,_0x991407),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x991407,_0x2292e1);}catch{}return _0x2292e1||null;}['normalizeInstanceIdentifier'](_0x4a5f0d=Ne){return this['component']?this['component']['multipleInstances']?_0x4a5f0d:Ne:_0x4a5f0d;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x42b27d){return _0x42b27d===Ne?void 0x0:_0x42b27d;}function Nc(_0x26bc16){return _0x26bc16['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pc{constructor(_0xca0ef2){this['name']=_0xca0ef2,this['providers']=new Map();}['addComponent'](_0x3e4c89){const _0x28af0a=this['getProvider'](_0x3e4c89['name']);if(_0x28af0a['isComponentSet']())throw new Error('Component\x20'+_0x3e4c89['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x28af0a['setComponent'](_0x3e4c89);}['addOrOverwriteComponent'](_0x34d6ff){this['getProvider'](_0x34d6ff['name'])['isComponentSet']()&&this['providers']['delete'](_0x34d6ff['name']),this['addComponent'](_0x34d6ff);}['getProvider'](_0x51deb7){if(this['providers']['has'](_0x51deb7))return this['providers']['get'](_0x51deb7);const _0x26cc7f=new Ac(_0x51deb7,this);return this['providers']['set'](_0x51deb7,_0x26cc7f),_0x26cc7f;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x1f66c7){_0x1f66c7[_0x1f66c7['DEBUG']=0x0]='DEBUG',_0x1f66c7[_0x1f66c7['VERBOSE']=0x1]='VERBOSE',_0x1f66c7[_0x1f66c7['INFO']=0x2]='INFO',_0x1f66c7[_0x1f66c7['WARN']=0x3]='WARN',_0x1f66c7[_0x1f66c7['ERROR']=0x4]='ERROR',_0x1f66c7[_0x1f66c7['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x5491b3,_0x1e0c1b,..._0x560423)=>{if(_0x1e0c1b<_0x5491b3['logLevel'])return;const _0x7e1d44=new Date()['toISOString'](),_0x17d81f=Mc[_0x1e0c1b];if(_0x17d81f)console[_0x17d81f]('['+_0x7e1d44+']\x20\x20'+_0x5491b3['name']+':',..._0x560423);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x1e0c1b+')');};class Ui{constructor(_0x5b26b7){this['name']=_0x5b26b7,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x3c431e){if(!(_0x3c431e in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x3c431e+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x3c431e;}['setLogLevel'](_0x5cecd3){this['_logLevel']=typeof _0x5cecd3=='string'?Oc[_0x5cecd3]:_0x5cecd3;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x2954de){if(typeof _0x2954de!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x2954de;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x1ec5be){this['_userLogHandler']=_0x1ec5be;}['debug'](..._0x21c9f0){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x21c9f0),this['_logHandler'](this,T['DEBUG'],..._0x21c9f0);}['log'](..._0x41dbdf){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x41dbdf),this['_logHandler'](this,T['VERBOSE'],..._0x41dbdf);}['info'](..._0x5d1b5a){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x5d1b5a),this['_logHandler'](this,T['INFO'],..._0x5d1b5a);}['warn'](..._0x54d45d){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x54d45d),this['_logHandler'](this,T['WARN'],..._0x54d45d);}['error'](..._0x383731){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x383731),this['_logHandler'](this,T['ERROR'],..._0x383731);}}const xc=(_0x4651ae,_0x57d167)=>_0x57d167['some'](_0x2da09b=>_0x4651ae instanceof _0x2da09b);let Ds,Ms;function Fc(){return Ds||(Ds=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ms||(Ms=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),di=new WeakMap(),Xr=new WeakMap(),Xn=new WeakMap(),Wi=new WeakMap();function Wc(_0x3fbcc4){const _0x1f82da=new Promise((_0x755beb,_0x33396f)=>{const _0x32802e=()=>{_0x3fbcc4['removeEventListener']('success',_0x5ae276),_0x3fbcc4['removeEventListener']('error',_0x2e6344);},_0x5ae276=()=>{_0x755beb(_e(_0x3fbcc4['result'])),_0x32802e();},_0x2e6344=()=>{_0x33396f(_0x3fbcc4['error']),_0x32802e();};_0x3fbcc4['addEventListener']('success',_0x5ae276),_0x3fbcc4['addEventListener']('error',_0x2e6344);});return _0x1f82da['then'](_0x491685=>{_0x491685 instanceof IDBCursor&&Jr['set'](_0x491685,_0x3fbcc4);})['catch'](()=>{}),Wi['set'](_0x1f82da,_0x3fbcc4),_0x1f82da;}function Bc(_0x59b0fd){if(di['has'](_0x59b0fd))return;const _0x1c4d94=new Promise((_0x205201,_0x574aeb)=>{const _0x14f51f=()=>{_0x59b0fd['removeEventListener']('complete',_0x38ff19),_0x59b0fd['removeEventListener']('error',_0x464417),_0x59b0fd['removeEventListener']('abort',_0x464417);},_0x38ff19=()=>{_0x205201(),_0x14f51f();},_0x464417=()=>{_0x574aeb(_0x59b0fd['error']||new DOMException('AbortError','AbortError')),_0x14f51f();};_0x59b0fd['addEventListener']('complete',_0x38ff19),_0x59b0fd['addEventListener']('error',_0x464417),_0x59b0fd['addEventListener']('abort',_0x464417);});di['set'](_0x59b0fd,_0x1c4d94);}let fi={'get'(_0x36051a,_0x4b93e4,_0x3e6471){if(_0x36051a instanceof IDBTransaction){if(_0x4b93e4==='done')return di['get'](_0x36051a);if(_0x4b93e4==='objectStoreNames')return _0x36051a['objectStoreNames']||Xr['get'](_0x36051a);if(_0x4b93e4==='store')return _0x3e6471['objectStoreNames'][0x1]?void 0x0:_0x3e6471['objectStore'](_0x3e6471['objectStoreNames'][0x0]);}return _e(_0x36051a[_0x4b93e4]);},'set'(_0x5bbde5,_0x276cfc,_0x2de169){return _0x5bbde5[_0x276cfc]=_0x2de169,!0x0;},'has'(_0x45d5c3,_0x359235){return _0x45d5c3 instanceof IDBTransaction&&(_0x359235==='done'||_0x359235==='store')?!0x0:_0x359235 in _0x45d5c3;}};function Vc(_0xafc95c){fi=_0xafc95c(fi);}function Hc(_0xeffc87){return _0xeffc87===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x5bbdfe,..._0x96cd10){const _0x1e2467=_0xeffc87['call'](Zn(this),_0x5bbdfe,..._0x96cd10);return Xr['set'](_0x1e2467,_0x5bbdfe['sort']?_0x5bbdfe['sort']():[_0x5bbdfe]),_e(_0x1e2467);}:Uc()['includes'](_0xeffc87)?function(..._0x2be8eb){return _0xeffc87['apply'](Zn(this),_0x2be8eb),_e(Jr['get'](this));}:function(..._0x4fb177){return _e(_0xeffc87['apply'](Zn(this),_0x4fb177));};}function $c(_0x49b842){return typeof _0x49b842=='function'?Hc(_0x49b842):(_0x49b842 instanceof IDBTransaction&&Bc(_0x49b842),xc(_0x49b842,Fc())?new Proxy(_0x49b842,fi):_0x49b842);}function _e(_0x376e07){if(_0x376e07 instanceof IDBRequest)return Wc(_0x376e07);if(Xn['has'](_0x376e07))return Xn['get'](_0x376e07);const _0x5c629b=$c(_0x376e07);return _0x5c629b!==_0x376e07&&(Xn['set'](_0x376e07,_0x5c629b),Wi['set'](_0x5c629b,_0x376e07)),_0x5c629b;}const Zn=_0x4ab6eb=>Wi['get'](_0x4ab6eb);function Gc(_0x24795b,_0x2ab155,{blocked:_0x4c3809,upgrade:_0x52d83c,blocking:_0x52b305,terminated:_0x1911de}={}){const _0x3dec94=indexedDB['open'](_0x24795b,_0x2ab155),_0x4acfe9=_e(_0x3dec94);return _0x52d83c&&_0x3dec94['addEventListener']('upgradeneeded',_0x5dc445=>{_0x52d83c(_e(_0x3dec94['result']),_0x5dc445['oldVersion'],_0x5dc445['newVersion'],_e(_0x3dec94['transaction']),_0x5dc445);}),_0x4c3809&&_0x3dec94['addEventListener']('blocked',_0x479b99=>_0x4c3809(_0x479b99['oldVersion'],_0x479b99['newVersion'],_0x479b99)),_0x4acfe9['then'](_0x50c18a=>{_0x1911de&&_0x50c18a['addEventListener']('close',()=>_0x1911de()),_0x52b305&&_0x50c18a['addEventListener']('versionchange',_0x37b021=>_0x52b305(_0x37b021['oldVersion'],_0x37b021['newVersion'],_0x37b021));})['catch'](()=>{}),_0x4acfe9;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],ei=new Map();function Ls(_0x577545,_0x3f115b){if(!(_0x577545 instanceof IDBDatabase&&!(_0x3f115b in _0x577545)&&typeof _0x3f115b=='string'))return;if(ei['get'](_0x3f115b))return ei['get'](_0x3f115b);const _0x168933=_0x3f115b['replace'](/FromIndex$/,''),_0x9d9612=_0x3f115b!==_0x168933,_0x41da96=zc['includes'](_0x168933);if(!(_0x168933 in(_0x9d9612?IDBIndex:IDBObjectStore)['prototype'])||!(_0x41da96||qc['includes'](_0x168933)))return;const _0x5c67ab=async function(_0x246d83,..._0x4a1d8d){const _0x50917e=this['transaction'](_0x246d83,_0x41da96?'readwrite':'readonly');let _0x15c952=_0x50917e['store'];return _0x9d9612&&(_0x15c952=_0x15c952['index'](_0x4a1d8d['shift']())),(await Promise['all']([_0x15c952[_0x168933](..._0x4a1d8d),_0x41da96&&_0x50917e['done']]))[0x0];};return ei['set'](_0x3f115b,_0x5c67ab),_0x5c67ab;}Vc(_0x136581=>({..._0x136581,'get':(_0x413555,_0x2def9c,_0x79dbe)=>Ls(_0x413555,_0x2def9c)||_0x136581['get'](_0x413555,_0x2def9c,_0x79dbe),'has':(_0x49c604,_0x4d8dce)=>!!Ls(_0x49c604,_0x4d8dce)||_0x136581['has'](_0x49c604,_0x4d8dce)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x3fd577){this['container']=_0x3fd577;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x2678f6=>{if(Kc(_0x2678f6)){const _0x548266=_0x2678f6['getImmediate']();return _0x548266['library']+'/'+_0x548266['version'];}else return null;})['filter'](_0x4bd92c=>_0x4bd92c)['join']('\x20');}}function Kc(_0x25c35b){const _0x187c1e=_0x25c35b['getComponent']();return(_0x187c1e==null?void 0x0:_0x187c1e['type'])==='VERSION';}const pi='@firebase/app',xs='0.14.6',oe=new Ui('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.6.0',_i='[DEFAULT]',wl={[pi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},xe=new Map(),gi=new Map(),mi=new Map();function Fs(_0x533163,_0x48d784){try{_0x533163['container']['addComponent'](_0x48d784);}catch(_0x2d31db){oe['debug']('Component\x20'+_0x48d784['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x533163['name'],_0x2d31db);}}function Ze(_0x2779ed){const _0x4f39e9=_0x2779ed['name'];if(mi['has'](_0x4f39e9))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x4f39e9+'.'),!0x1;mi['set'](_0x4f39e9,_0x2779ed);for(const _0x3e42f9 of xe['values']())Fs(_0x3e42f9,_0x2779ed);for(const _0x3f0317 of gi['values']())Fs(_0x3f0317,_0x2779ed);return!0x0;}function Bi(_0x54522c,_0x24d86e){const _0x13aa95=_0x54522c['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x13aa95&&_0x13aa95['triggerHeartbeat'](),_0x54522c['container']['getProvider'](_0x24d86e);}function $(_0x39be3d){return _0x39be3d==null?!0x1:_0x39be3d['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Bt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x12a86f,_0x2d7112,_0x512c3e){this['_isDeleted']=!0x1,this['_options']={..._0x12a86f},this['_config']={..._0x2d7112},this['_name']=_0x2d7112['name'],this['_automaticDataCollectionEnabled']=_0x2d7112['automaticDataCollectionEnabled'],this['_container']=_0x512c3e,this['container']['addComponent'](new Le('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x4ca4b2){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x4ca4b2;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x34e6d6){this['_isDeleted']=_0x34e6d6;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const lt=Il;function Sl(_0x3b2368,_0x2078da={}){let _0x18adda=_0x3b2368;typeof _0x2078da!='object'&&(_0x2078da={'name':_0x2078da});const _0x5b28be={'name':_i,'automaticDataCollectionEnabled':!0x0,..._0x2078da},_0x14ea56=_0x5b28be['name'];if(typeof _0x14ea56!='string'||!_0x14ea56)throw ge['create']('bad-app-name',{'appName':String(_0x14ea56)});if(_0x18adda||(_0x18adda=qr()),!_0x18adda)throw ge['create']('no-options');const _0x2f8e5b=xe['get'](_0x14ea56);if(_0x2f8e5b){if(Me(_0x18adda,_0x2f8e5b['options'])&&Me(_0x5b28be,_0x2f8e5b['config']))return _0x2f8e5b;throw ge['create']('duplicate-app',{'appName':_0x14ea56});}const _0x10e956=new Pc(_0x14ea56);for(const _0x522c8e of mi['values']())_0x10e956['addComponent'](_0x522c8e);const _0x23369f=new Tl(_0x18adda,_0x5b28be,_0x10e956);return xe['set'](_0x14ea56,_0x23369f),_0x23369f;}function Zr(_0xc2ff28=_i){const _0x59a4eb=xe['get'](_0xc2ff28);if(!_0x59a4eb&&_0xc2ff28===_i&&qr())return Sl();if(!_0x59a4eb)throw ge['create']('no-app',{'appName':_0xc2ff28});return _0x59a4eb;}function f_(){return Array['from'](xe['values']());}async function p_(_0xa559cb){let _0x3da278=!0x1;const _0x36719b=_0xa559cb['name'];xe['has'](_0x36719b)?(_0x3da278=!0x0,xe['delete'](_0x36719b)):gi['has'](_0x36719b)&&_0xa559cb['decRefCount']()<=0x0&&(gi['delete'](_0x36719b),_0x3da278=!0x0),_0x3da278&&(await Promise['all'](_0xa559cb['container']['getProviders']()['map'](_0x2a8e95=>_0x2a8e95['delete']())),_0xa559cb['isDeleted']=!0x0);}function me(_0x32573d,_0x563d3,_0x12997b){let _0x2131b8=wl[_0x32573d]??_0x32573d;_0x12997b&&(_0x2131b8+='-'+_0x12997b);const _0x4ef362=_0x2131b8['match'](/\s|\//),_0x21d9fd=_0x563d3['match'](/\s|\//);if(_0x4ef362||_0x21d9fd){const _0x83c996=['Unable\x20to\x20register\x20library\x20\x22'+_0x2131b8+'\x22\x20with\x20version\x20\x22'+_0x563d3+'\x22:'];_0x4ef362&&_0x83c996['push']('library\x20name\x20\x22'+_0x2131b8+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x4ef362&&_0x21d9fd&&_0x83c996['push']('and'),_0x21d9fd&&_0x83c996['push']('version\x20name\x20\x22'+_0x563d3+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x83c996['join']('\x20'));return;}Ze(new Le(_0x2131b8+'-version',()=>({'library':_0x2131b8,'version':_0x563d3}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,kt='firebase-heartbeat-store';let ti=null;function eo(){return ti||(ti=Gc(bl,Rl,{'upgrade':(_0x1faf0b,_0x26e328)=>{switch(_0x26e328){case 0x0:try{_0x1faf0b['createObjectStore'](kt);}catch(_0x4b194b){console['warn'](_0x4b194b);}}}})['catch'](_0x344247=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x344247['message']});})),ti;}async function Al(_0x51d14b){try{const _0x1d0652=(await eo())['transaction'](kt),_0x16e84e=await _0x1d0652['objectStore'](kt)['get'](to(_0x51d14b));return await _0x1d0652['done'],_0x16e84e;}catch(_0x672fe2){if(_0x672fe2 instanceof Se)oe['warn'](_0x672fe2['message']);else{const _0x3dbf6a=ge['create']('idb-get',{'originalErrorMessage':_0x672fe2==null?void 0x0:_0x672fe2['message']});oe['warn'](_0x3dbf6a['message']);}}}async function Us(_0x555b74,_0xd1f08){try{const _0x3e7e42=(await eo())['transaction'](kt,'readwrite');await _0x3e7e42['objectStore'](kt)['put'](_0xd1f08,to(_0x555b74)),await _0x3e7e42['done'];}catch(_0x415c7a){if(_0x415c7a instanceof Se)oe['warn'](_0x415c7a['message']);else{const _0x2ecf9d=ge['create']('idb-set',{'originalErrorMessage':_0x415c7a==null?void 0x0:_0x415c7a['message']});oe['warn'](_0x2ecf9d['message']);}}}function to(_0x8eb732){return _0x8eb732['name']+'!'+_0x8eb732['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Nl=0x1e;class Pl{constructor(_0x465ef8){this['container']=_0x465ef8,this['_heartbeatsCache']=null;const _0x5f3b36=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x5f3b36),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x3228b6=>(this['_heartbeatsCache']=_0x3228b6,_0x3228b6));}async['triggerHeartbeat'](){var _0x5457fb,_0x24dc84;try{const _0x31c1db=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x37bb5d=Ws();if(((_0x5457fb=this['_heartbeatsCache'])==null?void 0x0:_0x5457fb['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x24dc84=this['_heartbeatsCache'])==null?void 0x0:_0x24dc84['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x37bb5d||this['_heartbeatsCache']['heartbeats']['some'](_0x1785bb=>_0x1785bb['date']===_0x37bb5d))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x37bb5d,'agent':_0x31c1db}),this['_heartbeatsCache']['heartbeats']['length']>Nl){const _0x121cd5=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x121cd5,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x2cca19){oe['warn'](_0x2cca19);}}async['getHeartbeatsHeader'](){var _0x850f01;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x850f01=this['_heartbeatsCache'])==null?void 0x0:_0x850f01['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x5b0b7d=Ws(),{heartbeatsToSend:_0x41a259,unsentEntries:_0x39cf6e}=Ol(this['_heartbeatsCache']['heartbeats']),_0x432797=cn(JSON['stringify']({'version':0x2,'heartbeats':_0x41a259}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x5b0b7d,_0x39cf6e['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x39cf6e,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x432797;}catch(_0x5b7728){return oe['warn'](_0x5b7728),'';}}}function Ws(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x27692c,_0x5c42f1=kl){const _0x384dfd=[];let _0x566cf3=_0x27692c['slice']();for(const _0x4b74a5 of _0x27692c){const _0x385ff0=_0x384dfd['find'](_0x3bec00=>_0x3bec00['agent']===_0x4b74a5['agent']);if(_0x385ff0){if(_0x385ff0['dates']['push'](_0x4b74a5['date']),Bs(_0x384dfd)>_0x5c42f1){_0x385ff0['dates']['pop']();break;}}else{if(_0x384dfd['push']({'agent':_0x4b74a5['agent'],'dates':[_0x4b74a5['date']]}),Bs(_0x384dfd)>_0x5c42f1){_0x384dfd['pop']();break;}}_0x566cf3=_0x566cf3['slice'](0x1);}return{'heartbeatsToSend':_0x384dfd,'unsentEntries':_0x566cf3};}class Dl{constructor(_0x2c03a0){this['app']=_0x2c03a0,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x4f5c37=await Al(this['app']);return _0x4f5c37!=null&&_0x4f5c37['heartbeats']?_0x4f5c37:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x5a3708){if(await this['_canUseIndexedDBPromise']){const _0x3a9856=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x5a3708['lastSentHeartbeatDate']??_0x3a9856['lastSentHeartbeatDate'],'heartbeats':_0x5a3708['heartbeats']});}else return;}async['add'](_0x3eb86e){if(await this['_canUseIndexedDBPromise']){const _0x227f70=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x3eb86e['lastSentHeartbeatDate']??_0x227f70['lastSentHeartbeatDate'],'heartbeats':[..._0x227f70['heartbeats'],..._0x3eb86e['heartbeats']]});}else return;}}function Bs(_0x72f526){return cn(JSON['stringify']({'version':0x2,'heartbeats':_0x72f526}))['length'];}function Ml(_0x3dfee3){if(_0x3dfee3['length']===0x0)return-0x1;let _0x556f70=0x0,_0x1fd4a1=_0x3dfee3[0x0]['date'];for(let _0x3413c5=0x1;_0x3413c5<_0x3dfee3['length'];_0x3413c5++)_0x3dfee3[_0x3413c5]['date']<_0x1fd4a1&&(_0x1fd4a1=_0x3dfee3[_0x3413c5]['date'],_0x556f70=_0x3413c5);return _0x556f70;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x3280ff){Ze(new Le('platform-logger',_0x28620d=>new jc(_0x28620d),'PRIVATE')),Ze(new Le('heartbeat',_0x43e552=>new Pl(_0x43e552),'PRIVATE')),me(pi,xs,_0x3280ff),me(pi,xs,'esm2020'),me('fire-js','');}Ll('');var xl='firebase',Fl='12.6.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(xl,Fl,'app');var Vs={};const Hs='@firebase/database',$s='1.1.0';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x372519){no=_0x372519;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x46a2e9){this['domStorage_']=_0x46a2e9,this['prefix_']='firebase:';}['set'](_0x3752e7,_0x194430){_0x194430==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x3752e7)):this['domStorage_']['setItem'](this['prefixedName_'](_0x3752e7),O(_0x194430));}['get'](_0x39e4a2){const _0x1d78b1=this['domStorage_']['getItem'](this['prefixedName_'](_0x39e4a2));return _0x1d78b1==null?null:At(_0x1d78b1);}['remove'](_0x401f65){this['domStorage_']['removeItem'](this['prefixedName_'](_0x401f65));}['prefixedName_'](_0x441d71){return this['prefix_']+_0x441d71;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x34c33f,_0x1ba2c3){_0x1ba2c3==null?delete this['cache_'][_0x34c33f]:this['cache_'][_0x34c33f]=_0x1ba2c3;}['get'](_0x20a3ce){return J(this['cache_'],_0x20a3ce)?this['cache_'][_0x20a3ce]:null;}['remove'](_0x46cb2f){delete this['cache_'][_0x46cb2f];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x517f0f){try{if(typeof window<'u'&&typeof window[_0x517f0f]<'u'){const _0x12d5a2=window[_0x517f0f];return _0x12d5a2['setItem']('firebase:sentinel','cache'),_0x12d5a2['removeItem']('firebase:sentinel'),new Wl(_0x12d5a2);}}catch{}return new Bl();},Oe=io('localStorage'),Vl=io('sessionStorage'),Ye=new Ui('@firebase/database'),so=(function(){let _0x5966cf=0x1;return function(){return _0x5966cf++;};}()),ro=function(_0x4fa715){const _0x552269=Rc(_0x4fa715),_0x5766c8=new Cc();_0x5766c8['update'](_0x552269);const _0x15decc=_0x5766c8['digest']();return Li['encodeByteArray'](_0x15decc);},Vt=function(..._0x334621){let _0x12e663='';for(let _0x29ab8a=0x0;_0x29ab8a<_0x334621['length'];_0x29ab8a++){const _0x227f7c=_0x334621[_0x29ab8a];Array['isArray'](_0x227f7c)||_0x227f7c&&typeof _0x227f7c=='object'&&typeof _0x227f7c['length']=='number'?_0x12e663+=Vt['apply'](null,_0x227f7c):typeof _0x227f7c=='object'?_0x12e663+=O(_0x227f7c):_0x12e663+=_0x227f7c,_0x12e663+='\x20';}return _0x12e663;};let wt=null,Gs=!0x0;const Hl=function(_0xae5997,_0x2455ed){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ye['logLevel']=T['VERBOSE'],wt=Ye['log']['bind'](Ye);},L=function(..._0x1f3ded){if(Gs===!0x0&&(Gs=!0x1,wt===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),wt){const _0x22e6e7=Vt['apply'](null,_0x1f3ded);wt(_0x22e6e7);}},Ht=function(_0x5bce4d){return function(..._0x1f0c18){L(_0x5bce4d,..._0x1f0c18);};},yi=function(..._0x6e0025){const _0x342d92='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Vt(..._0x6e0025);Ye['error'](_0x342d92);},ae=function(..._0x20bcb1){const _0x6ff8e4='FIREBASE\x20FATAL\x20ERROR:\x20'+Vt(..._0x20bcb1);throw Ye['error'](_0x6ff8e4),new Error(_0x6ff8e4);},U=function(..._0x54fbc1){const _0x5a917a='FIREBASE\x20WARNING:\x20'+Vt(..._0x54fbc1);Ye['warn'](_0x5a917a);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Vi=function(_0x4e2bf4){return typeof _0x4e2bf4=='number'&&(_0x4e2bf4!==_0x4e2bf4||_0x4e2bf4===Number['POSITIVE_INFINITY']||_0x4e2bf4===Number['NEGATIVE_INFINITY']);},Gl=function(_0x4621c4){if(document['readyState']==='complete')_0x4621c4();else{let _0x5021fa=!0x1;const _0x5b893e=function(){if(!document['body']){setTimeout(_0x5b893e,Math['floor'](0xa));return;}_0x5021fa||(_0x5021fa=!0x0,_0x4621c4());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x5b893e,!0x1),window['addEventListener']('load',_0x5b893e,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x5b893e();}),window['attachEvent']('onload',_0x5b893e));}},Fe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x200f9f,_0x418411){if(_0x200f9f===_0x418411)return 0x0;if(_0x200f9f===Fe||_0x418411===Ie)return-0x1;if(_0x418411===Fe||_0x200f9f===Ie)return 0x1;{const _0x5d85d8=qs(_0x200f9f),_0x35a7ab=qs(_0x418411);return _0x5d85d8!==null?_0x35a7ab!==null?_0x5d85d8-_0x35a7ab===0x0?_0x200f9f['length']-_0x418411['length']:_0x5d85d8-_0x35a7ab:-0x1:_0x35a7ab!==null?0x1:_0x200f9f<_0x418411?-0x1:0x1;}},ql=function(_0x3824b9,_0x443cac){return _0x3824b9===_0x443cac?0x0:_0x3824b9<_0x443cac?-0x1:0x1;},_t=function(_0x1b10f0,_0x4d8b63){if(_0x4d8b63&&_0x1b10f0 in _0x4d8b63)return _0x4d8b63[_0x1b10f0];throw new Error('Missing\x20required\x20key\x20('+_0x1b10f0+')\x20in\x20object:\x20'+O(_0x4d8b63));},Hi=function(_0x25a70a){if(typeof _0x25a70a!='object'||_0x25a70a===null)return O(_0x25a70a);const _0xb41c43=[];for(const _0x1fac32 in _0x25a70a)_0xb41c43['push'](_0x1fac32);_0xb41c43['sort']();let _0x312442='{';for(let _0x277c2e=0x0;_0x277c2e<_0xb41c43['length'];_0x277c2e++)_0x277c2e!==0x0&&(_0x312442+=','),_0x312442+=O(_0xb41c43[_0x277c2e]),_0x312442+=':',_0x312442+=Hi(_0x25a70a[_0xb41c43[_0x277c2e]]);return _0x312442+='}',_0x312442;},oo=function(_0x2ffcfe,_0x159684){const _0x1e6de1=_0x2ffcfe['length'];if(_0x1e6de1<=_0x159684)return[_0x2ffcfe];const _0x303e82=[];for(let _0x24d3a7=0x0;_0x24d3a7<_0x1e6de1;_0x24d3a7+=_0x159684)_0x24d3a7+_0x159684>_0x1e6de1?_0x303e82['push'](_0x2ffcfe['substring'](_0x24d3a7,_0x1e6de1)):_0x303e82['push'](_0x2ffcfe['substring'](_0x24d3a7,_0x24d3a7+_0x159684));return _0x303e82;};function x(_0x1ccade,_0x1e3637){for(const _0x340d6a in _0x1ccade)_0x1ccade['hasOwnProperty'](_0x340d6a)&&_0x1e3637(_0x340d6a,_0x1ccade[_0x340d6a]);}const ao=function(_0x297485){f(!Vi(_0x297485),'Invalid\x20JSON\x20number');const _0xe70a42=0xb,_0x496d44=0x34,_0x15fbbd=(0x1<<_0xe70a42-0x1)-0x1;let _0x5d5b11,_0x4c509b,_0x479975,_0x363fa1,_0xd26af9;_0x297485===0x0?(_0x4c509b=0x0,_0x479975=0x0,_0x5d5b11=0x1/_0x297485===-0x1/0x0?0x1:0x0):(_0x5d5b11=_0x297485<0x0,_0x297485=Math['abs'](_0x297485),_0x297485>=Math['pow'](0x2,0x1-_0x15fbbd)?(_0x363fa1=Math['min'](Math['floor'](Math['log'](_0x297485)/Math['LN2']),_0x15fbbd),_0x4c509b=_0x363fa1+_0x15fbbd,_0x479975=Math['round'](_0x297485*Math['pow'](0x2,_0x496d44-_0x363fa1)-Math['pow'](0x2,_0x496d44))):(_0x4c509b=0x0,_0x479975=Math['round'](_0x297485/Math['pow'](0x2,0x1-_0x15fbbd-_0x496d44))));const _0x11c665=[];for(_0xd26af9=_0x496d44;_0xd26af9;_0xd26af9-=0x1)_0x11c665['push'](_0x479975%0x2?0x1:0x0),_0x479975=Math['floor'](_0x479975/0x2);for(_0xd26af9=_0xe70a42;_0xd26af9;_0xd26af9-=0x1)_0x11c665['push'](_0x4c509b%0x2?0x1:0x0),_0x4c509b=Math['floor'](_0x4c509b/0x2);_0x11c665['push'](_0x5d5b11?0x1:0x0),_0x11c665['reverse']();const _0x4c7634=_0x11c665['join']('');let _0x474134='';for(_0xd26af9=0x0;_0xd26af9<0x40;_0xd26af9+=0x8){let _0xb49b49=parseInt(_0x4c7634['substr'](_0xd26af9,0x8),0x2)['toString'](0x10);_0xb49b49['length']===0x1&&(_0xb49b49='0'+_0xb49b49),_0x474134=_0x474134+_0xb49b49;}return _0x474134['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x2b0560,_0x2f9e8d){let _0x251028='Unknown\x20Error';_0x2b0560==='too_big'?_0x251028='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x2b0560==='permission_denied'?_0x251028='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x2b0560==='unavailable'&&(_0x251028='The\x20service\x20is\x20unavailable');const _0x247a8e=new Error(_0x2b0560+'\x20at\x20'+_0x2f9e8d['_path']['toString']()+':\x20'+_0x251028);return _0x247a8e['code']=_0x2b0560['toUpperCase'](),_0x247a8e;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,qs=function(_0x4f0d58){if(Yl['test'](_0x4f0d58)){const _0x27886d=Number(_0x4f0d58);if(_0x27886d>=Ql&&_0x27886d<=Jl)return _0x27886d;}return null;},ht=function(_0x1c9703){try{_0x1c9703();}catch(_0x4c5787){setTimeout(()=>{const _0x580718=_0x4c5787['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x580718),_0x4c5787;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},Ct=function(_0x4a17cf,_0x2d223c){const _0x262d0f=setTimeout(_0x4a17cf,_0x2d223c);return typeof _0x262d0f=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x262d0f):typeof _0x262d0f=='object'&&_0x262d0f['unref']&&_0x262d0f['unref'](),_0x262d0f;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x311f12,_0x2c2aed){this['appCheckProvider']=_0x2c2aed,this['appName']=_0x311f12['name'],$(_0x311f12)&&_0x311f12['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x311f12['settings']['appCheckToken']),this['appCheck']=_0x2c2aed==null?void 0x0:_0x2c2aed['getImmediate']({'optional':!0x0}),this['appCheck']||_0x2c2aed==null||_0x2c2aed['get']()['then'](_0x581259=>this['appCheck']=_0x581259);}['getToken'](_0x19e4fd){if(this['serverAppAppCheckToken']){if(_0x19e4fd)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x19e4fd):new Promise((_0x1d846c,_0x2a9231)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x19e4fd)['then'](_0x1d846c,_0x2a9231):_0x1d846c(null);},0x0);});}['addTokenChangeListener'](_0x4b7335){var _0x22d386;(_0x22d386=this['appCheckProvider'])==null||_0x22d386['get']()['then'](_0x28a4e0=>_0x28a4e0['addTokenListener'](_0x4b7335));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0xa9f5e4,_0x2ea574,_0xbe199b){this['appName_']=_0xa9f5e4,this['firebaseOptions_']=_0x2ea574,this['authProvider_']=_0xbe199b,this['auth_']=null,this['auth_']=_0xbe199b['getImmediate']({'optional':!0x0}),this['auth_']||_0xbe199b['onInit'](_0x477c77=>this['auth_']=_0x477c77);}['getToken'](_0x18f333){return this['auth_']?this['auth_']['getToken'](_0x18f333)['catch'](_0x364c00=>_0x364c00&&_0x364c00['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x364c00)):new Promise((_0x1ca313,_0x514761)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x18f333)['then'](_0x1ca313,_0x514761):_0x1ca313(null);},0x0);});}['addTokenChangeListener'](_0xd0ecc5){this['auth_']?this['auth_']['addAuthTokenListener'](_0xd0ecc5):this['authProvider_']['get']()['then'](_0x3b8469=>_0x3b8469['addAuthTokenListener'](_0xd0ecc5));}['removeTokenChangeListener'](_0x160eae){this['authProvider_']['get']()['then'](_0x5ccf8e=>_0x5ccf8e['removeAuthTokenListener'](_0x160eae));}['notifyForInvalidToken'](){let _0x34d664='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x34d664+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x34d664+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x34d664+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x34d664);}}class nn{constructor(_0x2561ec){this['accessToken']=_0x2561ec;}['getToken'](_0x438efa){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x206068){_0x206068(this['accessToken']);}['removeTokenChangeListener'](_0x290018){}['notifyForInvalidToken'](){}}nn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $i='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',vi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x238010,_0x3c4617,_0x36096c,_0x3b12d4,_0x26dc0e=!0x1,_0x328dbf='',_0x1c743b=!0x1,_0x2437e8=!0x1,_0x446f26=null){this['secure']=_0x3c4617,this['namespace']=_0x36096c,this['webSocketOnly']=_0x3b12d4,this['nodeAdmin']=_0x26dc0e,this['persistenceKey']=_0x328dbf,this['includeNamespaceInQueryParams']=_0x1c743b,this['isUsingEmulator']=_0x2437e8,this['emulatorOptions']=_0x446f26,this['_host']=_0x238010['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Oe['get']('host:'+_0x238010)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x3979d6){_0x3979d6!==this['internalHost']&&(this['internalHost']=_0x3979d6,this['isCacheableHost']()&&Oe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x54fc58=this['toURLString']();return this['persistenceKey']&&(_0x54fc58+='<'+this['persistenceKey']+'>'),_0x54fc58;}['toURLString'](){const _0x4019eb=this['secure']?'https://':'http://',_0x50941a=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x4019eb+this['host']+'/'+_0x50941a;}}function th(_0x15060b){return _0x15060b['host']!==_0x15060b['internalHost']||_0x15060b['isCustomHost']()||_0x15060b['includeNamespaceInQueryParams'];}function vo(_0x293dd2,_0x52afb2,_0x50706c){f(typeof _0x52afb2=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x50706c=='object','typeof\x20params\x20must\x20==\x20object');let _0x5afe03;if(_0x52afb2===go)_0x5afe03=(_0x293dd2['secure']?'wss://':'ws://')+_0x293dd2['internalHost']+'/.ws?';else{if(_0x52afb2===mo)_0x5afe03=(_0x293dd2['secure']?'https://':'http://')+_0x293dd2['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x52afb2);}th(_0x293dd2)&&(_0x50706c['ns']=_0x293dd2['namespace']);const _0x3fa27d=[];return x(_0x50706c,(_0x5e8b6c,_0x59f357)=>{_0x3fa27d['push'](_0x5e8b6c+'='+_0x59f357);}),_0x5afe03+_0x3fa27d['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x565513,_0x4e726d=0x1){J(this['counters_'],_0x565513)||(this['counters_'][_0x565513]=0x0),this['counters_'][_0x565513]+=_0x4e726d;}['get'](){return nc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ni={},ii={};function Gi(_0x13c5e1){const _0xb69f59=_0x13c5e1['toString']();return ni[_0xb69f59]||(ni[_0xb69f59]=new nh()),ni[_0xb69f59];}function ih(_0x59770c,_0x46742a){const _0x112b56=_0x59770c['toString']();return ii[_0x112b56]||(ii[_0x112b56]=_0x46742a()),ii[_0x112b56];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x660b09){this['onMessage_']=_0x660b09,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x515924,_0x3b1360){this['closeAfterResponse']=_0x515924,this['onClose']=_0x3b1360,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x4f536c,_0x581b23){for(this['pendingResponses'][_0x4f536c]=_0x581b23;this['pendingResponses'][this['currentResponseNum']];){const _0x242a5f=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x208eff=0x0;_0x208eff<_0x242a5f['length'];++_0x208eff)_0x242a5f[_0x208eff]&&ht(()=>{this['onMessage_'](_0x242a5f[_0x208eff]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class je{constructor(_0x281606,_0x3cd7d0,_0x986261,_0xd4f46e,_0x5e5d51,_0x26d175,_0x4ae9d6){this['connId']=_0x281606,this['repoInfo']=_0x3cd7d0,this['applicationId']=_0x986261,this['appCheckToken']=_0xd4f46e,this['authToken']=_0x5e5d51,this['transportSessionId']=_0x26d175,this['lastSessionId']=_0x4ae9d6,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Ht(_0x281606),this['stats_']=Gi(_0x3cd7d0),this['urlFn']=_0x2870fa=>(this['appCheckToken']&&(_0x2870fa[vi]=this['appCheckToken']),vo(_0x3cd7d0,mo,_0x2870fa));}['open'](_0x44fa77,_0x33a6b6){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x33a6b6,this['myPacketOrderer']=new sh(_0x44fa77),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new qi((..._0xac7c55)=>{const [_0x1b1d48,_0x511237,_0x2473e5,_0x47b9ee,_0x2905c3]=_0xac7c55;if(this['incrementIncomingBytes_'](_0xac7c55),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x1b1d48===zs)this['id']=_0x511237,this['password']=_0x2473e5;else{if(_0x1b1d48===rh)_0x511237?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x511237,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x1b1d48);}}},(..._0x40140a)=>{const [_0x46a647,_0x228960]=_0x40140a;this['incrementIncomingBytes_'](_0x40140a),this['myPacketOrderer']['handleResponse'](_0x46a647,_0x228960);},()=>{this['onClosed_']();},this['urlFn']);const _0x520840={};_0x520840[zs]='t',_0x520840[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x520840[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x520840[co]=$i,this['transportSessionId']&&(_0x520840[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x520840[po]=this['lastSessionId']),this['applicationId']&&(_0x520840[_o]=this['applicationId']),this['appCheckToken']&&(_0x520840[vi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x520840[ho]=uo);const _0x2f0a4a=this['urlFn'](_0x520840);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x2f0a4a),this['scriptTagHolder']['addTag'](_0x2f0a4a,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){je['forceAllow_']=!0x0;}static['forceDisallow'](){je['forceDisallow_']=!0x0;}static['isAvailable'](){return je['forceAllow_']?!0x0:!je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0xd427c){const _0x31cd5c=O(_0xd427c);this['bytesSent']+=_0x31cd5c['length'],this['stats_']['incrementCounter']('bytes_sent',_0x31cd5c['length']);const _0x3d697c=Hr(_0x31cd5c),_0x20b7b2=oo(_0x3d697c,fh);for(let _0x5b7d67=0x0;_0x5b7d67<_0x20b7b2['length'];_0x5b7d67++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x20b7b2['length'],_0x20b7b2[_0x5b7d67]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x18726d,_0xa758dd){this['myDisconnFrame']=document['createElement']('iframe');const _0xf4f2e2={};_0xf4f2e2[dh]='t',_0xf4f2e2[Eo]=_0x18726d,_0xf4f2e2[Io]=_0xa758dd,this['myDisconnFrame']['src']=this['urlFn'](_0xf4f2e2),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x231245){const _0x3c1b62=O(_0x231245)['length'];this['bytesReceived']+=_0x3c1b62,this['stats_']['incrementCounter']('bytes_received',_0x3c1b62);}}class qi{constructor(_0x54c543,_0x3875b8,_0xde72bb,_0x3ec18f){this['onDisconnect']=_0xde72bb,this['urlFn']=_0x3ec18f,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x54c543,window[ah+this['uniqueCallbackIdentifier']]=_0x3875b8,this['myIFrame']=qi['createIFrame_']();let _0x202334='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x202334='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0xe1d6ae='<html><body>'+_0x202334+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0xe1d6ae),this['myIFrame']['doc']['close']();}catch(_0xba2890){L('frame\x20writing\x20exception'),_0xba2890['stack']&&L(_0xba2890['stack']),L(_0xba2890);}}}static['createIFrame_'](){const _0x5b0335=document['createElement']('iframe');if(_0x5b0335['style']['display']='none',document['body']){document['body']['appendChild'](_0x5b0335);try{_0x5b0335['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x5338cb=document['domain'];_0x5b0335['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x5338cb+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x5b0335['contentDocument']?_0x5b0335['doc']=_0x5b0335['contentDocument']:_0x5b0335['contentWindow']?_0x5b0335['doc']=_0x5b0335['contentWindow']['document']:_0x5b0335['document']&&(_0x5b0335['doc']=_0x5b0335['document']),_0x5b0335;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x29fbdf=this['onDisconnect'];_0x29fbdf&&(this['onDisconnect']=null,_0x29fbdf());}['startLongPoll'](_0x2155ed,_0x3bdb5b){for(this['myID']=_0x2155ed,this['myPW']=_0x3bdb5b,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x3cb5a1={};_0x3cb5a1[Eo]=this['myID'],_0x3cb5a1[Io]=this['myPW'],_0x3cb5a1[wo]=this['currentSerial'];let _0x24584c=this['urlFn'](_0x3cb5a1),_0x235f20='',_0x5770f9=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x235f20['length']<=Co;){const _0x256ce4=this['pendingSegs']['shift']();_0x235f20=_0x235f20+'&'+lh+_0x5770f9+'='+_0x256ce4['seg']+'&'+hh+_0x5770f9+'='+_0x256ce4['ts']+'&'+uh+_0x5770f9+'='+_0x256ce4['d'],_0x5770f9++;}return _0x24584c=_0x24584c+_0x235f20,this['addLongPollTag_'](_0x24584c,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x519968,_0x540cad,_0x31fe51){this['pendingSegs']['push']({'seg':_0x519968,'ts':_0x540cad,'d':_0x31fe51}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x1130db,_0x188779){this['outstandingRequests']['add'](_0x188779);const _0x4743bc=()=>{this['outstandingRequests']['delete'](_0x188779),this['newRequest_']();},_0xb7f95b=setTimeout(_0x4743bc,Math['floor'](ph)),_0x59e56e=()=>{clearTimeout(_0xb7f95b),_0x4743bc();};this['addTag'](_0x1130db,_0x59e56e);}['addTag'](_0x21934e,_0x2dc83e){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x3bdbea=this['myIFrame']['doc']['createElement']('script');_0x3bdbea['type']='text/javascript',_0x3bdbea['async']=!0x0,_0x3bdbea['src']=_0x21934e,_0x3bdbea['onload']=_0x3bdbea['onreadystatechange']=function(){const _0x492049=_0x3bdbea['readyState'];(!_0x492049||_0x492049==='loaded'||_0x492049==='complete')&&(_0x3bdbea['onload']=_0x3bdbea['onreadystatechange']=null,_0x3bdbea['parentNode']&&_0x3bdbea['parentNode']['removeChild'](_0x3bdbea),_0x2dc83e());},_0x3bdbea['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x21934e),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x3bdbea);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let un=null;typeof MozWebSocket<'u'?un=MozWebSocket:typeof WebSocket<'u'&&(un=WebSocket);class z{constructor(_0x484081,_0x428a7d,_0x4ce71a,_0x1e7aef,_0x26f11f,_0x53ff48,_0x3fddf3){this['connId']=_0x484081,this['applicationId']=_0x4ce71a,this['appCheckToken']=_0x1e7aef,this['authToken']=_0x26f11f,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Ht(this['connId']),this['stats_']=Gi(_0x428a7d),this['connURL']=z['connectionURL_'](_0x428a7d,_0x53ff48,_0x3fddf3,_0x1e7aef,_0x4ce71a),this['nodeAdmin']=_0x428a7d['nodeAdmin'];}static['connectionURL_'](_0x20b899,_0x5271ba,_0x3e8905,_0x1adf56,_0x4dee28){const _0x4c3442={};return _0x4c3442[co]=$i,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x4c3442[ho]=uo),_0x5271ba&&(_0x4c3442[lo]=_0x5271ba),_0x3e8905&&(_0x4c3442[po]=_0x3e8905),_0x1adf56&&(_0x4c3442[vi]=_0x1adf56),_0x4dee28&&(_0x4c3442[_o]=_0x4dee28),vo(_0x20b899,go,_0x4c3442);}['open'](_0x10b259,_0x5897fb){this['onDisconnect']=_0x5897fb,this['onMessage']=_0x10b259,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Oe['set']('previous_websocket_failure',!0x0);try{let _0x769bf6;_c(),this['mySock']=new un(this['connURL'],[],_0x769bf6);}catch(_0x4b2f2d){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x1c5260=_0x4b2f2d['message']||_0x4b2f2d['data'];_0x1c5260&&this['log_'](_0x1c5260),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x2d139c=>{this['handleIncomingFrame'](_0x2d139c);},this['mySock']['onerror']=_0x5da815=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x2ceb82=_0x5da815['message']||_0x5da815['data'];_0x2ceb82&&this['log_'](_0x2ceb82),this['onClosed_']();};}['start'](){}static['forceDisallow'](){z['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x470671=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x5a877c=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x33146d=navigator['userAgent']['match'](_0x5a877c);_0x33146d&&_0x33146d['length']>0x1&&parseFloat(_0x33146d[0x1])<4.4&&(_0x470671=!0x0);}return!_0x470671&&un!==null&&!z['forceDisallow_'];}static['previouslyFailed'](){return Oe['isInMemoryStorage']||Oe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Oe['remove']('previous_websocket_failure');}['appendFrame_'](_0x40ab90){if(this['frames']['push'](_0x40ab90),this['frames']['length']===this['totalFrames']){const _0x19c368=this['frames']['join']('');this['frames']=null;const _0x36a685=At(_0x19c368);this['onMessage'](_0x36a685);}}['handleNewFrameCount_'](_0x1a1afd){this['totalFrames']=_0x1a1afd,this['frames']=[];}['extractFrameCount_'](_0x2d08f5){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x2d08f5['length']<=0x6){const _0x35117c=Number(_0x2d08f5);if(!isNaN(_0x35117c))return this['handleNewFrameCount_'](_0x35117c),null;}return this['handleNewFrameCount_'](0x1),_0x2d08f5;}['handleIncomingFrame'](_0x1ed7ed){if(this['mySock']===null)return;const _0x30b542=_0x1ed7ed['data'];if(this['bytesReceived']+=_0x30b542['length'],this['stats_']['incrementCounter']('bytes_received',_0x30b542['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x30b542);else{const _0x2a00e8=this['extractFrameCount_'](_0x30b542);_0x2a00e8!==null&&this['appendFrame_'](_0x2a00e8);}}['send'](_0x5da028){this['resetKeepAlive']();const _0x3176dd=O(_0x5da028);this['bytesSent']+=_0x3176dd['length'],this['stats_']['incrementCounter']('bytes_sent',_0x3176dd['length']);const _0x199c14=oo(_0x3176dd,gh);_0x199c14['length']>0x1&&this['sendString_'](String(_0x199c14['length']));for(let _0x298d39=0x0;_0x298d39<_0x199c14['length'];_0x298d39++)this['sendString_'](_0x199c14[_0x298d39]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x1e94ba){try{this['mySock']['send'](_0x1e94ba);}catch(_0x35acc4){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x35acc4['message']||_0x35acc4['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}z['responsesRequiredToBeHealthy']=0x2,z['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nt{static get['ALL_TRANSPORTS'](){return[je,z];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x46bbb6){this['initTransports_'](_0x46bbb6);}['initTransports_'](_0x55b139){const _0x5901b7=z&&z['isAvailable']();let _0x5655ac=_0x5901b7&&!z['previouslyFailed']();if(_0x55b139['webSocketOnly']&&(_0x5901b7||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x5655ac=!0x0),_0x5655ac)this['transports_']=[z];else{const _0x5ae5a6=this['transports_']=[];for(const _0x4b7c84 of Nt['ALL_TRANSPORTS'])_0x4b7c84&&_0x4b7c84['isAvailable']()&&_0x5ae5a6['push'](_0x4b7c84);Nt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Nt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,si='t',js='d',wh='s',Ks='r',Ch='e',Ys='o',Qs='a',Js='n',Xs='p',Th='h';class Sh{constructor(_0xc6ead0,_0x26b98f,_0x243244,_0x4ed1c5,_0x2505b7,_0x203b3f,_0x24d4c0,_0x13e191,_0x2624cb,_0x423fb1){this['id']=_0xc6ead0,this['repoInfo_']=_0x26b98f,this['applicationId_']=_0x243244,this['appCheckToken_']=_0x4ed1c5,this['authToken_']=_0x2505b7,this['onMessage_']=_0x203b3f,this['onReady_']=_0x24d4c0,this['onDisconnect_']=_0x13e191,this['onKill_']=_0x2624cb,this['lastSessionId']=_0x423fb1,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Ht('c:'+this['id']+':'),this['transportManager_']=new Nt(_0x26b98f),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x55694a=this['transportManager_']['initialTransport']();this['conn_']=new _0x55694a(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x55694a['responsesRequiredToBeHealthy']||0x0;const _0x2e75c4=this['connReceiver_'](this['conn_']),_0x281600=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x2e75c4,_0x281600);},Math['floor'](0x0));const _0x4714b9=_0x55694a['healthyTimeout']||0x0;_0x4714b9>0x0&&(this['healthyTimeout_']=Ct(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x4714b9)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x3772cf){return _0x282dd8=>{_0x3772cf===this['conn_']?this['onConnectionLost_'](_0x282dd8):_0x3772cf===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x152945){return _0x550ef5=>{this['state_']!==0x2&&(_0x152945===this['rx_']?this['onPrimaryMessageReceived_'](_0x550ef5):_0x152945===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x550ef5):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x1f11f5){const _0x2dbf16={'t':'d','d':_0x1f11f5};this['sendData_'](_0x2dbf16);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x465d1b){if(si in _0x465d1b){const _0x433000=_0x465d1b[si];_0x433000===Qs?this['upgradeIfSecondaryHealthy_']():_0x433000===Ks?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x433000===Ys&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x378a6b){const _0x28004b=_t('t',_0x378a6b),_0x4ba7b4=_t('d',_0x378a6b);if(_0x28004b==='c')this['onSecondaryControl_'](_0x4ba7b4);else{if(_0x28004b==='d')this['pendingDataMessages']['push'](_0x4ba7b4);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x28004b);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Xs,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Js,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x58338c){const _0x27c025=_t('t',_0x58338c),_0x36f8e9=_t('d',_0x58338c);_0x27c025==='c'?this['onControl_'](_0x36f8e9):_0x27c025==='d'&&this['onDataMessage_'](_0x36f8e9);}['onDataMessage_'](_0x48ac47){this['onPrimaryResponse_'](),this['onMessage_'](_0x48ac47);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x33cd62){const _0x5d1ee0=_t(si,_0x33cd62);if(js in _0x33cd62){const _0x5baf60=_0x33cd62[js];if(_0x5d1ee0===Th){const _0x2e030c={..._0x5baf60};this['repoInfo_']['isUsingEmulator']&&(_0x2e030c['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x2e030c);}else{if(_0x5d1ee0===Js){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x1c09c2=0x0;_0x1c09c2<this['pendingDataMessages']['length'];++_0x1c09c2)this['onDataMessage_'](this['pendingDataMessages'][_0x1c09c2]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x5d1ee0===wh?this['onConnectionShutdown_'](_0x5baf60):_0x5d1ee0===Ks?this['onReset_'](_0x5baf60):_0x5d1ee0===Ch?yi('Server\x20Error:\x20'+_0x5baf60):_0x5d1ee0===Ys?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):yi('Unknown\x20control\x20packet\x20command:\x20'+_0x5d1ee0);}}}['onHandshake_'](_0x14b91a){const _0x582155=_0x14b91a['ts'],_0x5a7dfb=_0x14b91a['v'],_0x301bff=_0x14b91a['h'];this['sessionId']=_0x14b91a['s'],this['repoInfo_']['host']=_0x301bff,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x582155),$i!==_0x5a7dfb&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x26eef0=this['transportManager_']['upgradeTransport']();_0x26eef0&&this['startUpgrade_'](_0x26eef0);}['startUpgrade_'](_0x79fef9){this['secondaryConn_']=new _0x79fef9(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x79fef9['responsesRequiredToBeHealthy']||0x0;const _0x3782c3=this['connReceiver_'](this['secondaryConn_']),_0x50dd1d=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x3782c3,_0x50dd1d),Ct(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x52daa1){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x52daa1),this['repoInfo_']['host']=_0x52daa1,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x23e2bc,_0x31cd0e){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x23e2bc,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x31cd0e,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):Ct(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Xs,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x35e5cc=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x35e5cc||this['rx_']===_0x35e5cc)&&this['close']();}['onConnectionLost_'](_0x23837b){this['conn_']=null,!_0x23837b&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Oe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x574436){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x574436),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x5cfe32){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x5cfe32);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0xdc7316,_0x182959,_0x1f0e4f,_0x51ee52){}['merge'](_0x37c6d1,_0x34d154,_0x85b93c,_0x90c4fe){}['refreshAuthToken'](_0x20895c){}['refreshAppCheckToken'](_0x44cbc6){}['onDisconnectPut'](_0x191736,_0x51da75,_0x4ceaf8){}['onDisconnectMerge'](_0xea0273,_0x5c57d3,_0x5da7e6){}['onDisconnectCancel'](_0x55aec9,_0x1e265d){}['reportStats'](_0x38acd4){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x499369){this['allowedEvents_']=_0x499369,this['listeners_']={},f(Array['isArray'](_0x499369)&&_0x499369['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x3da783,..._0x3912e8){if(Array['isArray'](this['listeners_'][_0x3da783])){const _0x47a093=[...this['listeners_'][_0x3da783]];for(let _0x4a3aba=0x0;_0x4a3aba<_0x47a093['length'];_0x4a3aba++)_0x47a093[_0x4a3aba]['callback']['apply'](_0x47a093[_0x4a3aba]['context'],_0x3912e8);}}['on'](_0x2a4e35,_0x31468b,_0x343fa6){this['validateEventType_'](_0x2a4e35),this['listeners_'][_0x2a4e35]=this['listeners_'][_0x2a4e35]||[],this['listeners_'][_0x2a4e35]['push']({'callback':_0x31468b,'context':_0x343fa6});const _0x2278be=this['getInitialEvent'](_0x2a4e35);_0x2278be&&_0x31468b['apply'](_0x343fa6,_0x2278be);}['off'](_0x38215f,_0x34702d,_0x333515){this['validateEventType_'](_0x38215f);const _0x4b437=this['listeners_'][_0x38215f]||[];for(let _0x135259=0x0;_0x135259<_0x4b437['length'];_0x135259++)if(_0x4b437[_0x135259]['callback']===_0x34702d&&(!_0x333515||_0x333515===_0x4b437[_0x135259]['context'])){_0x4b437['splice'](_0x135259,0x1);return;}}['validateEventType_'](_0x10c807){f(this['allowedEvents_']['find'](_0x3e840c=>_0x3e840c===_0x10c807),'Unknown\x20event:\x20'+_0x10c807);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class dn extends bo{static['getInstance'](){return new dn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Fi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0xe10f7f){return f(_0xe10f7f==='online','Unknown\x20event\x20type:\x20'+_0xe10f7f),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Zs=0x20,er=0x300;class C{constructor(_0x295f8a,_0x3eaf76){if(_0x3eaf76===void 0x0){this['pieces_']=_0x295f8a['split']('/');let _0x110afa=0x0;for(let _0x3a0741=0x0;_0x3a0741<this['pieces_']['length'];_0x3a0741++)this['pieces_'][_0x3a0741]['length']>0x0&&(this['pieces_'][_0x110afa]=this['pieces_'][_0x3a0741],_0x110afa++);this['pieces_']['length']=_0x110afa,this['pieceNum_']=0x0;}else this['pieces_']=_0x295f8a,this['pieceNum_']=_0x3eaf76;}['toString'](){let _0xa76bcb='';for(let _0x4d78bb=this['pieceNum_'];_0x4d78bb<this['pieces_']['length'];_0x4d78bb++)this['pieces_'][_0x4d78bb]!==''&&(_0xa76bcb+='/'+this['pieces_'][_0x4d78bb]);return _0xa76bcb||'/';}}function w(){return new C('');}function y(_0x575002){return _0x575002['pieceNum_']>=_0x575002['pieces_']['length']?null:_0x575002['pieces_'][_0x575002['pieceNum_']];}function we(_0x23ea61){return _0x23ea61['pieces_']['length']-_0x23ea61['pieceNum_'];}function b(_0x222727){let _0x198bed=_0x222727['pieceNum_'];return _0x198bed<_0x222727['pieces_']['length']&&_0x198bed++,new C(_0x222727['pieces_'],_0x198bed);}function zi(_0x5c03db){return _0x5c03db['pieceNum_']<_0x5c03db['pieces_']['length']?_0x5c03db['pieces_'][_0x5c03db['pieces_']['length']-0x1]:null;}function bh(_0x2caf2b){let _0x5b9ef4='';for(let _0x42acd0=_0x2caf2b['pieceNum_'];_0x42acd0<_0x2caf2b['pieces_']['length'];_0x42acd0++)_0x2caf2b['pieces_'][_0x42acd0]!==''&&(_0x5b9ef4+='/'+encodeURIComponent(String(_0x2caf2b['pieces_'][_0x42acd0])));return _0x5b9ef4||'/';}function Pt(_0x4518c8,_0x1b73fe=0x0){return _0x4518c8['pieces_']['slice'](_0x4518c8['pieceNum_']+_0x1b73fe);}function Ro(_0x1ab8fe){if(_0x1ab8fe['pieceNum_']>=_0x1ab8fe['pieces_']['length'])return null;const _0x44843f=[];for(let _0x25ee9f=_0x1ab8fe['pieceNum_'];_0x25ee9f<_0x1ab8fe['pieces_']['length']-0x1;_0x25ee9f++)_0x44843f['push'](_0x1ab8fe['pieces_'][_0x25ee9f]);return new C(_0x44843f,0x0);}function k(_0x4dadd4,_0x460ca8){const _0x1a7a5e=[];for(let _0x555c59=_0x4dadd4['pieceNum_'];_0x555c59<_0x4dadd4['pieces_']['length'];_0x555c59++)_0x1a7a5e['push'](_0x4dadd4['pieces_'][_0x555c59]);if(_0x460ca8 instanceof C){for(let _0xa33709=_0x460ca8['pieceNum_'];_0xa33709<_0x460ca8['pieces_']['length'];_0xa33709++)_0x1a7a5e['push'](_0x460ca8['pieces_'][_0xa33709]);}else{const _0x458903=_0x460ca8['split']('/');for(let _0xef2e7=0x0;_0xef2e7<_0x458903['length'];_0xef2e7++)_0x458903[_0xef2e7]['length']>0x0&&_0x1a7a5e['push'](_0x458903[_0xef2e7]);}return new C(_0x1a7a5e,0x0);}function v(_0x2a702e){return _0x2a702e['pieceNum_']>=_0x2a702e['pieces_']['length'];}function F(_0x926a2,_0x36345d){const _0x128d09=y(_0x926a2),_0x2290ae=y(_0x36345d);if(_0x128d09===null)return _0x36345d;if(_0x128d09===_0x2290ae)return F(b(_0x926a2),b(_0x36345d));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x36345d+')\x20is\x20not\x20within\x20outerPath\x20('+_0x926a2+')');}function Rh(_0xc91d9d,_0x49302f){const _0x3039f8=Pt(_0xc91d9d,0x0),_0x4fa05a=Pt(_0x49302f,0x0);for(let _0x5b3111=0x0;_0x5b3111<_0x3039f8['length']&&_0x5b3111<_0x4fa05a['length'];_0x5b3111++){const _0x32e883=He(_0x3039f8[_0x5b3111],_0x4fa05a[_0x5b3111]);if(_0x32e883!==0x0)return _0x32e883;}return _0x3039f8['length']===_0x4fa05a['length']?0x0:_0x3039f8['length']<_0x4fa05a['length']?-0x1:0x1;}function ji(_0x26f7ba,_0x5132c2){if(we(_0x26f7ba)!==we(_0x5132c2))return!0x1;for(let _0xb406a2=_0x26f7ba['pieceNum_'],_0x39b9a2=_0x5132c2['pieceNum_'];_0xb406a2<=_0x26f7ba['pieces_']['length'];_0xb406a2++,_0x39b9a2++)if(_0x26f7ba['pieces_'][_0xb406a2]!==_0x5132c2['pieces_'][_0x39b9a2])return!0x1;return!0x0;}function G(_0x219a18,_0x3aa9bb){let _0x547118=_0x219a18['pieceNum_'],_0x3a825a=_0x3aa9bb['pieceNum_'];if(we(_0x219a18)>we(_0x3aa9bb))return!0x1;for(;_0x547118<_0x219a18['pieces_']['length'];){if(_0x219a18['pieces_'][_0x547118]!==_0x3aa9bb['pieces_'][_0x3a825a])return!0x1;++_0x547118,++_0x3a825a;}return!0x0;}class Ah{constructor(_0x619daa,_0x3d4d1a){this['errorPrefix_']=_0x3d4d1a,this['parts_']=Pt(_0x619daa,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x4f2a1=0x0;_0x4f2a1<this['parts_']['length'];_0x4f2a1++)this['byteLength_']+=On(this['parts_'][_0x4f2a1]);Ao(this);}}function kh(_0x294f66,_0x12b9a1){_0x294f66['parts_']['length']>0x0&&(_0x294f66['byteLength_']+=0x1),_0x294f66['parts_']['push'](_0x12b9a1),_0x294f66['byteLength_']+=On(_0x12b9a1),Ao(_0x294f66);}function Nh(_0xaf73f9){const _0x5ba354=_0xaf73f9['parts_']['pop']();_0xaf73f9['byteLength_']-=On(_0x5ba354),_0xaf73f9['parts_']['length']>0x0&&(_0xaf73f9['byteLength_']-=0x1);}function Ao(_0x40ebf7){if(_0x40ebf7['byteLength_']>er)throw new Error(_0x40ebf7['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+er+'\x20bytes\x20('+_0x40ebf7['byteLength_']+').');if(_0x40ebf7['parts_']['length']>Zs)throw new Error(_0x40ebf7['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Zs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Pe(_0x40ebf7));}function Pe(_0x463b48){return _0x463b48['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x463b48['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends bo{static['getInstance'](){return new Ki();}constructor(){super(['visible']);let _0x11b8e7,_0x3b6a33;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x3b6a33='visibilitychange',_0x11b8e7='hidden'):typeof document['mozHidden']<'u'?(_0x3b6a33='mozvisibilitychange',_0x11b8e7='mozHidden'):typeof document['msHidden']<'u'?(_0x3b6a33='msvisibilitychange',_0x11b8e7='msHidden'):typeof document['webkitHidden']<'u'&&(_0x3b6a33='webkitvisibilitychange',_0x11b8e7='webkitHidden')),this['visible_']=!0x0,_0x3b6a33&&document['addEventListener'](_0x3b6a33,()=>{const _0x3dda83=!document[_0x11b8e7];_0x3dda83!==this['visible_']&&(this['visible_']=_0x3dda83,this['trigger']('visible',_0x3dda83));},!0x1);}['getInitialEvent'](_0x25f7b1){return f(_0x25f7b1==='visible','Unknown\x20event\x20type:\x20'+_0x25f7b1),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gt=0x3e8,Ph=0x12c*0x3e8,tr=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',nr=0x3;class se extends So{constructor(_0x155207,_0x438ffa,_0x5e2be4,_0x3180a9,_0x43b36b,_0x3b1be4,_0x40141d,_0x57f3d6){if(super(),this['repoInfo_']=_0x155207,this['applicationId_']=_0x438ffa,this['onDataUpdate_']=_0x5e2be4,this['onConnectStatus_']=_0x3180a9,this['onServerInfoUpdate_']=_0x43b36b,this['authTokenProvider_']=_0x3b1be4,this['appCheckTokenProvider_']=_0x40141d,this['authOverride_']=_0x57f3d6,this['id']=se['nextPersistentConnectionId_']++,this['log_']=Ht('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=gt,this['maxReconnectDelay_']=Ph,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x57f3d6)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Ki['getInstance']()['on']('visible',this['onVisible_'],this),_0x155207['host']['indexOf']('fblocal')===-0x1&&dn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x589105,_0x5c81bd,_0x3b38ab){const _0x4659ad=++this['requestNumber_'],_0x1b581f={'r':_0x4659ad,'a':_0x589105,'b':_0x5c81bd};this['log_'](O(_0x1b581f)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x1b581f),_0x3b38ab&&(this['requestCBHash_'][_0x4659ad]=_0x3b38ab);}['get'](_0xbe3f91){this['initConnection_']();const _0x3943a7=new ot(),_0x2bebae={'action':'g','request':{'p':_0xbe3f91['_path']['toString'](),'q':_0xbe3f91['_queryObject']},'onComplete':_0x363783=>{const _0x2615d2=_0x363783['d'];_0x363783['s']==='ok'?_0x3943a7['resolve'](_0x2615d2):_0x3943a7['reject'](_0x2615d2);}};this['outstandingGets_']['push'](_0x2bebae),this['outstandingGetCount_']++;const _0x10a413=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x10a413),_0x3943a7['promise'];}['listen'](_0x28ede8,_0x1d4b4e,_0x42e001,_0x864605){this['initConnection_']();const _0x3bd33b=_0x28ede8['_queryIdentifier'],_0x3f2bc5=_0x28ede8['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x3f2bc5+'\x20'+_0x3bd33b),this['listens']['has'](_0x3f2bc5)||this['listens']['set'](_0x3f2bc5,new Map()),f(_0x28ede8['_queryParams']['isDefault']()||!_0x28ede8['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x3f2bc5)['has'](_0x3bd33b),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0xd1aef5={'onComplete':_0x864605,'hashFn':_0x1d4b4e,'query':_0x28ede8,'tag':_0x42e001};this['listens']['get'](_0x3f2bc5)['set'](_0x3bd33b,_0xd1aef5),this['connected_']&&this['sendListen_'](_0xd1aef5);}['sendGet_'](_0x59972f){const _0x230211=this['outstandingGets_'][_0x59972f];this['sendRequest']('g',_0x230211['request'],_0xae6192=>{delete this['outstandingGets_'][_0x59972f],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x230211['onComplete']&&_0x230211['onComplete'](_0xae6192);});}['sendListen_'](_0x31f62b){const _0x1c16aa=_0x31f62b['query'],_0x5a16d8=_0x1c16aa['_path']['toString'](),_0x4ce0f8=_0x1c16aa['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x5a16d8+'\x20for\x20'+_0x4ce0f8);const _0xbd6a2b={'p':_0x5a16d8},_0x2593cf='q';_0x31f62b['tag']&&(_0xbd6a2b['q']=_0x1c16aa['_queryObject'],_0xbd6a2b['t']=_0x31f62b['tag']),_0xbd6a2b['h']=_0x31f62b['hashFn'](),this['sendRequest'](_0x2593cf,_0xbd6a2b,_0x3da6d9=>{const _0x31b9a0=_0x3da6d9['d'],_0x59d2f7=_0x3da6d9['s'];se['warnOnListenWarnings_'](_0x31b9a0,_0x1c16aa),(this['listens']['get'](_0x5a16d8)&&this['listens']['get'](_0x5a16d8)['get'](_0x4ce0f8))===_0x31f62b&&(this['log_']('listen\x20response',_0x3da6d9),_0x59d2f7!=='ok'&&this['removeListen_'](_0x5a16d8,_0x4ce0f8),_0x31f62b['onComplete']&&_0x31f62b['onComplete'](_0x59d2f7,_0x31b9a0));});}static['warnOnListenWarnings_'](_0x398404,_0x2f5540){if(_0x398404&&typeof _0x398404=='object'&&J(_0x398404,'w')){const _0x13a379=De(_0x398404,'w');if(Array['isArray'](_0x13a379)&&~_0x13a379['indexOf']('no_index')){const _0x5e9703='\x22.indexOn\x22:\x20\x22'+_0x2f5540['_queryParams']['getIndex']()['toString']()+'\x22',_0xc51096=_0x2f5540['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x5e9703+'\x20at\x20'+_0xc51096+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x2e9143){this['authToken_']=_0x2e9143,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x2e9143);}['reduceReconnectDelayIfAdminCredential_'](_0x185c44){(_0x185c44&&_0x185c44['length']===0x28||wc(_0x185c44))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=tr);}['refreshAppCheckToken'](_0x545ba6){this['appCheckToken_']=_0x545ba6,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x87497b=this['authToken_'],_0x3a1007=Ic(_0x87497b)?'auth':'gauth',_0x51f6d1={'cred':_0x87497b};this['authOverride_']===null?_0x51f6d1['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x51f6d1['authvar']=this['authOverride_']),this['sendRequest'](_0x3a1007,_0x51f6d1,_0x4c20bb=>{const _0x24ac65=_0x4c20bb['s'],_0x1cbcc8=_0x4c20bb['d']||'error';this['authToken_']===_0x87497b&&(_0x24ac65==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x24ac65,_0x1cbcc8));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x2c6fe2=>{const _0x4e9559=_0x2c6fe2['s'],_0x1f183a=_0x2c6fe2['d']||'error';_0x4e9559==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x4e9559,_0x1f183a);});}['unlisten'](_0x111983,_0x555f69){const _0xf62181=_0x111983['_path']['toString'](),_0x2ed08a=_0x111983['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0xf62181+'\x20'+_0x2ed08a),f(_0x111983['_queryParams']['isDefault']()||!_0x111983['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0xf62181,_0x2ed08a)&&this['connected_']&&this['sendUnlisten_'](_0xf62181,_0x2ed08a,_0x111983['_queryObject'],_0x555f69);}['sendUnlisten_'](_0x2e1284,_0xb45121,_0x212791,_0x56f7b2){this['log_']('Unlisten\x20on\x20'+_0x2e1284+'\x20for\x20'+_0xb45121);const _0x46e6a3={'p':_0x2e1284},_0x10baf4='n';_0x56f7b2&&(_0x46e6a3['q']=_0x212791,_0x46e6a3['t']=_0x56f7b2),this['sendRequest'](_0x10baf4,_0x46e6a3);}['onDisconnectPut'](_0x2f6ae0,_0x5d19c4,_0x31ed61){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x2f6ae0,_0x5d19c4,_0x31ed61):this['onDisconnectRequestQueue_']['push']({'pathString':_0x2f6ae0,'action':'o','data':_0x5d19c4,'onComplete':_0x31ed61});}['onDisconnectMerge'](_0x4570de,_0x5abefe,_0x161886){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x4570de,_0x5abefe,_0x161886):this['onDisconnectRequestQueue_']['push']({'pathString':_0x4570de,'action':'om','data':_0x5abefe,'onComplete':_0x161886});}['onDisconnectCancel'](_0x416bb3,_0x5259cc){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x416bb3,null,_0x5259cc):this['onDisconnectRequestQueue_']['push']({'pathString':_0x416bb3,'action':'oc','data':null,'onComplete':_0x5259cc});}['sendOnDisconnect_'](_0x164cab,_0x267dc0,_0x26d3c7,_0xcad6af){const _0x380037={'p':_0x267dc0,'d':_0x26d3c7};this['log_']('onDisconnect\x20'+_0x164cab,_0x380037),this['sendRequest'](_0x164cab,_0x380037,_0x1c8f6e=>{_0xcad6af&&setTimeout(()=>{_0xcad6af(_0x1c8f6e['s'],_0x1c8f6e['d']);},Math['floor'](0x0));});}['put'](_0x37f8b9,_0x1e9551,_0x271961,_0x223951){this['putInternal']('p',_0x37f8b9,_0x1e9551,_0x271961,_0x223951);}['merge'](_0x29c1f8,_0x1c15c5,_0x1fd10f,_0x1e4f6d){this['putInternal']('m',_0x29c1f8,_0x1c15c5,_0x1fd10f,_0x1e4f6d);}['putInternal'](_0x2711b4,_0xb032e,_0x12ab6f,_0xc93cb8,_0x172acf){this['initConnection_']();const _0x4778be={'p':_0xb032e,'d':_0x12ab6f};_0x172acf!==void 0x0&&(_0x4778be['h']=_0x172acf),this['outstandingPuts_']['push']({'action':_0x2711b4,'request':_0x4778be,'onComplete':_0xc93cb8}),this['outstandingPutCount_']++;const _0x3c99a1=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x3c99a1):this['log_']('Buffering\x20put:\x20'+_0xb032e);}['sendPut_'](_0x46676e){const _0x3e1451=this['outstandingPuts_'][_0x46676e]['action'],_0x3778cf=this['outstandingPuts_'][_0x46676e]['request'],_0x281a50=this['outstandingPuts_'][_0x46676e]['onComplete'];this['outstandingPuts_'][_0x46676e]['queued']=this['connected_'],this['sendRequest'](_0x3e1451,_0x3778cf,_0x22b8bb=>{this['log_'](_0x3e1451+'\x20response',_0x22b8bb),delete this['outstandingPuts_'][_0x46676e],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x281a50&&_0x281a50(_0x22b8bb['s'],_0x22b8bb['d']);});}['reportStats'](_0x162b46){if(this['connected_']){const _0x3f8694={'c':_0x162b46};this['log_']('reportStats',_0x3f8694),this['sendRequest']('s',_0x3f8694,_0x52b7a9=>{if(_0x52b7a9['s']!=='ok'){const _0x5ce040=_0x52b7a9['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x5ce040);}});}}['onDataMessage_'](_0x44fdbb){if('r'in _0x44fdbb){this['log_']('from\x20server:\x20'+O(_0x44fdbb));const _0x43d833=_0x44fdbb['r'],_0x235670=this['requestCBHash_'][_0x43d833];_0x235670&&(delete this['requestCBHash_'][_0x43d833],_0x235670(_0x44fdbb['b']));}else{if('error'in _0x44fdbb)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x44fdbb['error'];'a'in _0x44fdbb&&this['onDataPush_'](_0x44fdbb['a'],_0x44fdbb['b']);}}['onDataPush_'](_0x31912c,_0x5accfe){this['log_']('handleServerMessage',_0x31912c,_0x5accfe),_0x31912c==='d'?this['onDataUpdate_'](_0x5accfe['p'],_0x5accfe['d'],!0x1,_0x5accfe['t']):_0x31912c==='m'?this['onDataUpdate_'](_0x5accfe['p'],_0x5accfe['d'],!0x0,_0x5accfe['t']):_0x31912c==='c'?this['onListenRevoked_'](_0x5accfe['p'],_0x5accfe['q']):_0x31912c==='ac'?this['onAuthRevoked_'](_0x5accfe['s'],_0x5accfe['d']):_0x31912c==='apc'?this['onAppCheckRevoked_'](_0x5accfe['s'],_0x5accfe['d']):_0x31912c==='sd'?this['onSecurityDebugPacket_'](_0x5accfe):yi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x31912c)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x4145a6,_0x22bee0){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x4145a6),this['lastSessionId']=_0x22bee0,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x459ab4){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x459ab4));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x6f6689){_0x6f6689&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x6f6689;}['onOnline_'](_0x1d2e92){_0x1d2e92?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=gt),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x1e3082=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x36fdd2=Math['max'](0x0,this['reconnectDelay_']-_0x1e3082);_0x36fdd2=Math['random']()*_0x36fdd2,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x36fdd2+'ms'),this['scheduleConnect_'](_0x36fdd2),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x4e2a26=this['onDataMessage_']['bind'](this),_0x5ea9ab=this['onReady_']['bind'](this),_0x45e098=this['onRealtimeDisconnect_']['bind'](this),_0x5af9b8=this['id']+':'+se['nextConnectionId_']++,_0xcf541=this['lastSessionId'];let _0x55dd21=!0x1,_0x48ba9f=null;const _0x3e96a=function(){_0x48ba9f?_0x48ba9f['close']():(_0x55dd21=!0x0,_0x45e098());},_0x579d2a=function(_0x53e417){f(_0x48ba9f,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x48ba9f['sendRequest'](_0x53e417);};this['realtime_']={'close':_0x3e96a,'sendRequest':_0x579d2a};const _0x3f4264=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x5b22b4,_0x510153]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x3f4264),this['appCheckTokenProvider_']['getToken'](_0x3f4264)]);_0x55dd21?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x5b22b4&&_0x5b22b4['accessToken'],this['appCheckToken_']=_0x510153&&_0x510153['token'],_0x48ba9f=new Sh(_0x5af9b8,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x4e2a26,_0x5ea9ab,_0x45e098,_0x52c305=>{U(_0x52c305+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0xcf541));}catch(_0x45c7e1){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x45c7e1),_0x55dd21||(this['repoInfo_']['nodeAdmin']&&U(_0x45c7e1),_0x3e96a());}}}['interrupt'](_0x730d84){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x730d84),this['interruptReasons_'][_0x730d84]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x25a7f1){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x25a7f1),delete this['interruptReasons_'][_0x25a7f1],ui(this['interruptReasons_'])&&(this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x497ef7){const _0x52ed69=_0x497ef7-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x52ed69});}['cancelSentTransactions_'](){for(let _0x3135eb=0x0;_0x3135eb<this['outstandingPuts_']['length'];_0x3135eb++){const _0x5d9cc7=this['outstandingPuts_'][_0x3135eb];_0x5d9cc7&&'h'in _0x5d9cc7['request']&&_0x5d9cc7['queued']&&(_0x5d9cc7['onComplete']&&_0x5d9cc7['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x3135eb],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x5b7e51,_0x2ebae8){let _0x4e8e8e;_0x2ebae8?_0x4e8e8e=_0x2ebae8['map'](_0x452ba9=>Hi(_0x452ba9))['join']('$'):_0x4e8e8e='default';const _0x148a33=this['removeListen_'](_0x5b7e51,_0x4e8e8e);_0x148a33&&_0x148a33['onComplete']&&_0x148a33['onComplete']('permission_denied');}['removeListen_'](_0x394e3c,_0x1f6778){const _0x2421fc=new C(_0x394e3c)['toString']();let _0x5a7c57;if(this['listens']['has'](_0x2421fc)){const _0x409ed4=this['listens']['get'](_0x2421fc);_0x5a7c57=_0x409ed4['get'](_0x1f6778),_0x409ed4['delete'](_0x1f6778),_0x409ed4['size']===0x0&&this['listens']['delete'](_0x2421fc);}else _0x5a7c57=void 0x0;return _0x5a7c57;}['onAuthRevoked_'](_0x7e79f8,_0x3261a8){L('Auth\x20token\x20revoked:\x20'+_0x7e79f8+'/'+_0x3261a8),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x7e79f8==='invalid_token'||_0x7e79f8==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=nr&&(this['reconnectDelay_']=tr,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x15c93c,_0x17722c){L('App\x20check\x20token\x20revoked:\x20'+_0x15c93c+'/'+_0x17722c),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x15c93c==='invalid_token'||_0x15c93c==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=nr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x55647f){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x55647f):'msg'in _0x55647f&&console['log']('FIREBASE:\x20'+_0x55647f['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x59cf21 of this['listens']['values']())for(const _0x554f38 of _0x59cf21['values']())this['sendListen_'](_0x554f38);for(let _0x52ef4b=0x0;_0x52ef4b<this['outstandingPuts_']['length'];_0x52ef4b++)this['outstandingPuts_'][_0x52ef4b]&&this['sendPut_'](_0x52ef4b);for(;this['onDisconnectRequestQueue_']['length'];){const _0x119591=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x119591['action'],_0x119591['pathString'],_0x119591['data'],_0x119591['onComplete']);}for(let _0x3cf827=0x0;_0x3cf827<this['outstandingGets_']['length'];_0x3cf827++)this['outstandingGets_'][_0x3cf827]&&this['sendGet_'](_0x3cf827);}['sendConnectStats_'](){const _0x468663={};let _0x4eae5f='js';_0x468663['sdk.'+_0x4eae5f+'.'+no['replace'](/\./g,'-')]=0x1,Fi()?_0x468663['framework.cordova']=0x1:Yr()&&(_0x468663['framework.reactnative']=0x1),this['reportStats'](_0x468663);}['shouldReconnect_'](){const _0xe8e894=dn['getInstance']()['currentlyOnline']();return ui(this['interruptReasons_'])&&_0xe8e894;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x3286e8,_0x7e10fd){this['name']=_0x3286e8,this['node']=_0x7e10fd;}static['Wrap'](_0x3ae401,_0x4bb20a){return new E(_0x3ae401,_0x4bb20a);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x549352,_0x44f5c4){const _0x4462fc=new E(Fe,_0x549352),_0x14f441=new E(Fe,_0x44f5c4);return this['compare'](_0x4462fc,_0x14f441)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zt;class ko extends Dn{static get['__EMPTY_NODE'](){return Zt;}static set['__EMPTY_NODE'](_0x43801d){Zt=_0x43801d;}['compare'](_0x2c48cd,_0xea3f31){return He(_0x2c48cd['name'],_0xea3f31['name']);}['isDefinedOn'](_0x4845a7){throw rt('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x181aad,_0x120e3c){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Zt);}['makePost'](_0xa431fe,_0x2a4b5e){return f(typeof _0xa431fe=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0xa431fe,Zt);}['toString'](){return'.key';}}const ye=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class en{constructor(_0x2698b2,_0x184452,_0x598c00,_0xe3a031,_0x52bbcd=null){this['isReverse_']=_0xe3a031,this['resultGenerator_']=_0x52bbcd,this['nodeStack_']=[];let _0x459037=0x1;for(;!_0x2698b2['isEmpty']();)if(_0x2698b2=_0x2698b2,_0x459037=_0x184452?_0x598c00(_0x2698b2['key'],_0x184452):0x1,_0xe3a031&&(_0x459037*=-0x1),_0x459037<0x0)this['isReverse_']?_0x2698b2=_0x2698b2['left']:_0x2698b2=_0x2698b2['right'];else{if(_0x459037===0x0){this['nodeStack_']['push'](_0x2698b2);break;}else this['nodeStack_']['push'](_0x2698b2),this['isReverse_']?_0x2698b2=_0x2698b2['right']:_0x2698b2=_0x2698b2['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x59fc70=this['nodeStack_']['pop'](),_0x30d346;if(this['resultGenerator_']?_0x30d346=this['resultGenerator_'](_0x59fc70['key'],_0x59fc70['value']):_0x30d346={'key':_0x59fc70['key'],'value':_0x59fc70['value']},this['isReverse_']){for(_0x59fc70=_0x59fc70['left'];!_0x59fc70['isEmpty']();)this['nodeStack_']['push'](_0x59fc70),_0x59fc70=_0x59fc70['right'];}else{for(_0x59fc70=_0x59fc70['right'];!_0x59fc70['isEmpty']();)this['nodeStack_']['push'](_0x59fc70),_0x59fc70=_0x59fc70['left'];}return _0x30d346;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x4f94ee=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x4f94ee['key'],_0x4f94ee['value']):{'key':_0x4f94ee['key'],'value':_0x4f94ee['value']};}}class M{constructor(_0x5b53c9,_0x3e8e95,_0x5daa9e,_0x5aa070,_0xd69f46){this['key']=_0x5b53c9,this['value']=_0x3e8e95,this['color']=_0x5daa9e??M['RED'],this['left']=_0x5aa070??B['EMPTY_NODE'],this['right']=_0xd69f46??B['EMPTY_NODE'];}['copy'](_0x465da0,_0xa06988,_0x4c3eaf,_0x483ec8,_0x6d62a0){return new M(_0x465da0??this['key'],_0xa06988??this['value'],_0x4c3eaf??this['color'],_0x483ec8??this['left'],_0x6d62a0??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x78d8e0){return this['left']['inorderTraversal'](_0x78d8e0)||!!_0x78d8e0(this['key'],this['value'])||this['right']['inorderTraversal'](_0x78d8e0);}['reverseTraversal'](_0x71c5de){return this['right']['reverseTraversal'](_0x71c5de)||_0x71c5de(this['key'],this['value'])||this['left']['reverseTraversal'](_0x71c5de);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x4810de,_0xb96629,_0x1dc9a0){let _0x3078e6=this;const _0x5c2c8c=_0x1dc9a0(_0x4810de,_0x3078e6['key']);return _0x5c2c8c<0x0?_0x3078e6=_0x3078e6['copy'](null,null,null,_0x3078e6['left']['insert'](_0x4810de,_0xb96629,_0x1dc9a0),null):_0x5c2c8c===0x0?_0x3078e6=_0x3078e6['copy'](null,_0xb96629,null,null,null):_0x3078e6=_0x3078e6['copy'](null,null,null,null,_0x3078e6['right']['insert'](_0x4810de,_0xb96629,_0x1dc9a0)),_0x3078e6['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x3ac79d=this;return!_0x3ac79d['left']['isRed_']()&&!_0x3ac79d['left']['left']['isRed_']()&&(_0x3ac79d=_0x3ac79d['moveRedLeft_']()),_0x3ac79d=_0x3ac79d['copy'](null,null,null,_0x3ac79d['left']['removeMin_'](),null),_0x3ac79d['fixUp_']();}['remove'](_0x4fc490,_0x389b61){let _0x358760,_0x35d004;if(_0x358760=this,_0x389b61(_0x4fc490,_0x358760['key'])<0x0)!_0x358760['left']['isEmpty']()&&!_0x358760['left']['isRed_']()&&!_0x358760['left']['left']['isRed_']()&&(_0x358760=_0x358760['moveRedLeft_']()),_0x358760=_0x358760['copy'](null,null,null,_0x358760['left']['remove'](_0x4fc490,_0x389b61),null);else{if(_0x358760['left']['isRed_']()&&(_0x358760=_0x358760['rotateRight_']()),!_0x358760['right']['isEmpty']()&&!_0x358760['right']['isRed_']()&&!_0x358760['right']['left']['isRed_']()&&(_0x358760=_0x358760['moveRedRight_']()),_0x389b61(_0x4fc490,_0x358760['key'])===0x0){if(_0x358760['right']['isEmpty']())return B['EMPTY_NODE'];_0x35d004=_0x358760['right']['min_'](),_0x358760=_0x358760['copy'](_0x35d004['key'],_0x35d004['value'],null,null,_0x358760['right']['removeMin_']());}_0x358760=_0x358760['copy'](null,null,null,null,_0x358760['right']['remove'](_0x4fc490,_0x389b61));}return _0x358760['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x10df7f=this;return _0x10df7f['right']['isRed_']()&&!_0x10df7f['left']['isRed_']()&&(_0x10df7f=_0x10df7f['rotateLeft_']()),_0x10df7f['left']['isRed_']()&&_0x10df7f['left']['left']['isRed_']()&&(_0x10df7f=_0x10df7f['rotateRight_']()),_0x10df7f['left']['isRed_']()&&_0x10df7f['right']['isRed_']()&&(_0x10df7f=_0x10df7f['colorFlip_']()),_0x10df7f;}['moveRedLeft_'](){let _0x5e5feb=this['colorFlip_']();return _0x5e5feb['right']['left']['isRed_']()&&(_0x5e5feb=_0x5e5feb['copy'](null,null,null,null,_0x5e5feb['right']['rotateRight_']()),_0x5e5feb=_0x5e5feb['rotateLeft_'](),_0x5e5feb=_0x5e5feb['colorFlip_']()),_0x5e5feb;}['moveRedRight_'](){let _0x12e116=this['colorFlip_']();return _0x12e116['left']['left']['isRed_']()&&(_0x12e116=_0x12e116['rotateRight_'](),_0x12e116=_0x12e116['colorFlip_']()),_0x12e116;}['rotateLeft_'](){const _0x53114b=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x53114b,null);}['rotateRight_'](){const _0x25284a=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x25284a);}['colorFlip_'](){const _0x5e91d6=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x479fa0=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x5e91d6,_0x479fa0);}['checkMaxDepth_'](){const _0x586784=this['check_']();return Math['pow'](0x2,_0x586784)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x2ff796=this['left']['check_']();if(_0x2ff796!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x2ff796+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x4f0211,_0x38293e,_0x3df981,_0x3116d9,_0x5dca9b){return this;}['insert'](_0x43f02c,_0x517547,_0x213217){return new M(_0x43f02c,_0x517547,null);}['remove'](_0x54e394,_0x1c4aee){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x1da15e){return!0x1;}['reverseTraversal'](_0x18b1f8){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x1b3c91,_0x9e172d=B['EMPTY_NODE']){this['comparator_']=_0x1b3c91,this['root_']=_0x9e172d;}['insert'](_0x27f470,_0x3a4081){return new B(this['comparator_'],this['root_']['insert'](_0x27f470,_0x3a4081,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x5bacbe){return new B(this['comparator_'],this['root_']['remove'](_0x5bacbe,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x32bcb6){let _0x2fe85c,_0x128232=this['root_'];for(;!_0x128232['isEmpty']();){if(_0x2fe85c=this['comparator_'](_0x32bcb6,_0x128232['key']),_0x2fe85c===0x0)return _0x128232['value'];_0x2fe85c<0x0?_0x128232=_0x128232['left']:_0x2fe85c>0x0&&(_0x128232=_0x128232['right']);}return null;}['getPredecessorKey'](_0x4f3b45){let _0x3ca06a,_0x4c777c=this['root_'],_0x56cdda=null;for(;!_0x4c777c['isEmpty']();)if(_0x3ca06a=this['comparator_'](_0x4f3b45,_0x4c777c['key']),_0x3ca06a===0x0){if(_0x4c777c['left']['isEmpty']())return _0x56cdda?_0x56cdda['key']:null;for(_0x4c777c=_0x4c777c['left'];!_0x4c777c['right']['isEmpty']();)_0x4c777c=_0x4c777c['right'];return _0x4c777c['key'];}else _0x3ca06a<0x0?_0x4c777c=_0x4c777c['left']:_0x3ca06a>0x0&&(_0x56cdda=_0x4c777c,_0x4c777c=_0x4c777c['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x39bf55){return this['root_']['inorderTraversal'](_0x39bf55);}['reverseTraversal'](_0x1a7375){return this['root_']['reverseTraversal'](_0x1a7375);}['getIterator'](_0x5c782d){return new en(this['root_'],null,this['comparator_'],!0x1,_0x5c782d);}['getIteratorFrom'](_0x6b31a9,_0x4168a9){return new en(this['root_'],_0x6b31a9,this['comparator_'],!0x1,_0x4168a9);}['getReverseIteratorFrom'](_0x4b2061,_0x20143a){return new en(this['root_'],_0x4b2061,this['comparator_'],!0x0,_0x20143a);}['getReverseIterator'](_0x5e05df){return new en(this['root_'],null,this['comparator_'],!0x0,_0x5e05df);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0xd226a1,_0xe3f27){return He(_0xd226a1['name'],_0xe3f27['name']);}function Yi(_0x506ce6,_0x2f246c){return He(_0x506ce6,_0x2f246c);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ei;function Fh(_0x541f1d){Ei=_0x541f1d;}const No=function(_0x2276db){return typeof _0x2276db=='number'?'number:'+ao(_0x2276db):'string:'+_0x2276db;},Po=function(_0x595bcc){if(_0x595bcc['isLeafNode']()){const _0xe2ddd5=_0x595bcc['val']();f(typeof _0xe2ddd5=='string'||typeof _0xe2ddd5=='number'||typeof _0xe2ddd5=='object'&&J(_0xe2ddd5,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x595bcc===Ei||_0x595bcc['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x595bcc===Ei||_0x595bcc['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ir;class D{static set['__childrenNodeConstructor'](_0x1c470a){ir=_0x1c470a;}static get['__childrenNodeConstructor'](){return ir;}constructor(_0x4b3bde,_0x34003e=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x4b3bde,this['priorityNode_']=_0x34003e,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Po(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x23cb47){return new D(this['value_'],_0x23cb47);}['getImmediateChild'](_0x4f00a2){return _0x4f00a2==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x5b8e2e){return v(_0x5b8e2e)?this:y(_0x5b8e2e)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x1c4fee,_0x27d860){return null;}['updateImmediateChild'](_0x4a785f,_0x13572a){return _0x4a785f==='.priority'?this['updatePriority'](_0x13572a):_0x13572a['isEmpty']()&&_0x4a785f!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x4a785f,_0x13572a)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x155075,_0x42d01a){const _0x534dbe=y(_0x155075);return _0x534dbe===null?_0x42d01a:_0x42d01a['isEmpty']()&&_0x534dbe!=='.priority'?this:(f(_0x534dbe!=='.priority'||we(_0x155075)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x534dbe,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x155075),_0x42d01a)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x195357,_0x22f280){return!0x1;}['val'](_0x2f9ab7){return _0x2f9ab7&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x4efeed='';this['priorityNode_']['isEmpty']()||(_0x4efeed+='priority:'+No(this['priorityNode_']['val']())+':');const _0x308730=typeof this['value_'];_0x4efeed+=_0x308730+':',_0x308730==='number'?_0x4efeed+=ao(this['value_']):_0x4efeed+=this['value_'],this['lazyHash_']=ro(_0x4efeed);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x51ed68){return _0x51ed68===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x51ed68 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x51ed68['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x51ed68));}['compareToLeafNode_'](_0x362457){const _0x3aa690=typeof _0x362457['value_'],_0x551e33=typeof this['value_'],_0x3a74b0=D['VALUE_TYPE_ORDER']['indexOf'](_0x3aa690),_0x359852=D['VALUE_TYPE_ORDER']['indexOf'](_0x551e33);return f(_0x3a74b0>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x3aa690),f(_0x359852>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x551e33),_0x3a74b0===_0x359852?_0x551e33==='object'?0x0:this['value_']<_0x362457['value_']?-0x1:this['value_']===_0x362457['value_']?0x0:0x1:_0x359852-_0x3a74b0;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0xae312e){if(_0xae312e===this)return!0x0;if(_0xae312e['isLeafNode']()){const _0x3dd6a9=_0xae312e;return this['value_']===_0x3dd6a9['value_']&&this['priorityNode_']['equals'](_0x3dd6a9['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x5d86fd){Oo=_0x5d86fd;}function Wh(_0x39df94){Do=_0x39df94;}class Bh extends Dn{['compare'](_0x5bd732,_0x2c1646){const _0xfb8de9=_0x5bd732['node']['getPriority'](),_0x5d9a1c=_0x2c1646['node']['getPriority'](),_0x3af79c=_0xfb8de9['compareTo'](_0x5d9a1c);return _0x3af79c===0x0?He(_0x5bd732['name'],_0x2c1646['name']):_0x3af79c;}['isDefinedOn'](_0x3e8782){return!_0x3e8782['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x3e5c64,_0x17b912){return!_0x3e5c64['getPriority']()['equals'](_0x17b912['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',Do));}['makePost'](_0x2687e9,_0x58b3c4){const _0x3fc473=Oo(_0x2687e9);return new E(_0x58b3c4,new D('[PRIORITY-POST]',_0x3fc473));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x104ded){const _0x57e661=_0x10479f=>parseInt(Math['log'](_0x10479f)/Vh,0xa),_0x17b149=_0x44afca=>parseInt(Array(_0x44afca+0x1)['join']('1'),0x2);this['count']=_0x57e661(_0x104ded+0x1),this['current_']=this['count']-0x1;const _0x5358f9=_0x17b149(this['count']);this['bits_']=_0x104ded+0x1&_0x5358f9;}['nextBitIsOne'](){const _0x41e3f7=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x41e3f7;}}const fn=function(_0x238710,_0x23ee79,_0x485505,_0x310b27){_0x238710['sort'](_0x23ee79);const _0x1c1a18=function(_0x59e3f5,_0x9c0e9b){const _0x3434ca=_0x9c0e9b-_0x59e3f5;let _0xa46e95,_0x5a9437;if(_0x3434ca===0x0)return null;if(_0x3434ca===0x1)return _0xa46e95=_0x238710[_0x59e3f5],_0x5a9437=_0x485505?_0x485505(_0xa46e95):_0xa46e95,new M(_0x5a9437,_0xa46e95['node'],M['BLACK'],null,null);{const _0x363dd9=parseInt(_0x3434ca/0x2,0xa)+_0x59e3f5,_0x425608=_0x1c1a18(_0x59e3f5,_0x363dd9),_0x568dd6=_0x1c1a18(_0x363dd9+0x1,_0x9c0e9b);return _0xa46e95=_0x238710[_0x363dd9],_0x5a9437=_0x485505?_0x485505(_0xa46e95):_0xa46e95,new M(_0x5a9437,_0xa46e95['node'],M['BLACK'],_0x425608,_0x568dd6);}},_0xdf14ef=function(_0x5c6294){let _0x4d2f4b=null,_0x434a0e=null,_0x508718=_0x238710['length'];const _0x267d46=function(_0xd9ccc5,_0x3d455b){const _0x2de163=_0x508718-_0xd9ccc5,_0x237614=_0x508718;_0x508718-=_0xd9ccc5;const _0x35b937=_0x1c1a18(_0x2de163+0x1,_0x237614),_0x1369ba=_0x238710[_0x2de163],_0x1cf936=_0x485505?_0x485505(_0x1369ba):_0x1369ba;_0x22daf3(new M(_0x1cf936,_0x1369ba['node'],_0x3d455b,null,_0x35b937));},_0x22daf3=function(_0x1ea18a){_0x4d2f4b?(_0x4d2f4b['left']=_0x1ea18a,_0x4d2f4b=_0x1ea18a):(_0x434a0e=_0x1ea18a,_0x4d2f4b=_0x1ea18a);};for(let _0x525ba1=0x0;_0x525ba1<_0x5c6294['count'];++_0x525ba1){const _0x27e131=_0x5c6294['nextBitIsOne'](),_0x3be644=Math['pow'](0x2,_0x5c6294['count']-(_0x525ba1+0x1));_0x27e131?_0x267d46(_0x3be644,M['BLACK']):(_0x267d46(_0x3be644,M['BLACK']),_0x267d46(_0x3be644,M['RED']));}return _0x434a0e;},_0x13b4f5=new Hh(_0x238710['length']),_0xd81905=_0xdf14ef(_0x13b4f5);return new B(_0x310b27||_0x23ee79,_0xd81905);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ze={};class te{static get['Default'](){return f(ze&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),ri=ri||new te({'.priority':ze},{'.priority':R}),ri;}constructor(_0x99b3fb,_0x255ed6){this['indexes_']=_0x99b3fb,this['indexSet_']=_0x255ed6;}['get'](_0x1bf729){const _0x1fcb4e=De(this['indexes_'],_0x1bf729);if(!_0x1fcb4e)throw new Error('No\x20index\x20defined\x20for\x20'+_0x1bf729);return _0x1fcb4e instanceof B?_0x1fcb4e:null;}['hasIndex'](_0x7c05dd){return J(this['indexSet_'],_0x7c05dd['toString']());}['addIndex'](_0x1ce1b2,_0x197813){f(_0x1ce1b2!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x45b2da=[];let _0x445b53=!0x1;const _0xc66ec8=_0x197813['getIterator'](E['Wrap']);let _0x3f4068=_0xc66ec8['getNext']();for(;_0x3f4068;)_0x445b53=_0x445b53||_0x1ce1b2['isDefinedOn'](_0x3f4068['node']),_0x45b2da['push'](_0x3f4068),_0x3f4068=_0xc66ec8['getNext']();let _0x4d3eaf;_0x445b53?_0x4d3eaf=fn(_0x45b2da,_0x1ce1b2['getCompare']()):_0x4d3eaf=ze;const _0x3e03e9=_0x1ce1b2['toString'](),_0x396b46={...this['indexSet_']};_0x396b46[_0x3e03e9]=_0x1ce1b2;const _0x52cc1c={...this['indexes_']};return _0x52cc1c[_0x3e03e9]=_0x4d3eaf,new te(_0x52cc1c,_0x396b46);}['addToIndexes'](_0x433ffc,_0xc11292){const _0x4658f2=hn(this['indexes_'],(_0x309586,_0x3980ff)=>{const _0x15f6be=De(this['indexSet_'],_0x3980ff);if(f(_0x15f6be,'Missing\x20index\x20implementation\x20for\x20'+_0x3980ff),_0x309586===ze){if(_0x15f6be['isDefinedOn'](_0x433ffc['node'])){const _0x57aeb3=[],_0x2e3bc1=_0xc11292['getIterator'](E['Wrap']);let _0x21ae89=_0x2e3bc1['getNext']();for(;_0x21ae89;)_0x21ae89['name']!==_0x433ffc['name']&&_0x57aeb3['push'](_0x21ae89),_0x21ae89=_0x2e3bc1['getNext']();return _0x57aeb3['push'](_0x433ffc),fn(_0x57aeb3,_0x15f6be['getCompare']());}else return ze;}else{const _0x3a20ab=_0xc11292['get'](_0x433ffc['name']);let _0x3c5022=_0x309586;return _0x3a20ab&&(_0x3c5022=_0x3c5022['remove'](new E(_0x433ffc['name'],_0x3a20ab))),_0x3c5022['insert'](_0x433ffc,_0x433ffc['node']);}});return new te(_0x4658f2,this['indexSet_']);}['removeFromIndexes'](_0x156b41,_0x502b70){const _0x501da6=hn(this['indexes_'],_0x296436=>{if(_0x296436===ze)return _0x296436;{const _0x29530a=_0x502b70['get'](_0x156b41['name']);return _0x29530a?_0x296436['remove'](new E(_0x156b41['name'],_0x29530a)):_0x296436;}});return new te(_0x501da6,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let mt;class g{static get['EMPTY_NODE'](){return mt||(mt=new g(new B(Yi),null,te['Default']));}constructor(_0x1761fc,_0x54a880,_0x3e2452){this['children_']=_0x1761fc,this['priorityNode_']=_0x54a880,this['indexMap_']=_0x3e2452,this['lazyHash_']=null,this['priorityNode_']&&Po(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||mt;}['updatePriority'](_0x590066){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x590066,this['indexMap_']);}['getImmediateChild'](_0x4b2e8c){if(_0x4b2e8c==='.priority')return this['getPriority']();{const _0x6b5aed=this['children_']['get'](_0x4b2e8c);return _0x6b5aed===null?mt:_0x6b5aed;}}['getChild'](_0x326d13){const _0x3094f3=y(_0x326d13);return _0x3094f3===null?this:this['getImmediateChild'](_0x3094f3)['getChild'](b(_0x326d13));}['hasChild'](_0xc62d6c){return this['children_']['get'](_0xc62d6c)!==null;}['updateImmediateChild'](_0x95e9b3,_0x3a27ce){if(f(_0x3a27ce,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x95e9b3==='.priority')return this['updatePriority'](_0x3a27ce);{const _0x3f89d6=new E(_0x95e9b3,_0x3a27ce);let _0x40f9c5,_0x4092ba;_0x3a27ce['isEmpty']()?(_0x40f9c5=this['children_']['remove'](_0x95e9b3),_0x4092ba=this['indexMap_']['removeFromIndexes'](_0x3f89d6,this['children_'])):(_0x40f9c5=this['children_']['insert'](_0x95e9b3,_0x3a27ce),_0x4092ba=this['indexMap_']['addToIndexes'](_0x3f89d6,this['children_']));const _0xe2b3a5=_0x40f9c5['isEmpty']()?mt:this['priorityNode_'];return new g(_0x40f9c5,_0xe2b3a5,_0x4092ba);}}['updateChild'](_0x3b21d9,_0x40d74e){const _0x59438b=y(_0x3b21d9);if(_0x59438b===null)return _0x40d74e;{f(y(_0x3b21d9)!=='.priority'||we(_0x3b21d9)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x4f117c=this['getImmediateChild'](_0x59438b)['updateChild'](b(_0x3b21d9),_0x40d74e);return this['updateImmediateChild'](_0x59438b,_0x4f117c);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x445adc){if(this['isEmpty']())return null;const _0x402a2c={};let _0x3812f5=0x0,_0x421e7a=0x0,_0x4fd94b=!0x0;if(this['forEachChild'](R,(_0x284865,_0x5b465c)=>{_0x402a2c[_0x284865]=_0x5b465c['val'](_0x445adc),_0x3812f5++,_0x4fd94b&&g['INTEGER_REGEXP_']['test'](_0x284865)?_0x421e7a=Math['max'](_0x421e7a,Number(_0x284865)):_0x4fd94b=!0x1;}),!_0x445adc&&_0x4fd94b&&_0x421e7a<0x2*_0x3812f5){const _0x3fb2b3=[];for(const _0x14cf78 in _0x402a2c)_0x3fb2b3[_0x14cf78]=_0x402a2c[_0x14cf78];return _0x3fb2b3;}else return _0x445adc&&!this['getPriority']()['isEmpty']()&&(_0x402a2c['.priority']=this['getPriority']()['val']()),_0x402a2c;}['hash'](){if(this['lazyHash_']===null){let _0x206538='';this['getPriority']()['isEmpty']()||(_0x206538+='priority:'+No(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x383ccd,_0x22198a)=>{const _0x7dafc5=_0x22198a['hash']();_0x7dafc5!==''&&(_0x206538+=':'+_0x383ccd+':'+_0x7dafc5);}),this['lazyHash_']=_0x206538===''?'':ro(_0x206538);}return this['lazyHash_'];}['getPredecessorChildName'](_0x12ce62,_0x897ac2,_0x300eff){const _0x326287=this['resolveIndex_'](_0x300eff);if(_0x326287){const _0x412f6a=_0x326287['getPredecessorKey'](new E(_0x12ce62,_0x897ac2));return _0x412f6a?_0x412f6a['name']:null;}else return this['children_']['getPredecessorKey'](_0x12ce62);}['getFirstChildName'](_0x40c9aa){const _0x148527=this['resolveIndex_'](_0x40c9aa);if(_0x148527){const _0x4d3947=_0x148527['minKey']();return _0x4d3947&&_0x4d3947['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x45fad9){const _0x456408=this['getFirstChildName'](_0x45fad9);return _0x456408?new E(_0x456408,this['children_']['get'](_0x456408)):null;}['getLastChildName'](_0x4008f3){const _0x180130=this['resolveIndex_'](_0x4008f3);if(_0x180130){const _0x4235e2=_0x180130['maxKey']();return _0x4235e2&&_0x4235e2['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x595c15){const _0x54ca5b=this['getLastChildName'](_0x595c15);return _0x54ca5b?new E(_0x54ca5b,this['children_']['get'](_0x54ca5b)):null;}['forEachChild'](_0x37aea9,_0x2d42be){const _0x146c1a=this['resolveIndex_'](_0x37aea9);return _0x146c1a?_0x146c1a['inorderTraversal'](_0x34b96a=>_0x2d42be(_0x34b96a['name'],_0x34b96a['node'])):this['children_']['inorderTraversal'](_0x2d42be);}['getIterator'](_0x89a2f8){return this['getIteratorFrom'](_0x89a2f8['minPost'](),_0x89a2f8);}['getIteratorFrom'](_0x2d34b7,_0x758cc8){const _0x596f50=this['resolveIndex_'](_0x758cc8);if(_0x596f50)return _0x596f50['getIteratorFrom'](_0x2d34b7,_0x26b97e=>_0x26b97e);{const _0x46c7ec=this['children_']['getIteratorFrom'](_0x2d34b7['name'],E['Wrap']);let _0x1258d9=_0x46c7ec['peek']();for(;_0x1258d9!=null&&_0x758cc8['compare'](_0x1258d9,_0x2d34b7)<0x0;)_0x46c7ec['getNext'](),_0x1258d9=_0x46c7ec['peek']();return _0x46c7ec;}}['getReverseIterator'](_0x380441){return this['getReverseIteratorFrom'](_0x380441['maxPost'](),_0x380441);}['getReverseIteratorFrom'](_0x379687,_0x4dcba5){const _0x564923=this['resolveIndex_'](_0x4dcba5);if(_0x564923)return _0x564923['getReverseIteratorFrom'](_0x379687,_0x1c870a=>_0x1c870a);{const _0x243490=this['children_']['getReverseIteratorFrom'](_0x379687['name'],E['Wrap']);let _0x2dbf87=_0x243490['peek']();for(;_0x2dbf87!=null&&_0x4dcba5['compare'](_0x2dbf87,_0x379687)>0x0;)_0x243490['getNext'](),_0x2dbf87=_0x243490['peek']();return _0x243490;}}['compareTo'](_0x4cb2f5){return this['isEmpty']()?_0x4cb2f5['isEmpty']()?0x0:-0x1:_0x4cb2f5['isLeafNode']()||_0x4cb2f5['isEmpty']()?0x1:_0x4cb2f5===$t?-0x1:0x0;}['withIndex'](_0x1722e1){if(_0x1722e1===ye||this['indexMap_']['hasIndex'](_0x1722e1))return this;{const _0x605aae=this['indexMap_']['addIndex'](_0x1722e1,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x605aae);}}['isIndexed'](_0x1c3514){return _0x1c3514===ye||this['indexMap_']['hasIndex'](_0x1c3514);}['equals'](_0x1aa586){if(_0x1aa586===this)return!0x0;if(_0x1aa586['isLeafNode']())return!0x1;{const _0x33777b=_0x1aa586;if(this['getPriority']()['equals'](_0x33777b['getPriority']())){if(this['children_']['count']()===_0x33777b['children_']['count']()){const _0x36fe73=this['getIterator'](R),_0x2ec227=_0x33777b['getIterator'](R);let _0x6cc20c=_0x36fe73['getNext'](),_0x2a5843=_0x2ec227['getNext']();for(;_0x6cc20c&&_0x2a5843;){if(_0x6cc20c['name']!==_0x2a5843['name']||!_0x6cc20c['node']['equals'](_0x2a5843['node']))return!0x1;_0x6cc20c=_0x36fe73['getNext'](),_0x2a5843=_0x2ec227['getNext']();}return _0x6cc20c===null&&_0x2a5843===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x101b29){return _0x101b29===ye?null:this['indexMap_']['get'](_0x101b29['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Yi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x7dc8da){return _0x7dc8da===this?0x0:0x1;}['equals'](_0x52d30b){return _0x52d30b===this;}['getPriority'](){return this;}['getImmediateChild'](_0x38739d){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const $t=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(Fe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,$t)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh($t),Wh($t);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function P(_0x1d3000,_0x35be6b=null){if(_0x1d3000===null)return g['EMPTY_NODE'];if(typeof _0x1d3000=='object'&&'.priority'in _0x1d3000&&(_0x35be6b=_0x1d3000['.priority']),f(_0x35be6b===null||typeof _0x35be6b=='string'||typeof _0x35be6b=='number'||typeof _0x35be6b=='object'&&'.sv'in _0x35be6b,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x35be6b),typeof _0x1d3000=='object'&&'.value'in _0x1d3000&&_0x1d3000['.value']!==null&&(_0x1d3000=_0x1d3000['.value']),typeof _0x1d3000!='object'||'.sv'in _0x1d3000){const _0x587a64=_0x1d3000;return new D(_0x587a64,P(_0x35be6b));}if(!(_0x1d3000 instanceof Array)&&Gh){const _0x3df1bc=[];let _0x171805=!0x1;if(x(_0x1d3000,(_0x419dee,_0x3c8882)=>{if(_0x419dee['substring'](0x0,0x1)!=='.'){const _0x2649cc=P(_0x3c8882);_0x2649cc['isEmpty']()||(_0x171805=_0x171805||!_0x2649cc['getPriority']()['isEmpty'](),_0x3df1bc['push'](new E(_0x419dee,_0x2649cc)));}}),_0x3df1bc['length']===0x0)return g['EMPTY_NODE'];const _0x3c0242=fn(_0x3df1bc,xh,_0x47acff=>_0x47acff['name'],Yi);if(_0x171805){const _0x5d543a=fn(_0x3df1bc,R['getCompare']());return new g(_0x3c0242,P(_0x35be6b),new te({'.priority':_0x5d543a},{'.priority':R}));}else return new g(_0x3c0242,P(_0x35be6b),te['Default']);}else{let _0x5c8ac=g['EMPTY_NODE'];return x(_0x1d3000,(_0x257fad,_0x4c220f)=>{if(J(_0x1d3000,_0x257fad)&&_0x257fad['substring'](0x0,0x1)!=='.'){const _0x4d5d20=P(_0x4c220f);(_0x4d5d20['isLeafNode']()||!_0x4d5d20['isEmpty']())&&(_0x5c8ac=_0x5c8ac['updateImmediateChild'](_0x257fad,_0x4d5d20));}}),_0x5c8ac['updatePriority'](P(_0x35be6b));}}Uh(P);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi extends Dn{constructor(_0x1f59ac){super(),this['indexPath_']=_0x1f59ac,f(!v(_0x1f59ac)&&y(_0x1f59ac)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x5281be){return _0x5281be['getChild'](this['indexPath_']);}['isDefinedOn'](_0x4279dd){return!_0x4279dd['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0xdd0bbd,_0x526210){const _0x3821e9=this['extractChild'](_0xdd0bbd['node']),_0x2e3503=this['extractChild'](_0x526210['node']),_0x4bfd26=_0x3821e9['compareTo'](_0x2e3503);return _0x4bfd26===0x0?He(_0xdd0bbd['name'],_0x526210['name']):_0x4bfd26;}['makePost'](_0x1b08d7,_0x5c21c5){const _0x3ef2d4=P(_0x1b08d7),_0x7a7e=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x3ef2d4);return new E(_0x5c21c5,_0x7a7e);}['maxPost'](){const _0x4c9a92=g['EMPTY_NODE']['updateChild'](this['indexPath_'],$t);return new E(Ie,_0x4c9a92);}['toString'](){return Pt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Dn{['compare'](_0x2cfb8f,_0x1ad04d){const _0x284e40=_0x2cfb8f['node']['compareTo'](_0x1ad04d['node']);return _0x284e40===0x0?He(_0x2cfb8f['name'],_0x1ad04d['name']):_0x284e40;}['isDefinedOn'](_0x54dd1d){return!0x0;}['indexedValueChanged'](_0x346122,_0x51f621){return!_0x346122['equals'](_0x51f621);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x1499a6,_0x3f7c1e){const _0x128f69=P(_0x1499a6);return new E(_0x3f7c1e,_0x128f69);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x223046){return{'type':'value','snapshotNode':_0x223046};}function et(_0x18dbbd,_0x42d9e9){return{'type':'child_added','snapshotNode':_0x42d9e9,'childName':_0x18dbbd};}function Ot(_0x2c1bef,_0x5f4ce4){return{'type':'child_removed','snapshotNode':_0x5f4ce4,'childName':_0x2c1bef};}function Dt(_0x854064,_0x9e1893,_0x30f840){return{'type':'child_changed','snapshotNode':_0x9e1893,'childName':_0x854064,'oldSnap':_0x30f840};}function zh(_0x486e61,_0x2146f7){return{'type':'child_moved','snapshotNode':_0x2146f7,'childName':_0x486e61};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji{constructor(_0x37375b){this['index_']=_0x37375b;}['updateChild'](_0x5956b2,_0x44ffac,_0x51e502,_0x1e711b,_0x44af9a,_0x389041){f(_0x5956b2['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x317e0e=_0x5956b2['getImmediateChild'](_0x44ffac);return _0x317e0e['getChild'](_0x1e711b)['equals'](_0x51e502['getChild'](_0x1e711b))&&_0x317e0e['isEmpty']()===_0x51e502['isEmpty']()||(_0x389041!=null&&(_0x51e502['isEmpty']()?_0x5956b2['hasChild'](_0x44ffac)?_0x389041['trackChildChange'](Ot(_0x44ffac,_0x317e0e)):f(_0x5956b2['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x317e0e['isEmpty']()?_0x389041['trackChildChange'](et(_0x44ffac,_0x51e502)):_0x389041['trackChildChange'](Dt(_0x44ffac,_0x51e502,_0x317e0e))),_0x5956b2['isLeafNode']()&&_0x51e502['isEmpty']())?_0x5956b2:_0x5956b2['updateImmediateChild'](_0x44ffac,_0x51e502)['withIndex'](this['index_']);}['updateFullNode'](_0x19f471,_0x11ccf1,_0x2c2bca){return _0x2c2bca!=null&&(_0x19f471['isLeafNode']()||_0x19f471['forEachChild'](R,(_0x164c43,_0x596d54)=>{_0x11ccf1['hasChild'](_0x164c43)||_0x2c2bca['trackChildChange'](Ot(_0x164c43,_0x596d54));}),_0x11ccf1['isLeafNode']()||_0x11ccf1['forEachChild'](R,(_0x5b3b30,_0x27ce93)=>{if(_0x19f471['hasChild'](_0x5b3b30)){const _0x410ffb=_0x19f471['getImmediateChild'](_0x5b3b30);_0x410ffb['equals'](_0x27ce93)||_0x2c2bca['trackChildChange'](Dt(_0x5b3b30,_0x27ce93,_0x410ffb));}else _0x2c2bca['trackChildChange'](et(_0x5b3b30,_0x27ce93));})),_0x11ccf1['withIndex'](this['index_']);}['updatePriority'](_0x1a42b4,_0x229952){return _0x1a42b4['isEmpty']()?g['EMPTY_NODE']:_0x1a42b4['updatePriority'](_0x229952);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Mt{constructor(_0x4c8aec){this['indexedFilter_']=new Ji(_0x4c8aec['getIndex']()),this['index_']=_0x4c8aec['getIndex'](),this['startPost_']=Mt['getStartPost_'](_0x4c8aec),this['endPost_']=Mt['getEndPost_'](_0x4c8aec),this['startIsInclusive_']=!_0x4c8aec['startAfterSet_'],this['endIsInclusive_']=!_0x4c8aec['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x3fed2a){const _0x2aeb9a=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x3fed2a)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x3fed2a)<0x0,_0x22ce56=this['endIsInclusive_']?this['index_']['compare'](_0x3fed2a,this['getEndPost']())<=0x0:this['index_']['compare'](_0x3fed2a,this['getEndPost']())<0x0;return _0x2aeb9a&&_0x22ce56;}['updateChild'](_0x237043,_0xd37eb5,_0x25b4ee,_0x3a234b,_0x4eb482,_0x1b8466){return this['matches'](new E(_0xd37eb5,_0x25b4ee))||(_0x25b4ee=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x237043,_0xd37eb5,_0x25b4ee,_0x3a234b,_0x4eb482,_0x1b8466);}['updateFullNode'](_0x288a59,_0x529d1e,_0x501586){_0x529d1e['isLeafNode']()&&(_0x529d1e=g['EMPTY_NODE']);let _0x3c9353=_0x529d1e['withIndex'](this['index_']);_0x3c9353=_0x3c9353['updatePriority'](g['EMPTY_NODE']);const _0x1a7dbc=this;return _0x529d1e['forEachChild'](R,(_0x266374,_0x530624)=>{_0x1a7dbc['matches'](new E(_0x266374,_0x530624))||(_0x3c9353=_0x3c9353['updateImmediateChild'](_0x266374,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x288a59,_0x3c9353,_0x501586);}['updatePriority'](_0x492a10,_0x3b4f67){return _0x492a10;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x1dbb5b){if(_0x1dbb5b['hasStart']()){const _0x208169=_0x1dbb5b['getIndexStartName']();return _0x1dbb5b['getIndex']()['makePost'](_0x1dbb5b['getIndexStartValue'](),_0x208169);}else return _0x1dbb5b['getIndex']()['minPost']();}static['getEndPost_'](_0x453916){if(_0x453916['hasEnd']()){const _0x40aa96=_0x453916['getIndexEndName']();return _0x453916['getIndex']()['makePost'](_0x453916['getIndexEndValue'](),_0x40aa96);}else return _0x453916['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x44ef90){this['withinDirectionalStart']=_0x3f1e08=>this['reverse_']?this['withinEndPost'](_0x3f1e08):this['withinStartPost'](_0x3f1e08),this['withinDirectionalEnd']=_0x5a5004=>this['reverse_']?this['withinStartPost'](_0x5a5004):this['withinEndPost'](_0x5a5004),this['withinStartPost']=_0x30afbd=>{const _0x53cf62=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x30afbd);return this['startIsInclusive_']?_0x53cf62<=0x0:_0x53cf62<0x0;},this['withinEndPost']=_0x2903f4=>{const _0x2427b0=this['index_']['compare'](_0x2903f4,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x2427b0<=0x0:_0x2427b0<0x0;},this['rangedFilter_']=new Mt(_0x44ef90),this['index_']=_0x44ef90['getIndex'](),this['limit_']=_0x44ef90['getLimit'](),this['reverse_']=!_0x44ef90['isViewFromLeft'](),this['startIsInclusive_']=!_0x44ef90['startAfterSet_'],this['endIsInclusive_']=!_0x44ef90['endBeforeSet_'];}['updateChild'](_0x23c9f6,_0x3fba23,_0x194899,_0x96bfc1,_0x374aaf,_0x4564db){return this['rangedFilter_']['matches'](new E(_0x3fba23,_0x194899))||(_0x194899=g['EMPTY_NODE']),_0x23c9f6['getImmediateChild'](_0x3fba23)['equals'](_0x194899)?_0x23c9f6:_0x23c9f6['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x23c9f6,_0x3fba23,_0x194899,_0x96bfc1,_0x374aaf,_0x4564db):this['fullLimitUpdateChild_'](_0x23c9f6,_0x3fba23,_0x194899,_0x374aaf,_0x4564db);}['updateFullNode'](_0x418e22,_0x5e79ce,_0x6a0bbb){let _0xb348b9;if(_0x5e79ce['isLeafNode']()||_0x5e79ce['isEmpty']())_0xb348b9=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x5e79ce['numChildren']()&&_0x5e79ce['isIndexed'](this['index_'])){_0xb348b9=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x57d5da;this['reverse_']?_0x57d5da=_0x5e79ce['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x57d5da=_0x5e79ce['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x3d3140=0x0;for(;_0x57d5da['hasNext']()&&_0x3d3140<this['limit_'];){const _0x4c8ce5=_0x57d5da['getNext']();if(this['withinDirectionalStart'](_0x4c8ce5)){if(this['withinDirectionalEnd'](_0x4c8ce5))_0xb348b9=_0xb348b9['updateImmediateChild'](_0x4c8ce5['name'],_0x4c8ce5['node']),_0x3d3140++;else break;}else continue;}}else{_0xb348b9=_0x5e79ce['withIndex'](this['index_']),_0xb348b9=_0xb348b9['updatePriority'](g['EMPTY_NODE']);let _0xc07812;this['reverse_']?_0xc07812=_0xb348b9['getReverseIterator'](this['index_']):_0xc07812=_0xb348b9['getIterator'](this['index_']);let _0x1d3f17=0x0;for(;_0xc07812['hasNext']();){const _0x2d2ac6=_0xc07812['getNext']();_0x1d3f17<this['limit_']&&this['withinDirectionalStart'](_0x2d2ac6)&&this['withinDirectionalEnd'](_0x2d2ac6)?_0x1d3f17++:_0xb348b9=_0xb348b9['updateImmediateChild'](_0x2d2ac6['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x418e22,_0xb348b9,_0x6a0bbb);}['updatePriority'](_0x3441d2,_0x9c9549){return _0x3441d2;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x2198f7,_0x47c6b1,_0x16059d,_0x4120a5,_0xdeea8e){let _0x5c94c4;if(this['reverse_']){const _0x187793=this['index_']['getCompare']();_0x5c94c4=(_0x4aab9a,_0x302ec1)=>_0x187793(_0x302ec1,_0x4aab9a);}else _0x5c94c4=this['index_']['getCompare']();const _0x5e900f=_0x2198f7;f(_0x5e900f['numChildren']()===this['limit_'],'');const _0x3f9a58=new E(_0x47c6b1,_0x16059d),_0x408e22=this['reverse_']?_0x5e900f['getFirstChild'](this['index_']):_0x5e900f['getLastChild'](this['index_']),_0x153a8d=this['rangedFilter_']['matches'](_0x3f9a58);if(_0x5e900f['hasChild'](_0x47c6b1)){const _0x22c13b=_0x5e900f['getImmediateChild'](_0x47c6b1);let _0x3e2f33=_0x4120a5['getChildAfterChild'](this['index_'],_0x408e22,this['reverse_']);for(;_0x3e2f33!=null&&(_0x3e2f33['name']===_0x47c6b1||_0x5e900f['hasChild'](_0x3e2f33['name']));)_0x3e2f33=_0x4120a5['getChildAfterChild'](this['index_'],_0x3e2f33,this['reverse_']);const _0x360cd5=_0x3e2f33==null?0x1:_0x5c94c4(_0x3e2f33,_0x3f9a58);if(_0x153a8d&&!_0x16059d['isEmpty']()&&_0x360cd5>=0x0)return _0xdeea8e!=null&&_0xdeea8e['trackChildChange'](Dt(_0x47c6b1,_0x16059d,_0x22c13b)),_0x5e900f['updateImmediateChild'](_0x47c6b1,_0x16059d);{_0xdeea8e!=null&&_0xdeea8e['trackChildChange'](Ot(_0x47c6b1,_0x22c13b));const _0x4d9525=_0x5e900f['updateImmediateChild'](_0x47c6b1,g['EMPTY_NODE']);return _0x3e2f33!=null&&this['rangedFilter_']['matches'](_0x3e2f33)?(_0xdeea8e!=null&&_0xdeea8e['trackChildChange'](et(_0x3e2f33['name'],_0x3e2f33['node'])),_0x4d9525['updateImmediateChild'](_0x3e2f33['name'],_0x3e2f33['node'])):_0x4d9525;}}else return _0x16059d['isEmpty']()?_0x2198f7:_0x153a8d&&_0x5c94c4(_0x408e22,_0x3f9a58)>=0x0?(_0xdeea8e!=null&&(_0xdeea8e['trackChildChange'](Ot(_0x408e22['name'],_0x408e22['node'])),_0xdeea8e['trackChildChange'](et(_0x47c6b1,_0x16059d))),_0x5e900f['updateImmediateChild'](_0x47c6b1,_0x16059d)['updateImmediateChild'](_0x408e22['name'],g['EMPTY_NODE'])):_0x2198f7;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:Fe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x187b6b=new Xi();return _0x187b6b['limitSet_']=this['limitSet_'],_0x187b6b['limit_']=this['limit_'],_0x187b6b['startSet_']=this['startSet_'],_0x187b6b['startAfterSet_']=this['startAfterSet_'],_0x187b6b['indexStartValue_']=this['indexStartValue_'],_0x187b6b['startNameSet_']=this['startNameSet_'],_0x187b6b['indexStartName_']=this['indexStartName_'],_0x187b6b['endSet_']=this['endSet_'],_0x187b6b['endBeforeSet_']=this['endBeforeSet_'],_0x187b6b['indexEndValue_']=this['indexEndValue_'],_0x187b6b['endNameSet_']=this['endNameSet_'],_0x187b6b['indexEndName_']=this['indexEndName_'],_0x187b6b['index_']=this['index_'],_0x187b6b['viewFrom_']=this['viewFrom_'],_0x187b6b;}}function Kh(_0x35abed){return _0x35abed['loadsAllData']()?new Ji(_0x35abed['getIndex']()):_0x35abed['hasLimit']()?new jh(_0x35abed):new Mt(_0x35abed);}function Yh(_0x40f5ef,_0x590eee){const _0x49eef9=_0x40f5ef['copy']();return _0x49eef9['limitSet_']=!0x0,_0x49eef9['limit_']=_0x590eee,_0x49eef9['viewFrom_']='l',_0x49eef9;}function Qh(_0x198a8e,_0x358dbc,_0x13dacf){const _0x4a6711=_0x198a8e['copy']();return _0x4a6711['startSet_']=!0x0,_0x358dbc===void 0x0&&(_0x358dbc=null),_0x4a6711['indexStartValue_']=_0x358dbc,_0x13dacf!=null?(_0x4a6711['startNameSet_']=!0x0,_0x4a6711['indexStartName_']=_0x13dacf):(_0x4a6711['startNameSet_']=!0x1,_0x4a6711['indexStartName_']=''),_0x4a6711;}function Jh(_0xb670df,_0x6a8740,_0x2496a5){const _0x3b6d99=_0xb670df['copy']();return _0x3b6d99['endSet_']=!0x0,_0x6a8740===void 0x0&&(_0x6a8740=null),_0x3b6d99['indexEndValue_']=_0x6a8740,_0x2496a5!==void 0x0?(_0x3b6d99['endNameSet_']=!0x0,_0x3b6d99['indexEndName_']=_0x2496a5):(_0x3b6d99['endNameSet_']=!0x1,_0x3b6d99['indexEndName_']=''),_0x3b6d99;}function xo(_0x49392a,_0x4d4bea){const _0x332b77=_0x49392a['copy']();return _0x332b77['index_']=_0x4d4bea,_0x332b77;}function sr(_0x122c13){const _0x4418b7={};if(_0x122c13['isDefault']())return _0x4418b7;let _0x449fc4;if(_0x122c13['index_']===R?_0x449fc4='$priority':_0x122c13['index_']===Mo?_0x449fc4='$value':_0x122c13['index_']===ye?_0x449fc4='$key':(f(_0x122c13['index_']instanceof Qi,'Unrecognized\x20index\x20type!'),_0x449fc4=_0x122c13['index_']['toString']()),_0x4418b7['orderBy']=O(_0x449fc4),_0x122c13['startSet_']){const _0x4a9b9d=_0x122c13['startAfterSet_']?'startAfter':'startAt';_0x4418b7[_0x4a9b9d]=O(_0x122c13['indexStartValue_']),_0x122c13['startNameSet_']&&(_0x4418b7[_0x4a9b9d]+=','+O(_0x122c13['indexStartName_']));}if(_0x122c13['endSet_']){const _0x14aa39=_0x122c13['endBeforeSet_']?'endBefore':'endAt';_0x4418b7[_0x14aa39]=O(_0x122c13['indexEndValue_']),_0x122c13['endNameSet_']&&(_0x4418b7[_0x14aa39]+=','+O(_0x122c13['indexEndName_']));}return _0x122c13['limitSet_']&&(_0x122c13['isViewFromLeft']()?_0x4418b7['limitToFirst']=_0x122c13['limit_']:_0x4418b7['limitToLast']=_0x122c13['limit_']),_0x4418b7;}function rr(_0x461922){const _0x279414={};if(_0x461922['startSet_']&&(_0x279414['sp']=_0x461922['indexStartValue_'],_0x461922['startNameSet_']&&(_0x279414['sn']=_0x461922['indexStartName_']),_0x279414['sin']=!_0x461922['startAfterSet_']),_0x461922['endSet_']&&(_0x279414['ep']=_0x461922['indexEndValue_'],_0x461922['endNameSet_']&&(_0x279414['en']=_0x461922['indexEndName_']),_0x279414['ein']=!_0x461922['endBeforeSet_']),_0x461922['limitSet_']){_0x279414['l']=_0x461922['limit_'];let _0x4832f7=_0x461922['viewFrom_'];_0x4832f7===''&&(_0x461922['isViewFromLeft']()?_0x4832f7='l':_0x4832f7='r'),_0x279414['vf']=_0x4832f7;}return _0x461922['index_']!==R&&(_0x279414['i']=_0x461922['index_']['toString']()),_0x279414;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pn extends So{['reportStats'](_0x3cbd44){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x50923b,_0x141fa1){return _0x141fa1!==void 0x0?'tag$'+_0x141fa1:(f(_0x50923b['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x50923b['_path']['toString']());}constructor(_0x1fdee9,_0x128dc4,_0x60a26a,_0x2ed34d){super(),this['repoInfo_']=_0x1fdee9,this['onDataUpdate_']=_0x128dc4,this['authTokenProvider_']=_0x60a26a,this['appCheckTokenProvider_']=_0x2ed34d,this['log_']=Ht('p:rest:'),this['listens_']={};}['listen'](_0x3c5dc4,_0x5dfb4d,_0x304a8f,_0x4feea9){const _0x49d41a=_0x3c5dc4['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x49d41a+'\x20'+_0x3c5dc4['_queryIdentifier']);const _0x5d51ba=pn['getListenId_'](_0x3c5dc4,_0x304a8f),_0x23e964={};this['listens_'][_0x5d51ba]=_0x23e964;const _0x15a108=sr(_0x3c5dc4['_queryParams']);this['restRequest_'](_0x49d41a+'.json',_0x15a108,(_0x5e5221,_0x148365)=>{let _0x3ab54a=_0x148365;if(_0x5e5221===0x194&&(_0x3ab54a=null,_0x5e5221=null),_0x5e5221===null&&this['onDataUpdate_'](_0x49d41a,_0x3ab54a,!0x1,_0x304a8f),De(this['listens_'],_0x5d51ba)===_0x23e964){let _0x8bf147;_0x5e5221?_0x5e5221===0x191?_0x8bf147='permission_denied':_0x8bf147='rest_error:'+_0x5e5221:_0x8bf147='ok',_0x4feea9(_0x8bf147,null);}});}['unlisten'](_0x3dc3f1,_0xa78e25){const _0x17915d=pn['getListenId_'](_0x3dc3f1,_0xa78e25);delete this['listens_'][_0x17915d];}['get'](_0xef9dd4){const _0x40be49=sr(_0xef9dd4['_queryParams']),_0x20d43a=_0xef9dd4['_path']['toString'](),_0x477ac7=new ot();return this['restRequest_'](_0x20d43a+'.json',_0x40be49,(_0x584545,_0x14fc5b)=>{let _0x2ab75c=_0x14fc5b;_0x584545===0x194&&(_0x2ab75c=null,_0x584545=null),_0x584545===null?(this['onDataUpdate_'](_0x20d43a,_0x2ab75c,!0x1,null),_0x477ac7['resolve'](_0x2ab75c)):_0x477ac7['reject'](new Error(_0x2ab75c));}),_0x477ac7['promise'];}['refreshAuthToken'](_0x37fa75){}['restRequest_'](_0x2596ab,_0x574ce5={},_0x362220){return _0x574ce5['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x407020,_0x781493])=>{_0x407020&&_0x407020['accessToken']&&(_0x574ce5['auth']=_0x407020['accessToken']),_0x781493&&_0x781493['token']&&(_0x574ce5['ac']=_0x781493['token']);const _0x518173=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x2596ab+'?ns='+this['repoInfo_']['namespace']+ct(_0x574ce5);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x518173);const _0x22c278=new XMLHttpRequest();_0x22c278['onreadystatechange']=()=>{if(_0x362220&&_0x22c278['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x518173+'\x20received.\x20status:',_0x22c278['status'],'response:',_0x22c278['responseText']);let _0x3f65a9=null;if(_0x22c278['status']>=0xc8&&_0x22c278['status']<0x12c){try{_0x3f65a9=At(_0x22c278['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x518173+':\x20'+_0x22c278['responseText']);}_0x362220(null,_0x3f65a9);}else _0x22c278['status']!==0x191&&_0x22c278['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x518173+'\x20Status:\x20'+_0x22c278['status']),_0x362220(_0x22c278['status']);_0x362220=null;}},_0x22c278['open']('GET',_0x518173,!0x0),_0x22c278['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x5b4e21){return this['rootNode_']['getChild'](_0x5b4e21);}['updateSnapshot'](_0x3d1b2f,_0x3a5de4){this['rootNode_']=this['rootNode_']['updateChild'](_0x3d1b2f,_0x3a5de4);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function _n(){return{'value':null,'children':new Map()};}function Fo(_0x11e0c4,_0x2a8127,_0x47be99){if(v(_0x2a8127))_0x11e0c4['value']=_0x47be99,_0x11e0c4['children']['clear']();else{if(_0x11e0c4['value']!==null)_0x11e0c4['value']=_0x11e0c4['value']['updateChild'](_0x2a8127,_0x47be99);else{const _0x14c9b8=y(_0x2a8127);_0x11e0c4['children']['has'](_0x14c9b8)||_0x11e0c4['children']['set'](_0x14c9b8,_n());const _0x50f38e=_0x11e0c4['children']['get'](_0x14c9b8);_0x2a8127=b(_0x2a8127),Fo(_0x50f38e,_0x2a8127,_0x47be99);}}}function Ii(_0x342bcf,_0x3113d3,_0x374802){_0x342bcf['value']!==null?_0x374802(_0x3113d3,_0x342bcf['value']):Zh(_0x342bcf,(_0x14158b,_0x29d3bf)=>{const _0x3a9fb1=new C(_0x3113d3['toString']()+'/'+_0x14158b);Ii(_0x29d3bf,_0x3a9fb1,_0x374802);});}function Zh(_0x3e15b0,_0x5d4b7a){_0x3e15b0['children']['forEach']((_0x49e8af,_0x48520d)=>{_0x5d4b7a(_0x48520d,_0x49e8af);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x246437){this['collection_']=_0x246437,this['last_']=null;}['get'](){const _0x3a33b2=this['collection_']['get'](),_0x346989={..._0x3a33b2};return this['last_']&&x(this['last_'],(_0x17433a,_0xca770a)=>{_0x346989[_0x17433a]=_0x346989[_0x17433a]-_0xca770a;}),this['last_']=_0x3a33b2,_0x346989;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const or=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x49abf3,_0x5c9e94){this['server_']=_0x5c9e94,this['statsToReport_']={},this['statsListener_']=new eu(_0x49abf3);const _0x856ddb=or+(tu-or)*Math['random']();Ct(this['reportStats_']['bind'](this),Math['floor'](_0x856ddb));}['reportStats_'](){const _0x15e26e=this['statsListener_']['get'](),_0xa13ae6={};let _0xe41a17=!0x1;x(_0x15e26e,(_0x3a624a,_0x565953)=>{_0x565953>0x0&&J(this['statsToReport_'],_0x3a624a)&&(_0xa13ae6[_0x3a624a]=_0x565953,_0xe41a17=!0x0);}),_0xe41a17&&this['server_']['reportStats'](_0xa13ae6),Ct(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var j;(function(_0x334678){_0x334678[_0x334678['OVERWRITE']=0x0]='OVERWRITE',_0x334678[_0x334678['MERGE']=0x1]='MERGE',_0x334678[_0x334678['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x334678[_0x334678['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(j||(j={})));function Zi(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function es(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ts(_0x2fbd35){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x2fbd35,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gn{constructor(_0x3f3c00,_0x54c51c,_0x54580c){this['path']=_0x3f3c00,this['affectedTree']=_0x54c51c,this['revert']=_0x54580c,this['type']=j['ACK_USER_WRITE'],this['source']=Zi();}['operationForChild'](_0x2d276a){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0xb7be2b=this['affectedTree']['subtree'](new C(_0x2d276a));return new gn(w(),_0xb7be2b,this['revert']);}}else return f(y(this['path'])===_0x2d276a,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new gn(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Lt{constructor(_0x5dd537,_0x5d0f85){this['source']=_0x5dd537,this['path']=_0x5d0f85,this['type']=j['LISTEN_COMPLETE'];}['operationForChild'](_0x5b2f8c){return v(this['path'])?new Lt(this['source'],w()):new Lt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ue{constructor(_0x5a09de,_0x4f0865,_0xfe88d2){this['source']=_0x5a09de,this['path']=_0x4f0865,this['snap']=_0xfe88d2,this['type']=j['OVERWRITE'];}['operationForChild'](_0x5b142e){return v(this['path'])?new Ue(this['source'],w(),this['snap']['getImmediateChild'](_0x5b142e)):new Ue(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tt{constructor(_0x29166b,_0x494cb7,_0x1c9d70){this['source']=_0x29166b,this['path']=_0x494cb7,this['children']=_0x1c9d70,this['type']=j['MERGE'];}['operationForChild'](_0x3ba208){if(v(this['path'])){const _0x1ee924=this['children']['subtree'](new C(_0x3ba208));return _0x1ee924['isEmpty']()?null:_0x1ee924['value']?new Ue(this['source'],w(),_0x1ee924['value']):new tt(this['source'],w(),_0x1ee924);}else return f(y(this['path'])===_0x3ba208,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new tt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x15b896,_0x4e327e,_0x4fefd1){this['node_']=_0x15b896,this['fullyInitialized_']=_0x4e327e,this['filtered_']=_0x4fefd1;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x36600c){if(v(_0x36600c))return this['isFullyInitialized']()&&!this['filtered_'];const _0x45b93c=y(_0x36600c);return this['isCompleteForChild'](_0x45b93c);}['isCompleteForChild'](_0x51366f){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x51366f);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x3c75bc){this['query_']=_0x3c75bc,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x27ad22,_0x1c2c12,_0x31f9fa,_0x59c769){const _0x15fbc6=[],_0x1b504e=[];return _0x1c2c12['forEach'](_0x20e9a8=>{_0x20e9a8['type']==='child_changed'&&_0x27ad22['index_']['indexedValueChanged'](_0x20e9a8['oldSnap'],_0x20e9a8['snapshotNode'])&&_0x1b504e['push'](zh(_0x20e9a8['childName'],_0x20e9a8['snapshotNode']));}),yt(_0x27ad22,_0x15fbc6,'child_removed',_0x1c2c12,_0x59c769,_0x31f9fa),yt(_0x27ad22,_0x15fbc6,'child_added',_0x1c2c12,_0x59c769,_0x31f9fa),yt(_0x27ad22,_0x15fbc6,'child_moved',_0x1b504e,_0x59c769,_0x31f9fa),yt(_0x27ad22,_0x15fbc6,'child_changed',_0x1c2c12,_0x59c769,_0x31f9fa),yt(_0x27ad22,_0x15fbc6,'value',_0x1c2c12,_0x59c769,_0x31f9fa),_0x15fbc6;}function yt(_0xc079d9,_0x52350c,_0x36b0b6,_0x19c215,_0x569e47,_0x36535c){const _0x25da85=_0x19c215['filter'](_0x587925=>_0x587925['type']===_0x36b0b6);_0x25da85['sort']((_0x3590f7,_0x11866c)=>au(_0xc079d9,_0x3590f7,_0x11866c)),_0x25da85['forEach'](_0x3cc9b1=>{const _0x77df9f=ou(_0xc079d9,_0x3cc9b1,_0x36535c);_0x569e47['forEach'](_0x36f570=>{_0x36f570['respondsTo'](_0x3cc9b1['type'])&&_0x52350c['push'](_0x36f570['createEvent'](_0x77df9f,_0xc079d9['query_']));});});}function ou(_0x4ded75,_0x52564f,_0x5c337a){return _0x52564f['type']==='value'||_0x52564f['type']==='child_removed'||(_0x52564f['prevName']=_0x5c337a['getPredecessorChildName'](_0x52564f['childName'],_0x52564f['snapshotNode'],_0x4ded75['index_'])),_0x52564f;}function au(_0x835361,_0x4d0332,_0x165f04){if(_0x4d0332['childName']==null||_0x165f04['childName']==null)throw rt('Should\x20only\x20compare\x20child_\x20events.');const _0xde3298=new E(_0x4d0332['childName'],_0x4d0332['snapshotNode']),_0x3ba2c7=new E(_0x165f04['childName'],_0x165f04['snapshotNode']);return _0x835361['index_']['compare'](_0xde3298,_0x3ba2c7);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x58468b,_0x2da806){return{'eventCache':_0x58468b,'serverCache':_0x2da806};}function Tt(_0x278f14,_0xa8d39c,_0x16dc3e,_0x25930a){return Mn(new Ce(_0xa8d39c,_0x16dc3e,_0x25930a),_0x278f14['serverCache']);}function Uo(_0x8781ff,_0x554886,_0x5772af,_0x4759ef){return Mn(_0x8781ff['eventCache'],new Ce(_0x554886,_0x5772af,_0x4759ef));}function mn(_0x53f565){return _0x53f565['eventCache']['isFullyInitialized']()?_0x53f565['eventCache']['getNode']():null;}function We(_0x4fa81e){return _0x4fa81e['serverCache']['isFullyInitialized']()?_0x4fa81e['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let oi;const cu=()=>(oi||(oi=new B(ql)),oi);class S{static['fromObject'](_0x12d3d8){let _0x1da7fa=new S(null);return x(_0x12d3d8,(_0x4bc669,_0x4874e8)=>{_0x1da7fa=_0x1da7fa['set'](new C(_0x4bc669),_0x4874e8);}),_0x1da7fa;}constructor(_0x531dfe,_0x4d45cf=cu()){this['value']=_0x531dfe,this['children']=_0x4d45cf;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x2089a0,_0x1eb67f){if(this['value']!=null&&_0x1eb67f(this['value']))return{'path':w(),'value':this['value']};if(v(_0x2089a0))return null;{const _0x1e02e8=y(_0x2089a0),_0xa04a1c=this['children']['get'](_0x1e02e8);if(_0xa04a1c!==null){const _0x53555e=_0xa04a1c['findRootMostMatchingPathAndValue'](b(_0x2089a0),_0x1eb67f);return _0x53555e!=null?{'path':k(new C(_0x1e02e8),_0x53555e['path']),'value':_0x53555e['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x525f4b){return this['findRootMostMatchingPathAndValue'](_0x525f4b,()=>!0x0);}['subtree'](_0x51b809){if(v(_0x51b809))return this;{const _0x1ecb90=y(_0x51b809),_0x351c7f=this['children']['get'](_0x1ecb90);return _0x351c7f!==null?_0x351c7f['subtree'](b(_0x51b809)):new S(null);}}['set'](_0x5b7747,_0x4e8dbf){if(v(_0x5b7747))return new S(_0x4e8dbf,this['children']);{const _0x2680a0=y(_0x5b7747),_0x28d96f=(this['children']['get'](_0x2680a0)||new S(null))['set'](b(_0x5b7747),_0x4e8dbf),_0x1c431f=this['children']['insert'](_0x2680a0,_0x28d96f);return new S(this['value'],_0x1c431f);}}['remove'](_0x27fc07){if(v(_0x27fc07))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x3015b4=y(_0x27fc07),_0x4831f2=this['children']['get'](_0x3015b4);if(_0x4831f2){const _0xd71fef=_0x4831f2['remove'](b(_0x27fc07));let _0x49b1dc;return _0xd71fef['isEmpty']()?_0x49b1dc=this['children']['remove'](_0x3015b4):_0x49b1dc=this['children']['insert'](_0x3015b4,_0xd71fef),this['value']===null&&_0x49b1dc['isEmpty']()?new S(null):new S(this['value'],_0x49b1dc);}else return this;}}['get'](_0x4f412e){if(v(_0x4f412e))return this['value'];{const _0x34c93a=y(_0x4f412e),_0x59f0aa=this['children']['get'](_0x34c93a);return _0x59f0aa?_0x59f0aa['get'](b(_0x4f412e)):null;}}['setTree'](_0x117fc0,_0xfcc74f){if(v(_0x117fc0))return _0xfcc74f;{const _0x5c05d8=y(_0x117fc0),_0xdfba31=(this['children']['get'](_0x5c05d8)||new S(null))['setTree'](b(_0x117fc0),_0xfcc74f);let _0x1438dd;return _0xdfba31['isEmpty']()?_0x1438dd=this['children']['remove'](_0x5c05d8):_0x1438dd=this['children']['insert'](_0x5c05d8,_0xdfba31),new S(this['value'],_0x1438dd);}}['fold'](_0x6213ee){return this['fold_'](w(),_0x6213ee);}['fold_'](_0x2b9419,_0x4dc890){const _0x1b1ec8={};return this['children']['inorderTraversal']((_0x252823,_0x139f0a)=>{_0x1b1ec8[_0x252823]=_0x139f0a['fold_'](k(_0x2b9419,_0x252823),_0x4dc890);}),_0x4dc890(_0x2b9419,this['value'],_0x1b1ec8);}['findOnPath'](_0x285581,_0x9f7b36){return this['findOnPath_'](_0x285581,w(),_0x9f7b36);}['findOnPath_'](_0x23d40b,_0x27e418,_0x1aabbc){const _0x459abb=this['value']?_0x1aabbc(_0x27e418,this['value']):!0x1;if(_0x459abb)return _0x459abb;if(v(_0x23d40b))return null;{const _0x38a381=y(_0x23d40b),_0x2bc264=this['children']['get'](_0x38a381);return _0x2bc264?_0x2bc264['findOnPath_'](b(_0x23d40b),k(_0x27e418,_0x38a381),_0x1aabbc):null;}}['foreachOnPath'](_0x1043a4,_0x5a5087){return this['foreachOnPath_'](_0x1043a4,w(),_0x5a5087);}['foreachOnPath_'](_0x3d1c08,_0x31cbce,_0x2971a4){if(v(_0x3d1c08))return this;{this['value']&&_0x2971a4(_0x31cbce,this['value']);const _0x24b463=y(_0x3d1c08),_0x474f21=this['children']['get'](_0x24b463);return _0x474f21?_0x474f21['foreachOnPath_'](b(_0x3d1c08),k(_0x31cbce,_0x24b463),_0x2971a4):new S(null);}}['foreach'](_0x15c0f6){this['foreach_'](w(),_0x15c0f6);}['foreach_'](_0x53f720,_0x45b17a){this['children']['inorderTraversal']((_0x4e242b,_0x4e2dfb)=>{_0x4e2dfb['foreach_'](k(_0x53f720,_0x4e242b),_0x45b17a);}),this['value']&&_0x45b17a(_0x53f720,this['value']);}['foreachChild'](_0xc0f967){this['children']['inorderTraversal']((_0x5e7cb2,_0x156dcd)=>{_0x156dcd['value']&&_0xc0f967(_0x5e7cb2,_0x156dcd['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Y{constructor(_0x31ee16){this['writeTree_']=_0x31ee16;}static['empty'](){return new Y(new S(null));}}function St(_0x552932,_0x2cbdf0,_0x4d223d){if(v(_0x2cbdf0))return new Y(new S(_0x4d223d));{const _0x2db913=_0x552932['writeTree_']['findRootMostValueAndPath'](_0x2cbdf0);if(_0x2db913!=null){const _0x1a8c59=_0x2db913['path'];let _0x160b7b=_0x2db913['value'];const _0x303d72=F(_0x1a8c59,_0x2cbdf0);return _0x160b7b=_0x160b7b['updateChild'](_0x303d72,_0x4d223d),new Y(_0x552932['writeTree_']['set'](_0x1a8c59,_0x160b7b));}else{const _0x1c64a4=new S(_0x4d223d),_0x5d6222=_0x552932['writeTree_']['setTree'](_0x2cbdf0,_0x1c64a4);return new Y(_0x5d6222);}}}function wi(_0x3ee8e1,_0x103b90,_0x4fd549){let _0x364c3f=_0x3ee8e1;return x(_0x4fd549,(_0x5d172c,_0x2b006e)=>{_0x364c3f=St(_0x364c3f,k(_0x103b90,_0x5d172c),_0x2b006e);}),_0x364c3f;}function ar(_0xa6d0c2,_0x5ece9b){if(v(_0x5ece9b))return Y['empty']();{const _0xab4c7=_0xa6d0c2['writeTree_']['setTree'](_0x5ece9b,new S(null));return new Y(_0xab4c7);}}function Ci(_0x2a3294,_0x32b355){return $e(_0x2a3294,_0x32b355)!=null;}function $e(_0xa50ea9,_0x577ebc){const _0x2ec890=_0xa50ea9['writeTree_']['findRootMostValueAndPath'](_0x577ebc);return _0x2ec890!=null?_0xa50ea9['writeTree_']['get'](_0x2ec890['path'])['getChild'](F(_0x2ec890['path'],_0x577ebc)):null;}function cr(_0x2b0335){const _0x1b4494=[],_0x4334d8=_0x2b0335['writeTree_']['value'];return _0x4334d8!=null?_0x4334d8['isLeafNode']()||_0x4334d8['forEachChild'](R,(_0x5794ad,_0x318fc4)=>{_0x1b4494['push'](new E(_0x5794ad,_0x318fc4));}):_0x2b0335['writeTree_']['children']['inorderTraversal']((_0x2c65ec,_0x2a8468)=>{_0x2a8468['value']!=null&&_0x1b4494['push'](new E(_0x2c65ec,_0x2a8468['value']));}),_0x1b4494;}function ve(_0x234bfb,_0x1fd075){if(v(_0x1fd075))return _0x234bfb;{const _0x1623e4=$e(_0x234bfb,_0x1fd075);return _0x1623e4!=null?new Y(new S(_0x1623e4)):new Y(_0x234bfb['writeTree_']['subtree'](_0x1fd075));}}function Ti(_0x4dff62){return _0x4dff62['writeTree_']['isEmpty']();}function nt(_0x3da921,_0x35594a){return Wo(w(),_0x3da921['writeTree_'],_0x35594a);}function Wo(_0x16096a,_0x1379f0,_0x1a6167){if(_0x1379f0['value']!=null)return _0x1a6167['updateChild'](_0x16096a,_0x1379f0['value']);{let _0x5587b0=null;return _0x1379f0['children']['inorderTraversal']((_0x40e3bf,_0x533f86)=>{_0x40e3bf==='.priority'?(f(_0x533f86['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x5587b0=_0x533f86['value']):_0x1a6167=Wo(k(_0x16096a,_0x40e3bf),_0x533f86,_0x1a6167);}),!_0x1a6167['getChild'](_0x16096a)['isEmpty']()&&_0x5587b0!==null&&(_0x1a6167=_0x1a6167['updateChild'](k(_0x16096a,'.priority'),_0x5587b0)),_0x1a6167;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ln(_0x2b1468,_0x2ecbee){return $o(_0x2ecbee,_0x2b1468);}function lu(_0x4fa069,_0xece330,_0x3d5a8f,_0x4bb519,_0x528e95){f(_0x4bb519>_0x4fa069['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x528e95===void 0x0&&(_0x528e95=!0x0),_0x4fa069['allWrites']['push']({'path':_0xece330,'snap':_0x3d5a8f,'writeId':_0x4bb519,'visible':_0x528e95}),_0x528e95&&(_0x4fa069['visibleWrites']=St(_0x4fa069['visibleWrites'],_0xece330,_0x3d5a8f)),_0x4fa069['lastWriteId']=_0x4bb519;}function hu(_0x5d6ea5,_0x555429,_0x3f3627,_0x27e9fb){f(_0x27e9fb>_0x5d6ea5['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x5d6ea5['allWrites']['push']({'path':_0x555429,'children':_0x3f3627,'writeId':_0x27e9fb,'visible':!0x0}),_0x5d6ea5['visibleWrites']=wi(_0x5d6ea5['visibleWrites'],_0x555429,_0x3f3627),_0x5d6ea5['lastWriteId']=_0x27e9fb;}function uu(_0x31aba8,_0x2c944a){for(let _0x29e099=0x0;_0x29e099<_0x31aba8['allWrites']['length'];_0x29e099++){const _0x38470a=_0x31aba8['allWrites'][_0x29e099];if(_0x38470a['writeId']===_0x2c944a)return _0x38470a;}return null;}function du(_0xdcb715,_0x1d5c09){const _0x650d14=_0xdcb715['allWrites']['findIndex'](_0x56cea9=>_0x56cea9['writeId']===_0x1d5c09);f(_0x650d14>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0xb00a55=_0xdcb715['allWrites'][_0x650d14];_0xdcb715['allWrites']['splice'](_0x650d14,0x1);let _0x241eea=_0xb00a55['visible'],_0x39d3eb=!0x1,_0x88ebc8=_0xdcb715['allWrites']['length']-0x1;for(;_0x241eea&&_0x88ebc8>=0x0;){const _0x105068=_0xdcb715['allWrites'][_0x88ebc8];_0x105068['visible']&&(_0x88ebc8>=_0x650d14&&fu(_0x105068,_0xb00a55['path'])?_0x241eea=!0x1:G(_0xb00a55['path'],_0x105068['path'])&&(_0x39d3eb=!0x0)),_0x88ebc8--;}if(_0x241eea){if(_0x39d3eb)return pu(_0xdcb715),!0x0;if(_0xb00a55['snap'])_0xdcb715['visibleWrites']=ar(_0xdcb715['visibleWrites'],_0xb00a55['path']);else{const _0x12ef35=_0xb00a55['children'];x(_0x12ef35,_0x4dc4f8=>{_0xdcb715['visibleWrites']=ar(_0xdcb715['visibleWrites'],k(_0xb00a55['path'],_0x4dc4f8));});}return!0x0;}else return!0x1;}function fu(_0x3f987b,_0x36ebf6){if(_0x3f987b['snap'])return G(_0x3f987b['path'],_0x36ebf6);for(const _0x2ff553 in _0x3f987b['children'])if(_0x3f987b['children']['hasOwnProperty'](_0x2ff553)&&G(k(_0x3f987b['path'],_0x2ff553),_0x36ebf6))return!0x0;return!0x1;}function pu(_0x55ca7c){_0x55ca7c['visibleWrites']=Bo(_0x55ca7c['allWrites'],_u,w()),_0x55ca7c['allWrites']['length']>0x0?_0x55ca7c['lastWriteId']=_0x55ca7c['allWrites'][_0x55ca7c['allWrites']['length']-0x1]['writeId']:_0x55ca7c['lastWriteId']=-0x1;}function _u(_0x2145af){return _0x2145af['visible'];}function Bo(_0x45852f,_0x4b627a,_0x872170){let _0x4eb312=Y['empty']();for(let _0x5af749=0x0;_0x5af749<_0x45852f['length'];++_0x5af749){const _0x473e80=_0x45852f[_0x5af749];if(_0x4b627a(_0x473e80)){const _0x4fd40e=_0x473e80['path'];let _0x21341a;if(_0x473e80['snap'])G(_0x872170,_0x4fd40e)?(_0x21341a=F(_0x872170,_0x4fd40e),_0x4eb312=St(_0x4eb312,_0x21341a,_0x473e80['snap'])):G(_0x4fd40e,_0x872170)&&(_0x21341a=F(_0x4fd40e,_0x872170),_0x4eb312=St(_0x4eb312,w(),_0x473e80['snap']['getChild'](_0x21341a)));else{if(_0x473e80['children']){if(G(_0x872170,_0x4fd40e))_0x21341a=F(_0x872170,_0x4fd40e),_0x4eb312=wi(_0x4eb312,_0x21341a,_0x473e80['children']);else{if(G(_0x4fd40e,_0x872170)){if(_0x21341a=F(_0x4fd40e,_0x872170),v(_0x21341a))_0x4eb312=wi(_0x4eb312,w(),_0x473e80['children']);else{const _0xb86a92=De(_0x473e80['children'],y(_0x21341a));if(_0xb86a92){const _0x14f42e=_0xb86a92['getChild'](b(_0x21341a));_0x4eb312=St(_0x4eb312,w(),_0x14f42e);}}}}}else throw rt('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x4eb312;}function Vo(_0x191f05,_0x3a97df,_0x4a9e4b,_0xcc7b92,_0x2c8342){if(!_0xcc7b92&&!_0x2c8342){const _0x13e221=$e(_0x191f05['visibleWrites'],_0x3a97df);if(_0x13e221!=null)return _0x13e221;{const _0x424412=ve(_0x191f05['visibleWrites'],_0x3a97df);if(Ti(_0x424412))return _0x4a9e4b;if(_0x4a9e4b==null&&!Ci(_0x424412,w()))return null;{const _0x267395=_0x4a9e4b||g['EMPTY_NODE'];return nt(_0x424412,_0x267395);}}}else{const _0x1b0bbd=ve(_0x191f05['visibleWrites'],_0x3a97df);if(!_0x2c8342&&Ti(_0x1b0bbd))return _0x4a9e4b;if(!_0x2c8342&&_0x4a9e4b==null&&!Ci(_0x1b0bbd,w()))return null;{const _0x18a1e=function(_0x235c66){return(_0x235c66['visible']||_0x2c8342)&&(!_0xcc7b92||!~_0xcc7b92['indexOf'](_0x235c66['writeId']))&&(G(_0x235c66['path'],_0x3a97df)||G(_0x3a97df,_0x235c66['path']));},_0x20a10b=Bo(_0x191f05['allWrites'],_0x18a1e,_0x3a97df),_0x5a9667=_0x4a9e4b||g['EMPTY_NODE'];return nt(_0x20a10b,_0x5a9667);}}}function gu(_0x18156c,_0x491917,_0x40c368){let _0x4e427a=g['EMPTY_NODE'];const _0x4c1e0c=$e(_0x18156c['visibleWrites'],_0x491917);if(_0x4c1e0c)return _0x4c1e0c['isLeafNode']()||_0x4c1e0c['forEachChild'](R,(_0x47f2b9,_0xfec04c)=>{_0x4e427a=_0x4e427a['updateImmediateChild'](_0x47f2b9,_0xfec04c);}),_0x4e427a;if(_0x40c368){const _0x259b75=ve(_0x18156c['visibleWrites'],_0x491917);return _0x40c368['forEachChild'](R,(_0x58da53,_0xe0821f)=>{const _0x56df6d=nt(ve(_0x259b75,new C(_0x58da53)),_0xe0821f);_0x4e427a=_0x4e427a['updateImmediateChild'](_0x58da53,_0x56df6d);}),cr(_0x259b75)['forEach'](_0x58a528=>{_0x4e427a=_0x4e427a['updateImmediateChild'](_0x58a528['name'],_0x58a528['node']);}),_0x4e427a;}else{const _0x4e79d4=ve(_0x18156c['visibleWrites'],_0x491917);return cr(_0x4e79d4)['forEach'](_0x34fd54=>{_0x4e427a=_0x4e427a['updateImmediateChild'](_0x34fd54['name'],_0x34fd54['node']);}),_0x4e427a;}}function mu(_0x11bc0f,_0x6712d6,_0x5399f1,_0x36606d,_0x50dfa3){f(_0x36606d||_0x50dfa3,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x532a26=k(_0x6712d6,_0x5399f1);if(Ci(_0x11bc0f['visibleWrites'],_0x532a26))return null;{const _0x338b09=ve(_0x11bc0f['visibleWrites'],_0x532a26);return Ti(_0x338b09)?_0x50dfa3['getChild'](_0x5399f1):nt(_0x338b09,_0x50dfa3['getChild'](_0x5399f1));}}function yu(_0x3f7caf,_0x303618,_0x43fa1c,_0x204778){const _0xaafe22=k(_0x303618,_0x43fa1c),_0x187887=$e(_0x3f7caf['visibleWrites'],_0xaafe22);if(_0x187887!=null)return _0x187887;if(_0x204778['isCompleteForChild'](_0x43fa1c)){const _0x5351d7=ve(_0x3f7caf['visibleWrites'],_0xaafe22);return nt(_0x5351d7,_0x204778['getNode']()['getImmediateChild'](_0x43fa1c));}else return null;}function vu(_0x42f349,_0x4f0036){return $e(_0x42f349['visibleWrites'],_0x4f0036);}function Eu(_0x23ae5f,_0x8d7b27,_0x2d0497,_0x4e6d09,_0x4ee909,_0x212557,_0x44f1ce){let _0x456227;const _0x21a4d9=ve(_0x23ae5f['visibleWrites'],_0x8d7b27),_0x3e8d55=$e(_0x21a4d9,w());if(_0x3e8d55!=null)_0x456227=_0x3e8d55;else{if(_0x2d0497!=null)_0x456227=nt(_0x21a4d9,_0x2d0497);else return[];}if(_0x456227=_0x456227['withIndex'](_0x44f1ce),!_0x456227['isEmpty']()&&!_0x456227['isLeafNode']()){const _0x1ee72a=[],_0x7a5f4a=_0x44f1ce['getCompare'](),_0x1aa978=_0x212557?_0x456227['getReverseIteratorFrom'](_0x4e6d09,_0x44f1ce):_0x456227['getIteratorFrom'](_0x4e6d09,_0x44f1ce);let _0x414860=_0x1aa978['getNext']();for(;_0x414860&&_0x1ee72a['length']<_0x4ee909;)_0x7a5f4a(_0x414860,_0x4e6d09)!==0x0&&_0x1ee72a['push'](_0x414860),_0x414860=_0x1aa978['getNext']();return _0x1ee72a;}else return[];}function Iu(){return{'visibleWrites':Y['empty'](),'allWrites':[],'lastWriteId':-0x1};}function yn(_0x1d6cfe,_0x38c924,_0x1da2f2,_0x205982){return Vo(_0x1d6cfe['writeTree'],_0x1d6cfe['treePath'],_0x38c924,_0x1da2f2,_0x205982);}function ns(_0x229230,_0x2c2135){return gu(_0x229230['writeTree'],_0x229230['treePath'],_0x2c2135);}function lr(_0x189950,_0x5d7cf9,_0x2ac70c,_0x5485f0){return mu(_0x189950['writeTree'],_0x189950['treePath'],_0x5d7cf9,_0x2ac70c,_0x5485f0);}function vn(_0x1e3206,_0x54be32){return vu(_0x1e3206['writeTree'],k(_0x1e3206['treePath'],_0x54be32));}function wu(_0x1a61db,_0x25466c,_0x2f9279,_0xd8c131,_0x2d3c15,_0x3eab41){return Eu(_0x1a61db['writeTree'],_0x1a61db['treePath'],_0x25466c,_0x2f9279,_0xd8c131,_0x2d3c15,_0x3eab41);}function is(_0x5b02e0,_0x1e272c,_0x51ee28){return yu(_0x5b02e0['writeTree'],_0x5b02e0['treePath'],_0x1e272c,_0x51ee28);}function Ho(_0x7f0bb7,_0x299518){return $o(k(_0x7f0bb7['treePath'],_0x299518),_0x7f0bb7['writeTree']);}function $o(_0x230634,_0x3b7455){return{'treePath':_0x230634,'writeTree':_0x3b7455};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0xd685f1){const _0x5c3a99=_0xd685f1['type'],_0x4d5f29=_0xd685f1['childName'];f(_0x5c3a99==='child_added'||_0x5c3a99==='child_changed'||_0x5c3a99==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x4d5f29!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x48e979=this['changeMap']['get'](_0x4d5f29);if(_0x48e979){const _0x215bc1=_0x48e979['type'];if(_0x5c3a99==='child_added'&&_0x215bc1==='child_removed')this['changeMap']['set'](_0x4d5f29,Dt(_0x4d5f29,_0xd685f1['snapshotNode'],_0x48e979['snapshotNode']));else{if(_0x5c3a99==='child_removed'&&_0x215bc1==='child_added')this['changeMap']['delete'](_0x4d5f29);else{if(_0x5c3a99==='child_removed'&&_0x215bc1==='child_changed')this['changeMap']['set'](_0x4d5f29,Ot(_0x4d5f29,_0x48e979['oldSnap']));else{if(_0x5c3a99==='child_changed'&&_0x215bc1==='child_added')this['changeMap']['set'](_0x4d5f29,et(_0x4d5f29,_0xd685f1['snapshotNode']));else{if(_0x5c3a99==='child_changed'&&_0x215bc1==='child_changed')this['changeMap']['set'](_0x4d5f29,Dt(_0x4d5f29,_0xd685f1['snapshotNode'],_0x48e979['oldSnap']));else throw rt('Illegal\x20combination\x20of\x20changes:\x20'+_0xd685f1+'\x20occurred\x20after\x20'+_0x48e979);}}}}}else this['changeMap']['set'](_0x4d5f29,_0xd685f1);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x4de329){return null;}['getChildAfterChild'](_0x5a0f00,_0x5c4863,_0x36d9f5){return null;}}const Go=new Tu();class ss{constructor(_0xbfc8f4,_0x40469f,_0x188eb6=null){this['writes_']=_0xbfc8f4,this['viewCache_']=_0x40469f,this['optCompleteServerCache_']=_0x188eb6;}['getCompleteChild'](_0x28a67a){const _0xd816b1=this['viewCache_']['eventCache'];if(_0xd816b1['isCompleteForChild'](_0x28a67a))return _0xd816b1['getNode']()['getImmediateChild'](_0x28a67a);{const _0x9bdbb3=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return is(this['writes_'],_0x28a67a,_0x9bdbb3);}}['getChildAfterChild'](_0x594aee,_0x39b256,_0x38dc50){const _0x4aee42=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:We(this['viewCache_']),_0x303d9d=wu(this['writes_'],_0x4aee42,_0x39b256,0x1,_0x38dc50,_0x594aee);return _0x303d9d['length']===0x0?null:_0x303d9d[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x53f243){return{'filter':_0x53f243};}function bu(_0xc29ad8,_0x25a6fe){f(_0x25a6fe['eventCache']['getNode']()['isIndexed'](_0xc29ad8['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x25a6fe['serverCache']['getNode']()['isIndexed'](_0xc29ad8['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x4fd39a,_0x5f0a18,_0x21335d,_0x58e5c8,_0x345caf){const _0x41e0e7=new Cu();let _0x1c9565,_0x59f69d;if(_0x21335d['type']===j['OVERWRITE']){const _0x4b76d1=_0x21335d;_0x4b76d1['source']['fromUser']?_0x1c9565=Si(_0x4fd39a,_0x5f0a18,_0x4b76d1['path'],_0x4b76d1['snap'],_0x58e5c8,_0x345caf,_0x41e0e7):(f(_0x4b76d1['source']['fromServer'],'Unknown\x20source.'),_0x59f69d=_0x4b76d1['source']['tagged']||_0x5f0a18['serverCache']['isFiltered']()&&!v(_0x4b76d1['path']),_0x1c9565=En(_0x4fd39a,_0x5f0a18,_0x4b76d1['path'],_0x4b76d1['snap'],_0x58e5c8,_0x345caf,_0x59f69d,_0x41e0e7));}else{if(_0x21335d['type']===j['MERGE']){const _0x30bfd0=_0x21335d;_0x30bfd0['source']['fromUser']?_0x1c9565=ku(_0x4fd39a,_0x5f0a18,_0x30bfd0['path'],_0x30bfd0['children'],_0x58e5c8,_0x345caf,_0x41e0e7):(f(_0x30bfd0['source']['fromServer'],'Unknown\x20source.'),_0x59f69d=_0x30bfd0['source']['tagged']||_0x5f0a18['serverCache']['isFiltered'](),_0x1c9565=bi(_0x4fd39a,_0x5f0a18,_0x30bfd0['path'],_0x30bfd0['children'],_0x58e5c8,_0x345caf,_0x59f69d,_0x41e0e7));}else{if(_0x21335d['type']===j['ACK_USER_WRITE']){const _0x388de2=_0x21335d;_0x388de2['revert']?_0x1c9565=Ou(_0x4fd39a,_0x5f0a18,_0x388de2['path'],_0x58e5c8,_0x345caf,_0x41e0e7):_0x1c9565=Nu(_0x4fd39a,_0x5f0a18,_0x388de2['path'],_0x388de2['affectedTree'],_0x58e5c8,_0x345caf,_0x41e0e7);}else{if(_0x21335d['type']===j['LISTEN_COMPLETE'])_0x1c9565=Pu(_0x4fd39a,_0x5f0a18,_0x21335d['path'],_0x58e5c8,_0x41e0e7);else throw rt('Unknown\x20operation\x20type:\x20'+_0x21335d['type']);}}}const _0x12bd08=_0x41e0e7['getChanges']();return Au(_0x5f0a18,_0x1c9565,_0x12bd08),{'viewCache':_0x1c9565,'changes':_0x12bd08};}function Au(_0x4d6d0a,_0x3ccb23,_0x48035a){const _0x2edb28=_0x3ccb23['eventCache'];if(_0x2edb28['isFullyInitialized']()){const _0x6dab7c=_0x2edb28['getNode']()['isLeafNode']()||_0x2edb28['getNode']()['isEmpty'](),_0x262f46=mn(_0x4d6d0a);(_0x48035a['length']>0x0||!_0x4d6d0a['eventCache']['isFullyInitialized']()||_0x6dab7c&&!_0x2edb28['getNode']()['equals'](_0x262f46)||!_0x2edb28['getNode']()['getPriority']()['equals'](_0x262f46['getPriority']()))&&_0x48035a['push'](Lo(mn(_0x3ccb23)));}}function qo(_0x400e48,_0x5156ca,_0x352e21,_0x4d69df,_0x292db1,_0x18f9b4){const _0x73749=_0x5156ca['eventCache'];if(vn(_0x4d69df,_0x352e21)!=null)return _0x5156ca;{let _0x4c15a9,_0x3674f3;if(v(_0x352e21)){if(f(_0x5156ca['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x5156ca['serverCache']['isFiltered']()){const _0x505b84=We(_0x5156ca),_0x5b327f=_0x505b84 instanceof g?_0x505b84:g['EMPTY_NODE'],_0x2f3e34=ns(_0x4d69df,_0x5b327f);_0x4c15a9=_0x400e48['filter']['updateFullNode'](_0x5156ca['eventCache']['getNode'](),_0x2f3e34,_0x18f9b4);}else{const _0x3ab4d2=yn(_0x4d69df,We(_0x5156ca));_0x4c15a9=_0x400e48['filter']['updateFullNode'](_0x5156ca['eventCache']['getNode'](),_0x3ab4d2,_0x18f9b4);}}else{const _0x3438b0=y(_0x352e21);if(_0x3438b0==='.priority'){f(we(_0x352e21)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x38670d=_0x73749['getNode']();_0x3674f3=_0x5156ca['serverCache']['getNode']();const _0x4e8bbd=lr(_0x4d69df,_0x352e21,_0x38670d,_0x3674f3);_0x4e8bbd!=null?_0x4c15a9=_0x400e48['filter']['updatePriority'](_0x38670d,_0x4e8bbd):_0x4c15a9=_0x73749['getNode']();}else{const _0x42e1be=b(_0x352e21);let _0x58de4d;if(_0x73749['isCompleteForChild'](_0x3438b0)){_0x3674f3=_0x5156ca['serverCache']['getNode']();const _0x2536ce=lr(_0x4d69df,_0x352e21,_0x73749['getNode'](),_0x3674f3);_0x2536ce!=null?_0x58de4d=_0x73749['getNode']()['getImmediateChild'](_0x3438b0)['updateChild'](_0x42e1be,_0x2536ce):_0x58de4d=_0x73749['getNode']()['getImmediateChild'](_0x3438b0);}else _0x58de4d=is(_0x4d69df,_0x3438b0,_0x5156ca['serverCache']);_0x58de4d!=null?_0x4c15a9=_0x400e48['filter']['updateChild'](_0x73749['getNode'](),_0x3438b0,_0x58de4d,_0x42e1be,_0x292db1,_0x18f9b4):_0x4c15a9=_0x73749['getNode']();}}return Tt(_0x5156ca,_0x4c15a9,_0x73749['isFullyInitialized']()||v(_0x352e21),_0x400e48['filter']['filtersNodes']());}}function En(_0x366144,_0x30780c,_0x48995a,_0x17aca9,_0x574ee5,_0x337c32,_0x195a97,_0x67d25a){const _0x1c9bfa=_0x30780c['serverCache'];let _0x563a15;const _0x2f0383=_0x195a97?_0x366144['filter']:_0x366144['filter']['getIndexedFilter']();if(v(_0x48995a))_0x563a15=_0x2f0383['updateFullNode'](_0x1c9bfa['getNode'](),_0x17aca9,null);else{if(_0x2f0383['filtersNodes']()&&!_0x1c9bfa['isFiltered']()){const _0x12ad10=_0x1c9bfa['getNode']()['updateChild'](_0x48995a,_0x17aca9);_0x563a15=_0x2f0383['updateFullNode'](_0x1c9bfa['getNode'](),_0x12ad10,null);}else{const _0x4cdc48=y(_0x48995a);if(!_0x1c9bfa['isCompleteForPath'](_0x48995a)&&we(_0x48995a)>0x1)return _0x30780c;const _0x5ee380=b(_0x48995a),_0x301bd8=_0x1c9bfa['getNode']()['getImmediateChild'](_0x4cdc48)['updateChild'](_0x5ee380,_0x17aca9);_0x4cdc48==='.priority'?_0x563a15=_0x2f0383['updatePriority'](_0x1c9bfa['getNode'](),_0x301bd8):_0x563a15=_0x2f0383['updateChild'](_0x1c9bfa['getNode'](),_0x4cdc48,_0x301bd8,_0x5ee380,Go,null);}}const _0x3b9578=Uo(_0x30780c,_0x563a15,_0x1c9bfa['isFullyInitialized']()||v(_0x48995a),_0x2f0383['filtersNodes']()),_0x33d2c6=new ss(_0x574ee5,_0x3b9578,_0x337c32);return qo(_0x366144,_0x3b9578,_0x48995a,_0x574ee5,_0x33d2c6,_0x67d25a);}function Si(_0x2ff52d,_0x36b40c,_0x466f43,_0x5e05e1,_0x48bbd4,_0x18e38a,_0x262dd2){const _0x4afc6c=_0x36b40c['eventCache'];let _0x2215eb,_0x72684a;const _0x226e0f=new ss(_0x48bbd4,_0x36b40c,_0x18e38a);if(v(_0x466f43))_0x72684a=_0x2ff52d['filter']['updateFullNode'](_0x36b40c['eventCache']['getNode'](),_0x5e05e1,_0x262dd2),_0x2215eb=Tt(_0x36b40c,_0x72684a,!0x0,_0x2ff52d['filter']['filtersNodes']());else{const _0x4a888d=y(_0x466f43);if(_0x4a888d==='.priority')_0x72684a=_0x2ff52d['filter']['updatePriority'](_0x36b40c['eventCache']['getNode'](),_0x5e05e1),_0x2215eb=Tt(_0x36b40c,_0x72684a,_0x4afc6c['isFullyInitialized'](),_0x4afc6c['isFiltered']());else{const _0x41b6d9=b(_0x466f43),_0x5592bf=_0x4afc6c['getNode']()['getImmediateChild'](_0x4a888d);let _0x2de79e;if(v(_0x41b6d9))_0x2de79e=_0x5e05e1;else{const _0x1b39e8=_0x226e0f['getCompleteChild'](_0x4a888d);_0x1b39e8!=null?zi(_0x41b6d9)==='.priority'&&_0x1b39e8['getChild'](Ro(_0x41b6d9))['isEmpty']()?_0x2de79e=_0x1b39e8:_0x2de79e=_0x1b39e8['updateChild'](_0x41b6d9,_0x5e05e1):_0x2de79e=g['EMPTY_NODE'];}if(_0x5592bf['equals'](_0x2de79e))_0x2215eb=_0x36b40c;else{const _0x53b80d=_0x2ff52d['filter']['updateChild'](_0x4afc6c['getNode'](),_0x4a888d,_0x2de79e,_0x41b6d9,_0x226e0f,_0x262dd2);_0x2215eb=Tt(_0x36b40c,_0x53b80d,_0x4afc6c['isFullyInitialized'](),_0x2ff52d['filter']['filtersNodes']());}}}return _0x2215eb;}function hr(_0x1912f0,_0x302ec7){return _0x1912f0['eventCache']['isCompleteForChild'](_0x302ec7);}function ku(_0xcab549,_0x168020,_0x36c2c2,_0x35c72d,_0x349d99,_0x5295f0,_0x2cb47f){let _0x2bc911=_0x168020;return _0x35c72d['foreach']((_0x44ad7d,_0x4f5425)=>{const _0x120180=k(_0x36c2c2,_0x44ad7d);hr(_0x168020,y(_0x120180))&&(_0x2bc911=Si(_0xcab549,_0x2bc911,_0x120180,_0x4f5425,_0x349d99,_0x5295f0,_0x2cb47f));}),_0x35c72d['foreach']((_0x52d6c6,_0x33ade4)=>{const _0x372204=k(_0x36c2c2,_0x52d6c6);hr(_0x168020,y(_0x372204))||(_0x2bc911=Si(_0xcab549,_0x2bc911,_0x372204,_0x33ade4,_0x349d99,_0x5295f0,_0x2cb47f));}),_0x2bc911;}function ur(_0x33e6d7,_0x462e28,_0x2e6e40){return _0x2e6e40['foreach']((_0x1c3f84,_0x5e68e4)=>{_0x462e28=_0x462e28['updateChild'](_0x1c3f84,_0x5e68e4);}),_0x462e28;}function bi(_0x345455,_0x483408,_0x55b7a4,_0x2fa7b1,_0x32546f,_0xe6798a,_0x3cbee,_0x485dfe){if(_0x483408['serverCache']['getNode']()['isEmpty']()&&!_0x483408['serverCache']['isFullyInitialized']())return _0x483408;let _0x5998a9=_0x483408,_0x40ceaa;v(_0x55b7a4)?_0x40ceaa=_0x2fa7b1:_0x40ceaa=new S(null)['setTree'](_0x55b7a4,_0x2fa7b1);const _0x280807=_0x483408['serverCache']['getNode']();return _0x40ceaa['children']['inorderTraversal']((_0x46aa5e,_0x5dedde)=>{if(_0x280807['hasChild'](_0x46aa5e)){const _0x3cf406=_0x483408['serverCache']['getNode']()['getImmediateChild'](_0x46aa5e),_0x3178b0=ur(_0x345455,_0x3cf406,_0x5dedde);_0x5998a9=En(_0x345455,_0x5998a9,new C(_0x46aa5e),_0x3178b0,_0x32546f,_0xe6798a,_0x3cbee,_0x485dfe);}}),_0x40ceaa['children']['inorderTraversal']((_0x55da09,_0x16fa7d)=>{const _0x57d1e7=!_0x483408['serverCache']['isCompleteForChild'](_0x55da09)&&_0x16fa7d['value']===null;if(!_0x280807['hasChild'](_0x55da09)&&!_0x57d1e7){const _0x2728f1=_0x483408['serverCache']['getNode']()['getImmediateChild'](_0x55da09),_0x2519d6=ur(_0x345455,_0x2728f1,_0x16fa7d);_0x5998a9=En(_0x345455,_0x5998a9,new C(_0x55da09),_0x2519d6,_0x32546f,_0xe6798a,_0x3cbee,_0x485dfe);}}),_0x5998a9;}function Nu(_0x102d77,_0x5125ad,_0x442efb,_0x451359,_0x3c022e,_0x1a4c21,_0x20a63e){if(vn(_0x3c022e,_0x442efb)!=null)return _0x5125ad;const _0x315d06=_0x5125ad['serverCache']['isFiltered'](),_0x487181=_0x5125ad['serverCache'];if(_0x451359['value']!=null){if(v(_0x442efb)&&_0x487181['isFullyInitialized']()||_0x487181['isCompleteForPath'](_0x442efb))return En(_0x102d77,_0x5125ad,_0x442efb,_0x487181['getNode']()['getChild'](_0x442efb),_0x3c022e,_0x1a4c21,_0x315d06,_0x20a63e);if(v(_0x442efb)){let _0x19f4d3=new S(null);return _0x487181['getNode']()['forEachChild'](ye,(_0x3f8275,_0x4c0276)=>{_0x19f4d3=_0x19f4d3['set'](new C(_0x3f8275),_0x4c0276);}),bi(_0x102d77,_0x5125ad,_0x442efb,_0x19f4d3,_0x3c022e,_0x1a4c21,_0x315d06,_0x20a63e);}else return _0x5125ad;}else{let _0x508f32=new S(null);return _0x451359['foreach']((_0x368f92,_0x15996b)=>{const _0x9b2945=k(_0x442efb,_0x368f92);_0x487181['isCompleteForPath'](_0x9b2945)&&(_0x508f32=_0x508f32['set'](_0x368f92,_0x487181['getNode']()['getChild'](_0x9b2945)));}),bi(_0x102d77,_0x5125ad,_0x442efb,_0x508f32,_0x3c022e,_0x1a4c21,_0x315d06,_0x20a63e);}}function Pu(_0x3e252e,_0xccfbd6,_0x14b560,_0x35a432,_0x3ee663){const _0x58045b=_0xccfbd6['serverCache'],_0x23702a=Uo(_0xccfbd6,_0x58045b['getNode'](),_0x58045b['isFullyInitialized']()||v(_0x14b560),_0x58045b['isFiltered']());return qo(_0x3e252e,_0x23702a,_0x14b560,_0x35a432,Go,_0x3ee663);}function Ou(_0x21ad28,_0x33c9d2,_0x3c033c,_0x4850e4,_0x499abe,_0x117b37){let _0x2e0dbb;if(vn(_0x4850e4,_0x3c033c)!=null)return _0x33c9d2;{const _0x5b2c7a=new ss(_0x4850e4,_0x33c9d2,_0x499abe),_0x5d2282=_0x33c9d2['eventCache']['getNode']();let _0x3c22f4;if(v(_0x3c033c)||y(_0x3c033c)==='.priority'){let _0x228c4a;if(_0x33c9d2['serverCache']['isFullyInitialized']())_0x228c4a=yn(_0x4850e4,We(_0x33c9d2));else{const _0x56f4d5=_0x33c9d2['serverCache']['getNode']();f(_0x56f4d5 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x228c4a=ns(_0x4850e4,_0x56f4d5);}_0x228c4a=_0x228c4a,_0x3c22f4=_0x21ad28['filter']['updateFullNode'](_0x5d2282,_0x228c4a,_0x117b37);}else{const _0x4bf66e=y(_0x3c033c);let _0xb1f778=is(_0x4850e4,_0x4bf66e,_0x33c9d2['serverCache']);_0xb1f778==null&&_0x33c9d2['serverCache']['isCompleteForChild'](_0x4bf66e)&&(_0xb1f778=_0x5d2282['getImmediateChild'](_0x4bf66e)),_0xb1f778!=null?_0x3c22f4=_0x21ad28['filter']['updateChild'](_0x5d2282,_0x4bf66e,_0xb1f778,b(_0x3c033c),_0x5b2c7a,_0x117b37):_0x33c9d2['eventCache']['getNode']()['hasChild'](_0x4bf66e)?_0x3c22f4=_0x21ad28['filter']['updateChild'](_0x5d2282,_0x4bf66e,g['EMPTY_NODE'],b(_0x3c033c),_0x5b2c7a,_0x117b37):_0x3c22f4=_0x5d2282,_0x3c22f4['isEmpty']()&&_0x33c9d2['serverCache']['isFullyInitialized']()&&(_0x2e0dbb=yn(_0x4850e4,We(_0x33c9d2)),_0x2e0dbb['isLeafNode']()&&(_0x3c22f4=_0x21ad28['filter']['updateFullNode'](_0x3c22f4,_0x2e0dbb,_0x117b37)));}return _0x2e0dbb=_0x33c9d2['serverCache']['isFullyInitialized']()||vn(_0x4850e4,w())!=null,Tt(_0x33c9d2,_0x3c22f4,_0x2e0dbb,_0x21ad28['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x11bf82,_0x42c0bf){this['query_']=_0x11bf82,this['eventRegistrations_']=[];const _0x43205c=this['query_']['_queryParams'],_0x79df2a=new Ji(_0x43205c['getIndex']()),_0x204bb0=Kh(_0x43205c);this['processor_']=Su(_0x204bb0);const _0x1bc9d0=_0x42c0bf['serverCache'],_0x3ec3a2=_0x42c0bf['eventCache'],_0x99c6c4=_0x79df2a['updateFullNode'](g['EMPTY_NODE'],_0x1bc9d0['getNode'](),null),_0x18dd89=_0x204bb0['updateFullNode'](g['EMPTY_NODE'],_0x3ec3a2['getNode'](),null),_0x52360c=new Ce(_0x99c6c4,_0x1bc9d0['isFullyInitialized'](),_0x79df2a['filtersNodes']()),_0x194636=new Ce(_0x18dd89,_0x3ec3a2['isFullyInitialized'](),_0x204bb0['filtersNodes']());this['viewCache_']=Mn(_0x194636,_0x52360c),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0xb55c67){return _0xb55c67['viewCache_']['serverCache']['getNode']();}function Lu(_0x190213){return mn(_0x190213['viewCache_']);}function xu(_0x4aaae4,_0x2ad269){const _0x2404dc=We(_0x4aaae4['viewCache_']);return _0x2404dc&&(_0x4aaae4['query']['_queryParams']['loadsAllData']()||!v(_0x2ad269)&&!_0x2404dc['getImmediateChild'](y(_0x2ad269))['isEmpty']())?_0x2404dc['getChild'](_0x2ad269):null;}function dr(_0x28b33c){return _0x28b33c['eventRegistrations_']['length']===0x0;}function Fu(_0x4b0df5,_0x5d49b1){_0x4b0df5['eventRegistrations_']['push'](_0x5d49b1);}function fr(_0x291b83,_0x128372,_0x59045f){const _0x4602c4=[];if(_0x59045f){f(_0x128372==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x965424=_0x291b83['query']['_path'];_0x291b83['eventRegistrations_']['forEach'](_0x277ccc=>{const _0x41376e=_0x277ccc['createCancelEvent'](_0x59045f,_0x965424);_0x41376e&&_0x4602c4['push'](_0x41376e);});}if(_0x128372){let _0x54eeaf=[];for(let _0x50b880=0x0;_0x50b880<_0x291b83['eventRegistrations_']['length'];++_0x50b880){const _0x59897f=_0x291b83['eventRegistrations_'][_0x50b880];if(!_0x59897f['matches'](_0x128372))_0x54eeaf['push'](_0x59897f);else{if(_0x128372['hasAnyCallback']()){_0x54eeaf=_0x54eeaf['concat'](_0x291b83['eventRegistrations_']['slice'](_0x50b880+0x1));break;}}}_0x291b83['eventRegistrations_']=_0x54eeaf;}else _0x291b83['eventRegistrations_']=[];return _0x4602c4;}function pr(_0x1505c0,_0x14e286,_0x3a274e,_0x2efd5a){_0x14e286['type']===j['MERGE']&&_0x14e286['source']['queryId']!==null&&(f(We(_0x1505c0['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(mn(_0x1505c0['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x1ce6d6=_0x1505c0['viewCache_'],_0x24674a=Ru(_0x1505c0['processor_'],_0x1ce6d6,_0x14e286,_0x3a274e,_0x2efd5a);return bu(_0x1505c0['processor_'],_0x24674a['viewCache']),f(_0x24674a['viewCache']['serverCache']['isFullyInitialized']()||!_0x1ce6d6['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x1505c0['viewCache_']=_0x24674a['viewCache'],zo(_0x1505c0,_0x24674a['changes'],_0x24674a['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x136684,_0x20b03c){const _0x528ae4=_0x136684['viewCache_']['eventCache'],_0x45e14d=[];return _0x528ae4['getNode']()['isLeafNode']()||_0x528ae4['getNode']()['forEachChild'](R,(_0x1a514c,_0x3fc724)=>{_0x45e14d['push'](et(_0x1a514c,_0x3fc724));}),_0x528ae4['isFullyInitialized']()&&_0x45e14d['push'](Lo(_0x528ae4['getNode']())),zo(_0x136684,_0x45e14d,_0x528ae4['getNode'](),_0x20b03c);}function zo(_0x356047,_0x37d5ed,_0x5c0526,_0x387816){const _0x397cea=_0x387816?[_0x387816]:_0x356047['eventRegistrations_'];return ru(_0x356047['eventGenerator_'],_0x37d5ed,_0x5c0526,_0x397cea);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;class jo{constructor(){this['views']=new Map();}}function Wu(_0x128bae){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x128bae;}function Bu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}function Vu(_0x37a64d){return _0x37a64d['views']['size']===0x0;}function rs(_0x2ecac4,_0x53cb05,_0x59910f,_0x516f70){const _0xe46ac6=_0x53cb05['source']['queryId'];if(_0xe46ac6!==null){const _0x43c00b=_0x2ecac4['views']['get'](_0xe46ac6);return f(_0x43c00b!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),pr(_0x43c00b,_0x53cb05,_0x59910f,_0x516f70);}else{let _0x20a2bf=[];for(const _0x38dca3 of _0x2ecac4['views']['values']())_0x20a2bf=_0x20a2bf['concat'](pr(_0x38dca3,_0x53cb05,_0x59910f,_0x516f70));return _0x20a2bf;}}function Ko(_0x54316c,_0x489090,_0x3fbcc8,_0x44e453,_0x256fb8){const _0x3fb7ac=_0x489090['_queryIdentifier'],_0x31e723=_0x54316c['views']['get'](_0x3fb7ac);if(!_0x31e723){let _0x5dfe70=yn(_0x3fbcc8,_0x256fb8?_0x44e453:null),_0x5b8660=!0x1;_0x5dfe70?_0x5b8660=!0x0:_0x44e453 instanceof g?(_0x5dfe70=ns(_0x3fbcc8,_0x44e453),_0x5b8660=!0x1):(_0x5dfe70=g['EMPTY_NODE'],_0x5b8660=!0x1);const _0x1625f0=Mn(new Ce(_0x5dfe70,_0x5b8660,!0x1),new Ce(_0x44e453,_0x256fb8,!0x1));return new Du(_0x489090,_0x1625f0);}return _0x31e723;}function Hu(_0x21934c,_0x2d1537,_0xc97ccd,_0x4bc6a2,_0x57469b,_0x2a25ac){const _0x30dcb6=Ko(_0x21934c,_0x2d1537,_0x4bc6a2,_0x57469b,_0x2a25ac);return _0x21934c['views']['has'](_0x2d1537['_queryIdentifier'])||_0x21934c['views']['set'](_0x2d1537['_queryIdentifier'],_0x30dcb6),Fu(_0x30dcb6,_0xc97ccd),Uu(_0x30dcb6,_0xc97ccd);}function $u(_0x4d72a7,_0x286bf5,_0x2df1eb,_0x2dd989){const _0x49de2b=_0x286bf5['_queryIdentifier'],_0x1e4fe6=[];let _0x540793=[];const _0x2ab3b9=Te(_0x4d72a7);if(_0x49de2b==='default'){for(const [_0x2680ab,_0x3ee6e6]of _0x4d72a7['views']['entries']())_0x540793=_0x540793['concat'](fr(_0x3ee6e6,_0x2df1eb,_0x2dd989)),dr(_0x3ee6e6)&&(_0x4d72a7['views']['delete'](_0x2680ab),_0x3ee6e6['query']['_queryParams']['loadsAllData']()||_0x1e4fe6['push'](_0x3ee6e6['query']));}else{const _0x1c3c74=_0x4d72a7['views']['get'](_0x49de2b);_0x1c3c74&&(_0x540793=_0x540793['concat'](fr(_0x1c3c74,_0x2df1eb,_0x2dd989)),dr(_0x1c3c74)&&(_0x4d72a7['views']['delete'](_0x49de2b),_0x1c3c74['query']['_queryParams']['loadsAllData']()||_0x1e4fe6['push'](_0x1c3c74['query'])));}return _0x2ab3b9&&!Te(_0x4d72a7)&&_0x1e4fe6['push'](new(Bu())(_0x286bf5['_repo'],_0x286bf5['_path'])),{'removed':_0x1e4fe6,'events':_0x540793};}function Yo(_0x13bcee){const _0x176c1d=[];for(const _0x7c3502 of _0x13bcee['views']['values']())_0x7c3502['query']['_queryParams']['loadsAllData']()||_0x176c1d['push'](_0x7c3502);return _0x176c1d;}function Ee(_0x5f1255,_0x1d4fc0){let _0x54b7a6=null;for(const _0x361f6a of _0x5f1255['views']['values']())_0x54b7a6=_0x54b7a6||xu(_0x361f6a,_0x1d4fc0);return _0x54b7a6;}function Qo(_0x37d04f,_0x52ffee){if(_0x52ffee['_queryParams']['loadsAllData']())return xn(_0x37d04f);{const _0x4c331f=_0x52ffee['_queryIdentifier'];return _0x37d04f['views']['get'](_0x4c331f);}}function Jo(_0x5d0a09,_0x384f71){return Qo(_0x5d0a09,_0x384f71)!=null;}function Te(_0x497414){return xn(_0x497414)!=null;}function xn(_0x28fc63){for(const _0x2ae468 of _0x28fc63['views']['values']())if(_0x2ae468['query']['_queryParams']['loadsAllData']())return _0x2ae468;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let wn;function Gu(_0xb82ac7){f(!wn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),wn=_0xb82ac7;}function qu(){return f(wn,'Reference.ts\x20has\x20not\x20been\x20loaded'),wn;}let zu=0x1;class _r{constructor(_0x3623ff){this['listenProvider_']=_0x3623ff,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function os(_0x4fdd15,_0x40b5b7,_0x4ec872,_0x35401c,_0x3fef98){return lu(_0x4fdd15['pendingWriteTree_'],_0x40b5b7,_0x4ec872,_0x35401c,_0x3fef98),_0x3fef98?ut(_0x4fdd15,new Ue(Zi(),_0x40b5b7,_0x4ec872)):[];}function ju(_0x6e5605,_0x106ce8,_0x2c40a5,_0x3ab55f){hu(_0x6e5605['pendingWriteTree_'],_0x106ce8,_0x2c40a5,_0x3ab55f);const _0x19a186=S['fromObject'](_0x2c40a5);return ut(_0x6e5605,new tt(Zi(),_0x106ce8,_0x19a186));}function pe(_0x4b5ce3,_0x11e120,_0x1cf616=!0x1){const _0x47adef=uu(_0x4b5ce3['pendingWriteTree_'],_0x11e120);if(du(_0x4b5ce3['pendingWriteTree_'],_0x11e120)){let _0x3917d1=new S(null);return _0x47adef['snap']!=null?_0x3917d1=_0x3917d1['set'](w(),!0x0):x(_0x47adef['children'],_0x140c70=>{_0x3917d1=_0x3917d1['set'](new C(_0x140c70),!0x0);}),ut(_0x4b5ce3,new gn(_0x47adef['path'],_0x3917d1,_0x1cf616));}else return[];}function Gt(_0x3c42e4,_0x872d47,_0x88b7){return ut(_0x3c42e4,new Ue(es(),_0x872d47,_0x88b7));}function Ku(_0x58f160,_0xd7ac05,_0x35f271){const _0x1835e8=S['fromObject'](_0x35f271);return ut(_0x58f160,new tt(es(),_0xd7ac05,_0x1835e8));}function Yu(_0x416ddf,_0x4b8e2f){return ut(_0x416ddf,new Lt(es(),_0x4b8e2f));}function Qu(_0xf663bb,_0xa59ac7,_0x10a498){const _0x329098=as(_0xf663bb,_0x10a498);if(_0x329098){const _0x3077d3=cs(_0x329098),_0x8eebdb=_0x3077d3['path'],_0x325ef2=_0x3077d3['queryId'],_0x3ead8d=F(_0x8eebdb,_0xa59ac7),_0xcf9ddf=new Lt(ts(_0x325ef2),_0x3ead8d);return ls(_0xf663bb,_0x8eebdb,_0xcf9ddf);}else return[];}function Cn(_0x5d177d,_0x278e2c,_0x363ab5,_0x13b29b,_0x5694b2=!0x1){const _0x49c18f=_0x278e2c['_path'],_0x19e015=_0x5d177d['syncPointTree_']['get'](_0x49c18f);let _0x3c0872=[];if(_0x19e015&&(_0x278e2c['_queryIdentifier']==='default'||Jo(_0x19e015,_0x278e2c))){const _0x12f700=$u(_0x19e015,_0x278e2c,_0x363ab5,_0x13b29b);Vu(_0x19e015)&&(_0x5d177d['syncPointTree_']=_0x5d177d['syncPointTree_']['remove'](_0x49c18f));const _0x4c24ee=_0x12f700['removed'];if(_0x3c0872=_0x12f700['events'],!_0x5694b2){const _0x547a5f=_0x4c24ee['findIndex'](_0x40eb24=>_0x40eb24['_queryParams']['loadsAllData']())!==-0x1,_0x100020=_0x5d177d['syncPointTree_']['findOnPath'](_0x49c18f,(_0x4292f0,_0x2bc061)=>Te(_0x2bc061));if(_0x547a5f&&!_0x100020){const _0x2cfab5=_0x5d177d['syncPointTree_']['subtree'](_0x49c18f);if(!_0x2cfab5['isEmpty']()){const _0x3f9b4d=Zu(_0x2cfab5);for(let _0x8f7b38=0x0;_0x8f7b38<_0x3f9b4d['length'];++_0x8f7b38){const _0x1721b7=_0x3f9b4d[_0x8f7b38],_0x51bf2f=_0x1721b7['query'],_0x9ce130=ta(_0x5d177d,_0x1721b7);_0x5d177d['listenProvider_']['startListening'](bt(_0x51bf2f),xt(_0x5d177d,_0x51bf2f),_0x9ce130['hashFn'],_0x9ce130['onComplete']);}}}!_0x100020&&_0x4c24ee['length']>0x0&&!_0x13b29b&&(_0x547a5f?_0x5d177d['listenProvider_']['stopListening'](bt(_0x278e2c),null):_0x4c24ee['forEach'](_0x4e78ed=>{const _0x54953c=_0x5d177d['queryToTagMap']['get'](Un(_0x4e78ed));_0x5d177d['listenProvider_']['stopListening'](bt(_0x4e78ed),_0x54953c);}));}ed(_0x5d177d,_0x4c24ee);}return _0x3c0872;}function Xo(_0x4933cb,_0x26eed6,_0x295592,_0x651e1d){const _0x51e30c=as(_0x4933cb,_0x651e1d);if(_0x51e30c!=null){const _0x2da499=cs(_0x51e30c),_0x120b19=_0x2da499['path'],_0x2ca469=_0x2da499['queryId'],_0x3b4bce=F(_0x120b19,_0x26eed6),_0x671b91=new Ue(ts(_0x2ca469),_0x3b4bce,_0x295592);return ls(_0x4933cb,_0x120b19,_0x671b91);}else return[];}function Ju(_0x40c4d4,_0x2bf8f7,_0x34d6e5,_0x26201e){const _0x587c18=as(_0x40c4d4,_0x26201e);if(_0x587c18){const _0x3e2e60=cs(_0x587c18),_0x1fad06=_0x3e2e60['path'],_0x15608c=_0x3e2e60['queryId'],_0x303e1c=F(_0x1fad06,_0x2bf8f7),_0xb98035=S['fromObject'](_0x34d6e5),_0x5fa0df=new tt(ts(_0x15608c),_0x303e1c,_0xb98035);return ls(_0x40c4d4,_0x1fad06,_0x5fa0df);}else return[];}function Ri(_0x142813,_0x2bd217,_0x54fc78,_0x4bee4e=!0x1){const _0x166199=_0x2bd217['_path'];let _0x27eefe=null,_0x1dc96a=!0x1;_0x142813['syncPointTree_']['foreachOnPath'](_0x166199,(_0x5377a0,_0xa8f750)=>{const _0x311162=F(_0x5377a0,_0x166199);_0x27eefe=_0x27eefe||Ee(_0xa8f750,_0x311162),_0x1dc96a=_0x1dc96a||Te(_0xa8f750);});let _0x355652=_0x142813['syncPointTree_']['get'](_0x166199);_0x355652?(_0x1dc96a=_0x1dc96a||Te(_0x355652),_0x27eefe=_0x27eefe||Ee(_0x355652,w())):(_0x355652=new jo(),_0x142813['syncPointTree_']=_0x142813['syncPointTree_']['set'](_0x166199,_0x355652));let _0x2f1349;_0x27eefe!=null?_0x2f1349=!0x0:(_0x2f1349=!0x1,_0x27eefe=g['EMPTY_NODE'],_0x142813['syncPointTree_']['subtree'](_0x166199)['foreachChild']((_0x44cc6d,_0x3f459e)=>{const _0x202905=Ee(_0x3f459e,w());_0x202905&&(_0x27eefe=_0x27eefe['updateImmediateChild'](_0x44cc6d,_0x202905));}));const _0x16fa59=Jo(_0x355652,_0x2bd217);if(!_0x16fa59&&!_0x2bd217['_queryParams']['loadsAllData']()){const _0x327d22=Un(_0x2bd217);f(!_0x142813['queryToTagMap']['has'](_0x327d22),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x4c57e6=td();_0x142813['queryToTagMap']['set'](_0x327d22,_0x4c57e6),_0x142813['tagToQueryMap']['set'](_0x4c57e6,_0x327d22);}const _0x4088e3=Ln(_0x142813['pendingWriteTree_'],_0x166199);let _0x5c435d=Hu(_0x355652,_0x2bd217,_0x54fc78,_0x4088e3,_0x27eefe,_0x2f1349);if(!_0x16fa59&&!_0x1dc96a&&!_0x4bee4e){const _0x181c69=Qo(_0x355652,_0x2bd217);_0x5c435d=_0x5c435d['concat'](nd(_0x142813,_0x2bd217,_0x181c69));}return _0x5c435d;}function Fn(_0x47097e,_0x289dda,_0x583025){const _0x556e07=_0x47097e['pendingWriteTree_'],_0x1a314e=_0x47097e['syncPointTree_']['findOnPath'](_0x289dda,(_0x42785f,_0x5e61bf)=>{const _0x58bf6d=F(_0x42785f,_0x289dda),_0x54522a=Ee(_0x5e61bf,_0x58bf6d);if(_0x54522a)return _0x54522a;});return Vo(_0x556e07,_0x289dda,_0x1a314e,_0x583025,!0x0);}function Xu(_0x20ccc0,_0x114f67){const _0x2f1c39=_0x114f67['_path'];let _0x39d27c=null;_0x20ccc0['syncPointTree_']['foreachOnPath'](_0x2f1c39,(_0x41d902,_0x18b2a0)=>{const _0x1645f6=F(_0x41d902,_0x2f1c39);_0x39d27c=_0x39d27c||Ee(_0x18b2a0,_0x1645f6);});let _0x6c091a=_0x20ccc0['syncPointTree_']['get'](_0x2f1c39);_0x6c091a?_0x39d27c=_0x39d27c||Ee(_0x6c091a,w()):(_0x6c091a=new jo(),_0x20ccc0['syncPointTree_']=_0x20ccc0['syncPointTree_']['set'](_0x2f1c39,_0x6c091a));const _0x4a2b3b=_0x39d27c!=null,_0xcd6652=_0x4a2b3b?new Ce(_0x39d27c,!0x0,!0x1):null,_0x3642cc=Ln(_0x20ccc0['pendingWriteTree_'],_0x114f67['_path']),_0x2527bd=Ko(_0x6c091a,_0x114f67,_0x3642cc,_0x4a2b3b?_0xcd6652['getNode']():g['EMPTY_NODE'],_0x4a2b3b);return Lu(_0x2527bd);}function ut(_0x10e90c,_0x3e7e6a){return Zo(_0x3e7e6a,_0x10e90c['syncPointTree_'],null,Ln(_0x10e90c['pendingWriteTree_'],w()));}function Zo(_0x5040f6,_0x2770f8,_0x1fcfce,_0x1a6962){if(v(_0x5040f6['path']))return ea(_0x5040f6,_0x2770f8,_0x1fcfce,_0x1a6962);{const _0x1a5520=_0x2770f8['get'](w());_0x1fcfce==null&&_0x1a5520!=null&&(_0x1fcfce=Ee(_0x1a5520,w()));let _0x10c21c=[];const _0x3824c4=y(_0x5040f6['path']),_0x13429a=_0x5040f6['operationForChild'](_0x3824c4),_0x5eeec5=_0x2770f8['children']['get'](_0x3824c4);if(_0x5eeec5&&_0x13429a){const _0x2876ec=_0x1fcfce?_0x1fcfce['getImmediateChild'](_0x3824c4):null,_0x453f3b=Ho(_0x1a6962,_0x3824c4);_0x10c21c=_0x10c21c['concat'](Zo(_0x13429a,_0x5eeec5,_0x2876ec,_0x453f3b));}return _0x1a5520&&(_0x10c21c=_0x10c21c['concat'](rs(_0x1a5520,_0x5040f6,_0x1a6962,_0x1fcfce))),_0x10c21c;}}function ea(_0xd364cc,_0x5cbf3a,_0x94bc1,_0xe83853){const _0x4698ab=_0x5cbf3a['get'](w());_0x94bc1==null&&_0x4698ab!=null&&(_0x94bc1=Ee(_0x4698ab,w()));let _0x21f9c7=[];return _0x5cbf3a['children']['inorderTraversal']((_0xdd604d,_0x2b34f3)=>{const _0x383d4c=_0x94bc1?_0x94bc1['getImmediateChild'](_0xdd604d):null,_0x2113e0=Ho(_0xe83853,_0xdd604d),_0x458e6d=_0xd364cc['operationForChild'](_0xdd604d);_0x458e6d&&(_0x21f9c7=_0x21f9c7['concat'](ea(_0x458e6d,_0x2b34f3,_0x383d4c,_0x2113e0)));}),_0x4698ab&&(_0x21f9c7=_0x21f9c7['concat'](rs(_0x4698ab,_0xd364cc,_0xe83853,_0x94bc1))),_0x21f9c7;}function ta(_0x410202,_0x5b8618){const _0x4d75d8=_0x5b8618['query'],_0x2d696f=xt(_0x410202,_0x4d75d8);return{'hashFn':()=>(Mu(_0x5b8618)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x3de330=>{if(_0x3de330==='ok')return _0x2d696f?Qu(_0x410202,_0x4d75d8['_path'],_0x2d696f):Yu(_0x410202,_0x4d75d8['_path']);{const _0x2df843=Kl(_0x3de330,_0x4d75d8);return Cn(_0x410202,_0x4d75d8,null,_0x2df843);}}};}function xt(_0x35f487,_0xd7eded){const _0x382498=Un(_0xd7eded);return _0x35f487['queryToTagMap']['get'](_0x382498);}function Un(_0x45a76f){return _0x45a76f['_path']['toString']()+'$'+_0x45a76f['_queryIdentifier'];}function as(_0x4ee3f4,_0xe487e5){return _0x4ee3f4['tagToQueryMap']['get'](_0xe487e5);}function cs(_0x5477c6){const _0x5e54e1=_0x5477c6['indexOf']('$');return f(_0x5e54e1!==-0x1&&_0x5e54e1<_0x5477c6['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x5477c6['substr'](_0x5e54e1+0x1),'path':new C(_0x5477c6['substr'](0x0,_0x5e54e1))};}function ls(_0xaebf27,_0x107358,_0x2cbf7b){const _0x4784c4=_0xaebf27['syncPointTree_']['get'](_0x107358);f(_0x4784c4,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x5cb053=Ln(_0xaebf27['pendingWriteTree_'],_0x107358);return rs(_0x4784c4,_0x2cbf7b,_0x5cb053,null);}function Zu(_0x301a22){return _0x301a22['fold']((_0x4e0cd8,_0x28cb9b,_0x4f1d73)=>{if(_0x28cb9b&&Te(_0x28cb9b))return[xn(_0x28cb9b)];{let _0x440e75=[];return _0x28cb9b&&(_0x440e75=Yo(_0x28cb9b)),x(_0x4f1d73,(_0x45389d,_0x24d0cb)=>{_0x440e75=_0x440e75['concat'](_0x24d0cb);}),_0x440e75;}});}function bt(_0x231ff2){return _0x231ff2['_queryParams']['loadsAllData']()&&!_0x231ff2['_queryParams']['isDefault']()?new(qu())(_0x231ff2['_repo'],_0x231ff2['_path']):_0x231ff2;}function ed(_0x236a1e,_0x4a7f09){for(let _0x589c08=0x0;_0x589c08<_0x4a7f09['length'];++_0x589c08){const _0x28bb89=_0x4a7f09[_0x589c08];if(!_0x28bb89['_queryParams']['loadsAllData']()){const _0x1e2a72=Un(_0x28bb89),_0x58b97d=_0x236a1e['queryToTagMap']['get'](_0x1e2a72);_0x236a1e['queryToTagMap']['delete'](_0x1e2a72),_0x236a1e['tagToQueryMap']['delete'](_0x58b97d);}}}function td(){return zu++;}function nd(_0x52bd41,_0x4a5a0c,_0x5742b9){const _0xe9ef99=_0x4a5a0c['_path'],_0x1c1585=xt(_0x52bd41,_0x4a5a0c),_0x59c2e7=ta(_0x52bd41,_0x5742b9),_0x5a6617=_0x52bd41['listenProvider_']['startListening'](bt(_0x4a5a0c),_0x1c1585,_0x59c2e7['hashFn'],_0x59c2e7['onComplete']),_0x236a94=_0x52bd41['syncPointTree_']['subtree'](_0xe9ef99);if(_0x1c1585)f(!Te(_0x236a94['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x10521f=_0x236a94['fold']((_0x5afd8f,_0x528138,_0x22a93c)=>{if(!v(_0x5afd8f)&&_0x528138&&Te(_0x528138))return[xn(_0x528138)['query']];{let _0x266f32=[];return _0x528138&&(_0x266f32=_0x266f32['concat'](Yo(_0x528138)['map'](_0x5eb90e=>_0x5eb90e['query']))),x(_0x22a93c,(_0x3ba3c4,_0x985878)=>{_0x266f32=_0x266f32['concat'](_0x985878);}),_0x266f32;}});for(let _0x5d623d=0x0;_0x5d623d<_0x10521f['length'];++_0x5d623d){const _0x2d23ed=_0x10521f[_0x5d623d];_0x52bd41['listenProvider_']['stopListening'](bt(_0x2d23ed),xt(_0x52bd41,_0x2d23ed));}}return _0x5a6617;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class hs{constructor(_0x4a7d00){this['node_']=_0x4a7d00;}['getImmediateChild'](_0x5ef5c7){const _0x480afa=this['node_']['getImmediateChild'](_0x5ef5c7);return new hs(_0x480afa);}['node'](){return this['node_'];}}class us{constructor(_0x44b5b9,_0x553a23){this['syncTree_']=_0x44b5b9,this['path_']=_0x553a23;}['getImmediateChild'](_0x54d89b){const _0x31be1d=k(this['path_'],_0x54d89b);return new us(this['syncTree_'],_0x31be1d);}['node'](){return Fn(this['syncTree_'],this['path_']);}}const id=function(_0x2364e6){return _0x2364e6=_0x2364e6||{},_0x2364e6['timestamp']=_0x2364e6['timestamp']||new Date()['getTime'](),_0x2364e6;},gr=function(_0x41dd3e,_0x528b42,_0x1b8ed4){if(!_0x41dd3e||typeof _0x41dd3e!='object')return _0x41dd3e;if(f('.sv'in _0x41dd3e,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x41dd3e['.sv']=='string')return sd(_0x41dd3e['.sv'],_0x528b42,_0x1b8ed4);if(typeof _0x41dd3e['.sv']=='object')return rd(_0x41dd3e['.sv'],_0x528b42);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x41dd3e,null,0x2));},sd=function(_0x1913d5,_0x464795,_0x54e1d4){switch(_0x1913d5){case'timestamp':return _0x54e1d4['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x1913d5);}},rd=function(_0x38464b,_0x552d3b,_0xef6de9){_0x38464b['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x38464b,null,0x2));const _0x4b0730=_0x38464b['increment'];typeof _0x4b0730!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x4b0730);const _0x12d7ab=_0x552d3b['node']();if(f(_0x12d7ab!==null&&typeof _0x12d7ab<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x12d7ab['isLeafNode']())return _0x4b0730;const _0x389d01=_0x12d7ab['getValue']();return typeof _0x389d01!='number'?_0x4b0730:_0x389d01+_0x4b0730;},na=function(_0x2757ba,_0x2928f5,_0x593f72,_0x5e4037){return fs(_0x2928f5,new us(_0x593f72,_0x2757ba),_0x5e4037);},ds=function(_0x1137ea,_0x5b4453,_0x1d4f80){return fs(_0x1137ea,new hs(_0x5b4453),_0x1d4f80);};function fs(_0x830408,_0x244f94,_0x2cef0b){const _0x2f7ddd=_0x830408['getPriority']()['val'](),_0x18acb0=gr(_0x2f7ddd,_0x244f94['getImmediateChild']('.priority'),_0x2cef0b);let _0x26d24e;if(_0x830408['isLeafNode']()){const _0x400813=_0x830408,_0x4cac22=gr(_0x400813['getValue'](),_0x244f94,_0x2cef0b);return _0x4cac22!==_0x400813['getValue']()||_0x18acb0!==_0x400813['getPriority']()['val']()?new D(_0x4cac22,P(_0x18acb0)):_0x830408;}else{const _0x546699=_0x830408;return _0x26d24e=_0x546699,_0x18acb0!==_0x546699['getPriority']()['val']()&&(_0x26d24e=_0x26d24e['updatePriority'](new D(_0x18acb0))),_0x546699['forEachChild'](R,(_0x46bb68,_0x346bcc)=>{const _0x5f0d6d=fs(_0x346bcc,_0x244f94['getImmediateChild'](_0x46bb68),_0x2cef0b);_0x5f0d6d!==_0x346bcc&&(_0x26d24e=_0x26d24e['updateImmediateChild'](_0x46bb68,_0x5f0d6d));}),_0x26d24e;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ps{constructor(_0x184791='',_0x26b3d7=null,_0xe464c9={'children':{},'childCount':0x0}){this['name']=_0x184791,this['parent']=_0x26b3d7,this['node']=_0xe464c9;}}function Wn(_0x3b2871,_0x31e201){let _0x134805=_0x31e201 instanceof C?_0x31e201:new C(_0x31e201),_0x52d5c4=_0x3b2871,_0x473c14=y(_0x134805);for(;_0x473c14!==null;){const _0x4e7186=De(_0x52d5c4['node']['children'],_0x473c14)||{'children':{},'childCount':0x0};_0x52d5c4=new ps(_0x473c14,_0x52d5c4,_0x4e7186),_0x134805=b(_0x134805),_0x473c14=y(_0x134805);}return _0x52d5c4;}function Ge(_0x1ccba0){return _0x1ccba0['node']['value'];}function _s(_0x22c0a2,_0xb1fa0f){_0x22c0a2['node']['value']=_0xb1fa0f,Ai(_0x22c0a2);}function ia(_0x12f44d){return _0x12f44d['node']['childCount']>0x0;}function od(_0xc73f8c){return Ge(_0xc73f8c)===void 0x0&&!ia(_0xc73f8c);}function Bn(_0x3dbee1,_0x3501e2){x(_0x3dbee1['node']['children'],(_0x395917,_0x2b9c58)=>{_0x3501e2(new ps(_0x395917,_0x3dbee1,_0x2b9c58));});}function sa(_0x21f09b,_0x46f17e,_0x44c198,_0x164418){_0x44c198&&_0x46f17e(_0x21f09b),Bn(_0x21f09b,_0x5465d5=>{sa(_0x5465d5,_0x46f17e,!0x0);});}function ad(_0x331373,_0x421ad1,_0x2633de){let _0x191d91=_0x331373['parent'];for(;_0x191d91!==null;){if(_0x421ad1(_0x191d91))return!0x0;_0x191d91=_0x191d91['parent'];}return!0x1;}function qt(_0xcd7924){return new C(_0xcd7924['parent']===null?_0xcd7924['name']:qt(_0xcd7924['parent'])+'/'+_0xcd7924['name']);}function Ai(_0x4b9301){_0x4b9301['parent']!==null&&cd(_0x4b9301['parent'],_0x4b9301['name'],_0x4b9301);}function cd(_0x66eb1b,_0x24be5b,_0x1214b1){const _0x4e5e4c=od(_0x1214b1),_0x4c8e5a=J(_0x66eb1b['node']['children'],_0x24be5b);_0x4e5e4c&&_0x4c8e5a?(delete _0x66eb1b['node']['children'][_0x24be5b],_0x66eb1b['node']['childCount']--,Ai(_0x66eb1b)):!_0x4e5e4c&&!_0x4c8e5a&&(_0x66eb1b['node']['children'][_0x24be5b]=_0x1214b1['node'],_0x66eb1b['node']['childCount']++,Ai(_0x66eb1b));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ai=0xa*0x400*0x400,gs=function(_0x5b5b01){return typeof _0x5b5b01=='string'&&_0x5b5b01['length']!==0x0&&!ld['test'](_0x5b5b01);},ra=function(_0x370d21){return typeof _0x370d21=='string'&&_0x370d21['length']!==0x0&&!hd['test'](_0x370d21);},ud=function(_0x4a9cbc){return _0x4a9cbc&&(_0x4a9cbc=_0x4a9cbc['replace'](/^\/*\.info(\/|$)/,'/')),ra(_0x4a9cbc);},Tn=function(_0x38c8f6){return _0x38c8f6===null||typeof _0x38c8f6=='string'||typeof _0x38c8f6=='number'&&!Vi(_0x38c8f6)||_0x38c8f6&&typeof _0x38c8f6=='object'&&J(_0x38c8f6,'.sv');},zt=function(_0x36cb61,_0x338ad9,_0x589c0c,_0x3ba9ff){_0x3ba9ff&&_0x338ad9===void 0x0||jt(Pn(_0x36cb61,'value'),_0x338ad9,_0x589c0c);},jt=function(_0x30dbd2,_0x2ac57e,_0x1fa4e2){const _0x594704=_0x1fa4e2 instanceof C?new Ah(_0x1fa4e2,_0x30dbd2):_0x1fa4e2;if(_0x2ac57e===void 0x0)throw new Error(_0x30dbd2+'contains\x20undefined\x20'+Pe(_0x594704));if(typeof _0x2ac57e=='function')throw new Error(_0x30dbd2+'contains\x20a\x20function\x20'+Pe(_0x594704)+'\x20with\x20contents\x20=\x20'+_0x2ac57e['toString']());if(Vi(_0x2ac57e))throw new Error(_0x30dbd2+'contains\x20'+_0x2ac57e['toString']()+'\x20'+Pe(_0x594704));if(typeof _0x2ac57e=='string'&&_0x2ac57e['length']>ai/0x3&&On(_0x2ac57e)>ai)throw new Error(_0x30dbd2+'contains\x20a\x20string\x20greater\x20than\x20'+ai+'\x20utf8\x20bytes\x20'+Pe(_0x594704)+'\x20(\x27'+_0x2ac57e['substring'](0x0,0x32)+'...\x27)');if(_0x2ac57e&&typeof _0x2ac57e=='object'){let _0xc35060=!0x1,_0x1893bd=!0x1;if(x(_0x2ac57e,(_0xaf596e,_0x53919b)=>{if(_0xaf596e==='.value')_0xc35060=!0x0;else{if(_0xaf596e!=='.priority'&&_0xaf596e!=='.sv'&&(_0x1893bd=!0x0,!gs(_0xaf596e)))throw new Error(_0x30dbd2+'\x20contains\x20an\x20invalid\x20key\x20('+_0xaf596e+')\x20'+Pe(_0x594704)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x594704,_0xaf596e),jt(_0x30dbd2,_0x53919b,_0x594704),Nh(_0x594704);}),_0xc35060&&_0x1893bd)throw new Error(_0x30dbd2+'\x20contains\x20\x22.value\x22\x20child\x20'+Pe(_0x594704)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x3259b4,_0xe2bad8){let _0x184f9e,_0x5b6f44;for(_0x184f9e=0x0;_0x184f9e<_0xe2bad8['length'];_0x184f9e++){_0x5b6f44=_0xe2bad8[_0x184f9e];const _0x255efb=Pt(_0x5b6f44);for(let _0x3cb5e5=0x0;_0x3cb5e5<_0x255efb['length'];_0x3cb5e5++)if(!(_0x255efb[_0x3cb5e5]==='.priority'&&_0x3cb5e5===_0x255efb['length']-0x1)){if(!gs(_0x255efb[_0x3cb5e5]))throw new Error(_0x3259b4+'contains\x20an\x20invalid\x20key\x20('+_0x255efb[_0x3cb5e5]+')\x20in\x20path\x20'+_0x5b6f44['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0xe2bad8['sort'](Rh);let _0x50c279=null;for(_0x184f9e=0x0;_0x184f9e<_0xe2bad8['length'];_0x184f9e++){if(_0x5b6f44=_0xe2bad8[_0x184f9e],_0x50c279!==null&&G(_0x50c279,_0x5b6f44))throw new Error(_0x3259b4+'contains\x20a\x20path\x20'+_0x50c279['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x5b6f44['toString']());_0x50c279=_0x5b6f44;}},fd=function(_0x800063,_0x90740b,_0x560d59,_0x5bbadb){const _0x3f0bff=Pn(_0x800063,'values');if(!(_0x90740b&&typeof _0x90740b=='object')||Array['isArray'](_0x90740b))throw new Error(_0x3f0bff+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x5e63d3=[];x(_0x90740b,(_0x592a8f,_0x22edfe)=>{const _0x3b70e3=new C(_0x592a8f);if(jt(_0x3f0bff,_0x22edfe,k(_0x560d59,_0x3b70e3)),zi(_0x3b70e3)==='.priority'&&!Tn(_0x22edfe))throw new Error(_0x3f0bff+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x3b70e3['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x5e63d3['push'](_0x3b70e3);}),dd(_0x3f0bff,_0x5e63d3);},ms=function(_0x216c48,_0x40949c,_0x5df740,_0x5147e5){if(!ra(_0x5df740))throw new Error(Pn(_0x216c48,_0x40949c)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x5df740+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x5d9218,_0x285c7a,_0x4f8876,_0xcc97f3){_0x4f8876&&(_0x4f8876=_0x4f8876['replace'](/^\/*\.info(\/|$)/,'/')),ms(_0x5d9218,_0x285c7a,_0x4f8876);},ys=function(_0x549f20,_0x5d17ac){if(y(_0x5d17ac)==='.info')throw new Error(_0x549f20+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x49ceed,_0xe2aa2d){const _0x35f12e=_0xe2aa2d['path']['toString']();if(typeof _0xe2aa2d['repoInfo']['host']!='string'||_0xe2aa2d['repoInfo']['host']['length']===0x0||!gs(_0xe2aa2d['repoInfo']['namespace'])&&_0xe2aa2d['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x35f12e['length']!==0x0&&!ud(_0x35f12e))throw new Error(Pn(_0x49ceed,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Vn(_0x50e122,_0x545037){let _0x14063a=null;for(let _0xd8c068=0x0;_0xd8c068<_0x545037['length'];_0xd8c068++){const _0x4b8f74=_0x545037[_0xd8c068],_0x120229=_0x4b8f74['getPath']();_0x14063a!==null&&!ji(_0x120229,_0x14063a['path'])&&(_0x50e122['eventLists_']['push'](_0x14063a),_0x14063a=null),_0x14063a===null&&(_0x14063a={'events':[],'path':_0x120229}),_0x14063a['events']['push'](_0x4b8f74);}_0x14063a&&_0x50e122['eventLists_']['push'](_0x14063a);}function oa(_0x5be359,_0x2358b6,_0x23e1f5){Vn(_0x5be359,_0x23e1f5),aa(_0x5be359,_0x24d0a9=>ji(_0x24d0a9,_0x2358b6));}function H(_0x734e87,_0x2a6151,_0xfefa93){Vn(_0x734e87,_0xfefa93),aa(_0x734e87,_0x13c5a3=>G(_0x13c5a3,_0x2a6151)||G(_0x2a6151,_0x13c5a3));}function aa(_0xa9f9f6,_0x2d71ea){_0xa9f9f6['recursionDepth_']++;let _0x5b510e=!0x0;for(let _0x52ea30=0x0;_0x52ea30<_0xa9f9f6['eventLists_']['length'];_0x52ea30++){const _0x80640a=_0xa9f9f6['eventLists_'][_0x52ea30];if(_0x80640a){const _0x1c7f5b=_0x80640a['path'];_0x2d71ea(_0x1c7f5b)?(md(_0xa9f9f6['eventLists_'][_0x52ea30]),_0xa9f9f6['eventLists_'][_0x52ea30]=null):_0x5b510e=!0x1;}}_0x5b510e&&(_0xa9f9f6['eventLists_']=[]),_0xa9f9f6['recursionDepth_']--;}function md(_0x287e5e){for(let _0x3618dc=0x0;_0x3618dc<_0x287e5e['events']['length'];_0x3618dc++){const _0x1aa1bc=_0x287e5e['events'][_0x3618dc];if(_0x1aa1bc!==null){_0x287e5e['events'][_0x3618dc]=null;const _0x2f89ce=_0x1aa1bc['getEventRunner']();wt&&L('event:\x20'+_0x1aa1bc['toString']()),ht(_0x2f89ce);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x1386d6,_0x5f5d5b,_0x45c6e2,_0x55d0b8){this['repoInfo_']=_0x1386d6,this['forceRestClient_']=_0x5f5d5b,this['authTokenProvider_']=_0x45c6e2,this['appCheckProvider_']=_0x55d0b8,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=_n(),this['transactionQueueTree_']=new ps(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x4e4e54,_0xeaca76,_0x5bd342){if(_0x4e4e54['stats_']=Gi(_0x4e4e54['repoInfo_']),_0x4e4e54['forceRestClient_']||Xl())_0x4e4e54['server_']=new pn(_0x4e4e54['repoInfo_'],(_0xad948,_0x83c376,_0xc024f6,_0x1879e9)=>{mr(_0x4e4e54,_0xad948,_0x83c376,_0xc024f6,_0x1879e9);},_0x4e4e54['authTokenProvider_'],_0x4e4e54['appCheckProvider_']),setTimeout(()=>yr(_0x4e4e54,!0x0),0x0);else{if(typeof _0x5bd342<'u'&&_0x5bd342!==null){if(typeof _0x5bd342!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x5bd342);}catch(_0x8b7afb){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x8b7afb);}}_0x4e4e54['persistentConnection_']=new se(_0x4e4e54['repoInfo_'],_0xeaca76,(_0x19dbb4,_0x2e6f09,_0x4eba1f,_0x294f14)=>{mr(_0x4e4e54,_0x19dbb4,_0x2e6f09,_0x4eba1f,_0x294f14);},_0x3cc128=>{yr(_0x4e4e54,_0x3cc128);},_0x5a9ce8=>{Id(_0x4e4e54,_0x5a9ce8);},_0x4e4e54['authTokenProvider_'],_0x4e4e54['appCheckProvider_'],_0x5bd342),_0x4e4e54['server_']=_0x4e4e54['persistentConnection_'];}_0x4e4e54['authTokenProvider_']['addTokenChangeListener'](_0x597d95=>{_0x4e4e54['server_']['refreshAuthToken'](_0x597d95);}),_0x4e4e54['appCheckProvider_']['addTokenChangeListener'](_0x3458e6=>{_0x4e4e54['server_']['refreshAppCheckToken'](_0x3458e6['token']);}),_0x4e4e54['statsReporter_']=ih(_0x4e4e54['repoInfo_'],()=>new iu(_0x4e4e54['stats_'],_0x4e4e54['server_'])),_0x4e4e54['infoData_']=new Xh(),_0x4e4e54['infoSyncTree_']=new _r({'startListening':(_0x52e9c6,_0x149e6d,_0x548847,_0x1942f1)=>{let _0x2b2c76=[];const _0xf08f0e=_0x4e4e54['infoData_']['getNode'](_0x52e9c6['_path']);return _0xf08f0e['isEmpty']()||(_0x2b2c76=Gt(_0x4e4e54['infoSyncTree_'],_0x52e9c6['_path'],_0xf08f0e),setTimeout(()=>{_0x1942f1('ok');},0x0)),_0x2b2c76;},'stopListening':()=>{}}),vs(_0x4e4e54,'connected',!0x1),_0x4e4e54['serverSyncTree_']=new _r({'startListening':(_0x357e9c,_0x3069c3,_0x457971,_0x4b7a20)=>(_0x4e4e54['server_']['listen'](_0x357e9c,_0x457971,_0x3069c3,(_0x2cf2b7,_0x451512)=>{const _0x36060d=_0x4b7a20(_0x2cf2b7,_0x451512);H(_0x4e4e54['eventQueue_'],_0x357e9c['_path'],_0x36060d);}),[]),'stopListening':(_0x1dbee1,_0x550d22)=>{_0x4e4e54['server_']['unlisten'](_0x1dbee1,_0x550d22);}});}function la(_0x377d95){const _0x54e8ac=_0x377d95['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x54e8ac;}function Kt(_0x24febb){return id({'timestamp':la(_0x24febb)});}function mr(_0x2fb26f,_0x20d941,_0x1a067a,_0xbb0b08,_0x161c47){_0x2fb26f['dataUpdateCount']++;const _0x325c1d=new C(_0x20d941);_0x1a067a=_0x2fb26f['interceptServerDataCallback_']?_0x2fb26f['interceptServerDataCallback_'](_0x20d941,_0x1a067a):_0x1a067a;let _0x250ede=[];if(_0x161c47){if(_0xbb0b08){const _0x430276=hn(_0x1a067a,_0x5f0a50=>P(_0x5f0a50));_0x250ede=Ju(_0x2fb26f['serverSyncTree_'],_0x325c1d,_0x430276,_0x161c47);}else{const _0x151bf6=P(_0x1a067a);_0x250ede=Xo(_0x2fb26f['serverSyncTree_'],_0x325c1d,_0x151bf6,_0x161c47);}}else{if(_0xbb0b08){const _0x32e231=hn(_0x1a067a,_0x1d955d=>P(_0x1d955d));_0x250ede=Ku(_0x2fb26f['serverSyncTree_'],_0x325c1d,_0x32e231);}else{const _0x5eb6b3=P(_0x1a067a);_0x250ede=Gt(_0x2fb26f['serverSyncTree_'],_0x325c1d,_0x5eb6b3);}}let _0xc0bb4e=_0x325c1d;_0x250ede['length']>0x0&&(_0xc0bb4e=it(_0x2fb26f,_0x325c1d)),H(_0x2fb26f['eventQueue_'],_0xc0bb4e,_0x250ede);}function yr(_0x4216a4,_0x5a01bf){vs(_0x4216a4,'connected',_0x5a01bf),_0x5a01bf===!0x1&&Sd(_0x4216a4);}function Id(_0x15f56a,_0x36163d){x(_0x36163d,(_0x54c6c3,_0x503c51)=>{vs(_0x15f56a,_0x54c6c3,_0x503c51);});}function vs(_0x50d625,_0x16543b,_0x1a75e7){const _0x153336=new C('/.info/'+_0x16543b),_0x4c1821=P(_0x1a75e7);_0x50d625['infoData_']['updateSnapshot'](_0x153336,_0x4c1821);const _0x38e996=Gt(_0x50d625['infoSyncTree_'],_0x153336,_0x4c1821);H(_0x50d625['eventQueue_'],_0x153336,_0x38e996);}function Hn(_0x182edd){return _0x182edd['nextWriteId_']++;}function wd(_0x1bcedb,_0xf41ea4,_0x389e5e){const _0x112b1c=Xu(_0x1bcedb['serverSyncTree_'],_0xf41ea4);return _0x112b1c!=null?Promise['resolve'](_0x112b1c):_0x1bcedb['server_']['get'](_0xf41ea4)['then'](_0x586405=>{const _0x59ccbe=P(_0x586405)['withIndex'](_0xf41ea4['_queryParams']['getIndex']());Ri(_0x1bcedb['serverSyncTree_'],_0xf41ea4,_0x389e5e,!0x0);let _0x2d8198;if(_0xf41ea4['_queryParams']['loadsAllData']())_0x2d8198=Gt(_0x1bcedb['serverSyncTree_'],_0xf41ea4['_path'],_0x59ccbe);else{const _0x1e1f29=xt(_0x1bcedb['serverSyncTree_'],_0xf41ea4);_0x2d8198=Xo(_0x1bcedb['serverSyncTree_'],_0xf41ea4['_path'],_0x59ccbe,_0x1e1f29);}return H(_0x1bcedb['eventQueue_'],_0xf41ea4['_path'],_0x2d8198),Cn(_0x1bcedb['serverSyncTree_'],_0xf41ea4,_0x389e5e,null,!0x0),_0x59ccbe;},_0x3e4616=>(dt(_0x1bcedb,'get\x20for\x20query\x20'+O(_0xf41ea4)+'\x20failed:\x20'+_0x3e4616),Promise['reject'](new Error(_0x3e4616))));}function Cd(_0x299d7e,_0x186fe4,_0x4bf0eb,_0x24940d,_0xb65c4f){dt(_0x299d7e,'set',{'path':_0x186fe4['toString'](),'value':_0x4bf0eb,'priority':_0x24940d});const _0x106075=Kt(_0x299d7e),_0x4cb72a=P(_0x4bf0eb,_0x24940d),_0xe4214b=Fn(_0x299d7e['serverSyncTree_'],_0x186fe4),_0x4960f0=ds(_0x4cb72a,_0xe4214b,_0x106075),_0x19cb72=Hn(_0x299d7e),_0x3fc220=os(_0x299d7e['serverSyncTree_'],_0x186fe4,_0x4960f0,_0x19cb72,!0x0);Vn(_0x299d7e['eventQueue_'],_0x3fc220),_0x299d7e['server_']['put'](_0x186fe4['toString'](),_0x4cb72a['val'](!0x0),(_0x96780f,_0x30cc8f)=>{const _0x4be0a8=_0x96780f==='ok';_0x4be0a8||U('set\x20at\x20'+_0x186fe4+'\x20failed:\x20'+_0x96780f);const _0x238fd7=pe(_0x299d7e['serverSyncTree_'],_0x19cb72,!_0x4be0a8);H(_0x299d7e['eventQueue_'],_0x186fe4,_0x238fd7),ki(_0x299d7e,_0xb65c4f,_0x96780f,_0x30cc8f);});const _0x4260fc=Is(_0x299d7e,_0x186fe4);it(_0x299d7e,_0x4260fc),H(_0x299d7e['eventQueue_'],_0x4260fc,[]);}function Td(_0x37fee9,_0x258f19,_0x17284b,_0x163f90){dt(_0x37fee9,'update',{'path':_0x258f19['toString'](),'value':_0x17284b});let _0x534159=!0x0;const _0x11c562=Kt(_0x37fee9),_0x340bb1={};if(x(_0x17284b,(_0x636aa8,_0x381546)=>{_0x534159=!0x1,_0x340bb1[_0x636aa8]=na(k(_0x258f19,_0x636aa8),P(_0x381546),_0x37fee9['serverSyncTree_'],_0x11c562);}),_0x534159)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),ki(_0x37fee9,_0x163f90,'ok',void 0x0);else{const _0x54d45c=Hn(_0x37fee9),_0x49f2d6=ju(_0x37fee9['serverSyncTree_'],_0x258f19,_0x340bb1,_0x54d45c);Vn(_0x37fee9['eventQueue_'],_0x49f2d6),_0x37fee9['server_']['merge'](_0x258f19['toString'](),_0x17284b,(_0x35d203,_0x292de5)=>{const _0x4c772f=_0x35d203==='ok';_0x4c772f||U('update\x20at\x20'+_0x258f19+'\x20failed:\x20'+_0x35d203);const _0x4ec1d5=pe(_0x37fee9['serverSyncTree_'],_0x54d45c,!_0x4c772f),_0x5d5cf3=_0x4ec1d5['length']>0x0?it(_0x37fee9,_0x258f19):_0x258f19;H(_0x37fee9['eventQueue_'],_0x5d5cf3,_0x4ec1d5),ki(_0x37fee9,_0x163f90,_0x35d203,_0x292de5);}),x(_0x17284b,_0x5bcf9b=>{const _0x4ec91a=Is(_0x37fee9,k(_0x258f19,_0x5bcf9b));it(_0x37fee9,_0x4ec91a);}),H(_0x37fee9['eventQueue_'],_0x258f19,[]);}}function Sd(_0x359c29){dt(_0x359c29,'onDisconnectEvents');const _0x1aefac=Kt(_0x359c29),_0x586a9b=_n();Ii(_0x359c29['onDisconnect_'],w(),(_0x5de4e0,_0x34653f)=>{const _0x5a9faa=na(_0x5de4e0,_0x34653f,_0x359c29['serverSyncTree_'],_0x1aefac);Fo(_0x586a9b,_0x5de4e0,_0x5a9faa);});let _0x1f41aa=[];Ii(_0x586a9b,w(),(_0x34effd,_0x27d2d3)=>{_0x1f41aa=_0x1f41aa['concat'](Gt(_0x359c29['serverSyncTree_'],_0x34effd,_0x27d2d3));const _0x15c3ed=Is(_0x359c29,_0x34effd);it(_0x359c29,_0x15c3ed);}),_0x359c29['onDisconnect_']=_n(),H(_0x359c29['eventQueue_'],w(),_0x1f41aa);}function bd(_0x24a8a4,_0x2138f4,_0x25e3bf){let _0x7ac9cb;y(_0x2138f4['_path'])==='.info'?_0x7ac9cb=Ri(_0x24a8a4['infoSyncTree_'],_0x2138f4,_0x25e3bf):_0x7ac9cb=Ri(_0x24a8a4['serverSyncTree_'],_0x2138f4,_0x25e3bf),oa(_0x24a8a4['eventQueue_'],_0x2138f4['_path'],_0x7ac9cb);}function Rd(_0x641906,_0x4b05e7,_0x2467e3){let _0x395587;y(_0x4b05e7['_path'])==='.info'?_0x395587=Cn(_0x641906['infoSyncTree_'],_0x4b05e7,_0x2467e3):_0x395587=Cn(_0x641906['serverSyncTree_'],_0x4b05e7,_0x2467e3),oa(_0x641906['eventQueue_'],_0x4b05e7['_path'],_0x395587);}function ha(_0x31c7df){_0x31c7df['persistentConnection_']&&_0x31c7df['persistentConnection_']['interrupt'](ca);}function Ad(_0x3bd920){_0x3bd920['persistentConnection_']&&_0x3bd920['persistentConnection_']['resume'](ca);}function dt(_0x1760e4,..._0x183765){let _0x18a97a='';_0x1760e4['persistentConnection_']&&(_0x18a97a=_0x1760e4['persistentConnection_']['id']+':'),L(_0x18a97a,..._0x183765);}function ki(_0xe0de19,_0x49c485,_0x1c964f,_0x37ac75){_0x49c485&&ht(()=>{if(_0x1c964f==='ok')_0x49c485(null);else{const _0x186926=(_0x1c964f||'error')['toUpperCase']();let _0x3aab8b=_0x186926;_0x37ac75&&(_0x3aab8b+=':\x20'+_0x37ac75);const _0x47bd8e=new Error(_0x3aab8b);_0x47bd8e['code']=_0x186926,_0x49c485(_0x47bd8e);}});}function kd(_0x3a9d4e,_0x18d9c8,_0x5d95eb,_0x1ffc4b,_0x3bf4e7,_0x290e88){dt(_0x3a9d4e,'transaction\x20on\x20'+_0x18d9c8);const _0x24b892={'path':_0x18d9c8,'update':_0x5d95eb,'onComplete':_0x1ffc4b,'status':null,'order':so(),'applyLocally':_0x290e88,'retryCount':0x0,'unwatcher':_0x3bf4e7,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x9c5984=Es(_0x3a9d4e,_0x18d9c8,void 0x0);_0x24b892['currentInputSnapshot']=_0x9c5984;const _0x306162=_0x24b892['update'](_0x9c5984['val']());if(_0x306162===void 0x0)_0x24b892['unwatcher'](),_0x24b892['currentOutputSnapshotRaw']=null,_0x24b892['currentOutputSnapshotResolved']=null,_0x24b892['onComplete']&&_0x24b892['onComplete'](null,!0x1,_0x24b892['currentInputSnapshot']);else{jt('transaction\x20failed:\x20Data\x20returned\x20',_0x306162,_0x24b892['path']),_0x24b892['status']=0x0;const _0x1fdba0=Wn(_0x3a9d4e['transactionQueueTree_'],_0x18d9c8),_0x244e88=Ge(_0x1fdba0)||[];_0x244e88['push'](_0x24b892),_s(_0x1fdba0,_0x244e88);let _0x8f8ba4;typeof _0x306162=='object'&&_0x306162!==null&&J(_0x306162,'.priority')?(_0x8f8ba4=De(_0x306162,'.priority'),f(Tn(_0x8f8ba4),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x8f8ba4=(Fn(_0x3a9d4e['serverSyncTree_'],_0x18d9c8)||g['EMPTY_NODE'])['getPriority']()['val']();const _0xd1792e=Kt(_0x3a9d4e),_0x29fa1f=P(_0x306162,_0x8f8ba4),_0x447f47=ds(_0x29fa1f,_0x9c5984,_0xd1792e);_0x24b892['currentOutputSnapshotRaw']=_0x29fa1f,_0x24b892['currentOutputSnapshotResolved']=_0x447f47,_0x24b892['currentWriteId']=Hn(_0x3a9d4e);const _0x59253a=os(_0x3a9d4e['serverSyncTree_'],_0x18d9c8,_0x447f47,_0x24b892['currentWriteId'],_0x24b892['applyLocally']);H(_0x3a9d4e['eventQueue_'],_0x18d9c8,_0x59253a),$n(_0x3a9d4e,_0x3a9d4e['transactionQueueTree_']);}}function Es(_0x158e5b,_0x1f29d1,_0x262d83){return Fn(_0x158e5b['serverSyncTree_'],_0x1f29d1,_0x262d83)||g['EMPTY_NODE'];}function $n(_0x2306fb,_0x4b1da2=_0x2306fb['transactionQueueTree_']){if(_0x4b1da2||Gn(_0x2306fb,_0x4b1da2),Ge(_0x4b1da2)){const _0x517e84=da(_0x2306fb,_0x4b1da2);f(_0x517e84['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x517e84['every'](_0x41aa2c=>_0x41aa2c['status']===0x0)&&Nd(_0x2306fb,qt(_0x4b1da2),_0x517e84);}else ia(_0x4b1da2)&&Bn(_0x4b1da2,_0x22b28d=>{$n(_0x2306fb,_0x22b28d);});}function Nd(_0x34d28b,_0x3f633c,_0x1d7199){const _0x3fcd92=_0x1d7199['map'](_0x5cf748=>_0x5cf748['currentWriteId']),_0x10ce88=Es(_0x34d28b,_0x3f633c,_0x3fcd92);let _0x2bf67b=_0x10ce88;const _0x4739e2=_0x10ce88['hash']();for(let _0x427533=0x0;_0x427533<_0x1d7199['length'];_0x427533++){const _0x5df774=_0x1d7199[_0x427533];f(_0x5df774['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x5df774['status']=0x1,_0x5df774['retryCount']++;const _0x4b5a0e=F(_0x3f633c,_0x5df774['path']);_0x2bf67b=_0x2bf67b['updateChild'](_0x4b5a0e,_0x5df774['currentOutputSnapshotRaw']);}const _0x5b82f0=_0x2bf67b['val'](!0x0),_0x4dffd7=_0x3f633c;_0x34d28b['server_']['put'](_0x4dffd7['toString'](),_0x5b82f0,_0x2fadb7=>{dt(_0x34d28b,'transaction\x20put\x20response',{'path':_0x4dffd7['toString'](),'status':_0x2fadb7});let _0x534792=[];if(_0x2fadb7==='ok'){const _0x505643=[];for(let _0x551651=0x0;_0x551651<_0x1d7199['length'];_0x551651++)_0x1d7199[_0x551651]['status']=0x2,_0x534792=_0x534792['concat'](pe(_0x34d28b['serverSyncTree_'],_0x1d7199[_0x551651]['currentWriteId'])),_0x1d7199[_0x551651]['onComplete']&&_0x505643['push'](()=>_0x1d7199[_0x551651]['onComplete'](null,!0x0,_0x1d7199[_0x551651]['currentOutputSnapshotResolved'])),_0x1d7199[_0x551651]['unwatcher']();Gn(_0x34d28b,Wn(_0x34d28b['transactionQueueTree_'],_0x3f633c)),$n(_0x34d28b,_0x34d28b['transactionQueueTree_']),H(_0x34d28b['eventQueue_'],_0x3f633c,_0x534792);for(let _0x2c7be8=0x0;_0x2c7be8<_0x505643['length'];_0x2c7be8++)ht(_0x505643[_0x2c7be8]);}else{if(_0x2fadb7==='datastale'){for(let _0x5a8db1=0x0;_0x5a8db1<_0x1d7199['length'];_0x5a8db1++)_0x1d7199[_0x5a8db1]['status']===0x3?_0x1d7199[_0x5a8db1]['status']=0x4:_0x1d7199[_0x5a8db1]['status']=0x0;}else{U('transaction\x20at\x20'+_0x4dffd7['toString']()+'\x20failed:\x20'+_0x2fadb7);for(let _0x580d8e=0x0;_0x580d8e<_0x1d7199['length'];_0x580d8e++)_0x1d7199[_0x580d8e]['status']=0x4,_0x1d7199[_0x580d8e]['abortReason']=_0x2fadb7;}it(_0x34d28b,_0x3f633c);}},_0x4739e2);}function it(_0x1ebc36,_0x2281e5){const _0x579df6=ua(_0x1ebc36,_0x2281e5),_0x36b7d6=qt(_0x579df6),_0xa2149a=da(_0x1ebc36,_0x579df6);return Pd(_0x1ebc36,_0xa2149a,_0x36b7d6),_0x36b7d6;}function Pd(_0x3c57ef,_0x4afa9f,_0x320ab9){if(_0x4afa9f['length']===0x0)return;const _0x232319=[];let _0x2eca3b=[];const _0x3ba799=_0x4afa9f['filter'](_0x104967=>_0x104967['status']===0x0)['map'](_0x50b4d=>_0x50b4d['currentWriteId']);for(let _0x4bea14=0x0;_0x4bea14<_0x4afa9f['length'];_0x4bea14++){const _0x4a9c74=_0x4afa9f[_0x4bea14],_0x8cc4b9=F(_0x320ab9,_0x4a9c74['path']);let _0x3dd0db=!0x1,_0x2fecff;if(f(_0x8cc4b9!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x4a9c74['status']===0x4)_0x3dd0db=!0x0,_0x2fecff=_0x4a9c74['abortReason'],_0x2eca3b=_0x2eca3b['concat'](pe(_0x3c57ef['serverSyncTree_'],_0x4a9c74['currentWriteId'],!0x0));else{if(_0x4a9c74['status']===0x0){if(_0x4a9c74['retryCount']>=yd)_0x3dd0db=!0x0,_0x2fecff='maxretry',_0x2eca3b=_0x2eca3b['concat'](pe(_0x3c57ef['serverSyncTree_'],_0x4a9c74['currentWriteId'],!0x0));else{const _0x5c555a=Es(_0x3c57ef,_0x4a9c74['path'],_0x3ba799);_0x4a9c74['currentInputSnapshot']=_0x5c555a;const _0x17a469=_0x4afa9f[_0x4bea14]['update'](_0x5c555a['val']());if(_0x17a469!==void 0x0){jt('transaction\x20failed:\x20Data\x20returned\x20',_0x17a469,_0x4a9c74['path']);let _0x23ff4e=P(_0x17a469);typeof _0x17a469=='object'&&_0x17a469!=null&&J(_0x17a469,'.priority')||(_0x23ff4e=_0x23ff4e['updatePriority'](_0x5c555a['getPriority']()));const _0x36420a=_0x4a9c74['currentWriteId'],_0x4165b8=Kt(_0x3c57ef),_0x42d340=ds(_0x23ff4e,_0x5c555a,_0x4165b8);_0x4a9c74['currentOutputSnapshotRaw']=_0x23ff4e,_0x4a9c74['currentOutputSnapshotResolved']=_0x42d340,_0x4a9c74['currentWriteId']=Hn(_0x3c57ef),_0x3ba799['splice'](_0x3ba799['indexOf'](_0x36420a),0x1),_0x2eca3b=_0x2eca3b['concat'](os(_0x3c57ef['serverSyncTree_'],_0x4a9c74['path'],_0x42d340,_0x4a9c74['currentWriteId'],_0x4a9c74['applyLocally'])),_0x2eca3b=_0x2eca3b['concat'](pe(_0x3c57ef['serverSyncTree_'],_0x36420a,!0x0));}else _0x3dd0db=!0x0,_0x2fecff='nodata',_0x2eca3b=_0x2eca3b['concat'](pe(_0x3c57ef['serverSyncTree_'],_0x4a9c74['currentWriteId'],!0x0));}}}H(_0x3c57ef['eventQueue_'],_0x320ab9,_0x2eca3b),_0x2eca3b=[],_0x3dd0db&&(_0x4afa9f[_0x4bea14]['status']=0x2,function(_0x57b532){setTimeout(_0x57b532,Math['floor'](0x0));}(_0x4afa9f[_0x4bea14]['unwatcher']),_0x4afa9f[_0x4bea14]['onComplete']&&(_0x2fecff==='nodata'?_0x232319['push'](()=>_0x4afa9f[_0x4bea14]['onComplete'](null,!0x1,_0x4afa9f[_0x4bea14]['currentInputSnapshot'])):_0x232319['push'](()=>_0x4afa9f[_0x4bea14]['onComplete'](new Error(_0x2fecff),!0x1,null))));}Gn(_0x3c57ef,_0x3c57ef['transactionQueueTree_']);for(let _0x41c8f2=0x0;_0x41c8f2<_0x232319['length'];_0x41c8f2++)ht(_0x232319[_0x41c8f2]);$n(_0x3c57ef,_0x3c57ef['transactionQueueTree_']);}function ua(_0x3d2077,_0x1bf763){let _0x4eca60,_0xf8679=_0x3d2077['transactionQueueTree_'];for(_0x4eca60=y(_0x1bf763);_0x4eca60!==null&&Ge(_0xf8679)===void 0x0;)_0xf8679=Wn(_0xf8679,_0x4eca60),_0x1bf763=b(_0x1bf763),_0x4eca60=y(_0x1bf763);return _0xf8679;}function da(_0x50efdb,_0x3edc58){const _0x3ce2ae=[];return fa(_0x50efdb,_0x3edc58,_0x3ce2ae),_0x3ce2ae['sort']((_0xb9659a,_0x426e59)=>_0xb9659a['order']-_0x426e59['order']),_0x3ce2ae;}function fa(_0xcda6cf,_0x142266,_0x49a971){const _0x2bfe15=Ge(_0x142266);if(_0x2bfe15){for(let _0x381b5d=0x0;_0x381b5d<_0x2bfe15['length'];_0x381b5d++)_0x49a971['push'](_0x2bfe15[_0x381b5d]);}Bn(_0x142266,_0x5463a0=>{fa(_0xcda6cf,_0x5463a0,_0x49a971);});}function Gn(_0x2ce107,_0x426a65){const _0x2ac5f9=Ge(_0x426a65);if(_0x2ac5f9){let _0x3580d9=0x0;for(let _0x3bf7bc=0x0;_0x3bf7bc<_0x2ac5f9['length'];_0x3bf7bc++)_0x2ac5f9[_0x3bf7bc]['status']!==0x2&&(_0x2ac5f9[_0x3580d9]=_0x2ac5f9[_0x3bf7bc],_0x3580d9++);_0x2ac5f9['length']=_0x3580d9,_s(_0x426a65,_0x2ac5f9['length']>0x0?_0x2ac5f9:void 0x0);}Bn(_0x426a65,_0x319ba9=>{Gn(_0x2ce107,_0x319ba9);});}function Is(_0x176337,_0x55fcc9){const _0x1c3a50=qt(ua(_0x176337,_0x55fcc9)),_0x5c9d44=Wn(_0x176337['transactionQueueTree_'],_0x55fcc9);return ad(_0x5c9d44,_0x2df0e8=>{ci(_0x176337,_0x2df0e8);}),ci(_0x176337,_0x5c9d44),sa(_0x5c9d44,_0x14b647=>{ci(_0x176337,_0x14b647);}),_0x1c3a50;}function ci(_0x2452ee,_0x11e699){const _0x38e10f=Ge(_0x11e699);if(_0x38e10f){const _0x4faca6=[];let _0x3392c5=[],_0x572fa9=-0x1;for(let _0xd5d71f=0x0;_0xd5d71f<_0x38e10f['length'];_0xd5d71f++)_0x38e10f[_0xd5d71f]['status']===0x3||(_0x38e10f[_0xd5d71f]['status']===0x1?(f(_0x572fa9===_0xd5d71f-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x572fa9=_0xd5d71f,_0x38e10f[_0xd5d71f]['status']=0x3,_0x38e10f[_0xd5d71f]['abortReason']='set'):(f(_0x38e10f[_0xd5d71f]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x38e10f[_0xd5d71f]['unwatcher'](),_0x3392c5=_0x3392c5['concat'](pe(_0x2452ee['serverSyncTree_'],_0x38e10f[_0xd5d71f]['currentWriteId'],!0x0)),_0x38e10f[_0xd5d71f]['onComplete']&&_0x4faca6['push'](_0x38e10f[_0xd5d71f]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x572fa9===-0x1?_s(_0x11e699,void 0x0):_0x38e10f['length']=_0x572fa9+0x1,H(_0x2452ee['eventQueue_'],qt(_0x11e699),_0x3392c5);for(let _0x2079fd=0x0;_0x2079fd<_0x4faca6['length'];_0x2079fd++)ht(_0x4faca6[_0x2079fd]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Od(_0x30151b){let _0x5282ac='';const _0x34a1d7=_0x30151b['split']('/');for(let _0xc3cf27=0x0;_0xc3cf27<_0x34a1d7['length'];_0xc3cf27++)if(_0x34a1d7[_0xc3cf27]['length']>0x0){let _0x1a39c1=_0x34a1d7[_0xc3cf27];try{_0x1a39c1=decodeURIComponent(_0x1a39c1['replace'](/\+/g,'\x20'));}catch{}_0x5282ac+='/'+_0x1a39c1;}return _0x5282ac;}function Dd(_0xba5a74){const _0x499e09={};_0xba5a74['charAt'](0x0)==='?'&&(_0xba5a74=_0xba5a74['substring'](0x1));for(const _0x1ee0af of _0xba5a74['split']('&')){if(_0x1ee0af['length']===0x0)continue;const _0x15c2ad=_0x1ee0af['split']('=');_0x15c2ad['length']===0x2?_0x499e09[decodeURIComponent(_0x15c2ad[0x0])]=decodeURIComponent(_0x15c2ad[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x1ee0af+'\x27\x20in\x20query\x20\x27'+_0xba5a74+'\x27');}return _0x499e09;}const vr=function(_0x1ef756,_0x30e34d){const _0x38a74c=Md(_0x1ef756),_0x41cb6c=_0x38a74c['namespace'];_0x38a74c['domain']==='firebase.com'&&ae(_0x38a74c['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x41cb6c||_0x41cb6c==='undefined')&&_0x38a74c['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x38a74c['secure']||$l();const _0x434b8a=_0x38a74c['scheme']==='ws'||_0x38a74c['scheme']==='wss';return{'repoInfo':new yo(_0x38a74c['host'],_0x38a74c['secure'],_0x41cb6c,_0x434b8a,_0x30e34d,'',_0x41cb6c!==_0x38a74c['subdomain']),'path':new C(_0x38a74c['pathString'])};},Md=function(_0x459342){let _0x1a3700='',_0x1d4cff='',_0x223c0b='',_0x5b75ca='',_0x4f3ba6='',_0x24b929=!0x0,_0x537a8d='https',_0x28d627=0x1bb;if(typeof _0x459342=='string'){let _0x2cf806=_0x459342['indexOf']('//');_0x2cf806>=0x0&&(_0x537a8d=_0x459342['substring'](0x0,_0x2cf806-0x1),_0x459342=_0x459342['substring'](_0x2cf806+0x2));let _0x132753=_0x459342['indexOf']('/');_0x132753===-0x1&&(_0x132753=_0x459342['length']);let _0x59aba7=_0x459342['indexOf']('?');_0x59aba7===-0x1&&(_0x59aba7=_0x459342['length']),_0x1a3700=_0x459342['substring'](0x0,Math['min'](_0x132753,_0x59aba7)),_0x132753<_0x59aba7&&(_0x5b75ca=Od(_0x459342['substring'](_0x132753,_0x59aba7)));const _0x5269fa=Dd(_0x459342['substring'](Math['min'](_0x459342['length'],_0x59aba7)));_0x2cf806=_0x1a3700['indexOf'](':'),_0x2cf806>=0x0?(_0x24b929=_0x537a8d==='https'||_0x537a8d==='wss',_0x28d627=parseInt(_0x1a3700['substring'](_0x2cf806+0x1),0xa)):_0x2cf806=_0x1a3700['length'];const _0x384a22=_0x1a3700['slice'](0x0,_0x2cf806);if(_0x384a22['toLowerCase']()==='localhost')_0x1d4cff='localhost';else{if(_0x384a22['split']('.')['length']<=0x2)_0x1d4cff=_0x384a22;else{const _0x1d714f=_0x1a3700['indexOf']('.');_0x223c0b=_0x1a3700['substring'](0x0,_0x1d714f)['toLowerCase'](),_0x1d4cff=_0x1a3700['substring'](_0x1d714f+0x1),_0x4f3ba6=_0x223c0b;}}'ns'in _0x5269fa&&(_0x4f3ba6=_0x5269fa['ns']);}return{'host':_0x1a3700,'port':_0x28d627,'domain':_0x1d4cff,'subdomain':_0x223c0b,'secure':_0x24b929,'scheme':_0x537a8d,'pathString':_0x5b75ca,'namespace':_0x4f3ba6};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ld=(function(){let _0x35c542=0x0;const _0x5707da=[];return function(_0x16aa98){const _0x1dbe16=_0x16aa98===_0x35c542;_0x35c542=_0x16aa98;let _0x260094;const _0x24f8ef=new Array(0x8);for(_0x260094=0x7;_0x260094>=0x0;_0x260094--)_0x24f8ef[_0x260094]=Er['charAt'](_0x16aa98%0x40),_0x16aa98=Math['floor'](_0x16aa98/0x40);f(_0x16aa98===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x27268a=_0x24f8ef['join']('');if(_0x1dbe16){for(_0x260094=0xb;_0x260094>=0x0&&_0x5707da[_0x260094]===0x3f;_0x260094--)_0x5707da[_0x260094]=0x0;_0x5707da[_0x260094]++;}else{for(_0x260094=0x0;_0x260094<0xc;_0x260094++)_0x5707da[_0x260094]=Math['floor'](Math['random']()*0x40);}for(_0x260094=0x0;_0x260094<0xc;_0x260094++)_0x27268a+=Er['charAt'](_0x5707da[_0x260094]);return f(_0x27268a['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x27268a;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xd{constructor(_0x3b98b8,_0x1d504f,_0x583ebc,_0x5b6dfd){this['eventType']=_0x3b98b8,this['eventRegistration']=_0x1d504f,this['snapshot']=_0x583ebc,this['prevName']=_0x5b6dfd;}['getPath'](){const _0x2ef729=this['snapshot']['ref'];return this['eventType']==='value'?_0x2ef729['_path']:_0x2ef729['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Fd{constructor(_0x558dd8,_0x3a3428,_0xf79cb5){this['eventRegistration']=_0x558dd8,this['error']=_0x3a3428,this['path']=_0xf79cb5;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x49154b,_0x15e050){this['snapshotCallback']=_0x49154b,this['cancelCallback']=_0x15e050;}['onValue'](_0x314b1b,_0x207b44){this['snapshotCallback']['call'](null,_0x314b1b,_0x207b44);}['onCancel'](_0x2e009e){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x2e009e);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0xde4400){return this['snapshotCallback']===_0xde4400['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0xde4400['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0xde4400['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x20be44,_0x1990ea,_0x4ed0cd,_0x37ad5f){this['_repo']=_0x20be44,this['_path']=_0x1990ea,this['_queryParams']=_0x4ed0cd,this['_orderByCalled']=_0x37ad5f;}get['key'](){return v(this['_path'])?null:zi(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x30e0d5=rr(this['_queryParams']),_0x145685=Hi(_0x30e0d5);return _0x145685==='{}'?'default':_0x145685;}get['_queryObject'](){return rr(this['_queryParams']);}['isEqual'](_0x319291){if(_0x319291=N(_0x319291),!(_0x319291 instanceof be))return!0x1;const _0x2b6765=this['_repo']===_0x319291['_repo'],_0x1ddf9d=ji(this['_path'],_0x319291['_path']),_0x1c9cdc=this['_queryIdentifier']===_0x319291['_queryIdentifier'];return _0x2b6765&&_0x1ddf9d&&_0x1c9cdc;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x54b137,_0x6f0825){if(_0x54b137['_orderByCalled']===!0x0)throw new Error(_0x6f0825+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function qn(_0x23d020){let _0x12f457=null,_0x3f6629=null;if(_0x23d020['hasStart']()&&(_0x12f457=_0x23d020['getIndexStartValue']()),_0x23d020['hasEnd']()&&(_0x3f6629=_0x23d020['getIndexEndValue']()),_0x23d020['getIndex']()===ye){const _0x5189f4='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x2dd95b='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x23d020['hasStart']()){if(_0x23d020['getIndexStartName']()!==Fe)throw new Error(_0x5189f4);if(typeof _0x12f457!='string')throw new Error(_0x2dd95b);}if(_0x23d020['hasEnd']()){if(_0x23d020['getIndexEndName']()!==Ie)throw new Error(_0x5189f4);if(typeof _0x3f6629!='string')throw new Error(_0x2dd95b);}}else{if(_0x23d020['getIndex']()===R){if(_0x12f457!=null&&!Tn(_0x12f457)||_0x3f6629!=null&&!Tn(_0x3f6629))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x23d020['getIndex']()instanceof Qi||_0x23d020['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x12f457!=null&&typeof _0x12f457=='object'||_0x3f6629!=null&&typeof _0x3f6629=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x488613){if(_0x488613['hasStart']()&&_0x488613['hasEnd']()&&_0x488613['hasLimit']()&&!_0x488613['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends be{constructor(_0x6ae543,_0x3c5af3){super(_0x6ae543,_0x3c5af3,new Xi(),!0x1);}get['parent'](){const _0x2cba12=Ro(this['_path']);return _0x2cba12===null?null:new ee(this['_repo'],_0x2cba12);}get['root'](){let _0x42eb4e=this;for(;_0x42eb4e['parent']!==null;)_0x42eb4e=_0x42eb4e['parent'];return _0x42eb4e;}}class st{constructor(_0x46d159,_0xbe1377,_0x4ba69f){this['_node']=_0x46d159,this['ref']=_0xbe1377,this['_index']=_0x4ba69f;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x1ac1f4){const _0x5b82f5=new C(_0x1ac1f4),_0x556c6b=Ft(this['ref'],_0x1ac1f4);return new st(this['_node']['getChild'](_0x5b82f5),_0x556c6b,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x4a3145){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x2d2d51,_0xbd6f7f)=>_0x4a3145(new st(_0xbd6f7f,Ft(this['ref'],_0x2d2d51),R)));}['hasChild'](_0x5386a8){const _0x235fc1=new C(_0x5386a8);return!this['_node']['getChild'](_0x235fc1)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function __(_0x136fc5,_0x1bd52f){return _0x136fc5=N(_0x136fc5),_0x136fc5['_checkNotDeleted']('ref'),_0x1bd52f!==void 0x0?Ft(_0x136fc5['_root'],_0x1bd52f):_0x136fc5['_root'];}function Ft(_0x38e0cd,_0x14f283){return _0x38e0cd=N(_0x38e0cd),y(_0x38e0cd['_path'])===null?pd('child','path',_0x14f283):ms('child','path',_0x14f283),new ee(_0x38e0cd['_repo'],k(_0x38e0cd['_path'],_0x14f283));}function g_(_0x2e7509,_0xdec68d){_0x2e7509=N(_0x2e7509),ys('push',_0x2e7509['_path']),zt('push',_0xdec68d,_0x2e7509['_path'],!0x0);const _0xa5edef=la(_0x2e7509['_repo']),_0x5840a2=Ld(_0xa5edef),_0x3f990c=Ft(_0x2e7509,_0x5840a2),_0x2204da=Ft(_0x2e7509,_0x5840a2);let _0x4e02e5;return _0xdec68d!=null?_0x4e02e5=Ud(_0x2204da,_0xdec68d)['then'](()=>_0x2204da):_0x4e02e5=Promise['resolve'](_0x2204da),_0x3f990c['then']=_0x4e02e5['then']['bind'](_0x4e02e5),_0x3f990c['catch']=_0x4e02e5['then']['bind'](_0x4e02e5,void 0x0),_0x3f990c;}function Ud(_0x4fbbfd,_0x54cbc3){_0x4fbbfd=N(_0x4fbbfd),ys('set',_0x4fbbfd['_path']),zt('set',_0x54cbc3,_0x4fbbfd['_path'],!0x1);const _0x167b07=new ot();return Cd(_0x4fbbfd['_repo'],_0x4fbbfd['_path'],_0x54cbc3,null,_0x167b07['wrapCallback'](()=>{})),_0x167b07['promise'];}function m_(_0x283d2f,_0x2c0d5f){fd('update',_0x2c0d5f,_0x283d2f['_path']);const _0x46082b=new ot();return Td(_0x283d2f['_repo'],_0x283d2f['_path'],_0x2c0d5f,_0x46082b['wrapCallback'](()=>{})),_0x46082b['promise'];}function y_(_0x26077e){_0x26077e=N(_0x26077e);const _0x5bad7a=new pa(()=>{}),_0x1dfb5e=new zn(_0x5bad7a);return wd(_0x26077e['_repo'],_0x26077e,_0x1dfb5e)['then'](_0x30689f=>new st(_0x30689f,new ee(_0x26077e['_repo'],_0x26077e['_path']),_0x26077e['_queryParams']['getIndex']()));}class zn{constructor(_0xc17f9f){this['callbackContext']=_0xc17f9f;}['respondsTo'](_0x138563){return _0x138563==='value';}['createEvent'](_0x562539,_0x54c0f9){const _0x7045bc=_0x54c0f9['_queryParams']['getIndex']();return new xd('value',this,new st(_0x562539['snapshotNode'],new ee(_0x54c0f9['_repo'],_0x54c0f9['_path']),_0x7045bc));}['getEventRunner'](_0x1dc873){return _0x1dc873['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x1dc873['error']):()=>this['callbackContext']['onValue'](_0x1dc873['snapshot'],null);}['createCancelEvent'](_0x635866,_0x2c29c5){return this['callbackContext']['hasCancelCallback']?new Fd(this,_0x635866,_0x2c29c5):null;}['matches'](_0x1007c3){return _0x1007c3 instanceof zn?!_0x1007c3['callbackContext']||!this['callbackContext']?!0x0:_0x1007c3['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function Wd(_0x3ee420,_0x395d0e,_0x727f48,_0x219f31,_0x4692a9){const _0x26eda4=new pa(_0x727f48,void 0x0),_0x126995=new zn(_0x26eda4);return bd(_0x3ee420['_repo'],_0x3ee420,_0x126995),()=>Rd(_0x3ee420['_repo'],_0x3ee420,_0x126995);}function Bd(_0x1236b2,_0x4ec229,_0x614e77,_0x2c09d2){return Wd(_0x1236b2,'value',_0x4ec229);}class ft{}class ma extends ft{constructor(_0x695740,_0x1df242){super(),this['_value']=_0x695740,this['_key']=_0x1df242,this['type']='endAt';}['_apply'](_0x46a460){zt('endAt',this['_value'],_0x46a460['_path'],!0x0);const _0xd8ea26=Jh(_0x46a460['_queryParams'],this['_value'],this['_key']);if(ga(_0xd8ea26),qn(_0xd8ea26),_0x46a460['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x46a460['_repo'],_0x46a460['_path'],_0xd8ea26,_0x46a460['_orderByCalled']);}}function v_(_0x28ef53,_0xd58637){return new ma(_0x28ef53,_0xd58637);}class ya extends ft{constructor(_0x387407,_0x12784b){super(),this['_value']=_0x387407,this['_key']=_0x12784b,this['type']='startAt';}['_apply'](_0x4306c3){zt('startAt',this['_value'],_0x4306c3['_path'],!0x0);const _0x5f1ccf=Qh(_0x4306c3['_queryParams'],this['_value'],this['_key']);if(ga(_0x5f1ccf),qn(_0x5f1ccf),_0x4306c3['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x4306c3['_repo'],_0x4306c3['_path'],_0x5f1ccf,_0x4306c3['_orderByCalled']);}}function E_(_0x48c917=null,_0xac7bf7){return new ya(_0x48c917,_0xac7bf7);}class Vd extends ft{constructor(_0x4f36ca){super(),this['_limit']=_0x4f36ca,this['type']='limitToFirst';}['_apply'](_0x260a1e){if(_0x260a1e['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x260a1e['_repo'],_0x260a1e['_path'],Yh(_0x260a1e['_queryParams'],this['_limit']),_0x260a1e['_orderByCalled']);}}function I_(_0x4e850d){if(Math['floor'](_0x4e850d)!==_0x4e850d||_0x4e850d<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Vd(_0x4e850d);}class Hd extends ft{constructor(_0x4c346e){super(),this['_path']=_0x4c346e,this['type']='orderByChild';}['_apply'](_0x28a175){_a(_0x28a175,'orderByChild');const _0x33f917=new C(this['_path']);if(v(_0x33f917))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x4e1b94=new Qi(_0x33f917),_0x7b53c9=xo(_0x28a175['_queryParams'],_0x4e1b94);return qn(_0x7b53c9),new be(_0x28a175['_repo'],_0x28a175['_path'],_0x7b53c9,!0x0);}}function w_(_0x5b97f3){if(_0x5b97f3==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x5b97f3==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x5b97f3==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ms('orderByChild','path',_0x5b97f3),new Hd(_0x5b97f3);}class $d extends ft{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0xa3643d){_a(_0xa3643d,'orderByKey');const _0x416252=xo(_0xa3643d['_queryParams'],ye);return qn(_0x416252),new be(_0xa3643d['_repo'],_0xa3643d['_path'],_0x416252,!0x0);}}function C_(){return new $d();}class Gd extends ft{constructor(_0x256e9e,_0x1f200f){super(),this['_value']=_0x256e9e,this['_key']=_0x1f200f,this['type']='equalTo';}['_apply'](_0xadaaea){if(zt('equalTo',this['_value'],_0xadaaea['_path'],!0x1),_0xadaaea['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0xadaaea['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0xadaaea));}}function T_(_0x5e9485,_0x3aa1a8){return new Gd(_0x5e9485,_0x3aa1a8);}function S_(_0x184288,..._0x57a354){let _0x44f1fd=N(_0x184288);for(const _0x471671 of _0x57a354)_0x44f1fd=_0x471671['_apply'](_0x44f1fd);return _0x44f1fd;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qd='FIREBASE_DATABASE_EMULATOR_HOST',Ni={};let zd=!0x1;function jd(_0x176350,_0x40c3bf,_0x30e5b4,_0x54ab2b){const _0x4ad473=_0x40c3bf['lastIndexOf'](':'),_0x4ffa65=_0x40c3bf['substring'](0x0,_0x4ad473),_0x1be4df=at(_0x4ffa65);_0x176350['repoInfo_']=new yo(_0x40c3bf,_0x1be4df,_0x176350['repoInfo_']['namespace'],_0x176350['repoInfo_']['webSocketOnly'],_0x176350['repoInfo_']['nodeAdmin'],_0x176350['repoInfo_']['persistenceKey'],_0x176350['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x30e5b4),_0x54ab2b&&(_0x176350['authTokenProvider_']=_0x54ab2b);}function Kd(_0x1125b9,_0x12e5bd,_0x9baa7b,_0x4b4c73,_0x3714d3){let _0x1e988e=_0x4b4c73||_0x1125b9['options']['databaseURL'];_0x1e988e===void 0x0&&(_0x1125b9['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x1125b9['options']['projectId']),_0x1e988e=_0x1125b9['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x169dc2=vr(_0x1e988e,_0x3714d3),_0xac4683=_0x169dc2['repoInfo'],_0x388242;typeof process<'u'&&Vs&&(_0x388242=Vs[qd]),_0x388242?(_0x1e988e='http://'+_0x388242+'?ns='+_0xac4683['namespace'],_0x169dc2=vr(_0x1e988e,_0x3714d3),_0xac4683=_0x169dc2['repoInfo']):_0x169dc2['repoInfo']['secure'];const _0xaaaaf7=new eh(_0x1125b9['name'],_0x1125b9['options'],_0x12e5bd);_d('Invalid\x20Firebase\x20Database\x20URL',_0x169dc2),v(_0x169dc2['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x3a1f98=Qd(_0xac4683,_0x1125b9,_0xaaaaf7,new Zl(_0x1125b9,_0x9baa7b));return new Jd(_0x3a1f98,_0x1125b9);}function Yd(_0x2efc09,_0x2675aa){const _0x561e5c=Ni[_0x2675aa];(!_0x561e5c||_0x561e5c[_0x2efc09['key']]!==_0x2efc09)&&ae('Database\x20'+_0x2675aa+'('+_0x2efc09['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x2efc09),delete _0x561e5c[_0x2efc09['key']];}function Qd(_0x239737,_0x2ef1fd,_0x49612a,_0x1b13ff){let _0x5bc0e3=Ni[_0x2ef1fd['name']];_0x5bc0e3||(_0x5bc0e3={},Ni[_0x2ef1fd['name']]=_0x5bc0e3);let _0x2a45ab=_0x5bc0e3[_0x239737['toURLString']()];return _0x2a45ab&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x2a45ab=new vd(_0x239737,zd,_0x49612a,_0x1b13ff),_0x5bc0e3[_0x239737['toURLString']()]=_0x2a45ab,_0x2a45ab;}class Jd{constructor(_0x15a614,_0x4a85eb){this['_repoInternal']=_0x15a614,this['app']=_0x4a85eb,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Yd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x287cb7){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x287cb7+'\x20on\x20a\x20deleted\x20database.');}}function b_(_0x44bb30=Zr(),_0x4f756d){const _0x5ac2b4=Bi(_0x44bb30,'database')['getImmediate']({'identifier':_0x4f756d});if(!_0x5ac2b4['_instanceStarted']){const _0x168049=cc('database');_0x168049&&Xd(_0x5ac2b4,..._0x168049);}return _0x5ac2b4;}function Xd(_0x172889,_0x47cf5c,_0x53e05b,_0x5f1ab2={}){_0x172889=N(_0x172889),_0x172889['_checkNotDeleted']('useEmulator');const _0x5bd19b=_0x47cf5c+':'+_0x53e05b,_0x2c3933=_0x172889['_repoInternal'];if(_0x172889['_instanceStarted']){if(_0x5bd19b===_0x172889['_repoInternal']['repoInfo_']['host']&&Me(_0x5f1ab2,_0x2c3933['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x433a1e;if(_0x2c3933['repoInfo_']['nodeAdmin'])_0x5f1ab2['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x433a1e=new nn(nn['OWNER']);else{if(_0x5f1ab2['mockUserToken']){const _0x4f4274=typeof _0x5f1ab2['mockUserToken']=='string'?_0x5f1ab2['mockUserToken']:lc(_0x5f1ab2['mockUserToken'],_0x172889['app']['options']['projectId']);_0x433a1e=new nn(_0x4f4274);}}at(_0x47cf5c)&&(jr(_0x47cf5c),Kr('Database',!0x0)),jd(_0x2c3933,_0x5bd19b,_0x5f1ab2,_0x433a1e);}function R_(_0x6c9fab){_0x6c9fab=N(_0x6c9fab),_0x6c9fab['_checkNotDeleted']('goOffline'),ha(_0x6c9fab['_repo']);}function A_(_0x14f25b){_0x14f25b=N(_0x14f25b),_0x14f25b['_checkNotDeleted']('goOnline'),Ad(_0x14f25b['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Zd(_0xf223dc){Ul(lt),Ze(new Le('database',(_0x2fc8fa,{instanceIdentifier:_0x2ceba0})=>{const _0x31b0b5=_0x2fc8fa['getProvider']('app')['getImmediate'](),_0x2798a5=_0x2fc8fa['getProvider']('auth-internal'),_0x4f6850=_0x2fc8fa['getProvider']('app-check-internal');return Kd(_0x31b0b5,_0x2798a5,_0x4f6850,_0x2ceba0);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Hs,$s,_0xf223dc),me(Hs,$s,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ef={'.sv':'timestamp'};function k_(){return ef;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tf{constructor(_0x2a9a07,_0x3ae533){this['committed']=_0x2a9a07,this['snapshot']=_0x3ae533;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function N_(_0x532ca0,_0x2a8801,_0x31bef0){if(_0x532ca0=N(_0x532ca0),ys('Reference.transaction',_0x532ca0['_path']),_0x532ca0['key']==='.length'||_0x532ca0['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x532ca0['key']+'\x20is\x20a\x20read-only\x20object.';const _0x45382d=!0x0,_0x4d8cbd=new ot(),_0x10fe09=(_0x5bddf0,_0x13d139,_0x223a4b)=>{let _0x20a52d=null;_0x5bddf0?_0x4d8cbd['reject'](_0x5bddf0):(_0x20a52d=new st(_0x223a4b,new ee(_0x532ca0['_repo'],_0x532ca0['_path']),R),_0x4d8cbd['resolve'](new tf(_0x13d139,_0x20a52d)));},_0x192014=Bd(_0x532ca0,()=>{});return kd(_0x532ca0['_repo'],_0x532ca0['_path'],_0x2a8801,_0x10fe09,_0x192014,_0x45382d),_0x4d8cbd['promise'];}se['prototype']['simpleListen']=function(_0x79aba4,_0x1d52f0){this['sendRequest']('q',{'p':_0x79aba4},_0x1d52f0);},se['prototype']['echo']=function(_0x1b5cac,_0xfc9857){this['sendRequest']('echo',{'d':_0x1b5cac},_0xfc9857);},Zd();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const nf=va,Ea=new Bt('auth','Firebase',va()),Sn=new Ui('@firebase/auth');function sf(_0x19dad3,..._0x17ea2c){Sn['logLevel']<=T['WARN']&&Sn['warn']('Auth\x20('+lt+'):\x20'+_0x19dad3,..._0x17ea2c);}function sn(_0xcbc09e,..._0x19a68e){Sn['logLevel']<=T['ERROR']&&Sn['error']('Auth\x20('+lt+'):\x20'+_0xcbc09e,..._0x19a68e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x4b5001,..._0x5d07ea){throw ws(_0x4b5001,..._0x5d07ea);}function X(_0x5f5ca9,..._0x45af4c){return ws(_0x5f5ca9,..._0x45af4c);}function Ia(_0xdc78e0,_0x265123,_0x25e5dd){const _0x4385ba={...nf(),[_0x265123]:_0x25e5dd};return new Bt('auth','Firebase',_0x4385ba)['create'](_0x265123,{'appName':_0xdc78e0['name']});}function re(_0x42be9d){return Ia(_0x42be9d,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x35afc8,..._0x1076ce){if(typeof _0x35afc8!='string'){const _0x215794=_0x1076ce[0x0],_0x45f1d4=[..._0x1076ce['slice'](0x1)];return _0x45f1d4[0x0]&&(_0x45f1d4[0x0]['appName']=_0x35afc8['name']),_0x35afc8['_errorFactory']['create'](_0x215794,..._0x45f1d4);}return Ea['create'](_0x35afc8,..._0x1076ce);}function m(_0x4ee5c7,_0x142ff3,..._0x58ed9d){if(!_0x4ee5c7)throw ws(_0x142ff3,..._0x58ed9d);}function ne(_0x1d7454){const _0x2be598='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x1d7454;throw sn(_0x2be598),new Error(_0x2be598);}function ce(_0x5d1482,_0xe7fdba){_0x5d1482||ne(_0xe7fdba);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pi(){var _0x16fdfb;return typeof self<'u'&&((_0x16fdfb=self['location'])==null?void 0x0:_0x16fdfb['href'])||'';}function rf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x3f44cb;return typeof self<'u'&&((_0x3f44cb=self['location'])==null?void 0x0:_0x3f44cb['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function of(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(rf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function af(){if(typeof navigator>'u')return null;const _0xa2a61b=navigator;return _0xa2a61b['languages']&&_0xa2a61b['languages'][0x0]||_0xa2a61b['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yt{constructor(_0x159940,_0x1f595a){this['shortDelay']=_0x159940,this['longDelay']=_0x1f595a,ce(_0x1f595a>_0x159940,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Fi()||Yr();}['get'](){return of()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x388b7b,_0x592981){ce(_0x388b7b['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x2e0634}=_0x388b7b['emulator'];return _0x592981?''+_0x2e0634+(_0x592981['startsWith']('/')?_0x592981['slice'](0x1):_0x592981):_0x2e0634;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x51690c,_0x1092ca,_0x2dda0a){this['fetchImpl']=_0x51690c,_0x1092ca&&(this['headersImpl']=_0x1092ca),_0x2dda0a&&(this['responseImpl']=_0x2dda0a);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const cf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},lf=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],hf=new Yt(0x7530,0xea60);function Re(_0x237821,_0x3aed17){return _0x237821['tenantId']&&!_0x3aed17['tenantId']?{..._0x3aed17,'tenantId':_0x237821['tenantId']}:_0x3aed17;}async function Ae(_0x188b67,_0x2c6c94,_0x3f31b7,_0x1dddf0,_0x3ee60d={}){return Ca(_0x188b67,_0x3ee60d,async()=>{let _0x377759={},_0x3aff03={};_0x1dddf0&&(_0x2c6c94==='GET'?_0x3aff03=_0x1dddf0:_0x377759={'body':JSON['stringify'](_0x1dddf0)});const _0x4af870=ct({'key':_0x188b67['config']['apiKey'],..._0x3aff03})['slice'](0x1),_0x1802ac=await _0x188b67['_getAdditionalHeaders']();_0x1802ac['Content-Type']='application/json',_0x188b67['languageCode']&&(_0x1802ac['X-Firebase-Locale']=_0x188b67['languageCode']);const _0x36b173={'method':_0x2c6c94,'headers':_0x1802ac,..._0x377759};return dc()||(_0x36b173['referrerPolicy']='no-referrer'),_0x188b67['emulatorConfig']&&at(_0x188b67['emulatorConfig']['host'])&&(_0x36b173['credentials']='include'),wa['fetch']()(await Ta(_0x188b67,_0x188b67['config']['apiHost'],_0x3f31b7,_0x4af870),_0x36b173);});}async function Ca(_0x3b42d9,_0xf28067,_0x23b15e){_0x3b42d9['_canInitEmulator']=!0x1;const _0x229a84={...cf,..._0xf28067};try{const _0x2aaad3=new df(_0x3b42d9),_0x2ddb6a=await Promise['race']([_0x23b15e(),_0x2aaad3['promise']]);_0x2aaad3['clearNetworkTimeout']();const _0x1008b3=await _0x2ddb6a['json']();if('needConfirmation'in _0x1008b3)throw tn(_0x3b42d9,'account-exists-with-different-credential',_0x1008b3);if(_0x2ddb6a['ok']&&!('errorMessage'in _0x1008b3))return _0x1008b3;{const _0x4a31c3=_0x2ddb6a['ok']?_0x1008b3['errorMessage']:_0x1008b3['error']['message'],[_0x412c61,_0xc854e1]=_0x4a31c3['split']('\x20:\x20');if(_0x412c61==='FEDERATED_USER_ID_ALREADY_LINKED')throw tn(_0x3b42d9,'credential-already-in-use',_0x1008b3);if(_0x412c61==='EMAIL_EXISTS')throw tn(_0x3b42d9,'email-already-in-use',_0x1008b3);if(_0x412c61==='USER_DISABLED')throw tn(_0x3b42d9,'user-disabled',_0x1008b3);const _0x1b0275=_0x229a84[_0x412c61]||_0x412c61['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0xc854e1)throw Ia(_0x3b42d9,_0x1b0275,_0xc854e1);Q(_0x3b42d9,_0x1b0275);}}catch(_0x2ea377){if(_0x2ea377 instanceof Se)throw _0x2ea377;Q(_0x3b42d9,'network-request-failed',{'message':String(_0x2ea377)});}}async function Qt(_0x583032,_0x47ae10,_0x1e6333,_0x1d8975,_0x18ba33={}){const _0x2dc2ae=await Ae(_0x583032,_0x47ae10,_0x1e6333,_0x1d8975,_0x18ba33);return'mfaPendingCredential'in _0x2dc2ae&&Q(_0x583032,'multi-factor-auth-required',{'_serverResponse':_0x2dc2ae}),_0x2dc2ae;}async function Ta(_0x236193,_0x5e7e1d,_0x476d10,_0x7baa69){const _0x563cff=''+_0x5e7e1d+_0x476d10+'?'+_0x7baa69,_0x1a7594=_0x236193,_0x15f8e3=_0x1a7594['config']['emulator']?Cs(_0x236193['config'],_0x563cff):_0x236193['config']['apiScheme']+'://'+_0x563cff;return lf['includes'](_0x476d10)&&(await _0x1a7594['_persistenceManagerAvailable'],_0x1a7594['_getPersistenceType']()==='COOKIE')?_0x1a7594['_getPersistence']()['_getFinalTarget'](_0x15f8e3)['toString']():_0x15f8e3;}function uf(_0x344e44){switch(_0x344e44){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class df{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x311172){this['auth']=_0x311172,this['timer']=null,this['promise']=new Promise((_0x1dec20,_0xe61fda)=>{this['timer']=setTimeout(()=>_0xe61fda(X(this['auth'],'network-request-failed')),hf['get']());});}}function tn(_0x33643e,_0x2b9a23,_0x3d8357){const _0x4cd3e1={'appName':_0x33643e['name']};_0x3d8357['email']&&(_0x4cd3e1['email']=_0x3d8357['email']),_0x3d8357['phoneNumber']&&(_0x4cd3e1['phoneNumber']=_0x3d8357['phoneNumber']);const _0x51e185=X(_0x33643e,_0x2b9a23,_0x4cd3e1);return _0x51e185['customData']['_tokenResponse']=_0x3d8357,_0x51e185;}function wr(_0x25b0c5){return _0x25b0c5!==void 0x0&&_0x25b0c5['enterprise']!==void 0x0;}class ff{constructor(_0x616c60){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x616c60['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x616c60['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x616c60['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x10d887){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x40633c of this['recaptchaEnforcementState'])if(_0x40633c['provider']&&_0x40633c['provider']===_0x10d887)return uf(_0x40633c['enforcementState']);return null;}['isProviderEnabled'](_0x4695a6){return this['getProviderEnforcementState'](_0x4695a6)==='ENFORCE'||this['getProviderEnforcementState'](_0x4695a6)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function pf(_0x1d841e,_0x4bd554){return Ae(_0x1d841e,'GET','/v2/recaptchaConfig',Re(_0x1d841e,_0x4bd554));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function _f(_0xb1c867,_0x647eb7){return Ae(_0xb1c867,'POST','/v1/accounts:delete',_0x647eb7);}async function bn(_0x4ee9f9,_0x355b93){return Ae(_0x4ee9f9,'POST','/v1/accounts:lookup',_0x355b93);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Rt(_0x15ba0a){if(_0x15ba0a)try{const _0x169c53=new Date(Number(_0x15ba0a));if(!isNaN(_0x169c53['getTime']()))return _0x169c53['toUTCString']();}catch{}}async function gf(_0x5e8361,_0x2d1c31=!0x1){const _0x390191=N(_0x5e8361),_0x4cfce5=await _0x390191['getIdToken'](_0x2d1c31),_0x58c973=Ts(_0x4cfce5);m(_0x58c973&&_0x58c973['exp']&&_0x58c973['auth_time']&&_0x58c973['iat'],_0x390191['auth'],'internal-error');const _0x2dedeb=typeof _0x58c973['firebase']=='object'?_0x58c973['firebase']:void 0x0,_0xaec2db=_0x2dedeb==null?void 0x0:_0x2dedeb['sign_in_provider'];return{'claims':_0x58c973,'token':_0x4cfce5,'authTime':Rt(li(_0x58c973['auth_time'])),'issuedAtTime':Rt(li(_0x58c973['iat'])),'expirationTime':Rt(li(_0x58c973['exp'])),'signInProvider':_0xaec2db||null,'signInSecondFactor':(_0x2dedeb==null?void 0x0:_0x2dedeb['sign_in_second_factor'])||null};}function li(_0x3d23eb){return Number(_0x3d23eb)*0x3e8;}function Ts(_0x29ec94){const [_0x3845bc,_0x31f7e0,_0x230f83]=_0x29ec94['split']('.');if(_0x3845bc===void 0x0||_0x31f7e0===void 0x0||_0x230f83===void 0x0)return sn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x7fba42=ln(_0x31f7e0);return _0x7fba42?JSON['parse'](_0x7fba42):(sn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x23314d){return sn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x23314d==null?void 0x0:_0x23314d['toString']()),null;}}function Cr(_0x5a0f51){const _0x56bea3=Ts(_0x5a0f51);return m(_0x56bea3,'internal-error'),m(typeof _0x56bea3['exp']<'u','internal-error'),m(typeof _0x56bea3['iat']<'u','internal-error'),Number(_0x56bea3['exp'])-Number(_0x56bea3['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ut(_0x1ba452,_0x536661,_0x34ccfd=!0x1){if(_0x34ccfd)return _0x536661;try{return await _0x536661;}catch(_0x579797){throw _0x579797 instanceof Se&&mf(_0x579797)&&_0x1ba452['auth']['currentUser']===_0x1ba452&&await _0x1ba452['auth']['signOut'](),_0x579797;}}function mf({code:_0x4051bc}){return _0x4051bc==='auth/user-disabled'||_0x4051bc==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yf{constructor(_0x3e1a61){this['user']=_0x3e1a61,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x23b49d){if(_0x23b49d){const _0x4be3ef=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x4be3ef;}else{this['errorBackoff']=0x7530;const _0x3b083a=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x3b083a);}}['schedule'](_0x3d3035=!0x1){if(!this['isRunning'])return;const _0x27a0d2=this['getInterval'](_0x3d3035);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x27a0d2);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x4ca619){(_0x4ca619==null?void 0x0:_0x4ca619['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Oi{constructor(_0x5c5bb9,_0x44744f){this['createdAt']=_0x5c5bb9,this['lastLoginAt']=_0x44744f,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Rt(this['lastLoginAt']),this['creationTime']=Rt(this['createdAt']);}['_copy'](_0x20ee49){this['createdAt']=_0x20ee49['createdAt'],this['lastLoginAt']=_0x20ee49['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Rn(_0x45c4fb){var _0x3359a4;const _0x5d6eac=_0x45c4fb['auth'],_0x5128d5=await _0x45c4fb['getIdToken'](),_0x556a73=await Ut(_0x45c4fb,bn(_0x5d6eac,{'idToken':_0x5128d5}));m(_0x556a73==null?void 0x0:_0x556a73['users']['length'],_0x5d6eac,'internal-error');const _0x410dae=_0x556a73['users'][0x0];_0x45c4fb['_notifyReloadListener'](_0x410dae);const _0x28e19d=(_0x3359a4=_0x410dae['providerUserInfo'])!=null&&_0x3359a4['length']?Sa(_0x410dae['providerUserInfo']):[],_0x119aa5=Ef(_0x45c4fb['providerData'],_0x28e19d),_0x4cf32e=_0x45c4fb['isAnonymous'],_0x3fba92=!(_0x45c4fb['email']&&_0x410dae['passwordHash'])&&!(_0x119aa5!=null&&_0x119aa5['length']),_0x55a84d=_0x4cf32e?_0x3fba92:!0x1,_0x331380={'uid':_0x410dae['localId'],'displayName':_0x410dae['displayName']||null,'photoURL':_0x410dae['photoUrl']||null,'email':_0x410dae['email']||null,'emailVerified':_0x410dae['emailVerified']||!0x1,'phoneNumber':_0x410dae['phoneNumber']||null,'tenantId':_0x410dae['tenantId']||null,'providerData':_0x119aa5,'metadata':new Oi(_0x410dae['createdAt'],_0x410dae['lastLoginAt']),'isAnonymous':_0x55a84d};Object['assign'](_0x45c4fb,_0x331380);}async function vf(_0x5e99cc){const _0x59748f=N(_0x5e99cc);await Rn(_0x59748f),await _0x59748f['auth']['_persistUserIfCurrent'](_0x59748f),_0x59748f['auth']['_notifyListenersIfCurrent'](_0x59748f);}function Ef(_0x23558d,_0x205f01){return[..._0x23558d['filter'](_0x5c9f2a=>!_0x205f01['some'](_0x3ffac1=>_0x3ffac1['providerId']===_0x5c9f2a['providerId'])),..._0x205f01];}function Sa(_0x3df4d4){return _0x3df4d4['map'](({providerId:_0x38e7b5,..._0x1d07ee})=>({'providerId':_0x38e7b5,'uid':_0x1d07ee['rawId']||'','displayName':_0x1d07ee['displayName']||null,'email':_0x1d07ee['email']||null,'phoneNumber':_0x1d07ee['phoneNumber']||null,'photoURL':_0x1d07ee['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function If(_0x33d771,_0xd5e6f5){const _0x1dceb5=await Ca(_0x33d771,{},async()=>{const _0x53d45f=ct({'grant_type':'refresh_token','refresh_token':_0xd5e6f5})['slice'](0x1),{tokenApiHost:_0x15218f,apiKey:_0x34d116}=_0x33d771['config'],_0x4be695=await Ta(_0x33d771,_0x15218f,'/v1/token','key='+_0x34d116),_0x321d81=await _0x33d771['_getAdditionalHeaders']();_0x321d81['Content-Type']='application/x-www-form-urlencoded';const _0x4cd90e={'method':'POST','headers':_0x321d81,'body':_0x53d45f};return _0x33d771['emulatorConfig']&&at(_0x33d771['emulatorConfig']['host'])&&(_0x4cd90e['credentials']='include'),wa['fetch']()(_0x4be695,_0x4cd90e);});return{'accessToken':_0x1dceb5['access_token'],'expiresIn':_0x1dceb5['expires_in'],'refreshToken':_0x1dceb5['refresh_token']};}async function wf(_0x4499c9,_0x4a9a88){return Ae(_0x4499c9,'POST','/v2/accounts:revokeToken',Re(_0x4499c9,_0x4a9a88));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qe{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x9f86b7){m(_0x9f86b7['idToken'],'internal-error'),m(typeof _0x9f86b7['idToken']<'u','internal-error'),m(typeof _0x9f86b7['refreshToken']<'u','internal-error');const _0x4b3e50='expiresIn'in _0x9f86b7&&typeof _0x9f86b7['expiresIn']<'u'?Number(_0x9f86b7['expiresIn']):Cr(_0x9f86b7['idToken']);this['updateTokensAndExpiration'](_0x9f86b7['idToken'],_0x9f86b7['refreshToken'],_0x4b3e50);}['updateFromIdToken'](_0x5871bf){m(_0x5871bf['length']!==0x0,'internal-error');const _0x242332=Cr(_0x5871bf);this['updateTokensAndExpiration'](_0x5871bf,null,_0x242332);}async['getToken'](_0x2a3bfb,_0x3a26ad=!0x1){return!_0x3a26ad&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x2a3bfb,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x2a3bfb,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x1b9e76,_0x3cb5e2){const {accessToken:_0x4d988d,refreshToken:_0xa104d2,expiresIn:_0xa22d48}=await If(_0x1b9e76,_0x3cb5e2);this['updateTokensAndExpiration'](_0x4d988d,_0xa104d2,Number(_0xa22d48));}['updateTokensAndExpiration'](_0x356fe7,_0x2ea71e,_0x122b90){this['refreshToken']=_0x2ea71e||null,this['accessToken']=_0x356fe7||null,this['expirationTime']=Date['now']()+_0x122b90*0x3e8;}static['fromJSON'](_0x819467,_0x2b25b9){const {refreshToken:_0x1081f1,accessToken:_0x3d5da0,expirationTime:_0x1893fc}=_0x2b25b9,_0x57a979=new Qe();return _0x1081f1&&(m(typeof _0x1081f1=='string','internal-error',{'appName':_0x819467}),_0x57a979['refreshToken']=_0x1081f1),_0x3d5da0&&(m(typeof _0x3d5da0=='string','internal-error',{'appName':_0x819467}),_0x57a979['accessToken']=_0x3d5da0),_0x1893fc&&(m(typeof _0x1893fc=='number','internal-error',{'appName':_0x819467}),_0x57a979['expirationTime']=_0x1893fc),_0x57a979;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x3d1057){this['accessToken']=_0x3d1057['accessToken'],this['refreshToken']=_0x3d1057['refreshToken'],this['expirationTime']=_0x3d1057['expirationTime'];}['_clone'](){return Object['assign'](new Qe(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x400055,_0x224131){m(typeof _0x400055=='string'||typeof _0x400055>'u','internal-error',{'appName':_0x224131});}class K{constructor({uid:_0x50d2d6,auth:_0x168669,stsTokenManager:_0x4ba8fc,..._0x3477b5}){this['providerId']='firebase',this['proactiveRefresh']=new yf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x50d2d6,this['auth']=_0x168669,this['stsTokenManager']=_0x4ba8fc,this['accessToken']=_0x4ba8fc['accessToken'],this['displayName']=_0x3477b5['displayName']||null,this['email']=_0x3477b5['email']||null,this['emailVerified']=_0x3477b5['emailVerified']||!0x1,this['phoneNumber']=_0x3477b5['phoneNumber']||null,this['photoURL']=_0x3477b5['photoURL']||null,this['isAnonymous']=_0x3477b5['isAnonymous']||!0x1,this['tenantId']=_0x3477b5['tenantId']||null,this['providerData']=_0x3477b5['providerData']?[..._0x3477b5['providerData']]:[],this['metadata']=new Oi(_0x3477b5['createdAt']||void 0x0,_0x3477b5['lastLoginAt']||void 0x0);}async['getIdToken'](_0x4d2bbc){const _0x352159=await Ut(this,this['stsTokenManager']['getToken'](this['auth'],_0x4d2bbc));return m(_0x352159,this['auth'],'internal-error'),this['accessToken']!==_0x352159&&(this['accessToken']=_0x352159,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x352159;}['getIdTokenResult'](_0x1657ba){return gf(this,_0x1657ba);}['reload'](){return vf(this);}['_assign'](_0x5b63f7){this!==_0x5b63f7&&(m(this['uid']===_0x5b63f7['uid'],this['auth'],'internal-error'),this['displayName']=_0x5b63f7['displayName'],this['photoURL']=_0x5b63f7['photoURL'],this['email']=_0x5b63f7['email'],this['emailVerified']=_0x5b63f7['emailVerified'],this['phoneNumber']=_0x5b63f7['phoneNumber'],this['isAnonymous']=_0x5b63f7['isAnonymous'],this['tenantId']=_0x5b63f7['tenantId'],this['providerData']=_0x5b63f7['providerData']['map'](_0x42d320=>({..._0x42d320})),this['metadata']['_copy'](_0x5b63f7['metadata']),this['stsTokenManager']['_assign'](_0x5b63f7['stsTokenManager']));}['_clone'](_0x7eec9a){const _0x4dc5b8=new K({...this,'auth':_0x7eec9a,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x4dc5b8['metadata']['_copy'](this['metadata']),_0x4dc5b8;}['_onReload'](_0x46aa27){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x46aa27,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x2a0767){this['reloadListener']?this['reloadListener'](_0x2a0767):this['reloadUserInfo']=_0x2a0767;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x10a74c,_0x2cec2a=!0x1){let _0x535352=!0x1;_0x10a74c['idToken']&&_0x10a74c['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x10a74c),_0x535352=!0x0),_0x2cec2a&&await Rn(this),await this['auth']['_persistUserIfCurrent'](this),_0x535352&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x1117da=await this['getIdToken']();return await Ut(this,_f(this['auth'],{'idToken':_0x1117da})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x35f7b6=>({..._0x35f7b6})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x1f4e40,_0x2f45f1){const _0x1d4daf=_0x2f45f1['displayName']??void 0x0,_0x1d150c=_0x2f45f1['email']??void 0x0,_0x5a8a2c=_0x2f45f1['phoneNumber']??void 0x0,_0x3b2bdf=_0x2f45f1['photoURL']??void 0x0,_0xdeaca8=_0x2f45f1['tenantId']??void 0x0,_0x63b035=_0x2f45f1['_redirectEventId']??void 0x0,_0x2009fa=_0x2f45f1['createdAt']??void 0x0,_0x3b219c=_0x2f45f1['lastLoginAt']??void 0x0,{uid:_0x479814,emailVerified:_0x1bc5ca,isAnonymous:_0x27377c,providerData:_0x4380e4,stsTokenManager:_0x4d81c1}=_0x2f45f1;m(_0x479814&&_0x4d81c1,_0x1f4e40,'internal-error');const _0x10cf90=Qe['fromJSON'](this['name'],_0x4d81c1);m(typeof _0x479814=='string',_0x1f4e40,'internal-error'),le(_0x1d4daf,_0x1f4e40['name']),le(_0x1d150c,_0x1f4e40['name']),m(typeof _0x1bc5ca=='boolean',_0x1f4e40,'internal-error'),m(typeof _0x27377c=='boolean',_0x1f4e40,'internal-error'),le(_0x5a8a2c,_0x1f4e40['name']),le(_0x3b2bdf,_0x1f4e40['name']),le(_0xdeaca8,_0x1f4e40['name']),le(_0x63b035,_0x1f4e40['name']),le(_0x2009fa,_0x1f4e40['name']),le(_0x3b219c,_0x1f4e40['name']);const _0x1bc1ae=new K({'uid':_0x479814,'auth':_0x1f4e40,'email':_0x1d150c,'emailVerified':_0x1bc5ca,'displayName':_0x1d4daf,'isAnonymous':_0x27377c,'photoURL':_0x3b2bdf,'phoneNumber':_0x5a8a2c,'tenantId':_0xdeaca8,'stsTokenManager':_0x10cf90,'createdAt':_0x2009fa,'lastLoginAt':_0x3b219c});return _0x4380e4&&Array['isArray'](_0x4380e4)&&(_0x1bc1ae['providerData']=_0x4380e4['map'](_0xc59f51=>({..._0xc59f51}))),_0x63b035&&(_0x1bc1ae['_redirectEventId']=_0x63b035),_0x1bc1ae;}static async['_fromIdTokenResponse'](_0x47c3b2,_0x3d02af,_0x1654ce=!0x1){const _0x3b4ca0=new Qe();_0x3b4ca0['updateFromServerResponse'](_0x3d02af);const _0x530454=new K({'uid':_0x3d02af['localId'],'auth':_0x47c3b2,'stsTokenManager':_0x3b4ca0,'isAnonymous':_0x1654ce});return await Rn(_0x530454),_0x530454;}static async['_fromGetAccountInfoResponse'](_0x4c8a4e,_0x15d349,_0x24b1a7){const _0x4b833c=_0x15d349['users'][0x0];m(_0x4b833c['localId']!==void 0x0,'internal-error');const _0x408a0f=_0x4b833c['providerUserInfo']!==void 0x0?Sa(_0x4b833c['providerUserInfo']):[],_0x25e898=!(_0x4b833c['email']&&_0x4b833c['passwordHash'])&&!(_0x408a0f!=null&&_0x408a0f['length']),_0x1af078=new Qe();_0x1af078['updateFromIdToken'](_0x24b1a7);const _0x26cb43=new K({'uid':_0x4b833c['localId'],'auth':_0x4c8a4e,'stsTokenManager':_0x1af078,'isAnonymous':_0x25e898}),_0x57f143={'uid':_0x4b833c['localId'],'displayName':_0x4b833c['displayName']||null,'photoURL':_0x4b833c['photoUrl']||null,'email':_0x4b833c['email']||null,'emailVerified':_0x4b833c['emailVerified']||!0x1,'phoneNumber':_0x4b833c['phoneNumber']||null,'tenantId':_0x4b833c['tenantId']||null,'providerData':_0x408a0f,'metadata':new Oi(_0x4b833c['createdAt'],_0x4b833c['lastLoginAt']),'isAnonymous':!(_0x4b833c['email']&&_0x4b833c['passwordHash'])&&!(_0x408a0f!=null&&_0x408a0f['length'])};return Object['assign'](_0x26cb43,_0x57f143),_0x26cb43;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x5bf168){ce(_0x5bf168 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x418dcc=Tr['get'](_0x5bf168);return _0x418dcc?(ce(_0x418dcc instanceof _0x5bf168,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x418dcc):(_0x418dcc=new _0x5bf168(),Tr['set'](_0x5bf168,_0x418dcc),_0x418dcc);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x18b40e,_0x3181da){this['storage'][_0x18b40e]=_0x3181da;}async['_get'](_0x216bd5){const _0x2b23f7=this['storage'][_0x216bd5];return _0x2b23f7===void 0x0?null:_0x2b23f7;}async['_remove'](_0x3b2c4a){delete this['storage'][_0x3b2c4a];}['_addListener'](_0x25cd09,_0x2021ce){}['_removeListener'](_0x405bf1,_0x480045){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rn(_0x2f6e53,_0x5765a3,_0x5d0841){return'firebase:'+_0x2f6e53+':'+_0x5765a3+':'+_0x5d0841;}class Je{constructor(_0x3f5ea0,_0x43943d,_0x52a8b6){this['persistence']=_0x3f5ea0,this['auth']=_0x43943d,this['userKey']=_0x52a8b6;const {config:_0x507bbe,name:_0x3c95a2}=this['auth'];this['fullUserKey']=rn(this['userKey'],_0x507bbe['apiKey'],_0x3c95a2),this['fullPersistenceKey']=rn('persistence',_0x507bbe['apiKey'],_0x3c95a2),this['boundEventHandler']=_0x43943d['_onStorageEvent']['bind'](_0x43943d),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x3fa9f3){return this['persistence']['_set'](this['fullUserKey'],_0x3fa9f3['toJSON']());}async['getCurrentUser'](){const _0x2c5e3a=await this['persistence']['_get'](this['fullUserKey']);if(!_0x2c5e3a)return null;if(typeof _0x2c5e3a=='string'){const _0x4d2c8f=await bn(this['auth'],{'idToken':_0x2c5e3a})['catch'](()=>{});return _0x4d2c8f?K['_fromGetAccountInfoResponse'](this['auth'],_0x4d2c8f,_0x2c5e3a):null;}return K['_fromJSON'](this['auth'],_0x2c5e3a);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x34dcbd){if(this['persistence']===_0x34dcbd)return;const _0xb3fd4d=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x34dcbd,_0xb3fd4d)return this['setCurrentUser'](_0xb3fd4d);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x48e51a,_0x16644d,_0xefa123='authUser'){if(!_0x16644d['length'])return new Je(ie(Sr),_0x48e51a,_0xefa123);const _0x344be9=(await Promise['all'](_0x16644d['map'](async _0x384587=>{if(await _0x384587['_isAvailable']())return _0x384587;})))['filter'](_0x5ee8a8=>_0x5ee8a8);let _0x31b859=_0x344be9[0x0]||ie(Sr);const _0x4fb08a=rn(_0xefa123,_0x48e51a['config']['apiKey'],_0x48e51a['name']);let _0x249208=null;for(const _0x45635a of _0x16644d)try{const _0x11f8cb=await _0x45635a['_get'](_0x4fb08a);if(_0x11f8cb){let _0x5c7ccd;if(typeof _0x11f8cb=='string'){const _0x2bff10=await bn(_0x48e51a,{'idToken':_0x11f8cb})['catch'](()=>{});if(!_0x2bff10)break;_0x5c7ccd=await K['_fromGetAccountInfoResponse'](_0x48e51a,_0x2bff10,_0x11f8cb);}else _0x5c7ccd=K['_fromJSON'](_0x48e51a,_0x11f8cb);_0x45635a!==_0x31b859&&(_0x249208=_0x5c7ccd),_0x31b859=_0x45635a;break;}}catch{}const _0x13a52b=_0x344be9['filter'](_0x2b9a47=>_0x2b9a47['_shouldAllowMigration']);return!_0x31b859['_shouldAllowMigration']||!_0x13a52b['length']?new Je(_0x31b859,_0x48e51a,_0xefa123):(_0x31b859=_0x13a52b[0x0],_0x249208&&await _0x31b859['_set'](_0x4fb08a,_0x249208['toJSON']()),await Promise['all'](_0x16644d['map'](async _0x168245=>{if(_0x168245!==_0x31b859)try{await _0x168245['_remove'](_0x4fb08a);}catch{}})),new Je(_0x31b859,_0x48e51a,_0xefa123));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x5d10ec){const _0x181f56=_0x5d10ec['toLowerCase']();if(_0x181f56['includes']('opera/')||_0x181f56['includes']('opr/')||_0x181f56['includes']('opios/'))return'Opera';if(Na(_0x181f56))return'IEMobile';if(_0x181f56['includes']('msie')||_0x181f56['includes']('trident/'))return'IE';if(_0x181f56['includes']('edge/'))return'Edge';if(Ra(_0x181f56))return'Firefox';if(_0x181f56['includes']('silk/'))return'Silk';if(Oa(_0x181f56))return'Blackberry';if(Da(_0x181f56))return'Webos';if(Aa(_0x181f56))return'Safari';if((_0x181f56['includes']('chrome/')||ka(_0x181f56))&&!_0x181f56['includes']('edge/'))return'Chrome';if(Pa(_0x181f56))return'Android';{const _0x5f3ce9=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x87baea=_0x5d10ec['match'](_0x5f3ce9);if((_0x87baea==null?void 0x0:_0x87baea['length'])===0x2)return _0x87baea[0x1];}return'Other';}function Ra(_0x34d34=W()){return/firefox\//i['test'](_0x34d34);}function Aa(_0x1dd280=W()){const _0x40cbf5=_0x1dd280['toLowerCase']();return _0x40cbf5['includes']('safari/')&&!_0x40cbf5['includes']('chrome/')&&!_0x40cbf5['includes']('crios/')&&!_0x40cbf5['includes']('android');}function ka(_0x2bb03c=W()){return/crios\//i['test'](_0x2bb03c);}function Na(_0xc2be84=W()){return/iemobile/i['test'](_0xc2be84);}function Pa(_0x40ec8a=W()){return/android/i['test'](_0x40ec8a);}function Oa(_0x415421=W()){return/blackberry/i['test'](_0x415421);}function Da(_0x493423=W()){return/webos/i['test'](_0x493423);}function Ss(_0x45c8ea=W()){return/iphone|ipad|ipod/i['test'](_0x45c8ea)||/macintosh/i['test'](_0x45c8ea)&&/mobile/i['test'](_0x45c8ea);}function Cf(_0xe236a7=W()){var _0x549237;return Ss(_0xe236a7)&&!!((_0x549237=window['navigator'])!=null&&_0x549237['standalone']);}function Tf(){return pc()&&document['documentMode']===0xa;}function Ma(_0x1bd05f=W()){return Ss(_0x1bd05f)||Pa(_0x1bd05f)||Da(_0x1bd05f)||Oa(_0x1bd05f)||/windows phone/i['test'](_0x1bd05f)||Na(_0x1bd05f);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0xc19710,_0x1d717e=[]){let _0x2797a6;switch(_0xc19710){case'Browser':_0x2797a6=br(W());break;case'Worker':_0x2797a6=br(W())+'-'+_0xc19710;break;default:_0x2797a6=_0xc19710;}const _0x17b458=_0x1d717e['length']?_0x1d717e['join'](','):'FirebaseCore-web';return _0x2797a6+'/JsCore/'+lt+'/'+_0x17b458;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sf{constructor(_0x1e8e80){this['auth']=_0x1e8e80,this['queue']=[];}['pushCallback'](_0xdc8d4a,_0x3c2980){const _0x1b5315=_0x464089=>new Promise((_0x26b841,_0x117d6b)=>{try{const _0x5872e0=_0xdc8d4a(_0x464089);_0x26b841(_0x5872e0);}catch(_0x40948f){_0x117d6b(_0x40948f);}});_0x1b5315['onAbort']=_0x3c2980,this['queue']['push'](_0x1b5315);const _0x380bc0=this['queue']['length']-0x1;return()=>{this['queue'][_0x380bc0]=()=>Promise['resolve']();};}async['runMiddleware'](_0x1c5fec){if(this['auth']['currentUser']===_0x1c5fec)return;const _0xfadf8c=[];try{for(const _0x598ef0 of this['queue'])await _0x598ef0(_0x1c5fec),_0x598ef0['onAbort']&&_0xfadf8c['push'](_0x598ef0['onAbort']);}catch(_0x316641){_0xfadf8c['reverse']();for(const _0x2aefca of _0xfadf8c)try{_0x2aefca();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x316641==null?void 0x0:_0x316641['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bf(_0x2ebd7a,_0x33988a={}){return Ae(_0x2ebd7a,'GET','/v2/passwordPolicy',Re(_0x2ebd7a,_0x33988a));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rf=0x6;class Af{constructor(_0xfb9240){var _0x48676d;const _0x30e51e=_0xfb9240['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x30e51e['minPasswordLength']??Rf,_0x30e51e['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x30e51e['maxPasswordLength']),_0x30e51e['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x30e51e['containsLowercaseCharacter']),_0x30e51e['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x30e51e['containsUppercaseCharacter']),_0x30e51e['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x30e51e['containsNumericCharacter']),_0x30e51e['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x30e51e['containsNonAlphanumericCharacter']),this['enforcementState']=_0xfb9240['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x48676d=_0xfb9240['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x48676d['join'](''))??'',this['forceUpgradeOnSignin']=_0xfb9240['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0xfb9240['schemaVersion'];}['validatePassword'](_0x3b48b9){const _0x559e61={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x3b48b9,_0x559e61),this['validatePasswordCharacterOptions'](_0x3b48b9,_0x559e61),_0x559e61['isValid']&&(_0x559e61['isValid']=_0x559e61['meetsMinPasswordLength']??!0x0),_0x559e61['isValid']&&(_0x559e61['isValid']=_0x559e61['meetsMaxPasswordLength']??!0x0),_0x559e61['isValid']&&(_0x559e61['isValid']=_0x559e61['containsLowercaseLetter']??!0x0),_0x559e61['isValid']&&(_0x559e61['isValid']=_0x559e61['containsUppercaseLetter']??!0x0),_0x559e61['isValid']&&(_0x559e61['isValid']=_0x559e61['containsNumericCharacter']??!0x0),_0x559e61['isValid']&&(_0x559e61['isValid']=_0x559e61['containsNonAlphanumericCharacter']??!0x0),_0x559e61;}['validatePasswordLengthOptions'](_0x7a1e59,_0x3bb41c){const _0x30defa=this['customStrengthOptions']['minPasswordLength'],_0x170fb4=this['customStrengthOptions']['maxPasswordLength'];_0x30defa&&(_0x3bb41c['meetsMinPasswordLength']=_0x7a1e59['length']>=_0x30defa),_0x170fb4&&(_0x3bb41c['meetsMaxPasswordLength']=_0x7a1e59['length']<=_0x170fb4);}['validatePasswordCharacterOptions'](_0x559fbf,_0x15fc8b){this['updatePasswordCharacterOptionsStatuses'](_0x15fc8b,!0x1,!0x1,!0x1,!0x1);let _0x3cba03;for(let _0x31d910=0x0;_0x31d910<_0x559fbf['length'];_0x31d910++)_0x3cba03=_0x559fbf['charAt'](_0x31d910),this['updatePasswordCharacterOptionsStatuses'](_0x15fc8b,_0x3cba03>='a'&&_0x3cba03<='z',_0x3cba03>='A'&&_0x3cba03<='Z',_0x3cba03>='0'&&_0x3cba03<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x3cba03));}['updatePasswordCharacterOptionsStatuses'](_0x34fa7e,_0x3c4f80,_0x1a5788,_0x4bea1b,_0x40061c){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x34fa7e['containsLowercaseLetter']||(_0x34fa7e['containsLowercaseLetter']=_0x3c4f80)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x34fa7e['containsUppercaseLetter']||(_0x34fa7e['containsUppercaseLetter']=_0x1a5788)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x34fa7e['containsNumericCharacter']||(_0x34fa7e['containsNumericCharacter']=_0x4bea1b)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x34fa7e['containsNonAlphanumericCharacter']||(_0x34fa7e['containsNonAlphanumericCharacter']=_0x40061c));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x129849,_0x54f39e,_0x16ace9,_0x1f3414){this['app']=_0x129849,this['heartbeatServiceProvider']=_0x54f39e,this['appCheckServiceProvider']=_0x16ace9,this['config']=_0x1f3414,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new Sf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x129849['name'],this['clientVersion']=_0x1f3414['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x20c57e=>this['_resolvePersistenceManagerAvailable']=_0x20c57e);}['_initializeWithPersistence'](_0x2b4073,_0x33b1e0){return _0x33b1e0&&(this['_popupRedirectResolver']=ie(_0x33b1e0)),this['_initializationPromise']=this['queue'](async()=>{var _0x2014a3,_0x51a8dd,_0x8e6af4;if(!this['_deleted']&&(this['persistenceManager']=await Je['create'](this,_0x2b4073),(_0x2014a3=this['_resolvePersistenceManagerAvailable'])==null||_0x2014a3['call'](this),!this['_deleted'])){if((_0x51a8dd=this['_popupRedirectResolver'])!=null&&_0x51a8dd['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x33b1e0),this['lastNotifiedUid']=((_0x8e6af4=this['currentUser'])==null?void 0x0:_0x8e6af4['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x21371e=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x21371e)){if(this['currentUser']&&_0x21371e&&this['currentUser']['uid']===_0x21371e['uid']){this['_currentUser']['_assign'](_0x21371e),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x21371e,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x353c04){try{const _0x5aa09d=await bn(this,{'idToken':_0x353c04}),_0x3f8bec=await K['_fromGetAccountInfoResponse'](this,_0x5aa09d,_0x353c04);await this['directlySetCurrentUser'](_0x3f8bec);}catch(_0x269839){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x269839),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x5114b5){var _0x57ff2b;if($(this['app'])){const _0x51623b=this['app']['settings']['authIdToken'];return _0x51623b?new Promise(_0x5a5a0e=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x51623b)['then'](_0x5a5a0e,_0x5a5a0e));}):this['directlySetCurrentUser'](null);}const _0x5e94bb=await this['assertedPersistence']['getCurrentUser']();let _0x26d41a=_0x5e94bb,_0x5af082=!0x1;if(_0x5114b5&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x335969=(_0x57ff2b=this['redirectUser'])==null?void 0x0:_0x57ff2b['_redirectEventId'],_0x55b4af=_0x26d41a==null?void 0x0:_0x26d41a['_redirectEventId'],_0x1176b0=await this['tryRedirectSignIn'](_0x5114b5);(!_0x335969||_0x335969===_0x55b4af)&&(_0x1176b0!=null&&_0x1176b0['user'])&&(_0x26d41a=_0x1176b0['user'],_0x5af082=!0x0);}if(!_0x26d41a)return this['directlySetCurrentUser'](null);if(!_0x26d41a['_redirectEventId']){if(_0x5af082)try{await this['beforeStateQueue']['runMiddleware'](_0x26d41a);}catch(_0x5b6195){_0x26d41a=_0x5e94bb,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x5b6195));}return _0x26d41a?this['reloadAndSetCurrentUserOrClear'](_0x26d41a):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x26d41a['_redirectEventId']?this['directlySetCurrentUser'](_0x26d41a):this['reloadAndSetCurrentUserOrClear'](_0x26d41a);}async['tryRedirectSignIn'](_0x23a202){let _0x365068=null;try{_0x365068=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x23a202,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x365068;}async['reloadAndSetCurrentUserOrClear'](_0x3f397c){try{await Rn(_0x3f397c);}catch(_0x5f5261){if((_0x5f5261==null?void 0x0:_0x5f5261['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x3f397c);}['useDeviceLanguage'](){this['languageCode']=af();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x41d8f6){if($(this['app']))return Promise['reject'](re(this));const _0x57ae66=_0x41d8f6?N(_0x41d8f6):null;return _0x57ae66&&m(_0x57ae66['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x57ae66&&_0x57ae66['_clone'](this));}async['_updateCurrentUser'](_0x2737ee,_0x290305=!0x1){if(!this['_deleted'])return _0x2737ee&&m(this['tenantId']===_0x2737ee['tenantId'],this,'tenant-id-mismatch'),_0x290305||await this['beforeStateQueue']['runMiddleware'](_0x2737ee),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x2737ee),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0xc2ed22){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0xc2ed22));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x49ee69){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x599f25=this['_getPasswordPolicyInternal']();return _0x599f25['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x599f25['validatePassword'](_0x49ee69);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x474529=await bf(this),_0x4f49a3=new Af(_0x474529);this['tenantId']===null?this['_projectPasswordPolicy']=_0x4f49a3:this['_tenantPasswordPolicies'][this['tenantId']]=_0x4f49a3;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x3053b2){this['_errorFactory']=new Bt('auth','Firebase',_0x3053b2());}['onAuthStateChanged'](_0x53e0c1,_0x4176fb,_0x521cda){return this['registerStateListener'](this['authStateSubscription'],_0x53e0c1,_0x4176fb,_0x521cda);}['beforeAuthStateChanged'](_0x34e596,_0x14e8e0){return this['beforeStateQueue']['pushCallback'](_0x34e596,_0x14e8e0);}['onIdTokenChanged'](_0x1c1c34,_0x36a421,_0x50714c){return this['registerStateListener'](this['idTokenSubscription'],_0x1c1c34,_0x36a421,_0x50714c);}['authStateReady'](){return new Promise((_0x13ba6f,_0x21eb80)=>{if(this['currentUser'])_0x13ba6f();else{const _0x39a208=this['onAuthStateChanged'](()=>{_0x39a208(),_0x13ba6f();},_0x21eb80);}});}async['revokeAccessToken'](_0x583e09){if(this['currentUser']){const _0x27f56a=await this['currentUser']['getIdToken'](),_0x430165={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x583e09,'idToken':_0x27f56a};this['tenantId']!=null&&(_0x430165['tenantId']=this['tenantId']),await wf(this,_0x430165);}}['toJSON'](){var _0x4aeb6c;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x4aeb6c=this['_currentUser'])==null?void 0x0:_0x4aeb6c['toJSON']()};}async['_setRedirectUser'](_0x33e1fd,_0x171cd6){const _0x2b8fef=await this['getOrInitRedirectPersistenceManager'](_0x171cd6);return _0x33e1fd===null?_0x2b8fef['removeCurrentUser']():_0x2b8fef['setCurrentUser'](_0x33e1fd);}async['getOrInitRedirectPersistenceManager'](_0xe29dc8){if(!this['redirectPersistenceManager']){const _0x3295c2=_0xe29dc8&&ie(_0xe29dc8)||this['_popupRedirectResolver'];m(_0x3295c2,this,'argument-error'),this['redirectPersistenceManager']=await Je['create'](this,[ie(_0x3295c2['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x2ac022){var _0x5cce1f,_0x2445b1;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x5cce1f=this['_currentUser'])==null?void 0x0:_0x5cce1f['_redirectEventId'])===_0x2ac022?this['_currentUser']:((_0x2445b1=this['redirectUser'])==null?void 0x0:_0x2445b1['_redirectEventId'])===_0x2ac022?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x131fd8){if(_0x131fd8===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x131fd8));}['_notifyListenersIfCurrent'](_0x5a8f4e){_0x5a8f4e===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x54650b;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x28f22c=((_0x54650b=this['currentUser'])==null?void 0x0:_0x54650b['uid'])??null;this['lastNotifiedUid']!==_0x28f22c&&(this['lastNotifiedUid']=_0x28f22c,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x3cc44c,_0x59cb86,_0x4c9bd,_0x5adaa6){if(this['_deleted'])return()=>{};const _0x591246=typeof _0x59cb86=='function'?_0x59cb86:_0x59cb86['next']['bind'](_0x59cb86);let _0x32294d=!0x1;const _0x35789a=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x35789a,this,'internal-error'),_0x35789a['then'](()=>{_0x32294d||_0x591246(this['currentUser']);}),typeof _0x59cb86=='function'){const _0x3678b0=_0x3cc44c['addObserver'](_0x59cb86,_0x4c9bd,_0x5adaa6);return()=>{_0x32294d=!0x0,_0x3678b0();};}else{const _0x5a9d6a=_0x3cc44c['addObserver'](_0x59cb86);return()=>{_0x32294d=!0x0,_0x5a9d6a();};}}async['directlySetCurrentUser'](_0x381026){this['currentUser']&&this['currentUser']!==_0x381026&&this['_currentUser']['_stopProactiveRefresh'](),_0x381026&&this['isProactiveRefreshEnabled']&&_0x381026['_startProactiveRefresh'](),this['currentUser']=_0x381026,_0x381026?await this['assertedPersistence']['setCurrentUser'](_0x381026):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x3f93ec){return this['operations']=this['operations']['then'](_0x3f93ec,_0x3f93ec),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x284bc1){!_0x284bc1||this['frameworks']['includes'](_0x284bc1)||(this['frameworks']['push'](_0x284bc1),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x45ac4e;const _0x593c6b={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x593c6b['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x171604=await((_0x45ac4e=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x45ac4e['getHeartbeatsHeader']());_0x171604&&(_0x593c6b['X-Firebase-Client']=_0x171604);const _0x4d9cc0=await this['_getAppCheckToken']();return _0x4d9cc0&&(_0x593c6b['X-Firebase-AppCheck']=_0x4d9cc0),_0x593c6b;}async['_getAppCheckToken'](){var _0x5c30a6;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x431d13=await((_0x5c30a6=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x5c30a6['getToken']());return _0x431d13!=null&&_0x431d13['error']&&sf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x431d13['error']),_0x431d13==null?void 0x0:_0x431d13['token'];}}function qe(_0x4b7905){return N(_0x4b7905);}class Rr{constructor(_0x2f2c26){this['auth']=_0x2f2c26,this['observer']=null,this['addObserver']=Tc(_0x275c0b=>this['observer']=_0x275c0b);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Nf(_0xd9c8ad){jn=_0xd9c8ad;}function xa(_0x363ae5){return jn['loadJS'](_0x363ae5);}function Pf(){return jn['recaptchaEnterpriseScript'];}function Of(){return jn['gapiScript'];}function Df(_0x653673){return'__'+_0x653673+Math['floor'](Math['random']()*0xf4240);}class Mf{constructor(){this['enterprise']=new Lf();}['ready'](_0x17496e){_0x17496e();}['execute'](_0x421c7a,_0x3d4ef9){return Promise['resolve']('token');}['render'](_0x12eaa9,_0x25565d){return'';}}class Lf{['ready'](_0x526ae7){_0x526ae7();}['execute'](_0x23cc3c,_0x4025ca){return Promise['resolve']('token');}['render'](_0x175fda,_0x2b3576){return'';}}const xf='recaptcha-enterprise',Fa='NO_RECAPTCHA';class Ff{constructor(_0x1a2311){this['type']=xf,this['auth']=qe(_0x1a2311);}async['verify'](_0x1cd29a='verify',_0x4e4b56=!0x1){async function _0x9680fc(_0x5c8b73){if(!_0x4e4b56){if(_0x5c8b73['tenantId']==null&&_0x5c8b73['_agentRecaptchaConfig']!=null)return _0x5c8b73['_agentRecaptchaConfig']['siteKey'];if(_0x5c8b73['tenantId']!=null&&_0x5c8b73['_tenantRecaptchaConfigs'][_0x5c8b73['tenantId']]!==void 0x0)return _0x5c8b73['_tenantRecaptchaConfigs'][_0x5c8b73['tenantId']]['siteKey'];}return new Promise(async(_0x21539d,_0x261b96)=>{pf(_0x5c8b73,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x44b137=>{if(_0x44b137['recaptchaKey']===void 0x0)_0x261b96(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x3e2752=new ff(_0x44b137);return _0x5c8b73['tenantId']==null?_0x5c8b73['_agentRecaptchaConfig']=_0x3e2752:_0x5c8b73['_tenantRecaptchaConfigs'][_0x5c8b73['tenantId']]=_0x3e2752,_0x21539d(_0x3e2752['siteKey']);}})['catch'](_0x27a37b=>{_0x261b96(_0x27a37b);});});}function _0x5d3459(_0x5152a2,_0x17828d,_0x2273bb){const _0x1dfb58=window['grecaptcha'];wr(_0x1dfb58)?_0x1dfb58['enterprise']['ready'](()=>{_0x1dfb58['enterprise']['execute'](_0x5152a2,{'action':_0x1cd29a})['then'](_0x1d00e6=>{_0x17828d(_0x1d00e6);})['catch'](()=>{_0x17828d(Fa);});}):_0x2273bb(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Mf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x3500dd,_0x2191a1)=>{_0x9680fc(this['auth'])['then'](_0x54bdc1=>{if(!_0x4e4b56&&wr(window['grecaptcha']))_0x5d3459(_0x54bdc1,_0x3500dd,_0x2191a1);else{if(typeof window>'u'){_0x2191a1(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x3c4520=Pf();_0x3c4520['length']!==0x0&&(_0x3c4520+=_0x54bdc1),xa(_0x3c4520)['then'](()=>{_0x5d3459(_0x54bdc1,_0x3500dd,_0x2191a1);})['catch'](_0x61aea3=>{_0x2191a1(_0x61aea3);});}})['catch'](_0x1c23fb=>{_0x2191a1(_0x1c23fb);});});}}async function Ar(_0x5f5b42,_0x2ed6a4,_0x41049a,_0x2f08a4=!0x1,_0x1556dc=!0x1){const _0x3c6963=new Ff(_0x5f5b42);let _0xbb51a3;if(_0x1556dc)_0xbb51a3=Fa;else try{_0xbb51a3=await _0x3c6963['verify'](_0x41049a);}catch{_0xbb51a3=await _0x3c6963['verify'](_0x41049a,!0x0);}const _0x1a8fe8={..._0x2ed6a4};if(_0x41049a==='mfaSmsEnrollment'||_0x41049a==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x1a8fe8){const _0x20b433=_0x1a8fe8['phoneEnrollmentInfo']['phoneNumber'],_0xdde91d=_0x1a8fe8['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x1a8fe8,{'phoneEnrollmentInfo':{'phoneNumber':_0x20b433,'recaptchaToken':_0xdde91d,'captchaResponse':_0xbb51a3,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x1a8fe8){const _0x4a4ba0=_0x1a8fe8['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x1a8fe8,{'phoneSignInInfo':{'recaptchaToken':_0x4a4ba0,'captchaResponse':_0xbb51a3,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x1a8fe8;}return _0x2f08a4?Object['assign'](_0x1a8fe8,{'captchaResp':_0xbb51a3}):Object['assign'](_0x1a8fe8,{'captchaResponse':_0xbb51a3}),Object['assign'](_0x1a8fe8,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x1a8fe8,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x1a8fe8;}async function Di(_0x40197f,_0x98b10a,_0x43537d,_0xa92ead,_0x3e5b04){var _0x339c14;if((_0x339c14=_0x40197f['_getRecaptchaConfig']())!=null&&_0x339c14['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x4dab6f=await Ar(_0x40197f,_0x98b10a,_0x43537d,_0x43537d==='getOobCode');return _0xa92ead(_0x40197f,_0x4dab6f);}else return _0xa92ead(_0x40197f,_0x98b10a)['catch'](async _0x2717c6=>{if(_0x2717c6['code']==='auth/missing-recaptcha-token'){console['log'](_0x43537d+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x1ab346=await Ar(_0x40197f,_0x98b10a,_0x43537d,_0x43537d==='getOobCode');return _0xa92ead(_0x40197f,_0x1ab346);}else return Promise['reject'](_0x2717c6);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Uf(_0x1cbc57,_0x2fe575){const _0x593973=Bi(_0x1cbc57,'auth');if(_0x593973['isInitialized']()){const _0x25178c=_0x593973['getImmediate'](),_0x58ee7f=_0x593973['getOptions']();if(Me(_0x58ee7f,_0x2fe575??{}))return _0x25178c;Q(_0x25178c,'already-initialized');}return _0x593973['initialize']({'options':_0x2fe575});}function Wf(_0x2b84ab,_0x257321){const _0x2b533f=(_0x257321==null?void 0x0:_0x257321['persistence'])||[],_0x9cec8f=(Array['isArray'](_0x2b533f)?_0x2b533f:[_0x2b533f])['map'](ie);_0x257321!=null&&_0x257321['errorMap']&&_0x2b84ab['_updateErrorMap'](_0x257321['errorMap']),_0x2b84ab['_initializeWithPersistence'](_0x9cec8f,_0x257321==null?void 0x0:_0x257321['popupRedirectResolver']);}function Bf(_0x3b4388,_0x2e9577,_0x5dd338){const _0x55766d=qe(_0x3b4388);m(/^https?:\/\//['test'](_0x2e9577),_0x55766d,'invalid-emulator-scheme');const _0x2a971d=!0x1,_0x1215f8=Ua(_0x2e9577),{host:_0x5a35f6,port:_0x5a12f2}=Vf(_0x2e9577),_0x24cebb=_0x5a12f2===null?'':':'+_0x5a12f2,_0x54edac={'url':_0x1215f8+'//'+_0x5a35f6+_0x24cebb+'/'},_0xe261c=Object['freeze']({'host':_0x5a35f6,'port':_0x5a12f2,'protocol':_0x1215f8['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x2a971d})});if(!_0x55766d['_canInitEmulator']){m(_0x55766d['config']['emulator']&&_0x55766d['emulatorConfig'],_0x55766d,'emulator-config-failed'),m(Me(_0x54edac,_0x55766d['config']['emulator'])&&Me(_0xe261c,_0x55766d['emulatorConfig']),_0x55766d,'emulator-config-failed');return;}_0x55766d['config']['emulator']=_0x54edac,_0x55766d['emulatorConfig']=_0xe261c,_0x55766d['settings']['appVerificationDisabledForTesting']=!0x0,at(_0x5a35f6)?(jr(_0x1215f8+'//'+_0x5a35f6+_0x24cebb),Kr('Auth',!0x0)):Hf();}function Ua(_0x345b21){const _0x16ca4d=_0x345b21['indexOf'](':');return _0x16ca4d<0x0?'':_0x345b21['substr'](0x0,_0x16ca4d+0x1);}function Vf(_0xdae3b){const _0x1daff0=Ua(_0xdae3b),_0x57fb32=/(\/\/)?([^?#/]+)/['exec'](_0xdae3b['substr'](_0x1daff0['length']));if(!_0x57fb32)return{'host':'','port':null};const _0x33dbfb=_0x57fb32[0x2]['split']('@')['pop']()||'',_0x3d9627=/^(\[[^\]]+\])(:|$)/['exec'](_0x33dbfb);if(_0x3d9627){const _0x347141=_0x3d9627[0x1];return{'host':_0x347141,'port':kr(_0x33dbfb['substr'](_0x347141['length']+0x1))};}else{const [_0x2b1443,_0x29899a]=_0x33dbfb['split'](':');return{'host':_0x2b1443,'port':kr(_0x29899a)};}}function kr(_0x44266d){if(!_0x44266d)return null;const _0x178b44=Number(_0x44266d);return isNaN(_0x178b44)?null:_0x178b44;}function Hf(){function _0xfc992a(){const _0x6ef965=document['createElement']('p'),_0xda63c=_0x6ef965['style'];_0x6ef965['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0xda63c['position']='fixed',_0xda63c['width']='100%',_0xda63c['backgroundColor']='#ffffff',_0xda63c['border']='.1em\x20solid\x20#000000',_0xda63c['color']='#b50000',_0xda63c['bottom']='0px',_0xda63c['left']='0px',_0xda63c['margin']='0px',_0xda63c['zIndex']='10000',_0xda63c['textAlign']='center',_0x6ef965['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x6ef965);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0xfc992a):_0xfc992a());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x53ccf8,_0x221453){this['providerId']=_0x53ccf8,this['signInMethod']=_0x221453;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x4b80c7){return ne('not\x20implemented');}['_linkToIdToken'](_0x524143,_0x18a938){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x6806cb){return ne('not\x20implemented');}}async function $f(_0x59bf74,_0x446aed){return Ae(_0x59bf74,'POST','/v1/accounts:signUp',_0x446aed);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Gf(_0x14e1cb,_0x1fef9c){return Qt(_0x14e1cb,'POST','/v1/accounts:signInWithPassword',Re(_0x14e1cb,_0x1fef9c));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function qf(_0x5a6153,_0x3a6821){return Qt(_0x5a6153,'POST','/v1/accounts:signInWithEmailLink',Re(_0x5a6153,_0x3a6821));}async function zf(_0x4eeafe,_0x391cb0){return Qt(_0x4eeafe,'POST','/v1/accounts:signInWithEmailLink',Re(_0x4eeafe,_0x391cb0));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wt extends bs{constructor(_0x19a1ec,_0x25522d,_0x42ef26,_0x13787a=null){super('password',_0x42ef26),this['_email']=_0x19a1ec,this['_password']=_0x25522d,this['_tenantId']=_0x13787a;}static['_fromEmailAndPassword'](_0x545c1e,_0x3c77e5){return new Wt(_0x545c1e,_0x3c77e5,'password');}static['_fromEmailAndCode'](_0x35ab08,_0x2ff8c4,_0x3ec7e2=null){return new Wt(_0x35ab08,_0x2ff8c4,'emailLink',_0x3ec7e2);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x358138){const _0x4c8861=typeof _0x358138=='string'?JSON['parse'](_0x358138):_0x358138;if(_0x4c8861!=null&&_0x4c8861['email']&&(_0x4c8861!=null&&_0x4c8861['password'])){if(_0x4c8861['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x4c8861['email'],_0x4c8861['password']);if(_0x4c8861['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x4c8861['email'],_0x4c8861['password'],_0x4c8861['tenantId']);}return null;}async['_getIdTokenResponse'](_0x4a8bd1){switch(this['signInMethod']){case'password':const _0x337176={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x4a8bd1,_0x337176,'signInWithPassword',Gf);case'emailLink':return qf(_0x4a8bd1,{'email':this['_email'],'oobCode':this['_password']});default:Q(_0x4a8bd1,'internal-error');}}async['_linkToIdToken'](_0x284aee,_0x15a028){switch(this['signInMethod']){case'password':const _0x2964df={'idToken':_0x15a028,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x284aee,_0x2964df,'signUpPassword',$f);case'emailLink':return zf(_0x284aee,{'idToken':_0x15a028,'email':this['_email'],'oobCode':this['_password']});default:Q(_0x284aee,'internal-error');}}['_getReauthenticationResolver'](_0x10ae88){return this['_getIdTokenResponse'](_0x10ae88);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xe(_0x36cd5d,_0x3615fe){return Qt(_0x36cd5d,'POST','/v1/accounts:signInWithIdp',Re(_0x36cd5d,_0x3615fe));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jf='http://localhost';class Be extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x20106d){const _0xd4e322=new Be(_0x20106d['providerId'],_0x20106d['signInMethod']);return _0x20106d['idToken']||_0x20106d['accessToken']?(_0x20106d['idToken']&&(_0xd4e322['idToken']=_0x20106d['idToken']),_0x20106d['accessToken']&&(_0xd4e322['accessToken']=_0x20106d['accessToken']),_0x20106d['nonce']&&!_0x20106d['pendingToken']&&(_0xd4e322['nonce']=_0x20106d['nonce']),_0x20106d['pendingToken']&&(_0xd4e322['pendingToken']=_0x20106d['pendingToken'])):_0x20106d['oauthToken']&&_0x20106d['oauthTokenSecret']?(_0xd4e322['accessToken']=_0x20106d['oauthToken'],_0xd4e322['secret']=_0x20106d['oauthTokenSecret']):Q('argument-error'),_0xd4e322;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x180ed3){const _0x501a4b=typeof _0x180ed3=='string'?JSON['parse'](_0x180ed3):_0x180ed3,{providerId:_0x3606b0,signInMethod:_0x384979,..._0x4e1b14}=_0x501a4b;if(!_0x3606b0||!_0x384979)return null;const _0x11a79b=new Be(_0x3606b0,_0x384979);return _0x11a79b['idToken']=_0x4e1b14['idToken']||void 0x0,_0x11a79b['accessToken']=_0x4e1b14['accessToken']||void 0x0,_0x11a79b['secret']=_0x4e1b14['secret'],_0x11a79b['nonce']=_0x4e1b14['nonce'],_0x11a79b['pendingToken']=_0x4e1b14['pendingToken']||null,_0x11a79b;}['_getIdTokenResponse'](_0x3a7b51){const _0x8e404d=this['buildRequest']();return Xe(_0x3a7b51,_0x8e404d);}['_linkToIdToken'](_0x1511e7,_0x2e9d91){const _0xcb5d09=this['buildRequest']();return _0xcb5d09['idToken']=_0x2e9d91,Xe(_0x1511e7,_0xcb5d09);}['_getReauthenticationResolver'](_0x4acc4b){const _0x2941c4=this['buildRequest']();return _0x2941c4['autoCreate']=!0x1,Xe(_0x4acc4b,_0x2941c4);}['buildRequest'](){const _0x446717={'requestUri':jf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x446717['pendingToken']=this['pendingToken'];else{const _0x5b6ff5={};this['idToken']&&(_0x5b6ff5['id_token']=this['idToken']),this['accessToken']&&(_0x5b6ff5['access_token']=this['accessToken']),this['secret']&&(_0x5b6ff5['oauth_token_secret']=this['secret']),_0x5b6ff5['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x5b6ff5['nonce']=this['nonce']),_0x446717['postBody']=ct(_0x5b6ff5);}return _0x446717;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Kf(_0x18c9f4){switch(_0x18c9f4){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Yf(_0x3aed3e){const _0x3e62d9=vt(Et(_0x3aed3e))['link'],_0x46d63e=_0x3e62d9?vt(Et(_0x3e62d9))['deep_link_id']:null,_0x39f24a=vt(Et(_0x3aed3e))['deep_link_id'];return(_0x39f24a?vt(Et(_0x39f24a))['link']:null)||_0x39f24a||_0x46d63e||_0x3e62d9||_0x3aed3e;}class Rs{constructor(_0x45051f){const _0x5d4a14=vt(Et(_0x45051f)),_0x274eb4=_0x5d4a14['apiKey']??null,_0x29c8cc=_0x5d4a14['oobCode']??null,_0x42c583=Kf(_0x5d4a14['mode']??null);m(_0x274eb4&&_0x29c8cc&&_0x42c583,'argument-error'),this['apiKey']=_0x274eb4,this['operation']=_0x42c583,this['code']=_0x29c8cc,this['continueUrl']=_0x5d4a14['continueUrl']??null,this['languageCode']=_0x5d4a14['lang']??null,this['tenantId']=_0x5d4a14['tenantId']??null;}static['parseLink'](_0x5c32bc){const _0x1ffb21=Yf(_0x5c32bc);try{return new Rs(_0x1ffb21);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pt{constructor(){this['providerId']=pt['PROVIDER_ID'];}static['credential'](_0x510ff0,_0x30ae88){return Wt['_fromEmailAndPassword'](_0x510ff0,_0x30ae88);}static['credentialWithLink'](_0x3016b9,_0xd96494){const _0x2681ed=Rs['parseLink'](_0xd96494);return m(_0x2681ed,'argument-error'),Wt['_fromEmailAndCode'](_0x3016b9,_0x2681ed['code'],_0x2681ed['tenantId']);}}pt['PROVIDER_ID']='password',pt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',pt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x459e72){this['providerId']=_0x459e72,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x53274f){this['defaultLanguageCode']=_0x53274f;}['setCustomParameters'](_0x43ed8b){return this['customParameters']=_0x43ed8b,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jt extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x5e775b){return this['scopes']['includes'](_0x5e775b)||this['scopes']['push'](_0x5e775b),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Jt{constructor(){super('facebook.com');}static['credential'](_0x1f1567){return Be['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x1f1567});}static['credentialFromResult'](_0x159dc6){return he['credentialFromTaggedObject'](_0x159dc6);}static['credentialFromError'](_0x50780e){return he['credentialFromTaggedObject'](_0x50780e['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x52539b}){if(!_0x52539b||!('oauthAccessToken'in _0x52539b)||!_0x52539b['oauthAccessToken'])return null;try{return he['credential'](_0x52539b['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Jt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x17a27b,_0x5adead){return Be['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x17a27b,'accessToken':_0x5adead});}static['credentialFromResult'](_0xf5852c){return ue['credentialFromTaggedObject'](_0xf5852c);}static['credentialFromError'](_0x195e57){return ue['credentialFromTaggedObject'](_0x195e57['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x22a9a8}){if(!_0x22a9a8)return null;const {oauthIdToken:_0x4f6a9f,oauthAccessToken:_0x318fcc}=_0x22a9a8;if(!_0x4f6a9f&&!_0x318fcc)return null;try{return ue['credential'](_0x4f6a9f,_0x318fcc);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Jt{constructor(){super('github.com');}static['credential'](_0x392a86){return Be['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x392a86});}static['credentialFromResult'](_0x4c9168){return de['credentialFromTaggedObject'](_0x4c9168);}static['credentialFromError'](_0x6e9f07){return de['credentialFromTaggedObject'](_0x6e9f07['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x2f86ed}){if(!_0x2f86ed||!('oauthAccessToken'in _0x2f86ed)||!_0x2f86ed['oauthAccessToken'])return null;try{return de['credential'](_0x2f86ed['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Jt{constructor(){super('twitter.com');}static['credential'](_0x27b6d9,_0x2950c6){return Be['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x27b6d9,'oauthTokenSecret':_0x2950c6});}static['credentialFromResult'](_0x36b660){return fe['credentialFromTaggedObject'](_0x36b660);}static['credentialFromError'](_0x280d6a){return fe['credentialFromTaggedObject'](_0x280d6a['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x3596eb}){if(!_0x3596eb)return null;const {oauthAccessToken:_0x5a44de,oauthTokenSecret:_0x44cb6a}=_0x3596eb;if(!_0x5a44de||!_0x44cb6a)return null;try{return fe['credential'](_0x5a44de,_0x44cb6a);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Qf(_0x281c6c,_0x1c5d39){return Qt(_0x281c6c,'POST','/v1/accounts:signUp',Re(_0x281c6c,_0x1c5d39));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(_0x399e40){this['user']=_0x399e40['user'],this['providerId']=_0x399e40['providerId'],this['_tokenResponse']=_0x399e40['_tokenResponse'],this['operationType']=_0x399e40['operationType'];}static async['_fromIdTokenResponse'](_0x29f7cb,_0x5372e8,_0x5d86ba,_0xa58d59=!0x1){const _0x3c9243=await K['_fromIdTokenResponse'](_0x29f7cb,_0x5d86ba,_0xa58d59),_0x1f010b=Nr(_0x5d86ba);return new Ve({'user':_0x3c9243,'providerId':_0x1f010b,'_tokenResponse':_0x5d86ba,'operationType':_0x5372e8});}static async['_forOperation'](_0xdf1a02,_0x408a72,_0x574010){await _0xdf1a02['_updateTokensIfNecessary'](_0x574010,!0x0);const _0x628319=Nr(_0x574010);return new Ve({'user':_0xdf1a02,'providerId':_0x628319,'_tokenResponse':_0x574010,'operationType':_0x408a72});}}function Nr(_0x57eb83){return _0x57eb83['providerId']?_0x57eb83['providerId']:'phoneNumber'in _0x57eb83?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class An extends Se{constructor(_0x3d2a03,_0x2be695,_0x301c5d,_0x4043cf){super(_0x2be695['code'],_0x2be695['message']),this['operationType']=_0x301c5d,this['user']=_0x4043cf,Object['setPrototypeOf'](this,An['prototype']),this['customData']={'appName':_0x3d2a03['name'],'tenantId':_0x3d2a03['tenantId']??void 0x0,'_serverResponse':_0x2be695['customData']['_serverResponse'],'operationType':_0x301c5d};}static['_fromErrorAndOperation'](_0x5625bd,_0x547508,_0x20d312,_0x1005dc){return new An(_0x5625bd,_0x547508,_0x20d312,_0x1005dc);}}function Ba(_0x4eee09,_0x2b218e,_0x4a6d36,_0x33bf9b){return(_0x2b218e==='reauthenticate'?_0x4a6d36['_getReauthenticationResolver'](_0x4eee09):_0x4a6d36['_getIdTokenResponse'](_0x4eee09))['catch'](_0x4a603c=>{throw _0x4a603c['code']==='auth/multi-factor-auth-required'?An['_fromErrorAndOperation'](_0x4eee09,_0x4a603c,_0x2b218e,_0x33bf9b):_0x4a603c;});}async function Jf(_0x2feb2e,_0x4f2de7,_0x252e78=!0x1){const _0x14c0e0=await Ut(_0x2feb2e,_0x4f2de7['_linkToIdToken'](_0x2feb2e['auth'],await _0x2feb2e['getIdToken']()),_0x252e78);return Ve['_forOperation'](_0x2feb2e,'link',_0x14c0e0);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xf(_0x4d1edc,_0x3b8396,_0x39e3d4=!0x1){const {auth:_0x28ac73}=_0x4d1edc;if($(_0x28ac73['app']))return Promise['reject'](re(_0x28ac73));const _0xd48a5f='reauthenticate';try{const _0x12c96e=await Ut(_0x4d1edc,Ba(_0x28ac73,_0xd48a5f,_0x3b8396,_0x4d1edc),_0x39e3d4);m(_0x12c96e['idToken'],_0x28ac73,'internal-error');const _0x40c276=Ts(_0x12c96e['idToken']);m(_0x40c276,_0x28ac73,'internal-error');const {sub:_0x9e304b}=_0x40c276;return m(_0x4d1edc['uid']===_0x9e304b,_0x28ac73,'user-mismatch'),Ve['_forOperation'](_0x4d1edc,_0xd48a5f,_0x12c96e);}catch(_0x5ee4b2){throw(_0x5ee4b2==null?void 0x0:_0x5ee4b2['code'])==='auth/user-not-found'&&Q(_0x28ac73,'user-mismatch'),_0x5ee4b2;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x2707ae,_0x454ef9,_0x1cee6d=!0x1){if($(_0x2707ae['app']))return Promise['reject'](re(_0x2707ae));const _0xad1409='signIn',_0x34e316=await Ba(_0x2707ae,_0xad1409,_0x454ef9),_0x569919=await Ve['_fromIdTokenResponse'](_0x2707ae,_0xad1409,_0x34e316);return _0x1cee6d||await _0x2707ae['_updateCurrentUser'](_0x569919['user']),_0x569919;}async function Zf(_0x437e0e,_0x565000){return Va(qe(_0x437e0e),_0x565000);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0xa6dc61){const _0x16167=qe(_0xa6dc61);_0x16167['_getPasswordPolicyInternal']()&&await _0x16167['_updatePasswordPolicy']();}async function P_(_0x33d607,_0x1f00e0,_0x386a6b){if($(_0x33d607['app']))return Promise['reject'](re(_0x33d607));const _0x35273d=qe(_0x33d607),_0x44f9bd=await Di(_0x35273d,{'returnSecureToken':!0x0,'email':_0x1f00e0,'password':_0x386a6b,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Qf)['catch'](_0x4b3c6b=>{throw _0x4b3c6b['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x33d607),_0x4b3c6b;}),_0x285da6=await Ve['_fromIdTokenResponse'](_0x35273d,'signIn',_0x44f9bd);return await _0x35273d['_updateCurrentUser'](_0x285da6['user']),_0x285da6;}function O_(_0x4a96c8,_0x38558d,_0x3f1491){return $(_0x4a96c8['app'])?Promise['reject'](re(_0x4a96c8)):Zf(N(_0x4a96c8),pt['credential'](_0x38558d,_0x3f1491))['catch'](async _0x54a7cc=>{throw _0x54a7cc['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x4a96c8),_0x54a7cc;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function D_(_0x577a60,_0x47db28){return N(_0x577a60)['setPersistence'](_0x47db28);}function ep(_0xa10ceb,_0x114485,_0xfb720,_0x31390b){return N(_0xa10ceb)['onIdTokenChanged'](_0x114485,_0xfb720,_0x31390b);}function tp(_0x2cc780,_0x30475a,_0xccde43){return N(_0x2cc780)['beforeAuthStateChanged'](_0x30475a,_0xccde43);}function M_(_0x5b6476,_0x399dee,_0x4d1736,_0xfbcd00){return N(_0x5b6476)['onAuthStateChanged'](_0x399dee,_0x4d1736,_0xfbcd00);}function L_(_0x51175e){return N(_0x51175e)['signOut']();}const kn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x54eb4c,_0x1d1c79){this['storageRetriever']=_0x54eb4c,this['type']=_0x1d1c79;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](kn,'1'),this['storage']['removeItem'](kn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x3a6f5a,_0x173ff9){return this['storage']['setItem'](_0x3a6f5a,JSON['stringify'](_0x173ff9)),Promise['resolve']();}['_get'](_0x14cb7e){const _0x570153=this['storage']['getItem'](_0x14cb7e);return Promise['resolve'](_0x570153?JSON['parse'](_0x570153):null);}['_remove'](_0x58b69a){return this['storage']['removeItem'](_0x58b69a),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const np=0x3e8,ip=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0xb7935c,_0x9722a9)=>this['onStorageEvent'](_0xb7935c,_0x9722a9),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x41af5f){for(const _0xaba5a9 of Object['keys'](this['listeners'])){const _0x58a1b2=this['storage']['getItem'](_0xaba5a9),_0x4efcc1=this['localCache'][_0xaba5a9];_0x58a1b2!==_0x4efcc1&&_0x41af5f(_0xaba5a9,_0x4efcc1,_0x58a1b2);}}['onStorageEvent'](_0x1b434a,_0x18ed05=!0x1){if(!_0x1b434a['key']){this['forAllChangedKeys']((_0x2b6748,_0xeb5275,_0x201bef)=>{this['notifyListeners'](_0x2b6748,_0x201bef);});return;}const _0x4266ab=_0x1b434a['key'];_0x18ed05?this['detachListener']():this['stopPolling']();const _0x47de2b=()=>{const _0x515dda=this['storage']['getItem'](_0x4266ab);!_0x18ed05&&this['localCache'][_0x4266ab]===_0x515dda||this['notifyListeners'](_0x4266ab,_0x515dda);},_0x2e0a78=this['storage']['getItem'](_0x4266ab);Tf()&&_0x2e0a78!==_0x1b434a['newValue']&&_0x1b434a['newValue']!==_0x1b434a['oldValue']?setTimeout(_0x47de2b,ip):_0x47de2b();}['notifyListeners'](_0x425977,_0x1fee59){this['localCache'][_0x425977]=_0x1fee59;const _0x1156d5=this['listeners'][_0x425977];if(_0x1156d5){for(const _0x32a96b of Array['from'](_0x1156d5))_0x32a96b(_0x1fee59&&JSON['parse'](_0x1fee59));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x30c1f8,_0x14da02,_0x3e88c1)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x30c1f8,'oldValue':_0x14da02,'newValue':_0x3e88c1}),!0x0);});},np);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x4e7443,_0x82ab67){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x4e7443]||(this['listeners'][_0x4e7443]=new Set(),this['localCache'][_0x4e7443]=this['storage']['getItem'](_0x4e7443)),this['listeners'][_0x4e7443]['add'](_0x82ab67);}['_removeListener'](_0x519df3,_0x1cd773){this['listeners'][_0x519df3]&&(this['listeners'][_0x519df3]['delete'](_0x1cd773),this['listeners'][_0x519df3]['size']===0x0&&delete this['listeners'][_0x519df3]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0xd94857,_0x595d82){await super['_set'](_0xd94857,_0x595d82),this['localCache'][_0xd94857]=JSON['stringify'](_0x595d82);}async['_get'](_0x44e2f5){const _0x32c28c=await super['_get'](_0x44e2f5);return this['localCache'][_0x44e2f5]=JSON['stringify'](_0x32c28c),_0x32c28c;}async['_remove'](_0x10d4c6){await super['_remove'](_0x10d4c6),delete this['localCache'][_0x10d4c6];}}Ga['type']='LOCAL';const sp=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x35d8c8,_0xaa5a5f){}['_removeListener'](_0x36b9eb,_0x26d7d3){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rp(_0x1eefa6){return Promise['all'](_0x1eefa6['map'](async _0x34e4b5=>{try{return{'fulfilled':!0x0,'value':await _0x34e4b5};}catch(_0x57bcba){return{'fulfilled':!0x1,'reason':_0x57bcba};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kn{constructor(_0x14bf68){this['eventTarget']=_0x14bf68,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x54916b){const _0xbb1b65=this['receivers']['find'](_0xef0038=>_0xef0038['isListeningto'](_0x54916b));if(_0xbb1b65)return _0xbb1b65;const _0xecbfce=new Kn(_0x54916b);return this['receivers']['push'](_0xecbfce),_0xecbfce;}['isListeningto'](_0x440508){return this['eventTarget']===_0x440508;}async['handleEvent'](_0x5e15ca){const _0x46db23=_0x5e15ca,{eventId:_0x45836d,eventType:_0x414fc9,data:_0x130207}=_0x46db23['data'],_0x2ccf97=this['handlersMap'][_0x414fc9];if(!(_0x2ccf97!=null&&_0x2ccf97['size']))return;_0x46db23['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x45836d,'eventType':_0x414fc9});const _0x15947a=Array['from'](_0x2ccf97)['map'](async _0x38b6d2=>_0x38b6d2(_0x46db23['origin'],_0x130207)),_0x25a25c=await rp(_0x15947a);_0x46db23['ports'][0x0]['postMessage']({'status':'done','eventId':_0x45836d,'eventType':_0x414fc9,'response':_0x25a25c});}['_subscribe'](_0x3d2646,_0x29ff85){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x3d2646]||(this['handlersMap'][_0x3d2646]=new Set()),this['handlersMap'][_0x3d2646]['add'](_0x29ff85);}['_unsubscribe'](_0x29d1f1,_0x3c2b20){this['handlersMap'][_0x29d1f1]&&_0x3c2b20&&this['handlersMap'][_0x29d1f1]['delete'](_0x3c2b20),(!_0x3c2b20||this['handlersMap'][_0x29d1f1]['size']===0x0)&&delete this['handlersMap'][_0x29d1f1],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Kn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x3e916b='',_0x3c799c=0xa){let _0x25b8c5='';for(let _0x3e1c9b=0x0;_0x3e1c9b<_0x3c799c;_0x3e1c9b++)_0x25b8c5+=Math['floor'](Math['random']()*0xa);return _0x3e916b+_0x25b8c5;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class op{constructor(_0x3fb22a){this['target']=_0x3fb22a,this['handlers']=new Set();}['removeMessageHandler'](_0x1250a2){_0x1250a2['messageChannel']&&(_0x1250a2['messageChannel']['port1']['removeEventListener']('message',_0x1250a2['onMessage']),_0x1250a2['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x1250a2);}async['_send'](_0x33aa15,_0x350b4c,_0x420ce3=0x32){const _0x4f65e6=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x4f65e6)throw new Error('connection_unavailable');let _0x530314,_0x548b9;return new Promise((_0x78ee6,_0x4eb394)=>{const _0xc1651=As('',0x14);_0x4f65e6['port1']['start']();const _0x5cd546=setTimeout(()=>{_0x4eb394(new Error('unsupported_event'));},_0x420ce3);_0x548b9={'messageChannel':_0x4f65e6,'onMessage'(_0x19d7f5){const _0x12145e=_0x19d7f5;if(_0x12145e['data']['eventId']===_0xc1651)switch(_0x12145e['data']['status']){case'ack':clearTimeout(_0x5cd546),_0x530314=setTimeout(()=>{_0x4eb394(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x530314),_0x78ee6(_0x12145e['data']['response']);break;default:clearTimeout(_0x5cd546),clearTimeout(_0x530314),_0x4eb394(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x548b9),_0x4f65e6['port1']['addEventListener']('message',_0x548b9['onMessage']),this['target']['postMessage']({'eventType':_0x33aa15,'eventId':_0xc1651,'data':_0x350b4c},[_0x4f65e6['port2']]);})['finally'](()=>{_0x548b9&&this['removeMessageHandler'](_0x548b9);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function ap(_0x555218){Z()['location']['href']=_0x555218;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function cp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function lp(){var _0x471b3a;return((_0x471b3a=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x471b3a['controller'])||null;}function hp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',up=0x1,Nn='firebaseLocalStorage',Ya='fbase_key';class Xt{constructor(_0x51d0d2){this['request']=_0x51d0d2;}['toPromise'](){return new Promise((_0x2ce8f2,_0x270cc6)=>{this['request']['addEventListener']('success',()=>{_0x2ce8f2(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x270cc6(this['request']['error']);});});}}function Yn(_0x3c0754,_0x3e1b22){return _0x3c0754['transaction']([Nn],_0x3e1b22?'readwrite':'readonly')['objectStore'](Nn);}function dp(){const _0x3665b6=indexedDB['deleteDatabase'](Ka);return new Xt(_0x3665b6)['toPromise']();}function Mi(){const _0x4fc969=indexedDB['open'](Ka,up);return new Promise((_0x103f4a,_0x11b878)=>{_0x4fc969['addEventListener']('error',()=>{_0x11b878(_0x4fc969['error']);}),_0x4fc969['addEventListener']('upgradeneeded',()=>{const _0xb37c41=_0x4fc969['result'];try{_0xb37c41['createObjectStore'](Nn,{'keyPath':Ya});}catch(_0x1bcade){_0x11b878(_0x1bcade);}}),_0x4fc969['addEventListener']('success',async()=>{const _0x1af07a=_0x4fc969['result'];_0x1af07a['objectStoreNames']['contains'](Nn)?_0x103f4a(_0x1af07a):(_0x1af07a['close'](),await dp(),_0x103f4a(await Mi()));});});}async function Pr(_0x33e2f0,_0x4099d6,_0x41cdb1){const _0x1d1f84=Yn(_0x33e2f0,!0x0)['put']({[Ya]:_0x4099d6,'value':_0x41cdb1});return new Xt(_0x1d1f84)['toPromise']();}async function fp(_0x2f1130,_0x325245){const _0x3c08b4=Yn(_0x2f1130,!0x1)['get'](_0x325245),_0x24eed0=await new Xt(_0x3c08b4)['toPromise']();return _0x24eed0===void 0x0?null:_0x24eed0['value'];}function Or(_0x15a8b9,_0x16f10c){const _0x2b6fad=Yn(_0x15a8b9,!0x0)['delete'](_0x16f10c);return new Xt(_0x2b6fad)['toPromise']();}const pp=0x320,_p=0x3;class Qa{constructor(){this['type']='LOCAL',this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['db']?this['db']:(this['db']=await Mi(),this['db']);}async['_withRetries'](_0x4ef2a4){let _0x5f276a=0x0;for(;;)try{const _0x360ffc=await this['_openDb']();return await _0x4ef2a4(_0x360ffc);}catch(_0x56ad4a){if(_0x5f276a++>_p)throw _0x56ad4a;this['db']&&(this['db']['close'](),this['db']=void 0x0);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Kn['_getInstance'](hp()),this['receiver']['_subscribe']('keyChanged',async(_0x425d55,_0x492880)=>({'keyProcessed':(await this['_poll']())['includes'](_0x492880['key'])})),this['receiver']['_subscribe']('ping',async(_0x72987d,_0x1362fa)=>['keyChanged']);}async['initializeSender'](){var _0x7ca699,_0x4fd2d2;if(this['activeServiceWorker']=await cp(),!this['activeServiceWorker'])return;this['sender']=new op(this['activeServiceWorker']);const _0x1cf1f1=await this['sender']['_send']('ping',{},0x320);_0x1cf1f1&&(_0x7ca699=_0x1cf1f1[0x0])!=null&&_0x7ca699['fulfilled']&&(_0x4fd2d2=_0x1cf1f1[0x0])!=null&&_0x4fd2d2['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x503ddb){if(!(!this['sender']||!this['activeServiceWorker']||lp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x503ddb},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{if(!indexedDB)return!0x1;const _0x229b86=await Mi();return await Pr(_0x229b86,kn,'1'),await Or(_0x229b86,kn),!0x0;}catch{}return!0x1;}async['_withPendingWrite'](_0x3d592e){this['pendingWrites']++;try{await _0x3d592e();}finally{this['pendingWrites']--;}}async['_set'](_0x3132d0,_0x3bfc54){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x573d9e=>Pr(_0x573d9e,_0x3132d0,_0x3bfc54)),this['localCache'][_0x3132d0]=_0x3bfc54,this['notifyServiceWorker'](_0x3132d0)));}async['_get'](_0x16816f){const _0x50fd6c=await this['_withRetries'](_0x30caf1=>fp(_0x30caf1,_0x16816f));return this['localCache'][_0x16816f]=_0x50fd6c,_0x50fd6c;}async['_remove'](_0x19eab4){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x338884=>Or(_0x338884,_0x19eab4)),delete this['localCache'][_0x19eab4],this['notifyServiceWorker'](_0x19eab4)));}async['_poll'](){const _0x10f1c1=await this['_withRetries'](_0x2f0882=>{const _0x4b8a30=Yn(_0x2f0882,!0x1)['getAll']();return new Xt(_0x4b8a30)['toPromise']();});if(!_0x10f1c1)return[];if(this['pendingWrites']!==0x0)return[];const _0x5e5d60=[],_0x52e66d=new Set();if(_0x10f1c1['length']!==0x0){for(const {fbase_key:_0x2aab5e,value:_0x1b77b1}of _0x10f1c1)_0x52e66d['add'](_0x2aab5e),JSON['stringify'](this['localCache'][_0x2aab5e])!==JSON['stringify'](_0x1b77b1)&&(this['notifyListeners'](_0x2aab5e,_0x1b77b1),_0x5e5d60['push'](_0x2aab5e));}for(const _0x5ce52d of Object['keys'](this['localCache']))this['localCache'][_0x5ce52d]&&!_0x52e66d['has'](_0x5ce52d)&&(this['notifyListeners'](_0x5ce52d,null),_0x5e5d60['push'](_0x5ce52d));return _0x5e5d60;}['notifyListeners'](_0x363671,_0xc82dae){this['localCache'][_0x363671]=_0xc82dae;const _0x32db97=this['listeners'][_0x363671];if(_0x32db97){for(const _0x388de1 of Array['from'](_0x32db97))_0x388de1(_0xc82dae);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),pp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x2bc908,_0x614ffd){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x2bc908]||(this['listeners'][_0x2bc908]=new Set(),this['_get'](_0x2bc908)),this['listeners'][_0x2bc908]['add'](_0x614ffd);}['_removeListener'](_0x54b32e,_0x39b8d4){this['listeners'][_0x54b32e]&&(this['listeners'][_0x54b32e]['delete'](_0x39b8d4),this['listeners'][_0x54b32e]['size']===0x0&&delete this['listeners'][_0x54b32e]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Qa['type']='LOCAL';const gp=Qa;new Yt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function mp(_0x5e6114,_0xa5dea2){return _0xa5dea2?ie(_0xa5dea2):(m(_0x5e6114['_popupRedirectResolver'],_0x5e6114,'argument-error'),_0x5e6114['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x40478f){super('custom','custom'),this['params']=_0x40478f;}['_getIdTokenResponse'](_0x5d6904){return Xe(_0x5d6904,this['_buildIdpRequest']());}['_linkToIdToken'](_0x47f756,_0x2f7a3f){return Xe(_0x47f756,this['_buildIdpRequest'](_0x2f7a3f));}['_getReauthenticationResolver'](_0x1bf6d4){return Xe(_0x1bf6d4,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x1973b1){const _0x5cca2d={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x1973b1&&(_0x5cca2d['idToken']=_0x1973b1),_0x5cca2d;}}function yp(_0x5d6986){return Va(_0x5d6986['auth'],new ks(_0x5d6986),_0x5d6986['bypassAuthState']);}function vp(_0x50e64f){const {auth:_0x4c6c70,user:_0xed6949}=_0x50e64f;return m(_0xed6949,_0x4c6c70,'internal-error'),Xf(_0xed6949,new ks(_0x50e64f),_0x50e64f['bypassAuthState']);}async function Ep(_0x500bbb){const {auth:_0x167e4c,user:_0x1b5915}=_0x500bbb;return m(_0x1b5915,_0x167e4c,'internal-error'),Jf(_0x1b5915,new ks(_0x500bbb),_0x500bbb['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ja{constructor(_0x11814f,_0x3fb0c0,_0x27ffbf,_0x1c338e,_0x34d0f4=!0x1){this['auth']=_0x11814f,this['resolver']=_0x27ffbf,this['user']=_0x1c338e,this['bypassAuthState']=_0x34d0f4,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x3fb0c0)?_0x3fb0c0:[_0x3fb0c0];}['execute'](){return new Promise(async(_0x4c03cd,_0x8153ed)=>{this['pendingPromise']={'resolve':_0x4c03cd,'reject':_0x8153ed};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x17187d){this['reject'](_0x17187d);}});}async['onAuthEvent'](_0x51f169){const {urlResponse:_0x4551f3,sessionId:_0x5ef44b,postBody:_0x48eaf0,tenantId:_0x4e77d2,error:_0x1b1dc7,type:_0x14f19b}=_0x51f169;if(_0x1b1dc7){this['reject'](_0x1b1dc7);return;}const _0x1b86e6={'auth':this['auth'],'requestUri':_0x4551f3,'sessionId':_0x5ef44b,'tenantId':_0x4e77d2||void 0x0,'postBody':_0x48eaf0||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x14f19b)(_0x1b86e6));}catch(_0x391cf7){this['reject'](_0x391cf7);}}['onError'](_0x47363d){this['reject'](_0x47363d);}['getIdpTask'](_0x4a2635){switch(_0x4a2635){case'signInViaPopup':case'signInViaRedirect':return yp;case'linkViaPopup':case'linkViaRedirect':return Ep;case'reauthViaPopup':case'reauthViaRedirect':return vp;default:Q(this['auth'],'internal-error');}}['resolve'](_0x1376fd){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x1376fd),this['unregisterAndCleanUp']();}['reject'](_0x3c3d0c){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x3c3d0c),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ip=new Yt(0x7d0,0x2710);class Ke extends Ja{constructor(_0x3f5071,_0x81cedc,_0x16a396,_0x248f51,_0x2898ab){super(_0x3f5071,_0x81cedc,_0x248f51,_0x2898ab),this['provider']=_0x16a396,this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']&&Ke['currentPopupAction']['cancel'](),Ke['currentPopupAction']=this;}async['executeNotNull'](){const _0x2bc531=await this['execute']();return m(_0x2bc531,this['auth'],'internal-error'),_0x2bc531;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x80819e=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x80819e),this['authWindow']['associatedEvent']=_0x80819e,this['resolver']['_originValidation'](this['auth'])['catch'](_0x1ff456=>{this['reject'](_0x1ff456);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x334167=>{_0x334167||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x139743;return((_0x139743=this['authWindow'])==null?void 0x0:_0x139743['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']=null;}['pollUserCancellation'](){const _0x225a5a=()=>{var _0x2278c5,_0x3b107a;if((_0x3b107a=(_0x2278c5=this['authWindow'])==null?void 0x0:_0x2278c5['window'])!=null&&_0x3b107a['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x225a5a,Ip['get']());};_0x225a5a();}}Ke['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const wp='pendingRedirect',on=new Map();class Cp extends Ja{constructor(_0x31e6aa,_0x3e5caf,_0x502470=!0x1){super(_0x31e6aa,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x3e5caf,void 0x0,_0x502470),this['eventId']=null;}async['execute'](){let _0x32f326=on['get'](this['auth']['_key']());if(!_0x32f326){try{const _0x544a96=await Tp(this['resolver'],this['auth'])?await super['execute']():null;_0x32f326=()=>Promise['resolve'](_0x544a96);}catch(_0x3096ad){_0x32f326=()=>Promise['reject'](_0x3096ad);}on['set'](this['auth']['_key'](),_0x32f326);}return this['bypassAuthState']||on['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x32f326();}async['onAuthEvent'](_0x19716f){if(_0x19716f['type']==='signInViaRedirect')return super['onAuthEvent'](_0x19716f);if(_0x19716f['type']==='unknown'){this['resolve'](null);return;}if(_0x19716f['eventId']){const _0x4f34a9=await this['auth']['_redirectUserForId'](_0x19716f['eventId']);if(_0x4f34a9)return this['user']=_0x4f34a9,super['onAuthEvent'](_0x19716f);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Tp(_0x2ce7a6,_0x14fd80){const _0xde0c6a=Rp(_0x14fd80),_0x3c30f2=bp(_0x2ce7a6);if(!await _0x3c30f2['_isAvailable']())return!0x1;const _0x120093=await _0x3c30f2['_get'](_0xde0c6a)==='true';return await _0x3c30f2['_remove'](_0xde0c6a),_0x120093;}function Sp(_0x273214,_0x5906e4){on['set'](_0x273214['_key'](),_0x5906e4);}function bp(_0x4e5f7c){return ie(_0x4e5f7c['_redirectPersistence']);}function Rp(_0x3fc53d){return rn(wp,_0x3fc53d['config']['apiKey'],_0x3fc53d['name']);}async function Ap(_0x34fc09,_0xf1fe44,_0x3127a7=!0x1){if($(_0x34fc09['app']))return Promise['reject'](re(_0x34fc09));const _0x35ec1f=qe(_0x34fc09),_0x9214d0=mp(_0x35ec1f,_0xf1fe44),_0x38ad67=await new Cp(_0x35ec1f,_0x9214d0,_0x3127a7)['execute']();return _0x38ad67&&!_0x3127a7&&(delete _0x38ad67['user']['_redirectEventId'],await _0x35ec1f['_persistUserIfCurrent'](_0x38ad67['user']),await _0x35ec1f['_setRedirectUser'](null,_0xf1fe44)),_0x38ad67;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=0x258*0x3e8;class Np{constructor(_0x459803){this['auth']=_0x459803,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x191f6e){this['consumers']['add'](_0x191f6e),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x191f6e)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x191f6e),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x248c0d){this['consumers']['delete'](_0x248c0d);}['onEvent'](_0x3d7588){if(this['hasEventBeenHandled'](_0x3d7588))return!0x1;let _0x50ec78=!0x1;return this['consumers']['forEach'](_0x1e3d54=>{this['isEventForConsumer'](_0x3d7588,_0x1e3d54)&&(_0x50ec78=!0x0,this['sendToConsumer'](_0x3d7588,_0x1e3d54),this['saveEventToCache'](_0x3d7588));}),this['hasHandledPotentialRedirect']||!Pp(_0x3d7588)||(this['hasHandledPotentialRedirect']=!0x0,_0x50ec78||(this['queuedRedirectEvent']=_0x3d7588,_0x50ec78=!0x0)),_0x50ec78;}['sendToConsumer'](_0x875705,_0x1dd3ba){var _0x41612c;if(_0x875705['error']&&!Xa(_0x875705)){const _0x297a7a=((_0x41612c=_0x875705['error']['code'])==null?void 0x0:_0x41612c['split']('auth/')[0x1])||'internal-error';_0x1dd3ba['onError'](X(this['auth'],_0x297a7a));}else _0x1dd3ba['onAuthEvent'](_0x875705);}['isEventForConsumer'](_0x4730f4,_0x24cc23){const _0x14f69c=_0x24cc23['eventId']===null||!!_0x4730f4['eventId']&&_0x4730f4['eventId']===_0x24cc23['eventId'];return _0x24cc23['filter']['includes'](_0x4730f4['type'])&&_0x14f69c;}['hasEventBeenHandled'](_0x1da724){return Date['now']()-this['lastProcessedEventTime']>=kp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Dr(_0x1da724));}['saveEventToCache'](_0x53bbc9){this['cachedEventUids']['add'](Dr(_0x53bbc9)),this['lastProcessedEventTime']=Date['now']();}}function Dr(_0x2ed97d){return[_0x2ed97d['type'],_0x2ed97d['eventId'],_0x2ed97d['sessionId'],_0x2ed97d['tenantId']]['filter'](_0x2fd831=>_0x2fd831)['join']('-');}function Xa({type:_0x100852,error:_0x2fc6e2}){return _0x100852==='unknown'&&(_0x2fc6e2==null?void 0x0:_0x2fc6e2['code'])==='auth/no-auth-event';}function Pp(_0x483eed){switch(_0x483eed['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Xa(_0x483eed);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Op(_0x51b8dd,_0x73c8de={}){return Ae(_0x51b8dd,'GET','/v1/projects',_0x73c8de);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Mp=/^https?/;async function Lp(_0x541863){if(_0x541863['config']['emulator'])return;const {authorizedDomains:_0x200c0e}=await Op(_0x541863);for(const _0x189f3a of _0x200c0e)try{if(xp(_0x189f3a))return;}catch{}Q(_0x541863,'unauthorized-domain');}function xp(_0x4ca218){const _0x141f8e=Pi(),{protocol:_0x34f1fd,hostname:_0x255d77}=new URL(_0x141f8e);if(_0x4ca218['startsWith']('chrome-extension://')){const _0x40558b=new URL(_0x4ca218);return _0x40558b['hostname']===''&&_0x255d77===''?_0x34f1fd==='chrome-extension:'&&_0x4ca218['replace']('chrome-extension://','')===_0x141f8e['replace']('chrome-extension://',''):_0x34f1fd==='chrome-extension:'&&_0x40558b['hostname']===_0x255d77;}if(!Mp['test'](_0x34f1fd))return!0x1;if(Dp['test'](_0x4ca218))return _0x255d77===_0x4ca218;const _0x3cd9b7=_0x4ca218['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x3cd9b7+'|'+_0x3cd9b7+')$','i')['test'](_0x255d77);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Fp=new Yt(0x7530,0xea60);function Mr(){const _0x50a65f=Z()['___jsl'];if(_0x50a65f!=null&&_0x50a65f['H']){for(const _0x49b58e of Object['keys'](_0x50a65f['H']))if(_0x50a65f['H'][_0x49b58e]['r']=_0x50a65f['H'][_0x49b58e]['r']||[],_0x50a65f['H'][_0x49b58e]['L']=_0x50a65f['H'][_0x49b58e]['L']||[],_0x50a65f['H'][_0x49b58e]['r']=[..._0x50a65f['H'][_0x49b58e]['L']],_0x50a65f['CP']){for(let _0x157d36=0x0;_0x157d36<_0x50a65f['CP']['length'];_0x157d36++)_0x50a65f['CP'][_0x157d36]=null;}}}function Up(_0x131897){return new Promise((_0x408814,_0x30a1aa)=>{var _0x348420,_0x25008f,_0x1bc3ae;function _0x1a52de(){Mr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x408814(gapi['iframes']['getContext']());},'ontimeout':()=>{Mr(),_0x30a1aa(X(_0x131897,'network-request-failed'));},'timeout':Fp['get']()});}if((_0x25008f=(_0x348420=Z()['gapi'])==null?void 0x0:_0x348420['iframes'])!=null&&_0x25008f['Iframe'])_0x408814(gapi['iframes']['getContext']());else{if((_0x1bc3ae=Z()['gapi'])!=null&&_0x1bc3ae['load'])_0x1a52de();else{const _0xe2cd58=Df('iframefcb');return Z()[_0xe2cd58]=()=>{gapi['load']?_0x1a52de():_0x30a1aa(X(_0x131897,'network-request-failed'));},xa(Of()+'?onload='+_0xe2cd58)['catch'](_0x4e4f67=>_0x30a1aa(_0x4e4f67));}}})['catch'](_0x513e58=>{throw an=null,_0x513e58;});}let an=null;function Wp(_0x5ce712){return an=an||Up(_0x5ce712),an;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Yt(0x1388,0x3a98),Vp='__/auth/iframe',Hp='emulator/auth/iframe',$p={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Gp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function qp(_0x4c3257){const _0x1d6590=_0x4c3257['config'];m(_0x1d6590['authDomain'],_0x4c3257,'auth-domain-config-required');const _0x1d6932=_0x1d6590['emulator']?Cs(_0x1d6590,Hp):'https://'+_0x4c3257['config']['authDomain']+'/'+Vp,_0x469ff3={'apiKey':_0x1d6590['apiKey'],'appName':_0x4c3257['name'],'v':lt},_0x43d21b=Gp['get'](_0x4c3257['config']['apiHost']);_0x43d21b&&(_0x469ff3['eid']=_0x43d21b);const _0x17d9cb=_0x4c3257['_getFrameworks']();return _0x17d9cb['length']&&(_0x469ff3['fw']=_0x17d9cb['join'](',')),_0x1d6932+'?'+ct(_0x469ff3)['slice'](0x1);}async function zp(_0x2d1ea9){const _0x38de45=await Wp(_0x2d1ea9),_0x41c7a2=Z()['gapi'];return m(_0x41c7a2,_0x2d1ea9,'internal-error'),_0x38de45['open']({'where':document['body'],'url':qp(_0x2d1ea9),'messageHandlersFilter':_0x41c7a2['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':$p,'dontclear':!0x0},_0x328e7c=>new Promise(async(_0x2b6bc3,_0x128bbf)=>{await _0x328e7c['restyle']({'setHideOnLeave':!0x1});const _0x243153=X(_0x2d1ea9,'network-request-failed'),_0x53dadc=Z()['setTimeout'](()=>{_0x128bbf(_0x243153);},Bp['get']());function _0x168e8c(){Z()['clearTimeout'](_0x53dadc),_0x2b6bc3(_0x328e7c);}_0x328e7c['ping'](_0x168e8c)['then'](_0x168e8c,()=>{_0x128bbf(_0x243153);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Kp=0x1f4,Yp=0x258,Qp='_blank',Jp='http://localhost';class Lr{constructor(_0x38d2e6){this['window']=_0x38d2e6,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Xp(_0x42e35d,_0x4dbadd,_0x324f48,_0x2269b5=Kp,_0x118f69=Yp){const _0x4b592b=Math['max']((window['screen']['availHeight']-_0x118f69)/0x2,0x0)['toString'](),_0x17b2c5=Math['max']((window['screen']['availWidth']-_0x2269b5)/0x2,0x0)['toString']();let _0x34c432='';const _0x34c671={...jp,'width':_0x2269b5['toString'](),'height':_0x118f69['toString'](),'top':_0x4b592b,'left':_0x17b2c5},_0x5aa129=W()['toLowerCase']();_0x324f48&&(_0x34c432=ka(_0x5aa129)?Qp:_0x324f48),Ra(_0x5aa129)&&(_0x4dbadd=_0x4dbadd||Jp,_0x34c671['scrollbars']='yes');const _0x288014=Object['entries'](_0x34c671)['reduce']((_0x2b169c,[_0x237d1c,_0x25e349])=>''+_0x2b169c+_0x237d1c+'='+_0x25e349+',','');if(Cf(_0x5aa129)&&_0x34c432!=='_self')return Zp(_0x4dbadd||'',_0x34c432),new Lr(null);const _0x53f3ac=window['open'](_0x4dbadd||'',_0x34c432,_0x288014);m(_0x53f3ac,_0x42e35d,'popup-blocked');try{_0x53f3ac['focus']();}catch{}return new Lr(_0x53f3ac);}function Zp(_0x535ef7,_0x7abddd){const _0x365d0b=document['createElement']('a');_0x365d0b['href']=_0x535ef7,_0x365d0b['target']=_0x7abddd;const _0x1675a1=document['createEvent']('MouseEvent');_0x1675a1['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x365d0b['dispatchEvent'](_0x1675a1);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const e_='__/auth/handler',t_='emulator/auth/handler',n_=encodeURIComponent('fac');async function xr(_0x5c17e0,_0x426e22,_0x3617e3,_0x33f9e4,_0x1009ec,_0x3c7a2f){m(_0x5c17e0['config']['authDomain'],_0x5c17e0,'auth-domain-config-required'),m(_0x5c17e0['config']['apiKey'],_0x5c17e0,'invalid-api-key');const _0x1ce288={'apiKey':_0x5c17e0['config']['apiKey'],'appName':_0x5c17e0['name'],'authType':_0x3617e3,'redirectUrl':_0x33f9e4,'v':lt,'eventId':_0x1009ec};if(_0x426e22 instanceof Wa){_0x426e22['setDefaultLanguage'](_0x5c17e0['languageCode']),_0x1ce288['providerId']=_0x426e22['providerId']||'',ui(_0x426e22['getCustomParameters']())||(_0x1ce288['customParameters']=JSON['stringify'](_0x426e22['getCustomParameters']()));for(const [_0x34d297,_0x54832d]of Object['entries']({}))_0x1ce288[_0x34d297]=_0x54832d;}if(_0x426e22 instanceof Jt){const _0x35aa6f=_0x426e22['getScopes']()['filter'](_0x24f94f=>_0x24f94f!=='');_0x35aa6f['length']>0x0&&(_0x1ce288['scopes']=_0x35aa6f['join'](','));}_0x5c17e0['tenantId']&&(_0x1ce288['tid']=_0x5c17e0['tenantId']);const _0x4b76c1=_0x1ce288;for(const _0xa239eb of Object['keys'](_0x4b76c1))_0x4b76c1[_0xa239eb]===void 0x0&&delete _0x4b76c1[_0xa239eb];const _0x2dfe2f=await _0x5c17e0['_getAppCheckToken'](),_0x465ebe=_0x2dfe2f?'#'+n_+'='+encodeURIComponent(_0x2dfe2f):'';return i_(_0x5c17e0)+'?'+ct(_0x4b76c1)['slice'](0x1)+_0x465ebe;}function i_({config:_0x11d2c7}){return _0x11d2c7['emulator']?Cs(_0x11d2c7,t_):'https://'+_0x11d2c7['authDomain']+'/'+e_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const hi='webStorageSupport';class s_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Ap,this['_overrideRedirectResult']=Sp;}async['_openPopup'](_0x35a3e4,_0xd14fd1,_0x157fd6,_0x2a4174){var _0x406e89;ce((_0x406e89=this['eventManagers'][_0x35a3e4['_key']()])==null?void 0x0:_0x406e89['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x305b85=await xr(_0x35a3e4,_0xd14fd1,_0x157fd6,Pi(),_0x2a4174);return Xp(_0x35a3e4,_0x305b85,As());}async['_openRedirect'](_0xe27784,_0x47f682,_0x26ba57,_0x2a4457){await this['_originValidation'](_0xe27784);const _0x496da7=await xr(_0xe27784,_0x47f682,_0x26ba57,Pi(),_0x2a4457);return ap(_0x496da7),new Promise(()=>{});}['_initialize'](_0x592eac){const _0x2caf78=_0x592eac['_key']();if(this['eventManagers'][_0x2caf78]){const {manager:_0x9c2857,promise:_0x4df613}=this['eventManagers'][_0x2caf78];return _0x9c2857?Promise['resolve'](_0x9c2857):(ce(_0x4df613,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x4df613);}const _0x2f9dce=this['initAndGetManager'](_0x592eac);return this['eventManagers'][_0x2caf78]={'promise':_0x2f9dce},_0x2f9dce['catch'](()=>{delete this['eventManagers'][_0x2caf78];}),_0x2f9dce;}async['initAndGetManager'](_0x30c803){const _0xf75299=await zp(_0x30c803),_0x35aa68=new Np(_0x30c803);return _0xf75299['register']('authEvent',_0x1555f6=>(m(_0x1555f6==null?void 0x0:_0x1555f6['authEvent'],_0x30c803,'invalid-auth-event'),{'status':_0x35aa68['onEvent'](_0x1555f6['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x30c803['_key']()]={'manager':_0x35aa68},this['iframes'][_0x30c803['_key']()]=_0xf75299,_0x35aa68;}['_isIframeWebStorageSupported'](_0x24bf49,_0x24caaf){this['iframes'][_0x24bf49['_key']()]['send'](hi,{'type':hi},_0x21a492=>{var _0x59ad81;const _0x2f0c95=(_0x59ad81=_0x21a492==null?void 0x0:_0x21a492[0x0])==null?void 0x0:_0x59ad81[hi];_0x2f0c95!==void 0x0&&_0x24caaf(!!_0x2f0c95),Q(_0x24bf49,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x4441ed){const _0x154c76=_0x4441ed['_key']();return this['originValidationPromises'][_0x154c76]||(this['originValidationPromises'][_0x154c76]=Lp(_0x4441ed)),this['originValidationPromises'][_0x154c76];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const r_=s_;var Fr='@firebase/auth',Ur='1.11.1';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class o_{constructor(_0x1f9541){this['auth']=_0x1f9541,this['internalListeners']=new Map();}['getUid'](){var _0x1d4791;return this['assertAuthConfigured'](),((_0x1d4791=this['auth']['currentUser'])==null?void 0x0:_0x1d4791['uid'])||null;}async['getToken'](_0x420493){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x420493)}:null;}['addAuthTokenListener'](_0x3a6a2c){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x3a6a2c))return;const _0x17460a=this['auth']['onIdTokenChanged'](_0x5cad93=>{_0x3a6a2c((_0x5cad93==null?void 0x0:_0x5cad93['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x3a6a2c,_0x17460a),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x39a10f){this['assertAuthConfigured']();const _0x1dde18=this['internalListeners']['get'](_0x39a10f);_0x1dde18&&(this['internalListeners']['delete'](_0x39a10f),_0x1dde18(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function a_(_0xbc59b8){switch(_0xbc59b8){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function c_(_0x41cfcb){Ze(new Le('auth',(_0x14e1ef,{options:_0x4caba4})=>{const _0xd4a2a6=_0x14e1ef['getProvider']('app')['getImmediate'](),_0xba4562=_0x14e1ef['getProvider']('heartbeat'),_0x51dc6f=_0x14e1ef['getProvider']('app-check-internal'),{apiKey:_0x31d874,authDomain:_0x5aae8a}=_0xd4a2a6['options'];m(_0x31d874&&!_0x31d874['includes'](':'),'invalid-api-key',{'appName':_0xd4a2a6['name']});const _0x2f9aba={'apiKey':_0x31d874,'authDomain':_0x5aae8a,'clientPlatform':_0x41cfcb,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x41cfcb)},_0x542070=new kf(_0xd4a2a6,_0xba4562,_0x51dc6f,_0x2f9aba);return Wf(_0x542070,_0x4caba4),_0x542070;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x374ec2,_0x562cbc,_0x3d3f48)=>{_0x374ec2['getProvider']('auth-internal')['initialize']();})),Ze(new Le('auth-internal',_0x51eb18=>{const _0x4d5525=qe(_0x51eb18['getProvider']('auth')['getImmediate']());return(_0x5d33e6=>new o_(_0x5d33e6))(_0x4d5525);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Fr,Ur,a_(_0x41cfcb)),me(Fr,Ur,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const l_=0x12c,h_=zr('authIdTokenMaxAge')||l_;let Wr=null;const u_=_0x59a6ce=>async _0x14a6db=>{const _0x2353ee=_0x14a6db&&await _0x14a6db['getIdTokenResult'](),_0x17f8ba=_0x2353ee&&(new Date()['getTime']()-Date['parse'](_0x2353ee['issuedAtTime']))/0x3e8;if(_0x17f8ba&&_0x17f8ba>h_)return;const _0x23e7cf=_0x2353ee==null?void 0x0:_0x2353ee['token'];Wr!==_0x23e7cf&&(Wr=_0x23e7cf,await fetch(_0x59a6ce,{'method':_0x23e7cf?'POST':'DELETE','headers':_0x23e7cf?{'Authorization':'Bearer\x20'+_0x23e7cf}:{}}));};function x_(_0x21ceb2=Zr()){const _0x218bc4=Bi(_0x21ceb2,'auth');if(_0x218bc4['isInitialized']())return _0x218bc4['getImmediate']();const _0x36c851=Uf(_0x21ceb2,{'popupRedirectResolver':r_,'persistence':[gp,sp,za]}),_0x4987c5=zr('authTokenSyncURL');if(_0x4987c5&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x399e58=new URL(_0x4987c5,location['origin']);if(location['origin']===_0x399e58['origin']){const _0xe95d17=u_(_0x399e58['toString']());tp(_0x36c851,_0xe95d17,()=>_0xe95d17(_0x36c851['currentUser'])),ep(_0x36c851,_0x3413f7=>_0xe95d17(_0x3413f7));}}const _0x1abe96=Gr('auth');return _0x1abe96&&Bf(_0x36c851,'http://'+_0x1abe96),_0x36c851;}function d_(){var _0x4fab6c;return((_0x4fab6c=document['getElementsByTagName']('head'))==null?void 0x0:_0x4fab6c[0x0])??document;}Nf({'loadJS'(_0x4c2bc1){return new Promise((_0x26fc83,_0x223380)=>{const _0x221b2f=document['createElement']('script');_0x221b2f['setAttribute']('src',_0x4c2bc1),_0x221b2f['onload']=_0x26fc83,_0x221b2f['onerror']=_0x4952fd=>{const _0x34d571=X('internal-error');_0x34d571['customData']=_0x4952fd,_0x223380(_0x34d571);},_0x221b2f['type']='text/javascript',_0x221b2f['charset']='UTF-8',d_()['appendChild'](_0x221b2f);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),c_('Browser');export{P_ as A,L_ as B,C_ as C,x_ as a,sp as b,O_ as c,f_ as d,p_ as e,Zr as f,b_ as g,y_ as h,Sl as i,k_ as j,T_ as k,Ft as l,Ud as m,M_ as n,w_ as o,g_ as p,S_ as q,__ as r,D_ as s,R_ as t,m_ as u,A_ as v,N_ as w,E_ as x,v_ as y,I_ as z};