import{c as a19_0x52ebd1}from'./index-XuAk6kCc.js';/**
 * @license lucide-react v0.556.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */
const o=[['path',{'d':'M16\x207h6v6','key':'box55l'}],['path',{'d':'m22\x207-8.5\x208.5-5-5L2\x2017','key':'1t1m79'}]],n=a19_0x52ebd1('trending-up',o);export{n as T};