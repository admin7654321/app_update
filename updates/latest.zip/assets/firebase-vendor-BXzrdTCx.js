const Za=()=>{};var Ns={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Br={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x5c2676,_0x8fe09f){if(!_0x5c2676)throw rt(_0x8fe09f);},rt=function(_0x2b40e6){return new Error('Firebase\x20Database\x20('+Br['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x2b40e6);},Vr=function(_0x3d8694){const _0x504d26=[];let _0x31a1e0=0x0;for(let _0x1e54d4=0x0;_0x1e54d4<_0x3d8694['length'];_0x1e54d4++){let _0x4e2d36=_0x3d8694['charCodeAt'](_0x1e54d4);_0x4e2d36<0x80?_0x504d26[_0x31a1e0++]=_0x4e2d36:_0x4e2d36<0x800?(_0x504d26[_0x31a1e0++]=_0x4e2d36>>0x6|0xc0,_0x504d26[_0x31a1e0++]=_0x4e2d36&0x3f|0x80):(_0x4e2d36&0xfc00)===0xd800&&_0x1e54d4+0x1<_0x3d8694['length']&&(_0x3d8694['charCodeAt'](_0x1e54d4+0x1)&0xfc00)===0xdc00?(_0x4e2d36=0x10000+((_0x4e2d36&0x3ff)<<0xa)+(_0x3d8694['charCodeAt'](++_0x1e54d4)&0x3ff),_0x504d26[_0x31a1e0++]=_0x4e2d36>>0x12|0xf0,_0x504d26[_0x31a1e0++]=_0x4e2d36>>0xc&0x3f|0x80,_0x504d26[_0x31a1e0++]=_0x4e2d36>>0x6&0x3f|0x80,_0x504d26[_0x31a1e0++]=_0x4e2d36&0x3f|0x80):(_0x504d26[_0x31a1e0++]=_0x4e2d36>>0xc|0xe0,_0x504d26[_0x31a1e0++]=_0x4e2d36>>0x6&0x3f|0x80,_0x504d26[_0x31a1e0++]=_0x4e2d36&0x3f|0x80);}return _0x504d26;},ec=function(_0x236269){const _0x59bdfd=[];let _0xf2f018=0x0,_0x16a69d=0x0;for(;_0xf2f018<_0x236269['length'];){const _0x562e02=_0x236269[_0xf2f018++];if(_0x562e02<0x80)_0x59bdfd[_0x16a69d++]=String['fromCharCode'](_0x562e02);else{if(_0x562e02>0xbf&&_0x562e02<0xe0){const _0x54767b=_0x236269[_0xf2f018++];_0x59bdfd[_0x16a69d++]=String['fromCharCode']((_0x562e02&0x1f)<<0x6|_0x54767b&0x3f);}else{if(_0x562e02>0xef&&_0x562e02<0x16d){const _0x153a33=_0x236269[_0xf2f018++],_0x17057f=_0x236269[_0xf2f018++],_0x3e8beb=_0x236269[_0xf2f018++],_0x39a199=((_0x562e02&0x7)<<0x12|(_0x153a33&0x3f)<<0xc|(_0x17057f&0x3f)<<0x6|_0x3e8beb&0x3f)-0x10000;_0x59bdfd[_0x16a69d++]=String['fromCharCode'](0xd800+(_0x39a199>>0xa)),_0x59bdfd[_0x16a69d++]=String['fromCharCode'](0xdc00+(_0x39a199&0x3ff));}else{const _0x2cfa66=_0x236269[_0xf2f018++],_0x3d9766=_0x236269[_0xf2f018++];_0x59bdfd[_0x16a69d++]=String['fromCharCode']((_0x562e02&0xf)<<0xc|(_0x2cfa66&0x3f)<<0x6|_0x3d9766&0x3f);}}}}return _0x59bdfd['join']('');},Li={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x963730,_0x13788d){if(!Array['isArray'](_0x963730))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x554cce=_0x13788d?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x120f56=[];for(let _0x2ae69b=0x0;_0x2ae69b<_0x963730['length'];_0x2ae69b+=0x3){const _0x556429=_0x963730[_0x2ae69b],_0x34f800=_0x2ae69b+0x1<_0x963730['length'],_0x42c13b=_0x34f800?_0x963730[_0x2ae69b+0x1]:0x0,_0x1aac23=_0x2ae69b+0x2<_0x963730['length'],_0x54808f=_0x1aac23?_0x963730[_0x2ae69b+0x2]:0x0,_0x2840b8=_0x556429>>0x2,_0x1cc715=(_0x556429&0x3)<<0x4|_0x42c13b>>0x4;let _0x5fe696=(_0x42c13b&0xf)<<0x2|_0x54808f>>0x6,_0x5907a0=_0x54808f&0x3f;_0x1aac23||(_0x5907a0=0x40,_0x34f800||(_0x5fe696=0x40)),_0x120f56['push'](_0x554cce[_0x2840b8],_0x554cce[_0x1cc715],_0x554cce[_0x5fe696],_0x554cce[_0x5907a0]);}return _0x120f56['join']('');},'encodeString'(_0x13a12e,_0xa09e0a){return this['HAS_NATIVE_SUPPORT']&&!_0xa09e0a?btoa(_0x13a12e):this['encodeByteArray'](Vr(_0x13a12e),_0xa09e0a);},'decodeString'(_0x41b42b,_0x42a56e){return this['HAS_NATIVE_SUPPORT']&&!_0x42a56e?atob(_0x41b42b):ec(this['decodeStringToByteArray'](_0x41b42b,_0x42a56e));},'decodeStringToByteArray'(_0xf9a570,_0x33bec8){this['init_']();const _0x3414ba=_0x33bec8?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x3792d8=[];for(let _0x5baa4a=0x0;_0x5baa4a<_0xf9a570['length'];){const _0xa395b=_0x3414ba[_0xf9a570['charAt'](_0x5baa4a++)],_0x437343=_0x5baa4a<_0xf9a570['length']?_0x3414ba[_0xf9a570['charAt'](_0x5baa4a)]:0x0;++_0x5baa4a;const _0x49198b=_0x5baa4a<_0xf9a570['length']?_0x3414ba[_0xf9a570['charAt'](_0x5baa4a)]:0x40;++_0x5baa4a;const _0xf5a530=_0x5baa4a<_0xf9a570['length']?_0x3414ba[_0xf9a570['charAt'](_0x5baa4a)]:0x40;if(++_0x5baa4a,_0xa395b==null||_0x437343==null||_0x49198b==null||_0xf5a530==null)throw new tc();const _0x50da7c=_0xa395b<<0x2|_0x437343>>0x4;if(_0x3792d8['push'](_0x50da7c),_0x49198b!==0x40){const _0x7c3521=_0x437343<<0x4&0xf0|_0x49198b>>0x2;if(_0x3792d8['push'](_0x7c3521),_0xf5a530!==0x40){const _0x529f41=_0x49198b<<0x6&0xc0|_0xf5a530;_0x3792d8['push'](_0x529f41);}}}return _0x3792d8;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x23bec8=0x0;_0x23bec8<this['ENCODED_VALS']['length'];_0x23bec8++)this['byteToCharMap_'][_0x23bec8]=this['ENCODED_VALS']['charAt'](_0x23bec8),this['charToByteMap_'][this['byteToCharMap_'][_0x23bec8]]=_0x23bec8,this['byteToCharMapWebSafe_'][_0x23bec8]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x23bec8),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x23bec8]]=_0x23bec8,_0x23bec8>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x23bec8)]=_0x23bec8,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x23bec8)]=_0x23bec8);}}};class tc extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Hr=function(_0x29c066){const _0x2ab5c5=Vr(_0x29c066);return Li['encodeByteArray'](_0x2ab5c5,!0x0);},cn=function(_0x437bcb){return Hr(_0x437bcb)['replace'](/\./g,'');},ln=function(_0x3a0a15){try{return Li['decodeString'](_0x3a0a15,!0x0);}catch(_0x50622d){console['error']('base64Decode\x20failed:\x20',_0x50622d);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nc(_0x238df6){return $r(void 0x0,_0x238df6);}function $r(_0x4af550,_0x50dd38){if(!(_0x50dd38 instanceof Object))return _0x50dd38;switch(_0x50dd38['constructor']){case Date:const _0x459a31=_0x50dd38;return new Date(_0x459a31['getTime']());case Object:_0x4af550===void 0x0&&(_0x4af550={});break;case Array:_0x4af550=[];break;default:return _0x50dd38;}for(const _0xa5ffdd in _0x50dd38)!_0x50dd38['hasOwnProperty'](_0xa5ffdd)||!ic(_0xa5ffdd)||(_0x4af550[_0xa5ffdd]=$r(_0x4af550[_0xa5ffdd],_0x50dd38[_0xa5ffdd]));return _0x4af550;}function ic(_0x5b8c1a){return _0x5b8c1a!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rc=()=>sc()['__FIREBASE_DEFAULTS__'],oc=()=>{if(typeof process>'u'||typeof Ns>'u')return;const _0x36e718=Ns['__FIREBASE_DEFAULTS__'];if(_0x36e718)return JSON['parse'](_0x36e718);},ac=()=>{if(typeof document>'u')return;let _0x3a4008;try{_0x3a4008=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x2c1d04=_0x3a4008&&ln(_0x3a4008[0x1]);return _0x2c1d04&&JSON['parse'](_0x2c1d04);},xi=()=>{try{return Za()||rc()||oc()||ac();}catch(_0x355c16){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x355c16);return;}},Gr=_0x266fb4=>{var _0x211f87,_0x52f8d1;return(_0x52f8d1=(_0x211f87=xi())==null?void 0x0:_0x211f87['emulatorHosts'])==null?void 0x0:_0x52f8d1[_0x266fb4];},cc=_0x554bd6=>{const _0x2af1ba=Gr(_0x554bd6);if(!_0x2af1ba)return;const _0x89d6d0=_0x2af1ba['lastIndexOf'](':');if(_0x89d6d0<=0x0||_0x89d6d0+0x1===_0x2af1ba['length'])throw new Error('Invalid\x20host\x20'+_0x2af1ba+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x377cc9=parseInt(_0x2af1ba['substring'](_0x89d6d0+0x1),0xa);return _0x2af1ba[0x0]==='['?[_0x2af1ba['substring'](0x1,_0x89d6d0-0x1),_0x377cc9]:[_0x2af1ba['substring'](0x0,_0x89d6d0),_0x377cc9];},qr=()=>{var _0x593dd9;return(_0x593dd9=xi())==null?void 0x0:_0x593dd9['config'];},zr=_0x211bdc=>{var _0x4646c8;return(_0x4646c8=xi())==null?void 0x0:_0x4646c8['_'+_0x211bdc];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x304472,_0x46ff11)=>{this['resolve']=_0x304472,this['reject']=_0x46ff11;});}['wrapCallback'](_0x1062af){return(_0x31e449,_0x55deae)=>{_0x31e449?this['reject'](_0x31e449):this['resolve'](_0x55deae),typeof _0x1062af=='function'&&(this['promise']['catch'](()=>{}),_0x1062af['length']===0x1?_0x1062af(_0x31e449):_0x1062af(_0x31e449,_0x55deae));};}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x49cb95){try{return(_0x49cb95['startsWith']('http://')||_0x49cb95['startsWith']('https://')?new URL(_0x49cb95)['hostname']:_0x49cb95)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x7d9e7b){return(await fetch(_0x7d9e7b,{'credentials':'include'}))['ok'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function lc(_0x19462c,_0x2a8bba){if(_0x19462c['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x26a2c1={'alg':'none','type':'JWT'},_0x241dd4=_0x2a8bba||'demo-project',_0x3e9739=_0x19462c['iat']||0x0,_0x2e3568=_0x19462c['sub']||_0x19462c['user_id'];if(!_0x2e3568)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x282cd1={'iss':'https://securetoken.google.com/'+_0x241dd4,'aud':_0x241dd4,'iat':_0x3e9739,'exp':_0x3e9739+0xe10,'auth_time':_0x3e9739,'sub':_0x2e3568,'user_id':_0x2e3568,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x19462c};return[cn(JSON['stringify'](_0x26a2c1)),cn(JSON['stringify'](_0x282cd1)),'']['join']('.');}const It={};function hc(){const _0x5af57f={'prod':[],'emulator':[]};for(const _0x5da40c of Object['keys'](It))It[_0x5da40c]?_0x5af57f['emulator']['push'](_0x5da40c):_0x5af57f['prod']['push'](_0x5da40c);return _0x5af57f;}function uc(_0x23cf82){let _0x37ad40=document['getElementById'](_0x23cf82),_0x12f254=!0x1;return _0x37ad40||(_0x37ad40=document['createElement']('div'),_0x37ad40['setAttribute']('id',_0x23cf82),_0x12f254=!0x0),{'created':_0x12f254,'element':_0x37ad40};}let Ps=!0x1;function Kr(_0x18111d,_0xcada81){if(typeof window>'u'||typeof document>'u'||!at(window['location']['host'])||It[_0x18111d]===_0xcada81||It[_0x18111d]||Ps)return;It[_0x18111d]=_0xcada81;function _0x3fc9e3(_0xedb758){return'__firebase__banner__'+_0xedb758;}const _0x2c7b37='__firebase__banner',_0x3daf77=hc()['prod']['length']>0x0;function _0x56ba23(){const _0x4895e5=document['getElementById'](_0x2c7b37);_0x4895e5&&_0x4895e5['remove']();}function _0x438981(_0x59b573){_0x59b573['style']['display']='flex',_0x59b573['style']['background']='#7faaf0',_0x59b573['style']['position']='fixed',_0x59b573['style']['bottom']='5px',_0x59b573['style']['left']='5px',_0x59b573['style']['padding']='.5em',_0x59b573['style']['borderRadius']='5px',_0x59b573['style']['alignItems']='center';}function _0x5e0d20(_0x2578b3,_0x4f4298){_0x2578b3['setAttribute']('width','24'),_0x2578b3['setAttribute']('id',_0x4f4298),_0x2578b3['setAttribute']('height','24'),_0x2578b3['setAttribute']('viewBox','0\x200\x2024\x2024'),_0x2578b3['setAttribute']('fill','none'),_0x2578b3['style']['marginLeft']='-6px';}function _0x4a4786(){const _0x240d1a=document['createElement']('span');return _0x240d1a['style']['cursor']='pointer',_0x240d1a['style']['marginLeft']='16px',_0x240d1a['style']['fontSize']='24px',_0x240d1a['innerHTML']='\x20&times;',_0x240d1a['onclick']=()=>{Ps=!0x0,_0x56ba23();},_0x240d1a;}function _0x23cd59(_0x3c583b,_0x173366){_0x3c583b['setAttribute']('id',_0x173366),_0x3c583b['innerText']='Learn\x20more',_0x3c583b['href']='https://firebase.google.com/docs/studio/preview-apps#preview-backend',_0x3c583b['setAttribute']('target','__blank'),_0x3c583b['style']['paddingLeft']='5px',_0x3c583b['style']['textDecoration']='underline';}function _0xd4a4af(){const _0x4dd251=uc(_0x2c7b37),_0x4b1e06=_0x3fc9e3('text'),_0x59a27e=document['getElementById'](_0x4b1e06)||document['createElement']('span'),_0x53bc34=_0x3fc9e3('learnmore'),_0x2a855a=document['getElementById'](_0x53bc34)||document['createElement']('a'),_0x2402a0=_0x3fc9e3('preprendIcon'),_0x516ba4=document['getElementById'](_0x2402a0)||document['createElementNS']('http://www.w3.org/2000/svg','svg');if(_0x4dd251['created']){const _0x765c26=_0x4dd251['element'];_0x438981(_0x765c26),_0x23cd59(_0x2a855a,_0x53bc34);const _0x54d38f=_0x4a4786();_0x5e0d20(_0x516ba4,_0x2402a0),_0x765c26['append'](_0x516ba4,_0x59a27e,_0x2a855a,_0x54d38f),document['body']['appendChild'](_0x765c26);}_0x3daf77?(_0x59a27e['innerText']='Preview\x20backend\x20disconnected.',_0x516ba4['innerHTML']='<g\x20clip-path=\x22url(#clip0_6013_33858)\x22>\x0a<path\x20d=\x22M4.8\x2017.6L12\x205.6L19.2\x2017.6H4.8ZM6.91667\x2016.4H17.0833L12\x207.93333L6.91667\x2016.4ZM12\x2015.6C12.1667\x2015.6\x2012.3056\x2015.5444\x2012.4167\x2015.4333C12.5389\x2015.3111\x2012.6\x2015.1667\x2012.6\x2015C12.6\x2014.8333\x2012.5389\x2014.6944\x2012.4167\x2014.5833C12.3056\x2014.4611\x2012.1667\x2014.4\x2012\x2014.4C11.8333\x2014.4\x2011.6889\x2014.4611\x2011.5667\x2014.5833C11.4556\x2014.6944\x2011.4\x2014.8333\x2011.4\x2015C11.4\x2015.1667\x2011.4556\x2015.3111\x2011.5667\x2015.4333C11.6889\x2015.5444\x2011.8333\x2015.6\x2012\x2015.6ZM11.4\x2013.6H12.6V10.4H11.4V13.6Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6013_33858\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>'):(_0x516ba4['innerHTML']='<g\x20clip-path=\x22url(#clip0_6083_34804)\x22>\x0a<path\x20d=\x22M11.4\x2015.2H12.6V11.2H11.4V15.2ZM12\x2010C12.1667\x2010\x2012.3056\x209.94444\x2012.4167\x209.83333C12.5389\x209.71111\x2012.6\x209.56667\x2012.6\x209.4C12.6\x209.23333\x2012.5389\x209.09444\x2012.4167\x208.98333C12.3056\x208.86111\x2012.1667\x208.8\x2012\x208.8C11.8333\x208.8\x2011.6889\x208.86111\x2011.5667\x208.98333C11.4556\x209.09444\x2011.4\x209.23333\x2011.4\x209.4C11.4\x209.56667\x2011.4556\x209.71111\x2011.5667\x209.83333C11.6889\x209.94444\x2011.8333\x2010\x2012\x2010ZM12\x2018.4C11.1222\x2018.4\x2010.2944\x2018.2333\x209.51667\x2017.9C8.73889\x2017.5667\x208.05556\x2017.1111\x207.46667\x2016.5333C6.88889\x2015.9444\x206.43333\x2015.2611\x206.1\x2014.4833C5.76667\x2013.7056\x205.6\x2012.8778\x205.6\x2012C5.6\x2011.1111\x205.76667\x2010.2833\x206.1\x209.51667C6.43333\x208.73889\x206.88889\x208.06111\x207.46667\x207.48333C8.05556\x206.89444\x208.73889\x206.43333\x209.51667\x206.1C10.2944\x205.76667\x2011.1222\x205.6\x2012\x205.6C12.8889\x205.6\x2013.7167\x205.76667\x2014.4833\x206.1C15.2611\x206.43333\x2015.9389\x206.89444\x2016.5167\x207.48333C17.1056\x208.06111\x2017.5667\x208.73889\x2017.9\x209.51667C18.2333\x2010.2833\x2018.4\x2011.1111\x2018.4\x2012C18.4\x2012.8778\x2018.2333\x2013.7056\x2017.9\x2014.4833C17.5667\x2015.2611\x2017.1056\x2015.9444\x2016.5167\x2016.5333C15.9389\x2017.1111\x2015.2611\x2017.5667\x2014.4833\x2017.9C13.7167\x2018.2333\x2012.8889\x2018.4\x2012\x2018.4ZM12\x2017.2C13.4444\x2017.2\x2014.6722\x2016.6944\x2015.6833\x2015.6833C16.6944\x2014.6722\x2017.2\x2013.4444\x2017.2\x2012C17.2\x2010.5556\x2016.6944\x209.32778\x2015.6833\x208.31667C14.6722\x207.30555\x2013.4444\x206.8\x2012\x206.8C10.5556\x206.8\x209.32778\x207.30555\x208.31667\x208.31667C7.30556\x209.32778\x206.8\x2010.5556\x206.8\x2012C6.8\x2013.4444\x207.30556\x2014.6722\x208.31667\x2015.6833C9.32778\x2016.6944\x2010.5556\x2017.2\x2012\x2017.2Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6083_34804\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>',_0x59a27e['innerText']='Preview\x20backend\x20running\x20in\x20this\x20workspace.'),_0x59a27e['setAttribute']('id',_0x4b1e06);}document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0xd4a4af):_0xd4a4af();}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Fi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x495a52=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x495a52=='object'&&_0x495a52['id']!==void 0x0;}function Yr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x3982fc=W();return _0x3982fc['indexOf']('MSIE\x20')>=0x0||_0x3982fc['indexOf']('Trident/')>=0x0;}function _c(){return Br['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x3dd70a,_0x5da29f)=>{try{let _0x31d5a3=!0x0;const _0x3c1e27='validate-browser-context-for-indexeddb-analytics-module',_0x1670e1=self['indexedDB']['open'](_0x3c1e27);_0x1670e1['onsuccess']=()=>{_0x1670e1['result']['close'](),_0x31d5a3||self['indexedDB']['deleteDatabase'](_0x3c1e27),_0x3dd70a(!0x0);},_0x1670e1['onupgradeneeded']=()=>{_0x31d5a3=!0x1;},_0x1670e1['onerror']=()=>{var _0x530c95;_0x5da29f(((_0x530c95=_0x1670e1['error'])==null?void 0x0:_0x530c95['message'])||'');};}catch(_0x299b24){_0x5da29f(_0x299b24);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Se extends Error{constructor(_0x166506,_0x3ceb29,_0x3bcb16){super(_0x3ceb29),this['code']=_0x166506,this['customData']=_0x3bcb16,this['name']=yc,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Bt['prototype']['create']);}}class Bt{constructor(_0x4b9122,_0x27da65,_0x4fa2c2){this['service']=_0x4b9122,this['serviceName']=_0x27da65,this['errors']=_0x4fa2c2;}['create'](_0x550c1c,..._0x2f9eaa){const _0x5ce403=_0x2f9eaa[0x0]||{},_0x55d298=this['service']+'/'+_0x550c1c,_0x3d01a0=this['errors'][_0x550c1c],_0x472e50=_0x3d01a0?vc(_0x3d01a0,_0x5ce403):'Error',_0x361b28=this['serviceName']+':\x20'+_0x472e50+'\x20('+_0x55d298+').';return new Se(_0x55d298,_0x361b28,_0x5ce403);}}function vc(_0x1fe71a,_0xa93099){return _0x1fe71a['replace'](Ec,(_0x5d9e02,_0x48552f)=>{const _0x3c14d8=_0xa93099[_0x48552f];return _0x3c14d8!=null?String(_0x3c14d8):'<'+_0x48552f+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function At(_0x33a5d0){return JSON['parse'](_0x33a5d0);}function O(_0x3f1f09){return JSON['stringify'](_0x3f1f09);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qr=function(_0x5b2817){let _0x3104fd={},_0x38d557={},_0x123524={},_0x4c44ab='';try{const _0x29de3a=_0x5b2817['split']('.');_0x3104fd=At(ln(_0x29de3a[0x0])||''),_0x38d557=At(ln(_0x29de3a[0x1])||''),_0x4c44ab=_0x29de3a[0x2],_0x123524=_0x38d557['d']||{},delete _0x38d557['d'];}catch{}return{'header':_0x3104fd,'claims':_0x38d557,'data':_0x123524,'signature':_0x4c44ab};},Ic=function(_0x43c10f){const _0x13b95f=Qr(_0x43c10f),_0x13081a=_0x13b95f['claims'];return!!_0x13081a&&typeof _0x13081a=='object'&&_0x13081a['hasOwnProperty']('iat');},wc=function(_0x8bd734){const _0x5c3aa5=Qr(_0x8bd734)['claims'];return typeof _0x5c3aa5=='object'&&_0x5c3aa5['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function J(_0x4e9383,_0x56c02d){return Object['prototype']['hasOwnProperty']['call'](_0x4e9383,_0x56c02d);}function De(_0x2af234,_0x13adb3){if(Object['prototype']['hasOwnProperty']['call'](_0x2af234,_0x13adb3))return _0x2af234[_0x13adb3];}function ui(_0x151af6){for(const _0x3e4e7c in _0x151af6)if(Object['prototype']['hasOwnProperty']['call'](_0x151af6,_0x3e4e7c))return!0x1;return!0x0;}function hn(_0x3652e0,_0x4a3c20,_0x349487){const _0x4ef28b={};for(const _0x4b229b in _0x3652e0)Object['prototype']['hasOwnProperty']['call'](_0x3652e0,_0x4b229b)&&(_0x4ef28b[_0x4b229b]=_0x4a3c20['call'](_0x349487,_0x3652e0[_0x4b229b],_0x4b229b,_0x3652e0));return _0x4ef28b;}function Me(_0x202e20,_0x5c3516){if(_0x202e20===_0x5c3516)return!0x0;const _0x3361ab=Object['keys'](_0x202e20),_0x4a35e6=Object['keys'](_0x5c3516);for(const _0x5999a5 of _0x3361ab){if(!_0x4a35e6['includes'](_0x5999a5))return!0x1;const _0x208597=_0x202e20[_0x5999a5],_0x480b6d=_0x5c3516[_0x5999a5];if(Os(_0x208597)&&Os(_0x480b6d)){if(!Me(_0x208597,_0x480b6d))return!0x1;}else{if(_0x208597!==_0x480b6d)return!0x1;}}for(const _0x5ee547 of _0x4a35e6)if(!_0x3361ab['includes'](_0x5ee547))return!0x1;return!0x0;}function Os(_0x3d6943){return _0x3d6943!==null&&typeof _0x3d6943=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ct(_0x48d253){const _0x2673d3=[];for(const [_0x20a897,_0x5a9ede]of Object['entries'](_0x48d253))Array['isArray'](_0x5a9ede)?_0x5a9ede['forEach'](_0xc98b8c=>{_0x2673d3['push'](encodeURIComponent(_0x20a897)+'='+encodeURIComponent(_0xc98b8c));}):_0x2673d3['push'](encodeURIComponent(_0x20a897)+'='+encodeURIComponent(_0x5a9ede));return _0x2673d3['length']?'&'+_0x2673d3['join']('&'):'';}function vt(_0x2a2f69){const _0x216606={};return _0x2a2f69['replace'](/^\?/,'')['split']('&')['forEach'](_0x43f366=>{if(_0x43f366){const [_0x11a643,_0x157fa7]=_0x43f366['split']('=');_0x216606[decodeURIComponent(_0x11a643)]=decodeURIComponent(_0x157fa7);}}),_0x216606;}function Et(_0x366f77){const _0x46e2db=_0x366f77['indexOf']('?');if(!_0x46e2db)return'';const _0x21d017=_0x366f77['indexOf']('#',_0x46e2db);return _0x366f77['substring'](_0x46e2db,_0x21d017>0x0?_0x21d017:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x21bb5b=0x1;_0x21bb5b<this['blockSize'];++_0x21bb5b)this['pad_'][_0x21bb5b]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x1c86a3,_0x57fad7){_0x57fad7||(_0x57fad7=0x0);const _0x32e60b=this['W_'];if(typeof _0x1c86a3=='string'){for(let _0x4ea6f6=0x0;_0x4ea6f6<0x10;_0x4ea6f6++)_0x32e60b[_0x4ea6f6]=_0x1c86a3['charCodeAt'](_0x57fad7)<<0x18|_0x1c86a3['charCodeAt'](_0x57fad7+0x1)<<0x10|_0x1c86a3['charCodeAt'](_0x57fad7+0x2)<<0x8|_0x1c86a3['charCodeAt'](_0x57fad7+0x3),_0x57fad7+=0x4;}else{for(let _0x2195c7=0x0;_0x2195c7<0x10;_0x2195c7++)_0x32e60b[_0x2195c7]=_0x1c86a3[_0x57fad7]<<0x18|_0x1c86a3[_0x57fad7+0x1]<<0x10|_0x1c86a3[_0x57fad7+0x2]<<0x8|_0x1c86a3[_0x57fad7+0x3],_0x57fad7+=0x4;}for(let _0x3f435a=0x10;_0x3f435a<0x50;_0x3f435a++){const _0x5aac40=_0x32e60b[_0x3f435a-0x3]^_0x32e60b[_0x3f435a-0x8]^_0x32e60b[_0x3f435a-0xe]^_0x32e60b[_0x3f435a-0x10];_0x32e60b[_0x3f435a]=(_0x5aac40<<0x1|_0x5aac40>>>0x1f)&0xffffffff;}let _0x4b3e23=this['chain_'][0x0],_0x32f988=this['chain_'][0x1],_0x3045eb=this['chain_'][0x2],_0x2e4804=this['chain_'][0x3],_0x3246d3=this['chain_'][0x4],_0x1f9ca2,_0x3bbcd0;for(let _0x17dbd3=0x0;_0x17dbd3<0x50;_0x17dbd3++){_0x17dbd3<0x28?_0x17dbd3<0x14?(_0x1f9ca2=_0x2e4804^_0x32f988&(_0x3045eb^_0x2e4804),_0x3bbcd0=0x5a827999):(_0x1f9ca2=_0x32f988^_0x3045eb^_0x2e4804,_0x3bbcd0=0x6ed9eba1):_0x17dbd3<0x3c?(_0x1f9ca2=_0x32f988&_0x3045eb|_0x2e4804&(_0x32f988|_0x3045eb),_0x3bbcd0=0x8f1bbcdc):(_0x1f9ca2=_0x32f988^_0x3045eb^_0x2e4804,_0x3bbcd0=0xca62c1d6);const _0x1e5323=(_0x4b3e23<<0x5|_0x4b3e23>>>0x1b)+_0x1f9ca2+_0x3246d3+_0x3bbcd0+_0x32e60b[_0x17dbd3]&0xffffffff;_0x3246d3=_0x2e4804,_0x2e4804=_0x3045eb,_0x3045eb=(_0x32f988<<0x1e|_0x32f988>>>0x2)&0xffffffff,_0x32f988=_0x4b3e23,_0x4b3e23=_0x1e5323;}this['chain_'][0x0]=this['chain_'][0x0]+_0x4b3e23&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x32f988&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x3045eb&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x2e4804&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x3246d3&0xffffffff;}['update'](_0x45ae82,_0x5c0095){if(_0x45ae82==null)return;_0x5c0095===void 0x0&&(_0x5c0095=_0x45ae82['length']);const _0x13f3e6=_0x5c0095-this['blockSize'];let _0x36a73c=0x0;const _0x4d21fc=this['buf_'];let _0xca484e=this['inbuf_'];for(;_0x36a73c<_0x5c0095;){if(_0xca484e===0x0){for(;_0x36a73c<=_0x13f3e6;)this['compress_'](_0x45ae82,_0x36a73c),_0x36a73c+=this['blockSize'];}if(typeof _0x45ae82=='string'){for(;_0x36a73c<_0x5c0095;)if(_0x4d21fc[_0xca484e]=_0x45ae82['charCodeAt'](_0x36a73c),++_0xca484e,++_0x36a73c,_0xca484e===this['blockSize']){this['compress_'](_0x4d21fc),_0xca484e=0x0;break;}}else{for(;_0x36a73c<_0x5c0095;)if(_0x4d21fc[_0xca484e]=_0x45ae82[_0x36a73c],++_0xca484e,++_0x36a73c,_0xca484e===this['blockSize']){this['compress_'](_0x4d21fc),_0xca484e=0x0;break;}}}this['inbuf_']=_0xca484e,this['total_']+=_0x5c0095;}['digest'](){const _0xa7f449=[];let _0x507bb1=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x3388fb=this['blockSize']-0x1;_0x3388fb>=0x38;_0x3388fb--)this['buf_'][_0x3388fb]=_0x507bb1&0xff,_0x507bb1/=0x100;this['compress_'](this['buf_']);let _0x5e85df=0x0;for(let _0x57e39f=0x0;_0x57e39f<0x5;_0x57e39f++)for(let _0x2f135e=0x18;_0x2f135e>=0x0;_0x2f135e-=0x8)_0xa7f449[_0x5e85df]=this['chain_'][_0x57e39f]>>_0x2f135e&0xff,++_0x5e85df;return _0xa7f449;}}function Tc(_0x35523d,_0x32faf0){const _0x5c4cf9=new Sc(_0x35523d,_0x32faf0);return _0x5c4cf9['subscribe']['bind'](_0x5c4cf9);}class Sc{constructor(_0x443b5a,_0xb2354b){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0xb2354b,this['task']['then'](()=>{_0x443b5a(this);})['catch'](_0x5bf6fb=>{this['error'](_0x5bf6fb);});}['next'](_0x1d8537){this['forEachObserver'](_0x5a0737=>{_0x5a0737['next'](_0x1d8537);});}['error'](_0x4bf536){this['forEachObserver'](_0x314a33=>{_0x314a33['error'](_0x4bf536);}),this['close'](_0x4bf536);}['complete'](){this['forEachObserver'](_0x659d83=>{_0x659d83['complete']();}),this['close']();}['subscribe'](_0x4374a6,_0x5730be,_0x577dbb){let _0xd123c8;if(_0x4374a6===void 0x0&&_0x5730be===void 0x0&&_0x577dbb===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x4374a6,['next','error','complete'])?_0xd123c8=_0x4374a6:_0xd123c8={'next':_0x4374a6,'error':_0x5730be,'complete':_0x577dbb},_0xd123c8['next']===void 0x0&&(_0xd123c8['next']=Jn),_0xd123c8['error']===void 0x0&&(_0xd123c8['error']=Jn),_0xd123c8['complete']===void 0x0&&(_0xd123c8['complete']=Jn);const _0x54702e=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0xd123c8['error'](this['finalError']):_0xd123c8['complete']();}catch{}}),this['observers']['push'](_0xd123c8),_0x54702e;}['unsubscribeOne'](_0x3416bb){this['observers']===void 0x0||this['observers'][_0x3416bb]===void 0x0||(delete this['observers'][_0x3416bb],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x209717){if(!this['finalized']){for(let _0x16b070=0x0;_0x16b070<this['observers']['length'];_0x16b070++)this['sendOne'](_0x16b070,_0x209717);}}['sendOne'](_0x5be3de,_0x1d19a9){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x5be3de]!==void 0x0)try{_0x1d19a9(this['observers'][_0x5be3de]);}catch(_0x3d425e){typeof console<'u'&&console['error']&&console['error'](_0x3d425e);}});}['close'](_0x2bf55b){this['finalized']||(this['finalized']=!0x0,_0x2bf55b!==void 0x0&&(this['finalError']=_0x2bf55b),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x5f11b5,_0x456f05){if(typeof _0x5f11b5!='object'||_0x5f11b5===null)return!0x1;for(const _0x85143c of _0x456f05)if(_0x85143c in _0x5f11b5&&typeof _0x5f11b5[_0x85143c]=='function')return!0x0;return!0x1;}function Jn(){}function Pn(_0x5dd2d4,_0x2e061f){return _0x5dd2d4+'\x20failed:\x20'+_0x2e061f+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x323caf){const _0x1b5175=[];let _0x51fb7a=0x0;for(let _0x16c68f=0x0;_0x16c68f<_0x323caf['length'];_0x16c68f++){let _0xac4b01=_0x323caf['charCodeAt'](_0x16c68f);if(_0xac4b01>=0xd800&&_0xac4b01<=0xdbff){const _0x22cebd=_0xac4b01-0xd800;_0x16c68f++,f(_0x16c68f<_0x323caf['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x233535=_0x323caf['charCodeAt'](_0x16c68f)-0xdc00;_0xac4b01=0x10000+(_0x22cebd<<0xa)+_0x233535;}_0xac4b01<0x80?_0x1b5175[_0x51fb7a++]=_0xac4b01:_0xac4b01<0x800?(_0x1b5175[_0x51fb7a++]=_0xac4b01>>0x6|0xc0,_0x1b5175[_0x51fb7a++]=_0xac4b01&0x3f|0x80):_0xac4b01<0x10000?(_0x1b5175[_0x51fb7a++]=_0xac4b01>>0xc|0xe0,_0x1b5175[_0x51fb7a++]=_0xac4b01>>0x6&0x3f|0x80,_0x1b5175[_0x51fb7a++]=_0xac4b01&0x3f|0x80):(_0x1b5175[_0x51fb7a++]=_0xac4b01>>0x12|0xf0,_0x1b5175[_0x51fb7a++]=_0xac4b01>>0xc&0x3f|0x80,_0x1b5175[_0x51fb7a++]=_0xac4b01>>0x6&0x3f|0x80,_0x1b5175[_0x51fb7a++]=_0xac4b01&0x3f|0x80);}return _0x1b5175;},On=function(_0x3f1686){let _0x5e404b=0x0;for(let _0x4a2c4a=0x0;_0x4a2c4a<_0x3f1686['length'];_0x4a2c4a++){const _0x175a10=_0x3f1686['charCodeAt'](_0x4a2c4a);_0x175a10<0x80?_0x5e404b++:_0x175a10<0x800?_0x5e404b+=0x2:_0x175a10>=0xd800&&_0x175a10<=0xdbff?(_0x5e404b+=0x4,_0x4a2c4a++):_0x5e404b+=0x3;}return _0x5e404b;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function N(_0xc31a5d){return _0xc31a5d&&_0xc31a5d['_delegate']?_0xc31a5d['_delegate']:_0xc31a5d;}class Le{constructor(_0x2e16aa,_0x5863ad,_0x258eba){this['name']=_0x2e16aa,this['instanceFactory']=_0x5863ad,this['type']=_0x258eba,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x46fe02){return this['instantiationMode']=_0x46fe02,this;}['setMultipleInstances'](_0x3e57c4){return this['multipleInstances']=_0x3e57c4,this;}['setServiceProps'](_0x106691){return this['serviceProps']=_0x106691,this;}['setInstanceCreatedCallback'](_0x370ef5){return this['onInstanceCreated']=_0x370ef5,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x425260,_0x3191a3){this['name']=_0x425260,this['container']=_0x3191a3,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x35a5b7){const _0xdd7b78=this['normalizeInstanceIdentifier'](_0x35a5b7);if(!this['instancesDeferred']['has'](_0xdd7b78)){const _0xcc2c24=new ot();if(this['instancesDeferred']['set'](_0xdd7b78,_0xcc2c24),this['isInitialized'](_0xdd7b78)||this['shouldAutoInitialize']())try{const _0x755065=this['getOrInitializeService']({'instanceIdentifier':_0xdd7b78});_0x755065&&_0xcc2c24['resolve'](_0x755065);}catch{}}return this['instancesDeferred']['get'](_0xdd7b78)['promise'];}['getImmediate'](_0x3e1e35){const _0x52e896=this['normalizeInstanceIdentifier'](_0x3e1e35==null?void 0x0:_0x3e1e35['identifier']),_0x4655e8=(_0x3e1e35==null?void 0x0:_0x3e1e35['optional'])??!0x1;if(this['isInitialized'](_0x52e896)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x52e896});}catch(_0x27c5b2){if(_0x4655e8)return null;throw _0x27c5b2;}else{if(_0x4655e8)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x5c8b9a){if(_0x5c8b9a['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x5c8b9a['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x5c8b9a,!!this['shouldAutoInitialize']()){if(Nc(_0x5c8b9a))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x1903f1,_0x454b41]of this['instancesDeferred']['entries']()){const _0x3dc4d5=this['normalizeInstanceIdentifier'](_0x1903f1);try{const _0x120457=this['getOrInitializeService']({'instanceIdentifier':_0x3dc4d5});_0x454b41['resolve'](_0x120457);}catch{}}}}['clearInstance'](_0x4ca3ac=Ne){this['instancesDeferred']['delete'](_0x4ca3ac),this['instancesOptions']['delete'](_0x4ca3ac),this['instances']['delete'](_0x4ca3ac);}async['delete'](){const _0x50ff10=Array['from'](this['instances']['values']());await Promise['all']([..._0x50ff10['filter'](_0x269fd2=>'INTERNAL'in _0x269fd2)['map'](_0x5d47af=>_0x5d47af['INTERNAL']['delete']()),..._0x50ff10['filter'](_0xac02ac=>'_delete'in _0xac02ac)['map'](_0x510c45=>_0x510c45['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x121c2b=Ne){return this['instances']['has'](_0x121c2b);}['getOptions'](_0x519b2f=Ne){return this['instancesOptions']['get'](_0x519b2f)||{};}['initialize'](_0x482fc7={}){const {options:_0x53f508={}}=_0x482fc7,_0x4add2c=this['normalizeInstanceIdentifier'](_0x482fc7['instanceIdentifier']);if(this['isInitialized'](_0x4add2c))throw Error(this['name']+'('+_0x4add2c+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x1f52ab=this['getOrInitializeService']({'instanceIdentifier':_0x4add2c,'options':_0x53f508});for(const [_0x1e73b5,_0x37b955]of this['instancesDeferred']['entries']()){const _0x55c597=this['normalizeInstanceIdentifier'](_0x1e73b5);_0x4add2c===_0x55c597&&_0x37b955['resolve'](_0x1f52ab);}return _0x1f52ab;}['onInit'](_0x820d67,_0x47be27){const _0x595c44=this['normalizeInstanceIdentifier'](_0x47be27),_0x3ac464=this['onInitCallbacks']['get'](_0x595c44)??new Set();_0x3ac464['add'](_0x820d67),this['onInitCallbacks']['set'](_0x595c44,_0x3ac464);const _0x5193ed=this['instances']['get'](_0x595c44);return _0x5193ed&&_0x820d67(_0x5193ed,_0x595c44),()=>{_0x3ac464['delete'](_0x820d67);};}['invokeOnInitCallbacks'](_0x3996bb,_0x5f505c){const _0x7731b0=this['onInitCallbacks']['get'](_0x5f505c);if(_0x7731b0){for(const _0x448e5e of _0x7731b0)try{_0x448e5e(_0x3996bb,_0x5f505c);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x1ce79a,options:_0x23a599={}}){let _0xa4929f=this['instances']['get'](_0x1ce79a);if(!_0xa4929f&&this['component']&&(_0xa4929f=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x1ce79a),'options':_0x23a599}),this['instances']['set'](_0x1ce79a,_0xa4929f),this['instancesOptions']['set'](_0x1ce79a,_0x23a599),this['invokeOnInitCallbacks'](_0xa4929f,_0x1ce79a),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x1ce79a,_0xa4929f);}catch{}return _0xa4929f||null;}['normalizeInstanceIdentifier'](_0x52d1e1=Ne){return this['component']?this['component']['multipleInstances']?_0x52d1e1:Ne:_0x52d1e1;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x1f8de5){return _0x1f8de5===Ne?void 0x0:_0x1f8de5;}function Nc(_0x266714){return _0x266714['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pc{constructor(_0x6a847a){this['name']=_0x6a847a,this['providers']=new Map();}['addComponent'](_0x1cab3f){const _0x4f942d=this['getProvider'](_0x1cab3f['name']);if(_0x4f942d['isComponentSet']())throw new Error('Component\x20'+_0x1cab3f['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x4f942d['setComponent'](_0x1cab3f);}['addOrOverwriteComponent'](_0x457a7a){this['getProvider'](_0x457a7a['name'])['isComponentSet']()&&this['providers']['delete'](_0x457a7a['name']),this['addComponent'](_0x457a7a);}['getProvider'](_0x1f0faa){if(this['providers']['has'](_0x1f0faa))return this['providers']['get'](_0x1f0faa);const _0x2d7000=new Ac(_0x1f0faa,this);return this['providers']['set'](_0x1f0faa,_0x2d7000),_0x2d7000;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0xd6c91b){_0xd6c91b[_0xd6c91b['DEBUG']=0x0]='DEBUG',_0xd6c91b[_0xd6c91b['VERBOSE']=0x1]='VERBOSE',_0xd6c91b[_0xd6c91b['INFO']=0x2]='INFO',_0xd6c91b[_0xd6c91b['WARN']=0x3]='WARN',_0xd6c91b[_0xd6c91b['ERROR']=0x4]='ERROR',_0xd6c91b[_0xd6c91b['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x5f30c1,_0x187ba6,..._0x324450)=>{if(_0x187ba6<_0x5f30c1['logLevel'])return;const _0xcd1335=new Date()['toISOString'](),_0x3a9236=Mc[_0x187ba6];if(_0x3a9236)console[_0x3a9236]('['+_0xcd1335+']\x20\x20'+_0x5f30c1['name']+':',..._0x324450);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x187ba6+')');};class Ui{constructor(_0x3a8b0a){this['name']=_0x3a8b0a,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x4a85f1){if(!(_0x4a85f1 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x4a85f1+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x4a85f1;}['setLogLevel'](_0x2bac5d){this['_logLevel']=typeof _0x2bac5d=='string'?Oc[_0x2bac5d]:_0x2bac5d;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x3c6d12){if(typeof _0x3c6d12!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x3c6d12;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x21b5ae){this['_userLogHandler']=_0x21b5ae;}['debug'](..._0x17459d){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x17459d),this['_logHandler'](this,T['DEBUG'],..._0x17459d);}['log'](..._0x1d5c47){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x1d5c47),this['_logHandler'](this,T['VERBOSE'],..._0x1d5c47);}['info'](..._0x51fa28){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x51fa28),this['_logHandler'](this,T['INFO'],..._0x51fa28);}['warn'](..._0x322129){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x322129),this['_logHandler'](this,T['WARN'],..._0x322129);}['error'](..._0x3842da){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x3842da),this['_logHandler'](this,T['ERROR'],..._0x3842da);}}const xc=(_0x12b4bb,_0xdb0406)=>_0xdb0406['some'](_0x5c2f47=>_0x12b4bb instanceof _0x5c2f47);let Ds,Ms;function Fc(){return Ds||(Ds=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ms||(Ms=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),di=new WeakMap(),Xr=new WeakMap(),Xn=new WeakMap(),Wi=new WeakMap();function Wc(_0x4a22e6){const _0xa1633e=new Promise((_0x772c32,_0x30ecc8)=>{const _0x10a7db=()=>{_0x4a22e6['removeEventListener']('success',_0x5d0385),_0x4a22e6['removeEventListener']('error',_0x34d0f2);},_0x5d0385=()=>{_0x772c32(_e(_0x4a22e6['result'])),_0x10a7db();},_0x34d0f2=()=>{_0x30ecc8(_0x4a22e6['error']),_0x10a7db();};_0x4a22e6['addEventListener']('success',_0x5d0385),_0x4a22e6['addEventListener']('error',_0x34d0f2);});return _0xa1633e['then'](_0x15405a=>{_0x15405a instanceof IDBCursor&&Jr['set'](_0x15405a,_0x4a22e6);})['catch'](()=>{}),Wi['set'](_0xa1633e,_0x4a22e6),_0xa1633e;}function Bc(_0x331aa4){if(di['has'](_0x331aa4))return;const _0x261acc=new Promise((_0x52a2af,_0x2b1ac4)=>{const _0x2731f0=()=>{_0x331aa4['removeEventListener']('complete',_0x273d5e),_0x331aa4['removeEventListener']('error',_0x517352),_0x331aa4['removeEventListener']('abort',_0x517352);},_0x273d5e=()=>{_0x52a2af(),_0x2731f0();},_0x517352=()=>{_0x2b1ac4(_0x331aa4['error']||new DOMException('AbortError','AbortError')),_0x2731f0();};_0x331aa4['addEventListener']('complete',_0x273d5e),_0x331aa4['addEventListener']('error',_0x517352),_0x331aa4['addEventListener']('abort',_0x517352);});di['set'](_0x331aa4,_0x261acc);}let fi={'get'(_0x46c4be,_0x57072a,_0x3f0668){if(_0x46c4be instanceof IDBTransaction){if(_0x57072a==='done')return di['get'](_0x46c4be);if(_0x57072a==='objectStoreNames')return _0x46c4be['objectStoreNames']||Xr['get'](_0x46c4be);if(_0x57072a==='store')return _0x3f0668['objectStoreNames'][0x1]?void 0x0:_0x3f0668['objectStore'](_0x3f0668['objectStoreNames'][0x0]);}return _e(_0x46c4be[_0x57072a]);},'set'(_0x2f131a,_0x450f17,_0x4652c6){return _0x2f131a[_0x450f17]=_0x4652c6,!0x0;},'has'(_0x509763,_0x33ba3a){return _0x509763 instanceof IDBTransaction&&(_0x33ba3a==='done'||_0x33ba3a==='store')?!0x0:_0x33ba3a in _0x509763;}};function Vc(_0x55330e){fi=_0x55330e(fi);}function Hc(_0x610d65){return _0x610d65===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x35af7c,..._0x4dbabf){const _0x184e60=_0x610d65['call'](Zn(this),_0x35af7c,..._0x4dbabf);return Xr['set'](_0x184e60,_0x35af7c['sort']?_0x35af7c['sort']():[_0x35af7c]),_e(_0x184e60);}:Uc()['includes'](_0x610d65)?function(..._0x4be5a9){return _0x610d65['apply'](Zn(this),_0x4be5a9),_e(Jr['get'](this));}:function(..._0x282002){return _e(_0x610d65['apply'](Zn(this),_0x282002));};}function $c(_0x17489a){return typeof _0x17489a=='function'?Hc(_0x17489a):(_0x17489a instanceof IDBTransaction&&Bc(_0x17489a),xc(_0x17489a,Fc())?new Proxy(_0x17489a,fi):_0x17489a);}function _e(_0x1fbbfd){if(_0x1fbbfd instanceof IDBRequest)return Wc(_0x1fbbfd);if(Xn['has'](_0x1fbbfd))return Xn['get'](_0x1fbbfd);const _0x15c85a=$c(_0x1fbbfd);return _0x15c85a!==_0x1fbbfd&&(Xn['set'](_0x1fbbfd,_0x15c85a),Wi['set'](_0x15c85a,_0x1fbbfd)),_0x15c85a;}const Zn=_0x35a318=>Wi['get'](_0x35a318);function Gc(_0x23ffb8,_0x1c30a7,{blocked:_0x380384,upgrade:_0x223192,blocking:_0x49d0f5,terminated:_0x4a144d}={}){const _0x475ebd=indexedDB['open'](_0x23ffb8,_0x1c30a7),_0x791c68=_e(_0x475ebd);return _0x223192&&_0x475ebd['addEventListener']('upgradeneeded',_0x52eb40=>{_0x223192(_e(_0x475ebd['result']),_0x52eb40['oldVersion'],_0x52eb40['newVersion'],_e(_0x475ebd['transaction']),_0x52eb40);}),_0x380384&&_0x475ebd['addEventListener']('blocked',_0x53cc81=>_0x380384(_0x53cc81['oldVersion'],_0x53cc81['newVersion'],_0x53cc81)),_0x791c68['then'](_0x2f3b73=>{_0x4a144d&&_0x2f3b73['addEventListener']('close',()=>_0x4a144d()),_0x49d0f5&&_0x2f3b73['addEventListener']('versionchange',_0x45601a=>_0x49d0f5(_0x45601a['oldVersion'],_0x45601a['newVersion'],_0x45601a));})['catch'](()=>{}),_0x791c68;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],ei=new Map();function Ls(_0x364663,_0x55d9ad){if(!(_0x364663 instanceof IDBDatabase&&!(_0x55d9ad in _0x364663)&&typeof _0x55d9ad=='string'))return;if(ei['get'](_0x55d9ad))return ei['get'](_0x55d9ad);const _0x5e1737=_0x55d9ad['replace'](/FromIndex$/,''),_0x3a3b06=_0x55d9ad!==_0x5e1737,_0xbda501=zc['includes'](_0x5e1737);if(!(_0x5e1737 in(_0x3a3b06?IDBIndex:IDBObjectStore)['prototype'])||!(_0xbda501||qc['includes'](_0x5e1737)))return;const _0x110d08=async function(_0x15074e,..._0x143e48){const _0x346158=this['transaction'](_0x15074e,_0xbda501?'readwrite':'readonly');let _0x476548=_0x346158['store'];return _0x3a3b06&&(_0x476548=_0x476548['index'](_0x143e48['shift']())),(await Promise['all']([_0x476548[_0x5e1737](..._0x143e48),_0xbda501&&_0x346158['done']]))[0x0];};return ei['set'](_0x55d9ad,_0x110d08),_0x110d08;}Vc(_0x564b8e=>({..._0x564b8e,'get':(_0x5782c4,_0x49400e,_0x52a3f4)=>Ls(_0x5782c4,_0x49400e)||_0x564b8e['get'](_0x5782c4,_0x49400e,_0x52a3f4),'has':(_0x349eca,_0x137eea)=>!!Ls(_0x349eca,_0x137eea)||_0x564b8e['has'](_0x349eca,_0x137eea)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x4dd8fe){this['container']=_0x4dd8fe;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x535644=>{if(Kc(_0x535644)){const _0x58f96e=_0x535644['getImmediate']();return _0x58f96e['library']+'/'+_0x58f96e['version'];}else return null;})['filter'](_0xd909bd=>_0xd909bd)['join']('\x20');}}function Kc(_0x1048f4){const _0x38dd4a=_0x1048f4['getComponent']();return(_0x38dd4a==null?void 0x0:_0x38dd4a['type'])==='VERSION';}const pi='@firebase/app',xs='0.14.6',oe=new Ui('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.6.0',_i='[DEFAULT]',wl={[pi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},xe=new Map(),gi=new Map(),mi=new Map();function Fs(_0xc3e257,_0x3b88e8){try{_0xc3e257['container']['addComponent'](_0x3b88e8);}catch(_0x5a84b6){oe['debug']('Component\x20'+_0x3b88e8['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0xc3e257['name'],_0x5a84b6);}}function Ze(_0x438b90){const _0x2bc0b8=_0x438b90['name'];if(mi['has'](_0x2bc0b8))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x2bc0b8+'.'),!0x1;mi['set'](_0x2bc0b8,_0x438b90);for(const _0x57131b of xe['values']())Fs(_0x57131b,_0x438b90);for(const _0x53139b of gi['values']())Fs(_0x53139b,_0x438b90);return!0x0;}function Bi(_0x354f30,_0x20547d){const _0x47e700=_0x354f30['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x47e700&&_0x47e700['triggerHeartbeat'](),_0x354f30['container']['getProvider'](_0x20547d);}function $(_0x1fa8c9){return _0x1fa8c9==null?!0x1:_0x1fa8c9['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Bt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x5cd23b,_0x2c038e,_0x3fcdab){this['_isDeleted']=!0x1,this['_options']={..._0x5cd23b},this['_config']={..._0x2c038e},this['_name']=_0x2c038e['name'],this['_automaticDataCollectionEnabled']=_0x2c038e['automaticDataCollectionEnabled'],this['_container']=_0x3fcdab,this['container']['addComponent'](new Le('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x2cef5e){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x2cef5e;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x5b404f){this['_isDeleted']=_0x5b404f;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const lt=Il;function Sl(_0x34bd4a,_0x5aeb4d={}){let _0x1e0bfb=_0x34bd4a;typeof _0x5aeb4d!='object'&&(_0x5aeb4d={'name':_0x5aeb4d});const _0x50cf84={'name':_i,'automaticDataCollectionEnabled':!0x0,..._0x5aeb4d},_0xd0e124=_0x50cf84['name'];if(typeof _0xd0e124!='string'||!_0xd0e124)throw ge['create']('bad-app-name',{'appName':String(_0xd0e124)});if(_0x1e0bfb||(_0x1e0bfb=qr()),!_0x1e0bfb)throw ge['create']('no-options');const _0x1dcde3=xe['get'](_0xd0e124);if(_0x1dcde3){if(Me(_0x1e0bfb,_0x1dcde3['options'])&&Me(_0x50cf84,_0x1dcde3['config']))return _0x1dcde3;throw ge['create']('duplicate-app',{'appName':_0xd0e124});}const _0x446835=new Pc(_0xd0e124);for(const _0x110fad of mi['values']())_0x446835['addComponent'](_0x110fad);const _0x4f2621=new Tl(_0x1e0bfb,_0x50cf84,_0x446835);return xe['set'](_0xd0e124,_0x4f2621),_0x4f2621;}function Zr(_0x517bad=_i){const _0x4a569b=xe['get'](_0x517bad);if(!_0x4a569b&&_0x517bad===_i&&qr())return Sl();if(!_0x4a569b)throw ge['create']('no-app',{'appName':_0x517bad});return _0x4a569b;}function f_(){return Array['from'](xe['values']());}async function p_(_0x551140){let _0x5d375c=!0x1;const _0x1bf3f2=_0x551140['name'];xe['has'](_0x1bf3f2)?(_0x5d375c=!0x0,xe['delete'](_0x1bf3f2)):gi['has'](_0x1bf3f2)&&_0x551140['decRefCount']()<=0x0&&(gi['delete'](_0x1bf3f2),_0x5d375c=!0x0),_0x5d375c&&(await Promise['all'](_0x551140['container']['getProviders']()['map'](_0x2175c2=>_0x2175c2['delete']())),_0x551140['isDeleted']=!0x0);}function me(_0x5e435a,_0x518b0c,_0xec672){let _0x3e4095=wl[_0x5e435a]??_0x5e435a;_0xec672&&(_0x3e4095+='-'+_0xec672);const _0x54b7d3=_0x3e4095['match'](/\s|\//),_0x2d4cde=_0x518b0c['match'](/\s|\//);if(_0x54b7d3||_0x2d4cde){const _0xb74c04=['Unable\x20to\x20register\x20library\x20\x22'+_0x3e4095+'\x22\x20with\x20version\x20\x22'+_0x518b0c+'\x22:'];_0x54b7d3&&_0xb74c04['push']('library\x20name\x20\x22'+_0x3e4095+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x54b7d3&&_0x2d4cde&&_0xb74c04['push']('and'),_0x2d4cde&&_0xb74c04['push']('version\x20name\x20\x22'+_0x518b0c+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0xb74c04['join']('\x20'));return;}Ze(new Le(_0x3e4095+'-version',()=>({'library':_0x3e4095,'version':_0x518b0c}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,kt='firebase-heartbeat-store';let ti=null;function eo(){return ti||(ti=Gc(bl,Rl,{'upgrade':(_0x3da1db,_0x27418d)=>{switch(_0x27418d){case 0x0:try{_0x3da1db['createObjectStore'](kt);}catch(_0x4d0b7e){console['warn'](_0x4d0b7e);}}}})['catch'](_0xa0f1ce=>{throw ge['create']('idb-open',{'originalErrorMessage':_0xa0f1ce['message']});})),ti;}async function Al(_0x396347){try{const _0x1ed39b=(await eo())['transaction'](kt),_0x513dea=await _0x1ed39b['objectStore'](kt)['get'](to(_0x396347));return await _0x1ed39b['done'],_0x513dea;}catch(_0x479133){if(_0x479133 instanceof Se)oe['warn'](_0x479133['message']);else{const _0x1f51f4=ge['create']('idb-get',{'originalErrorMessage':_0x479133==null?void 0x0:_0x479133['message']});oe['warn'](_0x1f51f4['message']);}}}async function Us(_0x51976a,_0x4c2bcd){try{const _0xa6ce4e=(await eo())['transaction'](kt,'readwrite');await _0xa6ce4e['objectStore'](kt)['put'](_0x4c2bcd,to(_0x51976a)),await _0xa6ce4e['done'];}catch(_0x24a318){if(_0x24a318 instanceof Se)oe['warn'](_0x24a318['message']);else{const _0x9c17b=ge['create']('idb-set',{'originalErrorMessage':_0x24a318==null?void 0x0:_0x24a318['message']});oe['warn'](_0x9c17b['message']);}}}function to(_0x59ee8d){return _0x59ee8d['name']+'!'+_0x59ee8d['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Nl=0x1e;class Pl{constructor(_0x288514){this['container']=_0x288514,this['_heartbeatsCache']=null;const _0x2c6e37=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x2c6e37),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x3d1206=>(this['_heartbeatsCache']=_0x3d1206,_0x3d1206));}async['triggerHeartbeat'](){var _0x444d51,_0x393260;try{const _0x318932=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0xd7608a=Ws();if(((_0x444d51=this['_heartbeatsCache'])==null?void 0x0:_0x444d51['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x393260=this['_heartbeatsCache'])==null?void 0x0:_0x393260['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0xd7608a||this['_heartbeatsCache']['heartbeats']['some'](_0x35cf4f=>_0x35cf4f['date']===_0xd7608a))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0xd7608a,'agent':_0x318932}),this['_heartbeatsCache']['heartbeats']['length']>Nl){const _0x30f692=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x30f692,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x158044){oe['warn'](_0x158044);}}async['getHeartbeatsHeader'](){var _0x4fa4e2;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x4fa4e2=this['_heartbeatsCache'])==null?void 0x0:_0x4fa4e2['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x197768=Ws(),{heartbeatsToSend:_0x4d59ea,unsentEntries:_0x2ad322}=Ol(this['_heartbeatsCache']['heartbeats']),_0x5a9e60=cn(JSON['stringify']({'version':0x2,'heartbeats':_0x4d59ea}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x197768,_0x2ad322['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x2ad322,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x5a9e60;}catch(_0x36adaa){return oe['warn'](_0x36adaa),'';}}}function Ws(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0xc47901,_0x6335de=kl){const _0x3f0148=[];let _0x58ce38=_0xc47901['slice']();for(const _0x301274 of _0xc47901){const _0x453ba2=_0x3f0148['find'](_0x42fd27=>_0x42fd27['agent']===_0x301274['agent']);if(_0x453ba2){if(_0x453ba2['dates']['push'](_0x301274['date']),Bs(_0x3f0148)>_0x6335de){_0x453ba2['dates']['pop']();break;}}else{if(_0x3f0148['push']({'agent':_0x301274['agent'],'dates':[_0x301274['date']]}),Bs(_0x3f0148)>_0x6335de){_0x3f0148['pop']();break;}}_0x58ce38=_0x58ce38['slice'](0x1);}return{'heartbeatsToSend':_0x3f0148,'unsentEntries':_0x58ce38};}class Dl{constructor(_0x21085c){this['app']=_0x21085c,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x270834=await Al(this['app']);return _0x270834!=null&&_0x270834['heartbeats']?_0x270834:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x3e9efe){if(await this['_canUseIndexedDBPromise']){const _0xe49463=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x3e9efe['lastSentHeartbeatDate']??_0xe49463['lastSentHeartbeatDate'],'heartbeats':_0x3e9efe['heartbeats']});}else return;}async['add'](_0x577aa8){if(await this['_canUseIndexedDBPromise']){const _0x8c601=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x577aa8['lastSentHeartbeatDate']??_0x8c601['lastSentHeartbeatDate'],'heartbeats':[..._0x8c601['heartbeats'],..._0x577aa8['heartbeats']]});}else return;}}function Bs(_0x1530ea){return cn(JSON['stringify']({'version':0x2,'heartbeats':_0x1530ea}))['length'];}function Ml(_0x152acd){if(_0x152acd['length']===0x0)return-0x1;let _0x5de2b3=0x0,_0x23e25d=_0x152acd[0x0]['date'];for(let _0x38037b=0x1;_0x38037b<_0x152acd['length'];_0x38037b++)_0x152acd[_0x38037b]['date']<_0x23e25d&&(_0x23e25d=_0x152acd[_0x38037b]['date'],_0x5de2b3=_0x38037b);return _0x5de2b3;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x5ec173){Ze(new Le('platform-logger',_0x4cff28=>new jc(_0x4cff28),'PRIVATE')),Ze(new Le('heartbeat',_0x32d3fc=>new Pl(_0x32d3fc),'PRIVATE')),me(pi,xs,_0x5ec173),me(pi,xs,'esm2020'),me('fire-js','');}Ll('');var xl='firebase',Fl='12.6.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(xl,Fl,'app');var Vs={};const Hs='@firebase/database',$s='1.1.0';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x10894a){no=_0x10894a;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x315e4c){this['domStorage_']=_0x315e4c,this['prefix_']='firebase:';}['set'](_0x55ea82,_0x35644d){_0x35644d==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x55ea82)):this['domStorage_']['setItem'](this['prefixedName_'](_0x55ea82),O(_0x35644d));}['get'](_0x37df55){const _0x3b7a4b=this['domStorage_']['getItem'](this['prefixedName_'](_0x37df55));return _0x3b7a4b==null?null:At(_0x3b7a4b);}['remove'](_0x3902fc){this['domStorage_']['removeItem'](this['prefixedName_'](_0x3902fc));}['prefixedName_'](_0x5014a4){return this['prefix_']+_0x5014a4;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x574f9c,_0x13a97a){_0x13a97a==null?delete this['cache_'][_0x574f9c]:this['cache_'][_0x574f9c]=_0x13a97a;}['get'](_0x2b3333){return J(this['cache_'],_0x2b3333)?this['cache_'][_0x2b3333]:null;}['remove'](_0x588524){delete this['cache_'][_0x588524];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x55ef88){try{if(typeof window<'u'&&typeof window[_0x55ef88]<'u'){const _0x5705f0=window[_0x55ef88];return _0x5705f0['setItem']('firebase:sentinel','cache'),_0x5705f0['removeItem']('firebase:sentinel'),new Wl(_0x5705f0);}}catch{}return new Bl();},Oe=io('localStorage'),Vl=io('sessionStorage'),Ye=new Ui('@firebase/database'),so=(function(){let _0x3acb4c=0x1;return function(){return _0x3acb4c++;};}()),ro=function(_0x226122){const _0x3f7d2a=Rc(_0x226122),_0x4696a6=new Cc();_0x4696a6['update'](_0x3f7d2a);const _0x1be0da=_0x4696a6['digest']();return Li['encodeByteArray'](_0x1be0da);},Vt=function(..._0x105482){let _0x2f9c36='';for(let _0x4507e7=0x0;_0x4507e7<_0x105482['length'];_0x4507e7++){const _0x5a6e6f=_0x105482[_0x4507e7];Array['isArray'](_0x5a6e6f)||_0x5a6e6f&&typeof _0x5a6e6f=='object'&&typeof _0x5a6e6f['length']=='number'?_0x2f9c36+=Vt['apply'](null,_0x5a6e6f):typeof _0x5a6e6f=='object'?_0x2f9c36+=O(_0x5a6e6f):_0x2f9c36+=_0x5a6e6f,_0x2f9c36+='\x20';}return _0x2f9c36;};let wt=null,Gs=!0x0;const Hl=function(_0x55621d,_0x3d11fe){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ye['logLevel']=T['VERBOSE'],wt=Ye['log']['bind'](Ye);},L=function(..._0x4b0dda){if(Gs===!0x0&&(Gs=!0x1,wt===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),wt){const _0x4ce424=Vt['apply'](null,_0x4b0dda);wt(_0x4ce424);}},Ht=function(_0x3a4378){return function(..._0x467137){L(_0x3a4378,..._0x467137);};},yi=function(..._0xd67146){const _0x2ff1e8='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Vt(..._0xd67146);Ye['error'](_0x2ff1e8);},ae=function(..._0x51c942){const _0x5d49ed='FIREBASE\x20FATAL\x20ERROR:\x20'+Vt(..._0x51c942);throw Ye['error'](_0x5d49ed),new Error(_0x5d49ed);},U=function(..._0x56b197){const _0x1e7f1e='FIREBASE\x20WARNING:\x20'+Vt(..._0x56b197);Ye['warn'](_0x1e7f1e);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Vi=function(_0x1e47ed){return typeof _0x1e47ed=='number'&&(_0x1e47ed!==_0x1e47ed||_0x1e47ed===Number['POSITIVE_INFINITY']||_0x1e47ed===Number['NEGATIVE_INFINITY']);},Gl=function(_0x1c1c27){if(document['readyState']==='complete')_0x1c1c27();else{let _0x4bbbe5=!0x1;const _0x5890c8=function(){if(!document['body']){setTimeout(_0x5890c8,Math['floor'](0xa));return;}_0x4bbbe5||(_0x4bbbe5=!0x0,_0x1c1c27());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x5890c8,!0x1),window['addEventListener']('load',_0x5890c8,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x5890c8();}),window['attachEvent']('onload',_0x5890c8));}},Fe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x4f26b8,_0x3f3091){if(_0x4f26b8===_0x3f3091)return 0x0;if(_0x4f26b8===Fe||_0x3f3091===Ie)return-0x1;if(_0x3f3091===Fe||_0x4f26b8===Ie)return 0x1;{const _0x179b2f=qs(_0x4f26b8),_0x222bde=qs(_0x3f3091);return _0x179b2f!==null?_0x222bde!==null?_0x179b2f-_0x222bde===0x0?_0x4f26b8['length']-_0x3f3091['length']:_0x179b2f-_0x222bde:-0x1:_0x222bde!==null?0x1:_0x4f26b8<_0x3f3091?-0x1:0x1;}},ql=function(_0xebcde3,_0x395c0a){return _0xebcde3===_0x395c0a?0x0:_0xebcde3<_0x395c0a?-0x1:0x1;},_t=function(_0x4620ad,_0x54a993){if(_0x54a993&&_0x4620ad in _0x54a993)return _0x54a993[_0x4620ad];throw new Error('Missing\x20required\x20key\x20('+_0x4620ad+')\x20in\x20object:\x20'+O(_0x54a993));},Hi=function(_0x4d40e5){if(typeof _0x4d40e5!='object'||_0x4d40e5===null)return O(_0x4d40e5);const _0x459d54=[];for(const _0x59cd5d in _0x4d40e5)_0x459d54['push'](_0x59cd5d);_0x459d54['sort']();let _0x2d62ad='{';for(let _0x2315f=0x0;_0x2315f<_0x459d54['length'];_0x2315f++)_0x2315f!==0x0&&(_0x2d62ad+=','),_0x2d62ad+=O(_0x459d54[_0x2315f]),_0x2d62ad+=':',_0x2d62ad+=Hi(_0x4d40e5[_0x459d54[_0x2315f]]);return _0x2d62ad+='}',_0x2d62ad;},oo=function(_0x10d27b,_0x2c4cc9){const _0x3884f9=_0x10d27b['length'];if(_0x3884f9<=_0x2c4cc9)return[_0x10d27b];const _0x338fb9=[];for(let _0x4f803c=0x0;_0x4f803c<_0x3884f9;_0x4f803c+=_0x2c4cc9)_0x4f803c+_0x2c4cc9>_0x3884f9?_0x338fb9['push'](_0x10d27b['substring'](_0x4f803c,_0x3884f9)):_0x338fb9['push'](_0x10d27b['substring'](_0x4f803c,_0x4f803c+_0x2c4cc9));return _0x338fb9;};function x(_0x4a36bc,_0x42ac55){for(const _0x5adb2c in _0x4a36bc)_0x4a36bc['hasOwnProperty'](_0x5adb2c)&&_0x42ac55(_0x5adb2c,_0x4a36bc[_0x5adb2c]);}const ao=function(_0x21a788){f(!Vi(_0x21a788),'Invalid\x20JSON\x20number');const _0x13b6b0=0xb,_0x5a208d=0x34,_0x346a91=(0x1<<_0x13b6b0-0x1)-0x1;let _0x3c6d50,_0xb28e0b,_0xa07720,_0x2d461a,_0x36ef35;_0x21a788===0x0?(_0xb28e0b=0x0,_0xa07720=0x0,_0x3c6d50=0x1/_0x21a788===-0x1/0x0?0x1:0x0):(_0x3c6d50=_0x21a788<0x0,_0x21a788=Math['abs'](_0x21a788),_0x21a788>=Math['pow'](0x2,0x1-_0x346a91)?(_0x2d461a=Math['min'](Math['floor'](Math['log'](_0x21a788)/Math['LN2']),_0x346a91),_0xb28e0b=_0x2d461a+_0x346a91,_0xa07720=Math['round'](_0x21a788*Math['pow'](0x2,_0x5a208d-_0x2d461a)-Math['pow'](0x2,_0x5a208d))):(_0xb28e0b=0x0,_0xa07720=Math['round'](_0x21a788/Math['pow'](0x2,0x1-_0x346a91-_0x5a208d))));const _0x35d63b=[];for(_0x36ef35=_0x5a208d;_0x36ef35;_0x36ef35-=0x1)_0x35d63b['push'](_0xa07720%0x2?0x1:0x0),_0xa07720=Math['floor'](_0xa07720/0x2);for(_0x36ef35=_0x13b6b0;_0x36ef35;_0x36ef35-=0x1)_0x35d63b['push'](_0xb28e0b%0x2?0x1:0x0),_0xb28e0b=Math['floor'](_0xb28e0b/0x2);_0x35d63b['push'](_0x3c6d50?0x1:0x0),_0x35d63b['reverse']();const _0x45cee9=_0x35d63b['join']('');let _0x404750='';for(_0x36ef35=0x0;_0x36ef35<0x40;_0x36ef35+=0x8){let _0x535956=parseInt(_0x45cee9['substr'](_0x36ef35,0x8),0x2)['toString'](0x10);_0x535956['length']===0x1&&(_0x535956='0'+_0x535956),_0x404750=_0x404750+_0x535956;}return _0x404750['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x1b716e,_0x1c6c72){let _0x1d8e56='Unknown\x20Error';_0x1b716e==='too_big'?_0x1d8e56='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x1b716e==='permission_denied'?_0x1d8e56='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x1b716e==='unavailable'&&(_0x1d8e56='The\x20service\x20is\x20unavailable');const _0x1a5f7c=new Error(_0x1b716e+'\x20at\x20'+_0x1c6c72['_path']['toString']()+':\x20'+_0x1d8e56);return _0x1a5f7c['code']=_0x1b716e['toUpperCase'](),_0x1a5f7c;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,qs=function(_0x2afa4c){if(Yl['test'](_0x2afa4c)){const _0x32e865=Number(_0x2afa4c);if(_0x32e865>=Ql&&_0x32e865<=Jl)return _0x32e865;}return null;},ht=function(_0x4819e0){try{_0x4819e0();}catch(_0x36426b){setTimeout(()=>{const _0x4f5e94=_0x36426b['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x4f5e94),_0x36426b;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},Ct=function(_0x2ff996,_0x432ea4){const _0x2b4def=setTimeout(_0x2ff996,_0x432ea4);return typeof _0x2b4def=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x2b4def):typeof _0x2b4def=='object'&&_0x2b4def['unref']&&_0x2b4def['unref'](),_0x2b4def;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x5f1fa0,_0x4d1628){this['appCheckProvider']=_0x4d1628,this['appName']=_0x5f1fa0['name'],$(_0x5f1fa0)&&_0x5f1fa0['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x5f1fa0['settings']['appCheckToken']),this['appCheck']=_0x4d1628==null?void 0x0:_0x4d1628['getImmediate']({'optional':!0x0}),this['appCheck']||_0x4d1628==null||_0x4d1628['get']()['then'](_0x26fb2e=>this['appCheck']=_0x26fb2e);}['getToken'](_0x3e13fd){if(this['serverAppAppCheckToken']){if(_0x3e13fd)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x3e13fd):new Promise((_0x2bfc51,_0x13c5bd)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x3e13fd)['then'](_0x2bfc51,_0x13c5bd):_0x2bfc51(null);},0x0);});}['addTokenChangeListener'](_0x29a3db){var _0x26cbd5;(_0x26cbd5=this['appCheckProvider'])==null||_0x26cbd5['get']()['then'](_0x2e4cf7=>_0x2e4cf7['addTokenListener'](_0x29a3db));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x4bb34d,_0x7af2bf,_0x59fcfe){this['appName_']=_0x4bb34d,this['firebaseOptions_']=_0x7af2bf,this['authProvider_']=_0x59fcfe,this['auth_']=null,this['auth_']=_0x59fcfe['getImmediate']({'optional':!0x0}),this['auth_']||_0x59fcfe['onInit'](_0x15a86a=>this['auth_']=_0x15a86a);}['getToken'](_0xfd562f){return this['auth_']?this['auth_']['getToken'](_0xfd562f)['catch'](_0x503880=>_0x503880&&_0x503880['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x503880)):new Promise((_0x3a7bd1,_0x2cbb07)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0xfd562f)['then'](_0x3a7bd1,_0x2cbb07):_0x3a7bd1(null);},0x0);});}['addTokenChangeListener'](_0x34ed4a){this['auth_']?this['auth_']['addAuthTokenListener'](_0x34ed4a):this['authProvider_']['get']()['then'](_0x31900d=>_0x31900d['addAuthTokenListener'](_0x34ed4a));}['removeTokenChangeListener'](_0x374de5){this['authProvider_']['get']()['then'](_0x3f7ce4=>_0x3f7ce4['removeAuthTokenListener'](_0x374de5));}['notifyForInvalidToken'](){let _0x177879='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x177879+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x177879+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x177879+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x177879);}}class nn{constructor(_0x30a84f){this['accessToken']=_0x30a84f;}['getToken'](_0x1e627f){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x3e136b){_0x3e136b(this['accessToken']);}['removeTokenChangeListener'](_0x353849){}['notifyForInvalidToken'](){}}nn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $i='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',vi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x24dea3,_0x5a6bb5,_0x2538bd,_0x4ff9dc,_0x21ed27=!0x1,_0x34ac4c='',_0x1bd581=!0x1,_0x1e6e79=!0x1,_0x550544=null){this['secure']=_0x5a6bb5,this['namespace']=_0x2538bd,this['webSocketOnly']=_0x4ff9dc,this['nodeAdmin']=_0x21ed27,this['persistenceKey']=_0x34ac4c,this['includeNamespaceInQueryParams']=_0x1bd581,this['isUsingEmulator']=_0x1e6e79,this['emulatorOptions']=_0x550544,this['_host']=_0x24dea3['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Oe['get']('host:'+_0x24dea3)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x2dfae5){_0x2dfae5!==this['internalHost']&&(this['internalHost']=_0x2dfae5,this['isCacheableHost']()&&Oe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x22996d=this['toURLString']();return this['persistenceKey']&&(_0x22996d+='<'+this['persistenceKey']+'>'),_0x22996d;}['toURLString'](){const _0x1e29b0=this['secure']?'https://':'http://',_0x10fb01=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x1e29b0+this['host']+'/'+_0x10fb01;}}function th(_0x52a71c){return _0x52a71c['host']!==_0x52a71c['internalHost']||_0x52a71c['isCustomHost']()||_0x52a71c['includeNamespaceInQueryParams'];}function vo(_0x50d70d,_0x554bb4,_0x29ae93){f(typeof _0x554bb4=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x29ae93=='object','typeof\x20params\x20must\x20==\x20object');let _0x413fe6;if(_0x554bb4===go)_0x413fe6=(_0x50d70d['secure']?'wss://':'ws://')+_0x50d70d['internalHost']+'/.ws?';else{if(_0x554bb4===mo)_0x413fe6=(_0x50d70d['secure']?'https://':'http://')+_0x50d70d['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x554bb4);}th(_0x50d70d)&&(_0x29ae93['ns']=_0x50d70d['namespace']);const _0x5c02df=[];return x(_0x29ae93,(_0xf386f6,_0x21839e)=>{_0x5c02df['push'](_0xf386f6+'='+_0x21839e);}),_0x413fe6+_0x5c02df['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x22126d,_0x4ffbe0=0x1){J(this['counters_'],_0x22126d)||(this['counters_'][_0x22126d]=0x0),this['counters_'][_0x22126d]+=_0x4ffbe0;}['get'](){return nc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ni={},ii={};function Gi(_0x52d62f){const _0x17719f=_0x52d62f['toString']();return ni[_0x17719f]||(ni[_0x17719f]=new nh()),ni[_0x17719f];}function ih(_0x458f5c,_0x325f8b){const _0x2f4398=_0x458f5c['toString']();return ii[_0x2f4398]||(ii[_0x2f4398]=_0x325f8b()),ii[_0x2f4398];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x1b4460){this['onMessage_']=_0x1b4460,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x3cb4ea,_0x6eda5a){this['closeAfterResponse']=_0x3cb4ea,this['onClose']=_0x6eda5a,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x298aa0,_0x3ffad7){for(this['pendingResponses'][_0x298aa0]=_0x3ffad7;this['pendingResponses'][this['currentResponseNum']];){const _0x1d2fb4=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0xd53802=0x0;_0xd53802<_0x1d2fb4['length'];++_0xd53802)_0x1d2fb4[_0xd53802]&&ht(()=>{this['onMessage_'](_0x1d2fb4[_0xd53802]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class je{constructor(_0x5188f1,_0x9d48f6,_0x4bfdc4,_0x3266c4,_0x3f8576,_0x1a1df1,_0x53ff4c){this['connId']=_0x5188f1,this['repoInfo']=_0x9d48f6,this['applicationId']=_0x4bfdc4,this['appCheckToken']=_0x3266c4,this['authToken']=_0x3f8576,this['transportSessionId']=_0x1a1df1,this['lastSessionId']=_0x53ff4c,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Ht(_0x5188f1),this['stats_']=Gi(_0x9d48f6),this['urlFn']=_0x5d85cd=>(this['appCheckToken']&&(_0x5d85cd[vi]=this['appCheckToken']),vo(_0x9d48f6,mo,_0x5d85cd));}['open'](_0xd8e03e,_0x2387ce){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x2387ce,this['myPacketOrderer']=new sh(_0xd8e03e),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new qi((..._0x3af778)=>{const [_0x2afccd,_0x142937,_0x11a234,_0x149a02,_0x42a9a8]=_0x3af778;if(this['incrementIncomingBytes_'](_0x3af778),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x2afccd===zs)this['id']=_0x142937,this['password']=_0x11a234;else{if(_0x2afccd===rh)_0x142937?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x142937,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x2afccd);}}},(..._0x3c5486)=>{const [_0x5c1fa0,_0x322d4d]=_0x3c5486;this['incrementIncomingBytes_'](_0x3c5486),this['myPacketOrderer']['handleResponse'](_0x5c1fa0,_0x322d4d);},()=>{this['onClosed_']();},this['urlFn']);const _0x5aee5e={};_0x5aee5e[zs]='t',_0x5aee5e[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x5aee5e[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x5aee5e[co]=$i,this['transportSessionId']&&(_0x5aee5e[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x5aee5e[po]=this['lastSessionId']),this['applicationId']&&(_0x5aee5e[_o]=this['applicationId']),this['appCheckToken']&&(_0x5aee5e[vi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x5aee5e[ho]=uo);const _0x4b1a8a=this['urlFn'](_0x5aee5e);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x4b1a8a),this['scriptTagHolder']['addTag'](_0x4b1a8a,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){je['forceAllow_']=!0x0;}static['forceDisallow'](){je['forceDisallow_']=!0x0;}static['isAvailable'](){return je['forceAllow_']?!0x0:!je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x422fdb){const _0x5b6c69=O(_0x422fdb);this['bytesSent']+=_0x5b6c69['length'],this['stats_']['incrementCounter']('bytes_sent',_0x5b6c69['length']);const _0x1cc488=Hr(_0x5b6c69),_0x2959df=oo(_0x1cc488,fh);for(let _0x12a57d=0x0;_0x12a57d<_0x2959df['length'];_0x12a57d++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x2959df['length'],_0x2959df[_0x12a57d]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x2752df,_0x265c99){this['myDisconnFrame']=document['createElement']('iframe');const _0x1f8e6e={};_0x1f8e6e[dh]='t',_0x1f8e6e[Eo]=_0x2752df,_0x1f8e6e[Io]=_0x265c99,this['myDisconnFrame']['src']=this['urlFn'](_0x1f8e6e),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x3fbb98){const _0x2c1126=O(_0x3fbb98)['length'];this['bytesReceived']+=_0x2c1126,this['stats_']['incrementCounter']('bytes_received',_0x2c1126);}}class qi{constructor(_0x3fbe0b,_0x26f461,_0x2eb9b1,_0x4cac19){this['onDisconnect']=_0x2eb9b1,this['urlFn']=_0x4cac19,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x3fbe0b,window[ah+this['uniqueCallbackIdentifier']]=_0x26f461,this['myIFrame']=qi['createIFrame_']();let _0x553e49='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x553e49='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x407ede='<html><body>'+_0x553e49+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x407ede),this['myIFrame']['doc']['close']();}catch(_0x452e8a){L('frame\x20writing\x20exception'),_0x452e8a['stack']&&L(_0x452e8a['stack']),L(_0x452e8a);}}}static['createIFrame_'](){const _0xd38014=document['createElement']('iframe');if(_0xd38014['style']['display']='none',document['body']){document['body']['appendChild'](_0xd38014);try{_0xd38014['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x583c1d=document['domain'];_0xd38014['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x583c1d+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0xd38014['contentDocument']?_0xd38014['doc']=_0xd38014['contentDocument']:_0xd38014['contentWindow']?_0xd38014['doc']=_0xd38014['contentWindow']['document']:_0xd38014['document']&&(_0xd38014['doc']=_0xd38014['document']),_0xd38014;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x2fa508=this['onDisconnect'];_0x2fa508&&(this['onDisconnect']=null,_0x2fa508());}['startLongPoll'](_0x4011b4,_0x4ed8dc){for(this['myID']=_0x4011b4,this['myPW']=_0x4ed8dc,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x18212b={};_0x18212b[Eo]=this['myID'],_0x18212b[Io]=this['myPW'],_0x18212b[wo]=this['currentSerial'];let _0x4af2f4=this['urlFn'](_0x18212b),_0x3e0e7a='',_0x5037a8=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x3e0e7a['length']<=Co;){const _0x1615f7=this['pendingSegs']['shift']();_0x3e0e7a=_0x3e0e7a+'&'+lh+_0x5037a8+'='+_0x1615f7['seg']+'&'+hh+_0x5037a8+'='+_0x1615f7['ts']+'&'+uh+_0x5037a8+'='+_0x1615f7['d'],_0x5037a8++;}return _0x4af2f4=_0x4af2f4+_0x3e0e7a,this['addLongPollTag_'](_0x4af2f4,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x19d92a,_0x48f183,_0x4ff1c3){this['pendingSegs']['push']({'seg':_0x19d92a,'ts':_0x48f183,'d':_0x4ff1c3}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x40237b,_0x1fff97){this['outstandingRequests']['add'](_0x1fff97);const _0x4e71ba=()=>{this['outstandingRequests']['delete'](_0x1fff97),this['newRequest_']();},_0x11d23a=setTimeout(_0x4e71ba,Math['floor'](ph)),_0x329f4e=()=>{clearTimeout(_0x11d23a),_0x4e71ba();};this['addTag'](_0x40237b,_0x329f4e);}['addTag'](_0xc3dcc,_0x1d9a6b){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x3290d1=this['myIFrame']['doc']['createElement']('script');_0x3290d1['type']='text/javascript',_0x3290d1['async']=!0x0,_0x3290d1['src']=_0xc3dcc,_0x3290d1['onload']=_0x3290d1['onreadystatechange']=function(){const _0x1ced52=_0x3290d1['readyState'];(!_0x1ced52||_0x1ced52==='loaded'||_0x1ced52==='complete')&&(_0x3290d1['onload']=_0x3290d1['onreadystatechange']=null,_0x3290d1['parentNode']&&_0x3290d1['parentNode']['removeChild'](_0x3290d1),_0x1d9a6b());},_0x3290d1['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0xc3dcc),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x3290d1);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let un=null;typeof MozWebSocket<'u'?un=MozWebSocket:typeof WebSocket<'u'&&(un=WebSocket);class z{constructor(_0x45e6da,_0x1df9df,_0x342a36,_0x1e2808,_0x49ea35,_0x578a78,_0x31db5a){this['connId']=_0x45e6da,this['applicationId']=_0x342a36,this['appCheckToken']=_0x1e2808,this['authToken']=_0x49ea35,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Ht(this['connId']),this['stats_']=Gi(_0x1df9df),this['connURL']=z['connectionURL_'](_0x1df9df,_0x578a78,_0x31db5a,_0x1e2808,_0x342a36),this['nodeAdmin']=_0x1df9df['nodeAdmin'];}static['connectionURL_'](_0x34ff16,_0x419f4d,_0x124bca,_0x527d04,_0x5f043b){const _0x3a0fe2={};return _0x3a0fe2[co]=$i,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x3a0fe2[ho]=uo),_0x419f4d&&(_0x3a0fe2[lo]=_0x419f4d),_0x124bca&&(_0x3a0fe2[po]=_0x124bca),_0x527d04&&(_0x3a0fe2[vi]=_0x527d04),_0x5f043b&&(_0x3a0fe2[_o]=_0x5f043b),vo(_0x34ff16,go,_0x3a0fe2);}['open'](_0x167e07,_0xa3fb66){this['onDisconnect']=_0xa3fb66,this['onMessage']=_0x167e07,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Oe['set']('previous_websocket_failure',!0x0);try{let _0x2b01fa;_c(),this['mySock']=new un(this['connURL'],[],_0x2b01fa);}catch(_0x5443bd){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x4b5d79=_0x5443bd['message']||_0x5443bd['data'];_0x4b5d79&&this['log_'](_0x4b5d79),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x621e15=>{this['handleIncomingFrame'](_0x621e15);},this['mySock']['onerror']=_0x2db327=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x250cea=_0x2db327['message']||_0x2db327['data'];_0x250cea&&this['log_'](_0x250cea),this['onClosed_']();};}['start'](){}static['forceDisallow'](){z['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x441ecb=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x27e99a=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x241004=navigator['userAgent']['match'](_0x27e99a);_0x241004&&_0x241004['length']>0x1&&parseFloat(_0x241004[0x1])<4.4&&(_0x441ecb=!0x0);}return!_0x441ecb&&un!==null&&!z['forceDisallow_'];}static['previouslyFailed'](){return Oe['isInMemoryStorage']||Oe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Oe['remove']('previous_websocket_failure');}['appendFrame_'](_0x2105c3){if(this['frames']['push'](_0x2105c3),this['frames']['length']===this['totalFrames']){const _0x46aba2=this['frames']['join']('');this['frames']=null;const _0x4fad58=At(_0x46aba2);this['onMessage'](_0x4fad58);}}['handleNewFrameCount_'](_0x1a3030){this['totalFrames']=_0x1a3030,this['frames']=[];}['extractFrameCount_'](_0x425b82){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x425b82['length']<=0x6){const _0x57ddba=Number(_0x425b82);if(!isNaN(_0x57ddba))return this['handleNewFrameCount_'](_0x57ddba),null;}return this['handleNewFrameCount_'](0x1),_0x425b82;}['handleIncomingFrame'](_0x19c239){if(this['mySock']===null)return;const _0x1a7033=_0x19c239['data'];if(this['bytesReceived']+=_0x1a7033['length'],this['stats_']['incrementCounter']('bytes_received',_0x1a7033['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x1a7033);else{const _0x1442af=this['extractFrameCount_'](_0x1a7033);_0x1442af!==null&&this['appendFrame_'](_0x1442af);}}['send'](_0x4ea1d4){this['resetKeepAlive']();const _0x57894a=O(_0x4ea1d4);this['bytesSent']+=_0x57894a['length'],this['stats_']['incrementCounter']('bytes_sent',_0x57894a['length']);const _0x46bb07=oo(_0x57894a,gh);_0x46bb07['length']>0x1&&this['sendString_'](String(_0x46bb07['length']));for(let _0xe21a2a=0x0;_0xe21a2a<_0x46bb07['length'];_0xe21a2a++)this['sendString_'](_0x46bb07[_0xe21a2a]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x20bb83){try{this['mySock']['send'](_0x20bb83);}catch(_0x227863){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x227863['message']||_0x227863['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}z['responsesRequiredToBeHealthy']=0x2,z['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nt{static get['ALL_TRANSPORTS'](){return[je,z];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x3f1ded){this['initTransports_'](_0x3f1ded);}['initTransports_'](_0x36d09c){const _0x204752=z&&z['isAvailable']();let _0x448309=_0x204752&&!z['previouslyFailed']();if(_0x36d09c['webSocketOnly']&&(_0x204752||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x448309=!0x0),_0x448309)this['transports_']=[z];else{const _0x5e71c8=this['transports_']=[];for(const _0x52b2f9 of Nt['ALL_TRANSPORTS'])_0x52b2f9&&_0x52b2f9['isAvailable']()&&_0x5e71c8['push'](_0x52b2f9);Nt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Nt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,si='t',js='d',wh='s',Ks='r',Ch='e',Ys='o',Qs='a',Js='n',Xs='p',Th='h';class Sh{constructor(_0x40c003,_0x26aa4f,_0x5bf729,_0x2258f8,_0x372ab6,_0x177f2b,_0x24fdf5,_0x8f69f3,_0x4a9ac4,_0x1d393f){this['id']=_0x40c003,this['repoInfo_']=_0x26aa4f,this['applicationId_']=_0x5bf729,this['appCheckToken_']=_0x2258f8,this['authToken_']=_0x372ab6,this['onMessage_']=_0x177f2b,this['onReady_']=_0x24fdf5,this['onDisconnect_']=_0x8f69f3,this['onKill_']=_0x4a9ac4,this['lastSessionId']=_0x1d393f,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Ht('c:'+this['id']+':'),this['transportManager_']=new Nt(_0x26aa4f),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x4f64a8=this['transportManager_']['initialTransport']();this['conn_']=new _0x4f64a8(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x4f64a8['responsesRequiredToBeHealthy']||0x0;const _0x49abee=this['connReceiver_'](this['conn_']),_0x30cb8a=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x49abee,_0x30cb8a);},Math['floor'](0x0));const _0x304a92=_0x4f64a8['healthyTimeout']||0x0;_0x304a92>0x0&&(this['healthyTimeout_']=Ct(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x304a92)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x4a268a){return _0x399d95=>{_0x4a268a===this['conn_']?this['onConnectionLost_'](_0x399d95):_0x4a268a===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x595e54){return _0x230acf=>{this['state_']!==0x2&&(_0x595e54===this['rx_']?this['onPrimaryMessageReceived_'](_0x230acf):_0x595e54===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x230acf):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x57cfb6){const _0x17aa87={'t':'d','d':_0x57cfb6};this['sendData_'](_0x17aa87);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x2f927a){if(si in _0x2f927a){const _0x4a8429=_0x2f927a[si];_0x4a8429===Qs?this['upgradeIfSecondaryHealthy_']():_0x4a8429===Ks?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x4a8429===Ys&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x2fd1c9){const _0x1cb14f=_t('t',_0x2fd1c9),_0x1bd0f4=_t('d',_0x2fd1c9);if(_0x1cb14f==='c')this['onSecondaryControl_'](_0x1bd0f4);else{if(_0x1cb14f==='d')this['pendingDataMessages']['push'](_0x1bd0f4);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x1cb14f);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Xs,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Js,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x54f175){const _0x1c8d14=_t('t',_0x54f175),_0xe4cb77=_t('d',_0x54f175);_0x1c8d14==='c'?this['onControl_'](_0xe4cb77):_0x1c8d14==='d'&&this['onDataMessage_'](_0xe4cb77);}['onDataMessage_'](_0x2a6d94){this['onPrimaryResponse_'](),this['onMessage_'](_0x2a6d94);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x1af84c){const _0x4e9dce=_t(si,_0x1af84c);if(js in _0x1af84c){const _0x13c89c=_0x1af84c[js];if(_0x4e9dce===Th){const _0xb800a7={..._0x13c89c};this['repoInfo_']['isUsingEmulator']&&(_0xb800a7['h']=this['repoInfo_']['host']),this['onHandshake_'](_0xb800a7);}else{if(_0x4e9dce===Js){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0xfa0fdf=0x0;_0xfa0fdf<this['pendingDataMessages']['length'];++_0xfa0fdf)this['onDataMessage_'](this['pendingDataMessages'][_0xfa0fdf]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x4e9dce===wh?this['onConnectionShutdown_'](_0x13c89c):_0x4e9dce===Ks?this['onReset_'](_0x13c89c):_0x4e9dce===Ch?yi('Server\x20Error:\x20'+_0x13c89c):_0x4e9dce===Ys?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):yi('Unknown\x20control\x20packet\x20command:\x20'+_0x4e9dce);}}}['onHandshake_'](_0x3e3cda){const _0x593c5a=_0x3e3cda['ts'],_0x493fa9=_0x3e3cda['v'],_0x237b44=_0x3e3cda['h'];this['sessionId']=_0x3e3cda['s'],this['repoInfo_']['host']=_0x237b44,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x593c5a),$i!==_0x493fa9&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0xf66a77=this['transportManager_']['upgradeTransport']();_0xf66a77&&this['startUpgrade_'](_0xf66a77);}['startUpgrade_'](_0x5a0f30){this['secondaryConn_']=new _0x5a0f30(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x5a0f30['responsesRequiredToBeHealthy']||0x0;const _0x7abd5d=this['connReceiver_'](this['secondaryConn_']),_0x478738=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x7abd5d,_0x478738),Ct(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x3b5bf){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x3b5bf),this['repoInfo_']['host']=_0x3b5bf,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x33b3dc,_0x19fcd0){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x33b3dc,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x19fcd0,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):Ct(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Xs,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x5d6c7a=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x5d6c7a||this['rx_']===_0x5d6c7a)&&this['close']();}['onConnectionLost_'](_0x39a6cd){this['conn_']=null,!_0x39a6cd&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Oe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x341906){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x341906),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x4a5bb1){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x4a5bb1);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x425b14,_0x25a647,_0x47f2d0,_0x52afef){}['merge'](_0x8de0e4,_0x3fb078,_0x5a869f,_0xb58049){}['refreshAuthToken'](_0x5e1913){}['refreshAppCheckToken'](_0x282518){}['onDisconnectPut'](_0x5c5d12,_0x5eee25,_0x3a7b2c){}['onDisconnectMerge'](_0x270119,_0x9f417a,_0xb4e966){}['onDisconnectCancel'](_0x56f46b,_0x50cd30){}['reportStats'](_0x5bbdc9){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x21879f){this['allowedEvents_']=_0x21879f,this['listeners_']={},f(Array['isArray'](_0x21879f)&&_0x21879f['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x2e9132,..._0x30a600){if(Array['isArray'](this['listeners_'][_0x2e9132])){const _0x288d55=[...this['listeners_'][_0x2e9132]];for(let _0x1c81be=0x0;_0x1c81be<_0x288d55['length'];_0x1c81be++)_0x288d55[_0x1c81be]['callback']['apply'](_0x288d55[_0x1c81be]['context'],_0x30a600);}}['on'](_0x2ad6c5,_0x22d5d7,_0x4d7910){this['validateEventType_'](_0x2ad6c5),this['listeners_'][_0x2ad6c5]=this['listeners_'][_0x2ad6c5]||[],this['listeners_'][_0x2ad6c5]['push']({'callback':_0x22d5d7,'context':_0x4d7910});const _0x508791=this['getInitialEvent'](_0x2ad6c5);_0x508791&&_0x22d5d7['apply'](_0x4d7910,_0x508791);}['off'](_0x2176a8,_0x520246,_0x393cb6){this['validateEventType_'](_0x2176a8);const _0x44709a=this['listeners_'][_0x2176a8]||[];for(let _0x5d923c=0x0;_0x5d923c<_0x44709a['length'];_0x5d923c++)if(_0x44709a[_0x5d923c]['callback']===_0x520246&&(!_0x393cb6||_0x393cb6===_0x44709a[_0x5d923c]['context'])){_0x44709a['splice'](_0x5d923c,0x1);return;}}['validateEventType_'](_0x5946c5){f(this['allowedEvents_']['find'](_0x873c15=>_0x873c15===_0x5946c5),'Unknown\x20event:\x20'+_0x5946c5);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class dn extends bo{static['getInstance'](){return new dn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Fi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x52b1a1){return f(_0x52b1a1==='online','Unknown\x20event\x20type:\x20'+_0x52b1a1),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Zs=0x20,er=0x300;class C{constructor(_0x26bde5,_0x187b5b){if(_0x187b5b===void 0x0){this['pieces_']=_0x26bde5['split']('/');let _0x4e99c5=0x0;for(let _0x169a50=0x0;_0x169a50<this['pieces_']['length'];_0x169a50++)this['pieces_'][_0x169a50]['length']>0x0&&(this['pieces_'][_0x4e99c5]=this['pieces_'][_0x169a50],_0x4e99c5++);this['pieces_']['length']=_0x4e99c5,this['pieceNum_']=0x0;}else this['pieces_']=_0x26bde5,this['pieceNum_']=_0x187b5b;}['toString'](){let _0x151302='';for(let _0x19c781=this['pieceNum_'];_0x19c781<this['pieces_']['length'];_0x19c781++)this['pieces_'][_0x19c781]!==''&&(_0x151302+='/'+this['pieces_'][_0x19c781]);return _0x151302||'/';}}function w(){return new C('');}function y(_0x206091){return _0x206091['pieceNum_']>=_0x206091['pieces_']['length']?null:_0x206091['pieces_'][_0x206091['pieceNum_']];}function we(_0x3d4feb){return _0x3d4feb['pieces_']['length']-_0x3d4feb['pieceNum_'];}function b(_0x1cf1dd){let _0x56bba0=_0x1cf1dd['pieceNum_'];return _0x56bba0<_0x1cf1dd['pieces_']['length']&&_0x56bba0++,new C(_0x1cf1dd['pieces_'],_0x56bba0);}function zi(_0x58a43b){return _0x58a43b['pieceNum_']<_0x58a43b['pieces_']['length']?_0x58a43b['pieces_'][_0x58a43b['pieces_']['length']-0x1]:null;}function bh(_0x49e606){let _0x4c1ed6='';for(let _0x3e247c=_0x49e606['pieceNum_'];_0x3e247c<_0x49e606['pieces_']['length'];_0x3e247c++)_0x49e606['pieces_'][_0x3e247c]!==''&&(_0x4c1ed6+='/'+encodeURIComponent(String(_0x49e606['pieces_'][_0x3e247c])));return _0x4c1ed6||'/';}function Pt(_0x197a0e,_0x31c54f=0x0){return _0x197a0e['pieces_']['slice'](_0x197a0e['pieceNum_']+_0x31c54f);}function Ro(_0x542e60){if(_0x542e60['pieceNum_']>=_0x542e60['pieces_']['length'])return null;const _0x53dbcc=[];for(let _0x313ae6=_0x542e60['pieceNum_'];_0x313ae6<_0x542e60['pieces_']['length']-0x1;_0x313ae6++)_0x53dbcc['push'](_0x542e60['pieces_'][_0x313ae6]);return new C(_0x53dbcc,0x0);}function k(_0x489761,_0x1d24ed){const _0x2aee39=[];for(let _0x53a31d=_0x489761['pieceNum_'];_0x53a31d<_0x489761['pieces_']['length'];_0x53a31d++)_0x2aee39['push'](_0x489761['pieces_'][_0x53a31d]);if(_0x1d24ed instanceof C){for(let _0x357225=_0x1d24ed['pieceNum_'];_0x357225<_0x1d24ed['pieces_']['length'];_0x357225++)_0x2aee39['push'](_0x1d24ed['pieces_'][_0x357225]);}else{const _0x9ec462=_0x1d24ed['split']('/');for(let _0x3a8675=0x0;_0x3a8675<_0x9ec462['length'];_0x3a8675++)_0x9ec462[_0x3a8675]['length']>0x0&&_0x2aee39['push'](_0x9ec462[_0x3a8675]);}return new C(_0x2aee39,0x0);}function v(_0x1e22f3){return _0x1e22f3['pieceNum_']>=_0x1e22f3['pieces_']['length'];}function F(_0x21443f,_0x54424c){const _0x120189=y(_0x21443f),_0x3660bb=y(_0x54424c);if(_0x120189===null)return _0x54424c;if(_0x120189===_0x3660bb)return F(b(_0x21443f),b(_0x54424c));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x54424c+')\x20is\x20not\x20within\x20outerPath\x20('+_0x21443f+')');}function Rh(_0x220d2a,_0x401ce1){const _0x36f615=Pt(_0x220d2a,0x0),_0x1e1504=Pt(_0x401ce1,0x0);for(let _0x15bf49=0x0;_0x15bf49<_0x36f615['length']&&_0x15bf49<_0x1e1504['length'];_0x15bf49++){const _0x3cdea4=He(_0x36f615[_0x15bf49],_0x1e1504[_0x15bf49]);if(_0x3cdea4!==0x0)return _0x3cdea4;}return _0x36f615['length']===_0x1e1504['length']?0x0:_0x36f615['length']<_0x1e1504['length']?-0x1:0x1;}function ji(_0x466db1,_0xfa8991){if(we(_0x466db1)!==we(_0xfa8991))return!0x1;for(let _0x2feeb6=_0x466db1['pieceNum_'],_0x465322=_0xfa8991['pieceNum_'];_0x2feeb6<=_0x466db1['pieces_']['length'];_0x2feeb6++,_0x465322++)if(_0x466db1['pieces_'][_0x2feeb6]!==_0xfa8991['pieces_'][_0x465322])return!0x1;return!0x0;}function G(_0x535c96,_0x580d7e){let _0x4c0fc7=_0x535c96['pieceNum_'],_0x22d5a5=_0x580d7e['pieceNum_'];if(we(_0x535c96)>we(_0x580d7e))return!0x1;for(;_0x4c0fc7<_0x535c96['pieces_']['length'];){if(_0x535c96['pieces_'][_0x4c0fc7]!==_0x580d7e['pieces_'][_0x22d5a5])return!0x1;++_0x4c0fc7,++_0x22d5a5;}return!0x0;}class Ah{constructor(_0x38c29d,_0x466f47){this['errorPrefix_']=_0x466f47,this['parts_']=Pt(_0x38c29d,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x4749a3=0x0;_0x4749a3<this['parts_']['length'];_0x4749a3++)this['byteLength_']+=On(this['parts_'][_0x4749a3]);Ao(this);}}function kh(_0x1ed48d,_0x13e9dd){_0x1ed48d['parts_']['length']>0x0&&(_0x1ed48d['byteLength_']+=0x1),_0x1ed48d['parts_']['push'](_0x13e9dd),_0x1ed48d['byteLength_']+=On(_0x13e9dd),Ao(_0x1ed48d);}function Nh(_0x23e989){const _0x51e015=_0x23e989['parts_']['pop']();_0x23e989['byteLength_']-=On(_0x51e015),_0x23e989['parts_']['length']>0x0&&(_0x23e989['byteLength_']-=0x1);}function Ao(_0xda334e){if(_0xda334e['byteLength_']>er)throw new Error(_0xda334e['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+er+'\x20bytes\x20('+_0xda334e['byteLength_']+').');if(_0xda334e['parts_']['length']>Zs)throw new Error(_0xda334e['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Zs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Pe(_0xda334e));}function Pe(_0x19e24b){return _0x19e24b['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x19e24b['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends bo{static['getInstance'](){return new Ki();}constructor(){super(['visible']);let _0x329f1a,_0x864068;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x864068='visibilitychange',_0x329f1a='hidden'):typeof document['mozHidden']<'u'?(_0x864068='mozvisibilitychange',_0x329f1a='mozHidden'):typeof document['msHidden']<'u'?(_0x864068='msvisibilitychange',_0x329f1a='msHidden'):typeof document['webkitHidden']<'u'&&(_0x864068='webkitvisibilitychange',_0x329f1a='webkitHidden')),this['visible_']=!0x0,_0x864068&&document['addEventListener'](_0x864068,()=>{const _0x4cbeb4=!document[_0x329f1a];_0x4cbeb4!==this['visible_']&&(this['visible_']=_0x4cbeb4,this['trigger']('visible',_0x4cbeb4));},!0x1);}['getInitialEvent'](_0x3457e9){return f(_0x3457e9==='visible','Unknown\x20event\x20type:\x20'+_0x3457e9),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gt=0x3e8,Ph=0x12c*0x3e8,tr=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',nr=0x3;class se extends So{constructor(_0x45e25c,_0x309d6,_0x55385d,_0x10dcdb,_0x32a4bb,_0x494b80,_0x256095,_0x50c0f4){if(super(),this['repoInfo_']=_0x45e25c,this['applicationId_']=_0x309d6,this['onDataUpdate_']=_0x55385d,this['onConnectStatus_']=_0x10dcdb,this['onServerInfoUpdate_']=_0x32a4bb,this['authTokenProvider_']=_0x494b80,this['appCheckTokenProvider_']=_0x256095,this['authOverride_']=_0x50c0f4,this['id']=se['nextPersistentConnectionId_']++,this['log_']=Ht('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=gt,this['maxReconnectDelay_']=Ph,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x50c0f4)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Ki['getInstance']()['on']('visible',this['onVisible_'],this),_0x45e25c['host']['indexOf']('fblocal')===-0x1&&dn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x3ac15d,_0x45e63f,_0x4fbea9){const _0x3ca960=++this['requestNumber_'],_0x418a8b={'r':_0x3ca960,'a':_0x3ac15d,'b':_0x45e63f};this['log_'](O(_0x418a8b)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x418a8b),_0x4fbea9&&(this['requestCBHash_'][_0x3ca960]=_0x4fbea9);}['get'](_0x14f9ab){this['initConnection_']();const _0x3ec688=new ot(),_0xd146ad={'action':'g','request':{'p':_0x14f9ab['_path']['toString'](),'q':_0x14f9ab['_queryObject']},'onComplete':_0x287a49=>{const _0x7dc5f0=_0x287a49['d'];_0x287a49['s']==='ok'?_0x3ec688['resolve'](_0x7dc5f0):_0x3ec688['reject'](_0x7dc5f0);}};this['outstandingGets_']['push'](_0xd146ad),this['outstandingGetCount_']++;const _0x199819=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x199819),_0x3ec688['promise'];}['listen'](_0x59c0ab,_0x13892c,_0x2e0a5e,_0x180f2c){this['initConnection_']();const _0x1ec955=_0x59c0ab['_queryIdentifier'],_0x41d362=_0x59c0ab['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x41d362+'\x20'+_0x1ec955),this['listens']['has'](_0x41d362)||this['listens']['set'](_0x41d362,new Map()),f(_0x59c0ab['_queryParams']['isDefault']()||!_0x59c0ab['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x41d362)['has'](_0x1ec955),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0xdeb03a={'onComplete':_0x180f2c,'hashFn':_0x13892c,'query':_0x59c0ab,'tag':_0x2e0a5e};this['listens']['get'](_0x41d362)['set'](_0x1ec955,_0xdeb03a),this['connected_']&&this['sendListen_'](_0xdeb03a);}['sendGet_'](_0x449d84){const _0x196444=this['outstandingGets_'][_0x449d84];this['sendRequest']('g',_0x196444['request'],_0x4e0fb6=>{delete this['outstandingGets_'][_0x449d84],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x196444['onComplete']&&_0x196444['onComplete'](_0x4e0fb6);});}['sendListen_'](_0xfe14c1){const _0x3ec86a=_0xfe14c1['query'],_0x1f245e=_0x3ec86a['_path']['toString'](),_0x48e933=_0x3ec86a['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x1f245e+'\x20for\x20'+_0x48e933);const _0x4df606={'p':_0x1f245e},_0x5dd4d7='q';_0xfe14c1['tag']&&(_0x4df606['q']=_0x3ec86a['_queryObject'],_0x4df606['t']=_0xfe14c1['tag']),_0x4df606['h']=_0xfe14c1['hashFn'](),this['sendRequest'](_0x5dd4d7,_0x4df606,_0x48cb8d=>{const _0x54c798=_0x48cb8d['d'],_0x102b6e=_0x48cb8d['s'];se['warnOnListenWarnings_'](_0x54c798,_0x3ec86a),(this['listens']['get'](_0x1f245e)&&this['listens']['get'](_0x1f245e)['get'](_0x48e933))===_0xfe14c1&&(this['log_']('listen\x20response',_0x48cb8d),_0x102b6e!=='ok'&&this['removeListen_'](_0x1f245e,_0x48e933),_0xfe14c1['onComplete']&&_0xfe14c1['onComplete'](_0x102b6e,_0x54c798));});}static['warnOnListenWarnings_'](_0x24d736,_0x5f3e27){if(_0x24d736&&typeof _0x24d736=='object'&&J(_0x24d736,'w')){const _0x3f47f1=De(_0x24d736,'w');if(Array['isArray'](_0x3f47f1)&&~_0x3f47f1['indexOf']('no_index')){const _0x40cd4b='\x22.indexOn\x22:\x20\x22'+_0x5f3e27['_queryParams']['getIndex']()['toString']()+'\x22',_0x10bc6e=_0x5f3e27['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x40cd4b+'\x20at\x20'+_0x10bc6e+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x358abf){this['authToken_']=_0x358abf,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x358abf);}['reduceReconnectDelayIfAdminCredential_'](_0x15c05d){(_0x15c05d&&_0x15c05d['length']===0x28||wc(_0x15c05d))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=tr);}['refreshAppCheckToken'](_0x47df8c){this['appCheckToken_']=_0x47df8c,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0xe67dec=this['authToken_'],_0x3c6d1e=Ic(_0xe67dec)?'auth':'gauth',_0x17b441={'cred':_0xe67dec};this['authOverride_']===null?_0x17b441['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x17b441['authvar']=this['authOverride_']),this['sendRequest'](_0x3c6d1e,_0x17b441,_0x5bab1a=>{const _0x4a6e20=_0x5bab1a['s'],_0x3e538b=_0x5bab1a['d']||'error';this['authToken_']===_0xe67dec&&(_0x4a6e20==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x4a6e20,_0x3e538b));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x2a461a=>{const _0x19f690=_0x2a461a['s'],_0x5c070d=_0x2a461a['d']||'error';_0x19f690==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x19f690,_0x5c070d);});}['unlisten'](_0x3b161a,_0x631a7){const _0x3a7326=_0x3b161a['_path']['toString'](),_0x22373f=_0x3b161a['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x3a7326+'\x20'+_0x22373f),f(_0x3b161a['_queryParams']['isDefault']()||!_0x3b161a['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x3a7326,_0x22373f)&&this['connected_']&&this['sendUnlisten_'](_0x3a7326,_0x22373f,_0x3b161a['_queryObject'],_0x631a7);}['sendUnlisten_'](_0x226acd,_0x41247c,_0x3eb720,_0x4bcc1b){this['log_']('Unlisten\x20on\x20'+_0x226acd+'\x20for\x20'+_0x41247c);const _0x47ee8f={'p':_0x226acd},_0x398f05='n';_0x4bcc1b&&(_0x47ee8f['q']=_0x3eb720,_0x47ee8f['t']=_0x4bcc1b),this['sendRequest'](_0x398f05,_0x47ee8f);}['onDisconnectPut'](_0x21cc92,_0x1ef0a8,_0x4e6146){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x21cc92,_0x1ef0a8,_0x4e6146):this['onDisconnectRequestQueue_']['push']({'pathString':_0x21cc92,'action':'o','data':_0x1ef0a8,'onComplete':_0x4e6146});}['onDisconnectMerge'](_0x5d00c5,_0x4b4081,_0x2ba219){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x5d00c5,_0x4b4081,_0x2ba219):this['onDisconnectRequestQueue_']['push']({'pathString':_0x5d00c5,'action':'om','data':_0x4b4081,'onComplete':_0x2ba219});}['onDisconnectCancel'](_0x95c8e7,_0x343662){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x95c8e7,null,_0x343662):this['onDisconnectRequestQueue_']['push']({'pathString':_0x95c8e7,'action':'oc','data':null,'onComplete':_0x343662});}['sendOnDisconnect_'](_0x2d20f5,_0x2fad83,_0x3df58f,_0x5ed0ad){const _0x1dbdfa={'p':_0x2fad83,'d':_0x3df58f};this['log_']('onDisconnect\x20'+_0x2d20f5,_0x1dbdfa),this['sendRequest'](_0x2d20f5,_0x1dbdfa,_0x24a9ca=>{_0x5ed0ad&&setTimeout(()=>{_0x5ed0ad(_0x24a9ca['s'],_0x24a9ca['d']);},Math['floor'](0x0));});}['put'](_0x1464a8,_0x102dc1,_0x494769,_0xc1dc9c){this['putInternal']('p',_0x1464a8,_0x102dc1,_0x494769,_0xc1dc9c);}['merge'](_0x1de343,_0x56c546,_0x3a7547,_0x269225){this['putInternal']('m',_0x1de343,_0x56c546,_0x3a7547,_0x269225);}['putInternal'](_0x14db8e,_0x120bfc,_0x276fac,_0x440c4e,_0x181fd1){this['initConnection_']();const _0x10e05f={'p':_0x120bfc,'d':_0x276fac};_0x181fd1!==void 0x0&&(_0x10e05f['h']=_0x181fd1),this['outstandingPuts_']['push']({'action':_0x14db8e,'request':_0x10e05f,'onComplete':_0x440c4e}),this['outstandingPutCount_']++;const _0x2ca345=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x2ca345):this['log_']('Buffering\x20put:\x20'+_0x120bfc);}['sendPut_'](_0x259178){const _0x97a68f=this['outstandingPuts_'][_0x259178]['action'],_0x252135=this['outstandingPuts_'][_0x259178]['request'],_0x1b2d74=this['outstandingPuts_'][_0x259178]['onComplete'];this['outstandingPuts_'][_0x259178]['queued']=this['connected_'],this['sendRequest'](_0x97a68f,_0x252135,_0x558c75=>{this['log_'](_0x97a68f+'\x20response',_0x558c75),delete this['outstandingPuts_'][_0x259178],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x1b2d74&&_0x1b2d74(_0x558c75['s'],_0x558c75['d']);});}['reportStats'](_0xf78d4c){if(this['connected_']){const _0x584102={'c':_0xf78d4c};this['log_']('reportStats',_0x584102),this['sendRequest']('s',_0x584102,_0x324aa7=>{if(_0x324aa7['s']!=='ok'){const _0x586d60=_0x324aa7['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x586d60);}});}}['onDataMessage_'](_0x379a9a){if('r'in _0x379a9a){this['log_']('from\x20server:\x20'+O(_0x379a9a));const _0x3af974=_0x379a9a['r'],_0xc092e8=this['requestCBHash_'][_0x3af974];_0xc092e8&&(delete this['requestCBHash_'][_0x3af974],_0xc092e8(_0x379a9a['b']));}else{if('error'in _0x379a9a)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x379a9a['error'];'a'in _0x379a9a&&this['onDataPush_'](_0x379a9a['a'],_0x379a9a['b']);}}['onDataPush_'](_0x4a120a,_0x1dd879){this['log_']('handleServerMessage',_0x4a120a,_0x1dd879),_0x4a120a==='d'?this['onDataUpdate_'](_0x1dd879['p'],_0x1dd879['d'],!0x1,_0x1dd879['t']):_0x4a120a==='m'?this['onDataUpdate_'](_0x1dd879['p'],_0x1dd879['d'],!0x0,_0x1dd879['t']):_0x4a120a==='c'?this['onListenRevoked_'](_0x1dd879['p'],_0x1dd879['q']):_0x4a120a==='ac'?this['onAuthRevoked_'](_0x1dd879['s'],_0x1dd879['d']):_0x4a120a==='apc'?this['onAppCheckRevoked_'](_0x1dd879['s'],_0x1dd879['d']):_0x4a120a==='sd'?this['onSecurityDebugPacket_'](_0x1dd879):yi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x4a120a)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x27e663,_0x1ef2ef){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x27e663),this['lastSessionId']=_0x1ef2ef,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x1f404f){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x1f404f));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x5e07f2){_0x5e07f2&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x5e07f2;}['onOnline_'](_0x4aac2f){_0x4aac2f?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=gt),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x3e44ad=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0xe5c8e9=Math['max'](0x0,this['reconnectDelay_']-_0x3e44ad);_0xe5c8e9=Math['random']()*_0xe5c8e9,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0xe5c8e9+'ms'),this['scheduleConnect_'](_0xe5c8e9),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x35a8ea=this['onDataMessage_']['bind'](this),_0xbb8eaa=this['onReady_']['bind'](this),_0x1e7090=this['onRealtimeDisconnect_']['bind'](this),_0x5e8b87=this['id']+':'+se['nextConnectionId_']++,_0x1933d5=this['lastSessionId'];let _0x15da67=!0x1,_0x58d1f1=null;const _0x59ce7a=function(){_0x58d1f1?_0x58d1f1['close']():(_0x15da67=!0x0,_0x1e7090());},_0x54bfe1=function(_0x346911){f(_0x58d1f1,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x58d1f1['sendRequest'](_0x346911);};this['realtime_']={'close':_0x59ce7a,'sendRequest':_0x54bfe1};const _0x31a053=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x47406f,_0x56824a]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x31a053),this['appCheckTokenProvider_']['getToken'](_0x31a053)]);_0x15da67?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x47406f&&_0x47406f['accessToken'],this['appCheckToken_']=_0x56824a&&_0x56824a['token'],_0x58d1f1=new Sh(_0x5e8b87,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x35a8ea,_0xbb8eaa,_0x1e7090,_0x5c87c3=>{U(_0x5c87c3+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x1933d5));}catch(_0x2f25c0){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x2f25c0),_0x15da67||(this['repoInfo_']['nodeAdmin']&&U(_0x2f25c0),_0x59ce7a());}}}['interrupt'](_0x3c34a5){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x3c34a5),this['interruptReasons_'][_0x3c34a5]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x2c9a44){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x2c9a44),delete this['interruptReasons_'][_0x2c9a44],ui(this['interruptReasons_'])&&(this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x20b279){const _0x4a4ebc=_0x20b279-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x4a4ebc});}['cancelSentTransactions_'](){for(let _0x2ff330=0x0;_0x2ff330<this['outstandingPuts_']['length'];_0x2ff330++){const _0xe48dcb=this['outstandingPuts_'][_0x2ff330];_0xe48dcb&&'h'in _0xe48dcb['request']&&_0xe48dcb['queued']&&(_0xe48dcb['onComplete']&&_0xe48dcb['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x2ff330],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x3fd1ef,_0x5464ed){let _0x1013a3;_0x5464ed?_0x1013a3=_0x5464ed['map'](_0x255ce8=>Hi(_0x255ce8))['join']('$'):_0x1013a3='default';const _0x2406c4=this['removeListen_'](_0x3fd1ef,_0x1013a3);_0x2406c4&&_0x2406c4['onComplete']&&_0x2406c4['onComplete']('permission_denied');}['removeListen_'](_0x4ceb50,_0x4abccb){const _0x9778a2=new C(_0x4ceb50)['toString']();let _0x51ec06;if(this['listens']['has'](_0x9778a2)){const _0x39e5c8=this['listens']['get'](_0x9778a2);_0x51ec06=_0x39e5c8['get'](_0x4abccb),_0x39e5c8['delete'](_0x4abccb),_0x39e5c8['size']===0x0&&this['listens']['delete'](_0x9778a2);}else _0x51ec06=void 0x0;return _0x51ec06;}['onAuthRevoked_'](_0x17c195,_0x4ee27c){L('Auth\x20token\x20revoked:\x20'+_0x17c195+'/'+_0x4ee27c),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x17c195==='invalid_token'||_0x17c195==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=nr&&(this['reconnectDelay_']=tr,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x3ccd41,_0x3c23d1){L('App\x20check\x20token\x20revoked:\x20'+_0x3ccd41+'/'+_0x3c23d1),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x3ccd41==='invalid_token'||_0x3ccd41==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=nr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x924fdd){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x924fdd):'msg'in _0x924fdd&&console['log']('FIREBASE:\x20'+_0x924fdd['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x4e26f4 of this['listens']['values']())for(const _0x39d5af of _0x4e26f4['values']())this['sendListen_'](_0x39d5af);for(let _0x543265=0x0;_0x543265<this['outstandingPuts_']['length'];_0x543265++)this['outstandingPuts_'][_0x543265]&&this['sendPut_'](_0x543265);for(;this['onDisconnectRequestQueue_']['length'];){const _0x2dd554=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x2dd554['action'],_0x2dd554['pathString'],_0x2dd554['data'],_0x2dd554['onComplete']);}for(let _0x59232a=0x0;_0x59232a<this['outstandingGets_']['length'];_0x59232a++)this['outstandingGets_'][_0x59232a]&&this['sendGet_'](_0x59232a);}['sendConnectStats_'](){const _0x3ae540={};let _0x26cae3='js';_0x3ae540['sdk.'+_0x26cae3+'.'+no['replace'](/\./g,'-')]=0x1,Fi()?_0x3ae540['framework.cordova']=0x1:Yr()&&(_0x3ae540['framework.reactnative']=0x1),this['reportStats'](_0x3ae540);}['shouldReconnect_'](){const _0x26c60e=dn['getInstance']()['currentlyOnline']();return ui(this['interruptReasons_'])&&_0x26c60e;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x5a28ed,_0x58fc08){this['name']=_0x5a28ed,this['node']=_0x58fc08;}static['Wrap'](_0x4568cd,_0x466287){return new E(_0x4568cd,_0x466287);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x111bd0,_0x274b2f){const _0x4309f0=new E(Fe,_0x111bd0),_0x6ac2e1=new E(Fe,_0x274b2f);return this['compare'](_0x4309f0,_0x6ac2e1)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zt;class ko extends Dn{static get['__EMPTY_NODE'](){return Zt;}static set['__EMPTY_NODE'](_0xe59f95){Zt=_0xe59f95;}['compare'](_0x335a35,_0x2c9d94){return He(_0x335a35['name'],_0x2c9d94['name']);}['isDefinedOn'](_0x5804ca){throw rt('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x2e6b0c,_0x544394){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Zt);}['makePost'](_0x4d73b3,_0x4435c4){return f(typeof _0x4d73b3=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x4d73b3,Zt);}['toString'](){return'.key';}}const ye=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class en{constructor(_0x24f09b,_0x1f78e0,_0x3d4dfc,_0x9205b9,_0x15c8da=null){this['isReverse_']=_0x9205b9,this['resultGenerator_']=_0x15c8da,this['nodeStack_']=[];let _0x4071de=0x1;for(;!_0x24f09b['isEmpty']();)if(_0x24f09b=_0x24f09b,_0x4071de=_0x1f78e0?_0x3d4dfc(_0x24f09b['key'],_0x1f78e0):0x1,_0x9205b9&&(_0x4071de*=-0x1),_0x4071de<0x0)this['isReverse_']?_0x24f09b=_0x24f09b['left']:_0x24f09b=_0x24f09b['right'];else{if(_0x4071de===0x0){this['nodeStack_']['push'](_0x24f09b);break;}else this['nodeStack_']['push'](_0x24f09b),this['isReverse_']?_0x24f09b=_0x24f09b['right']:_0x24f09b=_0x24f09b['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x1d9300=this['nodeStack_']['pop'](),_0x20ebd5;if(this['resultGenerator_']?_0x20ebd5=this['resultGenerator_'](_0x1d9300['key'],_0x1d9300['value']):_0x20ebd5={'key':_0x1d9300['key'],'value':_0x1d9300['value']},this['isReverse_']){for(_0x1d9300=_0x1d9300['left'];!_0x1d9300['isEmpty']();)this['nodeStack_']['push'](_0x1d9300),_0x1d9300=_0x1d9300['right'];}else{for(_0x1d9300=_0x1d9300['right'];!_0x1d9300['isEmpty']();)this['nodeStack_']['push'](_0x1d9300),_0x1d9300=_0x1d9300['left'];}return _0x20ebd5;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x464384=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x464384['key'],_0x464384['value']):{'key':_0x464384['key'],'value':_0x464384['value']};}}class M{constructor(_0x464aed,_0x5379b4,_0x28f87a,_0x370ba3,_0x20994d){this['key']=_0x464aed,this['value']=_0x5379b4,this['color']=_0x28f87a??M['RED'],this['left']=_0x370ba3??B['EMPTY_NODE'],this['right']=_0x20994d??B['EMPTY_NODE'];}['copy'](_0x73f9f8,_0x19176d,_0x375774,_0x13a1d1,_0x285e03){return new M(_0x73f9f8??this['key'],_0x19176d??this['value'],_0x375774??this['color'],_0x13a1d1??this['left'],_0x285e03??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x2fe4ba){return this['left']['inorderTraversal'](_0x2fe4ba)||!!_0x2fe4ba(this['key'],this['value'])||this['right']['inorderTraversal'](_0x2fe4ba);}['reverseTraversal'](_0x1232f7){return this['right']['reverseTraversal'](_0x1232f7)||_0x1232f7(this['key'],this['value'])||this['left']['reverseTraversal'](_0x1232f7);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x3b6c9c,_0x481a49,_0x3e06e0){let _0x2c07fb=this;const _0x456d50=_0x3e06e0(_0x3b6c9c,_0x2c07fb['key']);return _0x456d50<0x0?_0x2c07fb=_0x2c07fb['copy'](null,null,null,_0x2c07fb['left']['insert'](_0x3b6c9c,_0x481a49,_0x3e06e0),null):_0x456d50===0x0?_0x2c07fb=_0x2c07fb['copy'](null,_0x481a49,null,null,null):_0x2c07fb=_0x2c07fb['copy'](null,null,null,null,_0x2c07fb['right']['insert'](_0x3b6c9c,_0x481a49,_0x3e06e0)),_0x2c07fb['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x2d61f9=this;return!_0x2d61f9['left']['isRed_']()&&!_0x2d61f9['left']['left']['isRed_']()&&(_0x2d61f9=_0x2d61f9['moveRedLeft_']()),_0x2d61f9=_0x2d61f9['copy'](null,null,null,_0x2d61f9['left']['removeMin_'](),null),_0x2d61f9['fixUp_']();}['remove'](_0x32841e,_0x14e88a){let _0x1353d0,_0x512e9b;if(_0x1353d0=this,_0x14e88a(_0x32841e,_0x1353d0['key'])<0x0)!_0x1353d0['left']['isEmpty']()&&!_0x1353d0['left']['isRed_']()&&!_0x1353d0['left']['left']['isRed_']()&&(_0x1353d0=_0x1353d0['moveRedLeft_']()),_0x1353d0=_0x1353d0['copy'](null,null,null,_0x1353d0['left']['remove'](_0x32841e,_0x14e88a),null);else{if(_0x1353d0['left']['isRed_']()&&(_0x1353d0=_0x1353d0['rotateRight_']()),!_0x1353d0['right']['isEmpty']()&&!_0x1353d0['right']['isRed_']()&&!_0x1353d0['right']['left']['isRed_']()&&(_0x1353d0=_0x1353d0['moveRedRight_']()),_0x14e88a(_0x32841e,_0x1353d0['key'])===0x0){if(_0x1353d0['right']['isEmpty']())return B['EMPTY_NODE'];_0x512e9b=_0x1353d0['right']['min_'](),_0x1353d0=_0x1353d0['copy'](_0x512e9b['key'],_0x512e9b['value'],null,null,_0x1353d0['right']['removeMin_']());}_0x1353d0=_0x1353d0['copy'](null,null,null,null,_0x1353d0['right']['remove'](_0x32841e,_0x14e88a));}return _0x1353d0['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x2ca454=this;return _0x2ca454['right']['isRed_']()&&!_0x2ca454['left']['isRed_']()&&(_0x2ca454=_0x2ca454['rotateLeft_']()),_0x2ca454['left']['isRed_']()&&_0x2ca454['left']['left']['isRed_']()&&(_0x2ca454=_0x2ca454['rotateRight_']()),_0x2ca454['left']['isRed_']()&&_0x2ca454['right']['isRed_']()&&(_0x2ca454=_0x2ca454['colorFlip_']()),_0x2ca454;}['moveRedLeft_'](){let _0x33feb6=this['colorFlip_']();return _0x33feb6['right']['left']['isRed_']()&&(_0x33feb6=_0x33feb6['copy'](null,null,null,null,_0x33feb6['right']['rotateRight_']()),_0x33feb6=_0x33feb6['rotateLeft_'](),_0x33feb6=_0x33feb6['colorFlip_']()),_0x33feb6;}['moveRedRight_'](){let _0x57628b=this['colorFlip_']();return _0x57628b['left']['left']['isRed_']()&&(_0x57628b=_0x57628b['rotateRight_'](),_0x57628b=_0x57628b['colorFlip_']()),_0x57628b;}['rotateLeft_'](){const _0x2d0b5e=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x2d0b5e,null);}['rotateRight_'](){const _0x108408=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x108408);}['colorFlip_'](){const _0x2b574d=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x46572a=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x2b574d,_0x46572a);}['checkMaxDepth_'](){const _0xcb0a26=this['check_']();return Math['pow'](0x2,_0xcb0a26)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x304d43=this['left']['check_']();if(_0x304d43!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x304d43+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x450535,_0xf5e32,_0xc4763e,_0x1cc8fc,_0x2561f5){return this;}['insert'](_0x33901f,_0x45c732,_0x26b546){return new M(_0x33901f,_0x45c732,null);}['remove'](_0x1f2e71,_0x59bd49){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x12dd5b){return!0x1;}['reverseTraversal'](_0x53eb7b){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x4e83db,_0x48a5fe=B['EMPTY_NODE']){this['comparator_']=_0x4e83db,this['root_']=_0x48a5fe;}['insert'](_0x35c8be,_0x543642){return new B(this['comparator_'],this['root_']['insert'](_0x35c8be,_0x543642,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x2d9c83){return new B(this['comparator_'],this['root_']['remove'](_0x2d9c83,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x545e20){let _0xef1338,_0x4a70b5=this['root_'];for(;!_0x4a70b5['isEmpty']();){if(_0xef1338=this['comparator_'](_0x545e20,_0x4a70b5['key']),_0xef1338===0x0)return _0x4a70b5['value'];_0xef1338<0x0?_0x4a70b5=_0x4a70b5['left']:_0xef1338>0x0&&(_0x4a70b5=_0x4a70b5['right']);}return null;}['getPredecessorKey'](_0x592948){let _0x2b1063,_0x190d90=this['root_'],_0x2ec313=null;for(;!_0x190d90['isEmpty']();)if(_0x2b1063=this['comparator_'](_0x592948,_0x190d90['key']),_0x2b1063===0x0){if(_0x190d90['left']['isEmpty']())return _0x2ec313?_0x2ec313['key']:null;for(_0x190d90=_0x190d90['left'];!_0x190d90['right']['isEmpty']();)_0x190d90=_0x190d90['right'];return _0x190d90['key'];}else _0x2b1063<0x0?_0x190d90=_0x190d90['left']:_0x2b1063>0x0&&(_0x2ec313=_0x190d90,_0x190d90=_0x190d90['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x121f51){return this['root_']['inorderTraversal'](_0x121f51);}['reverseTraversal'](_0x3799d1){return this['root_']['reverseTraversal'](_0x3799d1);}['getIterator'](_0x2c0122){return new en(this['root_'],null,this['comparator_'],!0x1,_0x2c0122);}['getIteratorFrom'](_0x3b206f,_0x3d2056){return new en(this['root_'],_0x3b206f,this['comparator_'],!0x1,_0x3d2056);}['getReverseIteratorFrom'](_0x5c2bb6,_0x3ea55b){return new en(this['root_'],_0x5c2bb6,this['comparator_'],!0x0,_0x3ea55b);}['getReverseIterator'](_0xbe4630){return new en(this['root_'],null,this['comparator_'],!0x0,_0xbe4630);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x2e6242,_0x561cb7){return He(_0x2e6242['name'],_0x561cb7['name']);}function Yi(_0x35a2fe,_0x2614a5){return He(_0x35a2fe,_0x2614a5);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ei;function Fh(_0x164ad6){Ei=_0x164ad6;}const No=function(_0x28c302){return typeof _0x28c302=='number'?'number:'+ao(_0x28c302):'string:'+_0x28c302;},Po=function(_0x1df48a){if(_0x1df48a['isLeafNode']()){const _0x52a527=_0x1df48a['val']();f(typeof _0x52a527=='string'||typeof _0x52a527=='number'||typeof _0x52a527=='object'&&J(_0x52a527,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x1df48a===Ei||_0x1df48a['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x1df48a===Ei||_0x1df48a['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ir;class D{static set['__childrenNodeConstructor'](_0x3889e6){ir=_0x3889e6;}static get['__childrenNodeConstructor'](){return ir;}constructor(_0x53f07a,_0x990816=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x53f07a,this['priorityNode_']=_0x990816,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Po(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x1aff28){return new D(this['value_'],_0x1aff28);}['getImmediateChild'](_0x3a640f){return _0x3a640f==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x54a3b3){return v(_0x54a3b3)?this:y(_0x54a3b3)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x42e76d,_0x2e3694){return null;}['updateImmediateChild'](_0x11bdff,_0x10386a){return _0x11bdff==='.priority'?this['updatePriority'](_0x10386a):_0x10386a['isEmpty']()&&_0x11bdff!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x11bdff,_0x10386a)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x4b34d2,_0xb7ee6b){const _0x340a03=y(_0x4b34d2);return _0x340a03===null?_0xb7ee6b:_0xb7ee6b['isEmpty']()&&_0x340a03!=='.priority'?this:(f(_0x340a03!=='.priority'||we(_0x4b34d2)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x340a03,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x4b34d2),_0xb7ee6b)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x54bbb5,_0x1be5f1){return!0x1;}['val'](_0xadca90){return _0xadca90&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x24689c='';this['priorityNode_']['isEmpty']()||(_0x24689c+='priority:'+No(this['priorityNode_']['val']())+':');const _0x1ae2ab=typeof this['value_'];_0x24689c+=_0x1ae2ab+':',_0x1ae2ab==='number'?_0x24689c+=ao(this['value_']):_0x24689c+=this['value_'],this['lazyHash_']=ro(_0x24689c);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x4e96cc){return _0x4e96cc===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x4e96cc instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x4e96cc['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x4e96cc));}['compareToLeafNode_'](_0x4269cf){const _0x146074=typeof _0x4269cf['value_'],_0x26b259=typeof this['value_'],_0x34e900=D['VALUE_TYPE_ORDER']['indexOf'](_0x146074),_0x45d6d2=D['VALUE_TYPE_ORDER']['indexOf'](_0x26b259);return f(_0x34e900>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x146074),f(_0x45d6d2>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x26b259),_0x34e900===_0x45d6d2?_0x26b259==='object'?0x0:this['value_']<_0x4269cf['value_']?-0x1:this['value_']===_0x4269cf['value_']?0x0:0x1:_0x45d6d2-_0x34e900;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x46c50c){if(_0x46c50c===this)return!0x0;if(_0x46c50c['isLeafNode']()){const _0x4602ce=_0x46c50c;return this['value_']===_0x4602ce['value_']&&this['priorityNode_']['equals'](_0x4602ce['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x5588f0){Oo=_0x5588f0;}function Wh(_0x4b4ab0){Do=_0x4b4ab0;}class Bh extends Dn{['compare'](_0x3f9f81,_0x467cd3){const _0x5baf99=_0x3f9f81['node']['getPriority'](),_0x189f39=_0x467cd3['node']['getPriority'](),_0x52dabd=_0x5baf99['compareTo'](_0x189f39);return _0x52dabd===0x0?He(_0x3f9f81['name'],_0x467cd3['name']):_0x52dabd;}['isDefinedOn'](_0x500b0c){return!_0x500b0c['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x2f7c77,_0x4370ba){return!_0x2f7c77['getPriority']()['equals'](_0x4370ba['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',Do));}['makePost'](_0x2ec06f,_0x3e3a9d){const _0x48b166=Oo(_0x2ec06f);return new E(_0x3e3a9d,new D('[PRIORITY-POST]',_0x48b166));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x3dcf6c){const _0x478aa8=_0x1c53be=>parseInt(Math['log'](_0x1c53be)/Vh,0xa),_0x5248fc=_0x5ad0e3=>parseInt(Array(_0x5ad0e3+0x1)['join']('1'),0x2);this['count']=_0x478aa8(_0x3dcf6c+0x1),this['current_']=this['count']-0x1;const _0x594230=_0x5248fc(this['count']);this['bits_']=_0x3dcf6c+0x1&_0x594230;}['nextBitIsOne'](){const _0x585bd4=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x585bd4;}}const fn=function(_0x5f4665,_0x5e0162,_0x1a9993,_0x5607ad){_0x5f4665['sort'](_0x5e0162);const _0x505e2c=function(_0x4977e6,_0x52f3f4){const _0x390d40=_0x52f3f4-_0x4977e6;let _0xda2f49,_0x6155cb;if(_0x390d40===0x0)return null;if(_0x390d40===0x1)return _0xda2f49=_0x5f4665[_0x4977e6],_0x6155cb=_0x1a9993?_0x1a9993(_0xda2f49):_0xda2f49,new M(_0x6155cb,_0xda2f49['node'],M['BLACK'],null,null);{const _0x55471e=parseInt(_0x390d40/0x2,0xa)+_0x4977e6,_0x1390f5=_0x505e2c(_0x4977e6,_0x55471e),_0x5ef4e1=_0x505e2c(_0x55471e+0x1,_0x52f3f4);return _0xda2f49=_0x5f4665[_0x55471e],_0x6155cb=_0x1a9993?_0x1a9993(_0xda2f49):_0xda2f49,new M(_0x6155cb,_0xda2f49['node'],M['BLACK'],_0x1390f5,_0x5ef4e1);}},_0x50d34c=function(_0x17150d){let _0x2c4488=null,_0x5db65f=null,_0x2d949d=_0x5f4665['length'];const _0x30f5f4=function(_0x2b3f93,_0x42420b){const _0x6d4fbe=_0x2d949d-_0x2b3f93,_0x38a29a=_0x2d949d;_0x2d949d-=_0x2b3f93;const _0x5c7b39=_0x505e2c(_0x6d4fbe+0x1,_0x38a29a),_0x55540e=_0x5f4665[_0x6d4fbe],_0x43eede=_0x1a9993?_0x1a9993(_0x55540e):_0x55540e;_0x2d9830(new M(_0x43eede,_0x55540e['node'],_0x42420b,null,_0x5c7b39));},_0x2d9830=function(_0x5bd566){_0x2c4488?(_0x2c4488['left']=_0x5bd566,_0x2c4488=_0x5bd566):(_0x5db65f=_0x5bd566,_0x2c4488=_0x5bd566);};for(let _0xe6f80f=0x0;_0xe6f80f<_0x17150d['count'];++_0xe6f80f){const _0x3fc1fd=_0x17150d['nextBitIsOne'](),_0x118b5c=Math['pow'](0x2,_0x17150d['count']-(_0xe6f80f+0x1));_0x3fc1fd?_0x30f5f4(_0x118b5c,M['BLACK']):(_0x30f5f4(_0x118b5c,M['BLACK']),_0x30f5f4(_0x118b5c,M['RED']));}return _0x5db65f;},_0x295741=new Hh(_0x5f4665['length']),_0x508ea3=_0x50d34c(_0x295741);return new B(_0x5607ad||_0x5e0162,_0x508ea3);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ze={};class te{static get['Default'](){return f(ze&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),ri=ri||new te({'.priority':ze},{'.priority':R}),ri;}constructor(_0x51ac5e,_0x2c05b5){this['indexes_']=_0x51ac5e,this['indexSet_']=_0x2c05b5;}['get'](_0x2ef9ce){const _0x6a271=De(this['indexes_'],_0x2ef9ce);if(!_0x6a271)throw new Error('No\x20index\x20defined\x20for\x20'+_0x2ef9ce);return _0x6a271 instanceof B?_0x6a271:null;}['hasIndex'](_0xcf261a){return J(this['indexSet_'],_0xcf261a['toString']());}['addIndex'](_0x3469df,_0x2c5292){f(_0x3469df!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x2ed7bb=[];let _0x595852=!0x1;const _0x5eab0d=_0x2c5292['getIterator'](E['Wrap']);let _0x3b6684=_0x5eab0d['getNext']();for(;_0x3b6684;)_0x595852=_0x595852||_0x3469df['isDefinedOn'](_0x3b6684['node']),_0x2ed7bb['push'](_0x3b6684),_0x3b6684=_0x5eab0d['getNext']();let _0x4a5847;_0x595852?_0x4a5847=fn(_0x2ed7bb,_0x3469df['getCompare']()):_0x4a5847=ze;const _0x58e826=_0x3469df['toString'](),_0x2e50c6={...this['indexSet_']};_0x2e50c6[_0x58e826]=_0x3469df;const _0x2f0267={...this['indexes_']};return _0x2f0267[_0x58e826]=_0x4a5847,new te(_0x2f0267,_0x2e50c6);}['addToIndexes'](_0x583847,_0x418606){const _0x38a5ef=hn(this['indexes_'],(_0x44343e,_0x177bee)=>{const _0xfadb90=De(this['indexSet_'],_0x177bee);if(f(_0xfadb90,'Missing\x20index\x20implementation\x20for\x20'+_0x177bee),_0x44343e===ze){if(_0xfadb90['isDefinedOn'](_0x583847['node'])){const _0x47780c=[],_0x4c302b=_0x418606['getIterator'](E['Wrap']);let _0x1ce011=_0x4c302b['getNext']();for(;_0x1ce011;)_0x1ce011['name']!==_0x583847['name']&&_0x47780c['push'](_0x1ce011),_0x1ce011=_0x4c302b['getNext']();return _0x47780c['push'](_0x583847),fn(_0x47780c,_0xfadb90['getCompare']());}else return ze;}else{const _0x1c043f=_0x418606['get'](_0x583847['name']);let _0x5b873f=_0x44343e;return _0x1c043f&&(_0x5b873f=_0x5b873f['remove'](new E(_0x583847['name'],_0x1c043f))),_0x5b873f['insert'](_0x583847,_0x583847['node']);}});return new te(_0x38a5ef,this['indexSet_']);}['removeFromIndexes'](_0x1f2428,_0x2c5479){const _0x312a01=hn(this['indexes_'],_0xaf6096=>{if(_0xaf6096===ze)return _0xaf6096;{const _0x1d4128=_0x2c5479['get'](_0x1f2428['name']);return _0x1d4128?_0xaf6096['remove'](new E(_0x1f2428['name'],_0x1d4128)):_0xaf6096;}});return new te(_0x312a01,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let mt;class g{static get['EMPTY_NODE'](){return mt||(mt=new g(new B(Yi),null,te['Default']));}constructor(_0x464681,_0x10f9c9,_0x1e79b9){this['children_']=_0x464681,this['priorityNode_']=_0x10f9c9,this['indexMap_']=_0x1e79b9,this['lazyHash_']=null,this['priorityNode_']&&Po(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||mt;}['updatePriority'](_0x45739e){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x45739e,this['indexMap_']);}['getImmediateChild'](_0xe3920f){if(_0xe3920f==='.priority')return this['getPriority']();{const _0x21808b=this['children_']['get'](_0xe3920f);return _0x21808b===null?mt:_0x21808b;}}['getChild'](_0x2eefaf){const _0x234b24=y(_0x2eefaf);return _0x234b24===null?this:this['getImmediateChild'](_0x234b24)['getChild'](b(_0x2eefaf));}['hasChild'](_0x14694c){return this['children_']['get'](_0x14694c)!==null;}['updateImmediateChild'](_0x59db97,_0x5f2613){if(f(_0x5f2613,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x59db97==='.priority')return this['updatePriority'](_0x5f2613);{const _0x5bb5f2=new E(_0x59db97,_0x5f2613);let _0x125c03,_0x4d1868;_0x5f2613['isEmpty']()?(_0x125c03=this['children_']['remove'](_0x59db97),_0x4d1868=this['indexMap_']['removeFromIndexes'](_0x5bb5f2,this['children_'])):(_0x125c03=this['children_']['insert'](_0x59db97,_0x5f2613),_0x4d1868=this['indexMap_']['addToIndexes'](_0x5bb5f2,this['children_']));const _0xa84c8a=_0x125c03['isEmpty']()?mt:this['priorityNode_'];return new g(_0x125c03,_0xa84c8a,_0x4d1868);}}['updateChild'](_0x492219,_0x1d16d5){const _0x52c562=y(_0x492219);if(_0x52c562===null)return _0x1d16d5;{f(y(_0x492219)!=='.priority'||we(_0x492219)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x381948=this['getImmediateChild'](_0x52c562)['updateChild'](b(_0x492219),_0x1d16d5);return this['updateImmediateChild'](_0x52c562,_0x381948);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x47250c){if(this['isEmpty']())return null;const _0x5a7a66={};let _0x36bfda=0x0,_0x27f9ec=0x0,_0x5c5195=!0x0;if(this['forEachChild'](R,(_0x43ed61,_0x154887)=>{_0x5a7a66[_0x43ed61]=_0x154887['val'](_0x47250c),_0x36bfda++,_0x5c5195&&g['INTEGER_REGEXP_']['test'](_0x43ed61)?_0x27f9ec=Math['max'](_0x27f9ec,Number(_0x43ed61)):_0x5c5195=!0x1;}),!_0x47250c&&_0x5c5195&&_0x27f9ec<0x2*_0x36bfda){const _0x2a0aff=[];for(const _0x4a8e67 in _0x5a7a66)_0x2a0aff[_0x4a8e67]=_0x5a7a66[_0x4a8e67];return _0x2a0aff;}else return _0x47250c&&!this['getPriority']()['isEmpty']()&&(_0x5a7a66['.priority']=this['getPriority']()['val']()),_0x5a7a66;}['hash'](){if(this['lazyHash_']===null){let _0x1ce3f2='';this['getPriority']()['isEmpty']()||(_0x1ce3f2+='priority:'+No(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x198162,_0x45e34b)=>{const _0x52f891=_0x45e34b['hash']();_0x52f891!==''&&(_0x1ce3f2+=':'+_0x198162+':'+_0x52f891);}),this['lazyHash_']=_0x1ce3f2===''?'':ro(_0x1ce3f2);}return this['lazyHash_'];}['getPredecessorChildName'](_0x1fb49d,_0x215356,_0x417af4){const _0x5328b1=this['resolveIndex_'](_0x417af4);if(_0x5328b1){const _0x566719=_0x5328b1['getPredecessorKey'](new E(_0x1fb49d,_0x215356));return _0x566719?_0x566719['name']:null;}else return this['children_']['getPredecessorKey'](_0x1fb49d);}['getFirstChildName'](_0x4d81e4){const _0x3bfcbc=this['resolveIndex_'](_0x4d81e4);if(_0x3bfcbc){const _0x5ed95f=_0x3bfcbc['minKey']();return _0x5ed95f&&_0x5ed95f['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x37d3b1){const _0x585400=this['getFirstChildName'](_0x37d3b1);return _0x585400?new E(_0x585400,this['children_']['get'](_0x585400)):null;}['getLastChildName'](_0x5902ba){const _0x19a3a3=this['resolveIndex_'](_0x5902ba);if(_0x19a3a3){const _0x561270=_0x19a3a3['maxKey']();return _0x561270&&_0x561270['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x1bf4f8){const _0x1586a1=this['getLastChildName'](_0x1bf4f8);return _0x1586a1?new E(_0x1586a1,this['children_']['get'](_0x1586a1)):null;}['forEachChild'](_0xd8cc6a,_0xbeb15b){const _0x3d7c45=this['resolveIndex_'](_0xd8cc6a);return _0x3d7c45?_0x3d7c45['inorderTraversal'](_0x482da8=>_0xbeb15b(_0x482da8['name'],_0x482da8['node'])):this['children_']['inorderTraversal'](_0xbeb15b);}['getIterator'](_0x3442c4){return this['getIteratorFrom'](_0x3442c4['minPost'](),_0x3442c4);}['getIteratorFrom'](_0x2b287b,_0x4b970d){const _0x3ec38b=this['resolveIndex_'](_0x4b970d);if(_0x3ec38b)return _0x3ec38b['getIteratorFrom'](_0x2b287b,_0x2fbfe3=>_0x2fbfe3);{const _0xa66816=this['children_']['getIteratorFrom'](_0x2b287b['name'],E['Wrap']);let _0x3230e0=_0xa66816['peek']();for(;_0x3230e0!=null&&_0x4b970d['compare'](_0x3230e0,_0x2b287b)<0x0;)_0xa66816['getNext'](),_0x3230e0=_0xa66816['peek']();return _0xa66816;}}['getReverseIterator'](_0x27e178){return this['getReverseIteratorFrom'](_0x27e178['maxPost'](),_0x27e178);}['getReverseIteratorFrom'](_0x176c9d,_0x98c06c){const _0x2d20dc=this['resolveIndex_'](_0x98c06c);if(_0x2d20dc)return _0x2d20dc['getReverseIteratorFrom'](_0x176c9d,_0x4a77af=>_0x4a77af);{const _0x1b476b=this['children_']['getReverseIteratorFrom'](_0x176c9d['name'],E['Wrap']);let _0x106b3d=_0x1b476b['peek']();for(;_0x106b3d!=null&&_0x98c06c['compare'](_0x106b3d,_0x176c9d)>0x0;)_0x1b476b['getNext'](),_0x106b3d=_0x1b476b['peek']();return _0x1b476b;}}['compareTo'](_0x28d6a3){return this['isEmpty']()?_0x28d6a3['isEmpty']()?0x0:-0x1:_0x28d6a3['isLeafNode']()||_0x28d6a3['isEmpty']()?0x1:_0x28d6a3===$t?-0x1:0x0;}['withIndex'](_0x502844){if(_0x502844===ye||this['indexMap_']['hasIndex'](_0x502844))return this;{const _0x5c984a=this['indexMap_']['addIndex'](_0x502844,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x5c984a);}}['isIndexed'](_0x3c7b10){return _0x3c7b10===ye||this['indexMap_']['hasIndex'](_0x3c7b10);}['equals'](_0x2714e1){if(_0x2714e1===this)return!0x0;if(_0x2714e1['isLeafNode']())return!0x1;{const _0x1087bc=_0x2714e1;if(this['getPriority']()['equals'](_0x1087bc['getPriority']())){if(this['children_']['count']()===_0x1087bc['children_']['count']()){const _0x274252=this['getIterator'](R),_0x4b54a4=_0x1087bc['getIterator'](R);let _0x4f8243=_0x274252['getNext'](),_0x3ab8cf=_0x4b54a4['getNext']();for(;_0x4f8243&&_0x3ab8cf;){if(_0x4f8243['name']!==_0x3ab8cf['name']||!_0x4f8243['node']['equals'](_0x3ab8cf['node']))return!0x1;_0x4f8243=_0x274252['getNext'](),_0x3ab8cf=_0x4b54a4['getNext']();}return _0x4f8243===null&&_0x3ab8cf===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x4ab740){return _0x4ab740===ye?null:this['indexMap_']['get'](_0x4ab740['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Yi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x126a33){return _0x126a33===this?0x0:0x1;}['equals'](_0x1043aa){return _0x1043aa===this;}['getPriority'](){return this;}['getImmediateChild'](_0x30309d){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const $t=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(Fe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,$t)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh($t),Wh($t);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function P(_0x23b8d3,_0x297b6a=null){if(_0x23b8d3===null)return g['EMPTY_NODE'];if(typeof _0x23b8d3=='object'&&'.priority'in _0x23b8d3&&(_0x297b6a=_0x23b8d3['.priority']),f(_0x297b6a===null||typeof _0x297b6a=='string'||typeof _0x297b6a=='number'||typeof _0x297b6a=='object'&&'.sv'in _0x297b6a,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x297b6a),typeof _0x23b8d3=='object'&&'.value'in _0x23b8d3&&_0x23b8d3['.value']!==null&&(_0x23b8d3=_0x23b8d3['.value']),typeof _0x23b8d3!='object'||'.sv'in _0x23b8d3){const _0x1ac363=_0x23b8d3;return new D(_0x1ac363,P(_0x297b6a));}if(!(_0x23b8d3 instanceof Array)&&Gh){const _0x2d81e8=[];let _0x24331c=!0x1;if(x(_0x23b8d3,(_0x458222,_0x2437dc)=>{if(_0x458222['substring'](0x0,0x1)!=='.'){const _0x33c273=P(_0x2437dc);_0x33c273['isEmpty']()||(_0x24331c=_0x24331c||!_0x33c273['getPriority']()['isEmpty'](),_0x2d81e8['push'](new E(_0x458222,_0x33c273)));}}),_0x2d81e8['length']===0x0)return g['EMPTY_NODE'];const _0x64eb51=fn(_0x2d81e8,xh,_0x10d532=>_0x10d532['name'],Yi);if(_0x24331c){const _0x742144=fn(_0x2d81e8,R['getCompare']());return new g(_0x64eb51,P(_0x297b6a),new te({'.priority':_0x742144},{'.priority':R}));}else return new g(_0x64eb51,P(_0x297b6a),te['Default']);}else{let _0x5a5596=g['EMPTY_NODE'];return x(_0x23b8d3,(_0x4099f1,_0x493be5)=>{if(J(_0x23b8d3,_0x4099f1)&&_0x4099f1['substring'](0x0,0x1)!=='.'){const _0xa2e070=P(_0x493be5);(_0xa2e070['isLeafNode']()||!_0xa2e070['isEmpty']())&&(_0x5a5596=_0x5a5596['updateImmediateChild'](_0x4099f1,_0xa2e070));}}),_0x5a5596['updatePriority'](P(_0x297b6a));}}Uh(P);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi extends Dn{constructor(_0x5667d1){super(),this['indexPath_']=_0x5667d1,f(!v(_0x5667d1)&&y(_0x5667d1)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x13b330){return _0x13b330['getChild'](this['indexPath_']);}['isDefinedOn'](_0x4c5228){return!_0x4c5228['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x5c78a6,_0x29d77c){const _0x2ea26e=this['extractChild'](_0x5c78a6['node']),_0x44546d=this['extractChild'](_0x29d77c['node']),_0x4157a3=_0x2ea26e['compareTo'](_0x44546d);return _0x4157a3===0x0?He(_0x5c78a6['name'],_0x29d77c['name']):_0x4157a3;}['makePost'](_0x93b1bf,_0x551820){const _0x31f6d6=P(_0x93b1bf),_0x25716d=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x31f6d6);return new E(_0x551820,_0x25716d);}['maxPost'](){const _0xbd4894=g['EMPTY_NODE']['updateChild'](this['indexPath_'],$t);return new E(Ie,_0xbd4894);}['toString'](){return Pt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Dn{['compare'](_0x544920,_0x15c00c){const _0x494753=_0x544920['node']['compareTo'](_0x15c00c['node']);return _0x494753===0x0?He(_0x544920['name'],_0x15c00c['name']):_0x494753;}['isDefinedOn'](_0x5bf897){return!0x0;}['indexedValueChanged'](_0x3f3dfa,_0x4a3f00){return!_0x3f3dfa['equals'](_0x4a3f00);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x9ae24b,_0xf93097){const _0x482366=P(_0x9ae24b);return new E(_0xf93097,_0x482366);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x52ff3f){return{'type':'value','snapshotNode':_0x52ff3f};}function et(_0x16ff51,_0x5e7d58){return{'type':'child_added','snapshotNode':_0x5e7d58,'childName':_0x16ff51};}function Ot(_0x4322c1,_0x53dec9){return{'type':'child_removed','snapshotNode':_0x53dec9,'childName':_0x4322c1};}function Dt(_0x116be3,_0xae3175,_0x5b5484){return{'type':'child_changed','snapshotNode':_0xae3175,'childName':_0x116be3,'oldSnap':_0x5b5484};}function zh(_0x3a413e,_0x353576){return{'type':'child_moved','snapshotNode':_0x353576,'childName':_0x3a413e};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji{constructor(_0x36598a){this['index_']=_0x36598a;}['updateChild'](_0x2ee7c2,_0x5e499e,_0x1bda9c,_0x1733b6,_0x17b944,_0x872741){f(_0x2ee7c2['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x569c4a=_0x2ee7c2['getImmediateChild'](_0x5e499e);return _0x569c4a['getChild'](_0x1733b6)['equals'](_0x1bda9c['getChild'](_0x1733b6))&&_0x569c4a['isEmpty']()===_0x1bda9c['isEmpty']()||(_0x872741!=null&&(_0x1bda9c['isEmpty']()?_0x2ee7c2['hasChild'](_0x5e499e)?_0x872741['trackChildChange'](Ot(_0x5e499e,_0x569c4a)):f(_0x2ee7c2['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x569c4a['isEmpty']()?_0x872741['trackChildChange'](et(_0x5e499e,_0x1bda9c)):_0x872741['trackChildChange'](Dt(_0x5e499e,_0x1bda9c,_0x569c4a))),_0x2ee7c2['isLeafNode']()&&_0x1bda9c['isEmpty']())?_0x2ee7c2:_0x2ee7c2['updateImmediateChild'](_0x5e499e,_0x1bda9c)['withIndex'](this['index_']);}['updateFullNode'](_0x41920e,_0x1c8ab7,_0x5e3bdd){return _0x5e3bdd!=null&&(_0x41920e['isLeafNode']()||_0x41920e['forEachChild'](R,(_0x526bac,_0x3df44a)=>{_0x1c8ab7['hasChild'](_0x526bac)||_0x5e3bdd['trackChildChange'](Ot(_0x526bac,_0x3df44a));}),_0x1c8ab7['isLeafNode']()||_0x1c8ab7['forEachChild'](R,(_0x1374fa,_0x3cf674)=>{if(_0x41920e['hasChild'](_0x1374fa)){const _0x2570e6=_0x41920e['getImmediateChild'](_0x1374fa);_0x2570e6['equals'](_0x3cf674)||_0x5e3bdd['trackChildChange'](Dt(_0x1374fa,_0x3cf674,_0x2570e6));}else _0x5e3bdd['trackChildChange'](et(_0x1374fa,_0x3cf674));})),_0x1c8ab7['withIndex'](this['index_']);}['updatePriority'](_0x3deb2d,_0x2a28e3){return _0x3deb2d['isEmpty']()?g['EMPTY_NODE']:_0x3deb2d['updatePriority'](_0x2a28e3);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Mt{constructor(_0xa95885){this['indexedFilter_']=new Ji(_0xa95885['getIndex']()),this['index_']=_0xa95885['getIndex'](),this['startPost_']=Mt['getStartPost_'](_0xa95885),this['endPost_']=Mt['getEndPost_'](_0xa95885),this['startIsInclusive_']=!_0xa95885['startAfterSet_'],this['endIsInclusive_']=!_0xa95885['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x2d39b8){const _0x28f62f=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x2d39b8)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x2d39b8)<0x0,_0x50b5cd=this['endIsInclusive_']?this['index_']['compare'](_0x2d39b8,this['getEndPost']())<=0x0:this['index_']['compare'](_0x2d39b8,this['getEndPost']())<0x0;return _0x28f62f&&_0x50b5cd;}['updateChild'](_0x35a116,_0x2c9bc4,_0x4fa381,_0x5c2f33,_0x36f79d,_0x5652fa){return this['matches'](new E(_0x2c9bc4,_0x4fa381))||(_0x4fa381=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x35a116,_0x2c9bc4,_0x4fa381,_0x5c2f33,_0x36f79d,_0x5652fa);}['updateFullNode'](_0x52f00a,_0x1edf41,_0x1b561f){_0x1edf41['isLeafNode']()&&(_0x1edf41=g['EMPTY_NODE']);let _0x3a06a3=_0x1edf41['withIndex'](this['index_']);_0x3a06a3=_0x3a06a3['updatePriority'](g['EMPTY_NODE']);const _0x87597c=this;return _0x1edf41['forEachChild'](R,(_0x43cd10,_0x455491)=>{_0x87597c['matches'](new E(_0x43cd10,_0x455491))||(_0x3a06a3=_0x3a06a3['updateImmediateChild'](_0x43cd10,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x52f00a,_0x3a06a3,_0x1b561f);}['updatePriority'](_0x33242e,_0x183c31){return _0x33242e;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x39e296){if(_0x39e296['hasStart']()){const _0x4f7fce=_0x39e296['getIndexStartName']();return _0x39e296['getIndex']()['makePost'](_0x39e296['getIndexStartValue'](),_0x4f7fce);}else return _0x39e296['getIndex']()['minPost']();}static['getEndPost_'](_0x392186){if(_0x392186['hasEnd']()){const _0x52a6ef=_0x392186['getIndexEndName']();return _0x392186['getIndex']()['makePost'](_0x392186['getIndexEndValue'](),_0x52a6ef);}else return _0x392186['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x4b587a){this['withinDirectionalStart']=_0x54e6e0=>this['reverse_']?this['withinEndPost'](_0x54e6e0):this['withinStartPost'](_0x54e6e0),this['withinDirectionalEnd']=_0x137de4=>this['reverse_']?this['withinStartPost'](_0x137de4):this['withinEndPost'](_0x137de4),this['withinStartPost']=_0x579992=>{const _0x4daad9=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x579992);return this['startIsInclusive_']?_0x4daad9<=0x0:_0x4daad9<0x0;},this['withinEndPost']=_0x477343=>{const _0x4dc5e6=this['index_']['compare'](_0x477343,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x4dc5e6<=0x0:_0x4dc5e6<0x0;},this['rangedFilter_']=new Mt(_0x4b587a),this['index_']=_0x4b587a['getIndex'](),this['limit_']=_0x4b587a['getLimit'](),this['reverse_']=!_0x4b587a['isViewFromLeft'](),this['startIsInclusive_']=!_0x4b587a['startAfterSet_'],this['endIsInclusive_']=!_0x4b587a['endBeforeSet_'];}['updateChild'](_0xb948a8,_0x5450a2,_0x389cbe,_0x140713,_0x15295a,_0x4d9dc5){return this['rangedFilter_']['matches'](new E(_0x5450a2,_0x389cbe))||(_0x389cbe=g['EMPTY_NODE']),_0xb948a8['getImmediateChild'](_0x5450a2)['equals'](_0x389cbe)?_0xb948a8:_0xb948a8['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0xb948a8,_0x5450a2,_0x389cbe,_0x140713,_0x15295a,_0x4d9dc5):this['fullLimitUpdateChild_'](_0xb948a8,_0x5450a2,_0x389cbe,_0x15295a,_0x4d9dc5);}['updateFullNode'](_0x56c412,_0x46503a,_0x525ae5){let _0x6cab68;if(_0x46503a['isLeafNode']()||_0x46503a['isEmpty']())_0x6cab68=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x46503a['numChildren']()&&_0x46503a['isIndexed'](this['index_'])){_0x6cab68=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x328f75;this['reverse_']?_0x328f75=_0x46503a['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x328f75=_0x46503a['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x22ab59=0x0;for(;_0x328f75['hasNext']()&&_0x22ab59<this['limit_'];){const _0x2617fc=_0x328f75['getNext']();if(this['withinDirectionalStart'](_0x2617fc)){if(this['withinDirectionalEnd'](_0x2617fc))_0x6cab68=_0x6cab68['updateImmediateChild'](_0x2617fc['name'],_0x2617fc['node']),_0x22ab59++;else break;}else continue;}}else{_0x6cab68=_0x46503a['withIndex'](this['index_']),_0x6cab68=_0x6cab68['updatePriority'](g['EMPTY_NODE']);let _0x280790;this['reverse_']?_0x280790=_0x6cab68['getReverseIterator'](this['index_']):_0x280790=_0x6cab68['getIterator'](this['index_']);let _0x3ee356=0x0;for(;_0x280790['hasNext']();){const _0x394b71=_0x280790['getNext']();_0x3ee356<this['limit_']&&this['withinDirectionalStart'](_0x394b71)&&this['withinDirectionalEnd'](_0x394b71)?_0x3ee356++:_0x6cab68=_0x6cab68['updateImmediateChild'](_0x394b71['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x56c412,_0x6cab68,_0x525ae5);}['updatePriority'](_0x337559,_0x261070){return _0x337559;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x36a982,_0x340429,_0x43ddf2,_0x579cc9,_0x37e55c){let _0x7c69f2;if(this['reverse_']){const _0x280542=this['index_']['getCompare']();_0x7c69f2=(_0x2d41e3,_0x242dbd)=>_0x280542(_0x242dbd,_0x2d41e3);}else _0x7c69f2=this['index_']['getCompare']();const _0x409f28=_0x36a982;f(_0x409f28['numChildren']()===this['limit_'],'');const _0x30e46b=new E(_0x340429,_0x43ddf2),_0x5ed886=this['reverse_']?_0x409f28['getFirstChild'](this['index_']):_0x409f28['getLastChild'](this['index_']),_0x100a03=this['rangedFilter_']['matches'](_0x30e46b);if(_0x409f28['hasChild'](_0x340429)){const _0x26c2bf=_0x409f28['getImmediateChild'](_0x340429);let _0xe32837=_0x579cc9['getChildAfterChild'](this['index_'],_0x5ed886,this['reverse_']);for(;_0xe32837!=null&&(_0xe32837['name']===_0x340429||_0x409f28['hasChild'](_0xe32837['name']));)_0xe32837=_0x579cc9['getChildAfterChild'](this['index_'],_0xe32837,this['reverse_']);const _0x565ff5=_0xe32837==null?0x1:_0x7c69f2(_0xe32837,_0x30e46b);if(_0x100a03&&!_0x43ddf2['isEmpty']()&&_0x565ff5>=0x0)return _0x37e55c!=null&&_0x37e55c['trackChildChange'](Dt(_0x340429,_0x43ddf2,_0x26c2bf)),_0x409f28['updateImmediateChild'](_0x340429,_0x43ddf2);{_0x37e55c!=null&&_0x37e55c['trackChildChange'](Ot(_0x340429,_0x26c2bf));const _0x25da21=_0x409f28['updateImmediateChild'](_0x340429,g['EMPTY_NODE']);return _0xe32837!=null&&this['rangedFilter_']['matches'](_0xe32837)?(_0x37e55c!=null&&_0x37e55c['trackChildChange'](et(_0xe32837['name'],_0xe32837['node'])),_0x25da21['updateImmediateChild'](_0xe32837['name'],_0xe32837['node'])):_0x25da21;}}else return _0x43ddf2['isEmpty']()?_0x36a982:_0x100a03&&_0x7c69f2(_0x5ed886,_0x30e46b)>=0x0?(_0x37e55c!=null&&(_0x37e55c['trackChildChange'](Ot(_0x5ed886['name'],_0x5ed886['node'])),_0x37e55c['trackChildChange'](et(_0x340429,_0x43ddf2))),_0x409f28['updateImmediateChild'](_0x340429,_0x43ddf2)['updateImmediateChild'](_0x5ed886['name'],g['EMPTY_NODE'])):_0x36a982;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:Fe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x3f9160=new Xi();return _0x3f9160['limitSet_']=this['limitSet_'],_0x3f9160['limit_']=this['limit_'],_0x3f9160['startSet_']=this['startSet_'],_0x3f9160['startAfterSet_']=this['startAfterSet_'],_0x3f9160['indexStartValue_']=this['indexStartValue_'],_0x3f9160['startNameSet_']=this['startNameSet_'],_0x3f9160['indexStartName_']=this['indexStartName_'],_0x3f9160['endSet_']=this['endSet_'],_0x3f9160['endBeforeSet_']=this['endBeforeSet_'],_0x3f9160['indexEndValue_']=this['indexEndValue_'],_0x3f9160['endNameSet_']=this['endNameSet_'],_0x3f9160['indexEndName_']=this['indexEndName_'],_0x3f9160['index_']=this['index_'],_0x3f9160['viewFrom_']=this['viewFrom_'],_0x3f9160;}}function Kh(_0x4e32e3){return _0x4e32e3['loadsAllData']()?new Ji(_0x4e32e3['getIndex']()):_0x4e32e3['hasLimit']()?new jh(_0x4e32e3):new Mt(_0x4e32e3);}function Yh(_0x58210c,_0x56ff34){const _0xd74d3=_0x58210c['copy']();return _0xd74d3['limitSet_']=!0x0,_0xd74d3['limit_']=_0x56ff34,_0xd74d3['viewFrom_']='l',_0xd74d3;}function Qh(_0x3da006,_0x1605f6,_0x2fee73){const _0xa638e7=_0x3da006['copy']();return _0xa638e7['startSet_']=!0x0,_0x1605f6===void 0x0&&(_0x1605f6=null),_0xa638e7['indexStartValue_']=_0x1605f6,_0x2fee73!=null?(_0xa638e7['startNameSet_']=!0x0,_0xa638e7['indexStartName_']=_0x2fee73):(_0xa638e7['startNameSet_']=!0x1,_0xa638e7['indexStartName_']=''),_0xa638e7;}function Jh(_0xc03e0e,_0x4b2559,_0x1f3b46){const _0x12d2bc=_0xc03e0e['copy']();return _0x12d2bc['endSet_']=!0x0,_0x4b2559===void 0x0&&(_0x4b2559=null),_0x12d2bc['indexEndValue_']=_0x4b2559,_0x1f3b46!==void 0x0?(_0x12d2bc['endNameSet_']=!0x0,_0x12d2bc['indexEndName_']=_0x1f3b46):(_0x12d2bc['endNameSet_']=!0x1,_0x12d2bc['indexEndName_']=''),_0x12d2bc;}function xo(_0x45de26,_0x21be64){const _0x53ca71=_0x45de26['copy']();return _0x53ca71['index_']=_0x21be64,_0x53ca71;}function sr(_0x3162e3){const _0x377ea7={};if(_0x3162e3['isDefault']())return _0x377ea7;let _0x598ab9;if(_0x3162e3['index_']===R?_0x598ab9='$priority':_0x3162e3['index_']===Mo?_0x598ab9='$value':_0x3162e3['index_']===ye?_0x598ab9='$key':(f(_0x3162e3['index_']instanceof Qi,'Unrecognized\x20index\x20type!'),_0x598ab9=_0x3162e3['index_']['toString']()),_0x377ea7['orderBy']=O(_0x598ab9),_0x3162e3['startSet_']){const _0x2841d8=_0x3162e3['startAfterSet_']?'startAfter':'startAt';_0x377ea7[_0x2841d8]=O(_0x3162e3['indexStartValue_']),_0x3162e3['startNameSet_']&&(_0x377ea7[_0x2841d8]+=','+O(_0x3162e3['indexStartName_']));}if(_0x3162e3['endSet_']){const _0x112c56=_0x3162e3['endBeforeSet_']?'endBefore':'endAt';_0x377ea7[_0x112c56]=O(_0x3162e3['indexEndValue_']),_0x3162e3['endNameSet_']&&(_0x377ea7[_0x112c56]+=','+O(_0x3162e3['indexEndName_']));}return _0x3162e3['limitSet_']&&(_0x3162e3['isViewFromLeft']()?_0x377ea7['limitToFirst']=_0x3162e3['limit_']:_0x377ea7['limitToLast']=_0x3162e3['limit_']),_0x377ea7;}function rr(_0x3f11e3){const _0x17797d={};if(_0x3f11e3['startSet_']&&(_0x17797d['sp']=_0x3f11e3['indexStartValue_'],_0x3f11e3['startNameSet_']&&(_0x17797d['sn']=_0x3f11e3['indexStartName_']),_0x17797d['sin']=!_0x3f11e3['startAfterSet_']),_0x3f11e3['endSet_']&&(_0x17797d['ep']=_0x3f11e3['indexEndValue_'],_0x3f11e3['endNameSet_']&&(_0x17797d['en']=_0x3f11e3['indexEndName_']),_0x17797d['ein']=!_0x3f11e3['endBeforeSet_']),_0x3f11e3['limitSet_']){_0x17797d['l']=_0x3f11e3['limit_'];let _0x5d756d=_0x3f11e3['viewFrom_'];_0x5d756d===''&&(_0x3f11e3['isViewFromLeft']()?_0x5d756d='l':_0x5d756d='r'),_0x17797d['vf']=_0x5d756d;}return _0x3f11e3['index_']!==R&&(_0x17797d['i']=_0x3f11e3['index_']['toString']()),_0x17797d;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pn extends So{['reportStats'](_0x364eab){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0xb7dea2,_0x3cdee3){return _0x3cdee3!==void 0x0?'tag$'+_0x3cdee3:(f(_0xb7dea2['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0xb7dea2['_path']['toString']());}constructor(_0x5e5ae2,_0xbe5a1e,_0x4e1361,_0x37fbde){super(),this['repoInfo_']=_0x5e5ae2,this['onDataUpdate_']=_0xbe5a1e,this['authTokenProvider_']=_0x4e1361,this['appCheckTokenProvider_']=_0x37fbde,this['log_']=Ht('p:rest:'),this['listens_']={};}['listen'](_0x27efa5,_0x5ee498,_0x2b9c49,_0x45472c){const _0x602924=_0x27efa5['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x602924+'\x20'+_0x27efa5['_queryIdentifier']);const _0xf89e74=pn['getListenId_'](_0x27efa5,_0x2b9c49),_0x45d114={};this['listens_'][_0xf89e74]=_0x45d114;const _0x326125=sr(_0x27efa5['_queryParams']);this['restRequest_'](_0x602924+'.json',_0x326125,(_0x211dc3,_0x3a303f)=>{let _0x6096fb=_0x3a303f;if(_0x211dc3===0x194&&(_0x6096fb=null,_0x211dc3=null),_0x211dc3===null&&this['onDataUpdate_'](_0x602924,_0x6096fb,!0x1,_0x2b9c49),De(this['listens_'],_0xf89e74)===_0x45d114){let _0xc68b4c;_0x211dc3?_0x211dc3===0x191?_0xc68b4c='permission_denied':_0xc68b4c='rest_error:'+_0x211dc3:_0xc68b4c='ok',_0x45472c(_0xc68b4c,null);}});}['unlisten'](_0x1e0b5b,_0x40453b){const _0x874ebe=pn['getListenId_'](_0x1e0b5b,_0x40453b);delete this['listens_'][_0x874ebe];}['get'](_0x45c2f7){const _0x207600=sr(_0x45c2f7['_queryParams']),_0x567c7a=_0x45c2f7['_path']['toString'](),_0x5da308=new ot();return this['restRequest_'](_0x567c7a+'.json',_0x207600,(_0x2ac656,_0x483a83)=>{let _0x1537d7=_0x483a83;_0x2ac656===0x194&&(_0x1537d7=null,_0x2ac656=null),_0x2ac656===null?(this['onDataUpdate_'](_0x567c7a,_0x1537d7,!0x1,null),_0x5da308['resolve'](_0x1537d7)):_0x5da308['reject'](new Error(_0x1537d7));}),_0x5da308['promise'];}['refreshAuthToken'](_0x14af46){}['restRequest_'](_0x37ccb3,_0x48d78b={},_0x3c46f7){return _0x48d78b['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x13425b,_0x16efb3])=>{_0x13425b&&_0x13425b['accessToken']&&(_0x48d78b['auth']=_0x13425b['accessToken']),_0x16efb3&&_0x16efb3['token']&&(_0x48d78b['ac']=_0x16efb3['token']);const _0x46600f=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x37ccb3+'?ns='+this['repoInfo_']['namespace']+ct(_0x48d78b);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x46600f);const _0x26229d=new XMLHttpRequest();_0x26229d['onreadystatechange']=()=>{if(_0x3c46f7&&_0x26229d['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x46600f+'\x20received.\x20status:',_0x26229d['status'],'response:',_0x26229d['responseText']);let _0x4aa0d1=null;if(_0x26229d['status']>=0xc8&&_0x26229d['status']<0x12c){try{_0x4aa0d1=At(_0x26229d['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x46600f+':\x20'+_0x26229d['responseText']);}_0x3c46f7(null,_0x4aa0d1);}else _0x26229d['status']!==0x191&&_0x26229d['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x46600f+'\x20Status:\x20'+_0x26229d['status']),_0x3c46f7(_0x26229d['status']);_0x3c46f7=null;}},_0x26229d['open']('GET',_0x46600f,!0x0),_0x26229d['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x1195bb){return this['rootNode_']['getChild'](_0x1195bb);}['updateSnapshot'](_0x26e382,_0xbf0b6f){this['rootNode_']=this['rootNode_']['updateChild'](_0x26e382,_0xbf0b6f);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function _n(){return{'value':null,'children':new Map()};}function Fo(_0x3b2156,_0x491184,_0x14abd0){if(v(_0x491184))_0x3b2156['value']=_0x14abd0,_0x3b2156['children']['clear']();else{if(_0x3b2156['value']!==null)_0x3b2156['value']=_0x3b2156['value']['updateChild'](_0x491184,_0x14abd0);else{const _0x24aa95=y(_0x491184);_0x3b2156['children']['has'](_0x24aa95)||_0x3b2156['children']['set'](_0x24aa95,_n());const _0x3e9eb4=_0x3b2156['children']['get'](_0x24aa95);_0x491184=b(_0x491184),Fo(_0x3e9eb4,_0x491184,_0x14abd0);}}}function Ii(_0x5f1c19,_0x5de59c,_0x4d3ddd){_0x5f1c19['value']!==null?_0x4d3ddd(_0x5de59c,_0x5f1c19['value']):Zh(_0x5f1c19,(_0x5cb1fd,_0x3b0d76)=>{const _0x58c502=new C(_0x5de59c['toString']()+'/'+_0x5cb1fd);Ii(_0x3b0d76,_0x58c502,_0x4d3ddd);});}function Zh(_0x2c090e,_0x4bcb96){_0x2c090e['children']['forEach']((_0x248257,_0x3b7946)=>{_0x4bcb96(_0x3b7946,_0x248257);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x236ce5){this['collection_']=_0x236ce5,this['last_']=null;}['get'](){const _0x33ab3c=this['collection_']['get'](),_0x38c35e={..._0x33ab3c};return this['last_']&&x(this['last_'],(_0x1df5e3,_0x30788b)=>{_0x38c35e[_0x1df5e3]=_0x38c35e[_0x1df5e3]-_0x30788b;}),this['last_']=_0x33ab3c,_0x38c35e;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const or=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x4828e5,_0x4d3e98){this['server_']=_0x4d3e98,this['statsToReport_']={},this['statsListener_']=new eu(_0x4828e5);const _0x264867=or+(tu-or)*Math['random']();Ct(this['reportStats_']['bind'](this),Math['floor'](_0x264867));}['reportStats_'](){const _0x29b012=this['statsListener_']['get'](),_0x5c932b={};let _0x459b53=!0x1;x(_0x29b012,(_0x57748f,_0x436d08)=>{_0x436d08>0x0&&J(this['statsToReport_'],_0x57748f)&&(_0x5c932b[_0x57748f]=_0x436d08,_0x459b53=!0x0);}),_0x459b53&&this['server_']['reportStats'](_0x5c932b),Ct(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var j;(function(_0x56d5a1){_0x56d5a1[_0x56d5a1['OVERWRITE']=0x0]='OVERWRITE',_0x56d5a1[_0x56d5a1['MERGE']=0x1]='MERGE',_0x56d5a1[_0x56d5a1['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x56d5a1[_0x56d5a1['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(j||(j={})));function Zi(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function es(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ts(_0x9543fc){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x9543fc,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gn{constructor(_0x2cb802,_0x574bf7,_0x405cba){this['path']=_0x2cb802,this['affectedTree']=_0x574bf7,this['revert']=_0x405cba,this['type']=j['ACK_USER_WRITE'],this['source']=Zi();}['operationForChild'](_0x398425){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x3c09ee=this['affectedTree']['subtree'](new C(_0x398425));return new gn(w(),_0x3c09ee,this['revert']);}}else return f(y(this['path'])===_0x398425,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new gn(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Lt{constructor(_0x1ed9df,_0x220a6e){this['source']=_0x1ed9df,this['path']=_0x220a6e,this['type']=j['LISTEN_COMPLETE'];}['operationForChild'](_0x56c5a8){return v(this['path'])?new Lt(this['source'],w()):new Lt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ue{constructor(_0x410cee,_0x43a36a,_0x13c47c){this['source']=_0x410cee,this['path']=_0x43a36a,this['snap']=_0x13c47c,this['type']=j['OVERWRITE'];}['operationForChild'](_0x437b69){return v(this['path'])?new Ue(this['source'],w(),this['snap']['getImmediateChild'](_0x437b69)):new Ue(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tt{constructor(_0x2273b6,_0x1e4992,_0x6e00f4){this['source']=_0x2273b6,this['path']=_0x1e4992,this['children']=_0x6e00f4,this['type']=j['MERGE'];}['operationForChild'](_0x926900){if(v(this['path'])){const _0x1d222c=this['children']['subtree'](new C(_0x926900));return _0x1d222c['isEmpty']()?null:_0x1d222c['value']?new Ue(this['source'],w(),_0x1d222c['value']):new tt(this['source'],w(),_0x1d222c);}else return f(y(this['path'])===_0x926900,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new tt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x95ce65,_0x5ad052,_0x1b6b2f){this['node_']=_0x95ce65,this['fullyInitialized_']=_0x5ad052,this['filtered_']=_0x1b6b2f;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x94330b){if(v(_0x94330b))return this['isFullyInitialized']()&&!this['filtered_'];const _0x4ab24c=y(_0x94330b);return this['isCompleteForChild'](_0x4ab24c);}['isCompleteForChild'](_0x3c42e2){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x3c42e2);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x1b25cb){this['query_']=_0x1b25cb,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0xb6b03c,_0x502988,_0x303971,_0x33133f){const _0x3a2b19=[],_0x28e74c=[];return _0x502988['forEach'](_0x3c8ae4=>{_0x3c8ae4['type']==='child_changed'&&_0xb6b03c['index_']['indexedValueChanged'](_0x3c8ae4['oldSnap'],_0x3c8ae4['snapshotNode'])&&_0x28e74c['push'](zh(_0x3c8ae4['childName'],_0x3c8ae4['snapshotNode']));}),yt(_0xb6b03c,_0x3a2b19,'child_removed',_0x502988,_0x33133f,_0x303971),yt(_0xb6b03c,_0x3a2b19,'child_added',_0x502988,_0x33133f,_0x303971),yt(_0xb6b03c,_0x3a2b19,'child_moved',_0x28e74c,_0x33133f,_0x303971),yt(_0xb6b03c,_0x3a2b19,'child_changed',_0x502988,_0x33133f,_0x303971),yt(_0xb6b03c,_0x3a2b19,'value',_0x502988,_0x33133f,_0x303971),_0x3a2b19;}function yt(_0x28e058,_0x317dcf,_0x219f18,_0x24791a,_0x3fad75,_0x344db3){const _0x273f96=_0x24791a['filter'](_0x3c102b=>_0x3c102b['type']===_0x219f18);_0x273f96['sort']((_0x263505,_0x4b4eaf)=>au(_0x28e058,_0x263505,_0x4b4eaf)),_0x273f96['forEach'](_0xa54b17=>{const _0x557f6b=ou(_0x28e058,_0xa54b17,_0x344db3);_0x3fad75['forEach'](_0x475afa=>{_0x475afa['respondsTo'](_0xa54b17['type'])&&_0x317dcf['push'](_0x475afa['createEvent'](_0x557f6b,_0x28e058['query_']));});});}function ou(_0xf405eb,_0x53d37f,_0x221bd9){return _0x53d37f['type']==='value'||_0x53d37f['type']==='child_removed'||(_0x53d37f['prevName']=_0x221bd9['getPredecessorChildName'](_0x53d37f['childName'],_0x53d37f['snapshotNode'],_0xf405eb['index_'])),_0x53d37f;}function au(_0x38273c,_0x5dfa6c,_0x30d63b){if(_0x5dfa6c['childName']==null||_0x30d63b['childName']==null)throw rt('Should\x20only\x20compare\x20child_\x20events.');const _0x4097c2=new E(_0x5dfa6c['childName'],_0x5dfa6c['snapshotNode']),_0x12a4e4=new E(_0x30d63b['childName'],_0x30d63b['snapshotNode']);return _0x38273c['index_']['compare'](_0x4097c2,_0x12a4e4);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x231762,_0x74e061){return{'eventCache':_0x231762,'serverCache':_0x74e061};}function Tt(_0x2f2f43,_0x155dc0,_0x1d7d65,_0x224566){return Mn(new Ce(_0x155dc0,_0x1d7d65,_0x224566),_0x2f2f43['serverCache']);}function Uo(_0x5f0ea3,_0x108aa1,_0x3029ce,_0xd4df41){return Mn(_0x5f0ea3['eventCache'],new Ce(_0x108aa1,_0x3029ce,_0xd4df41));}function mn(_0x198e00){return _0x198e00['eventCache']['isFullyInitialized']()?_0x198e00['eventCache']['getNode']():null;}function We(_0x4c8d45){return _0x4c8d45['serverCache']['isFullyInitialized']()?_0x4c8d45['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let oi;const cu=()=>(oi||(oi=new B(ql)),oi);class S{static['fromObject'](_0x41525e){let _0x24533e=new S(null);return x(_0x41525e,(_0x40903a,_0x368886)=>{_0x24533e=_0x24533e['set'](new C(_0x40903a),_0x368886);}),_0x24533e;}constructor(_0x793302,_0x40848d=cu()){this['value']=_0x793302,this['children']=_0x40848d;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0xbc7791,_0x3d20aa){if(this['value']!=null&&_0x3d20aa(this['value']))return{'path':w(),'value':this['value']};if(v(_0xbc7791))return null;{const _0x4b832b=y(_0xbc7791),_0x4826b5=this['children']['get'](_0x4b832b);if(_0x4826b5!==null){const _0x51c3a3=_0x4826b5['findRootMostMatchingPathAndValue'](b(_0xbc7791),_0x3d20aa);return _0x51c3a3!=null?{'path':k(new C(_0x4b832b),_0x51c3a3['path']),'value':_0x51c3a3['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x859c3a){return this['findRootMostMatchingPathAndValue'](_0x859c3a,()=>!0x0);}['subtree'](_0x454013){if(v(_0x454013))return this;{const _0x23ef83=y(_0x454013),_0x16f211=this['children']['get'](_0x23ef83);return _0x16f211!==null?_0x16f211['subtree'](b(_0x454013)):new S(null);}}['set'](_0xb4d917,_0x5c173e){if(v(_0xb4d917))return new S(_0x5c173e,this['children']);{const _0x5da497=y(_0xb4d917),_0x141b74=(this['children']['get'](_0x5da497)||new S(null))['set'](b(_0xb4d917),_0x5c173e),_0x42c571=this['children']['insert'](_0x5da497,_0x141b74);return new S(this['value'],_0x42c571);}}['remove'](_0x5daecc){if(v(_0x5daecc))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x2e104e=y(_0x5daecc),_0x35f148=this['children']['get'](_0x2e104e);if(_0x35f148){const _0x4451d0=_0x35f148['remove'](b(_0x5daecc));let _0x2c0f6d;return _0x4451d0['isEmpty']()?_0x2c0f6d=this['children']['remove'](_0x2e104e):_0x2c0f6d=this['children']['insert'](_0x2e104e,_0x4451d0),this['value']===null&&_0x2c0f6d['isEmpty']()?new S(null):new S(this['value'],_0x2c0f6d);}else return this;}}['get'](_0x2454ca){if(v(_0x2454ca))return this['value'];{const _0x347af8=y(_0x2454ca),_0x311d2e=this['children']['get'](_0x347af8);return _0x311d2e?_0x311d2e['get'](b(_0x2454ca)):null;}}['setTree'](_0x153832,_0x374d91){if(v(_0x153832))return _0x374d91;{const _0x4505c8=y(_0x153832),_0x547130=(this['children']['get'](_0x4505c8)||new S(null))['setTree'](b(_0x153832),_0x374d91);let _0x122bec;return _0x547130['isEmpty']()?_0x122bec=this['children']['remove'](_0x4505c8):_0x122bec=this['children']['insert'](_0x4505c8,_0x547130),new S(this['value'],_0x122bec);}}['fold'](_0x4ec4a2){return this['fold_'](w(),_0x4ec4a2);}['fold_'](_0x308473,_0x3059a1){const _0x2cf6f4={};return this['children']['inorderTraversal']((_0xc789d8,_0x2991be)=>{_0x2cf6f4[_0xc789d8]=_0x2991be['fold_'](k(_0x308473,_0xc789d8),_0x3059a1);}),_0x3059a1(_0x308473,this['value'],_0x2cf6f4);}['findOnPath'](_0x48d468,_0x5df7d4){return this['findOnPath_'](_0x48d468,w(),_0x5df7d4);}['findOnPath_'](_0x177e71,_0x44eecd,_0x2c2a26){const _0x5eab08=this['value']?_0x2c2a26(_0x44eecd,this['value']):!0x1;if(_0x5eab08)return _0x5eab08;if(v(_0x177e71))return null;{const _0x5c271e=y(_0x177e71),_0x3e7769=this['children']['get'](_0x5c271e);return _0x3e7769?_0x3e7769['findOnPath_'](b(_0x177e71),k(_0x44eecd,_0x5c271e),_0x2c2a26):null;}}['foreachOnPath'](_0x3d2e4b,_0x51381f){return this['foreachOnPath_'](_0x3d2e4b,w(),_0x51381f);}['foreachOnPath_'](_0x110ede,_0x56695e,_0x42aa1b){if(v(_0x110ede))return this;{this['value']&&_0x42aa1b(_0x56695e,this['value']);const _0x545463=y(_0x110ede),_0x3d7be1=this['children']['get'](_0x545463);return _0x3d7be1?_0x3d7be1['foreachOnPath_'](b(_0x110ede),k(_0x56695e,_0x545463),_0x42aa1b):new S(null);}}['foreach'](_0x3ec423){this['foreach_'](w(),_0x3ec423);}['foreach_'](_0x52ea5f,_0xf77e8c){this['children']['inorderTraversal']((_0x5c49ae,_0x2f2fa1)=>{_0x2f2fa1['foreach_'](k(_0x52ea5f,_0x5c49ae),_0xf77e8c);}),this['value']&&_0xf77e8c(_0x52ea5f,this['value']);}['foreachChild'](_0x20a218){this['children']['inorderTraversal']((_0x19b8c1,_0x581351)=>{_0x581351['value']&&_0x20a218(_0x19b8c1,_0x581351['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Y{constructor(_0x598796){this['writeTree_']=_0x598796;}static['empty'](){return new Y(new S(null));}}function St(_0xf7aed5,_0x30550e,_0x25c32c){if(v(_0x30550e))return new Y(new S(_0x25c32c));{const _0x868ba2=_0xf7aed5['writeTree_']['findRootMostValueAndPath'](_0x30550e);if(_0x868ba2!=null){const _0x458fa4=_0x868ba2['path'];let _0x2a2155=_0x868ba2['value'];const _0x1e677b=F(_0x458fa4,_0x30550e);return _0x2a2155=_0x2a2155['updateChild'](_0x1e677b,_0x25c32c),new Y(_0xf7aed5['writeTree_']['set'](_0x458fa4,_0x2a2155));}else{const _0xaff917=new S(_0x25c32c),_0x4cd652=_0xf7aed5['writeTree_']['setTree'](_0x30550e,_0xaff917);return new Y(_0x4cd652);}}}function wi(_0x15cdf0,_0x202a4d,_0x2d199f){let _0x3d6ce5=_0x15cdf0;return x(_0x2d199f,(_0x33957d,_0x2607e5)=>{_0x3d6ce5=St(_0x3d6ce5,k(_0x202a4d,_0x33957d),_0x2607e5);}),_0x3d6ce5;}function ar(_0x176cb4,_0x3ab077){if(v(_0x3ab077))return Y['empty']();{const _0x1feece=_0x176cb4['writeTree_']['setTree'](_0x3ab077,new S(null));return new Y(_0x1feece);}}function Ci(_0x52ebc9,_0x446a62){return $e(_0x52ebc9,_0x446a62)!=null;}function $e(_0x2f757e,_0x5e0246){const _0x1745be=_0x2f757e['writeTree_']['findRootMostValueAndPath'](_0x5e0246);return _0x1745be!=null?_0x2f757e['writeTree_']['get'](_0x1745be['path'])['getChild'](F(_0x1745be['path'],_0x5e0246)):null;}function cr(_0x5468a6){const _0x4dfe87=[],_0x1f9a94=_0x5468a6['writeTree_']['value'];return _0x1f9a94!=null?_0x1f9a94['isLeafNode']()||_0x1f9a94['forEachChild'](R,(_0x3f279b,_0x2784b6)=>{_0x4dfe87['push'](new E(_0x3f279b,_0x2784b6));}):_0x5468a6['writeTree_']['children']['inorderTraversal']((_0x2995fd,_0x3b9088)=>{_0x3b9088['value']!=null&&_0x4dfe87['push'](new E(_0x2995fd,_0x3b9088['value']));}),_0x4dfe87;}function ve(_0x266088,_0x517026){if(v(_0x517026))return _0x266088;{const _0x69666e=$e(_0x266088,_0x517026);return _0x69666e!=null?new Y(new S(_0x69666e)):new Y(_0x266088['writeTree_']['subtree'](_0x517026));}}function Ti(_0x42826c){return _0x42826c['writeTree_']['isEmpty']();}function nt(_0x1c2d81,_0x2c0d98){return Wo(w(),_0x1c2d81['writeTree_'],_0x2c0d98);}function Wo(_0x16c294,_0x114276,_0xbb5c1a){if(_0x114276['value']!=null)return _0xbb5c1a['updateChild'](_0x16c294,_0x114276['value']);{let _0x49afd1=null;return _0x114276['children']['inorderTraversal']((_0x1a8138,_0x482254)=>{_0x1a8138==='.priority'?(f(_0x482254['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x49afd1=_0x482254['value']):_0xbb5c1a=Wo(k(_0x16c294,_0x1a8138),_0x482254,_0xbb5c1a);}),!_0xbb5c1a['getChild'](_0x16c294)['isEmpty']()&&_0x49afd1!==null&&(_0xbb5c1a=_0xbb5c1a['updateChild'](k(_0x16c294,'.priority'),_0x49afd1)),_0xbb5c1a;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ln(_0x2f6f71,_0x19f402){return $o(_0x19f402,_0x2f6f71);}function lu(_0x2692c1,_0x100f4e,_0x429717,_0x346e0e,_0x277af4){f(_0x346e0e>_0x2692c1['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x277af4===void 0x0&&(_0x277af4=!0x0),_0x2692c1['allWrites']['push']({'path':_0x100f4e,'snap':_0x429717,'writeId':_0x346e0e,'visible':_0x277af4}),_0x277af4&&(_0x2692c1['visibleWrites']=St(_0x2692c1['visibleWrites'],_0x100f4e,_0x429717)),_0x2692c1['lastWriteId']=_0x346e0e;}function hu(_0x1f0a9e,_0x5711a9,_0x36d482,_0x7e9d52){f(_0x7e9d52>_0x1f0a9e['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x1f0a9e['allWrites']['push']({'path':_0x5711a9,'children':_0x36d482,'writeId':_0x7e9d52,'visible':!0x0}),_0x1f0a9e['visibleWrites']=wi(_0x1f0a9e['visibleWrites'],_0x5711a9,_0x36d482),_0x1f0a9e['lastWriteId']=_0x7e9d52;}function uu(_0x16e239,_0x149b84){for(let _0x18f1c9=0x0;_0x18f1c9<_0x16e239['allWrites']['length'];_0x18f1c9++){const _0x5d241f=_0x16e239['allWrites'][_0x18f1c9];if(_0x5d241f['writeId']===_0x149b84)return _0x5d241f;}return null;}function du(_0x3fb5a0,_0x55af1f){const _0x263e91=_0x3fb5a0['allWrites']['findIndex'](_0x16ed90=>_0x16ed90['writeId']===_0x55af1f);f(_0x263e91>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x420014=_0x3fb5a0['allWrites'][_0x263e91];_0x3fb5a0['allWrites']['splice'](_0x263e91,0x1);let _0x4af5ed=_0x420014['visible'],_0x58e511=!0x1,_0x354020=_0x3fb5a0['allWrites']['length']-0x1;for(;_0x4af5ed&&_0x354020>=0x0;){const _0x46b7c0=_0x3fb5a0['allWrites'][_0x354020];_0x46b7c0['visible']&&(_0x354020>=_0x263e91&&fu(_0x46b7c0,_0x420014['path'])?_0x4af5ed=!0x1:G(_0x420014['path'],_0x46b7c0['path'])&&(_0x58e511=!0x0)),_0x354020--;}if(_0x4af5ed){if(_0x58e511)return pu(_0x3fb5a0),!0x0;if(_0x420014['snap'])_0x3fb5a0['visibleWrites']=ar(_0x3fb5a0['visibleWrites'],_0x420014['path']);else{const _0x2dfa85=_0x420014['children'];x(_0x2dfa85,_0x2e4491=>{_0x3fb5a0['visibleWrites']=ar(_0x3fb5a0['visibleWrites'],k(_0x420014['path'],_0x2e4491));});}return!0x0;}else return!0x1;}function fu(_0x5b9023,_0x44ddb5){if(_0x5b9023['snap'])return G(_0x5b9023['path'],_0x44ddb5);for(const _0x27b115 in _0x5b9023['children'])if(_0x5b9023['children']['hasOwnProperty'](_0x27b115)&&G(k(_0x5b9023['path'],_0x27b115),_0x44ddb5))return!0x0;return!0x1;}function pu(_0x1311cd){_0x1311cd['visibleWrites']=Bo(_0x1311cd['allWrites'],_u,w()),_0x1311cd['allWrites']['length']>0x0?_0x1311cd['lastWriteId']=_0x1311cd['allWrites'][_0x1311cd['allWrites']['length']-0x1]['writeId']:_0x1311cd['lastWriteId']=-0x1;}function _u(_0x4a5c8e){return _0x4a5c8e['visible'];}function Bo(_0xd0f3ed,_0x39253b,_0x313b5f){let _0x1a9a63=Y['empty']();for(let _0x10eec6=0x0;_0x10eec6<_0xd0f3ed['length'];++_0x10eec6){const _0x1a08c9=_0xd0f3ed[_0x10eec6];if(_0x39253b(_0x1a08c9)){const _0xabf407=_0x1a08c9['path'];let _0x30f806;if(_0x1a08c9['snap'])G(_0x313b5f,_0xabf407)?(_0x30f806=F(_0x313b5f,_0xabf407),_0x1a9a63=St(_0x1a9a63,_0x30f806,_0x1a08c9['snap'])):G(_0xabf407,_0x313b5f)&&(_0x30f806=F(_0xabf407,_0x313b5f),_0x1a9a63=St(_0x1a9a63,w(),_0x1a08c9['snap']['getChild'](_0x30f806)));else{if(_0x1a08c9['children']){if(G(_0x313b5f,_0xabf407))_0x30f806=F(_0x313b5f,_0xabf407),_0x1a9a63=wi(_0x1a9a63,_0x30f806,_0x1a08c9['children']);else{if(G(_0xabf407,_0x313b5f)){if(_0x30f806=F(_0xabf407,_0x313b5f),v(_0x30f806))_0x1a9a63=wi(_0x1a9a63,w(),_0x1a08c9['children']);else{const _0x26db15=De(_0x1a08c9['children'],y(_0x30f806));if(_0x26db15){const _0x4e2854=_0x26db15['getChild'](b(_0x30f806));_0x1a9a63=St(_0x1a9a63,w(),_0x4e2854);}}}}}else throw rt('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x1a9a63;}function Vo(_0x14f4f8,_0x3ba867,_0x143f73,_0x3b2e6e,_0x20f128){if(!_0x3b2e6e&&!_0x20f128){const _0x31c404=$e(_0x14f4f8['visibleWrites'],_0x3ba867);if(_0x31c404!=null)return _0x31c404;{const _0x17e392=ve(_0x14f4f8['visibleWrites'],_0x3ba867);if(Ti(_0x17e392))return _0x143f73;if(_0x143f73==null&&!Ci(_0x17e392,w()))return null;{const _0x466ad8=_0x143f73||g['EMPTY_NODE'];return nt(_0x17e392,_0x466ad8);}}}else{const _0x4e0aca=ve(_0x14f4f8['visibleWrites'],_0x3ba867);if(!_0x20f128&&Ti(_0x4e0aca))return _0x143f73;if(!_0x20f128&&_0x143f73==null&&!Ci(_0x4e0aca,w()))return null;{const _0x12e6e4=function(_0x50256b){return(_0x50256b['visible']||_0x20f128)&&(!_0x3b2e6e||!~_0x3b2e6e['indexOf'](_0x50256b['writeId']))&&(G(_0x50256b['path'],_0x3ba867)||G(_0x3ba867,_0x50256b['path']));},_0x27b66e=Bo(_0x14f4f8['allWrites'],_0x12e6e4,_0x3ba867),_0x30d458=_0x143f73||g['EMPTY_NODE'];return nt(_0x27b66e,_0x30d458);}}}function gu(_0x1a3456,_0x46d95f,_0x56fcc5){let _0x5e8bda=g['EMPTY_NODE'];const _0x388479=$e(_0x1a3456['visibleWrites'],_0x46d95f);if(_0x388479)return _0x388479['isLeafNode']()||_0x388479['forEachChild'](R,(_0x1a39bf,_0xad460c)=>{_0x5e8bda=_0x5e8bda['updateImmediateChild'](_0x1a39bf,_0xad460c);}),_0x5e8bda;if(_0x56fcc5){const _0x489cb0=ve(_0x1a3456['visibleWrites'],_0x46d95f);return _0x56fcc5['forEachChild'](R,(_0x46d2d1,_0x8232)=>{const _0x560aae=nt(ve(_0x489cb0,new C(_0x46d2d1)),_0x8232);_0x5e8bda=_0x5e8bda['updateImmediateChild'](_0x46d2d1,_0x560aae);}),cr(_0x489cb0)['forEach'](_0x5dd000=>{_0x5e8bda=_0x5e8bda['updateImmediateChild'](_0x5dd000['name'],_0x5dd000['node']);}),_0x5e8bda;}else{const _0x50f17b=ve(_0x1a3456['visibleWrites'],_0x46d95f);return cr(_0x50f17b)['forEach'](_0x5e30d4=>{_0x5e8bda=_0x5e8bda['updateImmediateChild'](_0x5e30d4['name'],_0x5e30d4['node']);}),_0x5e8bda;}}function mu(_0x4e7388,_0xf3dbfa,_0x116da6,_0x18df4a,_0x59c9be){f(_0x18df4a||_0x59c9be,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x5170fc=k(_0xf3dbfa,_0x116da6);if(Ci(_0x4e7388['visibleWrites'],_0x5170fc))return null;{const _0x26ae63=ve(_0x4e7388['visibleWrites'],_0x5170fc);return Ti(_0x26ae63)?_0x59c9be['getChild'](_0x116da6):nt(_0x26ae63,_0x59c9be['getChild'](_0x116da6));}}function yu(_0x34bde0,_0x10bdf0,_0x5b3a74,_0x28136e){const _0x4a5ed7=k(_0x10bdf0,_0x5b3a74),_0x43e543=$e(_0x34bde0['visibleWrites'],_0x4a5ed7);if(_0x43e543!=null)return _0x43e543;if(_0x28136e['isCompleteForChild'](_0x5b3a74)){const _0x53a1e3=ve(_0x34bde0['visibleWrites'],_0x4a5ed7);return nt(_0x53a1e3,_0x28136e['getNode']()['getImmediateChild'](_0x5b3a74));}else return null;}function vu(_0x21049,_0x438e37){return $e(_0x21049['visibleWrites'],_0x438e37);}function Eu(_0x92575c,_0xe1329e,_0x5679af,_0x4779da,_0x233706,_0x325d3d,_0x58a2bf){let _0x2aa391;const _0x3ed77c=ve(_0x92575c['visibleWrites'],_0xe1329e),_0x32958b=$e(_0x3ed77c,w());if(_0x32958b!=null)_0x2aa391=_0x32958b;else{if(_0x5679af!=null)_0x2aa391=nt(_0x3ed77c,_0x5679af);else return[];}if(_0x2aa391=_0x2aa391['withIndex'](_0x58a2bf),!_0x2aa391['isEmpty']()&&!_0x2aa391['isLeafNode']()){const _0x2e562b=[],_0x346eff=_0x58a2bf['getCompare'](),_0x4af5ff=_0x325d3d?_0x2aa391['getReverseIteratorFrom'](_0x4779da,_0x58a2bf):_0x2aa391['getIteratorFrom'](_0x4779da,_0x58a2bf);let _0x32f899=_0x4af5ff['getNext']();for(;_0x32f899&&_0x2e562b['length']<_0x233706;)_0x346eff(_0x32f899,_0x4779da)!==0x0&&_0x2e562b['push'](_0x32f899),_0x32f899=_0x4af5ff['getNext']();return _0x2e562b;}else return[];}function Iu(){return{'visibleWrites':Y['empty'](),'allWrites':[],'lastWriteId':-0x1};}function yn(_0x468421,_0x2f88f4,_0x1966f9,_0x3cdd42){return Vo(_0x468421['writeTree'],_0x468421['treePath'],_0x2f88f4,_0x1966f9,_0x3cdd42);}function ns(_0x36b78e,_0x5c6917){return gu(_0x36b78e['writeTree'],_0x36b78e['treePath'],_0x5c6917);}function lr(_0x10b9c8,_0x37a9ae,_0x36573c,_0x470991){return mu(_0x10b9c8['writeTree'],_0x10b9c8['treePath'],_0x37a9ae,_0x36573c,_0x470991);}function vn(_0x22fafd,_0x2fc9d4){return vu(_0x22fafd['writeTree'],k(_0x22fafd['treePath'],_0x2fc9d4));}function wu(_0x536624,_0x2628e7,_0x30588a,_0x3e7311,_0x446e17,_0x1a5b1a){return Eu(_0x536624['writeTree'],_0x536624['treePath'],_0x2628e7,_0x30588a,_0x3e7311,_0x446e17,_0x1a5b1a);}function is(_0xce1c92,_0xb424d3,_0x5ae9b3){return yu(_0xce1c92['writeTree'],_0xce1c92['treePath'],_0xb424d3,_0x5ae9b3);}function Ho(_0x1e0628,_0x3f20c0){return $o(k(_0x1e0628['treePath'],_0x3f20c0),_0x1e0628['writeTree']);}function $o(_0x547de7,_0x566075){return{'treePath':_0x547de7,'writeTree':_0x566075};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x46df42){const _0x367446=_0x46df42['type'],_0x1d3c8d=_0x46df42['childName'];f(_0x367446==='child_added'||_0x367446==='child_changed'||_0x367446==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x1d3c8d!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x56bcc8=this['changeMap']['get'](_0x1d3c8d);if(_0x56bcc8){const _0x587e66=_0x56bcc8['type'];if(_0x367446==='child_added'&&_0x587e66==='child_removed')this['changeMap']['set'](_0x1d3c8d,Dt(_0x1d3c8d,_0x46df42['snapshotNode'],_0x56bcc8['snapshotNode']));else{if(_0x367446==='child_removed'&&_0x587e66==='child_added')this['changeMap']['delete'](_0x1d3c8d);else{if(_0x367446==='child_removed'&&_0x587e66==='child_changed')this['changeMap']['set'](_0x1d3c8d,Ot(_0x1d3c8d,_0x56bcc8['oldSnap']));else{if(_0x367446==='child_changed'&&_0x587e66==='child_added')this['changeMap']['set'](_0x1d3c8d,et(_0x1d3c8d,_0x46df42['snapshotNode']));else{if(_0x367446==='child_changed'&&_0x587e66==='child_changed')this['changeMap']['set'](_0x1d3c8d,Dt(_0x1d3c8d,_0x46df42['snapshotNode'],_0x56bcc8['oldSnap']));else throw rt('Illegal\x20combination\x20of\x20changes:\x20'+_0x46df42+'\x20occurred\x20after\x20'+_0x56bcc8);}}}}}else this['changeMap']['set'](_0x1d3c8d,_0x46df42);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x2dd463){return null;}['getChildAfterChild'](_0x3d33fe,_0x158a09,_0x30ac29){return null;}}const Go=new Tu();class ss{constructor(_0x127c68,_0x5da927,_0x1db42f=null){this['writes_']=_0x127c68,this['viewCache_']=_0x5da927,this['optCompleteServerCache_']=_0x1db42f;}['getCompleteChild'](_0x25fcde){const _0x454496=this['viewCache_']['eventCache'];if(_0x454496['isCompleteForChild'](_0x25fcde))return _0x454496['getNode']()['getImmediateChild'](_0x25fcde);{const _0x41eda6=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return is(this['writes_'],_0x25fcde,_0x41eda6);}}['getChildAfterChild'](_0x3c89e8,_0x2e846c,_0x3e4758){const _0x2a3bf2=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:We(this['viewCache_']),_0xa1c560=wu(this['writes_'],_0x2a3bf2,_0x2e846c,0x1,_0x3e4758,_0x3c89e8);return _0xa1c560['length']===0x0?null:_0xa1c560[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x3b2773){return{'filter':_0x3b2773};}function bu(_0x17110a,_0x548968){f(_0x548968['eventCache']['getNode']()['isIndexed'](_0x17110a['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x548968['serverCache']['getNode']()['isIndexed'](_0x17110a['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x53e214,_0x149c98,_0x4e4cff,_0x37bd31,_0x10145b){const _0x5b7bb0=new Cu();let _0x1b6969,_0x30e4b5;if(_0x4e4cff['type']===j['OVERWRITE']){const _0x56ecd2=_0x4e4cff;_0x56ecd2['source']['fromUser']?_0x1b6969=Si(_0x53e214,_0x149c98,_0x56ecd2['path'],_0x56ecd2['snap'],_0x37bd31,_0x10145b,_0x5b7bb0):(f(_0x56ecd2['source']['fromServer'],'Unknown\x20source.'),_0x30e4b5=_0x56ecd2['source']['tagged']||_0x149c98['serverCache']['isFiltered']()&&!v(_0x56ecd2['path']),_0x1b6969=En(_0x53e214,_0x149c98,_0x56ecd2['path'],_0x56ecd2['snap'],_0x37bd31,_0x10145b,_0x30e4b5,_0x5b7bb0));}else{if(_0x4e4cff['type']===j['MERGE']){const _0x44f4ce=_0x4e4cff;_0x44f4ce['source']['fromUser']?_0x1b6969=ku(_0x53e214,_0x149c98,_0x44f4ce['path'],_0x44f4ce['children'],_0x37bd31,_0x10145b,_0x5b7bb0):(f(_0x44f4ce['source']['fromServer'],'Unknown\x20source.'),_0x30e4b5=_0x44f4ce['source']['tagged']||_0x149c98['serverCache']['isFiltered'](),_0x1b6969=bi(_0x53e214,_0x149c98,_0x44f4ce['path'],_0x44f4ce['children'],_0x37bd31,_0x10145b,_0x30e4b5,_0x5b7bb0));}else{if(_0x4e4cff['type']===j['ACK_USER_WRITE']){const _0x6450a9=_0x4e4cff;_0x6450a9['revert']?_0x1b6969=Ou(_0x53e214,_0x149c98,_0x6450a9['path'],_0x37bd31,_0x10145b,_0x5b7bb0):_0x1b6969=Nu(_0x53e214,_0x149c98,_0x6450a9['path'],_0x6450a9['affectedTree'],_0x37bd31,_0x10145b,_0x5b7bb0);}else{if(_0x4e4cff['type']===j['LISTEN_COMPLETE'])_0x1b6969=Pu(_0x53e214,_0x149c98,_0x4e4cff['path'],_0x37bd31,_0x5b7bb0);else throw rt('Unknown\x20operation\x20type:\x20'+_0x4e4cff['type']);}}}const _0x1d11b1=_0x5b7bb0['getChanges']();return Au(_0x149c98,_0x1b6969,_0x1d11b1),{'viewCache':_0x1b6969,'changes':_0x1d11b1};}function Au(_0x3592e4,_0x5128ac,_0x31f16d){const _0x3f29ae=_0x5128ac['eventCache'];if(_0x3f29ae['isFullyInitialized']()){const _0x57fd1a=_0x3f29ae['getNode']()['isLeafNode']()||_0x3f29ae['getNode']()['isEmpty'](),_0xaf2354=mn(_0x3592e4);(_0x31f16d['length']>0x0||!_0x3592e4['eventCache']['isFullyInitialized']()||_0x57fd1a&&!_0x3f29ae['getNode']()['equals'](_0xaf2354)||!_0x3f29ae['getNode']()['getPriority']()['equals'](_0xaf2354['getPriority']()))&&_0x31f16d['push'](Lo(mn(_0x5128ac)));}}function qo(_0x50110a,_0x512c75,_0x1fd57f,_0x5dac30,_0x1d8aba,_0x1a63dc){const _0x1d03a9=_0x512c75['eventCache'];if(vn(_0x5dac30,_0x1fd57f)!=null)return _0x512c75;{let _0x3ab6f8,_0x490a74;if(v(_0x1fd57f)){if(f(_0x512c75['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x512c75['serverCache']['isFiltered']()){const _0x5a2916=We(_0x512c75),_0x392682=_0x5a2916 instanceof g?_0x5a2916:g['EMPTY_NODE'],_0x446ea5=ns(_0x5dac30,_0x392682);_0x3ab6f8=_0x50110a['filter']['updateFullNode'](_0x512c75['eventCache']['getNode'](),_0x446ea5,_0x1a63dc);}else{const _0x111ab6=yn(_0x5dac30,We(_0x512c75));_0x3ab6f8=_0x50110a['filter']['updateFullNode'](_0x512c75['eventCache']['getNode'](),_0x111ab6,_0x1a63dc);}}else{const _0x205be5=y(_0x1fd57f);if(_0x205be5==='.priority'){f(we(_0x1fd57f)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x289ae4=_0x1d03a9['getNode']();_0x490a74=_0x512c75['serverCache']['getNode']();const _0x5a8954=lr(_0x5dac30,_0x1fd57f,_0x289ae4,_0x490a74);_0x5a8954!=null?_0x3ab6f8=_0x50110a['filter']['updatePriority'](_0x289ae4,_0x5a8954):_0x3ab6f8=_0x1d03a9['getNode']();}else{const _0x30c78f=b(_0x1fd57f);let _0x3fdbf6;if(_0x1d03a9['isCompleteForChild'](_0x205be5)){_0x490a74=_0x512c75['serverCache']['getNode']();const _0x54b9eb=lr(_0x5dac30,_0x1fd57f,_0x1d03a9['getNode'](),_0x490a74);_0x54b9eb!=null?_0x3fdbf6=_0x1d03a9['getNode']()['getImmediateChild'](_0x205be5)['updateChild'](_0x30c78f,_0x54b9eb):_0x3fdbf6=_0x1d03a9['getNode']()['getImmediateChild'](_0x205be5);}else _0x3fdbf6=is(_0x5dac30,_0x205be5,_0x512c75['serverCache']);_0x3fdbf6!=null?_0x3ab6f8=_0x50110a['filter']['updateChild'](_0x1d03a9['getNode'](),_0x205be5,_0x3fdbf6,_0x30c78f,_0x1d8aba,_0x1a63dc):_0x3ab6f8=_0x1d03a9['getNode']();}}return Tt(_0x512c75,_0x3ab6f8,_0x1d03a9['isFullyInitialized']()||v(_0x1fd57f),_0x50110a['filter']['filtersNodes']());}}function En(_0x588b56,_0x17cf7d,_0x43759b,_0x414909,_0x6ada3d,_0x59ae77,_0x3d6a1d,_0x1c09e7){const _0x2f6d7a=_0x17cf7d['serverCache'];let _0x458056;const _0x336719=_0x3d6a1d?_0x588b56['filter']:_0x588b56['filter']['getIndexedFilter']();if(v(_0x43759b))_0x458056=_0x336719['updateFullNode'](_0x2f6d7a['getNode'](),_0x414909,null);else{if(_0x336719['filtersNodes']()&&!_0x2f6d7a['isFiltered']()){const _0x5dfc11=_0x2f6d7a['getNode']()['updateChild'](_0x43759b,_0x414909);_0x458056=_0x336719['updateFullNode'](_0x2f6d7a['getNode'](),_0x5dfc11,null);}else{const _0x5ef62e=y(_0x43759b);if(!_0x2f6d7a['isCompleteForPath'](_0x43759b)&&we(_0x43759b)>0x1)return _0x17cf7d;const _0xa058f2=b(_0x43759b),_0x2a7de9=_0x2f6d7a['getNode']()['getImmediateChild'](_0x5ef62e)['updateChild'](_0xa058f2,_0x414909);_0x5ef62e==='.priority'?_0x458056=_0x336719['updatePriority'](_0x2f6d7a['getNode'](),_0x2a7de9):_0x458056=_0x336719['updateChild'](_0x2f6d7a['getNode'](),_0x5ef62e,_0x2a7de9,_0xa058f2,Go,null);}}const _0x398563=Uo(_0x17cf7d,_0x458056,_0x2f6d7a['isFullyInitialized']()||v(_0x43759b),_0x336719['filtersNodes']()),_0x5b6635=new ss(_0x6ada3d,_0x398563,_0x59ae77);return qo(_0x588b56,_0x398563,_0x43759b,_0x6ada3d,_0x5b6635,_0x1c09e7);}function Si(_0x3c0622,_0x4dc80f,_0x307ce2,_0x52e57e,_0x200f0d,_0x4203c5,_0x147ffa){const _0x26f5c7=_0x4dc80f['eventCache'];let _0x32c474,_0x2dc934;const _0x4e1bdc=new ss(_0x200f0d,_0x4dc80f,_0x4203c5);if(v(_0x307ce2))_0x2dc934=_0x3c0622['filter']['updateFullNode'](_0x4dc80f['eventCache']['getNode'](),_0x52e57e,_0x147ffa),_0x32c474=Tt(_0x4dc80f,_0x2dc934,!0x0,_0x3c0622['filter']['filtersNodes']());else{const _0x3d7044=y(_0x307ce2);if(_0x3d7044==='.priority')_0x2dc934=_0x3c0622['filter']['updatePriority'](_0x4dc80f['eventCache']['getNode'](),_0x52e57e),_0x32c474=Tt(_0x4dc80f,_0x2dc934,_0x26f5c7['isFullyInitialized'](),_0x26f5c7['isFiltered']());else{const _0x1fddce=b(_0x307ce2),_0xb840f0=_0x26f5c7['getNode']()['getImmediateChild'](_0x3d7044);let _0x39b6a6;if(v(_0x1fddce))_0x39b6a6=_0x52e57e;else{const _0x27db75=_0x4e1bdc['getCompleteChild'](_0x3d7044);_0x27db75!=null?zi(_0x1fddce)==='.priority'&&_0x27db75['getChild'](Ro(_0x1fddce))['isEmpty']()?_0x39b6a6=_0x27db75:_0x39b6a6=_0x27db75['updateChild'](_0x1fddce,_0x52e57e):_0x39b6a6=g['EMPTY_NODE'];}if(_0xb840f0['equals'](_0x39b6a6))_0x32c474=_0x4dc80f;else{const _0x25666c=_0x3c0622['filter']['updateChild'](_0x26f5c7['getNode'](),_0x3d7044,_0x39b6a6,_0x1fddce,_0x4e1bdc,_0x147ffa);_0x32c474=Tt(_0x4dc80f,_0x25666c,_0x26f5c7['isFullyInitialized'](),_0x3c0622['filter']['filtersNodes']());}}}return _0x32c474;}function hr(_0x325264,_0x286204){return _0x325264['eventCache']['isCompleteForChild'](_0x286204);}function ku(_0x4a87c7,_0x15cd1f,_0x18fa04,_0x5d452c,_0x59a456,_0x5815ff,_0x401aa3){let _0x537105=_0x15cd1f;return _0x5d452c['foreach']((_0x35194d,_0x197d0e)=>{const _0x389ca3=k(_0x18fa04,_0x35194d);hr(_0x15cd1f,y(_0x389ca3))&&(_0x537105=Si(_0x4a87c7,_0x537105,_0x389ca3,_0x197d0e,_0x59a456,_0x5815ff,_0x401aa3));}),_0x5d452c['foreach']((_0x5e6f46,_0x2d5200)=>{const _0xca597d=k(_0x18fa04,_0x5e6f46);hr(_0x15cd1f,y(_0xca597d))||(_0x537105=Si(_0x4a87c7,_0x537105,_0xca597d,_0x2d5200,_0x59a456,_0x5815ff,_0x401aa3));}),_0x537105;}function ur(_0x1fbe7c,_0x1edff4,_0x93e9bc){return _0x93e9bc['foreach']((_0x447af2,_0x380da2)=>{_0x1edff4=_0x1edff4['updateChild'](_0x447af2,_0x380da2);}),_0x1edff4;}function bi(_0x4ab3b6,_0x45438e,_0x50fa87,_0x448a44,_0x4eb3c8,_0x556054,_0x4fa63a,_0x4e440c){if(_0x45438e['serverCache']['getNode']()['isEmpty']()&&!_0x45438e['serverCache']['isFullyInitialized']())return _0x45438e;let _0x52a4c4=_0x45438e,_0x5876c6;v(_0x50fa87)?_0x5876c6=_0x448a44:_0x5876c6=new S(null)['setTree'](_0x50fa87,_0x448a44);const _0x4b4925=_0x45438e['serverCache']['getNode']();return _0x5876c6['children']['inorderTraversal']((_0x1a7739,_0x4d46cd)=>{if(_0x4b4925['hasChild'](_0x1a7739)){const _0x168a86=_0x45438e['serverCache']['getNode']()['getImmediateChild'](_0x1a7739),_0x2d7de9=ur(_0x4ab3b6,_0x168a86,_0x4d46cd);_0x52a4c4=En(_0x4ab3b6,_0x52a4c4,new C(_0x1a7739),_0x2d7de9,_0x4eb3c8,_0x556054,_0x4fa63a,_0x4e440c);}}),_0x5876c6['children']['inorderTraversal']((_0x1c612b,_0x3e9549)=>{const _0x52e0b2=!_0x45438e['serverCache']['isCompleteForChild'](_0x1c612b)&&_0x3e9549['value']===null;if(!_0x4b4925['hasChild'](_0x1c612b)&&!_0x52e0b2){const _0x441f4e=_0x45438e['serverCache']['getNode']()['getImmediateChild'](_0x1c612b),_0x298aec=ur(_0x4ab3b6,_0x441f4e,_0x3e9549);_0x52a4c4=En(_0x4ab3b6,_0x52a4c4,new C(_0x1c612b),_0x298aec,_0x4eb3c8,_0x556054,_0x4fa63a,_0x4e440c);}}),_0x52a4c4;}function Nu(_0x358a04,_0x5edd20,_0x204658,_0x53c654,_0x4324f7,_0x32ad25,_0x23b83c){if(vn(_0x4324f7,_0x204658)!=null)return _0x5edd20;const _0x5c508c=_0x5edd20['serverCache']['isFiltered'](),_0x11200c=_0x5edd20['serverCache'];if(_0x53c654['value']!=null){if(v(_0x204658)&&_0x11200c['isFullyInitialized']()||_0x11200c['isCompleteForPath'](_0x204658))return En(_0x358a04,_0x5edd20,_0x204658,_0x11200c['getNode']()['getChild'](_0x204658),_0x4324f7,_0x32ad25,_0x5c508c,_0x23b83c);if(v(_0x204658)){let _0x1f76ce=new S(null);return _0x11200c['getNode']()['forEachChild'](ye,(_0x225fd6,_0x550f02)=>{_0x1f76ce=_0x1f76ce['set'](new C(_0x225fd6),_0x550f02);}),bi(_0x358a04,_0x5edd20,_0x204658,_0x1f76ce,_0x4324f7,_0x32ad25,_0x5c508c,_0x23b83c);}else return _0x5edd20;}else{let _0x5a8dff=new S(null);return _0x53c654['foreach']((_0x39a31e,_0x5c1cb5)=>{const _0x19bb24=k(_0x204658,_0x39a31e);_0x11200c['isCompleteForPath'](_0x19bb24)&&(_0x5a8dff=_0x5a8dff['set'](_0x39a31e,_0x11200c['getNode']()['getChild'](_0x19bb24)));}),bi(_0x358a04,_0x5edd20,_0x204658,_0x5a8dff,_0x4324f7,_0x32ad25,_0x5c508c,_0x23b83c);}}function Pu(_0x445757,_0x3281a6,_0x2c9dfd,_0x1faa19,_0x159351){const _0x141dc8=_0x3281a6['serverCache'],_0x32c859=Uo(_0x3281a6,_0x141dc8['getNode'](),_0x141dc8['isFullyInitialized']()||v(_0x2c9dfd),_0x141dc8['isFiltered']());return qo(_0x445757,_0x32c859,_0x2c9dfd,_0x1faa19,Go,_0x159351);}function Ou(_0x3087ae,_0x51ae65,_0x3c273e,_0x25a662,_0x24b645,_0x3eb9a2){let _0x238060;if(vn(_0x25a662,_0x3c273e)!=null)return _0x51ae65;{const _0x5bc897=new ss(_0x25a662,_0x51ae65,_0x24b645),_0x88e2a5=_0x51ae65['eventCache']['getNode']();let _0x546803;if(v(_0x3c273e)||y(_0x3c273e)==='.priority'){let _0x131369;if(_0x51ae65['serverCache']['isFullyInitialized']())_0x131369=yn(_0x25a662,We(_0x51ae65));else{const _0xcec54c=_0x51ae65['serverCache']['getNode']();f(_0xcec54c instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x131369=ns(_0x25a662,_0xcec54c);}_0x131369=_0x131369,_0x546803=_0x3087ae['filter']['updateFullNode'](_0x88e2a5,_0x131369,_0x3eb9a2);}else{const _0x3a6a28=y(_0x3c273e);let _0x3aaa4d=is(_0x25a662,_0x3a6a28,_0x51ae65['serverCache']);_0x3aaa4d==null&&_0x51ae65['serverCache']['isCompleteForChild'](_0x3a6a28)&&(_0x3aaa4d=_0x88e2a5['getImmediateChild'](_0x3a6a28)),_0x3aaa4d!=null?_0x546803=_0x3087ae['filter']['updateChild'](_0x88e2a5,_0x3a6a28,_0x3aaa4d,b(_0x3c273e),_0x5bc897,_0x3eb9a2):_0x51ae65['eventCache']['getNode']()['hasChild'](_0x3a6a28)?_0x546803=_0x3087ae['filter']['updateChild'](_0x88e2a5,_0x3a6a28,g['EMPTY_NODE'],b(_0x3c273e),_0x5bc897,_0x3eb9a2):_0x546803=_0x88e2a5,_0x546803['isEmpty']()&&_0x51ae65['serverCache']['isFullyInitialized']()&&(_0x238060=yn(_0x25a662,We(_0x51ae65)),_0x238060['isLeafNode']()&&(_0x546803=_0x3087ae['filter']['updateFullNode'](_0x546803,_0x238060,_0x3eb9a2)));}return _0x238060=_0x51ae65['serverCache']['isFullyInitialized']()||vn(_0x25a662,w())!=null,Tt(_0x51ae65,_0x546803,_0x238060,_0x3087ae['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x291d5a,_0x19d22b){this['query_']=_0x291d5a,this['eventRegistrations_']=[];const _0x455422=this['query_']['_queryParams'],_0x1211b1=new Ji(_0x455422['getIndex']()),_0x183531=Kh(_0x455422);this['processor_']=Su(_0x183531);const _0x61dc41=_0x19d22b['serverCache'],_0x787bee=_0x19d22b['eventCache'],_0x471a46=_0x1211b1['updateFullNode'](g['EMPTY_NODE'],_0x61dc41['getNode'](),null),_0x3fd699=_0x183531['updateFullNode'](g['EMPTY_NODE'],_0x787bee['getNode'](),null),_0x1fb0d0=new Ce(_0x471a46,_0x61dc41['isFullyInitialized'](),_0x1211b1['filtersNodes']()),_0x39dc87=new Ce(_0x3fd699,_0x787bee['isFullyInitialized'](),_0x183531['filtersNodes']());this['viewCache_']=Mn(_0x39dc87,_0x1fb0d0),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x17305f){return _0x17305f['viewCache_']['serverCache']['getNode']();}function Lu(_0x3a08c0){return mn(_0x3a08c0['viewCache_']);}function xu(_0x1f23d7,_0x1a8fa4){const _0x55ad1=We(_0x1f23d7['viewCache_']);return _0x55ad1&&(_0x1f23d7['query']['_queryParams']['loadsAllData']()||!v(_0x1a8fa4)&&!_0x55ad1['getImmediateChild'](y(_0x1a8fa4))['isEmpty']())?_0x55ad1['getChild'](_0x1a8fa4):null;}function dr(_0x3d6335){return _0x3d6335['eventRegistrations_']['length']===0x0;}function Fu(_0x5dbf02,_0x1460a1){_0x5dbf02['eventRegistrations_']['push'](_0x1460a1);}function fr(_0x308c56,_0x1e7dd7,_0x576c16){const _0xb23221=[];if(_0x576c16){f(_0x1e7dd7==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x25800d=_0x308c56['query']['_path'];_0x308c56['eventRegistrations_']['forEach'](_0x2febe4=>{const _0x110ddf=_0x2febe4['createCancelEvent'](_0x576c16,_0x25800d);_0x110ddf&&_0xb23221['push'](_0x110ddf);});}if(_0x1e7dd7){let _0xc25988=[];for(let _0x2516a2=0x0;_0x2516a2<_0x308c56['eventRegistrations_']['length'];++_0x2516a2){const _0x3ab25c=_0x308c56['eventRegistrations_'][_0x2516a2];if(!_0x3ab25c['matches'](_0x1e7dd7))_0xc25988['push'](_0x3ab25c);else{if(_0x1e7dd7['hasAnyCallback']()){_0xc25988=_0xc25988['concat'](_0x308c56['eventRegistrations_']['slice'](_0x2516a2+0x1));break;}}}_0x308c56['eventRegistrations_']=_0xc25988;}else _0x308c56['eventRegistrations_']=[];return _0xb23221;}function pr(_0x11cad9,_0x2d7ba3,_0x39e725,_0x2050e1){_0x2d7ba3['type']===j['MERGE']&&_0x2d7ba3['source']['queryId']!==null&&(f(We(_0x11cad9['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(mn(_0x11cad9['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x25efdf=_0x11cad9['viewCache_'],_0x320253=Ru(_0x11cad9['processor_'],_0x25efdf,_0x2d7ba3,_0x39e725,_0x2050e1);return bu(_0x11cad9['processor_'],_0x320253['viewCache']),f(_0x320253['viewCache']['serverCache']['isFullyInitialized']()||!_0x25efdf['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x11cad9['viewCache_']=_0x320253['viewCache'],zo(_0x11cad9,_0x320253['changes'],_0x320253['viewCache']['eventCache']['getNode'](),null);}function Uu(_0xe24685,_0xf4010){const _0x3246b1=_0xe24685['viewCache_']['eventCache'],_0x196ebd=[];return _0x3246b1['getNode']()['isLeafNode']()||_0x3246b1['getNode']()['forEachChild'](R,(_0xaed6e9,_0x2e8986)=>{_0x196ebd['push'](et(_0xaed6e9,_0x2e8986));}),_0x3246b1['isFullyInitialized']()&&_0x196ebd['push'](Lo(_0x3246b1['getNode']())),zo(_0xe24685,_0x196ebd,_0x3246b1['getNode'](),_0xf4010);}function zo(_0x5a8d32,_0x25f292,_0x3bc86f,_0x4efc0d){const _0x372b6e=_0x4efc0d?[_0x4efc0d]:_0x5a8d32['eventRegistrations_'];return ru(_0x5a8d32['eventGenerator_'],_0x25f292,_0x3bc86f,_0x372b6e);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;class jo{constructor(){this['views']=new Map();}}function Wu(_0x4c2b7d){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x4c2b7d;}function Bu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}function Vu(_0x59ff23){return _0x59ff23['views']['size']===0x0;}function rs(_0x5ecf61,_0x23807b,_0x4c8897,_0xdcd002){const _0x534b5d=_0x23807b['source']['queryId'];if(_0x534b5d!==null){const _0x17458f=_0x5ecf61['views']['get'](_0x534b5d);return f(_0x17458f!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),pr(_0x17458f,_0x23807b,_0x4c8897,_0xdcd002);}else{let _0x387601=[];for(const _0x5752b8 of _0x5ecf61['views']['values']())_0x387601=_0x387601['concat'](pr(_0x5752b8,_0x23807b,_0x4c8897,_0xdcd002));return _0x387601;}}function Ko(_0x1cab8f,_0x4ce7b0,_0x58839c,_0x3de6c9,_0x42a29e){const _0x1f8428=_0x4ce7b0['_queryIdentifier'],_0x492135=_0x1cab8f['views']['get'](_0x1f8428);if(!_0x492135){let _0x3aae93=yn(_0x58839c,_0x42a29e?_0x3de6c9:null),_0x3247c1=!0x1;_0x3aae93?_0x3247c1=!0x0:_0x3de6c9 instanceof g?(_0x3aae93=ns(_0x58839c,_0x3de6c9),_0x3247c1=!0x1):(_0x3aae93=g['EMPTY_NODE'],_0x3247c1=!0x1);const _0x9d792c=Mn(new Ce(_0x3aae93,_0x3247c1,!0x1),new Ce(_0x3de6c9,_0x42a29e,!0x1));return new Du(_0x4ce7b0,_0x9d792c);}return _0x492135;}function Hu(_0x426fed,_0x575e0b,_0x508b3e,_0x1cea88,_0x452c04,_0x54ce70){const _0x1cf07c=Ko(_0x426fed,_0x575e0b,_0x1cea88,_0x452c04,_0x54ce70);return _0x426fed['views']['has'](_0x575e0b['_queryIdentifier'])||_0x426fed['views']['set'](_0x575e0b['_queryIdentifier'],_0x1cf07c),Fu(_0x1cf07c,_0x508b3e),Uu(_0x1cf07c,_0x508b3e);}function $u(_0x35cc79,_0x569565,_0x443ede,_0x13217e){const _0x1568b5=_0x569565['_queryIdentifier'],_0x3b9ba9=[];let _0x3f0bf9=[];const _0x172887=Te(_0x35cc79);if(_0x1568b5==='default'){for(const [_0x34db62,_0x262ce1]of _0x35cc79['views']['entries']())_0x3f0bf9=_0x3f0bf9['concat'](fr(_0x262ce1,_0x443ede,_0x13217e)),dr(_0x262ce1)&&(_0x35cc79['views']['delete'](_0x34db62),_0x262ce1['query']['_queryParams']['loadsAllData']()||_0x3b9ba9['push'](_0x262ce1['query']));}else{const _0x1cc895=_0x35cc79['views']['get'](_0x1568b5);_0x1cc895&&(_0x3f0bf9=_0x3f0bf9['concat'](fr(_0x1cc895,_0x443ede,_0x13217e)),dr(_0x1cc895)&&(_0x35cc79['views']['delete'](_0x1568b5),_0x1cc895['query']['_queryParams']['loadsAllData']()||_0x3b9ba9['push'](_0x1cc895['query'])));}return _0x172887&&!Te(_0x35cc79)&&_0x3b9ba9['push'](new(Bu())(_0x569565['_repo'],_0x569565['_path'])),{'removed':_0x3b9ba9,'events':_0x3f0bf9};}function Yo(_0x1123e3){const _0x2111df=[];for(const _0x229af9 of _0x1123e3['views']['values']())_0x229af9['query']['_queryParams']['loadsAllData']()||_0x2111df['push'](_0x229af9);return _0x2111df;}function Ee(_0x50d773,_0x5a4d9f){let _0x230a73=null;for(const _0x2ce2c1 of _0x50d773['views']['values']())_0x230a73=_0x230a73||xu(_0x2ce2c1,_0x5a4d9f);return _0x230a73;}function Qo(_0x2a7515,_0x4e04cb){if(_0x4e04cb['_queryParams']['loadsAllData']())return xn(_0x2a7515);{const _0x340035=_0x4e04cb['_queryIdentifier'];return _0x2a7515['views']['get'](_0x340035);}}function Jo(_0xb73102,_0x5e4ca9){return Qo(_0xb73102,_0x5e4ca9)!=null;}function Te(_0x1ec85d){return xn(_0x1ec85d)!=null;}function xn(_0x511979){for(const _0x38010f of _0x511979['views']['values']())if(_0x38010f['query']['_queryParams']['loadsAllData']())return _0x38010f;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let wn;function Gu(_0xf7e584){f(!wn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),wn=_0xf7e584;}function qu(){return f(wn,'Reference.ts\x20has\x20not\x20been\x20loaded'),wn;}let zu=0x1;class _r{constructor(_0x136fb0){this['listenProvider_']=_0x136fb0,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function os(_0x2507d7,_0x22b2e4,_0x76d0fe,_0x27103f,_0x579a6b){return lu(_0x2507d7['pendingWriteTree_'],_0x22b2e4,_0x76d0fe,_0x27103f,_0x579a6b),_0x579a6b?ut(_0x2507d7,new Ue(Zi(),_0x22b2e4,_0x76d0fe)):[];}function ju(_0x4506f1,_0x42503b,_0x4747ce,_0x507acb){hu(_0x4506f1['pendingWriteTree_'],_0x42503b,_0x4747ce,_0x507acb);const _0x37f65f=S['fromObject'](_0x4747ce);return ut(_0x4506f1,new tt(Zi(),_0x42503b,_0x37f65f));}function pe(_0x201720,_0x26a7d3,_0x11fe28=!0x1){const _0x437f61=uu(_0x201720['pendingWriteTree_'],_0x26a7d3);if(du(_0x201720['pendingWriteTree_'],_0x26a7d3)){let _0x3844da=new S(null);return _0x437f61['snap']!=null?_0x3844da=_0x3844da['set'](w(),!0x0):x(_0x437f61['children'],_0x24a25c=>{_0x3844da=_0x3844da['set'](new C(_0x24a25c),!0x0);}),ut(_0x201720,new gn(_0x437f61['path'],_0x3844da,_0x11fe28));}else return[];}function Gt(_0xa42082,_0x240cf6,_0x20b49d){return ut(_0xa42082,new Ue(es(),_0x240cf6,_0x20b49d));}function Ku(_0x59084e,_0x3ecee9,_0x520fd0){const _0x5119ae=S['fromObject'](_0x520fd0);return ut(_0x59084e,new tt(es(),_0x3ecee9,_0x5119ae));}function Yu(_0x4aed2f,_0x46e851){return ut(_0x4aed2f,new Lt(es(),_0x46e851));}function Qu(_0x362f18,_0x2f4223,_0x56f963){const _0x3c29c9=as(_0x362f18,_0x56f963);if(_0x3c29c9){const _0x1de4b9=cs(_0x3c29c9),_0x5dfaae=_0x1de4b9['path'],_0x4cebba=_0x1de4b9['queryId'],_0x424846=F(_0x5dfaae,_0x2f4223),_0x520798=new Lt(ts(_0x4cebba),_0x424846);return ls(_0x362f18,_0x5dfaae,_0x520798);}else return[];}function Cn(_0x1febe6,_0x4dfdfd,_0x16a5c4,_0x5bc565,_0x11dd60=!0x1){const _0x3bf8d0=_0x4dfdfd['_path'],_0x519540=_0x1febe6['syncPointTree_']['get'](_0x3bf8d0);let _0x103602=[];if(_0x519540&&(_0x4dfdfd['_queryIdentifier']==='default'||Jo(_0x519540,_0x4dfdfd))){const _0x7908b1=$u(_0x519540,_0x4dfdfd,_0x16a5c4,_0x5bc565);Vu(_0x519540)&&(_0x1febe6['syncPointTree_']=_0x1febe6['syncPointTree_']['remove'](_0x3bf8d0));const _0x4caeb9=_0x7908b1['removed'];if(_0x103602=_0x7908b1['events'],!_0x11dd60){const _0x53f45b=_0x4caeb9['findIndex'](_0x1f5908=>_0x1f5908['_queryParams']['loadsAllData']())!==-0x1,_0x300b83=_0x1febe6['syncPointTree_']['findOnPath'](_0x3bf8d0,(_0x1ca936,_0x4b225d)=>Te(_0x4b225d));if(_0x53f45b&&!_0x300b83){const _0x2a6850=_0x1febe6['syncPointTree_']['subtree'](_0x3bf8d0);if(!_0x2a6850['isEmpty']()){const _0x5740f2=Zu(_0x2a6850);for(let _0x53ffa8=0x0;_0x53ffa8<_0x5740f2['length'];++_0x53ffa8){const _0x2a26d9=_0x5740f2[_0x53ffa8],_0x31a4e7=_0x2a26d9['query'],_0x4bbed7=ta(_0x1febe6,_0x2a26d9);_0x1febe6['listenProvider_']['startListening'](bt(_0x31a4e7),xt(_0x1febe6,_0x31a4e7),_0x4bbed7['hashFn'],_0x4bbed7['onComplete']);}}}!_0x300b83&&_0x4caeb9['length']>0x0&&!_0x5bc565&&(_0x53f45b?_0x1febe6['listenProvider_']['stopListening'](bt(_0x4dfdfd),null):_0x4caeb9['forEach'](_0x539145=>{const _0x11237c=_0x1febe6['queryToTagMap']['get'](Un(_0x539145));_0x1febe6['listenProvider_']['stopListening'](bt(_0x539145),_0x11237c);}));}ed(_0x1febe6,_0x4caeb9);}return _0x103602;}function Xo(_0x16d7e8,_0x435d3f,_0x15ba66,_0x48a2ea){const _0x1c462d=as(_0x16d7e8,_0x48a2ea);if(_0x1c462d!=null){const _0x2629d6=cs(_0x1c462d),_0xa808c5=_0x2629d6['path'],_0x52c750=_0x2629d6['queryId'],_0x6ed33c=F(_0xa808c5,_0x435d3f),_0x3c091a=new Ue(ts(_0x52c750),_0x6ed33c,_0x15ba66);return ls(_0x16d7e8,_0xa808c5,_0x3c091a);}else return[];}function Ju(_0x15541,_0x523413,_0x4ba757,_0x1e81a1){const _0xd950a4=as(_0x15541,_0x1e81a1);if(_0xd950a4){const _0x32c189=cs(_0xd950a4),_0x18a919=_0x32c189['path'],_0xe97e36=_0x32c189['queryId'],_0x45a708=F(_0x18a919,_0x523413),_0x2c9740=S['fromObject'](_0x4ba757),_0x368983=new tt(ts(_0xe97e36),_0x45a708,_0x2c9740);return ls(_0x15541,_0x18a919,_0x368983);}else return[];}function Ri(_0x463e5c,_0xa25725,_0x2355d3,_0x543edc=!0x1){const _0x23096a=_0xa25725['_path'];let _0x24b734=null,_0x2f4694=!0x1;_0x463e5c['syncPointTree_']['foreachOnPath'](_0x23096a,(_0x268f49,_0x308eff)=>{const _0x2cd9f9=F(_0x268f49,_0x23096a);_0x24b734=_0x24b734||Ee(_0x308eff,_0x2cd9f9),_0x2f4694=_0x2f4694||Te(_0x308eff);});let _0x1e5754=_0x463e5c['syncPointTree_']['get'](_0x23096a);_0x1e5754?(_0x2f4694=_0x2f4694||Te(_0x1e5754),_0x24b734=_0x24b734||Ee(_0x1e5754,w())):(_0x1e5754=new jo(),_0x463e5c['syncPointTree_']=_0x463e5c['syncPointTree_']['set'](_0x23096a,_0x1e5754));let _0x341e00;_0x24b734!=null?_0x341e00=!0x0:(_0x341e00=!0x1,_0x24b734=g['EMPTY_NODE'],_0x463e5c['syncPointTree_']['subtree'](_0x23096a)['foreachChild']((_0x5771cc,_0x51c107)=>{const _0x59ab07=Ee(_0x51c107,w());_0x59ab07&&(_0x24b734=_0x24b734['updateImmediateChild'](_0x5771cc,_0x59ab07));}));const _0x45ca76=Jo(_0x1e5754,_0xa25725);if(!_0x45ca76&&!_0xa25725['_queryParams']['loadsAllData']()){const _0x1c8efc=Un(_0xa25725);f(!_0x463e5c['queryToTagMap']['has'](_0x1c8efc),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0xc3e8eb=td();_0x463e5c['queryToTagMap']['set'](_0x1c8efc,_0xc3e8eb),_0x463e5c['tagToQueryMap']['set'](_0xc3e8eb,_0x1c8efc);}const _0x358ab8=Ln(_0x463e5c['pendingWriteTree_'],_0x23096a);let _0x105d28=Hu(_0x1e5754,_0xa25725,_0x2355d3,_0x358ab8,_0x24b734,_0x341e00);if(!_0x45ca76&&!_0x2f4694&&!_0x543edc){const _0x1698c3=Qo(_0x1e5754,_0xa25725);_0x105d28=_0x105d28['concat'](nd(_0x463e5c,_0xa25725,_0x1698c3));}return _0x105d28;}function Fn(_0x2f3b5f,_0x3a10ad,_0x1499cb){const _0x4023b5=_0x2f3b5f['pendingWriteTree_'],_0x4b3c4a=_0x2f3b5f['syncPointTree_']['findOnPath'](_0x3a10ad,(_0x165931,_0x30508b)=>{const _0x67a1bb=F(_0x165931,_0x3a10ad),_0x5f50d2=Ee(_0x30508b,_0x67a1bb);if(_0x5f50d2)return _0x5f50d2;});return Vo(_0x4023b5,_0x3a10ad,_0x4b3c4a,_0x1499cb,!0x0);}function Xu(_0x339650,_0x536dca){const _0x590085=_0x536dca['_path'];let _0x79d603=null;_0x339650['syncPointTree_']['foreachOnPath'](_0x590085,(_0x3399fa,_0x30accf)=>{const _0x4700a2=F(_0x3399fa,_0x590085);_0x79d603=_0x79d603||Ee(_0x30accf,_0x4700a2);});let _0x315033=_0x339650['syncPointTree_']['get'](_0x590085);_0x315033?_0x79d603=_0x79d603||Ee(_0x315033,w()):(_0x315033=new jo(),_0x339650['syncPointTree_']=_0x339650['syncPointTree_']['set'](_0x590085,_0x315033));const _0x5d3f38=_0x79d603!=null,_0x464196=_0x5d3f38?new Ce(_0x79d603,!0x0,!0x1):null,_0x191a56=Ln(_0x339650['pendingWriteTree_'],_0x536dca['_path']),_0x3d530b=Ko(_0x315033,_0x536dca,_0x191a56,_0x5d3f38?_0x464196['getNode']():g['EMPTY_NODE'],_0x5d3f38);return Lu(_0x3d530b);}function ut(_0x321117,_0x5e8a9d){return Zo(_0x5e8a9d,_0x321117['syncPointTree_'],null,Ln(_0x321117['pendingWriteTree_'],w()));}function Zo(_0x2c2fc2,_0x58de57,_0x3d9c11,_0x240460){if(v(_0x2c2fc2['path']))return ea(_0x2c2fc2,_0x58de57,_0x3d9c11,_0x240460);{const _0x4dfea9=_0x58de57['get'](w());_0x3d9c11==null&&_0x4dfea9!=null&&(_0x3d9c11=Ee(_0x4dfea9,w()));let _0x2b4eea=[];const _0x593290=y(_0x2c2fc2['path']),_0x2ea029=_0x2c2fc2['operationForChild'](_0x593290),_0x49dcaa=_0x58de57['children']['get'](_0x593290);if(_0x49dcaa&&_0x2ea029){const _0x3065ec=_0x3d9c11?_0x3d9c11['getImmediateChild'](_0x593290):null,_0x458b0e=Ho(_0x240460,_0x593290);_0x2b4eea=_0x2b4eea['concat'](Zo(_0x2ea029,_0x49dcaa,_0x3065ec,_0x458b0e));}return _0x4dfea9&&(_0x2b4eea=_0x2b4eea['concat'](rs(_0x4dfea9,_0x2c2fc2,_0x240460,_0x3d9c11))),_0x2b4eea;}}function ea(_0x44c44e,_0xeb82e0,_0x23c6e4,_0x32cb51){const _0x538203=_0xeb82e0['get'](w());_0x23c6e4==null&&_0x538203!=null&&(_0x23c6e4=Ee(_0x538203,w()));let _0x12a72b=[];return _0xeb82e0['children']['inorderTraversal']((_0x1801e0,_0x467139)=>{const _0x44c2d7=_0x23c6e4?_0x23c6e4['getImmediateChild'](_0x1801e0):null,_0x83fc8e=Ho(_0x32cb51,_0x1801e0),_0x50aa80=_0x44c44e['operationForChild'](_0x1801e0);_0x50aa80&&(_0x12a72b=_0x12a72b['concat'](ea(_0x50aa80,_0x467139,_0x44c2d7,_0x83fc8e)));}),_0x538203&&(_0x12a72b=_0x12a72b['concat'](rs(_0x538203,_0x44c44e,_0x32cb51,_0x23c6e4))),_0x12a72b;}function ta(_0x964d21,_0x3781e6){const _0x823f99=_0x3781e6['query'],_0xce7ed=xt(_0x964d21,_0x823f99);return{'hashFn':()=>(Mu(_0x3781e6)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x258ef9=>{if(_0x258ef9==='ok')return _0xce7ed?Qu(_0x964d21,_0x823f99['_path'],_0xce7ed):Yu(_0x964d21,_0x823f99['_path']);{const _0x2d8f5d=Kl(_0x258ef9,_0x823f99);return Cn(_0x964d21,_0x823f99,null,_0x2d8f5d);}}};}function xt(_0x38308c,_0x3d5dbc){const _0x2da59b=Un(_0x3d5dbc);return _0x38308c['queryToTagMap']['get'](_0x2da59b);}function Un(_0x1546b2){return _0x1546b2['_path']['toString']()+'$'+_0x1546b2['_queryIdentifier'];}function as(_0x3b67ce,_0x2a98fc){return _0x3b67ce['tagToQueryMap']['get'](_0x2a98fc);}function cs(_0x5d5c01){const _0x575c10=_0x5d5c01['indexOf']('$');return f(_0x575c10!==-0x1&&_0x575c10<_0x5d5c01['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x5d5c01['substr'](_0x575c10+0x1),'path':new C(_0x5d5c01['substr'](0x0,_0x575c10))};}function ls(_0x17639b,_0x2bbba5,_0x21da69){const _0x2ef1cd=_0x17639b['syncPointTree_']['get'](_0x2bbba5);f(_0x2ef1cd,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x543600=Ln(_0x17639b['pendingWriteTree_'],_0x2bbba5);return rs(_0x2ef1cd,_0x21da69,_0x543600,null);}function Zu(_0x26b222){return _0x26b222['fold']((_0x21533c,_0x37fbc0,_0x2ee94a)=>{if(_0x37fbc0&&Te(_0x37fbc0))return[xn(_0x37fbc0)];{let _0x3d9591=[];return _0x37fbc0&&(_0x3d9591=Yo(_0x37fbc0)),x(_0x2ee94a,(_0x415132,_0x4651ec)=>{_0x3d9591=_0x3d9591['concat'](_0x4651ec);}),_0x3d9591;}});}function bt(_0x1c27de){return _0x1c27de['_queryParams']['loadsAllData']()&&!_0x1c27de['_queryParams']['isDefault']()?new(qu())(_0x1c27de['_repo'],_0x1c27de['_path']):_0x1c27de;}function ed(_0x9c9fec,_0x5b9959){for(let _0x86f465=0x0;_0x86f465<_0x5b9959['length'];++_0x86f465){const _0x803f64=_0x5b9959[_0x86f465];if(!_0x803f64['_queryParams']['loadsAllData']()){const _0x49bdf4=Un(_0x803f64),_0x18c1b2=_0x9c9fec['queryToTagMap']['get'](_0x49bdf4);_0x9c9fec['queryToTagMap']['delete'](_0x49bdf4),_0x9c9fec['tagToQueryMap']['delete'](_0x18c1b2);}}}function td(){return zu++;}function nd(_0x3acd7b,_0x5bd347,_0x2c1514){const _0x264f3c=_0x5bd347['_path'],_0x2a9986=xt(_0x3acd7b,_0x5bd347),_0x5ec419=ta(_0x3acd7b,_0x2c1514),_0x4f196a=_0x3acd7b['listenProvider_']['startListening'](bt(_0x5bd347),_0x2a9986,_0x5ec419['hashFn'],_0x5ec419['onComplete']),_0x15cdbc=_0x3acd7b['syncPointTree_']['subtree'](_0x264f3c);if(_0x2a9986)f(!Te(_0x15cdbc['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0xc091da=_0x15cdbc['fold']((_0x4d6880,_0x497973,_0x59b8d9)=>{if(!v(_0x4d6880)&&_0x497973&&Te(_0x497973))return[xn(_0x497973)['query']];{let _0x2f7eca=[];return _0x497973&&(_0x2f7eca=_0x2f7eca['concat'](Yo(_0x497973)['map'](_0x94e88=>_0x94e88['query']))),x(_0x59b8d9,(_0x3ce69f,_0x44e006)=>{_0x2f7eca=_0x2f7eca['concat'](_0x44e006);}),_0x2f7eca;}});for(let _0x3a777=0x0;_0x3a777<_0xc091da['length'];++_0x3a777){const _0x3996e7=_0xc091da[_0x3a777];_0x3acd7b['listenProvider_']['stopListening'](bt(_0x3996e7),xt(_0x3acd7b,_0x3996e7));}}return _0x4f196a;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class hs{constructor(_0x135a33){this['node_']=_0x135a33;}['getImmediateChild'](_0x14a99f){const _0x5483c8=this['node_']['getImmediateChild'](_0x14a99f);return new hs(_0x5483c8);}['node'](){return this['node_'];}}class us{constructor(_0x3e92f3,_0x40113e){this['syncTree_']=_0x3e92f3,this['path_']=_0x40113e;}['getImmediateChild'](_0x477b4c){const _0x2b9e41=k(this['path_'],_0x477b4c);return new us(this['syncTree_'],_0x2b9e41);}['node'](){return Fn(this['syncTree_'],this['path_']);}}const id=function(_0x439e47){return _0x439e47=_0x439e47||{},_0x439e47['timestamp']=_0x439e47['timestamp']||new Date()['getTime'](),_0x439e47;},gr=function(_0x248f5c,_0x598b51,_0x316dcb){if(!_0x248f5c||typeof _0x248f5c!='object')return _0x248f5c;if(f('.sv'in _0x248f5c,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x248f5c['.sv']=='string')return sd(_0x248f5c['.sv'],_0x598b51,_0x316dcb);if(typeof _0x248f5c['.sv']=='object')return rd(_0x248f5c['.sv'],_0x598b51);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x248f5c,null,0x2));},sd=function(_0x1e22d8,_0x39b709,_0x4b7cf6){switch(_0x1e22d8){case'timestamp':return _0x4b7cf6['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x1e22d8);}},rd=function(_0x5a9d60,_0xfde604,_0x3b2d27){_0x5a9d60['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x5a9d60,null,0x2));const _0xdf8b89=_0x5a9d60['increment'];typeof _0xdf8b89!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0xdf8b89);const _0x385ca0=_0xfde604['node']();if(f(_0x385ca0!==null&&typeof _0x385ca0<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x385ca0['isLeafNode']())return _0xdf8b89;const _0x333d0c=_0x385ca0['getValue']();return typeof _0x333d0c!='number'?_0xdf8b89:_0x333d0c+_0xdf8b89;},na=function(_0x4c21bd,_0x2fbc4b,_0x23434b,_0x52408e){return fs(_0x2fbc4b,new us(_0x23434b,_0x4c21bd),_0x52408e);},ds=function(_0x43ad5b,_0x3e7129,_0x229ca4){return fs(_0x43ad5b,new hs(_0x3e7129),_0x229ca4);};function fs(_0x5f72f7,_0x315117,_0x4adb55){const _0x216a41=_0x5f72f7['getPriority']()['val'](),_0x385df6=gr(_0x216a41,_0x315117['getImmediateChild']('.priority'),_0x4adb55);let _0x2a1b23;if(_0x5f72f7['isLeafNode']()){const _0x5d5590=_0x5f72f7,_0x13ab93=gr(_0x5d5590['getValue'](),_0x315117,_0x4adb55);return _0x13ab93!==_0x5d5590['getValue']()||_0x385df6!==_0x5d5590['getPriority']()['val']()?new D(_0x13ab93,P(_0x385df6)):_0x5f72f7;}else{const _0x44fab8=_0x5f72f7;return _0x2a1b23=_0x44fab8,_0x385df6!==_0x44fab8['getPriority']()['val']()&&(_0x2a1b23=_0x2a1b23['updatePriority'](new D(_0x385df6))),_0x44fab8['forEachChild'](R,(_0x4e8baa,_0x1496c1)=>{const _0x9d567e=fs(_0x1496c1,_0x315117['getImmediateChild'](_0x4e8baa),_0x4adb55);_0x9d567e!==_0x1496c1&&(_0x2a1b23=_0x2a1b23['updateImmediateChild'](_0x4e8baa,_0x9d567e));}),_0x2a1b23;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ps{constructor(_0x6d6f22='',_0x4c7985=null,_0x10ffb0={'children':{},'childCount':0x0}){this['name']=_0x6d6f22,this['parent']=_0x4c7985,this['node']=_0x10ffb0;}}function Wn(_0x1f9443,_0x18e759){let _0x3bac2e=_0x18e759 instanceof C?_0x18e759:new C(_0x18e759),_0x1a8a07=_0x1f9443,_0x101c76=y(_0x3bac2e);for(;_0x101c76!==null;){const _0x180659=De(_0x1a8a07['node']['children'],_0x101c76)||{'children':{},'childCount':0x0};_0x1a8a07=new ps(_0x101c76,_0x1a8a07,_0x180659),_0x3bac2e=b(_0x3bac2e),_0x101c76=y(_0x3bac2e);}return _0x1a8a07;}function Ge(_0xa99d75){return _0xa99d75['node']['value'];}function _s(_0x54814a,_0x150586){_0x54814a['node']['value']=_0x150586,Ai(_0x54814a);}function ia(_0x46b03a){return _0x46b03a['node']['childCount']>0x0;}function od(_0x499248){return Ge(_0x499248)===void 0x0&&!ia(_0x499248);}function Bn(_0x434948,_0x104b7e){x(_0x434948['node']['children'],(_0x2776d6,_0x5b3822)=>{_0x104b7e(new ps(_0x2776d6,_0x434948,_0x5b3822));});}function sa(_0x34abe8,_0x3226dd,_0x3c96e4,_0xe4288e){_0x3c96e4&&_0x3226dd(_0x34abe8),Bn(_0x34abe8,_0x3e6f79=>{sa(_0x3e6f79,_0x3226dd,!0x0);});}function ad(_0x424ac1,_0x7054ab,_0x23895d){let _0x57998a=_0x424ac1['parent'];for(;_0x57998a!==null;){if(_0x7054ab(_0x57998a))return!0x0;_0x57998a=_0x57998a['parent'];}return!0x1;}function qt(_0x5cc3cf){return new C(_0x5cc3cf['parent']===null?_0x5cc3cf['name']:qt(_0x5cc3cf['parent'])+'/'+_0x5cc3cf['name']);}function Ai(_0x38cb91){_0x38cb91['parent']!==null&&cd(_0x38cb91['parent'],_0x38cb91['name'],_0x38cb91);}function cd(_0x254dad,_0x36c86e,_0x31359c){const _0x133a61=od(_0x31359c),_0xeb5eaf=J(_0x254dad['node']['children'],_0x36c86e);_0x133a61&&_0xeb5eaf?(delete _0x254dad['node']['children'][_0x36c86e],_0x254dad['node']['childCount']--,Ai(_0x254dad)):!_0x133a61&&!_0xeb5eaf&&(_0x254dad['node']['children'][_0x36c86e]=_0x31359c['node'],_0x254dad['node']['childCount']++,Ai(_0x254dad));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ai=0xa*0x400*0x400,gs=function(_0x27aac6){return typeof _0x27aac6=='string'&&_0x27aac6['length']!==0x0&&!ld['test'](_0x27aac6);},ra=function(_0x11df8e){return typeof _0x11df8e=='string'&&_0x11df8e['length']!==0x0&&!hd['test'](_0x11df8e);},ud=function(_0x58578e){return _0x58578e&&(_0x58578e=_0x58578e['replace'](/^\/*\.info(\/|$)/,'/')),ra(_0x58578e);},Tn=function(_0x45480b){return _0x45480b===null||typeof _0x45480b=='string'||typeof _0x45480b=='number'&&!Vi(_0x45480b)||_0x45480b&&typeof _0x45480b=='object'&&J(_0x45480b,'.sv');},zt=function(_0x5a493f,_0x23e86d,_0x11fe75,_0x4323b1){_0x4323b1&&_0x23e86d===void 0x0||jt(Pn(_0x5a493f,'value'),_0x23e86d,_0x11fe75);},jt=function(_0x57c0b0,_0x4c5796,_0x35ee2c){const _0x1897c3=_0x35ee2c instanceof C?new Ah(_0x35ee2c,_0x57c0b0):_0x35ee2c;if(_0x4c5796===void 0x0)throw new Error(_0x57c0b0+'contains\x20undefined\x20'+Pe(_0x1897c3));if(typeof _0x4c5796=='function')throw new Error(_0x57c0b0+'contains\x20a\x20function\x20'+Pe(_0x1897c3)+'\x20with\x20contents\x20=\x20'+_0x4c5796['toString']());if(Vi(_0x4c5796))throw new Error(_0x57c0b0+'contains\x20'+_0x4c5796['toString']()+'\x20'+Pe(_0x1897c3));if(typeof _0x4c5796=='string'&&_0x4c5796['length']>ai/0x3&&On(_0x4c5796)>ai)throw new Error(_0x57c0b0+'contains\x20a\x20string\x20greater\x20than\x20'+ai+'\x20utf8\x20bytes\x20'+Pe(_0x1897c3)+'\x20(\x27'+_0x4c5796['substring'](0x0,0x32)+'...\x27)');if(_0x4c5796&&typeof _0x4c5796=='object'){let _0x1ca48a=!0x1,_0x542916=!0x1;if(x(_0x4c5796,(_0xa4cba6,_0x1ddf3f)=>{if(_0xa4cba6==='.value')_0x1ca48a=!0x0;else{if(_0xa4cba6!=='.priority'&&_0xa4cba6!=='.sv'&&(_0x542916=!0x0,!gs(_0xa4cba6)))throw new Error(_0x57c0b0+'\x20contains\x20an\x20invalid\x20key\x20('+_0xa4cba6+')\x20'+Pe(_0x1897c3)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x1897c3,_0xa4cba6),jt(_0x57c0b0,_0x1ddf3f,_0x1897c3),Nh(_0x1897c3);}),_0x1ca48a&&_0x542916)throw new Error(_0x57c0b0+'\x20contains\x20\x22.value\x22\x20child\x20'+Pe(_0x1897c3)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x10d65a,_0x5872e1){let _0xa0001d,_0x2ff4de;for(_0xa0001d=0x0;_0xa0001d<_0x5872e1['length'];_0xa0001d++){_0x2ff4de=_0x5872e1[_0xa0001d];const _0xaed7b4=Pt(_0x2ff4de);for(let _0x4634e8=0x0;_0x4634e8<_0xaed7b4['length'];_0x4634e8++)if(!(_0xaed7b4[_0x4634e8]==='.priority'&&_0x4634e8===_0xaed7b4['length']-0x1)){if(!gs(_0xaed7b4[_0x4634e8]))throw new Error(_0x10d65a+'contains\x20an\x20invalid\x20key\x20('+_0xaed7b4[_0x4634e8]+')\x20in\x20path\x20'+_0x2ff4de['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x5872e1['sort'](Rh);let _0xf6eddd=null;for(_0xa0001d=0x0;_0xa0001d<_0x5872e1['length'];_0xa0001d++){if(_0x2ff4de=_0x5872e1[_0xa0001d],_0xf6eddd!==null&&G(_0xf6eddd,_0x2ff4de))throw new Error(_0x10d65a+'contains\x20a\x20path\x20'+_0xf6eddd['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x2ff4de['toString']());_0xf6eddd=_0x2ff4de;}},fd=function(_0x18f732,_0x38b33a,_0x15adf1,_0x3cd67b){const _0x189d0e=Pn(_0x18f732,'values');if(!(_0x38b33a&&typeof _0x38b33a=='object')||Array['isArray'](_0x38b33a))throw new Error(_0x189d0e+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x5e0172=[];x(_0x38b33a,(_0x3e275a,_0x42c389)=>{const _0x316022=new C(_0x3e275a);if(jt(_0x189d0e,_0x42c389,k(_0x15adf1,_0x316022)),zi(_0x316022)==='.priority'&&!Tn(_0x42c389))throw new Error(_0x189d0e+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x316022['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x5e0172['push'](_0x316022);}),dd(_0x189d0e,_0x5e0172);},ms=function(_0x2cecfc,_0x4e1775,_0x1ab132,_0x266bc5){if(!ra(_0x1ab132))throw new Error(Pn(_0x2cecfc,_0x4e1775)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x1ab132+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x32ee6a,_0x583751,_0x51b871,_0x28a169){_0x51b871&&(_0x51b871=_0x51b871['replace'](/^\/*\.info(\/|$)/,'/')),ms(_0x32ee6a,_0x583751,_0x51b871);},ys=function(_0x2b6f37,_0x2af3d9){if(y(_0x2af3d9)==='.info')throw new Error(_0x2b6f37+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x1da9a7,_0x5bc101){const _0x2dd418=_0x5bc101['path']['toString']();if(typeof _0x5bc101['repoInfo']['host']!='string'||_0x5bc101['repoInfo']['host']['length']===0x0||!gs(_0x5bc101['repoInfo']['namespace'])&&_0x5bc101['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x2dd418['length']!==0x0&&!ud(_0x2dd418))throw new Error(Pn(_0x1da9a7,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Vn(_0x466e43,_0x20ccef){let _0x58a962=null;for(let _0x1d3434=0x0;_0x1d3434<_0x20ccef['length'];_0x1d3434++){const _0x5e1309=_0x20ccef[_0x1d3434],_0x20d302=_0x5e1309['getPath']();_0x58a962!==null&&!ji(_0x20d302,_0x58a962['path'])&&(_0x466e43['eventLists_']['push'](_0x58a962),_0x58a962=null),_0x58a962===null&&(_0x58a962={'events':[],'path':_0x20d302}),_0x58a962['events']['push'](_0x5e1309);}_0x58a962&&_0x466e43['eventLists_']['push'](_0x58a962);}function oa(_0x4c6425,_0x5eaf50,_0x3c272f){Vn(_0x4c6425,_0x3c272f),aa(_0x4c6425,_0x314777=>ji(_0x314777,_0x5eaf50));}function H(_0x55b595,_0x463c2b,_0x4552c9){Vn(_0x55b595,_0x4552c9),aa(_0x55b595,_0x33127d=>G(_0x33127d,_0x463c2b)||G(_0x463c2b,_0x33127d));}function aa(_0x304c0b,_0x3399e1){_0x304c0b['recursionDepth_']++;let _0x284d89=!0x0;for(let _0x172aed=0x0;_0x172aed<_0x304c0b['eventLists_']['length'];_0x172aed++){const _0x1ed003=_0x304c0b['eventLists_'][_0x172aed];if(_0x1ed003){const _0x2fae4e=_0x1ed003['path'];_0x3399e1(_0x2fae4e)?(md(_0x304c0b['eventLists_'][_0x172aed]),_0x304c0b['eventLists_'][_0x172aed]=null):_0x284d89=!0x1;}}_0x284d89&&(_0x304c0b['eventLists_']=[]),_0x304c0b['recursionDepth_']--;}function md(_0x4c9039){for(let _0x3db544=0x0;_0x3db544<_0x4c9039['events']['length'];_0x3db544++){const _0x4c0ffe=_0x4c9039['events'][_0x3db544];if(_0x4c0ffe!==null){_0x4c9039['events'][_0x3db544]=null;const _0x58a251=_0x4c0ffe['getEventRunner']();wt&&L('event:\x20'+_0x4c0ffe['toString']()),ht(_0x58a251);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x3dc1e0,_0x135332,_0x2125e5,_0x106099){this['repoInfo_']=_0x3dc1e0,this['forceRestClient_']=_0x135332,this['authTokenProvider_']=_0x2125e5,this['appCheckProvider_']=_0x106099,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=_n(),this['transactionQueueTree_']=new ps(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x5bb7f9,_0x66eb76,_0x4d83cc){if(_0x5bb7f9['stats_']=Gi(_0x5bb7f9['repoInfo_']),_0x5bb7f9['forceRestClient_']||Xl())_0x5bb7f9['server_']=new pn(_0x5bb7f9['repoInfo_'],(_0x4a57ba,_0x9987ab,_0xf74076,_0x5033fc)=>{mr(_0x5bb7f9,_0x4a57ba,_0x9987ab,_0xf74076,_0x5033fc);},_0x5bb7f9['authTokenProvider_'],_0x5bb7f9['appCheckProvider_']),setTimeout(()=>yr(_0x5bb7f9,!0x0),0x0);else{if(typeof _0x4d83cc<'u'&&_0x4d83cc!==null){if(typeof _0x4d83cc!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x4d83cc);}catch(_0x19f592){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x19f592);}}_0x5bb7f9['persistentConnection_']=new se(_0x5bb7f9['repoInfo_'],_0x66eb76,(_0x40cba0,_0x46bfa9,_0x7ff93b,_0x4e3055)=>{mr(_0x5bb7f9,_0x40cba0,_0x46bfa9,_0x7ff93b,_0x4e3055);},_0x29b2ba=>{yr(_0x5bb7f9,_0x29b2ba);},_0x20d907=>{Id(_0x5bb7f9,_0x20d907);},_0x5bb7f9['authTokenProvider_'],_0x5bb7f9['appCheckProvider_'],_0x4d83cc),_0x5bb7f9['server_']=_0x5bb7f9['persistentConnection_'];}_0x5bb7f9['authTokenProvider_']['addTokenChangeListener'](_0x190af8=>{_0x5bb7f9['server_']['refreshAuthToken'](_0x190af8);}),_0x5bb7f9['appCheckProvider_']['addTokenChangeListener'](_0x37c9c2=>{_0x5bb7f9['server_']['refreshAppCheckToken'](_0x37c9c2['token']);}),_0x5bb7f9['statsReporter_']=ih(_0x5bb7f9['repoInfo_'],()=>new iu(_0x5bb7f9['stats_'],_0x5bb7f9['server_'])),_0x5bb7f9['infoData_']=new Xh(),_0x5bb7f9['infoSyncTree_']=new _r({'startListening':(_0x5cdfc0,_0x357fbd,_0x4828a0,_0x17a78b)=>{let _0x438fbd=[];const _0x30f728=_0x5bb7f9['infoData_']['getNode'](_0x5cdfc0['_path']);return _0x30f728['isEmpty']()||(_0x438fbd=Gt(_0x5bb7f9['infoSyncTree_'],_0x5cdfc0['_path'],_0x30f728),setTimeout(()=>{_0x17a78b('ok');},0x0)),_0x438fbd;},'stopListening':()=>{}}),vs(_0x5bb7f9,'connected',!0x1),_0x5bb7f9['serverSyncTree_']=new _r({'startListening':(_0x3c30b1,_0x2a441b,_0x108f05,_0x5d8c84)=>(_0x5bb7f9['server_']['listen'](_0x3c30b1,_0x108f05,_0x2a441b,(_0x5ae98c,_0x12a75a)=>{const _0x366f43=_0x5d8c84(_0x5ae98c,_0x12a75a);H(_0x5bb7f9['eventQueue_'],_0x3c30b1['_path'],_0x366f43);}),[]),'stopListening':(_0x37a971,_0xede9d8)=>{_0x5bb7f9['server_']['unlisten'](_0x37a971,_0xede9d8);}});}function la(_0x44cc14){const _0x32d060=_0x44cc14['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x32d060;}function Kt(_0x3886c3){return id({'timestamp':la(_0x3886c3)});}function mr(_0x558ccf,_0x46d48c,_0x14ebf6,_0x3a8ac9,_0x117283){_0x558ccf['dataUpdateCount']++;const _0x5c611f=new C(_0x46d48c);_0x14ebf6=_0x558ccf['interceptServerDataCallback_']?_0x558ccf['interceptServerDataCallback_'](_0x46d48c,_0x14ebf6):_0x14ebf6;let _0x406a83=[];if(_0x117283){if(_0x3a8ac9){const _0x35299a=hn(_0x14ebf6,_0x556ba4=>P(_0x556ba4));_0x406a83=Ju(_0x558ccf['serverSyncTree_'],_0x5c611f,_0x35299a,_0x117283);}else{const _0x17c7c9=P(_0x14ebf6);_0x406a83=Xo(_0x558ccf['serverSyncTree_'],_0x5c611f,_0x17c7c9,_0x117283);}}else{if(_0x3a8ac9){const _0x53f8c3=hn(_0x14ebf6,_0x42e931=>P(_0x42e931));_0x406a83=Ku(_0x558ccf['serverSyncTree_'],_0x5c611f,_0x53f8c3);}else{const _0x4e6c7f=P(_0x14ebf6);_0x406a83=Gt(_0x558ccf['serverSyncTree_'],_0x5c611f,_0x4e6c7f);}}let _0x36f7ea=_0x5c611f;_0x406a83['length']>0x0&&(_0x36f7ea=it(_0x558ccf,_0x5c611f)),H(_0x558ccf['eventQueue_'],_0x36f7ea,_0x406a83);}function yr(_0x202f19,_0x15265e){vs(_0x202f19,'connected',_0x15265e),_0x15265e===!0x1&&Sd(_0x202f19);}function Id(_0x10d7a4,_0x15c2d1){x(_0x15c2d1,(_0x5555f6,_0x59db48)=>{vs(_0x10d7a4,_0x5555f6,_0x59db48);});}function vs(_0xf6960f,_0x5cc90b,_0x4fa6a1){const _0x1c04ea=new C('/.info/'+_0x5cc90b),_0x5a640c=P(_0x4fa6a1);_0xf6960f['infoData_']['updateSnapshot'](_0x1c04ea,_0x5a640c);const _0x2e6e3a=Gt(_0xf6960f['infoSyncTree_'],_0x1c04ea,_0x5a640c);H(_0xf6960f['eventQueue_'],_0x1c04ea,_0x2e6e3a);}function Hn(_0x50dda1){return _0x50dda1['nextWriteId_']++;}function wd(_0x1e4b07,_0x476656,_0x39503c){const _0x6d02a6=Xu(_0x1e4b07['serverSyncTree_'],_0x476656);return _0x6d02a6!=null?Promise['resolve'](_0x6d02a6):_0x1e4b07['server_']['get'](_0x476656)['then'](_0x29cf4d=>{const _0x59760b=P(_0x29cf4d)['withIndex'](_0x476656['_queryParams']['getIndex']());Ri(_0x1e4b07['serverSyncTree_'],_0x476656,_0x39503c,!0x0);let _0x1052d7;if(_0x476656['_queryParams']['loadsAllData']())_0x1052d7=Gt(_0x1e4b07['serverSyncTree_'],_0x476656['_path'],_0x59760b);else{const _0x1e01da=xt(_0x1e4b07['serverSyncTree_'],_0x476656);_0x1052d7=Xo(_0x1e4b07['serverSyncTree_'],_0x476656['_path'],_0x59760b,_0x1e01da);}return H(_0x1e4b07['eventQueue_'],_0x476656['_path'],_0x1052d7),Cn(_0x1e4b07['serverSyncTree_'],_0x476656,_0x39503c,null,!0x0),_0x59760b;},_0x33b06d=>(dt(_0x1e4b07,'get\x20for\x20query\x20'+O(_0x476656)+'\x20failed:\x20'+_0x33b06d),Promise['reject'](new Error(_0x33b06d))));}function Cd(_0x3c2dfa,_0x15408c,_0x4917bd,_0x650fdb,_0x20d5fb){dt(_0x3c2dfa,'set',{'path':_0x15408c['toString'](),'value':_0x4917bd,'priority':_0x650fdb});const _0x5293a0=Kt(_0x3c2dfa),_0x479863=P(_0x4917bd,_0x650fdb),_0xdde973=Fn(_0x3c2dfa['serverSyncTree_'],_0x15408c),_0x1f6d42=ds(_0x479863,_0xdde973,_0x5293a0),_0x1b7557=Hn(_0x3c2dfa),_0x434202=os(_0x3c2dfa['serverSyncTree_'],_0x15408c,_0x1f6d42,_0x1b7557,!0x0);Vn(_0x3c2dfa['eventQueue_'],_0x434202),_0x3c2dfa['server_']['put'](_0x15408c['toString'](),_0x479863['val'](!0x0),(_0x57dc29,_0x4749cc)=>{const _0x348ed9=_0x57dc29==='ok';_0x348ed9||U('set\x20at\x20'+_0x15408c+'\x20failed:\x20'+_0x57dc29);const _0x5187e6=pe(_0x3c2dfa['serverSyncTree_'],_0x1b7557,!_0x348ed9);H(_0x3c2dfa['eventQueue_'],_0x15408c,_0x5187e6),ki(_0x3c2dfa,_0x20d5fb,_0x57dc29,_0x4749cc);});const _0x178267=Is(_0x3c2dfa,_0x15408c);it(_0x3c2dfa,_0x178267),H(_0x3c2dfa['eventQueue_'],_0x178267,[]);}function Td(_0x5f3c66,_0x296d17,_0x1effd4,_0x19d6b7){dt(_0x5f3c66,'update',{'path':_0x296d17['toString'](),'value':_0x1effd4});let _0x160bd4=!0x0;const _0x57e813=Kt(_0x5f3c66),_0x30e307={};if(x(_0x1effd4,(_0x310628,_0x2c0737)=>{_0x160bd4=!0x1,_0x30e307[_0x310628]=na(k(_0x296d17,_0x310628),P(_0x2c0737),_0x5f3c66['serverSyncTree_'],_0x57e813);}),_0x160bd4)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),ki(_0x5f3c66,_0x19d6b7,'ok',void 0x0);else{const _0x86481e=Hn(_0x5f3c66),_0x522765=ju(_0x5f3c66['serverSyncTree_'],_0x296d17,_0x30e307,_0x86481e);Vn(_0x5f3c66['eventQueue_'],_0x522765),_0x5f3c66['server_']['merge'](_0x296d17['toString'](),_0x1effd4,(_0x51a8bf,_0x2bd197)=>{const _0x6afaed=_0x51a8bf==='ok';_0x6afaed||U('update\x20at\x20'+_0x296d17+'\x20failed:\x20'+_0x51a8bf);const _0x509cf1=pe(_0x5f3c66['serverSyncTree_'],_0x86481e,!_0x6afaed),_0x5aed7d=_0x509cf1['length']>0x0?it(_0x5f3c66,_0x296d17):_0x296d17;H(_0x5f3c66['eventQueue_'],_0x5aed7d,_0x509cf1),ki(_0x5f3c66,_0x19d6b7,_0x51a8bf,_0x2bd197);}),x(_0x1effd4,_0x5c186d=>{const _0x5ae60c=Is(_0x5f3c66,k(_0x296d17,_0x5c186d));it(_0x5f3c66,_0x5ae60c);}),H(_0x5f3c66['eventQueue_'],_0x296d17,[]);}}function Sd(_0x164642){dt(_0x164642,'onDisconnectEvents');const _0x411f2a=Kt(_0x164642),_0x2f2d58=_n();Ii(_0x164642['onDisconnect_'],w(),(_0x30008c,_0x3e7f66)=>{const _0x11ad8d=na(_0x30008c,_0x3e7f66,_0x164642['serverSyncTree_'],_0x411f2a);Fo(_0x2f2d58,_0x30008c,_0x11ad8d);});let _0x1953f4=[];Ii(_0x2f2d58,w(),(_0x41a424,_0x7f372d)=>{_0x1953f4=_0x1953f4['concat'](Gt(_0x164642['serverSyncTree_'],_0x41a424,_0x7f372d));const _0x1252b9=Is(_0x164642,_0x41a424);it(_0x164642,_0x1252b9);}),_0x164642['onDisconnect_']=_n(),H(_0x164642['eventQueue_'],w(),_0x1953f4);}function bd(_0x211da8,_0x4cef6e,_0x3a87fc){let _0x22e0bd;y(_0x4cef6e['_path'])==='.info'?_0x22e0bd=Ri(_0x211da8['infoSyncTree_'],_0x4cef6e,_0x3a87fc):_0x22e0bd=Ri(_0x211da8['serverSyncTree_'],_0x4cef6e,_0x3a87fc),oa(_0x211da8['eventQueue_'],_0x4cef6e['_path'],_0x22e0bd);}function Rd(_0x25e9d9,_0x2c7e8b,_0x2097a4){let _0x4e9fa3;y(_0x2c7e8b['_path'])==='.info'?_0x4e9fa3=Cn(_0x25e9d9['infoSyncTree_'],_0x2c7e8b,_0x2097a4):_0x4e9fa3=Cn(_0x25e9d9['serverSyncTree_'],_0x2c7e8b,_0x2097a4),oa(_0x25e9d9['eventQueue_'],_0x2c7e8b['_path'],_0x4e9fa3);}function ha(_0x249b43){_0x249b43['persistentConnection_']&&_0x249b43['persistentConnection_']['interrupt'](ca);}function Ad(_0x43aa3a){_0x43aa3a['persistentConnection_']&&_0x43aa3a['persistentConnection_']['resume'](ca);}function dt(_0x4da371,..._0x4ccf31){let _0xe01915='';_0x4da371['persistentConnection_']&&(_0xe01915=_0x4da371['persistentConnection_']['id']+':'),L(_0xe01915,..._0x4ccf31);}function ki(_0x1dddc3,_0x501306,_0x59378a,_0x3b5d7e){_0x501306&&ht(()=>{if(_0x59378a==='ok')_0x501306(null);else{const _0x43873b=(_0x59378a||'error')['toUpperCase']();let _0x39550c=_0x43873b;_0x3b5d7e&&(_0x39550c+=':\x20'+_0x3b5d7e);const _0x5588d0=new Error(_0x39550c);_0x5588d0['code']=_0x43873b,_0x501306(_0x5588d0);}});}function kd(_0x5756bc,_0x5e1134,_0x378c4c,_0x4674cb,_0xe1232d,_0x11a681){dt(_0x5756bc,'transaction\x20on\x20'+_0x5e1134);const _0x4a5019={'path':_0x5e1134,'update':_0x378c4c,'onComplete':_0x4674cb,'status':null,'order':so(),'applyLocally':_0x11a681,'retryCount':0x0,'unwatcher':_0xe1232d,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x128573=Es(_0x5756bc,_0x5e1134,void 0x0);_0x4a5019['currentInputSnapshot']=_0x128573;const _0x1ac05c=_0x4a5019['update'](_0x128573['val']());if(_0x1ac05c===void 0x0)_0x4a5019['unwatcher'](),_0x4a5019['currentOutputSnapshotRaw']=null,_0x4a5019['currentOutputSnapshotResolved']=null,_0x4a5019['onComplete']&&_0x4a5019['onComplete'](null,!0x1,_0x4a5019['currentInputSnapshot']);else{jt('transaction\x20failed:\x20Data\x20returned\x20',_0x1ac05c,_0x4a5019['path']),_0x4a5019['status']=0x0;const _0x3d3619=Wn(_0x5756bc['transactionQueueTree_'],_0x5e1134),_0x3ec469=Ge(_0x3d3619)||[];_0x3ec469['push'](_0x4a5019),_s(_0x3d3619,_0x3ec469);let _0x5bf3e9;typeof _0x1ac05c=='object'&&_0x1ac05c!==null&&J(_0x1ac05c,'.priority')?(_0x5bf3e9=De(_0x1ac05c,'.priority'),f(Tn(_0x5bf3e9),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x5bf3e9=(Fn(_0x5756bc['serverSyncTree_'],_0x5e1134)||g['EMPTY_NODE'])['getPriority']()['val']();const _0xdb2386=Kt(_0x5756bc),_0x54f02b=P(_0x1ac05c,_0x5bf3e9),_0x296c16=ds(_0x54f02b,_0x128573,_0xdb2386);_0x4a5019['currentOutputSnapshotRaw']=_0x54f02b,_0x4a5019['currentOutputSnapshotResolved']=_0x296c16,_0x4a5019['currentWriteId']=Hn(_0x5756bc);const _0x372ae=os(_0x5756bc['serverSyncTree_'],_0x5e1134,_0x296c16,_0x4a5019['currentWriteId'],_0x4a5019['applyLocally']);H(_0x5756bc['eventQueue_'],_0x5e1134,_0x372ae),$n(_0x5756bc,_0x5756bc['transactionQueueTree_']);}}function Es(_0x3ef353,_0x12853e,_0x20ea85){return Fn(_0x3ef353['serverSyncTree_'],_0x12853e,_0x20ea85)||g['EMPTY_NODE'];}function $n(_0x556a6c,_0x288fc5=_0x556a6c['transactionQueueTree_']){if(_0x288fc5||Gn(_0x556a6c,_0x288fc5),Ge(_0x288fc5)){const _0x44e4ea=da(_0x556a6c,_0x288fc5);f(_0x44e4ea['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x44e4ea['every'](_0x4b80c2=>_0x4b80c2['status']===0x0)&&Nd(_0x556a6c,qt(_0x288fc5),_0x44e4ea);}else ia(_0x288fc5)&&Bn(_0x288fc5,_0x459658=>{$n(_0x556a6c,_0x459658);});}function Nd(_0x5c4459,_0x59761c,_0x4957ae){const _0x3cd281=_0x4957ae['map'](_0x34174d=>_0x34174d['currentWriteId']),_0x10b3fe=Es(_0x5c4459,_0x59761c,_0x3cd281);let _0x55c65b=_0x10b3fe;const _0x164466=_0x10b3fe['hash']();for(let _0x1ea5ef=0x0;_0x1ea5ef<_0x4957ae['length'];_0x1ea5ef++){const _0x47b64b=_0x4957ae[_0x1ea5ef];f(_0x47b64b['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x47b64b['status']=0x1,_0x47b64b['retryCount']++;const _0x280dc0=F(_0x59761c,_0x47b64b['path']);_0x55c65b=_0x55c65b['updateChild'](_0x280dc0,_0x47b64b['currentOutputSnapshotRaw']);}const _0x103c50=_0x55c65b['val'](!0x0),_0x1c9bc8=_0x59761c;_0x5c4459['server_']['put'](_0x1c9bc8['toString'](),_0x103c50,_0x145ec8=>{dt(_0x5c4459,'transaction\x20put\x20response',{'path':_0x1c9bc8['toString'](),'status':_0x145ec8});let _0x559306=[];if(_0x145ec8==='ok'){const _0x11604d=[];for(let _0x1ea65c=0x0;_0x1ea65c<_0x4957ae['length'];_0x1ea65c++)_0x4957ae[_0x1ea65c]['status']=0x2,_0x559306=_0x559306['concat'](pe(_0x5c4459['serverSyncTree_'],_0x4957ae[_0x1ea65c]['currentWriteId'])),_0x4957ae[_0x1ea65c]['onComplete']&&_0x11604d['push'](()=>_0x4957ae[_0x1ea65c]['onComplete'](null,!0x0,_0x4957ae[_0x1ea65c]['currentOutputSnapshotResolved'])),_0x4957ae[_0x1ea65c]['unwatcher']();Gn(_0x5c4459,Wn(_0x5c4459['transactionQueueTree_'],_0x59761c)),$n(_0x5c4459,_0x5c4459['transactionQueueTree_']),H(_0x5c4459['eventQueue_'],_0x59761c,_0x559306);for(let _0x217e7c=0x0;_0x217e7c<_0x11604d['length'];_0x217e7c++)ht(_0x11604d[_0x217e7c]);}else{if(_0x145ec8==='datastale'){for(let _0x2e6054=0x0;_0x2e6054<_0x4957ae['length'];_0x2e6054++)_0x4957ae[_0x2e6054]['status']===0x3?_0x4957ae[_0x2e6054]['status']=0x4:_0x4957ae[_0x2e6054]['status']=0x0;}else{U('transaction\x20at\x20'+_0x1c9bc8['toString']()+'\x20failed:\x20'+_0x145ec8);for(let _0x363db7=0x0;_0x363db7<_0x4957ae['length'];_0x363db7++)_0x4957ae[_0x363db7]['status']=0x4,_0x4957ae[_0x363db7]['abortReason']=_0x145ec8;}it(_0x5c4459,_0x59761c);}},_0x164466);}function it(_0x3972fb,_0x27e472){const _0x4155c4=ua(_0x3972fb,_0x27e472),_0x198a8e=qt(_0x4155c4),_0x305d03=da(_0x3972fb,_0x4155c4);return Pd(_0x3972fb,_0x305d03,_0x198a8e),_0x198a8e;}function Pd(_0x126d8d,_0x12cf30,_0x301c26){if(_0x12cf30['length']===0x0)return;const _0x35580d=[];let _0xab364a=[];const _0x16fb76=_0x12cf30['filter'](_0x2705b6=>_0x2705b6['status']===0x0)['map'](_0x343385=>_0x343385['currentWriteId']);for(let _0x49a60f=0x0;_0x49a60f<_0x12cf30['length'];_0x49a60f++){const _0x3b14ce=_0x12cf30[_0x49a60f],_0x495ae2=F(_0x301c26,_0x3b14ce['path']);let _0x11429e=!0x1,_0x119835;if(f(_0x495ae2!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x3b14ce['status']===0x4)_0x11429e=!0x0,_0x119835=_0x3b14ce['abortReason'],_0xab364a=_0xab364a['concat'](pe(_0x126d8d['serverSyncTree_'],_0x3b14ce['currentWriteId'],!0x0));else{if(_0x3b14ce['status']===0x0){if(_0x3b14ce['retryCount']>=yd)_0x11429e=!0x0,_0x119835='maxretry',_0xab364a=_0xab364a['concat'](pe(_0x126d8d['serverSyncTree_'],_0x3b14ce['currentWriteId'],!0x0));else{const _0x3e8c24=Es(_0x126d8d,_0x3b14ce['path'],_0x16fb76);_0x3b14ce['currentInputSnapshot']=_0x3e8c24;const _0x3378d0=_0x12cf30[_0x49a60f]['update'](_0x3e8c24['val']());if(_0x3378d0!==void 0x0){jt('transaction\x20failed:\x20Data\x20returned\x20',_0x3378d0,_0x3b14ce['path']);let _0x2ee1f2=P(_0x3378d0);typeof _0x3378d0=='object'&&_0x3378d0!=null&&J(_0x3378d0,'.priority')||(_0x2ee1f2=_0x2ee1f2['updatePriority'](_0x3e8c24['getPriority']()));const _0x3a20f4=_0x3b14ce['currentWriteId'],_0x5f296b=Kt(_0x126d8d),_0x1f6509=ds(_0x2ee1f2,_0x3e8c24,_0x5f296b);_0x3b14ce['currentOutputSnapshotRaw']=_0x2ee1f2,_0x3b14ce['currentOutputSnapshotResolved']=_0x1f6509,_0x3b14ce['currentWriteId']=Hn(_0x126d8d),_0x16fb76['splice'](_0x16fb76['indexOf'](_0x3a20f4),0x1),_0xab364a=_0xab364a['concat'](os(_0x126d8d['serverSyncTree_'],_0x3b14ce['path'],_0x1f6509,_0x3b14ce['currentWriteId'],_0x3b14ce['applyLocally'])),_0xab364a=_0xab364a['concat'](pe(_0x126d8d['serverSyncTree_'],_0x3a20f4,!0x0));}else _0x11429e=!0x0,_0x119835='nodata',_0xab364a=_0xab364a['concat'](pe(_0x126d8d['serverSyncTree_'],_0x3b14ce['currentWriteId'],!0x0));}}}H(_0x126d8d['eventQueue_'],_0x301c26,_0xab364a),_0xab364a=[],_0x11429e&&(_0x12cf30[_0x49a60f]['status']=0x2,function(_0x312c67){setTimeout(_0x312c67,Math['floor'](0x0));}(_0x12cf30[_0x49a60f]['unwatcher']),_0x12cf30[_0x49a60f]['onComplete']&&(_0x119835==='nodata'?_0x35580d['push'](()=>_0x12cf30[_0x49a60f]['onComplete'](null,!0x1,_0x12cf30[_0x49a60f]['currentInputSnapshot'])):_0x35580d['push'](()=>_0x12cf30[_0x49a60f]['onComplete'](new Error(_0x119835),!0x1,null))));}Gn(_0x126d8d,_0x126d8d['transactionQueueTree_']);for(let _0x12b345=0x0;_0x12b345<_0x35580d['length'];_0x12b345++)ht(_0x35580d[_0x12b345]);$n(_0x126d8d,_0x126d8d['transactionQueueTree_']);}function ua(_0x59777d,_0x2ae95f){let _0xf0082b,_0x14c362=_0x59777d['transactionQueueTree_'];for(_0xf0082b=y(_0x2ae95f);_0xf0082b!==null&&Ge(_0x14c362)===void 0x0;)_0x14c362=Wn(_0x14c362,_0xf0082b),_0x2ae95f=b(_0x2ae95f),_0xf0082b=y(_0x2ae95f);return _0x14c362;}function da(_0x3a46bb,_0x1060d1){const _0x7541c1=[];return fa(_0x3a46bb,_0x1060d1,_0x7541c1),_0x7541c1['sort']((_0x37ad93,_0x52d006)=>_0x37ad93['order']-_0x52d006['order']),_0x7541c1;}function fa(_0x448657,_0x46b8fa,_0x1d2e59){const _0x359ed3=Ge(_0x46b8fa);if(_0x359ed3){for(let _0x12b1f9=0x0;_0x12b1f9<_0x359ed3['length'];_0x12b1f9++)_0x1d2e59['push'](_0x359ed3[_0x12b1f9]);}Bn(_0x46b8fa,_0x81f263=>{fa(_0x448657,_0x81f263,_0x1d2e59);});}function Gn(_0x21361d,_0x575958){const _0x36267d=Ge(_0x575958);if(_0x36267d){let _0x254a53=0x0;for(let _0x3e542d=0x0;_0x3e542d<_0x36267d['length'];_0x3e542d++)_0x36267d[_0x3e542d]['status']!==0x2&&(_0x36267d[_0x254a53]=_0x36267d[_0x3e542d],_0x254a53++);_0x36267d['length']=_0x254a53,_s(_0x575958,_0x36267d['length']>0x0?_0x36267d:void 0x0);}Bn(_0x575958,_0x6ae861=>{Gn(_0x21361d,_0x6ae861);});}function Is(_0xb53773,_0x5c5e5b){const _0x356cf6=qt(ua(_0xb53773,_0x5c5e5b)),_0x58280a=Wn(_0xb53773['transactionQueueTree_'],_0x5c5e5b);return ad(_0x58280a,_0x26ddd0=>{ci(_0xb53773,_0x26ddd0);}),ci(_0xb53773,_0x58280a),sa(_0x58280a,_0x8eb918=>{ci(_0xb53773,_0x8eb918);}),_0x356cf6;}function ci(_0x56044a,_0x381149){const _0x34dfac=Ge(_0x381149);if(_0x34dfac){const _0x50e707=[];let _0x25741a=[],_0x1a69ca=-0x1;for(let _0x498ba5=0x0;_0x498ba5<_0x34dfac['length'];_0x498ba5++)_0x34dfac[_0x498ba5]['status']===0x3||(_0x34dfac[_0x498ba5]['status']===0x1?(f(_0x1a69ca===_0x498ba5-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x1a69ca=_0x498ba5,_0x34dfac[_0x498ba5]['status']=0x3,_0x34dfac[_0x498ba5]['abortReason']='set'):(f(_0x34dfac[_0x498ba5]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x34dfac[_0x498ba5]['unwatcher'](),_0x25741a=_0x25741a['concat'](pe(_0x56044a['serverSyncTree_'],_0x34dfac[_0x498ba5]['currentWriteId'],!0x0)),_0x34dfac[_0x498ba5]['onComplete']&&_0x50e707['push'](_0x34dfac[_0x498ba5]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x1a69ca===-0x1?_s(_0x381149,void 0x0):_0x34dfac['length']=_0x1a69ca+0x1,H(_0x56044a['eventQueue_'],qt(_0x381149),_0x25741a);for(let _0x450e3f=0x0;_0x450e3f<_0x50e707['length'];_0x450e3f++)ht(_0x50e707[_0x450e3f]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Od(_0x45d1bb){let _0x28d35a='';const _0x5ea9a2=_0x45d1bb['split']('/');for(let _0x358aea=0x0;_0x358aea<_0x5ea9a2['length'];_0x358aea++)if(_0x5ea9a2[_0x358aea]['length']>0x0){let _0x76aa86=_0x5ea9a2[_0x358aea];try{_0x76aa86=decodeURIComponent(_0x76aa86['replace'](/\+/g,'\x20'));}catch{}_0x28d35a+='/'+_0x76aa86;}return _0x28d35a;}function Dd(_0x5c9502){const _0x90fe35={};_0x5c9502['charAt'](0x0)==='?'&&(_0x5c9502=_0x5c9502['substring'](0x1));for(const _0x27ec73 of _0x5c9502['split']('&')){if(_0x27ec73['length']===0x0)continue;const _0x481793=_0x27ec73['split']('=');_0x481793['length']===0x2?_0x90fe35[decodeURIComponent(_0x481793[0x0])]=decodeURIComponent(_0x481793[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x27ec73+'\x27\x20in\x20query\x20\x27'+_0x5c9502+'\x27');}return _0x90fe35;}const vr=function(_0x5dabec,_0x2f160e){const _0x1be890=Md(_0x5dabec),_0x250838=_0x1be890['namespace'];_0x1be890['domain']==='firebase.com'&&ae(_0x1be890['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x250838||_0x250838==='undefined')&&_0x1be890['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x1be890['secure']||$l();const _0x29d2c1=_0x1be890['scheme']==='ws'||_0x1be890['scheme']==='wss';return{'repoInfo':new yo(_0x1be890['host'],_0x1be890['secure'],_0x250838,_0x29d2c1,_0x2f160e,'',_0x250838!==_0x1be890['subdomain']),'path':new C(_0x1be890['pathString'])};},Md=function(_0x30eda6){let _0x470377='',_0x3c1dea='',_0x8c87c3='',_0x4708cb='',_0x19b1f6='',_0x3ee719=!0x0,_0x596384='https',_0x1576fb=0x1bb;if(typeof _0x30eda6=='string'){let _0x525d53=_0x30eda6['indexOf']('//');_0x525d53>=0x0&&(_0x596384=_0x30eda6['substring'](0x0,_0x525d53-0x1),_0x30eda6=_0x30eda6['substring'](_0x525d53+0x2));let _0x267145=_0x30eda6['indexOf']('/');_0x267145===-0x1&&(_0x267145=_0x30eda6['length']);let _0x167b2e=_0x30eda6['indexOf']('?');_0x167b2e===-0x1&&(_0x167b2e=_0x30eda6['length']),_0x470377=_0x30eda6['substring'](0x0,Math['min'](_0x267145,_0x167b2e)),_0x267145<_0x167b2e&&(_0x4708cb=Od(_0x30eda6['substring'](_0x267145,_0x167b2e)));const _0x4ba641=Dd(_0x30eda6['substring'](Math['min'](_0x30eda6['length'],_0x167b2e)));_0x525d53=_0x470377['indexOf'](':'),_0x525d53>=0x0?(_0x3ee719=_0x596384==='https'||_0x596384==='wss',_0x1576fb=parseInt(_0x470377['substring'](_0x525d53+0x1),0xa)):_0x525d53=_0x470377['length'];const _0xcefbf1=_0x470377['slice'](0x0,_0x525d53);if(_0xcefbf1['toLowerCase']()==='localhost')_0x3c1dea='localhost';else{if(_0xcefbf1['split']('.')['length']<=0x2)_0x3c1dea=_0xcefbf1;else{const _0x37eda1=_0x470377['indexOf']('.');_0x8c87c3=_0x470377['substring'](0x0,_0x37eda1)['toLowerCase'](),_0x3c1dea=_0x470377['substring'](_0x37eda1+0x1),_0x19b1f6=_0x8c87c3;}}'ns'in _0x4ba641&&(_0x19b1f6=_0x4ba641['ns']);}return{'host':_0x470377,'port':_0x1576fb,'domain':_0x3c1dea,'subdomain':_0x8c87c3,'secure':_0x3ee719,'scheme':_0x596384,'pathString':_0x4708cb,'namespace':_0x19b1f6};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ld=(function(){let _0x2e73f8=0x0;const _0x1cde48=[];return function(_0x417720){const _0x1ea9f8=_0x417720===_0x2e73f8;_0x2e73f8=_0x417720;let _0xd56e6c;const _0x4dec48=new Array(0x8);for(_0xd56e6c=0x7;_0xd56e6c>=0x0;_0xd56e6c--)_0x4dec48[_0xd56e6c]=Er['charAt'](_0x417720%0x40),_0x417720=Math['floor'](_0x417720/0x40);f(_0x417720===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x1b7c19=_0x4dec48['join']('');if(_0x1ea9f8){for(_0xd56e6c=0xb;_0xd56e6c>=0x0&&_0x1cde48[_0xd56e6c]===0x3f;_0xd56e6c--)_0x1cde48[_0xd56e6c]=0x0;_0x1cde48[_0xd56e6c]++;}else{for(_0xd56e6c=0x0;_0xd56e6c<0xc;_0xd56e6c++)_0x1cde48[_0xd56e6c]=Math['floor'](Math['random']()*0x40);}for(_0xd56e6c=0x0;_0xd56e6c<0xc;_0xd56e6c++)_0x1b7c19+=Er['charAt'](_0x1cde48[_0xd56e6c]);return f(_0x1b7c19['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x1b7c19;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xd{constructor(_0x2d0c44,_0x18e21c,_0x39ced7,_0x319271){this['eventType']=_0x2d0c44,this['eventRegistration']=_0x18e21c,this['snapshot']=_0x39ced7,this['prevName']=_0x319271;}['getPath'](){const _0x41f015=this['snapshot']['ref'];return this['eventType']==='value'?_0x41f015['_path']:_0x41f015['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Fd{constructor(_0x59563e,_0x4d9e1e,_0x24e919){this['eventRegistration']=_0x59563e,this['error']=_0x4d9e1e,this['path']=_0x24e919;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x51ba36,_0x2620b5){this['snapshotCallback']=_0x51ba36,this['cancelCallback']=_0x2620b5;}['onValue'](_0x43001d,_0x4672dd){this['snapshotCallback']['call'](null,_0x43001d,_0x4672dd);}['onCancel'](_0x221b74){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x221b74);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x3cd6b1){return this['snapshotCallback']===_0x3cd6b1['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x3cd6b1['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x3cd6b1['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0xf5278d,_0x5c25e4,_0x5c09d6,_0x4cd339){this['_repo']=_0xf5278d,this['_path']=_0x5c25e4,this['_queryParams']=_0x5c09d6,this['_orderByCalled']=_0x4cd339;}get['key'](){return v(this['_path'])?null:zi(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x5b6acc=rr(this['_queryParams']),_0x4d5827=Hi(_0x5b6acc);return _0x4d5827==='{}'?'default':_0x4d5827;}get['_queryObject'](){return rr(this['_queryParams']);}['isEqual'](_0x26efcb){if(_0x26efcb=N(_0x26efcb),!(_0x26efcb instanceof be))return!0x1;const _0x35fe12=this['_repo']===_0x26efcb['_repo'],_0xf7f462=ji(this['_path'],_0x26efcb['_path']),_0x240a51=this['_queryIdentifier']===_0x26efcb['_queryIdentifier'];return _0x35fe12&&_0xf7f462&&_0x240a51;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x5c6429,_0x28b173){if(_0x5c6429['_orderByCalled']===!0x0)throw new Error(_0x28b173+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function qn(_0x3448c6){let _0x3cf97a=null,_0x462e63=null;if(_0x3448c6['hasStart']()&&(_0x3cf97a=_0x3448c6['getIndexStartValue']()),_0x3448c6['hasEnd']()&&(_0x462e63=_0x3448c6['getIndexEndValue']()),_0x3448c6['getIndex']()===ye){const _0x52c696='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x2b1407='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x3448c6['hasStart']()){if(_0x3448c6['getIndexStartName']()!==Fe)throw new Error(_0x52c696);if(typeof _0x3cf97a!='string')throw new Error(_0x2b1407);}if(_0x3448c6['hasEnd']()){if(_0x3448c6['getIndexEndName']()!==Ie)throw new Error(_0x52c696);if(typeof _0x462e63!='string')throw new Error(_0x2b1407);}}else{if(_0x3448c6['getIndex']()===R){if(_0x3cf97a!=null&&!Tn(_0x3cf97a)||_0x462e63!=null&&!Tn(_0x462e63))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x3448c6['getIndex']()instanceof Qi||_0x3448c6['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x3cf97a!=null&&typeof _0x3cf97a=='object'||_0x462e63!=null&&typeof _0x462e63=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x412f8d){if(_0x412f8d['hasStart']()&&_0x412f8d['hasEnd']()&&_0x412f8d['hasLimit']()&&!_0x412f8d['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends be{constructor(_0x2d79c3,_0x466c5b){super(_0x2d79c3,_0x466c5b,new Xi(),!0x1);}get['parent'](){const _0x3d2e84=Ro(this['_path']);return _0x3d2e84===null?null:new ee(this['_repo'],_0x3d2e84);}get['root'](){let _0x435dd3=this;for(;_0x435dd3['parent']!==null;)_0x435dd3=_0x435dd3['parent'];return _0x435dd3;}}class st{constructor(_0x10dd0b,_0x4e3732,_0x109a77){this['_node']=_0x10dd0b,this['ref']=_0x4e3732,this['_index']=_0x109a77;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x23ff39){const _0x546b76=new C(_0x23ff39),_0x467595=Ft(this['ref'],_0x23ff39);return new st(this['_node']['getChild'](_0x546b76),_0x467595,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x24cc37){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x4fb90c,_0x440f32)=>_0x24cc37(new st(_0x440f32,Ft(this['ref'],_0x4fb90c),R)));}['hasChild'](_0x393b8c){const _0x519868=new C(_0x393b8c);return!this['_node']['getChild'](_0x519868)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function __(_0xe2412d,_0x1b9aca){return _0xe2412d=N(_0xe2412d),_0xe2412d['_checkNotDeleted']('ref'),_0x1b9aca!==void 0x0?Ft(_0xe2412d['_root'],_0x1b9aca):_0xe2412d['_root'];}function Ft(_0x2f37f3,_0x1f3049){return _0x2f37f3=N(_0x2f37f3),y(_0x2f37f3['_path'])===null?pd('child','path',_0x1f3049):ms('child','path',_0x1f3049),new ee(_0x2f37f3['_repo'],k(_0x2f37f3['_path'],_0x1f3049));}function g_(_0x5cd50f,_0xb17c61){_0x5cd50f=N(_0x5cd50f),ys('push',_0x5cd50f['_path']),zt('push',_0xb17c61,_0x5cd50f['_path'],!0x0);const _0x4a3e02=la(_0x5cd50f['_repo']),_0x4f52e4=Ld(_0x4a3e02),_0x334988=Ft(_0x5cd50f,_0x4f52e4),_0x4e0d1e=Ft(_0x5cd50f,_0x4f52e4);let _0x43a3e0;return _0xb17c61!=null?_0x43a3e0=Ud(_0x4e0d1e,_0xb17c61)['then'](()=>_0x4e0d1e):_0x43a3e0=Promise['resolve'](_0x4e0d1e),_0x334988['then']=_0x43a3e0['then']['bind'](_0x43a3e0),_0x334988['catch']=_0x43a3e0['then']['bind'](_0x43a3e0,void 0x0),_0x334988;}function Ud(_0xe383da,_0xa6aa35){_0xe383da=N(_0xe383da),ys('set',_0xe383da['_path']),zt('set',_0xa6aa35,_0xe383da['_path'],!0x1);const _0x4ed2e1=new ot();return Cd(_0xe383da['_repo'],_0xe383da['_path'],_0xa6aa35,null,_0x4ed2e1['wrapCallback'](()=>{})),_0x4ed2e1['promise'];}function m_(_0x4505,_0x46391a){fd('update',_0x46391a,_0x4505['_path']);const _0x5e159d=new ot();return Td(_0x4505['_repo'],_0x4505['_path'],_0x46391a,_0x5e159d['wrapCallback'](()=>{})),_0x5e159d['promise'];}function y_(_0x4c83bd){_0x4c83bd=N(_0x4c83bd);const _0x529155=new pa(()=>{}),_0x584522=new zn(_0x529155);return wd(_0x4c83bd['_repo'],_0x4c83bd,_0x584522)['then'](_0x486a24=>new st(_0x486a24,new ee(_0x4c83bd['_repo'],_0x4c83bd['_path']),_0x4c83bd['_queryParams']['getIndex']()));}class zn{constructor(_0x119efd){this['callbackContext']=_0x119efd;}['respondsTo'](_0x208a8f){return _0x208a8f==='value';}['createEvent'](_0xab899f,_0x19d7f8){const _0x2b4872=_0x19d7f8['_queryParams']['getIndex']();return new xd('value',this,new st(_0xab899f['snapshotNode'],new ee(_0x19d7f8['_repo'],_0x19d7f8['_path']),_0x2b4872));}['getEventRunner'](_0x4f0748){return _0x4f0748['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x4f0748['error']):()=>this['callbackContext']['onValue'](_0x4f0748['snapshot'],null);}['createCancelEvent'](_0x20e36f,_0x3604b0){return this['callbackContext']['hasCancelCallback']?new Fd(this,_0x20e36f,_0x3604b0):null;}['matches'](_0x303d9a){return _0x303d9a instanceof zn?!_0x303d9a['callbackContext']||!this['callbackContext']?!0x0:_0x303d9a['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function Wd(_0x4fceba,_0x2fa823,_0x22238a,_0x2294d9,_0x5f18db){const _0x26eb76=new pa(_0x22238a,void 0x0),_0x54b0b0=new zn(_0x26eb76);return bd(_0x4fceba['_repo'],_0x4fceba,_0x54b0b0),()=>Rd(_0x4fceba['_repo'],_0x4fceba,_0x54b0b0);}function Bd(_0x2c4096,_0x23e58b,_0x4c5979,_0x3eceae){return Wd(_0x2c4096,'value',_0x23e58b);}class ft{}class ma extends ft{constructor(_0x51f5db,_0x278cb3){super(),this['_value']=_0x51f5db,this['_key']=_0x278cb3,this['type']='endAt';}['_apply'](_0x389148){zt('endAt',this['_value'],_0x389148['_path'],!0x0);const _0x3986fb=Jh(_0x389148['_queryParams'],this['_value'],this['_key']);if(ga(_0x3986fb),qn(_0x3986fb),_0x389148['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x389148['_repo'],_0x389148['_path'],_0x3986fb,_0x389148['_orderByCalled']);}}function v_(_0x33c6b2,_0x426685){return new ma(_0x33c6b2,_0x426685);}class ya extends ft{constructor(_0x2d89e3,_0x92fa42){super(),this['_value']=_0x2d89e3,this['_key']=_0x92fa42,this['type']='startAt';}['_apply'](_0x37d042){zt('startAt',this['_value'],_0x37d042['_path'],!0x0);const _0x4aa6bb=Qh(_0x37d042['_queryParams'],this['_value'],this['_key']);if(ga(_0x4aa6bb),qn(_0x4aa6bb),_0x37d042['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x37d042['_repo'],_0x37d042['_path'],_0x4aa6bb,_0x37d042['_orderByCalled']);}}function E_(_0x51b41a=null,_0x495d02){return new ya(_0x51b41a,_0x495d02);}class Vd extends ft{constructor(_0x2dbb08){super(),this['_limit']=_0x2dbb08,this['type']='limitToFirst';}['_apply'](_0x2eac06){if(_0x2eac06['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x2eac06['_repo'],_0x2eac06['_path'],Yh(_0x2eac06['_queryParams'],this['_limit']),_0x2eac06['_orderByCalled']);}}function I_(_0x3d0b1f){if(Math['floor'](_0x3d0b1f)!==_0x3d0b1f||_0x3d0b1f<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Vd(_0x3d0b1f);}class Hd extends ft{constructor(_0x3b7717){super(),this['_path']=_0x3b7717,this['type']='orderByChild';}['_apply'](_0x171383){_a(_0x171383,'orderByChild');const _0x4bd0da=new C(this['_path']);if(v(_0x4bd0da))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0xfce0f1=new Qi(_0x4bd0da),_0x17f836=xo(_0x171383['_queryParams'],_0xfce0f1);return qn(_0x17f836),new be(_0x171383['_repo'],_0x171383['_path'],_0x17f836,!0x0);}}function w_(_0x2789df){if(_0x2789df==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x2789df==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x2789df==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ms('orderByChild','path',_0x2789df),new Hd(_0x2789df);}class $d extends ft{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x4ed5c0){_a(_0x4ed5c0,'orderByKey');const _0x5e64ff=xo(_0x4ed5c0['_queryParams'],ye);return qn(_0x5e64ff),new be(_0x4ed5c0['_repo'],_0x4ed5c0['_path'],_0x5e64ff,!0x0);}}function C_(){return new $d();}class Gd extends ft{constructor(_0x2fe9fb,_0x2ac6db){super(),this['_value']=_0x2fe9fb,this['_key']=_0x2ac6db,this['type']='equalTo';}['_apply'](_0x3e16da){if(zt('equalTo',this['_value'],_0x3e16da['_path'],!0x1),_0x3e16da['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x3e16da['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x3e16da));}}function T_(_0x4222b4,_0x10b636){return new Gd(_0x4222b4,_0x10b636);}function S_(_0x5a5b96,..._0xdba087){let _0x156328=N(_0x5a5b96);for(const _0x3bbf18 of _0xdba087)_0x156328=_0x3bbf18['_apply'](_0x156328);return _0x156328;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qd='FIREBASE_DATABASE_EMULATOR_HOST',Ni={};let zd=!0x1;function jd(_0x2694c5,_0x1a165a,_0x491561,_0x37b772){const _0x3c7715=_0x1a165a['lastIndexOf'](':'),_0x37ce43=_0x1a165a['substring'](0x0,_0x3c7715),_0x398793=at(_0x37ce43);_0x2694c5['repoInfo_']=new yo(_0x1a165a,_0x398793,_0x2694c5['repoInfo_']['namespace'],_0x2694c5['repoInfo_']['webSocketOnly'],_0x2694c5['repoInfo_']['nodeAdmin'],_0x2694c5['repoInfo_']['persistenceKey'],_0x2694c5['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x491561),_0x37b772&&(_0x2694c5['authTokenProvider_']=_0x37b772);}function Kd(_0x16bbd8,_0x2b929d,_0x2f8b55,_0x4e0754,_0xaa3ee7){let _0x4fb110=_0x4e0754||_0x16bbd8['options']['databaseURL'];_0x4fb110===void 0x0&&(_0x16bbd8['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x16bbd8['options']['projectId']),_0x4fb110=_0x16bbd8['options']['projectId']+'-default-rtdb.firebaseio.com');let _0xf7aa91=vr(_0x4fb110,_0xaa3ee7),_0x20c3b5=_0xf7aa91['repoInfo'],_0x8803cb;typeof process<'u'&&Vs&&(_0x8803cb=Vs[qd]),_0x8803cb?(_0x4fb110='http://'+_0x8803cb+'?ns='+_0x20c3b5['namespace'],_0xf7aa91=vr(_0x4fb110,_0xaa3ee7),_0x20c3b5=_0xf7aa91['repoInfo']):_0xf7aa91['repoInfo']['secure'];const _0x3355e9=new eh(_0x16bbd8['name'],_0x16bbd8['options'],_0x2b929d);_d('Invalid\x20Firebase\x20Database\x20URL',_0xf7aa91),v(_0xf7aa91['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0xf989d2=Qd(_0x20c3b5,_0x16bbd8,_0x3355e9,new Zl(_0x16bbd8,_0x2f8b55));return new Jd(_0xf989d2,_0x16bbd8);}function Yd(_0x4bbf5f,_0x493aeb){const _0x987e83=Ni[_0x493aeb];(!_0x987e83||_0x987e83[_0x4bbf5f['key']]!==_0x4bbf5f)&&ae('Database\x20'+_0x493aeb+'('+_0x4bbf5f['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x4bbf5f),delete _0x987e83[_0x4bbf5f['key']];}function Qd(_0x4c2395,_0x185aeb,_0x4eaf41,_0xfa1a2d){let _0x4d0c51=Ni[_0x185aeb['name']];_0x4d0c51||(_0x4d0c51={},Ni[_0x185aeb['name']]=_0x4d0c51);let _0x3cafe4=_0x4d0c51[_0x4c2395['toURLString']()];return _0x3cafe4&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x3cafe4=new vd(_0x4c2395,zd,_0x4eaf41,_0xfa1a2d),_0x4d0c51[_0x4c2395['toURLString']()]=_0x3cafe4,_0x3cafe4;}class Jd{constructor(_0x337662,_0x42e60e){this['_repoInternal']=_0x337662,this['app']=_0x42e60e,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Yd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x4a8491){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x4a8491+'\x20on\x20a\x20deleted\x20database.');}}function b_(_0x468433=Zr(),_0x5bead6){const _0x268963=Bi(_0x468433,'database')['getImmediate']({'identifier':_0x5bead6});if(!_0x268963['_instanceStarted']){const _0x1f1b6f=cc('database');_0x1f1b6f&&Xd(_0x268963,..._0x1f1b6f);}return _0x268963;}function Xd(_0x21a1ca,_0x595fce,_0x45e7c6,_0x2cc502={}){_0x21a1ca=N(_0x21a1ca),_0x21a1ca['_checkNotDeleted']('useEmulator');const _0x3242d9=_0x595fce+':'+_0x45e7c6,_0x26c8cd=_0x21a1ca['_repoInternal'];if(_0x21a1ca['_instanceStarted']){if(_0x3242d9===_0x21a1ca['_repoInternal']['repoInfo_']['host']&&Me(_0x2cc502,_0x26c8cd['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x3a8f80;if(_0x26c8cd['repoInfo_']['nodeAdmin'])_0x2cc502['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x3a8f80=new nn(nn['OWNER']);else{if(_0x2cc502['mockUserToken']){const _0x22da83=typeof _0x2cc502['mockUserToken']=='string'?_0x2cc502['mockUserToken']:lc(_0x2cc502['mockUserToken'],_0x21a1ca['app']['options']['projectId']);_0x3a8f80=new nn(_0x22da83);}}at(_0x595fce)&&(jr(_0x595fce),Kr('Database',!0x0)),jd(_0x26c8cd,_0x3242d9,_0x2cc502,_0x3a8f80);}function R_(_0x3dbc19){_0x3dbc19=N(_0x3dbc19),_0x3dbc19['_checkNotDeleted']('goOffline'),ha(_0x3dbc19['_repo']);}function A_(_0x50ee80){_0x50ee80=N(_0x50ee80),_0x50ee80['_checkNotDeleted']('goOnline'),Ad(_0x50ee80['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Zd(_0x50b3ec){Ul(lt),Ze(new Le('database',(_0x194787,{instanceIdentifier:_0x4a99b7})=>{const _0x413253=_0x194787['getProvider']('app')['getImmediate'](),_0x2daf29=_0x194787['getProvider']('auth-internal'),_0x1b298b=_0x194787['getProvider']('app-check-internal');return Kd(_0x413253,_0x2daf29,_0x1b298b,_0x4a99b7);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Hs,$s,_0x50b3ec),me(Hs,$s,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ef={'.sv':'timestamp'};function k_(){return ef;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tf{constructor(_0x51866c,_0x36702d){this['committed']=_0x51866c,this['snapshot']=_0x36702d;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function N_(_0x159654,_0xb2fee6,_0x3de522){if(_0x159654=N(_0x159654),ys('Reference.transaction',_0x159654['_path']),_0x159654['key']==='.length'||_0x159654['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x159654['key']+'\x20is\x20a\x20read-only\x20object.';const _0x267e21=!0x0,_0x502afb=new ot(),_0x23b2ab=(_0x6879e1,_0x3bd9c8,_0x5f4f41)=>{let _0x2261f1=null;_0x6879e1?_0x502afb['reject'](_0x6879e1):(_0x2261f1=new st(_0x5f4f41,new ee(_0x159654['_repo'],_0x159654['_path']),R),_0x502afb['resolve'](new tf(_0x3bd9c8,_0x2261f1)));},_0x56242a=Bd(_0x159654,()=>{});return kd(_0x159654['_repo'],_0x159654['_path'],_0xb2fee6,_0x23b2ab,_0x56242a,_0x267e21),_0x502afb['promise'];}se['prototype']['simpleListen']=function(_0x5d1f86,_0x2cc996){this['sendRequest']('q',{'p':_0x5d1f86},_0x2cc996);},se['prototype']['echo']=function(_0x3c1984,_0x39700e){this['sendRequest']('echo',{'d':_0x3c1984},_0x39700e);},Zd();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const nf=va,Ea=new Bt('auth','Firebase',va()),Sn=new Ui('@firebase/auth');function sf(_0x53fbec,..._0x123df6){Sn['logLevel']<=T['WARN']&&Sn['warn']('Auth\x20('+lt+'):\x20'+_0x53fbec,..._0x123df6);}function sn(_0x1938ce,..._0x2570d3){Sn['logLevel']<=T['ERROR']&&Sn['error']('Auth\x20('+lt+'):\x20'+_0x1938ce,..._0x2570d3);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x456b1d,..._0x1a7e91){throw ws(_0x456b1d,..._0x1a7e91);}function X(_0x524fb8,..._0x18af75){return ws(_0x524fb8,..._0x18af75);}function Ia(_0x1faedf,_0x3d155a,_0x3562be){const _0x5c28cd={...nf(),[_0x3d155a]:_0x3562be};return new Bt('auth','Firebase',_0x5c28cd)['create'](_0x3d155a,{'appName':_0x1faedf['name']});}function re(_0x1492f4){return Ia(_0x1492f4,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0xc918c7,..._0x11e41c){if(typeof _0xc918c7!='string'){const _0x2c58bb=_0x11e41c[0x0],_0x5245d4=[..._0x11e41c['slice'](0x1)];return _0x5245d4[0x0]&&(_0x5245d4[0x0]['appName']=_0xc918c7['name']),_0xc918c7['_errorFactory']['create'](_0x2c58bb,..._0x5245d4);}return Ea['create'](_0xc918c7,..._0x11e41c);}function m(_0x5035af,_0x35493f,..._0x398018){if(!_0x5035af)throw ws(_0x35493f,..._0x398018);}function ne(_0x160f43){const _0x26c8a1='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x160f43;throw sn(_0x26c8a1),new Error(_0x26c8a1);}function ce(_0x4b0be6,_0x19a213){_0x4b0be6||ne(_0x19a213);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pi(){var _0x86c832;return typeof self<'u'&&((_0x86c832=self['location'])==null?void 0x0:_0x86c832['href'])||'';}function rf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x33c41e;return typeof self<'u'&&((_0x33c41e=self['location'])==null?void 0x0:_0x33c41e['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function of(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(rf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function af(){if(typeof navigator>'u')return null;const _0x5da915=navigator;return _0x5da915['languages']&&_0x5da915['languages'][0x0]||_0x5da915['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yt{constructor(_0x5f4031,_0x22cb75){this['shortDelay']=_0x5f4031,this['longDelay']=_0x22cb75,ce(_0x22cb75>_0x5f4031,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Fi()||Yr();}['get'](){return of()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x55f493,_0x2adf3d){ce(_0x55f493['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x25c82f}=_0x55f493['emulator'];return _0x2adf3d?''+_0x25c82f+(_0x2adf3d['startsWith']('/')?_0x2adf3d['slice'](0x1):_0x2adf3d):_0x25c82f;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x32138e,_0x23307b,_0x512cc4){this['fetchImpl']=_0x32138e,_0x23307b&&(this['headersImpl']=_0x23307b),_0x512cc4&&(this['responseImpl']=_0x512cc4);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const cf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},lf=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],hf=new Yt(0x7530,0xea60);function Re(_0x98cf70,_0x441713){return _0x98cf70['tenantId']&&!_0x441713['tenantId']?{..._0x441713,'tenantId':_0x98cf70['tenantId']}:_0x441713;}async function Ae(_0x238af2,_0x221750,_0x8ffb84,_0x551b5c,_0x16a9ab={}){return Ca(_0x238af2,_0x16a9ab,async()=>{let _0x37116b={},_0x417edb={};_0x551b5c&&(_0x221750==='GET'?_0x417edb=_0x551b5c:_0x37116b={'body':JSON['stringify'](_0x551b5c)});const _0x4f247f=ct({'key':_0x238af2['config']['apiKey'],..._0x417edb})['slice'](0x1),_0x1b96f9=await _0x238af2['_getAdditionalHeaders']();_0x1b96f9['Content-Type']='application/json',_0x238af2['languageCode']&&(_0x1b96f9['X-Firebase-Locale']=_0x238af2['languageCode']);const _0x4a1312={'method':_0x221750,'headers':_0x1b96f9,..._0x37116b};return dc()||(_0x4a1312['referrerPolicy']='no-referrer'),_0x238af2['emulatorConfig']&&at(_0x238af2['emulatorConfig']['host'])&&(_0x4a1312['credentials']='include'),wa['fetch']()(await Ta(_0x238af2,_0x238af2['config']['apiHost'],_0x8ffb84,_0x4f247f),_0x4a1312);});}async function Ca(_0x538df6,_0x18135b,_0x269ac8){_0x538df6['_canInitEmulator']=!0x1;const _0x162f4a={...cf,..._0x18135b};try{const _0x174a3f=new df(_0x538df6),_0x435f49=await Promise['race']([_0x269ac8(),_0x174a3f['promise']]);_0x174a3f['clearNetworkTimeout']();const _0x30667e=await _0x435f49['json']();if('needConfirmation'in _0x30667e)throw tn(_0x538df6,'account-exists-with-different-credential',_0x30667e);if(_0x435f49['ok']&&!('errorMessage'in _0x30667e))return _0x30667e;{const _0x4d08df=_0x435f49['ok']?_0x30667e['errorMessage']:_0x30667e['error']['message'],[_0x157609,_0x381e40]=_0x4d08df['split']('\x20:\x20');if(_0x157609==='FEDERATED_USER_ID_ALREADY_LINKED')throw tn(_0x538df6,'credential-already-in-use',_0x30667e);if(_0x157609==='EMAIL_EXISTS')throw tn(_0x538df6,'email-already-in-use',_0x30667e);if(_0x157609==='USER_DISABLED')throw tn(_0x538df6,'user-disabled',_0x30667e);const _0xec9443=_0x162f4a[_0x157609]||_0x157609['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x381e40)throw Ia(_0x538df6,_0xec9443,_0x381e40);Q(_0x538df6,_0xec9443);}}catch(_0x326b2a){if(_0x326b2a instanceof Se)throw _0x326b2a;Q(_0x538df6,'network-request-failed',{'message':String(_0x326b2a)});}}async function Qt(_0x10c92c,_0x5c1b53,_0xb632b9,_0x586b6b,_0x190861={}){const _0x5c991a=await Ae(_0x10c92c,_0x5c1b53,_0xb632b9,_0x586b6b,_0x190861);return'mfaPendingCredential'in _0x5c991a&&Q(_0x10c92c,'multi-factor-auth-required',{'_serverResponse':_0x5c991a}),_0x5c991a;}async function Ta(_0x5e7a38,_0x4ad309,_0x421d95,_0x33b4a2){const _0x426c00=''+_0x4ad309+_0x421d95+'?'+_0x33b4a2,_0x5d2bdd=_0x5e7a38,_0x1f6ca5=_0x5d2bdd['config']['emulator']?Cs(_0x5e7a38['config'],_0x426c00):_0x5e7a38['config']['apiScheme']+'://'+_0x426c00;return lf['includes'](_0x421d95)&&(await _0x5d2bdd['_persistenceManagerAvailable'],_0x5d2bdd['_getPersistenceType']()==='COOKIE')?_0x5d2bdd['_getPersistence']()['_getFinalTarget'](_0x1f6ca5)['toString']():_0x1f6ca5;}function uf(_0x4ce6fd){switch(_0x4ce6fd){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class df{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x31c5cb){this['auth']=_0x31c5cb,this['timer']=null,this['promise']=new Promise((_0x18417b,_0x2e1280)=>{this['timer']=setTimeout(()=>_0x2e1280(X(this['auth'],'network-request-failed')),hf['get']());});}}function tn(_0x32b170,_0x20fa22,_0x5422c5){const _0xe16046={'appName':_0x32b170['name']};_0x5422c5['email']&&(_0xe16046['email']=_0x5422c5['email']),_0x5422c5['phoneNumber']&&(_0xe16046['phoneNumber']=_0x5422c5['phoneNumber']);const _0x1e59f2=X(_0x32b170,_0x20fa22,_0xe16046);return _0x1e59f2['customData']['_tokenResponse']=_0x5422c5,_0x1e59f2;}function wr(_0xba1eee){return _0xba1eee!==void 0x0&&_0xba1eee['enterprise']!==void 0x0;}class ff{constructor(_0x4df4e8){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x4df4e8['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x4df4e8['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x4df4e8['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x30c32d){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x278e87 of this['recaptchaEnforcementState'])if(_0x278e87['provider']&&_0x278e87['provider']===_0x30c32d)return uf(_0x278e87['enforcementState']);return null;}['isProviderEnabled'](_0x44d0ae){return this['getProviderEnforcementState'](_0x44d0ae)==='ENFORCE'||this['getProviderEnforcementState'](_0x44d0ae)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function pf(_0x3d84ce,_0x247fd8){return Ae(_0x3d84ce,'GET','/v2/recaptchaConfig',Re(_0x3d84ce,_0x247fd8));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function _f(_0x1970fe,_0x2180fc){return Ae(_0x1970fe,'POST','/v1/accounts:delete',_0x2180fc);}async function bn(_0x4954f3,_0x5f466c){return Ae(_0x4954f3,'POST','/v1/accounts:lookup',_0x5f466c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Rt(_0x21d566){if(_0x21d566)try{const _0x175b45=new Date(Number(_0x21d566));if(!isNaN(_0x175b45['getTime']()))return _0x175b45['toUTCString']();}catch{}}async function gf(_0x5e1b59,_0x34101f=!0x1){const _0x549635=N(_0x5e1b59),_0x5442b9=await _0x549635['getIdToken'](_0x34101f),_0x2189fa=Ts(_0x5442b9);m(_0x2189fa&&_0x2189fa['exp']&&_0x2189fa['auth_time']&&_0x2189fa['iat'],_0x549635['auth'],'internal-error');const _0x53fc3e=typeof _0x2189fa['firebase']=='object'?_0x2189fa['firebase']:void 0x0,_0x26bd05=_0x53fc3e==null?void 0x0:_0x53fc3e['sign_in_provider'];return{'claims':_0x2189fa,'token':_0x5442b9,'authTime':Rt(li(_0x2189fa['auth_time'])),'issuedAtTime':Rt(li(_0x2189fa['iat'])),'expirationTime':Rt(li(_0x2189fa['exp'])),'signInProvider':_0x26bd05||null,'signInSecondFactor':(_0x53fc3e==null?void 0x0:_0x53fc3e['sign_in_second_factor'])||null};}function li(_0x3b7176){return Number(_0x3b7176)*0x3e8;}function Ts(_0x59c845){const [_0xf8af61,_0x426ece,_0x448134]=_0x59c845['split']('.');if(_0xf8af61===void 0x0||_0x426ece===void 0x0||_0x448134===void 0x0)return sn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x1e395c=ln(_0x426ece);return _0x1e395c?JSON['parse'](_0x1e395c):(sn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x557d9e){return sn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x557d9e==null?void 0x0:_0x557d9e['toString']()),null;}}function Cr(_0x1f5d45){const _0x41c353=Ts(_0x1f5d45);return m(_0x41c353,'internal-error'),m(typeof _0x41c353['exp']<'u','internal-error'),m(typeof _0x41c353['iat']<'u','internal-error'),Number(_0x41c353['exp'])-Number(_0x41c353['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ut(_0x29ae00,_0x2e1b15,_0x6604bc=!0x1){if(_0x6604bc)return _0x2e1b15;try{return await _0x2e1b15;}catch(_0x2fdb4d){throw _0x2fdb4d instanceof Se&&mf(_0x2fdb4d)&&_0x29ae00['auth']['currentUser']===_0x29ae00&&await _0x29ae00['auth']['signOut'](),_0x2fdb4d;}}function mf({code:_0x329ab3}){return _0x329ab3==='auth/user-disabled'||_0x329ab3==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yf{constructor(_0x882c5e){this['user']=_0x882c5e,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x4d2144){if(_0x4d2144){const _0x2527d2=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x2527d2;}else{this['errorBackoff']=0x7530;const _0x3b5e18=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x3b5e18);}}['schedule'](_0x3cd61f=!0x1){if(!this['isRunning'])return;const _0x3f3c32=this['getInterval'](_0x3cd61f);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x3f3c32);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x2430da){(_0x2430da==null?void 0x0:_0x2430da['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Oi{constructor(_0x2e70d5,_0x2fc440){this['createdAt']=_0x2e70d5,this['lastLoginAt']=_0x2fc440,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Rt(this['lastLoginAt']),this['creationTime']=Rt(this['createdAt']);}['_copy'](_0x3d26bf){this['createdAt']=_0x3d26bf['createdAt'],this['lastLoginAt']=_0x3d26bf['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Rn(_0x3e9191){var _0x317caf;const _0x2e2327=_0x3e9191['auth'],_0x540c35=await _0x3e9191['getIdToken'](),_0x4b7acc=await Ut(_0x3e9191,bn(_0x2e2327,{'idToken':_0x540c35}));m(_0x4b7acc==null?void 0x0:_0x4b7acc['users']['length'],_0x2e2327,'internal-error');const _0x335529=_0x4b7acc['users'][0x0];_0x3e9191['_notifyReloadListener'](_0x335529);const _0x4050c5=(_0x317caf=_0x335529['providerUserInfo'])!=null&&_0x317caf['length']?Sa(_0x335529['providerUserInfo']):[],_0x1ee5dd=Ef(_0x3e9191['providerData'],_0x4050c5),_0x5904cf=_0x3e9191['isAnonymous'],_0x5b9275=!(_0x3e9191['email']&&_0x335529['passwordHash'])&&!(_0x1ee5dd!=null&&_0x1ee5dd['length']),_0x26d5d4=_0x5904cf?_0x5b9275:!0x1,_0x238af9={'uid':_0x335529['localId'],'displayName':_0x335529['displayName']||null,'photoURL':_0x335529['photoUrl']||null,'email':_0x335529['email']||null,'emailVerified':_0x335529['emailVerified']||!0x1,'phoneNumber':_0x335529['phoneNumber']||null,'tenantId':_0x335529['tenantId']||null,'providerData':_0x1ee5dd,'metadata':new Oi(_0x335529['createdAt'],_0x335529['lastLoginAt']),'isAnonymous':_0x26d5d4};Object['assign'](_0x3e9191,_0x238af9);}async function vf(_0x132b03){const _0x4d9a05=N(_0x132b03);await Rn(_0x4d9a05),await _0x4d9a05['auth']['_persistUserIfCurrent'](_0x4d9a05),_0x4d9a05['auth']['_notifyListenersIfCurrent'](_0x4d9a05);}function Ef(_0x3479c0,_0x237108){return[..._0x3479c0['filter'](_0x88cb7=>!_0x237108['some'](_0x3e6283=>_0x3e6283['providerId']===_0x88cb7['providerId'])),..._0x237108];}function Sa(_0x146637){return _0x146637['map'](({providerId:_0xc6f3fb,..._0x4417ae})=>({'providerId':_0xc6f3fb,'uid':_0x4417ae['rawId']||'','displayName':_0x4417ae['displayName']||null,'email':_0x4417ae['email']||null,'phoneNumber':_0x4417ae['phoneNumber']||null,'photoURL':_0x4417ae['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function If(_0x307f2c,_0x5f5172){const _0x1ebc43=await Ca(_0x307f2c,{},async()=>{const _0x38c442=ct({'grant_type':'refresh_token','refresh_token':_0x5f5172})['slice'](0x1),{tokenApiHost:_0x743c81,apiKey:_0x5f4ef8}=_0x307f2c['config'],_0x1e21e7=await Ta(_0x307f2c,_0x743c81,'/v1/token','key='+_0x5f4ef8),_0x32b195=await _0x307f2c['_getAdditionalHeaders']();_0x32b195['Content-Type']='application/x-www-form-urlencoded';const _0x350b9b={'method':'POST','headers':_0x32b195,'body':_0x38c442};return _0x307f2c['emulatorConfig']&&at(_0x307f2c['emulatorConfig']['host'])&&(_0x350b9b['credentials']='include'),wa['fetch']()(_0x1e21e7,_0x350b9b);});return{'accessToken':_0x1ebc43['access_token'],'expiresIn':_0x1ebc43['expires_in'],'refreshToken':_0x1ebc43['refresh_token']};}async function wf(_0x117d07,_0x50cf24){return Ae(_0x117d07,'POST','/v2/accounts:revokeToken',Re(_0x117d07,_0x50cf24));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qe{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x455215){m(_0x455215['idToken'],'internal-error'),m(typeof _0x455215['idToken']<'u','internal-error'),m(typeof _0x455215['refreshToken']<'u','internal-error');const _0x48a170='expiresIn'in _0x455215&&typeof _0x455215['expiresIn']<'u'?Number(_0x455215['expiresIn']):Cr(_0x455215['idToken']);this['updateTokensAndExpiration'](_0x455215['idToken'],_0x455215['refreshToken'],_0x48a170);}['updateFromIdToken'](_0x92f254){m(_0x92f254['length']!==0x0,'internal-error');const _0x4d5314=Cr(_0x92f254);this['updateTokensAndExpiration'](_0x92f254,null,_0x4d5314);}async['getToken'](_0xcab77c,_0x368ac7=!0x1){return!_0x368ac7&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0xcab77c,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0xcab77c,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x32a4b8,_0x10b40e){const {accessToken:_0x59a474,refreshToken:_0x2d2124,expiresIn:_0x4d114c}=await If(_0x32a4b8,_0x10b40e);this['updateTokensAndExpiration'](_0x59a474,_0x2d2124,Number(_0x4d114c));}['updateTokensAndExpiration'](_0x27be87,_0x4333f0,_0x432ba6){this['refreshToken']=_0x4333f0||null,this['accessToken']=_0x27be87||null,this['expirationTime']=Date['now']()+_0x432ba6*0x3e8;}static['fromJSON'](_0x4e8f1f,_0x5591a8){const {refreshToken:_0x4e1544,accessToken:_0x17f95b,expirationTime:_0x24e00c}=_0x5591a8,_0x239061=new Qe();return _0x4e1544&&(m(typeof _0x4e1544=='string','internal-error',{'appName':_0x4e8f1f}),_0x239061['refreshToken']=_0x4e1544),_0x17f95b&&(m(typeof _0x17f95b=='string','internal-error',{'appName':_0x4e8f1f}),_0x239061['accessToken']=_0x17f95b),_0x24e00c&&(m(typeof _0x24e00c=='number','internal-error',{'appName':_0x4e8f1f}),_0x239061['expirationTime']=_0x24e00c),_0x239061;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0xddb051){this['accessToken']=_0xddb051['accessToken'],this['refreshToken']=_0xddb051['refreshToken'],this['expirationTime']=_0xddb051['expirationTime'];}['_clone'](){return Object['assign'](new Qe(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x3e411c,_0xae9f7f){m(typeof _0x3e411c=='string'||typeof _0x3e411c>'u','internal-error',{'appName':_0xae9f7f});}class K{constructor({uid:_0x1f3ba2,auth:_0x47e24e,stsTokenManager:_0x4f58ef,..._0x44480e}){this['providerId']='firebase',this['proactiveRefresh']=new yf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x1f3ba2,this['auth']=_0x47e24e,this['stsTokenManager']=_0x4f58ef,this['accessToken']=_0x4f58ef['accessToken'],this['displayName']=_0x44480e['displayName']||null,this['email']=_0x44480e['email']||null,this['emailVerified']=_0x44480e['emailVerified']||!0x1,this['phoneNumber']=_0x44480e['phoneNumber']||null,this['photoURL']=_0x44480e['photoURL']||null,this['isAnonymous']=_0x44480e['isAnonymous']||!0x1,this['tenantId']=_0x44480e['tenantId']||null,this['providerData']=_0x44480e['providerData']?[..._0x44480e['providerData']]:[],this['metadata']=new Oi(_0x44480e['createdAt']||void 0x0,_0x44480e['lastLoginAt']||void 0x0);}async['getIdToken'](_0x2e133e){const _0x493f84=await Ut(this,this['stsTokenManager']['getToken'](this['auth'],_0x2e133e));return m(_0x493f84,this['auth'],'internal-error'),this['accessToken']!==_0x493f84&&(this['accessToken']=_0x493f84,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x493f84;}['getIdTokenResult'](_0x5ea9a7){return gf(this,_0x5ea9a7);}['reload'](){return vf(this);}['_assign'](_0x19c99e){this!==_0x19c99e&&(m(this['uid']===_0x19c99e['uid'],this['auth'],'internal-error'),this['displayName']=_0x19c99e['displayName'],this['photoURL']=_0x19c99e['photoURL'],this['email']=_0x19c99e['email'],this['emailVerified']=_0x19c99e['emailVerified'],this['phoneNumber']=_0x19c99e['phoneNumber'],this['isAnonymous']=_0x19c99e['isAnonymous'],this['tenantId']=_0x19c99e['tenantId'],this['providerData']=_0x19c99e['providerData']['map'](_0x3fee6c=>({..._0x3fee6c})),this['metadata']['_copy'](_0x19c99e['metadata']),this['stsTokenManager']['_assign'](_0x19c99e['stsTokenManager']));}['_clone'](_0x58ce43){const _0x3c2768=new K({...this,'auth':_0x58ce43,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x3c2768['metadata']['_copy'](this['metadata']),_0x3c2768;}['_onReload'](_0x530e36){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x530e36,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0xec0119){this['reloadListener']?this['reloadListener'](_0xec0119):this['reloadUserInfo']=_0xec0119;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x46d649,_0x315120=!0x1){let _0x1e7ef=!0x1;_0x46d649['idToken']&&_0x46d649['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x46d649),_0x1e7ef=!0x0),_0x315120&&await Rn(this),await this['auth']['_persistUserIfCurrent'](this),_0x1e7ef&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x933054=await this['getIdToken']();return await Ut(this,_f(this['auth'],{'idToken':_0x933054})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x3c48b7=>({..._0x3c48b7})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x777e64,_0xcac4e8){const _0x242f9f=_0xcac4e8['displayName']??void 0x0,_0x13ca3d=_0xcac4e8['email']??void 0x0,_0x4c7875=_0xcac4e8['phoneNumber']??void 0x0,_0x6f8c26=_0xcac4e8['photoURL']??void 0x0,_0x5cee6b=_0xcac4e8['tenantId']??void 0x0,_0x3159cc=_0xcac4e8['_redirectEventId']??void 0x0,_0x30dca6=_0xcac4e8['createdAt']??void 0x0,_0x3fc344=_0xcac4e8['lastLoginAt']??void 0x0,{uid:_0x47c779,emailVerified:_0x51b4a9,isAnonymous:_0x531956,providerData:_0x129fb7,stsTokenManager:_0x3c5097}=_0xcac4e8;m(_0x47c779&&_0x3c5097,_0x777e64,'internal-error');const _0xdccb7b=Qe['fromJSON'](this['name'],_0x3c5097);m(typeof _0x47c779=='string',_0x777e64,'internal-error'),le(_0x242f9f,_0x777e64['name']),le(_0x13ca3d,_0x777e64['name']),m(typeof _0x51b4a9=='boolean',_0x777e64,'internal-error'),m(typeof _0x531956=='boolean',_0x777e64,'internal-error'),le(_0x4c7875,_0x777e64['name']),le(_0x6f8c26,_0x777e64['name']),le(_0x5cee6b,_0x777e64['name']),le(_0x3159cc,_0x777e64['name']),le(_0x30dca6,_0x777e64['name']),le(_0x3fc344,_0x777e64['name']);const _0x226fba=new K({'uid':_0x47c779,'auth':_0x777e64,'email':_0x13ca3d,'emailVerified':_0x51b4a9,'displayName':_0x242f9f,'isAnonymous':_0x531956,'photoURL':_0x6f8c26,'phoneNumber':_0x4c7875,'tenantId':_0x5cee6b,'stsTokenManager':_0xdccb7b,'createdAt':_0x30dca6,'lastLoginAt':_0x3fc344});return _0x129fb7&&Array['isArray'](_0x129fb7)&&(_0x226fba['providerData']=_0x129fb7['map'](_0x397e3b=>({..._0x397e3b}))),_0x3159cc&&(_0x226fba['_redirectEventId']=_0x3159cc),_0x226fba;}static async['_fromIdTokenResponse'](_0x2cf8a0,_0x3a747e,_0x4e9c42=!0x1){const _0x2140f3=new Qe();_0x2140f3['updateFromServerResponse'](_0x3a747e);const _0x3e130f=new K({'uid':_0x3a747e['localId'],'auth':_0x2cf8a0,'stsTokenManager':_0x2140f3,'isAnonymous':_0x4e9c42});return await Rn(_0x3e130f),_0x3e130f;}static async['_fromGetAccountInfoResponse'](_0x1dfc61,_0x1707aa,_0x44d01b){const _0x465c94=_0x1707aa['users'][0x0];m(_0x465c94['localId']!==void 0x0,'internal-error');const _0x4b0197=_0x465c94['providerUserInfo']!==void 0x0?Sa(_0x465c94['providerUserInfo']):[],_0x66aa0d=!(_0x465c94['email']&&_0x465c94['passwordHash'])&&!(_0x4b0197!=null&&_0x4b0197['length']),_0xdc996c=new Qe();_0xdc996c['updateFromIdToken'](_0x44d01b);const _0x154119=new K({'uid':_0x465c94['localId'],'auth':_0x1dfc61,'stsTokenManager':_0xdc996c,'isAnonymous':_0x66aa0d}),_0x2ba049={'uid':_0x465c94['localId'],'displayName':_0x465c94['displayName']||null,'photoURL':_0x465c94['photoUrl']||null,'email':_0x465c94['email']||null,'emailVerified':_0x465c94['emailVerified']||!0x1,'phoneNumber':_0x465c94['phoneNumber']||null,'tenantId':_0x465c94['tenantId']||null,'providerData':_0x4b0197,'metadata':new Oi(_0x465c94['createdAt'],_0x465c94['lastLoginAt']),'isAnonymous':!(_0x465c94['email']&&_0x465c94['passwordHash'])&&!(_0x4b0197!=null&&_0x4b0197['length'])};return Object['assign'](_0x154119,_0x2ba049),_0x154119;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x4803d6){ce(_0x4803d6 instanceof Function,'Expected\x20a\x20class\x20definition');let _0xef20db=Tr['get'](_0x4803d6);return _0xef20db?(ce(_0xef20db instanceof _0x4803d6,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0xef20db):(_0xef20db=new _0x4803d6(),Tr['set'](_0x4803d6,_0xef20db),_0xef20db);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x3692c6,_0x426b92){this['storage'][_0x3692c6]=_0x426b92;}async['_get'](_0x533721){const _0xa2e404=this['storage'][_0x533721];return _0xa2e404===void 0x0?null:_0xa2e404;}async['_remove'](_0x267fff){delete this['storage'][_0x267fff];}['_addListener'](_0x112446,_0x17d8d3){}['_removeListener'](_0x2b9a01,_0x382eb8){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rn(_0x2b2db6,_0x470f1e,_0x31dce8){return'firebase:'+_0x2b2db6+':'+_0x470f1e+':'+_0x31dce8;}class Je{constructor(_0x4cada8,_0x3dc51e,_0x7181a5){this['persistence']=_0x4cada8,this['auth']=_0x3dc51e,this['userKey']=_0x7181a5;const {config:_0x1f3138,name:_0x15d55d}=this['auth'];this['fullUserKey']=rn(this['userKey'],_0x1f3138['apiKey'],_0x15d55d),this['fullPersistenceKey']=rn('persistence',_0x1f3138['apiKey'],_0x15d55d),this['boundEventHandler']=_0x3dc51e['_onStorageEvent']['bind'](_0x3dc51e),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x31b6e1){return this['persistence']['_set'](this['fullUserKey'],_0x31b6e1['toJSON']());}async['getCurrentUser'](){const _0x5d7942=await this['persistence']['_get'](this['fullUserKey']);if(!_0x5d7942)return null;if(typeof _0x5d7942=='string'){const _0x1caa15=await bn(this['auth'],{'idToken':_0x5d7942})['catch'](()=>{});return _0x1caa15?K['_fromGetAccountInfoResponse'](this['auth'],_0x1caa15,_0x5d7942):null;}return K['_fromJSON'](this['auth'],_0x5d7942);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x1b6681){if(this['persistence']===_0x1b6681)return;const _0x1e2e6d=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x1b6681,_0x1e2e6d)return this['setCurrentUser'](_0x1e2e6d);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x5bc1aa,_0x465272,_0xe36101='authUser'){if(!_0x465272['length'])return new Je(ie(Sr),_0x5bc1aa,_0xe36101);const _0x2f16e9=(await Promise['all'](_0x465272['map'](async _0x5bdfcb=>{if(await _0x5bdfcb['_isAvailable']())return _0x5bdfcb;})))['filter'](_0x344a3e=>_0x344a3e);let _0x58b7fd=_0x2f16e9[0x0]||ie(Sr);const _0x4b5e1a=rn(_0xe36101,_0x5bc1aa['config']['apiKey'],_0x5bc1aa['name']);let _0x29392d=null;for(const _0x3fdc73 of _0x465272)try{const _0x282437=await _0x3fdc73['_get'](_0x4b5e1a);if(_0x282437){let _0x50d6c8;if(typeof _0x282437=='string'){const _0x4e5d35=await bn(_0x5bc1aa,{'idToken':_0x282437})['catch'](()=>{});if(!_0x4e5d35)break;_0x50d6c8=await K['_fromGetAccountInfoResponse'](_0x5bc1aa,_0x4e5d35,_0x282437);}else _0x50d6c8=K['_fromJSON'](_0x5bc1aa,_0x282437);_0x3fdc73!==_0x58b7fd&&(_0x29392d=_0x50d6c8),_0x58b7fd=_0x3fdc73;break;}}catch{}const _0x57a8fc=_0x2f16e9['filter'](_0x44e09c=>_0x44e09c['_shouldAllowMigration']);return!_0x58b7fd['_shouldAllowMigration']||!_0x57a8fc['length']?new Je(_0x58b7fd,_0x5bc1aa,_0xe36101):(_0x58b7fd=_0x57a8fc[0x0],_0x29392d&&await _0x58b7fd['_set'](_0x4b5e1a,_0x29392d['toJSON']()),await Promise['all'](_0x465272['map'](async _0x5e7b79=>{if(_0x5e7b79!==_0x58b7fd)try{await _0x5e7b79['_remove'](_0x4b5e1a);}catch{}})),new Je(_0x58b7fd,_0x5bc1aa,_0xe36101));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x5bf984){const _0x164311=_0x5bf984['toLowerCase']();if(_0x164311['includes']('opera/')||_0x164311['includes']('opr/')||_0x164311['includes']('opios/'))return'Opera';if(Na(_0x164311))return'IEMobile';if(_0x164311['includes']('msie')||_0x164311['includes']('trident/'))return'IE';if(_0x164311['includes']('edge/'))return'Edge';if(Ra(_0x164311))return'Firefox';if(_0x164311['includes']('silk/'))return'Silk';if(Oa(_0x164311))return'Blackberry';if(Da(_0x164311))return'Webos';if(Aa(_0x164311))return'Safari';if((_0x164311['includes']('chrome/')||ka(_0x164311))&&!_0x164311['includes']('edge/'))return'Chrome';if(Pa(_0x164311))return'Android';{const _0x31f574=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x10a290=_0x5bf984['match'](_0x31f574);if((_0x10a290==null?void 0x0:_0x10a290['length'])===0x2)return _0x10a290[0x1];}return'Other';}function Ra(_0x41e40a=W()){return/firefox\//i['test'](_0x41e40a);}function Aa(_0x3ea77b=W()){const _0x29ff89=_0x3ea77b['toLowerCase']();return _0x29ff89['includes']('safari/')&&!_0x29ff89['includes']('chrome/')&&!_0x29ff89['includes']('crios/')&&!_0x29ff89['includes']('android');}function ka(_0x215e73=W()){return/crios\//i['test'](_0x215e73);}function Na(_0x578fc4=W()){return/iemobile/i['test'](_0x578fc4);}function Pa(_0x2b2b48=W()){return/android/i['test'](_0x2b2b48);}function Oa(_0x1f5d5b=W()){return/blackberry/i['test'](_0x1f5d5b);}function Da(_0x558f93=W()){return/webos/i['test'](_0x558f93);}function Ss(_0x2d9f9d=W()){return/iphone|ipad|ipod/i['test'](_0x2d9f9d)||/macintosh/i['test'](_0x2d9f9d)&&/mobile/i['test'](_0x2d9f9d);}function Cf(_0x1ded8d=W()){var _0xb59e67;return Ss(_0x1ded8d)&&!!((_0xb59e67=window['navigator'])!=null&&_0xb59e67['standalone']);}function Tf(){return pc()&&document['documentMode']===0xa;}function Ma(_0x5b12e0=W()){return Ss(_0x5b12e0)||Pa(_0x5b12e0)||Da(_0x5b12e0)||Oa(_0x5b12e0)||/windows phone/i['test'](_0x5b12e0)||Na(_0x5b12e0);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x4144bc,_0x522eb9=[]){let _0x392c4c;switch(_0x4144bc){case'Browser':_0x392c4c=br(W());break;case'Worker':_0x392c4c=br(W())+'-'+_0x4144bc;break;default:_0x392c4c=_0x4144bc;}const _0x59ca7d=_0x522eb9['length']?_0x522eb9['join'](','):'FirebaseCore-web';return _0x392c4c+'/JsCore/'+lt+'/'+_0x59ca7d;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sf{constructor(_0x4bfd29){this['auth']=_0x4bfd29,this['queue']=[];}['pushCallback'](_0x333c1a,_0x5ddeb1){const _0x2c3c54=_0x5d241a=>new Promise((_0x1ed602,_0x5125d5)=>{try{const _0x565c24=_0x333c1a(_0x5d241a);_0x1ed602(_0x565c24);}catch(_0x220e83){_0x5125d5(_0x220e83);}});_0x2c3c54['onAbort']=_0x5ddeb1,this['queue']['push'](_0x2c3c54);const _0x3de90b=this['queue']['length']-0x1;return()=>{this['queue'][_0x3de90b]=()=>Promise['resolve']();};}async['runMiddleware'](_0x40dc8c){if(this['auth']['currentUser']===_0x40dc8c)return;const _0x551c59=[];try{for(const _0x5c6de0 of this['queue'])await _0x5c6de0(_0x40dc8c),_0x5c6de0['onAbort']&&_0x551c59['push'](_0x5c6de0['onAbort']);}catch(_0x40a853){_0x551c59['reverse']();for(const _0x37897e of _0x551c59)try{_0x37897e();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x40a853==null?void 0x0:_0x40a853['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bf(_0x4a6a62,_0x504463={}){return Ae(_0x4a6a62,'GET','/v2/passwordPolicy',Re(_0x4a6a62,_0x504463));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rf=0x6;class Af{constructor(_0xb268c9){var _0x395274;const _0x5b7804=_0xb268c9['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x5b7804['minPasswordLength']??Rf,_0x5b7804['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x5b7804['maxPasswordLength']),_0x5b7804['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x5b7804['containsLowercaseCharacter']),_0x5b7804['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x5b7804['containsUppercaseCharacter']),_0x5b7804['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x5b7804['containsNumericCharacter']),_0x5b7804['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x5b7804['containsNonAlphanumericCharacter']),this['enforcementState']=_0xb268c9['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x395274=_0xb268c9['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x395274['join'](''))??'',this['forceUpgradeOnSignin']=_0xb268c9['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0xb268c9['schemaVersion'];}['validatePassword'](_0x394634){const _0x2c4213={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x394634,_0x2c4213),this['validatePasswordCharacterOptions'](_0x394634,_0x2c4213),_0x2c4213['isValid']&&(_0x2c4213['isValid']=_0x2c4213['meetsMinPasswordLength']??!0x0),_0x2c4213['isValid']&&(_0x2c4213['isValid']=_0x2c4213['meetsMaxPasswordLength']??!0x0),_0x2c4213['isValid']&&(_0x2c4213['isValid']=_0x2c4213['containsLowercaseLetter']??!0x0),_0x2c4213['isValid']&&(_0x2c4213['isValid']=_0x2c4213['containsUppercaseLetter']??!0x0),_0x2c4213['isValid']&&(_0x2c4213['isValid']=_0x2c4213['containsNumericCharacter']??!0x0),_0x2c4213['isValid']&&(_0x2c4213['isValid']=_0x2c4213['containsNonAlphanumericCharacter']??!0x0),_0x2c4213;}['validatePasswordLengthOptions'](_0x2827d0,_0x48127d){const _0x227e70=this['customStrengthOptions']['minPasswordLength'],_0x4433e7=this['customStrengthOptions']['maxPasswordLength'];_0x227e70&&(_0x48127d['meetsMinPasswordLength']=_0x2827d0['length']>=_0x227e70),_0x4433e7&&(_0x48127d['meetsMaxPasswordLength']=_0x2827d0['length']<=_0x4433e7);}['validatePasswordCharacterOptions'](_0x1979cd,_0xd14b0b){this['updatePasswordCharacterOptionsStatuses'](_0xd14b0b,!0x1,!0x1,!0x1,!0x1);let _0x21d40e;for(let _0x35dc7b=0x0;_0x35dc7b<_0x1979cd['length'];_0x35dc7b++)_0x21d40e=_0x1979cd['charAt'](_0x35dc7b),this['updatePasswordCharacterOptionsStatuses'](_0xd14b0b,_0x21d40e>='a'&&_0x21d40e<='z',_0x21d40e>='A'&&_0x21d40e<='Z',_0x21d40e>='0'&&_0x21d40e<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x21d40e));}['updatePasswordCharacterOptionsStatuses'](_0x406a43,_0x377777,_0x180d19,_0x4c11aa,_0x49a171){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x406a43['containsLowercaseLetter']||(_0x406a43['containsLowercaseLetter']=_0x377777)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x406a43['containsUppercaseLetter']||(_0x406a43['containsUppercaseLetter']=_0x180d19)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x406a43['containsNumericCharacter']||(_0x406a43['containsNumericCharacter']=_0x4c11aa)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x406a43['containsNonAlphanumericCharacter']||(_0x406a43['containsNonAlphanumericCharacter']=_0x49a171));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x3cb139,_0x2b530b,_0x194a64,_0x34853e){this['app']=_0x3cb139,this['heartbeatServiceProvider']=_0x2b530b,this['appCheckServiceProvider']=_0x194a64,this['config']=_0x34853e,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new Sf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x3cb139['name'],this['clientVersion']=_0x34853e['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0xef9694=>this['_resolvePersistenceManagerAvailable']=_0xef9694);}['_initializeWithPersistence'](_0x799e00,_0x8d480d){return _0x8d480d&&(this['_popupRedirectResolver']=ie(_0x8d480d)),this['_initializationPromise']=this['queue'](async()=>{var _0x4d6500,_0x3124b7,_0x788b64;if(!this['_deleted']&&(this['persistenceManager']=await Je['create'](this,_0x799e00),(_0x4d6500=this['_resolvePersistenceManagerAvailable'])==null||_0x4d6500['call'](this),!this['_deleted'])){if((_0x3124b7=this['_popupRedirectResolver'])!=null&&_0x3124b7['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x8d480d),this['lastNotifiedUid']=((_0x788b64=this['currentUser'])==null?void 0x0:_0x788b64['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x15ac6b=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x15ac6b)){if(this['currentUser']&&_0x15ac6b&&this['currentUser']['uid']===_0x15ac6b['uid']){this['_currentUser']['_assign'](_0x15ac6b),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x15ac6b,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x4a257d){try{const _0x572960=await bn(this,{'idToken':_0x4a257d}),_0x19a05c=await K['_fromGetAccountInfoResponse'](this,_0x572960,_0x4a257d);await this['directlySetCurrentUser'](_0x19a05c);}catch(_0x6abca3){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x6abca3),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x5a4d19){var _0x318660;if($(this['app'])){const _0x2db1b2=this['app']['settings']['authIdToken'];return _0x2db1b2?new Promise(_0x478ba1=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x2db1b2)['then'](_0x478ba1,_0x478ba1));}):this['directlySetCurrentUser'](null);}const _0x497891=await this['assertedPersistence']['getCurrentUser']();let _0x363ae7=_0x497891,_0x1fb770=!0x1;if(_0x5a4d19&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x7e38f4=(_0x318660=this['redirectUser'])==null?void 0x0:_0x318660['_redirectEventId'],_0x55e393=_0x363ae7==null?void 0x0:_0x363ae7['_redirectEventId'],_0x2444bd=await this['tryRedirectSignIn'](_0x5a4d19);(!_0x7e38f4||_0x7e38f4===_0x55e393)&&(_0x2444bd!=null&&_0x2444bd['user'])&&(_0x363ae7=_0x2444bd['user'],_0x1fb770=!0x0);}if(!_0x363ae7)return this['directlySetCurrentUser'](null);if(!_0x363ae7['_redirectEventId']){if(_0x1fb770)try{await this['beforeStateQueue']['runMiddleware'](_0x363ae7);}catch(_0x1230ef){_0x363ae7=_0x497891,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x1230ef));}return _0x363ae7?this['reloadAndSetCurrentUserOrClear'](_0x363ae7):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x363ae7['_redirectEventId']?this['directlySetCurrentUser'](_0x363ae7):this['reloadAndSetCurrentUserOrClear'](_0x363ae7);}async['tryRedirectSignIn'](_0x2f423d){let _0x1ca60e=null;try{_0x1ca60e=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x2f423d,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x1ca60e;}async['reloadAndSetCurrentUserOrClear'](_0xc055d2){try{await Rn(_0xc055d2);}catch(_0x7c28f5){if((_0x7c28f5==null?void 0x0:_0x7c28f5['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0xc055d2);}['useDeviceLanguage'](){this['languageCode']=af();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x449107){if($(this['app']))return Promise['reject'](re(this));const _0x4573ca=_0x449107?N(_0x449107):null;return _0x4573ca&&m(_0x4573ca['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x4573ca&&_0x4573ca['_clone'](this));}async['_updateCurrentUser'](_0x83bca7,_0x43f6d0=!0x1){if(!this['_deleted'])return _0x83bca7&&m(this['tenantId']===_0x83bca7['tenantId'],this,'tenant-id-mismatch'),_0x43f6d0||await this['beforeStateQueue']['runMiddleware'](_0x83bca7),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x83bca7),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x3786ef){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x3786ef));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x3d0936){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x4f8a6c=this['_getPasswordPolicyInternal']();return _0x4f8a6c['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x4f8a6c['validatePassword'](_0x3d0936);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x3f1e29=await bf(this),_0x36ec55=new Af(_0x3f1e29);this['tenantId']===null?this['_projectPasswordPolicy']=_0x36ec55:this['_tenantPasswordPolicies'][this['tenantId']]=_0x36ec55;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0xf618bb){this['_errorFactory']=new Bt('auth','Firebase',_0xf618bb());}['onAuthStateChanged'](_0x3d37d0,_0x32bff8,_0x5d26ca){return this['registerStateListener'](this['authStateSubscription'],_0x3d37d0,_0x32bff8,_0x5d26ca);}['beforeAuthStateChanged'](_0x2bd09d,_0x36decd){return this['beforeStateQueue']['pushCallback'](_0x2bd09d,_0x36decd);}['onIdTokenChanged'](_0x1b5ea7,_0x14c93c,_0x23ca69){return this['registerStateListener'](this['idTokenSubscription'],_0x1b5ea7,_0x14c93c,_0x23ca69);}['authStateReady'](){return new Promise((_0x387061,_0x3eb1d4)=>{if(this['currentUser'])_0x387061();else{const _0x58eb32=this['onAuthStateChanged'](()=>{_0x58eb32(),_0x387061();},_0x3eb1d4);}});}async['revokeAccessToken'](_0x23173a){if(this['currentUser']){const _0x1d99a4=await this['currentUser']['getIdToken'](),_0x323e46={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x23173a,'idToken':_0x1d99a4};this['tenantId']!=null&&(_0x323e46['tenantId']=this['tenantId']),await wf(this,_0x323e46);}}['toJSON'](){var _0x324bc0;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x324bc0=this['_currentUser'])==null?void 0x0:_0x324bc0['toJSON']()};}async['_setRedirectUser'](_0x1b1a17,_0x392d7d){const _0x4432f0=await this['getOrInitRedirectPersistenceManager'](_0x392d7d);return _0x1b1a17===null?_0x4432f0['removeCurrentUser']():_0x4432f0['setCurrentUser'](_0x1b1a17);}async['getOrInitRedirectPersistenceManager'](_0x29be8d){if(!this['redirectPersistenceManager']){const _0x2fc0fd=_0x29be8d&&ie(_0x29be8d)||this['_popupRedirectResolver'];m(_0x2fc0fd,this,'argument-error'),this['redirectPersistenceManager']=await Je['create'](this,[ie(_0x2fc0fd['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x4cf957){var _0x4c4099,_0x4a2cf5;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x4c4099=this['_currentUser'])==null?void 0x0:_0x4c4099['_redirectEventId'])===_0x4cf957?this['_currentUser']:((_0x4a2cf5=this['redirectUser'])==null?void 0x0:_0x4a2cf5['_redirectEventId'])===_0x4cf957?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x5612ad){if(_0x5612ad===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x5612ad));}['_notifyListenersIfCurrent'](_0x12c029){_0x12c029===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x3c700e;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x19df2e=((_0x3c700e=this['currentUser'])==null?void 0x0:_0x3c700e['uid'])??null;this['lastNotifiedUid']!==_0x19df2e&&(this['lastNotifiedUid']=_0x19df2e,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x294e72,_0x2ee18b,_0x86b0a7,_0x267b06){if(this['_deleted'])return()=>{};const _0x1484c3=typeof _0x2ee18b=='function'?_0x2ee18b:_0x2ee18b['next']['bind'](_0x2ee18b);let _0x4830cf=!0x1;const _0x28dcae=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x28dcae,this,'internal-error'),_0x28dcae['then'](()=>{_0x4830cf||_0x1484c3(this['currentUser']);}),typeof _0x2ee18b=='function'){const _0x64da22=_0x294e72['addObserver'](_0x2ee18b,_0x86b0a7,_0x267b06);return()=>{_0x4830cf=!0x0,_0x64da22();};}else{const _0x1cde63=_0x294e72['addObserver'](_0x2ee18b);return()=>{_0x4830cf=!0x0,_0x1cde63();};}}async['directlySetCurrentUser'](_0x13379f){this['currentUser']&&this['currentUser']!==_0x13379f&&this['_currentUser']['_stopProactiveRefresh'](),_0x13379f&&this['isProactiveRefreshEnabled']&&_0x13379f['_startProactiveRefresh'](),this['currentUser']=_0x13379f,_0x13379f?await this['assertedPersistence']['setCurrentUser'](_0x13379f):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x13a3d6){return this['operations']=this['operations']['then'](_0x13a3d6,_0x13a3d6),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x196f11){!_0x196f11||this['frameworks']['includes'](_0x196f11)||(this['frameworks']['push'](_0x196f11),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x544e9b;const _0x3a2414={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x3a2414['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x139a37=await((_0x544e9b=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x544e9b['getHeartbeatsHeader']());_0x139a37&&(_0x3a2414['X-Firebase-Client']=_0x139a37);const _0x3cb92d=await this['_getAppCheckToken']();return _0x3cb92d&&(_0x3a2414['X-Firebase-AppCheck']=_0x3cb92d),_0x3a2414;}async['_getAppCheckToken'](){var _0x320412;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x3430a8=await((_0x320412=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x320412['getToken']());return _0x3430a8!=null&&_0x3430a8['error']&&sf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x3430a8['error']),_0x3430a8==null?void 0x0:_0x3430a8['token'];}}function qe(_0x33b4ab){return N(_0x33b4ab);}class Rr{constructor(_0x5c2086){this['auth']=_0x5c2086,this['observer']=null,this['addObserver']=Tc(_0x2540f3=>this['observer']=_0x2540f3);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Nf(_0x30ab33){jn=_0x30ab33;}function xa(_0x58e7de){return jn['loadJS'](_0x58e7de);}function Pf(){return jn['recaptchaEnterpriseScript'];}function Of(){return jn['gapiScript'];}function Df(_0xcb502){return'__'+_0xcb502+Math['floor'](Math['random']()*0xf4240);}class Mf{constructor(){this['enterprise']=new Lf();}['ready'](_0x18d996){_0x18d996();}['execute'](_0x2fb402,_0x4418f9){return Promise['resolve']('token');}['render'](_0x2fdede,_0x32dcf3){return'';}}class Lf{['ready'](_0xeba404){_0xeba404();}['execute'](_0x39366f,_0x314db0){return Promise['resolve']('token');}['render'](_0x43960e,_0x1721c6){return'';}}const xf='recaptcha-enterprise',Fa='NO_RECAPTCHA';class Ff{constructor(_0xb530e3){this['type']=xf,this['auth']=qe(_0xb530e3);}async['verify'](_0x23be2e='verify',_0x3cd0f5=!0x1){async function _0x1435c1(_0x4b4ce3){if(!_0x3cd0f5){if(_0x4b4ce3['tenantId']==null&&_0x4b4ce3['_agentRecaptchaConfig']!=null)return _0x4b4ce3['_agentRecaptchaConfig']['siteKey'];if(_0x4b4ce3['tenantId']!=null&&_0x4b4ce3['_tenantRecaptchaConfigs'][_0x4b4ce3['tenantId']]!==void 0x0)return _0x4b4ce3['_tenantRecaptchaConfigs'][_0x4b4ce3['tenantId']]['siteKey'];}return new Promise(async(_0x38239e,_0x485b43)=>{pf(_0x4b4ce3,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0xf0cda=>{if(_0xf0cda['recaptchaKey']===void 0x0)_0x485b43(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x5ba615=new ff(_0xf0cda);return _0x4b4ce3['tenantId']==null?_0x4b4ce3['_agentRecaptchaConfig']=_0x5ba615:_0x4b4ce3['_tenantRecaptchaConfigs'][_0x4b4ce3['tenantId']]=_0x5ba615,_0x38239e(_0x5ba615['siteKey']);}})['catch'](_0x2c6c1a=>{_0x485b43(_0x2c6c1a);});});}function _0x430ec0(_0x46fb88,_0x5404b0,_0x4d88c8){const _0x33be79=window['grecaptcha'];wr(_0x33be79)?_0x33be79['enterprise']['ready'](()=>{_0x33be79['enterprise']['execute'](_0x46fb88,{'action':_0x23be2e})['then'](_0x4cfbab=>{_0x5404b0(_0x4cfbab);})['catch'](()=>{_0x5404b0(Fa);});}):_0x4d88c8(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Mf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x1be5a4,_0x5f12f9)=>{_0x1435c1(this['auth'])['then'](_0x40986d=>{if(!_0x3cd0f5&&wr(window['grecaptcha']))_0x430ec0(_0x40986d,_0x1be5a4,_0x5f12f9);else{if(typeof window>'u'){_0x5f12f9(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x5586fc=Pf();_0x5586fc['length']!==0x0&&(_0x5586fc+=_0x40986d),xa(_0x5586fc)['then'](()=>{_0x430ec0(_0x40986d,_0x1be5a4,_0x5f12f9);})['catch'](_0x75bb81=>{_0x5f12f9(_0x75bb81);});}})['catch'](_0x32603e=>{_0x5f12f9(_0x32603e);});});}}async function Ar(_0x353cae,_0xbfb966,_0x4bf965,_0x560149=!0x1,_0x2107a6=!0x1){const _0x2dec6d=new Ff(_0x353cae);let _0x12cae2;if(_0x2107a6)_0x12cae2=Fa;else try{_0x12cae2=await _0x2dec6d['verify'](_0x4bf965);}catch{_0x12cae2=await _0x2dec6d['verify'](_0x4bf965,!0x0);}const _0x46510d={..._0xbfb966};if(_0x4bf965==='mfaSmsEnrollment'||_0x4bf965==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x46510d){const _0x2f8407=_0x46510d['phoneEnrollmentInfo']['phoneNumber'],_0x27c9a5=_0x46510d['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x46510d,{'phoneEnrollmentInfo':{'phoneNumber':_0x2f8407,'recaptchaToken':_0x27c9a5,'captchaResponse':_0x12cae2,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x46510d){const _0x527d83=_0x46510d['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x46510d,{'phoneSignInInfo':{'recaptchaToken':_0x527d83,'captchaResponse':_0x12cae2,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x46510d;}return _0x560149?Object['assign'](_0x46510d,{'captchaResp':_0x12cae2}):Object['assign'](_0x46510d,{'captchaResponse':_0x12cae2}),Object['assign'](_0x46510d,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x46510d,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x46510d;}async function Di(_0x209125,_0x3bde9f,_0x472d95,_0x3d66ae,_0x2df53c){var _0x477be7;if((_0x477be7=_0x209125['_getRecaptchaConfig']())!=null&&_0x477be7['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x3f765c=await Ar(_0x209125,_0x3bde9f,_0x472d95,_0x472d95==='getOobCode');return _0x3d66ae(_0x209125,_0x3f765c);}else return _0x3d66ae(_0x209125,_0x3bde9f)['catch'](async _0x583aec=>{if(_0x583aec['code']==='auth/missing-recaptcha-token'){console['log'](_0x472d95+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0xd95086=await Ar(_0x209125,_0x3bde9f,_0x472d95,_0x472d95==='getOobCode');return _0x3d66ae(_0x209125,_0xd95086);}else return Promise['reject'](_0x583aec);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Uf(_0x3f4603,_0x4ceea9){const _0x4d0664=Bi(_0x3f4603,'auth');if(_0x4d0664['isInitialized']()){const _0x26180e=_0x4d0664['getImmediate'](),_0xbd98ea=_0x4d0664['getOptions']();if(Me(_0xbd98ea,_0x4ceea9??{}))return _0x26180e;Q(_0x26180e,'already-initialized');}return _0x4d0664['initialize']({'options':_0x4ceea9});}function Wf(_0x17fae8,_0x450def){const _0x4becaa=(_0x450def==null?void 0x0:_0x450def['persistence'])||[],_0x25be00=(Array['isArray'](_0x4becaa)?_0x4becaa:[_0x4becaa])['map'](ie);_0x450def!=null&&_0x450def['errorMap']&&_0x17fae8['_updateErrorMap'](_0x450def['errorMap']),_0x17fae8['_initializeWithPersistence'](_0x25be00,_0x450def==null?void 0x0:_0x450def['popupRedirectResolver']);}function Bf(_0x5a1afa,_0x1f84ce,_0x2b3475){const _0x607925=qe(_0x5a1afa);m(/^https?:\/\//['test'](_0x1f84ce),_0x607925,'invalid-emulator-scheme');const _0x4f6dab=!0x1,_0x945231=Ua(_0x1f84ce),{host:_0x313519,port:_0x481093}=Vf(_0x1f84ce),_0x4584ba=_0x481093===null?'':':'+_0x481093,_0x5018cc={'url':_0x945231+'//'+_0x313519+_0x4584ba+'/'},_0x3bc5f8=Object['freeze']({'host':_0x313519,'port':_0x481093,'protocol':_0x945231['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x4f6dab})});if(!_0x607925['_canInitEmulator']){m(_0x607925['config']['emulator']&&_0x607925['emulatorConfig'],_0x607925,'emulator-config-failed'),m(Me(_0x5018cc,_0x607925['config']['emulator'])&&Me(_0x3bc5f8,_0x607925['emulatorConfig']),_0x607925,'emulator-config-failed');return;}_0x607925['config']['emulator']=_0x5018cc,_0x607925['emulatorConfig']=_0x3bc5f8,_0x607925['settings']['appVerificationDisabledForTesting']=!0x0,at(_0x313519)?(jr(_0x945231+'//'+_0x313519+_0x4584ba),Kr('Auth',!0x0)):Hf();}function Ua(_0x1c3d81){const _0x37a9b6=_0x1c3d81['indexOf'](':');return _0x37a9b6<0x0?'':_0x1c3d81['substr'](0x0,_0x37a9b6+0x1);}function Vf(_0x1bb6ad){const _0x317e29=Ua(_0x1bb6ad),_0x353d94=/(\/\/)?([^?#/]+)/['exec'](_0x1bb6ad['substr'](_0x317e29['length']));if(!_0x353d94)return{'host':'','port':null};const _0x513592=_0x353d94[0x2]['split']('@')['pop']()||'',_0xcde3eb=/^(\[[^\]]+\])(:|$)/['exec'](_0x513592);if(_0xcde3eb){const _0x349440=_0xcde3eb[0x1];return{'host':_0x349440,'port':kr(_0x513592['substr'](_0x349440['length']+0x1))};}else{const [_0x943b5b,_0xf1b013]=_0x513592['split'](':');return{'host':_0x943b5b,'port':kr(_0xf1b013)};}}function kr(_0x8d48c6){if(!_0x8d48c6)return null;const _0x39ebda=Number(_0x8d48c6);return isNaN(_0x39ebda)?null:_0x39ebda;}function Hf(){function _0x42825b(){const _0x578cf0=document['createElement']('p'),_0x43ae51=_0x578cf0['style'];_0x578cf0['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x43ae51['position']='fixed',_0x43ae51['width']='100%',_0x43ae51['backgroundColor']='#ffffff',_0x43ae51['border']='.1em\x20solid\x20#000000',_0x43ae51['color']='#b50000',_0x43ae51['bottom']='0px',_0x43ae51['left']='0px',_0x43ae51['margin']='0px',_0x43ae51['zIndex']='10000',_0x43ae51['textAlign']='center',_0x578cf0['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x578cf0);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x42825b):_0x42825b());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x102f03,_0x14412e){this['providerId']=_0x102f03,this['signInMethod']=_0x14412e;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x3da6ca){return ne('not\x20implemented');}['_linkToIdToken'](_0x5a4577,_0x3e9091){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x59f6e5){return ne('not\x20implemented');}}async function $f(_0x36040b,_0x2dc21e){return Ae(_0x36040b,'POST','/v1/accounts:signUp',_0x2dc21e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Gf(_0x55cad9,_0xe613ae){return Qt(_0x55cad9,'POST','/v1/accounts:signInWithPassword',Re(_0x55cad9,_0xe613ae));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function qf(_0x581207,_0x559778){return Qt(_0x581207,'POST','/v1/accounts:signInWithEmailLink',Re(_0x581207,_0x559778));}async function zf(_0x3ab138,_0x520096){return Qt(_0x3ab138,'POST','/v1/accounts:signInWithEmailLink',Re(_0x3ab138,_0x520096));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wt extends bs{constructor(_0x186efd,_0x43093b,_0x3d464e,_0x1ab109=null){super('password',_0x3d464e),this['_email']=_0x186efd,this['_password']=_0x43093b,this['_tenantId']=_0x1ab109;}static['_fromEmailAndPassword'](_0xfef958,_0x427dbb){return new Wt(_0xfef958,_0x427dbb,'password');}static['_fromEmailAndCode'](_0x3478a4,_0x57fa5c,_0x3f1251=null){return new Wt(_0x3478a4,_0x57fa5c,'emailLink',_0x3f1251);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x2a2262){const _0x14f577=typeof _0x2a2262=='string'?JSON['parse'](_0x2a2262):_0x2a2262;if(_0x14f577!=null&&_0x14f577['email']&&(_0x14f577!=null&&_0x14f577['password'])){if(_0x14f577['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x14f577['email'],_0x14f577['password']);if(_0x14f577['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x14f577['email'],_0x14f577['password'],_0x14f577['tenantId']);}return null;}async['_getIdTokenResponse'](_0xe3d90){switch(this['signInMethod']){case'password':const _0x53cccd={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0xe3d90,_0x53cccd,'signInWithPassword',Gf);case'emailLink':return qf(_0xe3d90,{'email':this['_email'],'oobCode':this['_password']});default:Q(_0xe3d90,'internal-error');}}async['_linkToIdToken'](_0x1b2b36,_0x1652a6){switch(this['signInMethod']){case'password':const _0x126acc={'idToken':_0x1652a6,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x1b2b36,_0x126acc,'signUpPassword',$f);case'emailLink':return zf(_0x1b2b36,{'idToken':_0x1652a6,'email':this['_email'],'oobCode':this['_password']});default:Q(_0x1b2b36,'internal-error');}}['_getReauthenticationResolver'](_0x50c41c){return this['_getIdTokenResponse'](_0x50c41c);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xe(_0x2453a5,_0x581377){return Qt(_0x2453a5,'POST','/v1/accounts:signInWithIdp',Re(_0x2453a5,_0x581377));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jf='http://localhost';class Be extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x1d437a){const _0xc15cae=new Be(_0x1d437a['providerId'],_0x1d437a['signInMethod']);return _0x1d437a['idToken']||_0x1d437a['accessToken']?(_0x1d437a['idToken']&&(_0xc15cae['idToken']=_0x1d437a['idToken']),_0x1d437a['accessToken']&&(_0xc15cae['accessToken']=_0x1d437a['accessToken']),_0x1d437a['nonce']&&!_0x1d437a['pendingToken']&&(_0xc15cae['nonce']=_0x1d437a['nonce']),_0x1d437a['pendingToken']&&(_0xc15cae['pendingToken']=_0x1d437a['pendingToken'])):_0x1d437a['oauthToken']&&_0x1d437a['oauthTokenSecret']?(_0xc15cae['accessToken']=_0x1d437a['oauthToken'],_0xc15cae['secret']=_0x1d437a['oauthTokenSecret']):Q('argument-error'),_0xc15cae;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x4d17a3){const _0x37250b=typeof _0x4d17a3=='string'?JSON['parse'](_0x4d17a3):_0x4d17a3,{providerId:_0x360048,signInMethod:_0x49b86d,..._0x332403}=_0x37250b;if(!_0x360048||!_0x49b86d)return null;const _0x96e870=new Be(_0x360048,_0x49b86d);return _0x96e870['idToken']=_0x332403['idToken']||void 0x0,_0x96e870['accessToken']=_0x332403['accessToken']||void 0x0,_0x96e870['secret']=_0x332403['secret'],_0x96e870['nonce']=_0x332403['nonce'],_0x96e870['pendingToken']=_0x332403['pendingToken']||null,_0x96e870;}['_getIdTokenResponse'](_0x3c77c6){const _0x3adcc=this['buildRequest']();return Xe(_0x3c77c6,_0x3adcc);}['_linkToIdToken'](_0x1009f2,_0xe4e20b){const _0x55deaf=this['buildRequest']();return _0x55deaf['idToken']=_0xe4e20b,Xe(_0x1009f2,_0x55deaf);}['_getReauthenticationResolver'](_0x496975){const _0x4cdb29=this['buildRequest']();return _0x4cdb29['autoCreate']=!0x1,Xe(_0x496975,_0x4cdb29);}['buildRequest'](){const _0x291e75={'requestUri':jf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x291e75['pendingToken']=this['pendingToken'];else{const _0x33aa57={};this['idToken']&&(_0x33aa57['id_token']=this['idToken']),this['accessToken']&&(_0x33aa57['access_token']=this['accessToken']),this['secret']&&(_0x33aa57['oauth_token_secret']=this['secret']),_0x33aa57['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x33aa57['nonce']=this['nonce']),_0x291e75['postBody']=ct(_0x33aa57);}return _0x291e75;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Kf(_0x3bb782){switch(_0x3bb782){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Yf(_0x3106b6){const _0x3d6029=vt(Et(_0x3106b6))['link'],_0x280aeb=_0x3d6029?vt(Et(_0x3d6029))['deep_link_id']:null,_0xc8b9e1=vt(Et(_0x3106b6))['deep_link_id'];return(_0xc8b9e1?vt(Et(_0xc8b9e1))['link']:null)||_0xc8b9e1||_0x280aeb||_0x3d6029||_0x3106b6;}class Rs{constructor(_0x5b40eb){const _0x314c67=vt(Et(_0x5b40eb)),_0x194ac3=_0x314c67['apiKey']??null,_0x1f93e5=_0x314c67['oobCode']??null,_0x1003f7=Kf(_0x314c67['mode']??null);m(_0x194ac3&&_0x1f93e5&&_0x1003f7,'argument-error'),this['apiKey']=_0x194ac3,this['operation']=_0x1003f7,this['code']=_0x1f93e5,this['continueUrl']=_0x314c67['continueUrl']??null,this['languageCode']=_0x314c67['lang']??null,this['tenantId']=_0x314c67['tenantId']??null;}static['parseLink'](_0x4f530f){const _0x525098=Yf(_0x4f530f);try{return new Rs(_0x525098);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pt{constructor(){this['providerId']=pt['PROVIDER_ID'];}static['credential'](_0x13c110,_0xf42864){return Wt['_fromEmailAndPassword'](_0x13c110,_0xf42864);}static['credentialWithLink'](_0x1721ec,_0x222e79){const _0x58d9c6=Rs['parseLink'](_0x222e79);return m(_0x58d9c6,'argument-error'),Wt['_fromEmailAndCode'](_0x1721ec,_0x58d9c6['code'],_0x58d9c6['tenantId']);}}pt['PROVIDER_ID']='password',pt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',pt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x594256){this['providerId']=_0x594256,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x2377df){this['defaultLanguageCode']=_0x2377df;}['setCustomParameters'](_0x5afd79){return this['customParameters']=_0x5afd79,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jt extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x4cc992){return this['scopes']['includes'](_0x4cc992)||this['scopes']['push'](_0x4cc992),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Jt{constructor(){super('facebook.com');}static['credential'](_0x3dcc18){return Be['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x3dcc18});}static['credentialFromResult'](_0x5edecd){return he['credentialFromTaggedObject'](_0x5edecd);}static['credentialFromError'](_0x42a698){return he['credentialFromTaggedObject'](_0x42a698['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x294b82}){if(!_0x294b82||!('oauthAccessToken'in _0x294b82)||!_0x294b82['oauthAccessToken'])return null;try{return he['credential'](_0x294b82['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Jt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x5d9c02,_0x49d6cf){return Be['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x5d9c02,'accessToken':_0x49d6cf});}static['credentialFromResult'](_0x116983){return ue['credentialFromTaggedObject'](_0x116983);}static['credentialFromError'](_0x191627){return ue['credentialFromTaggedObject'](_0x191627['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x47050c}){if(!_0x47050c)return null;const {oauthIdToken:_0x53c0de,oauthAccessToken:_0x4b2f6c}=_0x47050c;if(!_0x53c0de&&!_0x4b2f6c)return null;try{return ue['credential'](_0x53c0de,_0x4b2f6c);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Jt{constructor(){super('github.com');}static['credential'](_0x2bda9e){return Be['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x2bda9e});}static['credentialFromResult'](_0x433304){return de['credentialFromTaggedObject'](_0x433304);}static['credentialFromError'](_0x5a4baf){return de['credentialFromTaggedObject'](_0x5a4baf['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x21d6b7}){if(!_0x21d6b7||!('oauthAccessToken'in _0x21d6b7)||!_0x21d6b7['oauthAccessToken'])return null;try{return de['credential'](_0x21d6b7['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Jt{constructor(){super('twitter.com');}static['credential'](_0x51ffdc,_0x4345d9){return Be['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x51ffdc,'oauthTokenSecret':_0x4345d9});}static['credentialFromResult'](_0x413251){return fe['credentialFromTaggedObject'](_0x413251);}static['credentialFromError'](_0x43321d){return fe['credentialFromTaggedObject'](_0x43321d['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x10bfca}){if(!_0x10bfca)return null;const {oauthAccessToken:_0x46e52e,oauthTokenSecret:_0x53b605}=_0x10bfca;if(!_0x46e52e||!_0x53b605)return null;try{return fe['credential'](_0x46e52e,_0x53b605);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Qf(_0x117785,_0x3887dd){return Qt(_0x117785,'POST','/v1/accounts:signUp',Re(_0x117785,_0x3887dd));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(_0x47f3b1){this['user']=_0x47f3b1['user'],this['providerId']=_0x47f3b1['providerId'],this['_tokenResponse']=_0x47f3b1['_tokenResponse'],this['operationType']=_0x47f3b1['operationType'];}static async['_fromIdTokenResponse'](_0x52196f,_0x20c447,_0x4bdfd3,_0x51e77e=!0x1){const _0x5033e3=await K['_fromIdTokenResponse'](_0x52196f,_0x4bdfd3,_0x51e77e),_0x5e0bf5=Nr(_0x4bdfd3);return new Ve({'user':_0x5033e3,'providerId':_0x5e0bf5,'_tokenResponse':_0x4bdfd3,'operationType':_0x20c447});}static async['_forOperation'](_0x438d0e,_0x406f4b,_0x6f6b40){await _0x438d0e['_updateTokensIfNecessary'](_0x6f6b40,!0x0);const _0x507fdf=Nr(_0x6f6b40);return new Ve({'user':_0x438d0e,'providerId':_0x507fdf,'_tokenResponse':_0x6f6b40,'operationType':_0x406f4b});}}function Nr(_0x16ac75){return _0x16ac75['providerId']?_0x16ac75['providerId']:'phoneNumber'in _0x16ac75?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class An extends Se{constructor(_0x564a1a,_0x58b77f,_0x187a34,_0x29466e){super(_0x58b77f['code'],_0x58b77f['message']),this['operationType']=_0x187a34,this['user']=_0x29466e,Object['setPrototypeOf'](this,An['prototype']),this['customData']={'appName':_0x564a1a['name'],'tenantId':_0x564a1a['tenantId']??void 0x0,'_serverResponse':_0x58b77f['customData']['_serverResponse'],'operationType':_0x187a34};}static['_fromErrorAndOperation'](_0x48b738,_0x2246fb,_0x114897,_0x59d927){return new An(_0x48b738,_0x2246fb,_0x114897,_0x59d927);}}function Ba(_0x573f99,_0x27f445,_0x4c6e12,_0x58f636){return(_0x27f445==='reauthenticate'?_0x4c6e12['_getReauthenticationResolver'](_0x573f99):_0x4c6e12['_getIdTokenResponse'](_0x573f99))['catch'](_0x464cd2=>{throw _0x464cd2['code']==='auth/multi-factor-auth-required'?An['_fromErrorAndOperation'](_0x573f99,_0x464cd2,_0x27f445,_0x58f636):_0x464cd2;});}async function Jf(_0x18dba9,_0x5cae0d,_0x46cacb=!0x1){const _0x3d21e0=await Ut(_0x18dba9,_0x5cae0d['_linkToIdToken'](_0x18dba9['auth'],await _0x18dba9['getIdToken']()),_0x46cacb);return Ve['_forOperation'](_0x18dba9,'link',_0x3d21e0);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xf(_0x26ef07,_0x28a631,_0x201fae=!0x1){const {auth:_0x42eebf}=_0x26ef07;if($(_0x42eebf['app']))return Promise['reject'](re(_0x42eebf));const _0xd7cf2='reauthenticate';try{const _0x3503a4=await Ut(_0x26ef07,Ba(_0x42eebf,_0xd7cf2,_0x28a631,_0x26ef07),_0x201fae);m(_0x3503a4['idToken'],_0x42eebf,'internal-error');const _0x52578c=Ts(_0x3503a4['idToken']);m(_0x52578c,_0x42eebf,'internal-error');const {sub:_0x40ab6c}=_0x52578c;return m(_0x26ef07['uid']===_0x40ab6c,_0x42eebf,'user-mismatch'),Ve['_forOperation'](_0x26ef07,_0xd7cf2,_0x3503a4);}catch(_0x5a1b3f){throw(_0x5a1b3f==null?void 0x0:_0x5a1b3f['code'])==='auth/user-not-found'&&Q(_0x42eebf,'user-mismatch'),_0x5a1b3f;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x181cba,_0x505843,_0x4a0d81=!0x1){if($(_0x181cba['app']))return Promise['reject'](re(_0x181cba));const _0x486ae6='signIn',_0x2b57be=await Ba(_0x181cba,_0x486ae6,_0x505843),_0x4584fe=await Ve['_fromIdTokenResponse'](_0x181cba,_0x486ae6,_0x2b57be);return _0x4a0d81||await _0x181cba['_updateCurrentUser'](_0x4584fe['user']),_0x4584fe;}async function Zf(_0x52e49f,_0x32fca3){return Va(qe(_0x52e49f),_0x32fca3);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x4b0e40){const _0x2841c3=qe(_0x4b0e40);_0x2841c3['_getPasswordPolicyInternal']()&&await _0x2841c3['_updatePasswordPolicy']();}async function P_(_0x487599,_0x55af13,_0x1810cb){if($(_0x487599['app']))return Promise['reject'](re(_0x487599));const _0x34efed=qe(_0x487599),_0x1794fd=await Di(_0x34efed,{'returnSecureToken':!0x0,'email':_0x55af13,'password':_0x1810cb,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Qf)['catch'](_0x4240db=>{throw _0x4240db['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x487599),_0x4240db;}),_0x42362f=await Ve['_fromIdTokenResponse'](_0x34efed,'signIn',_0x1794fd);return await _0x34efed['_updateCurrentUser'](_0x42362f['user']),_0x42362f;}function O_(_0xd0f07e,_0x116e94,_0x269684){return $(_0xd0f07e['app'])?Promise['reject'](re(_0xd0f07e)):Zf(N(_0xd0f07e),pt['credential'](_0x116e94,_0x269684))['catch'](async _0x5d482e=>{throw _0x5d482e['code']==='auth/password-does-not-meet-requirements'&&Ha(_0xd0f07e),_0x5d482e;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function D_(_0x4ec70c,_0x2f4ed6){return N(_0x4ec70c)['setPersistence'](_0x2f4ed6);}function ep(_0x3c4cb0,_0x155bda,_0x5a854c,_0x35d587){return N(_0x3c4cb0)['onIdTokenChanged'](_0x155bda,_0x5a854c,_0x35d587);}function tp(_0x492b0c,_0x41c264,_0x2f8b6b){return N(_0x492b0c)['beforeAuthStateChanged'](_0x41c264,_0x2f8b6b);}function M_(_0x510eb7,_0x1cec83,_0x116e31,_0x19d11d){return N(_0x510eb7)['onAuthStateChanged'](_0x1cec83,_0x116e31,_0x19d11d);}function L_(_0x37b8e0){return N(_0x37b8e0)['signOut']();}const kn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x4c8b12,_0x24705c){this['storageRetriever']=_0x4c8b12,this['type']=_0x24705c;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](kn,'1'),this['storage']['removeItem'](kn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x57bf7f,_0x1e5138){return this['storage']['setItem'](_0x57bf7f,JSON['stringify'](_0x1e5138)),Promise['resolve']();}['_get'](_0x362d0a){const _0x2505e0=this['storage']['getItem'](_0x362d0a);return Promise['resolve'](_0x2505e0?JSON['parse'](_0x2505e0):null);}['_remove'](_0x35bef7){return this['storage']['removeItem'](_0x35bef7),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const np=0x3e8,ip=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x67fd14,_0x32b2cf)=>this['onStorageEvent'](_0x67fd14,_0x32b2cf),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x323c39){for(const _0x283f22 of Object['keys'](this['listeners'])){const _0x594a8a=this['storage']['getItem'](_0x283f22),_0xee090=this['localCache'][_0x283f22];_0x594a8a!==_0xee090&&_0x323c39(_0x283f22,_0xee090,_0x594a8a);}}['onStorageEvent'](_0x532d94,_0x117eaf=!0x1){if(!_0x532d94['key']){this['forAllChangedKeys']((_0x1ed60c,_0x1892c4,_0x512dd7)=>{this['notifyListeners'](_0x1ed60c,_0x512dd7);});return;}const _0x43ef2e=_0x532d94['key'];_0x117eaf?this['detachListener']():this['stopPolling']();const _0x3f6e4d=()=>{const _0x1bd408=this['storage']['getItem'](_0x43ef2e);!_0x117eaf&&this['localCache'][_0x43ef2e]===_0x1bd408||this['notifyListeners'](_0x43ef2e,_0x1bd408);},_0x55b1e9=this['storage']['getItem'](_0x43ef2e);Tf()&&_0x55b1e9!==_0x532d94['newValue']&&_0x532d94['newValue']!==_0x532d94['oldValue']?setTimeout(_0x3f6e4d,ip):_0x3f6e4d();}['notifyListeners'](_0x54d51c,_0x4ca869){this['localCache'][_0x54d51c]=_0x4ca869;const _0x21c018=this['listeners'][_0x54d51c];if(_0x21c018){for(const _0x29f90f of Array['from'](_0x21c018))_0x29f90f(_0x4ca869&&JSON['parse'](_0x4ca869));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x4f4321,_0x1d3728,_0x3aa61a)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x4f4321,'oldValue':_0x1d3728,'newValue':_0x3aa61a}),!0x0);});},np);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x1b06ff,_0x431aaf){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x1b06ff]||(this['listeners'][_0x1b06ff]=new Set(),this['localCache'][_0x1b06ff]=this['storage']['getItem'](_0x1b06ff)),this['listeners'][_0x1b06ff]['add'](_0x431aaf);}['_removeListener'](_0x2898ae,_0x4d53f8){this['listeners'][_0x2898ae]&&(this['listeners'][_0x2898ae]['delete'](_0x4d53f8),this['listeners'][_0x2898ae]['size']===0x0&&delete this['listeners'][_0x2898ae]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x3c45d1,_0xbf64bd){await super['_set'](_0x3c45d1,_0xbf64bd),this['localCache'][_0x3c45d1]=JSON['stringify'](_0xbf64bd);}async['_get'](_0x3a1b11){const _0x4507bc=await super['_get'](_0x3a1b11);return this['localCache'][_0x3a1b11]=JSON['stringify'](_0x4507bc),_0x4507bc;}async['_remove'](_0x40c2ba){await super['_remove'](_0x40c2ba),delete this['localCache'][_0x40c2ba];}}Ga['type']='LOCAL';const sp=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x41db45,_0x4d4eb5){}['_removeListener'](_0x5df784,_0x1c9f49){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rp(_0x2bb4df){return Promise['all'](_0x2bb4df['map'](async _0x5607a9=>{try{return{'fulfilled':!0x0,'value':await _0x5607a9};}catch(_0x2c89f1){return{'fulfilled':!0x1,'reason':_0x2c89f1};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kn{constructor(_0x3a3280){this['eventTarget']=_0x3a3280,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x979fdf){const _0x5dca61=this['receivers']['find'](_0x4013bc=>_0x4013bc['isListeningto'](_0x979fdf));if(_0x5dca61)return _0x5dca61;const _0x587ce4=new Kn(_0x979fdf);return this['receivers']['push'](_0x587ce4),_0x587ce4;}['isListeningto'](_0x1a87b6){return this['eventTarget']===_0x1a87b6;}async['handleEvent'](_0x3632e5){const _0x263dd8=_0x3632e5,{eventId:_0x4ee9e8,eventType:_0x13a8b2,data:_0x15e986}=_0x263dd8['data'],_0x5b21e4=this['handlersMap'][_0x13a8b2];if(!(_0x5b21e4!=null&&_0x5b21e4['size']))return;_0x263dd8['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x4ee9e8,'eventType':_0x13a8b2});const _0x551999=Array['from'](_0x5b21e4)['map'](async _0x39e032=>_0x39e032(_0x263dd8['origin'],_0x15e986)),_0x2fa6ad=await rp(_0x551999);_0x263dd8['ports'][0x0]['postMessage']({'status':'done','eventId':_0x4ee9e8,'eventType':_0x13a8b2,'response':_0x2fa6ad});}['_subscribe'](_0x3d3e1d,_0x37d18c){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x3d3e1d]||(this['handlersMap'][_0x3d3e1d]=new Set()),this['handlersMap'][_0x3d3e1d]['add'](_0x37d18c);}['_unsubscribe'](_0x25fab5,_0x273604){this['handlersMap'][_0x25fab5]&&_0x273604&&this['handlersMap'][_0x25fab5]['delete'](_0x273604),(!_0x273604||this['handlersMap'][_0x25fab5]['size']===0x0)&&delete this['handlersMap'][_0x25fab5],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Kn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x191bfc='',_0x2c9d13=0xa){let _0x46349c='';for(let _0x2898c8=0x0;_0x2898c8<_0x2c9d13;_0x2898c8++)_0x46349c+=Math['floor'](Math['random']()*0xa);return _0x191bfc+_0x46349c;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class op{constructor(_0x3726f6){this['target']=_0x3726f6,this['handlers']=new Set();}['removeMessageHandler'](_0x192db5){_0x192db5['messageChannel']&&(_0x192db5['messageChannel']['port1']['removeEventListener']('message',_0x192db5['onMessage']),_0x192db5['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x192db5);}async['_send'](_0x2859ae,_0xe2b2d0,_0x2b6e9a=0x32){const _0x4ca4ce=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x4ca4ce)throw new Error('connection_unavailable');let _0x14586c,_0x57c796;return new Promise((_0x55b640,_0x515624)=>{const _0x3ae94e=As('',0x14);_0x4ca4ce['port1']['start']();const _0x5835e0=setTimeout(()=>{_0x515624(new Error('unsupported_event'));},_0x2b6e9a);_0x57c796={'messageChannel':_0x4ca4ce,'onMessage'(_0x386eec){const _0x40a13f=_0x386eec;if(_0x40a13f['data']['eventId']===_0x3ae94e)switch(_0x40a13f['data']['status']){case'ack':clearTimeout(_0x5835e0),_0x14586c=setTimeout(()=>{_0x515624(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x14586c),_0x55b640(_0x40a13f['data']['response']);break;default:clearTimeout(_0x5835e0),clearTimeout(_0x14586c),_0x515624(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x57c796),_0x4ca4ce['port1']['addEventListener']('message',_0x57c796['onMessage']),this['target']['postMessage']({'eventType':_0x2859ae,'eventId':_0x3ae94e,'data':_0xe2b2d0},[_0x4ca4ce['port2']]);})['finally'](()=>{_0x57c796&&this['removeMessageHandler'](_0x57c796);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function ap(_0x4e7204){Z()['location']['href']=_0x4e7204;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function cp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function lp(){var _0x537c22;return((_0x537c22=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x537c22['controller'])||null;}function hp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',up=0x1,Nn='firebaseLocalStorage',Ya='fbase_key';class Xt{constructor(_0x54b82c){this['request']=_0x54b82c;}['toPromise'](){return new Promise((_0x33901d,_0x5ab379)=>{this['request']['addEventListener']('success',()=>{_0x33901d(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x5ab379(this['request']['error']);});});}}function Yn(_0x2b0a8f,_0x17167d){return _0x2b0a8f['transaction']([Nn],_0x17167d?'readwrite':'readonly')['objectStore'](Nn);}function dp(){const _0x423619=indexedDB['deleteDatabase'](Ka);return new Xt(_0x423619)['toPromise']();}function Mi(){const _0xc0ee32=indexedDB['open'](Ka,up);return new Promise((_0x289732,_0x542015)=>{_0xc0ee32['addEventListener']('error',()=>{_0x542015(_0xc0ee32['error']);}),_0xc0ee32['addEventListener']('upgradeneeded',()=>{const _0x338f52=_0xc0ee32['result'];try{_0x338f52['createObjectStore'](Nn,{'keyPath':Ya});}catch(_0x3f7f7a){_0x542015(_0x3f7f7a);}}),_0xc0ee32['addEventListener']('success',async()=>{const _0x5005e9=_0xc0ee32['result'];_0x5005e9['objectStoreNames']['contains'](Nn)?_0x289732(_0x5005e9):(_0x5005e9['close'](),await dp(),_0x289732(await Mi()));});});}async function Pr(_0x1f2d93,_0x3e78dd,_0x2b86fa){const _0x295f75=Yn(_0x1f2d93,!0x0)['put']({[Ya]:_0x3e78dd,'value':_0x2b86fa});return new Xt(_0x295f75)['toPromise']();}async function fp(_0x1fe53a,_0x5545be){const _0x5dfef9=Yn(_0x1fe53a,!0x1)['get'](_0x5545be),_0x27c79a=await new Xt(_0x5dfef9)['toPromise']();return _0x27c79a===void 0x0?null:_0x27c79a['value'];}function Or(_0x2dda23,_0x14d386){const _0x5d861d=Yn(_0x2dda23,!0x0)['delete'](_0x14d386);return new Xt(_0x5d861d)['toPromise']();}const pp=0x320,_p=0x3;class Qa{constructor(){this['type']='LOCAL',this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['db']?this['db']:(this['db']=await Mi(),this['db']);}async['_withRetries'](_0x53d57f){let _0x510d53=0x0;for(;;)try{const _0x42ffe7=await this['_openDb']();return await _0x53d57f(_0x42ffe7);}catch(_0x57dc95){if(_0x510d53++>_p)throw _0x57dc95;this['db']&&(this['db']['close'](),this['db']=void 0x0);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Kn['_getInstance'](hp()),this['receiver']['_subscribe']('keyChanged',async(_0xaef644,_0x557f41)=>({'keyProcessed':(await this['_poll']())['includes'](_0x557f41['key'])})),this['receiver']['_subscribe']('ping',async(_0x861286,_0x7864e5)=>['keyChanged']);}async['initializeSender'](){var _0x2b260d,_0x2979fb;if(this['activeServiceWorker']=await cp(),!this['activeServiceWorker'])return;this['sender']=new op(this['activeServiceWorker']);const _0x36b814=await this['sender']['_send']('ping',{},0x320);_0x36b814&&(_0x2b260d=_0x36b814[0x0])!=null&&_0x2b260d['fulfilled']&&(_0x2979fb=_0x36b814[0x0])!=null&&_0x2979fb['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x377bc9){if(!(!this['sender']||!this['activeServiceWorker']||lp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x377bc9},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{if(!indexedDB)return!0x1;const _0x3c77cc=await Mi();return await Pr(_0x3c77cc,kn,'1'),await Or(_0x3c77cc,kn),!0x0;}catch{}return!0x1;}async['_withPendingWrite'](_0xd043df){this['pendingWrites']++;try{await _0xd043df();}finally{this['pendingWrites']--;}}async['_set'](_0x11dabc,_0x5087fc){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x24f0f4=>Pr(_0x24f0f4,_0x11dabc,_0x5087fc)),this['localCache'][_0x11dabc]=_0x5087fc,this['notifyServiceWorker'](_0x11dabc)));}async['_get'](_0x42a3b9){const _0x3faeb0=await this['_withRetries'](_0x113b95=>fp(_0x113b95,_0x42a3b9));return this['localCache'][_0x42a3b9]=_0x3faeb0,_0x3faeb0;}async['_remove'](_0x5f3457){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x581c5e=>Or(_0x581c5e,_0x5f3457)),delete this['localCache'][_0x5f3457],this['notifyServiceWorker'](_0x5f3457)));}async['_poll'](){const _0x51d0ca=await this['_withRetries'](_0x2c2388=>{const _0x8a4432=Yn(_0x2c2388,!0x1)['getAll']();return new Xt(_0x8a4432)['toPromise']();});if(!_0x51d0ca)return[];if(this['pendingWrites']!==0x0)return[];const _0x4149db=[],_0x108977=new Set();if(_0x51d0ca['length']!==0x0){for(const {fbase_key:_0x58e2bd,value:_0x3ba8ec}of _0x51d0ca)_0x108977['add'](_0x58e2bd),JSON['stringify'](this['localCache'][_0x58e2bd])!==JSON['stringify'](_0x3ba8ec)&&(this['notifyListeners'](_0x58e2bd,_0x3ba8ec),_0x4149db['push'](_0x58e2bd));}for(const _0x3ccf6a of Object['keys'](this['localCache']))this['localCache'][_0x3ccf6a]&&!_0x108977['has'](_0x3ccf6a)&&(this['notifyListeners'](_0x3ccf6a,null),_0x4149db['push'](_0x3ccf6a));return _0x4149db;}['notifyListeners'](_0x5a4ef8,_0x3ceba6){this['localCache'][_0x5a4ef8]=_0x3ceba6;const _0x10cabd=this['listeners'][_0x5a4ef8];if(_0x10cabd){for(const _0x12b318 of Array['from'](_0x10cabd))_0x12b318(_0x3ceba6);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),pp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x5d1604,_0x412e9b){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x5d1604]||(this['listeners'][_0x5d1604]=new Set(),this['_get'](_0x5d1604)),this['listeners'][_0x5d1604]['add'](_0x412e9b);}['_removeListener'](_0x3e6f5a,_0x534384){this['listeners'][_0x3e6f5a]&&(this['listeners'][_0x3e6f5a]['delete'](_0x534384),this['listeners'][_0x3e6f5a]['size']===0x0&&delete this['listeners'][_0x3e6f5a]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Qa['type']='LOCAL';const gp=Qa;new Yt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function mp(_0x2ab7b0,_0x1ddcff){return _0x1ddcff?ie(_0x1ddcff):(m(_0x2ab7b0['_popupRedirectResolver'],_0x2ab7b0,'argument-error'),_0x2ab7b0['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x568839){super('custom','custom'),this['params']=_0x568839;}['_getIdTokenResponse'](_0xd99ba4){return Xe(_0xd99ba4,this['_buildIdpRequest']());}['_linkToIdToken'](_0x1dc698,_0x415c87){return Xe(_0x1dc698,this['_buildIdpRequest'](_0x415c87));}['_getReauthenticationResolver'](_0x29b013){return Xe(_0x29b013,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x45381d){const _0x596b97={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x45381d&&(_0x596b97['idToken']=_0x45381d),_0x596b97;}}function yp(_0x294222){return Va(_0x294222['auth'],new ks(_0x294222),_0x294222['bypassAuthState']);}function vp(_0x5de996){const {auth:_0xca2e9e,user:_0x89f31f}=_0x5de996;return m(_0x89f31f,_0xca2e9e,'internal-error'),Xf(_0x89f31f,new ks(_0x5de996),_0x5de996['bypassAuthState']);}async function Ep(_0x7df870){const {auth:_0x388442,user:_0xb700af}=_0x7df870;return m(_0xb700af,_0x388442,'internal-error'),Jf(_0xb700af,new ks(_0x7df870),_0x7df870['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ja{constructor(_0x2a6458,_0x2c97f4,_0x24bb63,_0x222dc3,_0x44efb1=!0x1){this['auth']=_0x2a6458,this['resolver']=_0x24bb63,this['user']=_0x222dc3,this['bypassAuthState']=_0x44efb1,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x2c97f4)?_0x2c97f4:[_0x2c97f4];}['execute'](){return new Promise(async(_0x430a33,_0x11ce46)=>{this['pendingPromise']={'resolve':_0x430a33,'reject':_0x11ce46};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x714d1b){this['reject'](_0x714d1b);}});}async['onAuthEvent'](_0x1b662a){const {urlResponse:_0x2937d4,sessionId:_0x1cac19,postBody:_0x20cc32,tenantId:_0x1aebc7,error:_0x35a015,type:_0x18908c}=_0x1b662a;if(_0x35a015){this['reject'](_0x35a015);return;}const _0x3c0486={'auth':this['auth'],'requestUri':_0x2937d4,'sessionId':_0x1cac19,'tenantId':_0x1aebc7||void 0x0,'postBody':_0x20cc32||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x18908c)(_0x3c0486));}catch(_0x2f2521){this['reject'](_0x2f2521);}}['onError'](_0x36c288){this['reject'](_0x36c288);}['getIdpTask'](_0x567e1b){switch(_0x567e1b){case'signInViaPopup':case'signInViaRedirect':return yp;case'linkViaPopup':case'linkViaRedirect':return Ep;case'reauthViaPopup':case'reauthViaRedirect':return vp;default:Q(this['auth'],'internal-error');}}['resolve'](_0x1266a0){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x1266a0),this['unregisterAndCleanUp']();}['reject'](_0x236c30){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x236c30),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ip=new Yt(0x7d0,0x2710);class Ke extends Ja{constructor(_0x30d7a5,_0x4d6493,_0x11887e,_0x6d50bf,_0x23c31b){super(_0x30d7a5,_0x4d6493,_0x6d50bf,_0x23c31b),this['provider']=_0x11887e,this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']&&Ke['currentPopupAction']['cancel'](),Ke['currentPopupAction']=this;}async['executeNotNull'](){const _0x388955=await this['execute']();return m(_0x388955,this['auth'],'internal-error'),_0x388955;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x171b1e=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x171b1e),this['authWindow']['associatedEvent']=_0x171b1e,this['resolver']['_originValidation'](this['auth'])['catch'](_0x583a38=>{this['reject'](_0x583a38);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x51a6bc=>{_0x51a6bc||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x26ec47;return((_0x26ec47=this['authWindow'])==null?void 0x0:_0x26ec47['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']=null;}['pollUserCancellation'](){const _0x354ca5=()=>{var _0x181123,_0x417441;if((_0x417441=(_0x181123=this['authWindow'])==null?void 0x0:_0x181123['window'])!=null&&_0x417441['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x354ca5,Ip['get']());};_0x354ca5();}}Ke['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const wp='pendingRedirect',on=new Map();class Cp extends Ja{constructor(_0x242fa7,_0x36e5a9,_0x1616fc=!0x1){super(_0x242fa7,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x36e5a9,void 0x0,_0x1616fc),this['eventId']=null;}async['execute'](){let _0x3602b7=on['get'](this['auth']['_key']());if(!_0x3602b7){try{const _0x1a8160=await Tp(this['resolver'],this['auth'])?await super['execute']():null;_0x3602b7=()=>Promise['resolve'](_0x1a8160);}catch(_0x57e4ff){_0x3602b7=()=>Promise['reject'](_0x57e4ff);}on['set'](this['auth']['_key'](),_0x3602b7);}return this['bypassAuthState']||on['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x3602b7();}async['onAuthEvent'](_0x4db6f4){if(_0x4db6f4['type']==='signInViaRedirect')return super['onAuthEvent'](_0x4db6f4);if(_0x4db6f4['type']==='unknown'){this['resolve'](null);return;}if(_0x4db6f4['eventId']){const _0xc61ca3=await this['auth']['_redirectUserForId'](_0x4db6f4['eventId']);if(_0xc61ca3)return this['user']=_0xc61ca3,super['onAuthEvent'](_0x4db6f4);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Tp(_0xa89c62,_0x1c8850){const _0x10a70d=Rp(_0x1c8850),_0x101546=bp(_0xa89c62);if(!await _0x101546['_isAvailable']())return!0x1;const _0x498102=await _0x101546['_get'](_0x10a70d)==='true';return await _0x101546['_remove'](_0x10a70d),_0x498102;}function Sp(_0x3ed637,_0xb1ced6){on['set'](_0x3ed637['_key'](),_0xb1ced6);}function bp(_0x173040){return ie(_0x173040['_redirectPersistence']);}function Rp(_0x1f9134){return rn(wp,_0x1f9134['config']['apiKey'],_0x1f9134['name']);}async function Ap(_0x1db807,_0x4c7157,_0x3c91bf=!0x1){if($(_0x1db807['app']))return Promise['reject'](re(_0x1db807));const _0x3e14ac=qe(_0x1db807),_0x4f54d8=mp(_0x3e14ac,_0x4c7157),_0x2eef69=await new Cp(_0x3e14ac,_0x4f54d8,_0x3c91bf)['execute']();return _0x2eef69&&!_0x3c91bf&&(delete _0x2eef69['user']['_redirectEventId'],await _0x3e14ac['_persistUserIfCurrent'](_0x2eef69['user']),await _0x3e14ac['_setRedirectUser'](null,_0x4c7157)),_0x2eef69;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=0x258*0x3e8;class Np{constructor(_0x5a8b91){this['auth']=_0x5a8b91,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x2e654){this['consumers']['add'](_0x2e654),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x2e654)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x2e654),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x1fb983){this['consumers']['delete'](_0x1fb983);}['onEvent'](_0x5c4c97){if(this['hasEventBeenHandled'](_0x5c4c97))return!0x1;let _0x4bbe04=!0x1;return this['consumers']['forEach'](_0x136d25=>{this['isEventForConsumer'](_0x5c4c97,_0x136d25)&&(_0x4bbe04=!0x0,this['sendToConsumer'](_0x5c4c97,_0x136d25),this['saveEventToCache'](_0x5c4c97));}),this['hasHandledPotentialRedirect']||!Pp(_0x5c4c97)||(this['hasHandledPotentialRedirect']=!0x0,_0x4bbe04||(this['queuedRedirectEvent']=_0x5c4c97,_0x4bbe04=!0x0)),_0x4bbe04;}['sendToConsumer'](_0x55aef2,_0x217e72){var _0x617f25;if(_0x55aef2['error']&&!Xa(_0x55aef2)){const _0xf1105f=((_0x617f25=_0x55aef2['error']['code'])==null?void 0x0:_0x617f25['split']('auth/')[0x1])||'internal-error';_0x217e72['onError'](X(this['auth'],_0xf1105f));}else _0x217e72['onAuthEvent'](_0x55aef2);}['isEventForConsumer'](_0x2f17dd,_0xcfa393){const _0x496672=_0xcfa393['eventId']===null||!!_0x2f17dd['eventId']&&_0x2f17dd['eventId']===_0xcfa393['eventId'];return _0xcfa393['filter']['includes'](_0x2f17dd['type'])&&_0x496672;}['hasEventBeenHandled'](_0x4e2ac1){return Date['now']()-this['lastProcessedEventTime']>=kp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Dr(_0x4e2ac1));}['saveEventToCache'](_0x2cc24f){this['cachedEventUids']['add'](Dr(_0x2cc24f)),this['lastProcessedEventTime']=Date['now']();}}function Dr(_0x28a9fb){return[_0x28a9fb['type'],_0x28a9fb['eventId'],_0x28a9fb['sessionId'],_0x28a9fb['tenantId']]['filter'](_0x467e7c=>_0x467e7c)['join']('-');}function Xa({type:_0x1c7f7b,error:_0x2514e1}){return _0x1c7f7b==='unknown'&&(_0x2514e1==null?void 0x0:_0x2514e1['code'])==='auth/no-auth-event';}function Pp(_0x4f52b6){switch(_0x4f52b6['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Xa(_0x4f52b6);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Op(_0x349d68,_0x1a7e5c={}){return Ae(_0x349d68,'GET','/v1/projects',_0x1a7e5c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Mp=/^https?/;async function Lp(_0x20b888){if(_0x20b888['config']['emulator'])return;const {authorizedDomains:_0x566c90}=await Op(_0x20b888);for(const _0x269a4a of _0x566c90)try{if(xp(_0x269a4a))return;}catch{}Q(_0x20b888,'unauthorized-domain');}function xp(_0x23c036){const _0x1b136f=Pi(),{protocol:_0xb6379b,hostname:_0x55ed60}=new URL(_0x1b136f);if(_0x23c036['startsWith']('chrome-extension://')){const _0x25c069=new URL(_0x23c036);return _0x25c069['hostname']===''&&_0x55ed60===''?_0xb6379b==='chrome-extension:'&&_0x23c036['replace']('chrome-extension://','')===_0x1b136f['replace']('chrome-extension://',''):_0xb6379b==='chrome-extension:'&&_0x25c069['hostname']===_0x55ed60;}if(!Mp['test'](_0xb6379b))return!0x1;if(Dp['test'](_0x23c036))return _0x55ed60===_0x23c036;const _0x45b9d7=_0x23c036['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x45b9d7+'|'+_0x45b9d7+')$','i')['test'](_0x55ed60);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Fp=new Yt(0x7530,0xea60);function Mr(){const _0x2f61bd=Z()['___jsl'];if(_0x2f61bd!=null&&_0x2f61bd['H']){for(const _0x13c947 of Object['keys'](_0x2f61bd['H']))if(_0x2f61bd['H'][_0x13c947]['r']=_0x2f61bd['H'][_0x13c947]['r']||[],_0x2f61bd['H'][_0x13c947]['L']=_0x2f61bd['H'][_0x13c947]['L']||[],_0x2f61bd['H'][_0x13c947]['r']=[..._0x2f61bd['H'][_0x13c947]['L']],_0x2f61bd['CP']){for(let _0x3d32c9=0x0;_0x3d32c9<_0x2f61bd['CP']['length'];_0x3d32c9++)_0x2f61bd['CP'][_0x3d32c9]=null;}}}function Up(_0x2cdb6e){return new Promise((_0x5404f9,_0x4ffce0)=>{var _0x470b24,_0x4d9ee2,_0x1a8d9e;function _0x3988b1(){Mr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x5404f9(gapi['iframes']['getContext']());},'ontimeout':()=>{Mr(),_0x4ffce0(X(_0x2cdb6e,'network-request-failed'));},'timeout':Fp['get']()});}if((_0x4d9ee2=(_0x470b24=Z()['gapi'])==null?void 0x0:_0x470b24['iframes'])!=null&&_0x4d9ee2['Iframe'])_0x5404f9(gapi['iframes']['getContext']());else{if((_0x1a8d9e=Z()['gapi'])!=null&&_0x1a8d9e['load'])_0x3988b1();else{const _0x45580a=Df('iframefcb');return Z()[_0x45580a]=()=>{gapi['load']?_0x3988b1():_0x4ffce0(X(_0x2cdb6e,'network-request-failed'));},xa(Of()+'?onload='+_0x45580a)['catch'](_0x114ead=>_0x4ffce0(_0x114ead));}}})['catch'](_0x9bf93a=>{throw an=null,_0x9bf93a;});}let an=null;function Wp(_0x30686b){return an=an||Up(_0x30686b),an;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Yt(0x1388,0x3a98),Vp='__/auth/iframe',Hp='emulator/auth/iframe',$p={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Gp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function qp(_0x57ce3a){const _0x467b9f=_0x57ce3a['config'];m(_0x467b9f['authDomain'],_0x57ce3a,'auth-domain-config-required');const _0x5ef3e7=_0x467b9f['emulator']?Cs(_0x467b9f,Hp):'https://'+_0x57ce3a['config']['authDomain']+'/'+Vp,_0x528964={'apiKey':_0x467b9f['apiKey'],'appName':_0x57ce3a['name'],'v':lt},_0x15e56f=Gp['get'](_0x57ce3a['config']['apiHost']);_0x15e56f&&(_0x528964['eid']=_0x15e56f);const _0x32e1f5=_0x57ce3a['_getFrameworks']();return _0x32e1f5['length']&&(_0x528964['fw']=_0x32e1f5['join'](',')),_0x5ef3e7+'?'+ct(_0x528964)['slice'](0x1);}async function zp(_0x44c339){const _0x225d10=await Wp(_0x44c339),_0x45c731=Z()['gapi'];return m(_0x45c731,_0x44c339,'internal-error'),_0x225d10['open']({'where':document['body'],'url':qp(_0x44c339),'messageHandlersFilter':_0x45c731['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':$p,'dontclear':!0x0},_0x46e82e=>new Promise(async(_0x5d3df6,_0x5bfd76)=>{await _0x46e82e['restyle']({'setHideOnLeave':!0x1});const _0x3e6d44=X(_0x44c339,'network-request-failed'),_0x2e40f7=Z()['setTimeout'](()=>{_0x5bfd76(_0x3e6d44);},Bp['get']());function _0x3c9992(){Z()['clearTimeout'](_0x2e40f7),_0x5d3df6(_0x46e82e);}_0x46e82e['ping'](_0x3c9992)['then'](_0x3c9992,()=>{_0x5bfd76(_0x3e6d44);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Kp=0x1f4,Yp=0x258,Qp='_blank',Jp='http://localhost';class Lr{constructor(_0x3c782e){this['window']=_0x3c782e,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Xp(_0xd2f185,_0x3df230,_0x2f4e6d,_0x1b5b41=Kp,_0xcd4d90=Yp){const _0x9cb328=Math['max']((window['screen']['availHeight']-_0xcd4d90)/0x2,0x0)['toString'](),_0x2bf9ad=Math['max']((window['screen']['availWidth']-_0x1b5b41)/0x2,0x0)['toString']();let _0x39cbb9='';const _0x187021={...jp,'width':_0x1b5b41['toString'](),'height':_0xcd4d90['toString'](),'top':_0x9cb328,'left':_0x2bf9ad},_0x4997af=W()['toLowerCase']();_0x2f4e6d&&(_0x39cbb9=ka(_0x4997af)?Qp:_0x2f4e6d),Ra(_0x4997af)&&(_0x3df230=_0x3df230||Jp,_0x187021['scrollbars']='yes');const _0x2f41d8=Object['entries'](_0x187021)['reduce']((_0x394055,[_0x3ad4f0,_0x24350d])=>''+_0x394055+_0x3ad4f0+'='+_0x24350d+',','');if(Cf(_0x4997af)&&_0x39cbb9!=='_self')return Zp(_0x3df230||'',_0x39cbb9),new Lr(null);const _0x1072fc=window['open'](_0x3df230||'',_0x39cbb9,_0x2f41d8);m(_0x1072fc,_0xd2f185,'popup-blocked');try{_0x1072fc['focus']();}catch{}return new Lr(_0x1072fc);}function Zp(_0x2bb5b2,_0x13c9f1){const _0x5cd437=document['createElement']('a');_0x5cd437['href']=_0x2bb5b2,_0x5cd437['target']=_0x13c9f1;const _0x17c5f7=document['createEvent']('MouseEvent');_0x17c5f7['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x5cd437['dispatchEvent'](_0x17c5f7);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const e_='__/auth/handler',t_='emulator/auth/handler',n_=encodeURIComponent('fac');async function xr(_0x55eed8,_0x45c517,_0x19d216,_0x5d9c74,_0x15d77f,_0x22a749){m(_0x55eed8['config']['authDomain'],_0x55eed8,'auth-domain-config-required'),m(_0x55eed8['config']['apiKey'],_0x55eed8,'invalid-api-key');const _0x4ae283={'apiKey':_0x55eed8['config']['apiKey'],'appName':_0x55eed8['name'],'authType':_0x19d216,'redirectUrl':_0x5d9c74,'v':lt,'eventId':_0x15d77f};if(_0x45c517 instanceof Wa){_0x45c517['setDefaultLanguage'](_0x55eed8['languageCode']),_0x4ae283['providerId']=_0x45c517['providerId']||'',ui(_0x45c517['getCustomParameters']())||(_0x4ae283['customParameters']=JSON['stringify'](_0x45c517['getCustomParameters']()));for(const [_0x2727e7,_0x4dd37f]of Object['entries']({}))_0x4ae283[_0x2727e7]=_0x4dd37f;}if(_0x45c517 instanceof Jt){const _0x49c52c=_0x45c517['getScopes']()['filter'](_0x51b62e=>_0x51b62e!=='');_0x49c52c['length']>0x0&&(_0x4ae283['scopes']=_0x49c52c['join'](','));}_0x55eed8['tenantId']&&(_0x4ae283['tid']=_0x55eed8['tenantId']);const _0x3c2d9c=_0x4ae283;for(const _0x4e616a of Object['keys'](_0x3c2d9c))_0x3c2d9c[_0x4e616a]===void 0x0&&delete _0x3c2d9c[_0x4e616a];const _0x254297=await _0x55eed8['_getAppCheckToken'](),_0x3c2d63=_0x254297?'#'+n_+'='+encodeURIComponent(_0x254297):'';return i_(_0x55eed8)+'?'+ct(_0x3c2d9c)['slice'](0x1)+_0x3c2d63;}function i_({config:_0x565167}){return _0x565167['emulator']?Cs(_0x565167,t_):'https://'+_0x565167['authDomain']+'/'+e_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const hi='webStorageSupport';class s_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Ap,this['_overrideRedirectResult']=Sp;}async['_openPopup'](_0x34ee3e,_0x54e929,_0x5461d1,_0x206135){var _0x3bfda8;ce((_0x3bfda8=this['eventManagers'][_0x34ee3e['_key']()])==null?void 0x0:_0x3bfda8['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x4b2e2b=await xr(_0x34ee3e,_0x54e929,_0x5461d1,Pi(),_0x206135);return Xp(_0x34ee3e,_0x4b2e2b,As());}async['_openRedirect'](_0x42a8d0,_0x5ea7f4,_0x423ea1,_0x35ca12){await this['_originValidation'](_0x42a8d0);const _0x399fb5=await xr(_0x42a8d0,_0x5ea7f4,_0x423ea1,Pi(),_0x35ca12);return ap(_0x399fb5),new Promise(()=>{});}['_initialize'](_0x1714e7){const _0x3ae221=_0x1714e7['_key']();if(this['eventManagers'][_0x3ae221]){const {manager:_0x4bc5ed,promise:_0x24deb3}=this['eventManagers'][_0x3ae221];return _0x4bc5ed?Promise['resolve'](_0x4bc5ed):(ce(_0x24deb3,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x24deb3);}const _0x141dd6=this['initAndGetManager'](_0x1714e7);return this['eventManagers'][_0x3ae221]={'promise':_0x141dd6},_0x141dd6['catch'](()=>{delete this['eventManagers'][_0x3ae221];}),_0x141dd6;}async['initAndGetManager'](_0x3b7229){const _0x2c1d5f=await zp(_0x3b7229),_0x9d2e32=new Np(_0x3b7229);return _0x2c1d5f['register']('authEvent',_0x2fed6c=>(m(_0x2fed6c==null?void 0x0:_0x2fed6c['authEvent'],_0x3b7229,'invalid-auth-event'),{'status':_0x9d2e32['onEvent'](_0x2fed6c['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x3b7229['_key']()]={'manager':_0x9d2e32},this['iframes'][_0x3b7229['_key']()]=_0x2c1d5f,_0x9d2e32;}['_isIframeWebStorageSupported'](_0x8086ab,_0x5cf331){this['iframes'][_0x8086ab['_key']()]['send'](hi,{'type':hi},_0x3cc1cd=>{var _0x261f1f;const _0x4757d7=(_0x261f1f=_0x3cc1cd==null?void 0x0:_0x3cc1cd[0x0])==null?void 0x0:_0x261f1f[hi];_0x4757d7!==void 0x0&&_0x5cf331(!!_0x4757d7),Q(_0x8086ab,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x1509ff){const _0x143a0c=_0x1509ff['_key']();return this['originValidationPromises'][_0x143a0c]||(this['originValidationPromises'][_0x143a0c]=Lp(_0x1509ff)),this['originValidationPromises'][_0x143a0c];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const r_=s_;var Fr='@firebase/auth',Ur='1.11.1';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class o_{constructor(_0x364f21){this['auth']=_0x364f21,this['internalListeners']=new Map();}['getUid'](){var _0x15068d;return this['assertAuthConfigured'](),((_0x15068d=this['auth']['currentUser'])==null?void 0x0:_0x15068d['uid'])||null;}async['getToken'](_0x55b3ad){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x55b3ad)}:null;}['addAuthTokenListener'](_0x4a46a1){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x4a46a1))return;const _0x244a8f=this['auth']['onIdTokenChanged'](_0x17cca9=>{_0x4a46a1((_0x17cca9==null?void 0x0:_0x17cca9['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x4a46a1,_0x244a8f),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x30e467){this['assertAuthConfigured']();const _0x2085e9=this['internalListeners']['get'](_0x30e467);_0x2085e9&&(this['internalListeners']['delete'](_0x30e467),_0x2085e9(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function a_(_0x761d5c){switch(_0x761d5c){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function c_(_0xa63fdd){Ze(new Le('auth',(_0x5c8685,{options:_0x130b06})=>{const _0x2e2c08=_0x5c8685['getProvider']('app')['getImmediate'](),_0x3d4735=_0x5c8685['getProvider']('heartbeat'),_0x1e3bc0=_0x5c8685['getProvider']('app-check-internal'),{apiKey:_0x2bc15f,authDomain:_0x321685}=_0x2e2c08['options'];m(_0x2bc15f&&!_0x2bc15f['includes'](':'),'invalid-api-key',{'appName':_0x2e2c08['name']});const _0xd45e55={'apiKey':_0x2bc15f,'authDomain':_0x321685,'clientPlatform':_0xa63fdd,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0xa63fdd)},_0x4adc25=new kf(_0x2e2c08,_0x3d4735,_0x1e3bc0,_0xd45e55);return Wf(_0x4adc25,_0x130b06),_0x4adc25;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x9442c2,_0x2ad965,_0x5640a9)=>{_0x9442c2['getProvider']('auth-internal')['initialize']();})),Ze(new Le('auth-internal',_0x3e37d8=>{const _0x231059=qe(_0x3e37d8['getProvider']('auth')['getImmediate']());return(_0x2ad5e0=>new o_(_0x2ad5e0))(_0x231059);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Fr,Ur,a_(_0xa63fdd)),me(Fr,Ur,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const l_=0x12c,h_=zr('authIdTokenMaxAge')||l_;let Wr=null;const u_=_0x556ea2=>async _0x28b13e=>{const _0x2a63db=_0x28b13e&&await _0x28b13e['getIdTokenResult'](),_0x49efc1=_0x2a63db&&(new Date()['getTime']()-Date['parse'](_0x2a63db['issuedAtTime']))/0x3e8;if(_0x49efc1&&_0x49efc1>h_)return;const _0x38e759=_0x2a63db==null?void 0x0:_0x2a63db['token'];Wr!==_0x38e759&&(Wr=_0x38e759,await fetch(_0x556ea2,{'method':_0x38e759?'POST':'DELETE','headers':_0x38e759?{'Authorization':'Bearer\x20'+_0x38e759}:{}}));};function x_(_0x330d6a=Zr()){const _0x5809ac=Bi(_0x330d6a,'auth');if(_0x5809ac['isInitialized']())return _0x5809ac['getImmediate']();const _0x5727a7=Uf(_0x330d6a,{'popupRedirectResolver':r_,'persistence':[gp,sp,za]}),_0x139a4e=zr('authTokenSyncURL');if(_0x139a4e&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x4cc8e6=new URL(_0x139a4e,location['origin']);if(location['origin']===_0x4cc8e6['origin']){const _0x1b7478=u_(_0x4cc8e6['toString']());tp(_0x5727a7,_0x1b7478,()=>_0x1b7478(_0x5727a7['currentUser'])),ep(_0x5727a7,_0x1a3369=>_0x1b7478(_0x1a3369));}}const _0x29cf61=Gr('auth');return _0x29cf61&&Bf(_0x5727a7,'http://'+_0x29cf61),_0x5727a7;}function d_(){var _0x3d68f9;return((_0x3d68f9=document['getElementsByTagName']('head'))==null?void 0x0:_0x3d68f9[0x0])??document;}Nf({'loadJS'(_0x58c445){return new Promise((_0xbd6295,_0x7be24f)=>{const _0x32d028=document['createElement']('script');_0x32d028['setAttribute']('src',_0x58c445),_0x32d028['onload']=_0xbd6295,_0x32d028['onerror']=_0x4afe10=>{const _0x225d69=X('internal-error');_0x225d69['customData']=_0x4afe10,_0x7be24f(_0x225d69);},_0x32d028['type']='text/javascript',_0x32d028['charset']='UTF-8',d_()['appendChild'](_0x32d028);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),c_('Browser');export{P_ as A,L_ as B,C_ as C,x_ as a,sp as b,O_ as c,f_ as d,p_ as e,Zr as f,b_ as g,y_ as h,Sl as i,k_ as j,T_ as k,Ft as l,Ud as m,M_ as n,w_ as o,g_ as p,S_ as q,__ as r,D_ as s,A_ as t,m_ as u,R_ as v,N_ as w,E_ as x,v_ as y,I_ as z};