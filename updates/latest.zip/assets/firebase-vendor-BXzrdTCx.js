const Za=()=>{};var Ns={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Br={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x184b86,_0x5cd3e6){if(!_0x184b86)throw rt(_0x5cd3e6);},rt=function(_0x47d738){return new Error('Firebase\x20Database\x20('+Br['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x47d738);},Vr=function(_0x398d3d){const _0x2ff8a3=[];let _0x4dc407=0x0;for(let _0x1a3cb8=0x0;_0x1a3cb8<_0x398d3d['length'];_0x1a3cb8++){let _0x19876f=_0x398d3d['charCodeAt'](_0x1a3cb8);_0x19876f<0x80?_0x2ff8a3[_0x4dc407++]=_0x19876f:_0x19876f<0x800?(_0x2ff8a3[_0x4dc407++]=_0x19876f>>0x6|0xc0,_0x2ff8a3[_0x4dc407++]=_0x19876f&0x3f|0x80):(_0x19876f&0xfc00)===0xd800&&_0x1a3cb8+0x1<_0x398d3d['length']&&(_0x398d3d['charCodeAt'](_0x1a3cb8+0x1)&0xfc00)===0xdc00?(_0x19876f=0x10000+((_0x19876f&0x3ff)<<0xa)+(_0x398d3d['charCodeAt'](++_0x1a3cb8)&0x3ff),_0x2ff8a3[_0x4dc407++]=_0x19876f>>0x12|0xf0,_0x2ff8a3[_0x4dc407++]=_0x19876f>>0xc&0x3f|0x80,_0x2ff8a3[_0x4dc407++]=_0x19876f>>0x6&0x3f|0x80,_0x2ff8a3[_0x4dc407++]=_0x19876f&0x3f|0x80):(_0x2ff8a3[_0x4dc407++]=_0x19876f>>0xc|0xe0,_0x2ff8a3[_0x4dc407++]=_0x19876f>>0x6&0x3f|0x80,_0x2ff8a3[_0x4dc407++]=_0x19876f&0x3f|0x80);}return _0x2ff8a3;},ec=function(_0x158519){const _0x277fed=[];let _0x16e71f=0x0,_0x1d49da=0x0;for(;_0x16e71f<_0x158519['length'];){const _0x902356=_0x158519[_0x16e71f++];if(_0x902356<0x80)_0x277fed[_0x1d49da++]=String['fromCharCode'](_0x902356);else{if(_0x902356>0xbf&&_0x902356<0xe0){const _0x689d63=_0x158519[_0x16e71f++];_0x277fed[_0x1d49da++]=String['fromCharCode']((_0x902356&0x1f)<<0x6|_0x689d63&0x3f);}else{if(_0x902356>0xef&&_0x902356<0x16d){const _0x38cf1b=_0x158519[_0x16e71f++],_0x12a03c=_0x158519[_0x16e71f++],_0x5b2c37=_0x158519[_0x16e71f++],_0x508c45=((_0x902356&0x7)<<0x12|(_0x38cf1b&0x3f)<<0xc|(_0x12a03c&0x3f)<<0x6|_0x5b2c37&0x3f)-0x10000;_0x277fed[_0x1d49da++]=String['fromCharCode'](0xd800+(_0x508c45>>0xa)),_0x277fed[_0x1d49da++]=String['fromCharCode'](0xdc00+(_0x508c45&0x3ff));}else{const _0x3e679e=_0x158519[_0x16e71f++],_0x51d42d=_0x158519[_0x16e71f++];_0x277fed[_0x1d49da++]=String['fromCharCode']((_0x902356&0xf)<<0xc|(_0x3e679e&0x3f)<<0x6|_0x51d42d&0x3f);}}}}return _0x277fed['join']('');},Li={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x4bc950,_0x4b96e8){if(!Array['isArray'](_0x4bc950))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x147322=_0x4b96e8?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x8d327c=[];for(let _0x388bef=0x0;_0x388bef<_0x4bc950['length'];_0x388bef+=0x3){const _0x4f5a39=_0x4bc950[_0x388bef],_0x30c8cd=_0x388bef+0x1<_0x4bc950['length'],_0x56c27d=_0x30c8cd?_0x4bc950[_0x388bef+0x1]:0x0,_0x3ee222=_0x388bef+0x2<_0x4bc950['length'],_0x5248b2=_0x3ee222?_0x4bc950[_0x388bef+0x2]:0x0,_0x3fd66a=_0x4f5a39>>0x2,_0x2660b1=(_0x4f5a39&0x3)<<0x4|_0x56c27d>>0x4;let _0x55ff02=(_0x56c27d&0xf)<<0x2|_0x5248b2>>0x6,_0x3cb1b4=_0x5248b2&0x3f;_0x3ee222||(_0x3cb1b4=0x40,_0x30c8cd||(_0x55ff02=0x40)),_0x8d327c['push'](_0x147322[_0x3fd66a],_0x147322[_0x2660b1],_0x147322[_0x55ff02],_0x147322[_0x3cb1b4]);}return _0x8d327c['join']('');},'encodeString'(_0x3f7540,_0x28e3d6){return this['HAS_NATIVE_SUPPORT']&&!_0x28e3d6?btoa(_0x3f7540):this['encodeByteArray'](Vr(_0x3f7540),_0x28e3d6);},'decodeString'(_0xf24bbd,_0x3945b3){return this['HAS_NATIVE_SUPPORT']&&!_0x3945b3?atob(_0xf24bbd):ec(this['decodeStringToByteArray'](_0xf24bbd,_0x3945b3));},'decodeStringToByteArray'(_0x96c555,_0x370c1c){this['init_']();const _0x3b0e1e=_0x370c1c?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x5bf835=[];for(let _0x3abb1a=0x0;_0x3abb1a<_0x96c555['length'];){const _0x150d69=_0x3b0e1e[_0x96c555['charAt'](_0x3abb1a++)],_0x4dedbf=_0x3abb1a<_0x96c555['length']?_0x3b0e1e[_0x96c555['charAt'](_0x3abb1a)]:0x0;++_0x3abb1a;const _0x2e37ee=_0x3abb1a<_0x96c555['length']?_0x3b0e1e[_0x96c555['charAt'](_0x3abb1a)]:0x40;++_0x3abb1a;const _0x526886=_0x3abb1a<_0x96c555['length']?_0x3b0e1e[_0x96c555['charAt'](_0x3abb1a)]:0x40;if(++_0x3abb1a,_0x150d69==null||_0x4dedbf==null||_0x2e37ee==null||_0x526886==null)throw new tc();const _0x81cc2=_0x150d69<<0x2|_0x4dedbf>>0x4;if(_0x5bf835['push'](_0x81cc2),_0x2e37ee!==0x40){const _0x56b65d=_0x4dedbf<<0x4&0xf0|_0x2e37ee>>0x2;if(_0x5bf835['push'](_0x56b65d),_0x526886!==0x40){const _0x39963d=_0x2e37ee<<0x6&0xc0|_0x526886;_0x5bf835['push'](_0x39963d);}}}return _0x5bf835;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x38f0ae=0x0;_0x38f0ae<this['ENCODED_VALS']['length'];_0x38f0ae++)this['byteToCharMap_'][_0x38f0ae]=this['ENCODED_VALS']['charAt'](_0x38f0ae),this['charToByteMap_'][this['byteToCharMap_'][_0x38f0ae]]=_0x38f0ae,this['byteToCharMapWebSafe_'][_0x38f0ae]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x38f0ae),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x38f0ae]]=_0x38f0ae,_0x38f0ae>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x38f0ae)]=_0x38f0ae,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x38f0ae)]=_0x38f0ae);}}};class tc extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Hr=function(_0x11cf70){const _0x5baef0=Vr(_0x11cf70);return Li['encodeByteArray'](_0x5baef0,!0x0);},cn=function(_0x1955e7){return Hr(_0x1955e7)['replace'](/\./g,'');},ln=function(_0x2089a0){try{return Li['decodeString'](_0x2089a0,!0x0);}catch(_0x48ba6c){console['error']('base64Decode\x20failed:\x20',_0x48ba6c);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nc(_0x57319a){return $r(void 0x0,_0x57319a);}function $r(_0x182059,_0x136905){if(!(_0x136905 instanceof Object))return _0x136905;switch(_0x136905['constructor']){case Date:const _0xbaed1d=_0x136905;return new Date(_0xbaed1d['getTime']());case Object:_0x182059===void 0x0&&(_0x182059={});break;case Array:_0x182059=[];break;default:return _0x136905;}for(const _0x44f1cb in _0x136905)!_0x136905['hasOwnProperty'](_0x44f1cb)||!ic(_0x44f1cb)||(_0x182059[_0x44f1cb]=$r(_0x182059[_0x44f1cb],_0x136905[_0x44f1cb]));return _0x182059;}function ic(_0x19ea18){return _0x19ea18!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rc=()=>sc()['__FIREBASE_DEFAULTS__'],oc=()=>{if(typeof process>'u'||typeof Ns>'u')return;const _0x2cbcca=Ns['__FIREBASE_DEFAULTS__'];if(_0x2cbcca)return JSON['parse'](_0x2cbcca);},ac=()=>{if(typeof document>'u')return;let _0xe19cf4;try{_0xe19cf4=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x463358=_0xe19cf4&&ln(_0xe19cf4[0x1]);return _0x463358&&JSON['parse'](_0x463358);},xi=()=>{try{return Za()||rc()||oc()||ac();}catch(_0x5d04a0){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x5d04a0);return;}},Gr=_0x1a44ce=>{var _0x25b1c3,_0x54f021;return(_0x54f021=(_0x25b1c3=xi())==null?void 0x0:_0x25b1c3['emulatorHosts'])==null?void 0x0:_0x54f021[_0x1a44ce];},cc=_0x220675=>{const _0x2fca4a=Gr(_0x220675);if(!_0x2fca4a)return;const _0x15c797=_0x2fca4a['lastIndexOf'](':');if(_0x15c797<=0x0||_0x15c797+0x1===_0x2fca4a['length'])throw new Error('Invalid\x20host\x20'+_0x2fca4a+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x41658a=parseInt(_0x2fca4a['substring'](_0x15c797+0x1),0xa);return _0x2fca4a[0x0]==='['?[_0x2fca4a['substring'](0x1,_0x15c797-0x1),_0x41658a]:[_0x2fca4a['substring'](0x0,_0x15c797),_0x41658a];},qr=()=>{var _0x2b6d23;return(_0x2b6d23=xi())==null?void 0x0:_0x2b6d23['config'];},zr=_0x5f471a=>{var _0x4d58ff;return(_0x4d58ff=xi())==null?void 0x0:_0x4d58ff['_'+_0x5f471a];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x5595ad,_0x48da40)=>{this['resolve']=_0x5595ad,this['reject']=_0x48da40;});}['wrapCallback'](_0x5030cd){return(_0x6589b5,_0x2a6e12)=>{_0x6589b5?this['reject'](_0x6589b5):this['resolve'](_0x2a6e12),typeof _0x5030cd=='function'&&(this['promise']['catch'](()=>{}),_0x5030cd['length']===0x1?_0x5030cd(_0x6589b5):_0x5030cd(_0x6589b5,_0x2a6e12));};}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x42ce3){try{return(_0x42ce3['startsWith']('http://')||_0x42ce3['startsWith']('https://')?new URL(_0x42ce3)['hostname']:_0x42ce3)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x16f2ce){return(await fetch(_0x16f2ce,{'credentials':'include'}))['ok'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function lc(_0x25b190,_0x4eb9a7){if(_0x25b190['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x6df075={'alg':'none','type':'JWT'},_0x584544=_0x4eb9a7||'demo-project',_0x1118f8=_0x25b190['iat']||0x0,_0x367462=_0x25b190['sub']||_0x25b190['user_id'];if(!_0x367462)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x5bf7c9={'iss':'https://securetoken.google.com/'+_0x584544,'aud':_0x584544,'iat':_0x1118f8,'exp':_0x1118f8+0xe10,'auth_time':_0x1118f8,'sub':_0x367462,'user_id':_0x367462,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x25b190};return[cn(JSON['stringify'](_0x6df075)),cn(JSON['stringify'](_0x5bf7c9)),'']['join']('.');}const It={};function hc(){const _0x4de1a6={'prod':[],'emulator':[]};for(const _0x2f3773 of Object['keys'](It))It[_0x2f3773]?_0x4de1a6['emulator']['push'](_0x2f3773):_0x4de1a6['prod']['push'](_0x2f3773);return _0x4de1a6;}function uc(_0x3f34e5){let _0x12827f=document['getElementById'](_0x3f34e5),_0x1c2387=!0x1;return _0x12827f||(_0x12827f=document['createElement']('div'),_0x12827f['setAttribute']('id',_0x3f34e5),_0x1c2387=!0x0),{'created':_0x1c2387,'element':_0x12827f};}let Ps=!0x1;function Kr(_0x29d1d6,_0x206b86){if(typeof window>'u'||typeof document>'u'||!at(window['location']['host'])||It[_0x29d1d6]===_0x206b86||It[_0x29d1d6]||Ps)return;It[_0x29d1d6]=_0x206b86;function _0x10fca7(_0x2228ac){return'__firebase__banner__'+_0x2228ac;}const _0x34ca65='__firebase__banner',_0x2fdaf0=hc()['prod']['length']>0x0;function _0x5d16a7(){const _0x241a40=document['getElementById'](_0x34ca65);_0x241a40&&_0x241a40['remove']();}function _0x4d4e1a(_0xab36b8){_0xab36b8['style']['display']='flex',_0xab36b8['style']['background']='#7faaf0',_0xab36b8['style']['position']='fixed',_0xab36b8['style']['bottom']='5px',_0xab36b8['style']['left']='5px',_0xab36b8['style']['padding']='.5em',_0xab36b8['style']['borderRadius']='5px',_0xab36b8['style']['alignItems']='center';}function _0x92252c(_0x560541,_0x4b3ac4){_0x560541['setAttribute']('width','24'),_0x560541['setAttribute']('id',_0x4b3ac4),_0x560541['setAttribute']('height','24'),_0x560541['setAttribute']('viewBox','0\x200\x2024\x2024'),_0x560541['setAttribute']('fill','none'),_0x560541['style']['marginLeft']='-6px';}function _0x481cf5(){const _0x519467=document['createElement']('span');return _0x519467['style']['cursor']='pointer',_0x519467['style']['marginLeft']='16px',_0x519467['style']['fontSize']='24px',_0x519467['innerHTML']='\x20&times;',_0x519467['onclick']=()=>{Ps=!0x0,_0x5d16a7();},_0x519467;}function _0x2cadf4(_0x1acbe5,_0x1c9805){_0x1acbe5['setAttribute']('id',_0x1c9805),_0x1acbe5['innerText']='Learn\x20more',_0x1acbe5['href']='https://firebase.google.com/docs/studio/preview-apps#preview-backend',_0x1acbe5['setAttribute']('target','__blank'),_0x1acbe5['style']['paddingLeft']='5px',_0x1acbe5['style']['textDecoration']='underline';}function _0x4a48ad(){const _0x468a16=uc(_0x34ca65),_0x13e70e=_0x10fca7('text'),_0x22d332=document['getElementById'](_0x13e70e)||document['createElement']('span'),_0x56c8c9=_0x10fca7('learnmore'),_0x418992=document['getElementById'](_0x56c8c9)||document['createElement']('a'),_0x373fd=_0x10fca7('preprendIcon'),_0x573c6d=document['getElementById'](_0x373fd)||document['createElementNS']('http://www.w3.org/2000/svg','svg');if(_0x468a16['created']){const _0x311954=_0x468a16['element'];_0x4d4e1a(_0x311954),_0x2cadf4(_0x418992,_0x56c8c9);const _0x5a4ad2=_0x481cf5();_0x92252c(_0x573c6d,_0x373fd),_0x311954['append'](_0x573c6d,_0x22d332,_0x418992,_0x5a4ad2),document['body']['appendChild'](_0x311954);}_0x2fdaf0?(_0x22d332['innerText']='Preview\x20backend\x20disconnected.',_0x573c6d['innerHTML']='<g\x20clip-path=\x22url(#clip0_6013_33858)\x22>\x0a<path\x20d=\x22M4.8\x2017.6L12\x205.6L19.2\x2017.6H4.8ZM6.91667\x2016.4H17.0833L12\x207.93333L6.91667\x2016.4ZM12\x2015.6C12.1667\x2015.6\x2012.3056\x2015.5444\x2012.4167\x2015.4333C12.5389\x2015.3111\x2012.6\x2015.1667\x2012.6\x2015C12.6\x2014.8333\x2012.5389\x2014.6944\x2012.4167\x2014.5833C12.3056\x2014.4611\x2012.1667\x2014.4\x2012\x2014.4C11.8333\x2014.4\x2011.6889\x2014.4611\x2011.5667\x2014.5833C11.4556\x2014.6944\x2011.4\x2014.8333\x2011.4\x2015C11.4\x2015.1667\x2011.4556\x2015.3111\x2011.5667\x2015.4333C11.6889\x2015.5444\x2011.8333\x2015.6\x2012\x2015.6ZM11.4\x2013.6H12.6V10.4H11.4V13.6Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6013_33858\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>'):(_0x573c6d['innerHTML']='<g\x20clip-path=\x22url(#clip0_6083_34804)\x22>\x0a<path\x20d=\x22M11.4\x2015.2H12.6V11.2H11.4V15.2ZM12\x2010C12.1667\x2010\x2012.3056\x209.94444\x2012.4167\x209.83333C12.5389\x209.71111\x2012.6\x209.56667\x2012.6\x209.4C12.6\x209.23333\x2012.5389\x209.09444\x2012.4167\x208.98333C12.3056\x208.86111\x2012.1667\x208.8\x2012\x208.8C11.8333\x208.8\x2011.6889\x208.86111\x2011.5667\x208.98333C11.4556\x209.09444\x2011.4\x209.23333\x2011.4\x209.4C11.4\x209.56667\x2011.4556\x209.71111\x2011.5667\x209.83333C11.6889\x209.94444\x2011.8333\x2010\x2012\x2010ZM12\x2018.4C11.1222\x2018.4\x2010.2944\x2018.2333\x209.51667\x2017.9C8.73889\x2017.5667\x208.05556\x2017.1111\x207.46667\x2016.5333C6.88889\x2015.9444\x206.43333\x2015.2611\x206.1\x2014.4833C5.76667\x2013.7056\x205.6\x2012.8778\x205.6\x2012C5.6\x2011.1111\x205.76667\x2010.2833\x206.1\x209.51667C6.43333\x208.73889\x206.88889\x208.06111\x207.46667\x207.48333C8.05556\x206.89444\x208.73889\x206.43333\x209.51667\x206.1C10.2944\x205.76667\x2011.1222\x205.6\x2012\x205.6C12.8889\x205.6\x2013.7167\x205.76667\x2014.4833\x206.1C15.2611\x206.43333\x2015.9389\x206.89444\x2016.5167\x207.48333C17.1056\x208.06111\x2017.5667\x208.73889\x2017.9\x209.51667C18.2333\x2010.2833\x2018.4\x2011.1111\x2018.4\x2012C18.4\x2012.8778\x2018.2333\x2013.7056\x2017.9\x2014.4833C17.5667\x2015.2611\x2017.1056\x2015.9444\x2016.5167\x2016.5333C15.9389\x2017.1111\x2015.2611\x2017.5667\x2014.4833\x2017.9C13.7167\x2018.2333\x2012.8889\x2018.4\x2012\x2018.4ZM12\x2017.2C13.4444\x2017.2\x2014.6722\x2016.6944\x2015.6833\x2015.6833C16.6944\x2014.6722\x2017.2\x2013.4444\x2017.2\x2012C17.2\x2010.5556\x2016.6944\x209.32778\x2015.6833\x208.31667C14.6722\x207.30555\x2013.4444\x206.8\x2012\x206.8C10.5556\x206.8\x209.32778\x207.30555\x208.31667\x208.31667C7.30556\x209.32778\x206.8\x2010.5556\x206.8\x2012C6.8\x2013.4444\x207.30556\x2014.6722\x208.31667\x2015.6833C9.32778\x2016.6944\x2010.5556\x2017.2\x2012\x2017.2Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6083_34804\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>',_0x22d332['innerText']='Preview\x20backend\x20running\x20in\x20this\x20workspace.'),_0x22d332['setAttribute']('id',_0x13e70e);}document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x4a48ad):_0x4a48ad();}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Fi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x384f7f=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x384f7f=='object'&&_0x384f7f['id']!==void 0x0;}function Yr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x55f57d=W();return _0x55f57d['indexOf']('MSIE\x20')>=0x0||_0x55f57d['indexOf']('Trident/')>=0x0;}function _c(){return Br['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x15b58a,_0x412a12)=>{try{let _0x39eaac=!0x0;const _0x956ab0='validate-browser-context-for-indexeddb-analytics-module',_0x59aa13=self['indexedDB']['open'](_0x956ab0);_0x59aa13['onsuccess']=()=>{_0x59aa13['result']['close'](),_0x39eaac||self['indexedDB']['deleteDatabase'](_0x956ab0),_0x15b58a(!0x0);},_0x59aa13['onupgradeneeded']=()=>{_0x39eaac=!0x1;},_0x59aa13['onerror']=()=>{var _0x42d43f;_0x412a12(((_0x42d43f=_0x59aa13['error'])==null?void 0x0:_0x42d43f['message'])||'');};}catch(_0x31a606){_0x412a12(_0x31a606);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Se extends Error{constructor(_0x431352,_0x3c6a7f,_0xc72ee2){super(_0x3c6a7f),this['code']=_0x431352,this['customData']=_0xc72ee2,this['name']=yc,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Bt['prototype']['create']);}}class Bt{constructor(_0x137e2e,_0x252d99,_0x476ec5){this['service']=_0x137e2e,this['serviceName']=_0x252d99,this['errors']=_0x476ec5;}['create'](_0xe21b85,..._0x3670f3){const _0x3a32e1=_0x3670f3[0x0]||{},_0x490eb2=this['service']+'/'+_0xe21b85,_0x106acd=this['errors'][_0xe21b85],_0x3605c2=_0x106acd?vc(_0x106acd,_0x3a32e1):'Error',_0x593f19=this['serviceName']+':\x20'+_0x3605c2+'\x20('+_0x490eb2+').';return new Se(_0x490eb2,_0x593f19,_0x3a32e1);}}function vc(_0x300ab5,_0x2ef9cb){return _0x300ab5['replace'](Ec,(_0x188ed0,_0x3d330a)=>{const _0xc1361e=_0x2ef9cb[_0x3d330a];return _0xc1361e!=null?String(_0xc1361e):'<'+_0x3d330a+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function At(_0x4c1b95){return JSON['parse'](_0x4c1b95);}function O(_0x48275b){return JSON['stringify'](_0x48275b);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qr=function(_0x1e3193){let _0x5225f8={},_0x4c4c77={},_0x4062d4={},_0xc1cc43='';try{const _0x4d0e98=_0x1e3193['split']('.');_0x5225f8=At(ln(_0x4d0e98[0x0])||''),_0x4c4c77=At(ln(_0x4d0e98[0x1])||''),_0xc1cc43=_0x4d0e98[0x2],_0x4062d4=_0x4c4c77['d']||{},delete _0x4c4c77['d'];}catch{}return{'header':_0x5225f8,'claims':_0x4c4c77,'data':_0x4062d4,'signature':_0xc1cc43};},Ic=function(_0x1a24ad){const _0x2c1ccf=Qr(_0x1a24ad),_0x150aca=_0x2c1ccf['claims'];return!!_0x150aca&&typeof _0x150aca=='object'&&_0x150aca['hasOwnProperty']('iat');},wc=function(_0x1e62f2){const _0x1eb273=Qr(_0x1e62f2)['claims'];return typeof _0x1eb273=='object'&&_0x1eb273['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function J(_0x2dbbd9,_0x5b537b){return Object['prototype']['hasOwnProperty']['call'](_0x2dbbd9,_0x5b537b);}function De(_0x161a9d,_0x12b714){if(Object['prototype']['hasOwnProperty']['call'](_0x161a9d,_0x12b714))return _0x161a9d[_0x12b714];}function ui(_0x35a98d){for(const _0x205d88 in _0x35a98d)if(Object['prototype']['hasOwnProperty']['call'](_0x35a98d,_0x205d88))return!0x1;return!0x0;}function hn(_0x3d59ef,_0x4d8387,_0x279bfb){const _0x443eac={};for(const _0x2d0c66 in _0x3d59ef)Object['prototype']['hasOwnProperty']['call'](_0x3d59ef,_0x2d0c66)&&(_0x443eac[_0x2d0c66]=_0x4d8387['call'](_0x279bfb,_0x3d59ef[_0x2d0c66],_0x2d0c66,_0x3d59ef));return _0x443eac;}function Me(_0x343b77,_0x52388c){if(_0x343b77===_0x52388c)return!0x0;const _0xf8fad9=Object['keys'](_0x343b77),_0x2c657a=Object['keys'](_0x52388c);for(const _0x529c47 of _0xf8fad9){if(!_0x2c657a['includes'](_0x529c47))return!0x1;const _0x5603ae=_0x343b77[_0x529c47],_0x5aa17a=_0x52388c[_0x529c47];if(Os(_0x5603ae)&&Os(_0x5aa17a)){if(!Me(_0x5603ae,_0x5aa17a))return!0x1;}else{if(_0x5603ae!==_0x5aa17a)return!0x1;}}for(const _0x2d2601 of _0x2c657a)if(!_0xf8fad9['includes'](_0x2d2601))return!0x1;return!0x0;}function Os(_0x41e65e){return _0x41e65e!==null&&typeof _0x41e65e=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ct(_0x31d02b){const _0x4c6d24=[];for(const [_0x2ce37e,_0x4ecce7]of Object['entries'](_0x31d02b))Array['isArray'](_0x4ecce7)?_0x4ecce7['forEach'](_0x557690=>{_0x4c6d24['push'](encodeURIComponent(_0x2ce37e)+'='+encodeURIComponent(_0x557690));}):_0x4c6d24['push'](encodeURIComponent(_0x2ce37e)+'='+encodeURIComponent(_0x4ecce7));return _0x4c6d24['length']?'&'+_0x4c6d24['join']('&'):'';}function vt(_0x327e1d){const _0x4d0cda={};return _0x327e1d['replace'](/^\?/,'')['split']('&')['forEach'](_0x4d00c8=>{if(_0x4d00c8){const [_0x163ebf,_0x88f732]=_0x4d00c8['split']('=');_0x4d0cda[decodeURIComponent(_0x163ebf)]=decodeURIComponent(_0x88f732);}}),_0x4d0cda;}function Et(_0x3de1fe){const _0x3b0549=_0x3de1fe['indexOf']('?');if(!_0x3b0549)return'';const _0xf15643=_0x3de1fe['indexOf']('#',_0x3b0549);return _0x3de1fe['substring'](_0x3b0549,_0xf15643>0x0?_0xf15643:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x2a46a2=0x1;_0x2a46a2<this['blockSize'];++_0x2a46a2)this['pad_'][_0x2a46a2]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x5949df,_0x61d2fc){_0x61d2fc||(_0x61d2fc=0x0);const _0x5e3f0b=this['W_'];if(typeof _0x5949df=='string'){for(let _0x58436c=0x0;_0x58436c<0x10;_0x58436c++)_0x5e3f0b[_0x58436c]=_0x5949df['charCodeAt'](_0x61d2fc)<<0x18|_0x5949df['charCodeAt'](_0x61d2fc+0x1)<<0x10|_0x5949df['charCodeAt'](_0x61d2fc+0x2)<<0x8|_0x5949df['charCodeAt'](_0x61d2fc+0x3),_0x61d2fc+=0x4;}else{for(let _0x1fd384=0x0;_0x1fd384<0x10;_0x1fd384++)_0x5e3f0b[_0x1fd384]=_0x5949df[_0x61d2fc]<<0x18|_0x5949df[_0x61d2fc+0x1]<<0x10|_0x5949df[_0x61d2fc+0x2]<<0x8|_0x5949df[_0x61d2fc+0x3],_0x61d2fc+=0x4;}for(let _0x36c883=0x10;_0x36c883<0x50;_0x36c883++){const _0x1913a7=_0x5e3f0b[_0x36c883-0x3]^_0x5e3f0b[_0x36c883-0x8]^_0x5e3f0b[_0x36c883-0xe]^_0x5e3f0b[_0x36c883-0x10];_0x5e3f0b[_0x36c883]=(_0x1913a7<<0x1|_0x1913a7>>>0x1f)&0xffffffff;}let _0x5a804a=this['chain_'][0x0],_0x2d3a5e=this['chain_'][0x1],_0x4b3a5f=this['chain_'][0x2],_0x166608=this['chain_'][0x3],_0x166a86=this['chain_'][0x4],_0x598a69,_0x383385;for(let _0x42fd6e=0x0;_0x42fd6e<0x50;_0x42fd6e++){_0x42fd6e<0x28?_0x42fd6e<0x14?(_0x598a69=_0x166608^_0x2d3a5e&(_0x4b3a5f^_0x166608),_0x383385=0x5a827999):(_0x598a69=_0x2d3a5e^_0x4b3a5f^_0x166608,_0x383385=0x6ed9eba1):_0x42fd6e<0x3c?(_0x598a69=_0x2d3a5e&_0x4b3a5f|_0x166608&(_0x2d3a5e|_0x4b3a5f),_0x383385=0x8f1bbcdc):(_0x598a69=_0x2d3a5e^_0x4b3a5f^_0x166608,_0x383385=0xca62c1d6);const _0x27a7f3=(_0x5a804a<<0x5|_0x5a804a>>>0x1b)+_0x598a69+_0x166a86+_0x383385+_0x5e3f0b[_0x42fd6e]&0xffffffff;_0x166a86=_0x166608,_0x166608=_0x4b3a5f,_0x4b3a5f=(_0x2d3a5e<<0x1e|_0x2d3a5e>>>0x2)&0xffffffff,_0x2d3a5e=_0x5a804a,_0x5a804a=_0x27a7f3;}this['chain_'][0x0]=this['chain_'][0x0]+_0x5a804a&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x2d3a5e&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x4b3a5f&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x166608&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x166a86&0xffffffff;}['update'](_0xdafa2e,_0x493382){if(_0xdafa2e==null)return;_0x493382===void 0x0&&(_0x493382=_0xdafa2e['length']);const _0x211eab=_0x493382-this['blockSize'];let _0x3a6aff=0x0;const _0x3d5a54=this['buf_'];let _0x44067a=this['inbuf_'];for(;_0x3a6aff<_0x493382;){if(_0x44067a===0x0){for(;_0x3a6aff<=_0x211eab;)this['compress_'](_0xdafa2e,_0x3a6aff),_0x3a6aff+=this['blockSize'];}if(typeof _0xdafa2e=='string'){for(;_0x3a6aff<_0x493382;)if(_0x3d5a54[_0x44067a]=_0xdafa2e['charCodeAt'](_0x3a6aff),++_0x44067a,++_0x3a6aff,_0x44067a===this['blockSize']){this['compress_'](_0x3d5a54),_0x44067a=0x0;break;}}else{for(;_0x3a6aff<_0x493382;)if(_0x3d5a54[_0x44067a]=_0xdafa2e[_0x3a6aff],++_0x44067a,++_0x3a6aff,_0x44067a===this['blockSize']){this['compress_'](_0x3d5a54),_0x44067a=0x0;break;}}}this['inbuf_']=_0x44067a,this['total_']+=_0x493382;}['digest'](){const _0x2c492e=[];let _0x140edd=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x26b2b0=this['blockSize']-0x1;_0x26b2b0>=0x38;_0x26b2b0--)this['buf_'][_0x26b2b0]=_0x140edd&0xff,_0x140edd/=0x100;this['compress_'](this['buf_']);let _0xc90783=0x0;for(let _0x2d3883=0x0;_0x2d3883<0x5;_0x2d3883++)for(let _0x435987=0x18;_0x435987>=0x0;_0x435987-=0x8)_0x2c492e[_0xc90783]=this['chain_'][_0x2d3883]>>_0x435987&0xff,++_0xc90783;return _0x2c492e;}}function Tc(_0xb84664,_0x213f2d){const _0x1147ad=new Sc(_0xb84664,_0x213f2d);return _0x1147ad['subscribe']['bind'](_0x1147ad);}class Sc{constructor(_0x45e4c1,_0x224145){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x224145,this['task']['then'](()=>{_0x45e4c1(this);})['catch'](_0xa697cb=>{this['error'](_0xa697cb);});}['next'](_0x54fd00){this['forEachObserver'](_0x40a684=>{_0x40a684['next'](_0x54fd00);});}['error'](_0x552829){this['forEachObserver'](_0x55d242=>{_0x55d242['error'](_0x552829);}),this['close'](_0x552829);}['complete'](){this['forEachObserver'](_0x3f42f7=>{_0x3f42f7['complete']();}),this['close']();}['subscribe'](_0x1b59fc,_0x314fdb,_0x1ca059){let _0x348a00;if(_0x1b59fc===void 0x0&&_0x314fdb===void 0x0&&_0x1ca059===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x1b59fc,['next','error','complete'])?_0x348a00=_0x1b59fc:_0x348a00={'next':_0x1b59fc,'error':_0x314fdb,'complete':_0x1ca059},_0x348a00['next']===void 0x0&&(_0x348a00['next']=Jn),_0x348a00['error']===void 0x0&&(_0x348a00['error']=Jn),_0x348a00['complete']===void 0x0&&(_0x348a00['complete']=Jn);const _0x2eb4e3=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x348a00['error'](this['finalError']):_0x348a00['complete']();}catch{}}),this['observers']['push'](_0x348a00),_0x2eb4e3;}['unsubscribeOne'](_0x5a9241){this['observers']===void 0x0||this['observers'][_0x5a9241]===void 0x0||(delete this['observers'][_0x5a9241],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x3c5047){if(!this['finalized']){for(let _0x25db22=0x0;_0x25db22<this['observers']['length'];_0x25db22++)this['sendOne'](_0x25db22,_0x3c5047);}}['sendOne'](_0x3b0745,_0x112338){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x3b0745]!==void 0x0)try{_0x112338(this['observers'][_0x3b0745]);}catch(_0x1b3d55){typeof console<'u'&&console['error']&&console['error'](_0x1b3d55);}});}['close'](_0x39bf97){this['finalized']||(this['finalized']=!0x0,_0x39bf97!==void 0x0&&(this['finalError']=_0x39bf97),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x2ef40e,_0x5678d5){if(typeof _0x2ef40e!='object'||_0x2ef40e===null)return!0x1;for(const _0x1b9a57 of _0x5678d5)if(_0x1b9a57 in _0x2ef40e&&typeof _0x2ef40e[_0x1b9a57]=='function')return!0x0;return!0x1;}function Jn(){}function Pn(_0x25619e,_0x53bf71){return _0x25619e+'\x20failed:\x20'+_0x53bf71+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x22a1d1){const _0x238c91=[];let _0x5260fc=0x0;for(let _0x20d6b6=0x0;_0x20d6b6<_0x22a1d1['length'];_0x20d6b6++){let _0x552a8c=_0x22a1d1['charCodeAt'](_0x20d6b6);if(_0x552a8c>=0xd800&&_0x552a8c<=0xdbff){const _0x57d679=_0x552a8c-0xd800;_0x20d6b6++,f(_0x20d6b6<_0x22a1d1['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x5a1f9e=_0x22a1d1['charCodeAt'](_0x20d6b6)-0xdc00;_0x552a8c=0x10000+(_0x57d679<<0xa)+_0x5a1f9e;}_0x552a8c<0x80?_0x238c91[_0x5260fc++]=_0x552a8c:_0x552a8c<0x800?(_0x238c91[_0x5260fc++]=_0x552a8c>>0x6|0xc0,_0x238c91[_0x5260fc++]=_0x552a8c&0x3f|0x80):_0x552a8c<0x10000?(_0x238c91[_0x5260fc++]=_0x552a8c>>0xc|0xe0,_0x238c91[_0x5260fc++]=_0x552a8c>>0x6&0x3f|0x80,_0x238c91[_0x5260fc++]=_0x552a8c&0x3f|0x80):(_0x238c91[_0x5260fc++]=_0x552a8c>>0x12|0xf0,_0x238c91[_0x5260fc++]=_0x552a8c>>0xc&0x3f|0x80,_0x238c91[_0x5260fc++]=_0x552a8c>>0x6&0x3f|0x80,_0x238c91[_0x5260fc++]=_0x552a8c&0x3f|0x80);}return _0x238c91;},On=function(_0x1800f8){let _0x476c0b=0x0;for(let _0x48901d=0x0;_0x48901d<_0x1800f8['length'];_0x48901d++){const _0x13db46=_0x1800f8['charCodeAt'](_0x48901d);_0x13db46<0x80?_0x476c0b++:_0x13db46<0x800?_0x476c0b+=0x2:_0x13db46>=0xd800&&_0x13db46<=0xdbff?(_0x476c0b+=0x4,_0x48901d++):_0x476c0b+=0x3;}return _0x476c0b;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function N(_0x139f76){return _0x139f76&&_0x139f76['_delegate']?_0x139f76['_delegate']:_0x139f76;}class Le{constructor(_0x52d9ed,_0x220b88,_0x25d16b){this['name']=_0x52d9ed,this['instanceFactory']=_0x220b88,this['type']=_0x25d16b,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x52dd15){return this['instantiationMode']=_0x52dd15,this;}['setMultipleInstances'](_0x51f8c0){return this['multipleInstances']=_0x51f8c0,this;}['setServiceProps'](_0x2de69e){return this['serviceProps']=_0x2de69e,this;}['setInstanceCreatedCallback'](_0x4e694b){return this['onInstanceCreated']=_0x4e694b,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x3cfa1b,_0x409888){this['name']=_0x3cfa1b,this['container']=_0x409888,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0xaeb3b1){const _0x529285=this['normalizeInstanceIdentifier'](_0xaeb3b1);if(!this['instancesDeferred']['has'](_0x529285)){const _0x4006fa=new ot();if(this['instancesDeferred']['set'](_0x529285,_0x4006fa),this['isInitialized'](_0x529285)||this['shouldAutoInitialize']())try{const _0xa41049=this['getOrInitializeService']({'instanceIdentifier':_0x529285});_0xa41049&&_0x4006fa['resolve'](_0xa41049);}catch{}}return this['instancesDeferred']['get'](_0x529285)['promise'];}['getImmediate'](_0x34a9af){const _0x4a1df9=this['normalizeInstanceIdentifier'](_0x34a9af==null?void 0x0:_0x34a9af['identifier']),_0x1d21cc=(_0x34a9af==null?void 0x0:_0x34a9af['optional'])??!0x1;if(this['isInitialized'](_0x4a1df9)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x4a1df9});}catch(_0x28952c){if(_0x1d21cc)return null;throw _0x28952c;}else{if(_0x1d21cc)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x531cb9){if(_0x531cb9['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x531cb9['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x531cb9,!!this['shouldAutoInitialize']()){if(Nc(_0x531cb9))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x22e7fc,_0xa68cc1]of this['instancesDeferred']['entries']()){const _0x55b70a=this['normalizeInstanceIdentifier'](_0x22e7fc);try{const _0x465d7c=this['getOrInitializeService']({'instanceIdentifier':_0x55b70a});_0xa68cc1['resolve'](_0x465d7c);}catch{}}}}['clearInstance'](_0x306003=Ne){this['instancesDeferred']['delete'](_0x306003),this['instancesOptions']['delete'](_0x306003),this['instances']['delete'](_0x306003);}async['delete'](){const _0x5bfcb0=Array['from'](this['instances']['values']());await Promise['all']([..._0x5bfcb0['filter'](_0x10481d=>'INTERNAL'in _0x10481d)['map'](_0xf15c3=>_0xf15c3['INTERNAL']['delete']()),..._0x5bfcb0['filter'](_0x3bda70=>'_delete'in _0x3bda70)['map'](_0x4086cb=>_0x4086cb['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x44d4a2=Ne){return this['instances']['has'](_0x44d4a2);}['getOptions'](_0x4699d8=Ne){return this['instancesOptions']['get'](_0x4699d8)||{};}['initialize'](_0x2f6b98={}){const {options:_0x71c757={}}=_0x2f6b98,_0x5ef6b2=this['normalizeInstanceIdentifier'](_0x2f6b98['instanceIdentifier']);if(this['isInitialized'](_0x5ef6b2))throw Error(this['name']+'('+_0x5ef6b2+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x471724=this['getOrInitializeService']({'instanceIdentifier':_0x5ef6b2,'options':_0x71c757});for(const [_0x25e35e,_0x1589c1]of this['instancesDeferred']['entries']()){const _0x53d4a8=this['normalizeInstanceIdentifier'](_0x25e35e);_0x5ef6b2===_0x53d4a8&&_0x1589c1['resolve'](_0x471724);}return _0x471724;}['onInit'](_0x58cca4,_0x1158f4){const _0xebf43d=this['normalizeInstanceIdentifier'](_0x1158f4),_0xcadfca=this['onInitCallbacks']['get'](_0xebf43d)??new Set();_0xcadfca['add'](_0x58cca4),this['onInitCallbacks']['set'](_0xebf43d,_0xcadfca);const _0x4aedb8=this['instances']['get'](_0xebf43d);return _0x4aedb8&&_0x58cca4(_0x4aedb8,_0xebf43d),()=>{_0xcadfca['delete'](_0x58cca4);};}['invokeOnInitCallbacks'](_0x3942a1,_0x19dd6f){const _0x1c4540=this['onInitCallbacks']['get'](_0x19dd6f);if(_0x1c4540){for(const _0x5a12f1 of _0x1c4540)try{_0x5a12f1(_0x3942a1,_0x19dd6f);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x5bebbd,options:_0x226534={}}){let _0x4e146a=this['instances']['get'](_0x5bebbd);if(!_0x4e146a&&this['component']&&(_0x4e146a=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x5bebbd),'options':_0x226534}),this['instances']['set'](_0x5bebbd,_0x4e146a),this['instancesOptions']['set'](_0x5bebbd,_0x226534),this['invokeOnInitCallbacks'](_0x4e146a,_0x5bebbd),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x5bebbd,_0x4e146a);}catch{}return _0x4e146a||null;}['normalizeInstanceIdentifier'](_0x507790=Ne){return this['component']?this['component']['multipleInstances']?_0x507790:Ne:_0x507790;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x21c1d1){return _0x21c1d1===Ne?void 0x0:_0x21c1d1;}function Nc(_0x543314){return _0x543314['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pc{constructor(_0x4e5fbb){this['name']=_0x4e5fbb,this['providers']=new Map();}['addComponent'](_0x1f0dcb){const _0x584d88=this['getProvider'](_0x1f0dcb['name']);if(_0x584d88['isComponentSet']())throw new Error('Component\x20'+_0x1f0dcb['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x584d88['setComponent'](_0x1f0dcb);}['addOrOverwriteComponent'](_0x2898c9){this['getProvider'](_0x2898c9['name'])['isComponentSet']()&&this['providers']['delete'](_0x2898c9['name']),this['addComponent'](_0x2898c9);}['getProvider'](_0x4d11e3){if(this['providers']['has'](_0x4d11e3))return this['providers']['get'](_0x4d11e3);const _0x530f6c=new Ac(_0x4d11e3,this);return this['providers']['set'](_0x4d11e3,_0x530f6c),_0x530f6c;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x113403){_0x113403[_0x113403['DEBUG']=0x0]='DEBUG',_0x113403[_0x113403['VERBOSE']=0x1]='VERBOSE',_0x113403[_0x113403['INFO']=0x2]='INFO',_0x113403[_0x113403['WARN']=0x3]='WARN',_0x113403[_0x113403['ERROR']=0x4]='ERROR',_0x113403[_0x113403['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x517f28,_0x41dffa,..._0x3b337d)=>{if(_0x41dffa<_0x517f28['logLevel'])return;const _0x53b7c8=new Date()['toISOString'](),_0x3ef03a=Mc[_0x41dffa];if(_0x3ef03a)console[_0x3ef03a]('['+_0x53b7c8+']\x20\x20'+_0x517f28['name']+':',..._0x3b337d);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x41dffa+')');};class Ui{constructor(_0x164aca){this['name']=_0x164aca,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x351fcb){if(!(_0x351fcb in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x351fcb+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x351fcb;}['setLogLevel'](_0x1d3d6a){this['_logLevel']=typeof _0x1d3d6a=='string'?Oc[_0x1d3d6a]:_0x1d3d6a;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x2ac94c){if(typeof _0x2ac94c!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x2ac94c;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x340d8e){this['_userLogHandler']=_0x340d8e;}['debug'](..._0x12e212){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x12e212),this['_logHandler'](this,T['DEBUG'],..._0x12e212);}['log'](..._0x372dc6){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x372dc6),this['_logHandler'](this,T['VERBOSE'],..._0x372dc6);}['info'](..._0x3924ac){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x3924ac),this['_logHandler'](this,T['INFO'],..._0x3924ac);}['warn'](..._0x19faa8){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x19faa8),this['_logHandler'](this,T['WARN'],..._0x19faa8);}['error'](..._0x5eebfa){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x5eebfa),this['_logHandler'](this,T['ERROR'],..._0x5eebfa);}}const xc=(_0x2a2b60,_0x270150)=>_0x270150['some'](_0xcab357=>_0x2a2b60 instanceof _0xcab357);let Ds,Ms;function Fc(){return Ds||(Ds=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ms||(Ms=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),di=new WeakMap(),Xr=new WeakMap(),Xn=new WeakMap(),Wi=new WeakMap();function Wc(_0x3d7aa1){const _0x4bc124=new Promise((_0x4a4a38,_0x55ed42)=>{const _0x250568=()=>{_0x3d7aa1['removeEventListener']('success',_0x509e87),_0x3d7aa1['removeEventListener']('error',_0x1eb2cc);},_0x509e87=()=>{_0x4a4a38(_e(_0x3d7aa1['result'])),_0x250568();},_0x1eb2cc=()=>{_0x55ed42(_0x3d7aa1['error']),_0x250568();};_0x3d7aa1['addEventListener']('success',_0x509e87),_0x3d7aa1['addEventListener']('error',_0x1eb2cc);});return _0x4bc124['then'](_0x4c9159=>{_0x4c9159 instanceof IDBCursor&&Jr['set'](_0x4c9159,_0x3d7aa1);})['catch'](()=>{}),Wi['set'](_0x4bc124,_0x3d7aa1),_0x4bc124;}function Bc(_0x4bcc28){if(di['has'](_0x4bcc28))return;const _0x443f3f=new Promise((_0x1751d3,_0x4967f0)=>{const _0x20259c=()=>{_0x4bcc28['removeEventListener']('complete',_0x2e2757),_0x4bcc28['removeEventListener']('error',_0x523eff),_0x4bcc28['removeEventListener']('abort',_0x523eff);},_0x2e2757=()=>{_0x1751d3(),_0x20259c();},_0x523eff=()=>{_0x4967f0(_0x4bcc28['error']||new DOMException('AbortError','AbortError')),_0x20259c();};_0x4bcc28['addEventListener']('complete',_0x2e2757),_0x4bcc28['addEventListener']('error',_0x523eff),_0x4bcc28['addEventListener']('abort',_0x523eff);});di['set'](_0x4bcc28,_0x443f3f);}let fi={'get'(_0x187fd6,_0xa44972,_0x535616){if(_0x187fd6 instanceof IDBTransaction){if(_0xa44972==='done')return di['get'](_0x187fd6);if(_0xa44972==='objectStoreNames')return _0x187fd6['objectStoreNames']||Xr['get'](_0x187fd6);if(_0xa44972==='store')return _0x535616['objectStoreNames'][0x1]?void 0x0:_0x535616['objectStore'](_0x535616['objectStoreNames'][0x0]);}return _e(_0x187fd6[_0xa44972]);},'set'(_0x16a96f,_0x5a8d0a,_0x1b5dde){return _0x16a96f[_0x5a8d0a]=_0x1b5dde,!0x0;},'has'(_0xddcc7,_0x509892){return _0xddcc7 instanceof IDBTransaction&&(_0x509892==='done'||_0x509892==='store')?!0x0:_0x509892 in _0xddcc7;}};function Vc(_0x5653c4){fi=_0x5653c4(fi);}function Hc(_0x354c60){return _0x354c60===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x302945,..._0x520f06){const _0xe771f2=_0x354c60['call'](Zn(this),_0x302945,..._0x520f06);return Xr['set'](_0xe771f2,_0x302945['sort']?_0x302945['sort']():[_0x302945]),_e(_0xe771f2);}:Uc()['includes'](_0x354c60)?function(..._0x25f71a){return _0x354c60['apply'](Zn(this),_0x25f71a),_e(Jr['get'](this));}:function(..._0x2e54f9){return _e(_0x354c60['apply'](Zn(this),_0x2e54f9));};}function $c(_0x1c50a6){return typeof _0x1c50a6=='function'?Hc(_0x1c50a6):(_0x1c50a6 instanceof IDBTransaction&&Bc(_0x1c50a6),xc(_0x1c50a6,Fc())?new Proxy(_0x1c50a6,fi):_0x1c50a6);}function _e(_0x13c8f7){if(_0x13c8f7 instanceof IDBRequest)return Wc(_0x13c8f7);if(Xn['has'](_0x13c8f7))return Xn['get'](_0x13c8f7);const _0xef1d9a=$c(_0x13c8f7);return _0xef1d9a!==_0x13c8f7&&(Xn['set'](_0x13c8f7,_0xef1d9a),Wi['set'](_0xef1d9a,_0x13c8f7)),_0xef1d9a;}const Zn=_0x40937e=>Wi['get'](_0x40937e);function Gc(_0x2f5941,_0x8b0483,{blocked:_0xa057f2,upgrade:_0xdd0b9b,blocking:_0x3bf174,terminated:_0x1302ee}={}){const _0x12e1d0=indexedDB['open'](_0x2f5941,_0x8b0483),_0x2aa22b=_e(_0x12e1d0);return _0xdd0b9b&&_0x12e1d0['addEventListener']('upgradeneeded',_0x48b2e3=>{_0xdd0b9b(_e(_0x12e1d0['result']),_0x48b2e3['oldVersion'],_0x48b2e3['newVersion'],_e(_0x12e1d0['transaction']),_0x48b2e3);}),_0xa057f2&&_0x12e1d0['addEventListener']('blocked',_0x143461=>_0xa057f2(_0x143461['oldVersion'],_0x143461['newVersion'],_0x143461)),_0x2aa22b['then'](_0x2bfcbd=>{_0x1302ee&&_0x2bfcbd['addEventListener']('close',()=>_0x1302ee()),_0x3bf174&&_0x2bfcbd['addEventListener']('versionchange',_0x28f729=>_0x3bf174(_0x28f729['oldVersion'],_0x28f729['newVersion'],_0x28f729));})['catch'](()=>{}),_0x2aa22b;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],ei=new Map();function Ls(_0x96ea8e,_0x5358bc){if(!(_0x96ea8e instanceof IDBDatabase&&!(_0x5358bc in _0x96ea8e)&&typeof _0x5358bc=='string'))return;if(ei['get'](_0x5358bc))return ei['get'](_0x5358bc);const _0x3416ca=_0x5358bc['replace'](/FromIndex$/,''),_0x32301c=_0x5358bc!==_0x3416ca,_0x53bfe2=zc['includes'](_0x3416ca);if(!(_0x3416ca in(_0x32301c?IDBIndex:IDBObjectStore)['prototype'])||!(_0x53bfe2||qc['includes'](_0x3416ca)))return;const _0x5b7219=async function(_0x1afec8,..._0x888758){const _0x4c9ba6=this['transaction'](_0x1afec8,_0x53bfe2?'readwrite':'readonly');let _0x2f0a72=_0x4c9ba6['store'];return _0x32301c&&(_0x2f0a72=_0x2f0a72['index'](_0x888758['shift']())),(await Promise['all']([_0x2f0a72[_0x3416ca](..._0x888758),_0x53bfe2&&_0x4c9ba6['done']]))[0x0];};return ei['set'](_0x5358bc,_0x5b7219),_0x5b7219;}Vc(_0x263960=>({..._0x263960,'get':(_0x3e87e8,_0x68f013,_0x188ec1)=>Ls(_0x3e87e8,_0x68f013)||_0x263960['get'](_0x3e87e8,_0x68f013,_0x188ec1),'has':(_0x173e19,_0x32b0e8)=>!!Ls(_0x173e19,_0x32b0e8)||_0x263960['has'](_0x173e19,_0x32b0e8)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x1ad5ae){this['container']=_0x1ad5ae;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x12e200=>{if(Kc(_0x12e200)){const _0x256727=_0x12e200['getImmediate']();return _0x256727['library']+'/'+_0x256727['version'];}else return null;})['filter'](_0x58a1b7=>_0x58a1b7)['join']('\x20');}}function Kc(_0x2b76cc){const _0x108bfd=_0x2b76cc['getComponent']();return(_0x108bfd==null?void 0x0:_0x108bfd['type'])==='VERSION';}const pi='@firebase/app',xs='0.14.6',oe=new Ui('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.6.0',_i='[DEFAULT]',wl={[pi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},xe=new Map(),gi=new Map(),mi=new Map();function Fs(_0x29084a,_0x58c445){try{_0x29084a['container']['addComponent'](_0x58c445);}catch(_0x56c176){oe['debug']('Component\x20'+_0x58c445['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x29084a['name'],_0x56c176);}}function Ze(_0x45dad0){const _0x41c2fe=_0x45dad0['name'];if(mi['has'](_0x41c2fe))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x41c2fe+'.'),!0x1;mi['set'](_0x41c2fe,_0x45dad0);for(const _0x4dcd37 of xe['values']())Fs(_0x4dcd37,_0x45dad0);for(const _0x484121 of gi['values']())Fs(_0x484121,_0x45dad0);return!0x0;}function Bi(_0x20e73b,_0x2bfbff){const _0x1e6340=_0x20e73b['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x1e6340&&_0x1e6340['triggerHeartbeat'](),_0x20e73b['container']['getProvider'](_0x2bfbff);}function $(_0x1d474f){return _0x1d474f==null?!0x1:_0x1d474f['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Bt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x2534aa,_0x3fe08d,_0x350f85){this['_isDeleted']=!0x1,this['_options']={..._0x2534aa},this['_config']={..._0x3fe08d},this['_name']=_0x3fe08d['name'],this['_automaticDataCollectionEnabled']=_0x3fe08d['automaticDataCollectionEnabled'],this['_container']=_0x350f85,this['container']['addComponent'](new Le('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x2ba82a){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x2ba82a;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x47e87d){this['_isDeleted']=_0x47e87d;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const lt=Il;function Sl(_0x439301,_0x1dacc0={}){let _0x15994a=_0x439301;typeof _0x1dacc0!='object'&&(_0x1dacc0={'name':_0x1dacc0});const _0x1e6e67={'name':_i,'automaticDataCollectionEnabled':!0x0,..._0x1dacc0},_0x2954de=_0x1e6e67['name'];if(typeof _0x2954de!='string'||!_0x2954de)throw ge['create']('bad-app-name',{'appName':String(_0x2954de)});if(_0x15994a||(_0x15994a=qr()),!_0x15994a)throw ge['create']('no-options');const _0x6cf435=xe['get'](_0x2954de);if(_0x6cf435){if(Me(_0x15994a,_0x6cf435['options'])&&Me(_0x1e6e67,_0x6cf435['config']))return _0x6cf435;throw ge['create']('duplicate-app',{'appName':_0x2954de});}const _0x5b743f=new Pc(_0x2954de);for(const _0x79c908 of mi['values']())_0x5b743f['addComponent'](_0x79c908);const _0x45fe78=new Tl(_0x15994a,_0x1e6e67,_0x5b743f);return xe['set'](_0x2954de,_0x45fe78),_0x45fe78;}function Zr(_0x5a7868=_i){const _0x2fb0c0=xe['get'](_0x5a7868);if(!_0x2fb0c0&&_0x5a7868===_i&&qr())return Sl();if(!_0x2fb0c0)throw ge['create']('no-app',{'appName':_0x5a7868});return _0x2fb0c0;}function f_(){return Array['from'](xe['values']());}async function p_(_0x32d3cc){let _0x3c415b=!0x1;const _0x44fb79=_0x32d3cc['name'];xe['has'](_0x44fb79)?(_0x3c415b=!0x0,xe['delete'](_0x44fb79)):gi['has'](_0x44fb79)&&_0x32d3cc['decRefCount']()<=0x0&&(gi['delete'](_0x44fb79),_0x3c415b=!0x0),_0x3c415b&&(await Promise['all'](_0x32d3cc['container']['getProviders']()['map'](_0x3080df=>_0x3080df['delete']())),_0x32d3cc['isDeleted']=!0x0);}function me(_0x13077f,_0x5368ae,_0x51b2d5){let _0x1ae816=wl[_0x13077f]??_0x13077f;_0x51b2d5&&(_0x1ae816+='-'+_0x51b2d5);const _0x55bd9d=_0x1ae816['match'](/\s|\//),_0x501e47=_0x5368ae['match'](/\s|\//);if(_0x55bd9d||_0x501e47){const _0x350c72=['Unable\x20to\x20register\x20library\x20\x22'+_0x1ae816+'\x22\x20with\x20version\x20\x22'+_0x5368ae+'\x22:'];_0x55bd9d&&_0x350c72['push']('library\x20name\x20\x22'+_0x1ae816+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x55bd9d&&_0x501e47&&_0x350c72['push']('and'),_0x501e47&&_0x350c72['push']('version\x20name\x20\x22'+_0x5368ae+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x350c72['join']('\x20'));return;}Ze(new Le(_0x1ae816+'-version',()=>({'library':_0x1ae816,'version':_0x5368ae}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,kt='firebase-heartbeat-store';let ti=null;function eo(){return ti||(ti=Gc(bl,Rl,{'upgrade':(_0x3b7b19,_0x1e0e8c)=>{switch(_0x1e0e8c){case 0x0:try{_0x3b7b19['createObjectStore'](kt);}catch(_0x774088){console['warn'](_0x774088);}}}})['catch'](_0x2cfe16=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x2cfe16['message']});})),ti;}async function Al(_0x13a28c){try{const _0x4e391e=(await eo())['transaction'](kt),_0x31331c=await _0x4e391e['objectStore'](kt)['get'](to(_0x13a28c));return await _0x4e391e['done'],_0x31331c;}catch(_0x4d6566){if(_0x4d6566 instanceof Se)oe['warn'](_0x4d6566['message']);else{const _0x1128fd=ge['create']('idb-get',{'originalErrorMessage':_0x4d6566==null?void 0x0:_0x4d6566['message']});oe['warn'](_0x1128fd['message']);}}}async function Us(_0x27c63,_0x4ebd05){try{const _0xd4c73c=(await eo())['transaction'](kt,'readwrite');await _0xd4c73c['objectStore'](kt)['put'](_0x4ebd05,to(_0x27c63)),await _0xd4c73c['done'];}catch(_0x4c3c7e){if(_0x4c3c7e instanceof Se)oe['warn'](_0x4c3c7e['message']);else{const _0x41affd=ge['create']('idb-set',{'originalErrorMessage':_0x4c3c7e==null?void 0x0:_0x4c3c7e['message']});oe['warn'](_0x41affd['message']);}}}function to(_0x11ffa0){return _0x11ffa0['name']+'!'+_0x11ffa0['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Nl=0x1e;class Pl{constructor(_0x47f774){this['container']=_0x47f774,this['_heartbeatsCache']=null;const _0x2fe3be=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x2fe3be),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x2097e8=>(this['_heartbeatsCache']=_0x2097e8,_0x2097e8));}async['triggerHeartbeat'](){var _0x574a68,_0xadff62;try{const _0x6a6cbf=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x2218ee=Ws();if(((_0x574a68=this['_heartbeatsCache'])==null?void 0x0:_0x574a68['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0xadff62=this['_heartbeatsCache'])==null?void 0x0:_0xadff62['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x2218ee||this['_heartbeatsCache']['heartbeats']['some'](_0x14bcbc=>_0x14bcbc['date']===_0x2218ee))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x2218ee,'agent':_0x6a6cbf}),this['_heartbeatsCache']['heartbeats']['length']>Nl){const _0x3caedb=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x3caedb,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x24f6d3){oe['warn'](_0x24f6d3);}}async['getHeartbeatsHeader'](){var _0x4fb482;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x4fb482=this['_heartbeatsCache'])==null?void 0x0:_0x4fb482['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x36fc26=Ws(),{heartbeatsToSend:_0x27501f,unsentEntries:_0x2fab31}=Ol(this['_heartbeatsCache']['heartbeats']),_0x5afe44=cn(JSON['stringify']({'version':0x2,'heartbeats':_0x27501f}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x36fc26,_0x2fab31['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x2fab31,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x5afe44;}catch(_0x3f763c){return oe['warn'](_0x3f763c),'';}}}function Ws(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x442713,_0x41f02b=kl){const _0xb04752=[];let _0x4229b8=_0x442713['slice']();for(const _0x201f3c of _0x442713){const _0x38a654=_0xb04752['find'](_0x37a227=>_0x37a227['agent']===_0x201f3c['agent']);if(_0x38a654){if(_0x38a654['dates']['push'](_0x201f3c['date']),Bs(_0xb04752)>_0x41f02b){_0x38a654['dates']['pop']();break;}}else{if(_0xb04752['push']({'agent':_0x201f3c['agent'],'dates':[_0x201f3c['date']]}),Bs(_0xb04752)>_0x41f02b){_0xb04752['pop']();break;}}_0x4229b8=_0x4229b8['slice'](0x1);}return{'heartbeatsToSend':_0xb04752,'unsentEntries':_0x4229b8};}class Dl{constructor(_0x1177d6){this['app']=_0x1177d6,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x30f8d9=await Al(this['app']);return _0x30f8d9!=null&&_0x30f8d9['heartbeats']?_0x30f8d9:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x277e32){if(await this['_canUseIndexedDBPromise']){const _0x5498a0=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x277e32['lastSentHeartbeatDate']??_0x5498a0['lastSentHeartbeatDate'],'heartbeats':_0x277e32['heartbeats']});}else return;}async['add'](_0x4090c0){if(await this['_canUseIndexedDBPromise']){const _0x339493=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x4090c0['lastSentHeartbeatDate']??_0x339493['lastSentHeartbeatDate'],'heartbeats':[..._0x339493['heartbeats'],..._0x4090c0['heartbeats']]});}else return;}}function Bs(_0x5227b1){return cn(JSON['stringify']({'version':0x2,'heartbeats':_0x5227b1}))['length'];}function Ml(_0x15b29a){if(_0x15b29a['length']===0x0)return-0x1;let _0x3363bd=0x0,_0xdacd30=_0x15b29a[0x0]['date'];for(let _0x549fcc=0x1;_0x549fcc<_0x15b29a['length'];_0x549fcc++)_0x15b29a[_0x549fcc]['date']<_0xdacd30&&(_0xdacd30=_0x15b29a[_0x549fcc]['date'],_0x3363bd=_0x549fcc);return _0x3363bd;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x3bb0a7){Ze(new Le('platform-logger',_0x3e7fcf=>new jc(_0x3e7fcf),'PRIVATE')),Ze(new Le('heartbeat',_0x1332c2=>new Pl(_0x1332c2),'PRIVATE')),me(pi,xs,_0x3bb0a7),me(pi,xs,'esm2020'),me('fire-js','');}Ll('');var xl='firebase',Fl='12.6.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(xl,Fl,'app');var Vs={};const Hs='@firebase/database',$s='1.1.0';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x2f806b){no=_0x2f806b;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x38b7a3){this['domStorage_']=_0x38b7a3,this['prefix_']='firebase:';}['set'](_0x2b9b06,_0x53d446){_0x53d446==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x2b9b06)):this['domStorage_']['setItem'](this['prefixedName_'](_0x2b9b06),O(_0x53d446));}['get'](_0x5829b5){const _0x2d5699=this['domStorage_']['getItem'](this['prefixedName_'](_0x5829b5));return _0x2d5699==null?null:At(_0x2d5699);}['remove'](_0x4bd0a1){this['domStorage_']['removeItem'](this['prefixedName_'](_0x4bd0a1));}['prefixedName_'](_0x114186){return this['prefix_']+_0x114186;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x5c4f47,_0x5ce119){_0x5ce119==null?delete this['cache_'][_0x5c4f47]:this['cache_'][_0x5c4f47]=_0x5ce119;}['get'](_0x28e416){return J(this['cache_'],_0x28e416)?this['cache_'][_0x28e416]:null;}['remove'](_0x32c0b8){delete this['cache_'][_0x32c0b8];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0xd16d42){try{if(typeof window<'u'&&typeof window[_0xd16d42]<'u'){const _0x53a597=window[_0xd16d42];return _0x53a597['setItem']('firebase:sentinel','cache'),_0x53a597['removeItem']('firebase:sentinel'),new Wl(_0x53a597);}}catch{}return new Bl();},Oe=io('localStorage'),Vl=io('sessionStorage'),Ye=new Ui('@firebase/database'),so=(function(){let _0x5e84df=0x1;return function(){return _0x5e84df++;};}()),ro=function(_0x310d75){const _0x44a57a=Rc(_0x310d75),_0x2e2bb3=new Cc();_0x2e2bb3['update'](_0x44a57a);const _0x1b037d=_0x2e2bb3['digest']();return Li['encodeByteArray'](_0x1b037d);},Vt=function(..._0x4e6fed){let _0x59026b='';for(let _0x54882f=0x0;_0x54882f<_0x4e6fed['length'];_0x54882f++){const _0x3d8a4f=_0x4e6fed[_0x54882f];Array['isArray'](_0x3d8a4f)||_0x3d8a4f&&typeof _0x3d8a4f=='object'&&typeof _0x3d8a4f['length']=='number'?_0x59026b+=Vt['apply'](null,_0x3d8a4f):typeof _0x3d8a4f=='object'?_0x59026b+=O(_0x3d8a4f):_0x59026b+=_0x3d8a4f,_0x59026b+='\x20';}return _0x59026b;};let wt=null,Gs=!0x0;const Hl=function(_0x2564b4,_0x10d874){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ye['logLevel']=T['VERBOSE'],wt=Ye['log']['bind'](Ye);},L=function(..._0x357c66){if(Gs===!0x0&&(Gs=!0x1,wt===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),wt){const _0x29c454=Vt['apply'](null,_0x357c66);wt(_0x29c454);}},Ht=function(_0x1d3432){return function(..._0x341a3c){L(_0x1d3432,..._0x341a3c);};},yi=function(..._0x3add97){const _0x5dc2e6='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Vt(..._0x3add97);Ye['error'](_0x5dc2e6);},ae=function(..._0xbdcfd9){const _0x16baea='FIREBASE\x20FATAL\x20ERROR:\x20'+Vt(..._0xbdcfd9);throw Ye['error'](_0x16baea),new Error(_0x16baea);},U=function(..._0x40c1b6){const _0x47e02e='FIREBASE\x20WARNING:\x20'+Vt(..._0x40c1b6);Ye['warn'](_0x47e02e);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Vi=function(_0x57e39e){return typeof _0x57e39e=='number'&&(_0x57e39e!==_0x57e39e||_0x57e39e===Number['POSITIVE_INFINITY']||_0x57e39e===Number['NEGATIVE_INFINITY']);},Gl=function(_0x3abcda){if(document['readyState']==='complete')_0x3abcda();else{let _0x18ff7f=!0x1;const _0x2774bb=function(){if(!document['body']){setTimeout(_0x2774bb,Math['floor'](0xa));return;}_0x18ff7f||(_0x18ff7f=!0x0,_0x3abcda());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x2774bb,!0x1),window['addEventListener']('load',_0x2774bb,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x2774bb();}),window['attachEvent']('onload',_0x2774bb));}},Fe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x23cc9c,_0x340128){if(_0x23cc9c===_0x340128)return 0x0;if(_0x23cc9c===Fe||_0x340128===Ie)return-0x1;if(_0x340128===Fe||_0x23cc9c===Ie)return 0x1;{const _0x65d859=qs(_0x23cc9c),_0x1b1a36=qs(_0x340128);return _0x65d859!==null?_0x1b1a36!==null?_0x65d859-_0x1b1a36===0x0?_0x23cc9c['length']-_0x340128['length']:_0x65d859-_0x1b1a36:-0x1:_0x1b1a36!==null?0x1:_0x23cc9c<_0x340128?-0x1:0x1;}},ql=function(_0x5aa0d5,_0x9b7a70){return _0x5aa0d5===_0x9b7a70?0x0:_0x5aa0d5<_0x9b7a70?-0x1:0x1;},_t=function(_0x89b305,_0x5aee73){if(_0x5aee73&&_0x89b305 in _0x5aee73)return _0x5aee73[_0x89b305];throw new Error('Missing\x20required\x20key\x20('+_0x89b305+')\x20in\x20object:\x20'+O(_0x5aee73));},Hi=function(_0x1ed914){if(typeof _0x1ed914!='object'||_0x1ed914===null)return O(_0x1ed914);const _0x4e4afb=[];for(const _0x5117d0 in _0x1ed914)_0x4e4afb['push'](_0x5117d0);_0x4e4afb['sort']();let _0x106939='{';for(let _0x376d34=0x0;_0x376d34<_0x4e4afb['length'];_0x376d34++)_0x376d34!==0x0&&(_0x106939+=','),_0x106939+=O(_0x4e4afb[_0x376d34]),_0x106939+=':',_0x106939+=Hi(_0x1ed914[_0x4e4afb[_0x376d34]]);return _0x106939+='}',_0x106939;},oo=function(_0x3a6733,_0x360d30){const _0x34e58b=_0x3a6733['length'];if(_0x34e58b<=_0x360d30)return[_0x3a6733];const _0x4972f8=[];for(let _0xae25f=0x0;_0xae25f<_0x34e58b;_0xae25f+=_0x360d30)_0xae25f+_0x360d30>_0x34e58b?_0x4972f8['push'](_0x3a6733['substring'](_0xae25f,_0x34e58b)):_0x4972f8['push'](_0x3a6733['substring'](_0xae25f,_0xae25f+_0x360d30));return _0x4972f8;};function x(_0x96474d,_0x1f6e00){for(const _0x14cdcc in _0x96474d)_0x96474d['hasOwnProperty'](_0x14cdcc)&&_0x1f6e00(_0x14cdcc,_0x96474d[_0x14cdcc]);}const ao=function(_0x2dd42d){f(!Vi(_0x2dd42d),'Invalid\x20JSON\x20number');const _0x4afdf1=0xb,_0x249c0c=0x34,_0x27d720=(0x1<<_0x4afdf1-0x1)-0x1;let _0x16a0fa,_0x260f89,_0x411e04,_0x29a653,_0x6b3edf;_0x2dd42d===0x0?(_0x260f89=0x0,_0x411e04=0x0,_0x16a0fa=0x1/_0x2dd42d===-0x1/0x0?0x1:0x0):(_0x16a0fa=_0x2dd42d<0x0,_0x2dd42d=Math['abs'](_0x2dd42d),_0x2dd42d>=Math['pow'](0x2,0x1-_0x27d720)?(_0x29a653=Math['min'](Math['floor'](Math['log'](_0x2dd42d)/Math['LN2']),_0x27d720),_0x260f89=_0x29a653+_0x27d720,_0x411e04=Math['round'](_0x2dd42d*Math['pow'](0x2,_0x249c0c-_0x29a653)-Math['pow'](0x2,_0x249c0c))):(_0x260f89=0x0,_0x411e04=Math['round'](_0x2dd42d/Math['pow'](0x2,0x1-_0x27d720-_0x249c0c))));const _0x8bd781=[];for(_0x6b3edf=_0x249c0c;_0x6b3edf;_0x6b3edf-=0x1)_0x8bd781['push'](_0x411e04%0x2?0x1:0x0),_0x411e04=Math['floor'](_0x411e04/0x2);for(_0x6b3edf=_0x4afdf1;_0x6b3edf;_0x6b3edf-=0x1)_0x8bd781['push'](_0x260f89%0x2?0x1:0x0),_0x260f89=Math['floor'](_0x260f89/0x2);_0x8bd781['push'](_0x16a0fa?0x1:0x0),_0x8bd781['reverse']();const _0x5ab397=_0x8bd781['join']('');let _0xe8b813='';for(_0x6b3edf=0x0;_0x6b3edf<0x40;_0x6b3edf+=0x8){let _0x108e43=parseInt(_0x5ab397['substr'](_0x6b3edf,0x8),0x2)['toString'](0x10);_0x108e43['length']===0x1&&(_0x108e43='0'+_0x108e43),_0xe8b813=_0xe8b813+_0x108e43;}return _0xe8b813['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x4e874f,_0x5696ad){let _0x35808b='Unknown\x20Error';_0x4e874f==='too_big'?_0x35808b='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x4e874f==='permission_denied'?_0x35808b='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x4e874f==='unavailable'&&(_0x35808b='The\x20service\x20is\x20unavailable');const _0x41a066=new Error(_0x4e874f+'\x20at\x20'+_0x5696ad['_path']['toString']()+':\x20'+_0x35808b);return _0x41a066['code']=_0x4e874f['toUpperCase'](),_0x41a066;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,qs=function(_0x397f46){if(Yl['test'](_0x397f46)){const _0x30dbb6=Number(_0x397f46);if(_0x30dbb6>=Ql&&_0x30dbb6<=Jl)return _0x30dbb6;}return null;},ht=function(_0x1d7456){try{_0x1d7456();}catch(_0x14aaca){setTimeout(()=>{const _0x4a439b=_0x14aaca['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x4a439b),_0x14aaca;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},Ct=function(_0x33927a,_0x36b1d3){const _0x319dec=setTimeout(_0x33927a,_0x36b1d3);return typeof _0x319dec=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x319dec):typeof _0x319dec=='object'&&_0x319dec['unref']&&_0x319dec['unref'](),_0x319dec;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x35eb1d,_0x4bb7c4){this['appCheckProvider']=_0x4bb7c4,this['appName']=_0x35eb1d['name'],$(_0x35eb1d)&&_0x35eb1d['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x35eb1d['settings']['appCheckToken']),this['appCheck']=_0x4bb7c4==null?void 0x0:_0x4bb7c4['getImmediate']({'optional':!0x0}),this['appCheck']||_0x4bb7c4==null||_0x4bb7c4['get']()['then'](_0x2e900a=>this['appCheck']=_0x2e900a);}['getToken'](_0x59322e){if(this['serverAppAppCheckToken']){if(_0x59322e)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x59322e):new Promise((_0x3f7f67,_0x48c95c)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x59322e)['then'](_0x3f7f67,_0x48c95c):_0x3f7f67(null);},0x0);});}['addTokenChangeListener'](_0x210cd3){var _0x45776c;(_0x45776c=this['appCheckProvider'])==null||_0x45776c['get']()['then'](_0x57ceb4=>_0x57ceb4['addTokenListener'](_0x210cd3));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x3e0fa1,_0x51de1,_0x28e528){this['appName_']=_0x3e0fa1,this['firebaseOptions_']=_0x51de1,this['authProvider_']=_0x28e528,this['auth_']=null,this['auth_']=_0x28e528['getImmediate']({'optional':!0x0}),this['auth_']||_0x28e528['onInit'](_0x126801=>this['auth_']=_0x126801);}['getToken'](_0x6a96db){return this['auth_']?this['auth_']['getToken'](_0x6a96db)['catch'](_0x31a600=>_0x31a600&&_0x31a600['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x31a600)):new Promise((_0x48be31,_0x4a8816)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x6a96db)['then'](_0x48be31,_0x4a8816):_0x48be31(null);},0x0);});}['addTokenChangeListener'](_0x16b274){this['auth_']?this['auth_']['addAuthTokenListener'](_0x16b274):this['authProvider_']['get']()['then'](_0x5ea6b5=>_0x5ea6b5['addAuthTokenListener'](_0x16b274));}['removeTokenChangeListener'](_0x4fe24c){this['authProvider_']['get']()['then'](_0x1b8abc=>_0x1b8abc['removeAuthTokenListener'](_0x4fe24c));}['notifyForInvalidToken'](){let _0x4a6e84='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x4a6e84+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x4a6e84+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x4a6e84+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x4a6e84);}}class nn{constructor(_0x2ff0a5){this['accessToken']=_0x2ff0a5;}['getToken'](_0x59dda5){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0xffded6){_0xffded6(this['accessToken']);}['removeTokenChangeListener'](_0x37b5b4){}['notifyForInvalidToken'](){}}nn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $i='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',vi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x1e605a,_0x5702b6,_0x4dc73b,_0x2118a0,_0x5ce4cd=!0x1,_0x28c04a='',_0x530bca=!0x1,_0x715fb=!0x1,_0x15d39e=null){this['secure']=_0x5702b6,this['namespace']=_0x4dc73b,this['webSocketOnly']=_0x2118a0,this['nodeAdmin']=_0x5ce4cd,this['persistenceKey']=_0x28c04a,this['includeNamespaceInQueryParams']=_0x530bca,this['isUsingEmulator']=_0x715fb,this['emulatorOptions']=_0x15d39e,this['_host']=_0x1e605a['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Oe['get']('host:'+_0x1e605a)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x1f8b78){_0x1f8b78!==this['internalHost']&&(this['internalHost']=_0x1f8b78,this['isCacheableHost']()&&Oe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x412165=this['toURLString']();return this['persistenceKey']&&(_0x412165+='<'+this['persistenceKey']+'>'),_0x412165;}['toURLString'](){const _0x2fc53c=this['secure']?'https://':'http://',_0x22a20c=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x2fc53c+this['host']+'/'+_0x22a20c;}}function th(_0xb36dbf){return _0xb36dbf['host']!==_0xb36dbf['internalHost']||_0xb36dbf['isCustomHost']()||_0xb36dbf['includeNamespaceInQueryParams'];}function vo(_0x277f39,_0x236f07,_0x4ae0cd){f(typeof _0x236f07=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x4ae0cd=='object','typeof\x20params\x20must\x20==\x20object');let _0x63bd29;if(_0x236f07===go)_0x63bd29=(_0x277f39['secure']?'wss://':'ws://')+_0x277f39['internalHost']+'/.ws?';else{if(_0x236f07===mo)_0x63bd29=(_0x277f39['secure']?'https://':'http://')+_0x277f39['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x236f07);}th(_0x277f39)&&(_0x4ae0cd['ns']=_0x277f39['namespace']);const _0xb41a68=[];return x(_0x4ae0cd,(_0x52cf99,_0x4d147e)=>{_0xb41a68['push'](_0x52cf99+'='+_0x4d147e);}),_0x63bd29+_0xb41a68['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x50c28b,_0x3c421d=0x1){J(this['counters_'],_0x50c28b)||(this['counters_'][_0x50c28b]=0x0),this['counters_'][_0x50c28b]+=_0x3c421d;}['get'](){return nc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ni={},ii={};function Gi(_0x2b81bd){const _0x285699=_0x2b81bd['toString']();return ni[_0x285699]||(ni[_0x285699]=new nh()),ni[_0x285699];}function ih(_0x5c57ce,_0x4be945){const _0x1902ed=_0x5c57ce['toString']();return ii[_0x1902ed]||(ii[_0x1902ed]=_0x4be945()),ii[_0x1902ed];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x422e15){this['onMessage_']=_0x422e15,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x3ca659,_0x287bc7){this['closeAfterResponse']=_0x3ca659,this['onClose']=_0x287bc7,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x2eb2c6,_0x57d6d0){for(this['pendingResponses'][_0x2eb2c6]=_0x57d6d0;this['pendingResponses'][this['currentResponseNum']];){const _0x10f03a=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x21de3f=0x0;_0x21de3f<_0x10f03a['length'];++_0x21de3f)_0x10f03a[_0x21de3f]&&ht(()=>{this['onMessage_'](_0x10f03a[_0x21de3f]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class je{constructor(_0x39a417,_0x362261,_0x2f5a58,_0x426949,_0x3116e0,_0x4c9dc6,_0x2b8c4d){this['connId']=_0x39a417,this['repoInfo']=_0x362261,this['applicationId']=_0x2f5a58,this['appCheckToken']=_0x426949,this['authToken']=_0x3116e0,this['transportSessionId']=_0x4c9dc6,this['lastSessionId']=_0x2b8c4d,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Ht(_0x39a417),this['stats_']=Gi(_0x362261),this['urlFn']=_0x143594=>(this['appCheckToken']&&(_0x143594[vi]=this['appCheckToken']),vo(_0x362261,mo,_0x143594));}['open'](_0x649ebb,_0x281bdf){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x281bdf,this['myPacketOrderer']=new sh(_0x649ebb),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new qi((..._0x596d6b)=>{const [_0x531dda,_0xc0c74b,_0x363c33,_0x1219c6,_0x270dcf]=_0x596d6b;if(this['incrementIncomingBytes_'](_0x596d6b),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x531dda===zs)this['id']=_0xc0c74b,this['password']=_0x363c33;else{if(_0x531dda===rh)_0xc0c74b?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0xc0c74b,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x531dda);}}},(..._0x294fef)=>{const [_0x4b0e90,_0x33db69]=_0x294fef;this['incrementIncomingBytes_'](_0x294fef),this['myPacketOrderer']['handleResponse'](_0x4b0e90,_0x33db69);},()=>{this['onClosed_']();},this['urlFn']);const _0x54f0c4={};_0x54f0c4[zs]='t',_0x54f0c4[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x54f0c4[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x54f0c4[co]=$i,this['transportSessionId']&&(_0x54f0c4[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x54f0c4[po]=this['lastSessionId']),this['applicationId']&&(_0x54f0c4[_o]=this['applicationId']),this['appCheckToken']&&(_0x54f0c4[vi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x54f0c4[ho]=uo);const _0x89334e=this['urlFn'](_0x54f0c4);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x89334e),this['scriptTagHolder']['addTag'](_0x89334e,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){je['forceAllow_']=!0x0;}static['forceDisallow'](){je['forceDisallow_']=!0x0;}static['isAvailable'](){return je['forceAllow_']?!0x0:!je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x59bce0){const _0x3a13ca=O(_0x59bce0);this['bytesSent']+=_0x3a13ca['length'],this['stats_']['incrementCounter']('bytes_sent',_0x3a13ca['length']);const _0x5d0361=Hr(_0x3a13ca),_0x18b387=oo(_0x5d0361,fh);for(let _0x5241cd=0x0;_0x5241cd<_0x18b387['length'];_0x5241cd++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x18b387['length'],_0x18b387[_0x5241cd]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x1dff72,_0x24b668){this['myDisconnFrame']=document['createElement']('iframe');const _0x13834a={};_0x13834a[dh]='t',_0x13834a[Eo]=_0x1dff72,_0x13834a[Io]=_0x24b668,this['myDisconnFrame']['src']=this['urlFn'](_0x13834a),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x1fe5c8){const _0x43d2ae=O(_0x1fe5c8)['length'];this['bytesReceived']+=_0x43d2ae,this['stats_']['incrementCounter']('bytes_received',_0x43d2ae);}}class qi{constructor(_0x3809df,_0x5891fa,_0x56c3a5,_0x47fd0c){this['onDisconnect']=_0x56c3a5,this['urlFn']=_0x47fd0c,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x3809df,window[ah+this['uniqueCallbackIdentifier']]=_0x5891fa,this['myIFrame']=qi['createIFrame_']();let _0x3eaf48='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x3eaf48='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x1be86c='<html><body>'+_0x3eaf48+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x1be86c),this['myIFrame']['doc']['close']();}catch(_0x18aa02){L('frame\x20writing\x20exception'),_0x18aa02['stack']&&L(_0x18aa02['stack']),L(_0x18aa02);}}}static['createIFrame_'](){const _0x324003=document['createElement']('iframe');if(_0x324003['style']['display']='none',document['body']){document['body']['appendChild'](_0x324003);try{_0x324003['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x5b4261=document['domain'];_0x324003['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x5b4261+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x324003['contentDocument']?_0x324003['doc']=_0x324003['contentDocument']:_0x324003['contentWindow']?_0x324003['doc']=_0x324003['contentWindow']['document']:_0x324003['document']&&(_0x324003['doc']=_0x324003['document']),_0x324003;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x4645e3=this['onDisconnect'];_0x4645e3&&(this['onDisconnect']=null,_0x4645e3());}['startLongPoll'](_0x385dd8,_0x35f5f8){for(this['myID']=_0x385dd8,this['myPW']=_0x35f5f8,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x5c00c3={};_0x5c00c3[Eo]=this['myID'],_0x5c00c3[Io]=this['myPW'],_0x5c00c3[wo]=this['currentSerial'];let _0x5d99c8=this['urlFn'](_0x5c00c3),_0x3868e9='',_0x1492cc=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x3868e9['length']<=Co;){const _0x3bfd35=this['pendingSegs']['shift']();_0x3868e9=_0x3868e9+'&'+lh+_0x1492cc+'='+_0x3bfd35['seg']+'&'+hh+_0x1492cc+'='+_0x3bfd35['ts']+'&'+uh+_0x1492cc+'='+_0x3bfd35['d'],_0x1492cc++;}return _0x5d99c8=_0x5d99c8+_0x3868e9,this['addLongPollTag_'](_0x5d99c8,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x2731f6,_0x406219,_0x42e25b){this['pendingSegs']['push']({'seg':_0x2731f6,'ts':_0x406219,'d':_0x42e25b}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x575f40,_0x190c9a){this['outstandingRequests']['add'](_0x190c9a);const _0x10bf6f=()=>{this['outstandingRequests']['delete'](_0x190c9a),this['newRequest_']();},_0x4e02a3=setTimeout(_0x10bf6f,Math['floor'](ph)),_0xb7dff8=()=>{clearTimeout(_0x4e02a3),_0x10bf6f();};this['addTag'](_0x575f40,_0xb7dff8);}['addTag'](_0x274d9a,_0x233389){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x30e0e2=this['myIFrame']['doc']['createElement']('script');_0x30e0e2['type']='text/javascript',_0x30e0e2['async']=!0x0,_0x30e0e2['src']=_0x274d9a,_0x30e0e2['onload']=_0x30e0e2['onreadystatechange']=function(){const _0x2cc589=_0x30e0e2['readyState'];(!_0x2cc589||_0x2cc589==='loaded'||_0x2cc589==='complete')&&(_0x30e0e2['onload']=_0x30e0e2['onreadystatechange']=null,_0x30e0e2['parentNode']&&_0x30e0e2['parentNode']['removeChild'](_0x30e0e2),_0x233389());},_0x30e0e2['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x274d9a),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x30e0e2);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let un=null;typeof MozWebSocket<'u'?un=MozWebSocket:typeof WebSocket<'u'&&(un=WebSocket);class z{constructor(_0x1b56de,_0x53478a,_0x1c1c34,_0x19c784,_0x23227d,_0x755c5b,_0x4207f4){this['connId']=_0x1b56de,this['applicationId']=_0x1c1c34,this['appCheckToken']=_0x19c784,this['authToken']=_0x23227d,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Ht(this['connId']),this['stats_']=Gi(_0x53478a),this['connURL']=z['connectionURL_'](_0x53478a,_0x755c5b,_0x4207f4,_0x19c784,_0x1c1c34),this['nodeAdmin']=_0x53478a['nodeAdmin'];}static['connectionURL_'](_0x32f1d1,_0x11c984,_0xfa9c02,_0x6a6d95,_0x4f165c){const _0x28ad5b={};return _0x28ad5b[co]=$i,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x28ad5b[ho]=uo),_0x11c984&&(_0x28ad5b[lo]=_0x11c984),_0xfa9c02&&(_0x28ad5b[po]=_0xfa9c02),_0x6a6d95&&(_0x28ad5b[vi]=_0x6a6d95),_0x4f165c&&(_0x28ad5b[_o]=_0x4f165c),vo(_0x32f1d1,go,_0x28ad5b);}['open'](_0x4d4b58,_0x5020e7){this['onDisconnect']=_0x5020e7,this['onMessage']=_0x4d4b58,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Oe['set']('previous_websocket_failure',!0x0);try{let _0x4b1cf9;_c(),this['mySock']=new un(this['connURL'],[],_0x4b1cf9);}catch(_0x765040){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x395607=_0x765040['message']||_0x765040['data'];_0x395607&&this['log_'](_0x395607),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x46f7e3=>{this['handleIncomingFrame'](_0x46f7e3);},this['mySock']['onerror']=_0x4fac79=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x36f00b=_0x4fac79['message']||_0x4fac79['data'];_0x36f00b&&this['log_'](_0x36f00b),this['onClosed_']();};}['start'](){}static['forceDisallow'](){z['forceDisallow_']=!0x0;}static['isAvailable'](){let _0x380fa2=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x2d025d=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x2e7364=navigator['userAgent']['match'](_0x2d025d);_0x2e7364&&_0x2e7364['length']>0x1&&parseFloat(_0x2e7364[0x1])<4.4&&(_0x380fa2=!0x0);}return!_0x380fa2&&un!==null&&!z['forceDisallow_'];}static['previouslyFailed'](){return Oe['isInMemoryStorage']||Oe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Oe['remove']('previous_websocket_failure');}['appendFrame_'](_0x4daebb){if(this['frames']['push'](_0x4daebb),this['frames']['length']===this['totalFrames']){const _0x518cb4=this['frames']['join']('');this['frames']=null;const _0x564e15=At(_0x518cb4);this['onMessage'](_0x564e15);}}['handleNewFrameCount_'](_0x5cb7a0){this['totalFrames']=_0x5cb7a0,this['frames']=[];}['extractFrameCount_'](_0x4803da){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x4803da['length']<=0x6){const _0x166fb7=Number(_0x4803da);if(!isNaN(_0x166fb7))return this['handleNewFrameCount_'](_0x166fb7),null;}return this['handleNewFrameCount_'](0x1),_0x4803da;}['handleIncomingFrame'](_0x2bfdb7){if(this['mySock']===null)return;const _0x51d158=_0x2bfdb7['data'];if(this['bytesReceived']+=_0x51d158['length'],this['stats_']['incrementCounter']('bytes_received',_0x51d158['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x51d158);else{const _0x496cdd=this['extractFrameCount_'](_0x51d158);_0x496cdd!==null&&this['appendFrame_'](_0x496cdd);}}['send'](_0x3b557d){this['resetKeepAlive']();const _0xcf132c=O(_0x3b557d);this['bytesSent']+=_0xcf132c['length'],this['stats_']['incrementCounter']('bytes_sent',_0xcf132c['length']);const _0x202094=oo(_0xcf132c,gh);_0x202094['length']>0x1&&this['sendString_'](String(_0x202094['length']));for(let _0x46147e=0x0;_0x46147e<_0x202094['length'];_0x46147e++)this['sendString_'](_0x202094[_0x46147e]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x30b2dc){try{this['mySock']['send'](_0x30b2dc);}catch(_0x1d0093){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x1d0093['message']||_0x1d0093['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}z['responsesRequiredToBeHealthy']=0x2,z['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nt{static get['ALL_TRANSPORTS'](){return[je,z];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x46b5f7){this['initTransports_'](_0x46b5f7);}['initTransports_'](_0x5d973c){const _0x1e7274=z&&z['isAvailable']();let _0x54885a=_0x1e7274&&!z['previouslyFailed']();if(_0x5d973c['webSocketOnly']&&(_0x1e7274||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x54885a=!0x0),_0x54885a)this['transports_']=[z];else{const _0x3ba45a=this['transports_']=[];for(const _0x2760a2 of Nt['ALL_TRANSPORTS'])_0x2760a2&&_0x2760a2['isAvailable']()&&_0x3ba45a['push'](_0x2760a2);Nt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Nt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,si='t',js='d',wh='s',Ks='r',Ch='e',Ys='o',Qs='a',Js='n',Xs='p',Th='h';class Sh{constructor(_0x27d8dc,_0x5deaa5,_0x333b31,_0x4168ee,_0x5d3b54,_0xcfd963,_0x3d8802,_0x56cb79,_0x66638f,_0x1ee63b){this['id']=_0x27d8dc,this['repoInfo_']=_0x5deaa5,this['applicationId_']=_0x333b31,this['appCheckToken_']=_0x4168ee,this['authToken_']=_0x5d3b54,this['onMessage_']=_0xcfd963,this['onReady_']=_0x3d8802,this['onDisconnect_']=_0x56cb79,this['onKill_']=_0x66638f,this['lastSessionId']=_0x1ee63b,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Ht('c:'+this['id']+':'),this['transportManager_']=new Nt(_0x5deaa5),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x5e8066=this['transportManager_']['initialTransport']();this['conn_']=new _0x5e8066(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x5e8066['responsesRequiredToBeHealthy']||0x0;const _0x45f6c2=this['connReceiver_'](this['conn_']),_0x2b2fac=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x45f6c2,_0x2b2fac);},Math['floor'](0x0));const _0x493a54=_0x5e8066['healthyTimeout']||0x0;_0x493a54>0x0&&(this['healthyTimeout_']=Ct(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x493a54)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x455bfb){return _0x214810=>{_0x455bfb===this['conn_']?this['onConnectionLost_'](_0x214810):_0x455bfb===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x19d3c0){return _0x5aba9d=>{this['state_']!==0x2&&(_0x19d3c0===this['rx_']?this['onPrimaryMessageReceived_'](_0x5aba9d):_0x19d3c0===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x5aba9d):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x2845d9){const _0x377d19={'t':'d','d':_0x2845d9};this['sendData_'](_0x377d19);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x46c694){if(si in _0x46c694){const _0x1ea927=_0x46c694[si];_0x1ea927===Qs?this['upgradeIfSecondaryHealthy_']():_0x1ea927===Ks?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x1ea927===Ys&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x339212){const _0x20e156=_t('t',_0x339212),_0x2b2692=_t('d',_0x339212);if(_0x20e156==='c')this['onSecondaryControl_'](_0x2b2692);else{if(_0x20e156==='d')this['pendingDataMessages']['push'](_0x2b2692);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x20e156);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Xs,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Js,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x197f53){const _0x688c60=_t('t',_0x197f53),_0x40a6d0=_t('d',_0x197f53);_0x688c60==='c'?this['onControl_'](_0x40a6d0):_0x688c60==='d'&&this['onDataMessage_'](_0x40a6d0);}['onDataMessage_'](_0x267761){this['onPrimaryResponse_'](),this['onMessage_'](_0x267761);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x2c29fe){const _0x4d3ea8=_t(si,_0x2c29fe);if(js in _0x2c29fe){const _0xcda420=_0x2c29fe[js];if(_0x4d3ea8===Th){const _0x5d0081={..._0xcda420};this['repoInfo_']['isUsingEmulator']&&(_0x5d0081['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x5d0081);}else{if(_0x4d3ea8===Js){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x2b0a38=0x0;_0x2b0a38<this['pendingDataMessages']['length'];++_0x2b0a38)this['onDataMessage_'](this['pendingDataMessages'][_0x2b0a38]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x4d3ea8===wh?this['onConnectionShutdown_'](_0xcda420):_0x4d3ea8===Ks?this['onReset_'](_0xcda420):_0x4d3ea8===Ch?yi('Server\x20Error:\x20'+_0xcda420):_0x4d3ea8===Ys?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):yi('Unknown\x20control\x20packet\x20command:\x20'+_0x4d3ea8);}}}['onHandshake_'](_0x345722){const _0xc95725=_0x345722['ts'],_0x2872de=_0x345722['v'],_0x1ee59e=_0x345722['h'];this['sessionId']=_0x345722['s'],this['repoInfo_']['host']=_0x1ee59e,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0xc95725),$i!==_0x2872de&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x5bc751=this['transportManager_']['upgradeTransport']();_0x5bc751&&this['startUpgrade_'](_0x5bc751);}['startUpgrade_'](_0x51dc2c){this['secondaryConn_']=new _0x51dc2c(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x51dc2c['responsesRequiredToBeHealthy']||0x0;const _0x339fa4=this['connReceiver_'](this['secondaryConn_']),_0xe3417a=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x339fa4,_0xe3417a),Ct(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x476d4f){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x476d4f),this['repoInfo_']['host']=_0x476d4f,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x538ea2,_0x489177){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x538ea2,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x489177,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):Ct(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Xs,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x2a06eb=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x2a06eb||this['rx_']===_0x2a06eb)&&this['close']();}['onConnectionLost_'](_0x5b4560){this['conn_']=null,!_0x5b4560&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Oe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0xafa3d4){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0xafa3d4),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x13be68){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x13be68);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x22e260,_0x5ede7c,_0x1075fd,_0x25919e){}['merge'](_0x524cff,_0x300d1f,_0x2a814b,_0xfdb8d1){}['refreshAuthToken'](_0x3e7e33){}['refreshAppCheckToken'](_0x1fae9b){}['onDisconnectPut'](_0x56cc2d,_0x3376cb,_0x5280fe){}['onDisconnectMerge'](_0x2ca78b,_0x542f83,_0x3170c7){}['onDisconnectCancel'](_0x3400a3,_0x40ad19){}['reportStats'](_0x55c2e3){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x6e69a9){this['allowedEvents_']=_0x6e69a9,this['listeners_']={},f(Array['isArray'](_0x6e69a9)&&_0x6e69a9['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x14ff2a,..._0x3e812c){if(Array['isArray'](this['listeners_'][_0x14ff2a])){const _0x256a80=[...this['listeners_'][_0x14ff2a]];for(let _0x260cbe=0x0;_0x260cbe<_0x256a80['length'];_0x260cbe++)_0x256a80[_0x260cbe]['callback']['apply'](_0x256a80[_0x260cbe]['context'],_0x3e812c);}}['on'](_0xd39bfb,_0x363b2c,_0x4ac193){this['validateEventType_'](_0xd39bfb),this['listeners_'][_0xd39bfb]=this['listeners_'][_0xd39bfb]||[],this['listeners_'][_0xd39bfb]['push']({'callback':_0x363b2c,'context':_0x4ac193});const _0xac1bbd=this['getInitialEvent'](_0xd39bfb);_0xac1bbd&&_0x363b2c['apply'](_0x4ac193,_0xac1bbd);}['off'](_0x65e451,_0x5707f3,_0x367da7){this['validateEventType_'](_0x65e451);const _0x1cc5bb=this['listeners_'][_0x65e451]||[];for(let _0x1aefef=0x0;_0x1aefef<_0x1cc5bb['length'];_0x1aefef++)if(_0x1cc5bb[_0x1aefef]['callback']===_0x5707f3&&(!_0x367da7||_0x367da7===_0x1cc5bb[_0x1aefef]['context'])){_0x1cc5bb['splice'](_0x1aefef,0x1);return;}}['validateEventType_'](_0x4b249b){f(this['allowedEvents_']['find'](_0x1a0ec0=>_0x1a0ec0===_0x4b249b),'Unknown\x20event:\x20'+_0x4b249b);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class dn extends bo{static['getInstance'](){return new dn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Fi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x243a0f){return f(_0x243a0f==='online','Unknown\x20event\x20type:\x20'+_0x243a0f),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Zs=0x20,er=0x300;class C{constructor(_0x2c17aa,_0x3fd794){if(_0x3fd794===void 0x0){this['pieces_']=_0x2c17aa['split']('/');let _0x457cfe=0x0;for(let _0x98f8b4=0x0;_0x98f8b4<this['pieces_']['length'];_0x98f8b4++)this['pieces_'][_0x98f8b4]['length']>0x0&&(this['pieces_'][_0x457cfe]=this['pieces_'][_0x98f8b4],_0x457cfe++);this['pieces_']['length']=_0x457cfe,this['pieceNum_']=0x0;}else this['pieces_']=_0x2c17aa,this['pieceNum_']=_0x3fd794;}['toString'](){let _0x433384='';for(let _0x453055=this['pieceNum_'];_0x453055<this['pieces_']['length'];_0x453055++)this['pieces_'][_0x453055]!==''&&(_0x433384+='/'+this['pieces_'][_0x453055]);return _0x433384||'/';}}function w(){return new C('');}function y(_0x19f083){return _0x19f083['pieceNum_']>=_0x19f083['pieces_']['length']?null:_0x19f083['pieces_'][_0x19f083['pieceNum_']];}function we(_0x2bd39c){return _0x2bd39c['pieces_']['length']-_0x2bd39c['pieceNum_'];}function b(_0x277a5d){let _0x28ef4a=_0x277a5d['pieceNum_'];return _0x28ef4a<_0x277a5d['pieces_']['length']&&_0x28ef4a++,new C(_0x277a5d['pieces_'],_0x28ef4a);}function zi(_0x2997df){return _0x2997df['pieceNum_']<_0x2997df['pieces_']['length']?_0x2997df['pieces_'][_0x2997df['pieces_']['length']-0x1]:null;}function bh(_0x355a9f){let _0x1f1524='';for(let _0x528ab1=_0x355a9f['pieceNum_'];_0x528ab1<_0x355a9f['pieces_']['length'];_0x528ab1++)_0x355a9f['pieces_'][_0x528ab1]!==''&&(_0x1f1524+='/'+encodeURIComponent(String(_0x355a9f['pieces_'][_0x528ab1])));return _0x1f1524||'/';}function Pt(_0xe59018,_0x1da5aa=0x0){return _0xe59018['pieces_']['slice'](_0xe59018['pieceNum_']+_0x1da5aa);}function Ro(_0x88b85b){if(_0x88b85b['pieceNum_']>=_0x88b85b['pieces_']['length'])return null;const _0x13c0b4=[];for(let _0x1daece=_0x88b85b['pieceNum_'];_0x1daece<_0x88b85b['pieces_']['length']-0x1;_0x1daece++)_0x13c0b4['push'](_0x88b85b['pieces_'][_0x1daece]);return new C(_0x13c0b4,0x0);}function k(_0x54e6ab,_0x424e41){const _0x2ae74d=[];for(let _0x2bb54b=_0x54e6ab['pieceNum_'];_0x2bb54b<_0x54e6ab['pieces_']['length'];_0x2bb54b++)_0x2ae74d['push'](_0x54e6ab['pieces_'][_0x2bb54b]);if(_0x424e41 instanceof C){for(let _0x26d9b6=_0x424e41['pieceNum_'];_0x26d9b6<_0x424e41['pieces_']['length'];_0x26d9b6++)_0x2ae74d['push'](_0x424e41['pieces_'][_0x26d9b6]);}else{const _0x562dcd=_0x424e41['split']('/');for(let _0x258984=0x0;_0x258984<_0x562dcd['length'];_0x258984++)_0x562dcd[_0x258984]['length']>0x0&&_0x2ae74d['push'](_0x562dcd[_0x258984]);}return new C(_0x2ae74d,0x0);}function v(_0x17c27c){return _0x17c27c['pieceNum_']>=_0x17c27c['pieces_']['length'];}function F(_0x7e0799,_0x59ee6e){const _0x47901b=y(_0x7e0799),_0x22fe18=y(_0x59ee6e);if(_0x47901b===null)return _0x59ee6e;if(_0x47901b===_0x22fe18)return F(b(_0x7e0799),b(_0x59ee6e));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x59ee6e+')\x20is\x20not\x20within\x20outerPath\x20('+_0x7e0799+')');}function Rh(_0x3f0e87,_0x2f8850){const _0x123cbe=Pt(_0x3f0e87,0x0),_0xa01290=Pt(_0x2f8850,0x0);for(let _0x42dc8b=0x0;_0x42dc8b<_0x123cbe['length']&&_0x42dc8b<_0xa01290['length'];_0x42dc8b++){const _0x524318=He(_0x123cbe[_0x42dc8b],_0xa01290[_0x42dc8b]);if(_0x524318!==0x0)return _0x524318;}return _0x123cbe['length']===_0xa01290['length']?0x0:_0x123cbe['length']<_0xa01290['length']?-0x1:0x1;}function ji(_0xe12159,_0xacc1b2){if(we(_0xe12159)!==we(_0xacc1b2))return!0x1;for(let _0x31e0fb=_0xe12159['pieceNum_'],_0x9c8b9d=_0xacc1b2['pieceNum_'];_0x31e0fb<=_0xe12159['pieces_']['length'];_0x31e0fb++,_0x9c8b9d++)if(_0xe12159['pieces_'][_0x31e0fb]!==_0xacc1b2['pieces_'][_0x9c8b9d])return!0x1;return!0x0;}function G(_0x227e55,_0x3d5e23){let _0x11f5c1=_0x227e55['pieceNum_'],_0x4efcf6=_0x3d5e23['pieceNum_'];if(we(_0x227e55)>we(_0x3d5e23))return!0x1;for(;_0x11f5c1<_0x227e55['pieces_']['length'];){if(_0x227e55['pieces_'][_0x11f5c1]!==_0x3d5e23['pieces_'][_0x4efcf6])return!0x1;++_0x11f5c1,++_0x4efcf6;}return!0x0;}class Ah{constructor(_0x209298,_0x595f13){this['errorPrefix_']=_0x595f13,this['parts_']=Pt(_0x209298,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x9d7802=0x0;_0x9d7802<this['parts_']['length'];_0x9d7802++)this['byteLength_']+=On(this['parts_'][_0x9d7802]);Ao(this);}}function kh(_0xcb7c22,_0x47fabb){_0xcb7c22['parts_']['length']>0x0&&(_0xcb7c22['byteLength_']+=0x1),_0xcb7c22['parts_']['push'](_0x47fabb),_0xcb7c22['byteLength_']+=On(_0x47fabb),Ao(_0xcb7c22);}function Nh(_0x5c469a){const _0x252f84=_0x5c469a['parts_']['pop']();_0x5c469a['byteLength_']-=On(_0x252f84),_0x5c469a['parts_']['length']>0x0&&(_0x5c469a['byteLength_']-=0x1);}function Ao(_0x35315f){if(_0x35315f['byteLength_']>er)throw new Error(_0x35315f['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+er+'\x20bytes\x20('+_0x35315f['byteLength_']+').');if(_0x35315f['parts_']['length']>Zs)throw new Error(_0x35315f['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Zs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Pe(_0x35315f));}function Pe(_0x12bf78){return _0x12bf78['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x12bf78['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends bo{static['getInstance'](){return new Ki();}constructor(){super(['visible']);let _0x43ba8,_0x4d2175;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x4d2175='visibilitychange',_0x43ba8='hidden'):typeof document['mozHidden']<'u'?(_0x4d2175='mozvisibilitychange',_0x43ba8='mozHidden'):typeof document['msHidden']<'u'?(_0x4d2175='msvisibilitychange',_0x43ba8='msHidden'):typeof document['webkitHidden']<'u'&&(_0x4d2175='webkitvisibilitychange',_0x43ba8='webkitHidden')),this['visible_']=!0x0,_0x4d2175&&document['addEventListener'](_0x4d2175,()=>{const _0x4f4d88=!document[_0x43ba8];_0x4f4d88!==this['visible_']&&(this['visible_']=_0x4f4d88,this['trigger']('visible',_0x4f4d88));},!0x1);}['getInitialEvent'](_0xfd15c0){return f(_0xfd15c0==='visible','Unknown\x20event\x20type:\x20'+_0xfd15c0),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gt=0x3e8,Ph=0x12c*0x3e8,tr=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',nr=0x3;class se extends So{constructor(_0x1accb9,_0x1e9c87,_0x10fde0,_0x2daa29,_0x26f5e0,_0x2681eb,_0x3da972,_0x553027){if(super(),this['repoInfo_']=_0x1accb9,this['applicationId_']=_0x1e9c87,this['onDataUpdate_']=_0x10fde0,this['onConnectStatus_']=_0x2daa29,this['onServerInfoUpdate_']=_0x26f5e0,this['authTokenProvider_']=_0x2681eb,this['appCheckTokenProvider_']=_0x3da972,this['authOverride_']=_0x553027,this['id']=se['nextPersistentConnectionId_']++,this['log_']=Ht('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=gt,this['maxReconnectDelay_']=Ph,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x553027)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Ki['getInstance']()['on']('visible',this['onVisible_'],this),_0x1accb9['host']['indexOf']('fblocal')===-0x1&&dn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x46a09a,_0x22b322,_0x3418ac){const _0xbe22ae=++this['requestNumber_'],_0x5912ba={'r':_0xbe22ae,'a':_0x46a09a,'b':_0x22b322};this['log_'](O(_0x5912ba)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x5912ba),_0x3418ac&&(this['requestCBHash_'][_0xbe22ae]=_0x3418ac);}['get'](_0xc5910f){this['initConnection_']();const _0x4fedaf=new ot(),_0x3166aa={'action':'g','request':{'p':_0xc5910f['_path']['toString'](),'q':_0xc5910f['_queryObject']},'onComplete':_0xd96c72=>{const _0x1faecd=_0xd96c72['d'];_0xd96c72['s']==='ok'?_0x4fedaf['resolve'](_0x1faecd):_0x4fedaf['reject'](_0x1faecd);}};this['outstandingGets_']['push'](_0x3166aa),this['outstandingGetCount_']++;const _0x1156e2=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x1156e2),_0x4fedaf['promise'];}['listen'](_0x4b5d68,_0x357a4c,_0x2316b4,_0x19a820){this['initConnection_']();const _0x4d2555=_0x4b5d68['_queryIdentifier'],_0x3b7249=_0x4b5d68['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x3b7249+'\x20'+_0x4d2555),this['listens']['has'](_0x3b7249)||this['listens']['set'](_0x3b7249,new Map()),f(_0x4b5d68['_queryParams']['isDefault']()||!_0x4b5d68['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x3b7249)['has'](_0x4d2555),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x2aa3cc={'onComplete':_0x19a820,'hashFn':_0x357a4c,'query':_0x4b5d68,'tag':_0x2316b4};this['listens']['get'](_0x3b7249)['set'](_0x4d2555,_0x2aa3cc),this['connected_']&&this['sendListen_'](_0x2aa3cc);}['sendGet_'](_0x3b7faf){const _0x322f1f=this['outstandingGets_'][_0x3b7faf];this['sendRequest']('g',_0x322f1f['request'],_0x558f1a=>{delete this['outstandingGets_'][_0x3b7faf],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x322f1f['onComplete']&&_0x322f1f['onComplete'](_0x558f1a);});}['sendListen_'](_0x44f134){const _0x117de6=_0x44f134['query'],_0x2a1736=_0x117de6['_path']['toString'](),_0x5560b6=_0x117de6['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x2a1736+'\x20for\x20'+_0x5560b6);const _0x2f546f={'p':_0x2a1736},_0x3af556='q';_0x44f134['tag']&&(_0x2f546f['q']=_0x117de6['_queryObject'],_0x2f546f['t']=_0x44f134['tag']),_0x2f546f['h']=_0x44f134['hashFn'](),this['sendRequest'](_0x3af556,_0x2f546f,_0x304feb=>{const _0x357971=_0x304feb['d'],_0x42e951=_0x304feb['s'];se['warnOnListenWarnings_'](_0x357971,_0x117de6),(this['listens']['get'](_0x2a1736)&&this['listens']['get'](_0x2a1736)['get'](_0x5560b6))===_0x44f134&&(this['log_']('listen\x20response',_0x304feb),_0x42e951!=='ok'&&this['removeListen_'](_0x2a1736,_0x5560b6),_0x44f134['onComplete']&&_0x44f134['onComplete'](_0x42e951,_0x357971));});}static['warnOnListenWarnings_'](_0x50efc3,_0x5f4044){if(_0x50efc3&&typeof _0x50efc3=='object'&&J(_0x50efc3,'w')){const _0xd7b545=De(_0x50efc3,'w');if(Array['isArray'](_0xd7b545)&&~_0xd7b545['indexOf']('no_index')){const _0x1dd671='\x22.indexOn\x22:\x20\x22'+_0x5f4044['_queryParams']['getIndex']()['toString']()+'\x22',_0x5edcf6=_0x5f4044['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x1dd671+'\x20at\x20'+_0x5edcf6+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x2bb5d8){this['authToken_']=_0x2bb5d8,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x2bb5d8);}['reduceReconnectDelayIfAdminCredential_'](_0x25824e){(_0x25824e&&_0x25824e['length']===0x28||wc(_0x25824e))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=tr);}['refreshAppCheckToken'](_0x5a10f2){this['appCheckToken_']=_0x5a10f2,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x28a7fd=this['authToken_'],_0xa75318=Ic(_0x28a7fd)?'auth':'gauth',_0x5976b6={'cred':_0x28a7fd};this['authOverride_']===null?_0x5976b6['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x5976b6['authvar']=this['authOverride_']),this['sendRequest'](_0xa75318,_0x5976b6,_0x38317e=>{const _0x31ba9c=_0x38317e['s'],_0x4ed165=_0x38317e['d']||'error';this['authToken_']===_0x28a7fd&&(_0x31ba9c==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x31ba9c,_0x4ed165));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x337650=>{const _0x16ae63=_0x337650['s'],_0xd82b5f=_0x337650['d']||'error';_0x16ae63==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x16ae63,_0xd82b5f);});}['unlisten'](_0x31469c,_0x196807){const _0x51428c=_0x31469c['_path']['toString'](),_0x31801d=_0x31469c['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x51428c+'\x20'+_0x31801d),f(_0x31469c['_queryParams']['isDefault']()||!_0x31469c['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x51428c,_0x31801d)&&this['connected_']&&this['sendUnlisten_'](_0x51428c,_0x31801d,_0x31469c['_queryObject'],_0x196807);}['sendUnlisten_'](_0x28ce35,_0x36aa07,_0x4ee65a,_0x318fb6){this['log_']('Unlisten\x20on\x20'+_0x28ce35+'\x20for\x20'+_0x36aa07);const _0x37b9e2={'p':_0x28ce35},_0x3e97e5='n';_0x318fb6&&(_0x37b9e2['q']=_0x4ee65a,_0x37b9e2['t']=_0x318fb6),this['sendRequest'](_0x3e97e5,_0x37b9e2);}['onDisconnectPut'](_0x6b8d51,_0x4934c6,_0x18a181){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x6b8d51,_0x4934c6,_0x18a181):this['onDisconnectRequestQueue_']['push']({'pathString':_0x6b8d51,'action':'o','data':_0x4934c6,'onComplete':_0x18a181});}['onDisconnectMerge'](_0x5cdbe6,_0x2fe139,_0x27fec0){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x5cdbe6,_0x2fe139,_0x27fec0):this['onDisconnectRequestQueue_']['push']({'pathString':_0x5cdbe6,'action':'om','data':_0x2fe139,'onComplete':_0x27fec0});}['onDisconnectCancel'](_0x3941d4,_0x2e388b){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x3941d4,null,_0x2e388b):this['onDisconnectRequestQueue_']['push']({'pathString':_0x3941d4,'action':'oc','data':null,'onComplete':_0x2e388b});}['sendOnDisconnect_'](_0x2bac2c,_0x23b8d6,_0x47287f,_0x48e253){const _0xefb621={'p':_0x23b8d6,'d':_0x47287f};this['log_']('onDisconnect\x20'+_0x2bac2c,_0xefb621),this['sendRequest'](_0x2bac2c,_0xefb621,_0x3f09d4=>{_0x48e253&&setTimeout(()=>{_0x48e253(_0x3f09d4['s'],_0x3f09d4['d']);},Math['floor'](0x0));});}['put'](_0x251d5e,_0xbca5e7,_0x55e3ea,_0x4a6e9f){this['putInternal']('p',_0x251d5e,_0xbca5e7,_0x55e3ea,_0x4a6e9f);}['merge'](_0x211e7a,_0x5085a7,_0x2820a0,_0x3bc398){this['putInternal']('m',_0x211e7a,_0x5085a7,_0x2820a0,_0x3bc398);}['putInternal'](_0x1861f3,_0x4d1971,_0x16263d,_0x14deda,_0x3cbfab){this['initConnection_']();const _0x47eaff={'p':_0x4d1971,'d':_0x16263d};_0x3cbfab!==void 0x0&&(_0x47eaff['h']=_0x3cbfab),this['outstandingPuts_']['push']({'action':_0x1861f3,'request':_0x47eaff,'onComplete':_0x14deda}),this['outstandingPutCount_']++;const _0xf1e846=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0xf1e846):this['log_']('Buffering\x20put:\x20'+_0x4d1971);}['sendPut_'](_0x4a237d){const _0x15fa8a=this['outstandingPuts_'][_0x4a237d]['action'],_0x57e3de=this['outstandingPuts_'][_0x4a237d]['request'],_0x55f1c1=this['outstandingPuts_'][_0x4a237d]['onComplete'];this['outstandingPuts_'][_0x4a237d]['queued']=this['connected_'],this['sendRequest'](_0x15fa8a,_0x57e3de,_0x467880=>{this['log_'](_0x15fa8a+'\x20response',_0x467880),delete this['outstandingPuts_'][_0x4a237d],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x55f1c1&&_0x55f1c1(_0x467880['s'],_0x467880['d']);});}['reportStats'](_0x27df2a){if(this['connected_']){const _0x1e84e0={'c':_0x27df2a};this['log_']('reportStats',_0x1e84e0),this['sendRequest']('s',_0x1e84e0,_0x5d395d=>{if(_0x5d395d['s']!=='ok'){const _0x56f5c0=_0x5d395d['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x56f5c0);}});}}['onDataMessage_'](_0x5a038e){if('r'in _0x5a038e){this['log_']('from\x20server:\x20'+O(_0x5a038e));const _0x19299b=_0x5a038e['r'],_0x5e4319=this['requestCBHash_'][_0x19299b];_0x5e4319&&(delete this['requestCBHash_'][_0x19299b],_0x5e4319(_0x5a038e['b']));}else{if('error'in _0x5a038e)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x5a038e['error'];'a'in _0x5a038e&&this['onDataPush_'](_0x5a038e['a'],_0x5a038e['b']);}}['onDataPush_'](_0x5f2b38,_0x32c3f8){this['log_']('handleServerMessage',_0x5f2b38,_0x32c3f8),_0x5f2b38==='d'?this['onDataUpdate_'](_0x32c3f8['p'],_0x32c3f8['d'],!0x1,_0x32c3f8['t']):_0x5f2b38==='m'?this['onDataUpdate_'](_0x32c3f8['p'],_0x32c3f8['d'],!0x0,_0x32c3f8['t']):_0x5f2b38==='c'?this['onListenRevoked_'](_0x32c3f8['p'],_0x32c3f8['q']):_0x5f2b38==='ac'?this['onAuthRevoked_'](_0x32c3f8['s'],_0x32c3f8['d']):_0x5f2b38==='apc'?this['onAppCheckRevoked_'](_0x32c3f8['s'],_0x32c3f8['d']):_0x5f2b38==='sd'?this['onSecurityDebugPacket_'](_0x32c3f8):yi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x5f2b38)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x1cbbcf,_0x15f8b0){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x1cbbcf),this['lastSessionId']=_0x15f8b0,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x511ff3){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x511ff3));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x34eb1b){_0x34eb1b&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x34eb1b;}['onOnline_'](_0x397414){_0x397414?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=gt),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x23c998=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x5ebb78=Math['max'](0x0,this['reconnectDelay_']-_0x23c998);_0x5ebb78=Math['random']()*_0x5ebb78,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x5ebb78+'ms'),this['scheduleConnect_'](_0x5ebb78),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x8e7df4=this['onDataMessage_']['bind'](this),_0x5c5981=this['onReady_']['bind'](this),_0x488081=this['onRealtimeDisconnect_']['bind'](this),_0x4d3c87=this['id']+':'+se['nextConnectionId_']++,_0x3c0755=this['lastSessionId'];let _0x4992a6=!0x1,_0x58b0d2=null;const _0x29a167=function(){_0x58b0d2?_0x58b0d2['close']():(_0x4992a6=!0x0,_0x488081());},_0x1f339b=function(_0x177623){f(_0x58b0d2,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x58b0d2['sendRequest'](_0x177623);};this['realtime_']={'close':_0x29a167,'sendRequest':_0x1f339b};const _0x52ad17=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x5540ef,_0x3f4892]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x52ad17),this['appCheckTokenProvider_']['getToken'](_0x52ad17)]);_0x4992a6?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x5540ef&&_0x5540ef['accessToken'],this['appCheckToken_']=_0x3f4892&&_0x3f4892['token'],_0x58b0d2=new Sh(_0x4d3c87,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x8e7df4,_0x5c5981,_0x488081,_0x2f1a6d=>{U(_0x2f1a6d+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x3c0755));}catch(_0x483456){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x483456),_0x4992a6||(this['repoInfo_']['nodeAdmin']&&U(_0x483456),_0x29a167());}}}['interrupt'](_0x21466e){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x21466e),this['interruptReasons_'][_0x21466e]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x34e913){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x34e913),delete this['interruptReasons_'][_0x34e913],ui(this['interruptReasons_'])&&(this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x35f29c){const _0x34f0d7=_0x35f29c-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x34f0d7});}['cancelSentTransactions_'](){for(let _0x365b0c=0x0;_0x365b0c<this['outstandingPuts_']['length'];_0x365b0c++){const _0x3e8155=this['outstandingPuts_'][_0x365b0c];_0x3e8155&&'h'in _0x3e8155['request']&&_0x3e8155['queued']&&(_0x3e8155['onComplete']&&_0x3e8155['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x365b0c],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0xe929dd,_0x2b17c0){let _0x8220af;_0x2b17c0?_0x8220af=_0x2b17c0['map'](_0x1f2831=>Hi(_0x1f2831))['join']('$'):_0x8220af='default';const _0x415fed=this['removeListen_'](_0xe929dd,_0x8220af);_0x415fed&&_0x415fed['onComplete']&&_0x415fed['onComplete']('permission_denied');}['removeListen_'](_0x3df06d,_0x5b3252){const _0x1e73aa=new C(_0x3df06d)['toString']();let _0x3f1a54;if(this['listens']['has'](_0x1e73aa)){const _0x18bccf=this['listens']['get'](_0x1e73aa);_0x3f1a54=_0x18bccf['get'](_0x5b3252),_0x18bccf['delete'](_0x5b3252),_0x18bccf['size']===0x0&&this['listens']['delete'](_0x1e73aa);}else _0x3f1a54=void 0x0;return _0x3f1a54;}['onAuthRevoked_'](_0x4f477c,_0x543dbd){L('Auth\x20token\x20revoked:\x20'+_0x4f477c+'/'+_0x543dbd),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x4f477c==='invalid_token'||_0x4f477c==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=nr&&(this['reconnectDelay_']=tr,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x360d0c,_0x4ad215){L('App\x20check\x20token\x20revoked:\x20'+_0x360d0c+'/'+_0x4ad215),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x360d0c==='invalid_token'||_0x360d0c==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=nr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x149db5){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x149db5):'msg'in _0x149db5&&console['log']('FIREBASE:\x20'+_0x149db5['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x2850a1 of this['listens']['values']())for(const _0x42b8a8 of _0x2850a1['values']())this['sendListen_'](_0x42b8a8);for(let _0x59521f=0x0;_0x59521f<this['outstandingPuts_']['length'];_0x59521f++)this['outstandingPuts_'][_0x59521f]&&this['sendPut_'](_0x59521f);for(;this['onDisconnectRequestQueue_']['length'];){const _0xddbf5a=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0xddbf5a['action'],_0xddbf5a['pathString'],_0xddbf5a['data'],_0xddbf5a['onComplete']);}for(let _0x2b2248=0x0;_0x2b2248<this['outstandingGets_']['length'];_0x2b2248++)this['outstandingGets_'][_0x2b2248]&&this['sendGet_'](_0x2b2248);}['sendConnectStats_'](){const _0x330cfe={};let _0x157328='js';_0x330cfe['sdk.'+_0x157328+'.'+no['replace'](/\./g,'-')]=0x1,Fi()?_0x330cfe['framework.cordova']=0x1:Yr()&&(_0x330cfe['framework.reactnative']=0x1),this['reportStats'](_0x330cfe);}['shouldReconnect_'](){const _0x303e02=dn['getInstance']()['currentlyOnline']();return ui(this['interruptReasons_'])&&_0x303e02;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x216418,_0x797df9){this['name']=_0x216418,this['node']=_0x797df9;}static['Wrap'](_0x45e645,_0x50e1ed){return new E(_0x45e645,_0x50e1ed);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x2e23c6,_0x3ba33b){const _0x19deb5=new E(Fe,_0x2e23c6),_0x54d9f9=new E(Fe,_0x3ba33b);return this['compare'](_0x19deb5,_0x54d9f9)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zt;class ko extends Dn{static get['__EMPTY_NODE'](){return Zt;}static set['__EMPTY_NODE'](_0x3abbd7){Zt=_0x3abbd7;}['compare'](_0x5b509b,_0xd9c309){return He(_0x5b509b['name'],_0xd9c309['name']);}['isDefinedOn'](_0x1f8223){throw rt('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x4e1075,_0x3e530f){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Zt);}['makePost'](_0x4ec367,_0x397806){return f(typeof _0x4ec367=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x4ec367,Zt);}['toString'](){return'.key';}}const ye=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class en{constructor(_0x268468,_0x3f5fcb,_0x508a25,_0x35fefe,_0x160af9=null){this['isReverse_']=_0x35fefe,this['resultGenerator_']=_0x160af9,this['nodeStack_']=[];let _0x2b7579=0x1;for(;!_0x268468['isEmpty']();)if(_0x268468=_0x268468,_0x2b7579=_0x3f5fcb?_0x508a25(_0x268468['key'],_0x3f5fcb):0x1,_0x35fefe&&(_0x2b7579*=-0x1),_0x2b7579<0x0)this['isReverse_']?_0x268468=_0x268468['left']:_0x268468=_0x268468['right'];else{if(_0x2b7579===0x0){this['nodeStack_']['push'](_0x268468);break;}else this['nodeStack_']['push'](_0x268468),this['isReverse_']?_0x268468=_0x268468['right']:_0x268468=_0x268468['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x29c002=this['nodeStack_']['pop'](),_0x42a5d1;if(this['resultGenerator_']?_0x42a5d1=this['resultGenerator_'](_0x29c002['key'],_0x29c002['value']):_0x42a5d1={'key':_0x29c002['key'],'value':_0x29c002['value']},this['isReverse_']){for(_0x29c002=_0x29c002['left'];!_0x29c002['isEmpty']();)this['nodeStack_']['push'](_0x29c002),_0x29c002=_0x29c002['right'];}else{for(_0x29c002=_0x29c002['right'];!_0x29c002['isEmpty']();)this['nodeStack_']['push'](_0x29c002),_0x29c002=_0x29c002['left'];}return _0x42a5d1;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x1f0eea=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x1f0eea['key'],_0x1f0eea['value']):{'key':_0x1f0eea['key'],'value':_0x1f0eea['value']};}}class M{constructor(_0x3c7bd5,_0x583542,_0x38c0c5,_0xe5b87,_0x4fe5c6){this['key']=_0x3c7bd5,this['value']=_0x583542,this['color']=_0x38c0c5??M['RED'],this['left']=_0xe5b87??B['EMPTY_NODE'],this['right']=_0x4fe5c6??B['EMPTY_NODE'];}['copy'](_0x429913,_0xf67bcf,_0x142235,_0x392f7c,_0x5e1e88){return new M(_0x429913??this['key'],_0xf67bcf??this['value'],_0x142235??this['color'],_0x392f7c??this['left'],_0x5e1e88??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x302e5f){return this['left']['inorderTraversal'](_0x302e5f)||!!_0x302e5f(this['key'],this['value'])||this['right']['inorderTraversal'](_0x302e5f);}['reverseTraversal'](_0x44e2d2){return this['right']['reverseTraversal'](_0x44e2d2)||_0x44e2d2(this['key'],this['value'])||this['left']['reverseTraversal'](_0x44e2d2);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x3565af,_0x46cf76,_0x3d2727){let _0x5c4de2=this;const _0x22fe49=_0x3d2727(_0x3565af,_0x5c4de2['key']);return _0x22fe49<0x0?_0x5c4de2=_0x5c4de2['copy'](null,null,null,_0x5c4de2['left']['insert'](_0x3565af,_0x46cf76,_0x3d2727),null):_0x22fe49===0x0?_0x5c4de2=_0x5c4de2['copy'](null,_0x46cf76,null,null,null):_0x5c4de2=_0x5c4de2['copy'](null,null,null,null,_0x5c4de2['right']['insert'](_0x3565af,_0x46cf76,_0x3d2727)),_0x5c4de2['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x33de13=this;return!_0x33de13['left']['isRed_']()&&!_0x33de13['left']['left']['isRed_']()&&(_0x33de13=_0x33de13['moveRedLeft_']()),_0x33de13=_0x33de13['copy'](null,null,null,_0x33de13['left']['removeMin_'](),null),_0x33de13['fixUp_']();}['remove'](_0x16bf76,_0x3ad135){let _0x41c8a3,_0x22efdc;if(_0x41c8a3=this,_0x3ad135(_0x16bf76,_0x41c8a3['key'])<0x0)!_0x41c8a3['left']['isEmpty']()&&!_0x41c8a3['left']['isRed_']()&&!_0x41c8a3['left']['left']['isRed_']()&&(_0x41c8a3=_0x41c8a3['moveRedLeft_']()),_0x41c8a3=_0x41c8a3['copy'](null,null,null,_0x41c8a3['left']['remove'](_0x16bf76,_0x3ad135),null);else{if(_0x41c8a3['left']['isRed_']()&&(_0x41c8a3=_0x41c8a3['rotateRight_']()),!_0x41c8a3['right']['isEmpty']()&&!_0x41c8a3['right']['isRed_']()&&!_0x41c8a3['right']['left']['isRed_']()&&(_0x41c8a3=_0x41c8a3['moveRedRight_']()),_0x3ad135(_0x16bf76,_0x41c8a3['key'])===0x0){if(_0x41c8a3['right']['isEmpty']())return B['EMPTY_NODE'];_0x22efdc=_0x41c8a3['right']['min_'](),_0x41c8a3=_0x41c8a3['copy'](_0x22efdc['key'],_0x22efdc['value'],null,null,_0x41c8a3['right']['removeMin_']());}_0x41c8a3=_0x41c8a3['copy'](null,null,null,null,_0x41c8a3['right']['remove'](_0x16bf76,_0x3ad135));}return _0x41c8a3['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0xef784f=this;return _0xef784f['right']['isRed_']()&&!_0xef784f['left']['isRed_']()&&(_0xef784f=_0xef784f['rotateLeft_']()),_0xef784f['left']['isRed_']()&&_0xef784f['left']['left']['isRed_']()&&(_0xef784f=_0xef784f['rotateRight_']()),_0xef784f['left']['isRed_']()&&_0xef784f['right']['isRed_']()&&(_0xef784f=_0xef784f['colorFlip_']()),_0xef784f;}['moveRedLeft_'](){let _0x370ae8=this['colorFlip_']();return _0x370ae8['right']['left']['isRed_']()&&(_0x370ae8=_0x370ae8['copy'](null,null,null,null,_0x370ae8['right']['rotateRight_']()),_0x370ae8=_0x370ae8['rotateLeft_'](),_0x370ae8=_0x370ae8['colorFlip_']()),_0x370ae8;}['moveRedRight_'](){let _0x387210=this['colorFlip_']();return _0x387210['left']['left']['isRed_']()&&(_0x387210=_0x387210['rotateRight_'](),_0x387210=_0x387210['colorFlip_']()),_0x387210;}['rotateLeft_'](){const _0x430c3d=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x430c3d,null);}['rotateRight_'](){const _0xafab15=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0xafab15);}['colorFlip_'](){const _0x2f86db=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x32d6e0=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x2f86db,_0x32d6e0);}['checkMaxDepth_'](){const _0x16a015=this['check_']();return Math['pow'](0x2,_0x16a015)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x57ec42=this['left']['check_']();if(_0x57ec42!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x57ec42+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0xbe6b4a,_0x4f8926,_0x53ca23,_0x29cc80,_0x299cd1){return this;}['insert'](_0x2e39e1,_0xa31ac1,_0x585c55){return new M(_0x2e39e1,_0xa31ac1,null);}['remove'](_0x3cea21,_0x1c595e){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x28d785){return!0x1;}['reverseTraversal'](_0x22932b){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x474fd7,_0x1bcf42=B['EMPTY_NODE']){this['comparator_']=_0x474fd7,this['root_']=_0x1bcf42;}['insert'](_0x59184a,_0x6c2f26){return new B(this['comparator_'],this['root_']['insert'](_0x59184a,_0x6c2f26,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x54cafc){return new B(this['comparator_'],this['root_']['remove'](_0x54cafc,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x141729){let _0x21a6af,_0x528a1b=this['root_'];for(;!_0x528a1b['isEmpty']();){if(_0x21a6af=this['comparator_'](_0x141729,_0x528a1b['key']),_0x21a6af===0x0)return _0x528a1b['value'];_0x21a6af<0x0?_0x528a1b=_0x528a1b['left']:_0x21a6af>0x0&&(_0x528a1b=_0x528a1b['right']);}return null;}['getPredecessorKey'](_0x2eb1c9){let _0x321aa0,_0x5a3036=this['root_'],_0x268432=null;for(;!_0x5a3036['isEmpty']();)if(_0x321aa0=this['comparator_'](_0x2eb1c9,_0x5a3036['key']),_0x321aa0===0x0){if(_0x5a3036['left']['isEmpty']())return _0x268432?_0x268432['key']:null;for(_0x5a3036=_0x5a3036['left'];!_0x5a3036['right']['isEmpty']();)_0x5a3036=_0x5a3036['right'];return _0x5a3036['key'];}else _0x321aa0<0x0?_0x5a3036=_0x5a3036['left']:_0x321aa0>0x0&&(_0x268432=_0x5a3036,_0x5a3036=_0x5a3036['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x1b40cb){return this['root_']['inorderTraversal'](_0x1b40cb);}['reverseTraversal'](_0x3b7a77){return this['root_']['reverseTraversal'](_0x3b7a77);}['getIterator'](_0x3e7459){return new en(this['root_'],null,this['comparator_'],!0x1,_0x3e7459);}['getIteratorFrom'](_0x285734,_0x48d892){return new en(this['root_'],_0x285734,this['comparator_'],!0x1,_0x48d892);}['getReverseIteratorFrom'](_0x4cf08e,_0x447eaa){return new en(this['root_'],_0x4cf08e,this['comparator_'],!0x0,_0x447eaa);}['getReverseIterator'](_0x398498){return new en(this['root_'],null,this['comparator_'],!0x0,_0x398498);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x1f80dd,_0x4f9685){return He(_0x1f80dd['name'],_0x4f9685['name']);}function Yi(_0x38344c,_0x15402c){return He(_0x38344c,_0x15402c);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ei;function Fh(_0x4caacf){Ei=_0x4caacf;}const No=function(_0x56d15a){return typeof _0x56d15a=='number'?'number:'+ao(_0x56d15a):'string:'+_0x56d15a;},Po=function(_0x5a4f70){if(_0x5a4f70['isLeafNode']()){const _0xd6c985=_0x5a4f70['val']();f(typeof _0xd6c985=='string'||typeof _0xd6c985=='number'||typeof _0xd6c985=='object'&&J(_0xd6c985,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x5a4f70===Ei||_0x5a4f70['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x5a4f70===Ei||_0x5a4f70['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ir;class D{static set['__childrenNodeConstructor'](_0x430ef4){ir=_0x430ef4;}static get['__childrenNodeConstructor'](){return ir;}constructor(_0x42444d,_0x138d08=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x42444d,this['priorityNode_']=_0x138d08,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Po(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x341d7a){return new D(this['value_'],_0x341d7a);}['getImmediateChild'](_0x30995f){return _0x30995f==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x1957b9){return v(_0x1957b9)?this:y(_0x1957b9)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x49f58f,_0x142cf3){return null;}['updateImmediateChild'](_0x576c22,_0x4a1108){return _0x576c22==='.priority'?this['updatePriority'](_0x4a1108):_0x4a1108['isEmpty']()&&_0x576c22!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x576c22,_0x4a1108)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x3d3f90,_0x1a8471){const _0x59b0fa=y(_0x3d3f90);return _0x59b0fa===null?_0x1a8471:_0x1a8471['isEmpty']()&&_0x59b0fa!=='.priority'?this:(f(_0x59b0fa!=='.priority'||we(_0x3d3f90)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x59b0fa,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x3d3f90),_0x1a8471)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x51e2bc,_0x1abc13){return!0x1;}['val'](_0x3afea3){return _0x3afea3&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x3ae583='';this['priorityNode_']['isEmpty']()||(_0x3ae583+='priority:'+No(this['priorityNode_']['val']())+':');const _0x1d9f1f=typeof this['value_'];_0x3ae583+=_0x1d9f1f+':',_0x1d9f1f==='number'?_0x3ae583+=ao(this['value_']):_0x3ae583+=this['value_'],this['lazyHash_']=ro(_0x3ae583);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x17bddc){return _0x17bddc===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x17bddc instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x17bddc['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x17bddc));}['compareToLeafNode_'](_0x1cf4a5){const _0x2cd920=typeof _0x1cf4a5['value_'],_0x567b4f=typeof this['value_'],_0x4222d9=D['VALUE_TYPE_ORDER']['indexOf'](_0x2cd920),_0xc738e4=D['VALUE_TYPE_ORDER']['indexOf'](_0x567b4f);return f(_0x4222d9>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x2cd920),f(_0xc738e4>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x567b4f),_0x4222d9===_0xc738e4?_0x567b4f==='object'?0x0:this['value_']<_0x1cf4a5['value_']?-0x1:this['value_']===_0x1cf4a5['value_']?0x0:0x1:_0xc738e4-_0x4222d9;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x39801a){if(_0x39801a===this)return!0x0;if(_0x39801a['isLeafNode']()){const _0x1ac4c6=_0x39801a;return this['value_']===_0x1ac4c6['value_']&&this['priorityNode_']['equals'](_0x1ac4c6['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x49ff00){Oo=_0x49ff00;}function Wh(_0x5cbb33){Do=_0x5cbb33;}class Bh extends Dn{['compare'](_0x278728,_0x219886){const _0x2d2ae2=_0x278728['node']['getPriority'](),_0x4d4c54=_0x219886['node']['getPriority'](),_0xeafe5f=_0x2d2ae2['compareTo'](_0x4d4c54);return _0xeafe5f===0x0?He(_0x278728['name'],_0x219886['name']):_0xeafe5f;}['isDefinedOn'](_0x106e11){return!_0x106e11['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x2500b7,_0x1750b3){return!_0x2500b7['getPriority']()['equals'](_0x1750b3['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',Do));}['makePost'](_0x5b85d6,_0x1d4eda){const _0xd358c7=Oo(_0x5b85d6);return new E(_0x1d4eda,new D('[PRIORITY-POST]',_0xd358c7));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x5e4efd){const _0x29c180=_0x827def=>parseInt(Math['log'](_0x827def)/Vh,0xa),_0x5ee693=_0x42e79c=>parseInt(Array(_0x42e79c+0x1)['join']('1'),0x2);this['count']=_0x29c180(_0x5e4efd+0x1),this['current_']=this['count']-0x1;const _0x179bf0=_0x5ee693(this['count']);this['bits_']=_0x5e4efd+0x1&_0x179bf0;}['nextBitIsOne'](){const _0x131a25=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x131a25;}}const fn=function(_0x58f298,_0x2fe071,_0x304160,_0x5963ff){_0x58f298['sort'](_0x2fe071);const _0x105e5d=function(_0x3d29ea,_0xf33bb7){const _0x25f573=_0xf33bb7-_0x3d29ea;let _0x1c24dc,_0x1fb13b;if(_0x25f573===0x0)return null;if(_0x25f573===0x1)return _0x1c24dc=_0x58f298[_0x3d29ea],_0x1fb13b=_0x304160?_0x304160(_0x1c24dc):_0x1c24dc,new M(_0x1fb13b,_0x1c24dc['node'],M['BLACK'],null,null);{const _0x3428b2=parseInt(_0x25f573/0x2,0xa)+_0x3d29ea,_0x2518d6=_0x105e5d(_0x3d29ea,_0x3428b2),_0x4f9a7c=_0x105e5d(_0x3428b2+0x1,_0xf33bb7);return _0x1c24dc=_0x58f298[_0x3428b2],_0x1fb13b=_0x304160?_0x304160(_0x1c24dc):_0x1c24dc,new M(_0x1fb13b,_0x1c24dc['node'],M['BLACK'],_0x2518d6,_0x4f9a7c);}},_0x2a929d=function(_0x4550f3){let _0xed7f14=null,_0x539826=null,_0x49cfd4=_0x58f298['length'];const _0x25e25d=function(_0x5ad252,_0x1e4089){const _0x3c4ada=_0x49cfd4-_0x5ad252,_0x31f090=_0x49cfd4;_0x49cfd4-=_0x5ad252;const _0x460d78=_0x105e5d(_0x3c4ada+0x1,_0x31f090),_0xee200b=_0x58f298[_0x3c4ada],_0x47bf4f=_0x304160?_0x304160(_0xee200b):_0xee200b;_0x38f21f(new M(_0x47bf4f,_0xee200b['node'],_0x1e4089,null,_0x460d78));},_0x38f21f=function(_0x78669f){_0xed7f14?(_0xed7f14['left']=_0x78669f,_0xed7f14=_0x78669f):(_0x539826=_0x78669f,_0xed7f14=_0x78669f);};for(let _0x3956db=0x0;_0x3956db<_0x4550f3['count'];++_0x3956db){const _0x1a9d7f=_0x4550f3['nextBitIsOne'](),_0x3801e8=Math['pow'](0x2,_0x4550f3['count']-(_0x3956db+0x1));_0x1a9d7f?_0x25e25d(_0x3801e8,M['BLACK']):(_0x25e25d(_0x3801e8,M['BLACK']),_0x25e25d(_0x3801e8,M['RED']));}return _0x539826;},_0x2ed60e=new Hh(_0x58f298['length']),_0x28635f=_0x2a929d(_0x2ed60e);return new B(_0x5963ff||_0x2fe071,_0x28635f);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ze={};class te{static get['Default'](){return f(ze&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),ri=ri||new te({'.priority':ze},{'.priority':R}),ri;}constructor(_0x16a3d5,_0x1ae3b8){this['indexes_']=_0x16a3d5,this['indexSet_']=_0x1ae3b8;}['get'](_0x95bbb5){const _0x4a7003=De(this['indexes_'],_0x95bbb5);if(!_0x4a7003)throw new Error('No\x20index\x20defined\x20for\x20'+_0x95bbb5);return _0x4a7003 instanceof B?_0x4a7003:null;}['hasIndex'](_0x319eb0){return J(this['indexSet_'],_0x319eb0['toString']());}['addIndex'](_0x572d84,_0x5daad3){f(_0x572d84!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0x32540d=[];let _0x370d2=!0x1;const _0x228ca2=_0x5daad3['getIterator'](E['Wrap']);let _0x9174a0=_0x228ca2['getNext']();for(;_0x9174a0;)_0x370d2=_0x370d2||_0x572d84['isDefinedOn'](_0x9174a0['node']),_0x32540d['push'](_0x9174a0),_0x9174a0=_0x228ca2['getNext']();let _0x3c9619;_0x370d2?_0x3c9619=fn(_0x32540d,_0x572d84['getCompare']()):_0x3c9619=ze;const _0x14950f=_0x572d84['toString'](),_0x38b13d={...this['indexSet_']};_0x38b13d[_0x14950f]=_0x572d84;const _0x537950={...this['indexes_']};return _0x537950[_0x14950f]=_0x3c9619,new te(_0x537950,_0x38b13d);}['addToIndexes'](_0xca7efa,_0x25c603){const _0x3b8412=hn(this['indexes_'],(_0x3a7493,_0x468df0)=>{const _0x33d38e=De(this['indexSet_'],_0x468df0);if(f(_0x33d38e,'Missing\x20index\x20implementation\x20for\x20'+_0x468df0),_0x3a7493===ze){if(_0x33d38e['isDefinedOn'](_0xca7efa['node'])){const _0x4174db=[],_0x5b8131=_0x25c603['getIterator'](E['Wrap']);let _0x34ed8a=_0x5b8131['getNext']();for(;_0x34ed8a;)_0x34ed8a['name']!==_0xca7efa['name']&&_0x4174db['push'](_0x34ed8a),_0x34ed8a=_0x5b8131['getNext']();return _0x4174db['push'](_0xca7efa),fn(_0x4174db,_0x33d38e['getCompare']());}else return ze;}else{const _0x3afca7=_0x25c603['get'](_0xca7efa['name']);let _0x2dfbbb=_0x3a7493;return _0x3afca7&&(_0x2dfbbb=_0x2dfbbb['remove'](new E(_0xca7efa['name'],_0x3afca7))),_0x2dfbbb['insert'](_0xca7efa,_0xca7efa['node']);}});return new te(_0x3b8412,this['indexSet_']);}['removeFromIndexes'](_0x48cab5,_0x343b61){const _0xc36df=hn(this['indexes_'],_0x42ff24=>{if(_0x42ff24===ze)return _0x42ff24;{const _0x39b873=_0x343b61['get'](_0x48cab5['name']);return _0x39b873?_0x42ff24['remove'](new E(_0x48cab5['name'],_0x39b873)):_0x42ff24;}});return new te(_0xc36df,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let mt;class g{static get['EMPTY_NODE'](){return mt||(mt=new g(new B(Yi),null,te['Default']));}constructor(_0x47fb0b,_0x315864,_0xc511bf){this['children_']=_0x47fb0b,this['priorityNode_']=_0x315864,this['indexMap_']=_0xc511bf,this['lazyHash_']=null,this['priorityNode_']&&Po(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||mt;}['updatePriority'](_0x5c8160){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x5c8160,this['indexMap_']);}['getImmediateChild'](_0x12b36a){if(_0x12b36a==='.priority')return this['getPriority']();{const _0x36040d=this['children_']['get'](_0x12b36a);return _0x36040d===null?mt:_0x36040d;}}['getChild'](_0x2d0bb5){const _0xdc166a=y(_0x2d0bb5);return _0xdc166a===null?this:this['getImmediateChild'](_0xdc166a)['getChild'](b(_0x2d0bb5));}['hasChild'](_0x383145){return this['children_']['get'](_0x383145)!==null;}['updateImmediateChild'](_0xdfd23f,_0xabb198){if(f(_0xabb198,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0xdfd23f==='.priority')return this['updatePriority'](_0xabb198);{const _0x42f7c1=new E(_0xdfd23f,_0xabb198);let _0x36ad29,_0x16728c;_0xabb198['isEmpty']()?(_0x36ad29=this['children_']['remove'](_0xdfd23f),_0x16728c=this['indexMap_']['removeFromIndexes'](_0x42f7c1,this['children_'])):(_0x36ad29=this['children_']['insert'](_0xdfd23f,_0xabb198),_0x16728c=this['indexMap_']['addToIndexes'](_0x42f7c1,this['children_']));const _0xc293cf=_0x36ad29['isEmpty']()?mt:this['priorityNode_'];return new g(_0x36ad29,_0xc293cf,_0x16728c);}}['updateChild'](_0x554327,_0x5a261e){const _0x1ff2cd=y(_0x554327);if(_0x1ff2cd===null)return _0x5a261e;{f(y(_0x554327)!=='.priority'||we(_0x554327)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x1ade3c=this['getImmediateChild'](_0x1ff2cd)['updateChild'](b(_0x554327),_0x5a261e);return this['updateImmediateChild'](_0x1ff2cd,_0x1ade3c);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x4b1456){if(this['isEmpty']())return null;const _0x112da2={};let _0x1eb4bd=0x0,_0xf7a23d=0x0,_0x58607f=!0x0;if(this['forEachChild'](R,(_0x260e57,_0x51935f)=>{_0x112da2[_0x260e57]=_0x51935f['val'](_0x4b1456),_0x1eb4bd++,_0x58607f&&g['INTEGER_REGEXP_']['test'](_0x260e57)?_0xf7a23d=Math['max'](_0xf7a23d,Number(_0x260e57)):_0x58607f=!0x1;}),!_0x4b1456&&_0x58607f&&_0xf7a23d<0x2*_0x1eb4bd){const _0x3f37e6=[];for(const _0x28f0dd in _0x112da2)_0x3f37e6[_0x28f0dd]=_0x112da2[_0x28f0dd];return _0x3f37e6;}else return _0x4b1456&&!this['getPriority']()['isEmpty']()&&(_0x112da2['.priority']=this['getPriority']()['val']()),_0x112da2;}['hash'](){if(this['lazyHash_']===null){let _0x1ea513='';this['getPriority']()['isEmpty']()||(_0x1ea513+='priority:'+No(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x253009,_0x1816cc)=>{const _0x1c24ec=_0x1816cc['hash']();_0x1c24ec!==''&&(_0x1ea513+=':'+_0x253009+':'+_0x1c24ec);}),this['lazyHash_']=_0x1ea513===''?'':ro(_0x1ea513);}return this['lazyHash_'];}['getPredecessorChildName'](_0x33bf30,_0x52903b,_0x4c812c){const _0x1d0fa0=this['resolveIndex_'](_0x4c812c);if(_0x1d0fa0){const _0x204b8d=_0x1d0fa0['getPredecessorKey'](new E(_0x33bf30,_0x52903b));return _0x204b8d?_0x204b8d['name']:null;}else return this['children_']['getPredecessorKey'](_0x33bf30);}['getFirstChildName'](_0x1d245c){const _0x81eb8=this['resolveIndex_'](_0x1d245c);if(_0x81eb8){const _0x5f025b=_0x81eb8['minKey']();return _0x5f025b&&_0x5f025b['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x2386c9){const _0x900e1a=this['getFirstChildName'](_0x2386c9);return _0x900e1a?new E(_0x900e1a,this['children_']['get'](_0x900e1a)):null;}['getLastChildName'](_0x233eb2){const _0x49c681=this['resolveIndex_'](_0x233eb2);if(_0x49c681){const _0x2e98bc=_0x49c681['maxKey']();return _0x2e98bc&&_0x2e98bc['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0xa9d2aa){const _0xb95648=this['getLastChildName'](_0xa9d2aa);return _0xb95648?new E(_0xb95648,this['children_']['get'](_0xb95648)):null;}['forEachChild'](_0x28718f,_0x4f232c){const _0xaef87d=this['resolveIndex_'](_0x28718f);return _0xaef87d?_0xaef87d['inorderTraversal'](_0x74c6b6=>_0x4f232c(_0x74c6b6['name'],_0x74c6b6['node'])):this['children_']['inorderTraversal'](_0x4f232c);}['getIterator'](_0x33a511){return this['getIteratorFrom'](_0x33a511['minPost'](),_0x33a511);}['getIteratorFrom'](_0x1de14e,_0x275e0d){const _0x44fe19=this['resolveIndex_'](_0x275e0d);if(_0x44fe19)return _0x44fe19['getIteratorFrom'](_0x1de14e,_0x8425d0=>_0x8425d0);{const _0x2d4747=this['children_']['getIteratorFrom'](_0x1de14e['name'],E['Wrap']);let _0x46626e=_0x2d4747['peek']();for(;_0x46626e!=null&&_0x275e0d['compare'](_0x46626e,_0x1de14e)<0x0;)_0x2d4747['getNext'](),_0x46626e=_0x2d4747['peek']();return _0x2d4747;}}['getReverseIterator'](_0x11d36b){return this['getReverseIteratorFrom'](_0x11d36b['maxPost'](),_0x11d36b);}['getReverseIteratorFrom'](_0x396193,_0x5d4ec7){const _0x510381=this['resolveIndex_'](_0x5d4ec7);if(_0x510381)return _0x510381['getReverseIteratorFrom'](_0x396193,_0x69a94=>_0x69a94);{const _0x45353e=this['children_']['getReverseIteratorFrom'](_0x396193['name'],E['Wrap']);let _0x13a0c0=_0x45353e['peek']();for(;_0x13a0c0!=null&&_0x5d4ec7['compare'](_0x13a0c0,_0x396193)>0x0;)_0x45353e['getNext'](),_0x13a0c0=_0x45353e['peek']();return _0x45353e;}}['compareTo'](_0x43e97d){return this['isEmpty']()?_0x43e97d['isEmpty']()?0x0:-0x1:_0x43e97d['isLeafNode']()||_0x43e97d['isEmpty']()?0x1:_0x43e97d===$t?-0x1:0x0;}['withIndex'](_0x1d6cc6){if(_0x1d6cc6===ye||this['indexMap_']['hasIndex'](_0x1d6cc6))return this;{const _0xffc670=this['indexMap_']['addIndex'](_0x1d6cc6,this['children_']);return new g(this['children_'],this['priorityNode_'],_0xffc670);}}['isIndexed'](_0x4b7f03){return _0x4b7f03===ye||this['indexMap_']['hasIndex'](_0x4b7f03);}['equals'](_0xee44a6){if(_0xee44a6===this)return!0x0;if(_0xee44a6['isLeafNode']())return!0x1;{const _0x2a0511=_0xee44a6;if(this['getPriority']()['equals'](_0x2a0511['getPriority']())){if(this['children_']['count']()===_0x2a0511['children_']['count']()){const _0x180010=this['getIterator'](R),_0x5bccaa=_0x2a0511['getIterator'](R);let _0x44937d=_0x180010['getNext'](),_0x225b84=_0x5bccaa['getNext']();for(;_0x44937d&&_0x225b84;){if(_0x44937d['name']!==_0x225b84['name']||!_0x44937d['node']['equals'](_0x225b84['node']))return!0x1;_0x44937d=_0x180010['getNext'](),_0x225b84=_0x5bccaa['getNext']();}return _0x44937d===null&&_0x225b84===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x2d0307){return _0x2d0307===ye?null:this['indexMap_']['get'](_0x2d0307['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Yi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x2181b1){return _0x2181b1===this?0x0:0x1;}['equals'](_0x5754fd){return _0x5754fd===this;}['getPriority'](){return this;}['getImmediateChild'](_0x4b87b5){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const $t=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(Fe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,$t)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh($t),Wh($t);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function P(_0x5b7728,_0x2dbae2=null){if(_0x5b7728===null)return g['EMPTY_NODE'];if(typeof _0x5b7728=='object'&&'.priority'in _0x5b7728&&(_0x2dbae2=_0x5b7728['.priority']),f(_0x2dbae2===null||typeof _0x2dbae2=='string'||typeof _0x2dbae2=='number'||typeof _0x2dbae2=='object'&&'.sv'in _0x2dbae2,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x2dbae2),typeof _0x5b7728=='object'&&'.value'in _0x5b7728&&_0x5b7728['.value']!==null&&(_0x5b7728=_0x5b7728['.value']),typeof _0x5b7728!='object'||'.sv'in _0x5b7728){const _0x9e4e17=_0x5b7728;return new D(_0x9e4e17,P(_0x2dbae2));}if(!(_0x5b7728 instanceof Array)&&Gh){const _0x5f4a58=[];let _0x1f8f9d=!0x1;if(x(_0x5b7728,(_0xe12b86,_0x2cf135)=>{if(_0xe12b86['substring'](0x0,0x1)!=='.'){const _0x5e798e=P(_0x2cf135);_0x5e798e['isEmpty']()||(_0x1f8f9d=_0x1f8f9d||!_0x5e798e['getPriority']()['isEmpty'](),_0x5f4a58['push'](new E(_0xe12b86,_0x5e798e)));}}),_0x5f4a58['length']===0x0)return g['EMPTY_NODE'];const _0x2b921f=fn(_0x5f4a58,xh,_0x3dfdf7=>_0x3dfdf7['name'],Yi);if(_0x1f8f9d){const _0x548069=fn(_0x5f4a58,R['getCompare']());return new g(_0x2b921f,P(_0x2dbae2),new te({'.priority':_0x548069},{'.priority':R}));}else return new g(_0x2b921f,P(_0x2dbae2),te['Default']);}else{let _0x4c6a23=g['EMPTY_NODE'];return x(_0x5b7728,(_0x45d5da,_0x5a87c7)=>{if(J(_0x5b7728,_0x45d5da)&&_0x45d5da['substring'](0x0,0x1)!=='.'){const _0x33959f=P(_0x5a87c7);(_0x33959f['isLeafNode']()||!_0x33959f['isEmpty']())&&(_0x4c6a23=_0x4c6a23['updateImmediateChild'](_0x45d5da,_0x33959f));}}),_0x4c6a23['updatePriority'](P(_0x2dbae2));}}Uh(P);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi extends Dn{constructor(_0x136016){super(),this['indexPath_']=_0x136016,f(!v(_0x136016)&&y(_0x136016)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x5adbce){return _0x5adbce['getChild'](this['indexPath_']);}['isDefinedOn'](_0x29d5e3){return!_0x29d5e3['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x3508db,_0x3e10d5){const _0x62153e=this['extractChild'](_0x3508db['node']),_0x4edfe3=this['extractChild'](_0x3e10d5['node']),_0x1b44da=_0x62153e['compareTo'](_0x4edfe3);return _0x1b44da===0x0?He(_0x3508db['name'],_0x3e10d5['name']):_0x1b44da;}['makePost'](_0x3944e4,_0x38fa6e){const _0x37601e=P(_0x3944e4),_0x4282f9=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x37601e);return new E(_0x38fa6e,_0x4282f9);}['maxPost'](){const _0x572512=g['EMPTY_NODE']['updateChild'](this['indexPath_'],$t);return new E(Ie,_0x572512);}['toString'](){return Pt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Dn{['compare'](_0x49c1b7,_0x8c13a1){const _0x4babe9=_0x49c1b7['node']['compareTo'](_0x8c13a1['node']);return _0x4babe9===0x0?He(_0x49c1b7['name'],_0x8c13a1['name']):_0x4babe9;}['isDefinedOn'](_0x24219b){return!0x0;}['indexedValueChanged'](_0x34cdb8,_0x184b24){return!_0x34cdb8['equals'](_0x184b24);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x5f3eee,_0x162ea5){const _0x10868c=P(_0x5f3eee);return new E(_0x162ea5,_0x10868c);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x30717a){return{'type':'value','snapshotNode':_0x30717a};}function et(_0x1c3d70,_0x1d4178){return{'type':'child_added','snapshotNode':_0x1d4178,'childName':_0x1c3d70};}function Ot(_0x2a568c,_0x1b8f27){return{'type':'child_removed','snapshotNode':_0x1b8f27,'childName':_0x2a568c};}function Dt(_0x2c8ce1,_0x231d21,_0x437e1a){return{'type':'child_changed','snapshotNode':_0x231d21,'childName':_0x2c8ce1,'oldSnap':_0x437e1a};}function zh(_0x210733,_0x5b6975){return{'type':'child_moved','snapshotNode':_0x5b6975,'childName':_0x210733};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji{constructor(_0x171f7e){this['index_']=_0x171f7e;}['updateChild'](_0x509558,_0x50a506,_0x1dcdf0,_0x29a5ae,_0x4a5714,_0x4a0bfc){f(_0x509558['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0xde6182=_0x509558['getImmediateChild'](_0x50a506);return _0xde6182['getChild'](_0x29a5ae)['equals'](_0x1dcdf0['getChild'](_0x29a5ae))&&_0xde6182['isEmpty']()===_0x1dcdf0['isEmpty']()||(_0x4a0bfc!=null&&(_0x1dcdf0['isEmpty']()?_0x509558['hasChild'](_0x50a506)?_0x4a0bfc['trackChildChange'](Ot(_0x50a506,_0xde6182)):f(_0x509558['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0xde6182['isEmpty']()?_0x4a0bfc['trackChildChange'](et(_0x50a506,_0x1dcdf0)):_0x4a0bfc['trackChildChange'](Dt(_0x50a506,_0x1dcdf0,_0xde6182))),_0x509558['isLeafNode']()&&_0x1dcdf0['isEmpty']())?_0x509558:_0x509558['updateImmediateChild'](_0x50a506,_0x1dcdf0)['withIndex'](this['index_']);}['updateFullNode'](_0x333e47,_0x33e321,_0x34da68){return _0x34da68!=null&&(_0x333e47['isLeafNode']()||_0x333e47['forEachChild'](R,(_0x5095ce,_0x52e5ef)=>{_0x33e321['hasChild'](_0x5095ce)||_0x34da68['trackChildChange'](Ot(_0x5095ce,_0x52e5ef));}),_0x33e321['isLeafNode']()||_0x33e321['forEachChild'](R,(_0x250d46,_0x3fc314)=>{if(_0x333e47['hasChild'](_0x250d46)){const _0xa00d52=_0x333e47['getImmediateChild'](_0x250d46);_0xa00d52['equals'](_0x3fc314)||_0x34da68['trackChildChange'](Dt(_0x250d46,_0x3fc314,_0xa00d52));}else _0x34da68['trackChildChange'](et(_0x250d46,_0x3fc314));})),_0x33e321['withIndex'](this['index_']);}['updatePriority'](_0x2cda5c,_0x5766fd){return _0x2cda5c['isEmpty']()?g['EMPTY_NODE']:_0x2cda5c['updatePriority'](_0x5766fd);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Mt{constructor(_0x3df30d){this['indexedFilter_']=new Ji(_0x3df30d['getIndex']()),this['index_']=_0x3df30d['getIndex'](),this['startPost_']=Mt['getStartPost_'](_0x3df30d),this['endPost_']=Mt['getEndPost_'](_0x3df30d),this['startIsInclusive_']=!_0x3df30d['startAfterSet_'],this['endIsInclusive_']=!_0x3df30d['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x5d419d){const _0x47400f=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x5d419d)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x5d419d)<0x0,_0x50a61d=this['endIsInclusive_']?this['index_']['compare'](_0x5d419d,this['getEndPost']())<=0x0:this['index_']['compare'](_0x5d419d,this['getEndPost']())<0x0;return _0x47400f&&_0x50a61d;}['updateChild'](_0x120579,_0x4d5100,_0x38c49a,_0x2affe1,_0xf23534,_0x4f99e4){return this['matches'](new E(_0x4d5100,_0x38c49a))||(_0x38c49a=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x120579,_0x4d5100,_0x38c49a,_0x2affe1,_0xf23534,_0x4f99e4);}['updateFullNode'](_0x531c56,_0x5b8097,_0x33e86d){_0x5b8097['isLeafNode']()&&(_0x5b8097=g['EMPTY_NODE']);let _0x1c3bb4=_0x5b8097['withIndex'](this['index_']);_0x1c3bb4=_0x1c3bb4['updatePriority'](g['EMPTY_NODE']);const _0x357835=this;return _0x5b8097['forEachChild'](R,(_0x2aec2a,_0x5700d5)=>{_0x357835['matches'](new E(_0x2aec2a,_0x5700d5))||(_0x1c3bb4=_0x1c3bb4['updateImmediateChild'](_0x2aec2a,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x531c56,_0x1c3bb4,_0x33e86d);}['updatePriority'](_0x26afb5,_0x3016f5){return _0x26afb5;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0xe28434){if(_0xe28434['hasStart']()){const _0x1d7a30=_0xe28434['getIndexStartName']();return _0xe28434['getIndex']()['makePost'](_0xe28434['getIndexStartValue'](),_0x1d7a30);}else return _0xe28434['getIndex']()['minPost']();}static['getEndPost_'](_0x37054d){if(_0x37054d['hasEnd']()){const _0x5a251b=_0x37054d['getIndexEndName']();return _0x37054d['getIndex']()['makePost'](_0x37054d['getIndexEndValue'](),_0x5a251b);}else return _0x37054d['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x3fe6f9){this['withinDirectionalStart']=_0x106249=>this['reverse_']?this['withinEndPost'](_0x106249):this['withinStartPost'](_0x106249),this['withinDirectionalEnd']=_0x2b0944=>this['reverse_']?this['withinStartPost'](_0x2b0944):this['withinEndPost'](_0x2b0944),this['withinStartPost']=_0x59cad6=>{const _0x3946dc=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x59cad6);return this['startIsInclusive_']?_0x3946dc<=0x0:_0x3946dc<0x0;},this['withinEndPost']=_0x35beea=>{const _0x3b30a6=this['index_']['compare'](_0x35beea,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x3b30a6<=0x0:_0x3b30a6<0x0;},this['rangedFilter_']=new Mt(_0x3fe6f9),this['index_']=_0x3fe6f9['getIndex'](),this['limit_']=_0x3fe6f9['getLimit'](),this['reverse_']=!_0x3fe6f9['isViewFromLeft'](),this['startIsInclusive_']=!_0x3fe6f9['startAfterSet_'],this['endIsInclusive_']=!_0x3fe6f9['endBeforeSet_'];}['updateChild'](_0x103bda,_0x1bec6a,_0x1e4987,_0x2545b2,_0x1c4c72,_0x50207a){return this['rangedFilter_']['matches'](new E(_0x1bec6a,_0x1e4987))||(_0x1e4987=g['EMPTY_NODE']),_0x103bda['getImmediateChild'](_0x1bec6a)['equals'](_0x1e4987)?_0x103bda:_0x103bda['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x103bda,_0x1bec6a,_0x1e4987,_0x2545b2,_0x1c4c72,_0x50207a):this['fullLimitUpdateChild_'](_0x103bda,_0x1bec6a,_0x1e4987,_0x1c4c72,_0x50207a);}['updateFullNode'](_0x377164,_0x5f275e,_0x1f0b7a){let _0x13fa11;if(_0x5f275e['isLeafNode']()||_0x5f275e['isEmpty']())_0x13fa11=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x5f275e['numChildren']()&&_0x5f275e['isIndexed'](this['index_'])){_0x13fa11=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x211e9e;this['reverse_']?_0x211e9e=_0x5f275e['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x211e9e=_0x5f275e['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x6ba75=0x0;for(;_0x211e9e['hasNext']()&&_0x6ba75<this['limit_'];){const _0xf15576=_0x211e9e['getNext']();if(this['withinDirectionalStart'](_0xf15576)){if(this['withinDirectionalEnd'](_0xf15576))_0x13fa11=_0x13fa11['updateImmediateChild'](_0xf15576['name'],_0xf15576['node']),_0x6ba75++;else break;}else continue;}}else{_0x13fa11=_0x5f275e['withIndex'](this['index_']),_0x13fa11=_0x13fa11['updatePriority'](g['EMPTY_NODE']);let _0x5cfdd4;this['reverse_']?_0x5cfdd4=_0x13fa11['getReverseIterator'](this['index_']):_0x5cfdd4=_0x13fa11['getIterator'](this['index_']);let _0x186dea=0x0;for(;_0x5cfdd4['hasNext']();){const _0x22adaa=_0x5cfdd4['getNext']();_0x186dea<this['limit_']&&this['withinDirectionalStart'](_0x22adaa)&&this['withinDirectionalEnd'](_0x22adaa)?_0x186dea++:_0x13fa11=_0x13fa11['updateImmediateChild'](_0x22adaa['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x377164,_0x13fa11,_0x1f0b7a);}['updatePriority'](_0x459786,_0x550e12){return _0x459786;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x41a619,_0x27941b,_0x33d2ec,_0x17cb40,_0x110420){let _0x125d96;if(this['reverse_']){const _0x4a8cf4=this['index_']['getCompare']();_0x125d96=(_0x5ae099,_0x4805a3)=>_0x4a8cf4(_0x4805a3,_0x5ae099);}else _0x125d96=this['index_']['getCompare']();const _0x3fabae=_0x41a619;f(_0x3fabae['numChildren']()===this['limit_'],'');const _0x47a08a=new E(_0x27941b,_0x33d2ec),_0x31026d=this['reverse_']?_0x3fabae['getFirstChild'](this['index_']):_0x3fabae['getLastChild'](this['index_']),_0x480252=this['rangedFilter_']['matches'](_0x47a08a);if(_0x3fabae['hasChild'](_0x27941b)){const _0x3ff52c=_0x3fabae['getImmediateChild'](_0x27941b);let _0x51e7e0=_0x17cb40['getChildAfterChild'](this['index_'],_0x31026d,this['reverse_']);for(;_0x51e7e0!=null&&(_0x51e7e0['name']===_0x27941b||_0x3fabae['hasChild'](_0x51e7e0['name']));)_0x51e7e0=_0x17cb40['getChildAfterChild'](this['index_'],_0x51e7e0,this['reverse_']);const _0x50a045=_0x51e7e0==null?0x1:_0x125d96(_0x51e7e0,_0x47a08a);if(_0x480252&&!_0x33d2ec['isEmpty']()&&_0x50a045>=0x0)return _0x110420!=null&&_0x110420['trackChildChange'](Dt(_0x27941b,_0x33d2ec,_0x3ff52c)),_0x3fabae['updateImmediateChild'](_0x27941b,_0x33d2ec);{_0x110420!=null&&_0x110420['trackChildChange'](Ot(_0x27941b,_0x3ff52c));const _0x318919=_0x3fabae['updateImmediateChild'](_0x27941b,g['EMPTY_NODE']);return _0x51e7e0!=null&&this['rangedFilter_']['matches'](_0x51e7e0)?(_0x110420!=null&&_0x110420['trackChildChange'](et(_0x51e7e0['name'],_0x51e7e0['node'])),_0x318919['updateImmediateChild'](_0x51e7e0['name'],_0x51e7e0['node'])):_0x318919;}}else return _0x33d2ec['isEmpty']()?_0x41a619:_0x480252&&_0x125d96(_0x31026d,_0x47a08a)>=0x0?(_0x110420!=null&&(_0x110420['trackChildChange'](Ot(_0x31026d['name'],_0x31026d['node'])),_0x110420['trackChildChange'](et(_0x27941b,_0x33d2ec))),_0x3fabae['updateImmediateChild'](_0x27941b,_0x33d2ec)['updateImmediateChild'](_0x31026d['name'],g['EMPTY_NODE'])):_0x41a619;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:Fe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x38cc95=new Xi();return _0x38cc95['limitSet_']=this['limitSet_'],_0x38cc95['limit_']=this['limit_'],_0x38cc95['startSet_']=this['startSet_'],_0x38cc95['startAfterSet_']=this['startAfterSet_'],_0x38cc95['indexStartValue_']=this['indexStartValue_'],_0x38cc95['startNameSet_']=this['startNameSet_'],_0x38cc95['indexStartName_']=this['indexStartName_'],_0x38cc95['endSet_']=this['endSet_'],_0x38cc95['endBeforeSet_']=this['endBeforeSet_'],_0x38cc95['indexEndValue_']=this['indexEndValue_'],_0x38cc95['endNameSet_']=this['endNameSet_'],_0x38cc95['indexEndName_']=this['indexEndName_'],_0x38cc95['index_']=this['index_'],_0x38cc95['viewFrom_']=this['viewFrom_'],_0x38cc95;}}function Kh(_0x3e04da){return _0x3e04da['loadsAllData']()?new Ji(_0x3e04da['getIndex']()):_0x3e04da['hasLimit']()?new jh(_0x3e04da):new Mt(_0x3e04da);}function Yh(_0x50aa35,_0x4ddb14){const _0xaa550c=_0x50aa35['copy']();return _0xaa550c['limitSet_']=!0x0,_0xaa550c['limit_']=_0x4ddb14,_0xaa550c['viewFrom_']='l',_0xaa550c;}function Qh(_0x42f484,_0x52f666,_0x4efb34){const _0x28b9e3=_0x42f484['copy']();return _0x28b9e3['startSet_']=!0x0,_0x52f666===void 0x0&&(_0x52f666=null),_0x28b9e3['indexStartValue_']=_0x52f666,_0x4efb34!=null?(_0x28b9e3['startNameSet_']=!0x0,_0x28b9e3['indexStartName_']=_0x4efb34):(_0x28b9e3['startNameSet_']=!0x1,_0x28b9e3['indexStartName_']=''),_0x28b9e3;}function Jh(_0x25795d,_0xeb11e4,_0x26b7af){const _0x61ce83=_0x25795d['copy']();return _0x61ce83['endSet_']=!0x0,_0xeb11e4===void 0x0&&(_0xeb11e4=null),_0x61ce83['indexEndValue_']=_0xeb11e4,_0x26b7af!==void 0x0?(_0x61ce83['endNameSet_']=!0x0,_0x61ce83['indexEndName_']=_0x26b7af):(_0x61ce83['endNameSet_']=!0x1,_0x61ce83['indexEndName_']=''),_0x61ce83;}function xo(_0x2da40d,_0x285c88){const _0x2486ea=_0x2da40d['copy']();return _0x2486ea['index_']=_0x285c88,_0x2486ea;}function sr(_0x41edfe){const _0x1f0646={};if(_0x41edfe['isDefault']())return _0x1f0646;let _0x493224;if(_0x41edfe['index_']===R?_0x493224='$priority':_0x41edfe['index_']===Mo?_0x493224='$value':_0x41edfe['index_']===ye?_0x493224='$key':(f(_0x41edfe['index_']instanceof Qi,'Unrecognized\x20index\x20type!'),_0x493224=_0x41edfe['index_']['toString']()),_0x1f0646['orderBy']=O(_0x493224),_0x41edfe['startSet_']){const _0x2b1ef2=_0x41edfe['startAfterSet_']?'startAfter':'startAt';_0x1f0646[_0x2b1ef2]=O(_0x41edfe['indexStartValue_']),_0x41edfe['startNameSet_']&&(_0x1f0646[_0x2b1ef2]+=','+O(_0x41edfe['indexStartName_']));}if(_0x41edfe['endSet_']){const _0x3cb28d=_0x41edfe['endBeforeSet_']?'endBefore':'endAt';_0x1f0646[_0x3cb28d]=O(_0x41edfe['indexEndValue_']),_0x41edfe['endNameSet_']&&(_0x1f0646[_0x3cb28d]+=','+O(_0x41edfe['indexEndName_']));}return _0x41edfe['limitSet_']&&(_0x41edfe['isViewFromLeft']()?_0x1f0646['limitToFirst']=_0x41edfe['limit_']:_0x1f0646['limitToLast']=_0x41edfe['limit_']),_0x1f0646;}function rr(_0x163b40){const _0xff74cc={};if(_0x163b40['startSet_']&&(_0xff74cc['sp']=_0x163b40['indexStartValue_'],_0x163b40['startNameSet_']&&(_0xff74cc['sn']=_0x163b40['indexStartName_']),_0xff74cc['sin']=!_0x163b40['startAfterSet_']),_0x163b40['endSet_']&&(_0xff74cc['ep']=_0x163b40['indexEndValue_'],_0x163b40['endNameSet_']&&(_0xff74cc['en']=_0x163b40['indexEndName_']),_0xff74cc['ein']=!_0x163b40['endBeforeSet_']),_0x163b40['limitSet_']){_0xff74cc['l']=_0x163b40['limit_'];let _0x39ba20=_0x163b40['viewFrom_'];_0x39ba20===''&&(_0x163b40['isViewFromLeft']()?_0x39ba20='l':_0x39ba20='r'),_0xff74cc['vf']=_0x39ba20;}return _0x163b40['index_']!==R&&(_0xff74cc['i']=_0x163b40['index_']['toString']()),_0xff74cc;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pn extends So{['reportStats'](_0x277f24){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x22d623,_0x983b46){return _0x983b46!==void 0x0?'tag$'+_0x983b46:(f(_0x22d623['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x22d623['_path']['toString']());}constructor(_0x26f46e,_0x444366,_0x23a407,_0x5bcce2){super(),this['repoInfo_']=_0x26f46e,this['onDataUpdate_']=_0x444366,this['authTokenProvider_']=_0x23a407,this['appCheckTokenProvider_']=_0x5bcce2,this['log_']=Ht('p:rest:'),this['listens_']={};}['listen'](_0x43d252,_0x304a18,_0x4e7dd2,_0x299fcb){const _0x34eb3e=_0x43d252['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x34eb3e+'\x20'+_0x43d252['_queryIdentifier']);const _0x4355f0=pn['getListenId_'](_0x43d252,_0x4e7dd2),_0x1dffc0={};this['listens_'][_0x4355f0]=_0x1dffc0;const _0x372072=sr(_0x43d252['_queryParams']);this['restRequest_'](_0x34eb3e+'.json',_0x372072,(_0x146482,_0x39d064)=>{let _0x599bb1=_0x39d064;if(_0x146482===0x194&&(_0x599bb1=null,_0x146482=null),_0x146482===null&&this['onDataUpdate_'](_0x34eb3e,_0x599bb1,!0x1,_0x4e7dd2),De(this['listens_'],_0x4355f0)===_0x1dffc0){let _0x54df73;_0x146482?_0x146482===0x191?_0x54df73='permission_denied':_0x54df73='rest_error:'+_0x146482:_0x54df73='ok',_0x299fcb(_0x54df73,null);}});}['unlisten'](_0x469890,_0x41cb10){const _0x4ba03a=pn['getListenId_'](_0x469890,_0x41cb10);delete this['listens_'][_0x4ba03a];}['get'](_0x25d39c){const _0x23d7bd=sr(_0x25d39c['_queryParams']),_0x209359=_0x25d39c['_path']['toString'](),_0x3fbe7a=new ot();return this['restRequest_'](_0x209359+'.json',_0x23d7bd,(_0x4f26e9,_0x38c437)=>{let _0x504c52=_0x38c437;_0x4f26e9===0x194&&(_0x504c52=null,_0x4f26e9=null),_0x4f26e9===null?(this['onDataUpdate_'](_0x209359,_0x504c52,!0x1,null),_0x3fbe7a['resolve'](_0x504c52)):_0x3fbe7a['reject'](new Error(_0x504c52));}),_0x3fbe7a['promise'];}['refreshAuthToken'](_0x103cfe){}['restRequest_'](_0x3b7dc7,_0x54da0a={},_0x4dddd3){return _0x54da0a['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x4793af,_0x2eebab])=>{_0x4793af&&_0x4793af['accessToken']&&(_0x54da0a['auth']=_0x4793af['accessToken']),_0x2eebab&&_0x2eebab['token']&&(_0x54da0a['ac']=_0x2eebab['token']);const _0x3f70a0=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x3b7dc7+'?ns='+this['repoInfo_']['namespace']+ct(_0x54da0a);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x3f70a0);const _0x3a6f20=new XMLHttpRequest();_0x3a6f20['onreadystatechange']=()=>{if(_0x4dddd3&&_0x3a6f20['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x3f70a0+'\x20received.\x20status:',_0x3a6f20['status'],'response:',_0x3a6f20['responseText']);let _0x7165f=null;if(_0x3a6f20['status']>=0xc8&&_0x3a6f20['status']<0x12c){try{_0x7165f=At(_0x3a6f20['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x3f70a0+':\x20'+_0x3a6f20['responseText']);}_0x4dddd3(null,_0x7165f);}else _0x3a6f20['status']!==0x191&&_0x3a6f20['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x3f70a0+'\x20Status:\x20'+_0x3a6f20['status']),_0x4dddd3(_0x3a6f20['status']);_0x4dddd3=null;}},_0x3a6f20['open']('GET',_0x3f70a0,!0x0),_0x3a6f20['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x54d9a7){return this['rootNode_']['getChild'](_0x54d9a7);}['updateSnapshot'](_0x334458,_0x4a95c9){this['rootNode_']=this['rootNode_']['updateChild'](_0x334458,_0x4a95c9);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function _n(){return{'value':null,'children':new Map()};}function Fo(_0x1c00a6,_0x3d13ee,_0x4b89c0){if(v(_0x3d13ee))_0x1c00a6['value']=_0x4b89c0,_0x1c00a6['children']['clear']();else{if(_0x1c00a6['value']!==null)_0x1c00a6['value']=_0x1c00a6['value']['updateChild'](_0x3d13ee,_0x4b89c0);else{const _0x1d7250=y(_0x3d13ee);_0x1c00a6['children']['has'](_0x1d7250)||_0x1c00a6['children']['set'](_0x1d7250,_n());const _0x232c70=_0x1c00a6['children']['get'](_0x1d7250);_0x3d13ee=b(_0x3d13ee),Fo(_0x232c70,_0x3d13ee,_0x4b89c0);}}}function Ii(_0x6bfa27,_0x477065,_0x102c25){_0x6bfa27['value']!==null?_0x102c25(_0x477065,_0x6bfa27['value']):Zh(_0x6bfa27,(_0x1b4832,_0x58ae14)=>{const _0x15d68f=new C(_0x477065['toString']()+'/'+_0x1b4832);Ii(_0x58ae14,_0x15d68f,_0x102c25);});}function Zh(_0x4499c2,_0x4cc09e){_0x4499c2['children']['forEach']((_0x5c0354,_0x4060a6)=>{_0x4cc09e(_0x4060a6,_0x5c0354);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x17d6ac){this['collection_']=_0x17d6ac,this['last_']=null;}['get'](){const _0x1d085d=this['collection_']['get'](),_0x56edd7={..._0x1d085d};return this['last_']&&x(this['last_'],(_0x4c817d,_0xa82150)=>{_0x56edd7[_0x4c817d]=_0x56edd7[_0x4c817d]-_0xa82150;}),this['last_']=_0x1d085d,_0x56edd7;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const or=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x31ea84,_0x32819a){this['server_']=_0x32819a,this['statsToReport_']={},this['statsListener_']=new eu(_0x31ea84);const _0x2278fd=or+(tu-or)*Math['random']();Ct(this['reportStats_']['bind'](this),Math['floor'](_0x2278fd));}['reportStats_'](){const _0x49b803=this['statsListener_']['get'](),_0x339935={};let _0x596968=!0x1;x(_0x49b803,(_0x4bb2b7,_0x26039d)=>{_0x26039d>0x0&&J(this['statsToReport_'],_0x4bb2b7)&&(_0x339935[_0x4bb2b7]=_0x26039d,_0x596968=!0x0);}),_0x596968&&this['server_']['reportStats'](_0x339935),Ct(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var j;(function(_0x169f5f){_0x169f5f[_0x169f5f['OVERWRITE']=0x0]='OVERWRITE',_0x169f5f[_0x169f5f['MERGE']=0x1]='MERGE',_0x169f5f[_0x169f5f['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x169f5f[_0x169f5f['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(j||(j={})));function Zi(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function es(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ts(_0x2580b5){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x2580b5,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gn{constructor(_0x36fd24,_0x18e5e0,_0x2b3e13){this['path']=_0x36fd24,this['affectedTree']=_0x18e5e0,this['revert']=_0x2b3e13,this['type']=j['ACK_USER_WRITE'],this['source']=Zi();}['operationForChild'](_0xeae4f7){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x2867d5=this['affectedTree']['subtree'](new C(_0xeae4f7));return new gn(w(),_0x2867d5,this['revert']);}}else return f(y(this['path'])===_0xeae4f7,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new gn(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Lt{constructor(_0x261df1,_0x3fce97){this['source']=_0x261df1,this['path']=_0x3fce97,this['type']=j['LISTEN_COMPLETE'];}['operationForChild'](_0x4d4c91){return v(this['path'])?new Lt(this['source'],w()):new Lt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ue{constructor(_0x329ab3,_0x100453,_0x9c1a63){this['source']=_0x329ab3,this['path']=_0x100453,this['snap']=_0x9c1a63,this['type']=j['OVERWRITE'];}['operationForChild'](_0x38746d){return v(this['path'])?new Ue(this['source'],w(),this['snap']['getImmediateChild'](_0x38746d)):new Ue(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tt{constructor(_0x191372,_0xba6807,_0x4b4f04){this['source']=_0x191372,this['path']=_0xba6807,this['children']=_0x4b4f04,this['type']=j['MERGE'];}['operationForChild'](_0x5b8088){if(v(this['path'])){const _0x169d69=this['children']['subtree'](new C(_0x5b8088));return _0x169d69['isEmpty']()?null:_0x169d69['value']?new Ue(this['source'],w(),_0x169d69['value']):new tt(this['source'],w(),_0x169d69);}else return f(y(this['path'])===_0x5b8088,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new tt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0xd3af70,_0x40db84,_0x176797){this['node_']=_0xd3af70,this['fullyInitialized_']=_0x40db84,this['filtered_']=_0x176797;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0xff8c1c){if(v(_0xff8c1c))return this['isFullyInitialized']()&&!this['filtered_'];const _0x3b77ba=y(_0xff8c1c);return this['isCompleteForChild'](_0x3b77ba);}['isCompleteForChild'](_0x45d5ad){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x45d5ad);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x245e5c){this['query_']=_0x245e5c,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x431bc4,_0x1a74f9,_0x483bc1,_0x2d3b4e){const _0x104851=[],_0x47ff43=[];return _0x1a74f9['forEach'](_0x4b66b2=>{_0x4b66b2['type']==='child_changed'&&_0x431bc4['index_']['indexedValueChanged'](_0x4b66b2['oldSnap'],_0x4b66b2['snapshotNode'])&&_0x47ff43['push'](zh(_0x4b66b2['childName'],_0x4b66b2['snapshotNode']));}),yt(_0x431bc4,_0x104851,'child_removed',_0x1a74f9,_0x2d3b4e,_0x483bc1),yt(_0x431bc4,_0x104851,'child_added',_0x1a74f9,_0x2d3b4e,_0x483bc1),yt(_0x431bc4,_0x104851,'child_moved',_0x47ff43,_0x2d3b4e,_0x483bc1),yt(_0x431bc4,_0x104851,'child_changed',_0x1a74f9,_0x2d3b4e,_0x483bc1),yt(_0x431bc4,_0x104851,'value',_0x1a74f9,_0x2d3b4e,_0x483bc1),_0x104851;}function yt(_0x5619f0,_0x3ec15d,_0x57f249,_0x6f83d6,_0x4ec27f,_0x4f04d2){const _0x35ad16=_0x6f83d6['filter'](_0x14d541=>_0x14d541['type']===_0x57f249);_0x35ad16['sort']((_0xde4903,_0x408967)=>au(_0x5619f0,_0xde4903,_0x408967)),_0x35ad16['forEach'](_0x418f6f=>{const _0x1f47c7=ou(_0x5619f0,_0x418f6f,_0x4f04d2);_0x4ec27f['forEach'](_0x282fd8=>{_0x282fd8['respondsTo'](_0x418f6f['type'])&&_0x3ec15d['push'](_0x282fd8['createEvent'](_0x1f47c7,_0x5619f0['query_']));});});}function ou(_0x58cd9f,_0x27b996,_0x36dd04){return _0x27b996['type']==='value'||_0x27b996['type']==='child_removed'||(_0x27b996['prevName']=_0x36dd04['getPredecessorChildName'](_0x27b996['childName'],_0x27b996['snapshotNode'],_0x58cd9f['index_'])),_0x27b996;}function au(_0x13b6cd,_0x4776dd,_0x57258f){if(_0x4776dd['childName']==null||_0x57258f['childName']==null)throw rt('Should\x20only\x20compare\x20child_\x20events.');const _0x1f2ada=new E(_0x4776dd['childName'],_0x4776dd['snapshotNode']),_0x5e301c=new E(_0x57258f['childName'],_0x57258f['snapshotNode']);return _0x13b6cd['index_']['compare'](_0x1f2ada,_0x5e301c);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0xa651e7,_0x8447e0){return{'eventCache':_0xa651e7,'serverCache':_0x8447e0};}function Tt(_0x18309e,_0x5d0644,_0xde91d5,_0x1ee085){return Mn(new Ce(_0x5d0644,_0xde91d5,_0x1ee085),_0x18309e['serverCache']);}function Uo(_0x1fca45,_0x5768e6,_0x3d4186,_0x33c934){return Mn(_0x1fca45['eventCache'],new Ce(_0x5768e6,_0x3d4186,_0x33c934));}function mn(_0x1e5a35){return _0x1e5a35['eventCache']['isFullyInitialized']()?_0x1e5a35['eventCache']['getNode']():null;}function We(_0x1b4293){return _0x1b4293['serverCache']['isFullyInitialized']()?_0x1b4293['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let oi;const cu=()=>(oi||(oi=new B(ql)),oi);class S{static['fromObject'](_0x20c680){let _0x1d3156=new S(null);return x(_0x20c680,(_0x5a9d4f,_0x237eeb)=>{_0x1d3156=_0x1d3156['set'](new C(_0x5a9d4f),_0x237eeb);}),_0x1d3156;}constructor(_0xdecf94,_0x317d50=cu()){this['value']=_0xdecf94,this['children']=_0x317d50;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x1dcf6b,_0x14c7a3){if(this['value']!=null&&_0x14c7a3(this['value']))return{'path':w(),'value':this['value']};if(v(_0x1dcf6b))return null;{const _0x24909b=y(_0x1dcf6b),_0x57dc4b=this['children']['get'](_0x24909b);if(_0x57dc4b!==null){const _0xe12152=_0x57dc4b['findRootMostMatchingPathAndValue'](b(_0x1dcf6b),_0x14c7a3);return _0xe12152!=null?{'path':k(new C(_0x24909b),_0xe12152['path']),'value':_0xe12152['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x3d8279){return this['findRootMostMatchingPathAndValue'](_0x3d8279,()=>!0x0);}['subtree'](_0x2bcf12){if(v(_0x2bcf12))return this;{const _0x3f609b=y(_0x2bcf12),_0xeca9f8=this['children']['get'](_0x3f609b);return _0xeca9f8!==null?_0xeca9f8['subtree'](b(_0x2bcf12)):new S(null);}}['set'](_0x36fc86,_0x2215f4){if(v(_0x36fc86))return new S(_0x2215f4,this['children']);{const _0x5d22ed=y(_0x36fc86),_0x456883=(this['children']['get'](_0x5d22ed)||new S(null))['set'](b(_0x36fc86),_0x2215f4),_0x47ce69=this['children']['insert'](_0x5d22ed,_0x456883);return new S(this['value'],_0x47ce69);}}['remove'](_0x6d89d5){if(v(_0x6d89d5))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x18d9c7=y(_0x6d89d5),_0x5b3fa7=this['children']['get'](_0x18d9c7);if(_0x5b3fa7){const _0x5bbd42=_0x5b3fa7['remove'](b(_0x6d89d5));let _0x542350;return _0x5bbd42['isEmpty']()?_0x542350=this['children']['remove'](_0x18d9c7):_0x542350=this['children']['insert'](_0x18d9c7,_0x5bbd42),this['value']===null&&_0x542350['isEmpty']()?new S(null):new S(this['value'],_0x542350);}else return this;}}['get'](_0x3299a3){if(v(_0x3299a3))return this['value'];{const _0x5605eb=y(_0x3299a3),_0x5cb791=this['children']['get'](_0x5605eb);return _0x5cb791?_0x5cb791['get'](b(_0x3299a3)):null;}}['setTree'](_0xa5c402,_0x2033b4){if(v(_0xa5c402))return _0x2033b4;{const _0x4e8d09=y(_0xa5c402),_0x1e3f93=(this['children']['get'](_0x4e8d09)||new S(null))['setTree'](b(_0xa5c402),_0x2033b4);let _0x39ff00;return _0x1e3f93['isEmpty']()?_0x39ff00=this['children']['remove'](_0x4e8d09):_0x39ff00=this['children']['insert'](_0x4e8d09,_0x1e3f93),new S(this['value'],_0x39ff00);}}['fold'](_0x44bb30){return this['fold_'](w(),_0x44bb30);}['fold_'](_0x161f08,_0x47f87c){const _0x4505c5={};return this['children']['inorderTraversal']((_0x3aaf89,_0x540088)=>{_0x4505c5[_0x3aaf89]=_0x540088['fold_'](k(_0x161f08,_0x3aaf89),_0x47f87c);}),_0x47f87c(_0x161f08,this['value'],_0x4505c5);}['findOnPath'](_0x1770e8,_0x33559e){return this['findOnPath_'](_0x1770e8,w(),_0x33559e);}['findOnPath_'](_0x225f4a,_0x2bd6a6,_0x5748ab){const _0x65b52=this['value']?_0x5748ab(_0x2bd6a6,this['value']):!0x1;if(_0x65b52)return _0x65b52;if(v(_0x225f4a))return null;{const _0x152491=y(_0x225f4a),_0x50a782=this['children']['get'](_0x152491);return _0x50a782?_0x50a782['findOnPath_'](b(_0x225f4a),k(_0x2bd6a6,_0x152491),_0x5748ab):null;}}['foreachOnPath'](_0x43a620,_0x1ee8fc){return this['foreachOnPath_'](_0x43a620,w(),_0x1ee8fc);}['foreachOnPath_'](_0x5ea308,_0x4bdf29,_0x27d4d1){if(v(_0x5ea308))return this;{this['value']&&_0x27d4d1(_0x4bdf29,this['value']);const _0x1e7b88=y(_0x5ea308),_0xd84ffd=this['children']['get'](_0x1e7b88);return _0xd84ffd?_0xd84ffd['foreachOnPath_'](b(_0x5ea308),k(_0x4bdf29,_0x1e7b88),_0x27d4d1):new S(null);}}['foreach'](_0x3d879a){this['foreach_'](w(),_0x3d879a);}['foreach_'](_0x444f21,_0x498fbf){this['children']['inorderTraversal']((_0x2b649e,_0x21eb02)=>{_0x21eb02['foreach_'](k(_0x444f21,_0x2b649e),_0x498fbf);}),this['value']&&_0x498fbf(_0x444f21,this['value']);}['foreachChild'](_0x1f413d){this['children']['inorderTraversal']((_0x1a0345,_0x107631)=>{_0x107631['value']&&_0x1f413d(_0x1a0345,_0x107631['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Y{constructor(_0xa38c77){this['writeTree_']=_0xa38c77;}static['empty'](){return new Y(new S(null));}}function St(_0x14aefc,_0x4bea1b,_0x3ef656){if(v(_0x4bea1b))return new Y(new S(_0x3ef656));{const _0x1d5f1b=_0x14aefc['writeTree_']['findRootMostValueAndPath'](_0x4bea1b);if(_0x1d5f1b!=null){const _0x123ede=_0x1d5f1b['path'];let _0x304541=_0x1d5f1b['value'];const _0x553e43=F(_0x123ede,_0x4bea1b);return _0x304541=_0x304541['updateChild'](_0x553e43,_0x3ef656),new Y(_0x14aefc['writeTree_']['set'](_0x123ede,_0x304541));}else{const _0x365e8e=new S(_0x3ef656),_0x8866bd=_0x14aefc['writeTree_']['setTree'](_0x4bea1b,_0x365e8e);return new Y(_0x8866bd);}}}function wi(_0xb0150,_0x769027,_0x30bf8a){let _0x5b1523=_0xb0150;return x(_0x30bf8a,(_0x53bc16,_0x30ac5e)=>{_0x5b1523=St(_0x5b1523,k(_0x769027,_0x53bc16),_0x30ac5e);}),_0x5b1523;}function ar(_0x487149,_0x149066){if(v(_0x149066))return Y['empty']();{const _0x28df53=_0x487149['writeTree_']['setTree'](_0x149066,new S(null));return new Y(_0x28df53);}}function Ci(_0x54d860,_0x3bfd52){return $e(_0x54d860,_0x3bfd52)!=null;}function $e(_0xbbd530,_0x59194c){const _0x45a7a2=_0xbbd530['writeTree_']['findRootMostValueAndPath'](_0x59194c);return _0x45a7a2!=null?_0xbbd530['writeTree_']['get'](_0x45a7a2['path'])['getChild'](F(_0x45a7a2['path'],_0x59194c)):null;}function cr(_0xe345b1){const _0x795831=[],_0x41c5c1=_0xe345b1['writeTree_']['value'];return _0x41c5c1!=null?_0x41c5c1['isLeafNode']()||_0x41c5c1['forEachChild'](R,(_0x181e52,_0x2a19c9)=>{_0x795831['push'](new E(_0x181e52,_0x2a19c9));}):_0xe345b1['writeTree_']['children']['inorderTraversal']((_0x4964c2,_0x1b9812)=>{_0x1b9812['value']!=null&&_0x795831['push'](new E(_0x4964c2,_0x1b9812['value']));}),_0x795831;}function ve(_0x30e9d2,_0x22c716){if(v(_0x22c716))return _0x30e9d2;{const _0x1aacc8=$e(_0x30e9d2,_0x22c716);return _0x1aacc8!=null?new Y(new S(_0x1aacc8)):new Y(_0x30e9d2['writeTree_']['subtree'](_0x22c716));}}function Ti(_0x468c1f){return _0x468c1f['writeTree_']['isEmpty']();}function nt(_0x52d198,_0x3b7c9a){return Wo(w(),_0x52d198['writeTree_'],_0x3b7c9a);}function Wo(_0x4481c5,_0x3af7e0,_0x447b35){if(_0x3af7e0['value']!=null)return _0x447b35['updateChild'](_0x4481c5,_0x3af7e0['value']);{let _0x2faf59=null;return _0x3af7e0['children']['inorderTraversal']((_0x401936,_0x54e99e)=>{_0x401936==='.priority'?(f(_0x54e99e['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x2faf59=_0x54e99e['value']):_0x447b35=Wo(k(_0x4481c5,_0x401936),_0x54e99e,_0x447b35);}),!_0x447b35['getChild'](_0x4481c5)['isEmpty']()&&_0x2faf59!==null&&(_0x447b35=_0x447b35['updateChild'](k(_0x4481c5,'.priority'),_0x2faf59)),_0x447b35;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ln(_0x495de8,_0x441612){return $o(_0x441612,_0x495de8);}function lu(_0x3f9f6f,_0xa9ede3,_0x3d8b50,_0x5ddeb8,_0x5b47a9){f(_0x5ddeb8>_0x3f9f6f['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x5b47a9===void 0x0&&(_0x5b47a9=!0x0),_0x3f9f6f['allWrites']['push']({'path':_0xa9ede3,'snap':_0x3d8b50,'writeId':_0x5ddeb8,'visible':_0x5b47a9}),_0x5b47a9&&(_0x3f9f6f['visibleWrites']=St(_0x3f9f6f['visibleWrites'],_0xa9ede3,_0x3d8b50)),_0x3f9f6f['lastWriteId']=_0x5ddeb8;}function hu(_0x2c60b1,_0x301952,_0x46ac9a,_0x10b12d){f(_0x10b12d>_0x2c60b1['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x2c60b1['allWrites']['push']({'path':_0x301952,'children':_0x46ac9a,'writeId':_0x10b12d,'visible':!0x0}),_0x2c60b1['visibleWrites']=wi(_0x2c60b1['visibleWrites'],_0x301952,_0x46ac9a),_0x2c60b1['lastWriteId']=_0x10b12d;}function uu(_0x562d0d,_0x2fb38f){for(let _0x49a082=0x0;_0x49a082<_0x562d0d['allWrites']['length'];_0x49a082++){const _0x227e2c=_0x562d0d['allWrites'][_0x49a082];if(_0x227e2c['writeId']===_0x2fb38f)return _0x227e2c;}return null;}function du(_0x5d865c,_0xc65949){const _0x3c79a5=_0x5d865c['allWrites']['findIndex'](_0x324c30=>_0x324c30['writeId']===_0xc65949);f(_0x3c79a5>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x5c78f7=_0x5d865c['allWrites'][_0x3c79a5];_0x5d865c['allWrites']['splice'](_0x3c79a5,0x1);let _0x3876fe=_0x5c78f7['visible'],_0x2e9432=!0x1,_0x26f14b=_0x5d865c['allWrites']['length']-0x1;for(;_0x3876fe&&_0x26f14b>=0x0;){const _0x1773df=_0x5d865c['allWrites'][_0x26f14b];_0x1773df['visible']&&(_0x26f14b>=_0x3c79a5&&fu(_0x1773df,_0x5c78f7['path'])?_0x3876fe=!0x1:G(_0x5c78f7['path'],_0x1773df['path'])&&(_0x2e9432=!0x0)),_0x26f14b--;}if(_0x3876fe){if(_0x2e9432)return pu(_0x5d865c),!0x0;if(_0x5c78f7['snap'])_0x5d865c['visibleWrites']=ar(_0x5d865c['visibleWrites'],_0x5c78f7['path']);else{const _0x7ebd51=_0x5c78f7['children'];x(_0x7ebd51,_0x197bcb=>{_0x5d865c['visibleWrites']=ar(_0x5d865c['visibleWrites'],k(_0x5c78f7['path'],_0x197bcb));});}return!0x0;}else return!0x1;}function fu(_0x3da600,_0x5f3e79){if(_0x3da600['snap'])return G(_0x3da600['path'],_0x5f3e79);for(const _0x28e364 in _0x3da600['children'])if(_0x3da600['children']['hasOwnProperty'](_0x28e364)&&G(k(_0x3da600['path'],_0x28e364),_0x5f3e79))return!0x0;return!0x1;}function pu(_0xea4e3e){_0xea4e3e['visibleWrites']=Bo(_0xea4e3e['allWrites'],_u,w()),_0xea4e3e['allWrites']['length']>0x0?_0xea4e3e['lastWriteId']=_0xea4e3e['allWrites'][_0xea4e3e['allWrites']['length']-0x1]['writeId']:_0xea4e3e['lastWriteId']=-0x1;}function _u(_0xb49a58){return _0xb49a58['visible'];}function Bo(_0x56d7e1,_0x408ac9,_0x172b62){let _0xe39604=Y['empty']();for(let _0xfb3d89=0x0;_0xfb3d89<_0x56d7e1['length'];++_0xfb3d89){const _0xd2d680=_0x56d7e1[_0xfb3d89];if(_0x408ac9(_0xd2d680)){const _0x3a3228=_0xd2d680['path'];let _0x4ecc08;if(_0xd2d680['snap'])G(_0x172b62,_0x3a3228)?(_0x4ecc08=F(_0x172b62,_0x3a3228),_0xe39604=St(_0xe39604,_0x4ecc08,_0xd2d680['snap'])):G(_0x3a3228,_0x172b62)&&(_0x4ecc08=F(_0x3a3228,_0x172b62),_0xe39604=St(_0xe39604,w(),_0xd2d680['snap']['getChild'](_0x4ecc08)));else{if(_0xd2d680['children']){if(G(_0x172b62,_0x3a3228))_0x4ecc08=F(_0x172b62,_0x3a3228),_0xe39604=wi(_0xe39604,_0x4ecc08,_0xd2d680['children']);else{if(G(_0x3a3228,_0x172b62)){if(_0x4ecc08=F(_0x3a3228,_0x172b62),v(_0x4ecc08))_0xe39604=wi(_0xe39604,w(),_0xd2d680['children']);else{const _0x461375=De(_0xd2d680['children'],y(_0x4ecc08));if(_0x461375){const _0x31246e=_0x461375['getChild'](b(_0x4ecc08));_0xe39604=St(_0xe39604,w(),_0x31246e);}}}}}else throw rt('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0xe39604;}function Vo(_0x258bfd,_0x9d327b,_0x4f30ea,_0x398cef,_0x4ea879){if(!_0x398cef&&!_0x4ea879){const _0x7ddbc3=$e(_0x258bfd['visibleWrites'],_0x9d327b);if(_0x7ddbc3!=null)return _0x7ddbc3;{const _0x7150bb=ve(_0x258bfd['visibleWrites'],_0x9d327b);if(Ti(_0x7150bb))return _0x4f30ea;if(_0x4f30ea==null&&!Ci(_0x7150bb,w()))return null;{const _0x11b5ad=_0x4f30ea||g['EMPTY_NODE'];return nt(_0x7150bb,_0x11b5ad);}}}else{const _0x33d119=ve(_0x258bfd['visibleWrites'],_0x9d327b);if(!_0x4ea879&&Ti(_0x33d119))return _0x4f30ea;if(!_0x4ea879&&_0x4f30ea==null&&!Ci(_0x33d119,w()))return null;{const _0x21d21d=function(_0x4f9158){return(_0x4f9158['visible']||_0x4ea879)&&(!_0x398cef||!~_0x398cef['indexOf'](_0x4f9158['writeId']))&&(G(_0x4f9158['path'],_0x9d327b)||G(_0x9d327b,_0x4f9158['path']));},_0x2dce3a=Bo(_0x258bfd['allWrites'],_0x21d21d,_0x9d327b),_0x3c87e3=_0x4f30ea||g['EMPTY_NODE'];return nt(_0x2dce3a,_0x3c87e3);}}}function gu(_0x28958d,_0x439297,_0x20b2ac){let _0x5dddc0=g['EMPTY_NODE'];const _0x1ac449=$e(_0x28958d['visibleWrites'],_0x439297);if(_0x1ac449)return _0x1ac449['isLeafNode']()||_0x1ac449['forEachChild'](R,(_0x5f4494,_0x5c7d5e)=>{_0x5dddc0=_0x5dddc0['updateImmediateChild'](_0x5f4494,_0x5c7d5e);}),_0x5dddc0;if(_0x20b2ac){const _0x445ea7=ve(_0x28958d['visibleWrites'],_0x439297);return _0x20b2ac['forEachChild'](R,(_0x4293a1,_0x5455ab)=>{const _0x1762eb=nt(ve(_0x445ea7,new C(_0x4293a1)),_0x5455ab);_0x5dddc0=_0x5dddc0['updateImmediateChild'](_0x4293a1,_0x1762eb);}),cr(_0x445ea7)['forEach'](_0x51a3c0=>{_0x5dddc0=_0x5dddc0['updateImmediateChild'](_0x51a3c0['name'],_0x51a3c0['node']);}),_0x5dddc0;}else{const _0x5dae80=ve(_0x28958d['visibleWrites'],_0x439297);return cr(_0x5dae80)['forEach'](_0x48d0cc=>{_0x5dddc0=_0x5dddc0['updateImmediateChild'](_0x48d0cc['name'],_0x48d0cc['node']);}),_0x5dddc0;}}function mu(_0x27f054,_0x4284b3,_0x4c0387,_0x389655,_0x46cefb){f(_0x389655||_0x46cefb,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x5ae76c=k(_0x4284b3,_0x4c0387);if(Ci(_0x27f054['visibleWrites'],_0x5ae76c))return null;{const _0xfbbc8=ve(_0x27f054['visibleWrites'],_0x5ae76c);return Ti(_0xfbbc8)?_0x46cefb['getChild'](_0x4c0387):nt(_0xfbbc8,_0x46cefb['getChild'](_0x4c0387));}}function yu(_0xd07857,_0x3b350f,_0x4d3339,_0x3cc8d2){const _0x54b67c=k(_0x3b350f,_0x4d3339),_0xc9bd89=$e(_0xd07857['visibleWrites'],_0x54b67c);if(_0xc9bd89!=null)return _0xc9bd89;if(_0x3cc8d2['isCompleteForChild'](_0x4d3339)){const _0x24a83e=ve(_0xd07857['visibleWrites'],_0x54b67c);return nt(_0x24a83e,_0x3cc8d2['getNode']()['getImmediateChild'](_0x4d3339));}else return null;}function vu(_0x1bc710,_0x454a39){return $e(_0x1bc710['visibleWrites'],_0x454a39);}function Eu(_0x445904,_0x90d5a4,_0x39f3a6,_0x2ad307,_0xfdec56,_0x290a7c,_0x10e32e){let _0x1155c8;const _0x39f4f3=ve(_0x445904['visibleWrites'],_0x90d5a4),_0x297351=$e(_0x39f4f3,w());if(_0x297351!=null)_0x1155c8=_0x297351;else{if(_0x39f3a6!=null)_0x1155c8=nt(_0x39f4f3,_0x39f3a6);else return[];}if(_0x1155c8=_0x1155c8['withIndex'](_0x10e32e),!_0x1155c8['isEmpty']()&&!_0x1155c8['isLeafNode']()){const _0x1326db=[],_0x5c9ab6=_0x10e32e['getCompare'](),_0x137a89=_0x290a7c?_0x1155c8['getReverseIteratorFrom'](_0x2ad307,_0x10e32e):_0x1155c8['getIteratorFrom'](_0x2ad307,_0x10e32e);let _0x5eb6cc=_0x137a89['getNext']();for(;_0x5eb6cc&&_0x1326db['length']<_0xfdec56;)_0x5c9ab6(_0x5eb6cc,_0x2ad307)!==0x0&&_0x1326db['push'](_0x5eb6cc),_0x5eb6cc=_0x137a89['getNext']();return _0x1326db;}else return[];}function Iu(){return{'visibleWrites':Y['empty'](),'allWrites':[],'lastWriteId':-0x1};}function yn(_0x24a703,_0x32f8cf,_0x37869a,_0x164963){return Vo(_0x24a703['writeTree'],_0x24a703['treePath'],_0x32f8cf,_0x37869a,_0x164963);}function ns(_0x1259b,_0x13ed25){return gu(_0x1259b['writeTree'],_0x1259b['treePath'],_0x13ed25);}function lr(_0x17a6df,_0x144b60,_0x52c4de,_0x27338e){return mu(_0x17a6df['writeTree'],_0x17a6df['treePath'],_0x144b60,_0x52c4de,_0x27338e);}function vn(_0x3829a5,_0x34f156){return vu(_0x3829a5['writeTree'],k(_0x3829a5['treePath'],_0x34f156));}function wu(_0x257433,_0x22450c,_0x57b62,_0x507106,_0x2b2ed5,_0x5c4f0a){return Eu(_0x257433['writeTree'],_0x257433['treePath'],_0x22450c,_0x57b62,_0x507106,_0x2b2ed5,_0x5c4f0a);}function is(_0x5cbd39,_0x1ff29b,_0x4e849c){return yu(_0x5cbd39['writeTree'],_0x5cbd39['treePath'],_0x1ff29b,_0x4e849c);}function Ho(_0x4aee9e,_0x3a98e3){return $o(k(_0x4aee9e['treePath'],_0x3a98e3),_0x4aee9e['writeTree']);}function $o(_0x10459d,_0x846eba){return{'treePath':_0x10459d,'writeTree':_0x846eba};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x3f901d){const _0x6743ac=_0x3f901d['type'],_0x1822e2=_0x3f901d['childName'];f(_0x6743ac==='child_added'||_0x6743ac==='child_changed'||_0x6743ac==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x1822e2!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x45fe72=this['changeMap']['get'](_0x1822e2);if(_0x45fe72){const _0xfb93f1=_0x45fe72['type'];if(_0x6743ac==='child_added'&&_0xfb93f1==='child_removed')this['changeMap']['set'](_0x1822e2,Dt(_0x1822e2,_0x3f901d['snapshotNode'],_0x45fe72['snapshotNode']));else{if(_0x6743ac==='child_removed'&&_0xfb93f1==='child_added')this['changeMap']['delete'](_0x1822e2);else{if(_0x6743ac==='child_removed'&&_0xfb93f1==='child_changed')this['changeMap']['set'](_0x1822e2,Ot(_0x1822e2,_0x45fe72['oldSnap']));else{if(_0x6743ac==='child_changed'&&_0xfb93f1==='child_added')this['changeMap']['set'](_0x1822e2,et(_0x1822e2,_0x3f901d['snapshotNode']));else{if(_0x6743ac==='child_changed'&&_0xfb93f1==='child_changed')this['changeMap']['set'](_0x1822e2,Dt(_0x1822e2,_0x3f901d['snapshotNode'],_0x45fe72['oldSnap']));else throw rt('Illegal\x20combination\x20of\x20changes:\x20'+_0x3f901d+'\x20occurred\x20after\x20'+_0x45fe72);}}}}}else this['changeMap']['set'](_0x1822e2,_0x3f901d);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x141fc5){return null;}['getChildAfterChild'](_0x3a2967,_0x523007,_0x20e613){return null;}}const Go=new Tu();class ss{constructor(_0x3bb8d8,_0xb6b0e1,_0xa04eaf=null){this['writes_']=_0x3bb8d8,this['viewCache_']=_0xb6b0e1,this['optCompleteServerCache_']=_0xa04eaf;}['getCompleteChild'](_0x3f3597){const _0x47e9f4=this['viewCache_']['eventCache'];if(_0x47e9f4['isCompleteForChild'](_0x3f3597))return _0x47e9f4['getNode']()['getImmediateChild'](_0x3f3597);{const _0x459c6c=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return is(this['writes_'],_0x3f3597,_0x459c6c);}}['getChildAfterChild'](_0x4319c5,_0x5741ed,_0x5750e3){const _0x2921c3=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:We(this['viewCache_']),_0x2c168d=wu(this['writes_'],_0x2921c3,_0x5741ed,0x1,_0x5750e3,_0x4319c5);return _0x2c168d['length']===0x0?null:_0x2c168d[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x2e599b){return{'filter':_0x2e599b};}function bu(_0x5ba336,_0x230614){f(_0x230614['eventCache']['getNode']()['isIndexed'](_0x5ba336['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x230614['serverCache']['getNode']()['isIndexed'](_0x5ba336['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x42eb52,_0x254730,_0x5c4bee,_0x3fc146,_0x2cc548){const _0x2ea88d=new Cu();let _0x194c36,_0x9ee42c;if(_0x5c4bee['type']===j['OVERWRITE']){const _0x5980d2=_0x5c4bee;_0x5980d2['source']['fromUser']?_0x194c36=Si(_0x42eb52,_0x254730,_0x5980d2['path'],_0x5980d2['snap'],_0x3fc146,_0x2cc548,_0x2ea88d):(f(_0x5980d2['source']['fromServer'],'Unknown\x20source.'),_0x9ee42c=_0x5980d2['source']['tagged']||_0x254730['serverCache']['isFiltered']()&&!v(_0x5980d2['path']),_0x194c36=En(_0x42eb52,_0x254730,_0x5980d2['path'],_0x5980d2['snap'],_0x3fc146,_0x2cc548,_0x9ee42c,_0x2ea88d));}else{if(_0x5c4bee['type']===j['MERGE']){const _0x35b88e=_0x5c4bee;_0x35b88e['source']['fromUser']?_0x194c36=ku(_0x42eb52,_0x254730,_0x35b88e['path'],_0x35b88e['children'],_0x3fc146,_0x2cc548,_0x2ea88d):(f(_0x35b88e['source']['fromServer'],'Unknown\x20source.'),_0x9ee42c=_0x35b88e['source']['tagged']||_0x254730['serverCache']['isFiltered'](),_0x194c36=bi(_0x42eb52,_0x254730,_0x35b88e['path'],_0x35b88e['children'],_0x3fc146,_0x2cc548,_0x9ee42c,_0x2ea88d));}else{if(_0x5c4bee['type']===j['ACK_USER_WRITE']){const _0x1c16d9=_0x5c4bee;_0x1c16d9['revert']?_0x194c36=Ou(_0x42eb52,_0x254730,_0x1c16d9['path'],_0x3fc146,_0x2cc548,_0x2ea88d):_0x194c36=Nu(_0x42eb52,_0x254730,_0x1c16d9['path'],_0x1c16d9['affectedTree'],_0x3fc146,_0x2cc548,_0x2ea88d);}else{if(_0x5c4bee['type']===j['LISTEN_COMPLETE'])_0x194c36=Pu(_0x42eb52,_0x254730,_0x5c4bee['path'],_0x3fc146,_0x2ea88d);else throw rt('Unknown\x20operation\x20type:\x20'+_0x5c4bee['type']);}}}const _0x271468=_0x2ea88d['getChanges']();return Au(_0x254730,_0x194c36,_0x271468),{'viewCache':_0x194c36,'changes':_0x271468};}function Au(_0x2a5320,_0x3c7631,_0x3b0d58){const _0x143dad=_0x3c7631['eventCache'];if(_0x143dad['isFullyInitialized']()){const _0xf7b32b=_0x143dad['getNode']()['isLeafNode']()||_0x143dad['getNode']()['isEmpty'](),_0x416a84=mn(_0x2a5320);(_0x3b0d58['length']>0x0||!_0x2a5320['eventCache']['isFullyInitialized']()||_0xf7b32b&&!_0x143dad['getNode']()['equals'](_0x416a84)||!_0x143dad['getNode']()['getPriority']()['equals'](_0x416a84['getPriority']()))&&_0x3b0d58['push'](Lo(mn(_0x3c7631)));}}function qo(_0x56ac77,_0x1ac548,_0x56ae99,_0x6eda59,_0x4817df,_0x32ea5d){const _0x27d204=_0x1ac548['eventCache'];if(vn(_0x6eda59,_0x56ae99)!=null)return _0x1ac548;{let _0x50e51e,_0x5f4ee7;if(v(_0x56ae99)){if(f(_0x1ac548['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x1ac548['serverCache']['isFiltered']()){const _0x4cc327=We(_0x1ac548),_0x4466ec=_0x4cc327 instanceof g?_0x4cc327:g['EMPTY_NODE'],_0x197bc2=ns(_0x6eda59,_0x4466ec);_0x50e51e=_0x56ac77['filter']['updateFullNode'](_0x1ac548['eventCache']['getNode'](),_0x197bc2,_0x32ea5d);}else{const _0x30a814=yn(_0x6eda59,We(_0x1ac548));_0x50e51e=_0x56ac77['filter']['updateFullNode'](_0x1ac548['eventCache']['getNode'](),_0x30a814,_0x32ea5d);}}else{const _0x3822a1=y(_0x56ae99);if(_0x3822a1==='.priority'){f(we(_0x56ae99)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x52cd4f=_0x27d204['getNode']();_0x5f4ee7=_0x1ac548['serverCache']['getNode']();const _0x48db36=lr(_0x6eda59,_0x56ae99,_0x52cd4f,_0x5f4ee7);_0x48db36!=null?_0x50e51e=_0x56ac77['filter']['updatePriority'](_0x52cd4f,_0x48db36):_0x50e51e=_0x27d204['getNode']();}else{const _0x5d6661=b(_0x56ae99);let _0x251271;if(_0x27d204['isCompleteForChild'](_0x3822a1)){_0x5f4ee7=_0x1ac548['serverCache']['getNode']();const _0xebe3fc=lr(_0x6eda59,_0x56ae99,_0x27d204['getNode'](),_0x5f4ee7);_0xebe3fc!=null?_0x251271=_0x27d204['getNode']()['getImmediateChild'](_0x3822a1)['updateChild'](_0x5d6661,_0xebe3fc):_0x251271=_0x27d204['getNode']()['getImmediateChild'](_0x3822a1);}else _0x251271=is(_0x6eda59,_0x3822a1,_0x1ac548['serverCache']);_0x251271!=null?_0x50e51e=_0x56ac77['filter']['updateChild'](_0x27d204['getNode'](),_0x3822a1,_0x251271,_0x5d6661,_0x4817df,_0x32ea5d):_0x50e51e=_0x27d204['getNode']();}}return Tt(_0x1ac548,_0x50e51e,_0x27d204['isFullyInitialized']()||v(_0x56ae99),_0x56ac77['filter']['filtersNodes']());}}function En(_0x2d8c68,_0x599871,_0x477c8d,_0x550f13,_0x1f01f5,_0x351159,_0x16fb53,_0x33f9fc){const _0x47c0e3=_0x599871['serverCache'];let _0x42d71d;const _0x3fe439=_0x16fb53?_0x2d8c68['filter']:_0x2d8c68['filter']['getIndexedFilter']();if(v(_0x477c8d))_0x42d71d=_0x3fe439['updateFullNode'](_0x47c0e3['getNode'](),_0x550f13,null);else{if(_0x3fe439['filtersNodes']()&&!_0x47c0e3['isFiltered']()){const _0xb5b0de=_0x47c0e3['getNode']()['updateChild'](_0x477c8d,_0x550f13);_0x42d71d=_0x3fe439['updateFullNode'](_0x47c0e3['getNode'](),_0xb5b0de,null);}else{const _0x42a7f1=y(_0x477c8d);if(!_0x47c0e3['isCompleteForPath'](_0x477c8d)&&we(_0x477c8d)>0x1)return _0x599871;const _0x4124bc=b(_0x477c8d),_0x40072e=_0x47c0e3['getNode']()['getImmediateChild'](_0x42a7f1)['updateChild'](_0x4124bc,_0x550f13);_0x42a7f1==='.priority'?_0x42d71d=_0x3fe439['updatePriority'](_0x47c0e3['getNode'](),_0x40072e):_0x42d71d=_0x3fe439['updateChild'](_0x47c0e3['getNode'](),_0x42a7f1,_0x40072e,_0x4124bc,Go,null);}}const _0x5a5647=Uo(_0x599871,_0x42d71d,_0x47c0e3['isFullyInitialized']()||v(_0x477c8d),_0x3fe439['filtersNodes']()),_0x5d97e9=new ss(_0x1f01f5,_0x5a5647,_0x351159);return qo(_0x2d8c68,_0x5a5647,_0x477c8d,_0x1f01f5,_0x5d97e9,_0x33f9fc);}function Si(_0x5230d7,_0x26ff95,_0x463816,_0x13b77b,_0x477b98,_0x41959e,_0x2c40e6){const _0x309e88=_0x26ff95['eventCache'];let _0x5c584d,_0x2d28a7;const _0x1aee32=new ss(_0x477b98,_0x26ff95,_0x41959e);if(v(_0x463816))_0x2d28a7=_0x5230d7['filter']['updateFullNode'](_0x26ff95['eventCache']['getNode'](),_0x13b77b,_0x2c40e6),_0x5c584d=Tt(_0x26ff95,_0x2d28a7,!0x0,_0x5230d7['filter']['filtersNodes']());else{const _0x1dcaa1=y(_0x463816);if(_0x1dcaa1==='.priority')_0x2d28a7=_0x5230d7['filter']['updatePriority'](_0x26ff95['eventCache']['getNode'](),_0x13b77b),_0x5c584d=Tt(_0x26ff95,_0x2d28a7,_0x309e88['isFullyInitialized'](),_0x309e88['isFiltered']());else{const _0x55ed8f=b(_0x463816),_0x177d0f=_0x309e88['getNode']()['getImmediateChild'](_0x1dcaa1);let _0x344594;if(v(_0x55ed8f))_0x344594=_0x13b77b;else{const _0x4e8357=_0x1aee32['getCompleteChild'](_0x1dcaa1);_0x4e8357!=null?zi(_0x55ed8f)==='.priority'&&_0x4e8357['getChild'](Ro(_0x55ed8f))['isEmpty']()?_0x344594=_0x4e8357:_0x344594=_0x4e8357['updateChild'](_0x55ed8f,_0x13b77b):_0x344594=g['EMPTY_NODE'];}if(_0x177d0f['equals'](_0x344594))_0x5c584d=_0x26ff95;else{const _0x4a49a0=_0x5230d7['filter']['updateChild'](_0x309e88['getNode'](),_0x1dcaa1,_0x344594,_0x55ed8f,_0x1aee32,_0x2c40e6);_0x5c584d=Tt(_0x26ff95,_0x4a49a0,_0x309e88['isFullyInitialized'](),_0x5230d7['filter']['filtersNodes']());}}}return _0x5c584d;}function hr(_0x4d7633,_0x5e6979){return _0x4d7633['eventCache']['isCompleteForChild'](_0x5e6979);}function ku(_0x41096f,_0x160f9f,_0x417995,_0x4a7245,_0x3134c1,_0x370d0f,_0x4b7f13){let _0x580a95=_0x160f9f;return _0x4a7245['foreach']((_0x2f20c6,_0x1d101b)=>{const _0xddbc1d=k(_0x417995,_0x2f20c6);hr(_0x160f9f,y(_0xddbc1d))&&(_0x580a95=Si(_0x41096f,_0x580a95,_0xddbc1d,_0x1d101b,_0x3134c1,_0x370d0f,_0x4b7f13));}),_0x4a7245['foreach']((_0x4f4992,_0x1a6c3d)=>{const _0x4b0040=k(_0x417995,_0x4f4992);hr(_0x160f9f,y(_0x4b0040))||(_0x580a95=Si(_0x41096f,_0x580a95,_0x4b0040,_0x1a6c3d,_0x3134c1,_0x370d0f,_0x4b7f13));}),_0x580a95;}function ur(_0x185d83,_0xc77dea,_0x5cba58){return _0x5cba58['foreach']((_0x2f4d46,_0x589256)=>{_0xc77dea=_0xc77dea['updateChild'](_0x2f4d46,_0x589256);}),_0xc77dea;}function bi(_0x3082a5,_0x3b184b,_0x4bc57e,_0x5b7aa4,_0x50ce1c,_0x391975,_0x21f197,_0xfde77f){if(_0x3b184b['serverCache']['getNode']()['isEmpty']()&&!_0x3b184b['serverCache']['isFullyInitialized']())return _0x3b184b;let _0x452bfd=_0x3b184b,_0x56187b;v(_0x4bc57e)?_0x56187b=_0x5b7aa4:_0x56187b=new S(null)['setTree'](_0x4bc57e,_0x5b7aa4);const _0x40b86d=_0x3b184b['serverCache']['getNode']();return _0x56187b['children']['inorderTraversal']((_0x1e383,_0x239a90)=>{if(_0x40b86d['hasChild'](_0x1e383)){const _0x4af46e=_0x3b184b['serverCache']['getNode']()['getImmediateChild'](_0x1e383),_0x50de80=ur(_0x3082a5,_0x4af46e,_0x239a90);_0x452bfd=En(_0x3082a5,_0x452bfd,new C(_0x1e383),_0x50de80,_0x50ce1c,_0x391975,_0x21f197,_0xfde77f);}}),_0x56187b['children']['inorderTraversal']((_0x2ee2f6,_0x3be2c6)=>{const _0x2be8d1=!_0x3b184b['serverCache']['isCompleteForChild'](_0x2ee2f6)&&_0x3be2c6['value']===null;if(!_0x40b86d['hasChild'](_0x2ee2f6)&&!_0x2be8d1){const _0x3eb42b=_0x3b184b['serverCache']['getNode']()['getImmediateChild'](_0x2ee2f6),_0x1f9dc2=ur(_0x3082a5,_0x3eb42b,_0x3be2c6);_0x452bfd=En(_0x3082a5,_0x452bfd,new C(_0x2ee2f6),_0x1f9dc2,_0x50ce1c,_0x391975,_0x21f197,_0xfde77f);}}),_0x452bfd;}function Nu(_0x204fde,_0x19d341,_0x4b33ab,_0x5a1847,_0x40890d,_0x37c5c4,_0x441a2c){if(vn(_0x40890d,_0x4b33ab)!=null)return _0x19d341;const _0x3de0c9=_0x19d341['serverCache']['isFiltered'](),_0x5c5b1d=_0x19d341['serverCache'];if(_0x5a1847['value']!=null){if(v(_0x4b33ab)&&_0x5c5b1d['isFullyInitialized']()||_0x5c5b1d['isCompleteForPath'](_0x4b33ab))return En(_0x204fde,_0x19d341,_0x4b33ab,_0x5c5b1d['getNode']()['getChild'](_0x4b33ab),_0x40890d,_0x37c5c4,_0x3de0c9,_0x441a2c);if(v(_0x4b33ab)){let _0x9b610a=new S(null);return _0x5c5b1d['getNode']()['forEachChild'](ye,(_0x506241,_0x28fb9c)=>{_0x9b610a=_0x9b610a['set'](new C(_0x506241),_0x28fb9c);}),bi(_0x204fde,_0x19d341,_0x4b33ab,_0x9b610a,_0x40890d,_0x37c5c4,_0x3de0c9,_0x441a2c);}else return _0x19d341;}else{let _0x3d8ba7=new S(null);return _0x5a1847['foreach']((_0x160f54,_0x48abe0)=>{const _0x15a36c=k(_0x4b33ab,_0x160f54);_0x5c5b1d['isCompleteForPath'](_0x15a36c)&&(_0x3d8ba7=_0x3d8ba7['set'](_0x160f54,_0x5c5b1d['getNode']()['getChild'](_0x15a36c)));}),bi(_0x204fde,_0x19d341,_0x4b33ab,_0x3d8ba7,_0x40890d,_0x37c5c4,_0x3de0c9,_0x441a2c);}}function Pu(_0xf3fd67,_0x26a046,_0x4c8f2b,_0x81e71c,_0x43f627){const _0x238b55=_0x26a046['serverCache'],_0xd24522=Uo(_0x26a046,_0x238b55['getNode'](),_0x238b55['isFullyInitialized']()||v(_0x4c8f2b),_0x238b55['isFiltered']());return qo(_0xf3fd67,_0xd24522,_0x4c8f2b,_0x81e71c,Go,_0x43f627);}function Ou(_0xa53d87,_0x25d7c6,_0x4c47a8,_0x5a4197,_0x25d635,_0x5e5850){let _0x30cbf1;if(vn(_0x5a4197,_0x4c47a8)!=null)return _0x25d7c6;{const _0x3a3403=new ss(_0x5a4197,_0x25d7c6,_0x25d635),_0x5797c3=_0x25d7c6['eventCache']['getNode']();let _0x5ecb3a;if(v(_0x4c47a8)||y(_0x4c47a8)==='.priority'){let _0x5dd528;if(_0x25d7c6['serverCache']['isFullyInitialized']())_0x5dd528=yn(_0x5a4197,We(_0x25d7c6));else{const _0x466130=_0x25d7c6['serverCache']['getNode']();f(_0x466130 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x5dd528=ns(_0x5a4197,_0x466130);}_0x5dd528=_0x5dd528,_0x5ecb3a=_0xa53d87['filter']['updateFullNode'](_0x5797c3,_0x5dd528,_0x5e5850);}else{const _0x2cb856=y(_0x4c47a8);let _0x2c8f4c=is(_0x5a4197,_0x2cb856,_0x25d7c6['serverCache']);_0x2c8f4c==null&&_0x25d7c6['serverCache']['isCompleteForChild'](_0x2cb856)&&(_0x2c8f4c=_0x5797c3['getImmediateChild'](_0x2cb856)),_0x2c8f4c!=null?_0x5ecb3a=_0xa53d87['filter']['updateChild'](_0x5797c3,_0x2cb856,_0x2c8f4c,b(_0x4c47a8),_0x3a3403,_0x5e5850):_0x25d7c6['eventCache']['getNode']()['hasChild'](_0x2cb856)?_0x5ecb3a=_0xa53d87['filter']['updateChild'](_0x5797c3,_0x2cb856,g['EMPTY_NODE'],b(_0x4c47a8),_0x3a3403,_0x5e5850):_0x5ecb3a=_0x5797c3,_0x5ecb3a['isEmpty']()&&_0x25d7c6['serverCache']['isFullyInitialized']()&&(_0x30cbf1=yn(_0x5a4197,We(_0x25d7c6)),_0x30cbf1['isLeafNode']()&&(_0x5ecb3a=_0xa53d87['filter']['updateFullNode'](_0x5ecb3a,_0x30cbf1,_0x5e5850)));}return _0x30cbf1=_0x25d7c6['serverCache']['isFullyInitialized']()||vn(_0x5a4197,w())!=null,Tt(_0x25d7c6,_0x5ecb3a,_0x30cbf1,_0xa53d87['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x3165f3,_0x3eeeee){this['query_']=_0x3165f3,this['eventRegistrations_']=[];const _0x1c795c=this['query_']['_queryParams'],_0x4814f3=new Ji(_0x1c795c['getIndex']()),_0x2ccc3b=Kh(_0x1c795c);this['processor_']=Su(_0x2ccc3b);const _0x3de442=_0x3eeeee['serverCache'],_0xfa378e=_0x3eeeee['eventCache'],_0x483573=_0x4814f3['updateFullNode'](g['EMPTY_NODE'],_0x3de442['getNode'](),null),_0x5c0246=_0x2ccc3b['updateFullNode'](g['EMPTY_NODE'],_0xfa378e['getNode'](),null),_0xb2f6ce=new Ce(_0x483573,_0x3de442['isFullyInitialized'](),_0x4814f3['filtersNodes']()),_0x16dc72=new Ce(_0x5c0246,_0xfa378e['isFullyInitialized'](),_0x2ccc3b['filtersNodes']());this['viewCache_']=Mn(_0x16dc72,_0xb2f6ce),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x481623){return _0x481623['viewCache_']['serverCache']['getNode']();}function Lu(_0x4d9179){return mn(_0x4d9179['viewCache_']);}function xu(_0x31696d,_0x2f2058){const _0x591f44=We(_0x31696d['viewCache_']);return _0x591f44&&(_0x31696d['query']['_queryParams']['loadsAllData']()||!v(_0x2f2058)&&!_0x591f44['getImmediateChild'](y(_0x2f2058))['isEmpty']())?_0x591f44['getChild'](_0x2f2058):null;}function dr(_0x5d69b1){return _0x5d69b1['eventRegistrations_']['length']===0x0;}function Fu(_0x1c407f,_0x5b4988){_0x1c407f['eventRegistrations_']['push'](_0x5b4988);}function fr(_0x2ca074,_0xb51210,_0xe2a8c2){const _0x3962af=[];if(_0xe2a8c2){f(_0xb51210==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x3543b8=_0x2ca074['query']['_path'];_0x2ca074['eventRegistrations_']['forEach'](_0x405608=>{const _0x42ae96=_0x405608['createCancelEvent'](_0xe2a8c2,_0x3543b8);_0x42ae96&&_0x3962af['push'](_0x42ae96);});}if(_0xb51210){let _0x391675=[];for(let _0x4fede7=0x0;_0x4fede7<_0x2ca074['eventRegistrations_']['length'];++_0x4fede7){const _0x36b2e8=_0x2ca074['eventRegistrations_'][_0x4fede7];if(!_0x36b2e8['matches'](_0xb51210))_0x391675['push'](_0x36b2e8);else{if(_0xb51210['hasAnyCallback']()){_0x391675=_0x391675['concat'](_0x2ca074['eventRegistrations_']['slice'](_0x4fede7+0x1));break;}}}_0x2ca074['eventRegistrations_']=_0x391675;}else _0x2ca074['eventRegistrations_']=[];return _0x3962af;}function pr(_0x2e4214,_0x2fefe3,_0x1e0d07,_0x5ddb25){_0x2fefe3['type']===j['MERGE']&&_0x2fefe3['source']['queryId']!==null&&(f(We(_0x2e4214['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(mn(_0x2e4214['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x1fdb21=_0x2e4214['viewCache_'],_0x1cd910=Ru(_0x2e4214['processor_'],_0x1fdb21,_0x2fefe3,_0x1e0d07,_0x5ddb25);return bu(_0x2e4214['processor_'],_0x1cd910['viewCache']),f(_0x1cd910['viewCache']['serverCache']['isFullyInitialized']()||!_0x1fdb21['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x2e4214['viewCache_']=_0x1cd910['viewCache'],zo(_0x2e4214,_0x1cd910['changes'],_0x1cd910['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x3e0c6e,_0x576d63){const _0x99aee0=_0x3e0c6e['viewCache_']['eventCache'],_0x50bd23=[];return _0x99aee0['getNode']()['isLeafNode']()||_0x99aee0['getNode']()['forEachChild'](R,(_0xc82df8,_0x4e8215)=>{_0x50bd23['push'](et(_0xc82df8,_0x4e8215));}),_0x99aee0['isFullyInitialized']()&&_0x50bd23['push'](Lo(_0x99aee0['getNode']())),zo(_0x3e0c6e,_0x50bd23,_0x99aee0['getNode'](),_0x576d63);}function zo(_0x3b3ce0,_0xd181f3,_0x37684b,_0x1e0b62){const _0x2b7452=_0x1e0b62?[_0x1e0b62]:_0x3b3ce0['eventRegistrations_'];return ru(_0x3b3ce0['eventGenerator_'],_0xd181f3,_0x37684b,_0x2b7452);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;class jo{constructor(){this['views']=new Map();}}function Wu(_0x47d903){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x47d903;}function Bu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}function Vu(_0x15dc75){return _0x15dc75['views']['size']===0x0;}function rs(_0x4f091d,_0x208daf,_0x3a4181,_0x11c439){const _0x1559b7=_0x208daf['source']['queryId'];if(_0x1559b7!==null){const _0x2e589e=_0x4f091d['views']['get'](_0x1559b7);return f(_0x2e589e!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),pr(_0x2e589e,_0x208daf,_0x3a4181,_0x11c439);}else{let _0x7c02e2=[];for(const _0xdf6236 of _0x4f091d['views']['values']())_0x7c02e2=_0x7c02e2['concat'](pr(_0xdf6236,_0x208daf,_0x3a4181,_0x11c439));return _0x7c02e2;}}function Ko(_0x461c1d,_0x2b236f,_0x375eea,_0x5c4fdf,_0x36876f){const _0x432af3=_0x2b236f['_queryIdentifier'],_0x2c2484=_0x461c1d['views']['get'](_0x432af3);if(!_0x2c2484){let _0x16ccf3=yn(_0x375eea,_0x36876f?_0x5c4fdf:null),_0x3e488a=!0x1;_0x16ccf3?_0x3e488a=!0x0:_0x5c4fdf instanceof g?(_0x16ccf3=ns(_0x375eea,_0x5c4fdf),_0x3e488a=!0x1):(_0x16ccf3=g['EMPTY_NODE'],_0x3e488a=!0x1);const _0x5734cd=Mn(new Ce(_0x16ccf3,_0x3e488a,!0x1),new Ce(_0x5c4fdf,_0x36876f,!0x1));return new Du(_0x2b236f,_0x5734cd);}return _0x2c2484;}function Hu(_0x19d7e3,_0x2d89d9,_0x4baa1a,_0x49d429,_0x2cbd31,_0x472010){const _0x54340d=Ko(_0x19d7e3,_0x2d89d9,_0x49d429,_0x2cbd31,_0x472010);return _0x19d7e3['views']['has'](_0x2d89d9['_queryIdentifier'])||_0x19d7e3['views']['set'](_0x2d89d9['_queryIdentifier'],_0x54340d),Fu(_0x54340d,_0x4baa1a),Uu(_0x54340d,_0x4baa1a);}function $u(_0x1fe2c9,_0x37625d,_0x10aaf5,_0x3f2e45){const _0x159f84=_0x37625d['_queryIdentifier'],_0x1d3de1=[];let _0x56f962=[];const _0x18420f=Te(_0x1fe2c9);if(_0x159f84==='default'){for(const [_0x261da9,_0x517e97]of _0x1fe2c9['views']['entries']())_0x56f962=_0x56f962['concat'](fr(_0x517e97,_0x10aaf5,_0x3f2e45)),dr(_0x517e97)&&(_0x1fe2c9['views']['delete'](_0x261da9),_0x517e97['query']['_queryParams']['loadsAllData']()||_0x1d3de1['push'](_0x517e97['query']));}else{const _0x92e705=_0x1fe2c9['views']['get'](_0x159f84);_0x92e705&&(_0x56f962=_0x56f962['concat'](fr(_0x92e705,_0x10aaf5,_0x3f2e45)),dr(_0x92e705)&&(_0x1fe2c9['views']['delete'](_0x159f84),_0x92e705['query']['_queryParams']['loadsAllData']()||_0x1d3de1['push'](_0x92e705['query'])));}return _0x18420f&&!Te(_0x1fe2c9)&&_0x1d3de1['push'](new(Bu())(_0x37625d['_repo'],_0x37625d['_path'])),{'removed':_0x1d3de1,'events':_0x56f962};}function Yo(_0x28953a){const _0x36442d=[];for(const _0x3704f9 of _0x28953a['views']['values']())_0x3704f9['query']['_queryParams']['loadsAllData']()||_0x36442d['push'](_0x3704f9);return _0x36442d;}function Ee(_0x351432,_0x5b7e7b){let _0x354933=null;for(const _0x1b6fae of _0x351432['views']['values']())_0x354933=_0x354933||xu(_0x1b6fae,_0x5b7e7b);return _0x354933;}function Qo(_0x582a76,_0x35a893){if(_0x35a893['_queryParams']['loadsAllData']())return xn(_0x582a76);{const _0x2d220f=_0x35a893['_queryIdentifier'];return _0x582a76['views']['get'](_0x2d220f);}}function Jo(_0x17ba30,_0x5a9042){return Qo(_0x17ba30,_0x5a9042)!=null;}function Te(_0x485334){return xn(_0x485334)!=null;}function xn(_0x4eb79e){for(const _0x542e66 of _0x4eb79e['views']['values']())if(_0x542e66['query']['_queryParams']['loadsAllData']())return _0x542e66;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let wn;function Gu(_0x1f58f8){f(!wn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),wn=_0x1f58f8;}function qu(){return f(wn,'Reference.ts\x20has\x20not\x20been\x20loaded'),wn;}let zu=0x1;class _r{constructor(_0x2a7887){this['listenProvider_']=_0x2a7887,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function os(_0x4b9c1b,_0x190ed0,_0x10cc23,_0x2f7859,_0x3f3135){return lu(_0x4b9c1b['pendingWriteTree_'],_0x190ed0,_0x10cc23,_0x2f7859,_0x3f3135),_0x3f3135?ut(_0x4b9c1b,new Ue(Zi(),_0x190ed0,_0x10cc23)):[];}function ju(_0x1668e2,_0x173a25,_0x1f79a8,_0x38be10){hu(_0x1668e2['pendingWriteTree_'],_0x173a25,_0x1f79a8,_0x38be10);const _0x5ac9b6=S['fromObject'](_0x1f79a8);return ut(_0x1668e2,new tt(Zi(),_0x173a25,_0x5ac9b6));}function pe(_0x662b1f,_0x3e8199,_0x425239=!0x1){const _0x16dc35=uu(_0x662b1f['pendingWriteTree_'],_0x3e8199);if(du(_0x662b1f['pendingWriteTree_'],_0x3e8199)){let _0x8a984f=new S(null);return _0x16dc35['snap']!=null?_0x8a984f=_0x8a984f['set'](w(),!0x0):x(_0x16dc35['children'],_0xe74d7a=>{_0x8a984f=_0x8a984f['set'](new C(_0xe74d7a),!0x0);}),ut(_0x662b1f,new gn(_0x16dc35['path'],_0x8a984f,_0x425239));}else return[];}function Gt(_0xe92020,_0x555c53,_0xb42578){return ut(_0xe92020,new Ue(es(),_0x555c53,_0xb42578));}function Ku(_0x10b1c7,_0x2f8948,_0x9ef2fb){const _0x5e7d18=S['fromObject'](_0x9ef2fb);return ut(_0x10b1c7,new tt(es(),_0x2f8948,_0x5e7d18));}function Yu(_0x4babe3,_0x584701){return ut(_0x4babe3,new Lt(es(),_0x584701));}function Qu(_0x24aec0,_0x243873,_0x5d8f98){const _0x40d177=as(_0x24aec0,_0x5d8f98);if(_0x40d177){const _0x87aeca=cs(_0x40d177),_0x4e1db0=_0x87aeca['path'],_0x286fdd=_0x87aeca['queryId'],_0xc4d96a=F(_0x4e1db0,_0x243873),_0x4d3df8=new Lt(ts(_0x286fdd),_0xc4d96a);return ls(_0x24aec0,_0x4e1db0,_0x4d3df8);}else return[];}function Cn(_0x2728a7,_0x2b192b,_0x18984f,_0x477a46,_0x279dda=!0x1){const _0xe93fa1=_0x2b192b['_path'],_0x1b3346=_0x2728a7['syncPointTree_']['get'](_0xe93fa1);let _0x270ca7=[];if(_0x1b3346&&(_0x2b192b['_queryIdentifier']==='default'||Jo(_0x1b3346,_0x2b192b))){const _0x3ccafc=$u(_0x1b3346,_0x2b192b,_0x18984f,_0x477a46);Vu(_0x1b3346)&&(_0x2728a7['syncPointTree_']=_0x2728a7['syncPointTree_']['remove'](_0xe93fa1));const _0x185b03=_0x3ccafc['removed'];if(_0x270ca7=_0x3ccafc['events'],!_0x279dda){const _0x4db460=_0x185b03['findIndex'](_0x1e31f5=>_0x1e31f5['_queryParams']['loadsAllData']())!==-0x1,_0x4b79a2=_0x2728a7['syncPointTree_']['findOnPath'](_0xe93fa1,(_0x280bde,_0x2b869c)=>Te(_0x2b869c));if(_0x4db460&&!_0x4b79a2){const _0x4e2a38=_0x2728a7['syncPointTree_']['subtree'](_0xe93fa1);if(!_0x4e2a38['isEmpty']()){const _0x3bec37=Zu(_0x4e2a38);for(let _0x629a9e=0x0;_0x629a9e<_0x3bec37['length'];++_0x629a9e){const _0x5072ce=_0x3bec37[_0x629a9e],_0x487b84=_0x5072ce['query'],_0x569230=ta(_0x2728a7,_0x5072ce);_0x2728a7['listenProvider_']['startListening'](bt(_0x487b84),xt(_0x2728a7,_0x487b84),_0x569230['hashFn'],_0x569230['onComplete']);}}}!_0x4b79a2&&_0x185b03['length']>0x0&&!_0x477a46&&(_0x4db460?_0x2728a7['listenProvider_']['stopListening'](bt(_0x2b192b),null):_0x185b03['forEach'](_0x556d0d=>{const _0x2eb11d=_0x2728a7['queryToTagMap']['get'](Un(_0x556d0d));_0x2728a7['listenProvider_']['stopListening'](bt(_0x556d0d),_0x2eb11d);}));}ed(_0x2728a7,_0x185b03);}return _0x270ca7;}function Xo(_0x44ef18,_0x3fbc7b,_0xbe1b67,_0x3a1c35){const _0x3baadf=as(_0x44ef18,_0x3a1c35);if(_0x3baadf!=null){const _0x11b51c=cs(_0x3baadf),_0x44cf2e=_0x11b51c['path'],_0x4578d0=_0x11b51c['queryId'],_0x4d047f=F(_0x44cf2e,_0x3fbc7b),_0xf5ea86=new Ue(ts(_0x4578d0),_0x4d047f,_0xbe1b67);return ls(_0x44ef18,_0x44cf2e,_0xf5ea86);}else return[];}function Ju(_0x58d916,_0x1df179,_0x568923,_0x58a448){const _0x28e877=as(_0x58d916,_0x58a448);if(_0x28e877){const _0x2c3f0b=cs(_0x28e877),_0x1a03a8=_0x2c3f0b['path'],_0x32bb9e=_0x2c3f0b['queryId'],_0x5e3600=F(_0x1a03a8,_0x1df179),_0x151179=S['fromObject'](_0x568923),_0x4d7704=new tt(ts(_0x32bb9e),_0x5e3600,_0x151179);return ls(_0x58d916,_0x1a03a8,_0x4d7704);}else return[];}function Ri(_0x3819d3,_0xc1cfc0,_0x1c5e86,_0x39061e=!0x1){const _0x45d6ed=_0xc1cfc0['_path'];let _0x24b43a=null,_0x256bdd=!0x1;_0x3819d3['syncPointTree_']['foreachOnPath'](_0x45d6ed,(_0x3ed536,_0x1b833c)=>{const _0x27fc9a=F(_0x3ed536,_0x45d6ed);_0x24b43a=_0x24b43a||Ee(_0x1b833c,_0x27fc9a),_0x256bdd=_0x256bdd||Te(_0x1b833c);});let _0x38766b=_0x3819d3['syncPointTree_']['get'](_0x45d6ed);_0x38766b?(_0x256bdd=_0x256bdd||Te(_0x38766b),_0x24b43a=_0x24b43a||Ee(_0x38766b,w())):(_0x38766b=new jo(),_0x3819d3['syncPointTree_']=_0x3819d3['syncPointTree_']['set'](_0x45d6ed,_0x38766b));let _0x37e4e0;_0x24b43a!=null?_0x37e4e0=!0x0:(_0x37e4e0=!0x1,_0x24b43a=g['EMPTY_NODE'],_0x3819d3['syncPointTree_']['subtree'](_0x45d6ed)['foreachChild']((_0x3b3b77,_0x1aac3c)=>{const _0x16aa32=Ee(_0x1aac3c,w());_0x16aa32&&(_0x24b43a=_0x24b43a['updateImmediateChild'](_0x3b3b77,_0x16aa32));}));const _0x2c5f6e=Jo(_0x38766b,_0xc1cfc0);if(!_0x2c5f6e&&!_0xc1cfc0['_queryParams']['loadsAllData']()){const _0x27060c=Un(_0xc1cfc0);f(!_0x3819d3['queryToTagMap']['has'](_0x27060c),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x4c012c=td();_0x3819d3['queryToTagMap']['set'](_0x27060c,_0x4c012c),_0x3819d3['tagToQueryMap']['set'](_0x4c012c,_0x27060c);}const _0x5b7ed6=Ln(_0x3819d3['pendingWriteTree_'],_0x45d6ed);let _0x50155f=Hu(_0x38766b,_0xc1cfc0,_0x1c5e86,_0x5b7ed6,_0x24b43a,_0x37e4e0);if(!_0x2c5f6e&&!_0x256bdd&&!_0x39061e){const _0x4ad96b=Qo(_0x38766b,_0xc1cfc0);_0x50155f=_0x50155f['concat'](nd(_0x3819d3,_0xc1cfc0,_0x4ad96b));}return _0x50155f;}function Fn(_0x23b777,_0x92f0c,_0x3b7586){const _0x578f8b=_0x23b777['pendingWriteTree_'],_0x137885=_0x23b777['syncPointTree_']['findOnPath'](_0x92f0c,(_0x3a2166,_0x5ec966)=>{const _0x505a10=F(_0x3a2166,_0x92f0c),_0x16ecce=Ee(_0x5ec966,_0x505a10);if(_0x16ecce)return _0x16ecce;});return Vo(_0x578f8b,_0x92f0c,_0x137885,_0x3b7586,!0x0);}function Xu(_0x5c0ff3,_0x19b5ad){const _0xaa8823=_0x19b5ad['_path'];let _0x2bbc51=null;_0x5c0ff3['syncPointTree_']['foreachOnPath'](_0xaa8823,(_0x169baa,_0x136ef8)=>{const _0x4e3d05=F(_0x169baa,_0xaa8823);_0x2bbc51=_0x2bbc51||Ee(_0x136ef8,_0x4e3d05);});let _0x3f8bdb=_0x5c0ff3['syncPointTree_']['get'](_0xaa8823);_0x3f8bdb?_0x2bbc51=_0x2bbc51||Ee(_0x3f8bdb,w()):(_0x3f8bdb=new jo(),_0x5c0ff3['syncPointTree_']=_0x5c0ff3['syncPointTree_']['set'](_0xaa8823,_0x3f8bdb));const _0x430ae5=_0x2bbc51!=null,_0x572d6d=_0x430ae5?new Ce(_0x2bbc51,!0x0,!0x1):null,_0x33ab11=Ln(_0x5c0ff3['pendingWriteTree_'],_0x19b5ad['_path']),_0x4d866b=Ko(_0x3f8bdb,_0x19b5ad,_0x33ab11,_0x430ae5?_0x572d6d['getNode']():g['EMPTY_NODE'],_0x430ae5);return Lu(_0x4d866b);}function ut(_0x3aba08,_0x4c78aa){return Zo(_0x4c78aa,_0x3aba08['syncPointTree_'],null,Ln(_0x3aba08['pendingWriteTree_'],w()));}function Zo(_0x48580f,_0x27f673,_0x14cb85,_0x2d2936){if(v(_0x48580f['path']))return ea(_0x48580f,_0x27f673,_0x14cb85,_0x2d2936);{const _0x50450d=_0x27f673['get'](w());_0x14cb85==null&&_0x50450d!=null&&(_0x14cb85=Ee(_0x50450d,w()));let _0x544c47=[];const _0x57d8d4=y(_0x48580f['path']),_0x29d71c=_0x48580f['operationForChild'](_0x57d8d4),_0x28b370=_0x27f673['children']['get'](_0x57d8d4);if(_0x28b370&&_0x29d71c){const _0x3b3e39=_0x14cb85?_0x14cb85['getImmediateChild'](_0x57d8d4):null,_0x23ae03=Ho(_0x2d2936,_0x57d8d4);_0x544c47=_0x544c47['concat'](Zo(_0x29d71c,_0x28b370,_0x3b3e39,_0x23ae03));}return _0x50450d&&(_0x544c47=_0x544c47['concat'](rs(_0x50450d,_0x48580f,_0x2d2936,_0x14cb85))),_0x544c47;}}function ea(_0x35b257,_0x32cad2,_0x1accfe,_0x412fad){const _0x34de82=_0x32cad2['get'](w());_0x1accfe==null&&_0x34de82!=null&&(_0x1accfe=Ee(_0x34de82,w()));let _0x153d43=[];return _0x32cad2['children']['inorderTraversal']((_0x5a48f3,_0x1bb1ca)=>{const _0x2575b3=_0x1accfe?_0x1accfe['getImmediateChild'](_0x5a48f3):null,_0x4d7456=Ho(_0x412fad,_0x5a48f3),_0x39c314=_0x35b257['operationForChild'](_0x5a48f3);_0x39c314&&(_0x153d43=_0x153d43['concat'](ea(_0x39c314,_0x1bb1ca,_0x2575b3,_0x4d7456)));}),_0x34de82&&(_0x153d43=_0x153d43['concat'](rs(_0x34de82,_0x35b257,_0x412fad,_0x1accfe))),_0x153d43;}function ta(_0x1887f9,_0x51ea62){const _0x54c44a=_0x51ea62['query'],_0x2912be=xt(_0x1887f9,_0x54c44a);return{'hashFn':()=>(Mu(_0x51ea62)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x929ee8=>{if(_0x929ee8==='ok')return _0x2912be?Qu(_0x1887f9,_0x54c44a['_path'],_0x2912be):Yu(_0x1887f9,_0x54c44a['_path']);{const _0x537fca=Kl(_0x929ee8,_0x54c44a);return Cn(_0x1887f9,_0x54c44a,null,_0x537fca);}}};}function xt(_0x5cfb39,_0xd70f48){const _0x4f7f6c=Un(_0xd70f48);return _0x5cfb39['queryToTagMap']['get'](_0x4f7f6c);}function Un(_0x27631e){return _0x27631e['_path']['toString']()+'$'+_0x27631e['_queryIdentifier'];}function as(_0x831136,_0x1aa722){return _0x831136['tagToQueryMap']['get'](_0x1aa722);}function cs(_0x1b69ff){const _0x40552d=_0x1b69ff['indexOf']('$');return f(_0x40552d!==-0x1&&_0x40552d<_0x1b69ff['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x1b69ff['substr'](_0x40552d+0x1),'path':new C(_0x1b69ff['substr'](0x0,_0x40552d))};}function ls(_0x13852d,_0x15a851,_0x56bebb){const _0x265fb6=_0x13852d['syncPointTree_']['get'](_0x15a851);f(_0x265fb6,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x168069=Ln(_0x13852d['pendingWriteTree_'],_0x15a851);return rs(_0x265fb6,_0x56bebb,_0x168069,null);}function Zu(_0x1e374a){return _0x1e374a['fold']((_0x4f8107,_0x7de6f3,_0x19605d)=>{if(_0x7de6f3&&Te(_0x7de6f3))return[xn(_0x7de6f3)];{let _0x1bd28a=[];return _0x7de6f3&&(_0x1bd28a=Yo(_0x7de6f3)),x(_0x19605d,(_0x274a2d,_0x40d67e)=>{_0x1bd28a=_0x1bd28a['concat'](_0x40d67e);}),_0x1bd28a;}});}function bt(_0x5683e2){return _0x5683e2['_queryParams']['loadsAllData']()&&!_0x5683e2['_queryParams']['isDefault']()?new(qu())(_0x5683e2['_repo'],_0x5683e2['_path']):_0x5683e2;}function ed(_0x3d7dba,_0x16c275){for(let _0x592168=0x0;_0x592168<_0x16c275['length'];++_0x592168){const _0x3b1311=_0x16c275[_0x592168];if(!_0x3b1311['_queryParams']['loadsAllData']()){const _0x46f6c5=Un(_0x3b1311),_0x17f9ed=_0x3d7dba['queryToTagMap']['get'](_0x46f6c5);_0x3d7dba['queryToTagMap']['delete'](_0x46f6c5),_0x3d7dba['tagToQueryMap']['delete'](_0x17f9ed);}}}function td(){return zu++;}function nd(_0x53683a,_0x12838f,_0x28942f){const _0x179d68=_0x12838f['_path'],_0x59e510=xt(_0x53683a,_0x12838f),_0x24bf33=ta(_0x53683a,_0x28942f),_0x5485e6=_0x53683a['listenProvider_']['startListening'](bt(_0x12838f),_0x59e510,_0x24bf33['hashFn'],_0x24bf33['onComplete']),_0x4bda20=_0x53683a['syncPointTree_']['subtree'](_0x179d68);if(_0x59e510)f(!Te(_0x4bda20['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x3ded2c=_0x4bda20['fold']((_0x2a042a,_0x2cb589,_0x40319b)=>{if(!v(_0x2a042a)&&_0x2cb589&&Te(_0x2cb589))return[xn(_0x2cb589)['query']];{let _0x1ae5d9=[];return _0x2cb589&&(_0x1ae5d9=_0x1ae5d9['concat'](Yo(_0x2cb589)['map'](_0x552e79=>_0x552e79['query']))),x(_0x40319b,(_0x578914,_0x42500a)=>{_0x1ae5d9=_0x1ae5d9['concat'](_0x42500a);}),_0x1ae5d9;}});for(let _0xc22c82=0x0;_0xc22c82<_0x3ded2c['length'];++_0xc22c82){const _0x17fc55=_0x3ded2c[_0xc22c82];_0x53683a['listenProvider_']['stopListening'](bt(_0x17fc55),xt(_0x53683a,_0x17fc55));}}return _0x5485e6;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class hs{constructor(_0x5c852a){this['node_']=_0x5c852a;}['getImmediateChild'](_0x59d80d){const _0x46e56b=this['node_']['getImmediateChild'](_0x59d80d);return new hs(_0x46e56b);}['node'](){return this['node_'];}}class us{constructor(_0xe2f66,_0xe494a7){this['syncTree_']=_0xe2f66,this['path_']=_0xe494a7;}['getImmediateChild'](_0x3c1a51){const _0x22d568=k(this['path_'],_0x3c1a51);return new us(this['syncTree_'],_0x22d568);}['node'](){return Fn(this['syncTree_'],this['path_']);}}const id=function(_0x362218){return _0x362218=_0x362218||{},_0x362218['timestamp']=_0x362218['timestamp']||new Date()['getTime'](),_0x362218;},gr=function(_0x5c8a48,_0x79a253,_0x488606){if(!_0x5c8a48||typeof _0x5c8a48!='object')return _0x5c8a48;if(f('.sv'in _0x5c8a48,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x5c8a48['.sv']=='string')return sd(_0x5c8a48['.sv'],_0x79a253,_0x488606);if(typeof _0x5c8a48['.sv']=='object')return rd(_0x5c8a48['.sv'],_0x79a253);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x5c8a48,null,0x2));},sd=function(_0x249272,_0x3e2f61,_0x25b4ac){switch(_0x249272){case'timestamp':return _0x25b4ac['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x249272);}},rd=function(_0x513f7b,_0x47a69e,_0x1bfab5){_0x513f7b['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x513f7b,null,0x2));const _0x56888e=_0x513f7b['increment'];typeof _0x56888e!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x56888e);const _0x46bace=_0x47a69e['node']();if(f(_0x46bace!==null&&typeof _0x46bace<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x46bace['isLeafNode']())return _0x56888e;const _0x361180=_0x46bace['getValue']();return typeof _0x361180!='number'?_0x56888e:_0x361180+_0x56888e;},na=function(_0x15ffe0,_0x49a0c5,_0x4216e0,_0x1f5af6){return fs(_0x49a0c5,new us(_0x4216e0,_0x15ffe0),_0x1f5af6);},ds=function(_0x168044,_0x3e25ef,_0xe0d631){return fs(_0x168044,new hs(_0x3e25ef),_0xe0d631);};function fs(_0xa71345,_0xc15596,_0x3f3fb4){const _0x1d3f7d=_0xa71345['getPriority']()['val'](),_0x31f5af=gr(_0x1d3f7d,_0xc15596['getImmediateChild']('.priority'),_0x3f3fb4);let _0x55d222;if(_0xa71345['isLeafNode']()){const _0x3f59ef=_0xa71345,_0x534166=gr(_0x3f59ef['getValue'](),_0xc15596,_0x3f3fb4);return _0x534166!==_0x3f59ef['getValue']()||_0x31f5af!==_0x3f59ef['getPriority']()['val']()?new D(_0x534166,P(_0x31f5af)):_0xa71345;}else{const _0xa2a5a6=_0xa71345;return _0x55d222=_0xa2a5a6,_0x31f5af!==_0xa2a5a6['getPriority']()['val']()&&(_0x55d222=_0x55d222['updatePriority'](new D(_0x31f5af))),_0xa2a5a6['forEachChild'](R,(_0x17815b,_0x5efbdc)=>{const _0x382d2a=fs(_0x5efbdc,_0xc15596['getImmediateChild'](_0x17815b),_0x3f3fb4);_0x382d2a!==_0x5efbdc&&(_0x55d222=_0x55d222['updateImmediateChild'](_0x17815b,_0x382d2a));}),_0x55d222;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ps{constructor(_0x3835a6='',_0x5e373e=null,_0x57cc8d={'children':{},'childCount':0x0}){this['name']=_0x3835a6,this['parent']=_0x5e373e,this['node']=_0x57cc8d;}}function Wn(_0x5580c4,_0x155479){let _0x177669=_0x155479 instanceof C?_0x155479:new C(_0x155479),_0xe8065b=_0x5580c4,_0x356477=y(_0x177669);for(;_0x356477!==null;){const _0x411372=De(_0xe8065b['node']['children'],_0x356477)||{'children':{},'childCount':0x0};_0xe8065b=new ps(_0x356477,_0xe8065b,_0x411372),_0x177669=b(_0x177669),_0x356477=y(_0x177669);}return _0xe8065b;}function Ge(_0xd2c84){return _0xd2c84['node']['value'];}function _s(_0x16de9c,_0x5a2ec8){_0x16de9c['node']['value']=_0x5a2ec8,Ai(_0x16de9c);}function ia(_0x4b1b0d){return _0x4b1b0d['node']['childCount']>0x0;}function od(_0x3c2271){return Ge(_0x3c2271)===void 0x0&&!ia(_0x3c2271);}function Bn(_0x52fc2d,_0x46a21d){x(_0x52fc2d['node']['children'],(_0x28a905,_0x2b49ce)=>{_0x46a21d(new ps(_0x28a905,_0x52fc2d,_0x2b49ce));});}function sa(_0x5a4d32,_0x48b97,_0x2dc8aa,_0x4dedc1){_0x2dc8aa&&_0x48b97(_0x5a4d32),Bn(_0x5a4d32,_0x4f5fcd=>{sa(_0x4f5fcd,_0x48b97,!0x0);});}function ad(_0x3a0b19,_0x2f17d2,_0x1d9d22){let _0x3fdece=_0x3a0b19['parent'];for(;_0x3fdece!==null;){if(_0x2f17d2(_0x3fdece))return!0x0;_0x3fdece=_0x3fdece['parent'];}return!0x1;}function qt(_0x55e44f){return new C(_0x55e44f['parent']===null?_0x55e44f['name']:qt(_0x55e44f['parent'])+'/'+_0x55e44f['name']);}function Ai(_0x1389c2){_0x1389c2['parent']!==null&&cd(_0x1389c2['parent'],_0x1389c2['name'],_0x1389c2);}function cd(_0x11e2e4,_0x35b075,_0x4de8cd){const _0x1649c5=od(_0x4de8cd),_0x5842c1=J(_0x11e2e4['node']['children'],_0x35b075);_0x1649c5&&_0x5842c1?(delete _0x11e2e4['node']['children'][_0x35b075],_0x11e2e4['node']['childCount']--,Ai(_0x11e2e4)):!_0x1649c5&&!_0x5842c1&&(_0x11e2e4['node']['children'][_0x35b075]=_0x4de8cd['node'],_0x11e2e4['node']['childCount']++,Ai(_0x11e2e4));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ai=0xa*0x400*0x400,gs=function(_0x2048b1){return typeof _0x2048b1=='string'&&_0x2048b1['length']!==0x0&&!ld['test'](_0x2048b1);},ra=function(_0x37d1c8){return typeof _0x37d1c8=='string'&&_0x37d1c8['length']!==0x0&&!hd['test'](_0x37d1c8);},ud=function(_0x144588){return _0x144588&&(_0x144588=_0x144588['replace'](/^\/*\.info(\/|$)/,'/')),ra(_0x144588);},Tn=function(_0x418727){return _0x418727===null||typeof _0x418727=='string'||typeof _0x418727=='number'&&!Vi(_0x418727)||_0x418727&&typeof _0x418727=='object'&&J(_0x418727,'.sv');},zt=function(_0x508fcf,_0x4e2729,_0x431a3c,_0x3a19ae){_0x3a19ae&&_0x4e2729===void 0x0||jt(Pn(_0x508fcf,'value'),_0x4e2729,_0x431a3c);},jt=function(_0xb0dd1d,_0x4e7824,_0x1abd37){const _0x580f60=_0x1abd37 instanceof C?new Ah(_0x1abd37,_0xb0dd1d):_0x1abd37;if(_0x4e7824===void 0x0)throw new Error(_0xb0dd1d+'contains\x20undefined\x20'+Pe(_0x580f60));if(typeof _0x4e7824=='function')throw new Error(_0xb0dd1d+'contains\x20a\x20function\x20'+Pe(_0x580f60)+'\x20with\x20contents\x20=\x20'+_0x4e7824['toString']());if(Vi(_0x4e7824))throw new Error(_0xb0dd1d+'contains\x20'+_0x4e7824['toString']()+'\x20'+Pe(_0x580f60));if(typeof _0x4e7824=='string'&&_0x4e7824['length']>ai/0x3&&On(_0x4e7824)>ai)throw new Error(_0xb0dd1d+'contains\x20a\x20string\x20greater\x20than\x20'+ai+'\x20utf8\x20bytes\x20'+Pe(_0x580f60)+'\x20(\x27'+_0x4e7824['substring'](0x0,0x32)+'...\x27)');if(_0x4e7824&&typeof _0x4e7824=='object'){let _0x44508a=!0x1,_0x1de364=!0x1;if(x(_0x4e7824,(_0x4d1084,_0x493f65)=>{if(_0x4d1084==='.value')_0x44508a=!0x0;else{if(_0x4d1084!=='.priority'&&_0x4d1084!=='.sv'&&(_0x1de364=!0x0,!gs(_0x4d1084)))throw new Error(_0xb0dd1d+'\x20contains\x20an\x20invalid\x20key\x20('+_0x4d1084+')\x20'+Pe(_0x580f60)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x580f60,_0x4d1084),jt(_0xb0dd1d,_0x493f65,_0x580f60),Nh(_0x580f60);}),_0x44508a&&_0x1de364)throw new Error(_0xb0dd1d+'\x20contains\x20\x22.value\x22\x20child\x20'+Pe(_0x580f60)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x388b43,_0x184382){let _0x406f78,_0x47366d;for(_0x406f78=0x0;_0x406f78<_0x184382['length'];_0x406f78++){_0x47366d=_0x184382[_0x406f78];const _0x365499=Pt(_0x47366d);for(let _0x1bc31e=0x0;_0x1bc31e<_0x365499['length'];_0x1bc31e++)if(!(_0x365499[_0x1bc31e]==='.priority'&&_0x1bc31e===_0x365499['length']-0x1)){if(!gs(_0x365499[_0x1bc31e]))throw new Error(_0x388b43+'contains\x20an\x20invalid\x20key\x20('+_0x365499[_0x1bc31e]+')\x20in\x20path\x20'+_0x47366d['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x184382['sort'](Rh);let _0x52a2df=null;for(_0x406f78=0x0;_0x406f78<_0x184382['length'];_0x406f78++){if(_0x47366d=_0x184382[_0x406f78],_0x52a2df!==null&&G(_0x52a2df,_0x47366d))throw new Error(_0x388b43+'contains\x20a\x20path\x20'+_0x52a2df['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x47366d['toString']());_0x52a2df=_0x47366d;}},fd=function(_0x21bedf,_0x7a1944,_0x164431,_0x398fb2){const _0x511d6c=Pn(_0x21bedf,'values');if(!(_0x7a1944&&typeof _0x7a1944=='object')||Array['isArray'](_0x7a1944))throw new Error(_0x511d6c+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x1a41a6=[];x(_0x7a1944,(_0x587e16,_0x4603b3)=>{const _0x221a95=new C(_0x587e16);if(jt(_0x511d6c,_0x4603b3,k(_0x164431,_0x221a95)),zi(_0x221a95)==='.priority'&&!Tn(_0x4603b3))throw new Error(_0x511d6c+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x221a95['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x1a41a6['push'](_0x221a95);}),dd(_0x511d6c,_0x1a41a6);},ms=function(_0x519cd8,_0x3bfee5,_0x849290,_0x366b15){if(!ra(_0x849290))throw new Error(Pn(_0x519cd8,_0x3bfee5)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x849290+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0xc60165,_0x59c0c9,_0x5daaac,_0x2da8b7){_0x5daaac&&(_0x5daaac=_0x5daaac['replace'](/^\/*\.info(\/|$)/,'/')),ms(_0xc60165,_0x59c0c9,_0x5daaac);},ys=function(_0x29c9cd,_0x505a18){if(y(_0x505a18)==='.info')throw new Error(_0x29c9cd+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0xd9e8fa,_0x177c94){const _0x18d3f7=_0x177c94['path']['toString']();if(typeof _0x177c94['repoInfo']['host']!='string'||_0x177c94['repoInfo']['host']['length']===0x0||!gs(_0x177c94['repoInfo']['namespace'])&&_0x177c94['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x18d3f7['length']!==0x0&&!ud(_0x18d3f7))throw new Error(Pn(_0xd9e8fa,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Vn(_0x43e943,_0x788152){let _0x554c00=null;for(let _0x5aab6e=0x0;_0x5aab6e<_0x788152['length'];_0x5aab6e++){const _0x421f86=_0x788152[_0x5aab6e],_0x20094b=_0x421f86['getPath']();_0x554c00!==null&&!ji(_0x20094b,_0x554c00['path'])&&(_0x43e943['eventLists_']['push'](_0x554c00),_0x554c00=null),_0x554c00===null&&(_0x554c00={'events':[],'path':_0x20094b}),_0x554c00['events']['push'](_0x421f86);}_0x554c00&&_0x43e943['eventLists_']['push'](_0x554c00);}function oa(_0x2ddcbe,_0x1ae126,_0x21b496){Vn(_0x2ddcbe,_0x21b496),aa(_0x2ddcbe,_0x48f751=>ji(_0x48f751,_0x1ae126));}function H(_0x3eb60a,_0x41512b,_0x1cd9b5){Vn(_0x3eb60a,_0x1cd9b5),aa(_0x3eb60a,_0x430328=>G(_0x430328,_0x41512b)||G(_0x41512b,_0x430328));}function aa(_0x5cea7e,_0x1589e0){_0x5cea7e['recursionDepth_']++;let _0x1435f9=!0x0;for(let _0x4967d8=0x0;_0x4967d8<_0x5cea7e['eventLists_']['length'];_0x4967d8++){const _0x70475e=_0x5cea7e['eventLists_'][_0x4967d8];if(_0x70475e){const _0x17b6ac=_0x70475e['path'];_0x1589e0(_0x17b6ac)?(md(_0x5cea7e['eventLists_'][_0x4967d8]),_0x5cea7e['eventLists_'][_0x4967d8]=null):_0x1435f9=!0x1;}}_0x1435f9&&(_0x5cea7e['eventLists_']=[]),_0x5cea7e['recursionDepth_']--;}function md(_0x5323cd){for(let _0xe97ca0=0x0;_0xe97ca0<_0x5323cd['events']['length'];_0xe97ca0++){const _0x3d13f0=_0x5323cd['events'][_0xe97ca0];if(_0x3d13f0!==null){_0x5323cd['events'][_0xe97ca0]=null;const _0x561beb=_0x3d13f0['getEventRunner']();wt&&L('event:\x20'+_0x3d13f0['toString']()),ht(_0x561beb);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x3a9bec,_0x2689d0,_0x2fc3a9,_0xca12a9){this['repoInfo_']=_0x3a9bec,this['forceRestClient_']=_0x2689d0,this['authTokenProvider_']=_0x2fc3a9,this['appCheckProvider_']=_0xca12a9,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=_n(),this['transactionQueueTree_']=new ps(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x2a6a7a,_0x5e79dd,_0x347759){if(_0x2a6a7a['stats_']=Gi(_0x2a6a7a['repoInfo_']),_0x2a6a7a['forceRestClient_']||Xl())_0x2a6a7a['server_']=new pn(_0x2a6a7a['repoInfo_'],(_0x120eb5,_0x42db77,_0x359c9d,_0x5e50b5)=>{mr(_0x2a6a7a,_0x120eb5,_0x42db77,_0x359c9d,_0x5e50b5);},_0x2a6a7a['authTokenProvider_'],_0x2a6a7a['appCheckProvider_']),setTimeout(()=>yr(_0x2a6a7a,!0x0),0x0);else{if(typeof _0x347759<'u'&&_0x347759!==null){if(typeof _0x347759!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x347759);}catch(_0x57a054){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x57a054);}}_0x2a6a7a['persistentConnection_']=new se(_0x2a6a7a['repoInfo_'],_0x5e79dd,(_0x30bee5,_0x9a9568,_0xd0b83,_0x596c1f)=>{mr(_0x2a6a7a,_0x30bee5,_0x9a9568,_0xd0b83,_0x596c1f);},_0x583709=>{yr(_0x2a6a7a,_0x583709);},_0x5e283b=>{Id(_0x2a6a7a,_0x5e283b);},_0x2a6a7a['authTokenProvider_'],_0x2a6a7a['appCheckProvider_'],_0x347759),_0x2a6a7a['server_']=_0x2a6a7a['persistentConnection_'];}_0x2a6a7a['authTokenProvider_']['addTokenChangeListener'](_0x625d10=>{_0x2a6a7a['server_']['refreshAuthToken'](_0x625d10);}),_0x2a6a7a['appCheckProvider_']['addTokenChangeListener'](_0x3dec27=>{_0x2a6a7a['server_']['refreshAppCheckToken'](_0x3dec27['token']);}),_0x2a6a7a['statsReporter_']=ih(_0x2a6a7a['repoInfo_'],()=>new iu(_0x2a6a7a['stats_'],_0x2a6a7a['server_'])),_0x2a6a7a['infoData_']=new Xh(),_0x2a6a7a['infoSyncTree_']=new _r({'startListening':(_0x4040b8,_0x4b0591,_0x1b16a6,_0x480f9c)=>{let _0x543585=[];const _0x3e22fa=_0x2a6a7a['infoData_']['getNode'](_0x4040b8['_path']);return _0x3e22fa['isEmpty']()||(_0x543585=Gt(_0x2a6a7a['infoSyncTree_'],_0x4040b8['_path'],_0x3e22fa),setTimeout(()=>{_0x480f9c('ok');},0x0)),_0x543585;},'stopListening':()=>{}}),vs(_0x2a6a7a,'connected',!0x1),_0x2a6a7a['serverSyncTree_']=new _r({'startListening':(_0x1246d1,_0x11b5d9,_0x199edf,_0x508b53)=>(_0x2a6a7a['server_']['listen'](_0x1246d1,_0x199edf,_0x11b5d9,(_0x29235e,_0x9186be)=>{const _0x4abf54=_0x508b53(_0x29235e,_0x9186be);H(_0x2a6a7a['eventQueue_'],_0x1246d1['_path'],_0x4abf54);}),[]),'stopListening':(_0x31cfa3,_0x299a8d)=>{_0x2a6a7a['server_']['unlisten'](_0x31cfa3,_0x299a8d);}});}function la(_0x5bbccb){const _0x497de8=_0x5bbccb['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x497de8;}function Kt(_0x5ac62b){return id({'timestamp':la(_0x5ac62b)});}function mr(_0xc3a518,_0x31c23f,_0x487b70,_0x4c7bbe,_0x46461d){_0xc3a518['dataUpdateCount']++;const _0x422990=new C(_0x31c23f);_0x487b70=_0xc3a518['interceptServerDataCallback_']?_0xc3a518['interceptServerDataCallback_'](_0x31c23f,_0x487b70):_0x487b70;let _0x12d32f=[];if(_0x46461d){if(_0x4c7bbe){const _0x82fc80=hn(_0x487b70,_0x193aca=>P(_0x193aca));_0x12d32f=Ju(_0xc3a518['serverSyncTree_'],_0x422990,_0x82fc80,_0x46461d);}else{const _0xebdb31=P(_0x487b70);_0x12d32f=Xo(_0xc3a518['serverSyncTree_'],_0x422990,_0xebdb31,_0x46461d);}}else{if(_0x4c7bbe){const _0x134b54=hn(_0x487b70,_0x4aa5db=>P(_0x4aa5db));_0x12d32f=Ku(_0xc3a518['serverSyncTree_'],_0x422990,_0x134b54);}else{const _0x4e1309=P(_0x487b70);_0x12d32f=Gt(_0xc3a518['serverSyncTree_'],_0x422990,_0x4e1309);}}let _0x3ad06=_0x422990;_0x12d32f['length']>0x0&&(_0x3ad06=it(_0xc3a518,_0x422990)),H(_0xc3a518['eventQueue_'],_0x3ad06,_0x12d32f);}function yr(_0x18df3b,_0x3d135a){vs(_0x18df3b,'connected',_0x3d135a),_0x3d135a===!0x1&&Sd(_0x18df3b);}function Id(_0x3722f9,_0x4ad158){x(_0x4ad158,(_0x1d062b,_0x337b1c)=>{vs(_0x3722f9,_0x1d062b,_0x337b1c);});}function vs(_0x357c82,_0x5a5178,_0x1a2c05){const _0x3730f1=new C('/.info/'+_0x5a5178),_0x2de9ce=P(_0x1a2c05);_0x357c82['infoData_']['updateSnapshot'](_0x3730f1,_0x2de9ce);const _0x3a85ab=Gt(_0x357c82['infoSyncTree_'],_0x3730f1,_0x2de9ce);H(_0x357c82['eventQueue_'],_0x3730f1,_0x3a85ab);}function Hn(_0x1975e1){return _0x1975e1['nextWriteId_']++;}function wd(_0x3c0418,_0x50cd28,_0x486a6c){const _0x4589f9=Xu(_0x3c0418['serverSyncTree_'],_0x50cd28);return _0x4589f9!=null?Promise['resolve'](_0x4589f9):_0x3c0418['server_']['get'](_0x50cd28)['then'](_0x12fac4=>{const _0x57a316=P(_0x12fac4)['withIndex'](_0x50cd28['_queryParams']['getIndex']());Ri(_0x3c0418['serverSyncTree_'],_0x50cd28,_0x486a6c,!0x0);let _0x534809;if(_0x50cd28['_queryParams']['loadsAllData']())_0x534809=Gt(_0x3c0418['serverSyncTree_'],_0x50cd28['_path'],_0x57a316);else{const _0xd6c0ae=xt(_0x3c0418['serverSyncTree_'],_0x50cd28);_0x534809=Xo(_0x3c0418['serverSyncTree_'],_0x50cd28['_path'],_0x57a316,_0xd6c0ae);}return H(_0x3c0418['eventQueue_'],_0x50cd28['_path'],_0x534809),Cn(_0x3c0418['serverSyncTree_'],_0x50cd28,_0x486a6c,null,!0x0),_0x57a316;},_0x14fcd1=>(dt(_0x3c0418,'get\x20for\x20query\x20'+O(_0x50cd28)+'\x20failed:\x20'+_0x14fcd1),Promise['reject'](new Error(_0x14fcd1))));}function Cd(_0xdf039,_0x5b47b6,_0x1f3b8a,_0x2fab8a,_0xf41a01){dt(_0xdf039,'set',{'path':_0x5b47b6['toString'](),'value':_0x1f3b8a,'priority':_0x2fab8a});const _0x455ebb=Kt(_0xdf039),_0x1e3c84=P(_0x1f3b8a,_0x2fab8a),_0x166321=Fn(_0xdf039['serverSyncTree_'],_0x5b47b6),_0x48de27=ds(_0x1e3c84,_0x166321,_0x455ebb),_0x4dd434=Hn(_0xdf039),_0x5279f1=os(_0xdf039['serverSyncTree_'],_0x5b47b6,_0x48de27,_0x4dd434,!0x0);Vn(_0xdf039['eventQueue_'],_0x5279f1),_0xdf039['server_']['put'](_0x5b47b6['toString'](),_0x1e3c84['val'](!0x0),(_0x195aae,_0x572879)=>{const _0x30ad3c=_0x195aae==='ok';_0x30ad3c||U('set\x20at\x20'+_0x5b47b6+'\x20failed:\x20'+_0x195aae);const _0x54693c=pe(_0xdf039['serverSyncTree_'],_0x4dd434,!_0x30ad3c);H(_0xdf039['eventQueue_'],_0x5b47b6,_0x54693c),ki(_0xdf039,_0xf41a01,_0x195aae,_0x572879);});const _0x777d2d=Is(_0xdf039,_0x5b47b6);it(_0xdf039,_0x777d2d),H(_0xdf039['eventQueue_'],_0x777d2d,[]);}function Td(_0x3aa804,_0x2f5b13,_0x3ec5ac,_0x513204){dt(_0x3aa804,'update',{'path':_0x2f5b13['toString'](),'value':_0x3ec5ac});let _0x28a23a=!0x0;const _0x14d5a9=Kt(_0x3aa804),_0xa4a562={};if(x(_0x3ec5ac,(_0x32abd4,_0x28badb)=>{_0x28a23a=!0x1,_0xa4a562[_0x32abd4]=na(k(_0x2f5b13,_0x32abd4),P(_0x28badb),_0x3aa804['serverSyncTree_'],_0x14d5a9);}),_0x28a23a)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),ki(_0x3aa804,_0x513204,'ok',void 0x0);else{const _0x5433f5=Hn(_0x3aa804),_0x5f136d=ju(_0x3aa804['serverSyncTree_'],_0x2f5b13,_0xa4a562,_0x5433f5);Vn(_0x3aa804['eventQueue_'],_0x5f136d),_0x3aa804['server_']['merge'](_0x2f5b13['toString'](),_0x3ec5ac,(_0x40ada9,_0x2dac0f)=>{const _0x4cc965=_0x40ada9==='ok';_0x4cc965||U('update\x20at\x20'+_0x2f5b13+'\x20failed:\x20'+_0x40ada9);const _0x24e87c=pe(_0x3aa804['serverSyncTree_'],_0x5433f5,!_0x4cc965),_0x4802ac=_0x24e87c['length']>0x0?it(_0x3aa804,_0x2f5b13):_0x2f5b13;H(_0x3aa804['eventQueue_'],_0x4802ac,_0x24e87c),ki(_0x3aa804,_0x513204,_0x40ada9,_0x2dac0f);}),x(_0x3ec5ac,_0x4d91d8=>{const _0xbede6b=Is(_0x3aa804,k(_0x2f5b13,_0x4d91d8));it(_0x3aa804,_0xbede6b);}),H(_0x3aa804['eventQueue_'],_0x2f5b13,[]);}}function Sd(_0xdc26f1){dt(_0xdc26f1,'onDisconnectEvents');const _0x5025d5=Kt(_0xdc26f1),_0x170c82=_n();Ii(_0xdc26f1['onDisconnect_'],w(),(_0xf6cd9b,_0x463268)=>{const _0x43e405=na(_0xf6cd9b,_0x463268,_0xdc26f1['serverSyncTree_'],_0x5025d5);Fo(_0x170c82,_0xf6cd9b,_0x43e405);});let _0x257cab=[];Ii(_0x170c82,w(),(_0x52b788,_0x5778e0)=>{_0x257cab=_0x257cab['concat'](Gt(_0xdc26f1['serverSyncTree_'],_0x52b788,_0x5778e0));const _0xde079b=Is(_0xdc26f1,_0x52b788);it(_0xdc26f1,_0xde079b);}),_0xdc26f1['onDisconnect_']=_n(),H(_0xdc26f1['eventQueue_'],w(),_0x257cab);}function bd(_0x253544,_0x1af123,_0x2a13a4){let _0x5382f7;y(_0x1af123['_path'])==='.info'?_0x5382f7=Ri(_0x253544['infoSyncTree_'],_0x1af123,_0x2a13a4):_0x5382f7=Ri(_0x253544['serverSyncTree_'],_0x1af123,_0x2a13a4),oa(_0x253544['eventQueue_'],_0x1af123['_path'],_0x5382f7);}function Rd(_0x4b6ff2,_0x3542ac,_0x4a5d06){let _0x26b5fc;y(_0x3542ac['_path'])==='.info'?_0x26b5fc=Cn(_0x4b6ff2['infoSyncTree_'],_0x3542ac,_0x4a5d06):_0x26b5fc=Cn(_0x4b6ff2['serverSyncTree_'],_0x3542ac,_0x4a5d06),oa(_0x4b6ff2['eventQueue_'],_0x3542ac['_path'],_0x26b5fc);}function ha(_0x4bce80){_0x4bce80['persistentConnection_']&&_0x4bce80['persistentConnection_']['interrupt'](ca);}function Ad(_0x6a2fb4){_0x6a2fb4['persistentConnection_']&&_0x6a2fb4['persistentConnection_']['resume'](ca);}function dt(_0x193c11,..._0x562f33){let _0x842d6d='';_0x193c11['persistentConnection_']&&(_0x842d6d=_0x193c11['persistentConnection_']['id']+':'),L(_0x842d6d,..._0x562f33);}function ki(_0x152f6a,_0x2f3013,_0x124b20,_0xa9e5bb){_0x2f3013&&ht(()=>{if(_0x124b20==='ok')_0x2f3013(null);else{const _0x4cc2f3=(_0x124b20||'error')['toUpperCase']();let _0x3fcd29=_0x4cc2f3;_0xa9e5bb&&(_0x3fcd29+=':\x20'+_0xa9e5bb);const _0x629b07=new Error(_0x3fcd29);_0x629b07['code']=_0x4cc2f3,_0x2f3013(_0x629b07);}});}function kd(_0x2b9cda,_0x4d229d,_0x3f6058,_0x40d9cf,_0x4f7715,_0x37bb18){dt(_0x2b9cda,'transaction\x20on\x20'+_0x4d229d);const _0x3a95de={'path':_0x4d229d,'update':_0x3f6058,'onComplete':_0x40d9cf,'status':null,'order':so(),'applyLocally':_0x37bb18,'retryCount':0x0,'unwatcher':_0x4f7715,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x4859f2=Es(_0x2b9cda,_0x4d229d,void 0x0);_0x3a95de['currentInputSnapshot']=_0x4859f2;const _0x46f6ac=_0x3a95de['update'](_0x4859f2['val']());if(_0x46f6ac===void 0x0)_0x3a95de['unwatcher'](),_0x3a95de['currentOutputSnapshotRaw']=null,_0x3a95de['currentOutputSnapshotResolved']=null,_0x3a95de['onComplete']&&_0x3a95de['onComplete'](null,!0x1,_0x3a95de['currentInputSnapshot']);else{jt('transaction\x20failed:\x20Data\x20returned\x20',_0x46f6ac,_0x3a95de['path']),_0x3a95de['status']=0x0;const _0x2936b8=Wn(_0x2b9cda['transactionQueueTree_'],_0x4d229d),_0x4a39ba=Ge(_0x2936b8)||[];_0x4a39ba['push'](_0x3a95de),_s(_0x2936b8,_0x4a39ba);let _0xa10672;typeof _0x46f6ac=='object'&&_0x46f6ac!==null&&J(_0x46f6ac,'.priority')?(_0xa10672=De(_0x46f6ac,'.priority'),f(Tn(_0xa10672),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0xa10672=(Fn(_0x2b9cda['serverSyncTree_'],_0x4d229d)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x211673=Kt(_0x2b9cda),_0x52a33e=P(_0x46f6ac,_0xa10672),_0x529a66=ds(_0x52a33e,_0x4859f2,_0x211673);_0x3a95de['currentOutputSnapshotRaw']=_0x52a33e,_0x3a95de['currentOutputSnapshotResolved']=_0x529a66,_0x3a95de['currentWriteId']=Hn(_0x2b9cda);const _0x232c24=os(_0x2b9cda['serverSyncTree_'],_0x4d229d,_0x529a66,_0x3a95de['currentWriteId'],_0x3a95de['applyLocally']);H(_0x2b9cda['eventQueue_'],_0x4d229d,_0x232c24),$n(_0x2b9cda,_0x2b9cda['transactionQueueTree_']);}}function Es(_0x4ea5b6,_0x2b64df,_0x14b9fd){return Fn(_0x4ea5b6['serverSyncTree_'],_0x2b64df,_0x14b9fd)||g['EMPTY_NODE'];}function $n(_0x434342,_0x48c8f7=_0x434342['transactionQueueTree_']){if(_0x48c8f7||Gn(_0x434342,_0x48c8f7),Ge(_0x48c8f7)){const _0x574883=da(_0x434342,_0x48c8f7);f(_0x574883['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x574883['every'](_0x62d200=>_0x62d200['status']===0x0)&&Nd(_0x434342,qt(_0x48c8f7),_0x574883);}else ia(_0x48c8f7)&&Bn(_0x48c8f7,_0xbc4f6f=>{$n(_0x434342,_0xbc4f6f);});}function Nd(_0x18523a,_0x432278,_0x32b187){const _0x489309=_0x32b187['map'](_0x560ac3=>_0x560ac3['currentWriteId']),_0x5b8be3=Es(_0x18523a,_0x432278,_0x489309);let _0x5aa69f=_0x5b8be3;const _0xabe57a=_0x5b8be3['hash']();for(let _0x4a17f6=0x0;_0x4a17f6<_0x32b187['length'];_0x4a17f6++){const _0x5292e0=_0x32b187[_0x4a17f6];f(_0x5292e0['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x5292e0['status']=0x1,_0x5292e0['retryCount']++;const _0x548d60=F(_0x432278,_0x5292e0['path']);_0x5aa69f=_0x5aa69f['updateChild'](_0x548d60,_0x5292e0['currentOutputSnapshotRaw']);}const _0x6bdd94=_0x5aa69f['val'](!0x0),_0x57269e=_0x432278;_0x18523a['server_']['put'](_0x57269e['toString'](),_0x6bdd94,_0x5956b8=>{dt(_0x18523a,'transaction\x20put\x20response',{'path':_0x57269e['toString'](),'status':_0x5956b8});let _0x248f91=[];if(_0x5956b8==='ok'){const _0xfbb73b=[];for(let _0x1e197e=0x0;_0x1e197e<_0x32b187['length'];_0x1e197e++)_0x32b187[_0x1e197e]['status']=0x2,_0x248f91=_0x248f91['concat'](pe(_0x18523a['serverSyncTree_'],_0x32b187[_0x1e197e]['currentWriteId'])),_0x32b187[_0x1e197e]['onComplete']&&_0xfbb73b['push'](()=>_0x32b187[_0x1e197e]['onComplete'](null,!0x0,_0x32b187[_0x1e197e]['currentOutputSnapshotResolved'])),_0x32b187[_0x1e197e]['unwatcher']();Gn(_0x18523a,Wn(_0x18523a['transactionQueueTree_'],_0x432278)),$n(_0x18523a,_0x18523a['transactionQueueTree_']),H(_0x18523a['eventQueue_'],_0x432278,_0x248f91);for(let _0x53f480=0x0;_0x53f480<_0xfbb73b['length'];_0x53f480++)ht(_0xfbb73b[_0x53f480]);}else{if(_0x5956b8==='datastale'){for(let _0x37ad08=0x0;_0x37ad08<_0x32b187['length'];_0x37ad08++)_0x32b187[_0x37ad08]['status']===0x3?_0x32b187[_0x37ad08]['status']=0x4:_0x32b187[_0x37ad08]['status']=0x0;}else{U('transaction\x20at\x20'+_0x57269e['toString']()+'\x20failed:\x20'+_0x5956b8);for(let _0x49c8b3=0x0;_0x49c8b3<_0x32b187['length'];_0x49c8b3++)_0x32b187[_0x49c8b3]['status']=0x4,_0x32b187[_0x49c8b3]['abortReason']=_0x5956b8;}it(_0x18523a,_0x432278);}},_0xabe57a);}function it(_0x297340,_0x3d8280){const _0x42ad86=ua(_0x297340,_0x3d8280),_0x3d3db5=qt(_0x42ad86),_0xa27f8=da(_0x297340,_0x42ad86);return Pd(_0x297340,_0xa27f8,_0x3d3db5),_0x3d3db5;}function Pd(_0x3d6148,_0x17840b,_0x310b47){if(_0x17840b['length']===0x0)return;const _0x56d246=[];let _0xf7ab71=[];const _0xc61ff=_0x17840b['filter'](_0x28ab29=>_0x28ab29['status']===0x0)['map'](_0x3876ce=>_0x3876ce['currentWriteId']);for(let _0xcb6c46=0x0;_0xcb6c46<_0x17840b['length'];_0xcb6c46++){const _0x56a980=_0x17840b[_0xcb6c46],_0xecd4dc=F(_0x310b47,_0x56a980['path']);let _0x39b88a=!0x1,_0x4355d3;if(f(_0xecd4dc!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x56a980['status']===0x4)_0x39b88a=!0x0,_0x4355d3=_0x56a980['abortReason'],_0xf7ab71=_0xf7ab71['concat'](pe(_0x3d6148['serverSyncTree_'],_0x56a980['currentWriteId'],!0x0));else{if(_0x56a980['status']===0x0){if(_0x56a980['retryCount']>=yd)_0x39b88a=!0x0,_0x4355d3='maxretry',_0xf7ab71=_0xf7ab71['concat'](pe(_0x3d6148['serverSyncTree_'],_0x56a980['currentWriteId'],!0x0));else{const _0x2b624f=Es(_0x3d6148,_0x56a980['path'],_0xc61ff);_0x56a980['currentInputSnapshot']=_0x2b624f;const _0x26f1b6=_0x17840b[_0xcb6c46]['update'](_0x2b624f['val']());if(_0x26f1b6!==void 0x0){jt('transaction\x20failed:\x20Data\x20returned\x20',_0x26f1b6,_0x56a980['path']);let _0x280c38=P(_0x26f1b6);typeof _0x26f1b6=='object'&&_0x26f1b6!=null&&J(_0x26f1b6,'.priority')||(_0x280c38=_0x280c38['updatePriority'](_0x2b624f['getPriority']()));const _0x4cb488=_0x56a980['currentWriteId'],_0x4f55cd=Kt(_0x3d6148),_0x39ffa0=ds(_0x280c38,_0x2b624f,_0x4f55cd);_0x56a980['currentOutputSnapshotRaw']=_0x280c38,_0x56a980['currentOutputSnapshotResolved']=_0x39ffa0,_0x56a980['currentWriteId']=Hn(_0x3d6148),_0xc61ff['splice'](_0xc61ff['indexOf'](_0x4cb488),0x1),_0xf7ab71=_0xf7ab71['concat'](os(_0x3d6148['serverSyncTree_'],_0x56a980['path'],_0x39ffa0,_0x56a980['currentWriteId'],_0x56a980['applyLocally'])),_0xf7ab71=_0xf7ab71['concat'](pe(_0x3d6148['serverSyncTree_'],_0x4cb488,!0x0));}else _0x39b88a=!0x0,_0x4355d3='nodata',_0xf7ab71=_0xf7ab71['concat'](pe(_0x3d6148['serverSyncTree_'],_0x56a980['currentWriteId'],!0x0));}}}H(_0x3d6148['eventQueue_'],_0x310b47,_0xf7ab71),_0xf7ab71=[],_0x39b88a&&(_0x17840b[_0xcb6c46]['status']=0x2,function(_0x14f350){setTimeout(_0x14f350,Math['floor'](0x0));}(_0x17840b[_0xcb6c46]['unwatcher']),_0x17840b[_0xcb6c46]['onComplete']&&(_0x4355d3==='nodata'?_0x56d246['push'](()=>_0x17840b[_0xcb6c46]['onComplete'](null,!0x1,_0x17840b[_0xcb6c46]['currentInputSnapshot'])):_0x56d246['push'](()=>_0x17840b[_0xcb6c46]['onComplete'](new Error(_0x4355d3),!0x1,null))));}Gn(_0x3d6148,_0x3d6148['transactionQueueTree_']);for(let _0x56435c=0x0;_0x56435c<_0x56d246['length'];_0x56435c++)ht(_0x56d246[_0x56435c]);$n(_0x3d6148,_0x3d6148['transactionQueueTree_']);}function ua(_0x3c282e,_0x2730ac){let _0x2d8ef1,_0x138f58=_0x3c282e['transactionQueueTree_'];for(_0x2d8ef1=y(_0x2730ac);_0x2d8ef1!==null&&Ge(_0x138f58)===void 0x0;)_0x138f58=Wn(_0x138f58,_0x2d8ef1),_0x2730ac=b(_0x2730ac),_0x2d8ef1=y(_0x2730ac);return _0x138f58;}function da(_0x79260f,_0x5606b6){const _0x36bc75=[];return fa(_0x79260f,_0x5606b6,_0x36bc75),_0x36bc75['sort']((_0x578e80,_0x254f37)=>_0x578e80['order']-_0x254f37['order']),_0x36bc75;}function fa(_0x224085,_0xafe51b,_0x2224b9){const _0x24bb0a=Ge(_0xafe51b);if(_0x24bb0a){for(let _0x1bd36e=0x0;_0x1bd36e<_0x24bb0a['length'];_0x1bd36e++)_0x2224b9['push'](_0x24bb0a[_0x1bd36e]);}Bn(_0xafe51b,_0x1f9681=>{fa(_0x224085,_0x1f9681,_0x2224b9);});}function Gn(_0x233c7e,_0x390ec2){const _0x391393=Ge(_0x390ec2);if(_0x391393){let _0x47d137=0x0;for(let _0x326cbe=0x0;_0x326cbe<_0x391393['length'];_0x326cbe++)_0x391393[_0x326cbe]['status']!==0x2&&(_0x391393[_0x47d137]=_0x391393[_0x326cbe],_0x47d137++);_0x391393['length']=_0x47d137,_s(_0x390ec2,_0x391393['length']>0x0?_0x391393:void 0x0);}Bn(_0x390ec2,_0x41af44=>{Gn(_0x233c7e,_0x41af44);});}function Is(_0x2ab675,_0x2ec933){const _0x3967a5=qt(ua(_0x2ab675,_0x2ec933)),_0x18c986=Wn(_0x2ab675['transactionQueueTree_'],_0x2ec933);return ad(_0x18c986,_0x3462e2=>{ci(_0x2ab675,_0x3462e2);}),ci(_0x2ab675,_0x18c986),sa(_0x18c986,_0x25b8a6=>{ci(_0x2ab675,_0x25b8a6);}),_0x3967a5;}function ci(_0x2114d6,_0x29b095){const _0x23abf7=Ge(_0x29b095);if(_0x23abf7){const _0x4d7ff9=[];let _0x259010=[],_0x21d545=-0x1;for(let _0x5a8669=0x0;_0x5a8669<_0x23abf7['length'];_0x5a8669++)_0x23abf7[_0x5a8669]['status']===0x3||(_0x23abf7[_0x5a8669]['status']===0x1?(f(_0x21d545===_0x5a8669-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x21d545=_0x5a8669,_0x23abf7[_0x5a8669]['status']=0x3,_0x23abf7[_0x5a8669]['abortReason']='set'):(f(_0x23abf7[_0x5a8669]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x23abf7[_0x5a8669]['unwatcher'](),_0x259010=_0x259010['concat'](pe(_0x2114d6['serverSyncTree_'],_0x23abf7[_0x5a8669]['currentWriteId'],!0x0)),_0x23abf7[_0x5a8669]['onComplete']&&_0x4d7ff9['push'](_0x23abf7[_0x5a8669]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x21d545===-0x1?_s(_0x29b095,void 0x0):_0x23abf7['length']=_0x21d545+0x1,H(_0x2114d6['eventQueue_'],qt(_0x29b095),_0x259010);for(let _0x40c140=0x0;_0x40c140<_0x4d7ff9['length'];_0x40c140++)ht(_0x4d7ff9[_0x40c140]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Od(_0x3520c4){let _0x32c14a='';const _0x29867e=_0x3520c4['split']('/');for(let _0x3d5686=0x0;_0x3d5686<_0x29867e['length'];_0x3d5686++)if(_0x29867e[_0x3d5686]['length']>0x0){let _0x19c6ea=_0x29867e[_0x3d5686];try{_0x19c6ea=decodeURIComponent(_0x19c6ea['replace'](/\+/g,'\x20'));}catch{}_0x32c14a+='/'+_0x19c6ea;}return _0x32c14a;}function Dd(_0x1e7249){const _0x4ec9c1={};_0x1e7249['charAt'](0x0)==='?'&&(_0x1e7249=_0x1e7249['substring'](0x1));for(const _0x679d93 of _0x1e7249['split']('&')){if(_0x679d93['length']===0x0)continue;const _0x25b100=_0x679d93['split']('=');_0x25b100['length']===0x2?_0x4ec9c1[decodeURIComponent(_0x25b100[0x0])]=decodeURIComponent(_0x25b100[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x679d93+'\x27\x20in\x20query\x20\x27'+_0x1e7249+'\x27');}return _0x4ec9c1;}const vr=function(_0x20f616,_0x2fbc97){const _0x128b91=Md(_0x20f616),_0x482261=_0x128b91['namespace'];_0x128b91['domain']==='firebase.com'&&ae(_0x128b91['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x482261||_0x482261==='undefined')&&_0x128b91['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x128b91['secure']||$l();const _0x1975f5=_0x128b91['scheme']==='ws'||_0x128b91['scheme']==='wss';return{'repoInfo':new yo(_0x128b91['host'],_0x128b91['secure'],_0x482261,_0x1975f5,_0x2fbc97,'',_0x482261!==_0x128b91['subdomain']),'path':new C(_0x128b91['pathString'])};},Md=function(_0x4c7b35){let _0x4ffe5b='',_0x26cb1e='',_0x128e8f='',_0xa43633='',_0x1faf0f='',_0x3ed8c8=!0x0,_0x1abe92='https',_0x555b4f=0x1bb;if(typeof _0x4c7b35=='string'){let _0x4ec36b=_0x4c7b35['indexOf']('//');_0x4ec36b>=0x0&&(_0x1abe92=_0x4c7b35['substring'](0x0,_0x4ec36b-0x1),_0x4c7b35=_0x4c7b35['substring'](_0x4ec36b+0x2));let _0x5d12b4=_0x4c7b35['indexOf']('/');_0x5d12b4===-0x1&&(_0x5d12b4=_0x4c7b35['length']);let _0x5d901d=_0x4c7b35['indexOf']('?');_0x5d901d===-0x1&&(_0x5d901d=_0x4c7b35['length']),_0x4ffe5b=_0x4c7b35['substring'](0x0,Math['min'](_0x5d12b4,_0x5d901d)),_0x5d12b4<_0x5d901d&&(_0xa43633=Od(_0x4c7b35['substring'](_0x5d12b4,_0x5d901d)));const _0x5351f9=Dd(_0x4c7b35['substring'](Math['min'](_0x4c7b35['length'],_0x5d901d)));_0x4ec36b=_0x4ffe5b['indexOf'](':'),_0x4ec36b>=0x0?(_0x3ed8c8=_0x1abe92==='https'||_0x1abe92==='wss',_0x555b4f=parseInt(_0x4ffe5b['substring'](_0x4ec36b+0x1),0xa)):_0x4ec36b=_0x4ffe5b['length'];const _0x23b024=_0x4ffe5b['slice'](0x0,_0x4ec36b);if(_0x23b024['toLowerCase']()==='localhost')_0x26cb1e='localhost';else{if(_0x23b024['split']('.')['length']<=0x2)_0x26cb1e=_0x23b024;else{const _0x57fd0d=_0x4ffe5b['indexOf']('.');_0x128e8f=_0x4ffe5b['substring'](0x0,_0x57fd0d)['toLowerCase'](),_0x26cb1e=_0x4ffe5b['substring'](_0x57fd0d+0x1),_0x1faf0f=_0x128e8f;}}'ns'in _0x5351f9&&(_0x1faf0f=_0x5351f9['ns']);}return{'host':_0x4ffe5b,'port':_0x555b4f,'domain':_0x26cb1e,'subdomain':_0x128e8f,'secure':_0x3ed8c8,'scheme':_0x1abe92,'pathString':_0xa43633,'namespace':_0x1faf0f};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ld=(function(){let _0x1e3a82=0x0;const _0x21e8e5=[];return function(_0xbb64c){const _0x29f6f3=_0xbb64c===_0x1e3a82;_0x1e3a82=_0xbb64c;let _0x17b60b;const _0x99d035=new Array(0x8);for(_0x17b60b=0x7;_0x17b60b>=0x0;_0x17b60b--)_0x99d035[_0x17b60b]=Er['charAt'](_0xbb64c%0x40),_0xbb64c=Math['floor'](_0xbb64c/0x40);f(_0xbb64c===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x32ffe0=_0x99d035['join']('');if(_0x29f6f3){for(_0x17b60b=0xb;_0x17b60b>=0x0&&_0x21e8e5[_0x17b60b]===0x3f;_0x17b60b--)_0x21e8e5[_0x17b60b]=0x0;_0x21e8e5[_0x17b60b]++;}else{for(_0x17b60b=0x0;_0x17b60b<0xc;_0x17b60b++)_0x21e8e5[_0x17b60b]=Math['floor'](Math['random']()*0x40);}for(_0x17b60b=0x0;_0x17b60b<0xc;_0x17b60b++)_0x32ffe0+=Er['charAt'](_0x21e8e5[_0x17b60b]);return f(_0x32ffe0['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x32ffe0;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xd{constructor(_0x3a8514,_0x17fadc,_0x43fea3,_0x20973a){this['eventType']=_0x3a8514,this['eventRegistration']=_0x17fadc,this['snapshot']=_0x43fea3,this['prevName']=_0x20973a;}['getPath'](){const _0x56eb90=this['snapshot']['ref'];return this['eventType']==='value'?_0x56eb90['_path']:_0x56eb90['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Fd{constructor(_0xa7dc68,_0x16e336,_0x4ea167){this['eventRegistration']=_0xa7dc68,this['error']=_0x16e336,this['path']=_0x4ea167;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x59c020,_0x5526c4){this['snapshotCallback']=_0x59c020,this['cancelCallback']=_0x5526c4;}['onValue'](_0x3d116a,_0x4393a0){this['snapshotCallback']['call'](null,_0x3d116a,_0x4393a0);}['onCancel'](_0x14ee6d){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x14ee6d);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x11dc79){return this['snapshotCallback']===_0x11dc79['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x11dc79['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x11dc79['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x2986df,_0x4d6698,_0xc1157a,_0x3d7bb2){this['_repo']=_0x2986df,this['_path']=_0x4d6698,this['_queryParams']=_0xc1157a,this['_orderByCalled']=_0x3d7bb2;}get['key'](){return v(this['_path'])?null:zi(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0x50dff1=rr(this['_queryParams']),_0x51c100=Hi(_0x50dff1);return _0x51c100==='{}'?'default':_0x51c100;}get['_queryObject'](){return rr(this['_queryParams']);}['isEqual'](_0x24ab7a){if(_0x24ab7a=N(_0x24ab7a),!(_0x24ab7a instanceof be))return!0x1;const _0x445dff=this['_repo']===_0x24ab7a['_repo'],_0x21ef9a=ji(this['_path'],_0x24ab7a['_path']),_0x503db9=this['_queryIdentifier']===_0x24ab7a['_queryIdentifier'];return _0x445dff&&_0x21ef9a&&_0x503db9;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x5312bd,_0x111683){if(_0x5312bd['_orderByCalled']===!0x0)throw new Error(_0x111683+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function qn(_0x34e9c6){let _0x3e79ba=null,_0x5d31e1=null;if(_0x34e9c6['hasStart']()&&(_0x3e79ba=_0x34e9c6['getIndexStartValue']()),_0x34e9c6['hasEnd']()&&(_0x5d31e1=_0x34e9c6['getIndexEndValue']()),_0x34e9c6['getIndex']()===ye){const _0x16afbc='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x50aaf0='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x34e9c6['hasStart']()){if(_0x34e9c6['getIndexStartName']()!==Fe)throw new Error(_0x16afbc);if(typeof _0x3e79ba!='string')throw new Error(_0x50aaf0);}if(_0x34e9c6['hasEnd']()){if(_0x34e9c6['getIndexEndName']()!==Ie)throw new Error(_0x16afbc);if(typeof _0x5d31e1!='string')throw new Error(_0x50aaf0);}}else{if(_0x34e9c6['getIndex']()===R){if(_0x3e79ba!=null&&!Tn(_0x3e79ba)||_0x5d31e1!=null&&!Tn(_0x5d31e1))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x34e9c6['getIndex']()instanceof Qi||_0x34e9c6['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x3e79ba!=null&&typeof _0x3e79ba=='object'||_0x5d31e1!=null&&typeof _0x5d31e1=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x2536c8){if(_0x2536c8['hasStart']()&&_0x2536c8['hasEnd']()&&_0x2536c8['hasLimit']()&&!_0x2536c8['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends be{constructor(_0x364ffe,_0x36c80d){super(_0x364ffe,_0x36c80d,new Xi(),!0x1);}get['parent'](){const _0x5dd0f9=Ro(this['_path']);return _0x5dd0f9===null?null:new ee(this['_repo'],_0x5dd0f9);}get['root'](){let _0xa64c23=this;for(;_0xa64c23['parent']!==null;)_0xa64c23=_0xa64c23['parent'];return _0xa64c23;}}class st{constructor(_0x543d4d,_0xf3c719,_0x20fc4d){this['_node']=_0x543d4d,this['ref']=_0xf3c719,this['_index']=_0x20fc4d;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0xf744e1){const _0x21f1f9=new C(_0xf744e1),_0x48ef5e=Ft(this['ref'],_0xf744e1);return new st(this['_node']['getChild'](_0x21f1f9),_0x48ef5e,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x4156e7){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x18a014,_0x17ef66)=>_0x4156e7(new st(_0x17ef66,Ft(this['ref'],_0x18a014),R)));}['hasChild'](_0x457ca7){const _0x404cd8=new C(_0x457ca7);return!this['_node']['getChild'](_0x404cd8)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function __(_0x4f5d71,_0x1c66a7){return _0x4f5d71=N(_0x4f5d71),_0x4f5d71['_checkNotDeleted']('ref'),_0x1c66a7!==void 0x0?Ft(_0x4f5d71['_root'],_0x1c66a7):_0x4f5d71['_root'];}function Ft(_0x7290c5,_0x2a64e6){return _0x7290c5=N(_0x7290c5),y(_0x7290c5['_path'])===null?pd('child','path',_0x2a64e6):ms('child','path',_0x2a64e6),new ee(_0x7290c5['_repo'],k(_0x7290c5['_path'],_0x2a64e6));}function g_(_0x270195,_0x6ba39){_0x270195=N(_0x270195),ys('push',_0x270195['_path']),zt('push',_0x6ba39,_0x270195['_path'],!0x0);const _0x239a23=la(_0x270195['_repo']),_0xd34780=Ld(_0x239a23),_0x324139=Ft(_0x270195,_0xd34780),_0xa9c9a3=Ft(_0x270195,_0xd34780);let _0x417bd1;return _0x6ba39!=null?_0x417bd1=Ud(_0xa9c9a3,_0x6ba39)['then'](()=>_0xa9c9a3):_0x417bd1=Promise['resolve'](_0xa9c9a3),_0x324139['then']=_0x417bd1['then']['bind'](_0x417bd1),_0x324139['catch']=_0x417bd1['then']['bind'](_0x417bd1,void 0x0),_0x324139;}function Ud(_0x31aecc,_0x39e5bb){_0x31aecc=N(_0x31aecc),ys('set',_0x31aecc['_path']),zt('set',_0x39e5bb,_0x31aecc['_path'],!0x1);const _0x54ba05=new ot();return Cd(_0x31aecc['_repo'],_0x31aecc['_path'],_0x39e5bb,null,_0x54ba05['wrapCallback'](()=>{})),_0x54ba05['promise'];}function m_(_0xfe259b,_0x35b7ca){fd('update',_0x35b7ca,_0xfe259b['_path']);const _0x314bed=new ot();return Td(_0xfe259b['_repo'],_0xfe259b['_path'],_0x35b7ca,_0x314bed['wrapCallback'](()=>{})),_0x314bed['promise'];}function y_(_0x2c37d1){_0x2c37d1=N(_0x2c37d1);const _0x4ffc41=new pa(()=>{}),_0x401996=new zn(_0x4ffc41);return wd(_0x2c37d1['_repo'],_0x2c37d1,_0x401996)['then'](_0x81a463=>new st(_0x81a463,new ee(_0x2c37d1['_repo'],_0x2c37d1['_path']),_0x2c37d1['_queryParams']['getIndex']()));}class zn{constructor(_0x2f5786){this['callbackContext']=_0x2f5786;}['respondsTo'](_0xe4865c){return _0xe4865c==='value';}['createEvent'](_0x543a26,_0x537971){const _0x20a80f=_0x537971['_queryParams']['getIndex']();return new xd('value',this,new st(_0x543a26['snapshotNode'],new ee(_0x537971['_repo'],_0x537971['_path']),_0x20a80f));}['getEventRunner'](_0x3a736f){return _0x3a736f['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x3a736f['error']):()=>this['callbackContext']['onValue'](_0x3a736f['snapshot'],null);}['createCancelEvent'](_0x5605f1,_0x4bc9f9){return this['callbackContext']['hasCancelCallback']?new Fd(this,_0x5605f1,_0x4bc9f9):null;}['matches'](_0x1a3d69){return _0x1a3d69 instanceof zn?!_0x1a3d69['callbackContext']||!this['callbackContext']?!0x0:_0x1a3d69['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function Wd(_0x38ac9a,_0x4a2319,_0x21116b,_0x48a5eb,_0x527a73){const _0x452aa6=new pa(_0x21116b,void 0x0),_0x430318=new zn(_0x452aa6);return bd(_0x38ac9a['_repo'],_0x38ac9a,_0x430318),()=>Rd(_0x38ac9a['_repo'],_0x38ac9a,_0x430318);}function Bd(_0x5aec2c,_0x2744ed,_0x25c1ce,_0x415564){return Wd(_0x5aec2c,'value',_0x2744ed);}class ft{}class ma extends ft{constructor(_0x5a372e,_0x3b0e9d){super(),this['_value']=_0x5a372e,this['_key']=_0x3b0e9d,this['type']='endAt';}['_apply'](_0x4589dd){zt('endAt',this['_value'],_0x4589dd['_path'],!0x0);const _0x25e3a1=Jh(_0x4589dd['_queryParams'],this['_value'],this['_key']);if(ga(_0x25e3a1),qn(_0x25e3a1),_0x4589dd['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x4589dd['_repo'],_0x4589dd['_path'],_0x25e3a1,_0x4589dd['_orderByCalled']);}}function v_(_0x3f77e9,_0x108baa){return new ma(_0x3f77e9,_0x108baa);}class ya extends ft{constructor(_0x5b123f,_0x4d73bd){super(),this['_value']=_0x5b123f,this['_key']=_0x4d73bd,this['type']='startAt';}['_apply'](_0x34e1cc){zt('startAt',this['_value'],_0x34e1cc['_path'],!0x0);const _0x93bb68=Qh(_0x34e1cc['_queryParams'],this['_value'],this['_key']);if(ga(_0x93bb68),qn(_0x93bb68),_0x34e1cc['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x34e1cc['_repo'],_0x34e1cc['_path'],_0x93bb68,_0x34e1cc['_orderByCalled']);}}function E_(_0x4ccb1f=null,_0x588582){return new ya(_0x4ccb1f,_0x588582);}class Vd extends ft{constructor(_0x412e08){super(),this['_limit']=_0x412e08,this['type']='limitToFirst';}['_apply'](_0x3d1a3a){if(_0x3d1a3a['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x3d1a3a['_repo'],_0x3d1a3a['_path'],Yh(_0x3d1a3a['_queryParams'],this['_limit']),_0x3d1a3a['_orderByCalled']);}}function I_(_0x4c65c3){if(Math['floor'](_0x4c65c3)!==_0x4c65c3||_0x4c65c3<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Vd(_0x4c65c3);}class Hd extends ft{constructor(_0x10838){super(),this['_path']=_0x10838,this['type']='orderByChild';}['_apply'](_0x2a1eef){_a(_0x2a1eef,'orderByChild');const _0x18b0a1=new C(this['_path']);if(v(_0x18b0a1))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x1c99ce=new Qi(_0x18b0a1),_0x399426=xo(_0x2a1eef['_queryParams'],_0x1c99ce);return qn(_0x399426),new be(_0x2a1eef['_repo'],_0x2a1eef['_path'],_0x399426,!0x0);}}function w_(_0x1cb320){if(_0x1cb320==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x1cb320==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x1cb320==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ms('orderByChild','path',_0x1cb320),new Hd(_0x1cb320);}class $d extends ft{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x18f055){_a(_0x18f055,'orderByKey');const _0x621b71=xo(_0x18f055['_queryParams'],ye);return qn(_0x621b71),new be(_0x18f055['_repo'],_0x18f055['_path'],_0x621b71,!0x0);}}function C_(){return new $d();}class Gd extends ft{constructor(_0x3da8ff,_0x4c8acc){super(),this['_value']=_0x3da8ff,this['_key']=_0x4c8acc,this['type']='equalTo';}['_apply'](_0x24ada1){if(zt('equalTo',this['_value'],_0x24ada1['_path'],!0x1),_0x24ada1['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x24ada1['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x24ada1));}}function T_(_0x130314,_0x3ca091){return new Gd(_0x130314,_0x3ca091);}function S_(_0x5150fa,..._0x4ce489){let _0x1bfeac=N(_0x5150fa);for(const _0x28e4bc of _0x4ce489)_0x1bfeac=_0x28e4bc['_apply'](_0x1bfeac);return _0x1bfeac;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qd='FIREBASE_DATABASE_EMULATOR_HOST',Ni={};let zd=!0x1;function jd(_0x75b9f1,_0x3e4fbc,_0x49e8dc,_0x2834f4){const _0x50f25e=_0x3e4fbc['lastIndexOf'](':'),_0x4b11b7=_0x3e4fbc['substring'](0x0,_0x50f25e),_0x15614d=at(_0x4b11b7);_0x75b9f1['repoInfo_']=new yo(_0x3e4fbc,_0x15614d,_0x75b9f1['repoInfo_']['namespace'],_0x75b9f1['repoInfo_']['webSocketOnly'],_0x75b9f1['repoInfo_']['nodeAdmin'],_0x75b9f1['repoInfo_']['persistenceKey'],_0x75b9f1['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x49e8dc),_0x2834f4&&(_0x75b9f1['authTokenProvider_']=_0x2834f4);}function Kd(_0x3dba81,_0xbdac6e,_0x59d464,_0x40edd9,_0x34ef5a){let _0x29ce36=_0x40edd9||_0x3dba81['options']['databaseURL'];_0x29ce36===void 0x0&&(_0x3dba81['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x3dba81['options']['projectId']),_0x29ce36=_0x3dba81['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x436de4=vr(_0x29ce36,_0x34ef5a),_0x3fc6fe=_0x436de4['repoInfo'],_0x20e3e1;typeof process<'u'&&Vs&&(_0x20e3e1=Vs[qd]),_0x20e3e1?(_0x29ce36='http://'+_0x20e3e1+'?ns='+_0x3fc6fe['namespace'],_0x436de4=vr(_0x29ce36,_0x34ef5a),_0x3fc6fe=_0x436de4['repoInfo']):_0x436de4['repoInfo']['secure'];const _0x49cfd5=new eh(_0x3dba81['name'],_0x3dba81['options'],_0xbdac6e);_d('Invalid\x20Firebase\x20Database\x20URL',_0x436de4),v(_0x436de4['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x20ab3a=Qd(_0x3fc6fe,_0x3dba81,_0x49cfd5,new Zl(_0x3dba81,_0x59d464));return new Jd(_0x20ab3a,_0x3dba81);}function Yd(_0x22baff,_0x15de4b){const _0x44b6a9=Ni[_0x15de4b];(!_0x44b6a9||_0x44b6a9[_0x22baff['key']]!==_0x22baff)&&ae('Database\x20'+_0x15de4b+'('+_0x22baff['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x22baff),delete _0x44b6a9[_0x22baff['key']];}function Qd(_0x12be43,_0x3c37bc,_0x59a9e8,_0x2f186d){let _0x31a42e=Ni[_0x3c37bc['name']];_0x31a42e||(_0x31a42e={},Ni[_0x3c37bc['name']]=_0x31a42e);let _0x518ad8=_0x31a42e[_0x12be43['toURLString']()];return _0x518ad8&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x518ad8=new vd(_0x12be43,zd,_0x59a9e8,_0x2f186d),_0x31a42e[_0x12be43['toURLString']()]=_0x518ad8,_0x518ad8;}class Jd{constructor(_0x12686a,_0x17a78f){this['_repoInternal']=_0x12686a,this['app']=_0x17a78f,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Yd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x144b34){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x144b34+'\x20on\x20a\x20deleted\x20database.');}}function b_(_0x3896ad=Zr(),_0x20167a){const _0x26d764=Bi(_0x3896ad,'database')['getImmediate']({'identifier':_0x20167a});if(!_0x26d764['_instanceStarted']){const _0x22bc78=cc('database');_0x22bc78&&Xd(_0x26d764,..._0x22bc78);}return _0x26d764;}function Xd(_0x36087c,_0xb96cb9,_0x18fbf8,_0x32e43f={}){_0x36087c=N(_0x36087c),_0x36087c['_checkNotDeleted']('useEmulator');const _0x40462b=_0xb96cb9+':'+_0x18fbf8,_0x5ece5a=_0x36087c['_repoInternal'];if(_0x36087c['_instanceStarted']){if(_0x40462b===_0x36087c['_repoInternal']['repoInfo_']['host']&&Me(_0x32e43f,_0x5ece5a['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x315018;if(_0x5ece5a['repoInfo_']['nodeAdmin'])_0x32e43f['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x315018=new nn(nn['OWNER']);else{if(_0x32e43f['mockUserToken']){const _0xd2c49=typeof _0x32e43f['mockUserToken']=='string'?_0x32e43f['mockUserToken']:lc(_0x32e43f['mockUserToken'],_0x36087c['app']['options']['projectId']);_0x315018=new nn(_0xd2c49);}}at(_0xb96cb9)&&(jr(_0xb96cb9),Kr('Database',!0x0)),jd(_0x5ece5a,_0x40462b,_0x32e43f,_0x315018);}function R_(_0xf90b61){_0xf90b61=N(_0xf90b61),_0xf90b61['_checkNotDeleted']('goOffline'),ha(_0xf90b61['_repo']);}function A_(_0xda6fbb){_0xda6fbb=N(_0xda6fbb),_0xda6fbb['_checkNotDeleted']('goOnline'),Ad(_0xda6fbb['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Zd(_0x5b82ce){Ul(lt),Ze(new Le('database',(_0x392c4b,{instanceIdentifier:_0x15f0f0})=>{const _0x3dad8f=_0x392c4b['getProvider']('app')['getImmediate'](),_0xb78728=_0x392c4b['getProvider']('auth-internal'),_0x30a9c2=_0x392c4b['getProvider']('app-check-internal');return Kd(_0x3dad8f,_0xb78728,_0x30a9c2,_0x15f0f0);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Hs,$s,_0x5b82ce),me(Hs,$s,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ef={'.sv':'timestamp'};function k_(){return ef;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tf{constructor(_0x368504,_0x3f3b02){this['committed']=_0x368504,this['snapshot']=_0x3f3b02;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function N_(_0x149606,_0x222887,_0x48645b){if(_0x149606=N(_0x149606),ys('Reference.transaction',_0x149606['_path']),_0x149606['key']==='.length'||_0x149606['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x149606['key']+'\x20is\x20a\x20read-only\x20object.';const _0x1e317b=!0x0,_0xfb8781=new ot(),_0x5b93ce=(_0x1c85a5,_0x2c9870,_0x487838)=>{let _0x50f9a0=null;_0x1c85a5?_0xfb8781['reject'](_0x1c85a5):(_0x50f9a0=new st(_0x487838,new ee(_0x149606['_repo'],_0x149606['_path']),R),_0xfb8781['resolve'](new tf(_0x2c9870,_0x50f9a0)));},_0x3781f4=Bd(_0x149606,()=>{});return kd(_0x149606['_repo'],_0x149606['_path'],_0x222887,_0x5b93ce,_0x3781f4,_0x1e317b),_0xfb8781['promise'];}se['prototype']['simpleListen']=function(_0x33693d,_0x53688a){this['sendRequest']('q',{'p':_0x33693d},_0x53688a);},se['prototype']['echo']=function(_0x1044c0,_0x2e35de){this['sendRequest']('echo',{'d':_0x1044c0},_0x2e35de);},Zd();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const nf=va,Ea=new Bt('auth','Firebase',va()),Sn=new Ui('@firebase/auth');function sf(_0x5b335a,..._0x3a8c4c){Sn['logLevel']<=T['WARN']&&Sn['warn']('Auth\x20('+lt+'):\x20'+_0x5b335a,..._0x3a8c4c);}function sn(_0x2cedf3,..._0x3d6ad3){Sn['logLevel']<=T['ERROR']&&Sn['error']('Auth\x20('+lt+'):\x20'+_0x2cedf3,..._0x3d6ad3);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x142b04,..._0xca280e){throw ws(_0x142b04,..._0xca280e);}function X(_0x257da3,..._0x484900){return ws(_0x257da3,..._0x484900);}function Ia(_0x196eaf,_0x244947,_0x47b91f){const _0x5c61bd={...nf(),[_0x244947]:_0x47b91f};return new Bt('auth','Firebase',_0x5c61bd)['create'](_0x244947,{'appName':_0x196eaf['name']});}function re(_0xcbaf4d){return Ia(_0xcbaf4d,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x20a73d,..._0x523908){if(typeof _0x20a73d!='string'){const _0xde940f=_0x523908[0x0],_0x2550ae=[..._0x523908['slice'](0x1)];return _0x2550ae[0x0]&&(_0x2550ae[0x0]['appName']=_0x20a73d['name']),_0x20a73d['_errorFactory']['create'](_0xde940f,..._0x2550ae);}return Ea['create'](_0x20a73d,..._0x523908);}function m(_0x78b17,_0x132011,..._0x57532d){if(!_0x78b17)throw ws(_0x132011,..._0x57532d);}function ne(_0x2554e6){const _0x482b43='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x2554e6;throw sn(_0x482b43),new Error(_0x482b43);}function ce(_0x3f83e6,_0x36ff4f){_0x3f83e6||ne(_0x36ff4f);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pi(){var _0x1f275d;return typeof self<'u'&&((_0x1f275d=self['location'])==null?void 0x0:_0x1f275d['href'])||'';}function rf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x4deac8;return typeof self<'u'&&((_0x4deac8=self['location'])==null?void 0x0:_0x4deac8['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function of(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(rf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function af(){if(typeof navigator>'u')return null;const _0x1b0f28=navigator;return _0x1b0f28['languages']&&_0x1b0f28['languages'][0x0]||_0x1b0f28['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yt{constructor(_0xee4dfd,_0xf19de9){this['shortDelay']=_0xee4dfd,this['longDelay']=_0xf19de9,ce(_0xf19de9>_0xee4dfd,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Fi()||Yr();}['get'](){return of()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x2d267e,_0x726e2c){ce(_0x2d267e['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x24993d}=_0x2d267e['emulator'];return _0x726e2c?''+_0x24993d+(_0x726e2c['startsWith']('/')?_0x726e2c['slice'](0x1):_0x726e2c):_0x24993d;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x5bb047,_0x562ecc,_0x55e719){this['fetchImpl']=_0x5bb047,_0x562ecc&&(this['headersImpl']=_0x562ecc),_0x55e719&&(this['responseImpl']=_0x55e719);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const cf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},lf=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],hf=new Yt(0x7530,0xea60);function Re(_0xa3830d,_0x2da028){return _0xa3830d['tenantId']&&!_0x2da028['tenantId']?{..._0x2da028,'tenantId':_0xa3830d['tenantId']}:_0x2da028;}async function Ae(_0x7d78b1,_0x1ece86,_0x3c0263,_0x103c2a,_0x3b382f={}){return Ca(_0x7d78b1,_0x3b382f,async()=>{let _0x5ce939={},_0x5adefe={};_0x103c2a&&(_0x1ece86==='GET'?_0x5adefe=_0x103c2a:_0x5ce939={'body':JSON['stringify'](_0x103c2a)});const _0x5740fc=ct({'key':_0x7d78b1['config']['apiKey'],..._0x5adefe})['slice'](0x1),_0xb1e4ef=await _0x7d78b1['_getAdditionalHeaders']();_0xb1e4ef['Content-Type']='application/json',_0x7d78b1['languageCode']&&(_0xb1e4ef['X-Firebase-Locale']=_0x7d78b1['languageCode']);const _0x5e66d3={'method':_0x1ece86,'headers':_0xb1e4ef,..._0x5ce939};return dc()||(_0x5e66d3['referrerPolicy']='no-referrer'),_0x7d78b1['emulatorConfig']&&at(_0x7d78b1['emulatorConfig']['host'])&&(_0x5e66d3['credentials']='include'),wa['fetch']()(await Ta(_0x7d78b1,_0x7d78b1['config']['apiHost'],_0x3c0263,_0x5740fc),_0x5e66d3);});}async function Ca(_0x493f8a,_0x3fc934,_0x14e3b2){_0x493f8a['_canInitEmulator']=!0x1;const _0x45e519={...cf,..._0x3fc934};try{const _0x25f32f=new df(_0x493f8a),_0x591168=await Promise['race']([_0x14e3b2(),_0x25f32f['promise']]);_0x25f32f['clearNetworkTimeout']();const _0x37841a=await _0x591168['json']();if('needConfirmation'in _0x37841a)throw tn(_0x493f8a,'account-exists-with-different-credential',_0x37841a);if(_0x591168['ok']&&!('errorMessage'in _0x37841a))return _0x37841a;{const _0x11ffa9=_0x591168['ok']?_0x37841a['errorMessage']:_0x37841a['error']['message'],[_0x2873fd,_0xfa6a09]=_0x11ffa9['split']('\x20:\x20');if(_0x2873fd==='FEDERATED_USER_ID_ALREADY_LINKED')throw tn(_0x493f8a,'credential-already-in-use',_0x37841a);if(_0x2873fd==='EMAIL_EXISTS')throw tn(_0x493f8a,'email-already-in-use',_0x37841a);if(_0x2873fd==='USER_DISABLED')throw tn(_0x493f8a,'user-disabled',_0x37841a);const _0x345943=_0x45e519[_0x2873fd]||_0x2873fd['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0xfa6a09)throw Ia(_0x493f8a,_0x345943,_0xfa6a09);Q(_0x493f8a,_0x345943);}}catch(_0x2cf3c9){if(_0x2cf3c9 instanceof Se)throw _0x2cf3c9;Q(_0x493f8a,'network-request-failed',{'message':String(_0x2cf3c9)});}}async function Qt(_0x1ced70,_0x77617a,_0x4997d6,_0x429a6a,_0x4d38c5={}){const _0x2905f4=await Ae(_0x1ced70,_0x77617a,_0x4997d6,_0x429a6a,_0x4d38c5);return'mfaPendingCredential'in _0x2905f4&&Q(_0x1ced70,'multi-factor-auth-required',{'_serverResponse':_0x2905f4}),_0x2905f4;}async function Ta(_0xc90cce,_0x490edf,_0x262d62,_0x8f566a){const _0x1964e0=''+_0x490edf+_0x262d62+'?'+_0x8f566a,_0x32c1d4=_0xc90cce,_0x3814d6=_0x32c1d4['config']['emulator']?Cs(_0xc90cce['config'],_0x1964e0):_0xc90cce['config']['apiScheme']+'://'+_0x1964e0;return lf['includes'](_0x262d62)&&(await _0x32c1d4['_persistenceManagerAvailable'],_0x32c1d4['_getPersistenceType']()==='COOKIE')?_0x32c1d4['_getPersistence']()['_getFinalTarget'](_0x3814d6)['toString']():_0x3814d6;}function uf(_0x10a5bd){switch(_0x10a5bd){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class df{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x5d4880){this['auth']=_0x5d4880,this['timer']=null,this['promise']=new Promise((_0x299a5e,_0x2a384a)=>{this['timer']=setTimeout(()=>_0x2a384a(X(this['auth'],'network-request-failed')),hf['get']());});}}function tn(_0x540ab6,_0x253cd0,_0x187e94){const _0x38564b={'appName':_0x540ab6['name']};_0x187e94['email']&&(_0x38564b['email']=_0x187e94['email']),_0x187e94['phoneNumber']&&(_0x38564b['phoneNumber']=_0x187e94['phoneNumber']);const _0x5e5a43=X(_0x540ab6,_0x253cd0,_0x38564b);return _0x5e5a43['customData']['_tokenResponse']=_0x187e94,_0x5e5a43;}function wr(_0x9cf0a5){return _0x9cf0a5!==void 0x0&&_0x9cf0a5['enterprise']!==void 0x0;}class ff{constructor(_0x3881cc){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x3881cc['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x3881cc['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x3881cc['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0xe9e3d5){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x52d21b of this['recaptchaEnforcementState'])if(_0x52d21b['provider']&&_0x52d21b['provider']===_0xe9e3d5)return uf(_0x52d21b['enforcementState']);return null;}['isProviderEnabled'](_0x24ec2d){return this['getProviderEnforcementState'](_0x24ec2d)==='ENFORCE'||this['getProviderEnforcementState'](_0x24ec2d)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function pf(_0x9a39c,_0x191efc){return Ae(_0x9a39c,'GET','/v2/recaptchaConfig',Re(_0x9a39c,_0x191efc));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function _f(_0x4d9b4a,_0xe5b97e){return Ae(_0x4d9b4a,'POST','/v1/accounts:delete',_0xe5b97e);}async function bn(_0x54d11e,_0x1fb036){return Ae(_0x54d11e,'POST','/v1/accounts:lookup',_0x1fb036);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Rt(_0xb2c1d3){if(_0xb2c1d3)try{const _0x2910f8=new Date(Number(_0xb2c1d3));if(!isNaN(_0x2910f8['getTime']()))return _0x2910f8['toUTCString']();}catch{}}async function gf(_0x49773a,_0x4dfc98=!0x1){const _0x970aab=N(_0x49773a),_0x32f18b=await _0x970aab['getIdToken'](_0x4dfc98),_0x5cb9a9=Ts(_0x32f18b);m(_0x5cb9a9&&_0x5cb9a9['exp']&&_0x5cb9a9['auth_time']&&_0x5cb9a9['iat'],_0x970aab['auth'],'internal-error');const _0x460621=typeof _0x5cb9a9['firebase']=='object'?_0x5cb9a9['firebase']:void 0x0,_0x2c75bb=_0x460621==null?void 0x0:_0x460621['sign_in_provider'];return{'claims':_0x5cb9a9,'token':_0x32f18b,'authTime':Rt(li(_0x5cb9a9['auth_time'])),'issuedAtTime':Rt(li(_0x5cb9a9['iat'])),'expirationTime':Rt(li(_0x5cb9a9['exp'])),'signInProvider':_0x2c75bb||null,'signInSecondFactor':(_0x460621==null?void 0x0:_0x460621['sign_in_second_factor'])||null};}function li(_0x8f6be){return Number(_0x8f6be)*0x3e8;}function Ts(_0x4cb92c){const [_0x16a804,_0x5e3abf,_0x380fcd]=_0x4cb92c['split']('.');if(_0x16a804===void 0x0||_0x5e3abf===void 0x0||_0x380fcd===void 0x0)return sn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x4760f3=ln(_0x5e3abf);return _0x4760f3?JSON['parse'](_0x4760f3):(sn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x719a4d){return sn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x719a4d==null?void 0x0:_0x719a4d['toString']()),null;}}function Cr(_0x3fba0d){const _0x11cbd1=Ts(_0x3fba0d);return m(_0x11cbd1,'internal-error'),m(typeof _0x11cbd1['exp']<'u','internal-error'),m(typeof _0x11cbd1['iat']<'u','internal-error'),Number(_0x11cbd1['exp'])-Number(_0x11cbd1['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ut(_0x44a681,_0x14c2ab,_0x4f0a5c=!0x1){if(_0x4f0a5c)return _0x14c2ab;try{return await _0x14c2ab;}catch(_0x252964){throw _0x252964 instanceof Se&&mf(_0x252964)&&_0x44a681['auth']['currentUser']===_0x44a681&&await _0x44a681['auth']['signOut'](),_0x252964;}}function mf({code:_0x4ac5c6}){return _0x4ac5c6==='auth/user-disabled'||_0x4ac5c6==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yf{constructor(_0x10c804){this['user']=_0x10c804,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0xada722){if(_0xada722){const _0x1624d3=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x1624d3;}else{this['errorBackoff']=0x7530;const _0x370268=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x370268);}}['schedule'](_0x507c27=!0x1){if(!this['isRunning'])return;const _0x48a7bf=this['getInterval'](_0x507c27);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x48a7bf);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x3c41d6){(_0x3c41d6==null?void 0x0:_0x3c41d6['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Oi{constructor(_0x509df2,_0xcfe8c5){this['createdAt']=_0x509df2,this['lastLoginAt']=_0xcfe8c5,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Rt(this['lastLoginAt']),this['creationTime']=Rt(this['createdAt']);}['_copy'](_0x13c743){this['createdAt']=_0x13c743['createdAt'],this['lastLoginAt']=_0x13c743['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Rn(_0x43fa95){var _0x275213;const _0x21853b=_0x43fa95['auth'],_0xf7d780=await _0x43fa95['getIdToken'](),_0x435bda=await Ut(_0x43fa95,bn(_0x21853b,{'idToken':_0xf7d780}));m(_0x435bda==null?void 0x0:_0x435bda['users']['length'],_0x21853b,'internal-error');const _0x2f0a73=_0x435bda['users'][0x0];_0x43fa95['_notifyReloadListener'](_0x2f0a73);const _0x2872bc=(_0x275213=_0x2f0a73['providerUserInfo'])!=null&&_0x275213['length']?Sa(_0x2f0a73['providerUserInfo']):[],_0x18293f=Ef(_0x43fa95['providerData'],_0x2872bc),_0x12dd75=_0x43fa95['isAnonymous'],_0x309dcf=!(_0x43fa95['email']&&_0x2f0a73['passwordHash'])&&!(_0x18293f!=null&&_0x18293f['length']),_0x21f7d3=_0x12dd75?_0x309dcf:!0x1,_0x510e20={'uid':_0x2f0a73['localId'],'displayName':_0x2f0a73['displayName']||null,'photoURL':_0x2f0a73['photoUrl']||null,'email':_0x2f0a73['email']||null,'emailVerified':_0x2f0a73['emailVerified']||!0x1,'phoneNumber':_0x2f0a73['phoneNumber']||null,'tenantId':_0x2f0a73['tenantId']||null,'providerData':_0x18293f,'metadata':new Oi(_0x2f0a73['createdAt'],_0x2f0a73['lastLoginAt']),'isAnonymous':_0x21f7d3};Object['assign'](_0x43fa95,_0x510e20);}async function vf(_0x3e88ec){const _0x5d2ab3=N(_0x3e88ec);await Rn(_0x5d2ab3),await _0x5d2ab3['auth']['_persistUserIfCurrent'](_0x5d2ab3),_0x5d2ab3['auth']['_notifyListenersIfCurrent'](_0x5d2ab3);}function Ef(_0x1aa957,_0x13f81e){return[..._0x1aa957['filter'](_0x580bde=>!_0x13f81e['some'](_0x2f0967=>_0x2f0967['providerId']===_0x580bde['providerId'])),..._0x13f81e];}function Sa(_0x557783){return _0x557783['map'](({providerId:_0x32384b,..._0x459433})=>({'providerId':_0x32384b,'uid':_0x459433['rawId']||'','displayName':_0x459433['displayName']||null,'email':_0x459433['email']||null,'phoneNumber':_0x459433['phoneNumber']||null,'photoURL':_0x459433['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function If(_0x551348,_0x5c9f05){const _0x399153=await Ca(_0x551348,{},async()=>{const _0x109369=ct({'grant_type':'refresh_token','refresh_token':_0x5c9f05})['slice'](0x1),{tokenApiHost:_0x33b959,apiKey:_0x3240ba}=_0x551348['config'],_0x444299=await Ta(_0x551348,_0x33b959,'/v1/token','key='+_0x3240ba),_0x1f0a72=await _0x551348['_getAdditionalHeaders']();_0x1f0a72['Content-Type']='application/x-www-form-urlencoded';const _0xdf3f7e={'method':'POST','headers':_0x1f0a72,'body':_0x109369};return _0x551348['emulatorConfig']&&at(_0x551348['emulatorConfig']['host'])&&(_0xdf3f7e['credentials']='include'),wa['fetch']()(_0x444299,_0xdf3f7e);});return{'accessToken':_0x399153['access_token'],'expiresIn':_0x399153['expires_in'],'refreshToken':_0x399153['refresh_token']};}async function wf(_0x442a22,_0x404ebc){return Ae(_0x442a22,'POST','/v2/accounts:revokeToken',Re(_0x442a22,_0x404ebc));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qe{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x3edf7d){m(_0x3edf7d['idToken'],'internal-error'),m(typeof _0x3edf7d['idToken']<'u','internal-error'),m(typeof _0x3edf7d['refreshToken']<'u','internal-error');const _0x2b2fe1='expiresIn'in _0x3edf7d&&typeof _0x3edf7d['expiresIn']<'u'?Number(_0x3edf7d['expiresIn']):Cr(_0x3edf7d['idToken']);this['updateTokensAndExpiration'](_0x3edf7d['idToken'],_0x3edf7d['refreshToken'],_0x2b2fe1);}['updateFromIdToken'](_0x2d68fe){m(_0x2d68fe['length']!==0x0,'internal-error');const _0xbc6ea6=Cr(_0x2d68fe);this['updateTokensAndExpiration'](_0x2d68fe,null,_0xbc6ea6);}async['getToken'](_0x36c6cd,_0x4f98de=!0x1){return!_0x4f98de&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x36c6cd,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x36c6cd,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0xbb2eed,_0x4e83ce){const {accessToken:_0x1d3a96,refreshToken:_0x571d93,expiresIn:_0x57ecd0}=await If(_0xbb2eed,_0x4e83ce);this['updateTokensAndExpiration'](_0x1d3a96,_0x571d93,Number(_0x57ecd0));}['updateTokensAndExpiration'](_0x17e87f,_0x5eb718,_0x4886bc){this['refreshToken']=_0x5eb718||null,this['accessToken']=_0x17e87f||null,this['expirationTime']=Date['now']()+_0x4886bc*0x3e8;}static['fromJSON'](_0xd29d3e,_0x381c9a){const {refreshToken:_0x5152fe,accessToken:_0x56385b,expirationTime:_0x538609}=_0x381c9a,_0x41fd42=new Qe();return _0x5152fe&&(m(typeof _0x5152fe=='string','internal-error',{'appName':_0xd29d3e}),_0x41fd42['refreshToken']=_0x5152fe),_0x56385b&&(m(typeof _0x56385b=='string','internal-error',{'appName':_0xd29d3e}),_0x41fd42['accessToken']=_0x56385b),_0x538609&&(m(typeof _0x538609=='number','internal-error',{'appName':_0xd29d3e}),_0x41fd42['expirationTime']=_0x538609),_0x41fd42;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x4cdbf8){this['accessToken']=_0x4cdbf8['accessToken'],this['refreshToken']=_0x4cdbf8['refreshToken'],this['expirationTime']=_0x4cdbf8['expirationTime'];}['_clone'](){return Object['assign'](new Qe(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x3ecb65,_0x2e3dd9){m(typeof _0x3ecb65=='string'||typeof _0x3ecb65>'u','internal-error',{'appName':_0x2e3dd9});}class K{constructor({uid:_0x5a7d97,auth:_0x215985,stsTokenManager:_0xf4c1c4,..._0x37bcaf}){this['providerId']='firebase',this['proactiveRefresh']=new yf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x5a7d97,this['auth']=_0x215985,this['stsTokenManager']=_0xf4c1c4,this['accessToken']=_0xf4c1c4['accessToken'],this['displayName']=_0x37bcaf['displayName']||null,this['email']=_0x37bcaf['email']||null,this['emailVerified']=_0x37bcaf['emailVerified']||!0x1,this['phoneNumber']=_0x37bcaf['phoneNumber']||null,this['photoURL']=_0x37bcaf['photoURL']||null,this['isAnonymous']=_0x37bcaf['isAnonymous']||!0x1,this['tenantId']=_0x37bcaf['tenantId']||null,this['providerData']=_0x37bcaf['providerData']?[..._0x37bcaf['providerData']]:[],this['metadata']=new Oi(_0x37bcaf['createdAt']||void 0x0,_0x37bcaf['lastLoginAt']||void 0x0);}async['getIdToken'](_0x300502){const _0x4d1d3d=await Ut(this,this['stsTokenManager']['getToken'](this['auth'],_0x300502));return m(_0x4d1d3d,this['auth'],'internal-error'),this['accessToken']!==_0x4d1d3d&&(this['accessToken']=_0x4d1d3d,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x4d1d3d;}['getIdTokenResult'](_0x13f964){return gf(this,_0x13f964);}['reload'](){return vf(this);}['_assign'](_0xfeb936){this!==_0xfeb936&&(m(this['uid']===_0xfeb936['uid'],this['auth'],'internal-error'),this['displayName']=_0xfeb936['displayName'],this['photoURL']=_0xfeb936['photoURL'],this['email']=_0xfeb936['email'],this['emailVerified']=_0xfeb936['emailVerified'],this['phoneNumber']=_0xfeb936['phoneNumber'],this['isAnonymous']=_0xfeb936['isAnonymous'],this['tenantId']=_0xfeb936['tenantId'],this['providerData']=_0xfeb936['providerData']['map'](_0x4d9646=>({..._0x4d9646})),this['metadata']['_copy'](_0xfeb936['metadata']),this['stsTokenManager']['_assign'](_0xfeb936['stsTokenManager']));}['_clone'](_0x1cae84){const _0x4a5960=new K({...this,'auth':_0x1cae84,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x4a5960['metadata']['_copy'](this['metadata']),_0x4a5960;}['_onReload'](_0xcaf469){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0xcaf469,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x290950){this['reloadListener']?this['reloadListener'](_0x290950):this['reloadUserInfo']=_0x290950;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x34fe62,_0x20a2e7=!0x1){let _0x394bd5=!0x1;_0x34fe62['idToken']&&_0x34fe62['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x34fe62),_0x394bd5=!0x0),_0x20a2e7&&await Rn(this),await this['auth']['_persistUserIfCurrent'](this),_0x394bd5&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x596905=await this['getIdToken']();return await Ut(this,_f(this['auth'],{'idToken':_0x596905})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x45d4b2=>({..._0x45d4b2})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x12a78e,_0xaf8c98){const _0x20883d=_0xaf8c98['displayName']??void 0x0,_0x5c624a=_0xaf8c98['email']??void 0x0,_0x3c6df4=_0xaf8c98['phoneNumber']??void 0x0,_0x195408=_0xaf8c98['photoURL']??void 0x0,_0x348639=_0xaf8c98['tenantId']??void 0x0,_0x1e33f2=_0xaf8c98['_redirectEventId']??void 0x0,_0x2c260d=_0xaf8c98['createdAt']??void 0x0,_0x2cb717=_0xaf8c98['lastLoginAt']??void 0x0,{uid:_0x35448b,emailVerified:_0x255e53,isAnonymous:_0x1b28b9,providerData:_0x3fab04,stsTokenManager:_0x48056f}=_0xaf8c98;m(_0x35448b&&_0x48056f,_0x12a78e,'internal-error');const _0xf6fb3f=Qe['fromJSON'](this['name'],_0x48056f);m(typeof _0x35448b=='string',_0x12a78e,'internal-error'),le(_0x20883d,_0x12a78e['name']),le(_0x5c624a,_0x12a78e['name']),m(typeof _0x255e53=='boolean',_0x12a78e,'internal-error'),m(typeof _0x1b28b9=='boolean',_0x12a78e,'internal-error'),le(_0x3c6df4,_0x12a78e['name']),le(_0x195408,_0x12a78e['name']),le(_0x348639,_0x12a78e['name']),le(_0x1e33f2,_0x12a78e['name']),le(_0x2c260d,_0x12a78e['name']),le(_0x2cb717,_0x12a78e['name']);const _0xf677ea=new K({'uid':_0x35448b,'auth':_0x12a78e,'email':_0x5c624a,'emailVerified':_0x255e53,'displayName':_0x20883d,'isAnonymous':_0x1b28b9,'photoURL':_0x195408,'phoneNumber':_0x3c6df4,'tenantId':_0x348639,'stsTokenManager':_0xf6fb3f,'createdAt':_0x2c260d,'lastLoginAt':_0x2cb717});return _0x3fab04&&Array['isArray'](_0x3fab04)&&(_0xf677ea['providerData']=_0x3fab04['map'](_0x2b35c4=>({..._0x2b35c4}))),_0x1e33f2&&(_0xf677ea['_redirectEventId']=_0x1e33f2),_0xf677ea;}static async['_fromIdTokenResponse'](_0xf4c3d5,_0x3ae02e,_0x596837=!0x1){const _0x1a8ce7=new Qe();_0x1a8ce7['updateFromServerResponse'](_0x3ae02e);const _0x507fe5=new K({'uid':_0x3ae02e['localId'],'auth':_0xf4c3d5,'stsTokenManager':_0x1a8ce7,'isAnonymous':_0x596837});return await Rn(_0x507fe5),_0x507fe5;}static async['_fromGetAccountInfoResponse'](_0xc3c867,_0x267612,_0x42cf51){const _0x58f252=_0x267612['users'][0x0];m(_0x58f252['localId']!==void 0x0,'internal-error');const _0x466f7b=_0x58f252['providerUserInfo']!==void 0x0?Sa(_0x58f252['providerUserInfo']):[],_0x37cdf9=!(_0x58f252['email']&&_0x58f252['passwordHash'])&&!(_0x466f7b!=null&&_0x466f7b['length']),_0x153991=new Qe();_0x153991['updateFromIdToken'](_0x42cf51);const _0x340822=new K({'uid':_0x58f252['localId'],'auth':_0xc3c867,'stsTokenManager':_0x153991,'isAnonymous':_0x37cdf9}),_0x5d84e5={'uid':_0x58f252['localId'],'displayName':_0x58f252['displayName']||null,'photoURL':_0x58f252['photoUrl']||null,'email':_0x58f252['email']||null,'emailVerified':_0x58f252['emailVerified']||!0x1,'phoneNumber':_0x58f252['phoneNumber']||null,'tenantId':_0x58f252['tenantId']||null,'providerData':_0x466f7b,'metadata':new Oi(_0x58f252['createdAt'],_0x58f252['lastLoginAt']),'isAnonymous':!(_0x58f252['email']&&_0x58f252['passwordHash'])&&!(_0x466f7b!=null&&_0x466f7b['length'])};return Object['assign'](_0x340822,_0x5d84e5),_0x340822;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0xba907b){ce(_0xba907b instanceof Function,'Expected\x20a\x20class\x20definition');let _0x13fc45=Tr['get'](_0xba907b);return _0x13fc45?(ce(_0x13fc45 instanceof _0xba907b,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x13fc45):(_0x13fc45=new _0xba907b(),Tr['set'](_0xba907b,_0x13fc45),_0x13fc45);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x3a5ba3,_0x2cce75){this['storage'][_0x3a5ba3]=_0x2cce75;}async['_get'](_0x46206f){const _0x177711=this['storage'][_0x46206f];return _0x177711===void 0x0?null:_0x177711;}async['_remove'](_0x1573fb){delete this['storage'][_0x1573fb];}['_addListener'](_0x45de52,_0xf012da){}['_removeListener'](_0x43a64b,_0x2922e8){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rn(_0x7f8847,_0x496c6a,_0x23ead8){return'firebase:'+_0x7f8847+':'+_0x496c6a+':'+_0x23ead8;}class Je{constructor(_0x209e2b,_0x53a2a2,_0x36a4a0){this['persistence']=_0x209e2b,this['auth']=_0x53a2a2,this['userKey']=_0x36a4a0;const {config:_0x1550f0,name:_0x23b764}=this['auth'];this['fullUserKey']=rn(this['userKey'],_0x1550f0['apiKey'],_0x23b764),this['fullPersistenceKey']=rn('persistence',_0x1550f0['apiKey'],_0x23b764),this['boundEventHandler']=_0x53a2a2['_onStorageEvent']['bind'](_0x53a2a2),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x1dce24){return this['persistence']['_set'](this['fullUserKey'],_0x1dce24['toJSON']());}async['getCurrentUser'](){const _0x83ac0c=await this['persistence']['_get'](this['fullUserKey']);if(!_0x83ac0c)return null;if(typeof _0x83ac0c=='string'){const _0x3b9e62=await bn(this['auth'],{'idToken':_0x83ac0c})['catch'](()=>{});return _0x3b9e62?K['_fromGetAccountInfoResponse'](this['auth'],_0x3b9e62,_0x83ac0c):null;}return K['_fromJSON'](this['auth'],_0x83ac0c);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x179765){if(this['persistence']===_0x179765)return;const _0x5ec13c=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x179765,_0x5ec13c)return this['setCurrentUser'](_0x5ec13c);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x237915,_0xdcb292,_0x32b1a8='authUser'){if(!_0xdcb292['length'])return new Je(ie(Sr),_0x237915,_0x32b1a8);const _0x511ff5=(await Promise['all'](_0xdcb292['map'](async _0x50d9d7=>{if(await _0x50d9d7['_isAvailable']())return _0x50d9d7;})))['filter'](_0x109f01=>_0x109f01);let _0x2eff82=_0x511ff5[0x0]||ie(Sr);const _0x3e4eca=rn(_0x32b1a8,_0x237915['config']['apiKey'],_0x237915['name']);let _0x11ef53=null;for(const _0xc4b788 of _0xdcb292)try{const _0x3ef198=await _0xc4b788['_get'](_0x3e4eca);if(_0x3ef198){let _0x1eccef;if(typeof _0x3ef198=='string'){const _0x1dad56=await bn(_0x237915,{'idToken':_0x3ef198})['catch'](()=>{});if(!_0x1dad56)break;_0x1eccef=await K['_fromGetAccountInfoResponse'](_0x237915,_0x1dad56,_0x3ef198);}else _0x1eccef=K['_fromJSON'](_0x237915,_0x3ef198);_0xc4b788!==_0x2eff82&&(_0x11ef53=_0x1eccef),_0x2eff82=_0xc4b788;break;}}catch{}const _0x38eaed=_0x511ff5['filter'](_0xf67105=>_0xf67105['_shouldAllowMigration']);return!_0x2eff82['_shouldAllowMigration']||!_0x38eaed['length']?new Je(_0x2eff82,_0x237915,_0x32b1a8):(_0x2eff82=_0x38eaed[0x0],_0x11ef53&&await _0x2eff82['_set'](_0x3e4eca,_0x11ef53['toJSON']()),await Promise['all'](_0xdcb292['map'](async _0x4f8af8=>{if(_0x4f8af8!==_0x2eff82)try{await _0x4f8af8['_remove'](_0x3e4eca);}catch{}})),new Je(_0x2eff82,_0x237915,_0x32b1a8));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x4512ae){const _0x13cf96=_0x4512ae['toLowerCase']();if(_0x13cf96['includes']('opera/')||_0x13cf96['includes']('opr/')||_0x13cf96['includes']('opios/'))return'Opera';if(Na(_0x13cf96))return'IEMobile';if(_0x13cf96['includes']('msie')||_0x13cf96['includes']('trident/'))return'IE';if(_0x13cf96['includes']('edge/'))return'Edge';if(Ra(_0x13cf96))return'Firefox';if(_0x13cf96['includes']('silk/'))return'Silk';if(Oa(_0x13cf96))return'Blackberry';if(Da(_0x13cf96))return'Webos';if(Aa(_0x13cf96))return'Safari';if((_0x13cf96['includes']('chrome/')||ka(_0x13cf96))&&!_0x13cf96['includes']('edge/'))return'Chrome';if(Pa(_0x13cf96))return'Android';{const _0x34a2ed=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x57c26a=_0x4512ae['match'](_0x34a2ed);if((_0x57c26a==null?void 0x0:_0x57c26a['length'])===0x2)return _0x57c26a[0x1];}return'Other';}function Ra(_0x3e865b=W()){return/firefox\//i['test'](_0x3e865b);}function Aa(_0x3fa6d9=W()){const _0x2c7bd2=_0x3fa6d9['toLowerCase']();return _0x2c7bd2['includes']('safari/')&&!_0x2c7bd2['includes']('chrome/')&&!_0x2c7bd2['includes']('crios/')&&!_0x2c7bd2['includes']('android');}function ka(_0xa5eceb=W()){return/crios\//i['test'](_0xa5eceb);}function Na(_0x4468db=W()){return/iemobile/i['test'](_0x4468db);}function Pa(_0x533b97=W()){return/android/i['test'](_0x533b97);}function Oa(_0x516ad7=W()){return/blackberry/i['test'](_0x516ad7);}function Da(_0x4d4647=W()){return/webos/i['test'](_0x4d4647);}function Ss(_0x5aabd9=W()){return/iphone|ipad|ipod/i['test'](_0x5aabd9)||/macintosh/i['test'](_0x5aabd9)&&/mobile/i['test'](_0x5aabd9);}function Cf(_0x40ce49=W()){var _0x24451c;return Ss(_0x40ce49)&&!!((_0x24451c=window['navigator'])!=null&&_0x24451c['standalone']);}function Tf(){return pc()&&document['documentMode']===0xa;}function Ma(_0x228b39=W()){return Ss(_0x228b39)||Pa(_0x228b39)||Da(_0x228b39)||Oa(_0x228b39)||/windows phone/i['test'](_0x228b39)||Na(_0x228b39);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x309673,_0x4d17fc=[]){let _0x5a8d85;switch(_0x309673){case'Browser':_0x5a8d85=br(W());break;case'Worker':_0x5a8d85=br(W())+'-'+_0x309673;break;default:_0x5a8d85=_0x309673;}const _0x5d95c1=_0x4d17fc['length']?_0x4d17fc['join'](','):'FirebaseCore-web';return _0x5a8d85+'/JsCore/'+lt+'/'+_0x5d95c1;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sf{constructor(_0x125491){this['auth']=_0x125491,this['queue']=[];}['pushCallback'](_0x4caedd,_0x209843){const _0x18fa65=_0x1b5601=>new Promise((_0x4c908b,_0x45c2b4)=>{try{const _0x431f94=_0x4caedd(_0x1b5601);_0x4c908b(_0x431f94);}catch(_0x7d25){_0x45c2b4(_0x7d25);}});_0x18fa65['onAbort']=_0x209843,this['queue']['push'](_0x18fa65);const _0x26f4f3=this['queue']['length']-0x1;return()=>{this['queue'][_0x26f4f3]=()=>Promise['resolve']();};}async['runMiddleware'](_0x295e34){if(this['auth']['currentUser']===_0x295e34)return;const _0xc3c63b=[];try{for(const _0x2fe7af of this['queue'])await _0x2fe7af(_0x295e34),_0x2fe7af['onAbort']&&_0xc3c63b['push'](_0x2fe7af['onAbort']);}catch(_0x181ba7){_0xc3c63b['reverse']();for(const _0x52ff6b of _0xc3c63b)try{_0x52ff6b();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x181ba7==null?void 0x0:_0x181ba7['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bf(_0x21dcb6,_0xcf6f93={}){return Ae(_0x21dcb6,'GET','/v2/passwordPolicy',Re(_0x21dcb6,_0xcf6f93));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rf=0x6;class Af{constructor(_0x35a094){var _0x2e2168;const _0x543329=_0x35a094['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x543329['minPasswordLength']??Rf,_0x543329['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x543329['maxPasswordLength']),_0x543329['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x543329['containsLowercaseCharacter']),_0x543329['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x543329['containsUppercaseCharacter']),_0x543329['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x543329['containsNumericCharacter']),_0x543329['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x543329['containsNonAlphanumericCharacter']),this['enforcementState']=_0x35a094['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x2e2168=_0x35a094['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x2e2168['join'](''))??'',this['forceUpgradeOnSignin']=_0x35a094['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x35a094['schemaVersion'];}['validatePassword'](_0x34dcc3){const _0x3bd894={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x34dcc3,_0x3bd894),this['validatePasswordCharacterOptions'](_0x34dcc3,_0x3bd894),_0x3bd894['isValid']&&(_0x3bd894['isValid']=_0x3bd894['meetsMinPasswordLength']??!0x0),_0x3bd894['isValid']&&(_0x3bd894['isValid']=_0x3bd894['meetsMaxPasswordLength']??!0x0),_0x3bd894['isValid']&&(_0x3bd894['isValid']=_0x3bd894['containsLowercaseLetter']??!0x0),_0x3bd894['isValid']&&(_0x3bd894['isValid']=_0x3bd894['containsUppercaseLetter']??!0x0),_0x3bd894['isValid']&&(_0x3bd894['isValid']=_0x3bd894['containsNumericCharacter']??!0x0),_0x3bd894['isValid']&&(_0x3bd894['isValid']=_0x3bd894['containsNonAlphanumericCharacter']??!0x0),_0x3bd894;}['validatePasswordLengthOptions'](_0x388af0,_0x1d152a){const _0x4306f0=this['customStrengthOptions']['minPasswordLength'],_0x536ce0=this['customStrengthOptions']['maxPasswordLength'];_0x4306f0&&(_0x1d152a['meetsMinPasswordLength']=_0x388af0['length']>=_0x4306f0),_0x536ce0&&(_0x1d152a['meetsMaxPasswordLength']=_0x388af0['length']<=_0x536ce0);}['validatePasswordCharacterOptions'](_0x283982,_0x202dba){this['updatePasswordCharacterOptionsStatuses'](_0x202dba,!0x1,!0x1,!0x1,!0x1);let _0x1945bc;for(let _0x353485=0x0;_0x353485<_0x283982['length'];_0x353485++)_0x1945bc=_0x283982['charAt'](_0x353485),this['updatePasswordCharacterOptionsStatuses'](_0x202dba,_0x1945bc>='a'&&_0x1945bc<='z',_0x1945bc>='A'&&_0x1945bc<='Z',_0x1945bc>='0'&&_0x1945bc<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x1945bc));}['updatePasswordCharacterOptionsStatuses'](_0xacc92d,_0x37bcee,_0x2bd0da,_0x5401ec,_0x6ca93c){this['customStrengthOptions']['containsLowercaseLetter']&&(_0xacc92d['containsLowercaseLetter']||(_0xacc92d['containsLowercaseLetter']=_0x37bcee)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0xacc92d['containsUppercaseLetter']||(_0xacc92d['containsUppercaseLetter']=_0x2bd0da)),this['customStrengthOptions']['containsNumericCharacter']&&(_0xacc92d['containsNumericCharacter']||(_0xacc92d['containsNumericCharacter']=_0x5401ec)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0xacc92d['containsNonAlphanumericCharacter']||(_0xacc92d['containsNonAlphanumericCharacter']=_0x6ca93c));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x14ea1d,_0x144041,_0x255678,_0x492b4c){this['app']=_0x14ea1d,this['heartbeatServiceProvider']=_0x144041,this['appCheckServiceProvider']=_0x255678,this['config']=_0x492b4c,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new Sf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x14ea1d['name'],this['clientVersion']=_0x492b4c['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x1080b1=>this['_resolvePersistenceManagerAvailable']=_0x1080b1);}['_initializeWithPersistence'](_0x563b95,_0x42738c){return _0x42738c&&(this['_popupRedirectResolver']=ie(_0x42738c)),this['_initializationPromise']=this['queue'](async()=>{var _0x51da9c,_0x24ecc1,_0x15db1a;if(!this['_deleted']&&(this['persistenceManager']=await Je['create'](this,_0x563b95),(_0x51da9c=this['_resolvePersistenceManagerAvailable'])==null||_0x51da9c['call'](this),!this['_deleted'])){if((_0x24ecc1=this['_popupRedirectResolver'])!=null&&_0x24ecc1['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x42738c),this['lastNotifiedUid']=((_0x15db1a=this['currentUser'])==null?void 0x0:_0x15db1a['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x4125df=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x4125df)){if(this['currentUser']&&_0x4125df&&this['currentUser']['uid']===_0x4125df['uid']){this['_currentUser']['_assign'](_0x4125df),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x4125df,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x54f01d){try{const _0x4bd9b0=await bn(this,{'idToken':_0x54f01d}),_0x222b0b=await K['_fromGetAccountInfoResponse'](this,_0x4bd9b0,_0x54f01d);await this['directlySetCurrentUser'](_0x222b0b);}catch(_0x5e1faf){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x5e1faf),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x377bcc){var _0x28402d;if($(this['app'])){const _0x358a6e=this['app']['settings']['authIdToken'];return _0x358a6e?new Promise(_0x2f9f0e=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x358a6e)['then'](_0x2f9f0e,_0x2f9f0e));}):this['directlySetCurrentUser'](null);}const _0x3e2dc8=await this['assertedPersistence']['getCurrentUser']();let _0x3495fa=_0x3e2dc8,_0x346f65=!0x1;if(_0x377bcc&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x196917=(_0x28402d=this['redirectUser'])==null?void 0x0:_0x28402d['_redirectEventId'],_0xb89989=_0x3495fa==null?void 0x0:_0x3495fa['_redirectEventId'],_0x55a267=await this['tryRedirectSignIn'](_0x377bcc);(!_0x196917||_0x196917===_0xb89989)&&(_0x55a267!=null&&_0x55a267['user'])&&(_0x3495fa=_0x55a267['user'],_0x346f65=!0x0);}if(!_0x3495fa)return this['directlySetCurrentUser'](null);if(!_0x3495fa['_redirectEventId']){if(_0x346f65)try{await this['beforeStateQueue']['runMiddleware'](_0x3495fa);}catch(_0x1a44c3){_0x3495fa=_0x3e2dc8,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x1a44c3));}return _0x3495fa?this['reloadAndSetCurrentUserOrClear'](_0x3495fa):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x3495fa['_redirectEventId']?this['directlySetCurrentUser'](_0x3495fa):this['reloadAndSetCurrentUserOrClear'](_0x3495fa);}async['tryRedirectSignIn'](_0x24b0ec){let _0x5f0daf=null;try{_0x5f0daf=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x24b0ec,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x5f0daf;}async['reloadAndSetCurrentUserOrClear'](_0x118460){try{await Rn(_0x118460);}catch(_0x59422e){if((_0x59422e==null?void 0x0:_0x59422e['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x118460);}['useDeviceLanguage'](){this['languageCode']=af();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x44b975){if($(this['app']))return Promise['reject'](re(this));const _0x319b64=_0x44b975?N(_0x44b975):null;return _0x319b64&&m(_0x319b64['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x319b64&&_0x319b64['_clone'](this));}async['_updateCurrentUser'](_0x1affde,_0x3852a2=!0x1){if(!this['_deleted'])return _0x1affde&&m(this['tenantId']===_0x1affde['tenantId'],this,'tenant-id-mismatch'),_0x3852a2||await this['beforeStateQueue']['runMiddleware'](_0x1affde),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x1affde),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x4d8196){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x4d8196));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x5792c1){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0xd6ec0f=this['_getPasswordPolicyInternal']();return _0xd6ec0f['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0xd6ec0f['validatePassword'](_0x5792c1);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x1c31cb=await bf(this),_0x4807c9=new Af(_0x1c31cb);this['tenantId']===null?this['_projectPasswordPolicy']=_0x4807c9:this['_tenantPasswordPolicies'][this['tenantId']]=_0x4807c9;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x26686c){this['_errorFactory']=new Bt('auth','Firebase',_0x26686c());}['onAuthStateChanged'](_0x21dc42,_0x3d0bd8,_0x4beb2c){return this['registerStateListener'](this['authStateSubscription'],_0x21dc42,_0x3d0bd8,_0x4beb2c);}['beforeAuthStateChanged'](_0x58534e,_0x57a121){return this['beforeStateQueue']['pushCallback'](_0x58534e,_0x57a121);}['onIdTokenChanged'](_0x346e9e,_0x4de533,_0x2eb075){return this['registerStateListener'](this['idTokenSubscription'],_0x346e9e,_0x4de533,_0x2eb075);}['authStateReady'](){return new Promise((_0x48642e,_0x36dccc)=>{if(this['currentUser'])_0x48642e();else{const _0x3c4bfb=this['onAuthStateChanged'](()=>{_0x3c4bfb(),_0x48642e();},_0x36dccc);}});}async['revokeAccessToken'](_0x30bb90){if(this['currentUser']){const _0x348a37=await this['currentUser']['getIdToken'](),_0x214d70={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x30bb90,'idToken':_0x348a37};this['tenantId']!=null&&(_0x214d70['tenantId']=this['tenantId']),await wf(this,_0x214d70);}}['toJSON'](){var _0x3f6a97;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x3f6a97=this['_currentUser'])==null?void 0x0:_0x3f6a97['toJSON']()};}async['_setRedirectUser'](_0xb548bd,_0x49d5a3){const _0x1bcf22=await this['getOrInitRedirectPersistenceManager'](_0x49d5a3);return _0xb548bd===null?_0x1bcf22['removeCurrentUser']():_0x1bcf22['setCurrentUser'](_0xb548bd);}async['getOrInitRedirectPersistenceManager'](_0x480a44){if(!this['redirectPersistenceManager']){const _0x1fa3c2=_0x480a44&&ie(_0x480a44)||this['_popupRedirectResolver'];m(_0x1fa3c2,this,'argument-error'),this['redirectPersistenceManager']=await Je['create'](this,[ie(_0x1fa3c2['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x88479f){var _0x1619f4,_0x4c1ceb;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x1619f4=this['_currentUser'])==null?void 0x0:_0x1619f4['_redirectEventId'])===_0x88479f?this['_currentUser']:((_0x4c1ceb=this['redirectUser'])==null?void 0x0:_0x4c1ceb['_redirectEventId'])===_0x88479f?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x24e804){if(_0x24e804===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x24e804));}['_notifyListenersIfCurrent'](_0x1d439a){_0x1d439a===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x325fd5;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x396cc4=((_0x325fd5=this['currentUser'])==null?void 0x0:_0x325fd5['uid'])??null;this['lastNotifiedUid']!==_0x396cc4&&(this['lastNotifiedUid']=_0x396cc4,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x28f770,_0x4d72c8,_0x5a57c7,_0x2c65f1){if(this['_deleted'])return()=>{};const _0x4db940=typeof _0x4d72c8=='function'?_0x4d72c8:_0x4d72c8['next']['bind'](_0x4d72c8);let _0x2ef8b6=!0x1;const _0xa595e8=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0xa595e8,this,'internal-error'),_0xa595e8['then'](()=>{_0x2ef8b6||_0x4db940(this['currentUser']);}),typeof _0x4d72c8=='function'){const _0x6651df=_0x28f770['addObserver'](_0x4d72c8,_0x5a57c7,_0x2c65f1);return()=>{_0x2ef8b6=!0x0,_0x6651df();};}else{const _0x55a08e=_0x28f770['addObserver'](_0x4d72c8);return()=>{_0x2ef8b6=!0x0,_0x55a08e();};}}async['directlySetCurrentUser'](_0xc72365){this['currentUser']&&this['currentUser']!==_0xc72365&&this['_currentUser']['_stopProactiveRefresh'](),_0xc72365&&this['isProactiveRefreshEnabled']&&_0xc72365['_startProactiveRefresh'](),this['currentUser']=_0xc72365,_0xc72365?await this['assertedPersistence']['setCurrentUser'](_0xc72365):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x13b034){return this['operations']=this['operations']['then'](_0x13b034,_0x13b034),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x1bc34a){!_0x1bc34a||this['frameworks']['includes'](_0x1bc34a)||(this['frameworks']['push'](_0x1bc34a),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x55fcde;const _0x3a209c={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x3a209c['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x3a0630=await((_0x55fcde=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x55fcde['getHeartbeatsHeader']());_0x3a0630&&(_0x3a209c['X-Firebase-Client']=_0x3a0630);const _0x427dc3=await this['_getAppCheckToken']();return _0x427dc3&&(_0x3a209c['X-Firebase-AppCheck']=_0x427dc3),_0x3a209c;}async['_getAppCheckToken'](){var _0x458e37;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x2a46f7=await((_0x458e37=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x458e37['getToken']());return _0x2a46f7!=null&&_0x2a46f7['error']&&sf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x2a46f7['error']),_0x2a46f7==null?void 0x0:_0x2a46f7['token'];}}function qe(_0x1b9317){return N(_0x1b9317);}class Rr{constructor(_0x497827){this['auth']=_0x497827,this['observer']=null,this['addObserver']=Tc(_0x52a7dc=>this['observer']=_0x52a7dc);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Nf(_0x2522ea){jn=_0x2522ea;}function xa(_0x1df2c6){return jn['loadJS'](_0x1df2c6);}function Pf(){return jn['recaptchaEnterpriseScript'];}function Of(){return jn['gapiScript'];}function Df(_0xe8b163){return'__'+_0xe8b163+Math['floor'](Math['random']()*0xf4240);}class Mf{constructor(){this['enterprise']=new Lf();}['ready'](_0x1bdd5d){_0x1bdd5d();}['execute'](_0x4399e9,_0x1f162b){return Promise['resolve']('token');}['render'](_0x5dfe5c,_0xddb72f){return'';}}class Lf{['ready'](_0xac3fcf){_0xac3fcf();}['execute'](_0x3a3eb2,_0x4ed52a){return Promise['resolve']('token');}['render'](_0x1e9077,_0x1c303f){return'';}}const xf='recaptcha-enterprise',Fa='NO_RECAPTCHA';class Ff{constructor(_0x3194e8){this['type']=xf,this['auth']=qe(_0x3194e8);}async['verify'](_0x23466e='verify',_0x2a1f1e=!0x1){async function _0x2e336f(_0x4d772a){if(!_0x2a1f1e){if(_0x4d772a['tenantId']==null&&_0x4d772a['_agentRecaptchaConfig']!=null)return _0x4d772a['_agentRecaptchaConfig']['siteKey'];if(_0x4d772a['tenantId']!=null&&_0x4d772a['_tenantRecaptchaConfigs'][_0x4d772a['tenantId']]!==void 0x0)return _0x4d772a['_tenantRecaptchaConfigs'][_0x4d772a['tenantId']]['siteKey'];}return new Promise(async(_0x1b0e24,_0x25f7e0)=>{pf(_0x4d772a,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x4f5c6a=>{if(_0x4f5c6a['recaptchaKey']===void 0x0)_0x25f7e0(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x3d1e55=new ff(_0x4f5c6a);return _0x4d772a['tenantId']==null?_0x4d772a['_agentRecaptchaConfig']=_0x3d1e55:_0x4d772a['_tenantRecaptchaConfigs'][_0x4d772a['tenantId']]=_0x3d1e55,_0x1b0e24(_0x3d1e55['siteKey']);}})['catch'](_0x4f37cf=>{_0x25f7e0(_0x4f37cf);});});}function _0x56c6a4(_0x43a4ab,_0x15011d,_0xe316a7){const _0x2e6777=window['grecaptcha'];wr(_0x2e6777)?_0x2e6777['enterprise']['ready'](()=>{_0x2e6777['enterprise']['execute'](_0x43a4ab,{'action':_0x23466e})['then'](_0x307852=>{_0x15011d(_0x307852);})['catch'](()=>{_0x15011d(Fa);});}):_0xe316a7(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Mf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x281a23,_0x166d36)=>{_0x2e336f(this['auth'])['then'](_0x2a6b3b=>{if(!_0x2a1f1e&&wr(window['grecaptcha']))_0x56c6a4(_0x2a6b3b,_0x281a23,_0x166d36);else{if(typeof window>'u'){_0x166d36(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0xfe5bd=Pf();_0xfe5bd['length']!==0x0&&(_0xfe5bd+=_0x2a6b3b),xa(_0xfe5bd)['then'](()=>{_0x56c6a4(_0x2a6b3b,_0x281a23,_0x166d36);})['catch'](_0x3bb643=>{_0x166d36(_0x3bb643);});}})['catch'](_0x145069=>{_0x166d36(_0x145069);});});}}async function Ar(_0x25125b,_0x421047,_0x1d92d5,_0x57b31b=!0x1,_0x3154f7=!0x1){const _0x44edcd=new Ff(_0x25125b);let _0x36d289;if(_0x3154f7)_0x36d289=Fa;else try{_0x36d289=await _0x44edcd['verify'](_0x1d92d5);}catch{_0x36d289=await _0x44edcd['verify'](_0x1d92d5,!0x0);}const _0x433fb4={..._0x421047};if(_0x1d92d5==='mfaSmsEnrollment'||_0x1d92d5==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x433fb4){const _0x1ee01f=_0x433fb4['phoneEnrollmentInfo']['phoneNumber'],_0x372e8c=_0x433fb4['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x433fb4,{'phoneEnrollmentInfo':{'phoneNumber':_0x1ee01f,'recaptchaToken':_0x372e8c,'captchaResponse':_0x36d289,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x433fb4){const _0x349b2c=_0x433fb4['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x433fb4,{'phoneSignInInfo':{'recaptchaToken':_0x349b2c,'captchaResponse':_0x36d289,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x433fb4;}return _0x57b31b?Object['assign'](_0x433fb4,{'captchaResp':_0x36d289}):Object['assign'](_0x433fb4,{'captchaResponse':_0x36d289}),Object['assign'](_0x433fb4,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x433fb4,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x433fb4;}async function Di(_0x6c9732,_0xdd8084,_0xbd31ae,_0x17370c,_0x8ca93a){var _0xc665fd;if((_0xc665fd=_0x6c9732['_getRecaptchaConfig']())!=null&&_0xc665fd['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x15df68=await Ar(_0x6c9732,_0xdd8084,_0xbd31ae,_0xbd31ae==='getOobCode');return _0x17370c(_0x6c9732,_0x15df68);}else return _0x17370c(_0x6c9732,_0xdd8084)['catch'](async _0x5dc470=>{if(_0x5dc470['code']==='auth/missing-recaptcha-token'){console['log'](_0xbd31ae+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0xffea3e=await Ar(_0x6c9732,_0xdd8084,_0xbd31ae,_0xbd31ae==='getOobCode');return _0x17370c(_0x6c9732,_0xffea3e);}else return Promise['reject'](_0x5dc470);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Uf(_0x3bccef,_0x2a0eb9){const _0x4fa0cf=Bi(_0x3bccef,'auth');if(_0x4fa0cf['isInitialized']()){const _0x554689=_0x4fa0cf['getImmediate'](),_0x20275b=_0x4fa0cf['getOptions']();if(Me(_0x20275b,_0x2a0eb9??{}))return _0x554689;Q(_0x554689,'already-initialized');}return _0x4fa0cf['initialize']({'options':_0x2a0eb9});}function Wf(_0x3efc79,_0x266dbd){const _0x51ca7c=(_0x266dbd==null?void 0x0:_0x266dbd['persistence'])||[],_0x1ebdf5=(Array['isArray'](_0x51ca7c)?_0x51ca7c:[_0x51ca7c])['map'](ie);_0x266dbd!=null&&_0x266dbd['errorMap']&&_0x3efc79['_updateErrorMap'](_0x266dbd['errorMap']),_0x3efc79['_initializeWithPersistence'](_0x1ebdf5,_0x266dbd==null?void 0x0:_0x266dbd['popupRedirectResolver']);}function Bf(_0x2191cc,_0x4eda85,_0x1830bc){const _0x152841=qe(_0x2191cc);m(/^https?:\/\//['test'](_0x4eda85),_0x152841,'invalid-emulator-scheme');const _0x1003c9=!0x1,_0xcaff74=Ua(_0x4eda85),{host:_0x40c72b,port:_0x12618d}=Vf(_0x4eda85),_0x509b7d=_0x12618d===null?'':':'+_0x12618d,_0x5da62d={'url':_0xcaff74+'//'+_0x40c72b+_0x509b7d+'/'},_0x318a43=Object['freeze']({'host':_0x40c72b,'port':_0x12618d,'protocol':_0xcaff74['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x1003c9})});if(!_0x152841['_canInitEmulator']){m(_0x152841['config']['emulator']&&_0x152841['emulatorConfig'],_0x152841,'emulator-config-failed'),m(Me(_0x5da62d,_0x152841['config']['emulator'])&&Me(_0x318a43,_0x152841['emulatorConfig']),_0x152841,'emulator-config-failed');return;}_0x152841['config']['emulator']=_0x5da62d,_0x152841['emulatorConfig']=_0x318a43,_0x152841['settings']['appVerificationDisabledForTesting']=!0x0,at(_0x40c72b)?(jr(_0xcaff74+'//'+_0x40c72b+_0x509b7d),Kr('Auth',!0x0)):Hf();}function Ua(_0x530aa9){const _0xa50b0f=_0x530aa9['indexOf'](':');return _0xa50b0f<0x0?'':_0x530aa9['substr'](0x0,_0xa50b0f+0x1);}function Vf(_0xd75bc2){const _0x32c505=Ua(_0xd75bc2),_0x4d630b=/(\/\/)?([^?#/]+)/['exec'](_0xd75bc2['substr'](_0x32c505['length']));if(!_0x4d630b)return{'host':'','port':null};const _0x2a91d6=_0x4d630b[0x2]['split']('@')['pop']()||'',_0x320b8f=/^(\[[^\]]+\])(:|$)/['exec'](_0x2a91d6);if(_0x320b8f){const _0x51fbe1=_0x320b8f[0x1];return{'host':_0x51fbe1,'port':kr(_0x2a91d6['substr'](_0x51fbe1['length']+0x1))};}else{const [_0x4f57f3,_0x2b1007]=_0x2a91d6['split'](':');return{'host':_0x4f57f3,'port':kr(_0x2b1007)};}}function kr(_0x1ba3ec){if(!_0x1ba3ec)return null;const _0x35dc93=Number(_0x1ba3ec);return isNaN(_0x35dc93)?null:_0x35dc93;}function Hf(){function _0x1f681e(){const _0x19123c=document['createElement']('p'),_0x2a6e04=_0x19123c['style'];_0x19123c['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x2a6e04['position']='fixed',_0x2a6e04['width']='100%',_0x2a6e04['backgroundColor']='#ffffff',_0x2a6e04['border']='.1em\x20solid\x20#000000',_0x2a6e04['color']='#b50000',_0x2a6e04['bottom']='0px',_0x2a6e04['left']='0px',_0x2a6e04['margin']='0px',_0x2a6e04['zIndex']='10000',_0x2a6e04['textAlign']='center',_0x19123c['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x19123c);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x1f681e):_0x1f681e());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x41a7e6,_0x330d79){this['providerId']=_0x41a7e6,this['signInMethod']=_0x330d79;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x1b0a8a){return ne('not\x20implemented');}['_linkToIdToken'](_0x327b2d,_0x171036){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x2b2252){return ne('not\x20implemented');}}async function $f(_0x454112,_0x1f9e56){return Ae(_0x454112,'POST','/v1/accounts:signUp',_0x1f9e56);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Gf(_0x36d697,_0x4ee65e){return Qt(_0x36d697,'POST','/v1/accounts:signInWithPassword',Re(_0x36d697,_0x4ee65e));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function qf(_0x258dfa,_0x1ce541){return Qt(_0x258dfa,'POST','/v1/accounts:signInWithEmailLink',Re(_0x258dfa,_0x1ce541));}async function zf(_0x4bdcbf,_0x2e78f7){return Qt(_0x4bdcbf,'POST','/v1/accounts:signInWithEmailLink',Re(_0x4bdcbf,_0x2e78f7));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wt extends bs{constructor(_0x58cf41,_0x4de42b,_0x69719b,_0xc9ed3b=null){super('password',_0x69719b),this['_email']=_0x58cf41,this['_password']=_0x4de42b,this['_tenantId']=_0xc9ed3b;}static['_fromEmailAndPassword'](_0x177fab,_0x46a08b){return new Wt(_0x177fab,_0x46a08b,'password');}static['_fromEmailAndCode'](_0x225c01,_0x17f6ed,_0x30eda6=null){return new Wt(_0x225c01,_0x17f6ed,'emailLink',_0x30eda6);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x118b84){const _0x48efff=typeof _0x118b84=='string'?JSON['parse'](_0x118b84):_0x118b84;if(_0x48efff!=null&&_0x48efff['email']&&(_0x48efff!=null&&_0x48efff['password'])){if(_0x48efff['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x48efff['email'],_0x48efff['password']);if(_0x48efff['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x48efff['email'],_0x48efff['password'],_0x48efff['tenantId']);}return null;}async['_getIdTokenResponse'](_0x33b308){switch(this['signInMethod']){case'password':const _0x5971c0={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x33b308,_0x5971c0,'signInWithPassword',Gf);case'emailLink':return qf(_0x33b308,{'email':this['_email'],'oobCode':this['_password']});default:Q(_0x33b308,'internal-error');}}async['_linkToIdToken'](_0x92bfa,_0x214c83){switch(this['signInMethod']){case'password':const _0x41f738={'idToken':_0x214c83,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x92bfa,_0x41f738,'signUpPassword',$f);case'emailLink':return zf(_0x92bfa,{'idToken':_0x214c83,'email':this['_email'],'oobCode':this['_password']});default:Q(_0x92bfa,'internal-error');}}['_getReauthenticationResolver'](_0x19d17c){return this['_getIdTokenResponse'](_0x19d17c);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xe(_0x44e15f,_0xa1cdef){return Qt(_0x44e15f,'POST','/v1/accounts:signInWithIdp',Re(_0x44e15f,_0xa1cdef));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jf='http://localhost';class Be extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x4efb74){const _0x80eaa=new Be(_0x4efb74['providerId'],_0x4efb74['signInMethod']);return _0x4efb74['idToken']||_0x4efb74['accessToken']?(_0x4efb74['idToken']&&(_0x80eaa['idToken']=_0x4efb74['idToken']),_0x4efb74['accessToken']&&(_0x80eaa['accessToken']=_0x4efb74['accessToken']),_0x4efb74['nonce']&&!_0x4efb74['pendingToken']&&(_0x80eaa['nonce']=_0x4efb74['nonce']),_0x4efb74['pendingToken']&&(_0x80eaa['pendingToken']=_0x4efb74['pendingToken'])):_0x4efb74['oauthToken']&&_0x4efb74['oauthTokenSecret']?(_0x80eaa['accessToken']=_0x4efb74['oauthToken'],_0x80eaa['secret']=_0x4efb74['oauthTokenSecret']):Q('argument-error'),_0x80eaa;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x9af2e3){const _0x4ec1da=typeof _0x9af2e3=='string'?JSON['parse'](_0x9af2e3):_0x9af2e3,{providerId:_0x123d6a,signInMethod:_0x155e95,..._0x183f3e}=_0x4ec1da;if(!_0x123d6a||!_0x155e95)return null;const _0x1bd640=new Be(_0x123d6a,_0x155e95);return _0x1bd640['idToken']=_0x183f3e['idToken']||void 0x0,_0x1bd640['accessToken']=_0x183f3e['accessToken']||void 0x0,_0x1bd640['secret']=_0x183f3e['secret'],_0x1bd640['nonce']=_0x183f3e['nonce'],_0x1bd640['pendingToken']=_0x183f3e['pendingToken']||null,_0x1bd640;}['_getIdTokenResponse'](_0x4ee05c){const _0x152149=this['buildRequest']();return Xe(_0x4ee05c,_0x152149);}['_linkToIdToken'](_0x4de337,_0x7e1f00){const _0x785f2e=this['buildRequest']();return _0x785f2e['idToken']=_0x7e1f00,Xe(_0x4de337,_0x785f2e);}['_getReauthenticationResolver'](_0x2e1426){const _0x4c6bb1=this['buildRequest']();return _0x4c6bb1['autoCreate']=!0x1,Xe(_0x2e1426,_0x4c6bb1);}['buildRequest'](){const _0x592290={'requestUri':jf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x592290['pendingToken']=this['pendingToken'];else{const _0x2b026c={};this['idToken']&&(_0x2b026c['id_token']=this['idToken']),this['accessToken']&&(_0x2b026c['access_token']=this['accessToken']),this['secret']&&(_0x2b026c['oauth_token_secret']=this['secret']),_0x2b026c['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x2b026c['nonce']=this['nonce']),_0x592290['postBody']=ct(_0x2b026c);}return _0x592290;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Kf(_0x10cde7){switch(_0x10cde7){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Yf(_0xc02c53){const _0xac14f9=vt(Et(_0xc02c53))['link'],_0x3ad2de=_0xac14f9?vt(Et(_0xac14f9))['deep_link_id']:null,_0x42448e=vt(Et(_0xc02c53))['deep_link_id'];return(_0x42448e?vt(Et(_0x42448e))['link']:null)||_0x42448e||_0x3ad2de||_0xac14f9||_0xc02c53;}class Rs{constructor(_0x186e48){const _0x2dfaa1=vt(Et(_0x186e48)),_0x1cd6cf=_0x2dfaa1['apiKey']??null,_0x4ea3f0=_0x2dfaa1['oobCode']??null,_0x5650a7=Kf(_0x2dfaa1['mode']??null);m(_0x1cd6cf&&_0x4ea3f0&&_0x5650a7,'argument-error'),this['apiKey']=_0x1cd6cf,this['operation']=_0x5650a7,this['code']=_0x4ea3f0,this['continueUrl']=_0x2dfaa1['continueUrl']??null,this['languageCode']=_0x2dfaa1['lang']??null,this['tenantId']=_0x2dfaa1['tenantId']??null;}static['parseLink'](_0xbb5686){const _0x8562af=Yf(_0xbb5686);try{return new Rs(_0x8562af);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pt{constructor(){this['providerId']=pt['PROVIDER_ID'];}static['credential'](_0x11f9c1,_0x238cd){return Wt['_fromEmailAndPassword'](_0x11f9c1,_0x238cd);}static['credentialWithLink'](_0x47016c,_0x58570c){const _0x16ef47=Rs['parseLink'](_0x58570c);return m(_0x16ef47,'argument-error'),Wt['_fromEmailAndCode'](_0x47016c,_0x16ef47['code'],_0x16ef47['tenantId']);}}pt['PROVIDER_ID']='password',pt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',pt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x7cfc93){this['providerId']=_0x7cfc93,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x5f4635){this['defaultLanguageCode']=_0x5f4635;}['setCustomParameters'](_0x3b345b){return this['customParameters']=_0x3b345b,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jt extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0xd25090){return this['scopes']['includes'](_0xd25090)||this['scopes']['push'](_0xd25090),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Jt{constructor(){super('facebook.com');}static['credential'](_0x5aad8b){return Be['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x5aad8b});}static['credentialFromResult'](_0x44ccc9){return he['credentialFromTaggedObject'](_0x44ccc9);}static['credentialFromError'](_0x49926f){return he['credentialFromTaggedObject'](_0x49926f['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x364caf}){if(!_0x364caf||!('oauthAccessToken'in _0x364caf)||!_0x364caf['oauthAccessToken'])return null;try{return he['credential'](_0x364caf['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Jt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x1163db,_0x257381){return Be['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x1163db,'accessToken':_0x257381});}static['credentialFromResult'](_0x50e3dd){return ue['credentialFromTaggedObject'](_0x50e3dd);}static['credentialFromError'](_0x4dd99b){return ue['credentialFromTaggedObject'](_0x4dd99b['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x36f7d6}){if(!_0x36f7d6)return null;const {oauthIdToken:_0x1b2eb8,oauthAccessToken:_0x5822b1}=_0x36f7d6;if(!_0x1b2eb8&&!_0x5822b1)return null;try{return ue['credential'](_0x1b2eb8,_0x5822b1);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Jt{constructor(){super('github.com');}static['credential'](_0x85a0e5){return Be['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x85a0e5});}static['credentialFromResult'](_0x44ed96){return de['credentialFromTaggedObject'](_0x44ed96);}static['credentialFromError'](_0xff1451){return de['credentialFromTaggedObject'](_0xff1451['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x1d1d30}){if(!_0x1d1d30||!('oauthAccessToken'in _0x1d1d30)||!_0x1d1d30['oauthAccessToken'])return null;try{return de['credential'](_0x1d1d30['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Jt{constructor(){super('twitter.com');}static['credential'](_0x2898ea,_0x1df569){return Be['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x2898ea,'oauthTokenSecret':_0x1df569});}static['credentialFromResult'](_0x215049){return fe['credentialFromTaggedObject'](_0x215049);}static['credentialFromError'](_0x1a155b){return fe['credentialFromTaggedObject'](_0x1a155b['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x50fba7}){if(!_0x50fba7)return null;const {oauthAccessToken:_0x461c3e,oauthTokenSecret:_0x3cbc48}=_0x50fba7;if(!_0x461c3e||!_0x3cbc48)return null;try{return fe['credential'](_0x461c3e,_0x3cbc48);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Qf(_0xdb581b,_0x285c4f){return Qt(_0xdb581b,'POST','/v1/accounts:signUp',Re(_0xdb581b,_0x285c4f));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(_0x386808){this['user']=_0x386808['user'],this['providerId']=_0x386808['providerId'],this['_tokenResponse']=_0x386808['_tokenResponse'],this['operationType']=_0x386808['operationType'];}static async['_fromIdTokenResponse'](_0x376637,_0x24f22a,_0x4518ca,_0x139430=!0x1){const _0x5c7be1=await K['_fromIdTokenResponse'](_0x376637,_0x4518ca,_0x139430),_0x1227ff=Nr(_0x4518ca);return new Ve({'user':_0x5c7be1,'providerId':_0x1227ff,'_tokenResponse':_0x4518ca,'operationType':_0x24f22a});}static async['_forOperation'](_0x2beb2f,_0x14d254,_0xeaf689){await _0x2beb2f['_updateTokensIfNecessary'](_0xeaf689,!0x0);const _0xae1b68=Nr(_0xeaf689);return new Ve({'user':_0x2beb2f,'providerId':_0xae1b68,'_tokenResponse':_0xeaf689,'operationType':_0x14d254});}}function Nr(_0x249633){return _0x249633['providerId']?_0x249633['providerId']:'phoneNumber'in _0x249633?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class An extends Se{constructor(_0x5e3325,_0x55b2a5,_0x48091,_0x2ec9ec){super(_0x55b2a5['code'],_0x55b2a5['message']),this['operationType']=_0x48091,this['user']=_0x2ec9ec,Object['setPrototypeOf'](this,An['prototype']),this['customData']={'appName':_0x5e3325['name'],'tenantId':_0x5e3325['tenantId']??void 0x0,'_serverResponse':_0x55b2a5['customData']['_serverResponse'],'operationType':_0x48091};}static['_fromErrorAndOperation'](_0x3fa8e8,_0x59f21e,_0x20d305,_0x576962){return new An(_0x3fa8e8,_0x59f21e,_0x20d305,_0x576962);}}function Ba(_0x5c72b0,_0x2e16ac,_0x1a8d52,_0x4146b4){return(_0x2e16ac==='reauthenticate'?_0x1a8d52['_getReauthenticationResolver'](_0x5c72b0):_0x1a8d52['_getIdTokenResponse'](_0x5c72b0))['catch'](_0x53ac70=>{throw _0x53ac70['code']==='auth/multi-factor-auth-required'?An['_fromErrorAndOperation'](_0x5c72b0,_0x53ac70,_0x2e16ac,_0x4146b4):_0x53ac70;});}async function Jf(_0x56b623,_0xb5d9de,_0x2b694e=!0x1){const _0x3bab6c=await Ut(_0x56b623,_0xb5d9de['_linkToIdToken'](_0x56b623['auth'],await _0x56b623['getIdToken']()),_0x2b694e);return Ve['_forOperation'](_0x56b623,'link',_0x3bab6c);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xf(_0x4c304c,_0x1ae70b,_0x10c344=!0x1){const {auth:_0x5bba3f}=_0x4c304c;if($(_0x5bba3f['app']))return Promise['reject'](re(_0x5bba3f));const _0x2b4ba2='reauthenticate';try{const _0xb86205=await Ut(_0x4c304c,Ba(_0x5bba3f,_0x2b4ba2,_0x1ae70b,_0x4c304c),_0x10c344);m(_0xb86205['idToken'],_0x5bba3f,'internal-error');const _0x126cd8=Ts(_0xb86205['idToken']);m(_0x126cd8,_0x5bba3f,'internal-error');const {sub:_0x3aa38e}=_0x126cd8;return m(_0x4c304c['uid']===_0x3aa38e,_0x5bba3f,'user-mismatch'),Ve['_forOperation'](_0x4c304c,_0x2b4ba2,_0xb86205);}catch(_0x2e0a0f){throw(_0x2e0a0f==null?void 0x0:_0x2e0a0f['code'])==='auth/user-not-found'&&Q(_0x5bba3f,'user-mismatch'),_0x2e0a0f;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x24e702,_0x3b5527,_0x386e51=!0x1){if($(_0x24e702['app']))return Promise['reject'](re(_0x24e702));const _0x18616e='signIn',_0x431b53=await Ba(_0x24e702,_0x18616e,_0x3b5527),_0xf5a5df=await Ve['_fromIdTokenResponse'](_0x24e702,_0x18616e,_0x431b53);return _0x386e51||await _0x24e702['_updateCurrentUser'](_0xf5a5df['user']),_0xf5a5df;}async function Zf(_0x1ccda3,_0x184ffe){return Va(qe(_0x1ccda3),_0x184ffe);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x4c0f56){const _0x236de4=qe(_0x4c0f56);_0x236de4['_getPasswordPolicyInternal']()&&await _0x236de4['_updatePasswordPolicy']();}async function P_(_0x5bc0ee,_0x3c0ce0,_0x292d90){if($(_0x5bc0ee['app']))return Promise['reject'](re(_0x5bc0ee));const _0x779aea=qe(_0x5bc0ee),_0x15de1c=await Di(_0x779aea,{'returnSecureToken':!0x0,'email':_0x3c0ce0,'password':_0x292d90,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Qf)['catch'](_0x385268=>{throw _0x385268['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x5bc0ee),_0x385268;}),_0x43b3c1=await Ve['_fromIdTokenResponse'](_0x779aea,'signIn',_0x15de1c);return await _0x779aea['_updateCurrentUser'](_0x43b3c1['user']),_0x43b3c1;}function O_(_0x554a0f,_0x358837,_0x8c51f1){return $(_0x554a0f['app'])?Promise['reject'](re(_0x554a0f)):Zf(N(_0x554a0f),pt['credential'](_0x358837,_0x8c51f1))['catch'](async _0x95b15c=>{throw _0x95b15c['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x554a0f),_0x95b15c;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function D_(_0x5532db,_0x47fe43){return N(_0x5532db)['setPersistence'](_0x47fe43);}function ep(_0x400e16,_0x34a9d7,_0x3e0467,_0x400de0){return N(_0x400e16)['onIdTokenChanged'](_0x34a9d7,_0x3e0467,_0x400de0);}function tp(_0x95fd33,_0x41b57f,_0x1c6ec6){return N(_0x95fd33)['beforeAuthStateChanged'](_0x41b57f,_0x1c6ec6);}function M_(_0x291a4d,_0x3688ba,_0x48b1b1,_0x20afef){return N(_0x291a4d)['onAuthStateChanged'](_0x3688ba,_0x48b1b1,_0x20afef);}function L_(_0x5d4ff3){return N(_0x5d4ff3)['signOut']();}const kn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x2d7eb3,_0x153bef){this['storageRetriever']=_0x2d7eb3,this['type']=_0x153bef;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](kn,'1'),this['storage']['removeItem'](kn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x37642a,_0x7b85bf){return this['storage']['setItem'](_0x37642a,JSON['stringify'](_0x7b85bf)),Promise['resolve']();}['_get'](_0x5b5e41){const _0x1977fa=this['storage']['getItem'](_0x5b5e41);return Promise['resolve'](_0x1977fa?JSON['parse'](_0x1977fa):null);}['_remove'](_0x37dec0){return this['storage']['removeItem'](_0x37dec0),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const np=0x3e8,ip=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x528ffb,_0x524102)=>this['onStorageEvent'](_0x528ffb,_0x524102),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x455756){for(const _0x1c25df of Object['keys'](this['listeners'])){const _0x45514f=this['storage']['getItem'](_0x1c25df),_0x5a6355=this['localCache'][_0x1c25df];_0x45514f!==_0x5a6355&&_0x455756(_0x1c25df,_0x5a6355,_0x45514f);}}['onStorageEvent'](_0x2ff4fb,_0x1b4ba3=!0x1){if(!_0x2ff4fb['key']){this['forAllChangedKeys']((_0x4a7d25,_0x56dc05,_0x532263)=>{this['notifyListeners'](_0x4a7d25,_0x532263);});return;}const _0x2f0c4f=_0x2ff4fb['key'];_0x1b4ba3?this['detachListener']():this['stopPolling']();const _0x480f0a=()=>{const _0x25b34e=this['storage']['getItem'](_0x2f0c4f);!_0x1b4ba3&&this['localCache'][_0x2f0c4f]===_0x25b34e||this['notifyListeners'](_0x2f0c4f,_0x25b34e);},_0x3aaf94=this['storage']['getItem'](_0x2f0c4f);Tf()&&_0x3aaf94!==_0x2ff4fb['newValue']&&_0x2ff4fb['newValue']!==_0x2ff4fb['oldValue']?setTimeout(_0x480f0a,ip):_0x480f0a();}['notifyListeners'](_0x37873b,_0x381432){this['localCache'][_0x37873b]=_0x381432;const _0x1c745b=this['listeners'][_0x37873b];if(_0x1c745b){for(const _0x374dc9 of Array['from'](_0x1c745b))_0x374dc9(_0x381432&&JSON['parse'](_0x381432));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x394cde,_0xd7cb0e,_0x45d239)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x394cde,'oldValue':_0xd7cb0e,'newValue':_0x45d239}),!0x0);});},np);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x387574,_0x348ad0){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x387574]||(this['listeners'][_0x387574]=new Set(),this['localCache'][_0x387574]=this['storage']['getItem'](_0x387574)),this['listeners'][_0x387574]['add'](_0x348ad0);}['_removeListener'](_0x981be0,_0x30b63b){this['listeners'][_0x981be0]&&(this['listeners'][_0x981be0]['delete'](_0x30b63b),this['listeners'][_0x981be0]['size']===0x0&&delete this['listeners'][_0x981be0]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x88db29,_0x34baba){await super['_set'](_0x88db29,_0x34baba),this['localCache'][_0x88db29]=JSON['stringify'](_0x34baba);}async['_get'](_0x519f0d){const _0x4e2700=await super['_get'](_0x519f0d);return this['localCache'][_0x519f0d]=JSON['stringify'](_0x4e2700),_0x4e2700;}async['_remove'](_0xced278){await super['_remove'](_0xced278),delete this['localCache'][_0xced278];}}Ga['type']='LOCAL';const sp=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x1bfedf,_0x43e2ce){}['_removeListener'](_0xb3c92a,_0x58e5d9){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rp(_0x4a3b8c){return Promise['all'](_0x4a3b8c['map'](async _0x1eef3f=>{try{return{'fulfilled':!0x0,'value':await _0x1eef3f};}catch(_0x319f1d){return{'fulfilled':!0x1,'reason':_0x319f1d};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kn{constructor(_0x41358d){this['eventTarget']=_0x41358d,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x330456){const _0x126ff8=this['receivers']['find'](_0x50f722=>_0x50f722['isListeningto'](_0x330456));if(_0x126ff8)return _0x126ff8;const _0x382b04=new Kn(_0x330456);return this['receivers']['push'](_0x382b04),_0x382b04;}['isListeningto'](_0x4ea54d){return this['eventTarget']===_0x4ea54d;}async['handleEvent'](_0x2fa466){const _0x543f74=_0x2fa466,{eventId:_0x180313,eventType:_0x59b594,data:_0xcb3cbb}=_0x543f74['data'],_0x237cc9=this['handlersMap'][_0x59b594];if(!(_0x237cc9!=null&&_0x237cc9['size']))return;_0x543f74['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x180313,'eventType':_0x59b594});const _0x2e0612=Array['from'](_0x237cc9)['map'](async _0x24147e=>_0x24147e(_0x543f74['origin'],_0xcb3cbb)),_0x539261=await rp(_0x2e0612);_0x543f74['ports'][0x0]['postMessage']({'status':'done','eventId':_0x180313,'eventType':_0x59b594,'response':_0x539261});}['_subscribe'](_0x5a144c,_0x188110){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x5a144c]||(this['handlersMap'][_0x5a144c]=new Set()),this['handlersMap'][_0x5a144c]['add'](_0x188110);}['_unsubscribe'](_0x20a358,_0x4e094b){this['handlersMap'][_0x20a358]&&_0x4e094b&&this['handlersMap'][_0x20a358]['delete'](_0x4e094b),(!_0x4e094b||this['handlersMap'][_0x20a358]['size']===0x0)&&delete this['handlersMap'][_0x20a358],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Kn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x4efa4f='',_0x4ec678=0xa){let _0x40de93='';for(let _0xb9aae4=0x0;_0xb9aae4<_0x4ec678;_0xb9aae4++)_0x40de93+=Math['floor'](Math['random']()*0xa);return _0x4efa4f+_0x40de93;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class op{constructor(_0x3d3128){this['target']=_0x3d3128,this['handlers']=new Set();}['removeMessageHandler'](_0x21dd6e){_0x21dd6e['messageChannel']&&(_0x21dd6e['messageChannel']['port1']['removeEventListener']('message',_0x21dd6e['onMessage']),_0x21dd6e['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x21dd6e);}async['_send'](_0x3f964c,_0xc1bb6d,_0x1a4955=0x32){const _0x227b19=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x227b19)throw new Error('connection_unavailable');let _0x1928c0,_0x44f0e9;return new Promise((_0x124cc4,_0xfda588)=>{const _0x27398b=As('',0x14);_0x227b19['port1']['start']();const _0x254544=setTimeout(()=>{_0xfda588(new Error('unsupported_event'));},_0x1a4955);_0x44f0e9={'messageChannel':_0x227b19,'onMessage'(_0x7ed26d){const _0x50e17d=_0x7ed26d;if(_0x50e17d['data']['eventId']===_0x27398b)switch(_0x50e17d['data']['status']){case'ack':clearTimeout(_0x254544),_0x1928c0=setTimeout(()=>{_0xfda588(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x1928c0),_0x124cc4(_0x50e17d['data']['response']);break;default:clearTimeout(_0x254544),clearTimeout(_0x1928c0),_0xfda588(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x44f0e9),_0x227b19['port1']['addEventListener']('message',_0x44f0e9['onMessage']),this['target']['postMessage']({'eventType':_0x3f964c,'eventId':_0x27398b,'data':_0xc1bb6d},[_0x227b19['port2']]);})['finally'](()=>{_0x44f0e9&&this['removeMessageHandler'](_0x44f0e9);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function ap(_0x2e647c){Z()['location']['href']=_0x2e647c;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function cp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function lp(){var _0x112cc1;return((_0x112cc1=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x112cc1['controller'])||null;}function hp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',up=0x1,Nn='firebaseLocalStorage',Ya='fbase_key';class Xt{constructor(_0x43d91d){this['request']=_0x43d91d;}['toPromise'](){return new Promise((_0x2f27f9,_0x42377d)=>{this['request']['addEventListener']('success',()=>{_0x2f27f9(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x42377d(this['request']['error']);});});}}function Yn(_0x3a540f,_0x2f083d){return _0x3a540f['transaction']([Nn],_0x2f083d?'readwrite':'readonly')['objectStore'](Nn);}function dp(){const _0x10c927=indexedDB['deleteDatabase'](Ka);return new Xt(_0x10c927)['toPromise']();}function Mi(){const _0x465881=indexedDB['open'](Ka,up);return new Promise((_0x32ee11,_0x2319f9)=>{_0x465881['addEventListener']('error',()=>{_0x2319f9(_0x465881['error']);}),_0x465881['addEventListener']('upgradeneeded',()=>{const _0x2a460e=_0x465881['result'];try{_0x2a460e['createObjectStore'](Nn,{'keyPath':Ya});}catch(_0x3ab487){_0x2319f9(_0x3ab487);}}),_0x465881['addEventListener']('success',async()=>{const _0x1dfbb0=_0x465881['result'];_0x1dfbb0['objectStoreNames']['contains'](Nn)?_0x32ee11(_0x1dfbb0):(_0x1dfbb0['close'](),await dp(),_0x32ee11(await Mi()));});});}async function Pr(_0x152fd9,_0x1cbf50,_0x5620f6){const _0x46b3e4=Yn(_0x152fd9,!0x0)['put']({[Ya]:_0x1cbf50,'value':_0x5620f6});return new Xt(_0x46b3e4)['toPromise']();}async function fp(_0x42bfe5,_0x1b3d9c){const _0x56ae43=Yn(_0x42bfe5,!0x1)['get'](_0x1b3d9c),_0x35c35c=await new Xt(_0x56ae43)['toPromise']();return _0x35c35c===void 0x0?null:_0x35c35c['value'];}function Or(_0x5ce150,_0x9e224f){const _0x5cf2a1=Yn(_0x5ce150,!0x0)['delete'](_0x9e224f);return new Xt(_0x5cf2a1)['toPromise']();}const pp=0x320,_p=0x3;class Qa{constructor(){this['type']='LOCAL',this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['db']?this['db']:(this['db']=await Mi(),this['db']);}async['_withRetries'](_0x10e6ec){let _0x51ba45=0x0;for(;;)try{const _0x11278f=await this['_openDb']();return await _0x10e6ec(_0x11278f);}catch(_0xf2327d){if(_0x51ba45++>_p)throw _0xf2327d;this['db']&&(this['db']['close'](),this['db']=void 0x0);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Kn['_getInstance'](hp()),this['receiver']['_subscribe']('keyChanged',async(_0x114ff6,_0x7614a6)=>({'keyProcessed':(await this['_poll']())['includes'](_0x7614a6['key'])})),this['receiver']['_subscribe']('ping',async(_0x16f3ae,_0x25c6e4)=>['keyChanged']);}async['initializeSender'](){var _0x249c40,_0x355ac1;if(this['activeServiceWorker']=await cp(),!this['activeServiceWorker'])return;this['sender']=new op(this['activeServiceWorker']);const _0x3de6c3=await this['sender']['_send']('ping',{},0x320);_0x3de6c3&&(_0x249c40=_0x3de6c3[0x0])!=null&&_0x249c40['fulfilled']&&(_0x355ac1=_0x3de6c3[0x0])!=null&&_0x355ac1['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x598cac){if(!(!this['sender']||!this['activeServiceWorker']||lp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x598cac},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{if(!indexedDB)return!0x1;const _0x1862b1=await Mi();return await Pr(_0x1862b1,kn,'1'),await Or(_0x1862b1,kn),!0x0;}catch{}return!0x1;}async['_withPendingWrite'](_0x2620d2){this['pendingWrites']++;try{await _0x2620d2();}finally{this['pendingWrites']--;}}async['_set'](_0x538d92,_0x4c4ae3){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0xcea8a4=>Pr(_0xcea8a4,_0x538d92,_0x4c4ae3)),this['localCache'][_0x538d92]=_0x4c4ae3,this['notifyServiceWorker'](_0x538d92)));}async['_get'](_0x3e6a7b){const _0x4f0188=await this['_withRetries'](_0x36ff72=>fp(_0x36ff72,_0x3e6a7b));return this['localCache'][_0x3e6a7b]=_0x4f0188,_0x4f0188;}async['_remove'](_0x223874){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0xb609af=>Or(_0xb609af,_0x223874)),delete this['localCache'][_0x223874],this['notifyServiceWorker'](_0x223874)));}async['_poll'](){const _0x62f988=await this['_withRetries'](_0x6537d9=>{const _0x531959=Yn(_0x6537d9,!0x1)['getAll']();return new Xt(_0x531959)['toPromise']();});if(!_0x62f988)return[];if(this['pendingWrites']!==0x0)return[];const _0x2d746f=[],_0x1a260e=new Set();if(_0x62f988['length']!==0x0){for(const {fbase_key:_0x31842e,value:_0x4a6120}of _0x62f988)_0x1a260e['add'](_0x31842e),JSON['stringify'](this['localCache'][_0x31842e])!==JSON['stringify'](_0x4a6120)&&(this['notifyListeners'](_0x31842e,_0x4a6120),_0x2d746f['push'](_0x31842e));}for(const _0x52cb0a of Object['keys'](this['localCache']))this['localCache'][_0x52cb0a]&&!_0x1a260e['has'](_0x52cb0a)&&(this['notifyListeners'](_0x52cb0a,null),_0x2d746f['push'](_0x52cb0a));return _0x2d746f;}['notifyListeners'](_0x43f65a,_0x5e0e28){this['localCache'][_0x43f65a]=_0x5e0e28;const _0x420d8d=this['listeners'][_0x43f65a];if(_0x420d8d){for(const _0x11181a of Array['from'](_0x420d8d))_0x11181a(_0x5e0e28);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),pp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x29d2ec,_0x1c7ede){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x29d2ec]||(this['listeners'][_0x29d2ec]=new Set(),this['_get'](_0x29d2ec)),this['listeners'][_0x29d2ec]['add'](_0x1c7ede);}['_removeListener'](_0x2227dd,_0x132543){this['listeners'][_0x2227dd]&&(this['listeners'][_0x2227dd]['delete'](_0x132543),this['listeners'][_0x2227dd]['size']===0x0&&delete this['listeners'][_0x2227dd]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Qa['type']='LOCAL';const gp=Qa;new Yt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function mp(_0x9f19cd,_0x5aabc8){return _0x5aabc8?ie(_0x5aabc8):(m(_0x9f19cd['_popupRedirectResolver'],_0x9f19cd,'argument-error'),_0x9f19cd['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x3651f5){super('custom','custom'),this['params']=_0x3651f5;}['_getIdTokenResponse'](_0x43bf22){return Xe(_0x43bf22,this['_buildIdpRequest']());}['_linkToIdToken'](_0x2a97d2,_0x354bff){return Xe(_0x2a97d2,this['_buildIdpRequest'](_0x354bff));}['_getReauthenticationResolver'](_0x56b636){return Xe(_0x56b636,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x5899b5){const _0x181088={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x5899b5&&(_0x181088['idToken']=_0x5899b5),_0x181088;}}function yp(_0x4347b3){return Va(_0x4347b3['auth'],new ks(_0x4347b3),_0x4347b3['bypassAuthState']);}function vp(_0x24c245){const {auth:_0x272df7,user:_0x2aed7d}=_0x24c245;return m(_0x2aed7d,_0x272df7,'internal-error'),Xf(_0x2aed7d,new ks(_0x24c245),_0x24c245['bypassAuthState']);}async function Ep(_0x2dc444){const {auth:_0x2927e3,user:_0x4e9a5d}=_0x2dc444;return m(_0x4e9a5d,_0x2927e3,'internal-error'),Jf(_0x4e9a5d,new ks(_0x2dc444),_0x2dc444['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ja{constructor(_0x3da762,_0x96c7c0,_0xff26bb,_0x35d023,_0x77f0c3=!0x1){this['auth']=_0x3da762,this['resolver']=_0xff26bb,this['user']=_0x35d023,this['bypassAuthState']=_0x77f0c3,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x96c7c0)?_0x96c7c0:[_0x96c7c0];}['execute'](){return new Promise(async(_0x2e9f6a,_0x3c0824)=>{this['pendingPromise']={'resolve':_0x2e9f6a,'reject':_0x3c0824};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x2c734a){this['reject'](_0x2c734a);}});}async['onAuthEvent'](_0x3cf138){const {urlResponse:_0x3e3bd7,sessionId:_0x2e633d,postBody:_0x4b708c,tenantId:_0x3c015e,error:_0x5e32bf,type:_0x1108b0}=_0x3cf138;if(_0x5e32bf){this['reject'](_0x5e32bf);return;}const _0x556f7b={'auth':this['auth'],'requestUri':_0x3e3bd7,'sessionId':_0x2e633d,'tenantId':_0x3c015e||void 0x0,'postBody':_0x4b708c||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x1108b0)(_0x556f7b));}catch(_0x2b55f0){this['reject'](_0x2b55f0);}}['onError'](_0x48a422){this['reject'](_0x48a422);}['getIdpTask'](_0x4ddbe5){switch(_0x4ddbe5){case'signInViaPopup':case'signInViaRedirect':return yp;case'linkViaPopup':case'linkViaRedirect':return Ep;case'reauthViaPopup':case'reauthViaRedirect':return vp;default:Q(this['auth'],'internal-error');}}['resolve'](_0x6943d8){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x6943d8),this['unregisterAndCleanUp']();}['reject'](_0x53f7e1){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x53f7e1),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ip=new Yt(0x7d0,0x2710);class Ke extends Ja{constructor(_0xd6ba1,_0xb793ab,_0x181f7f,_0x508857,_0x1f6596){super(_0xd6ba1,_0xb793ab,_0x508857,_0x1f6596),this['provider']=_0x181f7f,this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']&&Ke['currentPopupAction']['cancel'](),Ke['currentPopupAction']=this;}async['executeNotNull'](){const _0x2ee598=await this['execute']();return m(_0x2ee598,this['auth'],'internal-error'),_0x2ee598;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x58b4ad=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x58b4ad),this['authWindow']['associatedEvent']=_0x58b4ad,this['resolver']['_originValidation'](this['auth'])['catch'](_0x307295=>{this['reject'](_0x307295);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x57f102=>{_0x57f102||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x4693ac;return((_0x4693ac=this['authWindow'])==null?void 0x0:_0x4693ac['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']=null;}['pollUserCancellation'](){const _0xff1d4d=()=>{var _0x51a4bf,_0x585643;if((_0x585643=(_0x51a4bf=this['authWindow'])==null?void 0x0:_0x51a4bf['window'])!=null&&_0x585643['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0xff1d4d,Ip['get']());};_0xff1d4d();}}Ke['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const wp='pendingRedirect',on=new Map();class Cp extends Ja{constructor(_0x44565f,_0x4649bd,_0x159c98=!0x1){super(_0x44565f,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x4649bd,void 0x0,_0x159c98),this['eventId']=null;}async['execute'](){let _0x1f1ac9=on['get'](this['auth']['_key']());if(!_0x1f1ac9){try{const _0x2eeb2c=await Tp(this['resolver'],this['auth'])?await super['execute']():null;_0x1f1ac9=()=>Promise['resolve'](_0x2eeb2c);}catch(_0x40cfec){_0x1f1ac9=()=>Promise['reject'](_0x40cfec);}on['set'](this['auth']['_key'](),_0x1f1ac9);}return this['bypassAuthState']||on['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x1f1ac9();}async['onAuthEvent'](_0x1df1ab){if(_0x1df1ab['type']==='signInViaRedirect')return super['onAuthEvent'](_0x1df1ab);if(_0x1df1ab['type']==='unknown'){this['resolve'](null);return;}if(_0x1df1ab['eventId']){const _0x4c6143=await this['auth']['_redirectUserForId'](_0x1df1ab['eventId']);if(_0x4c6143)return this['user']=_0x4c6143,super['onAuthEvent'](_0x1df1ab);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Tp(_0x502361,_0x348229){const _0x538316=Rp(_0x348229),_0x3f42a2=bp(_0x502361);if(!await _0x3f42a2['_isAvailable']())return!0x1;const _0xd2e3e0=await _0x3f42a2['_get'](_0x538316)==='true';return await _0x3f42a2['_remove'](_0x538316),_0xd2e3e0;}function Sp(_0x11e3e7,_0x2326fb){on['set'](_0x11e3e7['_key'](),_0x2326fb);}function bp(_0x29626d){return ie(_0x29626d['_redirectPersistence']);}function Rp(_0x27ddf1){return rn(wp,_0x27ddf1['config']['apiKey'],_0x27ddf1['name']);}async function Ap(_0x3ed559,_0x754934,_0x45d670=!0x1){if($(_0x3ed559['app']))return Promise['reject'](re(_0x3ed559));const _0x1e99e7=qe(_0x3ed559),_0x46fb6b=mp(_0x1e99e7,_0x754934),_0x53fe89=await new Cp(_0x1e99e7,_0x46fb6b,_0x45d670)['execute']();return _0x53fe89&&!_0x45d670&&(delete _0x53fe89['user']['_redirectEventId'],await _0x1e99e7['_persistUserIfCurrent'](_0x53fe89['user']),await _0x1e99e7['_setRedirectUser'](null,_0x754934)),_0x53fe89;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=0x258*0x3e8;class Np{constructor(_0x16d9ab){this['auth']=_0x16d9ab,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x4da7d7){this['consumers']['add'](_0x4da7d7),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x4da7d7)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x4da7d7),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x4588cd){this['consumers']['delete'](_0x4588cd);}['onEvent'](_0x3e34a7){if(this['hasEventBeenHandled'](_0x3e34a7))return!0x1;let _0x54e63f=!0x1;return this['consumers']['forEach'](_0x193079=>{this['isEventForConsumer'](_0x3e34a7,_0x193079)&&(_0x54e63f=!0x0,this['sendToConsumer'](_0x3e34a7,_0x193079),this['saveEventToCache'](_0x3e34a7));}),this['hasHandledPotentialRedirect']||!Pp(_0x3e34a7)||(this['hasHandledPotentialRedirect']=!0x0,_0x54e63f||(this['queuedRedirectEvent']=_0x3e34a7,_0x54e63f=!0x0)),_0x54e63f;}['sendToConsumer'](_0x286f79,_0x26abc7){var _0x2d960b;if(_0x286f79['error']&&!Xa(_0x286f79)){const _0x2187b4=((_0x2d960b=_0x286f79['error']['code'])==null?void 0x0:_0x2d960b['split']('auth/')[0x1])||'internal-error';_0x26abc7['onError'](X(this['auth'],_0x2187b4));}else _0x26abc7['onAuthEvent'](_0x286f79);}['isEventForConsumer'](_0x57cecd,_0x20cf63){const _0x3d8b84=_0x20cf63['eventId']===null||!!_0x57cecd['eventId']&&_0x57cecd['eventId']===_0x20cf63['eventId'];return _0x20cf63['filter']['includes'](_0x57cecd['type'])&&_0x3d8b84;}['hasEventBeenHandled'](_0x344e24){return Date['now']()-this['lastProcessedEventTime']>=kp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Dr(_0x344e24));}['saveEventToCache'](_0x280e7d){this['cachedEventUids']['add'](Dr(_0x280e7d)),this['lastProcessedEventTime']=Date['now']();}}function Dr(_0x179ba9){return[_0x179ba9['type'],_0x179ba9['eventId'],_0x179ba9['sessionId'],_0x179ba9['tenantId']]['filter'](_0x6af6fc=>_0x6af6fc)['join']('-');}function Xa({type:_0x4ee635,error:_0x547fb7}){return _0x4ee635==='unknown'&&(_0x547fb7==null?void 0x0:_0x547fb7['code'])==='auth/no-auth-event';}function Pp(_0x312e7d){switch(_0x312e7d['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Xa(_0x312e7d);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Op(_0x124095,_0x16d5fe={}){return Ae(_0x124095,'GET','/v1/projects',_0x16d5fe);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Mp=/^https?/;async function Lp(_0x3321e7){if(_0x3321e7['config']['emulator'])return;const {authorizedDomains:_0x5dfb01}=await Op(_0x3321e7);for(const _0xfa29ec of _0x5dfb01)try{if(xp(_0xfa29ec))return;}catch{}Q(_0x3321e7,'unauthorized-domain');}function xp(_0x4ce89d){const _0x23ebe0=Pi(),{protocol:_0x2ed687,hostname:_0x4c1c46}=new URL(_0x23ebe0);if(_0x4ce89d['startsWith']('chrome-extension://')){const _0x487a92=new URL(_0x4ce89d);return _0x487a92['hostname']===''&&_0x4c1c46===''?_0x2ed687==='chrome-extension:'&&_0x4ce89d['replace']('chrome-extension://','')===_0x23ebe0['replace']('chrome-extension://',''):_0x2ed687==='chrome-extension:'&&_0x487a92['hostname']===_0x4c1c46;}if(!Mp['test'](_0x2ed687))return!0x1;if(Dp['test'](_0x4ce89d))return _0x4c1c46===_0x4ce89d;const _0x417385=_0x4ce89d['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x417385+'|'+_0x417385+')$','i')['test'](_0x4c1c46);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Fp=new Yt(0x7530,0xea60);function Mr(){const _0x36f05a=Z()['___jsl'];if(_0x36f05a!=null&&_0x36f05a['H']){for(const _0x472795 of Object['keys'](_0x36f05a['H']))if(_0x36f05a['H'][_0x472795]['r']=_0x36f05a['H'][_0x472795]['r']||[],_0x36f05a['H'][_0x472795]['L']=_0x36f05a['H'][_0x472795]['L']||[],_0x36f05a['H'][_0x472795]['r']=[..._0x36f05a['H'][_0x472795]['L']],_0x36f05a['CP']){for(let _0x81f26f=0x0;_0x81f26f<_0x36f05a['CP']['length'];_0x81f26f++)_0x36f05a['CP'][_0x81f26f]=null;}}}function Up(_0x4337fd){return new Promise((_0x597200,_0x5d8ae8)=>{var _0x309dca,_0xc15bf9,_0xf73c2c;function _0x366e2c(){Mr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x597200(gapi['iframes']['getContext']());},'ontimeout':()=>{Mr(),_0x5d8ae8(X(_0x4337fd,'network-request-failed'));},'timeout':Fp['get']()});}if((_0xc15bf9=(_0x309dca=Z()['gapi'])==null?void 0x0:_0x309dca['iframes'])!=null&&_0xc15bf9['Iframe'])_0x597200(gapi['iframes']['getContext']());else{if((_0xf73c2c=Z()['gapi'])!=null&&_0xf73c2c['load'])_0x366e2c();else{const _0x3eb6f1=Df('iframefcb');return Z()[_0x3eb6f1]=()=>{gapi['load']?_0x366e2c():_0x5d8ae8(X(_0x4337fd,'network-request-failed'));},xa(Of()+'?onload='+_0x3eb6f1)['catch'](_0x27493a=>_0x5d8ae8(_0x27493a));}}})['catch'](_0x277c93=>{throw an=null,_0x277c93;});}let an=null;function Wp(_0x88c0aa){return an=an||Up(_0x88c0aa),an;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Yt(0x1388,0x3a98),Vp='__/auth/iframe',Hp='emulator/auth/iframe',$p={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Gp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function qp(_0x3b3e3b){const _0x30e603=_0x3b3e3b['config'];m(_0x30e603['authDomain'],_0x3b3e3b,'auth-domain-config-required');const _0xef6636=_0x30e603['emulator']?Cs(_0x30e603,Hp):'https://'+_0x3b3e3b['config']['authDomain']+'/'+Vp,_0x4cbd90={'apiKey':_0x30e603['apiKey'],'appName':_0x3b3e3b['name'],'v':lt},_0x442021=Gp['get'](_0x3b3e3b['config']['apiHost']);_0x442021&&(_0x4cbd90['eid']=_0x442021);const _0x21f515=_0x3b3e3b['_getFrameworks']();return _0x21f515['length']&&(_0x4cbd90['fw']=_0x21f515['join'](',')),_0xef6636+'?'+ct(_0x4cbd90)['slice'](0x1);}async function zp(_0x2ad379){const _0x1797a9=await Wp(_0x2ad379),_0x9b441e=Z()['gapi'];return m(_0x9b441e,_0x2ad379,'internal-error'),_0x1797a9['open']({'where':document['body'],'url':qp(_0x2ad379),'messageHandlersFilter':_0x9b441e['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':$p,'dontclear':!0x0},_0x5064a0=>new Promise(async(_0x1d3459,_0x5805f0)=>{await _0x5064a0['restyle']({'setHideOnLeave':!0x1});const _0x4528da=X(_0x2ad379,'network-request-failed'),_0x344c90=Z()['setTimeout'](()=>{_0x5805f0(_0x4528da);},Bp['get']());function _0x1dd972(){Z()['clearTimeout'](_0x344c90),_0x1d3459(_0x5064a0);}_0x5064a0['ping'](_0x1dd972)['then'](_0x1dd972,()=>{_0x5805f0(_0x4528da);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Kp=0x1f4,Yp=0x258,Qp='_blank',Jp='http://localhost';class Lr{constructor(_0x577e8d){this['window']=_0x577e8d,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Xp(_0x58c9ad,_0x3a0e16,_0x548ef2,_0xa0abff=Kp,_0x21510e=Yp){const _0xaa26ad=Math['max']((window['screen']['availHeight']-_0x21510e)/0x2,0x0)['toString'](),_0x50537d=Math['max']((window['screen']['availWidth']-_0xa0abff)/0x2,0x0)['toString']();let _0x38b6ec='';const _0x3c5695={...jp,'width':_0xa0abff['toString'](),'height':_0x21510e['toString'](),'top':_0xaa26ad,'left':_0x50537d},_0x31e6da=W()['toLowerCase']();_0x548ef2&&(_0x38b6ec=ka(_0x31e6da)?Qp:_0x548ef2),Ra(_0x31e6da)&&(_0x3a0e16=_0x3a0e16||Jp,_0x3c5695['scrollbars']='yes');const _0x5916fa=Object['entries'](_0x3c5695)['reduce']((_0x4cf14a,[_0xb9498f,_0x38307d])=>''+_0x4cf14a+_0xb9498f+'='+_0x38307d+',','');if(Cf(_0x31e6da)&&_0x38b6ec!=='_self')return Zp(_0x3a0e16||'',_0x38b6ec),new Lr(null);const _0x462fc5=window['open'](_0x3a0e16||'',_0x38b6ec,_0x5916fa);m(_0x462fc5,_0x58c9ad,'popup-blocked');try{_0x462fc5['focus']();}catch{}return new Lr(_0x462fc5);}function Zp(_0x2854a1,_0x3e20b8){const _0x306a29=document['createElement']('a');_0x306a29['href']=_0x2854a1,_0x306a29['target']=_0x3e20b8;const _0x3e373f=document['createEvent']('MouseEvent');_0x3e373f['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x306a29['dispatchEvent'](_0x3e373f);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const e_='__/auth/handler',t_='emulator/auth/handler',n_=encodeURIComponent('fac');async function xr(_0x16d855,_0x438857,_0x393b19,_0x24600c,_0x133abd,_0x4a410b){m(_0x16d855['config']['authDomain'],_0x16d855,'auth-domain-config-required'),m(_0x16d855['config']['apiKey'],_0x16d855,'invalid-api-key');const _0x1f68b1={'apiKey':_0x16d855['config']['apiKey'],'appName':_0x16d855['name'],'authType':_0x393b19,'redirectUrl':_0x24600c,'v':lt,'eventId':_0x133abd};if(_0x438857 instanceof Wa){_0x438857['setDefaultLanguage'](_0x16d855['languageCode']),_0x1f68b1['providerId']=_0x438857['providerId']||'',ui(_0x438857['getCustomParameters']())||(_0x1f68b1['customParameters']=JSON['stringify'](_0x438857['getCustomParameters']()));for(const [_0x4a3dbe,_0xa37f3c]of Object['entries']({}))_0x1f68b1[_0x4a3dbe]=_0xa37f3c;}if(_0x438857 instanceof Jt){const _0x1838a0=_0x438857['getScopes']()['filter'](_0x45c175=>_0x45c175!=='');_0x1838a0['length']>0x0&&(_0x1f68b1['scopes']=_0x1838a0['join'](','));}_0x16d855['tenantId']&&(_0x1f68b1['tid']=_0x16d855['tenantId']);const _0x135c41=_0x1f68b1;for(const _0x4c00f5 of Object['keys'](_0x135c41))_0x135c41[_0x4c00f5]===void 0x0&&delete _0x135c41[_0x4c00f5];const _0xd7da61=await _0x16d855['_getAppCheckToken'](),_0x1a3a80=_0xd7da61?'#'+n_+'='+encodeURIComponent(_0xd7da61):'';return i_(_0x16d855)+'?'+ct(_0x135c41)['slice'](0x1)+_0x1a3a80;}function i_({config:_0x5c364f}){return _0x5c364f['emulator']?Cs(_0x5c364f,t_):'https://'+_0x5c364f['authDomain']+'/'+e_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const hi='webStorageSupport';class s_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Ap,this['_overrideRedirectResult']=Sp;}async['_openPopup'](_0x4fba71,_0x237b5a,_0x4f35af,_0x59be6e){var _0x518b75;ce((_0x518b75=this['eventManagers'][_0x4fba71['_key']()])==null?void 0x0:_0x518b75['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x7ae319=await xr(_0x4fba71,_0x237b5a,_0x4f35af,Pi(),_0x59be6e);return Xp(_0x4fba71,_0x7ae319,As());}async['_openRedirect'](_0x418460,_0x5b26d6,_0x630e72,_0x3abaa9){await this['_originValidation'](_0x418460);const _0xb647fd=await xr(_0x418460,_0x5b26d6,_0x630e72,Pi(),_0x3abaa9);return ap(_0xb647fd),new Promise(()=>{});}['_initialize'](_0x10277c){const _0xb2ba5e=_0x10277c['_key']();if(this['eventManagers'][_0xb2ba5e]){const {manager:_0x536132,promise:_0x306702}=this['eventManagers'][_0xb2ba5e];return _0x536132?Promise['resolve'](_0x536132):(ce(_0x306702,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x306702);}const _0x1d3386=this['initAndGetManager'](_0x10277c);return this['eventManagers'][_0xb2ba5e]={'promise':_0x1d3386},_0x1d3386['catch'](()=>{delete this['eventManagers'][_0xb2ba5e];}),_0x1d3386;}async['initAndGetManager'](_0x143814){const _0x299e1f=await zp(_0x143814),_0x50001e=new Np(_0x143814);return _0x299e1f['register']('authEvent',_0x2d8091=>(m(_0x2d8091==null?void 0x0:_0x2d8091['authEvent'],_0x143814,'invalid-auth-event'),{'status':_0x50001e['onEvent'](_0x2d8091['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x143814['_key']()]={'manager':_0x50001e},this['iframes'][_0x143814['_key']()]=_0x299e1f,_0x50001e;}['_isIframeWebStorageSupported'](_0x5c00cb,_0x2bea3f){this['iframes'][_0x5c00cb['_key']()]['send'](hi,{'type':hi},_0x21fb91=>{var _0x14c8c9;const _0x4a40b3=(_0x14c8c9=_0x21fb91==null?void 0x0:_0x21fb91[0x0])==null?void 0x0:_0x14c8c9[hi];_0x4a40b3!==void 0x0&&_0x2bea3f(!!_0x4a40b3),Q(_0x5c00cb,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x1d6346){const _0x54e675=_0x1d6346['_key']();return this['originValidationPromises'][_0x54e675]||(this['originValidationPromises'][_0x54e675]=Lp(_0x1d6346)),this['originValidationPromises'][_0x54e675];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const r_=s_;var Fr='@firebase/auth',Ur='1.11.1';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class o_{constructor(_0x183ddf){this['auth']=_0x183ddf,this['internalListeners']=new Map();}['getUid'](){var _0xf33745;return this['assertAuthConfigured'](),((_0xf33745=this['auth']['currentUser'])==null?void 0x0:_0xf33745['uid'])||null;}async['getToken'](_0x4ef0a6){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x4ef0a6)}:null;}['addAuthTokenListener'](_0x3fb8ae){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x3fb8ae))return;const _0x4488c6=this['auth']['onIdTokenChanged'](_0x586058=>{_0x3fb8ae((_0x586058==null?void 0x0:_0x586058['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x3fb8ae,_0x4488c6),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x5d0f51){this['assertAuthConfigured']();const _0x3ee8fa=this['internalListeners']['get'](_0x5d0f51);_0x3ee8fa&&(this['internalListeners']['delete'](_0x5d0f51),_0x3ee8fa(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function a_(_0x5c95c0){switch(_0x5c95c0){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function c_(_0x4865c7){Ze(new Le('auth',(_0x50d262,{options:_0x5212c6})=>{const _0x26b1bf=_0x50d262['getProvider']('app')['getImmediate'](),_0x197a4d=_0x50d262['getProvider']('heartbeat'),_0x58a5ac=_0x50d262['getProvider']('app-check-internal'),{apiKey:_0x572888,authDomain:_0x30575a}=_0x26b1bf['options'];m(_0x572888&&!_0x572888['includes'](':'),'invalid-api-key',{'appName':_0x26b1bf['name']});const _0xdebba4={'apiKey':_0x572888,'authDomain':_0x30575a,'clientPlatform':_0x4865c7,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x4865c7)},_0x264752=new kf(_0x26b1bf,_0x197a4d,_0x58a5ac,_0xdebba4);return Wf(_0x264752,_0x5212c6),_0x264752;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0xfdd5eb,_0x11417d,_0x563ae9)=>{_0xfdd5eb['getProvider']('auth-internal')['initialize']();})),Ze(new Le('auth-internal',_0x582603=>{const _0x3144f7=qe(_0x582603['getProvider']('auth')['getImmediate']());return(_0x1d5fd2=>new o_(_0x1d5fd2))(_0x3144f7);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Fr,Ur,a_(_0x4865c7)),me(Fr,Ur,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const l_=0x12c,h_=zr('authIdTokenMaxAge')||l_;let Wr=null;const u_=_0x32aa51=>async _0x4238f=>{const _0x49645a=_0x4238f&&await _0x4238f['getIdTokenResult'](),_0x37b7fa=_0x49645a&&(new Date()['getTime']()-Date['parse'](_0x49645a['issuedAtTime']))/0x3e8;if(_0x37b7fa&&_0x37b7fa>h_)return;const _0x462711=_0x49645a==null?void 0x0:_0x49645a['token'];Wr!==_0x462711&&(Wr=_0x462711,await fetch(_0x32aa51,{'method':_0x462711?'POST':'DELETE','headers':_0x462711?{'Authorization':'Bearer\x20'+_0x462711}:{}}));};function x_(_0x339c63=Zr()){const _0x4ff938=Bi(_0x339c63,'auth');if(_0x4ff938['isInitialized']())return _0x4ff938['getImmediate']();const _0x5d6fc0=Uf(_0x339c63,{'popupRedirectResolver':r_,'persistence':[gp,sp,za]}),_0x479387=zr('authTokenSyncURL');if(_0x479387&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x38b6d4=new URL(_0x479387,location['origin']);if(location['origin']===_0x38b6d4['origin']){const _0x290ce5=u_(_0x38b6d4['toString']());tp(_0x5d6fc0,_0x290ce5,()=>_0x290ce5(_0x5d6fc0['currentUser'])),ep(_0x5d6fc0,_0x382bf2=>_0x290ce5(_0x382bf2));}}const _0x1647bd=Gr('auth');return _0x1647bd&&Bf(_0x5d6fc0,'http://'+_0x1647bd),_0x5d6fc0;}function d_(){var _0x4cf7fd;return((_0x4cf7fd=document['getElementsByTagName']('head'))==null?void 0x0:_0x4cf7fd[0x0])??document;}Nf({'loadJS'(_0xe10064){return new Promise((_0x2b821d,_0x26a53f)=>{const _0x269186=document['createElement']('script');_0x269186['setAttribute']('src',_0xe10064),_0x269186['onload']=_0x2b821d,_0x269186['onerror']=_0x3d5f67=>{const _0x355efc=X('internal-error');_0x355efc['customData']=_0x3d5f67,_0x26a53f(_0x355efc);},_0x269186['type']='text/javascript',_0x269186['charset']='UTF-8',d_()['appendChild'](_0x269186);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),c_('Browser');export{P_ as A,L_ as B,C_ as C,x_ as a,sp as b,O_ as c,f_ as d,p_ as e,Zr as f,b_ as g,y_ as h,Sl as i,k_ as j,T_ as k,Ft as l,Ud as m,M_ as n,w_ as o,g_ as p,S_ as q,__ as r,D_ as s,A_ as t,m_ as u,R_ as v,N_ as w,E_ as x,v_ as y,I_ as z};