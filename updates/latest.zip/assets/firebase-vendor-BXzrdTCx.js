const Za=()=>{};var Ns={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Br={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x3e10b0,_0xa87f4e){if(!_0x3e10b0)throw rt(_0xa87f4e);},rt=function(_0x4e9da0){return new Error('Firebase\x20Database\x20('+Br['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x4e9da0);},Vr=function(_0x45bc1e){const _0x30c304=[];let _0x12de3c=0x0;for(let _0x3fd409=0x0;_0x3fd409<_0x45bc1e['length'];_0x3fd409++){let _0x54b4d2=_0x45bc1e['charCodeAt'](_0x3fd409);_0x54b4d2<0x80?_0x30c304[_0x12de3c++]=_0x54b4d2:_0x54b4d2<0x800?(_0x30c304[_0x12de3c++]=_0x54b4d2>>0x6|0xc0,_0x30c304[_0x12de3c++]=_0x54b4d2&0x3f|0x80):(_0x54b4d2&0xfc00)===0xd800&&_0x3fd409+0x1<_0x45bc1e['length']&&(_0x45bc1e['charCodeAt'](_0x3fd409+0x1)&0xfc00)===0xdc00?(_0x54b4d2=0x10000+((_0x54b4d2&0x3ff)<<0xa)+(_0x45bc1e['charCodeAt'](++_0x3fd409)&0x3ff),_0x30c304[_0x12de3c++]=_0x54b4d2>>0x12|0xf0,_0x30c304[_0x12de3c++]=_0x54b4d2>>0xc&0x3f|0x80,_0x30c304[_0x12de3c++]=_0x54b4d2>>0x6&0x3f|0x80,_0x30c304[_0x12de3c++]=_0x54b4d2&0x3f|0x80):(_0x30c304[_0x12de3c++]=_0x54b4d2>>0xc|0xe0,_0x30c304[_0x12de3c++]=_0x54b4d2>>0x6&0x3f|0x80,_0x30c304[_0x12de3c++]=_0x54b4d2&0x3f|0x80);}return _0x30c304;},ec=function(_0xc95651){const _0xe28e9=[];let _0x7ff07d=0x0,_0x26076d=0x0;for(;_0x7ff07d<_0xc95651['length'];){const _0x508858=_0xc95651[_0x7ff07d++];if(_0x508858<0x80)_0xe28e9[_0x26076d++]=String['fromCharCode'](_0x508858);else{if(_0x508858>0xbf&&_0x508858<0xe0){const _0x4d72be=_0xc95651[_0x7ff07d++];_0xe28e9[_0x26076d++]=String['fromCharCode']((_0x508858&0x1f)<<0x6|_0x4d72be&0x3f);}else{if(_0x508858>0xef&&_0x508858<0x16d){const _0x2c40a4=_0xc95651[_0x7ff07d++],_0x25f76b=_0xc95651[_0x7ff07d++],_0x24c703=_0xc95651[_0x7ff07d++],_0x94cb3b=((_0x508858&0x7)<<0x12|(_0x2c40a4&0x3f)<<0xc|(_0x25f76b&0x3f)<<0x6|_0x24c703&0x3f)-0x10000;_0xe28e9[_0x26076d++]=String['fromCharCode'](0xd800+(_0x94cb3b>>0xa)),_0xe28e9[_0x26076d++]=String['fromCharCode'](0xdc00+(_0x94cb3b&0x3ff));}else{const _0x2f8d44=_0xc95651[_0x7ff07d++],_0x58e249=_0xc95651[_0x7ff07d++];_0xe28e9[_0x26076d++]=String['fromCharCode']((_0x508858&0xf)<<0xc|(_0x2f8d44&0x3f)<<0x6|_0x58e249&0x3f);}}}}return _0xe28e9['join']('');},Li={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x224157,_0x22f1e0){if(!Array['isArray'](_0x224157))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x2d5aea=_0x22f1e0?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x36f8c0=[];for(let _0x4c01f0=0x0;_0x4c01f0<_0x224157['length'];_0x4c01f0+=0x3){const _0x4dafad=_0x224157[_0x4c01f0],_0x442195=_0x4c01f0+0x1<_0x224157['length'],_0x1db235=_0x442195?_0x224157[_0x4c01f0+0x1]:0x0,_0x5a4cc3=_0x4c01f0+0x2<_0x224157['length'],_0x3726a3=_0x5a4cc3?_0x224157[_0x4c01f0+0x2]:0x0,_0x70ccdb=_0x4dafad>>0x2,_0x1c00db=(_0x4dafad&0x3)<<0x4|_0x1db235>>0x4;let _0x3e6f7b=(_0x1db235&0xf)<<0x2|_0x3726a3>>0x6,_0x276a04=_0x3726a3&0x3f;_0x5a4cc3||(_0x276a04=0x40,_0x442195||(_0x3e6f7b=0x40)),_0x36f8c0['push'](_0x2d5aea[_0x70ccdb],_0x2d5aea[_0x1c00db],_0x2d5aea[_0x3e6f7b],_0x2d5aea[_0x276a04]);}return _0x36f8c0['join']('');},'encodeString'(_0xa38e2b,_0x5883b1){return this['HAS_NATIVE_SUPPORT']&&!_0x5883b1?btoa(_0xa38e2b):this['encodeByteArray'](Vr(_0xa38e2b),_0x5883b1);},'decodeString'(_0x240ec9,_0xf9267c){return this['HAS_NATIVE_SUPPORT']&&!_0xf9267c?atob(_0x240ec9):ec(this['decodeStringToByteArray'](_0x240ec9,_0xf9267c));},'decodeStringToByteArray'(_0x3ffee9,_0x464e18){this['init_']();const _0x5ea46d=_0x464e18?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x4c7601=[];for(let _0x132810=0x0;_0x132810<_0x3ffee9['length'];){const _0x819bb=_0x5ea46d[_0x3ffee9['charAt'](_0x132810++)],_0x1c3a88=_0x132810<_0x3ffee9['length']?_0x5ea46d[_0x3ffee9['charAt'](_0x132810)]:0x0;++_0x132810;const _0x28e232=_0x132810<_0x3ffee9['length']?_0x5ea46d[_0x3ffee9['charAt'](_0x132810)]:0x40;++_0x132810;const _0x57b945=_0x132810<_0x3ffee9['length']?_0x5ea46d[_0x3ffee9['charAt'](_0x132810)]:0x40;if(++_0x132810,_0x819bb==null||_0x1c3a88==null||_0x28e232==null||_0x57b945==null)throw new tc();const _0x5a257b=_0x819bb<<0x2|_0x1c3a88>>0x4;if(_0x4c7601['push'](_0x5a257b),_0x28e232!==0x40){const _0x25ff07=_0x1c3a88<<0x4&0xf0|_0x28e232>>0x2;if(_0x4c7601['push'](_0x25ff07),_0x57b945!==0x40){const _0x391525=_0x28e232<<0x6&0xc0|_0x57b945;_0x4c7601['push'](_0x391525);}}}return _0x4c7601;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x2dcfa1=0x0;_0x2dcfa1<this['ENCODED_VALS']['length'];_0x2dcfa1++)this['byteToCharMap_'][_0x2dcfa1]=this['ENCODED_VALS']['charAt'](_0x2dcfa1),this['charToByteMap_'][this['byteToCharMap_'][_0x2dcfa1]]=_0x2dcfa1,this['byteToCharMapWebSafe_'][_0x2dcfa1]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x2dcfa1),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x2dcfa1]]=_0x2dcfa1,_0x2dcfa1>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x2dcfa1)]=_0x2dcfa1,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x2dcfa1)]=_0x2dcfa1);}}};class tc extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Hr=function(_0x4ad2d6){const _0x10d56c=Vr(_0x4ad2d6);return Li['encodeByteArray'](_0x10d56c,!0x0);},cn=function(_0x354f53){return Hr(_0x354f53)['replace'](/\./g,'');},ln=function(_0x299dd3){try{return Li['decodeString'](_0x299dd3,!0x0);}catch(_0x5f2c15){console['error']('base64Decode\x20failed:\x20',_0x5f2c15);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nc(_0x62aa4b){return $r(void 0x0,_0x62aa4b);}function $r(_0x15ad14,_0x2a442f){if(!(_0x2a442f instanceof Object))return _0x2a442f;switch(_0x2a442f['constructor']){case Date:const _0x4efc56=_0x2a442f;return new Date(_0x4efc56['getTime']());case Object:_0x15ad14===void 0x0&&(_0x15ad14={});break;case Array:_0x15ad14=[];break;default:return _0x2a442f;}for(const _0x4ecf4a in _0x2a442f)!_0x2a442f['hasOwnProperty'](_0x4ecf4a)||!ic(_0x4ecf4a)||(_0x15ad14[_0x4ecf4a]=$r(_0x15ad14[_0x4ecf4a],_0x2a442f[_0x4ecf4a]));return _0x15ad14;}function ic(_0xa6acad){return _0xa6acad!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rc=()=>sc()['__FIREBASE_DEFAULTS__'],oc=()=>{if(typeof process>'u'||typeof Ns>'u')return;const _0x5d21d9=Ns['__FIREBASE_DEFAULTS__'];if(_0x5d21d9)return JSON['parse'](_0x5d21d9);},ac=()=>{if(typeof document>'u')return;let _0xe26be1;try{_0xe26be1=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x2e0c0c=_0xe26be1&&ln(_0xe26be1[0x1]);return _0x2e0c0c&&JSON['parse'](_0x2e0c0c);},xi=()=>{try{return Za()||rc()||oc()||ac();}catch(_0xb1f47d){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0xb1f47d);return;}},Gr=_0x5f2b03=>{var _0x5de4ba,_0x252697;return(_0x252697=(_0x5de4ba=xi())==null?void 0x0:_0x5de4ba['emulatorHosts'])==null?void 0x0:_0x252697[_0x5f2b03];},cc=_0x488f10=>{const _0x5bbbf8=Gr(_0x488f10);if(!_0x5bbbf8)return;const _0x3ccba1=_0x5bbbf8['lastIndexOf'](':');if(_0x3ccba1<=0x0||_0x3ccba1+0x1===_0x5bbbf8['length'])throw new Error('Invalid\x20host\x20'+_0x5bbbf8+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x259844=parseInt(_0x5bbbf8['substring'](_0x3ccba1+0x1),0xa);return _0x5bbbf8[0x0]==='['?[_0x5bbbf8['substring'](0x1,_0x3ccba1-0x1),_0x259844]:[_0x5bbbf8['substring'](0x0,_0x3ccba1),_0x259844];},qr=()=>{var _0xf8ee4d;return(_0xf8ee4d=xi())==null?void 0x0:_0xf8ee4d['config'];},zr=_0x1a6399=>{var _0x5c5e47;return(_0x5c5e47=xi())==null?void 0x0:_0x5c5e47['_'+_0x1a6399];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x2925fe,_0x3414d4)=>{this['resolve']=_0x2925fe,this['reject']=_0x3414d4;});}['wrapCallback'](_0xa1c641){return(_0x1e07e9,_0xeea16b)=>{_0x1e07e9?this['reject'](_0x1e07e9):this['resolve'](_0xeea16b),typeof _0xa1c641=='function'&&(this['promise']['catch'](()=>{}),_0xa1c641['length']===0x1?_0xa1c641(_0x1e07e9):_0xa1c641(_0x1e07e9,_0xeea16b));};}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x5c4473){try{return(_0x5c4473['startsWith']('http://')||_0x5c4473['startsWith']('https://')?new URL(_0x5c4473)['hostname']:_0x5c4473)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x5e96ab){return(await fetch(_0x5e96ab,{'credentials':'include'}))['ok'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function lc(_0x2c3fe7,_0x1b8694){if(_0x2c3fe7['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x47a8e5={'alg':'none','type':'JWT'},_0x167c78=_0x1b8694||'demo-project',_0x546057=_0x2c3fe7['iat']||0x0,_0x5e7b79=_0x2c3fe7['sub']||_0x2c3fe7['user_id'];if(!_0x5e7b79)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x41087b={'iss':'https://securetoken.google.com/'+_0x167c78,'aud':_0x167c78,'iat':_0x546057,'exp':_0x546057+0xe10,'auth_time':_0x546057,'sub':_0x5e7b79,'user_id':_0x5e7b79,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x2c3fe7};return[cn(JSON['stringify'](_0x47a8e5)),cn(JSON['stringify'](_0x41087b)),'']['join']('.');}const It={};function hc(){const _0x1c0419={'prod':[],'emulator':[]};for(const _0x102cf3 of Object['keys'](It))It[_0x102cf3]?_0x1c0419['emulator']['push'](_0x102cf3):_0x1c0419['prod']['push'](_0x102cf3);return _0x1c0419;}function uc(_0xdc7529){let _0xfd01a6=document['getElementById'](_0xdc7529),_0x3d0b63=!0x1;return _0xfd01a6||(_0xfd01a6=document['createElement']('div'),_0xfd01a6['setAttribute']('id',_0xdc7529),_0x3d0b63=!0x0),{'created':_0x3d0b63,'element':_0xfd01a6};}let Ps=!0x1;function Kr(_0x480b25,_0xf70cdd){if(typeof window>'u'||typeof document>'u'||!at(window['location']['host'])||It[_0x480b25]===_0xf70cdd||It[_0x480b25]||Ps)return;It[_0x480b25]=_0xf70cdd;function _0x61aac9(_0x3b7b21){return'__firebase__banner__'+_0x3b7b21;}const _0x633521='__firebase__banner',_0x2654c6=hc()['prod']['length']>0x0;function _0x1fe653(){const _0x419ad4=document['getElementById'](_0x633521);_0x419ad4&&_0x419ad4['remove']();}function _0x5367c2(_0xe27830){_0xe27830['style']['display']='flex',_0xe27830['style']['background']='#7faaf0',_0xe27830['style']['position']='fixed',_0xe27830['style']['bottom']='5px',_0xe27830['style']['left']='5px',_0xe27830['style']['padding']='.5em',_0xe27830['style']['borderRadius']='5px',_0xe27830['style']['alignItems']='center';}function _0x3cab5e(_0x406306,_0x29524b){_0x406306['setAttribute']('width','24'),_0x406306['setAttribute']('id',_0x29524b),_0x406306['setAttribute']('height','24'),_0x406306['setAttribute']('viewBox','0\x200\x2024\x2024'),_0x406306['setAttribute']('fill','none'),_0x406306['style']['marginLeft']='-6px';}function _0x3e9f80(){const _0x3bd846=document['createElement']('span');return _0x3bd846['style']['cursor']='pointer',_0x3bd846['style']['marginLeft']='16px',_0x3bd846['style']['fontSize']='24px',_0x3bd846['innerHTML']='\x20&times;',_0x3bd846['onclick']=()=>{Ps=!0x0,_0x1fe653();},_0x3bd846;}function _0x1d9b8b(_0xc0df2a,_0xd0c12e){_0xc0df2a['setAttribute']('id',_0xd0c12e),_0xc0df2a['innerText']='Learn\x20more',_0xc0df2a['href']='https://firebase.google.com/docs/studio/preview-apps#preview-backend',_0xc0df2a['setAttribute']('target','__blank'),_0xc0df2a['style']['paddingLeft']='5px',_0xc0df2a['style']['textDecoration']='underline';}function _0x296763(){const _0x289094=uc(_0x633521),_0x37b1e0=_0x61aac9('text'),_0x476b0b=document['getElementById'](_0x37b1e0)||document['createElement']('span'),_0x2f8b82=_0x61aac9('learnmore'),_0x4f1db5=document['getElementById'](_0x2f8b82)||document['createElement']('a'),_0x593e53=_0x61aac9('preprendIcon'),_0x15f6f5=document['getElementById'](_0x593e53)||document['createElementNS']('http://www.w3.org/2000/svg','svg');if(_0x289094['created']){const _0x43a637=_0x289094['element'];_0x5367c2(_0x43a637),_0x1d9b8b(_0x4f1db5,_0x2f8b82);const _0x581d39=_0x3e9f80();_0x3cab5e(_0x15f6f5,_0x593e53),_0x43a637['append'](_0x15f6f5,_0x476b0b,_0x4f1db5,_0x581d39),document['body']['appendChild'](_0x43a637);}_0x2654c6?(_0x476b0b['innerText']='Preview\x20backend\x20disconnected.',_0x15f6f5['innerHTML']='<g\x20clip-path=\x22url(#clip0_6013_33858)\x22>\x0a<path\x20d=\x22M4.8\x2017.6L12\x205.6L19.2\x2017.6H4.8ZM6.91667\x2016.4H17.0833L12\x207.93333L6.91667\x2016.4ZM12\x2015.6C12.1667\x2015.6\x2012.3056\x2015.5444\x2012.4167\x2015.4333C12.5389\x2015.3111\x2012.6\x2015.1667\x2012.6\x2015C12.6\x2014.8333\x2012.5389\x2014.6944\x2012.4167\x2014.5833C12.3056\x2014.4611\x2012.1667\x2014.4\x2012\x2014.4C11.8333\x2014.4\x2011.6889\x2014.4611\x2011.5667\x2014.5833C11.4556\x2014.6944\x2011.4\x2014.8333\x2011.4\x2015C11.4\x2015.1667\x2011.4556\x2015.3111\x2011.5667\x2015.4333C11.6889\x2015.5444\x2011.8333\x2015.6\x2012\x2015.6ZM11.4\x2013.6H12.6V10.4H11.4V13.6Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6013_33858\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>'):(_0x15f6f5['innerHTML']='<g\x20clip-path=\x22url(#clip0_6083_34804)\x22>\x0a<path\x20d=\x22M11.4\x2015.2H12.6V11.2H11.4V15.2ZM12\x2010C12.1667\x2010\x2012.3056\x209.94444\x2012.4167\x209.83333C12.5389\x209.71111\x2012.6\x209.56667\x2012.6\x209.4C12.6\x209.23333\x2012.5389\x209.09444\x2012.4167\x208.98333C12.3056\x208.86111\x2012.1667\x208.8\x2012\x208.8C11.8333\x208.8\x2011.6889\x208.86111\x2011.5667\x208.98333C11.4556\x209.09444\x2011.4\x209.23333\x2011.4\x209.4C11.4\x209.56667\x2011.4556\x209.71111\x2011.5667\x209.83333C11.6889\x209.94444\x2011.8333\x2010\x2012\x2010ZM12\x2018.4C11.1222\x2018.4\x2010.2944\x2018.2333\x209.51667\x2017.9C8.73889\x2017.5667\x208.05556\x2017.1111\x207.46667\x2016.5333C6.88889\x2015.9444\x206.43333\x2015.2611\x206.1\x2014.4833C5.76667\x2013.7056\x205.6\x2012.8778\x205.6\x2012C5.6\x2011.1111\x205.76667\x2010.2833\x206.1\x209.51667C6.43333\x208.73889\x206.88889\x208.06111\x207.46667\x207.48333C8.05556\x206.89444\x208.73889\x206.43333\x209.51667\x206.1C10.2944\x205.76667\x2011.1222\x205.6\x2012\x205.6C12.8889\x205.6\x2013.7167\x205.76667\x2014.4833\x206.1C15.2611\x206.43333\x2015.9389\x206.89444\x2016.5167\x207.48333C17.1056\x208.06111\x2017.5667\x208.73889\x2017.9\x209.51667C18.2333\x2010.2833\x2018.4\x2011.1111\x2018.4\x2012C18.4\x2012.8778\x2018.2333\x2013.7056\x2017.9\x2014.4833C17.5667\x2015.2611\x2017.1056\x2015.9444\x2016.5167\x2016.5333C15.9389\x2017.1111\x2015.2611\x2017.5667\x2014.4833\x2017.9C13.7167\x2018.2333\x2012.8889\x2018.4\x2012\x2018.4ZM12\x2017.2C13.4444\x2017.2\x2014.6722\x2016.6944\x2015.6833\x2015.6833C16.6944\x2014.6722\x2017.2\x2013.4444\x2017.2\x2012C17.2\x2010.5556\x2016.6944\x209.32778\x2015.6833\x208.31667C14.6722\x207.30555\x2013.4444\x206.8\x2012\x206.8C10.5556\x206.8\x209.32778\x207.30555\x208.31667\x208.31667C7.30556\x209.32778\x206.8\x2010.5556\x206.8\x2012C6.8\x2013.4444\x207.30556\x2014.6722\x208.31667\x2015.6833C9.32778\x2016.6944\x2010.5556\x2017.2\x2012\x2017.2Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6083_34804\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>',_0x476b0b['innerText']='Preview\x20backend\x20running\x20in\x20this\x20workspace.'),_0x476b0b['setAttribute']('id',_0x37b1e0);}document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x296763):_0x296763();}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Fi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x3c1bab=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x3c1bab=='object'&&_0x3c1bab['id']!==void 0x0;}function Yr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x10b257=W();return _0x10b257['indexOf']('MSIE\x20')>=0x0||_0x10b257['indexOf']('Trident/')>=0x0;}function _c(){return Br['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0xa33f28,_0x219a1d)=>{try{let _0x3882cf=!0x0;const _0x48fb6a='validate-browser-context-for-indexeddb-analytics-module',_0x1db03f=self['indexedDB']['open'](_0x48fb6a);_0x1db03f['onsuccess']=()=>{_0x1db03f['result']['close'](),_0x3882cf||self['indexedDB']['deleteDatabase'](_0x48fb6a),_0xa33f28(!0x0);},_0x1db03f['onupgradeneeded']=()=>{_0x3882cf=!0x1;},_0x1db03f['onerror']=()=>{var _0x40915a;_0x219a1d(((_0x40915a=_0x1db03f['error'])==null?void 0x0:_0x40915a['message'])||'');};}catch(_0x1974b0){_0x219a1d(_0x1974b0);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Se extends Error{constructor(_0xe00fb4,_0x456c63,_0x23893b){super(_0x456c63),this['code']=_0xe00fb4,this['customData']=_0x23893b,this['name']=yc,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Bt['prototype']['create']);}}class Bt{constructor(_0x474620,_0x390ccb,_0x1660dc){this['service']=_0x474620,this['serviceName']=_0x390ccb,this['errors']=_0x1660dc;}['create'](_0xc0cd2d,..._0x476471){const _0x51ce9b=_0x476471[0x0]||{},_0x169b13=this['service']+'/'+_0xc0cd2d,_0x34950f=this['errors'][_0xc0cd2d],_0x9a3deb=_0x34950f?vc(_0x34950f,_0x51ce9b):'Error',_0xbe8da7=this['serviceName']+':\x20'+_0x9a3deb+'\x20('+_0x169b13+').';return new Se(_0x169b13,_0xbe8da7,_0x51ce9b);}}function vc(_0x2a55b3,_0x31f6ed){return _0x2a55b3['replace'](Ec,(_0x199351,_0xeb73f5)=>{const _0x1fbcb9=_0x31f6ed[_0xeb73f5];return _0x1fbcb9!=null?String(_0x1fbcb9):'<'+_0xeb73f5+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function At(_0xef9218){return JSON['parse'](_0xef9218);}function O(_0x275840){return JSON['stringify'](_0x275840);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qr=function(_0xdf0ea7){let _0x2a7d9c={},_0x438f99={},_0x5cf4d4={},_0x4ce332='';try{const _0x3bf286=_0xdf0ea7['split']('.');_0x2a7d9c=At(ln(_0x3bf286[0x0])||''),_0x438f99=At(ln(_0x3bf286[0x1])||''),_0x4ce332=_0x3bf286[0x2],_0x5cf4d4=_0x438f99['d']||{},delete _0x438f99['d'];}catch{}return{'header':_0x2a7d9c,'claims':_0x438f99,'data':_0x5cf4d4,'signature':_0x4ce332};},Ic=function(_0x1a786c){const _0x30e4a6=Qr(_0x1a786c),_0x3d5543=_0x30e4a6['claims'];return!!_0x3d5543&&typeof _0x3d5543=='object'&&_0x3d5543['hasOwnProperty']('iat');},wc=function(_0x4af026){const _0x8b2c54=Qr(_0x4af026)['claims'];return typeof _0x8b2c54=='object'&&_0x8b2c54['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function J(_0x32b1ce,_0x265508){return Object['prototype']['hasOwnProperty']['call'](_0x32b1ce,_0x265508);}function De(_0x3c0503,_0xdc2090){if(Object['prototype']['hasOwnProperty']['call'](_0x3c0503,_0xdc2090))return _0x3c0503[_0xdc2090];}function ui(_0x384885){for(const _0xee9689 in _0x384885)if(Object['prototype']['hasOwnProperty']['call'](_0x384885,_0xee9689))return!0x1;return!0x0;}function hn(_0x119907,_0x5eb5cb,_0x58f140){const _0xe69118={};for(const _0x33305b in _0x119907)Object['prototype']['hasOwnProperty']['call'](_0x119907,_0x33305b)&&(_0xe69118[_0x33305b]=_0x5eb5cb['call'](_0x58f140,_0x119907[_0x33305b],_0x33305b,_0x119907));return _0xe69118;}function Me(_0xfc9733,_0x264c18){if(_0xfc9733===_0x264c18)return!0x0;const _0x2bde2c=Object['keys'](_0xfc9733),_0x17ed1e=Object['keys'](_0x264c18);for(const _0x41fce2 of _0x2bde2c){if(!_0x17ed1e['includes'](_0x41fce2))return!0x1;const _0x35bd1e=_0xfc9733[_0x41fce2],_0x51fe3d=_0x264c18[_0x41fce2];if(Os(_0x35bd1e)&&Os(_0x51fe3d)){if(!Me(_0x35bd1e,_0x51fe3d))return!0x1;}else{if(_0x35bd1e!==_0x51fe3d)return!0x1;}}for(const _0x11b3ec of _0x17ed1e)if(!_0x2bde2c['includes'](_0x11b3ec))return!0x1;return!0x0;}function Os(_0x1d49bf){return _0x1d49bf!==null&&typeof _0x1d49bf=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ct(_0x4f935a){const _0x130eea=[];for(const [_0x5f1cd4,_0x39f1d6]of Object['entries'](_0x4f935a))Array['isArray'](_0x39f1d6)?_0x39f1d6['forEach'](_0x2d2c7e=>{_0x130eea['push'](encodeURIComponent(_0x5f1cd4)+'='+encodeURIComponent(_0x2d2c7e));}):_0x130eea['push'](encodeURIComponent(_0x5f1cd4)+'='+encodeURIComponent(_0x39f1d6));return _0x130eea['length']?'&'+_0x130eea['join']('&'):'';}function vt(_0x8368b7){const _0x26c44c={};return _0x8368b7['replace'](/^\?/,'')['split']('&')['forEach'](_0x3e5030=>{if(_0x3e5030){const [_0x1c361d,_0x30ab92]=_0x3e5030['split']('=');_0x26c44c[decodeURIComponent(_0x1c361d)]=decodeURIComponent(_0x30ab92);}}),_0x26c44c;}function Et(_0x474c15){const _0x5e773e=_0x474c15['indexOf']('?');if(!_0x5e773e)return'';const _0x393774=_0x474c15['indexOf']('#',_0x5e773e);return _0x474c15['substring'](_0x5e773e,_0x393774>0x0?_0x393774:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x18d364=0x1;_0x18d364<this['blockSize'];++_0x18d364)this['pad_'][_0x18d364]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x2795ff,_0x499b96){_0x499b96||(_0x499b96=0x0);const _0x27b4ce=this['W_'];if(typeof _0x2795ff=='string'){for(let _0x102756=0x0;_0x102756<0x10;_0x102756++)_0x27b4ce[_0x102756]=_0x2795ff['charCodeAt'](_0x499b96)<<0x18|_0x2795ff['charCodeAt'](_0x499b96+0x1)<<0x10|_0x2795ff['charCodeAt'](_0x499b96+0x2)<<0x8|_0x2795ff['charCodeAt'](_0x499b96+0x3),_0x499b96+=0x4;}else{for(let _0x3ad211=0x0;_0x3ad211<0x10;_0x3ad211++)_0x27b4ce[_0x3ad211]=_0x2795ff[_0x499b96]<<0x18|_0x2795ff[_0x499b96+0x1]<<0x10|_0x2795ff[_0x499b96+0x2]<<0x8|_0x2795ff[_0x499b96+0x3],_0x499b96+=0x4;}for(let _0x7a749d=0x10;_0x7a749d<0x50;_0x7a749d++){const _0x5f3156=_0x27b4ce[_0x7a749d-0x3]^_0x27b4ce[_0x7a749d-0x8]^_0x27b4ce[_0x7a749d-0xe]^_0x27b4ce[_0x7a749d-0x10];_0x27b4ce[_0x7a749d]=(_0x5f3156<<0x1|_0x5f3156>>>0x1f)&0xffffffff;}let _0x5a7428=this['chain_'][0x0],_0x4de2cf=this['chain_'][0x1],_0x244bb5=this['chain_'][0x2],_0x135f38=this['chain_'][0x3],_0x52afd2=this['chain_'][0x4],_0x1b781b,_0x1d0805;for(let _0x3df159=0x0;_0x3df159<0x50;_0x3df159++){_0x3df159<0x28?_0x3df159<0x14?(_0x1b781b=_0x135f38^_0x4de2cf&(_0x244bb5^_0x135f38),_0x1d0805=0x5a827999):(_0x1b781b=_0x4de2cf^_0x244bb5^_0x135f38,_0x1d0805=0x6ed9eba1):_0x3df159<0x3c?(_0x1b781b=_0x4de2cf&_0x244bb5|_0x135f38&(_0x4de2cf|_0x244bb5),_0x1d0805=0x8f1bbcdc):(_0x1b781b=_0x4de2cf^_0x244bb5^_0x135f38,_0x1d0805=0xca62c1d6);const _0x5d12c5=(_0x5a7428<<0x5|_0x5a7428>>>0x1b)+_0x1b781b+_0x52afd2+_0x1d0805+_0x27b4ce[_0x3df159]&0xffffffff;_0x52afd2=_0x135f38,_0x135f38=_0x244bb5,_0x244bb5=(_0x4de2cf<<0x1e|_0x4de2cf>>>0x2)&0xffffffff,_0x4de2cf=_0x5a7428,_0x5a7428=_0x5d12c5;}this['chain_'][0x0]=this['chain_'][0x0]+_0x5a7428&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x4de2cf&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x244bb5&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x135f38&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x52afd2&0xffffffff;}['update'](_0x3256ac,_0x355206){if(_0x3256ac==null)return;_0x355206===void 0x0&&(_0x355206=_0x3256ac['length']);const _0x13b5d0=_0x355206-this['blockSize'];let _0x2787f7=0x0;const _0x407602=this['buf_'];let _0x476106=this['inbuf_'];for(;_0x2787f7<_0x355206;){if(_0x476106===0x0){for(;_0x2787f7<=_0x13b5d0;)this['compress_'](_0x3256ac,_0x2787f7),_0x2787f7+=this['blockSize'];}if(typeof _0x3256ac=='string'){for(;_0x2787f7<_0x355206;)if(_0x407602[_0x476106]=_0x3256ac['charCodeAt'](_0x2787f7),++_0x476106,++_0x2787f7,_0x476106===this['blockSize']){this['compress_'](_0x407602),_0x476106=0x0;break;}}else{for(;_0x2787f7<_0x355206;)if(_0x407602[_0x476106]=_0x3256ac[_0x2787f7],++_0x476106,++_0x2787f7,_0x476106===this['blockSize']){this['compress_'](_0x407602),_0x476106=0x0;break;}}}this['inbuf_']=_0x476106,this['total_']+=_0x355206;}['digest'](){const _0x143c2e=[];let _0x2b9ade=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x5f43c5=this['blockSize']-0x1;_0x5f43c5>=0x38;_0x5f43c5--)this['buf_'][_0x5f43c5]=_0x2b9ade&0xff,_0x2b9ade/=0x100;this['compress_'](this['buf_']);let _0x1bdca1=0x0;for(let _0x48667f=0x0;_0x48667f<0x5;_0x48667f++)for(let _0x584761=0x18;_0x584761>=0x0;_0x584761-=0x8)_0x143c2e[_0x1bdca1]=this['chain_'][_0x48667f]>>_0x584761&0xff,++_0x1bdca1;return _0x143c2e;}}function Tc(_0x400dfc,_0x5647ea){const _0x32eda1=new Sc(_0x400dfc,_0x5647ea);return _0x32eda1['subscribe']['bind'](_0x32eda1);}class Sc{constructor(_0x3630de,_0x3c468f){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x3c468f,this['task']['then'](()=>{_0x3630de(this);})['catch'](_0x100180=>{this['error'](_0x100180);});}['next'](_0x50821d){this['forEachObserver'](_0x3aeb11=>{_0x3aeb11['next'](_0x50821d);});}['error'](_0x285acd){this['forEachObserver'](_0x22be52=>{_0x22be52['error'](_0x285acd);}),this['close'](_0x285acd);}['complete'](){this['forEachObserver'](_0x52fa7b=>{_0x52fa7b['complete']();}),this['close']();}['subscribe'](_0x21271a,_0x1549d1,_0x1a4365){let _0x53a9b8;if(_0x21271a===void 0x0&&_0x1549d1===void 0x0&&_0x1a4365===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x21271a,['next','error','complete'])?_0x53a9b8=_0x21271a:_0x53a9b8={'next':_0x21271a,'error':_0x1549d1,'complete':_0x1a4365},_0x53a9b8['next']===void 0x0&&(_0x53a9b8['next']=Jn),_0x53a9b8['error']===void 0x0&&(_0x53a9b8['error']=Jn),_0x53a9b8['complete']===void 0x0&&(_0x53a9b8['complete']=Jn);const _0x38a48a=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x53a9b8['error'](this['finalError']):_0x53a9b8['complete']();}catch{}}),this['observers']['push'](_0x53a9b8),_0x38a48a;}['unsubscribeOne'](_0x34a766){this['observers']===void 0x0||this['observers'][_0x34a766]===void 0x0||(delete this['observers'][_0x34a766],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x5b2e77){if(!this['finalized']){for(let _0x17e003=0x0;_0x17e003<this['observers']['length'];_0x17e003++)this['sendOne'](_0x17e003,_0x5b2e77);}}['sendOne'](_0x186f5f,_0x3b9deb){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0x186f5f]!==void 0x0)try{_0x3b9deb(this['observers'][_0x186f5f]);}catch(_0x371307){typeof console<'u'&&console['error']&&console['error'](_0x371307);}});}['close'](_0x57ef47){this['finalized']||(this['finalized']=!0x0,_0x57ef47!==void 0x0&&(this['finalError']=_0x57ef47),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x2442a9,_0x3fef35){if(typeof _0x2442a9!='object'||_0x2442a9===null)return!0x1;for(const _0x2b34c3 of _0x3fef35)if(_0x2b34c3 in _0x2442a9&&typeof _0x2442a9[_0x2b34c3]=='function')return!0x0;return!0x1;}function Jn(){}function Pn(_0x229d46,_0x2e50d6){return _0x229d46+'\x20failed:\x20'+_0x2e50d6+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0xe52425){const _0x51e723=[];let _0x1eb994=0x0;for(let _0x38fa6a=0x0;_0x38fa6a<_0xe52425['length'];_0x38fa6a++){let _0x50ad13=_0xe52425['charCodeAt'](_0x38fa6a);if(_0x50ad13>=0xd800&&_0x50ad13<=0xdbff){const _0x44f625=_0x50ad13-0xd800;_0x38fa6a++,f(_0x38fa6a<_0xe52425['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x4f80ac=_0xe52425['charCodeAt'](_0x38fa6a)-0xdc00;_0x50ad13=0x10000+(_0x44f625<<0xa)+_0x4f80ac;}_0x50ad13<0x80?_0x51e723[_0x1eb994++]=_0x50ad13:_0x50ad13<0x800?(_0x51e723[_0x1eb994++]=_0x50ad13>>0x6|0xc0,_0x51e723[_0x1eb994++]=_0x50ad13&0x3f|0x80):_0x50ad13<0x10000?(_0x51e723[_0x1eb994++]=_0x50ad13>>0xc|0xe0,_0x51e723[_0x1eb994++]=_0x50ad13>>0x6&0x3f|0x80,_0x51e723[_0x1eb994++]=_0x50ad13&0x3f|0x80):(_0x51e723[_0x1eb994++]=_0x50ad13>>0x12|0xf0,_0x51e723[_0x1eb994++]=_0x50ad13>>0xc&0x3f|0x80,_0x51e723[_0x1eb994++]=_0x50ad13>>0x6&0x3f|0x80,_0x51e723[_0x1eb994++]=_0x50ad13&0x3f|0x80);}return _0x51e723;},On=function(_0x178945){let _0x2cd9a5=0x0;for(let _0x19aab4=0x0;_0x19aab4<_0x178945['length'];_0x19aab4++){const _0x771fe5=_0x178945['charCodeAt'](_0x19aab4);_0x771fe5<0x80?_0x2cd9a5++:_0x771fe5<0x800?_0x2cd9a5+=0x2:_0x771fe5>=0xd800&&_0x771fe5<=0xdbff?(_0x2cd9a5+=0x4,_0x19aab4++):_0x2cd9a5+=0x3;}return _0x2cd9a5;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function N(_0xb71b90){return _0xb71b90&&_0xb71b90['_delegate']?_0xb71b90['_delegate']:_0xb71b90;}class Le{constructor(_0x33d765,_0x43bbf2,_0x3d48a6){this['name']=_0x33d765,this['instanceFactory']=_0x43bbf2,this['type']=_0x3d48a6,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x11939f){return this['instantiationMode']=_0x11939f,this;}['setMultipleInstances'](_0x477249){return this['multipleInstances']=_0x477249,this;}['setServiceProps'](_0x3b844c){return this['serviceProps']=_0x3b844c,this;}['setInstanceCreatedCallback'](_0x285bcf){return this['onInstanceCreated']=_0x285bcf,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0x49dfa4,_0x2e59ac){this['name']=_0x49dfa4,this['container']=_0x2e59ac,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x5c2ff){const _0x17dc99=this['normalizeInstanceIdentifier'](_0x5c2ff);if(!this['instancesDeferred']['has'](_0x17dc99)){const _0x362ee6=new ot();if(this['instancesDeferred']['set'](_0x17dc99,_0x362ee6),this['isInitialized'](_0x17dc99)||this['shouldAutoInitialize']())try{const _0x5c0c17=this['getOrInitializeService']({'instanceIdentifier':_0x17dc99});_0x5c0c17&&_0x362ee6['resolve'](_0x5c0c17);}catch{}}return this['instancesDeferred']['get'](_0x17dc99)['promise'];}['getImmediate'](_0x258a48){const _0x234cc9=this['normalizeInstanceIdentifier'](_0x258a48==null?void 0x0:_0x258a48['identifier']),_0x176546=(_0x258a48==null?void 0x0:_0x258a48['optional'])??!0x1;if(this['isInitialized'](_0x234cc9)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x234cc9});}catch(_0x206a40){if(_0x176546)return null;throw _0x206a40;}else{if(_0x176546)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x2cbd24){if(_0x2cbd24['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x2cbd24['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x2cbd24,!!this['shouldAutoInitialize']()){if(Nc(_0x2cbd24))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x21390c,_0x427a76]of this['instancesDeferred']['entries']()){const _0x20ffc8=this['normalizeInstanceIdentifier'](_0x21390c);try{const _0x4d2bfb=this['getOrInitializeService']({'instanceIdentifier':_0x20ffc8});_0x427a76['resolve'](_0x4d2bfb);}catch{}}}}['clearInstance'](_0x1b6903=Ne){this['instancesDeferred']['delete'](_0x1b6903),this['instancesOptions']['delete'](_0x1b6903),this['instances']['delete'](_0x1b6903);}async['delete'](){const _0x1695c4=Array['from'](this['instances']['values']());await Promise['all']([..._0x1695c4['filter'](_0x472bb6=>'INTERNAL'in _0x472bb6)['map'](_0x1025f7=>_0x1025f7['INTERNAL']['delete']()),..._0x1695c4['filter'](_0x30a035=>'_delete'in _0x30a035)['map'](_0x5814dc=>_0x5814dc['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x47a8f9=Ne){return this['instances']['has'](_0x47a8f9);}['getOptions'](_0x528c12=Ne){return this['instancesOptions']['get'](_0x528c12)||{};}['initialize'](_0x121cd3={}){const {options:_0x28114b={}}=_0x121cd3,_0x53d73e=this['normalizeInstanceIdentifier'](_0x121cd3['instanceIdentifier']);if(this['isInitialized'](_0x53d73e))throw Error(this['name']+'('+_0x53d73e+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x477710=this['getOrInitializeService']({'instanceIdentifier':_0x53d73e,'options':_0x28114b});for(const [_0x39479c,_0x31d4dc]of this['instancesDeferred']['entries']()){const _0x1e5b59=this['normalizeInstanceIdentifier'](_0x39479c);_0x53d73e===_0x1e5b59&&_0x31d4dc['resolve'](_0x477710);}return _0x477710;}['onInit'](_0x500535,_0x1269fb){const _0x1d97c4=this['normalizeInstanceIdentifier'](_0x1269fb),_0x157d55=this['onInitCallbacks']['get'](_0x1d97c4)??new Set();_0x157d55['add'](_0x500535),this['onInitCallbacks']['set'](_0x1d97c4,_0x157d55);const _0x165de1=this['instances']['get'](_0x1d97c4);return _0x165de1&&_0x500535(_0x165de1,_0x1d97c4),()=>{_0x157d55['delete'](_0x500535);};}['invokeOnInitCallbacks'](_0x39cf10,_0x37a086){const _0x53fd08=this['onInitCallbacks']['get'](_0x37a086);if(_0x53fd08){for(const _0x4a98a7 of _0x53fd08)try{_0x4a98a7(_0x39cf10,_0x37a086);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x4fbc63,options:_0xd05b4b={}}){let _0x568b32=this['instances']['get'](_0x4fbc63);if(!_0x568b32&&this['component']&&(_0x568b32=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x4fbc63),'options':_0xd05b4b}),this['instances']['set'](_0x4fbc63,_0x568b32),this['instancesOptions']['set'](_0x4fbc63,_0xd05b4b),this['invokeOnInitCallbacks'](_0x568b32,_0x4fbc63),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x4fbc63,_0x568b32);}catch{}return _0x568b32||null;}['normalizeInstanceIdentifier'](_0x478f7a=Ne){return this['component']?this['component']['multipleInstances']?_0x478f7a:Ne:_0x478f7a;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x5b2d7c){return _0x5b2d7c===Ne?void 0x0:_0x5b2d7c;}function Nc(_0x19cdeb){return _0x19cdeb['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pc{constructor(_0x29e0b5){this['name']=_0x29e0b5,this['providers']=new Map();}['addComponent'](_0x2a843f){const _0x49f830=this['getProvider'](_0x2a843f['name']);if(_0x49f830['isComponentSet']())throw new Error('Component\x20'+_0x2a843f['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x49f830['setComponent'](_0x2a843f);}['addOrOverwriteComponent'](_0x39b5ec){this['getProvider'](_0x39b5ec['name'])['isComponentSet']()&&this['providers']['delete'](_0x39b5ec['name']),this['addComponent'](_0x39b5ec);}['getProvider'](_0x3c028f){if(this['providers']['has'](_0x3c028f))return this['providers']['get'](_0x3c028f);const _0x445bcb=new Ac(_0x3c028f,this);return this['providers']['set'](_0x3c028f,_0x445bcb),_0x445bcb;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x5c2c44){_0x5c2c44[_0x5c2c44['DEBUG']=0x0]='DEBUG',_0x5c2c44[_0x5c2c44['VERBOSE']=0x1]='VERBOSE',_0x5c2c44[_0x5c2c44['INFO']=0x2]='INFO',_0x5c2c44[_0x5c2c44['WARN']=0x3]='WARN',_0x5c2c44[_0x5c2c44['ERROR']=0x4]='ERROR',_0x5c2c44[_0x5c2c44['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x4f27ba,_0x1e058c,..._0x289a59)=>{if(_0x1e058c<_0x4f27ba['logLevel'])return;const _0x4e4526=new Date()['toISOString'](),_0x1ab46b=Mc[_0x1e058c];if(_0x1ab46b)console[_0x1ab46b]('['+_0x4e4526+']\x20\x20'+_0x4f27ba['name']+':',..._0x289a59);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x1e058c+')');};class Ui{constructor(_0x3a06c7){this['name']=_0x3a06c7,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x5451ca){if(!(_0x5451ca in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x5451ca+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x5451ca;}['setLogLevel'](_0x3f80f5){this['_logLevel']=typeof _0x3f80f5=='string'?Oc[_0x3f80f5]:_0x3f80f5;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x5cb3d6){if(typeof _0x5cb3d6!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x5cb3d6;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x1d9933){this['_userLogHandler']=_0x1d9933;}['debug'](..._0x4542e1){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x4542e1),this['_logHandler'](this,T['DEBUG'],..._0x4542e1);}['log'](..._0x14c850){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x14c850),this['_logHandler'](this,T['VERBOSE'],..._0x14c850);}['info'](..._0xaea1a9){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0xaea1a9),this['_logHandler'](this,T['INFO'],..._0xaea1a9);}['warn'](..._0x305f20){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x305f20),this['_logHandler'](this,T['WARN'],..._0x305f20);}['error'](..._0x54da25){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x54da25),this['_logHandler'](this,T['ERROR'],..._0x54da25);}}const xc=(_0x2fcff9,_0x242543)=>_0x242543['some'](_0x533341=>_0x2fcff9 instanceof _0x533341);let Ds,Ms;function Fc(){return Ds||(Ds=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ms||(Ms=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),di=new WeakMap(),Xr=new WeakMap(),Xn=new WeakMap(),Wi=new WeakMap();function Wc(_0x2f8196){const _0x29cf0c=new Promise((_0x1d4aac,_0x4a8736)=>{const _0x5e0e01=()=>{_0x2f8196['removeEventListener']('success',_0x294a42),_0x2f8196['removeEventListener']('error',_0x6eb45a);},_0x294a42=()=>{_0x1d4aac(_e(_0x2f8196['result'])),_0x5e0e01();},_0x6eb45a=()=>{_0x4a8736(_0x2f8196['error']),_0x5e0e01();};_0x2f8196['addEventListener']('success',_0x294a42),_0x2f8196['addEventListener']('error',_0x6eb45a);});return _0x29cf0c['then'](_0x5f5c7b=>{_0x5f5c7b instanceof IDBCursor&&Jr['set'](_0x5f5c7b,_0x2f8196);})['catch'](()=>{}),Wi['set'](_0x29cf0c,_0x2f8196),_0x29cf0c;}function Bc(_0x534375){if(di['has'](_0x534375))return;const _0x2df801=new Promise((_0x51d83d,_0x10066f)=>{const _0x1e8eb8=()=>{_0x534375['removeEventListener']('complete',_0x34916d),_0x534375['removeEventListener']('error',_0x51a0d4),_0x534375['removeEventListener']('abort',_0x51a0d4);},_0x34916d=()=>{_0x51d83d(),_0x1e8eb8();},_0x51a0d4=()=>{_0x10066f(_0x534375['error']||new DOMException('AbortError','AbortError')),_0x1e8eb8();};_0x534375['addEventListener']('complete',_0x34916d),_0x534375['addEventListener']('error',_0x51a0d4),_0x534375['addEventListener']('abort',_0x51a0d4);});di['set'](_0x534375,_0x2df801);}let fi={'get'(_0x19e47b,_0x338b1a,_0x3ded4a){if(_0x19e47b instanceof IDBTransaction){if(_0x338b1a==='done')return di['get'](_0x19e47b);if(_0x338b1a==='objectStoreNames')return _0x19e47b['objectStoreNames']||Xr['get'](_0x19e47b);if(_0x338b1a==='store')return _0x3ded4a['objectStoreNames'][0x1]?void 0x0:_0x3ded4a['objectStore'](_0x3ded4a['objectStoreNames'][0x0]);}return _e(_0x19e47b[_0x338b1a]);},'set'(_0x1d7803,_0xaa0565,_0x125c47){return _0x1d7803[_0xaa0565]=_0x125c47,!0x0;},'has'(_0x5089a8,_0x4b7bea){return _0x5089a8 instanceof IDBTransaction&&(_0x4b7bea==='done'||_0x4b7bea==='store')?!0x0:_0x4b7bea in _0x5089a8;}};function Vc(_0x57f6b2){fi=_0x57f6b2(fi);}function Hc(_0x4b7fd0){return _0x4b7fd0===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0xd4252f,..._0x5b6a4d){const _0xa75b35=_0x4b7fd0['call'](Zn(this),_0xd4252f,..._0x5b6a4d);return Xr['set'](_0xa75b35,_0xd4252f['sort']?_0xd4252f['sort']():[_0xd4252f]),_e(_0xa75b35);}:Uc()['includes'](_0x4b7fd0)?function(..._0x5afa26){return _0x4b7fd0['apply'](Zn(this),_0x5afa26),_e(Jr['get'](this));}:function(..._0x47c07e){return _e(_0x4b7fd0['apply'](Zn(this),_0x47c07e));};}function $c(_0x3398cf){return typeof _0x3398cf=='function'?Hc(_0x3398cf):(_0x3398cf instanceof IDBTransaction&&Bc(_0x3398cf),xc(_0x3398cf,Fc())?new Proxy(_0x3398cf,fi):_0x3398cf);}function _e(_0x4d3f9b){if(_0x4d3f9b instanceof IDBRequest)return Wc(_0x4d3f9b);if(Xn['has'](_0x4d3f9b))return Xn['get'](_0x4d3f9b);const _0x10a51e=$c(_0x4d3f9b);return _0x10a51e!==_0x4d3f9b&&(Xn['set'](_0x4d3f9b,_0x10a51e),Wi['set'](_0x10a51e,_0x4d3f9b)),_0x10a51e;}const Zn=_0x50dfbd=>Wi['get'](_0x50dfbd);function Gc(_0x240076,_0x557ab8,{blocked:_0x6524f8,upgrade:_0x178dbd,blocking:_0x2c1be3,terminated:_0x36a670}={}){const _0x303a6e=indexedDB['open'](_0x240076,_0x557ab8),_0x1a502e=_e(_0x303a6e);return _0x178dbd&&_0x303a6e['addEventListener']('upgradeneeded',_0x347cdf=>{_0x178dbd(_e(_0x303a6e['result']),_0x347cdf['oldVersion'],_0x347cdf['newVersion'],_e(_0x303a6e['transaction']),_0x347cdf);}),_0x6524f8&&_0x303a6e['addEventListener']('blocked',_0x3a45d5=>_0x6524f8(_0x3a45d5['oldVersion'],_0x3a45d5['newVersion'],_0x3a45d5)),_0x1a502e['then'](_0x5ba689=>{_0x36a670&&_0x5ba689['addEventListener']('close',()=>_0x36a670()),_0x2c1be3&&_0x5ba689['addEventListener']('versionchange',_0x4f0a79=>_0x2c1be3(_0x4f0a79['oldVersion'],_0x4f0a79['newVersion'],_0x4f0a79));})['catch'](()=>{}),_0x1a502e;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],ei=new Map();function Ls(_0x57b50a,_0x37a066){if(!(_0x57b50a instanceof IDBDatabase&&!(_0x37a066 in _0x57b50a)&&typeof _0x37a066=='string'))return;if(ei['get'](_0x37a066))return ei['get'](_0x37a066);const _0x13becb=_0x37a066['replace'](/FromIndex$/,''),_0x4404f4=_0x37a066!==_0x13becb,_0x2396a7=zc['includes'](_0x13becb);if(!(_0x13becb in(_0x4404f4?IDBIndex:IDBObjectStore)['prototype'])||!(_0x2396a7||qc['includes'](_0x13becb)))return;const _0x2abc94=async function(_0x5641d9,..._0x30ec9f){const _0x47f68a=this['transaction'](_0x5641d9,_0x2396a7?'readwrite':'readonly');let _0x3d6ba0=_0x47f68a['store'];return _0x4404f4&&(_0x3d6ba0=_0x3d6ba0['index'](_0x30ec9f['shift']())),(await Promise['all']([_0x3d6ba0[_0x13becb](..._0x30ec9f),_0x2396a7&&_0x47f68a['done']]))[0x0];};return ei['set'](_0x37a066,_0x2abc94),_0x2abc94;}Vc(_0x43ca49=>({..._0x43ca49,'get':(_0x24259a,_0x4720c1,_0x1fb8e9)=>Ls(_0x24259a,_0x4720c1)||_0x43ca49['get'](_0x24259a,_0x4720c1,_0x1fb8e9),'has':(_0x8965dc,_0x15fa70)=>!!Ls(_0x8965dc,_0x15fa70)||_0x43ca49['has'](_0x8965dc,_0x15fa70)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x4c65be){this['container']=_0x4c65be;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x1b86e6=>{if(Kc(_0x1b86e6)){const _0x553a18=_0x1b86e6['getImmediate']();return _0x553a18['library']+'/'+_0x553a18['version'];}else return null;})['filter'](_0x320c20=>_0x320c20)['join']('\x20');}}function Kc(_0x333688){const _0x304a2b=_0x333688['getComponent']();return(_0x304a2b==null?void 0x0:_0x304a2b['type'])==='VERSION';}const pi='@firebase/app',xs='0.14.6',oe=new Ui('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.6.0',_i='[DEFAULT]',wl={[pi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},xe=new Map(),gi=new Map(),mi=new Map();function Fs(_0x56b095,_0x598cdf){try{_0x56b095['container']['addComponent'](_0x598cdf);}catch(_0x5254c8){oe['debug']('Component\x20'+_0x598cdf['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x56b095['name'],_0x5254c8);}}function Ze(_0x20906d){const _0x420836=_0x20906d['name'];if(mi['has'](_0x420836))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x420836+'.'),!0x1;mi['set'](_0x420836,_0x20906d);for(const _0x14ad88 of xe['values']())Fs(_0x14ad88,_0x20906d);for(const _0x21f8a7 of gi['values']())Fs(_0x21f8a7,_0x20906d);return!0x0;}function Bi(_0x2a08d8,_0x4f0775){const _0x1539a6=_0x2a08d8['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x1539a6&&_0x1539a6['triggerHeartbeat'](),_0x2a08d8['container']['getProvider'](_0x4f0775);}function $(_0x4fdf5f){return _0x4fdf5f==null?!0x1:_0x4fdf5f['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Bt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x39f015,_0x512ea4,_0x4123ed){this['_isDeleted']=!0x1,this['_options']={..._0x39f015},this['_config']={..._0x512ea4},this['_name']=_0x512ea4['name'],this['_automaticDataCollectionEnabled']=_0x512ea4['automaticDataCollectionEnabled'],this['_container']=_0x4123ed,this['container']['addComponent'](new Le('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x2bd6d5){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x2bd6d5;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x20297d){this['_isDeleted']=_0x20297d;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const lt=Il;function Sl(_0x27c04f,_0x3766d8={}){let _0x3bfb81=_0x27c04f;typeof _0x3766d8!='object'&&(_0x3766d8={'name':_0x3766d8});const _0x517508={'name':_i,'automaticDataCollectionEnabled':!0x0,..._0x3766d8},_0x5e694b=_0x517508['name'];if(typeof _0x5e694b!='string'||!_0x5e694b)throw ge['create']('bad-app-name',{'appName':String(_0x5e694b)});if(_0x3bfb81||(_0x3bfb81=qr()),!_0x3bfb81)throw ge['create']('no-options');const _0x13b1af=xe['get'](_0x5e694b);if(_0x13b1af){if(Me(_0x3bfb81,_0x13b1af['options'])&&Me(_0x517508,_0x13b1af['config']))return _0x13b1af;throw ge['create']('duplicate-app',{'appName':_0x5e694b});}const _0x59bcca=new Pc(_0x5e694b);for(const _0x578949 of mi['values']())_0x59bcca['addComponent'](_0x578949);const _0x29b222=new Tl(_0x3bfb81,_0x517508,_0x59bcca);return xe['set'](_0x5e694b,_0x29b222),_0x29b222;}function Zr(_0x579596=_i){const _0x173356=xe['get'](_0x579596);if(!_0x173356&&_0x579596===_i&&qr())return Sl();if(!_0x173356)throw ge['create']('no-app',{'appName':_0x579596});return _0x173356;}function f_(){return Array['from'](xe['values']());}async function p_(_0x1dc5c4){let _0x728bc0=!0x1;const _0x1c4a64=_0x1dc5c4['name'];xe['has'](_0x1c4a64)?(_0x728bc0=!0x0,xe['delete'](_0x1c4a64)):gi['has'](_0x1c4a64)&&_0x1dc5c4['decRefCount']()<=0x0&&(gi['delete'](_0x1c4a64),_0x728bc0=!0x0),_0x728bc0&&(await Promise['all'](_0x1dc5c4['container']['getProviders']()['map'](_0x1a1077=>_0x1a1077['delete']())),_0x1dc5c4['isDeleted']=!0x0);}function me(_0x3c743a,_0x2cb7eb,_0x55aee5){let _0x3f11a3=wl[_0x3c743a]??_0x3c743a;_0x55aee5&&(_0x3f11a3+='-'+_0x55aee5);const _0x1ec32d=_0x3f11a3['match'](/\s|\//),_0x2d99e2=_0x2cb7eb['match'](/\s|\//);if(_0x1ec32d||_0x2d99e2){const _0x10dea5=['Unable\x20to\x20register\x20library\x20\x22'+_0x3f11a3+'\x22\x20with\x20version\x20\x22'+_0x2cb7eb+'\x22:'];_0x1ec32d&&_0x10dea5['push']('library\x20name\x20\x22'+_0x3f11a3+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x1ec32d&&_0x2d99e2&&_0x10dea5['push']('and'),_0x2d99e2&&_0x10dea5['push']('version\x20name\x20\x22'+_0x2cb7eb+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x10dea5['join']('\x20'));return;}Ze(new Le(_0x3f11a3+'-version',()=>({'library':_0x3f11a3,'version':_0x2cb7eb}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,kt='firebase-heartbeat-store';let ti=null;function eo(){return ti||(ti=Gc(bl,Rl,{'upgrade':(_0x44b364,_0x64442d)=>{switch(_0x64442d){case 0x0:try{_0x44b364['createObjectStore'](kt);}catch(_0x283e5f){console['warn'](_0x283e5f);}}}})['catch'](_0x2dab55=>{throw ge['create']('idb-open',{'originalErrorMessage':_0x2dab55['message']});})),ti;}async function Al(_0xece595){try{const _0x16a4cf=(await eo())['transaction'](kt),_0x5f0c1b=await _0x16a4cf['objectStore'](kt)['get'](to(_0xece595));return await _0x16a4cf['done'],_0x5f0c1b;}catch(_0x4d934d){if(_0x4d934d instanceof Se)oe['warn'](_0x4d934d['message']);else{const _0x43ef1e=ge['create']('idb-get',{'originalErrorMessage':_0x4d934d==null?void 0x0:_0x4d934d['message']});oe['warn'](_0x43ef1e['message']);}}}async function Us(_0x46f1ec,_0x2d4501){try{const _0x1856ce=(await eo())['transaction'](kt,'readwrite');await _0x1856ce['objectStore'](kt)['put'](_0x2d4501,to(_0x46f1ec)),await _0x1856ce['done'];}catch(_0x36f8ca){if(_0x36f8ca instanceof Se)oe['warn'](_0x36f8ca['message']);else{const _0x3cd107=ge['create']('idb-set',{'originalErrorMessage':_0x36f8ca==null?void 0x0:_0x36f8ca['message']});oe['warn'](_0x3cd107['message']);}}}function to(_0x26a3ee){return _0x26a3ee['name']+'!'+_0x26a3ee['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Nl=0x1e;class Pl{constructor(_0x30a4e3){this['container']=_0x30a4e3,this['_heartbeatsCache']=null;const _0x4801c1=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x4801c1),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x567851=>(this['_heartbeatsCache']=_0x567851,_0x567851));}async['triggerHeartbeat'](){var _0x47dbe9,_0x3c0e89;try{const _0x12e9f9=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x336104=Ws();if(((_0x47dbe9=this['_heartbeatsCache'])==null?void 0x0:_0x47dbe9['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x3c0e89=this['_heartbeatsCache'])==null?void 0x0:_0x3c0e89['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x336104||this['_heartbeatsCache']['heartbeats']['some'](_0x1fcb46=>_0x1fcb46['date']===_0x336104))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x336104,'agent':_0x12e9f9}),this['_heartbeatsCache']['heartbeats']['length']>Nl){const _0x40f42f=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x40f42f,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x313855){oe['warn'](_0x313855);}}async['getHeartbeatsHeader'](){var _0x96072d;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x96072d=this['_heartbeatsCache'])==null?void 0x0:_0x96072d['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x4505a7=Ws(),{heartbeatsToSend:_0x55a0a1,unsentEntries:_0xdc372d}=Ol(this['_heartbeatsCache']['heartbeats']),_0x523b9c=cn(JSON['stringify']({'version':0x2,'heartbeats':_0x55a0a1}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x4505a7,_0xdc372d['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0xdc372d,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x523b9c;}catch(_0x5f5043){return oe['warn'](_0x5f5043),'';}}}function Ws(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x46cfaa,_0x1292e0=kl){const _0x101ca7=[];let _0x280db1=_0x46cfaa['slice']();for(const _0x563ca7 of _0x46cfaa){const _0x55a2b6=_0x101ca7['find'](_0x12a533=>_0x12a533['agent']===_0x563ca7['agent']);if(_0x55a2b6){if(_0x55a2b6['dates']['push'](_0x563ca7['date']),Bs(_0x101ca7)>_0x1292e0){_0x55a2b6['dates']['pop']();break;}}else{if(_0x101ca7['push']({'agent':_0x563ca7['agent'],'dates':[_0x563ca7['date']]}),Bs(_0x101ca7)>_0x1292e0){_0x101ca7['pop']();break;}}_0x280db1=_0x280db1['slice'](0x1);}return{'heartbeatsToSend':_0x101ca7,'unsentEntries':_0x280db1};}class Dl{constructor(_0x145ab1){this['app']=_0x145ab1,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x301838=await Al(this['app']);return _0x301838!=null&&_0x301838['heartbeats']?_0x301838:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x51cfb2){if(await this['_canUseIndexedDBPromise']){const _0x4748fc=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x51cfb2['lastSentHeartbeatDate']??_0x4748fc['lastSentHeartbeatDate'],'heartbeats':_0x51cfb2['heartbeats']});}else return;}async['add'](_0x51bb1e){if(await this['_canUseIndexedDBPromise']){const _0x69f4f8=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x51bb1e['lastSentHeartbeatDate']??_0x69f4f8['lastSentHeartbeatDate'],'heartbeats':[..._0x69f4f8['heartbeats'],..._0x51bb1e['heartbeats']]});}else return;}}function Bs(_0x5bb561){return cn(JSON['stringify']({'version':0x2,'heartbeats':_0x5bb561}))['length'];}function Ml(_0x216155){if(_0x216155['length']===0x0)return-0x1;let _0x390196=0x0,_0x5367df=_0x216155[0x0]['date'];for(let _0x558c8d=0x1;_0x558c8d<_0x216155['length'];_0x558c8d++)_0x216155[_0x558c8d]['date']<_0x5367df&&(_0x5367df=_0x216155[_0x558c8d]['date'],_0x390196=_0x558c8d);return _0x390196;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0x586181){Ze(new Le('platform-logger',_0x28ff4a=>new jc(_0x28ff4a),'PRIVATE')),Ze(new Le('heartbeat',_0xa38bff=>new Pl(_0xa38bff),'PRIVATE')),me(pi,xs,_0x586181),me(pi,xs,'esm2020'),me('fire-js','');}Ll('');var xl='firebase',Fl='12.6.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(xl,Fl,'app');var Vs={};const Hs='@firebase/database',$s='1.1.0';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x22b69e){no=_0x22b69e;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x275ff8){this['domStorage_']=_0x275ff8,this['prefix_']='firebase:';}['set'](_0x57bca4,_0x4d1778){_0x4d1778==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x57bca4)):this['domStorage_']['setItem'](this['prefixedName_'](_0x57bca4),O(_0x4d1778));}['get'](_0x3384fd){const _0x3aa5d0=this['domStorage_']['getItem'](this['prefixedName_'](_0x3384fd));return _0x3aa5d0==null?null:At(_0x3aa5d0);}['remove'](_0xcf85c0){this['domStorage_']['removeItem'](this['prefixedName_'](_0xcf85c0));}['prefixedName_'](_0x591c42){return this['prefix_']+_0x591c42;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x2fb638,_0x4c295d){_0x4c295d==null?delete this['cache_'][_0x2fb638]:this['cache_'][_0x2fb638]=_0x4c295d;}['get'](_0x1c631e){return J(this['cache_'],_0x1c631e)?this['cache_'][_0x1c631e]:null;}['remove'](_0x23adbb){delete this['cache_'][_0x23adbb];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x3942ab){try{if(typeof window<'u'&&typeof window[_0x3942ab]<'u'){const _0x3b24e8=window[_0x3942ab];return _0x3b24e8['setItem']('firebase:sentinel','cache'),_0x3b24e8['removeItem']('firebase:sentinel'),new Wl(_0x3b24e8);}}catch{}return new Bl();},Oe=io('localStorage'),Vl=io('sessionStorage'),Ye=new Ui('@firebase/database'),so=(function(){let _0x162748=0x1;return function(){return _0x162748++;};}()),ro=function(_0x5ddf03){const _0x16ea90=Rc(_0x5ddf03),_0x5df736=new Cc();_0x5df736['update'](_0x16ea90);const _0x3d10a8=_0x5df736['digest']();return Li['encodeByteArray'](_0x3d10a8);},Vt=function(..._0x3003e7){let _0x13605a='';for(let _0x4a92ef=0x0;_0x4a92ef<_0x3003e7['length'];_0x4a92ef++){const _0x23e309=_0x3003e7[_0x4a92ef];Array['isArray'](_0x23e309)||_0x23e309&&typeof _0x23e309=='object'&&typeof _0x23e309['length']=='number'?_0x13605a+=Vt['apply'](null,_0x23e309):typeof _0x23e309=='object'?_0x13605a+=O(_0x23e309):_0x13605a+=_0x23e309,_0x13605a+='\x20';}return _0x13605a;};let wt=null,Gs=!0x0;const Hl=function(_0x406f3a,_0x200c7b){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ye['logLevel']=T['VERBOSE'],wt=Ye['log']['bind'](Ye);},L=function(..._0x4de8bb){if(Gs===!0x0&&(Gs=!0x1,wt===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),wt){const _0x32b63e=Vt['apply'](null,_0x4de8bb);wt(_0x32b63e);}},Ht=function(_0x18e5d4){return function(..._0x48887){L(_0x18e5d4,..._0x48887);};},yi=function(..._0x276bd5){const _0x71f007='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Vt(..._0x276bd5);Ye['error'](_0x71f007);},ae=function(..._0x123856){const _0x430259='FIREBASE\x20FATAL\x20ERROR:\x20'+Vt(..._0x123856);throw Ye['error'](_0x430259),new Error(_0x430259);},U=function(..._0x5a3042){const _0x12d82d='FIREBASE\x20WARNING:\x20'+Vt(..._0x5a3042);Ye['warn'](_0x12d82d);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Vi=function(_0x5dbfb7){return typeof _0x5dbfb7=='number'&&(_0x5dbfb7!==_0x5dbfb7||_0x5dbfb7===Number['POSITIVE_INFINITY']||_0x5dbfb7===Number['NEGATIVE_INFINITY']);},Gl=function(_0x39cb71){if(document['readyState']==='complete')_0x39cb71();else{let _0x4ed972=!0x1;const _0x2f06d8=function(){if(!document['body']){setTimeout(_0x2f06d8,Math['floor'](0xa));return;}_0x4ed972||(_0x4ed972=!0x0,_0x39cb71());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x2f06d8,!0x1),window['addEventListener']('load',_0x2f06d8,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x2f06d8();}),window['attachEvent']('onload',_0x2f06d8));}},Fe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x7e1b8d,_0x261b4f){if(_0x7e1b8d===_0x261b4f)return 0x0;if(_0x7e1b8d===Fe||_0x261b4f===Ie)return-0x1;if(_0x261b4f===Fe||_0x7e1b8d===Ie)return 0x1;{const _0x337bb3=qs(_0x7e1b8d),_0x10bc2a=qs(_0x261b4f);return _0x337bb3!==null?_0x10bc2a!==null?_0x337bb3-_0x10bc2a===0x0?_0x7e1b8d['length']-_0x261b4f['length']:_0x337bb3-_0x10bc2a:-0x1:_0x10bc2a!==null?0x1:_0x7e1b8d<_0x261b4f?-0x1:0x1;}},ql=function(_0xbc0e1b,_0x4dad23){return _0xbc0e1b===_0x4dad23?0x0:_0xbc0e1b<_0x4dad23?-0x1:0x1;},_t=function(_0x485878,_0x5157e1){if(_0x5157e1&&_0x485878 in _0x5157e1)return _0x5157e1[_0x485878];throw new Error('Missing\x20required\x20key\x20('+_0x485878+')\x20in\x20object:\x20'+O(_0x5157e1));},Hi=function(_0xbcdec3){if(typeof _0xbcdec3!='object'||_0xbcdec3===null)return O(_0xbcdec3);const _0x352559=[];for(const _0x4572fc in _0xbcdec3)_0x352559['push'](_0x4572fc);_0x352559['sort']();let _0xef354d='{';for(let _0x566a22=0x0;_0x566a22<_0x352559['length'];_0x566a22++)_0x566a22!==0x0&&(_0xef354d+=','),_0xef354d+=O(_0x352559[_0x566a22]),_0xef354d+=':',_0xef354d+=Hi(_0xbcdec3[_0x352559[_0x566a22]]);return _0xef354d+='}',_0xef354d;},oo=function(_0x5c6ddd,_0x4c49c7){const _0x47b450=_0x5c6ddd['length'];if(_0x47b450<=_0x4c49c7)return[_0x5c6ddd];const _0x35f800=[];for(let _0x37bba5=0x0;_0x37bba5<_0x47b450;_0x37bba5+=_0x4c49c7)_0x37bba5+_0x4c49c7>_0x47b450?_0x35f800['push'](_0x5c6ddd['substring'](_0x37bba5,_0x47b450)):_0x35f800['push'](_0x5c6ddd['substring'](_0x37bba5,_0x37bba5+_0x4c49c7));return _0x35f800;};function x(_0x1058b7,_0x195a99){for(const _0x290fc4 in _0x1058b7)_0x1058b7['hasOwnProperty'](_0x290fc4)&&_0x195a99(_0x290fc4,_0x1058b7[_0x290fc4]);}const ao=function(_0x23bea8){f(!Vi(_0x23bea8),'Invalid\x20JSON\x20number');const _0x2021c5=0xb,_0x25969a=0x34,_0x30a6ae=(0x1<<_0x2021c5-0x1)-0x1;let _0x37f383,_0x4becd2,_0x5106ca,_0x498485,_0x395d0d;_0x23bea8===0x0?(_0x4becd2=0x0,_0x5106ca=0x0,_0x37f383=0x1/_0x23bea8===-0x1/0x0?0x1:0x0):(_0x37f383=_0x23bea8<0x0,_0x23bea8=Math['abs'](_0x23bea8),_0x23bea8>=Math['pow'](0x2,0x1-_0x30a6ae)?(_0x498485=Math['min'](Math['floor'](Math['log'](_0x23bea8)/Math['LN2']),_0x30a6ae),_0x4becd2=_0x498485+_0x30a6ae,_0x5106ca=Math['round'](_0x23bea8*Math['pow'](0x2,_0x25969a-_0x498485)-Math['pow'](0x2,_0x25969a))):(_0x4becd2=0x0,_0x5106ca=Math['round'](_0x23bea8/Math['pow'](0x2,0x1-_0x30a6ae-_0x25969a))));const _0x3d1f53=[];for(_0x395d0d=_0x25969a;_0x395d0d;_0x395d0d-=0x1)_0x3d1f53['push'](_0x5106ca%0x2?0x1:0x0),_0x5106ca=Math['floor'](_0x5106ca/0x2);for(_0x395d0d=_0x2021c5;_0x395d0d;_0x395d0d-=0x1)_0x3d1f53['push'](_0x4becd2%0x2?0x1:0x0),_0x4becd2=Math['floor'](_0x4becd2/0x2);_0x3d1f53['push'](_0x37f383?0x1:0x0),_0x3d1f53['reverse']();const _0x283bb6=_0x3d1f53['join']('');let _0xa876af='';for(_0x395d0d=0x0;_0x395d0d<0x40;_0x395d0d+=0x8){let _0x1c3a96=parseInt(_0x283bb6['substr'](_0x395d0d,0x8),0x2)['toString'](0x10);_0x1c3a96['length']===0x1&&(_0x1c3a96='0'+_0x1c3a96),_0xa876af=_0xa876af+_0x1c3a96;}return _0xa876af['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x3299f3,_0x2b7c68){let _0x2f792a='Unknown\x20Error';_0x3299f3==='too_big'?_0x2f792a='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x3299f3==='permission_denied'?_0x2f792a='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x3299f3==='unavailable'&&(_0x2f792a='The\x20service\x20is\x20unavailable');const _0x5d65e4=new Error(_0x3299f3+'\x20at\x20'+_0x2b7c68['_path']['toString']()+':\x20'+_0x2f792a);return _0x5d65e4['code']=_0x3299f3['toUpperCase'](),_0x5d65e4;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,qs=function(_0x2289e2){if(Yl['test'](_0x2289e2)){const _0xe8bcbc=Number(_0x2289e2);if(_0xe8bcbc>=Ql&&_0xe8bcbc<=Jl)return _0xe8bcbc;}return null;},ht=function(_0xb0d8e5){try{_0xb0d8e5();}catch(_0x344601){setTimeout(()=>{const _0x4e93e6=_0x344601['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x4e93e6),_0x344601;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},Ct=function(_0x1426dc,_0x4e8fba){const _0x28693d=setTimeout(_0x1426dc,_0x4e8fba);return typeof _0x28693d=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x28693d):typeof _0x28693d=='object'&&_0x28693d['unref']&&_0x28693d['unref'](),_0x28693d;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x27c5ae,_0x3bc3ac){this['appCheckProvider']=_0x3bc3ac,this['appName']=_0x27c5ae['name'],$(_0x27c5ae)&&_0x27c5ae['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x27c5ae['settings']['appCheckToken']),this['appCheck']=_0x3bc3ac==null?void 0x0:_0x3bc3ac['getImmediate']({'optional':!0x0}),this['appCheck']||_0x3bc3ac==null||_0x3bc3ac['get']()['then'](_0x5d49e6=>this['appCheck']=_0x5d49e6);}['getToken'](_0x3c8704){if(this['serverAppAppCheckToken']){if(_0x3c8704)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x3c8704):new Promise((_0x37f005,_0x4cdc2c)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x3c8704)['then'](_0x37f005,_0x4cdc2c):_0x37f005(null);},0x0);});}['addTokenChangeListener'](_0x466c96){var _0x83ac90;(_0x83ac90=this['appCheckProvider'])==null||_0x83ac90['get']()['then'](_0x3935f6=>_0x3935f6['addTokenListener'](_0x466c96));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x52a724,_0x3f7bd8,_0x2484c7){this['appName_']=_0x52a724,this['firebaseOptions_']=_0x3f7bd8,this['authProvider_']=_0x2484c7,this['auth_']=null,this['auth_']=_0x2484c7['getImmediate']({'optional':!0x0}),this['auth_']||_0x2484c7['onInit'](_0x2a887e=>this['auth_']=_0x2a887e);}['getToken'](_0x4dd1bc){return this['auth_']?this['auth_']['getToken'](_0x4dd1bc)['catch'](_0x47980c=>_0x47980c&&_0x47980c['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0x47980c)):new Promise((_0x3b225b,_0x3db9a4)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x4dd1bc)['then'](_0x3b225b,_0x3db9a4):_0x3b225b(null);},0x0);});}['addTokenChangeListener'](_0x127861){this['auth_']?this['auth_']['addAuthTokenListener'](_0x127861):this['authProvider_']['get']()['then'](_0x366c96=>_0x366c96['addAuthTokenListener'](_0x127861));}['removeTokenChangeListener'](_0x164658){this['authProvider_']['get']()['then'](_0x9d7e84=>_0x9d7e84['removeAuthTokenListener'](_0x164658));}['notifyForInvalidToken'](){let _0x465072='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x465072+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x465072+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x465072+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x465072);}}class nn{constructor(_0x33746e){this['accessToken']=_0x33746e;}['getToken'](_0x1ef643){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0xc8d972){_0xc8d972(this['accessToken']);}['removeTokenChangeListener'](_0x5f15ad){}['notifyForInvalidToken'](){}}nn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $i='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',vi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0xcdeafc,_0x1a8b88,_0x22d2a4,_0x3f35a1,_0x2af978=!0x1,_0x37402b='',_0x93d958=!0x1,_0x2941d0=!0x1,_0x95c649=null){this['secure']=_0x1a8b88,this['namespace']=_0x22d2a4,this['webSocketOnly']=_0x3f35a1,this['nodeAdmin']=_0x2af978,this['persistenceKey']=_0x37402b,this['includeNamespaceInQueryParams']=_0x93d958,this['isUsingEmulator']=_0x2941d0,this['emulatorOptions']=_0x95c649,this['_host']=_0xcdeafc['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Oe['get']('host:'+_0xcdeafc)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x473fa0){_0x473fa0!==this['internalHost']&&(this['internalHost']=_0x473fa0,this['isCacheableHost']()&&Oe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x3a4ebd=this['toURLString']();return this['persistenceKey']&&(_0x3a4ebd+='<'+this['persistenceKey']+'>'),_0x3a4ebd;}['toURLString'](){const _0x4c0885=this['secure']?'https://':'http://',_0x33e010=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x4c0885+this['host']+'/'+_0x33e010;}}function th(_0x271819){return _0x271819['host']!==_0x271819['internalHost']||_0x271819['isCustomHost']()||_0x271819['includeNamespaceInQueryParams'];}function vo(_0x20c1fa,_0x340ed3,_0x1e172f){f(typeof _0x340ed3=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x1e172f=='object','typeof\x20params\x20must\x20==\x20object');let _0x436f56;if(_0x340ed3===go)_0x436f56=(_0x20c1fa['secure']?'wss://':'ws://')+_0x20c1fa['internalHost']+'/.ws?';else{if(_0x340ed3===mo)_0x436f56=(_0x20c1fa['secure']?'https://':'http://')+_0x20c1fa['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x340ed3);}th(_0x20c1fa)&&(_0x1e172f['ns']=_0x20c1fa['namespace']);const _0x1385de=[];return x(_0x1e172f,(_0x4a0379,_0x208440)=>{_0x1385de['push'](_0x4a0379+'='+_0x208440);}),_0x436f56+_0x1385de['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x427fbb,_0x4a67bf=0x1){J(this['counters_'],_0x427fbb)||(this['counters_'][_0x427fbb]=0x0),this['counters_'][_0x427fbb]+=_0x4a67bf;}['get'](){return nc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ni={},ii={};function Gi(_0x1fdb1f){const _0x27f5a3=_0x1fdb1f['toString']();return ni[_0x27f5a3]||(ni[_0x27f5a3]=new nh()),ni[_0x27f5a3];}function ih(_0x5c968e,_0x200656){const _0xf513c2=_0x5c968e['toString']();return ii[_0xf513c2]||(ii[_0xf513c2]=_0x200656()),ii[_0xf513c2];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x3876b7){this['onMessage_']=_0x3876b7,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x5ce971,_0x5d80fa){this['closeAfterResponse']=_0x5ce971,this['onClose']=_0x5d80fa,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0x2e9199,_0x32ca0b){for(this['pendingResponses'][_0x2e9199]=_0x32ca0b;this['pendingResponses'][this['currentResponseNum']];){const _0x4a31db=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x36cbc2=0x0;_0x36cbc2<_0x4a31db['length'];++_0x36cbc2)_0x4a31db[_0x36cbc2]&&ht(()=>{this['onMessage_'](_0x4a31db[_0x36cbc2]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class je{constructor(_0x3c3395,_0x3e4097,_0x1e0add,_0x4a51c1,_0x1ee997,_0x58084e,_0x162f86){this['connId']=_0x3c3395,this['repoInfo']=_0x3e4097,this['applicationId']=_0x1e0add,this['appCheckToken']=_0x4a51c1,this['authToken']=_0x1ee997,this['transportSessionId']=_0x58084e,this['lastSessionId']=_0x162f86,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Ht(_0x3c3395),this['stats_']=Gi(_0x3e4097),this['urlFn']=_0x54cd50=>(this['appCheckToken']&&(_0x54cd50[vi]=this['appCheckToken']),vo(_0x3e4097,mo,_0x54cd50));}['open'](_0x3c50c5,_0x27318c){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x27318c,this['myPacketOrderer']=new sh(_0x3c50c5),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new qi((..._0x4ad5dd)=>{const [_0x2ba60e,_0x3b6852,_0x2c90a2,_0x491666,_0x1bdece]=_0x4ad5dd;if(this['incrementIncomingBytes_'](_0x4ad5dd),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x2ba60e===zs)this['id']=_0x3b6852,this['password']=_0x2c90a2;else{if(_0x2ba60e===rh)_0x3b6852?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x3b6852,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x2ba60e);}}},(..._0x367dfa)=>{const [_0x45ea07,_0x365184]=_0x367dfa;this['incrementIncomingBytes_'](_0x367dfa),this['myPacketOrderer']['handleResponse'](_0x45ea07,_0x365184);},()=>{this['onClosed_']();},this['urlFn']);const _0x21a97b={};_0x21a97b[zs]='t',_0x21a97b[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x21a97b[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x21a97b[co]=$i,this['transportSessionId']&&(_0x21a97b[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x21a97b[po]=this['lastSessionId']),this['applicationId']&&(_0x21a97b[_o]=this['applicationId']),this['appCheckToken']&&(_0x21a97b[vi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x21a97b[ho]=uo);const _0x3fd007=this['urlFn'](_0x21a97b);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x3fd007),this['scriptTagHolder']['addTag'](_0x3fd007,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){je['forceAllow_']=!0x0;}static['forceDisallow'](){je['forceDisallow_']=!0x0;}static['isAvailable'](){return je['forceAllow_']?!0x0:!je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x180552){const _0x208d93=O(_0x180552);this['bytesSent']+=_0x208d93['length'],this['stats_']['incrementCounter']('bytes_sent',_0x208d93['length']);const _0x26fc7a=Hr(_0x208d93),_0x23866b=oo(_0x26fc7a,fh);for(let _0x1d5e7b=0x0;_0x1d5e7b<_0x23866b['length'];_0x1d5e7b++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0x23866b['length'],_0x23866b[_0x1d5e7b]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x585811,_0xcb5456){this['myDisconnFrame']=document['createElement']('iframe');const _0x13cd3e={};_0x13cd3e[dh]='t',_0x13cd3e[Eo]=_0x585811,_0x13cd3e[Io]=_0xcb5456,this['myDisconnFrame']['src']=this['urlFn'](_0x13cd3e),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0x312d6c){const _0x550017=O(_0x312d6c)['length'];this['bytesReceived']+=_0x550017,this['stats_']['incrementCounter']('bytes_received',_0x550017);}}class qi{constructor(_0x1d474d,_0x28bd37,_0x4f92b4,_0x49db5b){this['onDisconnect']=_0x4f92b4,this['urlFn']=_0x49db5b,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x1d474d,window[ah+this['uniqueCallbackIdentifier']]=_0x28bd37,this['myIFrame']=qi['createIFrame_']();let _0x5aefc4='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x5aefc4='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x474a53='<html><body>'+_0x5aefc4+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x474a53),this['myIFrame']['doc']['close']();}catch(_0x5973c2){L('frame\x20writing\x20exception'),_0x5973c2['stack']&&L(_0x5973c2['stack']),L(_0x5973c2);}}}static['createIFrame_'](){const _0x4b3433=document['createElement']('iframe');if(_0x4b3433['style']['display']='none',document['body']){document['body']['appendChild'](_0x4b3433);try{_0x4b3433['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x4f151a=document['domain'];_0x4b3433['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x4f151a+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x4b3433['contentDocument']?_0x4b3433['doc']=_0x4b3433['contentDocument']:_0x4b3433['contentWindow']?_0x4b3433['doc']=_0x4b3433['contentWindow']['document']:_0x4b3433['document']&&(_0x4b3433['doc']=_0x4b3433['document']),_0x4b3433;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x4997ac=this['onDisconnect'];_0x4997ac&&(this['onDisconnect']=null,_0x4997ac());}['startLongPoll'](_0x357d01,_0x5d2c1a){for(this['myID']=_0x357d01,this['myPW']=_0x5d2c1a,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0x594ca7={};_0x594ca7[Eo]=this['myID'],_0x594ca7[Io]=this['myPW'],_0x594ca7[wo]=this['currentSerial'];let _0x2c7169=this['urlFn'](_0x594ca7),_0x242443='',_0x38ecf8=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0x242443['length']<=Co;){const _0xbc718b=this['pendingSegs']['shift']();_0x242443=_0x242443+'&'+lh+_0x38ecf8+'='+_0xbc718b['seg']+'&'+hh+_0x38ecf8+'='+_0xbc718b['ts']+'&'+uh+_0x38ecf8+'='+_0xbc718b['d'],_0x38ecf8++;}return _0x2c7169=_0x2c7169+_0x242443,this['addLongPollTag_'](_0x2c7169,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x233c3f,_0x4a8c2b,_0x53b794){this['pendingSegs']['push']({'seg':_0x233c3f,'ts':_0x4a8c2b,'d':_0x53b794}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x15092d,_0x4e9334){this['outstandingRequests']['add'](_0x4e9334);const _0x8ee8e6=()=>{this['outstandingRequests']['delete'](_0x4e9334),this['newRequest_']();},_0x3c7a3d=setTimeout(_0x8ee8e6,Math['floor'](ph)),_0x414bb5=()=>{clearTimeout(_0x3c7a3d),_0x8ee8e6();};this['addTag'](_0x15092d,_0x414bb5);}['addTag'](_0x3524e2,_0x679214){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x2e59ce=this['myIFrame']['doc']['createElement']('script');_0x2e59ce['type']='text/javascript',_0x2e59ce['async']=!0x0,_0x2e59ce['src']=_0x3524e2,_0x2e59ce['onload']=_0x2e59ce['onreadystatechange']=function(){const _0x24cf4f=_0x2e59ce['readyState'];(!_0x24cf4f||_0x24cf4f==='loaded'||_0x24cf4f==='complete')&&(_0x2e59ce['onload']=_0x2e59ce['onreadystatechange']=null,_0x2e59ce['parentNode']&&_0x2e59ce['parentNode']['removeChild'](_0x2e59ce),_0x679214());},_0x2e59ce['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x3524e2),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x2e59ce);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let un=null;typeof MozWebSocket<'u'?un=MozWebSocket:typeof WebSocket<'u'&&(un=WebSocket);class z{constructor(_0x527138,_0x43a3ab,_0x596bc7,_0x2a2ae4,_0x437796,_0x51f4e2,_0x303c4d){this['connId']=_0x527138,this['applicationId']=_0x596bc7,this['appCheckToken']=_0x2a2ae4,this['authToken']=_0x437796,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Ht(this['connId']),this['stats_']=Gi(_0x43a3ab),this['connURL']=z['connectionURL_'](_0x43a3ab,_0x51f4e2,_0x303c4d,_0x2a2ae4,_0x596bc7),this['nodeAdmin']=_0x43a3ab['nodeAdmin'];}static['connectionURL_'](_0x590646,_0x4096e3,_0x235192,_0x2460e8,_0x314021){const _0x44cf88={};return _0x44cf88[co]=$i,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x44cf88[ho]=uo),_0x4096e3&&(_0x44cf88[lo]=_0x4096e3),_0x235192&&(_0x44cf88[po]=_0x235192),_0x2460e8&&(_0x44cf88[vi]=_0x2460e8),_0x314021&&(_0x44cf88[_o]=_0x314021),vo(_0x590646,go,_0x44cf88);}['open'](_0x36197f,_0x4a8367){this['onDisconnect']=_0x4a8367,this['onMessage']=_0x36197f,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Oe['set']('previous_websocket_failure',!0x0);try{let _0x4b5a91;_c(),this['mySock']=new un(this['connURL'],[],_0x4b5a91);}catch(_0x6c2e75){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x57dc9e=_0x6c2e75['message']||_0x6c2e75['data'];_0x57dc9e&&this['log_'](_0x57dc9e),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x5cc379=>{this['handleIncomingFrame'](_0x5cc379);},this['mySock']['onerror']=_0x941ffe=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x426464=_0x941ffe['message']||_0x941ffe['data'];_0x426464&&this['log_'](_0x426464),this['onClosed_']();};}['start'](){}static['forceDisallow'](){z['forceDisallow_']=!0x0;}static['isAvailable'](){let _0xa607e=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x1ff512=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x1655a5=navigator['userAgent']['match'](_0x1ff512);_0x1655a5&&_0x1655a5['length']>0x1&&parseFloat(_0x1655a5[0x1])<4.4&&(_0xa607e=!0x0);}return!_0xa607e&&un!==null&&!z['forceDisallow_'];}static['previouslyFailed'](){return Oe['isInMemoryStorage']||Oe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Oe['remove']('previous_websocket_failure');}['appendFrame_'](_0x1773c7){if(this['frames']['push'](_0x1773c7),this['frames']['length']===this['totalFrames']){const _0x24a606=this['frames']['join']('');this['frames']=null;const _0x2cd4f3=At(_0x24a606);this['onMessage'](_0x2cd4f3);}}['handleNewFrameCount_'](_0x3613c2){this['totalFrames']=_0x3613c2,this['frames']=[];}['extractFrameCount_'](_0x85b8af){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x85b8af['length']<=0x6){const _0x3f344c=Number(_0x85b8af);if(!isNaN(_0x3f344c))return this['handleNewFrameCount_'](_0x3f344c),null;}return this['handleNewFrameCount_'](0x1),_0x85b8af;}['handleIncomingFrame'](_0x3585d8){if(this['mySock']===null)return;const _0x1b9d9c=_0x3585d8['data'];if(this['bytesReceived']+=_0x1b9d9c['length'],this['stats_']['incrementCounter']('bytes_received',_0x1b9d9c['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x1b9d9c);else{const _0x1e2f05=this['extractFrameCount_'](_0x1b9d9c);_0x1e2f05!==null&&this['appendFrame_'](_0x1e2f05);}}['send'](_0x5f4e65){this['resetKeepAlive']();const _0x357cbe=O(_0x5f4e65);this['bytesSent']+=_0x357cbe['length'],this['stats_']['incrementCounter']('bytes_sent',_0x357cbe['length']);const _0x3b1a83=oo(_0x357cbe,gh);_0x3b1a83['length']>0x1&&this['sendString_'](String(_0x3b1a83['length']));for(let _0x3a311c=0x0;_0x3a311c<_0x3b1a83['length'];_0x3a311c++)this['sendString_'](_0x3b1a83[_0x3a311c]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x16f013){try{this['mySock']['send'](_0x16f013);}catch(_0x45d501){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x45d501['message']||_0x45d501['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}z['responsesRequiredToBeHealthy']=0x2,z['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nt{static get['ALL_TRANSPORTS'](){return[je,z];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x19d48b){this['initTransports_'](_0x19d48b);}['initTransports_'](_0x4840cd){const _0x1ae075=z&&z['isAvailable']();let _0x4c56e4=_0x1ae075&&!z['previouslyFailed']();if(_0x4840cd['webSocketOnly']&&(_0x1ae075||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x4c56e4=!0x0),_0x4c56e4)this['transports_']=[z];else{const _0x54bc1f=this['transports_']=[];for(const _0x303776 of Nt['ALL_TRANSPORTS'])_0x303776&&_0x303776['isAvailable']()&&_0x54bc1f['push'](_0x303776);Nt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Nt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,si='t',js='d',wh='s',Ks='r',Ch='e',Ys='o',Qs='a',Js='n',Xs='p',Th='h';class Sh{constructor(_0x2c9e13,_0x29f91c,_0x307c18,_0x28f2db,_0x2c2fb4,_0x51a0a1,_0x2aeef4,_0x5782c9,_0x33ddf6,_0x5c0e55){this['id']=_0x2c9e13,this['repoInfo_']=_0x29f91c,this['applicationId_']=_0x307c18,this['appCheckToken_']=_0x28f2db,this['authToken_']=_0x2c2fb4,this['onMessage_']=_0x51a0a1,this['onReady_']=_0x2aeef4,this['onDisconnect_']=_0x5782c9,this['onKill_']=_0x33ddf6,this['lastSessionId']=_0x5c0e55,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Ht('c:'+this['id']+':'),this['transportManager_']=new Nt(_0x29f91c),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x4f2fee=this['transportManager_']['initialTransport']();this['conn_']=new _0x4f2fee(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x4f2fee['responsesRequiredToBeHealthy']||0x0;const _0xf40a31=this['connReceiver_'](this['conn_']),_0x350a75=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0xf40a31,_0x350a75);},Math['floor'](0x0));const _0x355c1d=_0x4f2fee['healthyTimeout']||0x0;_0x355c1d>0x0&&(this['healthyTimeout_']=Ct(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x355c1d)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x1d639a){return _0x28c058=>{_0x1d639a===this['conn_']?this['onConnectionLost_'](_0x28c058):_0x1d639a===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x216cc6){return _0x437e51=>{this['state_']!==0x2&&(_0x216cc6===this['rx_']?this['onPrimaryMessageReceived_'](_0x437e51):_0x216cc6===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x437e51):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x3d2d69){const _0x59dc46={'t':'d','d':_0x3d2d69};this['sendData_'](_0x59dc46);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x1e8b9b){if(si in _0x1e8b9b){const _0x1c8816=_0x1e8b9b[si];_0x1c8816===Qs?this['upgradeIfSecondaryHealthy_']():_0x1c8816===Ks?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x1c8816===Ys&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0x441581){const _0x344b0f=_t('t',_0x441581),_0x3eb8d6=_t('d',_0x441581);if(_0x344b0f==='c')this['onSecondaryControl_'](_0x3eb8d6);else{if(_0x344b0f==='d')this['pendingDataMessages']['push'](_0x3eb8d6);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x344b0f);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Xs,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Js,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x32e2d8){const _0x1b48f9=_t('t',_0x32e2d8),_0x4cd3bd=_t('d',_0x32e2d8);_0x1b48f9==='c'?this['onControl_'](_0x4cd3bd):_0x1b48f9==='d'&&this['onDataMessage_'](_0x4cd3bd);}['onDataMessage_'](_0x2266da){this['onPrimaryResponse_'](),this['onMessage_'](_0x2266da);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0x1acce4){const _0xbaea6a=_t(si,_0x1acce4);if(js in _0x1acce4){const _0x4f8a70=_0x1acce4[js];if(_0xbaea6a===Th){const _0x80f29={..._0x4f8a70};this['repoInfo_']['isUsingEmulator']&&(_0x80f29['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x80f29);}else{if(_0xbaea6a===Js){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x52c77f=0x0;_0x52c77f<this['pendingDataMessages']['length'];++_0x52c77f)this['onDataMessage_'](this['pendingDataMessages'][_0x52c77f]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0xbaea6a===wh?this['onConnectionShutdown_'](_0x4f8a70):_0xbaea6a===Ks?this['onReset_'](_0x4f8a70):_0xbaea6a===Ch?yi('Server\x20Error:\x20'+_0x4f8a70):_0xbaea6a===Ys?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):yi('Unknown\x20control\x20packet\x20command:\x20'+_0xbaea6a);}}}['onHandshake_'](_0x1c2d9d){const _0x125afc=_0x1c2d9d['ts'],_0x25d40c=_0x1c2d9d['v'],_0x58a242=_0x1c2d9d['h'];this['sessionId']=_0x1c2d9d['s'],this['repoInfo_']['host']=_0x58a242,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x125afc),$i!==_0x25d40c&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x531325=this['transportManager_']['upgradeTransport']();_0x531325&&this['startUpgrade_'](_0x531325);}['startUpgrade_'](_0xf57d74){this['secondaryConn_']=new _0xf57d74(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0xf57d74['responsesRequiredToBeHealthy']||0x0;const _0x48fad9=this['connReceiver_'](this['secondaryConn_']),_0x5d728b=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x48fad9,_0x5d728b),Ct(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x3ba2aa){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x3ba2aa),this['repoInfo_']['host']=_0x3ba2aa,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x9a31b9,_0x37d97d){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x9a31b9,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x37d97d,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):Ct(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Xs,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x365523=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x365523||this['rx_']===_0x365523)&&this['close']();}['onConnectionLost_'](_0x41789a){this['conn_']=null,!_0x41789a&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Oe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x2ac3b6){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x2ac3b6),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x17fa1c){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x17fa1c);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x3be59a,_0x1f63de,_0x1643bd,_0x5db38f){}['merge'](_0x296334,_0xf515a,_0x591574,_0x55b2d2){}['refreshAuthToken'](_0x44a73e){}['refreshAppCheckToken'](_0x445573){}['onDisconnectPut'](_0x34a6c8,_0x2b3f50,_0x44b648){}['onDisconnectMerge'](_0x1e3f73,_0x1e1a45,_0x3ad689){}['onDisconnectCancel'](_0x2eb3bd,_0x4c963f){}['reportStats'](_0x365e67){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x564474){this['allowedEvents_']=_0x564474,this['listeners_']={},f(Array['isArray'](_0x564474)&&_0x564474['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0xb93a31,..._0x2582a7){if(Array['isArray'](this['listeners_'][_0xb93a31])){const _0x1ce4ac=[...this['listeners_'][_0xb93a31]];for(let _0x1763d1=0x0;_0x1763d1<_0x1ce4ac['length'];_0x1763d1++)_0x1ce4ac[_0x1763d1]['callback']['apply'](_0x1ce4ac[_0x1763d1]['context'],_0x2582a7);}}['on'](_0x277776,_0x252bb9,_0x2b2af0){this['validateEventType_'](_0x277776),this['listeners_'][_0x277776]=this['listeners_'][_0x277776]||[],this['listeners_'][_0x277776]['push']({'callback':_0x252bb9,'context':_0x2b2af0});const _0x4e065d=this['getInitialEvent'](_0x277776);_0x4e065d&&_0x252bb9['apply'](_0x2b2af0,_0x4e065d);}['off'](_0x531060,_0x4dce76,_0x1d5ba4){this['validateEventType_'](_0x531060);const _0x22b0ed=this['listeners_'][_0x531060]||[];for(let _0x26b012=0x0;_0x26b012<_0x22b0ed['length'];_0x26b012++)if(_0x22b0ed[_0x26b012]['callback']===_0x4dce76&&(!_0x1d5ba4||_0x1d5ba4===_0x22b0ed[_0x26b012]['context'])){_0x22b0ed['splice'](_0x26b012,0x1);return;}}['validateEventType_'](_0x5dccae){f(this['allowedEvents_']['find'](_0x2ce600=>_0x2ce600===_0x5dccae),'Unknown\x20event:\x20'+_0x5dccae);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class dn extends bo{static['getInstance'](){return new dn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Fi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0xd5b704){return f(_0xd5b704==='online','Unknown\x20event\x20type:\x20'+_0xd5b704),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Zs=0x20,er=0x300;class C{constructor(_0x46b4f1,_0x33fd09){if(_0x33fd09===void 0x0){this['pieces_']=_0x46b4f1['split']('/');let _0x56cb9e=0x0;for(let _0x5c2386=0x0;_0x5c2386<this['pieces_']['length'];_0x5c2386++)this['pieces_'][_0x5c2386]['length']>0x0&&(this['pieces_'][_0x56cb9e]=this['pieces_'][_0x5c2386],_0x56cb9e++);this['pieces_']['length']=_0x56cb9e,this['pieceNum_']=0x0;}else this['pieces_']=_0x46b4f1,this['pieceNum_']=_0x33fd09;}['toString'](){let _0x2d06f5='';for(let _0x1a279a=this['pieceNum_'];_0x1a279a<this['pieces_']['length'];_0x1a279a++)this['pieces_'][_0x1a279a]!==''&&(_0x2d06f5+='/'+this['pieces_'][_0x1a279a]);return _0x2d06f5||'/';}}function w(){return new C('');}function y(_0x4fd989){return _0x4fd989['pieceNum_']>=_0x4fd989['pieces_']['length']?null:_0x4fd989['pieces_'][_0x4fd989['pieceNum_']];}function we(_0x364e97){return _0x364e97['pieces_']['length']-_0x364e97['pieceNum_'];}function b(_0x3f166e){let _0x1969e8=_0x3f166e['pieceNum_'];return _0x1969e8<_0x3f166e['pieces_']['length']&&_0x1969e8++,new C(_0x3f166e['pieces_'],_0x1969e8);}function zi(_0xa09d68){return _0xa09d68['pieceNum_']<_0xa09d68['pieces_']['length']?_0xa09d68['pieces_'][_0xa09d68['pieces_']['length']-0x1]:null;}function bh(_0x4daa42){let _0x9396b9='';for(let _0x1c211b=_0x4daa42['pieceNum_'];_0x1c211b<_0x4daa42['pieces_']['length'];_0x1c211b++)_0x4daa42['pieces_'][_0x1c211b]!==''&&(_0x9396b9+='/'+encodeURIComponent(String(_0x4daa42['pieces_'][_0x1c211b])));return _0x9396b9||'/';}function Pt(_0x4fba56,_0x2767ea=0x0){return _0x4fba56['pieces_']['slice'](_0x4fba56['pieceNum_']+_0x2767ea);}function Ro(_0x43d809){if(_0x43d809['pieceNum_']>=_0x43d809['pieces_']['length'])return null;const _0x52fbd6=[];for(let _0x14de6a=_0x43d809['pieceNum_'];_0x14de6a<_0x43d809['pieces_']['length']-0x1;_0x14de6a++)_0x52fbd6['push'](_0x43d809['pieces_'][_0x14de6a]);return new C(_0x52fbd6,0x0);}function k(_0x4a51ca,_0x51125e){const _0x1032e8=[];for(let _0x12f47c=_0x4a51ca['pieceNum_'];_0x12f47c<_0x4a51ca['pieces_']['length'];_0x12f47c++)_0x1032e8['push'](_0x4a51ca['pieces_'][_0x12f47c]);if(_0x51125e instanceof C){for(let _0x365ae4=_0x51125e['pieceNum_'];_0x365ae4<_0x51125e['pieces_']['length'];_0x365ae4++)_0x1032e8['push'](_0x51125e['pieces_'][_0x365ae4]);}else{const _0x9eaa96=_0x51125e['split']('/');for(let _0x222698=0x0;_0x222698<_0x9eaa96['length'];_0x222698++)_0x9eaa96[_0x222698]['length']>0x0&&_0x1032e8['push'](_0x9eaa96[_0x222698]);}return new C(_0x1032e8,0x0);}function v(_0xfbf594){return _0xfbf594['pieceNum_']>=_0xfbf594['pieces_']['length'];}function F(_0x54f525,_0x1b74bf){const _0x263fb9=y(_0x54f525),_0x4adf9e=y(_0x1b74bf);if(_0x263fb9===null)return _0x1b74bf;if(_0x263fb9===_0x4adf9e)return F(b(_0x54f525),b(_0x1b74bf));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x1b74bf+')\x20is\x20not\x20within\x20outerPath\x20('+_0x54f525+')');}function Rh(_0x4228bb,_0x6e528c){const _0x666cf3=Pt(_0x4228bb,0x0),_0x224dba=Pt(_0x6e528c,0x0);for(let _0x196968=0x0;_0x196968<_0x666cf3['length']&&_0x196968<_0x224dba['length'];_0x196968++){const _0x376627=He(_0x666cf3[_0x196968],_0x224dba[_0x196968]);if(_0x376627!==0x0)return _0x376627;}return _0x666cf3['length']===_0x224dba['length']?0x0:_0x666cf3['length']<_0x224dba['length']?-0x1:0x1;}function ji(_0x4a526c,_0x45816f){if(we(_0x4a526c)!==we(_0x45816f))return!0x1;for(let _0x321503=_0x4a526c['pieceNum_'],_0x11b7f4=_0x45816f['pieceNum_'];_0x321503<=_0x4a526c['pieces_']['length'];_0x321503++,_0x11b7f4++)if(_0x4a526c['pieces_'][_0x321503]!==_0x45816f['pieces_'][_0x11b7f4])return!0x1;return!0x0;}function G(_0x2157b4,_0x23abbe){let _0x3a80a9=_0x2157b4['pieceNum_'],_0x133a0b=_0x23abbe['pieceNum_'];if(we(_0x2157b4)>we(_0x23abbe))return!0x1;for(;_0x3a80a9<_0x2157b4['pieces_']['length'];){if(_0x2157b4['pieces_'][_0x3a80a9]!==_0x23abbe['pieces_'][_0x133a0b])return!0x1;++_0x3a80a9,++_0x133a0b;}return!0x0;}class Ah{constructor(_0x4273e8,_0x563d14){this['errorPrefix_']=_0x563d14,this['parts_']=Pt(_0x4273e8,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x2802d1=0x0;_0x2802d1<this['parts_']['length'];_0x2802d1++)this['byteLength_']+=On(this['parts_'][_0x2802d1]);Ao(this);}}function kh(_0x4a7b29,_0x1c8c1a){_0x4a7b29['parts_']['length']>0x0&&(_0x4a7b29['byteLength_']+=0x1),_0x4a7b29['parts_']['push'](_0x1c8c1a),_0x4a7b29['byteLength_']+=On(_0x1c8c1a),Ao(_0x4a7b29);}function Nh(_0x20e86b){const _0x5183ac=_0x20e86b['parts_']['pop']();_0x20e86b['byteLength_']-=On(_0x5183ac),_0x20e86b['parts_']['length']>0x0&&(_0x20e86b['byteLength_']-=0x1);}function Ao(_0x275d55){if(_0x275d55['byteLength_']>er)throw new Error(_0x275d55['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+er+'\x20bytes\x20('+_0x275d55['byteLength_']+').');if(_0x275d55['parts_']['length']>Zs)throw new Error(_0x275d55['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Zs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Pe(_0x275d55));}function Pe(_0xe85fd7){return _0xe85fd7['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0xe85fd7['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends bo{static['getInstance'](){return new Ki();}constructor(){super(['visible']);let _0x134d34,_0xf387ff;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0xf387ff='visibilitychange',_0x134d34='hidden'):typeof document['mozHidden']<'u'?(_0xf387ff='mozvisibilitychange',_0x134d34='mozHidden'):typeof document['msHidden']<'u'?(_0xf387ff='msvisibilitychange',_0x134d34='msHidden'):typeof document['webkitHidden']<'u'&&(_0xf387ff='webkitvisibilitychange',_0x134d34='webkitHidden')),this['visible_']=!0x0,_0xf387ff&&document['addEventListener'](_0xf387ff,()=>{const _0x39d301=!document[_0x134d34];_0x39d301!==this['visible_']&&(this['visible_']=_0x39d301,this['trigger']('visible',_0x39d301));},!0x1);}['getInitialEvent'](_0x37272b){return f(_0x37272b==='visible','Unknown\x20event\x20type:\x20'+_0x37272b),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gt=0x3e8,Ph=0x12c*0x3e8,tr=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',nr=0x3;class se extends So{constructor(_0x3fa8be,_0x1c3e57,_0x193ea9,_0x1be3dd,_0x3e8da0,_0xe2b123,_0x4db050,_0x1d65c7){if(super(),this['repoInfo_']=_0x3fa8be,this['applicationId_']=_0x1c3e57,this['onDataUpdate_']=_0x193ea9,this['onConnectStatus_']=_0x1be3dd,this['onServerInfoUpdate_']=_0x3e8da0,this['authTokenProvider_']=_0xe2b123,this['appCheckTokenProvider_']=_0x4db050,this['authOverride_']=_0x1d65c7,this['id']=se['nextPersistentConnectionId_']++,this['log_']=Ht('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=gt,this['maxReconnectDelay_']=Ph,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x1d65c7)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Ki['getInstance']()['on']('visible',this['onVisible_'],this),_0x3fa8be['host']['indexOf']('fblocal')===-0x1&&dn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x3791d6,_0x24e13e,_0x414f90){const _0x1ca106=++this['requestNumber_'],_0x54b927={'r':_0x1ca106,'a':_0x3791d6,'b':_0x24e13e};this['log_'](O(_0x54b927)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x54b927),_0x414f90&&(this['requestCBHash_'][_0x1ca106]=_0x414f90);}['get'](_0x1dde75){this['initConnection_']();const _0x1fd98e=new ot(),_0x2306c0={'action':'g','request':{'p':_0x1dde75['_path']['toString'](),'q':_0x1dde75['_queryObject']},'onComplete':_0x3267a7=>{const _0x59c305=_0x3267a7['d'];_0x3267a7['s']==='ok'?_0x1fd98e['resolve'](_0x59c305):_0x1fd98e['reject'](_0x59c305);}};this['outstandingGets_']['push'](_0x2306c0),this['outstandingGetCount_']++;const _0x1169c8=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x1169c8),_0x1fd98e['promise'];}['listen'](_0x1bbaf8,_0x30faee,_0xe99f84,_0x5b01e5){this['initConnection_']();const _0x396eab=_0x1bbaf8['_queryIdentifier'],_0x2158f0=_0x1bbaf8['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x2158f0+'\x20'+_0x396eab),this['listens']['has'](_0x2158f0)||this['listens']['set'](_0x2158f0,new Map()),f(_0x1bbaf8['_queryParams']['isDefault']()||!_0x1bbaf8['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x2158f0)['has'](_0x396eab),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x38018c={'onComplete':_0x5b01e5,'hashFn':_0x30faee,'query':_0x1bbaf8,'tag':_0xe99f84};this['listens']['get'](_0x2158f0)['set'](_0x396eab,_0x38018c),this['connected_']&&this['sendListen_'](_0x38018c);}['sendGet_'](_0x3419eb){const _0x5cb401=this['outstandingGets_'][_0x3419eb];this['sendRequest']('g',_0x5cb401['request'],_0x5f8778=>{delete this['outstandingGets_'][_0x3419eb],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x5cb401['onComplete']&&_0x5cb401['onComplete'](_0x5f8778);});}['sendListen_'](_0x56db1e){const _0xa10db=_0x56db1e['query'],_0x1c3860=_0xa10db['_path']['toString'](),_0x214709=_0xa10db['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x1c3860+'\x20for\x20'+_0x214709);const _0x5d87e6={'p':_0x1c3860},_0x168896='q';_0x56db1e['tag']&&(_0x5d87e6['q']=_0xa10db['_queryObject'],_0x5d87e6['t']=_0x56db1e['tag']),_0x5d87e6['h']=_0x56db1e['hashFn'](),this['sendRequest'](_0x168896,_0x5d87e6,_0x1d1143=>{const _0x5b16be=_0x1d1143['d'],_0x4b864a=_0x1d1143['s'];se['warnOnListenWarnings_'](_0x5b16be,_0xa10db),(this['listens']['get'](_0x1c3860)&&this['listens']['get'](_0x1c3860)['get'](_0x214709))===_0x56db1e&&(this['log_']('listen\x20response',_0x1d1143),_0x4b864a!=='ok'&&this['removeListen_'](_0x1c3860,_0x214709),_0x56db1e['onComplete']&&_0x56db1e['onComplete'](_0x4b864a,_0x5b16be));});}static['warnOnListenWarnings_'](_0x23ea3a,_0x1e869a){if(_0x23ea3a&&typeof _0x23ea3a=='object'&&J(_0x23ea3a,'w')){const _0x1cc8fb=De(_0x23ea3a,'w');if(Array['isArray'](_0x1cc8fb)&&~_0x1cc8fb['indexOf']('no_index')){const _0x3b4330='\x22.indexOn\x22:\x20\x22'+_0x1e869a['_queryParams']['getIndex']()['toString']()+'\x22',_0x25831b=_0x1e869a['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x3b4330+'\x20at\x20'+_0x25831b+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x197b22){this['authToken_']=_0x197b22,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x197b22);}['reduceReconnectDelayIfAdminCredential_'](_0x440e7e){(_0x440e7e&&_0x440e7e['length']===0x28||wc(_0x440e7e))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=tr);}['refreshAppCheckToken'](_0x2e3399){this['appCheckToken_']=_0x2e3399,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x2b8c38=this['authToken_'],_0x58b16b=Ic(_0x2b8c38)?'auth':'gauth',_0xe20e26={'cred':_0x2b8c38};this['authOverride_']===null?_0xe20e26['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0xe20e26['authvar']=this['authOverride_']),this['sendRequest'](_0x58b16b,_0xe20e26,_0x3ceb1e=>{const _0x3ecb72=_0x3ceb1e['s'],_0x14c229=_0x3ceb1e['d']||'error';this['authToken_']===_0x2b8c38&&(_0x3ecb72==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x3ecb72,_0x14c229));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x941bf=>{const _0x540eab=_0x941bf['s'],_0x31dd2f=_0x941bf['d']||'error';_0x540eab==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x540eab,_0x31dd2f);});}['unlisten'](_0xd82bfb,_0x19f24f){const _0x2c2763=_0xd82bfb['_path']['toString'](),_0xdd9463=_0xd82bfb['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x2c2763+'\x20'+_0xdd9463),f(_0xd82bfb['_queryParams']['isDefault']()||!_0xd82bfb['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x2c2763,_0xdd9463)&&this['connected_']&&this['sendUnlisten_'](_0x2c2763,_0xdd9463,_0xd82bfb['_queryObject'],_0x19f24f);}['sendUnlisten_'](_0x3e9aad,_0x2995f2,_0x121ca6,_0x1665a){this['log_']('Unlisten\x20on\x20'+_0x3e9aad+'\x20for\x20'+_0x2995f2);const _0x17e5ae={'p':_0x3e9aad},_0x1a6473='n';_0x1665a&&(_0x17e5ae['q']=_0x121ca6,_0x17e5ae['t']=_0x1665a),this['sendRequest'](_0x1a6473,_0x17e5ae);}['onDisconnectPut'](_0x2f81ae,_0x450256,_0x4fea76){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x2f81ae,_0x450256,_0x4fea76):this['onDisconnectRequestQueue_']['push']({'pathString':_0x2f81ae,'action':'o','data':_0x450256,'onComplete':_0x4fea76});}['onDisconnectMerge'](_0x388a5f,_0x29be0f,_0x50b666){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x388a5f,_0x29be0f,_0x50b666):this['onDisconnectRequestQueue_']['push']({'pathString':_0x388a5f,'action':'om','data':_0x29be0f,'onComplete':_0x50b666});}['onDisconnectCancel'](_0x304489,_0x3bb8d2){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x304489,null,_0x3bb8d2):this['onDisconnectRequestQueue_']['push']({'pathString':_0x304489,'action':'oc','data':null,'onComplete':_0x3bb8d2});}['sendOnDisconnect_'](_0x1d1470,_0x3729d3,_0x36aa91,_0x39440a){const _0x306002={'p':_0x3729d3,'d':_0x36aa91};this['log_']('onDisconnect\x20'+_0x1d1470,_0x306002),this['sendRequest'](_0x1d1470,_0x306002,_0x1ecffb=>{_0x39440a&&setTimeout(()=>{_0x39440a(_0x1ecffb['s'],_0x1ecffb['d']);},Math['floor'](0x0));});}['put'](_0xd89c85,_0x1d6020,_0xa4c1b,_0x49d7d3){this['putInternal']('p',_0xd89c85,_0x1d6020,_0xa4c1b,_0x49d7d3);}['merge'](_0x3d4161,_0x5d8d69,_0x5bada6,_0x8b0ad3){this['putInternal']('m',_0x3d4161,_0x5d8d69,_0x5bada6,_0x8b0ad3);}['putInternal'](_0x523e8d,_0x9234b1,_0x29b5e1,_0x5a6b89,_0x271e64){this['initConnection_']();const _0x584861={'p':_0x9234b1,'d':_0x29b5e1};_0x271e64!==void 0x0&&(_0x584861['h']=_0x271e64),this['outstandingPuts_']['push']({'action':_0x523e8d,'request':_0x584861,'onComplete':_0x5a6b89}),this['outstandingPutCount_']++;const _0xdad4d2=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0xdad4d2):this['log_']('Buffering\x20put:\x20'+_0x9234b1);}['sendPut_'](_0x45b593){const _0x2315bb=this['outstandingPuts_'][_0x45b593]['action'],_0x3205cb=this['outstandingPuts_'][_0x45b593]['request'],_0x38b1aa=this['outstandingPuts_'][_0x45b593]['onComplete'];this['outstandingPuts_'][_0x45b593]['queued']=this['connected_'],this['sendRequest'](_0x2315bb,_0x3205cb,_0x3c51ae=>{this['log_'](_0x2315bb+'\x20response',_0x3c51ae),delete this['outstandingPuts_'][_0x45b593],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x38b1aa&&_0x38b1aa(_0x3c51ae['s'],_0x3c51ae['d']);});}['reportStats'](_0x325665){if(this['connected_']){const _0x7b8244={'c':_0x325665};this['log_']('reportStats',_0x7b8244),this['sendRequest']('s',_0x7b8244,_0x1d5eb3=>{if(_0x1d5eb3['s']!=='ok'){const _0x880503=_0x1d5eb3['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x880503);}});}}['onDataMessage_'](_0x560561){if('r'in _0x560561){this['log_']('from\x20server:\x20'+O(_0x560561));const _0x2690f2=_0x560561['r'],_0x7c2d93=this['requestCBHash_'][_0x2690f2];_0x7c2d93&&(delete this['requestCBHash_'][_0x2690f2],_0x7c2d93(_0x560561['b']));}else{if('error'in _0x560561)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x560561['error'];'a'in _0x560561&&this['onDataPush_'](_0x560561['a'],_0x560561['b']);}}['onDataPush_'](_0x3b67fa,_0x42036f){this['log_']('handleServerMessage',_0x3b67fa,_0x42036f),_0x3b67fa==='d'?this['onDataUpdate_'](_0x42036f['p'],_0x42036f['d'],!0x1,_0x42036f['t']):_0x3b67fa==='m'?this['onDataUpdate_'](_0x42036f['p'],_0x42036f['d'],!0x0,_0x42036f['t']):_0x3b67fa==='c'?this['onListenRevoked_'](_0x42036f['p'],_0x42036f['q']):_0x3b67fa==='ac'?this['onAuthRevoked_'](_0x42036f['s'],_0x42036f['d']):_0x3b67fa==='apc'?this['onAppCheckRevoked_'](_0x42036f['s'],_0x42036f['d']):_0x3b67fa==='sd'?this['onSecurityDebugPacket_'](_0x42036f):yi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x3b67fa)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x45bee1,_0xb24367){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x45bee1),this['lastSessionId']=_0xb24367,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x1728dc){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x1728dc));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x2574b0){_0x2574b0&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x2574b0;}['onOnline_'](_0x20d8e2){_0x20d8e2?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=gt),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x100fcd=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x15af6d=Math['max'](0x0,this['reconnectDelay_']-_0x100fcd);_0x15af6d=Math['random']()*_0x15af6d,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x15af6d+'ms'),this['scheduleConnect_'](_0x15af6d),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x41a50a=this['onDataMessage_']['bind'](this),_0x3aac8e=this['onReady_']['bind'](this),_0x4eb16c=this['onRealtimeDisconnect_']['bind'](this),_0x3a54e3=this['id']+':'+se['nextConnectionId_']++,_0x33e4e2=this['lastSessionId'];let _0x492de7=!0x1,_0x95b664=null;const _0x1d8af8=function(){_0x95b664?_0x95b664['close']():(_0x492de7=!0x0,_0x4eb16c());},_0x3eafec=function(_0x361400){f(_0x95b664,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x95b664['sendRequest'](_0x361400);};this['realtime_']={'close':_0x1d8af8,'sendRequest':_0x3eafec};const _0x4715dd=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x79ec0d,_0x478513]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x4715dd),this['appCheckTokenProvider_']['getToken'](_0x4715dd)]);_0x492de7?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x79ec0d&&_0x79ec0d['accessToken'],this['appCheckToken_']=_0x478513&&_0x478513['token'],_0x95b664=new Sh(_0x3a54e3,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x41a50a,_0x3aac8e,_0x4eb16c,_0x4fc35f=>{U(_0x4fc35f+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x33e4e2));}catch(_0x18492b){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x18492b),_0x492de7||(this['repoInfo_']['nodeAdmin']&&U(_0x18492b),_0x1d8af8());}}}['interrupt'](_0x5043b4){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x5043b4),this['interruptReasons_'][_0x5043b4]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x3fb411){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x3fb411),delete this['interruptReasons_'][_0x3fb411],ui(this['interruptReasons_'])&&(this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x5d1a4e){const _0x15d77a=_0x5d1a4e-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x15d77a});}['cancelSentTransactions_'](){for(let _0x273643=0x0;_0x273643<this['outstandingPuts_']['length'];_0x273643++){const _0x478404=this['outstandingPuts_'][_0x273643];_0x478404&&'h'in _0x478404['request']&&_0x478404['queued']&&(_0x478404['onComplete']&&_0x478404['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x273643],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x5a5991,_0x1e4bc6){let _0x516768;_0x1e4bc6?_0x516768=_0x1e4bc6['map'](_0x12b564=>Hi(_0x12b564))['join']('$'):_0x516768='default';const _0x4f49f0=this['removeListen_'](_0x5a5991,_0x516768);_0x4f49f0&&_0x4f49f0['onComplete']&&_0x4f49f0['onComplete']('permission_denied');}['removeListen_'](_0xc24665,_0x2923f3){const _0x2e13b0=new C(_0xc24665)['toString']();let _0x26c2e5;if(this['listens']['has'](_0x2e13b0)){const _0x2102e8=this['listens']['get'](_0x2e13b0);_0x26c2e5=_0x2102e8['get'](_0x2923f3),_0x2102e8['delete'](_0x2923f3),_0x2102e8['size']===0x0&&this['listens']['delete'](_0x2e13b0);}else _0x26c2e5=void 0x0;return _0x26c2e5;}['onAuthRevoked_'](_0x57e2c3,_0xa9dfef){L('Auth\x20token\x20revoked:\x20'+_0x57e2c3+'/'+_0xa9dfef),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x57e2c3==='invalid_token'||_0x57e2c3==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=nr&&(this['reconnectDelay_']=tr,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x5c4129,_0x5bdf5d){L('App\x20check\x20token\x20revoked:\x20'+_0x5c4129+'/'+_0x5bdf5d),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x5c4129==='invalid_token'||_0x5c4129==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=nr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x1289e9){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x1289e9):'msg'in _0x1289e9&&console['log']('FIREBASE:\x20'+_0x1289e9['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x525622 of this['listens']['values']())for(const _0x201498 of _0x525622['values']())this['sendListen_'](_0x201498);for(let _0x1a3a8f=0x0;_0x1a3a8f<this['outstandingPuts_']['length'];_0x1a3a8f++)this['outstandingPuts_'][_0x1a3a8f]&&this['sendPut_'](_0x1a3a8f);for(;this['onDisconnectRequestQueue_']['length'];){const _0x2eaf74=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x2eaf74['action'],_0x2eaf74['pathString'],_0x2eaf74['data'],_0x2eaf74['onComplete']);}for(let _0x3792bb=0x0;_0x3792bb<this['outstandingGets_']['length'];_0x3792bb++)this['outstandingGets_'][_0x3792bb]&&this['sendGet_'](_0x3792bb);}['sendConnectStats_'](){const _0x21ecb9={};let _0x160fd6='js';_0x21ecb9['sdk.'+_0x160fd6+'.'+no['replace'](/\./g,'-')]=0x1,Fi()?_0x21ecb9['framework.cordova']=0x1:Yr()&&(_0x21ecb9['framework.reactnative']=0x1),this['reportStats'](_0x21ecb9);}['shouldReconnect_'](){const _0x2bc525=dn['getInstance']()['currentlyOnline']();return ui(this['interruptReasons_'])&&_0x2bc525;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x162029,_0x379022){this['name']=_0x162029,this['node']=_0x379022;}static['Wrap'](_0x203806,_0x8acfd4){return new E(_0x203806,_0x8acfd4);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x4aa1b9,_0x46e6c){const _0x575d6e=new E(Fe,_0x4aa1b9),_0x51ca4b=new E(Fe,_0x46e6c);return this['compare'](_0x575d6e,_0x51ca4b)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zt;class ko extends Dn{static get['__EMPTY_NODE'](){return Zt;}static set['__EMPTY_NODE'](_0x106565){Zt=_0x106565;}['compare'](_0x6b9e65,_0x2b317e){return He(_0x6b9e65['name'],_0x2b317e['name']);}['isDefinedOn'](_0x2cc265){throw rt('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x336e2e,_0x144057){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Zt);}['makePost'](_0x531136,_0x431396){return f(typeof _0x531136=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x531136,Zt);}['toString'](){return'.key';}}const ye=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class en{constructor(_0x3c5ab1,_0x5b1453,_0x4ac992,_0x2c8a60,_0xfed4da=null){this['isReverse_']=_0x2c8a60,this['resultGenerator_']=_0xfed4da,this['nodeStack_']=[];let _0x36341f=0x1;for(;!_0x3c5ab1['isEmpty']();)if(_0x3c5ab1=_0x3c5ab1,_0x36341f=_0x5b1453?_0x4ac992(_0x3c5ab1['key'],_0x5b1453):0x1,_0x2c8a60&&(_0x36341f*=-0x1),_0x36341f<0x0)this['isReverse_']?_0x3c5ab1=_0x3c5ab1['left']:_0x3c5ab1=_0x3c5ab1['right'];else{if(_0x36341f===0x0){this['nodeStack_']['push'](_0x3c5ab1);break;}else this['nodeStack_']['push'](_0x3c5ab1),this['isReverse_']?_0x3c5ab1=_0x3c5ab1['right']:_0x3c5ab1=_0x3c5ab1['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x5441c1=this['nodeStack_']['pop'](),_0x46370f;if(this['resultGenerator_']?_0x46370f=this['resultGenerator_'](_0x5441c1['key'],_0x5441c1['value']):_0x46370f={'key':_0x5441c1['key'],'value':_0x5441c1['value']},this['isReverse_']){for(_0x5441c1=_0x5441c1['left'];!_0x5441c1['isEmpty']();)this['nodeStack_']['push'](_0x5441c1),_0x5441c1=_0x5441c1['right'];}else{for(_0x5441c1=_0x5441c1['right'];!_0x5441c1['isEmpty']();)this['nodeStack_']['push'](_0x5441c1),_0x5441c1=_0x5441c1['left'];}return _0x46370f;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x7faf82=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x7faf82['key'],_0x7faf82['value']):{'key':_0x7faf82['key'],'value':_0x7faf82['value']};}}class M{constructor(_0x210b50,_0x34bc3b,_0x26f8d5,_0x5bb74a,_0x1cd0b4){this['key']=_0x210b50,this['value']=_0x34bc3b,this['color']=_0x26f8d5??M['RED'],this['left']=_0x5bb74a??B['EMPTY_NODE'],this['right']=_0x1cd0b4??B['EMPTY_NODE'];}['copy'](_0xc916bd,_0x48d375,_0x20041e,_0x52cc71,_0x44a79a){return new M(_0xc916bd??this['key'],_0x48d375??this['value'],_0x20041e??this['color'],_0x52cc71??this['left'],_0x44a79a??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x783869){return this['left']['inorderTraversal'](_0x783869)||!!_0x783869(this['key'],this['value'])||this['right']['inorderTraversal'](_0x783869);}['reverseTraversal'](_0x242224){return this['right']['reverseTraversal'](_0x242224)||_0x242224(this['key'],this['value'])||this['left']['reverseTraversal'](_0x242224);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x107c40,_0x2fd3c0,_0x2bda9d){let _0x3d3770=this;const _0x35e8ec=_0x2bda9d(_0x107c40,_0x3d3770['key']);return _0x35e8ec<0x0?_0x3d3770=_0x3d3770['copy'](null,null,null,_0x3d3770['left']['insert'](_0x107c40,_0x2fd3c0,_0x2bda9d),null):_0x35e8ec===0x0?_0x3d3770=_0x3d3770['copy'](null,_0x2fd3c0,null,null,null):_0x3d3770=_0x3d3770['copy'](null,null,null,null,_0x3d3770['right']['insert'](_0x107c40,_0x2fd3c0,_0x2bda9d)),_0x3d3770['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x4d499a=this;return!_0x4d499a['left']['isRed_']()&&!_0x4d499a['left']['left']['isRed_']()&&(_0x4d499a=_0x4d499a['moveRedLeft_']()),_0x4d499a=_0x4d499a['copy'](null,null,null,_0x4d499a['left']['removeMin_'](),null),_0x4d499a['fixUp_']();}['remove'](_0x1a0bc6,_0x1ded68){let _0x28be55,_0x14dec1;if(_0x28be55=this,_0x1ded68(_0x1a0bc6,_0x28be55['key'])<0x0)!_0x28be55['left']['isEmpty']()&&!_0x28be55['left']['isRed_']()&&!_0x28be55['left']['left']['isRed_']()&&(_0x28be55=_0x28be55['moveRedLeft_']()),_0x28be55=_0x28be55['copy'](null,null,null,_0x28be55['left']['remove'](_0x1a0bc6,_0x1ded68),null);else{if(_0x28be55['left']['isRed_']()&&(_0x28be55=_0x28be55['rotateRight_']()),!_0x28be55['right']['isEmpty']()&&!_0x28be55['right']['isRed_']()&&!_0x28be55['right']['left']['isRed_']()&&(_0x28be55=_0x28be55['moveRedRight_']()),_0x1ded68(_0x1a0bc6,_0x28be55['key'])===0x0){if(_0x28be55['right']['isEmpty']())return B['EMPTY_NODE'];_0x14dec1=_0x28be55['right']['min_'](),_0x28be55=_0x28be55['copy'](_0x14dec1['key'],_0x14dec1['value'],null,null,_0x28be55['right']['removeMin_']());}_0x28be55=_0x28be55['copy'](null,null,null,null,_0x28be55['right']['remove'](_0x1a0bc6,_0x1ded68));}return _0x28be55['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0xb98018=this;return _0xb98018['right']['isRed_']()&&!_0xb98018['left']['isRed_']()&&(_0xb98018=_0xb98018['rotateLeft_']()),_0xb98018['left']['isRed_']()&&_0xb98018['left']['left']['isRed_']()&&(_0xb98018=_0xb98018['rotateRight_']()),_0xb98018['left']['isRed_']()&&_0xb98018['right']['isRed_']()&&(_0xb98018=_0xb98018['colorFlip_']()),_0xb98018;}['moveRedLeft_'](){let _0x5d3b16=this['colorFlip_']();return _0x5d3b16['right']['left']['isRed_']()&&(_0x5d3b16=_0x5d3b16['copy'](null,null,null,null,_0x5d3b16['right']['rotateRight_']()),_0x5d3b16=_0x5d3b16['rotateLeft_'](),_0x5d3b16=_0x5d3b16['colorFlip_']()),_0x5d3b16;}['moveRedRight_'](){let _0x475b7e=this['colorFlip_']();return _0x475b7e['left']['left']['isRed_']()&&(_0x475b7e=_0x475b7e['rotateRight_'](),_0x475b7e=_0x475b7e['colorFlip_']()),_0x475b7e;}['rotateLeft_'](){const _0xbced2f=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0xbced2f,null);}['rotateRight_'](){const _0x31e87c=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x31e87c);}['colorFlip_'](){const _0x19d72a=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x4ca838=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x19d72a,_0x4ca838);}['checkMaxDepth_'](){const _0x5d7629=this['check_']();return Math['pow'](0x2,_0x5d7629)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x3e06eb=this['left']['check_']();if(_0x3e06eb!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x3e06eb+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0x4037f5,_0x3943f9,_0x4317a5,_0x873fc4,_0x2847fe){return this;}['insert'](_0x25c4b2,_0x2aada3,_0xb86645){return new M(_0x25c4b2,_0x2aada3,null);}['remove'](_0x347799,_0x1b8024){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x29b47b){return!0x1;}['reverseTraversal'](_0x3b5fd7){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x516453,_0x1cedc0=B['EMPTY_NODE']){this['comparator_']=_0x516453,this['root_']=_0x1cedc0;}['insert'](_0x5ee445,_0x5893c7){return new B(this['comparator_'],this['root_']['insert'](_0x5ee445,_0x5893c7,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0x23fb56){return new B(this['comparator_'],this['root_']['remove'](_0x23fb56,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x2ce0f0){let _0x34ccfc,_0x47cc57=this['root_'];for(;!_0x47cc57['isEmpty']();){if(_0x34ccfc=this['comparator_'](_0x2ce0f0,_0x47cc57['key']),_0x34ccfc===0x0)return _0x47cc57['value'];_0x34ccfc<0x0?_0x47cc57=_0x47cc57['left']:_0x34ccfc>0x0&&(_0x47cc57=_0x47cc57['right']);}return null;}['getPredecessorKey'](_0x89497f){let _0x39c1d3,_0x2c29f1=this['root_'],_0x809daf=null;for(;!_0x2c29f1['isEmpty']();)if(_0x39c1d3=this['comparator_'](_0x89497f,_0x2c29f1['key']),_0x39c1d3===0x0){if(_0x2c29f1['left']['isEmpty']())return _0x809daf?_0x809daf['key']:null;for(_0x2c29f1=_0x2c29f1['left'];!_0x2c29f1['right']['isEmpty']();)_0x2c29f1=_0x2c29f1['right'];return _0x2c29f1['key'];}else _0x39c1d3<0x0?_0x2c29f1=_0x2c29f1['left']:_0x39c1d3>0x0&&(_0x809daf=_0x2c29f1,_0x2c29f1=_0x2c29f1['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x25abb5){return this['root_']['inorderTraversal'](_0x25abb5);}['reverseTraversal'](_0x2095dc){return this['root_']['reverseTraversal'](_0x2095dc);}['getIterator'](_0x49fd75){return new en(this['root_'],null,this['comparator_'],!0x1,_0x49fd75);}['getIteratorFrom'](_0x44aa78,_0x4e26ad){return new en(this['root_'],_0x44aa78,this['comparator_'],!0x1,_0x4e26ad);}['getReverseIteratorFrom'](_0x1d4014,_0xd0c97e){return new en(this['root_'],_0x1d4014,this['comparator_'],!0x0,_0xd0c97e);}['getReverseIterator'](_0x2187a5){return new en(this['root_'],null,this['comparator_'],!0x0,_0x2187a5);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x236b9d,_0x37b859){return He(_0x236b9d['name'],_0x37b859['name']);}function Yi(_0x395135,_0x251008){return He(_0x395135,_0x251008);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ei;function Fh(_0x438755){Ei=_0x438755;}const No=function(_0x54f3e0){return typeof _0x54f3e0=='number'?'number:'+ao(_0x54f3e0):'string:'+_0x54f3e0;},Po=function(_0x2caede){if(_0x2caede['isLeafNode']()){const _0x1ed831=_0x2caede['val']();f(typeof _0x1ed831=='string'||typeof _0x1ed831=='number'||typeof _0x1ed831=='object'&&J(_0x1ed831,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x2caede===Ei||_0x2caede['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x2caede===Ei||_0x2caede['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ir;class D{static set['__childrenNodeConstructor'](_0x345ed5){ir=_0x345ed5;}static get['__childrenNodeConstructor'](){return ir;}constructor(_0x59bc1b,_0x509c6c=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x59bc1b,this['priorityNode_']=_0x509c6c,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Po(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x4a51f6){return new D(this['value_'],_0x4a51f6);}['getImmediateChild'](_0x57cb86){return _0x57cb86==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x8a20f3){return v(_0x8a20f3)?this:y(_0x8a20f3)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x485ce1,_0x152aa8){return null;}['updateImmediateChild'](_0x2c43ca,_0x9bea00){return _0x2c43ca==='.priority'?this['updatePriority'](_0x9bea00):_0x9bea00['isEmpty']()&&_0x2c43ca!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x2c43ca,_0x9bea00)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x5cec66,_0x175714){const _0x18e182=y(_0x5cec66);return _0x18e182===null?_0x175714:_0x175714['isEmpty']()&&_0x18e182!=='.priority'?this:(f(_0x18e182!=='.priority'||we(_0x5cec66)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x18e182,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x5cec66),_0x175714)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x420679,_0x29b4d3){return!0x1;}['val'](_0x4d24e2){return _0x4d24e2&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0x3d8538='';this['priorityNode_']['isEmpty']()||(_0x3d8538+='priority:'+No(this['priorityNode_']['val']())+':');const _0x1e51d0=typeof this['value_'];_0x3d8538+=_0x1e51d0+':',_0x1e51d0==='number'?_0x3d8538+=ao(this['value_']):_0x3d8538+=this['value_'],this['lazyHash_']=ro(_0x3d8538);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x1b8ec2){return _0x1b8ec2===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x1b8ec2 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x1b8ec2['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x1b8ec2));}['compareToLeafNode_'](_0x10dea3){const _0x7bb1d6=typeof _0x10dea3['value_'],_0x5adf31=typeof this['value_'],_0xb0c4c2=D['VALUE_TYPE_ORDER']['indexOf'](_0x7bb1d6),_0x77108e=D['VALUE_TYPE_ORDER']['indexOf'](_0x5adf31);return f(_0xb0c4c2>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x7bb1d6),f(_0x77108e>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x5adf31),_0xb0c4c2===_0x77108e?_0x5adf31==='object'?0x0:this['value_']<_0x10dea3['value_']?-0x1:this['value_']===_0x10dea3['value_']?0x0:0x1:_0x77108e-_0xb0c4c2;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x162d7b){if(_0x162d7b===this)return!0x0;if(_0x162d7b['isLeafNode']()){const _0x33f2e2=_0x162d7b;return this['value_']===_0x33f2e2['value_']&&this['priorityNode_']['equals'](_0x33f2e2['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x531384){Oo=_0x531384;}function Wh(_0x5beb31){Do=_0x5beb31;}class Bh extends Dn{['compare'](_0x5f3277,_0x597e1e){const _0x501095=_0x5f3277['node']['getPriority'](),_0x11ee5a=_0x597e1e['node']['getPriority'](),_0x7ceba4=_0x501095['compareTo'](_0x11ee5a);return _0x7ceba4===0x0?He(_0x5f3277['name'],_0x597e1e['name']):_0x7ceba4;}['isDefinedOn'](_0x29e3b9){return!_0x29e3b9['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x139b71,_0xeeac29){return!_0x139b71['getPriority']()['equals'](_0xeeac29['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',Do));}['makePost'](_0x39a7fc,_0x224214){const _0x51c3c8=Oo(_0x39a7fc);return new E(_0x224214,new D('[PRIORITY-POST]',_0x51c3c8));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x24d20c){const _0x2bd474=_0x1e0b90=>parseInt(Math['log'](_0x1e0b90)/Vh,0xa),_0x35da45=_0x35e974=>parseInt(Array(_0x35e974+0x1)['join']('1'),0x2);this['count']=_0x2bd474(_0x24d20c+0x1),this['current_']=this['count']-0x1;const _0x19ecf6=_0x35da45(this['count']);this['bits_']=_0x24d20c+0x1&_0x19ecf6;}['nextBitIsOne'](){const _0x52f673=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x52f673;}}const fn=function(_0x28b09b,_0x2715f7,_0x409b95,_0x50e046){_0x28b09b['sort'](_0x2715f7);const _0x2740c2=function(_0x5ad2c1,_0x40e6bd){const _0x3eb445=_0x40e6bd-_0x5ad2c1;let _0x4e43f4,_0x4a7cc6;if(_0x3eb445===0x0)return null;if(_0x3eb445===0x1)return _0x4e43f4=_0x28b09b[_0x5ad2c1],_0x4a7cc6=_0x409b95?_0x409b95(_0x4e43f4):_0x4e43f4,new M(_0x4a7cc6,_0x4e43f4['node'],M['BLACK'],null,null);{const _0x58e8f9=parseInt(_0x3eb445/0x2,0xa)+_0x5ad2c1,_0x184c1d=_0x2740c2(_0x5ad2c1,_0x58e8f9),_0x55d8f5=_0x2740c2(_0x58e8f9+0x1,_0x40e6bd);return _0x4e43f4=_0x28b09b[_0x58e8f9],_0x4a7cc6=_0x409b95?_0x409b95(_0x4e43f4):_0x4e43f4,new M(_0x4a7cc6,_0x4e43f4['node'],M['BLACK'],_0x184c1d,_0x55d8f5);}},_0x864380=function(_0x2ca7dd){let _0x500884=null,_0x1aac8a=null,_0x113294=_0x28b09b['length'];const _0x5e9325=function(_0xff184f,_0x2feb19){const _0x2a925c=_0x113294-_0xff184f,_0x2dc986=_0x113294;_0x113294-=_0xff184f;const _0x2dc686=_0x2740c2(_0x2a925c+0x1,_0x2dc986),_0x3e9709=_0x28b09b[_0x2a925c],_0x385a76=_0x409b95?_0x409b95(_0x3e9709):_0x3e9709;_0x31997b(new M(_0x385a76,_0x3e9709['node'],_0x2feb19,null,_0x2dc686));},_0x31997b=function(_0xc10b59){_0x500884?(_0x500884['left']=_0xc10b59,_0x500884=_0xc10b59):(_0x1aac8a=_0xc10b59,_0x500884=_0xc10b59);};for(let _0x3f46c5=0x0;_0x3f46c5<_0x2ca7dd['count'];++_0x3f46c5){const _0x2df9db=_0x2ca7dd['nextBitIsOne'](),_0x44c8a1=Math['pow'](0x2,_0x2ca7dd['count']-(_0x3f46c5+0x1));_0x2df9db?_0x5e9325(_0x44c8a1,M['BLACK']):(_0x5e9325(_0x44c8a1,M['BLACK']),_0x5e9325(_0x44c8a1,M['RED']));}return _0x1aac8a;},_0x1f8402=new Hh(_0x28b09b['length']),_0x2d27e8=_0x864380(_0x1f8402);return new B(_0x50e046||_0x2715f7,_0x2d27e8);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ze={};class te{static get['Default'](){return f(ze&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),ri=ri||new te({'.priority':ze},{'.priority':R}),ri;}constructor(_0x58e6c0,_0x410992){this['indexes_']=_0x58e6c0,this['indexSet_']=_0x410992;}['get'](_0x8868a3){const _0x2d8411=De(this['indexes_'],_0x8868a3);if(!_0x2d8411)throw new Error('No\x20index\x20defined\x20for\x20'+_0x8868a3);return _0x2d8411 instanceof B?_0x2d8411:null;}['hasIndex'](_0x5e7b15){return J(this['indexSet_'],_0x5e7b15['toString']());}['addIndex'](_0x661fb1,_0x4afcf1){f(_0x661fb1!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0xe40923=[];let _0x36cd47=!0x1;const _0x200771=_0x4afcf1['getIterator'](E['Wrap']);let _0x11621a=_0x200771['getNext']();for(;_0x11621a;)_0x36cd47=_0x36cd47||_0x661fb1['isDefinedOn'](_0x11621a['node']),_0xe40923['push'](_0x11621a),_0x11621a=_0x200771['getNext']();let _0x3a8c0b;_0x36cd47?_0x3a8c0b=fn(_0xe40923,_0x661fb1['getCompare']()):_0x3a8c0b=ze;const _0x112bfd=_0x661fb1['toString'](),_0x556592={...this['indexSet_']};_0x556592[_0x112bfd]=_0x661fb1;const _0x22468f={...this['indexes_']};return _0x22468f[_0x112bfd]=_0x3a8c0b,new te(_0x22468f,_0x556592);}['addToIndexes'](_0xf36fc0,_0x36cbd1){const _0xf2848=hn(this['indexes_'],(_0x5669f3,_0x18ded6)=>{const _0x357e53=De(this['indexSet_'],_0x18ded6);if(f(_0x357e53,'Missing\x20index\x20implementation\x20for\x20'+_0x18ded6),_0x5669f3===ze){if(_0x357e53['isDefinedOn'](_0xf36fc0['node'])){const _0x2029f5=[],_0x457149=_0x36cbd1['getIterator'](E['Wrap']);let _0x4c6c2e=_0x457149['getNext']();for(;_0x4c6c2e;)_0x4c6c2e['name']!==_0xf36fc0['name']&&_0x2029f5['push'](_0x4c6c2e),_0x4c6c2e=_0x457149['getNext']();return _0x2029f5['push'](_0xf36fc0),fn(_0x2029f5,_0x357e53['getCompare']());}else return ze;}else{const _0x445830=_0x36cbd1['get'](_0xf36fc0['name']);let _0x3a0888=_0x5669f3;return _0x445830&&(_0x3a0888=_0x3a0888['remove'](new E(_0xf36fc0['name'],_0x445830))),_0x3a0888['insert'](_0xf36fc0,_0xf36fc0['node']);}});return new te(_0xf2848,this['indexSet_']);}['removeFromIndexes'](_0x357a38,_0x2e0335){const _0x4e9f73=hn(this['indexes_'],_0xe44f32=>{if(_0xe44f32===ze)return _0xe44f32;{const _0x5885ce=_0x2e0335['get'](_0x357a38['name']);return _0x5885ce?_0xe44f32['remove'](new E(_0x357a38['name'],_0x5885ce)):_0xe44f32;}});return new te(_0x4e9f73,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let mt;class g{static get['EMPTY_NODE'](){return mt||(mt=new g(new B(Yi),null,te['Default']));}constructor(_0x109169,_0x59fc6e,_0x4b2cc7){this['children_']=_0x109169,this['priorityNode_']=_0x59fc6e,this['indexMap_']=_0x4b2cc7,this['lazyHash_']=null,this['priorityNode_']&&Po(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||mt;}['updatePriority'](_0x56f720){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x56f720,this['indexMap_']);}['getImmediateChild'](_0x3ae366){if(_0x3ae366==='.priority')return this['getPriority']();{const _0x28d527=this['children_']['get'](_0x3ae366);return _0x28d527===null?mt:_0x28d527;}}['getChild'](_0x69533c){const _0x9d1eca=y(_0x69533c);return _0x9d1eca===null?this:this['getImmediateChild'](_0x9d1eca)['getChild'](b(_0x69533c));}['hasChild'](_0x595c3b){return this['children_']['get'](_0x595c3b)!==null;}['updateImmediateChild'](_0x4cd650,_0x5751c6){if(f(_0x5751c6,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x4cd650==='.priority')return this['updatePriority'](_0x5751c6);{const _0x43a082=new E(_0x4cd650,_0x5751c6);let _0x4dc883,_0x47355f;_0x5751c6['isEmpty']()?(_0x4dc883=this['children_']['remove'](_0x4cd650),_0x47355f=this['indexMap_']['removeFromIndexes'](_0x43a082,this['children_'])):(_0x4dc883=this['children_']['insert'](_0x4cd650,_0x5751c6),_0x47355f=this['indexMap_']['addToIndexes'](_0x43a082,this['children_']));const _0x1bc382=_0x4dc883['isEmpty']()?mt:this['priorityNode_'];return new g(_0x4dc883,_0x1bc382,_0x47355f);}}['updateChild'](_0x4efcf1,_0x30b718){const _0x1e8c09=y(_0x4efcf1);if(_0x1e8c09===null)return _0x30b718;{f(y(_0x4efcf1)!=='.priority'||we(_0x4efcf1)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x41bcec=this['getImmediateChild'](_0x1e8c09)['updateChild'](b(_0x4efcf1),_0x30b718);return this['updateImmediateChild'](_0x1e8c09,_0x41bcec);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x54fca0){if(this['isEmpty']())return null;const _0x2867c6={};let _0x53f54c=0x0,_0x4da2eb=0x0,_0x3c3eec=!0x0;if(this['forEachChild'](R,(_0x5c8183,_0x14e6cc)=>{_0x2867c6[_0x5c8183]=_0x14e6cc['val'](_0x54fca0),_0x53f54c++,_0x3c3eec&&g['INTEGER_REGEXP_']['test'](_0x5c8183)?_0x4da2eb=Math['max'](_0x4da2eb,Number(_0x5c8183)):_0x3c3eec=!0x1;}),!_0x54fca0&&_0x3c3eec&&_0x4da2eb<0x2*_0x53f54c){const _0x1e8db9=[];for(const _0xfe2b50 in _0x2867c6)_0x1e8db9[_0xfe2b50]=_0x2867c6[_0xfe2b50];return _0x1e8db9;}else return _0x54fca0&&!this['getPriority']()['isEmpty']()&&(_0x2867c6['.priority']=this['getPriority']()['val']()),_0x2867c6;}['hash'](){if(this['lazyHash_']===null){let _0x151b81='';this['getPriority']()['isEmpty']()||(_0x151b81+='priority:'+No(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x115b24,_0x3e4e2f)=>{const _0x2c0b7c=_0x3e4e2f['hash']();_0x2c0b7c!==''&&(_0x151b81+=':'+_0x115b24+':'+_0x2c0b7c);}),this['lazyHash_']=_0x151b81===''?'':ro(_0x151b81);}return this['lazyHash_'];}['getPredecessorChildName'](_0x21799b,_0x1cefa2,_0x230d5e){const _0x15f2f9=this['resolveIndex_'](_0x230d5e);if(_0x15f2f9){const _0xba930d=_0x15f2f9['getPredecessorKey'](new E(_0x21799b,_0x1cefa2));return _0xba930d?_0xba930d['name']:null;}else return this['children_']['getPredecessorKey'](_0x21799b);}['getFirstChildName'](_0x54068d){const _0x7a9d59=this['resolveIndex_'](_0x54068d);if(_0x7a9d59){const _0x2d9da7=_0x7a9d59['minKey']();return _0x2d9da7&&_0x2d9da7['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x287dd7){const _0x222223=this['getFirstChildName'](_0x287dd7);return _0x222223?new E(_0x222223,this['children_']['get'](_0x222223)):null;}['getLastChildName'](_0x197de8){const _0x1695f0=this['resolveIndex_'](_0x197de8);if(_0x1695f0){const _0x4f4eac=_0x1695f0['maxKey']();return _0x4f4eac&&_0x4f4eac['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x44bf78){const _0x2952ab=this['getLastChildName'](_0x44bf78);return _0x2952ab?new E(_0x2952ab,this['children_']['get'](_0x2952ab)):null;}['forEachChild'](_0x5551f0,_0x1d2b27){const _0x387e6d=this['resolveIndex_'](_0x5551f0);return _0x387e6d?_0x387e6d['inorderTraversal'](_0x405ab2=>_0x1d2b27(_0x405ab2['name'],_0x405ab2['node'])):this['children_']['inorderTraversal'](_0x1d2b27);}['getIterator'](_0x1d7a7b){return this['getIteratorFrom'](_0x1d7a7b['minPost'](),_0x1d7a7b);}['getIteratorFrom'](_0x5661cc,_0x361a36){const _0x42c6a1=this['resolveIndex_'](_0x361a36);if(_0x42c6a1)return _0x42c6a1['getIteratorFrom'](_0x5661cc,_0x31f546=>_0x31f546);{const _0x1db94d=this['children_']['getIteratorFrom'](_0x5661cc['name'],E['Wrap']);let _0x30e8a8=_0x1db94d['peek']();for(;_0x30e8a8!=null&&_0x361a36['compare'](_0x30e8a8,_0x5661cc)<0x0;)_0x1db94d['getNext'](),_0x30e8a8=_0x1db94d['peek']();return _0x1db94d;}}['getReverseIterator'](_0xe33b72){return this['getReverseIteratorFrom'](_0xe33b72['maxPost'](),_0xe33b72);}['getReverseIteratorFrom'](_0x28b244,_0x5cd173){const _0x531246=this['resolveIndex_'](_0x5cd173);if(_0x531246)return _0x531246['getReverseIteratorFrom'](_0x28b244,_0x259a07=>_0x259a07);{const _0x228cb8=this['children_']['getReverseIteratorFrom'](_0x28b244['name'],E['Wrap']);let _0x3d32b9=_0x228cb8['peek']();for(;_0x3d32b9!=null&&_0x5cd173['compare'](_0x3d32b9,_0x28b244)>0x0;)_0x228cb8['getNext'](),_0x3d32b9=_0x228cb8['peek']();return _0x228cb8;}}['compareTo'](_0x4a52c8){return this['isEmpty']()?_0x4a52c8['isEmpty']()?0x0:-0x1:_0x4a52c8['isLeafNode']()||_0x4a52c8['isEmpty']()?0x1:_0x4a52c8===$t?-0x1:0x0;}['withIndex'](_0x10b277){if(_0x10b277===ye||this['indexMap_']['hasIndex'](_0x10b277))return this;{const _0x17bc57=this['indexMap_']['addIndex'](_0x10b277,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x17bc57);}}['isIndexed'](_0x2b426d){return _0x2b426d===ye||this['indexMap_']['hasIndex'](_0x2b426d);}['equals'](_0x57efb9){if(_0x57efb9===this)return!0x0;if(_0x57efb9['isLeafNode']())return!0x1;{const _0x5bc439=_0x57efb9;if(this['getPriority']()['equals'](_0x5bc439['getPriority']())){if(this['children_']['count']()===_0x5bc439['children_']['count']()){const _0x263bf2=this['getIterator'](R),_0xb38f33=_0x5bc439['getIterator'](R);let _0x4e1d15=_0x263bf2['getNext'](),_0x103494=_0xb38f33['getNext']();for(;_0x4e1d15&&_0x103494;){if(_0x4e1d15['name']!==_0x103494['name']||!_0x4e1d15['node']['equals'](_0x103494['node']))return!0x1;_0x4e1d15=_0x263bf2['getNext'](),_0x103494=_0xb38f33['getNext']();}return _0x4e1d15===null&&_0x103494===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x32f630){return _0x32f630===ye?null:this['indexMap_']['get'](_0x32f630['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Yi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x8eebbf){return _0x8eebbf===this?0x0:0x1;}['equals'](_0x33d6f0){return _0x33d6f0===this;}['getPriority'](){return this;}['getImmediateChild'](_0x1e3277){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const $t=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(Fe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,$t)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh($t),Wh($t);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function P(_0x419a11,_0x45ba51=null){if(_0x419a11===null)return g['EMPTY_NODE'];if(typeof _0x419a11=='object'&&'.priority'in _0x419a11&&(_0x45ba51=_0x419a11['.priority']),f(_0x45ba51===null||typeof _0x45ba51=='string'||typeof _0x45ba51=='number'||typeof _0x45ba51=='object'&&'.sv'in _0x45ba51,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x45ba51),typeof _0x419a11=='object'&&'.value'in _0x419a11&&_0x419a11['.value']!==null&&(_0x419a11=_0x419a11['.value']),typeof _0x419a11!='object'||'.sv'in _0x419a11){const _0xa8b9ae=_0x419a11;return new D(_0xa8b9ae,P(_0x45ba51));}if(!(_0x419a11 instanceof Array)&&Gh){const _0x4a297f=[];let _0x292a6a=!0x1;if(x(_0x419a11,(_0x3867fd,_0x21f4ac)=>{if(_0x3867fd['substring'](0x0,0x1)!=='.'){const _0x2ab94f=P(_0x21f4ac);_0x2ab94f['isEmpty']()||(_0x292a6a=_0x292a6a||!_0x2ab94f['getPriority']()['isEmpty'](),_0x4a297f['push'](new E(_0x3867fd,_0x2ab94f)));}}),_0x4a297f['length']===0x0)return g['EMPTY_NODE'];const _0x56f61e=fn(_0x4a297f,xh,_0xf3bc50=>_0xf3bc50['name'],Yi);if(_0x292a6a){const _0x5b1683=fn(_0x4a297f,R['getCompare']());return new g(_0x56f61e,P(_0x45ba51),new te({'.priority':_0x5b1683},{'.priority':R}));}else return new g(_0x56f61e,P(_0x45ba51),te['Default']);}else{let _0x240f40=g['EMPTY_NODE'];return x(_0x419a11,(_0xde0b58,_0x1e370c)=>{if(J(_0x419a11,_0xde0b58)&&_0xde0b58['substring'](0x0,0x1)!=='.'){const _0x34ef7c=P(_0x1e370c);(_0x34ef7c['isLeafNode']()||!_0x34ef7c['isEmpty']())&&(_0x240f40=_0x240f40['updateImmediateChild'](_0xde0b58,_0x34ef7c));}}),_0x240f40['updatePriority'](P(_0x45ba51));}}Uh(P);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi extends Dn{constructor(_0x1598ab){super(),this['indexPath_']=_0x1598ab,f(!v(_0x1598ab)&&y(_0x1598ab)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x682511){return _0x682511['getChild'](this['indexPath_']);}['isDefinedOn'](_0x37343e){return!_0x37343e['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x368944,_0xd046b0){const _0x449f2a=this['extractChild'](_0x368944['node']),_0x4c1974=this['extractChild'](_0xd046b0['node']),_0xfcddcc=_0x449f2a['compareTo'](_0x4c1974);return _0xfcddcc===0x0?He(_0x368944['name'],_0xd046b0['name']):_0xfcddcc;}['makePost'](_0x5c7661,_0xeb0d1c){const _0x569aa0=P(_0x5c7661),_0x1a8d08=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x569aa0);return new E(_0xeb0d1c,_0x1a8d08);}['maxPost'](){const _0x3cdae3=g['EMPTY_NODE']['updateChild'](this['indexPath_'],$t);return new E(Ie,_0x3cdae3);}['toString'](){return Pt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Dn{['compare'](_0x232c00,_0x35fc8f){const _0x47af40=_0x232c00['node']['compareTo'](_0x35fc8f['node']);return _0x47af40===0x0?He(_0x232c00['name'],_0x35fc8f['name']):_0x47af40;}['isDefinedOn'](_0x36280f){return!0x0;}['indexedValueChanged'](_0x825917,_0x336bc5){return!_0x825917['equals'](_0x336bc5);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x55525d,_0x5d8da4){const _0x242684=P(_0x55525d);return new E(_0x5d8da4,_0x242684);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0xdb7e9b){return{'type':'value','snapshotNode':_0xdb7e9b};}function et(_0x18b82f,_0xf9eb02){return{'type':'child_added','snapshotNode':_0xf9eb02,'childName':_0x18b82f};}function Ot(_0x1c267e,_0x300a1b){return{'type':'child_removed','snapshotNode':_0x300a1b,'childName':_0x1c267e};}function Dt(_0x402fcf,_0x24c9f9,_0x15c98c){return{'type':'child_changed','snapshotNode':_0x24c9f9,'childName':_0x402fcf,'oldSnap':_0x15c98c};}function zh(_0x1874c4,_0x5420a4){return{'type':'child_moved','snapshotNode':_0x5420a4,'childName':_0x1874c4};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji{constructor(_0x279e47){this['index_']=_0x279e47;}['updateChild'](_0x1ee221,_0x3c887e,_0x2d65d6,_0x4892a9,_0x16fe4f,_0x3daf79){f(_0x1ee221['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x19928d=_0x1ee221['getImmediateChild'](_0x3c887e);return _0x19928d['getChild'](_0x4892a9)['equals'](_0x2d65d6['getChild'](_0x4892a9))&&_0x19928d['isEmpty']()===_0x2d65d6['isEmpty']()||(_0x3daf79!=null&&(_0x2d65d6['isEmpty']()?_0x1ee221['hasChild'](_0x3c887e)?_0x3daf79['trackChildChange'](Ot(_0x3c887e,_0x19928d)):f(_0x1ee221['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x19928d['isEmpty']()?_0x3daf79['trackChildChange'](et(_0x3c887e,_0x2d65d6)):_0x3daf79['trackChildChange'](Dt(_0x3c887e,_0x2d65d6,_0x19928d))),_0x1ee221['isLeafNode']()&&_0x2d65d6['isEmpty']())?_0x1ee221:_0x1ee221['updateImmediateChild'](_0x3c887e,_0x2d65d6)['withIndex'](this['index_']);}['updateFullNode'](_0x3318a6,_0x14720c,_0x2e3e91){return _0x2e3e91!=null&&(_0x3318a6['isLeafNode']()||_0x3318a6['forEachChild'](R,(_0x2be977,_0x1c49f5)=>{_0x14720c['hasChild'](_0x2be977)||_0x2e3e91['trackChildChange'](Ot(_0x2be977,_0x1c49f5));}),_0x14720c['isLeafNode']()||_0x14720c['forEachChild'](R,(_0x13e466,_0x703bd5)=>{if(_0x3318a6['hasChild'](_0x13e466)){const _0x764fb2=_0x3318a6['getImmediateChild'](_0x13e466);_0x764fb2['equals'](_0x703bd5)||_0x2e3e91['trackChildChange'](Dt(_0x13e466,_0x703bd5,_0x764fb2));}else _0x2e3e91['trackChildChange'](et(_0x13e466,_0x703bd5));})),_0x14720c['withIndex'](this['index_']);}['updatePriority'](_0x3cabd5,_0x24dd66){return _0x3cabd5['isEmpty']()?g['EMPTY_NODE']:_0x3cabd5['updatePriority'](_0x24dd66);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Mt{constructor(_0x69a57e){this['indexedFilter_']=new Ji(_0x69a57e['getIndex']()),this['index_']=_0x69a57e['getIndex'](),this['startPost_']=Mt['getStartPost_'](_0x69a57e),this['endPost_']=Mt['getEndPost_'](_0x69a57e),this['startIsInclusive_']=!_0x69a57e['startAfterSet_'],this['endIsInclusive_']=!_0x69a57e['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x19d4b7){const _0x330575=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x19d4b7)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x19d4b7)<0x0,_0x584306=this['endIsInclusive_']?this['index_']['compare'](_0x19d4b7,this['getEndPost']())<=0x0:this['index_']['compare'](_0x19d4b7,this['getEndPost']())<0x0;return _0x330575&&_0x584306;}['updateChild'](_0x4739a7,_0x3288b7,_0x26ed82,_0x54d1e7,_0x10df21,_0x5ab742){return this['matches'](new E(_0x3288b7,_0x26ed82))||(_0x26ed82=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0x4739a7,_0x3288b7,_0x26ed82,_0x54d1e7,_0x10df21,_0x5ab742);}['updateFullNode'](_0x5a1684,_0x1a0517,_0x4ab1f6){_0x1a0517['isLeafNode']()&&(_0x1a0517=g['EMPTY_NODE']);let _0x4809f6=_0x1a0517['withIndex'](this['index_']);_0x4809f6=_0x4809f6['updatePriority'](g['EMPTY_NODE']);const _0xd8acae=this;return _0x1a0517['forEachChild'](R,(_0x26732f,_0x11fea3)=>{_0xd8acae['matches'](new E(_0x26732f,_0x11fea3))||(_0x4809f6=_0x4809f6['updateImmediateChild'](_0x26732f,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x5a1684,_0x4809f6,_0x4ab1f6);}['updatePriority'](_0xd527ad,_0x5c69b7){return _0xd527ad;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0xa48e6b){if(_0xa48e6b['hasStart']()){const _0xe1b3a6=_0xa48e6b['getIndexStartName']();return _0xa48e6b['getIndex']()['makePost'](_0xa48e6b['getIndexStartValue'](),_0xe1b3a6);}else return _0xa48e6b['getIndex']()['minPost']();}static['getEndPost_'](_0xa14755){if(_0xa14755['hasEnd']()){const _0x38d3b2=_0xa14755['getIndexEndName']();return _0xa14755['getIndex']()['makePost'](_0xa14755['getIndexEndValue'](),_0x38d3b2);}else return _0xa14755['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0x15b771){this['withinDirectionalStart']=_0x5ce375=>this['reverse_']?this['withinEndPost'](_0x5ce375):this['withinStartPost'](_0x5ce375),this['withinDirectionalEnd']=_0xc50f5d=>this['reverse_']?this['withinStartPost'](_0xc50f5d):this['withinEndPost'](_0xc50f5d),this['withinStartPost']=_0x1f6ad2=>{const _0x2de5ad=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x1f6ad2);return this['startIsInclusive_']?_0x2de5ad<=0x0:_0x2de5ad<0x0;},this['withinEndPost']=_0x36c35e=>{const _0x4617af=this['index_']['compare'](_0x36c35e,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x4617af<=0x0:_0x4617af<0x0;},this['rangedFilter_']=new Mt(_0x15b771),this['index_']=_0x15b771['getIndex'](),this['limit_']=_0x15b771['getLimit'](),this['reverse_']=!_0x15b771['isViewFromLeft'](),this['startIsInclusive_']=!_0x15b771['startAfterSet_'],this['endIsInclusive_']=!_0x15b771['endBeforeSet_'];}['updateChild'](_0x236f2a,_0x25a411,_0x4ea77b,_0x1826a7,_0x3f2f76,_0x1d3485){return this['rangedFilter_']['matches'](new E(_0x25a411,_0x4ea77b))||(_0x4ea77b=g['EMPTY_NODE']),_0x236f2a['getImmediateChild'](_0x25a411)['equals'](_0x4ea77b)?_0x236f2a:_0x236f2a['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x236f2a,_0x25a411,_0x4ea77b,_0x1826a7,_0x3f2f76,_0x1d3485):this['fullLimitUpdateChild_'](_0x236f2a,_0x25a411,_0x4ea77b,_0x3f2f76,_0x1d3485);}['updateFullNode'](_0xb3201c,_0x1d4bfd,_0x4a7196){let _0x5e170e;if(_0x1d4bfd['isLeafNode']()||_0x1d4bfd['isEmpty']())_0x5e170e=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x1d4bfd['numChildren']()&&_0x1d4bfd['isIndexed'](this['index_'])){_0x5e170e=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x147f4e;this['reverse_']?_0x147f4e=_0x1d4bfd['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x147f4e=_0x1d4bfd['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x5e9012=0x0;for(;_0x147f4e['hasNext']()&&_0x5e9012<this['limit_'];){const _0x1910dc=_0x147f4e['getNext']();if(this['withinDirectionalStart'](_0x1910dc)){if(this['withinDirectionalEnd'](_0x1910dc))_0x5e170e=_0x5e170e['updateImmediateChild'](_0x1910dc['name'],_0x1910dc['node']),_0x5e9012++;else break;}else continue;}}else{_0x5e170e=_0x1d4bfd['withIndex'](this['index_']),_0x5e170e=_0x5e170e['updatePriority'](g['EMPTY_NODE']);let _0x39fe79;this['reverse_']?_0x39fe79=_0x5e170e['getReverseIterator'](this['index_']):_0x39fe79=_0x5e170e['getIterator'](this['index_']);let _0x2ce933=0x0;for(;_0x39fe79['hasNext']();){const _0x50edd3=_0x39fe79['getNext']();_0x2ce933<this['limit_']&&this['withinDirectionalStart'](_0x50edd3)&&this['withinDirectionalEnd'](_0x50edd3)?_0x2ce933++:_0x5e170e=_0x5e170e['updateImmediateChild'](_0x50edd3['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0xb3201c,_0x5e170e,_0x4a7196);}['updatePriority'](_0x48e962,_0x379444){return _0x48e962;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x23fb11,_0x2c40fb,_0x383484,_0x162a93,_0x32dc48){let _0x298dd6;if(this['reverse_']){const _0x2c4077=this['index_']['getCompare']();_0x298dd6=(_0x5895be,_0x1d82d5)=>_0x2c4077(_0x1d82d5,_0x5895be);}else _0x298dd6=this['index_']['getCompare']();const _0x379d13=_0x23fb11;f(_0x379d13['numChildren']()===this['limit_'],'');const _0xd1dd39=new E(_0x2c40fb,_0x383484),_0xa1359=this['reverse_']?_0x379d13['getFirstChild'](this['index_']):_0x379d13['getLastChild'](this['index_']),_0x2088f0=this['rangedFilter_']['matches'](_0xd1dd39);if(_0x379d13['hasChild'](_0x2c40fb)){const _0x447fd2=_0x379d13['getImmediateChild'](_0x2c40fb);let _0x1e1b9a=_0x162a93['getChildAfterChild'](this['index_'],_0xa1359,this['reverse_']);for(;_0x1e1b9a!=null&&(_0x1e1b9a['name']===_0x2c40fb||_0x379d13['hasChild'](_0x1e1b9a['name']));)_0x1e1b9a=_0x162a93['getChildAfterChild'](this['index_'],_0x1e1b9a,this['reverse_']);const _0x4a8401=_0x1e1b9a==null?0x1:_0x298dd6(_0x1e1b9a,_0xd1dd39);if(_0x2088f0&&!_0x383484['isEmpty']()&&_0x4a8401>=0x0)return _0x32dc48!=null&&_0x32dc48['trackChildChange'](Dt(_0x2c40fb,_0x383484,_0x447fd2)),_0x379d13['updateImmediateChild'](_0x2c40fb,_0x383484);{_0x32dc48!=null&&_0x32dc48['trackChildChange'](Ot(_0x2c40fb,_0x447fd2));const _0x3b1147=_0x379d13['updateImmediateChild'](_0x2c40fb,g['EMPTY_NODE']);return _0x1e1b9a!=null&&this['rangedFilter_']['matches'](_0x1e1b9a)?(_0x32dc48!=null&&_0x32dc48['trackChildChange'](et(_0x1e1b9a['name'],_0x1e1b9a['node'])),_0x3b1147['updateImmediateChild'](_0x1e1b9a['name'],_0x1e1b9a['node'])):_0x3b1147;}}else return _0x383484['isEmpty']()?_0x23fb11:_0x2088f0&&_0x298dd6(_0xa1359,_0xd1dd39)>=0x0?(_0x32dc48!=null&&(_0x32dc48['trackChildChange'](Ot(_0xa1359['name'],_0xa1359['node'])),_0x32dc48['trackChildChange'](et(_0x2c40fb,_0x383484))),_0x379d13['updateImmediateChild'](_0x2c40fb,_0x383484)['updateImmediateChild'](_0xa1359['name'],g['EMPTY_NODE'])):_0x23fb11;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:Fe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x48c73d=new Xi();return _0x48c73d['limitSet_']=this['limitSet_'],_0x48c73d['limit_']=this['limit_'],_0x48c73d['startSet_']=this['startSet_'],_0x48c73d['startAfterSet_']=this['startAfterSet_'],_0x48c73d['indexStartValue_']=this['indexStartValue_'],_0x48c73d['startNameSet_']=this['startNameSet_'],_0x48c73d['indexStartName_']=this['indexStartName_'],_0x48c73d['endSet_']=this['endSet_'],_0x48c73d['endBeforeSet_']=this['endBeforeSet_'],_0x48c73d['indexEndValue_']=this['indexEndValue_'],_0x48c73d['endNameSet_']=this['endNameSet_'],_0x48c73d['indexEndName_']=this['indexEndName_'],_0x48c73d['index_']=this['index_'],_0x48c73d['viewFrom_']=this['viewFrom_'],_0x48c73d;}}function Kh(_0x54346c){return _0x54346c['loadsAllData']()?new Ji(_0x54346c['getIndex']()):_0x54346c['hasLimit']()?new jh(_0x54346c):new Mt(_0x54346c);}function Yh(_0x545520,_0x5c6eb8){const _0xe7237a=_0x545520['copy']();return _0xe7237a['limitSet_']=!0x0,_0xe7237a['limit_']=_0x5c6eb8,_0xe7237a['viewFrom_']='l',_0xe7237a;}function Qh(_0x5170eb,_0x34ce8e,_0x10d22a){const _0x2ffc95=_0x5170eb['copy']();return _0x2ffc95['startSet_']=!0x0,_0x34ce8e===void 0x0&&(_0x34ce8e=null),_0x2ffc95['indexStartValue_']=_0x34ce8e,_0x10d22a!=null?(_0x2ffc95['startNameSet_']=!0x0,_0x2ffc95['indexStartName_']=_0x10d22a):(_0x2ffc95['startNameSet_']=!0x1,_0x2ffc95['indexStartName_']=''),_0x2ffc95;}function Jh(_0x59cb83,_0x5d5463,_0xbc2068){const _0x5e705b=_0x59cb83['copy']();return _0x5e705b['endSet_']=!0x0,_0x5d5463===void 0x0&&(_0x5d5463=null),_0x5e705b['indexEndValue_']=_0x5d5463,_0xbc2068!==void 0x0?(_0x5e705b['endNameSet_']=!0x0,_0x5e705b['indexEndName_']=_0xbc2068):(_0x5e705b['endNameSet_']=!0x1,_0x5e705b['indexEndName_']=''),_0x5e705b;}function xo(_0x32e596,_0x5bd832){const _0x28c5e0=_0x32e596['copy']();return _0x28c5e0['index_']=_0x5bd832,_0x28c5e0;}function sr(_0x594094){const _0xaf6fe9={};if(_0x594094['isDefault']())return _0xaf6fe9;let _0x1d1fff;if(_0x594094['index_']===R?_0x1d1fff='$priority':_0x594094['index_']===Mo?_0x1d1fff='$value':_0x594094['index_']===ye?_0x1d1fff='$key':(f(_0x594094['index_']instanceof Qi,'Unrecognized\x20index\x20type!'),_0x1d1fff=_0x594094['index_']['toString']()),_0xaf6fe9['orderBy']=O(_0x1d1fff),_0x594094['startSet_']){const _0x1471f7=_0x594094['startAfterSet_']?'startAfter':'startAt';_0xaf6fe9[_0x1471f7]=O(_0x594094['indexStartValue_']),_0x594094['startNameSet_']&&(_0xaf6fe9[_0x1471f7]+=','+O(_0x594094['indexStartName_']));}if(_0x594094['endSet_']){const _0x3a8740=_0x594094['endBeforeSet_']?'endBefore':'endAt';_0xaf6fe9[_0x3a8740]=O(_0x594094['indexEndValue_']),_0x594094['endNameSet_']&&(_0xaf6fe9[_0x3a8740]+=','+O(_0x594094['indexEndName_']));}return _0x594094['limitSet_']&&(_0x594094['isViewFromLeft']()?_0xaf6fe9['limitToFirst']=_0x594094['limit_']:_0xaf6fe9['limitToLast']=_0x594094['limit_']),_0xaf6fe9;}function rr(_0x5c23d1){const _0x5843eb={};if(_0x5c23d1['startSet_']&&(_0x5843eb['sp']=_0x5c23d1['indexStartValue_'],_0x5c23d1['startNameSet_']&&(_0x5843eb['sn']=_0x5c23d1['indexStartName_']),_0x5843eb['sin']=!_0x5c23d1['startAfterSet_']),_0x5c23d1['endSet_']&&(_0x5843eb['ep']=_0x5c23d1['indexEndValue_'],_0x5c23d1['endNameSet_']&&(_0x5843eb['en']=_0x5c23d1['indexEndName_']),_0x5843eb['ein']=!_0x5c23d1['endBeforeSet_']),_0x5c23d1['limitSet_']){_0x5843eb['l']=_0x5c23d1['limit_'];let _0x424684=_0x5c23d1['viewFrom_'];_0x424684===''&&(_0x5c23d1['isViewFromLeft']()?_0x424684='l':_0x424684='r'),_0x5843eb['vf']=_0x424684;}return _0x5c23d1['index_']!==R&&(_0x5843eb['i']=_0x5c23d1['index_']['toString']()),_0x5843eb;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pn extends So{['reportStats'](_0x68e88d){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x3d51e6,_0x5be182){return _0x5be182!==void 0x0?'tag$'+_0x5be182:(f(_0x3d51e6['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x3d51e6['_path']['toString']());}constructor(_0x3ebc08,_0x166c01,_0xb17ff3,_0x33ea08){super(),this['repoInfo_']=_0x3ebc08,this['onDataUpdate_']=_0x166c01,this['authTokenProvider_']=_0xb17ff3,this['appCheckTokenProvider_']=_0x33ea08,this['log_']=Ht('p:rest:'),this['listens_']={};}['listen'](_0x776d0e,_0x503a05,_0x4326fb,_0x40905e){const _0x380842=_0x776d0e['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x380842+'\x20'+_0x776d0e['_queryIdentifier']);const _0x2c73cd=pn['getListenId_'](_0x776d0e,_0x4326fb),_0x3ea193={};this['listens_'][_0x2c73cd]=_0x3ea193;const _0x50be81=sr(_0x776d0e['_queryParams']);this['restRequest_'](_0x380842+'.json',_0x50be81,(_0x18f35a,_0xf67ea8)=>{let _0x2e26fb=_0xf67ea8;if(_0x18f35a===0x194&&(_0x2e26fb=null,_0x18f35a=null),_0x18f35a===null&&this['onDataUpdate_'](_0x380842,_0x2e26fb,!0x1,_0x4326fb),De(this['listens_'],_0x2c73cd)===_0x3ea193){let _0x3eadfe;_0x18f35a?_0x18f35a===0x191?_0x3eadfe='permission_denied':_0x3eadfe='rest_error:'+_0x18f35a:_0x3eadfe='ok',_0x40905e(_0x3eadfe,null);}});}['unlisten'](_0x166596,_0x505526){const _0x167dcb=pn['getListenId_'](_0x166596,_0x505526);delete this['listens_'][_0x167dcb];}['get'](_0x47bbb5){const _0x3714c6=sr(_0x47bbb5['_queryParams']),_0x471806=_0x47bbb5['_path']['toString'](),_0x12a165=new ot();return this['restRequest_'](_0x471806+'.json',_0x3714c6,(_0x4ea4fd,_0x5a2250)=>{let _0x56aee6=_0x5a2250;_0x4ea4fd===0x194&&(_0x56aee6=null,_0x4ea4fd=null),_0x4ea4fd===null?(this['onDataUpdate_'](_0x471806,_0x56aee6,!0x1,null),_0x12a165['resolve'](_0x56aee6)):_0x12a165['reject'](new Error(_0x56aee6));}),_0x12a165['promise'];}['refreshAuthToken'](_0x36ef05){}['restRequest_'](_0x54fd17,_0x55540c={},_0x4c12fe){return _0x55540c['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x4bf497,_0x3898ec])=>{_0x4bf497&&_0x4bf497['accessToken']&&(_0x55540c['auth']=_0x4bf497['accessToken']),_0x3898ec&&_0x3898ec['token']&&(_0x55540c['ac']=_0x3898ec['token']);const _0x14bec9=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x54fd17+'?ns='+this['repoInfo_']['namespace']+ct(_0x55540c);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0x14bec9);const _0x3dcfa6=new XMLHttpRequest();_0x3dcfa6['onreadystatechange']=()=>{if(_0x4c12fe&&_0x3dcfa6['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0x14bec9+'\x20received.\x20status:',_0x3dcfa6['status'],'response:',_0x3dcfa6['responseText']);let _0x38223b=null;if(_0x3dcfa6['status']>=0xc8&&_0x3dcfa6['status']<0x12c){try{_0x38223b=At(_0x3dcfa6['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0x14bec9+':\x20'+_0x3dcfa6['responseText']);}_0x4c12fe(null,_0x38223b);}else _0x3dcfa6['status']!==0x191&&_0x3dcfa6['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0x14bec9+'\x20Status:\x20'+_0x3dcfa6['status']),_0x4c12fe(_0x3dcfa6['status']);_0x4c12fe=null;}},_0x3dcfa6['open']('GET',_0x14bec9,!0x0),_0x3dcfa6['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x3c65bb){return this['rootNode_']['getChild'](_0x3c65bb);}['updateSnapshot'](_0x23837d,_0x4abeaa){this['rootNode_']=this['rootNode_']['updateChild'](_0x23837d,_0x4abeaa);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function _n(){return{'value':null,'children':new Map()};}function Fo(_0x52ab39,_0x1d70b7,_0x370e76){if(v(_0x1d70b7))_0x52ab39['value']=_0x370e76,_0x52ab39['children']['clear']();else{if(_0x52ab39['value']!==null)_0x52ab39['value']=_0x52ab39['value']['updateChild'](_0x1d70b7,_0x370e76);else{const _0x5430e0=y(_0x1d70b7);_0x52ab39['children']['has'](_0x5430e0)||_0x52ab39['children']['set'](_0x5430e0,_n());const _0x3475eb=_0x52ab39['children']['get'](_0x5430e0);_0x1d70b7=b(_0x1d70b7),Fo(_0x3475eb,_0x1d70b7,_0x370e76);}}}function Ii(_0x3c2f48,_0x54de07,_0x1f6888){_0x3c2f48['value']!==null?_0x1f6888(_0x54de07,_0x3c2f48['value']):Zh(_0x3c2f48,(_0x5207f3,_0x1a1025)=>{const _0x36acf3=new C(_0x54de07['toString']()+'/'+_0x5207f3);Ii(_0x1a1025,_0x36acf3,_0x1f6888);});}function Zh(_0x4c708e,_0xf95696){_0x4c708e['children']['forEach']((_0x451c81,_0x43bff3)=>{_0xf95696(_0x43bff3,_0x451c81);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x512c6a){this['collection_']=_0x512c6a,this['last_']=null;}['get'](){const _0x17e5b3=this['collection_']['get'](),_0x231c5a={..._0x17e5b3};return this['last_']&&x(this['last_'],(_0x52b2e8,_0x45e954)=>{_0x231c5a[_0x52b2e8]=_0x231c5a[_0x52b2e8]-_0x45e954;}),this['last_']=_0x17e5b3,_0x231c5a;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const or=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x3b6c6c,_0x31eede){this['server_']=_0x31eede,this['statsToReport_']={},this['statsListener_']=new eu(_0x3b6c6c);const _0x3565e2=or+(tu-or)*Math['random']();Ct(this['reportStats_']['bind'](this),Math['floor'](_0x3565e2));}['reportStats_'](){const _0x23f1b0=this['statsListener_']['get'](),_0x4952c4={};let _0x464072=!0x1;x(_0x23f1b0,(_0x32e1db,_0xb19d65)=>{_0xb19d65>0x0&&J(this['statsToReport_'],_0x32e1db)&&(_0x4952c4[_0x32e1db]=_0xb19d65,_0x464072=!0x0);}),_0x464072&&this['server_']['reportStats'](_0x4952c4),Ct(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var j;(function(_0x2964d0){_0x2964d0[_0x2964d0['OVERWRITE']=0x0]='OVERWRITE',_0x2964d0[_0x2964d0['MERGE']=0x1]='MERGE',_0x2964d0[_0x2964d0['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x2964d0[_0x2964d0['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(j||(j={})));function Zi(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function es(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ts(_0x161547){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x161547,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gn{constructor(_0xf3c22c,_0x2b666a,_0xa2942d){this['path']=_0xf3c22c,this['affectedTree']=_0x2b666a,this['revert']=_0xa2942d,this['type']=j['ACK_USER_WRITE'],this['source']=Zi();}['operationForChild'](_0x5574d2){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0x16224c=this['affectedTree']['subtree'](new C(_0x5574d2));return new gn(w(),_0x16224c,this['revert']);}}else return f(y(this['path'])===_0x5574d2,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new gn(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Lt{constructor(_0x32cf73,_0xe5811d){this['source']=_0x32cf73,this['path']=_0xe5811d,this['type']=j['LISTEN_COMPLETE'];}['operationForChild'](_0x4405fd){return v(this['path'])?new Lt(this['source'],w()):new Lt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ue{constructor(_0x2dc5b3,_0x3541f6,_0x2798e4){this['source']=_0x2dc5b3,this['path']=_0x3541f6,this['snap']=_0x2798e4,this['type']=j['OVERWRITE'];}['operationForChild'](_0x95d646){return v(this['path'])?new Ue(this['source'],w(),this['snap']['getImmediateChild'](_0x95d646)):new Ue(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tt{constructor(_0x1aff3e,_0x5398c8,_0x337b15){this['source']=_0x1aff3e,this['path']=_0x5398c8,this['children']=_0x337b15,this['type']=j['MERGE'];}['operationForChild'](_0x18a021){if(v(this['path'])){const _0x416293=this['children']['subtree'](new C(_0x18a021));return _0x416293['isEmpty']()?null:_0x416293['value']?new Ue(this['source'],w(),_0x416293['value']):new tt(this['source'],w(),_0x416293);}else return f(y(this['path'])===_0x18a021,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new tt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x44d3a2,_0xa51ad9,_0x205dc8){this['node_']=_0x44d3a2,this['fullyInitialized_']=_0xa51ad9,this['filtered_']=_0x205dc8;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x475630){if(v(_0x475630))return this['isFullyInitialized']()&&!this['filtered_'];const _0x4dbc26=y(_0x475630);return this['isCompleteForChild'](_0x4dbc26);}['isCompleteForChild'](_0x588448){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x588448);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x506ba5){this['query_']=_0x506ba5,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x7f381d,_0x2dff2e,_0x583e47,_0x23c73b){const _0x1b5594=[],_0x5eac9a=[];return _0x2dff2e['forEach'](_0x5996e1=>{_0x5996e1['type']==='child_changed'&&_0x7f381d['index_']['indexedValueChanged'](_0x5996e1['oldSnap'],_0x5996e1['snapshotNode'])&&_0x5eac9a['push'](zh(_0x5996e1['childName'],_0x5996e1['snapshotNode']));}),yt(_0x7f381d,_0x1b5594,'child_removed',_0x2dff2e,_0x23c73b,_0x583e47),yt(_0x7f381d,_0x1b5594,'child_added',_0x2dff2e,_0x23c73b,_0x583e47),yt(_0x7f381d,_0x1b5594,'child_moved',_0x5eac9a,_0x23c73b,_0x583e47),yt(_0x7f381d,_0x1b5594,'child_changed',_0x2dff2e,_0x23c73b,_0x583e47),yt(_0x7f381d,_0x1b5594,'value',_0x2dff2e,_0x23c73b,_0x583e47),_0x1b5594;}function yt(_0x12c86b,_0xd67911,_0x53738c,_0x44e091,_0x5f2602,_0x1dda99){const _0x25143a=_0x44e091['filter'](_0x56573b=>_0x56573b['type']===_0x53738c);_0x25143a['sort']((_0x1928e7,_0x76e1a0)=>au(_0x12c86b,_0x1928e7,_0x76e1a0)),_0x25143a['forEach'](_0x148f15=>{const _0x3bf257=ou(_0x12c86b,_0x148f15,_0x1dda99);_0x5f2602['forEach'](_0x125917=>{_0x125917['respondsTo'](_0x148f15['type'])&&_0xd67911['push'](_0x125917['createEvent'](_0x3bf257,_0x12c86b['query_']));});});}function ou(_0x113f34,_0x160dd9,_0xa25e55){return _0x160dd9['type']==='value'||_0x160dd9['type']==='child_removed'||(_0x160dd9['prevName']=_0xa25e55['getPredecessorChildName'](_0x160dd9['childName'],_0x160dd9['snapshotNode'],_0x113f34['index_'])),_0x160dd9;}function au(_0x3c9531,_0x84a465,_0xffe792){if(_0x84a465['childName']==null||_0xffe792['childName']==null)throw rt('Should\x20only\x20compare\x20child_\x20events.');const _0x96c014=new E(_0x84a465['childName'],_0x84a465['snapshotNode']),_0x575707=new E(_0xffe792['childName'],_0xffe792['snapshotNode']);return _0x3c9531['index_']['compare'](_0x96c014,_0x575707);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x1107d2,_0x27f3cc){return{'eventCache':_0x1107d2,'serverCache':_0x27f3cc};}function Tt(_0x245733,_0x4c2d1e,_0x1d8fba,_0x169653){return Mn(new Ce(_0x4c2d1e,_0x1d8fba,_0x169653),_0x245733['serverCache']);}function Uo(_0x2bc80e,_0x5722f7,_0x341768,_0x5d4471){return Mn(_0x2bc80e['eventCache'],new Ce(_0x5722f7,_0x341768,_0x5d4471));}function mn(_0x8376bd){return _0x8376bd['eventCache']['isFullyInitialized']()?_0x8376bd['eventCache']['getNode']():null;}function We(_0xbd19f6){return _0xbd19f6['serverCache']['isFullyInitialized']()?_0xbd19f6['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let oi;const cu=()=>(oi||(oi=new B(ql)),oi);class S{static['fromObject'](_0x262100){let _0x49ca6b=new S(null);return x(_0x262100,(_0x38b123,_0x2e7144)=>{_0x49ca6b=_0x49ca6b['set'](new C(_0x38b123),_0x2e7144);}),_0x49ca6b;}constructor(_0x59aba2,_0x106e19=cu()){this['value']=_0x59aba2,this['children']=_0x106e19;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x4e357c,_0x302bba){if(this['value']!=null&&_0x302bba(this['value']))return{'path':w(),'value':this['value']};if(v(_0x4e357c))return null;{const _0x76149e=y(_0x4e357c),_0x49434b=this['children']['get'](_0x76149e);if(_0x49434b!==null){const _0x246bf2=_0x49434b['findRootMostMatchingPathAndValue'](b(_0x4e357c),_0x302bba);return _0x246bf2!=null?{'path':k(new C(_0x76149e),_0x246bf2['path']),'value':_0x246bf2['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x16b2f6){return this['findRootMostMatchingPathAndValue'](_0x16b2f6,()=>!0x0);}['subtree'](_0xe16769){if(v(_0xe16769))return this;{const _0x382813=y(_0xe16769),_0x34db3b=this['children']['get'](_0x382813);return _0x34db3b!==null?_0x34db3b['subtree'](b(_0xe16769)):new S(null);}}['set'](_0x138d90,_0x369f90){if(v(_0x138d90))return new S(_0x369f90,this['children']);{const _0x5721ba=y(_0x138d90),_0x1d7851=(this['children']['get'](_0x5721ba)||new S(null))['set'](b(_0x138d90),_0x369f90),_0x2a8fc4=this['children']['insert'](_0x5721ba,_0x1d7851);return new S(this['value'],_0x2a8fc4);}}['remove'](_0x42276f){if(v(_0x42276f))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x10cf86=y(_0x42276f),_0x1b747b=this['children']['get'](_0x10cf86);if(_0x1b747b){const _0x2b9e9f=_0x1b747b['remove'](b(_0x42276f));let _0x122929;return _0x2b9e9f['isEmpty']()?_0x122929=this['children']['remove'](_0x10cf86):_0x122929=this['children']['insert'](_0x10cf86,_0x2b9e9f),this['value']===null&&_0x122929['isEmpty']()?new S(null):new S(this['value'],_0x122929);}else return this;}}['get'](_0x4288c8){if(v(_0x4288c8))return this['value'];{const _0x1df3f7=y(_0x4288c8),_0x16a2a3=this['children']['get'](_0x1df3f7);return _0x16a2a3?_0x16a2a3['get'](b(_0x4288c8)):null;}}['setTree'](_0x20b9ae,_0x4e429c){if(v(_0x20b9ae))return _0x4e429c;{const _0x963b90=y(_0x20b9ae),_0x3fd714=(this['children']['get'](_0x963b90)||new S(null))['setTree'](b(_0x20b9ae),_0x4e429c);let _0x470348;return _0x3fd714['isEmpty']()?_0x470348=this['children']['remove'](_0x963b90):_0x470348=this['children']['insert'](_0x963b90,_0x3fd714),new S(this['value'],_0x470348);}}['fold'](_0xf429cd){return this['fold_'](w(),_0xf429cd);}['fold_'](_0xd25327,_0x5c3260){const _0x18fea7={};return this['children']['inorderTraversal']((_0x1c2f46,_0x158c32)=>{_0x18fea7[_0x1c2f46]=_0x158c32['fold_'](k(_0xd25327,_0x1c2f46),_0x5c3260);}),_0x5c3260(_0xd25327,this['value'],_0x18fea7);}['findOnPath'](_0x436c37,_0x4186c2){return this['findOnPath_'](_0x436c37,w(),_0x4186c2);}['findOnPath_'](_0x19f0b4,_0x5428bc,_0x3ebe29){const _0x27f66a=this['value']?_0x3ebe29(_0x5428bc,this['value']):!0x1;if(_0x27f66a)return _0x27f66a;if(v(_0x19f0b4))return null;{const _0x3976b8=y(_0x19f0b4),_0x37647=this['children']['get'](_0x3976b8);return _0x37647?_0x37647['findOnPath_'](b(_0x19f0b4),k(_0x5428bc,_0x3976b8),_0x3ebe29):null;}}['foreachOnPath'](_0x10fb7f,_0x5250f3){return this['foreachOnPath_'](_0x10fb7f,w(),_0x5250f3);}['foreachOnPath_'](_0x59695b,_0x2f622c,_0x5184f6){if(v(_0x59695b))return this;{this['value']&&_0x5184f6(_0x2f622c,this['value']);const _0x275ba1=y(_0x59695b),_0x2b9b19=this['children']['get'](_0x275ba1);return _0x2b9b19?_0x2b9b19['foreachOnPath_'](b(_0x59695b),k(_0x2f622c,_0x275ba1),_0x5184f6):new S(null);}}['foreach'](_0x4f1557){this['foreach_'](w(),_0x4f1557);}['foreach_'](_0x563036,_0x1ed9be){this['children']['inorderTraversal']((_0x102c4c,_0x552b07)=>{_0x552b07['foreach_'](k(_0x563036,_0x102c4c),_0x1ed9be);}),this['value']&&_0x1ed9be(_0x563036,this['value']);}['foreachChild'](_0x3b7441){this['children']['inorderTraversal']((_0x19ad63,_0x512741)=>{_0x512741['value']&&_0x3b7441(_0x19ad63,_0x512741['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Y{constructor(_0x3551e5){this['writeTree_']=_0x3551e5;}static['empty'](){return new Y(new S(null));}}function St(_0x3b23f3,_0x4b3632,_0x46d577){if(v(_0x4b3632))return new Y(new S(_0x46d577));{const _0x23643c=_0x3b23f3['writeTree_']['findRootMostValueAndPath'](_0x4b3632);if(_0x23643c!=null){const _0x526317=_0x23643c['path'];let _0xd6672e=_0x23643c['value'];const _0x4163e2=F(_0x526317,_0x4b3632);return _0xd6672e=_0xd6672e['updateChild'](_0x4163e2,_0x46d577),new Y(_0x3b23f3['writeTree_']['set'](_0x526317,_0xd6672e));}else{const _0x1e4ff8=new S(_0x46d577),_0x5666cd=_0x3b23f3['writeTree_']['setTree'](_0x4b3632,_0x1e4ff8);return new Y(_0x5666cd);}}}function wi(_0x2fc3ef,_0xd617ed,_0x2e3ff7){let _0x583438=_0x2fc3ef;return x(_0x2e3ff7,(_0x226914,_0x1a915e)=>{_0x583438=St(_0x583438,k(_0xd617ed,_0x226914),_0x1a915e);}),_0x583438;}function ar(_0x4161e0,_0x345c95){if(v(_0x345c95))return Y['empty']();{const _0x9f603c=_0x4161e0['writeTree_']['setTree'](_0x345c95,new S(null));return new Y(_0x9f603c);}}function Ci(_0x31487d,_0x499e5d){return $e(_0x31487d,_0x499e5d)!=null;}function $e(_0x308062,_0x18941b){const _0x4088eb=_0x308062['writeTree_']['findRootMostValueAndPath'](_0x18941b);return _0x4088eb!=null?_0x308062['writeTree_']['get'](_0x4088eb['path'])['getChild'](F(_0x4088eb['path'],_0x18941b)):null;}function cr(_0x19cd84){const _0x5ef347=[],_0x451157=_0x19cd84['writeTree_']['value'];return _0x451157!=null?_0x451157['isLeafNode']()||_0x451157['forEachChild'](R,(_0xefc4fe,_0x4f21cf)=>{_0x5ef347['push'](new E(_0xefc4fe,_0x4f21cf));}):_0x19cd84['writeTree_']['children']['inorderTraversal']((_0x55cdfe,_0xff8a9a)=>{_0xff8a9a['value']!=null&&_0x5ef347['push'](new E(_0x55cdfe,_0xff8a9a['value']));}),_0x5ef347;}function ve(_0x1a5755,_0x2a8c6a){if(v(_0x2a8c6a))return _0x1a5755;{const _0x272674=$e(_0x1a5755,_0x2a8c6a);return _0x272674!=null?new Y(new S(_0x272674)):new Y(_0x1a5755['writeTree_']['subtree'](_0x2a8c6a));}}function Ti(_0x58ac50){return _0x58ac50['writeTree_']['isEmpty']();}function nt(_0x21ed53,_0x53a8d7){return Wo(w(),_0x21ed53['writeTree_'],_0x53a8d7);}function Wo(_0x16b6eb,_0x45505a,_0xbaae08){if(_0x45505a['value']!=null)return _0xbaae08['updateChild'](_0x16b6eb,_0x45505a['value']);{let _0x4e3af4=null;return _0x45505a['children']['inorderTraversal']((_0x36eb5b,_0x102a51)=>{_0x36eb5b==='.priority'?(f(_0x102a51['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x4e3af4=_0x102a51['value']):_0xbaae08=Wo(k(_0x16b6eb,_0x36eb5b),_0x102a51,_0xbaae08);}),!_0xbaae08['getChild'](_0x16b6eb)['isEmpty']()&&_0x4e3af4!==null&&(_0xbaae08=_0xbaae08['updateChild'](k(_0x16b6eb,'.priority'),_0x4e3af4)),_0xbaae08;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ln(_0x4f936b,_0x5df6ee){return $o(_0x5df6ee,_0x4f936b);}function lu(_0x8f3bf1,_0x5d84d8,_0x18f238,_0x76bad0,_0x3abf40){f(_0x76bad0>_0x8f3bf1['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x3abf40===void 0x0&&(_0x3abf40=!0x0),_0x8f3bf1['allWrites']['push']({'path':_0x5d84d8,'snap':_0x18f238,'writeId':_0x76bad0,'visible':_0x3abf40}),_0x3abf40&&(_0x8f3bf1['visibleWrites']=St(_0x8f3bf1['visibleWrites'],_0x5d84d8,_0x18f238)),_0x8f3bf1['lastWriteId']=_0x76bad0;}function hu(_0x10cadf,_0x51b7ea,_0x779c0,_0x2cd784){f(_0x2cd784>_0x10cadf['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x10cadf['allWrites']['push']({'path':_0x51b7ea,'children':_0x779c0,'writeId':_0x2cd784,'visible':!0x0}),_0x10cadf['visibleWrites']=wi(_0x10cadf['visibleWrites'],_0x51b7ea,_0x779c0),_0x10cadf['lastWriteId']=_0x2cd784;}function uu(_0x35a76d,_0x249c5e){for(let _0xf987e3=0x0;_0xf987e3<_0x35a76d['allWrites']['length'];_0xf987e3++){const _0x11b81e=_0x35a76d['allWrites'][_0xf987e3];if(_0x11b81e['writeId']===_0x249c5e)return _0x11b81e;}return null;}function du(_0xda5107,_0x2baf7f){const _0x5a5547=_0xda5107['allWrites']['findIndex'](_0x3ecc58=>_0x3ecc58['writeId']===_0x2baf7f);f(_0x5a5547>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x50029f=_0xda5107['allWrites'][_0x5a5547];_0xda5107['allWrites']['splice'](_0x5a5547,0x1);let _0x34243c=_0x50029f['visible'],_0x31b62d=!0x1,_0x1be3e9=_0xda5107['allWrites']['length']-0x1;for(;_0x34243c&&_0x1be3e9>=0x0;){const _0xd0f7a3=_0xda5107['allWrites'][_0x1be3e9];_0xd0f7a3['visible']&&(_0x1be3e9>=_0x5a5547&&fu(_0xd0f7a3,_0x50029f['path'])?_0x34243c=!0x1:G(_0x50029f['path'],_0xd0f7a3['path'])&&(_0x31b62d=!0x0)),_0x1be3e9--;}if(_0x34243c){if(_0x31b62d)return pu(_0xda5107),!0x0;if(_0x50029f['snap'])_0xda5107['visibleWrites']=ar(_0xda5107['visibleWrites'],_0x50029f['path']);else{const _0x234e5a=_0x50029f['children'];x(_0x234e5a,_0x95164b=>{_0xda5107['visibleWrites']=ar(_0xda5107['visibleWrites'],k(_0x50029f['path'],_0x95164b));});}return!0x0;}else return!0x1;}function fu(_0x1c1654,_0xf91305){if(_0x1c1654['snap'])return G(_0x1c1654['path'],_0xf91305);for(const _0x563232 in _0x1c1654['children'])if(_0x1c1654['children']['hasOwnProperty'](_0x563232)&&G(k(_0x1c1654['path'],_0x563232),_0xf91305))return!0x0;return!0x1;}function pu(_0x42d650){_0x42d650['visibleWrites']=Bo(_0x42d650['allWrites'],_u,w()),_0x42d650['allWrites']['length']>0x0?_0x42d650['lastWriteId']=_0x42d650['allWrites'][_0x42d650['allWrites']['length']-0x1]['writeId']:_0x42d650['lastWriteId']=-0x1;}function _u(_0x4e34ca){return _0x4e34ca['visible'];}function Bo(_0x5f2ab6,_0x5ca084,_0x561b49){let _0xf3a8d8=Y['empty']();for(let _0x5d3e3c=0x0;_0x5d3e3c<_0x5f2ab6['length'];++_0x5d3e3c){const _0x4d60b5=_0x5f2ab6[_0x5d3e3c];if(_0x5ca084(_0x4d60b5)){const _0x305afb=_0x4d60b5['path'];let _0x475171;if(_0x4d60b5['snap'])G(_0x561b49,_0x305afb)?(_0x475171=F(_0x561b49,_0x305afb),_0xf3a8d8=St(_0xf3a8d8,_0x475171,_0x4d60b5['snap'])):G(_0x305afb,_0x561b49)&&(_0x475171=F(_0x305afb,_0x561b49),_0xf3a8d8=St(_0xf3a8d8,w(),_0x4d60b5['snap']['getChild'](_0x475171)));else{if(_0x4d60b5['children']){if(G(_0x561b49,_0x305afb))_0x475171=F(_0x561b49,_0x305afb),_0xf3a8d8=wi(_0xf3a8d8,_0x475171,_0x4d60b5['children']);else{if(G(_0x305afb,_0x561b49)){if(_0x475171=F(_0x305afb,_0x561b49),v(_0x475171))_0xf3a8d8=wi(_0xf3a8d8,w(),_0x4d60b5['children']);else{const _0x45e9d8=De(_0x4d60b5['children'],y(_0x475171));if(_0x45e9d8){const _0x45e7dd=_0x45e9d8['getChild'](b(_0x475171));_0xf3a8d8=St(_0xf3a8d8,w(),_0x45e7dd);}}}}}else throw rt('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0xf3a8d8;}function Vo(_0x2cf463,_0x125d98,_0x355384,_0x11ddc4,_0x4232e4){if(!_0x11ddc4&&!_0x4232e4){const _0x3d3b95=$e(_0x2cf463['visibleWrites'],_0x125d98);if(_0x3d3b95!=null)return _0x3d3b95;{const _0x258ec4=ve(_0x2cf463['visibleWrites'],_0x125d98);if(Ti(_0x258ec4))return _0x355384;if(_0x355384==null&&!Ci(_0x258ec4,w()))return null;{const _0xcb280=_0x355384||g['EMPTY_NODE'];return nt(_0x258ec4,_0xcb280);}}}else{const _0x2ea600=ve(_0x2cf463['visibleWrites'],_0x125d98);if(!_0x4232e4&&Ti(_0x2ea600))return _0x355384;if(!_0x4232e4&&_0x355384==null&&!Ci(_0x2ea600,w()))return null;{const _0x417f16=function(_0x9af6ad){return(_0x9af6ad['visible']||_0x4232e4)&&(!_0x11ddc4||!~_0x11ddc4['indexOf'](_0x9af6ad['writeId']))&&(G(_0x9af6ad['path'],_0x125d98)||G(_0x125d98,_0x9af6ad['path']));},_0x127bd9=Bo(_0x2cf463['allWrites'],_0x417f16,_0x125d98),_0x4746ff=_0x355384||g['EMPTY_NODE'];return nt(_0x127bd9,_0x4746ff);}}}function gu(_0x1188f2,_0x285e97,_0x123b40){let _0x7dbc0a=g['EMPTY_NODE'];const _0x58275b=$e(_0x1188f2['visibleWrites'],_0x285e97);if(_0x58275b)return _0x58275b['isLeafNode']()||_0x58275b['forEachChild'](R,(_0x33893f,_0x524b71)=>{_0x7dbc0a=_0x7dbc0a['updateImmediateChild'](_0x33893f,_0x524b71);}),_0x7dbc0a;if(_0x123b40){const _0xc9b60a=ve(_0x1188f2['visibleWrites'],_0x285e97);return _0x123b40['forEachChild'](R,(_0x3857f,_0x3af2b7)=>{const _0x45a035=nt(ve(_0xc9b60a,new C(_0x3857f)),_0x3af2b7);_0x7dbc0a=_0x7dbc0a['updateImmediateChild'](_0x3857f,_0x45a035);}),cr(_0xc9b60a)['forEach'](_0x5aade8=>{_0x7dbc0a=_0x7dbc0a['updateImmediateChild'](_0x5aade8['name'],_0x5aade8['node']);}),_0x7dbc0a;}else{const _0x8cca9d=ve(_0x1188f2['visibleWrites'],_0x285e97);return cr(_0x8cca9d)['forEach'](_0x5837e8=>{_0x7dbc0a=_0x7dbc0a['updateImmediateChild'](_0x5837e8['name'],_0x5837e8['node']);}),_0x7dbc0a;}}function mu(_0x361daf,_0x16e742,_0x1e7908,_0x5ee776,_0x5acb27){f(_0x5ee776||_0x5acb27,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x52b0c7=k(_0x16e742,_0x1e7908);if(Ci(_0x361daf['visibleWrites'],_0x52b0c7))return null;{const _0x38177c=ve(_0x361daf['visibleWrites'],_0x52b0c7);return Ti(_0x38177c)?_0x5acb27['getChild'](_0x1e7908):nt(_0x38177c,_0x5acb27['getChild'](_0x1e7908));}}function yu(_0x23ffb5,_0x23d413,_0x177462,_0x12467b){const _0x57ffa1=k(_0x23d413,_0x177462),_0x5ccc82=$e(_0x23ffb5['visibleWrites'],_0x57ffa1);if(_0x5ccc82!=null)return _0x5ccc82;if(_0x12467b['isCompleteForChild'](_0x177462)){const _0x4b69b7=ve(_0x23ffb5['visibleWrites'],_0x57ffa1);return nt(_0x4b69b7,_0x12467b['getNode']()['getImmediateChild'](_0x177462));}else return null;}function vu(_0x3276ee,_0x3c9ef8){return $e(_0x3276ee['visibleWrites'],_0x3c9ef8);}function Eu(_0x44a717,_0x146965,_0x442565,_0x505fa2,_0x4aef4e,_0x238014,_0x186363){let _0x42928d;const _0x419726=ve(_0x44a717['visibleWrites'],_0x146965),_0x686ebf=$e(_0x419726,w());if(_0x686ebf!=null)_0x42928d=_0x686ebf;else{if(_0x442565!=null)_0x42928d=nt(_0x419726,_0x442565);else return[];}if(_0x42928d=_0x42928d['withIndex'](_0x186363),!_0x42928d['isEmpty']()&&!_0x42928d['isLeafNode']()){const _0x1a008c=[],_0x2b88e6=_0x186363['getCompare'](),_0x386e29=_0x238014?_0x42928d['getReverseIteratorFrom'](_0x505fa2,_0x186363):_0x42928d['getIteratorFrom'](_0x505fa2,_0x186363);let _0xed5307=_0x386e29['getNext']();for(;_0xed5307&&_0x1a008c['length']<_0x4aef4e;)_0x2b88e6(_0xed5307,_0x505fa2)!==0x0&&_0x1a008c['push'](_0xed5307),_0xed5307=_0x386e29['getNext']();return _0x1a008c;}else return[];}function Iu(){return{'visibleWrites':Y['empty'](),'allWrites':[],'lastWriteId':-0x1};}function yn(_0x318597,_0x48fa70,_0x82dae6,_0x1fd51f){return Vo(_0x318597['writeTree'],_0x318597['treePath'],_0x48fa70,_0x82dae6,_0x1fd51f);}function ns(_0x3e8d78,_0x2cba7b){return gu(_0x3e8d78['writeTree'],_0x3e8d78['treePath'],_0x2cba7b);}function lr(_0x5eb28c,_0x29c14f,_0x26cbb2,_0x503f9f){return mu(_0x5eb28c['writeTree'],_0x5eb28c['treePath'],_0x29c14f,_0x26cbb2,_0x503f9f);}function vn(_0x139f95,_0x3a3d08){return vu(_0x139f95['writeTree'],k(_0x139f95['treePath'],_0x3a3d08));}function wu(_0x252b05,_0x5586a9,_0x4c38a6,_0x3d447a,_0x4fa241,_0x59784f){return Eu(_0x252b05['writeTree'],_0x252b05['treePath'],_0x5586a9,_0x4c38a6,_0x3d447a,_0x4fa241,_0x59784f);}function is(_0x1c13df,_0x1ec0ad,_0x40da1f){return yu(_0x1c13df['writeTree'],_0x1c13df['treePath'],_0x1ec0ad,_0x40da1f);}function Ho(_0x4d3161,_0x4d3aef){return $o(k(_0x4d3161['treePath'],_0x4d3aef),_0x4d3161['writeTree']);}function $o(_0x5eee66,_0x305262){return{'treePath':_0x5eee66,'writeTree':_0x305262};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x73dc1a){const _0x2bd38f=_0x73dc1a['type'],_0x3de92d=_0x73dc1a['childName'];f(_0x2bd38f==='child_added'||_0x2bd38f==='child_changed'||_0x2bd38f==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0x3de92d!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x43563a=this['changeMap']['get'](_0x3de92d);if(_0x43563a){const _0x1e933f=_0x43563a['type'];if(_0x2bd38f==='child_added'&&_0x1e933f==='child_removed')this['changeMap']['set'](_0x3de92d,Dt(_0x3de92d,_0x73dc1a['snapshotNode'],_0x43563a['snapshotNode']));else{if(_0x2bd38f==='child_removed'&&_0x1e933f==='child_added')this['changeMap']['delete'](_0x3de92d);else{if(_0x2bd38f==='child_removed'&&_0x1e933f==='child_changed')this['changeMap']['set'](_0x3de92d,Ot(_0x3de92d,_0x43563a['oldSnap']));else{if(_0x2bd38f==='child_changed'&&_0x1e933f==='child_added')this['changeMap']['set'](_0x3de92d,et(_0x3de92d,_0x73dc1a['snapshotNode']));else{if(_0x2bd38f==='child_changed'&&_0x1e933f==='child_changed')this['changeMap']['set'](_0x3de92d,Dt(_0x3de92d,_0x73dc1a['snapshotNode'],_0x43563a['oldSnap']));else throw rt('Illegal\x20combination\x20of\x20changes:\x20'+_0x73dc1a+'\x20occurred\x20after\x20'+_0x43563a);}}}}}else this['changeMap']['set'](_0x3de92d,_0x73dc1a);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x2dd2b9){return null;}['getChildAfterChild'](_0x24198f,_0x455330,_0x299f31){return null;}}const Go=new Tu();class ss{constructor(_0x2d09f4,_0x2b2abd,_0x16bd4c=null){this['writes_']=_0x2d09f4,this['viewCache_']=_0x2b2abd,this['optCompleteServerCache_']=_0x16bd4c;}['getCompleteChild'](_0x321001){const _0x1f1b20=this['viewCache_']['eventCache'];if(_0x1f1b20['isCompleteForChild'](_0x321001))return _0x1f1b20['getNode']()['getImmediateChild'](_0x321001);{const _0x30d7eb=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return is(this['writes_'],_0x321001,_0x30d7eb);}}['getChildAfterChild'](_0x35fae1,_0x1533b7,_0x364dfa){const _0x344abb=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:We(this['viewCache_']),_0x57951f=wu(this['writes_'],_0x344abb,_0x1533b7,0x1,_0x364dfa,_0x35fae1);return _0x57951f['length']===0x0?null:_0x57951f[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x74f796){return{'filter':_0x74f796};}function bu(_0x4ac93f,_0x469e86){f(_0x469e86['eventCache']['getNode']()['isIndexed'](_0x4ac93f['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x469e86['serverCache']['getNode']()['isIndexed'](_0x4ac93f['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x562ae9,_0x1e94eb,_0x2bf45d,_0x3ac5ec,_0x37a5c0){const _0x3ff286=new Cu();let _0x1dd55e,_0x265225;if(_0x2bf45d['type']===j['OVERWRITE']){const _0x1d8bf0=_0x2bf45d;_0x1d8bf0['source']['fromUser']?_0x1dd55e=Si(_0x562ae9,_0x1e94eb,_0x1d8bf0['path'],_0x1d8bf0['snap'],_0x3ac5ec,_0x37a5c0,_0x3ff286):(f(_0x1d8bf0['source']['fromServer'],'Unknown\x20source.'),_0x265225=_0x1d8bf0['source']['tagged']||_0x1e94eb['serverCache']['isFiltered']()&&!v(_0x1d8bf0['path']),_0x1dd55e=En(_0x562ae9,_0x1e94eb,_0x1d8bf0['path'],_0x1d8bf0['snap'],_0x3ac5ec,_0x37a5c0,_0x265225,_0x3ff286));}else{if(_0x2bf45d['type']===j['MERGE']){const _0x241ebc=_0x2bf45d;_0x241ebc['source']['fromUser']?_0x1dd55e=ku(_0x562ae9,_0x1e94eb,_0x241ebc['path'],_0x241ebc['children'],_0x3ac5ec,_0x37a5c0,_0x3ff286):(f(_0x241ebc['source']['fromServer'],'Unknown\x20source.'),_0x265225=_0x241ebc['source']['tagged']||_0x1e94eb['serverCache']['isFiltered'](),_0x1dd55e=bi(_0x562ae9,_0x1e94eb,_0x241ebc['path'],_0x241ebc['children'],_0x3ac5ec,_0x37a5c0,_0x265225,_0x3ff286));}else{if(_0x2bf45d['type']===j['ACK_USER_WRITE']){const _0x32b11b=_0x2bf45d;_0x32b11b['revert']?_0x1dd55e=Ou(_0x562ae9,_0x1e94eb,_0x32b11b['path'],_0x3ac5ec,_0x37a5c0,_0x3ff286):_0x1dd55e=Nu(_0x562ae9,_0x1e94eb,_0x32b11b['path'],_0x32b11b['affectedTree'],_0x3ac5ec,_0x37a5c0,_0x3ff286);}else{if(_0x2bf45d['type']===j['LISTEN_COMPLETE'])_0x1dd55e=Pu(_0x562ae9,_0x1e94eb,_0x2bf45d['path'],_0x3ac5ec,_0x3ff286);else throw rt('Unknown\x20operation\x20type:\x20'+_0x2bf45d['type']);}}}const _0xa380a5=_0x3ff286['getChanges']();return Au(_0x1e94eb,_0x1dd55e,_0xa380a5),{'viewCache':_0x1dd55e,'changes':_0xa380a5};}function Au(_0x221455,_0x81f594,_0x55beb6){const _0x4359d=_0x81f594['eventCache'];if(_0x4359d['isFullyInitialized']()){const _0x237e02=_0x4359d['getNode']()['isLeafNode']()||_0x4359d['getNode']()['isEmpty'](),_0x5289b1=mn(_0x221455);(_0x55beb6['length']>0x0||!_0x221455['eventCache']['isFullyInitialized']()||_0x237e02&&!_0x4359d['getNode']()['equals'](_0x5289b1)||!_0x4359d['getNode']()['getPriority']()['equals'](_0x5289b1['getPriority']()))&&_0x55beb6['push'](Lo(mn(_0x81f594)));}}function qo(_0x4dc784,_0x488a07,_0x679c21,_0x386296,_0x31e463,_0x52448a){const _0x41fe9c=_0x488a07['eventCache'];if(vn(_0x386296,_0x679c21)!=null)return _0x488a07;{let _0x513f41,_0x2cd7e3;if(v(_0x679c21)){if(f(_0x488a07['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0x488a07['serverCache']['isFiltered']()){const _0x4f5158=We(_0x488a07),_0x5d6fb4=_0x4f5158 instanceof g?_0x4f5158:g['EMPTY_NODE'],_0x40db1e=ns(_0x386296,_0x5d6fb4);_0x513f41=_0x4dc784['filter']['updateFullNode'](_0x488a07['eventCache']['getNode'](),_0x40db1e,_0x52448a);}else{const _0x50919b=yn(_0x386296,We(_0x488a07));_0x513f41=_0x4dc784['filter']['updateFullNode'](_0x488a07['eventCache']['getNode'](),_0x50919b,_0x52448a);}}else{const _0x4cb802=y(_0x679c21);if(_0x4cb802==='.priority'){f(we(_0x679c21)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0xc0bd96=_0x41fe9c['getNode']();_0x2cd7e3=_0x488a07['serverCache']['getNode']();const _0x535146=lr(_0x386296,_0x679c21,_0xc0bd96,_0x2cd7e3);_0x535146!=null?_0x513f41=_0x4dc784['filter']['updatePriority'](_0xc0bd96,_0x535146):_0x513f41=_0x41fe9c['getNode']();}else{const _0x19373f=b(_0x679c21);let _0xea5b0f;if(_0x41fe9c['isCompleteForChild'](_0x4cb802)){_0x2cd7e3=_0x488a07['serverCache']['getNode']();const _0x2decc0=lr(_0x386296,_0x679c21,_0x41fe9c['getNode'](),_0x2cd7e3);_0x2decc0!=null?_0xea5b0f=_0x41fe9c['getNode']()['getImmediateChild'](_0x4cb802)['updateChild'](_0x19373f,_0x2decc0):_0xea5b0f=_0x41fe9c['getNode']()['getImmediateChild'](_0x4cb802);}else _0xea5b0f=is(_0x386296,_0x4cb802,_0x488a07['serverCache']);_0xea5b0f!=null?_0x513f41=_0x4dc784['filter']['updateChild'](_0x41fe9c['getNode'](),_0x4cb802,_0xea5b0f,_0x19373f,_0x31e463,_0x52448a):_0x513f41=_0x41fe9c['getNode']();}}return Tt(_0x488a07,_0x513f41,_0x41fe9c['isFullyInitialized']()||v(_0x679c21),_0x4dc784['filter']['filtersNodes']());}}function En(_0x40841e,_0x34eb7c,_0x3ba9d1,_0x2648eb,_0x5f0bf3,_0x8ead2b,_0x460187,_0x18bf06){const _0x3dbea9=_0x34eb7c['serverCache'];let _0x4c1034;const _0x3cf945=_0x460187?_0x40841e['filter']:_0x40841e['filter']['getIndexedFilter']();if(v(_0x3ba9d1))_0x4c1034=_0x3cf945['updateFullNode'](_0x3dbea9['getNode'](),_0x2648eb,null);else{if(_0x3cf945['filtersNodes']()&&!_0x3dbea9['isFiltered']()){const _0x1a66dd=_0x3dbea9['getNode']()['updateChild'](_0x3ba9d1,_0x2648eb);_0x4c1034=_0x3cf945['updateFullNode'](_0x3dbea9['getNode'](),_0x1a66dd,null);}else{const _0x2370d6=y(_0x3ba9d1);if(!_0x3dbea9['isCompleteForPath'](_0x3ba9d1)&&we(_0x3ba9d1)>0x1)return _0x34eb7c;const _0x57725b=b(_0x3ba9d1),_0x264b9a=_0x3dbea9['getNode']()['getImmediateChild'](_0x2370d6)['updateChild'](_0x57725b,_0x2648eb);_0x2370d6==='.priority'?_0x4c1034=_0x3cf945['updatePriority'](_0x3dbea9['getNode'](),_0x264b9a):_0x4c1034=_0x3cf945['updateChild'](_0x3dbea9['getNode'](),_0x2370d6,_0x264b9a,_0x57725b,Go,null);}}const _0x3da9f3=Uo(_0x34eb7c,_0x4c1034,_0x3dbea9['isFullyInitialized']()||v(_0x3ba9d1),_0x3cf945['filtersNodes']()),_0x43510c=new ss(_0x5f0bf3,_0x3da9f3,_0x8ead2b);return qo(_0x40841e,_0x3da9f3,_0x3ba9d1,_0x5f0bf3,_0x43510c,_0x18bf06);}function Si(_0x101ec1,_0x2ce597,_0x5f1634,_0xb9c490,_0x2586f5,_0x9c7fbc,_0xafda61){const _0x5285e0=_0x2ce597['eventCache'];let _0x289dc1,_0x386333;const _0xf0de5d=new ss(_0x2586f5,_0x2ce597,_0x9c7fbc);if(v(_0x5f1634))_0x386333=_0x101ec1['filter']['updateFullNode'](_0x2ce597['eventCache']['getNode'](),_0xb9c490,_0xafda61),_0x289dc1=Tt(_0x2ce597,_0x386333,!0x0,_0x101ec1['filter']['filtersNodes']());else{const _0x241842=y(_0x5f1634);if(_0x241842==='.priority')_0x386333=_0x101ec1['filter']['updatePriority'](_0x2ce597['eventCache']['getNode'](),_0xb9c490),_0x289dc1=Tt(_0x2ce597,_0x386333,_0x5285e0['isFullyInitialized'](),_0x5285e0['isFiltered']());else{const _0xeb37f1=b(_0x5f1634),_0x4d30a9=_0x5285e0['getNode']()['getImmediateChild'](_0x241842);let _0x277198;if(v(_0xeb37f1))_0x277198=_0xb9c490;else{const _0xf970db=_0xf0de5d['getCompleteChild'](_0x241842);_0xf970db!=null?zi(_0xeb37f1)==='.priority'&&_0xf970db['getChild'](Ro(_0xeb37f1))['isEmpty']()?_0x277198=_0xf970db:_0x277198=_0xf970db['updateChild'](_0xeb37f1,_0xb9c490):_0x277198=g['EMPTY_NODE'];}if(_0x4d30a9['equals'](_0x277198))_0x289dc1=_0x2ce597;else{const _0x1f8b6f=_0x101ec1['filter']['updateChild'](_0x5285e0['getNode'](),_0x241842,_0x277198,_0xeb37f1,_0xf0de5d,_0xafda61);_0x289dc1=Tt(_0x2ce597,_0x1f8b6f,_0x5285e0['isFullyInitialized'](),_0x101ec1['filter']['filtersNodes']());}}}return _0x289dc1;}function hr(_0x39bb4b,_0x55782e){return _0x39bb4b['eventCache']['isCompleteForChild'](_0x55782e);}function ku(_0x59d64f,_0x499d79,_0x120d61,_0x125518,_0x83cffc,_0x5d7468,_0x31b4a3){let _0x13317a=_0x499d79;return _0x125518['foreach']((_0x2ed15a,_0x3ef9ca)=>{const _0xac9a8f=k(_0x120d61,_0x2ed15a);hr(_0x499d79,y(_0xac9a8f))&&(_0x13317a=Si(_0x59d64f,_0x13317a,_0xac9a8f,_0x3ef9ca,_0x83cffc,_0x5d7468,_0x31b4a3));}),_0x125518['foreach']((_0x5b7ccb,_0x40c8b4)=>{const _0x154a19=k(_0x120d61,_0x5b7ccb);hr(_0x499d79,y(_0x154a19))||(_0x13317a=Si(_0x59d64f,_0x13317a,_0x154a19,_0x40c8b4,_0x83cffc,_0x5d7468,_0x31b4a3));}),_0x13317a;}function ur(_0x34cd78,_0x224d5f,_0x543643){return _0x543643['foreach']((_0x2ea1cf,_0x996462)=>{_0x224d5f=_0x224d5f['updateChild'](_0x2ea1cf,_0x996462);}),_0x224d5f;}function bi(_0x27caaa,_0x502ac1,_0x2794d9,_0x42fa3f,_0x184b63,_0x504d7d,_0x96a65c,_0x30cd26){if(_0x502ac1['serverCache']['getNode']()['isEmpty']()&&!_0x502ac1['serverCache']['isFullyInitialized']())return _0x502ac1;let _0x330df3=_0x502ac1,_0x19f7cc;v(_0x2794d9)?_0x19f7cc=_0x42fa3f:_0x19f7cc=new S(null)['setTree'](_0x2794d9,_0x42fa3f);const _0x4576f6=_0x502ac1['serverCache']['getNode']();return _0x19f7cc['children']['inorderTraversal']((_0x1daf5e,_0x342834)=>{if(_0x4576f6['hasChild'](_0x1daf5e)){const _0x3c5fb7=_0x502ac1['serverCache']['getNode']()['getImmediateChild'](_0x1daf5e),_0xc93066=ur(_0x27caaa,_0x3c5fb7,_0x342834);_0x330df3=En(_0x27caaa,_0x330df3,new C(_0x1daf5e),_0xc93066,_0x184b63,_0x504d7d,_0x96a65c,_0x30cd26);}}),_0x19f7cc['children']['inorderTraversal']((_0x391d28,_0x39e54c)=>{const _0x305580=!_0x502ac1['serverCache']['isCompleteForChild'](_0x391d28)&&_0x39e54c['value']===null;if(!_0x4576f6['hasChild'](_0x391d28)&&!_0x305580){const _0x374ee5=_0x502ac1['serverCache']['getNode']()['getImmediateChild'](_0x391d28),_0x28f29c=ur(_0x27caaa,_0x374ee5,_0x39e54c);_0x330df3=En(_0x27caaa,_0x330df3,new C(_0x391d28),_0x28f29c,_0x184b63,_0x504d7d,_0x96a65c,_0x30cd26);}}),_0x330df3;}function Nu(_0x4e8fb2,_0x1c3f76,_0x267b9c,_0xe9a0ff,_0x565a2d,_0x3dc98d,_0x40f737){if(vn(_0x565a2d,_0x267b9c)!=null)return _0x1c3f76;const _0x3cfbad=_0x1c3f76['serverCache']['isFiltered'](),_0x3ae553=_0x1c3f76['serverCache'];if(_0xe9a0ff['value']!=null){if(v(_0x267b9c)&&_0x3ae553['isFullyInitialized']()||_0x3ae553['isCompleteForPath'](_0x267b9c))return En(_0x4e8fb2,_0x1c3f76,_0x267b9c,_0x3ae553['getNode']()['getChild'](_0x267b9c),_0x565a2d,_0x3dc98d,_0x3cfbad,_0x40f737);if(v(_0x267b9c)){let _0x3826a8=new S(null);return _0x3ae553['getNode']()['forEachChild'](ye,(_0x46f52e,_0x1c806c)=>{_0x3826a8=_0x3826a8['set'](new C(_0x46f52e),_0x1c806c);}),bi(_0x4e8fb2,_0x1c3f76,_0x267b9c,_0x3826a8,_0x565a2d,_0x3dc98d,_0x3cfbad,_0x40f737);}else return _0x1c3f76;}else{let _0x30fb0a=new S(null);return _0xe9a0ff['foreach']((_0x2d194b,_0x1ff63e)=>{const _0x252224=k(_0x267b9c,_0x2d194b);_0x3ae553['isCompleteForPath'](_0x252224)&&(_0x30fb0a=_0x30fb0a['set'](_0x2d194b,_0x3ae553['getNode']()['getChild'](_0x252224)));}),bi(_0x4e8fb2,_0x1c3f76,_0x267b9c,_0x30fb0a,_0x565a2d,_0x3dc98d,_0x3cfbad,_0x40f737);}}function Pu(_0x30af86,_0x261648,_0x5a5276,_0x2af3a5,_0x2e5064){const _0x3b012c=_0x261648['serverCache'],_0x1badaa=Uo(_0x261648,_0x3b012c['getNode'](),_0x3b012c['isFullyInitialized']()||v(_0x5a5276),_0x3b012c['isFiltered']());return qo(_0x30af86,_0x1badaa,_0x5a5276,_0x2af3a5,Go,_0x2e5064);}function Ou(_0x382332,_0x33d0c4,_0x35bd5e,_0x44f57a,_0x2ed661,_0x2a1964){let _0x14564c;if(vn(_0x44f57a,_0x35bd5e)!=null)return _0x33d0c4;{const _0x381533=new ss(_0x44f57a,_0x33d0c4,_0x2ed661),_0x382b4a=_0x33d0c4['eventCache']['getNode']();let _0x5c1a10;if(v(_0x35bd5e)||y(_0x35bd5e)==='.priority'){let _0x2ec3bf;if(_0x33d0c4['serverCache']['isFullyInitialized']())_0x2ec3bf=yn(_0x44f57a,We(_0x33d0c4));else{const _0x3ce3d0=_0x33d0c4['serverCache']['getNode']();f(_0x3ce3d0 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x2ec3bf=ns(_0x44f57a,_0x3ce3d0);}_0x2ec3bf=_0x2ec3bf,_0x5c1a10=_0x382332['filter']['updateFullNode'](_0x382b4a,_0x2ec3bf,_0x2a1964);}else{const _0x1bf8e4=y(_0x35bd5e);let _0x3d7a99=is(_0x44f57a,_0x1bf8e4,_0x33d0c4['serverCache']);_0x3d7a99==null&&_0x33d0c4['serverCache']['isCompleteForChild'](_0x1bf8e4)&&(_0x3d7a99=_0x382b4a['getImmediateChild'](_0x1bf8e4)),_0x3d7a99!=null?_0x5c1a10=_0x382332['filter']['updateChild'](_0x382b4a,_0x1bf8e4,_0x3d7a99,b(_0x35bd5e),_0x381533,_0x2a1964):_0x33d0c4['eventCache']['getNode']()['hasChild'](_0x1bf8e4)?_0x5c1a10=_0x382332['filter']['updateChild'](_0x382b4a,_0x1bf8e4,g['EMPTY_NODE'],b(_0x35bd5e),_0x381533,_0x2a1964):_0x5c1a10=_0x382b4a,_0x5c1a10['isEmpty']()&&_0x33d0c4['serverCache']['isFullyInitialized']()&&(_0x14564c=yn(_0x44f57a,We(_0x33d0c4)),_0x14564c['isLeafNode']()&&(_0x5c1a10=_0x382332['filter']['updateFullNode'](_0x5c1a10,_0x14564c,_0x2a1964)));}return _0x14564c=_0x33d0c4['serverCache']['isFullyInitialized']()||vn(_0x44f57a,w())!=null,Tt(_0x33d0c4,_0x5c1a10,_0x14564c,_0x382332['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x355820,_0x1df3d8){this['query_']=_0x355820,this['eventRegistrations_']=[];const _0x9802d7=this['query_']['_queryParams'],_0x4bda93=new Ji(_0x9802d7['getIndex']()),_0x39ab8c=Kh(_0x9802d7);this['processor_']=Su(_0x39ab8c);const _0x25d2a5=_0x1df3d8['serverCache'],_0x23d533=_0x1df3d8['eventCache'],_0x346693=_0x4bda93['updateFullNode'](g['EMPTY_NODE'],_0x25d2a5['getNode'](),null),_0x132f7b=_0x39ab8c['updateFullNode'](g['EMPTY_NODE'],_0x23d533['getNode'](),null),_0x3d8a50=new Ce(_0x346693,_0x25d2a5['isFullyInitialized'](),_0x4bda93['filtersNodes']()),_0x16056e=new Ce(_0x132f7b,_0x23d533['isFullyInitialized'](),_0x39ab8c['filtersNodes']());this['viewCache_']=Mn(_0x16056e,_0x3d8a50),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x3a9ab7){return _0x3a9ab7['viewCache_']['serverCache']['getNode']();}function Lu(_0xeb757e){return mn(_0xeb757e['viewCache_']);}function xu(_0x1d45d4,_0x2696e6){const _0x19f33e=We(_0x1d45d4['viewCache_']);return _0x19f33e&&(_0x1d45d4['query']['_queryParams']['loadsAllData']()||!v(_0x2696e6)&&!_0x19f33e['getImmediateChild'](y(_0x2696e6))['isEmpty']())?_0x19f33e['getChild'](_0x2696e6):null;}function dr(_0x576b3d){return _0x576b3d['eventRegistrations_']['length']===0x0;}function Fu(_0x3090b7,_0x1e3e38){_0x3090b7['eventRegistrations_']['push'](_0x1e3e38);}function fr(_0x246d6a,_0x2cdcf2,_0x27d3c3){const _0xcdf6e9=[];if(_0x27d3c3){f(_0x2cdcf2==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x179e21=_0x246d6a['query']['_path'];_0x246d6a['eventRegistrations_']['forEach'](_0x3a3704=>{const _0x2e3b44=_0x3a3704['createCancelEvent'](_0x27d3c3,_0x179e21);_0x2e3b44&&_0xcdf6e9['push'](_0x2e3b44);});}if(_0x2cdcf2){let _0x40875f=[];for(let _0x322f83=0x0;_0x322f83<_0x246d6a['eventRegistrations_']['length'];++_0x322f83){const _0x2161d2=_0x246d6a['eventRegistrations_'][_0x322f83];if(!_0x2161d2['matches'](_0x2cdcf2))_0x40875f['push'](_0x2161d2);else{if(_0x2cdcf2['hasAnyCallback']()){_0x40875f=_0x40875f['concat'](_0x246d6a['eventRegistrations_']['slice'](_0x322f83+0x1));break;}}}_0x246d6a['eventRegistrations_']=_0x40875f;}else _0x246d6a['eventRegistrations_']=[];return _0xcdf6e9;}function pr(_0x179c28,_0x293d30,_0x5d0f1b,_0x37db1e){_0x293d30['type']===j['MERGE']&&_0x293d30['source']['queryId']!==null&&(f(We(_0x179c28['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(mn(_0x179c28['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x3b2855=_0x179c28['viewCache_'],_0x283ef0=Ru(_0x179c28['processor_'],_0x3b2855,_0x293d30,_0x5d0f1b,_0x37db1e);return bu(_0x179c28['processor_'],_0x283ef0['viewCache']),f(_0x283ef0['viewCache']['serverCache']['isFullyInitialized']()||!_0x3b2855['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x179c28['viewCache_']=_0x283ef0['viewCache'],zo(_0x179c28,_0x283ef0['changes'],_0x283ef0['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x468967,_0x2ba753){const _0x479d11=_0x468967['viewCache_']['eventCache'],_0x2fe07c=[];return _0x479d11['getNode']()['isLeafNode']()||_0x479d11['getNode']()['forEachChild'](R,(_0x4870a0,_0x32645d)=>{_0x2fe07c['push'](et(_0x4870a0,_0x32645d));}),_0x479d11['isFullyInitialized']()&&_0x2fe07c['push'](Lo(_0x479d11['getNode']())),zo(_0x468967,_0x2fe07c,_0x479d11['getNode'](),_0x2ba753);}function zo(_0x13b74a,_0x19b3c5,_0x33568e,_0x408d74){const _0x1d35b1=_0x408d74?[_0x408d74]:_0x13b74a['eventRegistrations_'];return ru(_0x13b74a['eventGenerator_'],_0x19b3c5,_0x33568e,_0x1d35b1);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;class jo{constructor(){this['views']=new Map();}}function Wu(_0x43aac0){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0x43aac0;}function Bu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}function Vu(_0x5cfdc5){return _0x5cfdc5['views']['size']===0x0;}function rs(_0x28b3f6,_0x5ca4d1,_0x5f37f0,_0x154a6f){const _0x4466da=_0x5ca4d1['source']['queryId'];if(_0x4466da!==null){const _0x393cf4=_0x28b3f6['views']['get'](_0x4466da);return f(_0x393cf4!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),pr(_0x393cf4,_0x5ca4d1,_0x5f37f0,_0x154a6f);}else{let _0x4eb2e1=[];for(const _0x195047 of _0x28b3f6['views']['values']())_0x4eb2e1=_0x4eb2e1['concat'](pr(_0x195047,_0x5ca4d1,_0x5f37f0,_0x154a6f));return _0x4eb2e1;}}function Ko(_0x13a878,_0x570630,_0x4a5afd,_0x33e3c8,_0x201afd){const _0x376389=_0x570630['_queryIdentifier'],_0x312279=_0x13a878['views']['get'](_0x376389);if(!_0x312279){let _0x31d9af=yn(_0x4a5afd,_0x201afd?_0x33e3c8:null),_0xeae3ba=!0x1;_0x31d9af?_0xeae3ba=!0x0:_0x33e3c8 instanceof g?(_0x31d9af=ns(_0x4a5afd,_0x33e3c8),_0xeae3ba=!0x1):(_0x31d9af=g['EMPTY_NODE'],_0xeae3ba=!0x1);const _0x6efaee=Mn(new Ce(_0x31d9af,_0xeae3ba,!0x1),new Ce(_0x33e3c8,_0x201afd,!0x1));return new Du(_0x570630,_0x6efaee);}return _0x312279;}function Hu(_0x486256,_0x281e18,_0x5a1c62,_0x53f2ef,_0x121fe4,_0x468995){const _0x51fe05=Ko(_0x486256,_0x281e18,_0x53f2ef,_0x121fe4,_0x468995);return _0x486256['views']['has'](_0x281e18['_queryIdentifier'])||_0x486256['views']['set'](_0x281e18['_queryIdentifier'],_0x51fe05),Fu(_0x51fe05,_0x5a1c62),Uu(_0x51fe05,_0x5a1c62);}function $u(_0x159a5b,_0xc62bf6,_0x2a62d1,_0x13ac09){const _0x4ea78f=_0xc62bf6['_queryIdentifier'],_0xfa8290=[];let _0x2ed9bc=[];const _0x5c8ff8=Te(_0x159a5b);if(_0x4ea78f==='default'){for(const [_0x187214,_0x1ece3a]of _0x159a5b['views']['entries']())_0x2ed9bc=_0x2ed9bc['concat'](fr(_0x1ece3a,_0x2a62d1,_0x13ac09)),dr(_0x1ece3a)&&(_0x159a5b['views']['delete'](_0x187214),_0x1ece3a['query']['_queryParams']['loadsAllData']()||_0xfa8290['push'](_0x1ece3a['query']));}else{const _0x190154=_0x159a5b['views']['get'](_0x4ea78f);_0x190154&&(_0x2ed9bc=_0x2ed9bc['concat'](fr(_0x190154,_0x2a62d1,_0x13ac09)),dr(_0x190154)&&(_0x159a5b['views']['delete'](_0x4ea78f),_0x190154['query']['_queryParams']['loadsAllData']()||_0xfa8290['push'](_0x190154['query'])));}return _0x5c8ff8&&!Te(_0x159a5b)&&_0xfa8290['push'](new(Bu())(_0xc62bf6['_repo'],_0xc62bf6['_path'])),{'removed':_0xfa8290,'events':_0x2ed9bc};}function Yo(_0x14a457){const _0x3adbbf=[];for(const _0x150b56 of _0x14a457['views']['values']())_0x150b56['query']['_queryParams']['loadsAllData']()||_0x3adbbf['push'](_0x150b56);return _0x3adbbf;}function Ee(_0x4ab7c9,_0x24337c){let _0x14cec1=null;for(const _0x4cc11b of _0x4ab7c9['views']['values']())_0x14cec1=_0x14cec1||xu(_0x4cc11b,_0x24337c);return _0x14cec1;}function Qo(_0x2bd269,_0x54dd30){if(_0x54dd30['_queryParams']['loadsAllData']())return xn(_0x2bd269);{const _0x3896d1=_0x54dd30['_queryIdentifier'];return _0x2bd269['views']['get'](_0x3896d1);}}function Jo(_0x47586e,_0x21bede){return Qo(_0x47586e,_0x21bede)!=null;}function Te(_0x224f77){return xn(_0x224f77)!=null;}function xn(_0x474265){for(const _0x932c48 of _0x474265['views']['values']())if(_0x932c48['query']['_queryParams']['loadsAllData']())return _0x932c48;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let wn;function Gu(_0x4b17bb){f(!wn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),wn=_0x4b17bb;}function qu(){return f(wn,'Reference.ts\x20has\x20not\x20been\x20loaded'),wn;}let zu=0x1;class _r{constructor(_0x515283){this['listenProvider_']=_0x515283,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function os(_0x4f272f,_0x11a00e,_0xb8e211,_0x4fac84,_0x4a9556){return lu(_0x4f272f['pendingWriteTree_'],_0x11a00e,_0xb8e211,_0x4fac84,_0x4a9556),_0x4a9556?ut(_0x4f272f,new Ue(Zi(),_0x11a00e,_0xb8e211)):[];}function ju(_0x514313,_0x132300,_0x55da38,_0x112002){hu(_0x514313['pendingWriteTree_'],_0x132300,_0x55da38,_0x112002);const _0x3e5771=S['fromObject'](_0x55da38);return ut(_0x514313,new tt(Zi(),_0x132300,_0x3e5771));}function pe(_0x430ace,_0x3e970b,_0x423749=!0x1){const _0x5bf930=uu(_0x430ace['pendingWriteTree_'],_0x3e970b);if(du(_0x430ace['pendingWriteTree_'],_0x3e970b)){let _0x39ed5c=new S(null);return _0x5bf930['snap']!=null?_0x39ed5c=_0x39ed5c['set'](w(),!0x0):x(_0x5bf930['children'],_0x4e9c96=>{_0x39ed5c=_0x39ed5c['set'](new C(_0x4e9c96),!0x0);}),ut(_0x430ace,new gn(_0x5bf930['path'],_0x39ed5c,_0x423749));}else return[];}function Gt(_0x1991d6,_0x1c432c,_0x5ba3b8){return ut(_0x1991d6,new Ue(es(),_0x1c432c,_0x5ba3b8));}function Ku(_0x2be159,_0x366bc8,_0x3b53c8){const _0x3e22ca=S['fromObject'](_0x3b53c8);return ut(_0x2be159,new tt(es(),_0x366bc8,_0x3e22ca));}function Yu(_0x1faabf,_0x474bee){return ut(_0x1faabf,new Lt(es(),_0x474bee));}function Qu(_0x3817c7,_0x25374f,_0xf64e2e){const _0x2a131c=as(_0x3817c7,_0xf64e2e);if(_0x2a131c){const _0x3b5cf8=cs(_0x2a131c),_0xb84dc1=_0x3b5cf8['path'],_0x2fffeb=_0x3b5cf8['queryId'],_0x105db9=F(_0xb84dc1,_0x25374f),_0x57e032=new Lt(ts(_0x2fffeb),_0x105db9);return ls(_0x3817c7,_0xb84dc1,_0x57e032);}else return[];}function Cn(_0x3b0553,_0x2c86cb,_0x10aa8b,_0x4db850,_0x45e587=!0x1){const _0x50e21d=_0x2c86cb['_path'],_0x311c21=_0x3b0553['syncPointTree_']['get'](_0x50e21d);let _0x40dbb6=[];if(_0x311c21&&(_0x2c86cb['_queryIdentifier']==='default'||Jo(_0x311c21,_0x2c86cb))){const _0x12ebe7=$u(_0x311c21,_0x2c86cb,_0x10aa8b,_0x4db850);Vu(_0x311c21)&&(_0x3b0553['syncPointTree_']=_0x3b0553['syncPointTree_']['remove'](_0x50e21d));const _0x3cfc63=_0x12ebe7['removed'];if(_0x40dbb6=_0x12ebe7['events'],!_0x45e587){const _0x42d103=_0x3cfc63['findIndex'](_0x33a025=>_0x33a025['_queryParams']['loadsAllData']())!==-0x1,_0x572205=_0x3b0553['syncPointTree_']['findOnPath'](_0x50e21d,(_0x3804e2,_0x2767ca)=>Te(_0x2767ca));if(_0x42d103&&!_0x572205){const _0x591698=_0x3b0553['syncPointTree_']['subtree'](_0x50e21d);if(!_0x591698['isEmpty']()){const _0x2d0532=Zu(_0x591698);for(let _0x28ff77=0x0;_0x28ff77<_0x2d0532['length'];++_0x28ff77){const _0x3b0a63=_0x2d0532[_0x28ff77],_0x41b73c=_0x3b0a63['query'],_0x2fcbb4=ta(_0x3b0553,_0x3b0a63);_0x3b0553['listenProvider_']['startListening'](bt(_0x41b73c),xt(_0x3b0553,_0x41b73c),_0x2fcbb4['hashFn'],_0x2fcbb4['onComplete']);}}}!_0x572205&&_0x3cfc63['length']>0x0&&!_0x4db850&&(_0x42d103?_0x3b0553['listenProvider_']['stopListening'](bt(_0x2c86cb),null):_0x3cfc63['forEach'](_0x22031f=>{const _0x2fa7ea=_0x3b0553['queryToTagMap']['get'](Un(_0x22031f));_0x3b0553['listenProvider_']['stopListening'](bt(_0x22031f),_0x2fa7ea);}));}ed(_0x3b0553,_0x3cfc63);}return _0x40dbb6;}function Xo(_0xb1c31c,_0x4b6adf,_0x2d2548,_0x401e8f){const _0x40423a=as(_0xb1c31c,_0x401e8f);if(_0x40423a!=null){const _0xce193d=cs(_0x40423a),_0x3e06d3=_0xce193d['path'],_0x5a7d6c=_0xce193d['queryId'],_0x33d04e=F(_0x3e06d3,_0x4b6adf),_0x51a88c=new Ue(ts(_0x5a7d6c),_0x33d04e,_0x2d2548);return ls(_0xb1c31c,_0x3e06d3,_0x51a88c);}else return[];}function Ju(_0x4307d2,_0x29a676,_0x25cbbd,_0x2d6042){const _0x33ab2c=as(_0x4307d2,_0x2d6042);if(_0x33ab2c){const _0x35daa8=cs(_0x33ab2c),_0x456fda=_0x35daa8['path'],_0x4d0ee6=_0x35daa8['queryId'],_0x414f9c=F(_0x456fda,_0x29a676),_0x263ddf=S['fromObject'](_0x25cbbd),_0x231074=new tt(ts(_0x4d0ee6),_0x414f9c,_0x263ddf);return ls(_0x4307d2,_0x456fda,_0x231074);}else return[];}function Ri(_0x1fb71b,_0x4cbb17,_0x151d47,_0x2ef2d4=!0x1){const _0x118c87=_0x4cbb17['_path'];let _0x5a2c27=null,_0x1c1d50=!0x1;_0x1fb71b['syncPointTree_']['foreachOnPath'](_0x118c87,(_0x53a96e,_0x2452a5)=>{const _0x37d86a=F(_0x53a96e,_0x118c87);_0x5a2c27=_0x5a2c27||Ee(_0x2452a5,_0x37d86a),_0x1c1d50=_0x1c1d50||Te(_0x2452a5);});let _0x1d1d3d=_0x1fb71b['syncPointTree_']['get'](_0x118c87);_0x1d1d3d?(_0x1c1d50=_0x1c1d50||Te(_0x1d1d3d),_0x5a2c27=_0x5a2c27||Ee(_0x1d1d3d,w())):(_0x1d1d3d=new jo(),_0x1fb71b['syncPointTree_']=_0x1fb71b['syncPointTree_']['set'](_0x118c87,_0x1d1d3d));let _0x49375d;_0x5a2c27!=null?_0x49375d=!0x0:(_0x49375d=!0x1,_0x5a2c27=g['EMPTY_NODE'],_0x1fb71b['syncPointTree_']['subtree'](_0x118c87)['foreachChild']((_0x1f030c,_0x5003ab)=>{const _0x631696=Ee(_0x5003ab,w());_0x631696&&(_0x5a2c27=_0x5a2c27['updateImmediateChild'](_0x1f030c,_0x631696));}));const _0x175e97=Jo(_0x1d1d3d,_0x4cbb17);if(!_0x175e97&&!_0x4cbb17['_queryParams']['loadsAllData']()){const _0x1564ee=Un(_0x4cbb17);f(!_0x1fb71b['queryToTagMap']['has'](_0x1564ee),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x2f4ea0=td();_0x1fb71b['queryToTagMap']['set'](_0x1564ee,_0x2f4ea0),_0x1fb71b['tagToQueryMap']['set'](_0x2f4ea0,_0x1564ee);}const _0xbfefaf=Ln(_0x1fb71b['pendingWriteTree_'],_0x118c87);let _0xe09574=Hu(_0x1d1d3d,_0x4cbb17,_0x151d47,_0xbfefaf,_0x5a2c27,_0x49375d);if(!_0x175e97&&!_0x1c1d50&&!_0x2ef2d4){const _0x52bc57=Qo(_0x1d1d3d,_0x4cbb17);_0xe09574=_0xe09574['concat'](nd(_0x1fb71b,_0x4cbb17,_0x52bc57));}return _0xe09574;}function Fn(_0xca0aae,_0x4db8f2,_0x568347){const _0x3df658=_0xca0aae['pendingWriteTree_'],_0x1f1a62=_0xca0aae['syncPointTree_']['findOnPath'](_0x4db8f2,(_0x47de6d,_0x3c873c)=>{const _0x16d118=F(_0x47de6d,_0x4db8f2),_0x3df56a=Ee(_0x3c873c,_0x16d118);if(_0x3df56a)return _0x3df56a;});return Vo(_0x3df658,_0x4db8f2,_0x1f1a62,_0x568347,!0x0);}function Xu(_0x273b83,_0x2abf8b){const _0x28a210=_0x2abf8b['_path'];let _0x397e8c=null;_0x273b83['syncPointTree_']['foreachOnPath'](_0x28a210,(_0x1c3436,_0x38fa01)=>{const _0x3241b5=F(_0x1c3436,_0x28a210);_0x397e8c=_0x397e8c||Ee(_0x38fa01,_0x3241b5);});let _0x18aa18=_0x273b83['syncPointTree_']['get'](_0x28a210);_0x18aa18?_0x397e8c=_0x397e8c||Ee(_0x18aa18,w()):(_0x18aa18=new jo(),_0x273b83['syncPointTree_']=_0x273b83['syncPointTree_']['set'](_0x28a210,_0x18aa18));const _0x187598=_0x397e8c!=null,_0x2e9d8d=_0x187598?new Ce(_0x397e8c,!0x0,!0x1):null,_0x2371e4=Ln(_0x273b83['pendingWriteTree_'],_0x2abf8b['_path']),_0x5bcd5a=Ko(_0x18aa18,_0x2abf8b,_0x2371e4,_0x187598?_0x2e9d8d['getNode']():g['EMPTY_NODE'],_0x187598);return Lu(_0x5bcd5a);}function ut(_0x3fa324,_0x4509ea){return Zo(_0x4509ea,_0x3fa324['syncPointTree_'],null,Ln(_0x3fa324['pendingWriteTree_'],w()));}function Zo(_0xb69dbe,_0xb3e6ab,_0x372c44,_0x3baa7f){if(v(_0xb69dbe['path']))return ea(_0xb69dbe,_0xb3e6ab,_0x372c44,_0x3baa7f);{const _0x12fd21=_0xb3e6ab['get'](w());_0x372c44==null&&_0x12fd21!=null&&(_0x372c44=Ee(_0x12fd21,w()));let _0x20cb79=[];const _0x277076=y(_0xb69dbe['path']),_0x4cbfa9=_0xb69dbe['operationForChild'](_0x277076),_0xcb3f8e=_0xb3e6ab['children']['get'](_0x277076);if(_0xcb3f8e&&_0x4cbfa9){const _0x5629c0=_0x372c44?_0x372c44['getImmediateChild'](_0x277076):null,_0x3365d4=Ho(_0x3baa7f,_0x277076);_0x20cb79=_0x20cb79['concat'](Zo(_0x4cbfa9,_0xcb3f8e,_0x5629c0,_0x3365d4));}return _0x12fd21&&(_0x20cb79=_0x20cb79['concat'](rs(_0x12fd21,_0xb69dbe,_0x3baa7f,_0x372c44))),_0x20cb79;}}function ea(_0x6ee286,_0x4fe03a,_0x12f2dc,_0x259703){const _0x39ec26=_0x4fe03a['get'](w());_0x12f2dc==null&&_0x39ec26!=null&&(_0x12f2dc=Ee(_0x39ec26,w()));let _0x13b8ab=[];return _0x4fe03a['children']['inorderTraversal']((_0x5b8bed,_0xbe6258)=>{const _0x5d6d87=_0x12f2dc?_0x12f2dc['getImmediateChild'](_0x5b8bed):null,_0x2993ce=Ho(_0x259703,_0x5b8bed),_0x45e777=_0x6ee286['operationForChild'](_0x5b8bed);_0x45e777&&(_0x13b8ab=_0x13b8ab['concat'](ea(_0x45e777,_0xbe6258,_0x5d6d87,_0x2993ce)));}),_0x39ec26&&(_0x13b8ab=_0x13b8ab['concat'](rs(_0x39ec26,_0x6ee286,_0x259703,_0x12f2dc))),_0x13b8ab;}function ta(_0x96d954,_0x182402){const _0x440954=_0x182402['query'],_0x1f8a24=xt(_0x96d954,_0x440954);return{'hashFn':()=>(Mu(_0x182402)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x28bb9e=>{if(_0x28bb9e==='ok')return _0x1f8a24?Qu(_0x96d954,_0x440954['_path'],_0x1f8a24):Yu(_0x96d954,_0x440954['_path']);{const _0x1c862a=Kl(_0x28bb9e,_0x440954);return Cn(_0x96d954,_0x440954,null,_0x1c862a);}}};}function xt(_0x5898f8,_0x5d55f6){const _0x41e44f=Un(_0x5d55f6);return _0x5898f8['queryToTagMap']['get'](_0x41e44f);}function Un(_0x4c1e9a){return _0x4c1e9a['_path']['toString']()+'$'+_0x4c1e9a['_queryIdentifier'];}function as(_0x432c97,_0x19b263){return _0x432c97['tagToQueryMap']['get'](_0x19b263);}function cs(_0x2ab3e2){const _0x45e18d=_0x2ab3e2['indexOf']('$');return f(_0x45e18d!==-0x1&&_0x45e18d<_0x2ab3e2['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x2ab3e2['substr'](_0x45e18d+0x1),'path':new C(_0x2ab3e2['substr'](0x0,_0x45e18d))};}function ls(_0x3b4a3d,_0x3e6a25,_0x9fbe64){const _0x39ed3e=_0x3b4a3d['syncPointTree_']['get'](_0x3e6a25);f(_0x39ed3e,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x4383ed=Ln(_0x3b4a3d['pendingWriteTree_'],_0x3e6a25);return rs(_0x39ed3e,_0x9fbe64,_0x4383ed,null);}function Zu(_0x3a4242){return _0x3a4242['fold']((_0x5ca269,_0x4fdcf1,_0x2ca780)=>{if(_0x4fdcf1&&Te(_0x4fdcf1))return[xn(_0x4fdcf1)];{let _0x26c7b3=[];return _0x4fdcf1&&(_0x26c7b3=Yo(_0x4fdcf1)),x(_0x2ca780,(_0x3b7e58,_0x2bd335)=>{_0x26c7b3=_0x26c7b3['concat'](_0x2bd335);}),_0x26c7b3;}});}function bt(_0x57eb34){return _0x57eb34['_queryParams']['loadsAllData']()&&!_0x57eb34['_queryParams']['isDefault']()?new(qu())(_0x57eb34['_repo'],_0x57eb34['_path']):_0x57eb34;}function ed(_0x2b6ab8,_0x31f165){for(let _0x2cdf63=0x0;_0x2cdf63<_0x31f165['length'];++_0x2cdf63){const _0x1659e1=_0x31f165[_0x2cdf63];if(!_0x1659e1['_queryParams']['loadsAllData']()){const _0x5f5301=Un(_0x1659e1),_0x581983=_0x2b6ab8['queryToTagMap']['get'](_0x5f5301);_0x2b6ab8['queryToTagMap']['delete'](_0x5f5301),_0x2b6ab8['tagToQueryMap']['delete'](_0x581983);}}}function td(){return zu++;}function nd(_0x585237,_0x22bed0,_0x8a6704){const _0x266002=_0x22bed0['_path'],_0xc945b3=xt(_0x585237,_0x22bed0),_0x3b532b=ta(_0x585237,_0x8a6704),_0x5e9cce=_0x585237['listenProvider_']['startListening'](bt(_0x22bed0),_0xc945b3,_0x3b532b['hashFn'],_0x3b532b['onComplete']),_0x136d6f=_0x585237['syncPointTree_']['subtree'](_0x266002);if(_0xc945b3)f(!Te(_0x136d6f['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x39364c=_0x136d6f['fold']((_0x1bdf66,_0x153e44,_0x6220e6)=>{if(!v(_0x1bdf66)&&_0x153e44&&Te(_0x153e44))return[xn(_0x153e44)['query']];{let _0x2128a3=[];return _0x153e44&&(_0x2128a3=_0x2128a3['concat'](Yo(_0x153e44)['map'](_0x2742a5=>_0x2742a5['query']))),x(_0x6220e6,(_0x476984,_0x350347)=>{_0x2128a3=_0x2128a3['concat'](_0x350347);}),_0x2128a3;}});for(let _0x3f2545=0x0;_0x3f2545<_0x39364c['length'];++_0x3f2545){const _0x13a17f=_0x39364c[_0x3f2545];_0x585237['listenProvider_']['stopListening'](bt(_0x13a17f),xt(_0x585237,_0x13a17f));}}return _0x5e9cce;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class hs{constructor(_0x196dbe){this['node_']=_0x196dbe;}['getImmediateChild'](_0x598f74){const _0x3ac700=this['node_']['getImmediateChild'](_0x598f74);return new hs(_0x3ac700);}['node'](){return this['node_'];}}class us{constructor(_0xaf5f4e,_0x560221){this['syncTree_']=_0xaf5f4e,this['path_']=_0x560221;}['getImmediateChild'](_0x20f426){const _0x1f2081=k(this['path_'],_0x20f426);return new us(this['syncTree_'],_0x1f2081);}['node'](){return Fn(this['syncTree_'],this['path_']);}}const id=function(_0x1a6a6e){return _0x1a6a6e=_0x1a6a6e||{},_0x1a6a6e['timestamp']=_0x1a6a6e['timestamp']||new Date()['getTime'](),_0x1a6a6e;},gr=function(_0x593c7a,_0x4b5782,_0x131dcc){if(!_0x593c7a||typeof _0x593c7a!='object')return _0x593c7a;if(f('.sv'in _0x593c7a,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x593c7a['.sv']=='string')return sd(_0x593c7a['.sv'],_0x4b5782,_0x131dcc);if(typeof _0x593c7a['.sv']=='object')return rd(_0x593c7a['.sv'],_0x4b5782);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x593c7a,null,0x2));},sd=function(_0x2bc19d,_0x3d3ea6,_0x4e7b4a){switch(_0x2bc19d){case'timestamp':return _0x4e7b4a['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x2bc19d);}},rd=function(_0x2f1a23,_0x53c7b0,_0x45ed53){_0x2f1a23['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x2f1a23,null,0x2));const _0x344272=_0x2f1a23['increment'];typeof _0x344272!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x344272);const _0x430b38=_0x53c7b0['node']();if(f(_0x430b38!==null&&typeof _0x430b38<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0x430b38['isLeafNode']())return _0x344272;const _0x5c1849=_0x430b38['getValue']();return typeof _0x5c1849!='number'?_0x344272:_0x5c1849+_0x344272;},na=function(_0x32f1bd,_0x5313e6,_0x337a5e,_0x19ffac){return fs(_0x5313e6,new us(_0x337a5e,_0x32f1bd),_0x19ffac);},ds=function(_0x8be1cd,_0x170a42,_0x28ff57){return fs(_0x8be1cd,new hs(_0x170a42),_0x28ff57);};function fs(_0x251357,_0xd675f0,_0x49236e){const _0x5c6b27=_0x251357['getPriority']()['val'](),_0x3c2a9c=gr(_0x5c6b27,_0xd675f0['getImmediateChild']('.priority'),_0x49236e);let _0x599262;if(_0x251357['isLeafNode']()){const _0x445106=_0x251357,_0x197874=gr(_0x445106['getValue'](),_0xd675f0,_0x49236e);return _0x197874!==_0x445106['getValue']()||_0x3c2a9c!==_0x445106['getPriority']()['val']()?new D(_0x197874,P(_0x3c2a9c)):_0x251357;}else{const _0x185e4e=_0x251357;return _0x599262=_0x185e4e,_0x3c2a9c!==_0x185e4e['getPriority']()['val']()&&(_0x599262=_0x599262['updatePriority'](new D(_0x3c2a9c))),_0x185e4e['forEachChild'](R,(_0x5cd0e3,_0x4cd8e6)=>{const _0x3d18f1=fs(_0x4cd8e6,_0xd675f0['getImmediateChild'](_0x5cd0e3),_0x49236e);_0x3d18f1!==_0x4cd8e6&&(_0x599262=_0x599262['updateImmediateChild'](_0x5cd0e3,_0x3d18f1));}),_0x599262;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ps{constructor(_0xcbe606='',_0x5a6d9b=null,_0x4871b7={'children':{},'childCount':0x0}){this['name']=_0xcbe606,this['parent']=_0x5a6d9b,this['node']=_0x4871b7;}}function Wn(_0x5d5d7e,_0x50d17b){let _0x5b78da=_0x50d17b instanceof C?_0x50d17b:new C(_0x50d17b),_0x3785e2=_0x5d5d7e,_0x41477c=y(_0x5b78da);for(;_0x41477c!==null;){const _0x2614c6=De(_0x3785e2['node']['children'],_0x41477c)||{'children':{},'childCount':0x0};_0x3785e2=new ps(_0x41477c,_0x3785e2,_0x2614c6),_0x5b78da=b(_0x5b78da),_0x41477c=y(_0x5b78da);}return _0x3785e2;}function Ge(_0x4999a0){return _0x4999a0['node']['value'];}function _s(_0x1339fb,_0x17ad8b){_0x1339fb['node']['value']=_0x17ad8b,Ai(_0x1339fb);}function ia(_0x2ac0db){return _0x2ac0db['node']['childCount']>0x0;}function od(_0x361803){return Ge(_0x361803)===void 0x0&&!ia(_0x361803);}function Bn(_0x1f65e1,_0x2e8702){x(_0x1f65e1['node']['children'],(_0x4713d7,_0x36a032)=>{_0x2e8702(new ps(_0x4713d7,_0x1f65e1,_0x36a032));});}function sa(_0xc21a99,_0x438d59,_0x37dced,_0x335bb6){_0x37dced&&_0x438d59(_0xc21a99),Bn(_0xc21a99,_0x5406c5=>{sa(_0x5406c5,_0x438d59,!0x0);});}function ad(_0x1f53ca,_0x5144a5,_0x8184b0){let _0x431cd1=_0x1f53ca['parent'];for(;_0x431cd1!==null;){if(_0x5144a5(_0x431cd1))return!0x0;_0x431cd1=_0x431cd1['parent'];}return!0x1;}function qt(_0x2fa86d){return new C(_0x2fa86d['parent']===null?_0x2fa86d['name']:qt(_0x2fa86d['parent'])+'/'+_0x2fa86d['name']);}function Ai(_0x4cc808){_0x4cc808['parent']!==null&&cd(_0x4cc808['parent'],_0x4cc808['name'],_0x4cc808);}function cd(_0x3a65cf,_0x50b76c,_0x4f5c36){const _0x137f21=od(_0x4f5c36),_0x55f421=J(_0x3a65cf['node']['children'],_0x50b76c);_0x137f21&&_0x55f421?(delete _0x3a65cf['node']['children'][_0x50b76c],_0x3a65cf['node']['childCount']--,Ai(_0x3a65cf)):!_0x137f21&&!_0x55f421&&(_0x3a65cf['node']['children'][_0x50b76c]=_0x4f5c36['node'],_0x3a65cf['node']['childCount']++,Ai(_0x3a65cf));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ai=0xa*0x400*0x400,gs=function(_0x5194c4){return typeof _0x5194c4=='string'&&_0x5194c4['length']!==0x0&&!ld['test'](_0x5194c4);},ra=function(_0x4af83e){return typeof _0x4af83e=='string'&&_0x4af83e['length']!==0x0&&!hd['test'](_0x4af83e);},ud=function(_0x368655){return _0x368655&&(_0x368655=_0x368655['replace'](/^\/*\.info(\/|$)/,'/')),ra(_0x368655);},Tn=function(_0x4c3b52){return _0x4c3b52===null||typeof _0x4c3b52=='string'||typeof _0x4c3b52=='number'&&!Vi(_0x4c3b52)||_0x4c3b52&&typeof _0x4c3b52=='object'&&J(_0x4c3b52,'.sv');},zt=function(_0x2911cb,_0x44f50b,_0x23fc08,_0x4fa714){_0x4fa714&&_0x44f50b===void 0x0||jt(Pn(_0x2911cb,'value'),_0x44f50b,_0x23fc08);},jt=function(_0x36c683,_0x8d5030,_0x165511){const _0x2dc954=_0x165511 instanceof C?new Ah(_0x165511,_0x36c683):_0x165511;if(_0x8d5030===void 0x0)throw new Error(_0x36c683+'contains\x20undefined\x20'+Pe(_0x2dc954));if(typeof _0x8d5030=='function')throw new Error(_0x36c683+'contains\x20a\x20function\x20'+Pe(_0x2dc954)+'\x20with\x20contents\x20=\x20'+_0x8d5030['toString']());if(Vi(_0x8d5030))throw new Error(_0x36c683+'contains\x20'+_0x8d5030['toString']()+'\x20'+Pe(_0x2dc954));if(typeof _0x8d5030=='string'&&_0x8d5030['length']>ai/0x3&&On(_0x8d5030)>ai)throw new Error(_0x36c683+'contains\x20a\x20string\x20greater\x20than\x20'+ai+'\x20utf8\x20bytes\x20'+Pe(_0x2dc954)+'\x20(\x27'+_0x8d5030['substring'](0x0,0x32)+'...\x27)');if(_0x8d5030&&typeof _0x8d5030=='object'){let _0x41a82c=!0x1,_0x2e8f76=!0x1;if(x(_0x8d5030,(_0x3e30b2,_0x3527fc)=>{if(_0x3e30b2==='.value')_0x41a82c=!0x0;else{if(_0x3e30b2!=='.priority'&&_0x3e30b2!=='.sv'&&(_0x2e8f76=!0x0,!gs(_0x3e30b2)))throw new Error(_0x36c683+'\x20contains\x20an\x20invalid\x20key\x20('+_0x3e30b2+')\x20'+Pe(_0x2dc954)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x2dc954,_0x3e30b2),jt(_0x36c683,_0x3527fc,_0x2dc954),Nh(_0x2dc954);}),_0x41a82c&&_0x2e8f76)throw new Error(_0x36c683+'\x20contains\x20\x22.value\x22\x20child\x20'+Pe(_0x2dc954)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x5e336f,_0x5a3bbb){let _0x3be56a,_0xdd1204;for(_0x3be56a=0x0;_0x3be56a<_0x5a3bbb['length'];_0x3be56a++){_0xdd1204=_0x5a3bbb[_0x3be56a];const _0x4b359b=Pt(_0xdd1204);for(let _0x3885ce=0x0;_0x3885ce<_0x4b359b['length'];_0x3885ce++)if(!(_0x4b359b[_0x3885ce]==='.priority'&&_0x3885ce===_0x4b359b['length']-0x1)){if(!gs(_0x4b359b[_0x3885ce]))throw new Error(_0x5e336f+'contains\x20an\x20invalid\x20key\x20('+_0x4b359b[_0x3885ce]+')\x20in\x20path\x20'+_0xdd1204['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x5a3bbb['sort'](Rh);let _0x43a194=null;for(_0x3be56a=0x0;_0x3be56a<_0x5a3bbb['length'];_0x3be56a++){if(_0xdd1204=_0x5a3bbb[_0x3be56a],_0x43a194!==null&&G(_0x43a194,_0xdd1204))throw new Error(_0x5e336f+'contains\x20a\x20path\x20'+_0x43a194['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0xdd1204['toString']());_0x43a194=_0xdd1204;}},fd=function(_0x3a5d8b,_0x517a31,_0x2d1bc6,_0x260aa6){const _0x4d9ce3=Pn(_0x3a5d8b,'values');if(!(_0x517a31&&typeof _0x517a31=='object')||Array['isArray'](_0x517a31))throw new Error(_0x4d9ce3+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x4ecd3d=[];x(_0x517a31,(_0x4bbabb,_0x318b78)=>{const _0x40423d=new C(_0x4bbabb);if(jt(_0x4d9ce3,_0x318b78,k(_0x2d1bc6,_0x40423d)),zi(_0x40423d)==='.priority'&&!Tn(_0x318b78))throw new Error(_0x4d9ce3+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x40423d['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x4ecd3d['push'](_0x40423d);}),dd(_0x4d9ce3,_0x4ecd3d);},ms=function(_0xf4c41,_0x2f3e8d,_0x5f10cd,_0x2e2be6){if(!ra(_0x5f10cd))throw new Error(Pn(_0xf4c41,_0x2f3e8d)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x5f10cd+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x6ed477,_0x1cef6a,_0x5c22dd,_0x381ddb){_0x5c22dd&&(_0x5c22dd=_0x5c22dd['replace'](/^\/*\.info(\/|$)/,'/')),ms(_0x6ed477,_0x1cef6a,_0x5c22dd);},ys=function(_0x2606c6,_0x4a5eb8){if(y(_0x4a5eb8)==='.info')throw new Error(_0x2606c6+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x41269b,_0x179209){const _0x12e4d3=_0x179209['path']['toString']();if(typeof _0x179209['repoInfo']['host']!='string'||_0x179209['repoInfo']['host']['length']===0x0||!gs(_0x179209['repoInfo']['namespace'])&&_0x179209['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0x12e4d3['length']!==0x0&&!ud(_0x12e4d3))throw new Error(Pn(_0x41269b,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Vn(_0xc1313a,_0x392ac2){let _0x4e355c=null;for(let _0x4ad272=0x0;_0x4ad272<_0x392ac2['length'];_0x4ad272++){const _0x4b1821=_0x392ac2[_0x4ad272],_0x144589=_0x4b1821['getPath']();_0x4e355c!==null&&!ji(_0x144589,_0x4e355c['path'])&&(_0xc1313a['eventLists_']['push'](_0x4e355c),_0x4e355c=null),_0x4e355c===null&&(_0x4e355c={'events':[],'path':_0x144589}),_0x4e355c['events']['push'](_0x4b1821);}_0x4e355c&&_0xc1313a['eventLists_']['push'](_0x4e355c);}function oa(_0x10e602,_0x15ae60,_0x47a402){Vn(_0x10e602,_0x47a402),aa(_0x10e602,_0x2dad2b=>ji(_0x2dad2b,_0x15ae60));}function H(_0x3836e6,_0x5125b2,_0x3890ed){Vn(_0x3836e6,_0x3890ed),aa(_0x3836e6,_0x43673c=>G(_0x43673c,_0x5125b2)||G(_0x5125b2,_0x43673c));}function aa(_0x422eaf,_0x1aa795){_0x422eaf['recursionDepth_']++;let _0x3cf9bc=!0x0;for(let _0x240b37=0x0;_0x240b37<_0x422eaf['eventLists_']['length'];_0x240b37++){const _0x274e31=_0x422eaf['eventLists_'][_0x240b37];if(_0x274e31){const _0x5ef811=_0x274e31['path'];_0x1aa795(_0x5ef811)?(md(_0x422eaf['eventLists_'][_0x240b37]),_0x422eaf['eventLists_'][_0x240b37]=null):_0x3cf9bc=!0x1;}}_0x3cf9bc&&(_0x422eaf['eventLists_']=[]),_0x422eaf['recursionDepth_']--;}function md(_0x594c1f){for(let _0x2528ce=0x0;_0x2528ce<_0x594c1f['events']['length'];_0x2528ce++){const _0x35fcf4=_0x594c1f['events'][_0x2528ce];if(_0x35fcf4!==null){_0x594c1f['events'][_0x2528ce]=null;const _0x41432a=_0x35fcf4['getEventRunner']();wt&&L('event:\x20'+_0x35fcf4['toString']()),ht(_0x41432a);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x2a0e2b,_0x8a21ca,_0x5f0ba5,_0x434603){this['repoInfo_']=_0x2a0e2b,this['forceRestClient_']=_0x8a21ca,this['authTokenProvider_']=_0x5f0ba5,this['appCheckProvider_']=_0x434603,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=_n(),this['transactionQueueTree_']=new ps(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x171e38,_0x7e8a58,_0x574815){if(_0x171e38['stats_']=Gi(_0x171e38['repoInfo_']),_0x171e38['forceRestClient_']||Xl())_0x171e38['server_']=new pn(_0x171e38['repoInfo_'],(_0x2fbc45,_0x638fc0,_0x23c39c,_0x49e483)=>{mr(_0x171e38,_0x2fbc45,_0x638fc0,_0x23c39c,_0x49e483);},_0x171e38['authTokenProvider_'],_0x171e38['appCheckProvider_']),setTimeout(()=>yr(_0x171e38,!0x0),0x0);else{if(typeof _0x574815<'u'&&_0x574815!==null){if(typeof _0x574815!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x574815);}catch(_0xa224c6){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0xa224c6);}}_0x171e38['persistentConnection_']=new se(_0x171e38['repoInfo_'],_0x7e8a58,(_0x28ed13,_0x4214cd,_0x30c526,_0x1f12c8)=>{mr(_0x171e38,_0x28ed13,_0x4214cd,_0x30c526,_0x1f12c8);},_0xbbb067=>{yr(_0x171e38,_0xbbb067);},_0x10546a=>{Id(_0x171e38,_0x10546a);},_0x171e38['authTokenProvider_'],_0x171e38['appCheckProvider_'],_0x574815),_0x171e38['server_']=_0x171e38['persistentConnection_'];}_0x171e38['authTokenProvider_']['addTokenChangeListener'](_0x467232=>{_0x171e38['server_']['refreshAuthToken'](_0x467232);}),_0x171e38['appCheckProvider_']['addTokenChangeListener'](_0x16614d=>{_0x171e38['server_']['refreshAppCheckToken'](_0x16614d['token']);}),_0x171e38['statsReporter_']=ih(_0x171e38['repoInfo_'],()=>new iu(_0x171e38['stats_'],_0x171e38['server_'])),_0x171e38['infoData_']=new Xh(),_0x171e38['infoSyncTree_']=new _r({'startListening':(_0x17f08d,_0x121d98,_0x3aebbd,_0xe639e1)=>{let _0x1d5ed8=[];const _0x14490a=_0x171e38['infoData_']['getNode'](_0x17f08d['_path']);return _0x14490a['isEmpty']()||(_0x1d5ed8=Gt(_0x171e38['infoSyncTree_'],_0x17f08d['_path'],_0x14490a),setTimeout(()=>{_0xe639e1('ok');},0x0)),_0x1d5ed8;},'stopListening':()=>{}}),vs(_0x171e38,'connected',!0x1),_0x171e38['serverSyncTree_']=new _r({'startListening':(_0xfbb8f6,_0x4a325f,_0x4c6b74,_0x6789e9)=>(_0x171e38['server_']['listen'](_0xfbb8f6,_0x4c6b74,_0x4a325f,(_0x190dd5,_0x46e5cd)=>{const _0xa52631=_0x6789e9(_0x190dd5,_0x46e5cd);H(_0x171e38['eventQueue_'],_0xfbb8f6['_path'],_0xa52631);}),[]),'stopListening':(_0x2509f9,_0x358c9e)=>{_0x171e38['server_']['unlisten'](_0x2509f9,_0x358c9e);}});}function la(_0x39a52b){const _0x5ec712=_0x39a52b['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x5ec712;}function Kt(_0x1620a6){return id({'timestamp':la(_0x1620a6)});}function mr(_0x116624,_0x2126c2,_0x4969dd,_0x5ebbba,_0x445109){_0x116624['dataUpdateCount']++;const _0x2304d6=new C(_0x2126c2);_0x4969dd=_0x116624['interceptServerDataCallback_']?_0x116624['interceptServerDataCallback_'](_0x2126c2,_0x4969dd):_0x4969dd;let _0x4e919d=[];if(_0x445109){if(_0x5ebbba){const _0x520a29=hn(_0x4969dd,_0x29e834=>P(_0x29e834));_0x4e919d=Ju(_0x116624['serverSyncTree_'],_0x2304d6,_0x520a29,_0x445109);}else{const _0x465234=P(_0x4969dd);_0x4e919d=Xo(_0x116624['serverSyncTree_'],_0x2304d6,_0x465234,_0x445109);}}else{if(_0x5ebbba){const _0x5bd189=hn(_0x4969dd,_0x38b742=>P(_0x38b742));_0x4e919d=Ku(_0x116624['serverSyncTree_'],_0x2304d6,_0x5bd189);}else{const _0x59de44=P(_0x4969dd);_0x4e919d=Gt(_0x116624['serverSyncTree_'],_0x2304d6,_0x59de44);}}let _0x412da5=_0x2304d6;_0x4e919d['length']>0x0&&(_0x412da5=it(_0x116624,_0x2304d6)),H(_0x116624['eventQueue_'],_0x412da5,_0x4e919d);}function yr(_0x228e69,_0x53e0c6){vs(_0x228e69,'connected',_0x53e0c6),_0x53e0c6===!0x1&&Sd(_0x228e69);}function Id(_0x514ce0,_0x857ae1){x(_0x857ae1,(_0x5325c5,_0x5ae94b)=>{vs(_0x514ce0,_0x5325c5,_0x5ae94b);});}function vs(_0x5f2a43,_0x133eca,_0x57f495){const _0x2f3fdc=new C('/.info/'+_0x133eca),_0x336611=P(_0x57f495);_0x5f2a43['infoData_']['updateSnapshot'](_0x2f3fdc,_0x336611);const _0x4236d1=Gt(_0x5f2a43['infoSyncTree_'],_0x2f3fdc,_0x336611);H(_0x5f2a43['eventQueue_'],_0x2f3fdc,_0x4236d1);}function Hn(_0x32a0fc){return _0x32a0fc['nextWriteId_']++;}function wd(_0x2d9728,_0x21848d,_0x1aa67f){const _0x53f7e7=Xu(_0x2d9728['serverSyncTree_'],_0x21848d);return _0x53f7e7!=null?Promise['resolve'](_0x53f7e7):_0x2d9728['server_']['get'](_0x21848d)['then'](_0x1a47b1=>{const _0x583496=P(_0x1a47b1)['withIndex'](_0x21848d['_queryParams']['getIndex']());Ri(_0x2d9728['serverSyncTree_'],_0x21848d,_0x1aa67f,!0x0);let _0x16008d;if(_0x21848d['_queryParams']['loadsAllData']())_0x16008d=Gt(_0x2d9728['serverSyncTree_'],_0x21848d['_path'],_0x583496);else{const _0x34f745=xt(_0x2d9728['serverSyncTree_'],_0x21848d);_0x16008d=Xo(_0x2d9728['serverSyncTree_'],_0x21848d['_path'],_0x583496,_0x34f745);}return H(_0x2d9728['eventQueue_'],_0x21848d['_path'],_0x16008d),Cn(_0x2d9728['serverSyncTree_'],_0x21848d,_0x1aa67f,null,!0x0),_0x583496;},_0x34b62c=>(dt(_0x2d9728,'get\x20for\x20query\x20'+O(_0x21848d)+'\x20failed:\x20'+_0x34b62c),Promise['reject'](new Error(_0x34b62c))));}function Cd(_0x2d8a2a,_0x24480a,_0x547928,_0x564674,_0x43d2f0){dt(_0x2d8a2a,'set',{'path':_0x24480a['toString'](),'value':_0x547928,'priority':_0x564674});const _0x2ee601=Kt(_0x2d8a2a),_0x5dda5b=P(_0x547928,_0x564674),_0x40c81a=Fn(_0x2d8a2a['serverSyncTree_'],_0x24480a),_0x4bbf14=ds(_0x5dda5b,_0x40c81a,_0x2ee601),_0x2fbf43=Hn(_0x2d8a2a),_0x4a0c28=os(_0x2d8a2a['serverSyncTree_'],_0x24480a,_0x4bbf14,_0x2fbf43,!0x0);Vn(_0x2d8a2a['eventQueue_'],_0x4a0c28),_0x2d8a2a['server_']['put'](_0x24480a['toString'](),_0x5dda5b['val'](!0x0),(_0x226c15,_0x280b97)=>{const _0x33d462=_0x226c15==='ok';_0x33d462||U('set\x20at\x20'+_0x24480a+'\x20failed:\x20'+_0x226c15);const _0x260d97=pe(_0x2d8a2a['serverSyncTree_'],_0x2fbf43,!_0x33d462);H(_0x2d8a2a['eventQueue_'],_0x24480a,_0x260d97),ki(_0x2d8a2a,_0x43d2f0,_0x226c15,_0x280b97);});const _0x56b47a=Is(_0x2d8a2a,_0x24480a);it(_0x2d8a2a,_0x56b47a),H(_0x2d8a2a['eventQueue_'],_0x56b47a,[]);}function Td(_0x7e36df,_0x504bd2,_0x47669b,_0xeefe3b){dt(_0x7e36df,'update',{'path':_0x504bd2['toString'](),'value':_0x47669b});let _0x524f32=!0x0;const _0x42f37f=Kt(_0x7e36df),_0x2a4b52={};if(x(_0x47669b,(_0x4f3e52,_0x2c7dae)=>{_0x524f32=!0x1,_0x2a4b52[_0x4f3e52]=na(k(_0x504bd2,_0x4f3e52),P(_0x2c7dae),_0x7e36df['serverSyncTree_'],_0x42f37f);}),_0x524f32)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),ki(_0x7e36df,_0xeefe3b,'ok',void 0x0);else{const _0x12c4ca=Hn(_0x7e36df),_0x196b2e=ju(_0x7e36df['serverSyncTree_'],_0x504bd2,_0x2a4b52,_0x12c4ca);Vn(_0x7e36df['eventQueue_'],_0x196b2e),_0x7e36df['server_']['merge'](_0x504bd2['toString'](),_0x47669b,(_0x38ef64,_0x11f92b)=>{const _0x431ba5=_0x38ef64==='ok';_0x431ba5||U('update\x20at\x20'+_0x504bd2+'\x20failed:\x20'+_0x38ef64);const _0x579a6d=pe(_0x7e36df['serverSyncTree_'],_0x12c4ca,!_0x431ba5),_0x35c539=_0x579a6d['length']>0x0?it(_0x7e36df,_0x504bd2):_0x504bd2;H(_0x7e36df['eventQueue_'],_0x35c539,_0x579a6d),ki(_0x7e36df,_0xeefe3b,_0x38ef64,_0x11f92b);}),x(_0x47669b,_0x85140a=>{const _0xc46d05=Is(_0x7e36df,k(_0x504bd2,_0x85140a));it(_0x7e36df,_0xc46d05);}),H(_0x7e36df['eventQueue_'],_0x504bd2,[]);}}function Sd(_0x25fe0f){dt(_0x25fe0f,'onDisconnectEvents');const _0x22e2e9=Kt(_0x25fe0f),_0x11f163=_n();Ii(_0x25fe0f['onDisconnect_'],w(),(_0x2ec8ec,_0x4cda02)=>{const _0x59f80d=na(_0x2ec8ec,_0x4cda02,_0x25fe0f['serverSyncTree_'],_0x22e2e9);Fo(_0x11f163,_0x2ec8ec,_0x59f80d);});let _0x5316a8=[];Ii(_0x11f163,w(),(_0x5cb0ff,_0x2c2311)=>{_0x5316a8=_0x5316a8['concat'](Gt(_0x25fe0f['serverSyncTree_'],_0x5cb0ff,_0x2c2311));const _0x448f35=Is(_0x25fe0f,_0x5cb0ff);it(_0x25fe0f,_0x448f35);}),_0x25fe0f['onDisconnect_']=_n(),H(_0x25fe0f['eventQueue_'],w(),_0x5316a8);}function bd(_0x17c20b,_0x526ed6,_0x5c351d){let _0x1912ff;y(_0x526ed6['_path'])==='.info'?_0x1912ff=Ri(_0x17c20b['infoSyncTree_'],_0x526ed6,_0x5c351d):_0x1912ff=Ri(_0x17c20b['serverSyncTree_'],_0x526ed6,_0x5c351d),oa(_0x17c20b['eventQueue_'],_0x526ed6['_path'],_0x1912ff);}function Rd(_0x1669d7,_0x2fa22f,_0x470dd8){let _0x394512;y(_0x2fa22f['_path'])==='.info'?_0x394512=Cn(_0x1669d7['infoSyncTree_'],_0x2fa22f,_0x470dd8):_0x394512=Cn(_0x1669d7['serverSyncTree_'],_0x2fa22f,_0x470dd8),oa(_0x1669d7['eventQueue_'],_0x2fa22f['_path'],_0x394512);}function ha(_0x44cb2d){_0x44cb2d['persistentConnection_']&&_0x44cb2d['persistentConnection_']['interrupt'](ca);}function Ad(_0x5673f3){_0x5673f3['persistentConnection_']&&_0x5673f3['persistentConnection_']['resume'](ca);}function dt(_0x2118d4,..._0x50c9af){let _0x4fa80d='';_0x2118d4['persistentConnection_']&&(_0x4fa80d=_0x2118d4['persistentConnection_']['id']+':'),L(_0x4fa80d,..._0x50c9af);}function ki(_0x452f00,_0x1bd00b,_0x5df90c,_0x490213){_0x1bd00b&&ht(()=>{if(_0x5df90c==='ok')_0x1bd00b(null);else{const _0xf2e85a=(_0x5df90c||'error')['toUpperCase']();let _0x2b0f13=_0xf2e85a;_0x490213&&(_0x2b0f13+=':\x20'+_0x490213);const _0xd134ac=new Error(_0x2b0f13);_0xd134ac['code']=_0xf2e85a,_0x1bd00b(_0xd134ac);}});}function kd(_0x15f1d3,_0x2cff21,_0x505633,_0x1642bd,_0x35c466,_0x1e9eb5){dt(_0x15f1d3,'transaction\x20on\x20'+_0x2cff21);const _0xede35b={'path':_0x2cff21,'update':_0x505633,'onComplete':_0x1642bd,'status':null,'order':so(),'applyLocally':_0x1e9eb5,'retryCount':0x0,'unwatcher':_0x35c466,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x5a9af8=Es(_0x15f1d3,_0x2cff21,void 0x0);_0xede35b['currentInputSnapshot']=_0x5a9af8;const _0x591555=_0xede35b['update'](_0x5a9af8['val']());if(_0x591555===void 0x0)_0xede35b['unwatcher'](),_0xede35b['currentOutputSnapshotRaw']=null,_0xede35b['currentOutputSnapshotResolved']=null,_0xede35b['onComplete']&&_0xede35b['onComplete'](null,!0x1,_0xede35b['currentInputSnapshot']);else{jt('transaction\x20failed:\x20Data\x20returned\x20',_0x591555,_0xede35b['path']),_0xede35b['status']=0x0;const _0x41c912=Wn(_0x15f1d3['transactionQueueTree_'],_0x2cff21),_0x11abb1=Ge(_0x41c912)||[];_0x11abb1['push'](_0xede35b),_s(_0x41c912,_0x11abb1);let _0x4cf30f;typeof _0x591555=='object'&&_0x591555!==null&&J(_0x591555,'.priority')?(_0x4cf30f=De(_0x591555,'.priority'),f(Tn(_0x4cf30f),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x4cf30f=(Fn(_0x15f1d3['serverSyncTree_'],_0x2cff21)||g['EMPTY_NODE'])['getPriority']()['val']();const _0xc6bb30=Kt(_0x15f1d3),_0x43be7b=P(_0x591555,_0x4cf30f),_0x3bd6f4=ds(_0x43be7b,_0x5a9af8,_0xc6bb30);_0xede35b['currentOutputSnapshotRaw']=_0x43be7b,_0xede35b['currentOutputSnapshotResolved']=_0x3bd6f4,_0xede35b['currentWriteId']=Hn(_0x15f1d3);const _0x20dcec=os(_0x15f1d3['serverSyncTree_'],_0x2cff21,_0x3bd6f4,_0xede35b['currentWriteId'],_0xede35b['applyLocally']);H(_0x15f1d3['eventQueue_'],_0x2cff21,_0x20dcec),$n(_0x15f1d3,_0x15f1d3['transactionQueueTree_']);}}function Es(_0x526fbf,_0x5485eb,_0x1d8110){return Fn(_0x526fbf['serverSyncTree_'],_0x5485eb,_0x1d8110)||g['EMPTY_NODE'];}function $n(_0x4385ab,_0x30e6e1=_0x4385ab['transactionQueueTree_']){if(_0x30e6e1||Gn(_0x4385ab,_0x30e6e1),Ge(_0x30e6e1)){const _0x3ff21b=da(_0x4385ab,_0x30e6e1);f(_0x3ff21b['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x3ff21b['every'](_0x31ed26=>_0x31ed26['status']===0x0)&&Nd(_0x4385ab,qt(_0x30e6e1),_0x3ff21b);}else ia(_0x30e6e1)&&Bn(_0x30e6e1,_0x17905f=>{$n(_0x4385ab,_0x17905f);});}function Nd(_0x5b9ec1,_0x3bcd1d,_0x592b3f){const _0x19da7f=_0x592b3f['map'](_0x14a3e0=>_0x14a3e0['currentWriteId']),_0x56f04d=Es(_0x5b9ec1,_0x3bcd1d,_0x19da7f);let _0x3a4861=_0x56f04d;const _0x3609b5=_0x56f04d['hash']();for(let _0x2b9f7e=0x0;_0x2b9f7e<_0x592b3f['length'];_0x2b9f7e++){const _0x66ed5e=_0x592b3f[_0x2b9f7e];f(_0x66ed5e['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x66ed5e['status']=0x1,_0x66ed5e['retryCount']++;const _0x38dacb=F(_0x3bcd1d,_0x66ed5e['path']);_0x3a4861=_0x3a4861['updateChild'](_0x38dacb,_0x66ed5e['currentOutputSnapshotRaw']);}const _0x5bf832=_0x3a4861['val'](!0x0),_0x3317ba=_0x3bcd1d;_0x5b9ec1['server_']['put'](_0x3317ba['toString'](),_0x5bf832,_0x1fe007=>{dt(_0x5b9ec1,'transaction\x20put\x20response',{'path':_0x3317ba['toString'](),'status':_0x1fe007});let _0x19ef85=[];if(_0x1fe007==='ok'){const _0x594e62=[];for(let _0xcfb4d5=0x0;_0xcfb4d5<_0x592b3f['length'];_0xcfb4d5++)_0x592b3f[_0xcfb4d5]['status']=0x2,_0x19ef85=_0x19ef85['concat'](pe(_0x5b9ec1['serverSyncTree_'],_0x592b3f[_0xcfb4d5]['currentWriteId'])),_0x592b3f[_0xcfb4d5]['onComplete']&&_0x594e62['push'](()=>_0x592b3f[_0xcfb4d5]['onComplete'](null,!0x0,_0x592b3f[_0xcfb4d5]['currentOutputSnapshotResolved'])),_0x592b3f[_0xcfb4d5]['unwatcher']();Gn(_0x5b9ec1,Wn(_0x5b9ec1['transactionQueueTree_'],_0x3bcd1d)),$n(_0x5b9ec1,_0x5b9ec1['transactionQueueTree_']),H(_0x5b9ec1['eventQueue_'],_0x3bcd1d,_0x19ef85);for(let _0x272c81=0x0;_0x272c81<_0x594e62['length'];_0x272c81++)ht(_0x594e62[_0x272c81]);}else{if(_0x1fe007==='datastale'){for(let _0x286a4d=0x0;_0x286a4d<_0x592b3f['length'];_0x286a4d++)_0x592b3f[_0x286a4d]['status']===0x3?_0x592b3f[_0x286a4d]['status']=0x4:_0x592b3f[_0x286a4d]['status']=0x0;}else{U('transaction\x20at\x20'+_0x3317ba['toString']()+'\x20failed:\x20'+_0x1fe007);for(let _0x169a38=0x0;_0x169a38<_0x592b3f['length'];_0x169a38++)_0x592b3f[_0x169a38]['status']=0x4,_0x592b3f[_0x169a38]['abortReason']=_0x1fe007;}it(_0x5b9ec1,_0x3bcd1d);}},_0x3609b5);}function it(_0x3ffca1,_0x280cd9){const _0x23a345=ua(_0x3ffca1,_0x280cd9),_0x2717fb=qt(_0x23a345),_0x3cd6bc=da(_0x3ffca1,_0x23a345);return Pd(_0x3ffca1,_0x3cd6bc,_0x2717fb),_0x2717fb;}function Pd(_0x1b6232,_0xc144f6,_0x456ec0){if(_0xc144f6['length']===0x0)return;const _0x3c4c22=[];let _0x1f59ea=[];const _0x3ba723=_0xc144f6['filter'](_0x4eb04f=>_0x4eb04f['status']===0x0)['map'](_0x477d8c=>_0x477d8c['currentWriteId']);for(let _0x552127=0x0;_0x552127<_0xc144f6['length'];_0x552127++){const _0x142039=_0xc144f6[_0x552127],_0x3f13ec=F(_0x456ec0,_0x142039['path']);let _0x22f6dd=!0x1,_0x284b05;if(f(_0x3f13ec!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x142039['status']===0x4)_0x22f6dd=!0x0,_0x284b05=_0x142039['abortReason'],_0x1f59ea=_0x1f59ea['concat'](pe(_0x1b6232['serverSyncTree_'],_0x142039['currentWriteId'],!0x0));else{if(_0x142039['status']===0x0){if(_0x142039['retryCount']>=yd)_0x22f6dd=!0x0,_0x284b05='maxretry',_0x1f59ea=_0x1f59ea['concat'](pe(_0x1b6232['serverSyncTree_'],_0x142039['currentWriteId'],!0x0));else{const _0x3261cf=Es(_0x1b6232,_0x142039['path'],_0x3ba723);_0x142039['currentInputSnapshot']=_0x3261cf;const _0x527414=_0xc144f6[_0x552127]['update'](_0x3261cf['val']());if(_0x527414!==void 0x0){jt('transaction\x20failed:\x20Data\x20returned\x20',_0x527414,_0x142039['path']);let _0xce89a7=P(_0x527414);typeof _0x527414=='object'&&_0x527414!=null&&J(_0x527414,'.priority')||(_0xce89a7=_0xce89a7['updatePriority'](_0x3261cf['getPriority']()));const _0x567c36=_0x142039['currentWriteId'],_0x228a40=Kt(_0x1b6232),_0xa852e3=ds(_0xce89a7,_0x3261cf,_0x228a40);_0x142039['currentOutputSnapshotRaw']=_0xce89a7,_0x142039['currentOutputSnapshotResolved']=_0xa852e3,_0x142039['currentWriteId']=Hn(_0x1b6232),_0x3ba723['splice'](_0x3ba723['indexOf'](_0x567c36),0x1),_0x1f59ea=_0x1f59ea['concat'](os(_0x1b6232['serverSyncTree_'],_0x142039['path'],_0xa852e3,_0x142039['currentWriteId'],_0x142039['applyLocally'])),_0x1f59ea=_0x1f59ea['concat'](pe(_0x1b6232['serverSyncTree_'],_0x567c36,!0x0));}else _0x22f6dd=!0x0,_0x284b05='nodata',_0x1f59ea=_0x1f59ea['concat'](pe(_0x1b6232['serverSyncTree_'],_0x142039['currentWriteId'],!0x0));}}}H(_0x1b6232['eventQueue_'],_0x456ec0,_0x1f59ea),_0x1f59ea=[],_0x22f6dd&&(_0xc144f6[_0x552127]['status']=0x2,function(_0x236446){setTimeout(_0x236446,Math['floor'](0x0));}(_0xc144f6[_0x552127]['unwatcher']),_0xc144f6[_0x552127]['onComplete']&&(_0x284b05==='nodata'?_0x3c4c22['push'](()=>_0xc144f6[_0x552127]['onComplete'](null,!0x1,_0xc144f6[_0x552127]['currentInputSnapshot'])):_0x3c4c22['push'](()=>_0xc144f6[_0x552127]['onComplete'](new Error(_0x284b05),!0x1,null))));}Gn(_0x1b6232,_0x1b6232['transactionQueueTree_']);for(let _0x3eb95c=0x0;_0x3eb95c<_0x3c4c22['length'];_0x3eb95c++)ht(_0x3c4c22[_0x3eb95c]);$n(_0x1b6232,_0x1b6232['transactionQueueTree_']);}function ua(_0xbb5465,_0x58345e){let _0x39038,_0xb5f338=_0xbb5465['transactionQueueTree_'];for(_0x39038=y(_0x58345e);_0x39038!==null&&Ge(_0xb5f338)===void 0x0;)_0xb5f338=Wn(_0xb5f338,_0x39038),_0x58345e=b(_0x58345e),_0x39038=y(_0x58345e);return _0xb5f338;}function da(_0x4b5687,_0x2c887f){const _0x4cfd7f=[];return fa(_0x4b5687,_0x2c887f,_0x4cfd7f),_0x4cfd7f['sort']((_0x356b66,_0x370fd8)=>_0x356b66['order']-_0x370fd8['order']),_0x4cfd7f;}function fa(_0x1bc3f3,_0x44eba8,_0x20cc60){const _0x334f7e=Ge(_0x44eba8);if(_0x334f7e){for(let _0x5947d4=0x0;_0x5947d4<_0x334f7e['length'];_0x5947d4++)_0x20cc60['push'](_0x334f7e[_0x5947d4]);}Bn(_0x44eba8,_0x30c0c9=>{fa(_0x1bc3f3,_0x30c0c9,_0x20cc60);});}function Gn(_0x3c4e26,_0x2477d0){const _0x1255da=Ge(_0x2477d0);if(_0x1255da){let _0x2dbd90=0x0;for(let _0x5dc965=0x0;_0x5dc965<_0x1255da['length'];_0x5dc965++)_0x1255da[_0x5dc965]['status']!==0x2&&(_0x1255da[_0x2dbd90]=_0x1255da[_0x5dc965],_0x2dbd90++);_0x1255da['length']=_0x2dbd90,_s(_0x2477d0,_0x1255da['length']>0x0?_0x1255da:void 0x0);}Bn(_0x2477d0,_0x5bac81=>{Gn(_0x3c4e26,_0x5bac81);});}function Is(_0xde6e9a,_0x1142c2){const _0x1b47fd=qt(ua(_0xde6e9a,_0x1142c2)),_0x5443ab=Wn(_0xde6e9a['transactionQueueTree_'],_0x1142c2);return ad(_0x5443ab,_0x3b6ff6=>{ci(_0xde6e9a,_0x3b6ff6);}),ci(_0xde6e9a,_0x5443ab),sa(_0x5443ab,_0x3ab411=>{ci(_0xde6e9a,_0x3ab411);}),_0x1b47fd;}function ci(_0x342698,_0xaf6d32){const _0x5665c9=Ge(_0xaf6d32);if(_0x5665c9){const _0x5a9aee=[];let _0x30030e=[],_0x54075=-0x1;for(let _0x35d3e1=0x0;_0x35d3e1<_0x5665c9['length'];_0x35d3e1++)_0x5665c9[_0x35d3e1]['status']===0x3||(_0x5665c9[_0x35d3e1]['status']===0x1?(f(_0x54075===_0x35d3e1-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x54075=_0x35d3e1,_0x5665c9[_0x35d3e1]['status']=0x3,_0x5665c9[_0x35d3e1]['abortReason']='set'):(f(_0x5665c9[_0x35d3e1]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x5665c9[_0x35d3e1]['unwatcher'](),_0x30030e=_0x30030e['concat'](pe(_0x342698['serverSyncTree_'],_0x5665c9[_0x35d3e1]['currentWriteId'],!0x0)),_0x5665c9[_0x35d3e1]['onComplete']&&_0x5a9aee['push'](_0x5665c9[_0x35d3e1]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x54075===-0x1?_s(_0xaf6d32,void 0x0):_0x5665c9['length']=_0x54075+0x1,H(_0x342698['eventQueue_'],qt(_0xaf6d32),_0x30030e);for(let _0x4d2637=0x0;_0x4d2637<_0x5a9aee['length'];_0x4d2637++)ht(_0x5a9aee[_0x4d2637]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Od(_0x3cc03e){let _0x25cf39='';const _0x4b8cf2=_0x3cc03e['split']('/');for(let _0x40b1e4=0x0;_0x40b1e4<_0x4b8cf2['length'];_0x40b1e4++)if(_0x4b8cf2[_0x40b1e4]['length']>0x0){let _0x28d4fb=_0x4b8cf2[_0x40b1e4];try{_0x28d4fb=decodeURIComponent(_0x28d4fb['replace'](/\+/g,'\x20'));}catch{}_0x25cf39+='/'+_0x28d4fb;}return _0x25cf39;}function Dd(_0x5a8b27){const _0x72965c={};_0x5a8b27['charAt'](0x0)==='?'&&(_0x5a8b27=_0x5a8b27['substring'](0x1));for(const _0x293bbc of _0x5a8b27['split']('&')){if(_0x293bbc['length']===0x0)continue;const _0x3bfef1=_0x293bbc['split']('=');_0x3bfef1['length']===0x2?_0x72965c[decodeURIComponent(_0x3bfef1[0x0])]=decodeURIComponent(_0x3bfef1[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x293bbc+'\x27\x20in\x20query\x20\x27'+_0x5a8b27+'\x27');}return _0x72965c;}const vr=function(_0x45c23d,_0x306ff0){const _0x1fb7dd=Md(_0x45c23d),_0x5781bc=_0x1fb7dd['namespace'];_0x1fb7dd['domain']==='firebase.com'&&ae(_0x1fb7dd['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x5781bc||_0x5781bc==='undefined')&&_0x1fb7dd['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x1fb7dd['secure']||$l();const _0x5393ba=_0x1fb7dd['scheme']==='ws'||_0x1fb7dd['scheme']==='wss';return{'repoInfo':new yo(_0x1fb7dd['host'],_0x1fb7dd['secure'],_0x5781bc,_0x5393ba,_0x306ff0,'',_0x5781bc!==_0x1fb7dd['subdomain']),'path':new C(_0x1fb7dd['pathString'])};},Md=function(_0xbe0591){let _0x215b3e='',_0x451161='',_0x4c69e5='',_0x21d7ea='',_0x54a849='',_0x94d4=!0x0,_0x5b42a4='https',_0x5ef51c=0x1bb;if(typeof _0xbe0591=='string'){let _0x4d248f=_0xbe0591['indexOf']('//');_0x4d248f>=0x0&&(_0x5b42a4=_0xbe0591['substring'](0x0,_0x4d248f-0x1),_0xbe0591=_0xbe0591['substring'](_0x4d248f+0x2));let _0x27e487=_0xbe0591['indexOf']('/');_0x27e487===-0x1&&(_0x27e487=_0xbe0591['length']);let _0x3d6796=_0xbe0591['indexOf']('?');_0x3d6796===-0x1&&(_0x3d6796=_0xbe0591['length']),_0x215b3e=_0xbe0591['substring'](0x0,Math['min'](_0x27e487,_0x3d6796)),_0x27e487<_0x3d6796&&(_0x21d7ea=Od(_0xbe0591['substring'](_0x27e487,_0x3d6796)));const _0x403b52=Dd(_0xbe0591['substring'](Math['min'](_0xbe0591['length'],_0x3d6796)));_0x4d248f=_0x215b3e['indexOf'](':'),_0x4d248f>=0x0?(_0x94d4=_0x5b42a4==='https'||_0x5b42a4==='wss',_0x5ef51c=parseInt(_0x215b3e['substring'](_0x4d248f+0x1),0xa)):_0x4d248f=_0x215b3e['length'];const _0x5a864d=_0x215b3e['slice'](0x0,_0x4d248f);if(_0x5a864d['toLowerCase']()==='localhost')_0x451161='localhost';else{if(_0x5a864d['split']('.')['length']<=0x2)_0x451161=_0x5a864d;else{const _0x1ca1c9=_0x215b3e['indexOf']('.');_0x4c69e5=_0x215b3e['substring'](0x0,_0x1ca1c9)['toLowerCase'](),_0x451161=_0x215b3e['substring'](_0x1ca1c9+0x1),_0x54a849=_0x4c69e5;}}'ns'in _0x403b52&&(_0x54a849=_0x403b52['ns']);}return{'host':_0x215b3e,'port':_0x5ef51c,'domain':_0x451161,'subdomain':_0x4c69e5,'secure':_0x94d4,'scheme':_0x5b42a4,'pathString':_0x21d7ea,'namespace':_0x54a849};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ld=(function(){let _0x2ac93f=0x0;const _0x21d5c2=[];return function(_0x226723){const _0x23bb0d=_0x226723===_0x2ac93f;_0x2ac93f=_0x226723;let _0x3e48c6;const _0x45aa0f=new Array(0x8);for(_0x3e48c6=0x7;_0x3e48c6>=0x0;_0x3e48c6--)_0x45aa0f[_0x3e48c6]=Er['charAt'](_0x226723%0x40),_0x226723=Math['floor'](_0x226723/0x40);f(_0x226723===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x3989b=_0x45aa0f['join']('');if(_0x23bb0d){for(_0x3e48c6=0xb;_0x3e48c6>=0x0&&_0x21d5c2[_0x3e48c6]===0x3f;_0x3e48c6--)_0x21d5c2[_0x3e48c6]=0x0;_0x21d5c2[_0x3e48c6]++;}else{for(_0x3e48c6=0x0;_0x3e48c6<0xc;_0x3e48c6++)_0x21d5c2[_0x3e48c6]=Math['floor'](Math['random']()*0x40);}for(_0x3e48c6=0x0;_0x3e48c6<0xc;_0x3e48c6++)_0x3989b+=Er['charAt'](_0x21d5c2[_0x3e48c6]);return f(_0x3989b['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x3989b;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xd{constructor(_0x14585a,_0x298c14,_0x43778a,_0x3f0a04){this['eventType']=_0x14585a,this['eventRegistration']=_0x298c14,this['snapshot']=_0x43778a,this['prevName']=_0x3f0a04;}['getPath'](){const _0x20b667=this['snapshot']['ref'];return this['eventType']==='value'?_0x20b667['_path']:_0x20b667['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Fd{constructor(_0x334751,_0x143cae,_0x1ca771){this['eventRegistration']=_0x334751,this['error']=_0x143cae,this['path']=_0x1ca771;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0x1775b5,_0x3d698d){this['snapshotCallback']=_0x1775b5,this['cancelCallback']=_0x3d698d;}['onValue'](_0x54d1c9,_0x86dd8f){this['snapshotCallback']['call'](null,_0x54d1c9,_0x86dd8f);}['onCancel'](_0x2fbac9){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x2fbac9);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x4c7132){return this['snapshotCallback']===_0x4c7132['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x4c7132['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x4c7132['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x18f1d6,_0x5ae451,_0x5ca145,_0x2a33e9){this['_repo']=_0x18f1d6,this['_path']=_0x5ae451,this['_queryParams']=_0x5ca145,this['_orderByCalled']=_0x2a33e9;}get['key'](){return v(this['_path'])?null:zi(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0xfa728d=rr(this['_queryParams']),_0x55cc82=Hi(_0xfa728d);return _0x55cc82==='{}'?'default':_0x55cc82;}get['_queryObject'](){return rr(this['_queryParams']);}['isEqual'](_0x157fc7){if(_0x157fc7=N(_0x157fc7),!(_0x157fc7 instanceof be))return!0x1;const _0x308ee1=this['_repo']===_0x157fc7['_repo'],_0x333532=ji(this['_path'],_0x157fc7['_path']),_0x41d992=this['_queryIdentifier']===_0x157fc7['_queryIdentifier'];return _0x308ee1&&_0x333532&&_0x41d992;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0x292806,_0x37f99e){if(_0x292806['_orderByCalled']===!0x0)throw new Error(_0x37f99e+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function qn(_0x4412){let _0x2f386d=null,_0x47b484=null;if(_0x4412['hasStart']()&&(_0x2f386d=_0x4412['getIndexStartValue']()),_0x4412['hasEnd']()&&(_0x47b484=_0x4412['getIndexEndValue']()),_0x4412['getIndex']()===ye){const _0x3dd7fb='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x335855='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x4412['hasStart']()){if(_0x4412['getIndexStartName']()!==Fe)throw new Error(_0x3dd7fb);if(typeof _0x2f386d!='string')throw new Error(_0x335855);}if(_0x4412['hasEnd']()){if(_0x4412['getIndexEndName']()!==Ie)throw new Error(_0x3dd7fb);if(typeof _0x47b484!='string')throw new Error(_0x335855);}}else{if(_0x4412['getIndex']()===R){if(_0x2f386d!=null&&!Tn(_0x2f386d)||_0x47b484!=null&&!Tn(_0x47b484))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x4412['getIndex']()instanceof Qi||_0x4412['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x2f386d!=null&&typeof _0x2f386d=='object'||_0x47b484!=null&&typeof _0x47b484=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x2fe808){if(_0x2fe808['hasStart']()&&_0x2fe808['hasEnd']()&&_0x2fe808['hasLimit']()&&!_0x2fe808['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends be{constructor(_0x3bf61b,_0x354f0f){super(_0x3bf61b,_0x354f0f,new Xi(),!0x1);}get['parent'](){const _0x13ee19=Ro(this['_path']);return _0x13ee19===null?null:new ee(this['_repo'],_0x13ee19);}get['root'](){let _0x4b66b0=this;for(;_0x4b66b0['parent']!==null;)_0x4b66b0=_0x4b66b0['parent'];return _0x4b66b0;}}class st{constructor(_0x457da0,_0x5d6c5b,_0x447ef1){this['_node']=_0x457da0,this['ref']=_0x5d6c5b,this['_index']=_0x447ef1;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x457dda){const _0x58d71e=new C(_0x457dda),_0x1b557e=Ft(this['ref'],_0x457dda);return new st(this['_node']['getChild'](_0x58d71e),_0x1b557e,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x5124c9){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x1f2856,_0x152d52)=>_0x5124c9(new st(_0x152d52,Ft(this['ref'],_0x1f2856),R)));}['hasChild'](_0x50f520){const _0x4ca379=new C(_0x50f520);return!this['_node']['getChild'](_0x4ca379)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function __(_0x5a563d,_0x3676c7){return _0x5a563d=N(_0x5a563d),_0x5a563d['_checkNotDeleted']('ref'),_0x3676c7!==void 0x0?Ft(_0x5a563d['_root'],_0x3676c7):_0x5a563d['_root'];}function Ft(_0x5ef62b,_0x4e2d6f){return _0x5ef62b=N(_0x5ef62b),y(_0x5ef62b['_path'])===null?pd('child','path',_0x4e2d6f):ms('child','path',_0x4e2d6f),new ee(_0x5ef62b['_repo'],k(_0x5ef62b['_path'],_0x4e2d6f));}function g_(_0x36f0c6,_0x3c8201){_0x36f0c6=N(_0x36f0c6),ys('push',_0x36f0c6['_path']),zt('push',_0x3c8201,_0x36f0c6['_path'],!0x0);const _0x8c56d2=la(_0x36f0c6['_repo']),_0x29782c=Ld(_0x8c56d2),_0x8398eb=Ft(_0x36f0c6,_0x29782c),_0x709ad4=Ft(_0x36f0c6,_0x29782c);let _0x5d3aa0;return _0x3c8201!=null?_0x5d3aa0=Ud(_0x709ad4,_0x3c8201)['then'](()=>_0x709ad4):_0x5d3aa0=Promise['resolve'](_0x709ad4),_0x8398eb['then']=_0x5d3aa0['then']['bind'](_0x5d3aa0),_0x8398eb['catch']=_0x5d3aa0['then']['bind'](_0x5d3aa0,void 0x0),_0x8398eb;}function Ud(_0x37a445,_0x113f4b){_0x37a445=N(_0x37a445),ys('set',_0x37a445['_path']),zt('set',_0x113f4b,_0x37a445['_path'],!0x1);const _0x53937=new ot();return Cd(_0x37a445['_repo'],_0x37a445['_path'],_0x113f4b,null,_0x53937['wrapCallback'](()=>{})),_0x53937['promise'];}function m_(_0x374593,_0x50b694){fd('update',_0x50b694,_0x374593['_path']);const _0x232877=new ot();return Td(_0x374593['_repo'],_0x374593['_path'],_0x50b694,_0x232877['wrapCallback'](()=>{})),_0x232877['promise'];}function y_(_0x1797dc){_0x1797dc=N(_0x1797dc);const _0x1eb094=new pa(()=>{}),_0x200aa2=new zn(_0x1eb094);return wd(_0x1797dc['_repo'],_0x1797dc,_0x200aa2)['then'](_0x397796=>new st(_0x397796,new ee(_0x1797dc['_repo'],_0x1797dc['_path']),_0x1797dc['_queryParams']['getIndex']()));}class zn{constructor(_0x118ddb){this['callbackContext']=_0x118ddb;}['respondsTo'](_0x1c485f){return _0x1c485f==='value';}['createEvent'](_0x411629,_0x332f02){const _0x463637=_0x332f02['_queryParams']['getIndex']();return new xd('value',this,new st(_0x411629['snapshotNode'],new ee(_0x332f02['_repo'],_0x332f02['_path']),_0x463637));}['getEventRunner'](_0x2f539f){return _0x2f539f['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0x2f539f['error']):()=>this['callbackContext']['onValue'](_0x2f539f['snapshot'],null);}['createCancelEvent'](_0x2672f5,_0x26e332){return this['callbackContext']['hasCancelCallback']?new Fd(this,_0x2672f5,_0x26e332):null;}['matches'](_0x37a828){return _0x37a828 instanceof zn?!_0x37a828['callbackContext']||!this['callbackContext']?!0x0:_0x37a828['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function Wd(_0x1e5f19,_0x4b316a,_0x109b77,_0x86344,_0x11249f){const _0x1f3235=new pa(_0x109b77,void 0x0),_0x486df2=new zn(_0x1f3235);return bd(_0x1e5f19['_repo'],_0x1e5f19,_0x486df2),()=>Rd(_0x1e5f19['_repo'],_0x1e5f19,_0x486df2);}function Bd(_0xf47246,_0x3d0663,_0x1c2dd6,_0x48e064){return Wd(_0xf47246,'value',_0x3d0663);}class ft{}class ma extends ft{constructor(_0x139060,_0x51b045){super(),this['_value']=_0x139060,this['_key']=_0x51b045,this['type']='endAt';}['_apply'](_0x357adb){zt('endAt',this['_value'],_0x357adb['_path'],!0x0);const _0x1ea290=Jh(_0x357adb['_queryParams'],this['_value'],this['_key']);if(ga(_0x1ea290),qn(_0x1ea290),_0x357adb['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x357adb['_repo'],_0x357adb['_path'],_0x1ea290,_0x357adb['_orderByCalled']);}}function v_(_0x515447,_0x464680){return new ma(_0x515447,_0x464680);}class ya extends ft{constructor(_0x2aea74,_0x3135e3){super(),this['_value']=_0x2aea74,this['_key']=_0x3135e3,this['type']='startAt';}['_apply'](_0x4fd24c){zt('startAt',this['_value'],_0x4fd24c['_path'],!0x0);const _0x25353e=Qh(_0x4fd24c['_queryParams'],this['_value'],this['_key']);if(ga(_0x25353e),qn(_0x25353e),_0x4fd24c['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x4fd24c['_repo'],_0x4fd24c['_path'],_0x25353e,_0x4fd24c['_orderByCalled']);}}function E_(_0x101d2c=null,_0xa35df6){return new ya(_0x101d2c,_0xa35df6);}class Vd extends ft{constructor(_0x9827a8){super(),this['_limit']=_0x9827a8,this['type']='limitToFirst';}['_apply'](_0x4e3400){if(_0x4e3400['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x4e3400['_repo'],_0x4e3400['_path'],Yh(_0x4e3400['_queryParams'],this['_limit']),_0x4e3400['_orderByCalled']);}}function I_(_0xb83ce7){if(Math['floor'](_0xb83ce7)!==_0xb83ce7||_0xb83ce7<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Vd(_0xb83ce7);}class Hd extends ft{constructor(_0x1dbd17){super(),this['_path']=_0x1dbd17,this['type']='orderByChild';}['_apply'](_0x42f396){_a(_0x42f396,'orderByChild');const _0x10ed78=new C(this['_path']);if(v(_0x10ed78))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x44eebd=new Qi(_0x10ed78),_0x49eb8a=xo(_0x42f396['_queryParams'],_0x44eebd);return qn(_0x49eb8a),new be(_0x42f396['_repo'],_0x42f396['_path'],_0x49eb8a,!0x0);}}function w_(_0x5651c2){if(_0x5651c2==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x5651c2==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x5651c2==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ms('orderByChild','path',_0x5651c2),new Hd(_0x5651c2);}class $d extends ft{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x27000d){_a(_0x27000d,'orderByKey');const _0x3febe7=xo(_0x27000d['_queryParams'],ye);return qn(_0x3febe7),new be(_0x27000d['_repo'],_0x27000d['_path'],_0x3febe7,!0x0);}}function C_(){return new $d();}class Gd extends ft{constructor(_0x5c8fa8,_0x2e0cd4){super(),this['_value']=_0x5c8fa8,this['_key']=_0x2e0cd4,this['type']='equalTo';}['_apply'](_0x16a629){if(zt('equalTo',this['_value'],_0x16a629['_path'],!0x1),_0x16a629['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x16a629['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x16a629));}}function T_(_0x44ea50,_0x19f54f){return new Gd(_0x44ea50,_0x19f54f);}function S_(_0x32b544,..._0x2ce22a){let _0x54fab0=N(_0x32b544);for(const _0x5a8755 of _0x2ce22a)_0x54fab0=_0x5a8755['_apply'](_0x54fab0);return _0x54fab0;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qd='FIREBASE_DATABASE_EMULATOR_HOST',Ni={};let zd=!0x1;function jd(_0x49b651,_0x9e368b,_0x1a99ea,_0xa32a50){const _0x550359=_0x9e368b['lastIndexOf'](':'),_0x131659=_0x9e368b['substring'](0x0,_0x550359),_0x543827=at(_0x131659);_0x49b651['repoInfo_']=new yo(_0x9e368b,_0x543827,_0x49b651['repoInfo_']['namespace'],_0x49b651['repoInfo_']['webSocketOnly'],_0x49b651['repoInfo_']['nodeAdmin'],_0x49b651['repoInfo_']['persistenceKey'],_0x49b651['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x1a99ea),_0xa32a50&&(_0x49b651['authTokenProvider_']=_0xa32a50);}function Kd(_0x19a78a,_0x5a928e,_0x44f70c,_0x384db0,_0x450087){let _0x1355d9=_0x384db0||_0x19a78a['options']['databaseURL'];_0x1355d9===void 0x0&&(_0x19a78a['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x19a78a['options']['projectId']),_0x1355d9=_0x19a78a['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x588b99=vr(_0x1355d9,_0x450087),_0x4b464f=_0x588b99['repoInfo'],_0x36245e;typeof process<'u'&&Vs&&(_0x36245e=Vs[qd]),_0x36245e?(_0x1355d9='http://'+_0x36245e+'?ns='+_0x4b464f['namespace'],_0x588b99=vr(_0x1355d9,_0x450087),_0x4b464f=_0x588b99['repoInfo']):_0x588b99['repoInfo']['secure'];const _0x2c10e0=new eh(_0x19a78a['name'],_0x19a78a['options'],_0x5a928e);_d('Invalid\x20Firebase\x20Database\x20URL',_0x588b99),v(_0x588b99['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x3fd5ae=Qd(_0x4b464f,_0x19a78a,_0x2c10e0,new Zl(_0x19a78a,_0x44f70c));return new Jd(_0x3fd5ae,_0x19a78a);}function Yd(_0x1238cc,_0x1ff21a){const _0x388e6b=Ni[_0x1ff21a];(!_0x388e6b||_0x388e6b[_0x1238cc['key']]!==_0x1238cc)&&ae('Database\x20'+_0x1ff21a+'('+_0x1238cc['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x1238cc),delete _0x388e6b[_0x1238cc['key']];}function Qd(_0x1e8174,_0x521bd6,_0x12cd80,_0x2caf34){let _0x12133f=Ni[_0x521bd6['name']];_0x12133f||(_0x12133f={},Ni[_0x521bd6['name']]=_0x12133f);let _0x517018=_0x12133f[_0x1e8174['toURLString']()];return _0x517018&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x517018=new vd(_0x1e8174,zd,_0x12cd80,_0x2caf34),_0x12133f[_0x1e8174['toURLString']()]=_0x517018,_0x517018;}class Jd{constructor(_0x3c6966,_0x33404e){this['_repoInternal']=_0x3c6966,this['app']=_0x33404e,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Yd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x105625){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x105625+'\x20on\x20a\x20deleted\x20database.');}}function b_(_0x4783db=Zr(),_0x3b6df0){const _0x1eabfb=Bi(_0x4783db,'database')['getImmediate']({'identifier':_0x3b6df0});if(!_0x1eabfb['_instanceStarted']){const _0x3a9838=cc('database');_0x3a9838&&Xd(_0x1eabfb,..._0x3a9838);}return _0x1eabfb;}function Xd(_0x5aa235,_0x19d96e,_0x1df823,_0x17c6cb={}){_0x5aa235=N(_0x5aa235),_0x5aa235['_checkNotDeleted']('useEmulator');const _0x217919=_0x19d96e+':'+_0x1df823,_0x2a0a7d=_0x5aa235['_repoInternal'];if(_0x5aa235['_instanceStarted']){if(_0x217919===_0x5aa235['_repoInternal']['repoInfo_']['host']&&Me(_0x17c6cb,_0x2a0a7d['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x51fc3b;if(_0x2a0a7d['repoInfo_']['nodeAdmin'])_0x17c6cb['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x51fc3b=new nn(nn['OWNER']);else{if(_0x17c6cb['mockUserToken']){const _0x203796=typeof _0x17c6cb['mockUserToken']=='string'?_0x17c6cb['mockUserToken']:lc(_0x17c6cb['mockUserToken'],_0x5aa235['app']['options']['projectId']);_0x51fc3b=new nn(_0x203796);}}at(_0x19d96e)&&(jr(_0x19d96e),Kr('Database',!0x0)),jd(_0x2a0a7d,_0x217919,_0x17c6cb,_0x51fc3b);}function R_(_0xbe0c71){_0xbe0c71=N(_0xbe0c71),_0xbe0c71['_checkNotDeleted']('goOffline'),ha(_0xbe0c71['_repo']);}function A_(_0x1cdabe){_0x1cdabe=N(_0x1cdabe),_0x1cdabe['_checkNotDeleted']('goOnline'),Ad(_0x1cdabe['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Zd(_0x16eace){Ul(lt),Ze(new Le('database',(_0x191525,{instanceIdentifier:_0xc9499d})=>{const _0x29fa90=_0x191525['getProvider']('app')['getImmediate'](),_0x1c911c=_0x191525['getProvider']('auth-internal'),_0x322603=_0x191525['getProvider']('app-check-internal');return Kd(_0x29fa90,_0x1c911c,_0x322603,_0xc9499d);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Hs,$s,_0x16eace),me(Hs,$s,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ef={'.sv':'timestamp'};function k_(){return ef;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tf{constructor(_0x54c66f,_0x908dfa){this['committed']=_0x54c66f,this['snapshot']=_0x908dfa;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function N_(_0x5625f6,_0x14f005,_0x1fc4c1){if(_0x5625f6=N(_0x5625f6),ys('Reference.transaction',_0x5625f6['_path']),_0x5625f6['key']==='.length'||_0x5625f6['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x5625f6['key']+'\x20is\x20a\x20read-only\x20object.';const _0x5daa17=!0x0,_0x45b68a=new ot(),_0xe90621=(_0x58e65c,_0x3a9bd3,_0x3c89ab)=>{let _0x594233=null;_0x58e65c?_0x45b68a['reject'](_0x58e65c):(_0x594233=new st(_0x3c89ab,new ee(_0x5625f6['_repo'],_0x5625f6['_path']),R),_0x45b68a['resolve'](new tf(_0x3a9bd3,_0x594233)));},_0x337bff=Bd(_0x5625f6,()=>{});return kd(_0x5625f6['_repo'],_0x5625f6['_path'],_0x14f005,_0xe90621,_0x337bff,_0x5daa17),_0x45b68a['promise'];}se['prototype']['simpleListen']=function(_0xec27,_0x475cfa){this['sendRequest']('q',{'p':_0xec27},_0x475cfa);},se['prototype']['echo']=function(_0x8d00d8,_0x33ab3a){this['sendRequest']('echo',{'d':_0x8d00d8},_0x33ab3a);},Zd();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const nf=va,Ea=new Bt('auth','Firebase',va()),Sn=new Ui('@firebase/auth');function sf(_0x606261,..._0x33bb74){Sn['logLevel']<=T['WARN']&&Sn['warn']('Auth\x20('+lt+'):\x20'+_0x606261,..._0x33bb74);}function sn(_0x33d2ad,..._0x4f5c96){Sn['logLevel']<=T['ERROR']&&Sn['error']('Auth\x20('+lt+'):\x20'+_0x33d2ad,..._0x4f5c96);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0xcd55a9,..._0x11f074){throw ws(_0xcd55a9,..._0x11f074);}function X(_0x26ed93,..._0x18c357){return ws(_0x26ed93,..._0x18c357);}function Ia(_0x475bf8,_0x2a1ce7,_0x34b6c1){const _0x581863={...nf(),[_0x2a1ce7]:_0x34b6c1};return new Bt('auth','Firebase',_0x581863)['create'](_0x2a1ce7,{'appName':_0x475bf8['name']});}function re(_0x5d77bf){return Ia(_0x5d77bf,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x2a25fe,..._0x1dd693){if(typeof _0x2a25fe!='string'){const _0x2cf6fd=_0x1dd693[0x0],_0x3eabb4=[..._0x1dd693['slice'](0x1)];return _0x3eabb4[0x0]&&(_0x3eabb4[0x0]['appName']=_0x2a25fe['name']),_0x2a25fe['_errorFactory']['create'](_0x2cf6fd,..._0x3eabb4);}return Ea['create'](_0x2a25fe,..._0x1dd693);}function m(_0x2d8e75,_0x238ed1,..._0x4724b7){if(!_0x2d8e75)throw ws(_0x238ed1,..._0x4724b7);}function ne(_0x34d608){const _0x1af5ed='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x34d608;throw sn(_0x1af5ed),new Error(_0x1af5ed);}function ce(_0x475324,_0x212e7b){_0x475324||ne(_0x212e7b);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pi(){var _0x225515;return typeof self<'u'&&((_0x225515=self['location'])==null?void 0x0:_0x225515['href'])||'';}function rf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x4420c5;return typeof self<'u'&&((_0x4420c5=self['location'])==null?void 0x0:_0x4420c5['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function of(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(rf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function af(){if(typeof navigator>'u')return null;const _0x1e723a=navigator;return _0x1e723a['languages']&&_0x1e723a['languages'][0x0]||_0x1e723a['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yt{constructor(_0x289a3,_0x32210d){this['shortDelay']=_0x289a3,this['longDelay']=_0x32210d,ce(_0x32210d>_0x289a3,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Fi()||Yr();}['get'](){return of()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x2cd175,_0xbf63cf){ce(_0x2cd175['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x485ebb}=_0x2cd175['emulator'];return _0xbf63cf?''+_0x485ebb+(_0xbf63cf['startsWith']('/')?_0xbf63cf['slice'](0x1):_0xbf63cf):_0x485ebb;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x2b88e4,_0x2e87a9,_0xae9a67){this['fetchImpl']=_0x2b88e4,_0x2e87a9&&(this['headersImpl']=_0x2e87a9),_0xae9a67&&(this['responseImpl']=_0xae9a67);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const cf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},lf=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],hf=new Yt(0x7530,0xea60);function Re(_0x32992e,_0x553ec9){return _0x32992e['tenantId']&&!_0x553ec9['tenantId']?{..._0x553ec9,'tenantId':_0x32992e['tenantId']}:_0x553ec9;}async function Ae(_0x130aba,_0x3cd959,_0x472989,_0x2e4376,_0x33f02e={}){return Ca(_0x130aba,_0x33f02e,async()=>{let _0x3075c7={},_0x373260={};_0x2e4376&&(_0x3cd959==='GET'?_0x373260=_0x2e4376:_0x3075c7={'body':JSON['stringify'](_0x2e4376)});const _0x38f343=ct({'key':_0x130aba['config']['apiKey'],..._0x373260})['slice'](0x1),_0x125554=await _0x130aba['_getAdditionalHeaders']();_0x125554['Content-Type']='application/json',_0x130aba['languageCode']&&(_0x125554['X-Firebase-Locale']=_0x130aba['languageCode']);const _0x1d9b7c={'method':_0x3cd959,'headers':_0x125554,..._0x3075c7};return dc()||(_0x1d9b7c['referrerPolicy']='no-referrer'),_0x130aba['emulatorConfig']&&at(_0x130aba['emulatorConfig']['host'])&&(_0x1d9b7c['credentials']='include'),wa['fetch']()(await Ta(_0x130aba,_0x130aba['config']['apiHost'],_0x472989,_0x38f343),_0x1d9b7c);});}async function Ca(_0xcc4998,_0x4dbd87,_0x3ed7de){_0xcc4998['_canInitEmulator']=!0x1;const _0x3a6805={...cf,..._0x4dbd87};try{const _0x58bd36=new df(_0xcc4998),_0x101533=await Promise['race']([_0x3ed7de(),_0x58bd36['promise']]);_0x58bd36['clearNetworkTimeout']();const _0x42db95=await _0x101533['json']();if('needConfirmation'in _0x42db95)throw tn(_0xcc4998,'account-exists-with-different-credential',_0x42db95);if(_0x101533['ok']&&!('errorMessage'in _0x42db95))return _0x42db95;{const _0xbc7277=_0x101533['ok']?_0x42db95['errorMessage']:_0x42db95['error']['message'],[_0x5e3274,_0x4f5103]=_0xbc7277['split']('\x20:\x20');if(_0x5e3274==='FEDERATED_USER_ID_ALREADY_LINKED')throw tn(_0xcc4998,'credential-already-in-use',_0x42db95);if(_0x5e3274==='EMAIL_EXISTS')throw tn(_0xcc4998,'email-already-in-use',_0x42db95);if(_0x5e3274==='USER_DISABLED')throw tn(_0xcc4998,'user-disabled',_0x42db95);const _0x3ec845=_0x3a6805[_0x5e3274]||_0x5e3274['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x4f5103)throw Ia(_0xcc4998,_0x3ec845,_0x4f5103);Q(_0xcc4998,_0x3ec845);}}catch(_0x5bfd38){if(_0x5bfd38 instanceof Se)throw _0x5bfd38;Q(_0xcc4998,'network-request-failed',{'message':String(_0x5bfd38)});}}async function Qt(_0xf0e80,_0x3d1879,_0xf35626,_0x2e0837,_0x16745f={}){const _0x512c85=await Ae(_0xf0e80,_0x3d1879,_0xf35626,_0x2e0837,_0x16745f);return'mfaPendingCredential'in _0x512c85&&Q(_0xf0e80,'multi-factor-auth-required',{'_serverResponse':_0x512c85}),_0x512c85;}async function Ta(_0x386740,_0x1e5876,_0x44a99b,_0xd3e37f){const _0x59e7ce=''+_0x1e5876+_0x44a99b+'?'+_0xd3e37f,_0x3976f8=_0x386740,_0x3271af=_0x3976f8['config']['emulator']?Cs(_0x386740['config'],_0x59e7ce):_0x386740['config']['apiScheme']+'://'+_0x59e7ce;return lf['includes'](_0x44a99b)&&(await _0x3976f8['_persistenceManagerAvailable'],_0x3976f8['_getPersistenceType']()==='COOKIE')?_0x3976f8['_getPersistence']()['_getFinalTarget'](_0x3271af)['toString']():_0x3271af;}function uf(_0x399723){switch(_0x399723){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class df{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x147018){this['auth']=_0x147018,this['timer']=null,this['promise']=new Promise((_0x1f1a34,_0x4a413b)=>{this['timer']=setTimeout(()=>_0x4a413b(X(this['auth'],'network-request-failed')),hf['get']());});}}function tn(_0xcb0ce5,_0x1812d3,_0x4bfb4a){const _0x392da5={'appName':_0xcb0ce5['name']};_0x4bfb4a['email']&&(_0x392da5['email']=_0x4bfb4a['email']),_0x4bfb4a['phoneNumber']&&(_0x392da5['phoneNumber']=_0x4bfb4a['phoneNumber']);const _0x2e427f=X(_0xcb0ce5,_0x1812d3,_0x392da5);return _0x2e427f['customData']['_tokenResponse']=_0x4bfb4a,_0x2e427f;}function wr(_0x5f172b){return _0x5f172b!==void 0x0&&_0x5f172b['enterprise']!==void 0x0;}class ff{constructor(_0x69186b){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x69186b['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x69186b['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x69186b['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x47c79c){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x5841f0 of this['recaptchaEnforcementState'])if(_0x5841f0['provider']&&_0x5841f0['provider']===_0x47c79c)return uf(_0x5841f0['enforcementState']);return null;}['isProviderEnabled'](_0x445687){return this['getProviderEnforcementState'](_0x445687)==='ENFORCE'||this['getProviderEnforcementState'](_0x445687)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function pf(_0x11256e,_0x2a9fbd){return Ae(_0x11256e,'GET','/v2/recaptchaConfig',Re(_0x11256e,_0x2a9fbd));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function _f(_0x340ea8,_0x468450){return Ae(_0x340ea8,'POST','/v1/accounts:delete',_0x468450);}async function bn(_0x69ba92,_0x1bd8e7){return Ae(_0x69ba92,'POST','/v1/accounts:lookup',_0x1bd8e7);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Rt(_0x197c0b){if(_0x197c0b)try{const _0x29f301=new Date(Number(_0x197c0b));if(!isNaN(_0x29f301['getTime']()))return _0x29f301['toUTCString']();}catch{}}async function gf(_0x53025b,_0x5ed833=!0x1){const _0x561ee2=N(_0x53025b),_0x39a7cd=await _0x561ee2['getIdToken'](_0x5ed833),_0x2a4ca0=Ts(_0x39a7cd);m(_0x2a4ca0&&_0x2a4ca0['exp']&&_0x2a4ca0['auth_time']&&_0x2a4ca0['iat'],_0x561ee2['auth'],'internal-error');const _0x232565=typeof _0x2a4ca0['firebase']=='object'?_0x2a4ca0['firebase']:void 0x0,_0x23e900=_0x232565==null?void 0x0:_0x232565['sign_in_provider'];return{'claims':_0x2a4ca0,'token':_0x39a7cd,'authTime':Rt(li(_0x2a4ca0['auth_time'])),'issuedAtTime':Rt(li(_0x2a4ca0['iat'])),'expirationTime':Rt(li(_0x2a4ca0['exp'])),'signInProvider':_0x23e900||null,'signInSecondFactor':(_0x232565==null?void 0x0:_0x232565['sign_in_second_factor'])||null};}function li(_0x58295e){return Number(_0x58295e)*0x3e8;}function Ts(_0x5ef3e8){const [_0x2446c2,_0x2ccced,_0x215ea5]=_0x5ef3e8['split']('.');if(_0x2446c2===void 0x0||_0x2ccced===void 0x0||_0x215ea5===void 0x0)return sn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x33831f=ln(_0x2ccced);return _0x33831f?JSON['parse'](_0x33831f):(sn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x38a312){return sn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x38a312==null?void 0x0:_0x38a312['toString']()),null;}}function Cr(_0x5b30a7){const _0x12c4c3=Ts(_0x5b30a7);return m(_0x12c4c3,'internal-error'),m(typeof _0x12c4c3['exp']<'u','internal-error'),m(typeof _0x12c4c3['iat']<'u','internal-error'),Number(_0x12c4c3['exp'])-Number(_0x12c4c3['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ut(_0x5685de,_0x116db0,_0x303483=!0x1){if(_0x303483)return _0x116db0;try{return await _0x116db0;}catch(_0x14d3b5){throw _0x14d3b5 instanceof Se&&mf(_0x14d3b5)&&_0x5685de['auth']['currentUser']===_0x5685de&&await _0x5685de['auth']['signOut'](),_0x14d3b5;}}function mf({code:_0x48a459}){return _0x48a459==='auth/user-disabled'||_0x48a459==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yf{constructor(_0x2123d1){this['user']=_0x2123d1,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x2cfc05){if(_0x2cfc05){const _0x29e159=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x29e159;}else{this['errorBackoff']=0x7530;const _0xace270=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0xace270);}}['schedule'](_0x25dc61=!0x1){if(!this['isRunning'])return;const _0x5ae29f=this['getInterval'](_0x25dc61);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x5ae29f);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x1e568d){(_0x1e568d==null?void 0x0:_0x1e568d['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Oi{constructor(_0xea81f2,_0x4ffa0d){this['createdAt']=_0xea81f2,this['lastLoginAt']=_0x4ffa0d,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Rt(this['lastLoginAt']),this['creationTime']=Rt(this['createdAt']);}['_copy'](_0x2bd77e){this['createdAt']=_0x2bd77e['createdAt'],this['lastLoginAt']=_0x2bd77e['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Rn(_0x3dda2a){var _0x2952d8;const _0x4769ab=_0x3dda2a['auth'],_0x5cf6d0=await _0x3dda2a['getIdToken'](),_0x2b3c4c=await Ut(_0x3dda2a,bn(_0x4769ab,{'idToken':_0x5cf6d0}));m(_0x2b3c4c==null?void 0x0:_0x2b3c4c['users']['length'],_0x4769ab,'internal-error');const _0x14864d=_0x2b3c4c['users'][0x0];_0x3dda2a['_notifyReloadListener'](_0x14864d);const _0x19eeb3=(_0x2952d8=_0x14864d['providerUserInfo'])!=null&&_0x2952d8['length']?Sa(_0x14864d['providerUserInfo']):[],_0x47e5f2=Ef(_0x3dda2a['providerData'],_0x19eeb3),_0x4a7197=_0x3dda2a['isAnonymous'],_0x3ea29c=!(_0x3dda2a['email']&&_0x14864d['passwordHash'])&&!(_0x47e5f2!=null&&_0x47e5f2['length']),_0x523624=_0x4a7197?_0x3ea29c:!0x1,_0x519094={'uid':_0x14864d['localId'],'displayName':_0x14864d['displayName']||null,'photoURL':_0x14864d['photoUrl']||null,'email':_0x14864d['email']||null,'emailVerified':_0x14864d['emailVerified']||!0x1,'phoneNumber':_0x14864d['phoneNumber']||null,'tenantId':_0x14864d['tenantId']||null,'providerData':_0x47e5f2,'metadata':new Oi(_0x14864d['createdAt'],_0x14864d['lastLoginAt']),'isAnonymous':_0x523624};Object['assign'](_0x3dda2a,_0x519094);}async function vf(_0xfc92ab){const _0x3e428d=N(_0xfc92ab);await Rn(_0x3e428d),await _0x3e428d['auth']['_persistUserIfCurrent'](_0x3e428d),_0x3e428d['auth']['_notifyListenersIfCurrent'](_0x3e428d);}function Ef(_0x2cf666,_0x12b9b1){return[..._0x2cf666['filter'](_0x338f0d=>!_0x12b9b1['some'](_0x21cdc1=>_0x21cdc1['providerId']===_0x338f0d['providerId'])),..._0x12b9b1];}function Sa(_0x32775d){return _0x32775d['map'](({providerId:_0x1b0456,..._0x3a6f5d})=>({'providerId':_0x1b0456,'uid':_0x3a6f5d['rawId']||'','displayName':_0x3a6f5d['displayName']||null,'email':_0x3a6f5d['email']||null,'phoneNumber':_0x3a6f5d['phoneNumber']||null,'photoURL':_0x3a6f5d['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function If(_0x58adff,_0x2a2545){const _0x148736=await Ca(_0x58adff,{},async()=>{const _0x125d55=ct({'grant_type':'refresh_token','refresh_token':_0x2a2545})['slice'](0x1),{tokenApiHost:_0xc8b243,apiKey:_0x2da635}=_0x58adff['config'],_0xf2bc11=await Ta(_0x58adff,_0xc8b243,'/v1/token','key='+_0x2da635),_0x4c829c=await _0x58adff['_getAdditionalHeaders']();_0x4c829c['Content-Type']='application/x-www-form-urlencoded';const _0x5f157d={'method':'POST','headers':_0x4c829c,'body':_0x125d55};return _0x58adff['emulatorConfig']&&at(_0x58adff['emulatorConfig']['host'])&&(_0x5f157d['credentials']='include'),wa['fetch']()(_0xf2bc11,_0x5f157d);});return{'accessToken':_0x148736['access_token'],'expiresIn':_0x148736['expires_in'],'refreshToken':_0x148736['refresh_token']};}async function wf(_0x107855,_0x120e32){return Ae(_0x107855,'POST','/v2/accounts:revokeToken',Re(_0x107855,_0x120e32));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qe{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x3587f6){m(_0x3587f6['idToken'],'internal-error'),m(typeof _0x3587f6['idToken']<'u','internal-error'),m(typeof _0x3587f6['refreshToken']<'u','internal-error');const _0x475b7b='expiresIn'in _0x3587f6&&typeof _0x3587f6['expiresIn']<'u'?Number(_0x3587f6['expiresIn']):Cr(_0x3587f6['idToken']);this['updateTokensAndExpiration'](_0x3587f6['idToken'],_0x3587f6['refreshToken'],_0x475b7b);}['updateFromIdToken'](_0x16bb50){m(_0x16bb50['length']!==0x0,'internal-error');const _0x1056df=Cr(_0x16bb50);this['updateTokensAndExpiration'](_0x16bb50,null,_0x1056df);}async['getToken'](_0x77706,_0x1ade58=!0x1){return!_0x1ade58&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x77706,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x77706,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x53c7d5,_0x488639){const {accessToken:_0x15296e,refreshToken:_0x34d78b,expiresIn:_0x3417b0}=await If(_0x53c7d5,_0x488639);this['updateTokensAndExpiration'](_0x15296e,_0x34d78b,Number(_0x3417b0));}['updateTokensAndExpiration'](_0x5c56dd,_0xceb94d,_0x237fe5){this['refreshToken']=_0xceb94d||null,this['accessToken']=_0x5c56dd||null,this['expirationTime']=Date['now']()+_0x237fe5*0x3e8;}static['fromJSON'](_0x5bd62e,_0x3b3520){const {refreshToken:_0x11bc65,accessToken:_0x4458ca,expirationTime:_0x5c4992}=_0x3b3520,_0x4be9e1=new Qe();return _0x11bc65&&(m(typeof _0x11bc65=='string','internal-error',{'appName':_0x5bd62e}),_0x4be9e1['refreshToken']=_0x11bc65),_0x4458ca&&(m(typeof _0x4458ca=='string','internal-error',{'appName':_0x5bd62e}),_0x4be9e1['accessToken']=_0x4458ca),_0x5c4992&&(m(typeof _0x5c4992=='number','internal-error',{'appName':_0x5bd62e}),_0x4be9e1['expirationTime']=_0x5c4992),_0x4be9e1;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x3da144){this['accessToken']=_0x3da144['accessToken'],this['refreshToken']=_0x3da144['refreshToken'],this['expirationTime']=_0x3da144['expirationTime'];}['_clone'](){return Object['assign'](new Qe(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x4958e0,_0x2d2809){m(typeof _0x4958e0=='string'||typeof _0x4958e0>'u','internal-error',{'appName':_0x2d2809});}class K{constructor({uid:_0x39930b,auth:_0x10d610,stsTokenManager:_0x3645c2,..._0x320543}){this['providerId']='firebase',this['proactiveRefresh']=new yf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x39930b,this['auth']=_0x10d610,this['stsTokenManager']=_0x3645c2,this['accessToken']=_0x3645c2['accessToken'],this['displayName']=_0x320543['displayName']||null,this['email']=_0x320543['email']||null,this['emailVerified']=_0x320543['emailVerified']||!0x1,this['phoneNumber']=_0x320543['phoneNumber']||null,this['photoURL']=_0x320543['photoURL']||null,this['isAnonymous']=_0x320543['isAnonymous']||!0x1,this['tenantId']=_0x320543['tenantId']||null,this['providerData']=_0x320543['providerData']?[..._0x320543['providerData']]:[],this['metadata']=new Oi(_0x320543['createdAt']||void 0x0,_0x320543['lastLoginAt']||void 0x0);}async['getIdToken'](_0x3c8cf4){const _0xa8f557=await Ut(this,this['stsTokenManager']['getToken'](this['auth'],_0x3c8cf4));return m(_0xa8f557,this['auth'],'internal-error'),this['accessToken']!==_0xa8f557&&(this['accessToken']=_0xa8f557,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0xa8f557;}['getIdTokenResult'](_0x2bbb05){return gf(this,_0x2bbb05);}['reload'](){return vf(this);}['_assign'](_0x2d43a3){this!==_0x2d43a3&&(m(this['uid']===_0x2d43a3['uid'],this['auth'],'internal-error'),this['displayName']=_0x2d43a3['displayName'],this['photoURL']=_0x2d43a3['photoURL'],this['email']=_0x2d43a3['email'],this['emailVerified']=_0x2d43a3['emailVerified'],this['phoneNumber']=_0x2d43a3['phoneNumber'],this['isAnonymous']=_0x2d43a3['isAnonymous'],this['tenantId']=_0x2d43a3['tenantId'],this['providerData']=_0x2d43a3['providerData']['map'](_0x71b58a=>({..._0x71b58a})),this['metadata']['_copy'](_0x2d43a3['metadata']),this['stsTokenManager']['_assign'](_0x2d43a3['stsTokenManager']));}['_clone'](_0x558265){const _0xc13320=new K({...this,'auth':_0x558265,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0xc13320['metadata']['_copy'](this['metadata']),_0xc13320;}['_onReload'](_0x412773){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x412773,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x361fa7){this['reloadListener']?this['reloadListener'](_0x361fa7):this['reloadUserInfo']=_0x361fa7;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x3578a4,_0x4c45b8=!0x1){let _0x35b87b=!0x1;_0x3578a4['idToken']&&_0x3578a4['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x3578a4),_0x35b87b=!0x0),_0x4c45b8&&await Rn(this),await this['auth']['_persistUserIfCurrent'](this),_0x35b87b&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x327324=await this['getIdToken']();return await Ut(this,_f(this['auth'],{'idToken':_0x327324})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x3911d4=>({..._0x3911d4})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x221500,_0x1b3cf9){const _0x46abbf=_0x1b3cf9['displayName']??void 0x0,_0x395a2e=_0x1b3cf9['email']??void 0x0,_0xf41e86=_0x1b3cf9['phoneNumber']??void 0x0,_0x2cd8f2=_0x1b3cf9['photoURL']??void 0x0,_0x179571=_0x1b3cf9['tenantId']??void 0x0,_0x3c50a3=_0x1b3cf9['_redirectEventId']??void 0x0,_0x8ce875=_0x1b3cf9['createdAt']??void 0x0,_0x1a8de8=_0x1b3cf9['lastLoginAt']??void 0x0,{uid:_0x58ae61,emailVerified:_0x1ed271,isAnonymous:_0x5bc7f1,providerData:_0x2033ff,stsTokenManager:_0x52dae3}=_0x1b3cf9;m(_0x58ae61&&_0x52dae3,_0x221500,'internal-error');const _0x1db855=Qe['fromJSON'](this['name'],_0x52dae3);m(typeof _0x58ae61=='string',_0x221500,'internal-error'),le(_0x46abbf,_0x221500['name']),le(_0x395a2e,_0x221500['name']),m(typeof _0x1ed271=='boolean',_0x221500,'internal-error'),m(typeof _0x5bc7f1=='boolean',_0x221500,'internal-error'),le(_0xf41e86,_0x221500['name']),le(_0x2cd8f2,_0x221500['name']),le(_0x179571,_0x221500['name']),le(_0x3c50a3,_0x221500['name']),le(_0x8ce875,_0x221500['name']),le(_0x1a8de8,_0x221500['name']);const _0x5efe7d=new K({'uid':_0x58ae61,'auth':_0x221500,'email':_0x395a2e,'emailVerified':_0x1ed271,'displayName':_0x46abbf,'isAnonymous':_0x5bc7f1,'photoURL':_0x2cd8f2,'phoneNumber':_0xf41e86,'tenantId':_0x179571,'stsTokenManager':_0x1db855,'createdAt':_0x8ce875,'lastLoginAt':_0x1a8de8});return _0x2033ff&&Array['isArray'](_0x2033ff)&&(_0x5efe7d['providerData']=_0x2033ff['map'](_0x113b50=>({..._0x113b50}))),_0x3c50a3&&(_0x5efe7d['_redirectEventId']=_0x3c50a3),_0x5efe7d;}static async['_fromIdTokenResponse'](_0x44471e,_0x39290a,_0x24abec=!0x1){const _0x4aed3d=new Qe();_0x4aed3d['updateFromServerResponse'](_0x39290a);const _0x2dedf7=new K({'uid':_0x39290a['localId'],'auth':_0x44471e,'stsTokenManager':_0x4aed3d,'isAnonymous':_0x24abec});return await Rn(_0x2dedf7),_0x2dedf7;}static async['_fromGetAccountInfoResponse'](_0x2d2b4c,_0x2ed819,_0x34eeb9){const _0x45e3fe=_0x2ed819['users'][0x0];m(_0x45e3fe['localId']!==void 0x0,'internal-error');const _0x35304e=_0x45e3fe['providerUserInfo']!==void 0x0?Sa(_0x45e3fe['providerUserInfo']):[],_0x1efcb6=!(_0x45e3fe['email']&&_0x45e3fe['passwordHash'])&&!(_0x35304e!=null&&_0x35304e['length']),_0x14c807=new Qe();_0x14c807['updateFromIdToken'](_0x34eeb9);const _0xfdf279=new K({'uid':_0x45e3fe['localId'],'auth':_0x2d2b4c,'stsTokenManager':_0x14c807,'isAnonymous':_0x1efcb6}),_0x3ac4c9={'uid':_0x45e3fe['localId'],'displayName':_0x45e3fe['displayName']||null,'photoURL':_0x45e3fe['photoUrl']||null,'email':_0x45e3fe['email']||null,'emailVerified':_0x45e3fe['emailVerified']||!0x1,'phoneNumber':_0x45e3fe['phoneNumber']||null,'tenantId':_0x45e3fe['tenantId']||null,'providerData':_0x35304e,'metadata':new Oi(_0x45e3fe['createdAt'],_0x45e3fe['lastLoginAt']),'isAnonymous':!(_0x45e3fe['email']&&_0x45e3fe['passwordHash'])&&!(_0x35304e!=null&&_0x35304e['length'])};return Object['assign'](_0xfdf279,_0x3ac4c9),_0xfdf279;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0x336c04){ce(_0x336c04 instanceof Function,'Expected\x20a\x20class\x20definition');let _0x20ad1e=Tr['get'](_0x336c04);return _0x20ad1e?(ce(_0x20ad1e instanceof _0x336c04,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x20ad1e):(_0x20ad1e=new _0x336c04(),Tr['set'](_0x336c04,_0x20ad1e),_0x20ad1e);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x4a89d0,_0x441cab){this['storage'][_0x4a89d0]=_0x441cab;}async['_get'](_0x4d59e1){const _0x142fc4=this['storage'][_0x4d59e1];return _0x142fc4===void 0x0?null:_0x142fc4;}async['_remove'](_0x4678ef){delete this['storage'][_0x4678ef];}['_addListener'](_0x5aec05,_0x446498){}['_removeListener'](_0x1b3c15,_0x5bb3b9){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rn(_0x2eb1e6,_0x23cb93,_0x282e4d){return'firebase:'+_0x2eb1e6+':'+_0x23cb93+':'+_0x282e4d;}class Je{constructor(_0x4cad71,_0x27118d,_0x5ccdc1){this['persistence']=_0x4cad71,this['auth']=_0x27118d,this['userKey']=_0x5ccdc1;const {config:_0x3f7a8a,name:_0xc68398}=this['auth'];this['fullUserKey']=rn(this['userKey'],_0x3f7a8a['apiKey'],_0xc68398),this['fullPersistenceKey']=rn('persistence',_0x3f7a8a['apiKey'],_0xc68398),this['boundEventHandler']=_0x27118d['_onStorageEvent']['bind'](_0x27118d),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x352b07){return this['persistence']['_set'](this['fullUserKey'],_0x352b07['toJSON']());}async['getCurrentUser'](){const _0x374ff9=await this['persistence']['_get'](this['fullUserKey']);if(!_0x374ff9)return null;if(typeof _0x374ff9=='string'){const _0x2c75de=await bn(this['auth'],{'idToken':_0x374ff9})['catch'](()=>{});return _0x2c75de?K['_fromGetAccountInfoResponse'](this['auth'],_0x2c75de,_0x374ff9):null;}return K['_fromJSON'](this['auth'],_0x374ff9);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x466c3f){if(this['persistence']===_0x466c3f)return;const _0x116f23=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x466c3f,_0x116f23)return this['setCurrentUser'](_0x116f23);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x3ced5b,_0xcc9f8b,_0x582154='authUser'){if(!_0xcc9f8b['length'])return new Je(ie(Sr),_0x3ced5b,_0x582154);const _0x4db930=(await Promise['all'](_0xcc9f8b['map'](async _0x2e64a3=>{if(await _0x2e64a3['_isAvailable']())return _0x2e64a3;})))['filter'](_0x1a1bc4=>_0x1a1bc4);let _0x4877a5=_0x4db930[0x0]||ie(Sr);const _0x469796=rn(_0x582154,_0x3ced5b['config']['apiKey'],_0x3ced5b['name']);let _0xd0e623=null;for(const _0x166db5 of _0xcc9f8b)try{const _0x4f704c=await _0x166db5['_get'](_0x469796);if(_0x4f704c){let _0x2c3744;if(typeof _0x4f704c=='string'){const _0x3a372d=await bn(_0x3ced5b,{'idToken':_0x4f704c})['catch'](()=>{});if(!_0x3a372d)break;_0x2c3744=await K['_fromGetAccountInfoResponse'](_0x3ced5b,_0x3a372d,_0x4f704c);}else _0x2c3744=K['_fromJSON'](_0x3ced5b,_0x4f704c);_0x166db5!==_0x4877a5&&(_0xd0e623=_0x2c3744),_0x4877a5=_0x166db5;break;}}catch{}const _0x364d99=_0x4db930['filter'](_0x5a16b1=>_0x5a16b1['_shouldAllowMigration']);return!_0x4877a5['_shouldAllowMigration']||!_0x364d99['length']?new Je(_0x4877a5,_0x3ced5b,_0x582154):(_0x4877a5=_0x364d99[0x0],_0xd0e623&&await _0x4877a5['_set'](_0x469796,_0xd0e623['toJSON']()),await Promise['all'](_0xcc9f8b['map'](async _0x33bea0=>{if(_0x33bea0!==_0x4877a5)try{await _0x33bea0['_remove'](_0x469796);}catch{}})),new Je(_0x4877a5,_0x3ced5b,_0x582154));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x44aff4){const _0x477b10=_0x44aff4['toLowerCase']();if(_0x477b10['includes']('opera/')||_0x477b10['includes']('opr/')||_0x477b10['includes']('opios/'))return'Opera';if(Na(_0x477b10))return'IEMobile';if(_0x477b10['includes']('msie')||_0x477b10['includes']('trident/'))return'IE';if(_0x477b10['includes']('edge/'))return'Edge';if(Ra(_0x477b10))return'Firefox';if(_0x477b10['includes']('silk/'))return'Silk';if(Oa(_0x477b10))return'Blackberry';if(Da(_0x477b10))return'Webos';if(Aa(_0x477b10))return'Safari';if((_0x477b10['includes']('chrome/')||ka(_0x477b10))&&!_0x477b10['includes']('edge/'))return'Chrome';if(Pa(_0x477b10))return'Android';{const _0x44ea95=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x5de09c=_0x44aff4['match'](_0x44ea95);if((_0x5de09c==null?void 0x0:_0x5de09c['length'])===0x2)return _0x5de09c[0x1];}return'Other';}function Ra(_0x35b2b5=W()){return/firefox\//i['test'](_0x35b2b5);}function Aa(_0x1546c9=W()){const _0x33e28b=_0x1546c9['toLowerCase']();return _0x33e28b['includes']('safari/')&&!_0x33e28b['includes']('chrome/')&&!_0x33e28b['includes']('crios/')&&!_0x33e28b['includes']('android');}function ka(_0x4424ff=W()){return/crios\//i['test'](_0x4424ff);}function Na(_0x3c1284=W()){return/iemobile/i['test'](_0x3c1284);}function Pa(_0x4a6c11=W()){return/android/i['test'](_0x4a6c11);}function Oa(_0x21946d=W()){return/blackberry/i['test'](_0x21946d);}function Da(_0x569690=W()){return/webos/i['test'](_0x569690);}function Ss(_0x50f40e=W()){return/iphone|ipad|ipod/i['test'](_0x50f40e)||/macintosh/i['test'](_0x50f40e)&&/mobile/i['test'](_0x50f40e);}function Cf(_0x2fbbfc=W()){var _0x279df2;return Ss(_0x2fbbfc)&&!!((_0x279df2=window['navigator'])!=null&&_0x279df2['standalone']);}function Tf(){return pc()&&document['documentMode']===0xa;}function Ma(_0x432590=W()){return Ss(_0x432590)||Pa(_0x432590)||Da(_0x432590)||Oa(_0x432590)||/windows phone/i['test'](_0x432590)||Na(_0x432590);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x458896,_0x4f595e=[]){let _0x4c44f0;switch(_0x458896){case'Browser':_0x4c44f0=br(W());break;case'Worker':_0x4c44f0=br(W())+'-'+_0x458896;break;default:_0x4c44f0=_0x458896;}const _0x552e69=_0x4f595e['length']?_0x4f595e['join'](','):'FirebaseCore-web';return _0x4c44f0+'/JsCore/'+lt+'/'+_0x552e69;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sf{constructor(_0x22e969){this['auth']=_0x22e969,this['queue']=[];}['pushCallback'](_0x1b668e,_0x4d4783){const _0x165059=_0x23547b=>new Promise((_0x302fbd,_0x12edc5)=>{try{const _0x184b19=_0x1b668e(_0x23547b);_0x302fbd(_0x184b19);}catch(_0x5eb2ad){_0x12edc5(_0x5eb2ad);}});_0x165059['onAbort']=_0x4d4783,this['queue']['push'](_0x165059);const _0x4dd7a4=this['queue']['length']-0x1;return()=>{this['queue'][_0x4dd7a4]=()=>Promise['resolve']();};}async['runMiddleware'](_0x1a3354){if(this['auth']['currentUser']===_0x1a3354)return;const _0x28f4b6=[];try{for(const _0x5e8e74 of this['queue'])await _0x5e8e74(_0x1a3354),_0x5e8e74['onAbort']&&_0x28f4b6['push'](_0x5e8e74['onAbort']);}catch(_0x493e4a){_0x28f4b6['reverse']();for(const _0x26b93e of _0x28f4b6)try{_0x26b93e();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x493e4a==null?void 0x0:_0x493e4a['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bf(_0x2955b6,_0x711aa7={}){return Ae(_0x2955b6,'GET','/v2/passwordPolicy',Re(_0x2955b6,_0x711aa7));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rf=0x6;class Af{constructor(_0x28adfd){var _0x173f9c;const _0x170081=_0x28adfd['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x170081['minPasswordLength']??Rf,_0x170081['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x170081['maxPasswordLength']),_0x170081['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x170081['containsLowercaseCharacter']),_0x170081['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x170081['containsUppercaseCharacter']),_0x170081['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x170081['containsNumericCharacter']),_0x170081['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x170081['containsNonAlphanumericCharacter']),this['enforcementState']=_0x28adfd['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0x173f9c=_0x28adfd['allowedNonAlphanumericCharacters'])==null?void 0x0:_0x173f9c['join'](''))??'',this['forceUpgradeOnSignin']=_0x28adfd['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x28adfd['schemaVersion'];}['validatePassword'](_0x41571a){const _0x620b99={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x41571a,_0x620b99),this['validatePasswordCharacterOptions'](_0x41571a,_0x620b99),_0x620b99['isValid']&&(_0x620b99['isValid']=_0x620b99['meetsMinPasswordLength']??!0x0),_0x620b99['isValid']&&(_0x620b99['isValid']=_0x620b99['meetsMaxPasswordLength']??!0x0),_0x620b99['isValid']&&(_0x620b99['isValid']=_0x620b99['containsLowercaseLetter']??!0x0),_0x620b99['isValid']&&(_0x620b99['isValid']=_0x620b99['containsUppercaseLetter']??!0x0),_0x620b99['isValid']&&(_0x620b99['isValid']=_0x620b99['containsNumericCharacter']??!0x0),_0x620b99['isValid']&&(_0x620b99['isValid']=_0x620b99['containsNonAlphanumericCharacter']??!0x0),_0x620b99;}['validatePasswordLengthOptions'](_0x1b6cc6,_0x9b8ec0){const _0x157c2a=this['customStrengthOptions']['minPasswordLength'],_0x5eb96e=this['customStrengthOptions']['maxPasswordLength'];_0x157c2a&&(_0x9b8ec0['meetsMinPasswordLength']=_0x1b6cc6['length']>=_0x157c2a),_0x5eb96e&&(_0x9b8ec0['meetsMaxPasswordLength']=_0x1b6cc6['length']<=_0x5eb96e);}['validatePasswordCharacterOptions'](_0x42a895,_0x59f73b){this['updatePasswordCharacterOptionsStatuses'](_0x59f73b,!0x1,!0x1,!0x1,!0x1);let _0x57a654;for(let _0x5e849d=0x0;_0x5e849d<_0x42a895['length'];_0x5e849d++)_0x57a654=_0x42a895['charAt'](_0x5e849d),this['updatePasswordCharacterOptionsStatuses'](_0x59f73b,_0x57a654>='a'&&_0x57a654<='z',_0x57a654>='A'&&_0x57a654<='Z',_0x57a654>='0'&&_0x57a654<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x57a654));}['updatePasswordCharacterOptionsStatuses'](_0x5efc9c,_0x3f4cee,_0x4760e6,_0x4751b5,_0x3db118){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x5efc9c['containsLowercaseLetter']||(_0x5efc9c['containsLowercaseLetter']=_0x3f4cee)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x5efc9c['containsUppercaseLetter']||(_0x5efc9c['containsUppercaseLetter']=_0x4760e6)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x5efc9c['containsNumericCharacter']||(_0x5efc9c['containsNumericCharacter']=_0x4751b5)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x5efc9c['containsNonAlphanumericCharacter']||(_0x5efc9c['containsNonAlphanumericCharacter']=_0x3db118));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x124def,_0xc75ad,_0x1d72b4,_0x5d829f){this['app']=_0x124def,this['heartbeatServiceProvider']=_0xc75ad,this['appCheckServiceProvider']=_0x1d72b4,this['config']=_0x5d829f,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new Sf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x124def['name'],this['clientVersion']=_0x5d829f['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0x22282e=>this['_resolvePersistenceManagerAvailable']=_0x22282e);}['_initializeWithPersistence'](_0x41f82f,_0x101c79){return _0x101c79&&(this['_popupRedirectResolver']=ie(_0x101c79)),this['_initializationPromise']=this['queue'](async()=>{var _0x219ca8,_0x487d69,_0x462cf9;if(!this['_deleted']&&(this['persistenceManager']=await Je['create'](this,_0x41f82f),(_0x219ca8=this['_resolvePersistenceManagerAvailable'])==null||_0x219ca8['call'](this),!this['_deleted'])){if((_0x487d69=this['_popupRedirectResolver'])!=null&&_0x487d69['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x101c79),this['lastNotifiedUid']=((_0x462cf9=this['currentUser'])==null?void 0x0:_0x462cf9['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0xaf212e=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0xaf212e)){if(this['currentUser']&&_0xaf212e&&this['currentUser']['uid']===_0xaf212e['uid']){this['_currentUser']['_assign'](_0xaf212e),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0xaf212e,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x1a13c9){try{const _0xbc7308=await bn(this,{'idToken':_0x1a13c9}),_0x5d515c=await K['_fromGetAccountInfoResponse'](this,_0xbc7308,_0x1a13c9);await this['directlySetCurrentUser'](_0x5d515c);}catch(_0x3875c6){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x3875c6),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x191707){var _0x520058;if($(this['app'])){const _0x1423ea=this['app']['settings']['authIdToken'];return _0x1423ea?new Promise(_0x5abca3=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x1423ea)['then'](_0x5abca3,_0x5abca3));}):this['directlySetCurrentUser'](null);}const _0x241714=await this['assertedPersistence']['getCurrentUser']();let _0x1a0a93=_0x241714,_0x455e16=!0x1;if(_0x191707&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x145664=(_0x520058=this['redirectUser'])==null?void 0x0:_0x520058['_redirectEventId'],_0x523c4a=_0x1a0a93==null?void 0x0:_0x1a0a93['_redirectEventId'],_0x825a13=await this['tryRedirectSignIn'](_0x191707);(!_0x145664||_0x145664===_0x523c4a)&&(_0x825a13!=null&&_0x825a13['user'])&&(_0x1a0a93=_0x825a13['user'],_0x455e16=!0x0);}if(!_0x1a0a93)return this['directlySetCurrentUser'](null);if(!_0x1a0a93['_redirectEventId']){if(_0x455e16)try{await this['beforeStateQueue']['runMiddleware'](_0x1a0a93);}catch(_0x2c20e4){_0x1a0a93=_0x241714,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0x2c20e4));}return _0x1a0a93?this['reloadAndSetCurrentUserOrClear'](_0x1a0a93):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x1a0a93['_redirectEventId']?this['directlySetCurrentUser'](_0x1a0a93):this['reloadAndSetCurrentUserOrClear'](_0x1a0a93);}async['tryRedirectSignIn'](_0x1daa98){let _0x28d107=null;try{_0x28d107=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0x1daa98,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x28d107;}async['reloadAndSetCurrentUserOrClear'](_0x3c85f7){try{await Rn(_0x3c85f7);}catch(_0x3d2725){if((_0x3d2725==null?void 0x0:_0x3d2725['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x3c85f7);}['useDeviceLanguage'](){this['languageCode']=af();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x37bbab){if($(this['app']))return Promise['reject'](re(this));const _0x69ddb8=_0x37bbab?N(_0x37bbab):null;return _0x69ddb8&&m(_0x69ddb8['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x69ddb8&&_0x69ddb8['_clone'](this));}async['_updateCurrentUser'](_0x1f5314,_0x379374=!0x1){if(!this['_deleted'])return _0x1f5314&&m(this['tenantId']===_0x1f5314['tenantId'],this,'tenant-id-mismatch'),_0x379374||await this['beforeStateQueue']['runMiddleware'](_0x1f5314),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x1f5314),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x16c59b){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x16c59b));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x2ae19e){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x55bcef=this['_getPasswordPolicyInternal']();return _0x55bcef['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x55bcef['validatePassword'](_0x2ae19e);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0x2d0e1f=await bf(this),_0x2b7404=new Af(_0x2d0e1f);this['tenantId']===null?this['_projectPasswordPolicy']=_0x2b7404:this['_tenantPasswordPolicies'][this['tenantId']]=_0x2b7404;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0xb66d51){this['_errorFactory']=new Bt('auth','Firebase',_0xb66d51());}['onAuthStateChanged'](_0x321ffd,_0x14bf56,_0x52681b){return this['registerStateListener'](this['authStateSubscription'],_0x321ffd,_0x14bf56,_0x52681b);}['beforeAuthStateChanged'](_0x489470,_0x432759){return this['beforeStateQueue']['pushCallback'](_0x489470,_0x432759);}['onIdTokenChanged'](_0x408f88,_0x1adf53,_0x2f3106){return this['registerStateListener'](this['idTokenSubscription'],_0x408f88,_0x1adf53,_0x2f3106);}['authStateReady'](){return new Promise((_0x175055,_0x2dd918)=>{if(this['currentUser'])_0x175055();else{const _0x2b9a01=this['onAuthStateChanged'](()=>{_0x2b9a01(),_0x175055();},_0x2dd918);}});}async['revokeAccessToken'](_0x53a86d){if(this['currentUser']){const _0x1ca0e4=await this['currentUser']['getIdToken'](),_0x50ae01={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x53a86d,'idToken':_0x1ca0e4};this['tenantId']!=null&&(_0x50ae01['tenantId']=this['tenantId']),await wf(this,_0x50ae01);}}['toJSON'](){var _0x460148;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x460148=this['_currentUser'])==null?void 0x0:_0x460148['toJSON']()};}async['_setRedirectUser'](_0x4138be,_0x400df7){const _0x449666=await this['getOrInitRedirectPersistenceManager'](_0x400df7);return _0x4138be===null?_0x449666['removeCurrentUser']():_0x449666['setCurrentUser'](_0x4138be);}async['getOrInitRedirectPersistenceManager'](_0x569b6d){if(!this['redirectPersistenceManager']){const _0x3c6006=_0x569b6d&&ie(_0x569b6d)||this['_popupRedirectResolver'];m(_0x3c6006,this,'argument-error'),this['redirectPersistenceManager']=await Je['create'](this,[ie(_0x3c6006['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0xdf383f){var _0x5b3044,_0x22e1aa;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x5b3044=this['_currentUser'])==null?void 0x0:_0x5b3044['_redirectEventId'])===_0xdf383f?this['_currentUser']:((_0x22e1aa=this['redirectUser'])==null?void 0x0:_0x22e1aa['_redirectEventId'])===_0xdf383f?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x16e177){if(_0x16e177===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x16e177));}['_notifyListenersIfCurrent'](_0x8b3d4b){_0x8b3d4b===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x1914e1;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x5911ba=((_0x1914e1=this['currentUser'])==null?void 0x0:_0x1914e1['uid'])??null;this['lastNotifiedUid']!==_0x5911ba&&(this['lastNotifiedUid']=_0x5911ba,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x599d85,_0x274554,_0x5171ce,_0x26b555){if(this['_deleted'])return()=>{};const _0x146216=typeof _0x274554=='function'?_0x274554:_0x274554['next']['bind'](_0x274554);let _0x37122c=!0x1;const _0x294bc8=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x294bc8,this,'internal-error'),_0x294bc8['then'](()=>{_0x37122c||_0x146216(this['currentUser']);}),typeof _0x274554=='function'){const _0xdd0bec=_0x599d85['addObserver'](_0x274554,_0x5171ce,_0x26b555);return()=>{_0x37122c=!0x0,_0xdd0bec();};}else{const _0x4c111c=_0x599d85['addObserver'](_0x274554);return()=>{_0x37122c=!0x0,_0x4c111c();};}}async['directlySetCurrentUser'](_0x542034){this['currentUser']&&this['currentUser']!==_0x542034&&this['_currentUser']['_stopProactiveRefresh'](),_0x542034&&this['isProactiveRefreshEnabled']&&_0x542034['_startProactiveRefresh'](),this['currentUser']=_0x542034,_0x542034?await this['assertedPersistence']['setCurrentUser'](_0x542034):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0x433498){return this['operations']=this['operations']['then'](_0x433498,_0x433498),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x4402c8){!_0x4402c8||this['frameworks']['includes'](_0x4402c8)||(this['frameworks']['push'](_0x4402c8),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x453593;const _0x1e2c79={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x1e2c79['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x5ae613=await((_0x453593=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x453593['getHeartbeatsHeader']());_0x5ae613&&(_0x1e2c79['X-Firebase-Client']=_0x5ae613);const _0x27e459=await this['_getAppCheckToken']();return _0x27e459&&(_0x1e2c79['X-Firebase-AppCheck']=_0x27e459),_0x1e2c79;}async['_getAppCheckToken'](){var _0x149932;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x4e5bd6=await((_0x149932=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x149932['getToken']());return _0x4e5bd6!=null&&_0x4e5bd6['error']&&sf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x4e5bd6['error']),_0x4e5bd6==null?void 0x0:_0x4e5bd6['token'];}}function qe(_0x2c9d65){return N(_0x2c9d65);}class Rr{constructor(_0x1fa42c){this['auth']=_0x1fa42c,this['observer']=null,this['addObserver']=Tc(_0x1b9192=>this['observer']=_0x1b9192);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Nf(_0x2937fe){jn=_0x2937fe;}function xa(_0x14ed94){return jn['loadJS'](_0x14ed94);}function Pf(){return jn['recaptchaEnterpriseScript'];}function Of(){return jn['gapiScript'];}function Df(_0x5b1334){return'__'+_0x5b1334+Math['floor'](Math['random']()*0xf4240);}class Mf{constructor(){this['enterprise']=new Lf();}['ready'](_0x19b239){_0x19b239();}['execute'](_0x3d6795,_0x49a338){return Promise['resolve']('token');}['render'](_0x4f3631,_0x460122){return'';}}class Lf{['ready'](_0x2fbf0c){_0x2fbf0c();}['execute'](_0x263eea,_0x21f79a){return Promise['resolve']('token');}['render'](_0x2a01cb,_0x447b81){return'';}}const xf='recaptcha-enterprise',Fa='NO_RECAPTCHA';class Ff{constructor(_0x51ecfb){this['type']=xf,this['auth']=qe(_0x51ecfb);}async['verify'](_0x490cf4='verify',_0x4f9ba6=!0x1){async function _0x73642e(_0x187eb9){if(!_0x4f9ba6){if(_0x187eb9['tenantId']==null&&_0x187eb9['_agentRecaptchaConfig']!=null)return _0x187eb9['_agentRecaptchaConfig']['siteKey'];if(_0x187eb9['tenantId']!=null&&_0x187eb9['_tenantRecaptchaConfigs'][_0x187eb9['tenantId']]!==void 0x0)return _0x187eb9['_tenantRecaptchaConfigs'][_0x187eb9['tenantId']]['siteKey'];}return new Promise(async(_0x485340,_0x1611be)=>{pf(_0x187eb9,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0xe5edf3=>{if(_0xe5edf3['recaptchaKey']===void 0x0)_0x1611be(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x12b7d6=new ff(_0xe5edf3);return _0x187eb9['tenantId']==null?_0x187eb9['_agentRecaptchaConfig']=_0x12b7d6:_0x187eb9['_tenantRecaptchaConfigs'][_0x187eb9['tenantId']]=_0x12b7d6,_0x485340(_0x12b7d6['siteKey']);}})['catch'](_0x507742=>{_0x1611be(_0x507742);});});}function _0x2c88c7(_0x523175,_0x418ec6,_0x492fd7){const _0x213c3d=window['grecaptcha'];wr(_0x213c3d)?_0x213c3d['enterprise']['ready'](()=>{_0x213c3d['enterprise']['execute'](_0x523175,{'action':_0x490cf4})['then'](_0x4fb585=>{_0x418ec6(_0x4fb585);})['catch'](()=>{_0x418ec6(Fa);});}):_0x492fd7(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Mf()['execute']('siteKey',{'action':'verify'}):new Promise((_0x316121,_0x4e7d7c)=>{_0x73642e(this['auth'])['then'](_0x176ca3=>{if(!_0x4f9ba6&&wr(window['grecaptcha']))_0x2c88c7(_0x176ca3,_0x316121,_0x4e7d7c);else{if(typeof window>'u'){_0x4e7d7c(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x22d015=Pf();_0x22d015['length']!==0x0&&(_0x22d015+=_0x176ca3),xa(_0x22d015)['then'](()=>{_0x2c88c7(_0x176ca3,_0x316121,_0x4e7d7c);})['catch'](_0x7bfa24=>{_0x4e7d7c(_0x7bfa24);});}})['catch'](_0x2c679d=>{_0x4e7d7c(_0x2c679d);});});}}async function Ar(_0x277823,_0x368315,_0x2ceec2,_0x483413=!0x1,_0x1dd1ec=!0x1){const _0x5c9f12=new Ff(_0x277823);let _0xbf4a01;if(_0x1dd1ec)_0xbf4a01=Fa;else try{_0xbf4a01=await _0x5c9f12['verify'](_0x2ceec2);}catch{_0xbf4a01=await _0x5c9f12['verify'](_0x2ceec2,!0x0);}const _0x5d7fea={..._0x368315};if(_0x2ceec2==='mfaSmsEnrollment'||_0x2ceec2==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x5d7fea){const _0x38f430=_0x5d7fea['phoneEnrollmentInfo']['phoneNumber'],_0x6cf49f=_0x5d7fea['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x5d7fea,{'phoneEnrollmentInfo':{'phoneNumber':_0x38f430,'recaptchaToken':_0x6cf49f,'captchaResponse':_0xbf4a01,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x5d7fea){const _0x36089b=_0x5d7fea['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x5d7fea,{'phoneSignInInfo':{'recaptchaToken':_0x36089b,'captchaResponse':_0xbf4a01,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x5d7fea;}return _0x483413?Object['assign'](_0x5d7fea,{'captchaResp':_0xbf4a01}):Object['assign'](_0x5d7fea,{'captchaResponse':_0xbf4a01}),Object['assign'](_0x5d7fea,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x5d7fea,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x5d7fea;}async function Di(_0x1677ed,_0x246c2d,_0x39acca,_0x10fdb2,_0x37a601){var _0x46eb18;if((_0x46eb18=_0x1677ed['_getRecaptchaConfig']())!=null&&_0x46eb18['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x31b3f9=await Ar(_0x1677ed,_0x246c2d,_0x39acca,_0x39acca==='getOobCode');return _0x10fdb2(_0x1677ed,_0x31b3f9);}else return _0x10fdb2(_0x1677ed,_0x246c2d)['catch'](async _0x192926=>{if(_0x192926['code']==='auth/missing-recaptcha-token'){console['log'](_0x39acca+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0x400793=await Ar(_0x1677ed,_0x246c2d,_0x39acca,_0x39acca==='getOobCode');return _0x10fdb2(_0x1677ed,_0x400793);}else return Promise['reject'](_0x192926);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Uf(_0x64636c,_0xf65499){const _0x102ac4=Bi(_0x64636c,'auth');if(_0x102ac4['isInitialized']()){const _0x247329=_0x102ac4['getImmediate'](),_0x30a115=_0x102ac4['getOptions']();if(Me(_0x30a115,_0xf65499??{}))return _0x247329;Q(_0x247329,'already-initialized');}return _0x102ac4['initialize']({'options':_0xf65499});}function Wf(_0xec57e2,_0x479e0c){const _0x104dae=(_0x479e0c==null?void 0x0:_0x479e0c['persistence'])||[],_0x10df65=(Array['isArray'](_0x104dae)?_0x104dae:[_0x104dae])['map'](ie);_0x479e0c!=null&&_0x479e0c['errorMap']&&_0xec57e2['_updateErrorMap'](_0x479e0c['errorMap']),_0xec57e2['_initializeWithPersistence'](_0x10df65,_0x479e0c==null?void 0x0:_0x479e0c['popupRedirectResolver']);}function Bf(_0x3f608e,_0xed9ce9,_0x36d314){const _0x301bf3=qe(_0x3f608e);m(/^https?:\/\//['test'](_0xed9ce9),_0x301bf3,'invalid-emulator-scheme');const _0x2f8fb4=!0x1,_0x47b036=Ua(_0xed9ce9),{host:_0x1691af,port:_0x41a398}=Vf(_0xed9ce9),_0x2f9f1d=_0x41a398===null?'':':'+_0x41a398,_0x3b5ddf={'url':_0x47b036+'//'+_0x1691af+_0x2f9f1d+'/'},_0x4e9f95=Object['freeze']({'host':_0x1691af,'port':_0x41a398,'protocol':_0x47b036['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x2f8fb4})});if(!_0x301bf3['_canInitEmulator']){m(_0x301bf3['config']['emulator']&&_0x301bf3['emulatorConfig'],_0x301bf3,'emulator-config-failed'),m(Me(_0x3b5ddf,_0x301bf3['config']['emulator'])&&Me(_0x4e9f95,_0x301bf3['emulatorConfig']),_0x301bf3,'emulator-config-failed');return;}_0x301bf3['config']['emulator']=_0x3b5ddf,_0x301bf3['emulatorConfig']=_0x4e9f95,_0x301bf3['settings']['appVerificationDisabledForTesting']=!0x0,at(_0x1691af)?(jr(_0x47b036+'//'+_0x1691af+_0x2f9f1d),Kr('Auth',!0x0)):Hf();}function Ua(_0x37a9d3){const _0x24dc00=_0x37a9d3['indexOf'](':');return _0x24dc00<0x0?'':_0x37a9d3['substr'](0x0,_0x24dc00+0x1);}function Vf(_0x214a3e){const _0x1a17ce=Ua(_0x214a3e),_0x3ae843=/(\/\/)?([^?#/]+)/['exec'](_0x214a3e['substr'](_0x1a17ce['length']));if(!_0x3ae843)return{'host':'','port':null};const _0xb5fb81=_0x3ae843[0x2]['split']('@')['pop']()||'',_0x4bd355=/^(\[[^\]]+\])(:|$)/['exec'](_0xb5fb81);if(_0x4bd355){const _0x4e0b41=_0x4bd355[0x1];return{'host':_0x4e0b41,'port':kr(_0xb5fb81['substr'](_0x4e0b41['length']+0x1))};}else{const [_0xca3886,_0x4286fc]=_0xb5fb81['split'](':');return{'host':_0xca3886,'port':kr(_0x4286fc)};}}function kr(_0x3fe868){if(!_0x3fe868)return null;const _0x58be27=Number(_0x3fe868);return isNaN(_0x58be27)?null:_0x58be27;}function Hf(){function _0x55b8ab(){const _0x4f959b=document['createElement']('p'),_0x318d6f=_0x4f959b['style'];_0x4f959b['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x318d6f['position']='fixed',_0x318d6f['width']='100%',_0x318d6f['backgroundColor']='#ffffff',_0x318d6f['border']='.1em\x20solid\x20#000000',_0x318d6f['color']='#b50000',_0x318d6f['bottom']='0px',_0x318d6f['left']='0px',_0x318d6f['margin']='0px',_0x318d6f['zIndex']='10000',_0x318d6f['textAlign']='center',_0x4f959b['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x4f959b);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x55b8ab):_0x55b8ab());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x31908e,_0x43151a){this['providerId']=_0x31908e,this['signInMethod']=_0x43151a;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x81ebc){return ne('not\x20implemented');}['_linkToIdToken'](_0x349943,_0x9e8367){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x270a89){return ne('not\x20implemented');}}async function $f(_0x521d5a,_0x1478cd){return Ae(_0x521d5a,'POST','/v1/accounts:signUp',_0x1478cd);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Gf(_0x406ce1,_0x1be310){return Qt(_0x406ce1,'POST','/v1/accounts:signInWithPassword',Re(_0x406ce1,_0x1be310));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function qf(_0x56f5c6,_0x49f309){return Qt(_0x56f5c6,'POST','/v1/accounts:signInWithEmailLink',Re(_0x56f5c6,_0x49f309));}async function zf(_0x93d781,_0x55e1b3){return Qt(_0x93d781,'POST','/v1/accounts:signInWithEmailLink',Re(_0x93d781,_0x55e1b3));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wt extends bs{constructor(_0x37fec9,_0x3c46e2,_0x49548e,_0x44b54=null){super('password',_0x49548e),this['_email']=_0x37fec9,this['_password']=_0x3c46e2,this['_tenantId']=_0x44b54;}static['_fromEmailAndPassword'](_0x3d63c0,_0xc2dfe1){return new Wt(_0x3d63c0,_0xc2dfe1,'password');}static['_fromEmailAndCode'](_0x53cdbc,_0x23d043,_0x180b51=null){return new Wt(_0x53cdbc,_0x23d043,'emailLink',_0x180b51);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x1ca112){const _0x13f6b0=typeof _0x1ca112=='string'?JSON['parse'](_0x1ca112):_0x1ca112;if(_0x13f6b0!=null&&_0x13f6b0['email']&&(_0x13f6b0!=null&&_0x13f6b0['password'])){if(_0x13f6b0['signInMethod']==='password')return this['_fromEmailAndPassword'](_0x13f6b0['email'],_0x13f6b0['password']);if(_0x13f6b0['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0x13f6b0['email'],_0x13f6b0['password'],_0x13f6b0['tenantId']);}return null;}async['_getIdTokenResponse'](_0x55aae0){switch(this['signInMethod']){case'password':const _0x57f709={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x55aae0,_0x57f709,'signInWithPassword',Gf);case'emailLink':return qf(_0x55aae0,{'email':this['_email'],'oobCode':this['_password']});default:Q(_0x55aae0,'internal-error');}}async['_linkToIdToken'](_0x480ff8,_0x512c3c){switch(this['signInMethod']){case'password':const _0x41a6ec={'idToken':_0x512c3c,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x480ff8,_0x41a6ec,'signUpPassword',$f);case'emailLink':return zf(_0x480ff8,{'idToken':_0x512c3c,'email':this['_email'],'oobCode':this['_password']});default:Q(_0x480ff8,'internal-error');}}['_getReauthenticationResolver'](_0x2b058c){return this['_getIdTokenResponse'](_0x2b058c);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xe(_0x4c7946,_0x5b2980){return Qt(_0x4c7946,'POST','/v1/accounts:signInWithIdp',Re(_0x4c7946,_0x5b2980));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jf='http://localhost';class Be extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x1a0ece){const _0x1ad5b8=new Be(_0x1a0ece['providerId'],_0x1a0ece['signInMethod']);return _0x1a0ece['idToken']||_0x1a0ece['accessToken']?(_0x1a0ece['idToken']&&(_0x1ad5b8['idToken']=_0x1a0ece['idToken']),_0x1a0ece['accessToken']&&(_0x1ad5b8['accessToken']=_0x1a0ece['accessToken']),_0x1a0ece['nonce']&&!_0x1a0ece['pendingToken']&&(_0x1ad5b8['nonce']=_0x1a0ece['nonce']),_0x1a0ece['pendingToken']&&(_0x1ad5b8['pendingToken']=_0x1a0ece['pendingToken'])):_0x1a0ece['oauthToken']&&_0x1a0ece['oauthTokenSecret']?(_0x1ad5b8['accessToken']=_0x1a0ece['oauthToken'],_0x1ad5b8['secret']=_0x1a0ece['oauthTokenSecret']):Q('argument-error'),_0x1ad5b8;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x37796b){const _0x5284eb=typeof _0x37796b=='string'?JSON['parse'](_0x37796b):_0x37796b,{providerId:_0x433b67,signInMethod:_0x2838f1,..._0xa13030}=_0x5284eb;if(!_0x433b67||!_0x2838f1)return null;const _0x13c4fc=new Be(_0x433b67,_0x2838f1);return _0x13c4fc['idToken']=_0xa13030['idToken']||void 0x0,_0x13c4fc['accessToken']=_0xa13030['accessToken']||void 0x0,_0x13c4fc['secret']=_0xa13030['secret'],_0x13c4fc['nonce']=_0xa13030['nonce'],_0x13c4fc['pendingToken']=_0xa13030['pendingToken']||null,_0x13c4fc;}['_getIdTokenResponse'](_0x274acf){const _0x18ed11=this['buildRequest']();return Xe(_0x274acf,_0x18ed11);}['_linkToIdToken'](_0x15e81e,_0x2a203b){const _0x2339e9=this['buildRequest']();return _0x2339e9['idToken']=_0x2a203b,Xe(_0x15e81e,_0x2339e9);}['_getReauthenticationResolver'](_0x3f1865){const _0x47425a=this['buildRequest']();return _0x47425a['autoCreate']=!0x1,Xe(_0x3f1865,_0x47425a);}['buildRequest'](){const _0x3d6e57={'requestUri':jf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x3d6e57['pendingToken']=this['pendingToken'];else{const _0x54116b={};this['idToken']&&(_0x54116b['id_token']=this['idToken']),this['accessToken']&&(_0x54116b['access_token']=this['accessToken']),this['secret']&&(_0x54116b['oauth_token_secret']=this['secret']),_0x54116b['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x54116b['nonce']=this['nonce']),_0x3d6e57['postBody']=ct(_0x54116b);}return _0x3d6e57;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Kf(_0x4dd048){switch(_0x4dd048){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Yf(_0x576f6a){const _0x41e33b=vt(Et(_0x576f6a))['link'],_0x1f60fe=_0x41e33b?vt(Et(_0x41e33b))['deep_link_id']:null,_0x1205ed=vt(Et(_0x576f6a))['deep_link_id'];return(_0x1205ed?vt(Et(_0x1205ed))['link']:null)||_0x1205ed||_0x1f60fe||_0x41e33b||_0x576f6a;}class Rs{constructor(_0x4738e4){const _0x2e4ee2=vt(Et(_0x4738e4)),_0x3c62be=_0x2e4ee2['apiKey']??null,_0x3a8623=_0x2e4ee2['oobCode']??null,_0x51374f=Kf(_0x2e4ee2['mode']??null);m(_0x3c62be&&_0x3a8623&&_0x51374f,'argument-error'),this['apiKey']=_0x3c62be,this['operation']=_0x51374f,this['code']=_0x3a8623,this['continueUrl']=_0x2e4ee2['continueUrl']??null,this['languageCode']=_0x2e4ee2['lang']??null,this['tenantId']=_0x2e4ee2['tenantId']??null;}static['parseLink'](_0x6f23fb){const _0x5ca888=Yf(_0x6f23fb);try{return new Rs(_0x5ca888);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pt{constructor(){this['providerId']=pt['PROVIDER_ID'];}static['credential'](_0x4acdd4,_0x5d3061){return Wt['_fromEmailAndPassword'](_0x4acdd4,_0x5d3061);}static['credentialWithLink'](_0xdb91d7,_0x2af7b3){const _0x3ecfb9=Rs['parseLink'](_0x2af7b3);return m(_0x3ecfb9,'argument-error'),Wt['_fromEmailAndCode'](_0xdb91d7,_0x3ecfb9['code'],_0x3ecfb9['tenantId']);}}pt['PROVIDER_ID']='password',pt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',pt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x493da4){this['providerId']=_0x493da4,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x1d89fc){this['defaultLanguageCode']=_0x1d89fc;}['setCustomParameters'](_0x2c2d58){return this['customParameters']=_0x2c2d58,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jt extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x7f6bf8){return this['scopes']['includes'](_0x7f6bf8)||this['scopes']['push'](_0x7f6bf8),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Jt{constructor(){super('facebook.com');}static['credential'](_0x4d4035){return Be['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x4d4035});}static['credentialFromResult'](_0x231cdb){return he['credentialFromTaggedObject'](_0x231cdb);}static['credentialFromError'](_0x54c021){return he['credentialFromTaggedObject'](_0x54c021['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4adc3c}){if(!_0x4adc3c||!('oauthAccessToken'in _0x4adc3c)||!_0x4adc3c['oauthAccessToken'])return null;try{return he['credential'](_0x4adc3c['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Jt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x143a01,_0x3fa097){return Be['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x143a01,'accessToken':_0x3fa097});}static['credentialFromResult'](_0xefc376){return ue['credentialFromTaggedObject'](_0xefc376);}static['credentialFromError'](_0x1cde38){return ue['credentialFromTaggedObject'](_0x1cde38['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4bf152}){if(!_0x4bf152)return null;const {oauthIdToken:_0x3aa00c,oauthAccessToken:_0x2b3352}=_0x4bf152;if(!_0x3aa00c&&!_0x2b3352)return null;try{return ue['credential'](_0x3aa00c,_0x2b3352);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Jt{constructor(){super('github.com');}static['credential'](_0x1a958f){return Be['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x1a958f});}static['credentialFromResult'](_0x50d2b9){return de['credentialFromTaggedObject'](_0x50d2b9);}static['credentialFromError'](_0x10071a){return de['credentialFromTaggedObject'](_0x10071a['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x182404}){if(!_0x182404||!('oauthAccessToken'in _0x182404)||!_0x182404['oauthAccessToken'])return null;try{return de['credential'](_0x182404['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Jt{constructor(){super('twitter.com');}static['credential'](_0xcbd8f3,_0x3332bb){return Be['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0xcbd8f3,'oauthTokenSecret':_0x3332bb});}static['credentialFromResult'](_0x1df807){return fe['credentialFromTaggedObject'](_0x1df807);}static['credentialFromError'](_0x6b971b){return fe['credentialFromTaggedObject'](_0x6b971b['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4cf0b7}){if(!_0x4cf0b7)return null;const {oauthAccessToken:_0x1a32ea,oauthTokenSecret:_0x96a1e4}=_0x4cf0b7;if(!_0x1a32ea||!_0x96a1e4)return null;try{return fe['credential'](_0x1a32ea,_0x96a1e4);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Qf(_0x11d5d1,_0x39b929){return Qt(_0x11d5d1,'POST','/v1/accounts:signUp',Re(_0x11d5d1,_0x39b929));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(_0x5465bc){this['user']=_0x5465bc['user'],this['providerId']=_0x5465bc['providerId'],this['_tokenResponse']=_0x5465bc['_tokenResponse'],this['operationType']=_0x5465bc['operationType'];}static async['_fromIdTokenResponse'](_0x126c09,_0x4d9f65,_0x1d7ec8,_0xe1d937=!0x1){const _0xce13c8=await K['_fromIdTokenResponse'](_0x126c09,_0x1d7ec8,_0xe1d937),_0x1f09d4=Nr(_0x1d7ec8);return new Ve({'user':_0xce13c8,'providerId':_0x1f09d4,'_tokenResponse':_0x1d7ec8,'operationType':_0x4d9f65});}static async['_forOperation'](_0x15fae2,_0x5891aa,_0x27d3a7){await _0x15fae2['_updateTokensIfNecessary'](_0x27d3a7,!0x0);const _0x55e488=Nr(_0x27d3a7);return new Ve({'user':_0x15fae2,'providerId':_0x55e488,'_tokenResponse':_0x27d3a7,'operationType':_0x5891aa});}}function Nr(_0x18d981){return _0x18d981['providerId']?_0x18d981['providerId']:'phoneNumber'in _0x18d981?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class An extends Se{constructor(_0x11d77d,_0x48f07c,_0x2e036e,_0x3dfa62){super(_0x48f07c['code'],_0x48f07c['message']),this['operationType']=_0x2e036e,this['user']=_0x3dfa62,Object['setPrototypeOf'](this,An['prototype']),this['customData']={'appName':_0x11d77d['name'],'tenantId':_0x11d77d['tenantId']??void 0x0,'_serverResponse':_0x48f07c['customData']['_serverResponse'],'operationType':_0x2e036e};}static['_fromErrorAndOperation'](_0x486b12,_0x571b8f,_0x460cd3,_0x41711f){return new An(_0x486b12,_0x571b8f,_0x460cd3,_0x41711f);}}function Ba(_0x454e71,_0x2fd78d,_0x2e20b4,_0x5bf9a1){return(_0x2fd78d==='reauthenticate'?_0x2e20b4['_getReauthenticationResolver'](_0x454e71):_0x2e20b4['_getIdTokenResponse'](_0x454e71))['catch'](_0x2c4194=>{throw _0x2c4194['code']==='auth/multi-factor-auth-required'?An['_fromErrorAndOperation'](_0x454e71,_0x2c4194,_0x2fd78d,_0x5bf9a1):_0x2c4194;});}async function Jf(_0x178d14,_0xa4d357,_0x36d91a=!0x1){const _0x20e164=await Ut(_0x178d14,_0xa4d357['_linkToIdToken'](_0x178d14['auth'],await _0x178d14['getIdToken']()),_0x36d91a);return Ve['_forOperation'](_0x178d14,'link',_0x20e164);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xf(_0x398987,_0x4bba53,_0x4cc039=!0x1){const {auth:_0x458cd4}=_0x398987;if($(_0x458cd4['app']))return Promise['reject'](re(_0x458cd4));const _0x43e51='reauthenticate';try{const _0xacf52=await Ut(_0x398987,Ba(_0x458cd4,_0x43e51,_0x4bba53,_0x398987),_0x4cc039);m(_0xacf52['idToken'],_0x458cd4,'internal-error');const _0x59be9e=Ts(_0xacf52['idToken']);m(_0x59be9e,_0x458cd4,'internal-error');const {sub:_0x16068d}=_0x59be9e;return m(_0x398987['uid']===_0x16068d,_0x458cd4,'user-mismatch'),Ve['_forOperation'](_0x398987,_0x43e51,_0xacf52);}catch(_0x54d2ef){throw(_0x54d2ef==null?void 0x0:_0x54d2ef['code'])==='auth/user-not-found'&&Q(_0x458cd4,'user-mismatch'),_0x54d2ef;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x359f85,_0x3ba72c,_0x537779=!0x1){if($(_0x359f85['app']))return Promise['reject'](re(_0x359f85));const _0x31853d='signIn',_0x20fb89=await Ba(_0x359f85,_0x31853d,_0x3ba72c),_0x2ee3c3=await Ve['_fromIdTokenResponse'](_0x359f85,_0x31853d,_0x20fb89);return _0x537779||await _0x359f85['_updateCurrentUser'](_0x2ee3c3['user']),_0x2ee3c3;}async function Zf(_0x140a4b,_0x1ad48c){return Va(qe(_0x140a4b),_0x1ad48c);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0x34d25b){const _0x1d7bac=qe(_0x34d25b);_0x1d7bac['_getPasswordPolicyInternal']()&&await _0x1d7bac['_updatePasswordPolicy']();}async function P_(_0x7f418,_0xf4bd50,_0x1c5640){if($(_0x7f418['app']))return Promise['reject'](re(_0x7f418));const _0x3fd058=qe(_0x7f418),_0x418bd8=await Di(_0x3fd058,{'returnSecureToken':!0x0,'email':_0xf4bd50,'password':_0x1c5640,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Qf)['catch'](_0x48317d=>{throw _0x48317d['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x7f418),_0x48317d;}),_0x5015cf=await Ve['_fromIdTokenResponse'](_0x3fd058,'signIn',_0x418bd8);return await _0x3fd058['_updateCurrentUser'](_0x5015cf['user']),_0x5015cf;}function O_(_0x4fe599,_0x4a7331,_0x1c189f){return $(_0x4fe599['app'])?Promise['reject'](re(_0x4fe599)):Zf(N(_0x4fe599),pt['credential'](_0x4a7331,_0x1c189f))['catch'](async _0x5e7772=>{throw _0x5e7772['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x4fe599),_0x5e7772;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function D_(_0x9ee5c7,_0x370dc2){return N(_0x9ee5c7)['setPersistence'](_0x370dc2);}function ep(_0x2f01a1,_0x33e39e,_0x1a3346,_0x343075){return N(_0x2f01a1)['onIdTokenChanged'](_0x33e39e,_0x1a3346,_0x343075);}function tp(_0xf1429c,_0x288191,_0x4cb9c8){return N(_0xf1429c)['beforeAuthStateChanged'](_0x288191,_0x4cb9c8);}function M_(_0xce0c34,_0x1c2d5f,_0xcfa97a,_0x1cbb5b){return N(_0xce0c34)['onAuthStateChanged'](_0x1c2d5f,_0xcfa97a,_0x1cbb5b);}function L_(_0x2d1800){return N(_0x2d1800)['signOut']();}const kn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x29ea15,_0x4d63e3){this['storageRetriever']=_0x29ea15,this['type']=_0x4d63e3;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](kn,'1'),this['storage']['removeItem'](kn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x322016,_0x27765c){return this['storage']['setItem'](_0x322016,JSON['stringify'](_0x27765c)),Promise['resolve']();}['_get'](_0x4de6cf){const _0xd56deb=this['storage']['getItem'](_0x4de6cf);return Promise['resolve'](_0xd56deb?JSON['parse'](_0xd56deb):null);}['_remove'](_0x3553dc){return this['storage']['removeItem'](_0x3553dc),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const np=0x3e8,ip=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x202905,_0xf5701e)=>this['onStorageEvent'](_0x202905,_0xf5701e),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x5f46a3){for(const _0x443f7d of Object['keys'](this['listeners'])){const _0x2c3091=this['storage']['getItem'](_0x443f7d),_0xc347ac=this['localCache'][_0x443f7d];_0x2c3091!==_0xc347ac&&_0x5f46a3(_0x443f7d,_0xc347ac,_0x2c3091);}}['onStorageEvent'](_0x2d70bc,_0x32dec4=!0x1){if(!_0x2d70bc['key']){this['forAllChangedKeys']((_0x3a1ad9,_0x33e767,_0x1b282b)=>{this['notifyListeners'](_0x3a1ad9,_0x1b282b);});return;}const _0x1d6264=_0x2d70bc['key'];_0x32dec4?this['detachListener']():this['stopPolling']();const _0x47b691=()=>{const _0x49484a=this['storage']['getItem'](_0x1d6264);!_0x32dec4&&this['localCache'][_0x1d6264]===_0x49484a||this['notifyListeners'](_0x1d6264,_0x49484a);},_0x5a49c9=this['storage']['getItem'](_0x1d6264);Tf()&&_0x5a49c9!==_0x2d70bc['newValue']&&_0x2d70bc['newValue']!==_0x2d70bc['oldValue']?setTimeout(_0x47b691,ip):_0x47b691();}['notifyListeners'](_0x544902,_0x264b34){this['localCache'][_0x544902]=_0x264b34;const _0x550237=this['listeners'][_0x544902];if(_0x550237){for(const _0x17443f of Array['from'](_0x550237))_0x17443f(_0x264b34&&JSON['parse'](_0x264b34));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0x4b033f,_0x45cda4,_0x492376)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0x4b033f,'oldValue':_0x45cda4,'newValue':_0x492376}),!0x0);});},np);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x35736a,_0x4a2c09){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x35736a]||(this['listeners'][_0x35736a]=new Set(),this['localCache'][_0x35736a]=this['storage']['getItem'](_0x35736a)),this['listeners'][_0x35736a]['add'](_0x4a2c09);}['_removeListener'](_0x3b8009,_0x2697d5){this['listeners'][_0x3b8009]&&(this['listeners'][_0x3b8009]['delete'](_0x2697d5),this['listeners'][_0x3b8009]['size']===0x0&&delete this['listeners'][_0x3b8009]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x1abc70,_0x4ad656){await super['_set'](_0x1abc70,_0x4ad656),this['localCache'][_0x1abc70]=JSON['stringify'](_0x4ad656);}async['_get'](_0x538156){const _0x53fe29=await super['_get'](_0x538156);return this['localCache'][_0x538156]=JSON['stringify'](_0x53fe29),_0x53fe29;}async['_remove'](_0xf89dc6){await super['_remove'](_0xf89dc6),delete this['localCache'][_0xf89dc6];}}Ga['type']='LOCAL';const sp=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x732cb6,_0xe07e47){}['_removeListener'](_0x2fcc59,_0x45796c){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rp(_0x4dfb14){return Promise['all'](_0x4dfb14['map'](async _0x91110=>{try{return{'fulfilled':!0x0,'value':await _0x91110};}catch(_0x37bb28){return{'fulfilled':!0x1,'reason':_0x37bb28};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kn{constructor(_0xa67e16){this['eventTarget']=_0xa67e16,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x2f26fd){const _0x8fe7b6=this['receivers']['find'](_0x3a9d64=>_0x3a9d64['isListeningto'](_0x2f26fd));if(_0x8fe7b6)return _0x8fe7b6;const _0x4cd855=new Kn(_0x2f26fd);return this['receivers']['push'](_0x4cd855),_0x4cd855;}['isListeningto'](_0x3e5e30){return this['eventTarget']===_0x3e5e30;}async['handleEvent'](_0x4ef033){const _0x1a51eb=_0x4ef033,{eventId:_0x3e6552,eventType:_0x38887c,data:_0x359aa0}=_0x1a51eb['data'],_0x4a8694=this['handlersMap'][_0x38887c];if(!(_0x4a8694!=null&&_0x4a8694['size']))return;_0x1a51eb['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x3e6552,'eventType':_0x38887c});const _0x57eff9=Array['from'](_0x4a8694)['map'](async _0x34d8cc=>_0x34d8cc(_0x1a51eb['origin'],_0x359aa0)),_0x14874f=await rp(_0x57eff9);_0x1a51eb['ports'][0x0]['postMessage']({'status':'done','eventId':_0x3e6552,'eventType':_0x38887c,'response':_0x14874f});}['_subscribe'](_0x2c0e63,_0xb0758d){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x2c0e63]||(this['handlersMap'][_0x2c0e63]=new Set()),this['handlersMap'][_0x2c0e63]['add'](_0xb0758d);}['_unsubscribe'](_0x4983a5,_0x27fef6){this['handlersMap'][_0x4983a5]&&_0x27fef6&&this['handlersMap'][_0x4983a5]['delete'](_0x27fef6),(!_0x27fef6||this['handlersMap'][_0x4983a5]['size']===0x0)&&delete this['handlersMap'][_0x4983a5],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Kn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x597e9b='',_0xb554d3=0xa){let _0x2470a0='';for(let _0x276bbb=0x0;_0x276bbb<_0xb554d3;_0x276bbb++)_0x2470a0+=Math['floor'](Math['random']()*0xa);return _0x597e9b+_0x2470a0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class op{constructor(_0x3bfcc6){this['target']=_0x3bfcc6,this['handlers']=new Set();}['removeMessageHandler'](_0x4ce3b5){_0x4ce3b5['messageChannel']&&(_0x4ce3b5['messageChannel']['port1']['removeEventListener']('message',_0x4ce3b5['onMessage']),_0x4ce3b5['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x4ce3b5);}async['_send'](_0x272141,_0x16193d,_0x2e7d24=0x32){const _0x4b2ceb=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x4b2ceb)throw new Error('connection_unavailable');let _0x40ff59,_0x212544;return new Promise((_0x3c1194,_0x44fb58)=>{const _0x4bf3ea=As('',0x14);_0x4b2ceb['port1']['start']();const _0x56d990=setTimeout(()=>{_0x44fb58(new Error('unsupported_event'));},_0x2e7d24);_0x212544={'messageChannel':_0x4b2ceb,'onMessage'(_0x1395ae){const _0x2a6106=_0x1395ae;if(_0x2a6106['data']['eventId']===_0x4bf3ea)switch(_0x2a6106['data']['status']){case'ack':clearTimeout(_0x56d990),_0x40ff59=setTimeout(()=>{_0x44fb58(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x40ff59),_0x3c1194(_0x2a6106['data']['response']);break;default:clearTimeout(_0x56d990),clearTimeout(_0x40ff59),_0x44fb58(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x212544),_0x4b2ceb['port1']['addEventListener']('message',_0x212544['onMessage']),this['target']['postMessage']({'eventType':_0x272141,'eventId':_0x4bf3ea,'data':_0x16193d},[_0x4b2ceb['port2']]);})['finally'](()=>{_0x212544&&this['removeMessageHandler'](_0x212544);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function ap(_0x34c992){Z()['location']['href']=_0x34c992;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function cp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function lp(){var _0x18b756;return((_0x18b756=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x18b756['controller'])||null;}function hp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',up=0x1,Nn='firebaseLocalStorage',Ya='fbase_key';class Xt{constructor(_0x19ebb3){this['request']=_0x19ebb3;}['toPromise'](){return new Promise((_0x53448c,_0x1ee1bf)=>{this['request']['addEventListener']('success',()=>{_0x53448c(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x1ee1bf(this['request']['error']);});});}}function Yn(_0x495e5a,_0x208410){return _0x495e5a['transaction']([Nn],_0x208410?'readwrite':'readonly')['objectStore'](Nn);}function dp(){const _0x37b42c=indexedDB['deleteDatabase'](Ka);return new Xt(_0x37b42c)['toPromise']();}function Mi(){const _0x227bed=indexedDB['open'](Ka,up);return new Promise((_0xa69b0f,_0x465ffc)=>{_0x227bed['addEventListener']('error',()=>{_0x465ffc(_0x227bed['error']);}),_0x227bed['addEventListener']('upgradeneeded',()=>{const _0x28248c=_0x227bed['result'];try{_0x28248c['createObjectStore'](Nn,{'keyPath':Ya});}catch(_0x2b7720){_0x465ffc(_0x2b7720);}}),_0x227bed['addEventListener']('success',async()=>{const _0x16e7be=_0x227bed['result'];_0x16e7be['objectStoreNames']['contains'](Nn)?_0xa69b0f(_0x16e7be):(_0x16e7be['close'](),await dp(),_0xa69b0f(await Mi()));});});}async function Pr(_0x19c7f4,_0x97a52e,_0x4dfe84){const _0x428050=Yn(_0x19c7f4,!0x0)['put']({[Ya]:_0x97a52e,'value':_0x4dfe84});return new Xt(_0x428050)['toPromise']();}async function fp(_0x1f59b1,_0x9a9347){const _0x58d363=Yn(_0x1f59b1,!0x1)['get'](_0x9a9347),_0x50de41=await new Xt(_0x58d363)['toPromise']();return _0x50de41===void 0x0?null:_0x50de41['value'];}function Or(_0x38b084,_0x166cfb){const _0x3239cf=Yn(_0x38b084,!0x0)['delete'](_0x166cfb);return new Xt(_0x3239cf)['toPromise']();}const pp=0x320,_p=0x3;class Qa{constructor(){this['type']='LOCAL',this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['db']?this['db']:(this['db']=await Mi(),this['db']);}async['_withRetries'](_0x144120){let _0x2e9b96=0x0;for(;;)try{const _0x2f34e2=await this['_openDb']();return await _0x144120(_0x2f34e2);}catch(_0x285fd7){if(_0x2e9b96++>_p)throw _0x285fd7;this['db']&&(this['db']['close'](),this['db']=void 0x0);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Kn['_getInstance'](hp()),this['receiver']['_subscribe']('keyChanged',async(_0x171e21,_0x56caf3)=>({'keyProcessed':(await this['_poll']())['includes'](_0x56caf3['key'])})),this['receiver']['_subscribe']('ping',async(_0x10655b,_0x1175e3)=>['keyChanged']);}async['initializeSender'](){var _0xab1789,_0x4cf912;if(this['activeServiceWorker']=await cp(),!this['activeServiceWorker'])return;this['sender']=new op(this['activeServiceWorker']);const _0x25be41=await this['sender']['_send']('ping',{},0x320);_0x25be41&&(_0xab1789=_0x25be41[0x0])!=null&&_0xab1789['fulfilled']&&(_0x4cf912=_0x25be41[0x0])!=null&&_0x4cf912['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0x24292d){if(!(!this['sender']||!this['activeServiceWorker']||lp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0x24292d},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{if(!indexedDB)return!0x1;const _0x34130f=await Mi();return await Pr(_0x34130f,kn,'1'),await Or(_0x34130f,kn),!0x0;}catch{}return!0x1;}async['_withPendingWrite'](_0x478749){this['pendingWrites']++;try{await _0x478749();}finally{this['pendingWrites']--;}}async['_set'](_0x15c0d3,_0x59da08){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x2da8d5=>Pr(_0x2da8d5,_0x15c0d3,_0x59da08)),this['localCache'][_0x15c0d3]=_0x59da08,this['notifyServiceWorker'](_0x15c0d3)));}async['_get'](_0x235cd7){const _0x49e283=await this['_withRetries'](_0x279c8d=>fp(_0x279c8d,_0x235cd7));return this['localCache'][_0x235cd7]=_0x49e283,_0x49e283;}async['_remove'](_0x3d5edb){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x5015a6=>Or(_0x5015a6,_0x3d5edb)),delete this['localCache'][_0x3d5edb],this['notifyServiceWorker'](_0x3d5edb)));}async['_poll'](){const _0x272127=await this['_withRetries'](_0x20193e=>{const _0xb71cc2=Yn(_0x20193e,!0x1)['getAll']();return new Xt(_0xb71cc2)['toPromise']();});if(!_0x272127)return[];if(this['pendingWrites']!==0x0)return[];const _0x350730=[],_0x11fdad=new Set();if(_0x272127['length']!==0x0){for(const {fbase_key:_0x1c023f,value:_0x2261fd}of _0x272127)_0x11fdad['add'](_0x1c023f),JSON['stringify'](this['localCache'][_0x1c023f])!==JSON['stringify'](_0x2261fd)&&(this['notifyListeners'](_0x1c023f,_0x2261fd),_0x350730['push'](_0x1c023f));}for(const _0x9a1ca9 of Object['keys'](this['localCache']))this['localCache'][_0x9a1ca9]&&!_0x11fdad['has'](_0x9a1ca9)&&(this['notifyListeners'](_0x9a1ca9,null),_0x350730['push'](_0x9a1ca9));return _0x350730;}['notifyListeners'](_0x2f4268,_0x4f6401){this['localCache'][_0x2f4268]=_0x4f6401;const _0x340034=this['listeners'][_0x2f4268];if(_0x340034){for(const _0x2b756d of Array['from'](_0x340034))_0x2b756d(_0x4f6401);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),pp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x43e66f,_0x1223b2){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x43e66f]||(this['listeners'][_0x43e66f]=new Set(),this['_get'](_0x43e66f)),this['listeners'][_0x43e66f]['add'](_0x1223b2);}['_removeListener'](_0xd82be2,_0x761434){this['listeners'][_0xd82be2]&&(this['listeners'][_0xd82be2]['delete'](_0x761434),this['listeners'][_0xd82be2]['size']===0x0&&delete this['listeners'][_0xd82be2]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Qa['type']='LOCAL';const gp=Qa;new Yt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function mp(_0x5e78ff,_0x1266c0){return _0x1266c0?ie(_0x1266c0):(m(_0x5e78ff['_popupRedirectResolver'],_0x5e78ff,'argument-error'),_0x5e78ff['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x244541){super('custom','custom'),this['params']=_0x244541;}['_getIdTokenResponse'](_0x3528d1){return Xe(_0x3528d1,this['_buildIdpRequest']());}['_linkToIdToken'](_0x12ef2d,_0x17e408){return Xe(_0x12ef2d,this['_buildIdpRequest'](_0x17e408));}['_getReauthenticationResolver'](_0x5a2fde){return Xe(_0x5a2fde,this['_buildIdpRequest']());}['_buildIdpRequest'](_0xc03e83){const _0x5b3622={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0xc03e83&&(_0x5b3622['idToken']=_0xc03e83),_0x5b3622;}}function yp(_0x163811){return Va(_0x163811['auth'],new ks(_0x163811),_0x163811['bypassAuthState']);}function vp(_0x2e9369){const {auth:_0xbf4144,user:_0x4166df}=_0x2e9369;return m(_0x4166df,_0xbf4144,'internal-error'),Xf(_0x4166df,new ks(_0x2e9369),_0x2e9369['bypassAuthState']);}async function Ep(_0x551002){const {auth:_0xeced61,user:_0x3bfbc8}=_0x551002;return m(_0x3bfbc8,_0xeced61,'internal-error'),Jf(_0x3bfbc8,new ks(_0x551002),_0x551002['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ja{constructor(_0x43d8e6,_0x17bdf4,_0x3665d6,_0x1810ee,_0x19ca6b=!0x1){this['auth']=_0x43d8e6,this['resolver']=_0x3665d6,this['user']=_0x1810ee,this['bypassAuthState']=_0x19ca6b,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x17bdf4)?_0x17bdf4:[_0x17bdf4];}['execute'](){return new Promise(async(_0x585037,_0xf7046a)=>{this['pendingPromise']={'resolve':_0x585037,'reject':_0xf7046a};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0x580565){this['reject'](_0x580565);}});}async['onAuthEvent'](_0x590d71){const {urlResponse:_0x39c1a5,sessionId:_0x508e3f,postBody:_0x9444d2,tenantId:_0x6421b8,error:_0x2b92b4,type:_0x60bb18}=_0x590d71;if(_0x2b92b4){this['reject'](_0x2b92b4);return;}const _0x5ee806={'auth':this['auth'],'requestUri':_0x39c1a5,'sessionId':_0x508e3f,'tenantId':_0x6421b8||void 0x0,'postBody':_0x9444d2||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x60bb18)(_0x5ee806));}catch(_0x5b5942){this['reject'](_0x5b5942);}}['onError'](_0x342d69){this['reject'](_0x342d69);}['getIdpTask'](_0x52dcb6){switch(_0x52dcb6){case'signInViaPopup':case'signInViaRedirect':return yp;case'linkViaPopup':case'linkViaRedirect':return Ep;case'reauthViaPopup':case'reauthViaRedirect':return vp;default:Q(this['auth'],'internal-error');}}['resolve'](_0x4f790e){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x4f790e),this['unregisterAndCleanUp']();}['reject'](_0x51e75b){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x51e75b),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ip=new Yt(0x7d0,0x2710);class Ke extends Ja{constructor(_0x5a29de,_0x158f32,_0xc0c85c,_0x3bbb92,_0x4b83da){super(_0x5a29de,_0x158f32,_0x3bbb92,_0x4b83da),this['provider']=_0xc0c85c,this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']&&Ke['currentPopupAction']['cancel'](),Ke['currentPopupAction']=this;}async['executeNotNull'](){const _0x35a13c=await this['execute']();return m(_0x35a13c,this['auth'],'internal-error'),_0x35a13c;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x38f1f6=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x38f1f6),this['authWindow']['associatedEvent']=_0x38f1f6,this['resolver']['_originValidation'](this['auth'])['catch'](_0x211d48=>{this['reject'](_0x211d48);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x370e6b=>{_0x370e6b||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x457557;return((_0x457557=this['authWindow'])==null?void 0x0:_0x457557['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']=null;}['pollUserCancellation'](){const _0x19d895=()=>{var _0x30d679,_0x561b21;if((_0x561b21=(_0x30d679=this['authWindow'])==null?void 0x0:_0x30d679['window'])!=null&&_0x561b21['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x19d895,Ip['get']());};_0x19d895();}}Ke['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const wp='pendingRedirect',on=new Map();class Cp extends Ja{constructor(_0x3e1403,_0x2f06a6,_0x2dee9a=!0x1){super(_0x3e1403,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x2f06a6,void 0x0,_0x2dee9a),this['eventId']=null;}async['execute'](){let _0x33dba2=on['get'](this['auth']['_key']());if(!_0x33dba2){try{const _0x5b9da3=await Tp(this['resolver'],this['auth'])?await super['execute']():null;_0x33dba2=()=>Promise['resolve'](_0x5b9da3);}catch(_0x1bcdd0){_0x33dba2=()=>Promise['reject'](_0x1bcdd0);}on['set'](this['auth']['_key'](),_0x33dba2);}return this['bypassAuthState']||on['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x33dba2();}async['onAuthEvent'](_0x345ac5){if(_0x345ac5['type']==='signInViaRedirect')return super['onAuthEvent'](_0x345ac5);if(_0x345ac5['type']==='unknown'){this['resolve'](null);return;}if(_0x345ac5['eventId']){const _0x555f15=await this['auth']['_redirectUserForId'](_0x345ac5['eventId']);if(_0x555f15)return this['user']=_0x555f15,super['onAuthEvent'](_0x345ac5);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Tp(_0x438ce1,_0x519ec5){const _0x241fa0=Rp(_0x519ec5),_0x5eec65=bp(_0x438ce1);if(!await _0x5eec65['_isAvailable']())return!0x1;const _0x3bc8cc=await _0x5eec65['_get'](_0x241fa0)==='true';return await _0x5eec65['_remove'](_0x241fa0),_0x3bc8cc;}function Sp(_0x1361dc,_0x2c340e){on['set'](_0x1361dc['_key'](),_0x2c340e);}function bp(_0x1ec9b9){return ie(_0x1ec9b9['_redirectPersistence']);}function Rp(_0x50238e){return rn(wp,_0x50238e['config']['apiKey'],_0x50238e['name']);}async function Ap(_0x79ba13,_0x1facce,_0x18b6ba=!0x1){if($(_0x79ba13['app']))return Promise['reject'](re(_0x79ba13));const _0x3ea12d=qe(_0x79ba13),_0x27be58=mp(_0x3ea12d,_0x1facce),_0x3fbf4f=await new Cp(_0x3ea12d,_0x27be58,_0x18b6ba)['execute']();return _0x3fbf4f&&!_0x18b6ba&&(delete _0x3fbf4f['user']['_redirectEventId'],await _0x3ea12d['_persistUserIfCurrent'](_0x3fbf4f['user']),await _0x3ea12d['_setRedirectUser'](null,_0x1facce)),_0x3fbf4f;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=0x258*0x3e8;class Np{constructor(_0x41d249){this['auth']=_0x41d249,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x370ab1){this['consumers']['add'](_0x370ab1),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x370ab1)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x370ab1),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0x6aa2b9){this['consumers']['delete'](_0x6aa2b9);}['onEvent'](_0x258ba4){if(this['hasEventBeenHandled'](_0x258ba4))return!0x1;let _0x243624=!0x1;return this['consumers']['forEach'](_0x208ee9=>{this['isEventForConsumer'](_0x258ba4,_0x208ee9)&&(_0x243624=!0x0,this['sendToConsumer'](_0x258ba4,_0x208ee9),this['saveEventToCache'](_0x258ba4));}),this['hasHandledPotentialRedirect']||!Pp(_0x258ba4)||(this['hasHandledPotentialRedirect']=!0x0,_0x243624||(this['queuedRedirectEvent']=_0x258ba4,_0x243624=!0x0)),_0x243624;}['sendToConsumer'](_0x5bdd6c,_0x49f939){var _0x2b57b0;if(_0x5bdd6c['error']&&!Xa(_0x5bdd6c)){const _0x4c701a=((_0x2b57b0=_0x5bdd6c['error']['code'])==null?void 0x0:_0x2b57b0['split']('auth/')[0x1])||'internal-error';_0x49f939['onError'](X(this['auth'],_0x4c701a));}else _0x49f939['onAuthEvent'](_0x5bdd6c);}['isEventForConsumer'](_0x13bcd1,_0x3fced5){const _0x5860e3=_0x3fced5['eventId']===null||!!_0x13bcd1['eventId']&&_0x13bcd1['eventId']===_0x3fced5['eventId'];return _0x3fced5['filter']['includes'](_0x13bcd1['type'])&&_0x5860e3;}['hasEventBeenHandled'](_0x3b7cc0){return Date['now']()-this['lastProcessedEventTime']>=kp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Dr(_0x3b7cc0));}['saveEventToCache'](_0x521a79){this['cachedEventUids']['add'](Dr(_0x521a79)),this['lastProcessedEventTime']=Date['now']();}}function Dr(_0x4efd8d){return[_0x4efd8d['type'],_0x4efd8d['eventId'],_0x4efd8d['sessionId'],_0x4efd8d['tenantId']]['filter'](_0x3ed20c=>_0x3ed20c)['join']('-');}function Xa({type:_0x157541,error:_0x177c5a}){return _0x157541==='unknown'&&(_0x177c5a==null?void 0x0:_0x177c5a['code'])==='auth/no-auth-event';}function Pp(_0x2b0102){switch(_0x2b0102['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Xa(_0x2b0102);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Op(_0x292d5f,_0xae2d2e={}){return Ae(_0x292d5f,'GET','/v1/projects',_0xae2d2e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Mp=/^https?/;async function Lp(_0x4b5eb5){if(_0x4b5eb5['config']['emulator'])return;const {authorizedDomains:_0x491848}=await Op(_0x4b5eb5);for(const _0x1006f1 of _0x491848)try{if(xp(_0x1006f1))return;}catch{}Q(_0x4b5eb5,'unauthorized-domain');}function xp(_0x2fe309){const _0x30c912=Pi(),{protocol:_0x30ae06,hostname:_0x512165}=new URL(_0x30c912);if(_0x2fe309['startsWith']('chrome-extension://')){const _0x15b028=new URL(_0x2fe309);return _0x15b028['hostname']===''&&_0x512165===''?_0x30ae06==='chrome-extension:'&&_0x2fe309['replace']('chrome-extension://','')===_0x30c912['replace']('chrome-extension://',''):_0x30ae06==='chrome-extension:'&&_0x15b028['hostname']===_0x512165;}if(!Mp['test'](_0x30ae06))return!0x1;if(Dp['test'](_0x2fe309))return _0x512165===_0x2fe309;const _0x4e5844=_0x2fe309['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x4e5844+'|'+_0x4e5844+')$','i')['test'](_0x512165);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Fp=new Yt(0x7530,0xea60);function Mr(){const _0x1094bf=Z()['___jsl'];if(_0x1094bf!=null&&_0x1094bf['H']){for(const _0x551a77 of Object['keys'](_0x1094bf['H']))if(_0x1094bf['H'][_0x551a77]['r']=_0x1094bf['H'][_0x551a77]['r']||[],_0x1094bf['H'][_0x551a77]['L']=_0x1094bf['H'][_0x551a77]['L']||[],_0x1094bf['H'][_0x551a77]['r']=[..._0x1094bf['H'][_0x551a77]['L']],_0x1094bf['CP']){for(let _0x513dd8=0x0;_0x513dd8<_0x1094bf['CP']['length'];_0x513dd8++)_0x1094bf['CP'][_0x513dd8]=null;}}}function Up(_0xdce15d){return new Promise((_0x4cddd0,_0xaa2bf0)=>{var _0x439daa,_0x4ce226,_0x207f2f;function _0xa474c7(){Mr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x4cddd0(gapi['iframes']['getContext']());},'ontimeout':()=>{Mr(),_0xaa2bf0(X(_0xdce15d,'network-request-failed'));},'timeout':Fp['get']()});}if((_0x4ce226=(_0x439daa=Z()['gapi'])==null?void 0x0:_0x439daa['iframes'])!=null&&_0x4ce226['Iframe'])_0x4cddd0(gapi['iframes']['getContext']());else{if((_0x207f2f=Z()['gapi'])!=null&&_0x207f2f['load'])_0xa474c7();else{const _0x2aeff2=Df('iframefcb');return Z()[_0x2aeff2]=()=>{gapi['load']?_0xa474c7():_0xaa2bf0(X(_0xdce15d,'network-request-failed'));},xa(Of()+'?onload='+_0x2aeff2)['catch'](_0x53c4af=>_0xaa2bf0(_0x53c4af));}}})['catch'](_0x1062b8=>{throw an=null,_0x1062b8;});}let an=null;function Wp(_0x40c63b){return an=an||Up(_0x40c63b),an;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Yt(0x1388,0x3a98),Vp='__/auth/iframe',Hp='emulator/auth/iframe',$p={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Gp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function qp(_0x498fd3){const _0x41e86c=_0x498fd3['config'];m(_0x41e86c['authDomain'],_0x498fd3,'auth-domain-config-required');const _0x160309=_0x41e86c['emulator']?Cs(_0x41e86c,Hp):'https://'+_0x498fd3['config']['authDomain']+'/'+Vp,_0x45bee3={'apiKey':_0x41e86c['apiKey'],'appName':_0x498fd3['name'],'v':lt},_0x3ea01e=Gp['get'](_0x498fd3['config']['apiHost']);_0x3ea01e&&(_0x45bee3['eid']=_0x3ea01e);const _0x2e40f1=_0x498fd3['_getFrameworks']();return _0x2e40f1['length']&&(_0x45bee3['fw']=_0x2e40f1['join'](',')),_0x160309+'?'+ct(_0x45bee3)['slice'](0x1);}async function zp(_0x49c431){const _0x1e0d28=await Wp(_0x49c431),_0x596ec8=Z()['gapi'];return m(_0x596ec8,_0x49c431,'internal-error'),_0x1e0d28['open']({'where':document['body'],'url':qp(_0x49c431),'messageHandlersFilter':_0x596ec8['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':$p,'dontclear':!0x0},_0x152c45=>new Promise(async(_0x3686b8,_0x134c77)=>{await _0x152c45['restyle']({'setHideOnLeave':!0x1});const _0x2cf46d=X(_0x49c431,'network-request-failed'),_0x53c70d=Z()['setTimeout'](()=>{_0x134c77(_0x2cf46d);},Bp['get']());function _0x572180(){Z()['clearTimeout'](_0x53c70d),_0x3686b8(_0x152c45);}_0x152c45['ping'](_0x572180)['then'](_0x572180,()=>{_0x134c77(_0x2cf46d);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Kp=0x1f4,Yp=0x258,Qp='_blank',Jp='http://localhost';class Lr{constructor(_0x5d0f6f){this['window']=_0x5d0f6f,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Xp(_0x134daa,_0x545d48,_0x2c7ee5,_0x2bde0e=Kp,_0x292810=Yp){const _0x506b4a=Math['max']((window['screen']['availHeight']-_0x292810)/0x2,0x0)['toString'](),_0x550f08=Math['max']((window['screen']['availWidth']-_0x2bde0e)/0x2,0x0)['toString']();let _0x2ddd32='';const _0x16576b={...jp,'width':_0x2bde0e['toString'](),'height':_0x292810['toString'](),'top':_0x506b4a,'left':_0x550f08},_0x56bf5e=W()['toLowerCase']();_0x2c7ee5&&(_0x2ddd32=ka(_0x56bf5e)?Qp:_0x2c7ee5),Ra(_0x56bf5e)&&(_0x545d48=_0x545d48||Jp,_0x16576b['scrollbars']='yes');const _0x477f27=Object['entries'](_0x16576b)['reduce']((_0x111174,[_0x1c0d0a,_0x5716d1])=>''+_0x111174+_0x1c0d0a+'='+_0x5716d1+',','');if(Cf(_0x56bf5e)&&_0x2ddd32!=='_self')return Zp(_0x545d48||'',_0x2ddd32),new Lr(null);const _0x3b5d2f=window['open'](_0x545d48||'',_0x2ddd32,_0x477f27);m(_0x3b5d2f,_0x134daa,'popup-blocked');try{_0x3b5d2f['focus']();}catch{}return new Lr(_0x3b5d2f);}function Zp(_0x3544f2,_0x1e6371){const _0x1e3930=document['createElement']('a');_0x1e3930['href']=_0x3544f2,_0x1e3930['target']=_0x1e6371;const _0x339fc2=document['createEvent']('MouseEvent');_0x339fc2['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x1e3930['dispatchEvent'](_0x339fc2);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const e_='__/auth/handler',t_='emulator/auth/handler',n_=encodeURIComponent('fac');async function xr(_0x3e0d69,_0x3bd33d,_0x275652,_0x3981f9,_0x27341b,_0x4527d0){m(_0x3e0d69['config']['authDomain'],_0x3e0d69,'auth-domain-config-required'),m(_0x3e0d69['config']['apiKey'],_0x3e0d69,'invalid-api-key');const _0x296861={'apiKey':_0x3e0d69['config']['apiKey'],'appName':_0x3e0d69['name'],'authType':_0x275652,'redirectUrl':_0x3981f9,'v':lt,'eventId':_0x27341b};if(_0x3bd33d instanceof Wa){_0x3bd33d['setDefaultLanguage'](_0x3e0d69['languageCode']),_0x296861['providerId']=_0x3bd33d['providerId']||'',ui(_0x3bd33d['getCustomParameters']())||(_0x296861['customParameters']=JSON['stringify'](_0x3bd33d['getCustomParameters']()));for(const [_0x13f394,_0x671493]of Object['entries']({}))_0x296861[_0x13f394]=_0x671493;}if(_0x3bd33d instanceof Jt){const _0x3dbee1=_0x3bd33d['getScopes']()['filter'](_0x6b626f=>_0x6b626f!=='');_0x3dbee1['length']>0x0&&(_0x296861['scopes']=_0x3dbee1['join'](','));}_0x3e0d69['tenantId']&&(_0x296861['tid']=_0x3e0d69['tenantId']);const _0x3bbb0b=_0x296861;for(const _0x5eb692 of Object['keys'](_0x3bbb0b))_0x3bbb0b[_0x5eb692]===void 0x0&&delete _0x3bbb0b[_0x5eb692];const _0x9c6ccb=await _0x3e0d69['_getAppCheckToken'](),_0x2b9c98=_0x9c6ccb?'#'+n_+'='+encodeURIComponent(_0x9c6ccb):'';return i_(_0x3e0d69)+'?'+ct(_0x3bbb0b)['slice'](0x1)+_0x2b9c98;}function i_({config:_0xc9c21d}){return _0xc9c21d['emulator']?Cs(_0xc9c21d,t_):'https://'+_0xc9c21d['authDomain']+'/'+e_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const hi='webStorageSupport';class s_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Ap,this['_overrideRedirectResult']=Sp;}async['_openPopup'](_0x505709,_0xf9c557,_0x134e35,_0x4f04d2){var _0x5515dd;ce((_0x5515dd=this['eventManagers'][_0x505709['_key']()])==null?void 0x0:_0x5515dd['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0x54ef57=await xr(_0x505709,_0xf9c557,_0x134e35,Pi(),_0x4f04d2);return Xp(_0x505709,_0x54ef57,As());}async['_openRedirect'](_0x5d8f34,_0x5c9fb3,_0x5d3010,_0x465a87){await this['_originValidation'](_0x5d8f34);const _0x41588a=await xr(_0x5d8f34,_0x5c9fb3,_0x5d3010,Pi(),_0x465a87);return ap(_0x41588a),new Promise(()=>{});}['_initialize'](_0x127d1b){const _0x311b5a=_0x127d1b['_key']();if(this['eventManagers'][_0x311b5a]){const {manager:_0x1b0801,promise:_0x27bb81}=this['eventManagers'][_0x311b5a];return _0x1b0801?Promise['resolve'](_0x1b0801):(ce(_0x27bb81,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x27bb81);}const _0x44a38d=this['initAndGetManager'](_0x127d1b);return this['eventManagers'][_0x311b5a]={'promise':_0x44a38d},_0x44a38d['catch'](()=>{delete this['eventManagers'][_0x311b5a];}),_0x44a38d;}async['initAndGetManager'](_0x3f76fb){const _0x440aff=await zp(_0x3f76fb),_0x360f29=new Np(_0x3f76fb);return _0x440aff['register']('authEvent',_0x58f026=>(m(_0x58f026==null?void 0x0:_0x58f026['authEvent'],_0x3f76fb,'invalid-auth-event'),{'status':_0x360f29['onEvent'](_0x58f026['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x3f76fb['_key']()]={'manager':_0x360f29},this['iframes'][_0x3f76fb['_key']()]=_0x440aff,_0x360f29;}['_isIframeWebStorageSupported'](_0x5689b2,_0x53aad8){this['iframes'][_0x5689b2['_key']()]['send'](hi,{'type':hi},_0x527f1d=>{var _0x1c86bd;const _0x6577c1=(_0x1c86bd=_0x527f1d==null?void 0x0:_0x527f1d[0x0])==null?void 0x0:_0x1c86bd[hi];_0x6577c1!==void 0x0&&_0x53aad8(!!_0x6577c1),Q(_0x5689b2,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x29665c){const _0x2c9341=_0x29665c['_key']();return this['originValidationPromises'][_0x2c9341]||(this['originValidationPromises'][_0x2c9341]=Lp(_0x29665c)),this['originValidationPromises'][_0x2c9341];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const r_=s_;var Fr='@firebase/auth',Ur='1.11.1';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class o_{constructor(_0x464acb){this['auth']=_0x464acb,this['internalListeners']=new Map();}['getUid'](){var _0x311f4b;return this['assertAuthConfigured'](),((_0x311f4b=this['auth']['currentUser'])==null?void 0x0:_0x311f4b['uid'])||null;}async['getToken'](_0x4ea335){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0x4ea335)}:null;}['addAuthTokenListener'](_0x5a8f4a){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x5a8f4a))return;const _0x100eb5=this['auth']['onIdTokenChanged'](_0x4678e6=>{_0x5a8f4a((_0x4678e6==null?void 0x0:_0x4678e6['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x5a8f4a,_0x100eb5),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x533fed){this['assertAuthConfigured']();const _0x4f5835=this['internalListeners']['get'](_0x533fed);_0x4f5835&&(this['internalListeners']['delete'](_0x533fed),_0x4f5835(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function a_(_0x53e650){switch(_0x53e650){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function c_(_0x717469){Ze(new Le('auth',(_0x3f47db,{options:_0x199fd9})=>{const _0x701ed8=_0x3f47db['getProvider']('app')['getImmediate'](),_0x9eafa9=_0x3f47db['getProvider']('heartbeat'),_0x5b8107=_0x3f47db['getProvider']('app-check-internal'),{apiKey:_0x360186,authDomain:_0x59dda3}=_0x701ed8['options'];m(_0x360186&&!_0x360186['includes'](':'),'invalid-api-key',{'appName':_0x701ed8['name']});const _0x10f799={'apiKey':_0x360186,'authDomain':_0x59dda3,'clientPlatform':_0x717469,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x717469)},_0x5b6984=new kf(_0x701ed8,_0x9eafa9,_0x5b8107,_0x10f799);return Wf(_0x5b6984,_0x199fd9),_0x5b6984;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0x38fed0,_0x41ae81,_0x31f975)=>{_0x38fed0['getProvider']('auth-internal')['initialize']();})),Ze(new Le('auth-internal',_0x1a1e8b=>{const _0x14f060=qe(_0x1a1e8b['getProvider']('auth')['getImmediate']());return(_0x3e1f6a=>new o_(_0x3e1f6a))(_0x14f060);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Fr,Ur,a_(_0x717469)),me(Fr,Ur,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const l_=0x12c,h_=zr('authIdTokenMaxAge')||l_;let Wr=null;const u_=_0x46fa84=>async _0x4656a9=>{const _0x147334=_0x4656a9&&await _0x4656a9['getIdTokenResult'](),_0x310644=_0x147334&&(new Date()['getTime']()-Date['parse'](_0x147334['issuedAtTime']))/0x3e8;if(_0x310644&&_0x310644>h_)return;const _0x3135b4=_0x147334==null?void 0x0:_0x147334['token'];Wr!==_0x3135b4&&(Wr=_0x3135b4,await fetch(_0x46fa84,{'method':_0x3135b4?'POST':'DELETE','headers':_0x3135b4?{'Authorization':'Bearer\x20'+_0x3135b4}:{}}));};function x_(_0x170380=Zr()){const _0x1102dc=Bi(_0x170380,'auth');if(_0x1102dc['isInitialized']())return _0x1102dc['getImmediate']();const _0x2802bc=Uf(_0x170380,{'popupRedirectResolver':r_,'persistence':[gp,sp,za]}),_0x38a28a=zr('authTokenSyncURL');if(_0x38a28a&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x596d01=new URL(_0x38a28a,location['origin']);if(location['origin']===_0x596d01['origin']){const _0x4ef9a2=u_(_0x596d01['toString']());tp(_0x2802bc,_0x4ef9a2,()=>_0x4ef9a2(_0x2802bc['currentUser'])),ep(_0x2802bc,_0x43ad1b=>_0x4ef9a2(_0x43ad1b));}}const _0x31c4c2=Gr('auth');return _0x31c4c2&&Bf(_0x2802bc,'http://'+_0x31c4c2),_0x2802bc;}function d_(){var _0x158ae4;return((_0x158ae4=document['getElementsByTagName']('head'))==null?void 0x0:_0x158ae4[0x0])??document;}Nf({'loadJS'(_0x11b168){return new Promise((_0x568f9f,_0x51db20)=>{const _0x327dd6=document['createElement']('script');_0x327dd6['setAttribute']('src',_0x11b168),_0x327dd6['onload']=_0x568f9f,_0x327dd6['onerror']=_0x416caa=>{const _0x1983a8=X('internal-error');_0x1983a8['customData']=_0x416caa,_0x51db20(_0x1983a8);},_0x327dd6['type']='text/javascript',_0x327dd6['charset']='UTF-8',d_()['appendChild'](_0x327dd6);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),c_('Browser');export{P_ as A,L_ as B,C_ as C,x_ as a,sp as b,O_ as c,f_ as d,p_ as e,Zr as f,b_ as g,y_ as h,Sl as i,k_ as j,T_ as k,Ft as l,Ud as m,M_ as n,w_ as o,g_ as p,S_ as q,__ as r,D_ as s,A_ as t,m_ as u,R_ as v,N_ as w,E_ as x,v_ as y,I_ as z};