const Za=()=>{};var Ns={};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Br={'NODE_ADMIN':!0x1,'SDK_VERSION':'${JSCORE_VERSION}'},f=function(_0x30a01b,_0x5622eb){if(!_0x30a01b)throw rt(_0x5622eb);},rt=function(_0x49f87a){return new Error('Firebase\x20Database\x20('+Br['SDK_VERSION']+')\x20INTERNAL\x20ASSERT\x20FAILED:\x20'+_0x49f87a);},Vr=function(_0x22f3af){const _0x11d05d=[];let _0x413e42=0x0;for(let _0x453c17=0x0;_0x453c17<_0x22f3af['length'];_0x453c17++){let _0x13d9f5=_0x22f3af['charCodeAt'](_0x453c17);_0x13d9f5<0x80?_0x11d05d[_0x413e42++]=_0x13d9f5:_0x13d9f5<0x800?(_0x11d05d[_0x413e42++]=_0x13d9f5>>0x6|0xc0,_0x11d05d[_0x413e42++]=_0x13d9f5&0x3f|0x80):(_0x13d9f5&0xfc00)===0xd800&&_0x453c17+0x1<_0x22f3af['length']&&(_0x22f3af['charCodeAt'](_0x453c17+0x1)&0xfc00)===0xdc00?(_0x13d9f5=0x10000+((_0x13d9f5&0x3ff)<<0xa)+(_0x22f3af['charCodeAt'](++_0x453c17)&0x3ff),_0x11d05d[_0x413e42++]=_0x13d9f5>>0x12|0xf0,_0x11d05d[_0x413e42++]=_0x13d9f5>>0xc&0x3f|0x80,_0x11d05d[_0x413e42++]=_0x13d9f5>>0x6&0x3f|0x80,_0x11d05d[_0x413e42++]=_0x13d9f5&0x3f|0x80):(_0x11d05d[_0x413e42++]=_0x13d9f5>>0xc|0xe0,_0x11d05d[_0x413e42++]=_0x13d9f5>>0x6&0x3f|0x80,_0x11d05d[_0x413e42++]=_0x13d9f5&0x3f|0x80);}return _0x11d05d;},ec=function(_0x3c84a6){const _0x412029=[];let _0xda0f63=0x0,_0x1a9c6b=0x0;for(;_0xda0f63<_0x3c84a6['length'];){const _0x4dee17=_0x3c84a6[_0xda0f63++];if(_0x4dee17<0x80)_0x412029[_0x1a9c6b++]=String['fromCharCode'](_0x4dee17);else{if(_0x4dee17>0xbf&&_0x4dee17<0xe0){const _0x60b342=_0x3c84a6[_0xda0f63++];_0x412029[_0x1a9c6b++]=String['fromCharCode']((_0x4dee17&0x1f)<<0x6|_0x60b342&0x3f);}else{if(_0x4dee17>0xef&&_0x4dee17<0x16d){const _0x400a28=_0x3c84a6[_0xda0f63++],_0x45de2a=_0x3c84a6[_0xda0f63++],_0x48fa3e=_0x3c84a6[_0xda0f63++],_0x2518ff=((_0x4dee17&0x7)<<0x12|(_0x400a28&0x3f)<<0xc|(_0x45de2a&0x3f)<<0x6|_0x48fa3e&0x3f)-0x10000;_0x412029[_0x1a9c6b++]=String['fromCharCode'](0xd800+(_0x2518ff>>0xa)),_0x412029[_0x1a9c6b++]=String['fromCharCode'](0xdc00+(_0x2518ff&0x3ff));}else{const _0x3fc4c5=_0x3c84a6[_0xda0f63++],_0x5310fa=_0x3c84a6[_0xda0f63++];_0x412029[_0x1a9c6b++]=String['fromCharCode']((_0x4dee17&0xf)<<0xc|(_0x3fc4c5&0x3f)<<0x6|_0x5310fa&0x3f);}}}}return _0x412029['join']('');},Li={'byteToCharMap_':null,'charToByteMap_':null,'byteToCharMapWebSafe_':null,'charToByteMapWebSafe_':null,'ENCODED_VALS_BASE':'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789',get 'ENCODED_VALS'(){return this['ENCODED_VALS_BASE']+'+/=';},get 'ENCODED_VALS_WEBSAFE'(){return this['ENCODED_VALS_BASE']+'-_.';},'HAS_NATIVE_SUPPORT':typeof atob=='function','encodeByteArray'(_0x52ad5d,_0x4dbc74){if(!Array['isArray'](_0x52ad5d))throw Error('encodeByteArray\x20takes\x20an\x20array\x20as\x20a\x20parameter');this['init_']();const _0x2594ea=_0x4dbc74?this['byteToCharMapWebSafe_']:this['byteToCharMap_'],_0x365743=[];for(let _0x4ca6e7=0x0;_0x4ca6e7<_0x52ad5d['length'];_0x4ca6e7+=0x3){const _0xc280a=_0x52ad5d[_0x4ca6e7],_0x49840c=_0x4ca6e7+0x1<_0x52ad5d['length'],_0x56a974=_0x49840c?_0x52ad5d[_0x4ca6e7+0x1]:0x0,_0x1fc3d7=_0x4ca6e7+0x2<_0x52ad5d['length'],_0x340846=_0x1fc3d7?_0x52ad5d[_0x4ca6e7+0x2]:0x0,_0x3482d7=_0xc280a>>0x2,_0x56fd02=(_0xc280a&0x3)<<0x4|_0x56a974>>0x4;let _0x43e8f0=(_0x56a974&0xf)<<0x2|_0x340846>>0x6,_0xb1af2d=_0x340846&0x3f;_0x1fc3d7||(_0xb1af2d=0x40,_0x49840c||(_0x43e8f0=0x40)),_0x365743['push'](_0x2594ea[_0x3482d7],_0x2594ea[_0x56fd02],_0x2594ea[_0x43e8f0],_0x2594ea[_0xb1af2d]);}return _0x365743['join']('');},'encodeString'(_0x43aa80,_0x723db7){return this['HAS_NATIVE_SUPPORT']&&!_0x723db7?btoa(_0x43aa80):this['encodeByteArray'](Vr(_0x43aa80),_0x723db7);},'decodeString'(_0x449441,_0x241dae){return this['HAS_NATIVE_SUPPORT']&&!_0x241dae?atob(_0x449441):ec(this['decodeStringToByteArray'](_0x449441,_0x241dae));},'decodeStringToByteArray'(_0x25a313,_0x188a47){this['init_']();const _0xfbfb2a=_0x188a47?this['charToByteMapWebSafe_']:this['charToByteMap_'],_0x44466e=[];for(let _0x3eecf2=0x0;_0x3eecf2<_0x25a313['length'];){const _0x8bc6b1=_0xfbfb2a[_0x25a313['charAt'](_0x3eecf2++)],_0x3c60e1=_0x3eecf2<_0x25a313['length']?_0xfbfb2a[_0x25a313['charAt'](_0x3eecf2)]:0x0;++_0x3eecf2;const _0x2ce818=_0x3eecf2<_0x25a313['length']?_0xfbfb2a[_0x25a313['charAt'](_0x3eecf2)]:0x40;++_0x3eecf2;const _0x15584d=_0x3eecf2<_0x25a313['length']?_0xfbfb2a[_0x25a313['charAt'](_0x3eecf2)]:0x40;if(++_0x3eecf2,_0x8bc6b1==null||_0x3c60e1==null||_0x2ce818==null||_0x15584d==null)throw new tc();const _0xdfa4f=_0x8bc6b1<<0x2|_0x3c60e1>>0x4;if(_0x44466e['push'](_0xdfa4f),_0x2ce818!==0x40){const _0x3c9da3=_0x3c60e1<<0x4&0xf0|_0x2ce818>>0x2;if(_0x44466e['push'](_0x3c9da3),_0x15584d!==0x40){const _0x420ce8=_0x2ce818<<0x6&0xc0|_0x15584d;_0x44466e['push'](_0x420ce8);}}}return _0x44466e;},'init_'(){if(!this['byteToCharMap_']){this['byteToCharMap_']={},this['charToByteMap_']={},this['byteToCharMapWebSafe_']={},this['charToByteMapWebSafe_']={};for(let _0x42b976=0x0;_0x42b976<this['ENCODED_VALS']['length'];_0x42b976++)this['byteToCharMap_'][_0x42b976]=this['ENCODED_VALS']['charAt'](_0x42b976),this['charToByteMap_'][this['byteToCharMap_'][_0x42b976]]=_0x42b976,this['byteToCharMapWebSafe_'][_0x42b976]=this['ENCODED_VALS_WEBSAFE']['charAt'](_0x42b976),this['charToByteMapWebSafe_'][this['byteToCharMapWebSafe_'][_0x42b976]]=_0x42b976,_0x42b976>=this['ENCODED_VALS_BASE']['length']&&(this['charToByteMap_'][this['ENCODED_VALS_WEBSAFE']['charAt'](_0x42b976)]=_0x42b976,this['charToByteMapWebSafe_'][this['ENCODED_VALS']['charAt'](_0x42b976)]=_0x42b976);}}};class tc extends Error{constructor(){super(...arguments),this['name']='DecodeBase64StringError';}}const Hr=function(_0x2ce8cb){const _0x25d132=Vr(_0x2ce8cb);return Li['encodeByteArray'](_0x25d132,!0x0);},cn=function(_0x6f1cde){return Hr(_0x6f1cde)['replace'](/\./g,'');},ln=function(_0x9c3de2){try{return Li['decodeString'](_0x9c3de2,!0x0);}catch(_0x968830){console['error']('base64Decode\x20failed:\x20',_0x968830);}return null;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function nc(_0x38cfe4){return $r(void 0x0,_0x38cfe4);}function $r(_0x3a6828,_0x4c3ae5){if(!(_0x4c3ae5 instanceof Object))return _0x4c3ae5;switch(_0x4c3ae5['constructor']){case Date:const _0x1862ca=_0x4c3ae5;return new Date(_0x1862ca['getTime']());case Object:_0x3a6828===void 0x0&&(_0x3a6828={});break;case Array:_0x3a6828=[];break;default:return _0x4c3ae5;}for(const _0x405d34 in _0x4c3ae5)!_0x4c3ae5['hasOwnProperty'](_0x405d34)||!ic(_0x405d34)||(_0x3a6828[_0x405d34]=$r(_0x3a6828[_0x405d34],_0x4c3ae5[_0x405d34]));return _0x3a6828;}function ic(_0x4c5229){return _0x4c5229!=='__proto__';}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sc(){if(typeof self<'u')return self;if(typeof window<'u')return window;if(typeof global<'u')return global;throw new Error('Unable\x20to\x20locate\x20global\x20object.');}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const rc=()=>sc()['__FIREBASE_DEFAULTS__'],oc=()=>{if(typeof process>'u'||typeof Ns>'u')return;const _0x170858=Ns['__FIREBASE_DEFAULTS__'];if(_0x170858)return JSON['parse'](_0x170858);},ac=()=>{if(typeof document>'u')return;let _0x3644aa;try{_0x3644aa=document['cookie']['match'](/__FIREBASE_DEFAULTS__=([^;]+)/);}catch{return;}const _0x507283=_0x3644aa&&ln(_0x3644aa[0x1]);return _0x507283&&JSON['parse'](_0x507283);},xi=()=>{try{return Za()||rc()||oc()||ac();}catch(_0x9d9ff2){console['info']('Unable\x20to\x20get\x20__FIREBASE_DEFAULTS__\x20due\x20to:\x20'+_0x9d9ff2);return;}},Gr=_0x461da9=>{var _0x2504ff,_0x34bbc6;return(_0x34bbc6=(_0x2504ff=xi())==null?void 0x0:_0x2504ff['emulatorHosts'])==null?void 0x0:_0x34bbc6[_0x461da9];},cc=_0xa71e1=>{const _0x1b7734=Gr(_0xa71e1);if(!_0x1b7734)return;const _0xaf5bf6=_0x1b7734['lastIndexOf'](':');if(_0xaf5bf6<=0x0||_0xaf5bf6+0x1===_0x1b7734['length'])throw new Error('Invalid\x20host\x20'+_0x1b7734+'\x20with\x20no\x20separate\x20hostname\x20and\x20port!');const _0x2a10be=parseInt(_0x1b7734['substring'](_0xaf5bf6+0x1),0xa);return _0x1b7734[0x0]==='['?[_0x1b7734['substring'](0x1,_0xaf5bf6-0x1),_0x2a10be]:[_0x1b7734['substring'](0x0,_0xaf5bf6),_0x2a10be];},qr=()=>{var _0x5a7c20;return(_0x5a7c20=xi())==null?void 0x0:_0x5a7c20['config'];},zr=_0x359e66=>{var _0x34c8b5;return(_0x34c8b5=xi())==null?void 0x0:_0x34c8b5['_'+_0x359e66];};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ot{constructor(){this['reject']=()=>{},this['resolve']=()=>{},this['promise']=new Promise((_0x55c447,_0x47d7c2)=>{this['resolve']=_0x55c447,this['reject']=_0x47d7c2;});}['wrapCallback'](_0x1b089a){return(_0x464949,_0x3a17cc)=>{_0x464949?this['reject'](_0x464949):this['resolve'](_0x3a17cc),typeof _0x1b089a=='function'&&(this['promise']['catch'](()=>{}),_0x1b089a['length']===0x1?_0x1b089a(_0x464949):_0x1b089a(_0x464949,_0x3a17cc));};}}/**
 * @license
 * Copyright 2025 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function at(_0x412b83){try{return(_0x412b83['startsWith']('http://')||_0x412b83['startsWith']('https://')?new URL(_0x412b83)['hostname']:_0x412b83)['endsWith']('.cloudworkstations.dev');}catch{return!0x1;}}async function jr(_0x228992){return(await fetch(_0x228992,{'credentials':'include'}))['ok'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function lc(_0x3b10bd,_0x3dc97f){if(_0x3b10bd['uid'])throw new Error('The\x20\x22uid\x22\x20field\x20is\x20no\x20longer\x20supported\x20by\x20mockUserToken.\x20Please\x20use\x20\x22sub\x22\x20instead\x20for\x20Firebase\x20Auth\x20User\x20ID.');const _0x21915a={'alg':'none','type':'JWT'},_0x238405=_0x3dc97f||'demo-project',_0x3fbd76=_0x3b10bd['iat']||0x0,_0x54434b=_0x3b10bd['sub']||_0x3b10bd['user_id'];if(!_0x54434b)throw new Error('mockUserToken\x20must\x20contain\x20\x27sub\x27\x20or\x20\x27user_id\x27\x20field!');const _0x7373f1={'iss':'https://securetoken.google.com/'+_0x238405,'aud':_0x238405,'iat':_0x3fbd76,'exp':_0x3fbd76+0xe10,'auth_time':_0x3fbd76,'sub':_0x54434b,'user_id':_0x54434b,'firebase':{'sign_in_provider':'custom','identities':{}},..._0x3b10bd};return[cn(JSON['stringify'](_0x21915a)),cn(JSON['stringify'](_0x7373f1)),'']['join']('.');}const It={};function hc(){const _0x1cd4cc={'prod':[],'emulator':[]};for(const _0x44fbd8 of Object['keys'](It))It[_0x44fbd8]?_0x1cd4cc['emulator']['push'](_0x44fbd8):_0x1cd4cc['prod']['push'](_0x44fbd8);return _0x1cd4cc;}function uc(_0x1919fa){let _0x11d37d=document['getElementById'](_0x1919fa),_0x3c7ec6=!0x1;return _0x11d37d||(_0x11d37d=document['createElement']('div'),_0x11d37d['setAttribute']('id',_0x1919fa),_0x3c7ec6=!0x0),{'created':_0x3c7ec6,'element':_0x11d37d};}let Ps=!0x1;function Kr(_0x145e04,_0x33160a){if(typeof window>'u'||typeof document>'u'||!at(window['location']['host'])||It[_0x145e04]===_0x33160a||It[_0x145e04]||Ps)return;It[_0x145e04]=_0x33160a;function _0x197619(_0x539c6c){return'__firebase__banner__'+_0x539c6c;}const _0x24a084='__firebase__banner',_0x19b970=hc()['prod']['length']>0x0;function _0x5df88a(){const _0x74a2db=document['getElementById'](_0x24a084);_0x74a2db&&_0x74a2db['remove']();}function _0xb1e59c(_0x230d64){_0x230d64['style']['display']='flex',_0x230d64['style']['background']='#7faaf0',_0x230d64['style']['position']='fixed',_0x230d64['style']['bottom']='5px',_0x230d64['style']['left']='5px',_0x230d64['style']['padding']='.5em',_0x230d64['style']['borderRadius']='5px',_0x230d64['style']['alignItems']='center';}function _0x21c185(_0x10869c,_0xe3fe70){_0x10869c['setAttribute']('width','24'),_0x10869c['setAttribute']('id',_0xe3fe70),_0x10869c['setAttribute']('height','24'),_0x10869c['setAttribute']('viewBox','0\x200\x2024\x2024'),_0x10869c['setAttribute']('fill','none'),_0x10869c['style']['marginLeft']='-6px';}function _0x35e549(){const _0x509bf0=document['createElement']('span');return _0x509bf0['style']['cursor']='pointer',_0x509bf0['style']['marginLeft']='16px',_0x509bf0['style']['fontSize']='24px',_0x509bf0['innerHTML']='\x20&times;',_0x509bf0['onclick']=()=>{Ps=!0x0,_0x5df88a();},_0x509bf0;}function _0x19d269(_0x35c1bd,_0x26e68b){_0x35c1bd['setAttribute']('id',_0x26e68b),_0x35c1bd['innerText']='Learn\x20more',_0x35c1bd['href']='https://firebase.google.com/docs/studio/preview-apps#preview-backend',_0x35c1bd['setAttribute']('target','__blank'),_0x35c1bd['style']['paddingLeft']='5px',_0x35c1bd['style']['textDecoration']='underline';}function _0x44d88c(){const _0x2edc7c=uc(_0x24a084),_0x5068e3=_0x197619('text'),_0x1fb55f=document['getElementById'](_0x5068e3)||document['createElement']('span'),_0x309ff2=_0x197619('learnmore'),_0x10cabc=document['getElementById'](_0x309ff2)||document['createElement']('a'),_0x584427=_0x197619('preprendIcon'),_0x472ecb=document['getElementById'](_0x584427)||document['createElementNS']('http://www.w3.org/2000/svg','svg');if(_0x2edc7c['created']){const _0x3672cc=_0x2edc7c['element'];_0xb1e59c(_0x3672cc),_0x19d269(_0x10cabc,_0x309ff2);const _0x5e04df=_0x35e549();_0x21c185(_0x472ecb,_0x584427),_0x3672cc['append'](_0x472ecb,_0x1fb55f,_0x10cabc,_0x5e04df),document['body']['appendChild'](_0x3672cc);}_0x19b970?(_0x1fb55f['innerText']='Preview\x20backend\x20disconnected.',_0x472ecb['innerHTML']='<g\x20clip-path=\x22url(#clip0_6013_33858)\x22>\x0a<path\x20d=\x22M4.8\x2017.6L12\x205.6L19.2\x2017.6H4.8ZM6.91667\x2016.4H17.0833L12\x207.93333L6.91667\x2016.4ZM12\x2015.6C12.1667\x2015.6\x2012.3056\x2015.5444\x2012.4167\x2015.4333C12.5389\x2015.3111\x2012.6\x2015.1667\x2012.6\x2015C12.6\x2014.8333\x2012.5389\x2014.6944\x2012.4167\x2014.5833C12.3056\x2014.4611\x2012.1667\x2014.4\x2012\x2014.4C11.8333\x2014.4\x2011.6889\x2014.4611\x2011.5667\x2014.5833C11.4556\x2014.6944\x2011.4\x2014.8333\x2011.4\x2015C11.4\x2015.1667\x2011.4556\x2015.3111\x2011.5667\x2015.4333C11.6889\x2015.5444\x2011.8333\x2015.6\x2012\x2015.6ZM11.4\x2013.6H12.6V10.4H11.4V13.6Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6013_33858\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>'):(_0x472ecb['innerHTML']='<g\x20clip-path=\x22url(#clip0_6083_34804)\x22>\x0a<path\x20d=\x22M11.4\x2015.2H12.6V11.2H11.4V15.2ZM12\x2010C12.1667\x2010\x2012.3056\x209.94444\x2012.4167\x209.83333C12.5389\x209.71111\x2012.6\x209.56667\x2012.6\x209.4C12.6\x209.23333\x2012.5389\x209.09444\x2012.4167\x208.98333C12.3056\x208.86111\x2012.1667\x208.8\x2012\x208.8C11.8333\x208.8\x2011.6889\x208.86111\x2011.5667\x208.98333C11.4556\x209.09444\x2011.4\x209.23333\x2011.4\x209.4C11.4\x209.56667\x2011.4556\x209.71111\x2011.5667\x209.83333C11.6889\x209.94444\x2011.8333\x2010\x2012\x2010ZM12\x2018.4C11.1222\x2018.4\x2010.2944\x2018.2333\x209.51667\x2017.9C8.73889\x2017.5667\x208.05556\x2017.1111\x207.46667\x2016.5333C6.88889\x2015.9444\x206.43333\x2015.2611\x206.1\x2014.4833C5.76667\x2013.7056\x205.6\x2012.8778\x205.6\x2012C5.6\x2011.1111\x205.76667\x2010.2833\x206.1\x209.51667C6.43333\x208.73889\x206.88889\x208.06111\x207.46667\x207.48333C8.05556\x206.89444\x208.73889\x206.43333\x209.51667\x206.1C10.2944\x205.76667\x2011.1222\x205.6\x2012\x205.6C12.8889\x205.6\x2013.7167\x205.76667\x2014.4833\x206.1C15.2611\x206.43333\x2015.9389\x206.89444\x2016.5167\x207.48333C17.1056\x208.06111\x2017.5667\x208.73889\x2017.9\x209.51667C18.2333\x2010.2833\x2018.4\x2011.1111\x2018.4\x2012C18.4\x2012.8778\x2018.2333\x2013.7056\x2017.9\x2014.4833C17.5667\x2015.2611\x2017.1056\x2015.9444\x2016.5167\x2016.5333C15.9389\x2017.1111\x2015.2611\x2017.5667\x2014.4833\x2017.9C13.7167\x2018.2333\x2012.8889\x2018.4\x2012\x2018.4ZM12\x2017.2C13.4444\x2017.2\x2014.6722\x2016.6944\x2015.6833\x2015.6833C16.6944\x2014.6722\x2017.2\x2013.4444\x2017.2\x2012C17.2\x2010.5556\x2016.6944\x209.32778\x2015.6833\x208.31667C14.6722\x207.30555\x2013.4444\x206.8\x2012\x206.8C10.5556\x206.8\x209.32778\x207.30555\x208.31667\x208.31667C7.30556\x209.32778\x206.8\x2010.5556\x206.8\x2012C6.8\x2013.4444\x207.30556\x2014.6722\x208.31667\x2015.6833C9.32778\x2016.6944\x2010.5556\x2017.2\x2012\x2017.2Z\x22\x20fill=\x22#212121\x22/>\x0a</g>\x0a<defs>\x0a<clipPath\x20id=\x22clip0_6083_34804\x22>\x0a<rect\x20width=\x2224\x22\x20height=\x2224\x22\x20fill=\x22white\x22/>\x0a</clipPath>\x0a</defs>',_0x1fb55f['innerText']='Preview\x20backend\x20running\x20in\x20this\x20workspace.'),_0x1fb55f['setAttribute']('id',_0x5068e3);}document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x44d88c):_0x44d88c();}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function W(){return typeof navigator<'u'&&typeof navigator['userAgent']=='string'?navigator['userAgent']:'';}function Fi(){return typeof window<'u'&&!!(window['cordova']||window['phonegap']||window['PhoneGap'])&&/ios|iphone|ipod|ipad|android|blackberry|iemobile/i['test'](W());}function dc(){return typeof navigator<'u'&&navigator['userAgent']==='Cloudflare-Workers';}function fc(){const _0x3db877=typeof chrome=='object'?chrome['runtime']:typeof browser=='object'?browser['runtime']:void 0x0;return typeof _0x3db877=='object'&&_0x3db877['id']!==void 0x0;}function Yr(){return typeof navigator=='object'&&navigator['product']==='ReactNative';}function pc(){const _0x1012b1=W();return _0x1012b1['indexOf']('MSIE\x20')>=0x0||_0x1012b1['indexOf']('Trident/')>=0x0;}function _c(){return Br['NODE_ADMIN']===!0x0;}function gc(){try{return typeof indexedDB=='object';}catch{return!0x1;}}function mc(){return new Promise((_0x146a7d,_0x1f19a2)=>{try{let _0x55aed9=!0x0;const _0xaf215a='validate-browser-context-for-indexeddb-analytics-module',_0x1803f9=self['indexedDB']['open'](_0xaf215a);_0x1803f9['onsuccess']=()=>{_0x1803f9['result']['close'](),_0x55aed9||self['indexedDB']['deleteDatabase'](_0xaf215a),_0x146a7d(!0x0);},_0x1803f9['onupgradeneeded']=()=>{_0x55aed9=!0x1;},_0x1803f9['onerror']=()=>{var _0x4de35f;_0x1f19a2(((_0x4de35f=_0x1803f9['error'])==null?void 0x0:_0x4de35f['message'])||'');};}catch(_0x1ecf19){_0x1f19a2(_0x1ecf19);}});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yc='FirebaseError';class Se extends Error{constructor(_0x4e98e2,_0x48d915,_0x30dc4a){super(_0x48d915),this['code']=_0x4e98e2,this['customData']=_0x30dc4a,this['name']=yc,Object['setPrototypeOf'](this,Se['prototype']),Error['captureStackTrace']&&Error['captureStackTrace'](this,Bt['prototype']['create']);}}class Bt{constructor(_0x3e5a1f,_0x238003,_0x4be225){this['service']=_0x3e5a1f,this['serviceName']=_0x238003,this['errors']=_0x4be225;}['create'](_0x257724,..._0xb3c6f1){const _0x309a38=_0xb3c6f1[0x0]||{},_0x2815e8=this['service']+'/'+_0x257724,_0x1e61cf=this['errors'][_0x257724],_0x5ae059=_0x1e61cf?vc(_0x1e61cf,_0x309a38):'Error',_0x5c8047=this['serviceName']+':\x20'+_0x5ae059+'\x20('+_0x2815e8+').';return new Se(_0x2815e8,_0x5c8047,_0x309a38);}}function vc(_0x41bdc6,_0x597bbd){return _0x41bdc6['replace'](Ec,(_0x1962c9,_0xc62a2a)=>{const _0xa04981=_0x597bbd[_0xc62a2a];return _0xa04981!=null?String(_0xa04981):'<'+_0xc62a2a+'?>';});}const Ec=/\{\$([^}]+)}/g;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function At(_0x206903){return JSON['parse'](_0x206903);}function O(_0xd7c3fb){return JSON['stringify'](_0xd7c3fb);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Qr=function(_0x36716a){let _0x35f6fe={},_0x30716b={},_0x4499e5={},_0x3be792='';try{const _0x2e1f77=_0x36716a['split']('.');_0x35f6fe=At(ln(_0x2e1f77[0x0])||''),_0x30716b=At(ln(_0x2e1f77[0x1])||''),_0x3be792=_0x2e1f77[0x2],_0x4499e5=_0x30716b['d']||{},delete _0x30716b['d'];}catch{}return{'header':_0x35f6fe,'claims':_0x30716b,'data':_0x4499e5,'signature':_0x3be792};},Ic=function(_0x533e9f){const _0x3cdb8a=Qr(_0x533e9f),_0x3f5adc=_0x3cdb8a['claims'];return!!_0x3f5adc&&typeof _0x3f5adc=='object'&&_0x3f5adc['hasOwnProperty']('iat');},wc=function(_0x164a66){const _0x5226de=Qr(_0x164a66)['claims'];return typeof _0x5226de=='object'&&_0x5226de['admin']===!0x0;};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function J(_0x1afd11,_0x3c7d9a){return Object['prototype']['hasOwnProperty']['call'](_0x1afd11,_0x3c7d9a);}function De(_0x4a7df2,_0x1ec91f){if(Object['prototype']['hasOwnProperty']['call'](_0x4a7df2,_0x1ec91f))return _0x4a7df2[_0x1ec91f];}function ui(_0x1269ad){for(const _0x2b6b4d in _0x1269ad)if(Object['prototype']['hasOwnProperty']['call'](_0x1269ad,_0x2b6b4d))return!0x1;return!0x0;}function hn(_0x15f75a,_0x325626,_0x526552){const _0x44ce03={};for(const _0x5c6aa7 in _0x15f75a)Object['prototype']['hasOwnProperty']['call'](_0x15f75a,_0x5c6aa7)&&(_0x44ce03[_0x5c6aa7]=_0x325626['call'](_0x526552,_0x15f75a[_0x5c6aa7],_0x5c6aa7,_0x15f75a));return _0x44ce03;}function Me(_0x3b4db5,_0x54de07){if(_0x3b4db5===_0x54de07)return!0x0;const _0x45e188=Object['keys'](_0x3b4db5),_0x9bc96c=Object['keys'](_0x54de07);for(const _0x56c80f of _0x45e188){if(!_0x9bc96c['includes'](_0x56c80f))return!0x1;const _0x44468a=_0x3b4db5[_0x56c80f],_0x281db7=_0x54de07[_0x56c80f];if(Os(_0x44468a)&&Os(_0x281db7)){if(!Me(_0x44468a,_0x281db7))return!0x1;}else{if(_0x44468a!==_0x281db7)return!0x1;}}for(const _0x4f0a2a of _0x9bc96c)if(!_0x45e188['includes'](_0x4f0a2a))return!0x1;return!0x0;}function Os(_0x4381e4){return _0x4381e4!==null&&typeof _0x4381e4=='object';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ct(_0x49cdec){const _0x40e001=[];for(const [_0x36c7f4,_0x1e3ca8]of Object['entries'](_0x49cdec))Array['isArray'](_0x1e3ca8)?_0x1e3ca8['forEach'](_0x33a8b2=>{_0x40e001['push'](encodeURIComponent(_0x36c7f4)+'='+encodeURIComponent(_0x33a8b2));}):_0x40e001['push'](encodeURIComponent(_0x36c7f4)+'='+encodeURIComponent(_0x1e3ca8));return _0x40e001['length']?'&'+_0x40e001['join']('&'):'';}function vt(_0x56fa14){const _0x539919={};return _0x56fa14['replace'](/^\?/,'')['split']('&')['forEach'](_0x2eb4d6=>{if(_0x2eb4d6){const [_0x203636,_0x3db220]=_0x2eb4d6['split']('=');_0x539919[decodeURIComponent(_0x203636)]=decodeURIComponent(_0x3db220);}}),_0x539919;}function Et(_0x28f7b9){const _0x51cb2f=_0x28f7b9['indexOf']('?');if(!_0x51cb2f)return'';const _0x5dbf9=_0x28f7b9['indexOf']('#',_0x51cb2f);return _0x28f7b9['substring'](_0x51cb2f,_0x5dbf9>0x0?_0x5dbf9:void 0x0);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cc{constructor(){this['chain_']=[],this['buf_']=[],this['W_']=[],this['pad_']=[],this['inbuf_']=0x0,this['total_']=0x0,this['blockSize']=0x200/0x8,this['pad_'][0x0]=0x80;for(let _0x334c76=0x1;_0x334c76<this['blockSize'];++_0x334c76)this['pad_'][_0x334c76]=0x0;this['reset']();}['reset'](){this['chain_'][0x0]=0x67452301,this['chain_'][0x1]=0xefcdab89,this['chain_'][0x2]=0x98badcfe,this['chain_'][0x3]=0x10325476,this['chain_'][0x4]=0xc3d2e1f0,this['inbuf_']=0x0,this['total_']=0x0;}['compress_'](_0x7473aa,_0x181f11){_0x181f11||(_0x181f11=0x0);const _0x26a87a=this['W_'];if(typeof _0x7473aa=='string'){for(let _0x476dc7=0x0;_0x476dc7<0x10;_0x476dc7++)_0x26a87a[_0x476dc7]=_0x7473aa['charCodeAt'](_0x181f11)<<0x18|_0x7473aa['charCodeAt'](_0x181f11+0x1)<<0x10|_0x7473aa['charCodeAt'](_0x181f11+0x2)<<0x8|_0x7473aa['charCodeAt'](_0x181f11+0x3),_0x181f11+=0x4;}else{for(let _0x123a81=0x0;_0x123a81<0x10;_0x123a81++)_0x26a87a[_0x123a81]=_0x7473aa[_0x181f11]<<0x18|_0x7473aa[_0x181f11+0x1]<<0x10|_0x7473aa[_0x181f11+0x2]<<0x8|_0x7473aa[_0x181f11+0x3],_0x181f11+=0x4;}for(let _0x417869=0x10;_0x417869<0x50;_0x417869++){const _0x55ca5e=_0x26a87a[_0x417869-0x3]^_0x26a87a[_0x417869-0x8]^_0x26a87a[_0x417869-0xe]^_0x26a87a[_0x417869-0x10];_0x26a87a[_0x417869]=(_0x55ca5e<<0x1|_0x55ca5e>>>0x1f)&0xffffffff;}let _0x5c7004=this['chain_'][0x0],_0x2e4003=this['chain_'][0x1],_0x587069=this['chain_'][0x2],_0x2aebea=this['chain_'][0x3],_0x484e9b=this['chain_'][0x4],_0x3cdc8a,_0x5387e1;for(let _0x336edd=0x0;_0x336edd<0x50;_0x336edd++){_0x336edd<0x28?_0x336edd<0x14?(_0x3cdc8a=_0x2aebea^_0x2e4003&(_0x587069^_0x2aebea),_0x5387e1=0x5a827999):(_0x3cdc8a=_0x2e4003^_0x587069^_0x2aebea,_0x5387e1=0x6ed9eba1):_0x336edd<0x3c?(_0x3cdc8a=_0x2e4003&_0x587069|_0x2aebea&(_0x2e4003|_0x587069),_0x5387e1=0x8f1bbcdc):(_0x3cdc8a=_0x2e4003^_0x587069^_0x2aebea,_0x5387e1=0xca62c1d6);const _0x232369=(_0x5c7004<<0x5|_0x5c7004>>>0x1b)+_0x3cdc8a+_0x484e9b+_0x5387e1+_0x26a87a[_0x336edd]&0xffffffff;_0x484e9b=_0x2aebea,_0x2aebea=_0x587069,_0x587069=(_0x2e4003<<0x1e|_0x2e4003>>>0x2)&0xffffffff,_0x2e4003=_0x5c7004,_0x5c7004=_0x232369;}this['chain_'][0x0]=this['chain_'][0x0]+_0x5c7004&0xffffffff,this['chain_'][0x1]=this['chain_'][0x1]+_0x2e4003&0xffffffff,this['chain_'][0x2]=this['chain_'][0x2]+_0x587069&0xffffffff,this['chain_'][0x3]=this['chain_'][0x3]+_0x2aebea&0xffffffff,this['chain_'][0x4]=this['chain_'][0x4]+_0x484e9b&0xffffffff;}['update'](_0x22e1c5,_0x5a4b7c){if(_0x22e1c5==null)return;_0x5a4b7c===void 0x0&&(_0x5a4b7c=_0x22e1c5['length']);const _0x4f226c=_0x5a4b7c-this['blockSize'];let _0x395717=0x0;const _0x4cd46b=this['buf_'];let _0x3db651=this['inbuf_'];for(;_0x395717<_0x5a4b7c;){if(_0x3db651===0x0){for(;_0x395717<=_0x4f226c;)this['compress_'](_0x22e1c5,_0x395717),_0x395717+=this['blockSize'];}if(typeof _0x22e1c5=='string'){for(;_0x395717<_0x5a4b7c;)if(_0x4cd46b[_0x3db651]=_0x22e1c5['charCodeAt'](_0x395717),++_0x3db651,++_0x395717,_0x3db651===this['blockSize']){this['compress_'](_0x4cd46b),_0x3db651=0x0;break;}}else{for(;_0x395717<_0x5a4b7c;)if(_0x4cd46b[_0x3db651]=_0x22e1c5[_0x395717],++_0x3db651,++_0x395717,_0x3db651===this['blockSize']){this['compress_'](_0x4cd46b),_0x3db651=0x0;break;}}}this['inbuf_']=_0x3db651,this['total_']+=_0x5a4b7c;}['digest'](){const _0x44ee1d=[];let _0x49455e=this['total_']*0x8;this['inbuf_']<0x38?this['update'](this['pad_'],0x38-this['inbuf_']):this['update'](this['pad_'],this['blockSize']-(this['inbuf_']-0x38));for(let _0x58d04c=this['blockSize']-0x1;_0x58d04c>=0x38;_0x58d04c--)this['buf_'][_0x58d04c]=_0x49455e&0xff,_0x49455e/=0x100;this['compress_'](this['buf_']);let _0x34bcdd=0x0;for(let _0x1d02fa=0x0;_0x1d02fa<0x5;_0x1d02fa++)for(let _0x1224f9=0x18;_0x1224f9>=0x0;_0x1224f9-=0x8)_0x44ee1d[_0x34bcdd]=this['chain_'][_0x1d02fa]>>_0x1224f9&0xff,++_0x34bcdd;return _0x44ee1d;}}function Tc(_0x778084,_0x55b6d0){const _0x3d2a1e=new Sc(_0x778084,_0x55b6d0);return _0x3d2a1e['subscribe']['bind'](_0x3d2a1e);}class Sc{constructor(_0x5c1e03,_0x462926){this['observers']=[],this['unsubscribes']=[],this['observerCount']=0x0,this['task']=Promise['resolve'](),this['finalized']=!0x1,this['onNoObservers']=_0x462926,this['task']['then'](()=>{_0x5c1e03(this);})['catch'](_0x28ed58=>{this['error'](_0x28ed58);});}['next'](_0x5678cf){this['forEachObserver'](_0x13c2c5=>{_0x13c2c5['next'](_0x5678cf);});}['error'](_0x4c1e5f){this['forEachObserver'](_0x5b9662=>{_0x5b9662['error'](_0x4c1e5f);}),this['close'](_0x4c1e5f);}['complete'](){this['forEachObserver'](_0x2b73f=>{_0x2b73f['complete']();}),this['close']();}['subscribe'](_0x4c1f07,_0x123e79,_0x4a4027){let _0x2e70a2;if(_0x4c1f07===void 0x0&&_0x123e79===void 0x0&&_0x4a4027===void 0x0)throw new Error('Missing\x20Observer.');bc(_0x4c1f07,['next','error','complete'])?_0x2e70a2=_0x4c1f07:_0x2e70a2={'next':_0x4c1f07,'error':_0x123e79,'complete':_0x4a4027},_0x2e70a2['next']===void 0x0&&(_0x2e70a2['next']=Jn),_0x2e70a2['error']===void 0x0&&(_0x2e70a2['error']=Jn),_0x2e70a2['complete']===void 0x0&&(_0x2e70a2['complete']=Jn);const _0x2ed465=this['unsubscribeOne']['bind'](this,this['observers']['length']);return this['finalized']&&this['task']['then'](()=>{try{this['finalError']?_0x2e70a2['error'](this['finalError']):_0x2e70a2['complete']();}catch{}}),this['observers']['push'](_0x2e70a2),_0x2ed465;}['unsubscribeOne'](_0x550068){this['observers']===void 0x0||this['observers'][_0x550068]===void 0x0||(delete this['observers'][_0x550068],this['observerCount']-=0x1,this['observerCount']===0x0&&this['onNoObservers']!==void 0x0&&this['onNoObservers'](this));}['forEachObserver'](_0x478fc2){if(!this['finalized']){for(let _0xf95d35=0x0;_0xf95d35<this['observers']['length'];_0xf95d35++)this['sendOne'](_0xf95d35,_0x478fc2);}}['sendOne'](_0xfbc526,_0x61bb49){this['task']['then'](()=>{if(this['observers']!==void 0x0&&this['observers'][_0xfbc526]!==void 0x0)try{_0x61bb49(this['observers'][_0xfbc526]);}catch(_0x2e7d90){typeof console<'u'&&console['error']&&console['error'](_0x2e7d90);}});}['close'](_0x3e508c){this['finalized']||(this['finalized']=!0x0,_0x3e508c!==void 0x0&&(this['finalError']=_0x3e508c),this['task']['then'](()=>{this['observers']=void 0x0,this['onNoObservers']=void 0x0;}));}}function bc(_0x55625e,_0x502da4){if(typeof _0x55625e!='object'||_0x55625e===null)return!0x1;for(const _0x3d8d9d of _0x502da4)if(_0x3d8d9d in _0x55625e&&typeof _0x55625e[_0x3d8d9d]=='function')return!0x0;return!0x1;}function Jn(){}function Pn(_0x1c8c37,_0x3d3a99){return _0x1c8c37+'\x20failed:\x20'+_0x3d3a99+'\x20argument\x20';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rc=function(_0x36ed53){const _0x1167c7=[];let _0x1dea3d=0x0;for(let _0x472775=0x0;_0x472775<_0x36ed53['length'];_0x472775++){let _0x2f896f=_0x36ed53['charCodeAt'](_0x472775);if(_0x2f896f>=0xd800&&_0x2f896f<=0xdbff){const _0xf8defb=_0x2f896f-0xd800;_0x472775++,f(_0x472775<_0x36ed53['length'],'Surrogate\x20pair\x20missing\x20trail\x20surrogate.');const _0x3bcaea=_0x36ed53['charCodeAt'](_0x472775)-0xdc00;_0x2f896f=0x10000+(_0xf8defb<<0xa)+_0x3bcaea;}_0x2f896f<0x80?_0x1167c7[_0x1dea3d++]=_0x2f896f:_0x2f896f<0x800?(_0x1167c7[_0x1dea3d++]=_0x2f896f>>0x6|0xc0,_0x1167c7[_0x1dea3d++]=_0x2f896f&0x3f|0x80):_0x2f896f<0x10000?(_0x1167c7[_0x1dea3d++]=_0x2f896f>>0xc|0xe0,_0x1167c7[_0x1dea3d++]=_0x2f896f>>0x6&0x3f|0x80,_0x1167c7[_0x1dea3d++]=_0x2f896f&0x3f|0x80):(_0x1167c7[_0x1dea3d++]=_0x2f896f>>0x12|0xf0,_0x1167c7[_0x1dea3d++]=_0x2f896f>>0xc&0x3f|0x80,_0x1167c7[_0x1dea3d++]=_0x2f896f>>0x6&0x3f|0x80,_0x1167c7[_0x1dea3d++]=_0x2f896f&0x3f|0x80);}return _0x1167c7;},On=function(_0x18877a){let _0x41197b=0x0;for(let _0x43cf5a=0x0;_0x43cf5a<_0x18877a['length'];_0x43cf5a++){const _0x1cafd8=_0x18877a['charCodeAt'](_0x43cf5a);_0x1cafd8<0x80?_0x41197b++:_0x1cafd8<0x800?_0x41197b+=0x2:_0x1cafd8>=0xd800&&_0x1cafd8<=0xdbff?(_0x41197b+=0x4,_0x43cf5a++):_0x41197b+=0x3;}return _0x41197b;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function N(_0x79bfcd){return _0x79bfcd&&_0x79bfcd['_delegate']?_0x79bfcd['_delegate']:_0x79bfcd;}class Le{constructor(_0x583d40,_0x543b12,_0x1dae68){this['name']=_0x583d40,this['instanceFactory']=_0x543b12,this['type']=_0x1dae68,this['multipleInstances']=!0x1,this['serviceProps']={},this['instantiationMode']='LAZY',this['onInstanceCreated']=null;}['setInstantiationMode'](_0x23c7ef){return this['instantiationMode']=_0x23c7ef,this;}['setMultipleInstances'](_0x2512fb){return this['multipleInstances']=_0x2512fb,this;}['setServiceProps'](_0x27a6a8){return this['serviceProps']=_0x27a6a8,this;}['setInstanceCreatedCallback'](_0x4e207d){return this['onInstanceCreated']=_0x4e207d,this;}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ne='[DEFAULT]';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ac{constructor(_0xb84535,_0x21a183){this['name']=_0xb84535,this['container']=_0x21a183,this['component']=null,this['instances']=new Map(),this['instancesDeferred']=new Map(),this['instancesOptions']=new Map(),this['onInitCallbacks']=new Map();}['get'](_0x5bc516){const _0x4a2f4b=this['normalizeInstanceIdentifier'](_0x5bc516);if(!this['instancesDeferred']['has'](_0x4a2f4b)){const _0x5717f5=new ot();if(this['instancesDeferred']['set'](_0x4a2f4b,_0x5717f5),this['isInitialized'](_0x4a2f4b)||this['shouldAutoInitialize']())try{const _0x24daf5=this['getOrInitializeService']({'instanceIdentifier':_0x4a2f4b});_0x24daf5&&_0x5717f5['resolve'](_0x24daf5);}catch{}}return this['instancesDeferred']['get'](_0x4a2f4b)['promise'];}['getImmediate'](_0x44eadb){const _0x16965b=this['normalizeInstanceIdentifier'](_0x44eadb==null?void 0x0:_0x44eadb['identifier']),_0x2b38f3=(_0x44eadb==null?void 0x0:_0x44eadb['optional'])??!0x1;if(this['isInitialized'](_0x16965b)||this['shouldAutoInitialize']())try{return this['getOrInitializeService']({'instanceIdentifier':_0x16965b});}catch(_0x273481){if(_0x2b38f3)return null;throw _0x273481;}else{if(_0x2b38f3)return null;throw Error('Service\x20'+this['name']+'\x20is\x20not\x20available');}}['getComponent'](){return this['component'];}['setComponent'](_0x2c1beb){if(_0x2c1beb['name']!==this['name'])throw Error('Mismatching\x20Component\x20'+_0x2c1beb['name']+'\x20for\x20Provider\x20'+this['name']+'.');if(this['component'])throw Error('Component\x20for\x20'+this['name']+'\x20has\x20already\x20been\x20provided');if(this['component']=_0x2c1beb,!!this['shouldAutoInitialize']()){if(Nc(_0x2c1beb))try{this['getOrInitializeService']({'instanceIdentifier':Ne});}catch{}for(const [_0x224376,_0x12f670]of this['instancesDeferred']['entries']()){const _0x507eb4=this['normalizeInstanceIdentifier'](_0x224376);try{const _0x11fe1d=this['getOrInitializeService']({'instanceIdentifier':_0x507eb4});_0x12f670['resolve'](_0x11fe1d);}catch{}}}}['clearInstance'](_0x333492=Ne){this['instancesDeferred']['delete'](_0x333492),this['instancesOptions']['delete'](_0x333492),this['instances']['delete'](_0x333492);}async['delete'](){const _0x3bad92=Array['from'](this['instances']['values']());await Promise['all']([..._0x3bad92['filter'](_0x4f37f9=>'INTERNAL'in _0x4f37f9)['map'](_0x2e3b93=>_0x2e3b93['INTERNAL']['delete']()),..._0x3bad92['filter'](_0x15e095=>'_delete'in _0x15e095)['map'](_0x3c9650=>_0x3c9650['_delete']())]);}['isComponentSet'](){return this['component']!=null;}['isInitialized'](_0x4b3680=Ne){return this['instances']['has'](_0x4b3680);}['getOptions'](_0x542381=Ne){return this['instancesOptions']['get'](_0x542381)||{};}['initialize'](_0x248a91={}){const {options:_0x2f6e9a={}}=_0x248a91,_0x2606d2=this['normalizeInstanceIdentifier'](_0x248a91['instanceIdentifier']);if(this['isInitialized'](_0x2606d2))throw Error(this['name']+'('+_0x2606d2+')\x20has\x20already\x20been\x20initialized');if(!this['isComponentSet']())throw Error('Component\x20'+this['name']+'\x20has\x20not\x20been\x20registered\x20yet');const _0x3ee105=this['getOrInitializeService']({'instanceIdentifier':_0x2606d2,'options':_0x2f6e9a});for(const [_0x3096bd,_0x48afcb]of this['instancesDeferred']['entries']()){const _0x5697fb=this['normalizeInstanceIdentifier'](_0x3096bd);_0x2606d2===_0x5697fb&&_0x48afcb['resolve'](_0x3ee105);}return _0x3ee105;}['onInit'](_0x356fe4,_0x1ae7d3){const _0x204afb=this['normalizeInstanceIdentifier'](_0x1ae7d3),_0x244f01=this['onInitCallbacks']['get'](_0x204afb)??new Set();_0x244f01['add'](_0x356fe4),this['onInitCallbacks']['set'](_0x204afb,_0x244f01);const _0x5a559c=this['instances']['get'](_0x204afb);return _0x5a559c&&_0x356fe4(_0x5a559c,_0x204afb),()=>{_0x244f01['delete'](_0x356fe4);};}['invokeOnInitCallbacks'](_0x3ac84d,_0x120b49){const _0x1742fe=this['onInitCallbacks']['get'](_0x120b49);if(_0x1742fe){for(const _0x4d9f7d of _0x1742fe)try{_0x4d9f7d(_0x3ac84d,_0x120b49);}catch{}}}['getOrInitializeService']({instanceIdentifier:_0x7b9ceb,options:_0x943386={}}){let _0x3d39df=this['instances']['get'](_0x7b9ceb);if(!_0x3d39df&&this['component']&&(_0x3d39df=this['component']['instanceFactory'](this['container'],{'instanceIdentifier':kc(_0x7b9ceb),'options':_0x943386}),this['instances']['set'](_0x7b9ceb,_0x3d39df),this['instancesOptions']['set'](_0x7b9ceb,_0x943386),this['invokeOnInitCallbacks'](_0x3d39df,_0x7b9ceb),this['component']['onInstanceCreated']))try{this['component']['onInstanceCreated'](this['container'],_0x7b9ceb,_0x3d39df);}catch{}return _0x3d39df||null;}['normalizeInstanceIdentifier'](_0x340369=Ne){return this['component']?this['component']['multipleInstances']?_0x340369:Ne:_0x340369;}['shouldAutoInitialize'](){return!!this['component']&&this['component']['instantiationMode']!=='EXPLICIT';}}function kc(_0x3790fc){return _0x3790fc===Ne?void 0x0:_0x3790fc;}function Nc(_0x3d7dc5){return _0x3d7dc5['instantiationMode']==='EAGER';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Pc{constructor(_0x266d85){this['name']=_0x266d85,this['providers']=new Map();}['addComponent'](_0x51a859){const _0x56ba7a=this['getProvider'](_0x51a859['name']);if(_0x56ba7a['isComponentSet']())throw new Error('Component\x20'+_0x51a859['name']+'\x20has\x20already\x20been\x20registered\x20with\x20'+this['name']);_0x56ba7a['setComponent'](_0x51a859);}['addOrOverwriteComponent'](_0x4d6286){this['getProvider'](_0x4d6286['name'])['isComponentSet']()&&this['providers']['delete'](_0x4d6286['name']),this['addComponent'](_0x4d6286);}['getProvider'](_0x4d6dcb){if(this['providers']['has'](_0x4d6dcb))return this['providers']['get'](_0x4d6dcb);const _0x24aa47=new Ac(_0x4d6dcb,this);return this['providers']['set'](_0x4d6dcb,_0x24aa47),_0x24aa47;}['getProviders'](){return Array['from'](this['providers']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var T;(function(_0x1b4009){_0x1b4009[_0x1b4009['DEBUG']=0x0]='DEBUG',_0x1b4009[_0x1b4009['VERBOSE']=0x1]='VERBOSE',_0x1b4009[_0x1b4009['INFO']=0x2]='INFO',_0x1b4009[_0x1b4009['WARN']=0x3]='WARN',_0x1b4009[_0x1b4009['ERROR']=0x4]='ERROR',_0x1b4009[_0x1b4009['SILENT']=0x5]='SILENT';}(T||(T={})));const Oc={'debug':T['DEBUG'],'verbose':T['VERBOSE'],'info':T['INFO'],'warn':T['WARN'],'error':T['ERROR'],'silent':T['SILENT']},Dc=T['INFO'],Mc={[T['DEBUG']]:'log',[T['VERBOSE']]:'log',[T['INFO']]:'info',[T['WARN']]:'warn',[T['ERROR']]:'error'},Lc=(_0x590125,_0x33a632,..._0x244077)=>{if(_0x33a632<_0x590125['logLevel'])return;const _0x59d57e=new Date()['toISOString'](),_0x434831=Mc[_0x33a632];if(_0x434831)console[_0x434831]('['+_0x59d57e+']\x20\x20'+_0x590125['name']+':',..._0x244077);else throw new Error('Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20'+_0x33a632+')');};class Ui{constructor(_0x5bf6ea){this['name']=_0x5bf6ea,this['_logLevel']=Dc,this['_logHandler']=Lc,this['_userLogHandler']=null;}get['logLevel'](){return this['_logLevel'];}set['logLevel'](_0x403639){if(!(_0x403639 in T))throw new TypeError('Invalid\x20value\x20\x22'+_0x403639+'\x22\x20assigned\x20to\x20`logLevel`');this['_logLevel']=_0x403639;}['setLogLevel'](_0x1fe6fb){this['_logLevel']=typeof _0x1fe6fb=='string'?Oc[_0x1fe6fb]:_0x1fe6fb;}get['logHandler'](){return this['_logHandler'];}set['logHandler'](_0x1dc13c){if(typeof _0x1dc13c!='function')throw new TypeError('Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function');this['_logHandler']=_0x1dc13c;}get['userLogHandler'](){return this['_userLogHandler'];}set['userLogHandler'](_0x341788){this['_userLogHandler']=_0x341788;}['debug'](..._0x59934c){this['_userLogHandler']&&this['_userLogHandler'](this,T['DEBUG'],..._0x59934c),this['_logHandler'](this,T['DEBUG'],..._0x59934c);}['log'](..._0x472073){this['_userLogHandler']&&this['_userLogHandler'](this,T['VERBOSE'],..._0x472073),this['_logHandler'](this,T['VERBOSE'],..._0x472073);}['info'](..._0x3955b7){this['_userLogHandler']&&this['_userLogHandler'](this,T['INFO'],..._0x3955b7),this['_logHandler'](this,T['INFO'],..._0x3955b7);}['warn'](..._0x1999a8){this['_userLogHandler']&&this['_userLogHandler'](this,T['WARN'],..._0x1999a8),this['_logHandler'](this,T['WARN'],..._0x1999a8);}['error'](..._0x3369c6){this['_userLogHandler']&&this['_userLogHandler'](this,T['ERROR'],..._0x3369c6),this['_logHandler'](this,T['ERROR'],..._0x3369c6);}}const xc=(_0x4e671f,_0x4a5aee)=>_0x4a5aee['some'](_0xd5bdd3=>_0x4e671f instanceof _0xd5bdd3);let Ds,Ms;function Fc(){return Ds||(Ds=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction]);}function Uc(){return Ms||(Ms=[IDBCursor['prototype']['advance'],IDBCursor['prototype']['continue'],IDBCursor['prototype']['continuePrimaryKey']]);}const Jr=new WeakMap(),di=new WeakMap(),Xr=new WeakMap(),Xn=new WeakMap(),Wi=new WeakMap();function Wc(_0x3b4480){const _0x50741f=new Promise((_0x52bfff,_0x2254a2)=>{const _0x43e9ef=()=>{_0x3b4480['removeEventListener']('success',_0x6e3e18),_0x3b4480['removeEventListener']('error',_0x47a265);},_0x6e3e18=()=>{_0x52bfff(_e(_0x3b4480['result'])),_0x43e9ef();},_0x47a265=()=>{_0x2254a2(_0x3b4480['error']),_0x43e9ef();};_0x3b4480['addEventListener']('success',_0x6e3e18),_0x3b4480['addEventListener']('error',_0x47a265);});return _0x50741f['then'](_0x3d39bb=>{_0x3d39bb instanceof IDBCursor&&Jr['set'](_0x3d39bb,_0x3b4480);})['catch'](()=>{}),Wi['set'](_0x50741f,_0x3b4480),_0x50741f;}function Bc(_0x40e264){if(di['has'](_0x40e264))return;const _0xb421ea=new Promise((_0x225aa6,_0x49fe55)=>{const _0xc3ce59=()=>{_0x40e264['removeEventListener']('complete',_0x27591c),_0x40e264['removeEventListener']('error',_0x158587),_0x40e264['removeEventListener']('abort',_0x158587);},_0x27591c=()=>{_0x225aa6(),_0xc3ce59();},_0x158587=()=>{_0x49fe55(_0x40e264['error']||new DOMException('AbortError','AbortError')),_0xc3ce59();};_0x40e264['addEventListener']('complete',_0x27591c),_0x40e264['addEventListener']('error',_0x158587),_0x40e264['addEventListener']('abort',_0x158587);});di['set'](_0x40e264,_0xb421ea);}let fi={'get'(_0x39609e,_0x34db60,_0x15f11a){if(_0x39609e instanceof IDBTransaction){if(_0x34db60==='done')return di['get'](_0x39609e);if(_0x34db60==='objectStoreNames')return _0x39609e['objectStoreNames']||Xr['get'](_0x39609e);if(_0x34db60==='store')return _0x15f11a['objectStoreNames'][0x1]?void 0x0:_0x15f11a['objectStore'](_0x15f11a['objectStoreNames'][0x0]);}return _e(_0x39609e[_0x34db60]);},'set'(_0x3f6cca,_0x5aa4e2,_0x1c5263){return _0x3f6cca[_0x5aa4e2]=_0x1c5263,!0x0;},'has'(_0x47f0e0,_0x17fe60){return _0x47f0e0 instanceof IDBTransaction&&(_0x17fe60==='done'||_0x17fe60==='store')?!0x0:_0x17fe60 in _0x47f0e0;}};function Vc(_0x721f9){fi=_0x721f9(fi);}function Hc(_0x4cb649){return _0x4cb649===IDBDatabase['prototype']['transaction']&&!('objectStoreNames'in IDBTransaction['prototype'])?function(_0x199d50,..._0x4d7176){const _0x3f88cb=_0x4cb649['call'](Zn(this),_0x199d50,..._0x4d7176);return Xr['set'](_0x3f88cb,_0x199d50['sort']?_0x199d50['sort']():[_0x199d50]),_e(_0x3f88cb);}:Uc()['includes'](_0x4cb649)?function(..._0xb55d0c){return _0x4cb649['apply'](Zn(this),_0xb55d0c),_e(Jr['get'](this));}:function(..._0x331f93){return _e(_0x4cb649['apply'](Zn(this),_0x331f93));};}function $c(_0x363653){return typeof _0x363653=='function'?Hc(_0x363653):(_0x363653 instanceof IDBTransaction&&Bc(_0x363653),xc(_0x363653,Fc())?new Proxy(_0x363653,fi):_0x363653);}function _e(_0x50a38e){if(_0x50a38e instanceof IDBRequest)return Wc(_0x50a38e);if(Xn['has'](_0x50a38e))return Xn['get'](_0x50a38e);const _0x26d08b=$c(_0x50a38e);return _0x26d08b!==_0x50a38e&&(Xn['set'](_0x50a38e,_0x26d08b),Wi['set'](_0x26d08b,_0x50a38e)),_0x26d08b;}const Zn=_0x28a7ba=>Wi['get'](_0x28a7ba);function Gc(_0x3daf43,_0x381d6a,{blocked:_0xf47b8e,upgrade:_0x1fb82c,blocking:_0x388cef,terminated:_0x53c5e0}={}){const _0x350767=indexedDB['open'](_0x3daf43,_0x381d6a),_0x149e38=_e(_0x350767);return _0x1fb82c&&_0x350767['addEventListener']('upgradeneeded',_0x491509=>{_0x1fb82c(_e(_0x350767['result']),_0x491509['oldVersion'],_0x491509['newVersion'],_e(_0x350767['transaction']),_0x491509);}),_0xf47b8e&&_0x350767['addEventListener']('blocked',_0x49838c=>_0xf47b8e(_0x49838c['oldVersion'],_0x49838c['newVersion'],_0x49838c)),_0x149e38['then'](_0x57c3e3=>{_0x53c5e0&&_0x57c3e3['addEventListener']('close',()=>_0x53c5e0()),_0x388cef&&_0x57c3e3['addEventListener']('versionchange',_0x41b55b=>_0x388cef(_0x41b55b['oldVersion'],_0x41b55b['newVersion'],_0x41b55b));})['catch'](()=>{}),_0x149e38;}const qc=['get','getKey','getAll','getAllKeys','count'],zc=['put','add','delete','clear'],ei=new Map();function Ls(_0x2a386e,_0x2020e5){if(!(_0x2a386e instanceof IDBDatabase&&!(_0x2020e5 in _0x2a386e)&&typeof _0x2020e5=='string'))return;if(ei['get'](_0x2020e5))return ei['get'](_0x2020e5);const _0x232c93=_0x2020e5['replace'](/FromIndex$/,''),_0x4f301e=_0x2020e5!==_0x232c93,_0x57f408=zc['includes'](_0x232c93);if(!(_0x232c93 in(_0x4f301e?IDBIndex:IDBObjectStore)['prototype'])||!(_0x57f408||qc['includes'](_0x232c93)))return;const _0x405cde=async function(_0x5a04b4,..._0x35eeed){const _0x442787=this['transaction'](_0x5a04b4,_0x57f408?'readwrite':'readonly');let _0x2ef825=_0x442787['store'];return _0x4f301e&&(_0x2ef825=_0x2ef825['index'](_0x35eeed['shift']())),(await Promise['all']([_0x2ef825[_0x232c93](..._0x35eeed),_0x57f408&&_0x442787['done']]))[0x0];};return ei['set'](_0x2020e5,_0x405cde),_0x405cde;}Vc(_0x864991=>({..._0x864991,'get':(_0x2c5680,_0x508a90,_0x3f34af)=>Ls(_0x2c5680,_0x508a90)||_0x864991['get'](_0x2c5680,_0x508a90,_0x3f34af),'has':(_0x3503ce,_0x590f39)=>!!Ls(_0x3503ce,_0x590f39)||_0x864991['has'](_0x3503ce,_0x590f39)}));/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jc{constructor(_0x28505c){this['container']=_0x28505c;}['getPlatformInfoString'](){return this['container']['getProviders']()['map'](_0x250a5d=>{if(Kc(_0x250a5d)){const _0x1b8e00=_0x250a5d['getImmediate']();return _0x1b8e00['library']+'/'+_0x1b8e00['version'];}else return null;})['filter'](_0x22a046=>_0x22a046)['join']('\x20');}}function Kc(_0x5aa46d){const _0x17161b=_0x5aa46d['getComponent']();return(_0x17161b==null?void 0x0:_0x17161b['type'])==='VERSION';}const pi='@firebase/app',xs='0.14.6',oe=new Ui('@firebase/app'),Yc='@firebase/app-compat',Qc='@firebase/analytics-compat',Jc='@firebase/analytics',Xc='@firebase/app-check-compat',Zc='@firebase/app-check',el='@firebase/auth',tl='@firebase/auth-compat',nl='@firebase/database',il='@firebase/data-connect',sl='@firebase/database-compat',rl='@firebase/functions',ol='@firebase/functions-compat',al='@firebase/installations',cl='@firebase/installations-compat',ll='@firebase/messaging',hl='@firebase/messaging-compat',ul='@firebase/performance',dl='@firebase/performance-compat',fl='@firebase/remote-config',pl='@firebase/remote-config-compat',_l='@firebase/storage',gl='@firebase/storage-compat',ml='@firebase/firestore',yl='@firebase/ai',vl='@firebase/firestore-compat',El='firebase',Il='12.6.0',_i='[DEFAULT]',wl={[pi]:'fire-core',[Yc]:'fire-core-compat',[Jc]:'fire-analytics',[Qc]:'fire-analytics-compat',[Zc]:'fire-app-check',[Xc]:'fire-app-check-compat',[el]:'fire-auth',[tl]:'fire-auth-compat',[nl]:'fire-rtdb',[il]:'fire-data-connect',[sl]:'fire-rtdb-compat',[rl]:'fire-fn',[ol]:'fire-fn-compat',[al]:'fire-iid',[cl]:'fire-iid-compat',[ll]:'fire-fcm',[hl]:'fire-fcm-compat',[ul]:'fire-perf',[dl]:'fire-perf-compat',[fl]:'fire-rc',[pl]:'fire-rc-compat',[_l]:'fire-gcs',[gl]:'fire-gcs-compat',[ml]:'fire-fst',[vl]:'fire-fst-compat',[yl]:'fire-vertex','fire-js':'fire-js',[El]:'fire-js-all'},xe=new Map(),gi=new Map(),mi=new Map();function Fs(_0x5020e1,_0x2a8006){try{_0x5020e1['container']['addComponent'](_0x2a8006);}catch(_0x41ea8b){oe['debug']('Component\x20'+_0x2a8006['name']+'\x20failed\x20to\x20register\x20with\x20FirebaseApp\x20'+_0x5020e1['name'],_0x41ea8b);}}function Ze(_0x29d726){const _0x4ebb62=_0x29d726['name'];if(mi['has'](_0x4ebb62))return oe['debug']('There\x20were\x20multiple\x20attempts\x20to\x20register\x20component\x20'+_0x4ebb62+'.'),!0x1;mi['set'](_0x4ebb62,_0x29d726);for(const _0x1e9ea7 of xe['values']())Fs(_0x1e9ea7,_0x29d726);for(const _0x121e69 of gi['values']())Fs(_0x121e69,_0x29d726);return!0x0;}function Bi(_0x416c5f,_0x22de11){const _0x5157a7=_0x416c5f['container']['getProvider']('heartbeat')['getImmediate']({'optional':!0x0});return _0x5157a7&&_0x5157a7['triggerHeartbeat'](),_0x416c5f['container']['getProvider'](_0x22de11);}function $(_0x880c08){return _0x880c08==null?!0x1:_0x880c08['settings']!==void 0x0;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Cl={'no-app':'No\x20Firebase\x20App\x20\x27{$appName}\x27\x20has\x20been\x20created\x20-\x20call\x20initializeApp()\x20first','bad-app-name':'Illegal\x20App\x20name:\x20\x27{$appName}\x27','duplicate-app':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20exists\x20with\x20different\x20options\x20or\x20config','app-deleted':'Firebase\x20App\x20named\x20\x27{$appName}\x27\x20already\x20deleted','server-app-deleted':'Firebase\x20Server\x20App\x20has\x20been\x20deleted','no-options':'Need\x20to\x20provide\x20options,\x20when\x20not\x20being\x20deployed\x20to\x20hosting\x20via\x20source.','invalid-app-argument':'firebase.{$appName}()\x20takes\x20either\x20no\x20argument\x20or\x20a\x20Firebase\x20App\x20instance.','invalid-log-argument':'First\x20argument\x20to\x20`onLog`\x20must\x20be\x20null\x20or\x20a\x20function.','idb-open':'Error\x20thrown\x20when\x20opening\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-get':'Error\x20thrown\x20when\x20reading\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-set':'Error\x20thrown\x20when\x20writing\x20to\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','idb-delete':'Error\x20thrown\x20when\x20deleting\x20from\x20IndexedDB.\x20Original\x20error:\x20{$originalErrorMessage}.','finalization-registry-not-supported':'FirebaseServerApp\x20deleteOnDeref\x20field\x20defined\x20but\x20the\x20JS\x20runtime\x20does\x20not\x20support\x20FinalizationRegistry.','invalid-server-app-environment':'FirebaseServerApp\x20is\x20not\x20for\x20use\x20in\x20browser\x20environments.'},ge=new Bt('app','Firebase',Cl);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tl{constructor(_0x9dd087,_0x842192,_0x23ee6f){this['_isDeleted']=!0x1,this['_options']={..._0x9dd087},this['_config']={..._0x842192},this['_name']=_0x842192['name'],this['_automaticDataCollectionEnabled']=_0x842192['automaticDataCollectionEnabled'],this['_container']=_0x23ee6f,this['container']['addComponent'](new Le('app',()=>this,'PUBLIC'));}get['automaticDataCollectionEnabled'](){return this['checkDestroyed'](),this['_automaticDataCollectionEnabled'];}set['automaticDataCollectionEnabled'](_0x120295){this['checkDestroyed'](),this['_automaticDataCollectionEnabled']=_0x120295;}get['name'](){return this['checkDestroyed'](),this['_name'];}get['options'](){return this['checkDestroyed'](),this['_options'];}get['config'](){return this['checkDestroyed'](),this['_config'];}get['container'](){return this['_container'];}get['isDeleted'](){return this['_isDeleted'];}set['isDeleted'](_0x36ceaf){this['_isDeleted']=_0x36ceaf;}['checkDestroyed'](){if(this['isDeleted'])throw ge['create']('app-deleted',{'appName':this['_name']});}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const lt=Il;function Sl(_0x144b85,_0x318387={}){let _0x48526d=_0x144b85;typeof _0x318387!='object'&&(_0x318387={'name':_0x318387});const _0x3e2666={'name':_i,'automaticDataCollectionEnabled':!0x0,..._0x318387},_0x4f75c3=_0x3e2666['name'];if(typeof _0x4f75c3!='string'||!_0x4f75c3)throw ge['create']('bad-app-name',{'appName':String(_0x4f75c3)});if(_0x48526d||(_0x48526d=qr()),!_0x48526d)throw ge['create']('no-options');const _0x9fae77=xe['get'](_0x4f75c3);if(_0x9fae77){if(Me(_0x48526d,_0x9fae77['options'])&&Me(_0x3e2666,_0x9fae77['config']))return _0x9fae77;throw ge['create']('duplicate-app',{'appName':_0x4f75c3});}const _0x33fd95=new Pc(_0x4f75c3);for(const _0x2d7568 of mi['values']())_0x33fd95['addComponent'](_0x2d7568);const _0x42643f=new Tl(_0x48526d,_0x3e2666,_0x33fd95);return xe['set'](_0x4f75c3,_0x42643f),_0x42643f;}function Zr(_0x3ff602=_i){const _0x3c4e47=xe['get'](_0x3ff602);if(!_0x3c4e47&&_0x3ff602===_i&&qr())return Sl();if(!_0x3c4e47)throw ge['create']('no-app',{'appName':_0x3ff602});return _0x3c4e47;}function f_(){return Array['from'](xe['values']());}async function p_(_0x42d543){let _0x57ba1c=!0x1;const _0x4a3829=_0x42d543['name'];xe['has'](_0x4a3829)?(_0x57ba1c=!0x0,xe['delete'](_0x4a3829)):gi['has'](_0x4a3829)&&_0x42d543['decRefCount']()<=0x0&&(gi['delete'](_0x4a3829),_0x57ba1c=!0x0),_0x57ba1c&&(await Promise['all'](_0x42d543['container']['getProviders']()['map'](_0x3cb56b=>_0x3cb56b['delete']())),_0x42d543['isDeleted']=!0x0);}function me(_0x305932,_0x544bfa,_0x224648){let _0x50f73e=wl[_0x305932]??_0x305932;_0x224648&&(_0x50f73e+='-'+_0x224648);const _0x201ccb=_0x50f73e['match'](/\s|\//),_0x598ce0=_0x544bfa['match'](/\s|\//);if(_0x201ccb||_0x598ce0){const _0x322a72=['Unable\x20to\x20register\x20library\x20\x22'+_0x50f73e+'\x22\x20with\x20version\x20\x22'+_0x544bfa+'\x22:'];_0x201ccb&&_0x322a72['push']('library\x20name\x20\x22'+_0x50f73e+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),_0x201ccb&&_0x598ce0&&_0x322a72['push']('and'),_0x598ce0&&_0x322a72['push']('version\x20name\x20\x22'+_0x544bfa+'\x22\x20contains\x20illegal\x20characters\x20(whitespace\x20or\x20\x22/\x22)'),oe['warn'](_0x322a72['join']('\x20'));return;}Ze(new Le(_0x50f73e+'-version',()=>({'library':_0x50f73e,'version':_0x544bfa}),'VERSION'));}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const bl='firebase-heartbeat-database',Rl=0x1,kt='firebase-heartbeat-store';let ti=null;function eo(){return ti||(ti=Gc(bl,Rl,{'upgrade':(_0x4acef6,_0xf99dca)=>{switch(_0xf99dca){case 0x0:try{_0x4acef6['createObjectStore'](kt);}catch(_0x27613a){console['warn'](_0x27613a);}}}})['catch'](_0xf79ea=>{throw ge['create']('idb-open',{'originalErrorMessage':_0xf79ea['message']});})),ti;}async function Al(_0x29ba68){try{const _0x4742f7=(await eo())['transaction'](kt),_0x5a5215=await _0x4742f7['objectStore'](kt)['get'](to(_0x29ba68));return await _0x4742f7['done'],_0x5a5215;}catch(_0x278b33){if(_0x278b33 instanceof Se)oe['warn'](_0x278b33['message']);else{const _0x187ce6=ge['create']('idb-get',{'originalErrorMessage':_0x278b33==null?void 0x0:_0x278b33['message']});oe['warn'](_0x187ce6['message']);}}}async function Us(_0x236ce9,_0x1cd802){try{const _0x1e6274=(await eo())['transaction'](kt,'readwrite');await _0x1e6274['objectStore'](kt)['put'](_0x1cd802,to(_0x236ce9)),await _0x1e6274['done'];}catch(_0x3fdab0){if(_0x3fdab0 instanceof Se)oe['warn'](_0x3fdab0['message']);else{const _0x4d806c=ge['create']('idb-set',{'originalErrorMessage':_0x3fdab0==null?void 0x0:_0x3fdab0['message']});oe['warn'](_0x4d806c['message']);}}}function to(_0x1a4ae2){return _0x1a4ae2['name']+'!'+_0x1a4ae2['options']['appId'];}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kl=0x400,Nl=0x1e;class Pl{constructor(_0x3ee4c2){this['container']=_0x3ee4c2,this['_heartbeatsCache']=null;const _0x112eb9=this['container']['getProvider']('app')['getImmediate']();this['_storage']=new Dl(_0x112eb9),this['_heartbeatsCachePromise']=this['_storage']['read']()['then'](_0x3d2662=>(this['_heartbeatsCache']=_0x3d2662,_0x3d2662));}async['triggerHeartbeat'](){var _0x5d0fe1,_0x28e73f;try{const _0x374207=this['container']['getProvider']('platform-logger')['getImmediate']()['getPlatformInfoString'](),_0x54919b=Ws();if(((_0x5d0fe1=this['_heartbeatsCache'])==null?void 0x0:_0x5d0fe1['heartbeats'])==null&&(this['_heartbeatsCache']=await this['_heartbeatsCachePromise'],((_0x28e73f=this['_heartbeatsCache'])==null?void 0x0:_0x28e73f['heartbeats'])==null)||this['_heartbeatsCache']['lastSentHeartbeatDate']===_0x54919b||this['_heartbeatsCache']['heartbeats']['some'](_0x49a20e=>_0x49a20e['date']===_0x54919b))return;if(this['_heartbeatsCache']['heartbeats']['push']({'date':_0x54919b,'agent':_0x374207}),this['_heartbeatsCache']['heartbeats']['length']>Nl){const _0x470de0=Ml(this['_heartbeatsCache']['heartbeats']);this['_heartbeatsCache']['heartbeats']['splice'](_0x470de0,0x1);}return this['_storage']['overwrite'](this['_heartbeatsCache']);}catch(_0x4fa775){oe['warn'](_0x4fa775);}}async['getHeartbeatsHeader'](){var _0x3e5e12;try{if(this['_heartbeatsCache']===null&&await this['_heartbeatsCachePromise'],((_0x3e5e12=this['_heartbeatsCache'])==null?void 0x0:_0x3e5e12['heartbeats'])==null||this['_heartbeatsCache']['heartbeats']['length']===0x0)return'';const _0x495be3=Ws(),{heartbeatsToSend:_0x36ceca,unsentEntries:_0x1cd9f8}=Ol(this['_heartbeatsCache']['heartbeats']),_0x107580=cn(JSON['stringify']({'version':0x2,'heartbeats':_0x36ceca}));return this['_heartbeatsCache']['lastSentHeartbeatDate']=_0x495be3,_0x1cd9f8['length']>0x0?(this['_heartbeatsCache']['heartbeats']=_0x1cd9f8,await this['_storage']['overwrite'](this['_heartbeatsCache'])):(this['_heartbeatsCache']['heartbeats']=[],this['_storage']['overwrite'](this['_heartbeatsCache'])),_0x107580;}catch(_0x3ae6c3){return oe['warn'](_0x3ae6c3),'';}}}function Ws(){return new Date()['toISOString']()['substring'](0x0,0xa);}function Ol(_0x209144,_0x589aa6=kl){const _0x18ab73=[];let _0x2f7dc0=_0x209144['slice']();for(const _0xd1bd8a of _0x209144){const _0x5e761a=_0x18ab73['find'](_0x2c0a6c=>_0x2c0a6c['agent']===_0xd1bd8a['agent']);if(_0x5e761a){if(_0x5e761a['dates']['push'](_0xd1bd8a['date']),Bs(_0x18ab73)>_0x589aa6){_0x5e761a['dates']['pop']();break;}}else{if(_0x18ab73['push']({'agent':_0xd1bd8a['agent'],'dates':[_0xd1bd8a['date']]}),Bs(_0x18ab73)>_0x589aa6){_0x18ab73['pop']();break;}}_0x2f7dc0=_0x2f7dc0['slice'](0x1);}return{'heartbeatsToSend':_0x18ab73,'unsentEntries':_0x2f7dc0};}class Dl{constructor(_0x32d19e){this['app']=_0x32d19e,this['_canUseIndexedDBPromise']=this['runIndexedDBEnvironmentCheck']();}async['runIndexedDBEnvironmentCheck'](){return gc()?mc()['then'](()=>!0x0)['catch'](()=>!0x1):!0x1;}async['read'](){if(await this['_canUseIndexedDBPromise']){const _0x21bd8a=await Al(this['app']);return _0x21bd8a!=null&&_0x21bd8a['heartbeats']?_0x21bd8a:{'heartbeats':[]};}else return{'heartbeats':[]};}async['overwrite'](_0x17b801){if(await this['_canUseIndexedDBPromise']){const _0x5433fe=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x17b801['lastSentHeartbeatDate']??_0x5433fe['lastSentHeartbeatDate'],'heartbeats':_0x17b801['heartbeats']});}else return;}async['add'](_0x17a5b4){if(await this['_canUseIndexedDBPromise']){const _0x3f3ae0=await this['read']();return Us(this['app'],{'lastSentHeartbeatDate':_0x17a5b4['lastSentHeartbeatDate']??_0x3f3ae0['lastSentHeartbeatDate'],'heartbeats':[..._0x3f3ae0['heartbeats'],..._0x17a5b4['heartbeats']]});}else return;}}function Bs(_0x3e03f5){return cn(JSON['stringify']({'version':0x2,'heartbeats':_0x3e03f5}))['length'];}function Ml(_0x17cf5d){if(_0x17cf5d['length']===0x0)return-0x1;let _0x31f0c2=0x0,_0x150c93=_0x17cf5d[0x0]['date'];for(let _0x555087=0x1;_0x555087<_0x17cf5d['length'];_0x555087++)_0x17cf5d[_0x555087]['date']<_0x150c93&&(_0x150c93=_0x17cf5d[_0x555087]['date'],_0x31f0c2=_0x555087);return _0x31f0c2;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ll(_0xcc4ba9){Ze(new Le('platform-logger',_0x172827=>new jc(_0x172827),'PRIVATE')),Ze(new Le('heartbeat',_0x171e83=>new Pl(_0x171e83),'PRIVATE')),me(pi,xs,_0xcc4ba9),me(pi,xs,'esm2020'),me('fire-js','');}Ll('');var xl='firebase',Fl='12.6.0';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
me(xl,Fl,'app');var Vs={};const Hs='@firebase/database',$s='1.1.0';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let no='';function Ul(_0x4dbc84){no=_0x4dbc84;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wl{constructor(_0x3670ba){this['domStorage_']=_0x3670ba,this['prefix_']='firebase:';}['set'](_0x51c935,_0x5ae79b){_0x5ae79b==null?this['domStorage_']['removeItem'](this['prefixedName_'](_0x51c935)):this['domStorage_']['setItem'](this['prefixedName_'](_0x51c935),O(_0x5ae79b));}['get'](_0x1ab71a){const _0x44ca41=this['domStorage_']['getItem'](this['prefixedName_'](_0x1ab71a));return _0x44ca41==null?null:At(_0x44ca41);}['remove'](_0x974db){this['domStorage_']['removeItem'](this['prefixedName_'](_0x974db));}['prefixedName_'](_0x44d5f2){return this['prefix_']+_0x44d5f2;}['toString'](){return this['domStorage_']['toString']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Bl{constructor(){this['cache_']={},this['isInMemoryStorage']=!0x0;}['set'](_0x5d9c46,_0x14583c){_0x14583c==null?delete this['cache_'][_0x5d9c46]:this['cache_'][_0x5d9c46]=_0x14583c;}['get'](_0x4b096c){return J(this['cache_'],_0x4b096c)?this['cache_'][_0x4b096c]:null;}['remove'](_0xf50043){delete this['cache_'][_0xf50043];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const io=function(_0x33f82c){try{if(typeof window<'u'&&typeof window[_0x33f82c]<'u'){const _0x24ed20=window[_0x33f82c];return _0x24ed20['setItem']('firebase:sentinel','cache'),_0x24ed20['removeItem']('firebase:sentinel'),new Wl(_0x24ed20);}}catch{}return new Bl();},Oe=io('localStorage'),Vl=io('sessionStorage'),Ye=new Ui('@firebase/database'),so=(function(){let _0x537ac5=0x1;return function(){return _0x537ac5++;};}()),ro=function(_0x121b36){const _0x102b28=Rc(_0x121b36),_0xcfd6d=new Cc();_0xcfd6d['update'](_0x102b28);const _0x21b58f=_0xcfd6d['digest']();return Li['encodeByteArray'](_0x21b58f);},Vt=function(..._0x5cbdea){let _0x19bb8a='';for(let _0x34dbca=0x0;_0x34dbca<_0x5cbdea['length'];_0x34dbca++){const _0x160083=_0x5cbdea[_0x34dbca];Array['isArray'](_0x160083)||_0x160083&&typeof _0x160083=='object'&&typeof _0x160083['length']=='number'?_0x19bb8a+=Vt['apply'](null,_0x160083):typeof _0x160083=='object'?_0x19bb8a+=O(_0x160083):_0x19bb8a+=_0x160083,_0x19bb8a+='\x20';}return _0x19bb8a;};let wt=null,Gs=!0x0;const Hl=function(_0x3322fc,_0xedd464){f(!0x0,'Can\x27t\x20turn\x20on\x20custom\x20loggers\x20persistently.'),Ye['logLevel']=T['VERBOSE'],wt=Ye['log']['bind'](Ye);},L=function(..._0x10ae1c){if(Gs===!0x0&&(Gs=!0x1,wt===null&&Vl['get']('logging_enabled')===!0x0&&Hl()),wt){const _0x28c21f=Vt['apply'](null,_0x10ae1c);wt(_0x28c21f);}},Ht=function(_0x32e92b){return function(..._0x571716){L(_0x32e92b,..._0x571716);};},yi=function(..._0x325b8e){const _0x53951a='FIREBASE\x20INTERNAL\x20ERROR:\x20'+Vt(..._0x325b8e);Ye['error'](_0x53951a);},ae=function(..._0x160f78){const _0x10056f='FIREBASE\x20FATAL\x20ERROR:\x20'+Vt(..._0x160f78);throw Ye['error'](_0x10056f),new Error(_0x10056f);},U=function(..._0x57433f){const _0x400b48='FIREBASE\x20WARNING:\x20'+Vt(..._0x57433f);Ye['warn'](_0x400b48);},$l=function(){typeof window<'u'&&window['location']&&window['location']['protocol']&&window['location']['protocol']['indexOf']('https:')!==-0x1&&U('Insecure\x20Firebase\x20access\x20from\x20a\x20secure\x20page.\x20Please\x20use\x20https\x20in\x20calls\x20to\x20new\x20Firebase().');},Vi=function(_0x306ef3){return typeof _0x306ef3=='number'&&(_0x306ef3!==_0x306ef3||_0x306ef3===Number['POSITIVE_INFINITY']||_0x306ef3===Number['NEGATIVE_INFINITY']);},Gl=function(_0x517b5f){if(document['readyState']==='complete')_0x517b5f();else{let _0x4f98c0=!0x1;const _0x9527da=function(){if(!document['body']){setTimeout(_0x9527da,Math['floor'](0xa));return;}_0x4f98c0||(_0x4f98c0=!0x0,_0x517b5f());};document['addEventListener']?(document['addEventListener']('DOMContentLoaded',_0x9527da,!0x1),window['addEventListener']('load',_0x9527da,!0x1)):document['attachEvent']&&(document['attachEvent']('onreadystatechange',()=>{document['readyState']==='complete'&&_0x9527da();}),window['attachEvent']('onload',_0x9527da));}},Fe='[MIN_NAME]',Ie='[MAX_NAME]',He=function(_0x5dbafe,_0x239628){if(_0x5dbafe===_0x239628)return 0x0;if(_0x5dbafe===Fe||_0x239628===Ie)return-0x1;if(_0x239628===Fe||_0x5dbafe===Ie)return 0x1;{const _0x3fc745=qs(_0x5dbafe),_0x41028f=qs(_0x239628);return _0x3fc745!==null?_0x41028f!==null?_0x3fc745-_0x41028f===0x0?_0x5dbafe['length']-_0x239628['length']:_0x3fc745-_0x41028f:-0x1:_0x41028f!==null?0x1:_0x5dbafe<_0x239628?-0x1:0x1;}},ql=function(_0xea2df0,_0x5ae3d3){return _0xea2df0===_0x5ae3d3?0x0:_0xea2df0<_0x5ae3d3?-0x1:0x1;},_t=function(_0x3aa918,_0x9cda3d){if(_0x9cda3d&&_0x3aa918 in _0x9cda3d)return _0x9cda3d[_0x3aa918];throw new Error('Missing\x20required\x20key\x20('+_0x3aa918+')\x20in\x20object:\x20'+O(_0x9cda3d));},Hi=function(_0x348935){if(typeof _0x348935!='object'||_0x348935===null)return O(_0x348935);const _0x7542a1=[];for(const _0x54e8e8 in _0x348935)_0x7542a1['push'](_0x54e8e8);_0x7542a1['sort']();let _0x165363='{';for(let _0x331f9d=0x0;_0x331f9d<_0x7542a1['length'];_0x331f9d++)_0x331f9d!==0x0&&(_0x165363+=','),_0x165363+=O(_0x7542a1[_0x331f9d]),_0x165363+=':',_0x165363+=Hi(_0x348935[_0x7542a1[_0x331f9d]]);return _0x165363+='}',_0x165363;},oo=function(_0x19f126,_0x343ae5){const _0x1ce853=_0x19f126['length'];if(_0x1ce853<=_0x343ae5)return[_0x19f126];const _0x672227=[];for(let _0x5c6953=0x0;_0x5c6953<_0x1ce853;_0x5c6953+=_0x343ae5)_0x5c6953+_0x343ae5>_0x1ce853?_0x672227['push'](_0x19f126['substring'](_0x5c6953,_0x1ce853)):_0x672227['push'](_0x19f126['substring'](_0x5c6953,_0x5c6953+_0x343ae5));return _0x672227;};function x(_0x4e4cd5,_0x351e9d){for(const _0xda7564 in _0x4e4cd5)_0x4e4cd5['hasOwnProperty'](_0xda7564)&&_0x351e9d(_0xda7564,_0x4e4cd5[_0xda7564]);}const ao=function(_0x27e468){f(!Vi(_0x27e468),'Invalid\x20JSON\x20number');const _0x18f5bb=0xb,_0x3ba5ab=0x34,_0x55cb5=(0x1<<_0x18f5bb-0x1)-0x1;let _0x31a3ee,_0x24d607,_0x73f1e5,_0x27a679,_0x24a488;_0x27e468===0x0?(_0x24d607=0x0,_0x73f1e5=0x0,_0x31a3ee=0x1/_0x27e468===-0x1/0x0?0x1:0x0):(_0x31a3ee=_0x27e468<0x0,_0x27e468=Math['abs'](_0x27e468),_0x27e468>=Math['pow'](0x2,0x1-_0x55cb5)?(_0x27a679=Math['min'](Math['floor'](Math['log'](_0x27e468)/Math['LN2']),_0x55cb5),_0x24d607=_0x27a679+_0x55cb5,_0x73f1e5=Math['round'](_0x27e468*Math['pow'](0x2,_0x3ba5ab-_0x27a679)-Math['pow'](0x2,_0x3ba5ab))):(_0x24d607=0x0,_0x73f1e5=Math['round'](_0x27e468/Math['pow'](0x2,0x1-_0x55cb5-_0x3ba5ab))));const _0x3d2879=[];for(_0x24a488=_0x3ba5ab;_0x24a488;_0x24a488-=0x1)_0x3d2879['push'](_0x73f1e5%0x2?0x1:0x0),_0x73f1e5=Math['floor'](_0x73f1e5/0x2);for(_0x24a488=_0x18f5bb;_0x24a488;_0x24a488-=0x1)_0x3d2879['push'](_0x24d607%0x2?0x1:0x0),_0x24d607=Math['floor'](_0x24d607/0x2);_0x3d2879['push'](_0x31a3ee?0x1:0x0),_0x3d2879['reverse']();const _0x1ab415=_0x3d2879['join']('');let _0x3b30b8='';for(_0x24a488=0x0;_0x24a488<0x40;_0x24a488+=0x8){let _0x20bea9=parseInt(_0x1ab415['substr'](_0x24a488,0x8),0x2)['toString'](0x10);_0x20bea9['length']===0x1&&(_0x20bea9='0'+_0x20bea9),_0x3b30b8=_0x3b30b8+_0x20bea9;}return _0x3b30b8['toLowerCase']();},zl=function(){return!!(typeof window=='object'&&window['chrome']&&window['chrome']['extension']&&!/^chrome/['test'](window['location']['href']));},jl=function(){return typeof Windows=='object'&&typeof Windows['UI']=='object';};function Kl(_0x492657,_0x2aa4e5){let _0xf1e868='Unknown\x20Error';_0x492657==='too_big'?_0xf1e868='The\x20data\x20requested\x20exceeds\x20the\x20maximum\x20size\x20that\x20can\x20be\x20accessed\x20with\x20a\x20single\x20request.':_0x492657==='permission_denied'?_0xf1e868='Client\x20doesn\x27t\x20have\x20permission\x20to\x20access\x20the\x20desired\x20data.':_0x492657==='unavailable'&&(_0xf1e868='The\x20service\x20is\x20unavailable');const _0x116c51=new Error(_0x492657+'\x20at\x20'+_0x2aa4e5['_path']['toString']()+':\x20'+_0xf1e868);return _0x116c51['code']=_0x492657['toUpperCase'](),_0x116c51;}const Yl=new RegExp('^-?(0*)\x5cd{1,10}$'),Ql=-0x80000000,Jl=0x7fffffff,qs=function(_0x45bcbf){if(Yl['test'](_0x45bcbf)){const _0x45f8f4=Number(_0x45bcbf);if(_0x45f8f4>=Ql&&_0x45f8f4<=Jl)return _0x45f8f4;}return null;},ht=function(_0x19b764){try{_0x19b764();}catch(_0x49c85c){setTimeout(()=>{const _0x317808=_0x49c85c['stack']||'';throw U('Exception\x20was\x20thrown\x20by\x20user\x20callback.',_0x317808),_0x49c85c;},Math['floor'](0x0));}},Xl=function(){return(typeof window=='object'&&window['navigator']&&window['navigator']['userAgent']||'')['search'](/googlebot|google webmaster tools|bingbot|yahoo! slurp|baiduspider|yandexbot|duckduckbot/i)>=0x0;},Ct=function(_0x2675e2,_0xbcaf97){const _0x3c58a5=setTimeout(_0x2675e2,_0xbcaf97);return typeof _0x3c58a5=='number'&&typeof Deno<'u'&&Deno['unrefTimer']?Deno['unrefTimer'](_0x3c58a5):typeof _0x3c58a5=='object'&&_0x3c58a5['unref']&&_0x3c58a5['unref'](),_0x3c58a5;};/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Zl{constructor(_0x4aadf6,_0x5b59e5){this['appCheckProvider']=_0x5b59e5,this['appName']=_0x4aadf6['name'],$(_0x4aadf6)&&_0x4aadf6['settings']['appCheckToken']&&(this['serverAppAppCheckToken']=_0x4aadf6['settings']['appCheckToken']),this['appCheck']=_0x5b59e5==null?void 0x0:_0x5b59e5['getImmediate']({'optional':!0x0}),this['appCheck']||_0x5b59e5==null||_0x5b59e5['get']()['then'](_0x2f046d=>this['appCheck']=_0x2f046d);}['getToken'](_0x139ae6){if(this['serverAppAppCheckToken']){if(_0x139ae6)throw new Error('Attempted\x20reuse\x20of\x20`FirebaseServerApp.appCheckToken`\x20after\x20previous\x20usage\x20failed.');return Promise['resolve']({'token':this['serverAppAppCheckToken']});}return this['appCheck']?this['appCheck']['getToken'](_0x139ae6):new Promise((_0x2a4005,_0x5d20d0)=>{setTimeout(()=>{this['appCheck']?this['getToken'](_0x139ae6)['then'](_0x2a4005,_0x5d20d0):_0x2a4005(null);},0x0);});}['addTokenChangeListener'](_0x14a4ca){var _0xc0eacf;(_0xc0eacf=this['appCheckProvider'])==null||_0xc0eacf['get']()['then'](_0x205cd3=>_0x205cd3['addTokenListener'](_0x14a4ca));}['notifyForInvalidToken'](){U('Provided\x20AppCheck\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eh{constructor(_0x3fe662,_0x49d479,_0xe91c0c){this['appName_']=_0x3fe662,this['firebaseOptions_']=_0x49d479,this['authProvider_']=_0xe91c0c,this['auth_']=null,this['auth_']=_0xe91c0c['getImmediate']({'optional':!0x0}),this['auth_']||_0xe91c0c['onInit'](_0x18a6fa=>this['auth_']=_0x18a6fa);}['getToken'](_0x1fc808){return this['auth_']?this['auth_']['getToken'](_0x1fc808)['catch'](_0xb9b50a=>_0xb9b50a&&_0xb9b50a['code']==='auth/token-not-initialized'?(L('Got\x20auth/token-not-initialized\x20error.\x20\x20Treating\x20as\x20null\x20token.'),null):Promise['reject'](_0xb9b50a)):new Promise((_0x13dce0,_0x5a60ab)=>{setTimeout(()=>{this['auth_']?this['getToken'](_0x1fc808)['then'](_0x13dce0,_0x5a60ab):_0x13dce0(null);},0x0);});}['addTokenChangeListener'](_0x5b18e9){this['auth_']?this['auth_']['addAuthTokenListener'](_0x5b18e9):this['authProvider_']['get']()['then'](_0x1fd69b=>_0x1fd69b['addAuthTokenListener'](_0x5b18e9));}['removeTokenChangeListener'](_0x57b7fb){this['authProvider_']['get']()['then'](_0x33e1de=>_0x33e1de['removeAuthTokenListener'](_0x57b7fb));}['notifyForInvalidToken'](){let _0x37608c='Provided\x20authentication\x20credentials\x20for\x20the\x20app\x20named\x20\x22'+this['appName_']+'\x22\x20are\x20invalid.\x20This\x20usually\x20indicates\x20your\x20app\x20was\x20not\x20initialized\x20correctly.\x20';'credential'in this['firebaseOptions_']?_0x37608c+='Make\x20sure\x20the\x20\x22credential\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':'serviceAccount'in this['firebaseOptions_']?_0x37608c+='Make\x20sure\x20the\x20\x22serviceAccount\x22\x20property\x20provided\x20to\x20initializeApp()\x20is\x20authorized\x20to\x20access\x20the\x20specified\x20\x22databaseURL\x22\x20and\x20is\x20from\x20the\x20correct\x20project.':_0x37608c+='Make\x20sure\x20the\x20\x22apiKey\x22\x20and\x20\x22databaseURL\x22\x20properties\x20provided\x20to\x20initializeApp()\x20match\x20the\x20values\x20provided\x20for\x20your\x20app\x20at\x20https://console.firebase.google.com/.',U(_0x37608c);}}class nn{constructor(_0x5c53c4){this['accessToken']=_0x5c53c4;}['getToken'](_0x1801b1){return Promise['resolve']({'accessToken':this['accessToken']});}['addTokenChangeListener'](_0x9ffe2a){_0x9ffe2a(this['accessToken']);}['removeTokenChangeListener'](_0x3e3544){}['notifyForInvalidToken'](){}}nn['OWNER']='owner';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const $i='5',co='v',lo='s',ho='r',uo='f',fo=/(console\.firebase|firebase-console-\w+\.corp|firebase\.corp)\.google\.com/,po='ls',_o='p',vi='ac',go='websocket',mo='long_polling';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yo{constructor(_0x233f2,_0x3c51a9,_0x22cc93,_0x489c1e,_0x38b712=!0x1,_0xb8f283='',_0x3df1e3=!0x1,_0x1e80af=!0x1,_0x2bccff=null){this['secure']=_0x3c51a9,this['namespace']=_0x22cc93,this['webSocketOnly']=_0x489c1e,this['nodeAdmin']=_0x38b712,this['persistenceKey']=_0xb8f283,this['includeNamespaceInQueryParams']=_0x3df1e3,this['isUsingEmulator']=_0x1e80af,this['emulatorOptions']=_0x2bccff,this['_host']=_0x233f2['toLowerCase'](),this['_domain']=this['_host']['substr'](this['_host']['indexOf']('.')+0x1),this['internalHost']=Oe['get']('host:'+_0x233f2)||this['_host'];}['isCacheableHost'](){return this['internalHost']['substr'](0x0,0x2)==='s-';}['isCustomHost'](){return this['_domain']!=='firebaseio.com'&&this['_domain']!=='firebaseio-demo.com';}get['host'](){return this['_host'];}set['host'](_0x57f52f){_0x57f52f!==this['internalHost']&&(this['internalHost']=_0x57f52f,this['isCacheableHost']()&&Oe['set']('host:'+this['_host'],this['internalHost']));}['toString'](){let _0x4c403d=this['toURLString']();return this['persistenceKey']&&(_0x4c403d+='<'+this['persistenceKey']+'>'),_0x4c403d;}['toURLString'](){const _0x1b6d30=this['secure']?'https://':'http://',_0x239e3b=this['includeNamespaceInQueryParams']?'?ns='+this['namespace']:'';return''+_0x1b6d30+this['host']+'/'+_0x239e3b;}}function th(_0x30ed6a){return _0x30ed6a['host']!==_0x30ed6a['internalHost']||_0x30ed6a['isCustomHost']()||_0x30ed6a['includeNamespaceInQueryParams'];}function vo(_0x55e961,_0x105fd6,_0x2df6f4){f(typeof _0x105fd6=='string','typeof\x20type\x20must\x20==\x20string'),f(typeof _0x2df6f4=='object','typeof\x20params\x20must\x20==\x20object');let _0x33f66d;if(_0x105fd6===go)_0x33f66d=(_0x55e961['secure']?'wss://':'ws://')+_0x55e961['internalHost']+'/.ws?';else{if(_0x105fd6===mo)_0x33f66d=(_0x55e961['secure']?'https://':'http://')+_0x55e961['internalHost']+'/.lp?';else throw new Error('Unknown\x20connection\x20type:\x20'+_0x105fd6);}th(_0x55e961)&&(_0x2df6f4['ns']=_0x55e961['namespace']);const _0x49d2a3=[];return x(_0x2df6f4,(_0x33fd4d,_0x563f89)=>{_0x49d2a3['push'](_0x33fd4d+'='+_0x563f89);}),_0x33f66d+_0x49d2a3['join']('&');}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class nh{constructor(){this['counters_']={};}['incrementCounter'](_0x5e58b2,_0x10ea4f=0x1){J(this['counters_'],_0x5e58b2)||(this['counters_'][_0x5e58b2]=0x0),this['counters_'][_0x5e58b2]+=_0x10ea4f;}['get'](){return nc(this['counters_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ni={},ii={};function Gi(_0xbd252f){const _0x3fa244=_0xbd252f['toString']();return ni[_0x3fa244]||(ni[_0x3fa244]=new nh()),ni[_0x3fa244];}function ih(_0x37d320,_0x160926){const _0x31b060=_0x37d320['toString']();return ii[_0x31b060]||(ii[_0x31b060]=_0x160926()),ii[_0x31b060];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class sh{constructor(_0x2ab40c){this['onMessage_']=_0x2ab40c,this['pendingResponses']=[],this['currentResponseNum']=0x0,this['closeAfterResponse']=-0x1,this['onClose']=null;}['closeAfter'](_0x51ecf4,_0x14c3d8){this['closeAfterResponse']=_0x51ecf4,this['onClose']=_0x14c3d8,this['closeAfterResponse']<this['currentResponseNum']&&(this['onClose'](),this['onClose']=null);}['handleResponse'](_0xc303fa,_0x548263){for(this['pendingResponses'][_0xc303fa]=_0x548263;this['pendingResponses'][this['currentResponseNum']];){const _0x1d841f=this['pendingResponses'][this['currentResponseNum']];delete this['pendingResponses'][this['currentResponseNum']];for(let _0x51e5d8=0x0;_0x51e5d8<_0x1d841f['length'];++_0x51e5d8)_0x1d841f[_0x51e5d8]&&ht(()=>{this['onMessage_'](_0x1d841f[_0x51e5d8]);});if(this['currentResponseNum']===this['closeAfterResponse']){this['onClose']&&(this['onClose'](),this['onClose']=null);break;}this['currentResponseNum']++;}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const zs='start',rh='close',oh='pLPCommand',ah='pRTLPCB',Eo='id',Io='pw',wo='ser',ch='cb',lh='seg',hh='ts',uh='d',dh='dframe',Co=0x74e,To=0x1e,fh=Co-To,ph=0x61a8,_h=0x7530;class je{constructor(_0x29d8f7,_0x5d69fc,_0x23c958,_0x3d1b0f,_0x3c4fe4,_0x5e9f19,_0x539839){this['connId']=_0x29d8f7,this['repoInfo']=_0x5d69fc,this['applicationId']=_0x23c958,this['appCheckToken']=_0x3d1b0f,this['authToken']=_0x3c4fe4,this['transportSessionId']=_0x5e9f19,this['lastSessionId']=_0x539839,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['everConnected_']=!0x1,this['log_']=Ht(_0x29d8f7),this['stats_']=Gi(_0x5d69fc),this['urlFn']=_0x3a8ae8=>(this['appCheckToken']&&(_0x3a8ae8[vi]=this['appCheckToken']),vo(_0x5d69fc,mo,_0x3a8ae8));}['open'](_0x5e41c0,_0x1cea33){this['curSegmentNum']=0x0,this['onDisconnect_']=_0x1cea33,this['myPacketOrderer']=new sh(_0x5e41c0),this['isClosed_']=!0x1,this['connectTimeoutTimer_']=setTimeout(()=>{this['log_']('Timed\x20out\x20trying\x20to\x20connect.'),this['onClosed_'](),this['connectTimeoutTimer_']=null;},Math['floor'](_h)),Gl(()=>{if(this['isClosed_'])return;this['scriptTagHolder']=new qi((..._0x1681a8)=>{const [_0x6080cc,_0x44164a,_0x458445,_0x21bb45,_0x3ed635]=_0x1681a8;if(this['incrementIncomingBytes_'](_0x1681a8),!!this['scriptTagHolder']){if(this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null),this['everConnected_']=!0x0,_0x6080cc===zs)this['id']=_0x44164a,this['password']=_0x458445;else{if(_0x6080cc===rh)_0x44164a?(this['scriptTagHolder']['sendNewPolls']=!0x1,this['myPacketOrderer']['closeAfter'](_0x44164a,()=>{this['onClosed_']();})):this['onClosed_']();else throw new Error('Unrecognized\x20command\x20received:\x20'+_0x6080cc);}}},(..._0x5b4134)=>{const [_0x36833e,_0xdfb3cc]=_0x5b4134;this['incrementIncomingBytes_'](_0x5b4134),this['myPacketOrderer']['handleResponse'](_0x36833e,_0xdfb3cc);},()=>{this['onClosed_']();},this['urlFn']);const _0x313c5e={};_0x313c5e[zs]='t',_0x313c5e[wo]=Math['floor'](Math['random']()*0x5f5e100),this['scriptTagHolder']['uniqueCallbackIdentifier']&&(_0x313c5e[ch]=this['scriptTagHolder']['uniqueCallbackIdentifier']),_0x313c5e[co]=$i,this['transportSessionId']&&(_0x313c5e[lo]=this['transportSessionId']),this['lastSessionId']&&(_0x313c5e[po]=this['lastSessionId']),this['applicationId']&&(_0x313c5e[_o]=this['applicationId']),this['appCheckToken']&&(_0x313c5e[vi]=this['appCheckToken']),typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x313c5e[ho]=uo);const _0x5a4797=this['urlFn'](_0x313c5e);this['log_']('Connecting\x20via\x20long-poll\x20to\x20'+_0x5a4797),this['scriptTagHolder']['addTag'](_0x5a4797,()=>{});});}['start'](){this['scriptTagHolder']['startLongPoll'](this['id'],this['password']),this['addDisconnectPingFrame'](this['id'],this['password']);}static['forceAllow'](){je['forceAllow_']=!0x0;}static['forceDisallow'](){je['forceDisallow_']=!0x0;}static['isAvailable'](){return je['forceAllow_']?!0x0:!je['forceDisallow_']&&typeof document<'u'&&document['createElement']!=null&&!zl()&&!jl();}['markConnectionHealthy'](){}['shutdown_'](){this['isClosed_']=!0x0,this['scriptTagHolder']&&(this['scriptTagHolder']['close'](),this['scriptTagHolder']=null),this['myDisconnFrame']&&(document['body']['removeChild'](this['myDisconnFrame']),this['myDisconnFrame']=null),this['connectTimeoutTimer_']&&(clearTimeout(this['connectTimeoutTimer_']),this['connectTimeoutTimer_']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect_']&&(this['onDisconnect_'](this['everConnected_']),this['onDisconnect_']=null));}['close'](){this['isClosed_']||(this['log_']('Longpoll\x20is\x20being\x20closed.'),this['shutdown_']());}['send'](_0x3efc10){const _0x2b46fa=O(_0x3efc10);this['bytesSent']+=_0x2b46fa['length'],this['stats_']['incrementCounter']('bytes_sent',_0x2b46fa['length']);const _0x539de5=Hr(_0x2b46fa),_0xc710bc=oo(_0x539de5,fh);for(let _0x18e33d=0x0;_0x18e33d<_0xc710bc['length'];_0x18e33d++)this['scriptTagHolder']['enqueueSegment'](this['curSegmentNum'],_0xc710bc['length'],_0xc710bc[_0x18e33d]),this['curSegmentNum']++;}['addDisconnectPingFrame'](_0x56447,_0x388ca0){this['myDisconnFrame']=document['createElement']('iframe');const _0x2898c7={};_0x2898c7[dh]='t',_0x2898c7[Eo]=_0x56447,_0x2898c7[Io]=_0x388ca0,this['myDisconnFrame']['src']=this['urlFn'](_0x2898c7),this['myDisconnFrame']['style']['display']='none',document['body']['appendChild'](this['myDisconnFrame']);}['incrementIncomingBytes_'](_0xbdf103){const _0x5c8b38=O(_0xbdf103)['length'];this['bytesReceived']+=_0x5c8b38,this['stats_']['incrementCounter']('bytes_received',_0x5c8b38);}}class qi{constructor(_0x27bda8,_0x20464c,_0x3790df,_0x50c0c8){this['onDisconnect']=_0x3790df,this['urlFn']=_0x50c0c8,this['outstandingRequests']=new Set(),this['pendingSegs']=[],this['currentSerial']=Math['floor'](Math['random']()*0x5f5e100),this['sendNewPolls']=!0x0;{this['uniqueCallbackIdentifier']=so(),window[oh+this['uniqueCallbackIdentifier']]=_0x27bda8,window[ah+this['uniqueCallbackIdentifier']]=_0x20464c,this['myIFrame']=qi['createIFrame_']();let _0x1fff22='';this['myIFrame']['src']&&this['myIFrame']['src']['substr'](0x0,0xb)==='javascript:'&&(_0x1fff22='<script>document.domain=\x22'+document['domain']+'\x22;</script>');const _0x214e6d='<html><body>'+_0x1fff22+'</body></html>';try{this['myIFrame']['doc']['open'](),this['myIFrame']['doc']['write'](_0x214e6d),this['myIFrame']['doc']['close']();}catch(_0x544fb7){L('frame\x20writing\x20exception'),_0x544fb7['stack']&&L(_0x544fb7['stack']),L(_0x544fb7);}}}static['createIFrame_'](){const _0x4bfb1f=document['createElement']('iframe');if(_0x4bfb1f['style']['display']='none',document['body']){document['body']['appendChild'](_0x4bfb1f);try{_0x4bfb1f['contentWindow']['document']||L('No\x20IE\x20domain\x20setting\x20required');}catch{const _0x2f1eee=document['domain'];_0x4bfb1f['src']='javascript:void((function(){document.open();document.domain=\x27'+_0x2f1eee+'\x27;document.close();})())';}}else throw'Document\x20body\x20has\x20not\x20initialized.\x20Wait\x20to\x20initialize\x20Firebase\x20until\x20after\x20the\x20document\x20is\x20ready.';return _0x4bfb1f['contentDocument']?_0x4bfb1f['doc']=_0x4bfb1f['contentDocument']:_0x4bfb1f['contentWindow']?_0x4bfb1f['doc']=_0x4bfb1f['contentWindow']['document']:_0x4bfb1f['document']&&(_0x4bfb1f['doc']=_0x4bfb1f['document']),_0x4bfb1f;}['close'](){this['alive']=!0x1,this['myIFrame']&&(this['myIFrame']['doc']['body']['textContent']='',setTimeout(()=>{this['myIFrame']!==null&&(document['body']['removeChild'](this['myIFrame']),this['myIFrame']=null);},Math['floor'](0x0)));const _0x517005=this['onDisconnect'];_0x517005&&(this['onDisconnect']=null,_0x517005());}['startLongPoll'](_0x2f1d2d,_0x40ae61){for(this['myID']=_0x2f1d2d,this['myPW']=_0x40ae61,this['alive']=!0x0;this['newRequest_'](););}['newRequest_'](){if(this['alive']&&this['sendNewPolls']&&this['outstandingRequests']['size']<(this['pendingSegs']['length']>0x0?0x2:0x1)){this['currentSerial']++;const _0xc82e24={};_0xc82e24[Eo]=this['myID'],_0xc82e24[Io]=this['myPW'],_0xc82e24[wo]=this['currentSerial'];let _0x1f9ffe=this['urlFn'](_0xc82e24),_0xd8d749='',_0x366bb3=0x0;for(;this['pendingSegs']['length']>0x0&&this['pendingSegs'][0x0]['d']['length']+To+_0xd8d749['length']<=Co;){const _0x2f1b54=this['pendingSegs']['shift']();_0xd8d749=_0xd8d749+'&'+lh+_0x366bb3+'='+_0x2f1b54['seg']+'&'+hh+_0x366bb3+'='+_0x2f1b54['ts']+'&'+uh+_0x366bb3+'='+_0x2f1b54['d'],_0x366bb3++;}return _0x1f9ffe=_0x1f9ffe+_0xd8d749,this['addLongPollTag_'](_0x1f9ffe,this['currentSerial']),!0x0;}else return!0x1;}['enqueueSegment'](_0x14b569,_0x3b085c,_0x27164c){this['pendingSegs']['push']({'seg':_0x14b569,'ts':_0x3b085c,'d':_0x27164c}),this['alive']&&this['newRequest_']();}['addLongPollTag_'](_0x34bb71,_0x123720){this['outstandingRequests']['add'](_0x123720);const _0x46af4f=()=>{this['outstandingRequests']['delete'](_0x123720),this['newRequest_']();},_0x4d28f4=setTimeout(_0x46af4f,Math['floor'](ph)),_0x35d606=()=>{clearTimeout(_0x4d28f4),_0x46af4f();};this['addTag'](_0x34bb71,_0x35d606);}['addTag'](_0x561496,_0x451a84){setTimeout(()=>{try{if(!this['sendNewPolls'])return;const _0x3f31ed=this['myIFrame']['doc']['createElement']('script');_0x3f31ed['type']='text/javascript',_0x3f31ed['async']=!0x0,_0x3f31ed['src']=_0x561496,_0x3f31ed['onload']=_0x3f31ed['onreadystatechange']=function(){const _0x155307=_0x3f31ed['readyState'];(!_0x155307||_0x155307==='loaded'||_0x155307==='complete')&&(_0x3f31ed['onload']=_0x3f31ed['onreadystatechange']=null,_0x3f31ed['parentNode']&&_0x3f31ed['parentNode']['removeChild'](_0x3f31ed),_0x451a84());},_0x3f31ed['onerror']=()=>{L('Long-poll\x20script\x20failed\x20to\x20load:\x20'+_0x561496),this['sendNewPolls']=!0x1,this['close']();},this['myIFrame']['doc']['body']['appendChild'](_0x3f31ed);}catch{}},Math['floor'](0x1));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gh=0x4000,mh=0xafc8;let un=null;typeof MozWebSocket<'u'?un=MozWebSocket:typeof WebSocket<'u'&&(un=WebSocket);class z{constructor(_0x16a1ea,_0x1dacad,_0x2ad637,_0x3263c6,_0x397948,_0x2d2f05,_0x40f54a){this['connId']=_0x16a1ea,this['applicationId']=_0x2ad637,this['appCheckToken']=_0x3263c6,this['authToken']=_0x397948,this['keepaliveTimer']=null,this['frames']=null,this['totalFrames']=0x0,this['bytesSent']=0x0,this['bytesReceived']=0x0,this['log_']=Ht(this['connId']),this['stats_']=Gi(_0x1dacad),this['connURL']=z['connectionURL_'](_0x1dacad,_0x2d2f05,_0x40f54a,_0x3263c6,_0x2ad637),this['nodeAdmin']=_0x1dacad['nodeAdmin'];}static['connectionURL_'](_0x5dbbac,_0x47d54e,_0x36e834,_0x17d1a4,_0xee8073){const _0x56108a={};return _0x56108a[co]=$i,typeof location<'u'&&location['hostname']&&fo['test'](location['hostname'])&&(_0x56108a[ho]=uo),_0x47d54e&&(_0x56108a[lo]=_0x47d54e),_0x36e834&&(_0x56108a[po]=_0x36e834),_0x17d1a4&&(_0x56108a[vi]=_0x17d1a4),_0xee8073&&(_0x56108a[_o]=_0xee8073),vo(_0x5dbbac,go,_0x56108a);}['open'](_0x35bf1f,_0x5d085e){this['onDisconnect']=_0x5d085e,this['onMessage']=_0x35bf1f,this['log_']('Websocket\x20connecting\x20to\x20'+this['connURL']),this['everConnected_']=!0x1,Oe['set']('previous_websocket_failure',!0x0);try{let _0x252ed6;_c(),this['mySock']=new un(this['connURL'],[],_0x252ed6);}catch(_0x5076f2){this['log_']('Error\x20instantiating\x20WebSocket.');const _0x59ae49=_0x5076f2['message']||_0x5076f2['data'];_0x59ae49&&this['log_'](_0x59ae49),this['onClosed_']();return;}this['mySock']['onopen']=()=>{this['log_']('Websocket\x20connected.'),this['everConnected_']=!0x0;},this['mySock']['onclose']=()=>{this['log_']('Websocket\x20connection\x20was\x20disconnected.'),this['mySock']=null,this['onClosed_']();},this['mySock']['onmessage']=_0x549565=>{this['handleIncomingFrame'](_0x549565);},this['mySock']['onerror']=_0x597107=>{this['log_']('WebSocket\x20error.\x20\x20Closing\x20connection.');const _0x1abf86=_0x597107['message']||_0x597107['data'];_0x1abf86&&this['log_'](_0x1abf86),this['onClosed_']();};}['start'](){}static['forceDisallow'](){z['forceDisallow_']=!0x0;}static['isAvailable'](){let _0xfd294e=!0x1;if(typeof navigator<'u'&&navigator['userAgent']){const _0x485dba=/Android ([0-9]{0,}\.[0-9]{0,})/,_0x1d14dd=navigator['userAgent']['match'](_0x485dba);_0x1d14dd&&_0x1d14dd['length']>0x1&&parseFloat(_0x1d14dd[0x1])<4.4&&(_0xfd294e=!0x0);}return!_0xfd294e&&un!==null&&!z['forceDisallow_'];}static['previouslyFailed'](){return Oe['isInMemoryStorage']||Oe['get']('previous_websocket_failure')===!0x0;}['markConnectionHealthy'](){Oe['remove']('previous_websocket_failure');}['appendFrame_'](_0x387636){if(this['frames']['push'](_0x387636),this['frames']['length']===this['totalFrames']){const _0xee1861=this['frames']['join']('');this['frames']=null;const _0x5cbef2=At(_0xee1861);this['onMessage'](_0x5cbef2);}}['handleNewFrameCount_'](_0x510980){this['totalFrames']=_0x510980,this['frames']=[];}['extractFrameCount_'](_0x1b9c80){if(f(this['frames']===null,'We\x20already\x20have\x20a\x20frame\x20buffer'),_0x1b9c80['length']<=0x6){const _0x4bedac=Number(_0x1b9c80);if(!isNaN(_0x4bedac))return this['handleNewFrameCount_'](_0x4bedac),null;}return this['handleNewFrameCount_'](0x1),_0x1b9c80;}['handleIncomingFrame'](_0x5617f0){if(this['mySock']===null)return;const _0x3c9965=_0x5617f0['data'];if(this['bytesReceived']+=_0x3c9965['length'],this['stats_']['incrementCounter']('bytes_received',_0x3c9965['length']),this['resetKeepAlive'](),this['frames']!==null)this['appendFrame_'](_0x3c9965);else{const _0x4d8672=this['extractFrameCount_'](_0x3c9965);_0x4d8672!==null&&this['appendFrame_'](_0x4d8672);}}['send'](_0x513c1d){this['resetKeepAlive']();const _0x22d4e7=O(_0x513c1d);this['bytesSent']+=_0x22d4e7['length'],this['stats_']['incrementCounter']('bytes_sent',_0x22d4e7['length']);const _0x2078a4=oo(_0x22d4e7,gh);_0x2078a4['length']>0x1&&this['sendString_'](String(_0x2078a4['length']));for(let _0x1c2cef=0x0;_0x1c2cef<_0x2078a4['length'];_0x1c2cef++)this['sendString_'](_0x2078a4[_0x1c2cef]);}['shutdown_'](){this['isClosed_']=!0x0,this['keepaliveTimer']&&(clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=null),this['mySock']&&(this['mySock']['close'](),this['mySock']=null);}['onClosed_'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20closing\x20itself'),this['shutdown_'](),this['onDisconnect']&&(this['onDisconnect'](this['everConnected_']),this['onDisconnect']=null));}['close'](){this['isClosed_']||(this['log_']('WebSocket\x20is\x20being\x20closed'),this['shutdown_']());}['resetKeepAlive'](){clearInterval(this['keepaliveTimer']),this['keepaliveTimer']=setInterval(()=>{this['mySock']&&this['sendString_']('0'),this['resetKeepAlive']();},Math['floor'](mh));}['sendString_'](_0x29c8ff){try{this['mySock']['send'](_0x29c8ff);}catch(_0x537014){this['log_']('Exception\x20thrown\x20from\x20WebSocket.send():',_0x537014['message']||_0x537014['data'],'Closing\x20connection.'),setTimeout(this['onClosed_']['bind'](this),0x0);}}}z['responsesRequiredToBeHealthy']=0x2,z['healthyTimeout']=0x7530;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Nt{static get['ALL_TRANSPORTS'](){return[je,z];}static get['IS_TRANSPORT_INITIALIZED'](){return this['globalTransportInitialized_'];}constructor(_0x5a9560){this['initTransports_'](_0x5a9560);}['initTransports_'](_0x4d9678){const _0x675e13=z&&z['isAvailable']();let _0x5ab47a=_0x675e13&&!z['previouslyFailed']();if(_0x4d9678['webSocketOnly']&&(_0x675e13||U('wss://\x20URL\x20used,\x20but\x20browser\x20isn\x27t\x20known\x20to\x20support\x20websockets.\x20\x20Trying\x20anyway.'),_0x5ab47a=!0x0),_0x5ab47a)this['transports_']=[z];else{const _0x647a0=this['transports_']=[];for(const _0x1660b8 of Nt['ALL_TRANSPORTS'])_0x1660b8&&_0x1660b8['isAvailable']()&&_0x647a0['push'](_0x1660b8);Nt['globalTransportInitialized_']=!0x0;}}['initialTransport'](){if(this['transports_']['length']>0x0)return this['transports_'][0x0];throw new Error('No\x20transports\x20available');}['upgradeTransport'](){return this['transports_']['length']>0x1?this['transports_'][0x1]:null;}}Nt['globalTransportInitialized_']=!0x1;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const yh=0xea60,vh=0x1388,Eh=0xa*0x400,Ih=0x64*0x400,si='t',js='d',wh='s',Ks='r',Ch='e',Ys='o',Qs='a',Js='n',Xs='p',Th='h';class Sh{constructor(_0x562c04,_0x9ad2c7,_0x1475f2,_0x2b43e0,_0x58b714,_0x5b22fa,_0x11d9a4,_0x4a5a57,_0x137a96,_0x4870b0){this['id']=_0x562c04,this['repoInfo_']=_0x9ad2c7,this['applicationId_']=_0x1475f2,this['appCheckToken_']=_0x2b43e0,this['authToken_']=_0x58b714,this['onMessage_']=_0x5b22fa,this['onReady_']=_0x11d9a4,this['onDisconnect_']=_0x4a5a57,this['onKill_']=_0x137a96,this['lastSessionId']=_0x4870b0,this['connectionCount']=0x0,this['pendingDataMessages']=[],this['state_']=0x0,this['log_']=Ht('c:'+this['id']+':'),this['transportManager_']=new Nt(_0x9ad2c7),this['log_']('Connection\x20created'),this['start_']();}['start_'](){const _0x328944=this['transportManager_']['initialTransport']();this['conn_']=new _0x328944(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],null,this['lastSessionId']),this['primaryResponsesRequired_']=_0x328944['responsesRequiredToBeHealthy']||0x0;const _0x2f5f87=this['connReceiver_'](this['conn_']),_0x2a375d=this['disconnReceiver_'](this['conn_']);this['tx_']=this['conn_'],this['rx_']=this['conn_'],this['secondaryConn_']=null,this['isHealthy_']=!0x1,setTimeout(()=>{this['conn_']&&this['conn_']['open'](_0x2f5f87,_0x2a375d);},Math['floor'](0x0));const _0x279f68=_0x328944['healthyTimeout']||0x0;_0x279f68>0x0&&(this['healthyTimeout_']=Ct(()=>{this['healthyTimeout_']=null,this['isHealthy_']||(this['conn_']&&this['conn_']['bytesReceived']>Ih?(this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20received\x20'+this['conn_']['bytesReceived']+'\x20bytes.\x20\x20Marking\x20connection\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()):this['conn_']&&this['conn_']['bytesSent']>Eh?this['log_']('Connection\x20exceeded\x20healthy\x20timeout\x20but\x20has\x20sent\x20'+this['conn_']['bytesSent']+'\x20bytes.\x20\x20Leaving\x20connection\x20alive.'):(this['log_']('Closing\x20unhealthy\x20connection\x20after\x20timeout.'),this['close']()));},Math['floor'](_0x279f68)));}['nextTransportId_'](){return'c:'+this['id']+':'+this['connectionCount']++;}['disconnReceiver_'](_0x686f27){return _0x1b4893=>{_0x686f27===this['conn_']?this['onConnectionLost_'](_0x1b4893):_0x686f27===this['secondaryConn_']?(this['log_']('Secondary\x20connection\x20lost.'),this['onSecondaryConnectionLost_']()):this['log_']('closing\x20an\x20old\x20connection');};}['connReceiver_'](_0x201874){return _0x5a477f=>{this['state_']!==0x2&&(_0x201874===this['rx_']?this['onPrimaryMessageReceived_'](_0x5a477f):_0x201874===this['secondaryConn_']?this['onSecondaryMessageReceived_'](_0x5a477f):this['log_']('message\x20on\x20old\x20connection'));};}['sendRequest'](_0x54e71c){const _0x2175fe={'t':'d','d':_0x54e71c};this['sendData_'](_0x2175fe);}['tryCleanupConnection'](){this['tx_']===this['secondaryConn_']&&this['rx_']===this['secondaryConn_']&&(this['log_']('cleaning\x20up\x20and\x20promoting\x20a\x20connection:\x20'+this['secondaryConn_']['connId']),this['conn_']=this['secondaryConn_'],this['secondaryConn_']=null);}['onSecondaryControl_'](_0x1d6d5d){if(si in _0x1d6d5d){const _0x359bc2=_0x1d6d5d[si];_0x359bc2===Qs?this['upgradeIfSecondaryHealthy_']():_0x359bc2===Ks?(this['log_']('Got\x20a\x20reset\x20on\x20secondary,\x20closing\x20it'),this['secondaryConn_']['close'](),(this['tx_']===this['secondaryConn_']||this['rx_']===this['secondaryConn_'])&&this['close']()):_0x359bc2===Ys&&(this['log_']('got\x20pong\x20on\x20secondary.'),this['secondaryResponsesRequired_']--,this['upgradeIfSecondaryHealthy_']());}}['onSecondaryMessageReceived_'](_0xf0671a){const _0x14ec86=_t('t',_0xf0671a),_0x587d23=_t('d',_0xf0671a);if(_0x14ec86==='c')this['onSecondaryControl_'](_0x587d23);else{if(_0x14ec86==='d')this['pendingDataMessages']['push'](_0x587d23);else throw new Error('Unknown\x20protocol\x20layer:\x20'+_0x14ec86);}}['upgradeIfSecondaryHealthy_'](){this['secondaryResponsesRequired_']<=0x0?(this['log_']('Secondary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['secondaryConn_']['markConnectionHealthy'](),this['proceedWithUpgrade_']()):(this['log_']('sending\x20ping\x20on\x20secondary.'),this['secondaryConn_']['send']({'t':'c','d':{'t':Xs,'d':{}}}));}['proceedWithUpgrade_'](){this['secondaryConn_']['start'](),this['log_']('sending\x20client\x20ack\x20on\x20secondary'),this['secondaryConn_']['send']({'t':'c','d':{'t':Qs,'d':{}}}),this['log_']('Ending\x20transmission\x20on\x20primary'),this['conn_']['send']({'t':'c','d':{'t':Js,'d':{}}}),this['tx_']=this['secondaryConn_'],this['tryCleanupConnection']();}['onPrimaryMessageReceived_'](_0x14cdff){const _0x62059c=_t('t',_0x14cdff),_0x4374e4=_t('d',_0x14cdff);_0x62059c==='c'?this['onControl_'](_0x4374e4):_0x62059c==='d'&&this['onDataMessage_'](_0x4374e4);}['onDataMessage_'](_0x5dcbe3){this['onPrimaryResponse_'](),this['onMessage_'](_0x5dcbe3);}['onPrimaryResponse_'](){this['isHealthy_']||(this['primaryResponsesRequired_']--,this['primaryResponsesRequired_']<=0x0&&(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0,this['conn_']['markConnectionHealthy']()));}['onControl_'](_0xf91fe8){const _0x4102c4=_t(si,_0xf91fe8);if(js in _0xf91fe8){const _0x147795=_0xf91fe8[js];if(_0x4102c4===Th){const _0x368048={..._0x147795};this['repoInfo_']['isUsingEmulator']&&(_0x368048['h']=this['repoInfo_']['host']),this['onHandshake_'](_0x368048);}else{if(_0x4102c4===Js){this['log_']('recvd\x20end\x20transmission\x20on\x20primary'),this['rx_']=this['secondaryConn_'];for(let _0x538ad1=0x0;_0x538ad1<this['pendingDataMessages']['length'];++_0x538ad1)this['onDataMessage_'](this['pendingDataMessages'][_0x538ad1]);this['pendingDataMessages']=[],this['tryCleanupConnection']();}else _0x4102c4===wh?this['onConnectionShutdown_'](_0x147795):_0x4102c4===Ks?this['onReset_'](_0x147795):_0x4102c4===Ch?yi('Server\x20Error:\x20'+_0x147795):_0x4102c4===Ys?(this['log_']('got\x20pong\x20on\x20primary.'),this['onPrimaryResponse_'](),this['sendPingOnPrimaryIfNecessary_']()):yi('Unknown\x20control\x20packet\x20command:\x20'+_0x4102c4);}}}['onHandshake_'](_0x9785b7){const _0x4dbb04=_0x9785b7['ts'],_0x157d1b=_0x9785b7['v'],_0x4086b0=_0x9785b7['h'];this['sessionId']=_0x9785b7['s'],this['repoInfo_']['host']=_0x4086b0,this['state_']===0x0&&(this['conn_']['start'](),this['onConnectionEstablished_'](this['conn_'],_0x4dbb04),$i!==_0x157d1b&&U('Protocol\x20version\x20mismatch\x20detected'),this['tryStartUpgrade_']());}['tryStartUpgrade_'](){const _0x239451=this['transportManager_']['upgradeTransport']();_0x239451&&this['startUpgrade_'](_0x239451);}['startUpgrade_'](_0x6864da){this['secondaryConn_']=new _0x6864da(this['nextTransportId_'](),this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],this['sessionId']),this['secondaryResponsesRequired_']=_0x6864da['responsesRequiredToBeHealthy']||0x0;const _0x6ccc9a=this['connReceiver_'](this['secondaryConn_']),_0x43ee90=this['disconnReceiver_'](this['secondaryConn_']);this['secondaryConn_']['open'](_0x6ccc9a,_0x43ee90),Ct(()=>{this['secondaryConn_']&&(this['log_']('Timed\x20out\x20trying\x20to\x20upgrade.'),this['secondaryConn_']['close']());},Math['floor'](yh));}['onReset_'](_0x5f13a4){this['log_']('Reset\x20packet\x20received.\x20\x20New\x20host:\x20'+_0x5f13a4),this['repoInfo_']['host']=_0x5f13a4,this['state_']===0x1?this['close']():(this['closeConnections_'](),this['start_']());}['onConnectionEstablished_'](_0x4e6f0d,_0x17e417){this['log_']('Realtime\x20connection\x20established.'),this['conn_']=_0x4e6f0d,this['state_']=0x1,this['onReady_']&&(this['onReady_'](_0x17e417,this['sessionId']),this['onReady_']=null),this['primaryResponsesRequired_']===0x0?(this['log_']('Primary\x20connection\x20is\x20healthy.'),this['isHealthy_']=!0x0):Ct(()=>{this['sendPingOnPrimaryIfNecessary_']();},Math['floor'](vh));}['sendPingOnPrimaryIfNecessary_'](){!this['isHealthy_']&&this['state_']===0x1&&(this['log_']('sending\x20ping\x20on\x20primary.'),this['sendData_']({'t':'c','d':{'t':Xs,'d':{}}}));}['onSecondaryConnectionLost_'](){const _0x3ffc22=this['secondaryConn_'];this['secondaryConn_']=null,(this['tx_']===_0x3ffc22||this['rx_']===_0x3ffc22)&&this['close']();}['onConnectionLost_'](_0x24aa04){this['conn_']=null,!_0x24aa04&&this['state_']===0x0?(this['log_']('Realtime\x20connection\x20failed.'),this['repoInfo_']['isCacheableHost']()&&(Oe['remove']('host:'+this['repoInfo_']['host']),this['repoInfo_']['internalHost']=this['repoInfo_']['host'])):this['state_']===0x1&&this['log_']('Realtime\x20connection\x20lost.'),this['close']();}['onConnectionShutdown_'](_0x17fe82){this['log_']('Connection\x20shutdown\x20command\x20received.\x20Shutting\x20down...'),this['onKill_']&&(this['onKill_'](_0x17fe82),this['onKill_']=null),this['onDisconnect_']=null,this['close']();}['sendData_'](_0x1da2c8){if(this['state_']!==0x1)throw'Connection\x20is\x20not\x20connected';this['tx_']['send'](_0x1da2c8);}['close'](){this['state_']!==0x2&&(this['log_']('Closing\x20realtime\x20connection.'),this['state_']=0x2,this['closeConnections_'](),this['onDisconnect_']&&(this['onDisconnect_'](),this['onDisconnect_']=null));}['closeConnections_'](){this['log_']('Shutting\x20down\x20all\x20connections'),this['conn_']&&(this['conn_']['close'](),this['conn_']=null),this['secondaryConn_']&&(this['secondaryConn_']['close'](),this['secondaryConn_']=null),this['healthyTimeout_']&&(clearTimeout(this['healthyTimeout_']),this['healthyTimeout_']=null);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class So{['put'](_0x1e7b08,_0x445048,_0x19bfd4,_0x3835ab){}['merge'](_0x51c022,_0x5aab86,_0x3a9a6a,_0x18af79){}['refreshAuthToken'](_0x4b44e6){}['refreshAppCheckToken'](_0x4192bc){}['onDisconnectPut'](_0x42b4b2,_0x31fb30,_0x326c0e){}['onDisconnectMerge'](_0x2195a4,_0x2cb4a5,_0x1cb504){}['onDisconnectCancel'](_0x506866,_0x54f1a3){}['reportStats'](_0x57a458){}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bo{constructor(_0x5e9f2e){this['allowedEvents_']=_0x5e9f2e,this['listeners_']={},f(Array['isArray'](_0x5e9f2e)&&_0x5e9f2e['length']>0x0,'Requires\x20a\x20non-empty\x20array');}['trigger'](_0x35c85d,..._0x4cc515){if(Array['isArray'](this['listeners_'][_0x35c85d])){const _0xaee721=[...this['listeners_'][_0x35c85d]];for(let _0x40c1a4=0x0;_0x40c1a4<_0xaee721['length'];_0x40c1a4++)_0xaee721[_0x40c1a4]['callback']['apply'](_0xaee721[_0x40c1a4]['context'],_0x4cc515);}}['on'](_0x3467d0,_0x4834e5,_0x532f7c){this['validateEventType_'](_0x3467d0),this['listeners_'][_0x3467d0]=this['listeners_'][_0x3467d0]||[],this['listeners_'][_0x3467d0]['push']({'callback':_0x4834e5,'context':_0x532f7c});const _0x32d671=this['getInitialEvent'](_0x3467d0);_0x32d671&&_0x4834e5['apply'](_0x532f7c,_0x32d671);}['off'](_0x2f2d5d,_0x5b8a3c,_0x182de7){this['validateEventType_'](_0x2f2d5d);const _0x101c59=this['listeners_'][_0x2f2d5d]||[];for(let _0x5b1dbc=0x0;_0x5b1dbc<_0x101c59['length'];_0x5b1dbc++)if(_0x101c59[_0x5b1dbc]['callback']===_0x5b8a3c&&(!_0x182de7||_0x182de7===_0x101c59[_0x5b1dbc]['context'])){_0x101c59['splice'](_0x5b1dbc,0x1);return;}}['validateEventType_'](_0x35805b){f(this['allowedEvents_']['find'](_0x4cb0c3=>_0x4cb0c3===_0x35805b),'Unknown\x20event:\x20'+_0x35805b);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class dn extends bo{static['getInstance'](){return new dn();}constructor(){super(['online']),this['online_']=!0x0,typeof window<'u'&&typeof window['addEventListener']<'u'&&!Fi()&&(window['addEventListener']('online',()=>{this['online_']||(this['online_']=!0x0,this['trigger']('online',!0x0));},!0x1),window['addEventListener']('offline',()=>{this['online_']&&(this['online_']=!0x1,this['trigger']('online',!0x1));},!0x1));}['getInitialEvent'](_0x244949){return f(_0x244949==='online','Unknown\x20event\x20type:\x20'+_0x244949),[this['online_']];}['currentlyOnline'](){return this['online_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Zs=0x20,er=0x300;class C{constructor(_0x2b4cfe,_0x29dcc0){if(_0x29dcc0===void 0x0){this['pieces_']=_0x2b4cfe['split']('/');let _0x1a5507=0x0;for(let _0x537be9=0x0;_0x537be9<this['pieces_']['length'];_0x537be9++)this['pieces_'][_0x537be9]['length']>0x0&&(this['pieces_'][_0x1a5507]=this['pieces_'][_0x537be9],_0x1a5507++);this['pieces_']['length']=_0x1a5507,this['pieceNum_']=0x0;}else this['pieces_']=_0x2b4cfe,this['pieceNum_']=_0x29dcc0;}['toString'](){let _0x4bf273='';for(let _0x30ac01=this['pieceNum_'];_0x30ac01<this['pieces_']['length'];_0x30ac01++)this['pieces_'][_0x30ac01]!==''&&(_0x4bf273+='/'+this['pieces_'][_0x30ac01]);return _0x4bf273||'/';}}function w(){return new C('');}function y(_0x45a36f){return _0x45a36f['pieceNum_']>=_0x45a36f['pieces_']['length']?null:_0x45a36f['pieces_'][_0x45a36f['pieceNum_']];}function we(_0x2993b8){return _0x2993b8['pieces_']['length']-_0x2993b8['pieceNum_'];}function b(_0x11e362){let _0x53074b=_0x11e362['pieceNum_'];return _0x53074b<_0x11e362['pieces_']['length']&&_0x53074b++,new C(_0x11e362['pieces_'],_0x53074b);}function zi(_0x524d54){return _0x524d54['pieceNum_']<_0x524d54['pieces_']['length']?_0x524d54['pieces_'][_0x524d54['pieces_']['length']-0x1]:null;}function bh(_0x200392){let _0x3a592e='';for(let _0x5d860d=_0x200392['pieceNum_'];_0x5d860d<_0x200392['pieces_']['length'];_0x5d860d++)_0x200392['pieces_'][_0x5d860d]!==''&&(_0x3a592e+='/'+encodeURIComponent(String(_0x200392['pieces_'][_0x5d860d])));return _0x3a592e||'/';}function Pt(_0x46981c,_0x27d21d=0x0){return _0x46981c['pieces_']['slice'](_0x46981c['pieceNum_']+_0x27d21d);}function Ro(_0x15fbf2){if(_0x15fbf2['pieceNum_']>=_0x15fbf2['pieces_']['length'])return null;const _0x5f3668=[];for(let _0x4282ad=_0x15fbf2['pieceNum_'];_0x4282ad<_0x15fbf2['pieces_']['length']-0x1;_0x4282ad++)_0x5f3668['push'](_0x15fbf2['pieces_'][_0x4282ad]);return new C(_0x5f3668,0x0);}function k(_0x3f1ee8,_0x43bf45){const _0x3874c2=[];for(let _0x482dc1=_0x3f1ee8['pieceNum_'];_0x482dc1<_0x3f1ee8['pieces_']['length'];_0x482dc1++)_0x3874c2['push'](_0x3f1ee8['pieces_'][_0x482dc1]);if(_0x43bf45 instanceof C){for(let _0x16160a=_0x43bf45['pieceNum_'];_0x16160a<_0x43bf45['pieces_']['length'];_0x16160a++)_0x3874c2['push'](_0x43bf45['pieces_'][_0x16160a]);}else{const _0x165baf=_0x43bf45['split']('/');for(let _0x24752b=0x0;_0x24752b<_0x165baf['length'];_0x24752b++)_0x165baf[_0x24752b]['length']>0x0&&_0x3874c2['push'](_0x165baf[_0x24752b]);}return new C(_0x3874c2,0x0);}function v(_0x6f0574){return _0x6f0574['pieceNum_']>=_0x6f0574['pieces_']['length'];}function F(_0x566dfe,_0x496e95){const _0x424b27=y(_0x566dfe),_0x43aaf8=y(_0x496e95);if(_0x424b27===null)return _0x496e95;if(_0x424b27===_0x43aaf8)return F(b(_0x566dfe),b(_0x496e95));throw new Error('INTERNAL\x20ERROR:\x20innerPath\x20('+_0x496e95+')\x20is\x20not\x20within\x20outerPath\x20('+_0x566dfe+')');}function Rh(_0x190038,_0x2a1887){const _0x4a639e=Pt(_0x190038,0x0),_0x2ad36a=Pt(_0x2a1887,0x0);for(let _0x56c9eb=0x0;_0x56c9eb<_0x4a639e['length']&&_0x56c9eb<_0x2ad36a['length'];_0x56c9eb++){const _0x26d61f=He(_0x4a639e[_0x56c9eb],_0x2ad36a[_0x56c9eb]);if(_0x26d61f!==0x0)return _0x26d61f;}return _0x4a639e['length']===_0x2ad36a['length']?0x0:_0x4a639e['length']<_0x2ad36a['length']?-0x1:0x1;}function ji(_0x407b4e,_0x265264){if(we(_0x407b4e)!==we(_0x265264))return!0x1;for(let _0x54a528=_0x407b4e['pieceNum_'],_0x4fe9b1=_0x265264['pieceNum_'];_0x54a528<=_0x407b4e['pieces_']['length'];_0x54a528++,_0x4fe9b1++)if(_0x407b4e['pieces_'][_0x54a528]!==_0x265264['pieces_'][_0x4fe9b1])return!0x1;return!0x0;}function G(_0x257b8d,_0x3b1a86){let _0x3fcc68=_0x257b8d['pieceNum_'],_0x46c574=_0x3b1a86['pieceNum_'];if(we(_0x257b8d)>we(_0x3b1a86))return!0x1;for(;_0x3fcc68<_0x257b8d['pieces_']['length'];){if(_0x257b8d['pieces_'][_0x3fcc68]!==_0x3b1a86['pieces_'][_0x46c574])return!0x1;++_0x3fcc68,++_0x46c574;}return!0x0;}class Ah{constructor(_0x1642ec,_0x361d20){this['errorPrefix_']=_0x361d20,this['parts_']=Pt(_0x1642ec,0x0),this['byteLength_']=Math['max'](0x1,this['parts_']['length']);for(let _0x5b1327=0x0;_0x5b1327<this['parts_']['length'];_0x5b1327++)this['byteLength_']+=On(this['parts_'][_0x5b1327]);Ao(this);}}function kh(_0x20dc7b,_0x46231e){_0x20dc7b['parts_']['length']>0x0&&(_0x20dc7b['byteLength_']+=0x1),_0x20dc7b['parts_']['push'](_0x46231e),_0x20dc7b['byteLength_']+=On(_0x46231e),Ao(_0x20dc7b);}function Nh(_0x4c7e4b){const _0x4eba39=_0x4c7e4b['parts_']['pop']();_0x4c7e4b['byteLength_']-=On(_0x4eba39),_0x4c7e4b['parts_']['length']>0x0&&(_0x4c7e4b['byteLength_']-=0x1);}function Ao(_0x212356){if(_0x212356['byteLength_']>er)throw new Error(_0x212356['errorPrefix_']+'has\x20a\x20key\x20path\x20longer\x20than\x20'+er+'\x20bytes\x20('+_0x212356['byteLength_']+').');if(_0x212356['parts_']['length']>Zs)throw new Error(_0x212356['errorPrefix_']+'path\x20specified\x20exceeds\x20the\x20maximum\x20depth\x20that\x20can\x20be\x20written\x20('+Zs+')\x20or\x20object\x20contains\x20a\x20cycle\x20'+Pe(_0x212356));}function Pe(_0x4845ff){return _0x4845ff['parts_']['length']===0x0?'':'in\x20property\x20\x27'+_0x4845ff['parts_']['join']('.')+'\x27';}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ki extends bo{static['getInstance'](){return new Ki();}constructor(){super(['visible']);let _0x586b3b,_0x53993f;typeof document<'u'&&typeof document['addEventListener']<'u'&&(typeof document['hidden']<'u'?(_0x53993f='visibilitychange',_0x586b3b='hidden'):typeof document['mozHidden']<'u'?(_0x53993f='mozvisibilitychange',_0x586b3b='mozHidden'):typeof document['msHidden']<'u'?(_0x53993f='msvisibilitychange',_0x586b3b='msHidden'):typeof document['webkitHidden']<'u'&&(_0x53993f='webkitvisibilitychange',_0x586b3b='webkitHidden')),this['visible_']=!0x0,_0x53993f&&document['addEventListener'](_0x53993f,()=>{const _0x571d1f=!document[_0x586b3b];_0x571d1f!==this['visible_']&&(this['visible_']=_0x571d1f,this['trigger']('visible',_0x571d1f));},!0x1);}['getInitialEvent'](_0x29f5c1){return f(_0x29f5c1==='visible','Unknown\x20event\x20type:\x20'+_0x29f5c1),[this['visible_']];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const gt=0x3e8,Ph=0x12c*0x3e8,tr=0x1e*0x3e8,Oh=1.3,Dh=0x7530,Mh='server_kill',nr=0x3;class se extends So{constructor(_0x5ad809,_0x5b83f4,_0x4de2db,_0x7036cf,_0x3fd69d,_0xec2dfd,_0x40613e,_0x40a6af){if(super(),this['repoInfo_']=_0x5ad809,this['applicationId_']=_0x5b83f4,this['onDataUpdate_']=_0x4de2db,this['onConnectStatus_']=_0x7036cf,this['onServerInfoUpdate_']=_0x3fd69d,this['authTokenProvider_']=_0xec2dfd,this['appCheckTokenProvider_']=_0x40613e,this['authOverride_']=_0x40a6af,this['id']=se['nextPersistentConnectionId_']++,this['log_']=Ht('p:'+this['id']+':'),this['interruptReasons_']={},this['listens']=new Map(),this['outstandingPuts_']=[],this['outstandingGets_']=[],this['outstandingPutCount_']=0x0,this['outstandingGetCount_']=0x0,this['onDisconnectRequestQueue_']=[],this['connected_']=!0x1,this['reconnectDelay_']=gt,this['maxReconnectDelay_']=Ph,this['securityDebugCallback_']=null,this['lastSessionId']=null,this['establishConnectionTimer_']=null,this['visible_']=!0x1,this['requestCBHash_']={},this['requestNumber_']=0x0,this['realtime_']=null,this['authToken_']=null,this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x1,this['invalidAuthTokenCount_']=0x0,this['invalidAppCheckTokenCount_']=0x0,this['firstConnection_']=!0x0,this['lastConnectionAttemptTime_']=null,this['lastConnectionEstablishedTime_']=null,_0x40a6af)throw new Error('Auth\x20override\x20specified\x20in\x20options,\x20but\x20not\x20supported\x20on\x20non\x20Node.js\x20platforms');Ki['getInstance']()['on']('visible',this['onVisible_'],this),_0x5ad809['host']['indexOf']('fblocal')===-0x1&&dn['getInstance']()['on']('online',this['onOnline_'],this);}['sendRequest'](_0x5a8551,_0x45e9db,_0x17253e){const _0x5cae04=++this['requestNumber_'],_0x56d17c={'r':_0x5cae04,'a':_0x5a8551,'b':_0x45e9db};this['log_'](O(_0x56d17c)),f(this['connected_'],'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),this['realtime_']['sendRequest'](_0x56d17c),_0x17253e&&(this['requestCBHash_'][_0x5cae04]=_0x17253e);}['get'](_0x51dc23){this['initConnection_']();const _0x4cbf0e=new ot(),_0x248100={'action':'g','request':{'p':_0x51dc23['_path']['toString'](),'q':_0x51dc23['_queryObject']},'onComplete':_0x1af4de=>{const _0x2c14a3=_0x1af4de['d'];_0x1af4de['s']==='ok'?_0x4cbf0e['resolve'](_0x2c14a3):_0x4cbf0e['reject'](_0x2c14a3);}};this['outstandingGets_']['push'](_0x248100),this['outstandingGetCount_']++;const _0x3049df=this['outstandingGets_']['length']-0x1;return this['connected_']&&this['sendGet_'](_0x3049df),_0x4cbf0e['promise'];}['listen'](_0xa056f3,_0x5b3aa9,_0x178d96,_0x3b7911){this['initConnection_']();const _0x1d16f7=_0xa056f3['_queryIdentifier'],_0x21f76e=_0xa056f3['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x21f76e+'\x20'+_0x1d16f7),this['listens']['has'](_0x21f76e)||this['listens']['set'](_0x21f76e,new Map()),f(_0xa056f3['_queryParams']['isDefault']()||!_0xa056f3['_queryParams']['loadsAllData'](),'listen()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),f(!this['listens']['get'](_0x21f76e)['has'](_0x1d16f7),'listen()\x20called\x20twice\x20for\x20same\x20path/queryId.');const _0x260218={'onComplete':_0x3b7911,'hashFn':_0x5b3aa9,'query':_0xa056f3,'tag':_0x178d96};this['listens']['get'](_0x21f76e)['set'](_0x1d16f7,_0x260218),this['connected_']&&this['sendListen_'](_0x260218);}['sendGet_'](_0x133917){const _0x13f311=this['outstandingGets_'][_0x133917];this['sendRequest']('g',_0x13f311['request'],_0x22c468=>{delete this['outstandingGets_'][_0x133917],this['outstandingGetCount_']--,this['outstandingGetCount_']===0x0&&(this['outstandingGets_']=[]),_0x13f311['onComplete']&&_0x13f311['onComplete'](_0x22c468);});}['sendListen_'](_0x574465){const _0x27f023=_0x574465['query'],_0x806899=_0x27f023['_path']['toString'](),_0x5bb71f=_0x27f023['_queryIdentifier'];this['log_']('Listen\x20on\x20'+_0x806899+'\x20for\x20'+_0x5bb71f);const _0x235a74={'p':_0x806899},_0x1fad2f='q';_0x574465['tag']&&(_0x235a74['q']=_0x27f023['_queryObject'],_0x235a74['t']=_0x574465['tag']),_0x235a74['h']=_0x574465['hashFn'](),this['sendRequest'](_0x1fad2f,_0x235a74,_0x2bf96c=>{const _0x2351eb=_0x2bf96c['d'],_0xe191f1=_0x2bf96c['s'];se['warnOnListenWarnings_'](_0x2351eb,_0x27f023),(this['listens']['get'](_0x806899)&&this['listens']['get'](_0x806899)['get'](_0x5bb71f))===_0x574465&&(this['log_']('listen\x20response',_0x2bf96c),_0xe191f1!=='ok'&&this['removeListen_'](_0x806899,_0x5bb71f),_0x574465['onComplete']&&_0x574465['onComplete'](_0xe191f1,_0x2351eb));});}static['warnOnListenWarnings_'](_0x5842f6,_0x888b45){if(_0x5842f6&&typeof _0x5842f6=='object'&&J(_0x5842f6,'w')){const _0x14f90b=De(_0x5842f6,'w');if(Array['isArray'](_0x14f90b)&&~_0x14f90b['indexOf']('no_index')){const _0x4fdc34='\x22.indexOn\x22:\x20\x22'+_0x888b45['_queryParams']['getIndex']()['toString']()+'\x22',_0x2340d6=_0x888b45['_path']['toString']();U('Using\x20an\x20unspecified\x20index.\x20Your\x20data\x20will\x20be\x20downloaded\x20and\x20filtered\x20on\x20the\x20client.\x20Consider\x20adding\x20'+_0x4fdc34+'\x20at\x20'+_0x2340d6+'\x20to\x20your\x20security\x20rules\x20for\x20better\x20performance.');}}}['refreshAuthToken'](_0x5f1c78){this['authToken_']=_0x5f1c78,this['log_']('Auth\x20token\x20refreshed'),this['authToken_']?this['tryAuth']():this['connected_']&&this['sendRequest']('unauth',{},()=>{}),this['reduceReconnectDelayIfAdminCredential_'](_0x5f1c78);}['reduceReconnectDelayIfAdminCredential_'](_0x48ab71){(_0x48ab71&&_0x48ab71['length']===0x28||wc(_0x48ab71))&&(this['log_']('Admin\x20auth\x20credential\x20detected.\x20\x20Reducing\x20max\x20reconnect\x20time.'),this['maxReconnectDelay_']=tr);}['refreshAppCheckToken'](_0x5823ad){this['appCheckToken_']=_0x5823ad,this['log_']('App\x20check\x20token\x20refreshed'),this['appCheckToken_']?this['tryAppCheck']():this['connected_']&&this['sendRequest']('unappeck',{},()=>{});}['tryAuth'](){if(this['connected_']&&this['authToken_']){const _0x3f96eb=this['authToken_'],_0x1ca891=Ic(_0x3f96eb)?'auth':'gauth',_0x52b539={'cred':_0x3f96eb};this['authOverride_']===null?_0x52b539['noauth']=!0x0:typeof this['authOverride_']=='object'&&(_0x52b539['authvar']=this['authOverride_']),this['sendRequest'](_0x1ca891,_0x52b539,_0x45b7f9=>{const _0x46aa96=_0x45b7f9['s'],_0xdbb2be=_0x45b7f9['d']||'error';this['authToken_']===_0x3f96eb&&(_0x46aa96==='ok'?this['invalidAuthTokenCount_']=0x0:this['onAuthRevoked_'](_0x46aa96,_0xdbb2be));});}}['tryAppCheck'](){this['connected_']&&this['appCheckToken_']&&this['sendRequest']('appcheck',{'token':this['appCheckToken_']},_0x43d7e0=>{const _0x36a377=_0x43d7e0['s'],_0x560e74=_0x43d7e0['d']||'error';_0x36a377==='ok'?this['invalidAppCheckTokenCount_']=0x0:this['onAppCheckRevoked_'](_0x36a377,_0x560e74);});}['unlisten'](_0x574df7,_0x38f9dd){const _0x345725=_0x574df7['_path']['toString'](),_0x578e5a=_0x574df7['_queryIdentifier'];this['log_']('Unlisten\x20called\x20for\x20'+_0x345725+'\x20'+_0x578e5a),f(_0x574df7['_queryParams']['isDefault']()||!_0x574df7['_queryParams']['loadsAllData'](),'unlisten()\x20called\x20for\x20non-default\x20but\x20complete\x20query'),this['removeListen_'](_0x345725,_0x578e5a)&&this['connected_']&&this['sendUnlisten_'](_0x345725,_0x578e5a,_0x574df7['_queryObject'],_0x38f9dd);}['sendUnlisten_'](_0x1e8ae2,_0x465c79,_0x2b0628,_0x4aaa52){this['log_']('Unlisten\x20on\x20'+_0x1e8ae2+'\x20for\x20'+_0x465c79);const _0x323793={'p':_0x1e8ae2},_0x4c1b29='n';_0x4aaa52&&(_0x323793['q']=_0x2b0628,_0x323793['t']=_0x4aaa52),this['sendRequest'](_0x4c1b29,_0x323793);}['onDisconnectPut'](_0x18ad94,_0x2eb91c,_0x330707){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('o',_0x18ad94,_0x2eb91c,_0x330707):this['onDisconnectRequestQueue_']['push']({'pathString':_0x18ad94,'action':'o','data':_0x2eb91c,'onComplete':_0x330707});}['onDisconnectMerge'](_0x21bed2,_0x122b89,_0x1d582e){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('om',_0x21bed2,_0x122b89,_0x1d582e):this['onDisconnectRequestQueue_']['push']({'pathString':_0x21bed2,'action':'om','data':_0x122b89,'onComplete':_0x1d582e});}['onDisconnectCancel'](_0x5627b8,_0x2669a0){this['initConnection_'](),this['connected_']?this['sendOnDisconnect_']('oc',_0x5627b8,null,_0x2669a0):this['onDisconnectRequestQueue_']['push']({'pathString':_0x5627b8,'action':'oc','data':null,'onComplete':_0x2669a0});}['sendOnDisconnect_'](_0x3be779,_0x3e8e65,_0x27e504,_0x1276c8){const _0x212d26={'p':_0x3e8e65,'d':_0x27e504};this['log_']('onDisconnect\x20'+_0x3be779,_0x212d26),this['sendRequest'](_0x3be779,_0x212d26,_0x2010dc=>{_0x1276c8&&setTimeout(()=>{_0x1276c8(_0x2010dc['s'],_0x2010dc['d']);},Math['floor'](0x0));});}['put'](_0x2109df,_0x328c93,_0x1d1981,_0x34310a){this['putInternal']('p',_0x2109df,_0x328c93,_0x1d1981,_0x34310a);}['merge'](_0x5ab87a,_0x31a041,_0x166c99,_0x22dc55){this['putInternal']('m',_0x5ab87a,_0x31a041,_0x166c99,_0x22dc55);}['putInternal'](_0x4d0fec,_0x2f9c2c,_0x11979c,_0x5af3c0,_0x3a0dbb){this['initConnection_']();const _0x3f8c4f={'p':_0x2f9c2c,'d':_0x11979c};_0x3a0dbb!==void 0x0&&(_0x3f8c4f['h']=_0x3a0dbb),this['outstandingPuts_']['push']({'action':_0x4d0fec,'request':_0x3f8c4f,'onComplete':_0x5af3c0}),this['outstandingPutCount_']++;const _0x47fddd=this['outstandingPuts_']['length']-0x1;this['connected_']?this['sendPut_'](_0x47fddd):this['log_']('Buffering\x20put:\x20'+_0x2f9c2c);}['sendPut_'](_0x150603){const _0x51229a=this['outstandingPuts_'][_0x150603]['action'],_0x3bf8a0=this['outstandingPuts_'][_0x150603]['request'],_0x532500=this['outstandingPuts_'][_0x150603]['onComplete'];this['outstandingPuts_'][_0x150603]['queued']=this['connected_'],this['sendRequest'](_0x51229a,_0x3bf8a0,_0x59c163=>{this['log_'](_0x51229a+'\x20response',_0x59c163),delete this['outstandingPuts_'][_0x150603],this['outstandingPutCount_']--,this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]),_0x532500&&_0x532500(_0x59c163['s'],_0x59c163['d']);});}['reportStats'](_0x6f2bf4){if(this['connected_']){const _0x38cc87={'c':_0x6f2bf4};this['log_']('reportStats',_0x38cc87),this['sendRequest']('s',_0x38cc87,_0x284a6e=>{if(_0x284a6e['s']!=='ok'){const _0x23054e=_0x284a6e['d'];this['log_']('reportStats','Error\x20sending\x20stats:\x20'+_0x23054e);}});}}['onDataMessage_'](_0x3373c8){if('r'in _0x3373c8){this['log_']('from\x20server:\x20'+O(_0x3373c8));const _0x4d3c9e=_0x3373c8['r'],_0x188070=this['requestCBHash_'][_0x4d3c9e];_0x188070&&(delete this['requestCBHash_'][_0x4d3c9e],_0x188070(_0x3373c8['b']));}else{if('error'in _0x3373c8)throw'A\x20server-side\x20error\x20has\x20occurred:\x20'+_0x3373c8['error'];'a'in _0x3373c8&&this['onDataPush_'](_0x3373c8['a'],_0x3373c8['b']);}}['onDataPush_'](_0x1f1dad,_0x2152b3){this['log_']('handleServerMessage',_0x1f1dad,_0x2152b3),_0x1f1dad==='d'?this['onDataUpdate_'](_0x2152b3['p'],_0x2152b3['d'],!0x1,_0x2152b3['t']):_0x1f1dad==='m'?this['onDataUpdate_'](_0x2152b3['p'],_0x2152b3['d'],!0x0,_0x2152b3['t']):_0x1f1dad==='c'?this['onListenRevoked_'](_0x2152b3['p'],_0x2152b3['q']):_0x1f1dad==='ac'?this['onAuthRevoked_'](_0x2152b3['s'],_0x2152b3['d']):_0x1f1dad==='apc'?this['onAppCheckRevoked_'](_0x2152b3['s'],_0x2152b3['d']):_0x1f1dad==='sd'?this['onSecurityDebugPacket_'](_0x2152b3):yi('Unrecognized\x20action\x20received\x20from\x20server:\x20'+O(_0x1f1dad)+'\x0aAre\x20you\x20using\x20the\x20latest\x20client?');}['onReady_'](_0x249e19,_0x874363){this['log_']('connection\x20ready'),this['connected_']=!0x0,this['lastConnectionEstablishedTime_']=new Date()['getTime'](),this['handleTimestamp_'](_0x249e19),this['lastSessionId']=_0x874363,this['firstConnection_']&&this['sendConnectStats_'](),this['restoreState_'](),this['firstConnection_']=!0x1,this['onConnectStatus_'](!0x0);}['scheduleConnect_'](_0x39208d){f(!this['realtime_'],'Scheduling\x20a\x20connect\x20when\x20we\x27re\x20already\x20connected/ing?'),this['establishConnectionTimer_']&&clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=setTimeout(()=>{this['establishConnectionTimer_']=null,this['establishConnection_']();},Math['floor'](_0x39208d));}['initConnection_'](){!this['realtime_']&&this['firstConnection_']&&this['scheduleConnect_'](0x0);}['onVisible_'](_0x321570){_0x321570&&!this['visible_']&&this['reconnectDelay_']===this['maxReconnectDelay_']&&(this['log_']('Window\x20became\x20visible.\x20\x20Reducing\x20delay.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)),this['visible_']=_0x321570;}['onOnline_'](_0x1fd53d){_0x1fd53d?(this['log_']('Browser\x20went\x20online.'),this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0)):(this['log_']('Browser\x20went\x20offline.\x20\x20Killing\x20connection.'),this['realtime_']&&this['realtime_']['close']());}['onRealtimeDisconnect_'](){if(this['log_']('data\x20client\x20disconnected'),this['connected_']=!0x1,this['realtime_']=null,this['cancelSentTransactions_'](),this['requestCBHash_']={},this['shouldReconnect_']()){this['visible_']?this['lastConnectionEstablishedTime_']&&(new Date()['getTime']()-this['lastConnectionEstablishedTime_']>Dh&&(this['reconnectDelay_']=gt),this['lastConnectionEstablishedTime_']=null):(this['log_']('Window\x20isn\x27t\x20visible.\x20\x20Delaying\x20reconnect.'),this['reconnectDelay_']=this['maxReconnectDelay_'],this['lastConnectionAttemptTime_']=new Date()['getTime']());const _0x955af=Math['max'](0x0,new Date()['getTime']()-this['lastConnectionAttemptTime_']);let _0x3f941c=Math['max'](0x0,this['reconnectDelay_']-_0x955af);_0x3f941c=Math['random']()*_0x3f941c,this['log_']('Trying\x20to\x20reconnect\x20in\x20'+_0x3f941c+'ms'),this['scheduleConnect_'](_0x3f941c),this['reconnectDelay_']=Math['min'](this['maxReconnectDelay_'],this['reconnectDelay_']*Oh);}this['onConnectStatus_'](!0x1);}async['establishConnection_'](){if(this['shouldReconnect_']()){this['log_']('Making\x20a\x20connection\x20attempt'),this['lastConnectionAttemptTime_']=new Date()['getTime'](),this['lastConnectionEstablishedTime_']=null;const _0x40815b=this['onDataMessage_']['bind'](this),_0x345b0c=this['onReady_']['bind'](this),_0x8d0ed4=this['onRealtimeDisconnect_']['bind'](this),_0x48968b=this['id']+':'+se['nextConnectionId_']++,_0x2a7455=this['lastSessionId'];let _0x22124a=!0x1,_0x5cfa76=null;const _0x26b37a=function(){_0x5cfa76?_0x5cfa76['close']():(_0x22124a=!0x0,_0x8d0ed4());},_0x32d53f=function(_0x57f9d7){f(_0x5cfa76,'sendRequest\x20call\x20when\x20we\x27re\x20not\x20connected\x20not\x20allowed.'),_0x5cfa76['sendRequest'](_0x57f9d7);};this['realtime_']={'close':_0x26b37a,'sendRequest':_0x32d53f};const _0x33fbdd=this['forceTokenRefresh_'];this['forceTokenRefresh_']=!0x1;try{const [_0x1514f1,_0x32e16d]=await Promise['all']([this['authTokenProvider_']['getToken'](_0x33fbdd),this['appCheckTokenProvider_']['getToken'](_0x33fbdd)]);_0x22124a?L('getToken()\x20completed\x20but\x20was\x20canceled'):(L('getToken()\x20completed.\x20Creating\x20connection.'),this['authToken_']=_0x1514f1&&_0x1514f1['accessToken'],this['appCheckToken_']=_0x32e16d&&_0x32e16d['token'],_0x5cfa76=new Sh(_0x48968b,this['repoInfo_'],this['applicationId_'],this['appCheckToken_'],this['authToken_'],_0x40815b,_0x345b0c,_0x8d0ed4,_0x1781c4=>{U(_0x1781c4+'\x20('+this['repoInfo_']['toString']()+')'),this['interrupt'](Mh);},_0x2a7455));}catch(_0x52fbce){this['log_']('Failed\x20to\x20get\x20token:\x20'+_0x52fbce),_0x22124a||(this['repoInfo_']['nodeAdmin']&&U(_0x52fbce),_0x26b37a());}}}['interrupt'](_0x39487d){L('Interrupting\x20connection\x20for\x20reason:\x20'+_0x39487d),this['interruptReasons_'][_0x39487d]=!0x0,this['realtime_']?this['realtime_']['close']():(this['establishConnectionTimer_']&&(clearTimeout(this['establishConnectionTimer_']),this['establishConnectionTimer_']=null),this['connected_']&&this['onRealtimeDisconnect_']());}['resume'](_0x181ea4){L('Resuming\x20connection\x20for\x20reason:\x20'+_0x181ea4),delete this['interruptReasons_'][_0x181ea4],ui(this['interruptReasons_'])&&(this['reconnectDelay_']=gt,this['realtime_']||this['scheduleConnect_'](0x0));}['handleTimestamp_'](_0x23e9c6){const _0x2e52a7=_0x23e9c6-new Date()['getTime']();this['onServerInfoUpdate_']({'serverTimeOffset':_0x2e52a7});}['cancelSentTransactions_'](){for(let _0x9029e4=0x0;_0x9029e4<this['outstandingPuts_']['length'];_0x9029e4++){const _0x1baedc=this['outstandingPuts_'][_0x9029e4];_0x1baedc&&'h'in _0x1baedc['request']&&_0x1baedc['queued']&&(_0x1baedc['onComplete']&&_0x1baedc['onComplete']('disconnect'),delete this['outstandingPuts_'][_0x9029e4],this['outstandingPutCount_']--);}this['outstandingPutCount_']===0x0&&(this['outstandingPuts_']=[]);}['onListenRevoked_'](_0x329bd5,_0x546804){let _0x3f6815;_0x546804?_0x3f6815=_0x546804['map'](_0x2fd94d=>Hi(_0x2fd94d))['join']('$'):_0x3f6815='default';const _0x1dd11c=this['removeListen_'](_0x329bd5,_0x3f6815);_0x1dd11c&&_0x1dd11c['onComplete']&&_0x1dd11c['onComplete']('permission_denied');}['removeListen_'](_0x58aae7,_0x5ce688){const _0x3904d7=new C(_0x58aae7)['toString']();let _0x3805fd;if(this['listens']['has'](_0x3904d7)){const _0x294e62=this['listens']['get'](_0x3904d7);_0x3805fd=_0x294e62['get'](_0x5ce688),_0x294e62['delete'](_0x5ce688),_0x294e62['size']===0x0&&this['listens']['delete'](_0x3904d7);}else _0x3805fd=void 0x0;return _0x3805fd;}['onAuthRevoked_'](_0x10fc9f,_0x2932cd){L('Auth\x20token\x20revoked:\x20'+_0x10fc9f+'/'+_0x2932cd),this['authToken_']=null,this['forceTokenRefresh_']=!0x0,this['realtime_']['close'](),(_0x10fc9f==='invalid_token'||_0x10fc9f==='permission_denied')&&(this['invalidAuthTokenCount_']++,this['invalidAuthTokenCount_']>=nr&&(this['reconnectDelay_']=tr,this['authTokenProvider_']['notifyForInvalidToken']()));}['onAppCheckRevoked_'](_0x16078e,_0x5052){L('App\x20check\x20token\x20revoked:\x20'+_0x16078e+'/'+_0x5052),this['appCheckToken_']=null,this['forceTokenRefresh_']=!0x0,(_0x16078e==='invalid_token'||_0x16078e==='permission_denied')&&(this['invalidAppCheckTokenCount_']++,this['invalidAppCheckTokenCount_']>=nr&&this['appCheckTokenProvider_']['notifyForInvalidToken']());}['onSecurityDebugPacket_'](_0x490744){this['securityDebugCallback_']?this['securityDebugCallback_'](_0x490744):'msg'in _0x490744&&console['log']('FIREBASE:\x20'+_0x490744['msg']['replace']('\x0a','\x0aFIREBASE:\x20'));}['restoreState_'](){this['tryAuth'](),this['tryAppCheck']();for(const _0x326e22 of this['listens']['values']())for(const _0x268b2f of _0x326e22['values']())this['sendListen_'](_0x268b2f);for(let _0x18874b=0x0;_0x18874b<this['outstandingPuts_']['length'];_0x18874b++)this['outstandingPuts_'][_0x18874b]&&this['sendPut_'](_0x18874b);for(;this['onDisconnectRequestQueue_']['length'];){const _0x4c7b38=this['onDisconnectRequestQueue_']['shift']();this['sendOnDisconnect_'](_0x4c7b38['action'],_0x4c7b38['pathString'],_0x4c7b38['data'],_0x4c7b38['onComplete']);}for(let _0x300239=0x0;_0x300239<this['outstandingGets_']['length'];_0x300239++)this['outstandingGets_'][_0x300239]&&this['sendGet_'](_0x300239);}['sendConnectStats_'](){const _0x40a752={};let _0x11b24d='js';_0x40a752['sdk.'+_0x11b24d+'.'+no['replace'](/\./g,'-')]=0x1,Fi()?_0x40a752['framework.cordova']=0x1:Yr()&&(_0x40a752['framework.reactnative']=0x1),this['reportStats'](_0x40a752);}['shouldReconnect_'](){const _0x1aa429=dn['getInstance']()['currentlyOnline']();return ui(this['interruptReasons_'])&&_0x1aa429;}}se['nextPersistentConnectionId_']=0x0,se['nextConnectionId_']=0x0;/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class E{constructor(_0x477652,_0x295570){this['name']=_0x477652,this['node']=_0x295570;}static['Wrap'](_0x5e260a,_0x4cc224){return new E(_0x5e260a,_0x4cc224);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Dn{['getCompare'](){return this['compare']['bind'](this);}['indexedValueChanged'](_0x36ab86,_0x474869){const _0x56d1cc=new E(Fe,_0x36ab86),_0x33c028=new E(Fe,_0x474869);return this['compare'](_0x56d1cc,_0x33c028)!==0x0;}['minPost'](){return E['MIN'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Zt;class ko extends Dn{static get['__EMPTY_NODE'](){return Zt;}static set['__EMPTY_NODE'](_0x2e8883){Zt=_0x2e8883;}['compare'](_0x5371fe,_0x5b003f){return He(_0x5371fe['name'],_0x5b003f['name']);}['isDefinedOn'](_0x4414c0){throw rt('KeyIndex.isDefinedOn\x20not\x20expected\x20to\x20be\x20called.');}['indexedValueChanged'](_0x587e2c,_0x3455f4){return!0x1;}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,Zt);}['makePost'](_0x21bf2c,_0x264c2f){return f(typeof _0x21bf2c=='string','KeyIndex\x20indexValue\x20must\x20always\x20be\x20a\x20string.'),new E(_0x21bf2c,Zt);}['toString'](){return'.key';}}const ye=new ko();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class en{constructor(_0x596cd9,_0x122306,_0x5604ca,_0x1585d0,_0x201626=null){this['isReverse_']=_0x1585d0,this['resultGenerator_']=_0x201626,this['nodeStack_']=[];let _0x3d99f0=0x1;for(;!_0x596cd9['isEmpty']();)if(_0x596cd9=_0x596cd9,_0x3d99f0=_0x122306?_0x5604ca(_0x596cd9['key'],_0x122306):0x1,_0x1585d0&&(_0x3d99f0*=-0x1),_0x3d99f0<0x0)this['isReverse_']?_0x596cd9=_0x596cd9['left']:_0x596cd9=_0x596cd9['right'];else{if(_0x3d99f0===0x0){this['nodeStack_']['push'](_0x596cd9);break;}else this['nodeStack_']['push'](_0x596cd9),this['isReverse_']?_0x596cd9=_0x596cd9['right']:_0x596cd9=_0x596cd9['left'];}}['getNext'](){if(this['nodeStack_']['length']===0x0)return null;let _0x1af4a9=this['nodeStack_']['pop'](),_0x45ae8a;if(this['resultGenerator_']?_0x45ae8a=this['resultGenerator_'](_0x1af4a9['key'],_0x1af4a9['value']):_0x45ae8a={'key':_0x1af4a9['key'],'value':_0x1af4a9['value']},this['isReverse_']){for(_0x1af4a9=_0x1af4a9['left'];!_0x1af4a9['isEmpty']();)this['nodeStack_']['push'](_0x1af4a9),_0x1af4a9=_0x1af4a9['right'];}else{for(_0x1af4a9=_0x1af4a9['right'];!_0x1af4a9['isEmpty']();)this['nodeStack_']['push'](_0x1af4a9),_0x1af4a9=_0x1af4a9['left'];}return _0x45ae8a;}['hasNext'](){return this['nodeStack_']['length']>0x0;}['peek'](){if(this['nodeStack_']['length']===0x0)return null;const _0x26f423=this['nodeStack_'][this['nodeStack_']['length']-0x1];return this['resultGenerator_']?this['resultGenerator_'](_0x26f423['key'],_0x26f423['value']):{'key':_0x26f423['key'],'value':_0x26f423['value']};}}class M{constructor(_0x3d027a,_0x18015f,_0xd9dc97,_0x1da24c,_0x52ec3c){this['key']=_0x3d027a,this['value']=_0x18015f,this['color']=_0xd9dc97??M['RED'],this['left']=_0x1da24c??B['EMPTY_NODE'],this['right']=_0x52ec3c??B['EMPTY_NODE'];}['copy'](_0x52ad21,_0x2bf820,_0x5cd350,_0x485fdd,_0x4c04c0){return new M(_0x52ad21??this['key'],_0x2bf820??this['value'],_0x5cd350??this['color'],_0x485fdd??this['left'],_0x4c04c0??this['right']);}['count'](){return this['left']['count']()+0x1+this['right']['count']();}['isEmpty'](){return!0x1;}['inorderTraversal'](_0x3aeff8){return this['left']['inorderTraversal'](_0x3aeff8)||!!_0x3aeff8(this['key'],this['value'])||this['right']['inorderTraversal'](_0x3aeff8);}['reverseTraversal'](_0x5bdb7c){return this['right']['reverseTraversal'](_0x5bdb7c)||_0x5bdb7c(this['key'],this['value'])||this['left']['reverseTraversal'](_0x5bdb7c);}['min_'](){return this['left']['isEmpty']()?this:this['left']['min_']();}['minKey'](){return this['min_']()['key'];}['maxKey'](){return this['right']['isEmpty']()?this['key']:this['right']['maxKey']();}['insert'](_0x4cfd2d,_0x3d037d,_0x5b8528){let _0x37ce2c=this;const _0x31627b=_0x5b8528(_0x4cfd2d,_0x37ce2c['key']);return _0x31627b<0x0?_0x37ce2c=_0x37ce2c['copy'](null,null,null,_0x37ce2c['left']['insert'](_0x4cfd2d,_0x3d037d,_0x5b8528),null):_0x31627b===0x0?_0x37ce2c=_0x37ce2c['copy'](null,_0x3d037d,null,null,null):_0x37ce2c=_0x37ce2c['copy'](null,null,null,null,_0x37ce2c['right']['insert'](_0x4cfd2d,_0x3d037d,_0x5b8528)),_0x37ce2c['fixUp_']();}['removeMin_'](){if(this['left']['isEmpty']())return B['EMPTY_NODE'];let _0x28adc8=this;return!_0x28adc8['left']['isRed_']()&&!_0x28adc8['left']['left']['isRed_']()&&(_0x28adc8=_0x28adc8['moveRedLeft_']()),_0x28adc8=_0x28adc8['copy'](null,null,null,_0x28adc8['left']['removeMin_'](),null),_0x28adc8['fixUp_']();}['remove'](_0x3c8172,_0x39acb5){let _0x563315,_0xc0ced1;if(_0x563315=this,_0x39acb5(_0x3c8172,_0x563315['key'])<0x0)!_0x563315['left']['isEmpty']()&&!_0x563315['left']['isRed_']()&&!_0x563315['left']['left']['isRed_']()&&(_0x563315=_0x563315['moveRedLeft_']()),_0x563315=_0x563315['copy'](null,null,null,_0x563315['left']['remove'](_0x3c8172,_0x39acb5),null);else{if(_0x563315['left']['isRed_']()&&(_0x563315=_0x563315['rotateRight_']()),!_0x563315['right']['isEmpty']()&&!_0x563315['right']['isRed_']()&&!_0x563315['right']['left']['isRed_']()&&(_0x563315=_0x563315['moveRedRight_']()),_0x39acb5(_0x3c8172,_0x563315['key'])===0x0){if(_0x563315['right']['isEmpty']())return B['EMPTY_NODE'];_0xc0ced1=_0x563315['right']['min_'](),_0x563315=_0x563315['copy'](_0xc0ced1['key'],_0xc0ced1['value'],null,null,_0x563315['right']['removeMin_']());}_0x563315=_0x563315['copy'](null,null,null,null,_0x563315['right']['remove'](_0x3c8172,_0x39acb5));}return _0x563315['fixUp_']();}['isRed_'](){return this['color'];}['fixUp_'](){let _0x2e7120=this;return _0x2e7120['right']['isRed_']()&&!_0x2e7120['left']['isRed_']()&&(_0x2e7120=_0x2e7120['rotateLeft_']()),_0x2e7120['left']['isRed_']()&&_0x2e7120['left']['left']['isRed_']()&&(_0x2e7120=_0x2e7120['rotateRight_']()),_0x2e7120['left']['isRed_']()&&_0x2e7120['right']['isRed_']()&&(_0x2e7120=_0x2e7120['colorFlip_']()),_0x2e7120;}['moveRedLeft_'](){let _0x16c7c6=this['colorFlip_']();return _0x16c7c6['right']['left']['isRed_']()&&(_0x16c7c6=_0x16c7c6['copy'](null,null,null,null,_0x16c7c6['right']['rotateRight_']()),_0x16c7c6=_0x16c7c6['rotateLeft_'](),_0x16c7c6=_0x16c7c6['colorFlip_']()),_0x16c7c6;}['moveRedRight_'](){let _0x23da91=this['colorFlip_']();return _0x23da91['left']['left']['isRed_']()&&(_0x23da91=_0x23da91['rotateRight_'](),_0x23da91=_0x23da91['colorFlip_']()),_0x23da91;}['rotateLeft_'](){const _0x3a12c9=this['copy'](null,null,M['RED'],null,this['right']['left']);return this['right']['copy'](null,null,this['color'],_0x3a12c9,null);}['rotateRight_'](){const _0x3f0a0e=this['copy'](null,null,M['RED'],this['left']['right'],null);return this['left']['copy'](null,null,this['color'],null,_0x3f0a0e);}['colorFlip_'](){const _0x3a92a5=this['left']['copy'](null,null,!this['left']['color'],null,null),_0x5c0e84=this['right']['copy'](null,null,!this['right']['color'],null,null);return this['copy'](null,null,!this['color'],_0x3a92a5,_0x5c0e84);}['checkMaxDepth_'](){const _0xa8f18=this['check_']();return Math['pow'](0x2,_0xa8f18)<=this['count']()+0x1;}['check_'](){if(this['isRed_']()&&this['left']['isRed_']())throw new Error('Red\x20node\x20has\x20red\x20child('+this['key']+','+this['value']+')');if(this['right']['isRed_']())throw new Error('Right\x20child\x20of\x20('+this['key']+','+this['value']+')\x20is\x20red');const _0x169371=this['left']['check_']();if(_0x169371!==this['right']['check_']())throw new Error('Black\x20depths\x20differ');return _0x169371+(this['isRed_']()?0x0:0x1);}}M['RED']=!0x0,M['BLACK']=!0x1;class Lh{['copy'](_0xd40333,_0x28a5f2,_0x49254a,_0x1f068b,_0x5b2411){return this;}['insert'](_0x2c139d,_0x1beb74,_0x5bf406){return new M(_0x2c139d,_0x1beb74,null);}['remove'](_0x3edd16,_0x5da73f){return this;}['count'](){return 0x0;}['isEmpty'](){return!0x0;}['inorderTraversal'](_0x28fec1){return!0x1;}['reverseTraversal'](_0x1d7e15){return!0x1;}['minKey'](){return null;}['maxKey'](){return null;}['check_'](){return 0x0;}['isRed_'](){return!0x1;}}class B{constructor(_0x516db4,_0x15c731=B['EMPTY_NODE']){this['comparator_']=_0x516db4,this['root_']=_0x15c731;}['insert'](_0x133787,_0x230dd4){return new B(this['comparator_'],this['root_']['insert'](_0x133787,_0x230dd4,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['remove'](_0xc75e33){return new B(this['comparator_'],this['root_']['remove'](_0xc75e33,this['comparator_'])['copy'](null,null,M['BLACK'],null,null));}['get'](_0x289efe){let _0x482934,_0x4059d6=this['root_'];for(;!_0x4059d6['isEmpty']();){if(_0x482934=this['comparator_'](_0x289efe,_0x4059d6['key']),_0x482934===0x0)return _0x4059d6['value'];_0x482934<0x0?_0x4059d6=_0x4059d6['left']:_0x482934>0x0&&(_0x4059d6=_0x4059d6['right']);}return null;}['getPredecessorKey'](_0xa01bca){let _0x2d1384,_0x2d2c6d=this['root_'],_0x415b14=null;for(;!_0x2d2c6d['isEmpty']();)if(_0x2d1384=this['comparator_'](_0xa01bca,_0x2d2c6d['key']),_0x2d1384===0x0){if(_0x2d2c6d['left']['isEmpty']())return _0x415b14?_0x415b14['key']:null;for(_0x2d2c6d=_0x2d2c6d['left'];!_0x2d2c6d['right']['isEmpty']();)_0x2d2c6d=_0x2d2c6d['right'];return _0x2d2c6d['key'];}else _0x2d1384<0x0?_0x2d2c6d=_0x2d2c6d['left']:_0x2d1384>0x0&&(_0x415b14=_0x2d2c6d,_0x2d2c6d=_0x2d2c6d['right']);throw new Error('Attempted\x20to\x20find\x20predecessor\x20key\x20for\x20a\x20nonexistent\x20key.\x20\x20What\x20gives?');}['isEmpty'](){return this['root_']['isEmpty']();}['count'](){return this['root_']['count']();}['minKey'](){return this['root_']['minKey']();}['maxKey'](){return this['root_']['maxKey']();}['inorderTraversal'](_0x2d38c3){return this['root_']['inorderTraversal'](_0x2d38c3);}['reverseTraversal'](_0x30f29a){return this['root_']['reverseTraversal'](_0x30f29a);}['getIterator'](_0x2d4856){return new en(this['root_'],null,this['comparator_'],!0x1,_0x2d4856);}['getIteratorFrom'](_0x4d62b4,_0x3ef8ff){return new en(this['root_'],_0x4d62b4,this['comparator_'],!0x1,_0x3ef8ff);}['getReverseIteratorFrom'](_0x5aa5cd,_0x1c336f){return new en(this['root_'],_0x5aa5cd,this['comparator_'],!0x0,_0x1c336f);}['getReverseIterator'](_0x44d06b){return new en(this['root_'],null,this['comparator_'],!0x0,_0x44d06b);}}B['EMPTY_NODE']=new Lh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function xh(_0x5207ce,_0x5e860c){return He(_0x5207ce['name'],_0x5e860c['name']);}function Yi(_0x73af95,_0x31a32){return He(_0x73af95,_0x31a32);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Ei;function Fh(_0x27f8bd){Ei=_0x27f8bd;}const No=function(_0x202b47){return typeof _0x202b47=='number'?'number:'+ao(_0x202b47):'string:'+_0x202b47;},Po=function(_0x2ca777){if(_0x2ca777['isLeafNode']()){const _0x2203ce=_0x2ca777['val']();f(typeof _0x2203ce=='string'||typeof _0x2203ce=='number'||typeof _0x2203ce=='object'&&J(_0x2203ce,'.sv'),'Priority\x20must\x20be\x20a\x20string\x20or\x20number.');}else f(_0x2ca777===Ei||_0x2ca777['isEmpty'](),'priority\x20of\x20unexpected\x20type.');f(_0x2ca777===Ei||_0x2ca777['getPriority']()['isEmpty'](),'Priority\x20nodes\x20can\x27t\x20have\x20a\x20priority\x20of\x20their\x20own.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ir;class D{static set['__childrenNodeConstructor'](_0x45f12b){ir=_0x45f12b;}static get['__childrenNodeConstructor'](){return ir;}constructor(_0x306a7e,_0x4a74cb=D['__childrenNodeConstructor']['EMPTY_NODE']){this['value_']=_0x306a7e,this['priorityNode_']=_0x4a74cb,this['lazyHash_']=null,f(this['value_']!==void 0x0&&this['value_']!==null,'LeafNode\x20shouldn\x27t\x20be\x20created\x20with\x20null/undefined\x20value.'),Po(this['priorityNode_']);}['isLeafNode'](){return!0x0;}['getPriority'](){return this['priorityNode_'];}['updatePriority'](_0x35983e){return new D(this['value_'],_0x35983e);}['getImmediateChild'](_0x2f8370){return _0x2f8370==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['getChild'](_0x56efa2){return v(_0x56efa2)?this:y(_0x56efa2)==='.priority'?this['priorityNode_']:D['__childrenNodeConstructor']['EMPTY_NODE'];}['hasChild'](){return!0x1;}['getPredecessorChildName'](_0x5da026,_0x52cb36){return null;}['updateImmediateChild'](_0x210726,_0x871d1b){return _0x210726==='.priority'?this['updatePriority'](_0x871d1b):_0x871d1b['isEmpty']()&&_0x210726!=='.priority'?this:D['__childrenNodeConstructor']['EMPTY_NODE']['updateImmediateChild'](_0x210726,_0x871d1b)['updatePriority'](this['priorityNode_']);}['updateChild'](_0x24e23d,_0x24befc){const _0x7f7cb5=y(_0x24e23d);return _0x7f7cb5===null?_0x24befc:_0x24befc['isEmpty']()&&_0x7f7cb5!=='.priority'?this:(f(_0x7f7cb5!=='.priority'||we(_0x24e23d)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path'),this['updateImmediateChild'](_0x7f7cb5,D['__childrenNodeConstructor']['EMPTY_NODE']['updateChild'](b(_0x24e23d),_0x24befc)));}['isEmpty'](){return!0x1;}['numChildren'](){return 0x0;}['forEachChild'](_0x2358ce,_0x496b7c){return!0x1;}['val'](_0x45f5c7){return _0x45f5c7&&!this['getPriority']()['isEmpty']()?{'.value':this['getValue'](),'.priority':this['getPriority']()['val']()}:this['getValue']();}['hash'](){if(this['lazyHash_']===null){let _0xb90bd1='';this['priorityNode_']['isEmpty']()||(_0xb90bd1+='priority:'+No(this['priorityNode_']['val']())+':');const _0x1b2b94=typeof this['value_'];_0xb90bd1+=_0x1b2b94+':',_0x1b2b94==='number'?_0xb90bd1+=ao(this['value_']):_0xb90bd1+=this['value_'],this['lazyHash_']=ro(_0xb90bd1);}return this['lazyHash_'];}['getValue'](){return this['value_'];}['compareTo'](_0x2a3612){return _0x2a3612===D['__childrenNodeConstructor']['EMPTY_NODE']?0x1:_0x2a3612 instanceof D['__childrenNodeConstructor']?-0x1:(f(_0x2a3612['isLeafNode'](),'Unknown\x20node\x20type'),this['compareToLeafNode_'](_0x2a3612));}['compareToLeafNode_'](_0x10299c){const _0x53ce10=typeof _0x10299c['value_'],_0xb6b0f2=typeof this['value_'],_0x29bb0a=D['VALUE_TYPE_ORDER']['indexOf'](_0x53ce10),_0x27f28e=D['VALUE_TYPE_ORDER']['indexOf'](_0xb6b0f2);return f(_0x29bb0a>=0x0,'Unknown\x20leaf\x20type:\x20'+_0x53ce10),f(_0x27f28e>=0x0,'Unknown\x20leaf\x20type:\x20'+_0xb6b0f2),_0x29bb0a===_0x27f28e?_0xb6b0f2==='object'?0x0:this['value_']<_0x10299c['value_']?-0x1:this['value_']===_0x10299c['value_']?0x0:0x1:_0x27f28e-_0x29bb0a;}['withIndex'](){return this;}['isIndexed'](){return!0x0;}['equals'](_0x82c083){if(_0x82c083===this)return!0x0;if(_0x82c083['isLeafNode']()){const _0x318373=_0x82c083;return this['value_']===_0x318373['value_']&&this['priorityNode_']['equals'](_0x318373['priorityNode_']);}else return!0x1;}}D['VALUE_TYPE_ORDER']=['object','boolean','number','string'];/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let Oo,Do;function Uh(_0x58ce02){Oo=_0x58ce02;}function Wh(_0xb4de5e){Do=_0xb4de5e;}class Bh extends Dn{['compare'](_0x29d293,_0x504c2f){const _0x5101c2=_0x29d293['node']['getPriority'](),_0xab5b4b=_0x504c2f['node']['getPriority'](),_0x2063ef=_0x5101c2['compareTo'](_0xab5b4b);return _0x2063ef===0x0?He(_0x29d293['name'],_0x504c2f['name']):_0x2063ef;}['isDefinedOn'](_0x32dcad){return!_0x32dcad['getPriority']()['isEmpty']();}['indexedValueChanged'](_0x459037,_0xbcf393){return!_0x459037['getPriority']()['equals'](_0xbcf393['getPriority']());}['minPost'](){return E['MIN'];}['maxPost'](){return new E(Ie,new D('[PRIORITY-POST]',Do));}['makePost'](_0x4abdab,_0x7e8967){const _0x1bd441=Oo(_0x4abdab);return new E(_0x7e8967,new D('[PRIORITY-POST]',_0x1bd441));}['toString'](){return'.priority';}}const R=new Bh(),Vh=Math['log'](0x2);class Hh{constructor(_0x1b31e4){const _0x19f575=_0x5b4d09=>parseInt(Math['log'](_0x5b4d09)/Vh,0xa),_0x2c00ee=_0x315bae=>parseInt(Array(_0x315bae+0x1)['join']('1'),0x2);this['count']=_0x19f575(_0x1b31e4+0x1),this['current_']=this['count']-0x1;const _0x4e341f=_0x2c00ee(this['count']);this['bits_']=_0x1b31e4+0x1&_0x4e341f;}['nextBitIsOne'](){const _0x148312=!(this['bits_']&0x1<<this['current_']);return this['current_']--,_0x148312;}}const fn=function(_0x441c40,_0x26b9ea,_0x4768ad,_0x4a5a81){_0x441c40['sort'](_0x26b9ea);const _0xcb4d66=function(_0x2c5280,_0x113f8a){const _0x476c1c=_0x113f8a-_0x2c5280;let _0x2f0b34,_0x549eb0;if(_0x476c1c===0x0)return null;if(_0x476c1c===0x1)return _0x2f0b34=_0x441c40[_0x2c5280],_0x549eb0=_0x4768ad?_0x4768ad(_0x2f0b34):_0x2f0b34,new M(_0x549eb0,_0x2f0b34['node'],M['BLACK'],null,null);{const _0x4f1a22=parseInt(_0x476c1c/0x2,0xa)+_0x2c5280,_0x5aa5bc=_0xcb4d66(_0x2c5280,_0x4f1a22),_0x56cc13=_0xcb4d66(_0x4f1a22+0x1,_0x113f8a);return _0x2f0b34=_0x441c40[_0x4f1a22],_0x549eb0=_0x4768ad?_0x4768ad(_0x2f0b34):_0x2f0b34,new M(_0x549eb0,_0x2f0b34['node'],M['BLACK'],_0x5aa5bc,_0x56cc13);}},_0x3548e9=function(_0x141ccd){let _0x110ce3=null,_0x550206=null,_0x3ed125=_0x441c40['length'];const _0x5be2e9=function(_0xed756c,_0x4aca96){const _0xbad707=_0x3ed125-_0xed756c,_0x1b6924=_0x3ed125;_0x3ed125-=_0xed756c;const _0x2d8f7f=_0xcb4d66(_0xbad707+0x1,_0x1b6924),_0x4c6f63=_0x441c40[_0xbad707],_0x4482a=_0x4768ad?_0x4768ad(_0x4c6f63):_0x4c6f63;_0x2e2e94(new M(_0x4482a,_0x4c6f63['node'],_0x4aca96,null,_0x2d8f7f));},_0x2e2e94=function(_0x30a8fb){_0x110ce3?(_0x110ce3['left']=_0x30a8fb,_0x110ce3=_0x30a8fb):(_0x550206=_0x30a8fb,_0x110ce3=_0x30a8fb);};for(let _0x2f195d=0x0;_0x2f195d<_0x141ccd['count'];++_0x2f195d){const _0x43cc73=_0x141ccd['nextBitIsOne'](),_0x13c5cf=Math['pow'](0x2,_0x141ccd['count']-(_0x2f195d+0x1));_0x43cc73?_0x5be2e9(_0x13c5cf,M['BLACK']):(_0x5be2e9(_0x13c5cf,M['BLACK']),_0x5be2e9(_0x13c5cf,M['RED']));}return _0x550206;},_0x2db561=new Hh(_0x441c40['length']),_0xea63af=_0x3548e9(_0x2db561);return new B(_0x4a5a81||_0x26b9ea,_0xea63af);};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let ri;const ze={};class te{static get['Default'](){return f(ze&&R,'ChildrenNode.ts\x20has\x20not\x20been\x20loaded'),ri=ri||new te({'.priority':ze},{'.priority':R}),ri;}constructor(_0x1c01fc,_0x4ac4eb){this['indexes_']=_0x1c01fc,this['indexSet_']=_0x4ac4eb;}['get'](_0x472ae4){const _0x376d3a=De(this['indexes_'],_0x472ae4);if(!_0x376d3a)throw new Error('No\x20index\x20defined\x20for\x20'+_0x472ae4);return _0x376d3a instanceof B?_0x376d3a:null;}['hasIndex'](_0x51ee3b){return J(this['indexSet_'],_0x51ee3b['toString']());}['addIndex'](_0xa82b36,_0x571cfb){f(_0xa82b36!==ye,'KeyIndex\x20always\x20exists\x20and\x20isn\x27t\x20meant\x20to\x20be\x20added\x20to\x20the\x20IndexMap.');const _0xe64f7c=[];let _0x48ea1f=!0x1;const _0x3e702c=_0x571cfb['getIterator'](E['Wrap']);let _0x17105e=_0x3e702c['getNext']();for(;_0x17105e;)_0x48ea1f=_0x48ea1f||_0xa82b36['isDefinedOn'](_0x17105e['node']),_0xe64f7c['push'](_0x17105e),_0x17105e=_0x3e702c['getNext']();let _0x262753;_0x48ea1f?_0x262753=fn(_0xe64f7c,_0xa82b36['getCompare']()):_0x262753=ze;const _0x5eeaf8=_0xa82b36['toString'](),_0x276fdf={...this['indexSet_']};_0x276fdf[_0x5eeaf8]=_0xa82b36;const _0x23fc80={...this['indexes_']};return _0x23fc80[_0x5eeaf8]=_0x262753,new te(_0x23fc80,_0x276fdf);}['addToIndexes'](_0x29e5a6,_0x3719c7){const _0x2bbf78=hn(this['indexes_'],(_0x4fff85,_0x3a3b73)=>{const _0x5357cc=De(this['indexSet_'],_0x3a3b73);if(f(_0x5357cc,'Missing\x20index\x20implementation\x20for\x20'+_0x3a3b73),_0x4fff85===ze){if(_0x5357cc['isDefinedOn'](_0x29e5a6['node'])){const _0x2b0f6c=[],_0x18da49=_0x3719c7['getIterator'](E['Wrap']);let _0x25c07f=_0x18da49['getNext']();for(;_0x25c07f;)_0x25c07f['name']!==_0x29e5a6['name']&&_0x2b0f6c['push'](_0x25c07f),_0x25c07f=_0x18da49['getNext']();return _0x2b0f6c['push'](_0x29e5a6),fn(_0x2b0f6c,_0x5357cc['getCompare']());}else return ze;}else{const _0x45162f=_0x3719c7['get'](_0x29e5a6['name']);let _0x3d3d54=_0x4fff85;return _0x45162f&&(_0x3d3d54=_0x3d3d54['remove'](new E(_0x29e5a6['name'],_0x45162f))),_0x3d3d54['insert'](_0x29e5a6,_0x29e5a6['node']);}});return new te(_0x2bbf78,this['indexSet_']);}['removeFromIndexes'](_0x3e1a4a,_0x4b0022){const _0x488898=hn(this['indexes_'],_0x1eda08=>{if(_0x1eda08===ze)return _0x1eda08;{const _0x207ba6=_0x4b0022['get'](_0x3e1a4a['name']);return _0x207ba6?_0x1eda08['remove'](new E(_0x3e1a4a['name'],_0x207ba6)):_0x1eda08;}});return new te(_0x488898,this['indexSet_']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let mt;class g{static get['EMPTY_NODE'](){return mt||(mt=new g(new B(Yi),null,te['Default']));}constructor(_0x150926,_0x442638,_0x4061b9){this['children_']=_0x150926,this['priorityNode_']=_0x442638,this['indexMap_']=_0x4061b9,this['lazyHash_']=null,this['priorityNode_']&&Po(this['priorityNode_']),this['children_']['isEmpty']()&&f(!this['priorityNode_']||this['priorityNode_']['isEmpty'](),'An\x20empty\x20node\x20cannot\x20have\x20a\x20priority');}['isLeafNode'](){return!0x1;}['getPriority'](){return this['priorityNode_']||mt;}['updatePriority'](_0x1674d2){return this['children_']['isEmpty']()?this:new g(this['children_'],_0x1674d2,this['indexMap_']);}['getImmediateChild'](_0x2ca7d9){if(_0x2ca7d9==='.priority')return this['getPriority']();{const _0x1007c3=this['children_']['get'](_0x2ca7d9);return _0x1007c3===null?mt:_0x1007c3;}}['getChild'](_0x4e01ce){const _0x3edad9=y(_0x4e01ce);return _0x3edad9===null?this:this['getImmediateChild'](_0x3edad9)['getChild'](b(_0x4e01ce));}['hasChild'](_0x298edd){return this['children_']['get'](_0x298edd)!==null;}['updateImmediateChild'](_0x318053,_0x144b4e){if(f(_0x144b4e,'We\x20should\x20always\x20be\x20passing\x20snapshot\x20nodes'),_0x318053==='.priority')return this['updatePriority'](_0x144b4e);{const _0x215b0f=new E(_0x318053,_0x144b4e);let _0x1d4b21,_0x431a3a;_0x144b4e['isEmpty']()?(_0x1d4b21=this['children_']['remove'](_0x318053),_0x431a3a=this['indexMap_']['removeFromIndexes'](_0x215b0f,this['children_'])):(_0x1d4b21=this['children_']['insert'](_0x318053,_0x144b4e),_0x431a3a=this['indexMap_']['addToIndexes'](_0x215b0f,this['children_']));const _0x4e5ab9=_0x1d4b21['isEmpty']()?mt:this['priorityNode_'];return new g(_0x1d4b21,_0x4e5ab9,_0x431a3a);}}['updateChild'](_0xd3500,_0x11b1c9){const _0x3889ab=y(_0xd3500);if(_0x3889ab===null)return _0x11b1c9;{f(y(_0xd3500)!=='.priority'||we(_0xd3500)===0x1,'.priority\x20must\x20be\x20the\x20last\x20token\x20in\x20a\x20path');const _0x35ebfc=this['getImmediateChild'](_0x3889ab)['updateChild'](b(_0xd3500),_0x11b1c9);return this['updateImmediateChild'](_0x3889ab,_0x35ebfc);}}['isEmpty'](){return this['children_']['isEmpty']();}['numChildren'](){return this['children_']['count']();}['val'](_0x51fb6b){if(this['isEmpty']())return null;const _0x3ebf48={};let _0x23a9e6=0x0,_0xf07e55=0x0,_0x55df15=!0x0;if(this['forEachChild'](R,(_0x1d4d7c,_0x302496)=>{_0x3ebf48[_0x1d4d7c]=_0x302496['val'](_0x51fb6b),_0x23a9e6++,_0x55df15&&g['INTEGER_REGEXP_']['test'](_0x1d4d7c)?_0xf07e55=Math['max'](_0xf07e55,Number(_0x1d4d7c)):_0x55df15=!0x1;}),!_0x51fb6b&&_0x55df15&&_0xf07e55<0x2*_0x23a9e6){const _0x4fc77f=[];for(const _0x14a3e2 in _0x3ebf48)_0x4fc77f[_0x14a3e2]=_0x3ebf48[_0x14a3e2];return _0x4fc77f;}else return _0x51fb6b&&!this['getPriority']()['isEmpty']()&&(_0x3ebf48['.priority']=this['getPriority']()['val']()),_0x3ebf48;}['hash'](){if(this['lazyHash_']===null){let _0x30923b='';this['getPriority']()['isEmpty']()||(_0x30923b+='priority:'+No(this['getPriority']()['val']())+':'),this['forEachChild'](R,(_0x3e1b28,_0xd305c3)=>{const _0x4cc940=_0xd305c3['hash']();_0x4cc940!==''&&(_0x30923b+=':'+_0x3e1b28+':'+_0x4cc940);}),this['lazyHash_']=_0x30923b===''?'':ro(_0x30923b);}return this['lazyHash_'];}['getPredecessorChildName'](_0x4c46f9,_0x15ce38,_0x49b68f){const _0x55370b=this['resolveIndex_'](_0x49b68f);if(_0x55370b){const _0xdbe8c6=_0x55370b['getPredecessorKey'](new E(_0x4c46f9,_0x15ce38));return _0xdbe8c6?_0xdbe8c6['name']:null;}else return this['children_']['getPredecessorKey'](_0x4c46f9);}['getFirstChildName'](_0xaa534){const _0x7bbd68=this['resolveIndex_'](_0xaa534);if(_0x7bbd68){const _0x210ad4=_0x7bbd68['minKey']();return _0x210ad4&&_0x210ad4['name'];}else return this['children_']['minKey']();}['getFirstChild'](_0x557912){const _0x469aa7=this['getFirstChildName'](_0x557912);return _0x469aa7?new E(_0x469aa7,this['children_']['get'](_0x469aa7)):null;}['getLastChildName'](_0x33d0ef){const _0x1f2bac=this['resolveIndex_'](_0x33d0ef);if(_0x1f2bac){const _0x144295=_0x1f2bac['maxKey']();return _0x144295&&_0x144295['name'];}else return this['children_']['maxKey']();}['getLastChild'](_0x3094ee){const _0x1dfb2a=this['getLastChildName'](_0x3094ee);return _0x1dfb2a?new E(_0x1dfb2a,this['children_']['get'](_0x1dfb2a)):null;}['forEachChild'](_0x55f6e3,_0x213269){const _0x31f487=this['resolveIndex_'](_0x55f6e3);return _0x31f487?_0x31f487['inorderTraversal'](_0x4868fb=>_0x213269(_0x4868fb['name'],_0x4868fb['node'])):this['children_']['inorderTraversal'](_0x213269);}['getIterator'](_0x1be899){return this['getIteratorFrom'](_0x1be899['minPost'](),_0x1be899);}['getIteratorFrom'](_0x37dabf,_0x89aec1){const _0x1df4e8=this['resolveIndex_'](_0x89aec1);if(_0x1df4e8)return _0x1df4e8['getIteratorFrom'](_0x37dabf,_0x54c398=>_0x54c398);{const _0x1d5c3a=this['children_']['getIteratorFrom'](_0x37dabf['name'],E['Wrap']);let _0x4e6d45=_0x1d5c3a['peek']();for(;_0x4e6d45!=null&&_0x89aec1['compare'](_0x4e6d45,_0x37dabf)<0x0;)_0x1d5c3a['getNext'](),_0x4e6d45=_0x1d5c3a['peek']();return _0x1d5c3a;}}['getReverseIterator'](_0x216aa4){return this['getReverseIteratorFrom'](_0x216aa4['maxPost'](),_0x216aa4);}['getReverseIteratorFrom'](_0x2f0690,_0x35711a){const _0x2ace2e=this['resolveIndex_'](_0x35711a);if(_0x2ace2e)return _0x2ace2e['getReverseIteratorFrom'](_0x2f0690,_0x4cce82=>_0x4cce82);{const _0x58c84c=this['children_']['getReverseIteratorFrom'](_0x2f0690['name'],E['Wrap']);let _0x1143ea=_0x58c84c['peek']();for(;_0x1143ea!=null&&_0x35711a['compare'](_0x1143ea,_0x2f0690)>0x0;)_0x58c84c['getNext'](),_0x1143ea=_0x58c84c['peek']();return _0x58c84c;}}['compareTo'](_0xa5bc0c){return this['isEmpty']()?_0xa5bc0c['isEmpty']()?0x0:-0x1:_0xa5bc0c['isLeafNode']()||_0xa5bc0c['isEmpty']()?0x1:_0xa5bc0c===$t?-0x1:0x0;}['withIndex'](_0x2a2bd2){if(_0x2a2bd2===ye||this['indexMap_']['hasIndex'](_0x2a2bd2))return this;{const _0x1b928c=this['indexMap_']['addIndex'](_0x2a2bd2,this['children_']);return new g(this['children_'],this['priorityNode_'],_0x1b928c);}}['isIndexed'](_0x272e43){return _0x272e43===ye||this['indexMap_']['hasIndex'](_0x272e43);}['equals'](_0x5c52c6){if(_0x5c52c6===this)return!0x0;if(_0x5c52c6['isLeafNode']())return!0x1;{const _0x3c6e2b=_0x5c52c6;if(this['getPriority']()['equals'](_0x3c6e2b['getPriority']())){if(this['children_']['count']()===_0x3c6e2b['children_']['count']()){const _0x39e43a=this['getIterator'](R),_0x4fb333=_0x3c6e2b['getIterator'](R);let _0x5e6463=_0x39e43a['getNext'](),_0x464894=_0x4fb333['getNext']();for(;_0x5e6463&&_0x464894;){if(_0x5e6463['name']!==_0x464894['name']||!_0x5e6463['node']['equals'](_0x464894['node']))return!0x1;_0x5e6463=_0x39e43a['getNext'](),_0x464894=_0x4fb333['getNext']();}return _0x5e6463===null&&_0x464894===null;}else return!0x1;}else return!0x1;}}['resolveIndex_'](_0x38d55a){return _0x38d55a===ye?null:this['indexMap_']['get'](_0x38d55a['toString']());}}g['INTEGER_REGEXP_']=/^(0|[1-9]\d*)$/;class $h extends g{constructor(){super(new B(Yi),g['EMPTY_NODE'],te['Default']);}['compareTo'](_0x55bc27){return _0x55bc27===this?0x0:0x1;}['equals'](_0x3f1cb5){return _0x3f1cb5===this;}['getPriority'](){return this;}['getImmediateChild'](_0x3620d8){return g['EMPTY_NODE'];}['isEmpty'](){return!0x1;}}const $t=new $h();Object['defineProperties'](E,{'MIN':{'value':new E(Fe,g['EMPTY_NODE'])},'MAX':{'value':new E(Ie,$t)}}),ko['__EMPTY_NODE']=g['EMPTY_NODE'],D['__childrenNodeConstructor']=g,Fh($t),Wh($t);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Gh=!0x0;function P(_0x4ff7bf,_0x1d22db=null){if(_0x4ff7bf===null)return g['EMPTY_NODE'];if(typeof _0x4ff7bf=='object'&&'.priority'in _0x4ff7bf&&(_0x1d22db=_0x4ff7bf['.priority']),f(_0x1d22db===null||typeof _0x1d22db=='string'||typeof _0x1d22db=='number'||typeof _0x1d22db=='object'&&'.sv'in _0x1d22db,'Invalid\x20priority\x20type\x20found:\x20'+typeof _0x1d22db),typeof _0x4ff7bf=='object'&&'.value'in _0x4ff7bf&&_0x4ff7bf['.value']!==null&&(_0x4ff7bf=_0x4ff7bf['.value']),typeof _0x4ff7bf!='object'||'.sv'in _0x4ff7bf){const _0x3f3626=_0x4ff7bf;return new D(_0x3f3626,P(_0x1d22db));}if(!(_0x4ff7bf instanceof Array)&&Gh){const _0x466faf=[];let _0x516239=!0x1;if(x(_0x4ff7bf,(_0xf01a1,_0x5ac6fc)=>{if(_0xf01a1['substring'](0x0,0x1)!=='.'){const _0x14b426=P(_0x5ac6fc);_0x14b426['isEmpty']()||(_0x516239=_0x516239||!_0x14b426['getPriority']()['isEmpty'](),_0x466faf['push'](new E(_0xf01a1,_0x14b426)));}}),_0x466faf['length']===0x0)return g['EMPTY_NODE'];const _0x172f7c=fn(_0x466faf,xh,_0x30ccb1=>_0x30ccb1['name'],Yi);if(_0x516239){const _0x425969=fn(_0x466faf,R['getCompare']());return new g(_0x172f7c,P(_0x1d22db),new te({'.priority':_0x425969},{'.priority':R}));}else return new g(_0x172f7c,P(_0x1d22db),te['Default']);}else{let _0x210151=g['EMPTY_NODE'];return x(_0x4ff7bf,(_0x14c691,_0x3277f4)=>{if(J(_0x4ff7bf,_0x14c691)&&_0x14c691['substring'](0x0,0x1)!=='.'){const _0x4f3d3e=P(_0x3277f4);(_0x4f3d3e['isLeafNode']()||!_0x4f3d3e['isEmpty']())&&(_0x210151=_0x210151['updateImmediateChild'](_0x14c691,_0x4f3d3e));}}),_0x210151['updatePriority'](P(_0x1d22db));}}Uh(P);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qi extends Dn{constructor(_0x12b4c9){super(),this['indexPath_']=_0x12b4c9,f(!v(_0x12b4c9)&&y(_0x12b4c9)!=='.priority','Can\x27t\x20create\x20PathIndex\x20with\x20empty\x20path\x20or\x20.priority\x20key');}['extractChild'](_0x278c9e){return _0x278c9e['getChild'](this['indexPath_']);}['isDefinedOn'](_0x29f899){return!_0x29f899['getChild'](this['indexPath_'])['isEmpty']();}['compare'](_0x1d3edf,_0x24a12c){const _0x51e775=this['extractChild'](_0x1d3edf['node']),_0xe379c5=this['extractChild'](_0x24a12c['node']),_0x334d17=_0x51e775['compareTo'](_0xe379c5);return _0x334d17===0x0?He(_0x1d3edf['name'],_0x24a12c['name']):_0x334d17;}['makePost'](_0x568f96,_0x12ae0e){const _0x48c4c8=P(_0x568f96),_0xe1395c=g['EMPTY_NODE']['updateChild'](this['indexPath_'],_0x48c4c8);return new E(_0x12ae0e,_0xe1395c);}['maxPost'](){const _0x404f44=g['EMPTY_NODE']['updateChild'](this['indexPath_'],$t);return new E(Ie,_0x404f44);}['toString'](){return Pt(this['indexPath_'],0x0)['join']('/');}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qh extends Dn{['compare'](_0x486284,_0x430210){const _0x101edc=_0x486284['node']['compareTo'](_0x430210['node']);return _0x101edc===0x0?He(_0x486284['name'],_0x430210['name']):_0x101edc;}['isDefinedOn'](_0xeed7d1){return!0x0;}['indexedValueChanged'](_0x426c45,_0x372ba8){return!_0x426c45['equals'](_0x372ba8);}['minPost'](){return E['MIN'];}['maxPost'](){return E['MAX'];}['makePost'](_0x28412d,_0x17f7ff){const _0x4e6365=P(_0x28412d);return new E(_0x17f7ff,_0x4e6365);}['toString'](){return'.value';}}const Mo=new qh();/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Lo(_0x239e05){return{'type':'value','snapshotNode':_0x239e05};}function et(_0x3548c5,_0x5b047e){return{'type':'child_added','snapshotNode':_0x5b047e,'childName':_0x3548c5};}function Ot(_0x27dc66,_0x227991){return{'type':'child_removed','snapshotNode':_0x227991,'childName':_0x27dc66};}function Dt(_0xd727dd,_0xfaea1b,_0x451662){return{'type':'child_changed','snapshotNode':_0xfaea1b,'childName':_0xd727dd,'oldSnap':_0x451662};}function zh(_0x4a5527,_0x16cff4){return{'type':'child_moved','snapshotNode':_0x16cff4,'childName':_0x4a5527};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ji{constructor(_0x2944af){this['index_']=_0x2944af;}['updateChild'](_0x31056b,_0x15b874,_0x2aa678,_0x1cb032,_0x195528,_0x10a8e2){f(_0x31056b['isIndexed'](this['index_']),'A\x20node\x20must\x20be\x20indexed\x20if\x20only\x20a\x20child\x20is\x20updated');const _0x1bce6e=_0x31056b['getImmediateChild'](_0x15b874);return _0x1bce6e['getChild'](_0x1cb032)['equals'](_0x2aa678['getChild'](_0x1cb032))&&_0x1bce6e['isEmpty']()===_0x2aa678['isEmpty']()||(_0x10a8e2!=null&&(_0x2aa678['isEmpty']()?_0x31056b['hasChild'](_0x15b874)?_0x10a8e2['trackChildChange'](Ot(_0x15b874,_0x1bce6e)):f(_0x31056b['isLeafNode'](),'A\x20child\x20remove\x20without\x20an\x20old\x20child\x20only\x20makes\x20sense\x20on\x20a\x20leaf\x20node'):_0x1bce6e['isEmpty']()?_0x10a8e2['trackChildChange'](et(_0x15b874,_0x2aa678)):_0x10a8e2['trackChildChange'](Dt(_0x15b874,_0x2aa678,_0x1bce6e))),_0x31056b['isLeafNode']()&&_0x2aa678['isEmpty']())?_0x31056b:_0x31056b['updateImmediateChild'](_0x15b874,_0x2aa678)['withIndex'](this['index_']);}['updateFullNode'](_0xf97bfa,_0x5f0d50,_0x4a412f){return _0x4a412f!=null&&(_0xf97bfa['isLeafNode']()||_0xf97bfa['forEachChild'](R,(_0x4611a5,_0x434a90)=>{_0x5f0d50['hasChild'](_0x4611a5)||_0x4a412f['trackChildChange'](Ot(_0x4611a5,_0x434a90));}),_0x5f0d50['isLeafNode']()||_0x5f0d50['forEachChild'](R,(_0x26bd87,_0xa2b463)=>{if(_0xf97bfa['hasChild'](_0x26bd87)){const _0xe282b4=_0xf97bfa['getImmediateChild'](_0x26bd87);_0xe282b4['equals'](_0xa2b463)||_0x4a412f['trackChildChange'](Dt(_0x26bd87,_0xa2b463,_0xe282b4));}else _0x4a412f['trackChildChange'](et(_0x26bd87,_0xa2b463));})),_0x5f0d50['withIndex'](this['index_']);}['updatePriority'](_0x320b97,_0x565118){return _0x320b97['isEmpty']()?g['EMPTY_NODE']:_0x320b97['updatePriority'](_0x565118);}['filtersNodes'](){return!0x1;}['getIndexedFilter'](){return this;}['getIndex'](){return this['index_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Mt{constructor(_0x4aa6ab){this['indexedFilter_']=new Ji(_0x4aa6ab['getIndex']()),this['index_']=_0x4aa6ab['getIndex'](),this['startPost_']=Mt['getStartPost_'](_0x4aa6ab),this['endPost_']=Mt['getEndPost_'](_0x4aa6ab),this['startIsInclusive_']=!_0x4aa6ab['startAfterSet_'],this['endIsInclusive_']=!_0x4aa6ab['endBeforeSet_'];}['getStartPost'](){return this['startPost_'];}['getEndPost'](){return this['endPost_'];}['matches'](_0x30ca30){const _0x342ac3=this['startIsInclusive_']?this['index_']['compare'](this['getStartPost'](),_0x30ca30)<=0x0:this['index_']['compare'](this['getStartPost'](),_0x30ca30)<0x0,_0x3d4ce7=this['endIsInclusive_']?this['index_']['compare'](_0x30ca30,this['getEndPost']())<=0x0:this['index_']['compare'](_0x30ca30,this['getEndPost']())<0x0;return _0x342ac3&&_0x3d4ce7;}['updateChild'](_0xa83307,_0x8a09e6,_0x3e409f,_0x141885,_0x2c326e,_0x3ec721){return this['matches'](new E(_0x8a09e6,_0x3e409f))||(_0x3e409f=g['EMPTY_NODE']),this['indexedFilter_']['updateChild'](_0xa83307,_0x8a09e6,_0x3e409f,_0x141885,_0x2c326e,_0x3ec721);}['updateFullNode'](_0x40f418,_0x5de894,_0x100bac){_0x5de894['isLeafNode']()&&(_0x5de894=g['EMPTY_NODE']);let _0x36361a=_0x5de894['withIndex'](this['index_']);_0x36361a=_0x36361a['updatePriority'](g['EMPTY_NODE']);const _0x1bf09b=this;return _0x5de894['forEachChild'](R,(_0x1942f2,_0x3bf71f)=>{_0x1bf09b['matches'](new E(_0x1942f2,_0x3bf71f))||(_0x36361a=_0x36361a['updateImmediateChild'](_0x1942f2,g['EMPTY_NODE']));}),this['indexedFilter_']['updateFullNode'](_0x40f418,_0x36361a,_0x100bac);}['updatePriority'](_0x91a957,_0x7ff6a5){return _0x91a957;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['indexedFilter_'];}['getIndex'](){return this['index_'];}static['getStartPost_'](_0x16bd79){if(_0x16bd79['hasStart']()){const _0x3dd109=_0x16bd79['getIndexStartName']();return _0x16bd79['getIndex']()['makePost'](_0x16bd79['getIndexStartValue'](),_0x3dd109);}else return _0x16bd79['getIndex']()['minPost']();}static['getEndPost_'](_0xb5a9d6){if(_0xb5a9d6['hasEnd']()){const _0x18a7de=_0xb5a9d6['getIndexEndName']();return _0xb5a9d6['getIndex']()['makePost'](_0xb5a9d6['getIndexEndValue'](),_0x18a7de);}else return _0xb5a9d6['getIndex']()['maxPost']();}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class jh{constructor(_0xda1ea2){this['withinDirectionalStart']=_0x53b48a=>this['reverse_']?this['withinEndPost'](_0x53b48a):this['withinStartPost'](_0x53b48a),this['withinDirectionalEnd']=_0x55c4ce=>this['reverse_']?this['withinStartPost'](_0x55c4ce):this['withinEndPost'](_0x55c4ce),this['withinStartPost']=_0x39e5b6=>{const _0x156764=this['index_']['compare'](this['rangedFilter_']['getStartPost'](),_0x39e5b6);return this['startIsInclusive_']?_0x156764<=0x0:_0x156764<0x0;},this['withinEndPost']=_0x22c8d7=>{const _0x4af983=this['index_']['compare'](_0x22c8d7,this['rangedFilter_']['getEndPost']());return this['endIsInclusive_']?_0x4af983<=0x0:_0x4af983<0x0;},this['rangedFilter_']=new Mt(_0xda1ea2),this['index_']=_0xda1ea2['getIndex'](),this['limit_']=_0xda1ea2['getLimit'](),this['reverse_']=!_0xda1ea2['isViewFromLeft'](),this['startIsInclusive_']=!_0xda1ea2['startAfterSet_'],this['endIsInclusive_']=!_0xda1ea2['endBeforeSet_'];}['updateChild'](_0x21ddbf,_0x5f5dca,_0x457ce2,_0x358ad7,_0x379d53,_0x4411cd){return this['rangedFilter_']['matches'](new E(_0x5f5dca,_0x457ce2))||(_0x457ce2=g['EMPTY_NODE']),_0x21ddbf['getImmediateChild'](_0x5f5dca)['equals'](_0x457ce2)?_0x21ddbf:_0x21ddbf['numChildren']()<this['limit_']?this['rangedFilter_']['getIndexedFilter']()['updateChild'](_0x21ddbf,_0x5f5dca,_0x457ce2,_0x358ad7,_0x379d53,_0x4411cd):this['fullLimitUpdateChild_'](_0x21ddbf,_0x5f5dca,_0x457ce2,_0x379d53,_0x4411cd);}['updateFullNode'](_0x52e67b,_0x47f354,_0x3d480e){let _0x17cd71;if(_0x47f354['isLeafNode']()||_0x47f354['isEmpty']())_0x17cd71=g['EMPTY_NODE']['withIndex'](this['index_']);else{if(this['limit_']*0x2<_0x47f354['numChildren']()&&_0x47f354['isIndexed'](this['index_'])){_0x17cd71=g['EMPTY_NODE']['withIndex'](this['index_']);let _0x314e8f;this['reverse_']?_0x314e8f=_0x47f354['getReverseIteratorFrom'](this['rangedFilter_']['getEndPost'](),this['index_']):_0x314e8f=_0x47f354['getIteratorFrom'](this['rangedFilter_']['getStartPost'](),this['index_']);let _0x18ab93=0x0;for(;_0x314e8f['hasNext']()&&_0x18ab93<this['limit_'];){const _0x2eb1eb=_0x314e8f['getNext']();if(this['withinDirectionalStart'](_0x2eb1eb)){if(this['withinDirectionalEnd'](_0x2eb1eb))_0x17cd71=_0x17cd71['updateImmediateChild'](_0x2eb1eb['name'],_0x2eb1eb['node']),_0x18ab93++;else break;}else continue;}}else{_0x17cd71=_0x47f354['withIndex'](this['index_']),_0x17cd71=_0x17cd71['updatePriority'](g['EMPTY_NODE']);let _0x45f545;this['reverse_']?_0x45f545=_0x17cd71['getReverseIterator'](this['index_']):_0x45f545=_0x17cd71['getIterator'](this['index_']);let _0xeb791c=0x0;for(;_0x45f545['hasNext']();){const _0x191934=_0x45f545['getNext']();_0xeb791c<this['limit_']&&this['withinDirectionalStart'](_0x191934)&&this['withinDirectionalEnd'](_0x191934)?_0xeb791c++:_0x17cd71=_0x17cd71['updateImmediateChild'](_0x191934['name'],g['EMPTY_NODE']);}}}return this['rangedFilter_']['getIndexedFilter']()['updateFullNode'](_0x52e67b,_0x17cd71,_0x3d480e);}['updatePriority'](_0x3a635f,_0x50337d){return _0x3a635f;}['filtersNodes'](){return!0x0;}['getIndexedFilter'](){return this['rangedFilter_']['getIndexedFilter']();}['getIndex'](){return this['index_'];}['fullLimitUpdateChild_'](_0x5d1711,_0x1eada4,_0x332cd8,_0x4530c0,_0x425c55){let _0x2c8200;if(this['reverse_']){const _0x4de1a2=this['index_']['getCompare']();_0x2c8200=(_0x29b0de,_0x551ec9)=>_0x4de1a2(_0x551ec9,_0x29b0de);}else _0x2c8200=this['index_']['getCompare']();const _0x5e5217=_0x5d1711;f(_0x5e5217['numChildren']()===this['limit_'],'');const _0x5431df=new E(_0x1eada4,_0x332cd8),_0x505593=this['reverse_']?_0x5e5217['getFirstChild'](this['index_']):_0x5e5217['getLastChild'](this['index_']),_0x2138eb=this['rangedFilter_']['matches'](_0x5431df);if(_0x5e5217['hasChild'](_0x1eada4)){const _0xe447eb=_0x5e5217['getImmediateChild'](_0x1eada4);let _0x480f81=_0x4530c0['getChildAfterChild'](this['index_'],_0x505593,this['reverse_']);for(;_0x480f81!=null&&(_0x480f81['name']===_0x1eada4||_0x5e5217['hasChild'](_0x480f81['name']));)_0x480f81=_0x4530c0['getChildAfterChild'](this['index_'],_0x480f81,this['reverse_']);const _0x414fbe=_0x480f81==null?0x1:_0x2c8200(_0x480f81,_0x5431df);if(_0x2138eb&&!_0x332cd8['isEmpty']()&&_0x414fbe>=0x0)return _0x425c55!=null&&_0x425c55['trackChildChange'](Dt(_0x1eada4,_0x332cd8,_0xe447eb)),_0x5e5217['updateImmediateChild'](_0x1eada4,_0x332cd8);{_0x425c55!=null&&_0x425c55['trackChildChange'](Ot(_0x1eada4,_0xe447eb));const _0x47f23a=_0x5e5217['updateImmediateChild'](_0x1eada4,g['EMPTY_NODE']);return _0x480f81!=null&&this['rangedFilter_']['matches'](_0x480f81)?(_0x425c55!=null&&_0x425c55['trackChildChange'](et(_0x480f81['name'],_0x480f81['node'])),_0x47f23a['updateImmediateChild'](_0x480f81['name'],_0x480f81['node'])):_0x47f23a;}}else return _0x332cd8['isEmpty']()?_0x5d1711:_0x2138eb&&_0x2c8200(_0x505593,_0x5431df)>=0x0?(_0x425c55!=null&&(_0x425c55['trackChildChange'](Ot(_0x505593['name'],_0x505593['node'])),_0x425c55['trackChildChange'](et(_0x1eada4,_0x332cd8))),_0x5e5217['updateImmediateChild'](_0x1eada4,_0x332cd8)['updateImmediateChild'](_0x505593['name'],g['EMPTY_NODE'])):_0x5d1711;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xi{constructor(){this['limitSet_']=!0x1,this['startSet_']=!0x1,this['startNameSet_']=!0x1,this['startAfterSet_']=!0x1,this['endSet_']=!0x1,this['endNameSet_']=!0x1,this['endBeforeSet_']=!0x1,this['limit_']=0x0,this['viewFrom_']='',this['indexStartValue_']=null,this['indexStartName_']='',this['indexEndValue_']=null,this['indexEndName_']='',this['index_']=R;}['hasStart'](){return this['startSet_'];}['isViewFromLeft'](){return this['viewFrom_']===''?this['startSet_']:this['viewFrom_']==='l';}['getIndexStartValue'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['indexStartValue_'];}['getIndexStartName'](){return f(this['startSet_'],'Only\x20valid\x20if\x20start\x20has\x20been\x20set'),this['startNameSet_']?this['indexStartName_']:Fe;}['hasEnd'](){return this['endSet_'];}['getIndexEndValue'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['indexEndValue_'];}['getIndexEndName'](){return f(this['endSet_'],'Only\x20valid\x20if\x20end\x20has\x20been\x20set'),this['endNameSet_']?this['indexEndName_']:Ie;}['hasLimit'](){return this['limitSet_'];}['hasAnchoredLimit'](){return this['limitSet_']&&this['viewFrom_']!=='';}['getLimit'](){return f(this['limitSet_'],'Only\x20valid\x20if\x20limit\x20has\x20been\x20set'),this['limit_'];}['getIndex'](){return this['index_'];}['loadsAllData'](){return!(this['startSet_']||this['endSet_']||this['limitSet_']);}['isDefault'](){return this['loadsAllData']()&&this['index_']===R;}['copy'](){const _0x20f632=new Xi();return _0x20f632['limitSet_']=this['limitSet_'],_0x20f632['limit_']=this['limit_'],_0x20f632['startSet_']=this['startSet_'],_0x20f632['startAfterSet_']=this['startAfterSet_'],_0x20f632['indexStartValue_']=this['indexStartValue_'],_0x20f632['startNameSet_']=this['startNameSet_'],_0x20f632['indexStartName_']=this['indexStartName_'],_0x20f632['endSet_']=this['endSet_'],_0x20f632['endBeforeSet_']=this['endBeforeSet_'],_0x20f632['indexEndValue_']=this['indexEndValue_'],_0x20f632['endNameSet_']=this['endNameSet_'],_0x20f632['indexEndName_']=this['indexEndName_'],_0x20f632['index_']=this['index_'],_0x20f632['viewFrom_']=this['viewFrom_'],_0x20f632;}}function Kh(_0x3485f9){return _0x3485f9['loadsAllData']()?new Ji(_0x3485f9['getIndex']()):_0x3485f9['hasLimit']()?new jh(_0x3485f9):new Mt(_0x3485f9);}function Yh(_0x3c81f6,_0x72290c){const _0x3cf854=_0x3c81f6['copy']();return _0x3cf854['limitSet_']=!0x0,_0x3cf854['limit_']=_0x72290c,_0x3cf854['viewFrom_']='l',_0x3cf854;}function Qh(_0x4bb772,_0x48b088,_0x408f64){const _0x31a0b5=_0x4bb772['copy']();return _0x31a0b5['startSet_']=!0x0,_0x48b088===void 0x0&&(_0x48b088=null),_0x31a0b5['indexStartValue_']=_0x48b088,_0x408f64!=null?(_0x31a0b5['startNameSet_']=!0x0,_0x31a0b5['indexStartName_']=_0x408f64):(_0x31a0b5['startNameSet_']=!0x1,_0x31a0b5['indexStartName_']=''),_0x31a0b5;}function Jh(_0xcd78b5,_0x4988a9,_0x3cf2bc){const _0x2f2d9c=_0xcd78b5['copy']();return _0x2f2d9c['endSet_']=!0x0,_0x4988a9===void 0x0&&(_0x4988a9=null),_0x2f2d9c['indexEndValue_']=_0x4988a9,_0x3cf2bc!==void 0x0?(_0x2f2d9c['endNameSet_']=!0x0,_0x2f2d9c['indexEndName_']=_0x3cf2bc):(_0x2f2d9c['endNameSet_']=!0x1,_0x2f2d9c['indexEndName_']=''),_0x2f2d9c;}function xo(_0x521361,_0xda4a83){const _0x36424d=_0x521361['copy']();return _0x36424d['index_']=_0xda4a83,_0x36424d;}function sr(_0xb6c35c){const _0x113078={};if(_0xb6c35c['isDefault']())return _0x113078;let _0x47e478;if(_0xb6c35c['index_']===R?_0x47e478='$priority':_0xb6c35c['index_']===Mo?_0x47e478='$value':_0xb6c35c['index_']===ye?_0x47e478='$key':(f(_0xb6c35c['index_']instanceof Qi,'Unrecognized\x20index\x20type!'),_0x47e478=_0xb6c35c['index_']['toString']()),_0x113078['orderBy']=O(_0x47e478),_0xb6c35c['startSet_']){const _0x20c815=_0xb6c35c['startAfterSet_']?'startAfter':'startAt';_0x113078[_0x20c815]=O(_0xb6c35c['indexStartValue_']),_0xb6c35c['startNameSet_']&&(_0x113078[_0x20c815]+=','+O(_0xb6c35c['indexStartName_']));}if(_0xb6c35c['endSet_']){const _0x22528e=_0xb6c35c['endBeforeSet_']?'endBefore':'endAt';_0x113078[_0x22528e]=O(_0xb6c35c['indexEndValue_']),_0xb6c35c['endNameSet_']&&(_0x113078[_0x22528e]+=','+O(_0xb6c35c['indexEndName_']));}return _0xb6c35c['limitSet_']&&(_0xb6c35c['isViewFromLeft']()?_0x113078['limitToFirst']=_0xb6c35c['limit_']:_0x113078['limitToLast']=_0xb6c35c['limit_']),_0x113078;}function rr(_0x36eb30){const _0x23f59d={};if(_0x36eb30['startSet_']&&(_0x23f59d['sp']=_0x36eb30['indexStartValue_'],_0x36eb30['startNameSet_']&&(_0x23f59d['sn']=_0x36eb30['indexStartName_']),_0x23f59d['sin']=!_0x36eb30['startAfterSet_']),_0x36eb30['endSet_']&&(_0x23f59d['ep']=_0x36eb30['indexEndValue_'],_0x36eb30['endNameSet_']&&(_0x23f59d['en']=_0x36eb30['indexEndName_']),_0x23f59d['ein']=!_0x36eb30['endBeforeSet_']),_0x36eb30['limitSet_']){_0x23f59d['l']=_0x36eb30['limit_'];let _0x4f6f29=_0x36eb30['viewFrom_'];_0x4f6f29===''&&(_0x36eb30['isViewFromLeft']()?_0x4f6f29='l':_0x4f6f29='r'),_0x23f59d['vf']=_0x4f6f29;}return _0x36eb30['index_']!==R&&(_0x23f59d['i']=_0x36eb30['index_']['toString']()),_0x23f59d;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pn extends So{['reportStats'](_0x1795df){throw new Error('Method\x20not\x20implemented.');}static['getListenId_'](_0x1a06d5,_0x22327b){return _0x22327b!==void 0x0?'tag$'+_0x22327b:(f(_0x1a06d5['_queryParams']['isDefault'](),'should\x20have\x20a\x20tag\x20if\x20it\x27s\x20not\x20a\x20default\x20query.'),_0x1a06d5['_path']['toString']());}constructor(_0x292731,_0x235a49,_0x3779df,_0x5144b9){super(),this['repoInfo_']=_0x292731,this['onDataUpdate_']=_0x235a49,this['authTokenProvider_']=_0x3779df,this['appCheckTokenProvider_']=_0x5144b9,this['log_']=Ht('p:rest:'),this['listens_']={};}['listen'](_0xc77602,_0x398950,_0x4c74f6,_0x221e71){const _0x3ae50f=_0xc77602['_path']['toString']();this['log_']('Listen\x20called\x20for\x20'+_0x3ae50f+'\x20'+_0xc77602['_queryIdentifier']);const _0x371bf8=pn['getListenId_'](_0xc77602,_0x4c74f6),_0x57b0ec={};this['listens_'][_0x371bf8]=_0x57b0ec;const _0x240c10=sr(_0xc77602['_queryParams']);this['restRequest_'](_0x3ae50f+'.json',_0x240c10,(_0x2121f8,_0x4aed9c)=>{let _0x216b52=_0x4aed9c;if(_0x2121f8===0x194&&(_0x216b52=null,_0x2121f8=null),_0x2121f8===null&&this['onDataUpdate_'](_0x3ae50f,_0x216b52,!0x1,_0x4c74f6),De(this['listens_'],_0x371bf8)===_0x57b0ec){let _0x5db325;_0x2121f8?_0x2121f8===0x191?_0x5db325='permission_denied':_0x5db325='rest_error:'+_0x2121f8:_0x5db325='ok',_0x221e71(_0x5db325,null);}});}['unlisten'](_0x3ec54c,_0x517809){const _0x110d4e=pn['getListenId_'](_0x3ec54c,_0x517809);delete this['listens_'][_0x110d4e];}['get'](_0x1b82f5){const _0x2bbe3e=sr(_0x1b82f5['_queryParams']),_0x65e787=_0x1b82f5['_path']['toString'](),_0x5818dc=new ot();return this['restRequest_'](_0x65e787+'.json',_0x2bbe3e,(_0x36fe0b,_0x390bd8)=>{let _0x3064b0=_0x390bd8;_0x36fe0b===0x194&&(_0x3064b0=null,_0x36fe0b=null),_0x36fe0b===null?(this['onDataUpdate_'](_0x65e787,_0x3064b0,!0x1,null),_0x5818dc['resolve'](_0x3064b0)):_0x5818dc['reject'](new Error(_0x3064b0));}),_0x5818dc['promise'];}['refreshAuthToken'](_0x274b8d){}['restRequest_'](_0x5273ca,_0x41a914={},_0x4662fe){return _0x41a914['format']='export',Promise['all']([this['authTokenProvider_']['getToken'](!0x1),this['appCheckTokenProvider_']['getToken'](!0x1)])['then'](([_0x187b61,_0x26d34f])=>{_0x187b61&&_0x187b61['accessToken']&&(_0x41a914['auth']=_0x187b61['accessToken']),_0x26d34f&&_0x26d34f['token']&&(_0x41a914['ac']=_0x26d34f['token']);const _0xfaf892=(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host']+_0x5273ca+'?ns='+this['repoInfo_']['namespace']+ct(_0x41a914);this['log_']('Sending\x20REST\x20request\x20for\x20'+_0xfaf892);const _0xa0c612=new XMLHttpRequest();_0xa0c612['onreadystatechange']=()=>{if(_0x4662fe&&_0xa0c612['readyState']===0x4){this['log_']('REST\x20Response\x20for\x20'+_0xfaf892+'\x20received.\x20status:',_0xa0c612['status'],'response:',_0xa0c612['responseText']);let _0x26e051=null;if(_0xa0c612['status']>=0xc8&&_0xa0c612['status']<0x12c){try{_0x26e051=At(_0xa0c612['responseText']);}catch{U('Failed\x20to\x20parse\x20JSON\x20response\x20for\x20'+_0xfaf892+':\x20'+_0xa0c612['responseText']);}_0x4662fe(null,_0x26e051);}else _0xa0c612['status']!==0x191&&_0xa0c612['status']!==0x194&&U('Got\x20unsuccessful\x20REST\x20response\x20for\x20'+_0xfaf892+'\x20Status:\x20'+_0xa0c612['status']),_0x4662fe(_0xa0c612['status']);_0x4662fe=null;}},_0xa0c612['open']('GET',_0xfaf892,!0x0),_0xa0c612['send']();});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Xh{constructor(){this['rootNode_']=g['EMPTY_NODE'];}['getNode'](_0x1f2045){return this['rootNode_']['getChild'](_0x1f2045);}['updateSnapshot'](_0x31ba8a,_0x231659){this['rootNode_']=this['rootNode_']['updateChild'](_0x31ba8a,_0x231659);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function _n(){return{'value':null,'children':new Map()};}function Fo(_0x43c356,_0x14e73c,_0x4129a3){if(v(_0x14e73c))_0x43c356['value']=_0x4129a3,_0x43c356['children']['clear']();else{if(_0x43c356['value']!==null)_0x43c356['value']=_0x43c356['value']['updateChild'](_0x14e73c,_0x4129a3);else{const _0x50c9c3=y(_0x14e73c);_0x43c356['children']['has'](_0x50c9c3)||_0x43c356['children']['set'](_0x50c9c3,_n());const _0x320e21=_0x43c356['children']['get'](_0x50c9c3);_0x14e73c=b(_0x14e73c),Fo(_0x320e21,_0x14e73c,_0x4129a3);}}}function Ii(_0x29ceab,_0x15bae5,_0xd5d16d){_0x29ceab['value']!==null?_0xd5d16d(_0x15bae5,_0x29ceab['value']):Zh(_0x29ceab,(_0x43cf88,_0x546c60)=>{const _0x1d77e3=new C(_0x15bae5['toString']()+'/'+_0x43cf88);Ii(_0x546c60,_0x1d77e3,_0xd5d16d);});}function Zh(_0x526a25,_0x51fbb7){_0x526a25['children']['forEach']((_0x3b2ab7,_0x162d75)=>{_0x51fbb7(_0x162d75,_0x3b2ab7);});}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class eu{constructor(_0x3dc0cd){this['collection_']=_0x3dc0cd,this['last_']=null;}['get'](){const _0x2da7ee=this['collection_']['get'](),_0x1e1f3a={..._0x2da7ee};return this['last_']&&x(this['last_'],(_0x21ab11,_0x438ec6)=>{_0x1e1f3a[_0x21ab11]=_0x1e1f3a[_0x21ab11]-_0x438ec6;}),this['last_']=_0x2da7ee,_0x1e1f3a;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const or=0xa*0x3e8,tu=0x1e*0x3e8,nu=0x12c*0x3e8;class iu{constructor(_0x4132e7,_0x4ef36a){this['server_']=_0x4ef36a,this['statsToReport_']={},this['statsListener_']=new eu(_0x4132e7);const _0x90560c=or+(tu-or)*Math['random']();Ct(this['reportStats_']['bind'](this),Math['floor'](_0x90560c));}['reportStats_'](){const _0x4bc599=this['statsListener_']['get'](),_0x282b21={};let _0x258ad6=!0x1;x(_0x4bc599,(_0x421192,_0x465687)=>{_0x465687>0x0&&J(this['statsToReport_'],_0x421192)&&(_0x282b21[_0x421192]=_0x465687,_0x258ad6=!0x0);}),_0x258ad6&&this['server_']['reportStats'](_0x282b21),Ct(this['reportStats_']['bind'](this),Math['floor'](Math['random']()*0x2*nu));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var j;(function(_0x50f27f){_0x50f27f[_0x50f27f['OVERWRITE']=0x0]='OVERWRITE',_0x50f27f[_0x50f27f['MERGE']=0x1]='MERGE',_0x50f27f[_0x50f27f['ACK_USER_WRITE']=0x2]='ACK_USER_WRITE',_0x50f27f[_0x50f27f['LISTEN_COMPLETE']=0x3]='LISTEN_COMPLETE';}(j||(j={})));function Zi(){return{'fromUser':!0x0,'fromServer':!0x1,'queryId':null,'tagged':!0x1};}function es(){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':null,'tagged':!0x1};}function ts(_0x22ccf5){return{'fromUser':!0x1,'fromServer':!0x0,'queryId':_0x22ccf5,'tagged':!0x0};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gn{constructor(_0xb1c8b1,_0x1a181a,_0x4169a5){this['path']=_0xb1c8b1,this['affectedTree']=_0x1a181a,this['revert']=_0x4169a5,this['type']=j['ACK_USER_WRITE'],this['source']=Zi();}['operationForChild'](_0x1190e5){if(v(this['path'])){if(this['affectedTree']['value']!=null)return f(this['affectedTree']['children']['isEmpty'](),'affectedTree\x20should\x20not\x20have\x20overlapping\x20affected\x20paths.'),this;{const _0xdfcd6f=this['affectedTree']['subtree'](new C(_0x1190e5));return new gn(w(),_0xdfcd6f,this['revert']);}}else return f(y(this['path'])===_0x1190e5,'operationForChild\x20called\x20for\x20unrelated\x20child.'),new gn(b(this['path']),this['affectedTree'],this['revert']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Lt{constructor(_0x363105,_0x3ecbc4){this['source']=_0x363105,this['path']=_0x3ecbc4,this['type']=j['LISTEN_COMPLETE'];}['operationForChild'](_0x29f79e){return v(this['path'])?new Lt(this['source'],w()):new Lt(this['source'],b(this['path']));}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ue{constructor(_0x19a3f6,_0x2d64cc,_0x1905be){this['source']=_0x19a3f6,this['path']=_0x2d64cc,this['snap']=_0x1905be,this['type']=j['OVERWRITE'];}['operationForChild'](_0x4fa6ca){return v(this['path'])?new Ue(this['source'],w(),this['snap']['getImmediateChild'](_0x4fa6ca)):new Ue(this['source'],b(this['path']),this['snap']);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tt{constructor(_0x5577c8,_0x6d5615,_0x1b8f2f){this['source']=_0x5577c8,this['path']=_0x6d5615,this['children']=_0x1b8f2f,this['type']=j['MERGE'];}['operationForChild'](_0x5b3c90){if(v(this['path'])){const _0xadb18a=this['children']['subtree'](new C(_0x5b3c90));return _0xadb18a['isEmpty']()?null:_0xadb18a['value']?new Ue(this['source'],w(),_0xadb18a['value']):new tt(this['source'],w(),_0xadb18a);}else return f(y(this['path'])===_0x5b3c90,'Can\x27t\x20get\x20a\x20merge\x20for\x20a\x20child\x20not\x20on\x20the\x20path\x20of\x20the\x20operation'),new tt(this['source'],b(this['path']),this['children']);}['toString'](){return'Operation('+this['path']+':\x20'+this['source']['toString']()+'\x20merge:\x20'+this['children']['toString']()+')';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ce{constructor(_0x32b602,_0x8723d3,_0x42b313){this['node_']=_0x32b602,this['fullyInitialized_']=_0x8723d3,this['filtered_']=_0x42b313;}['isFullyInitialized'](){return this['fullyInitialized_'];}['isFiltered'](){return this['filtered_'];}['isCompleteForPath'](_0x38163f){if(v(_0x38163f))return this['isFullyInitialized']()&&!this['filtered_'];const _0x1ee16e=y(_0x38163f);return this['isCompleteForChild'](_0x1ee16e);}['isCompleteForChild'](_0x57653b){return this['isFullyInitialized']()&&!this['filtered_']||this['node_']['hasChild'](_0x57653b);}['getNode'](){return this['node_'];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class su{constructor(_0x1080f6){this['query_']=_0x1080f6,this['index_']=this['query_']['_queryParams']['getIndex']();}}function ru(_0x4960e6,_0x5578bf,_0x3b9497,_0xb71271){const _0x22ce02=[],_0x2fd631=[];return _0x5578bf['forEach'](_0x44898e=>{_0x44898e['type']==='child_changed'&&_0x4960e6['index_']['indexedValueChanged'](_0x44898e['oldSnap'],_0x44898e['snapshotNode'])&&_0x2fd631['push'](zh(_0x44898e['childName'],_0x44898e['snapshotNode']));}),yt(_0x4960e6,_0x22ce02,'child_removed',_0x5578bf,_0xb71271,_0x3b9497),yt(_0x4960e6,_0x22ce02,'child_added',_0x5578bf,_0xb71271,_0x3b9497),yt(_0x4960e6,_0x22ce02,'child_moved',_0x2fd631,_0xb71271,_0x3b9497),yt(_0x4960e6,_0x22ce02,'child_changed',_0x5578bf,_0xb71271,_0x3b9497),yt(_0x4960e6,_0x22ce02,'value',_0x5578bf,_0xb71271,_0x3b9497),_0x22ce02;}function yt(_0x5ddec2,_0x1537a5,_0x5efc2,_0x26a1a9,_0x22e05b,_0x39246d){const _0x560824=_0x26a1a9['filter'](_0x58c900=>_0x58c900['type']===_0x5efc2);_0x560824['sort']((_0x1d6107,_0x504da5)=>au(_0x5ddec2,_0x1d6107,_0x504da5)),_0x560824['forEach'](_0x338edf=>{const _0x494ca1=ou(_0x5ddec2,_0x338edf,_0x39246d);_0x22e05b['forEach'](_0x2e48df=>{_0x2e48df['respondsTo'](_0x338edf['type'])&&_0x1537a5['push'](_0x2e48df['createEvent'](_0x494ca1,_0x5ddec2['query_']));});});}function ou(_0x75e9a4,_0x51f308,_0xdde627){return _0x51f308['type']==='value'||_0x51f308['type']==='child_removed'||(_0x51f308['prevName']=_0xdde627['getPredecessorChildName'](_0x51f308['childName'],_0x51f308['snapshotNode'],_0x75e9a4['index_'])),_0x51f308;}function au(_0x11ca9e,_0x55340d,_0x439f9b){if(_0x55340d['childName']==null||_0x439f9b['childName']==null)throw rt('Should\x20only\x20compare\x20child_\x20events.');const _0x2afab6=new E(_0x55340d['childName'],_0x55340d['snapshotNode']),_0x3de218=new E(_0x439f9b['childName'],_0x439f9b['snapshotNode']);return _0x11ca9e['index_']['compare'](_0x2afab6,_0x3de218);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Mn(_0x1b234,_0x25c7bf){return{'eventCache':_0x1b234,'serverCache':_0x25c7bf};}function Tt(_0x737429,_0xbb53e5,_0x427ca0,_0x6f29a0){return Mn(new Ce(_0xbb53e5,_0x427ca0,_0x6f29a0),_0x737429['serverCache']);}function Uo(_0xddec81,_0x5bcaeb,_0x45f5cf,_0x23a75c){return Mn(_0xddec81['eventCache'],new Ce(_0x5bcaeb,_0x45f5cf,_0x23a75c));}function mn(_0x351e22){return _0x351e22['eventCache']['isFullyInitialized']()?_0x351e22['eventCache']['getNode']():null;}function We(_0xdf0ca3){return _0xdf0ca3['serverCache']['isFullyInitialized']()?_0xdf0ca3['serverCache']['getNode']():null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let oi;const cu=()=>(oi||(oi=new B(ql)),oi);class S{static['fromObject'](_0x27e2a3){let _0x1e90d1=new S(null);return x(_0x27e2a3,(_0x56ca4d,_0x140ac5)=>{_0x1e90d1=_0x1e90d1['set'](new C(_0x56ca4d),_0x140ac5);}),_0x1e90d1;}constructor(_0x38665f,_0x3b3077=cu()){this['value']=_0x38665f,this['children']=_0x3b3077;}['isEmpty'](){return this['value']===null&&this['children']['isEmpty']();}['findRootMostMatchingPathAndValue'](_0x1758b4,_0xbb5a8){if(this['value']!=null&&_0xbb5a8(this['value']))return{'path':w(),'value':this['value']};if(v(_0x1758b4))return null;{const _0x50e290=y(_0x1758b4),_0x1e1439=this['children']['get'](_0x50e290);if(_0x1e1439!==null){const _0x2679ff=_0x1e1439['findRootMostMatchingPathAndValue'](b(_0x1758b4),_0xbb5a8);return _0x2679ff!=null?{'path':k(new C(_0x50e290),_0x2679ff['path']),'value':_0x2679ff['value']}:null;}else return null;}}['findRootMostValueAndPath'](_0x3f7105){return this['findRootMostMatchingPathAndValue'](_0x3f7105,()=>!0x0);}['subtree'](_0x1eef87){if(v(_0x1eef87))return this;{const _0x13ac1d=y(_0x1eef87),_0x27bdd3=this['children']['get'](_0x13ac1d);return _0x27bdd3!==null?_0x27bdd3['subtree'](b(_0x1eef87)):new S(null);}}['set'](_0x3c2558,_0x3679db){if(v(_0x3c2558))return new S(_0x3679db,this['children']);{const _0x535b9d=y(_0x3c2558),_0x224b48=(this['children']['get'](_0x535b9d)||new S(null))['set'](b(_0x3c2558),_0x3679db),_0x8f15=this['children']['insert'](_0x535b9d,_0x224b48);return new S(this['value'],_0x8f15);}}['remove'](_0x2e60bc){if(v(_0x2e60bc))return this['children']['isEmpty']()?new S(null):new S(null,this['children']);{const _0x5e60e3=y(_0x2e60bc),_0xc51fd8=this['children']['get'](_0x5e60e3);if(_0xc51fd8){const _0xac27ba=_0xc51fd8['remove'](b(_0x2e60bc));let _0x6662d5;return _0xac27ba['isEmpty']()?_0x6662d5=this['children']['remove'](_0x5e60e3):_0x6662d5=this['children']['insert'](_0x5e60e3,_0xac27ba),this['value']===null&&_0x6662d5['isEmpty']()?new S(null):new S(this['value'],_0x6662d5);}else return this;}}['get'](_0x43bda3){if(v(_0x43bda3))return this['value'];{const _0x1da53c=y(_0x43bda3),_0x5f37cb=this['children']['get'](_0x1da53c);return _0x5f37cb?_0x5f37cb['get'](b(_0x43bda3)):null;}}['setTree'](_0x3b5011,_0x18a8c3){if(v(_0x3b5011))return _0x18a8c3;{const _0x426aaa=y(_0x3b5011),_0x3f4fc1=(this['children']['get'](_0x426aaa)||new S(null))['setTree'](b(_0x3b5011),_0x18a8c3);let _0x3e2ac3;return _0x3f4fc1['isEmpty']()?_0x3e2ac3=this['children']['remove'](_0x426aaa):_0x3e2ac3=this['children']['insert'](_0x426aaa,_0x3f4fc1),new S(this['value'],_0x3e2ac3);}}['fold'](_0x2ad2e5){return this['fold_'](w(),_0x2ad2e5);}['fold_'](_0x510523,_0x28deef){const _0x379eca={};return this['children']['inorderTraversal']((_0xa9e770,_0x32e936)=>{_0x379eca[_0xa9e770]=_0x32e936['fold_'](k(_0x510523,_0xa9e770),_0x28deef);}),_0x28deef(_0x510523,this['value'],_0x379eca);}['findOnPath'](_0x14bcaf,_0x34ffda){return this['findOnPath_'](_0x14bcaf,w(),_0x34ffda);}['findOnPath_'](_0x24b564,_0x902ad5,_0x5522ce){const _0x2adf3b=this['value']?_0x5522ce(_0x902ad5,this['value']):!0x1;if(_0x2adf3b)return _0x2adf3b;if(v(_0x24b564))return null;{const _0x1473d7=y(_0x24b564),_0x455edf=this['children']['get'](_0x1473d7);return _0x455edf?_0x455edf['findOnPath_'](b(_0x24b564),k(_0x902ad5,_0x1473d7),_0x5522ce):null;}}['foreachOnPath'](_0x140535,_0x1167d7){return this['foreachOnPath_'](_0x140535,w(),_0x1167d7);}['foreachOnPath_'](_0x5c3e2b,_0x331b34,_0xdb28b7){if(v(_0x5c3e2b))return this;{this['value']&&_0xdb28b7(_0x331b34,this['value']);const _0x54ff75=y(_0x5c3e2b),_0x145da7=this['children']['get'](_0x54ff75);return _0x145da7?_0x145da7['foreachOnPath_'](b(_0x5c3e2b),k(_0x331b34,_0x54ff75),_0xdb28b7):new S(null);}}['foreach'](_0x29fa59){this['foreach_'](w(),_0x29fa59);}['foreach_'](_0xbff648,_0x5256ce){this['children']['inorderTraversal']((_0x233333,_0x25c567)=>{_0x25c567['foreach_'](k(_0xbff648,_0x233333),_0x5256ce);}),this['value']&&_0x5256ce(_0xbff648,this['value']);}['foreachChild'](_0x3cddd4){this['children']['inorderTraversal']((_0x1aca49,_0x559f9e)=>{_0x559f9e['value']&&_0x3cddd4(_0x1aca49,_0x559f9e['value']);});}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Y{constructor(_0x184211){this['writeTree_']=_0x184211;}static['empty'](){return new Y(new S(null));}}function St(_0x14df6c,_0x355520,_0x26623f){if(v(_0x355520))return new Y(new S(_0x26623f));{const _0x1c5c95=_0x14df6c['writeTree_']['findRootMostValueAndPath'](_0x355520);if(_0x1c5c95!=null){const _0x39eec4=_0x1c5c95['path'];let _0x2f5edd=_0x1c5c95['value'];const _0x1b59d1=F(_0x39eec4,_0x355520);return _0x2f5edd=_0x2f5edd['updateChild'](_0x1b59d1,_0x26623f),new Y(_0x14df6c['writeTree_']['set'](_0x39eec4,_0x2f5edd));}else{const _0x4680d6=new S(_0x26623f),_0x391db9=_0x14df6c['writeTree_']['setTree'](_0x355520,_0x4680d6);return new Y(_0x391db9);}}}function wi(_0x2c5098,_0x342452,_0x434bf8){let _0x270594=_0x2c5098;return x(_0x434bf8,(_0x226ed3,_0x3026f0)=>{_0x270594=St(_0x270594,k(_0x342452,_0x226ed3),_0x3026f0);}),_0x270594;}function ar(_0x3d6832,_0x1d12fe){if(v(_0x1d12fe))return Y['empty']();{const _0x42b572=_0x3d6832['writeTree_']['setTree'](_0x1d12fe,new S(null));return new Y(_0x42b572);}}function Ci(_0x19b592,_0x3cd079){return $e(_0x19b592,_0x3cd079)!=null;}function $e(_0x367f78,_0x3b6df4){const _0xd809ab=_0x367f78['writeTree_']['findRootMostValueAndPath'](_0x3b6df4);return _0xd809ab!=null?_0x367f78['writeTree_']['get'](_0xd809ab['path'])['getChild'](F(_0xd809ab['path'],_0x3b6df4)):null;}function cr(_0xcb3961){const _0x2458b1=[],_0x259d99=_0xcb3961['writeTree_']['value'];return _0x259d99!=null?_0x259d99['isLeafNode']()||_0x259d99['forEachChild'](R,(_0x58711b,_0x57e7db)=>{_0x2458b1['push'](new E(_0x58711b,_0x57e7db));}):_0xcb3961['writeTree_']['children']['inorderTraversal']((_0x3df76c,_0x90172f)=>{_0x90172f['value']!=null&&_0x2458b1['push'](new E(_0x3df76c,_0x90172f['value']));}),_0x2458b1;}function ve(_0x386cb2,_0x573091){if(v(_0x573091))return _0x386cb2;{const _0x54af5f=$e(_0x386cb2,_0x573091);return _0x54af5f!=null?new Y(new S(_0x54af5f)):new Y(_0x386cb2['writeTree_']['subtree'](_0x573091));}}function Ti(_0xb7d2b3){return _0xb7d2b3['writeTree_']['isEmpty']();}function nt(_0x11a00c,_0x5a4110){return Wo(w(),_0x11a00c['writeTree_'],_0x5a4110);}function Wo(_0x3e76c7,_0x36de21,_0x357dc0){if(_0x36de21['value']!=null)return _0x357dc0['updateChild'](_0x3e76c7,_0x36de21['value']);{let _0x4e965e=null;return _0x36de21['children']['inorderTraversal']((_0x58f366,_0x28faa4)=>{_0x58f366==='.priority'?(f(_0x28faa4['value']!==null,'Priority\x20writes\x20must\x20always\x20be\x20leaf\x20nodes'),_0x4e965e=_0x28faa4['value']):_0x357dc0=Wo(k(_0x3e76c7,_0x58f366),_0x28faa4,_0x357dc0);}),!_0x357dc0['getChild'](_0x3e76c7)['isEmpty']()&&_0x4e965e!==null&&(_0x357dc0=_0x357dc0['updateChild'](k(_0x3e76c7,'.priority'),_0x4e965e)),_0x357dc0;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Ln(_0x323512,_0x4d6711){return $o(_0x4d6711,_0x323512);}function lu(_0x371748,_0x52da53,_0x35e58b,_0x2ac3d5,_0x247d5a){f(_0x2ac3d5>_0x371748['lastWriteId'],'Stacking\x20an\x20older\x20write\x20on\x20top\x20of\x20newer\x20ones'),_0x247d5a===void 0x0&&(_0x247d5a=!0x0),_0x371748['allWrites']['push']({'path':_0x52da53,'snap':_0x35e58b,'writeId':_0x2ac3d5,'visible':_0x247d5a}),_0x247d5a&&(_0x371748['visibleWrites']=St(_0x371748['visibleWrites'],_0x52da53,_0x35e58b)),_0x371748['lastWriteId']=_0x2ac3d5;}function hu(_0x20ca63,_0x38a842,_0x230155,_0x5f2ba9){f(_0x5f2ba9>_0x20ca63['lastWriteId'],'Stacking\x20an\x20older\x20merge\x20on\x20top\x20of\x20newer\x20ones'),_0x20ca63['allWrites']['push']({'path':_0x38a842,'children':_0x230155,'writeId':_0x5f2ba9,'visible':!0x0}),_0x20ca63['visibleWrites']=wi(_0x20ca63['visibleWrites'],_0x38a842,_0x230155),_0x20ca63['lastWriteId']=_0x5f2ba9;}function uu(_0x3b6fd4,_0x2b65dc){for(let _0x941fe1=0x0;_0x941fe1<_0x3b6fd4['allWrites']['length'];_0x941fe1++){const _0x4690e0=_0x3b6fd4['allWrites'][_0x941fe1];if(_0x4690e0['writeId']===_0x2b65dc)return _0x4690e0;}return null;}function du(_0x4ba2a6,_0x4acacf){const _0x554464=_0x4ba2a6['allWrites']['findIndex'](_0x27c0ee=>_0x27c0ee['writeId']===_0x4acacf);f(_0x554464>=0x0,'removeWrite\x20called\x20with\x20nonexistent\x20writeId.');const _0x988e36=_0x4ba2a6['allWrites'][_0x554464];_0x4ba2a6['allWrites']['splice'](_0x554464,0x1);let _0x5a59f6=_0x988e36['visible'],_0x14b6bf=!0x1,_0x4662da=_0x4ba2a6['allWrites']['length']-0x1;for(;_0x5a59f6&&_0x4662da>=0x0;){const _0x17adca=_0x4ba2a6['allWrites'][_0x4662da];_0x17adca['visible']&&(_0x4662da>=_0x554464&&fu(_0x17adca,_0x988e36['path'])?_0x5a59f6=!0x1:G(_0x988e36['path'],_0x17adca['path'])&&(_0x14b6bf=!0x0)),_0x4662da--;}if(_0x5a59f6){if(_0x14b6bf)return pu(_0x4ba2a6),!0x0;if(_0x988e36['snap'])_0x4ba2a6['visibleWrites']=ar(_0x4ba2a6['visibleWrites'],_0x988e36['path']);else{const _0x2aad60=_0x988e36['children'];x(_0x2aad60,_0x17a470=>{_0x4ba2a6['visibleWrites']=ar(_0x4ba2a6['visibleWrites'],k(_0x988e36['path'],_0x17a470));});}return!0x0;}else return!0x1;}function fu(_0xd412d2,_0x4431f6){if(_0xd412d2['snap'])return G(_0xd412d2['path'],_0x4431f6);for(const _0x54d965 in _0xd412d2['children'])if(_0xd412d2['children']['hasOwnProperty'](_0x54d965)&&G(k(_0xd412d2['path'],_0x54d965),_0x4431f6))return!0x0;return!0x1;}function pu(_0x2095ad){_0x2095ad['visibleWrites']=Bo(_0x2095ad['allWrites'],_u,w()),_0x2095ad['allWrites']['length']>0x0?_0x2095ad['lastWriteId']=_0x2095ad['allWrites'][_0x2095ad['allWrites']['length']-0x1]['writeId']:_0x2095ad['lastWriteId']=-0x1;}function _u(_0x2b23f9){return _0x2b23f9['visible'];}function Bo(_0x1ac3f6,_0x3495d0,_0x2a6b3c){let _0x3c3f64=Y['empty']();for(let _0x5ef8cc=0x0;_0x5ef8cc<_0x1ac3f6['length'];++_0x5ef8cc){const _0x56aaf2=_0x1ac3f6[_0x5ef8cc];if(_0x3495d0(_0x56aaf2)){const _0x1d8b1a=_0x56aaf2['path'];let _0xa3c4b6;if(_0x56aaf2['snap'])G(_0x2a6b3c,_0x1d8b1a)?(_0xa3c4b6=F(_0x2a6b3c,_0x1d8b1a),_0x3c3f64=St(_0x3c3f64,_0xa3c4b6,_0x56aaf2['snap'])):G(_0x1d8b1a,_0x2a6b3c)&&(_0xa3c4b6=F(_0x1d8b1a,_0x2a6b3c),_0x3c3f64=St(_0x3c3f64,w(),_0x56aaf2['snap']['getChild'](_0xa3c4b6)));else{if(_0x56aaf2['children']){if(G(_0x2a6b3c,_0x1d8b1a))_0xa3c4b6=F(_0x2a6b3c,_0x1d8b1a),_0x3c3f64=wi(_0x3c3f64,_0xa3c4b6,_0x56aaf2['children']);else{if(G(_0x1d8b1a,_0x2a6b3c)){if(_0xa3c4b6=F(_0x1d8b1a,_0x2a6b3c),v(_0xa3c4b6))_0x3c3f64=wi(_0x3c3f64,w(),_0x56aaf2['children']);else{const _0x391fe0=De(_0x56aaf2['children'],y(_0xa3c4b6));if(_0x391fe0){const _0x36fdd1=_0x391fe0['getChild'](b(_0xa3c4b6));_0x3c3f64=St(_0x3c3f64,w(),_0x36fdd1);}}}}}else throw rt('WriteRecord\x20should\x20have\x20.snap\x20or\x20.children');}}}return _0x3c3f64;}function Vo(_0x5cd810,_0x23aced,_0x472e92,_0x2ff467,_0x22a19d){if(!_0x2ff467&&!_0x22a19d){const _0x4781fb=$e(_0x5cd810['visibleWrites'],_0x23aced);if(_0x4781fb!=null)return _0x4781fb;{const _0x52139e=ve(_0x5cd810['visibleWrites'],_0x23aced);if(Ti(_0x52139e))return _0x472e92;if(_0x472e92==null&&!Ci(_0x52139e,w()))return null;{const _0x2767f6=_0x472e92||g['EMPTY_NODE'];return nt(_0x52139e,_0x2767f6);}}}else{const _0x2f5685=ve(_0x5cd810['visibleWrites'],_0x23aced);if(!_0x22a19d&&Ti(_0x2f5685))return _0x472e92;if(!_0x22a19d&&_0x472e92==null&&!Ci(_0x2f5685,w()))return null;{const _0x5d3e8b=function(_0x4fcba4){return(_0x4fcba4['visible']||_0x22a19d)&&(!_0x2ff467||!~_0x2ff467['indexOf'](_0x4fcba4['writeId']))&&(G(_0x4fcba4['path'],_0x23aced)||G(_0x23aced,_0x4fcba4['path']));},_0x225b6b=Bo(_0x5cd810['allWrites'],_0x5d3e8b,_0x23aced),_0xec4d8d=_0x472e92||g['EMPTY_NODE'];return nt(_0x225b6b,_0xec4d8d);}}}function gu(_0x44b5f2,_0x2de9a3,_0x598eef){let _0x3a9660=g['EMPTY_NODE'];const _0x4ade91=$e(_0x44b5f2['visibleWrites'],_0x2de9a3);if(_0x4ade91)return _0x4ade91['isLeafNode']()||_0x4ade91['forEachChild'](R,(_0x5a0817,_0xdb662f)=>{_0x3a9660=_0x3a9660['updateImmediateChild'](_0x5a0817,_0xdb662f);}),_0x3a9660;if(_0x598eef){const _0x4fdfcd=ve(_0x44b5f2['visibleWrites'],_0x2de9a3);return _0x598eef['forEachChild'](R,(_0x397cda,_0x351839)=>{const _0x56182f=nt(ve(_0x4fdfcd,new C(_0x397cda)),_0x351839);_0x3a9660=_0x3a9660['updateImmediateChild'](_0x397cda,_0x56182f);}),cr(_0x4fdfcd)['forEach'](_0x581a4c=>{_0x3a9660=_0x3a9660['updateImmediateChild'](_0x581a4c['name'],_0x581a4c['node']);}),_0x3a9660;}else{const _0x262b89=ve(_0x44b5f2['visibleWrites'],_0x2de9a3);return cr(_0x262b89)['forEach'](_0x55ed11=>{_0x3a9660=_0x3a9660['updateImmediateChild'](_0x55ed11['name'],_0x55ed11['node']);}),_0x3a9660;}}function mu(_0x32741b,_0x496f41,_0x1cf086,_0xf755b3,_0x14ec56){f(_0xf755b3||_0x14ec56,'Either\x20existingEventSnap\x20or\x20existingServerSnap\x20must\x20exist');const _0x3976ca=k(_0x496f41,_0x1cf086);if(Ci(_0x32741b['visibleWrites'],_0x3976ca))return null;{const _0x33d375=ve(_0x32741b['visibleWrites'],_0x3976ca);return Ti(_0x33d375)?_0x14ec56['getChild'](_0x1cf086):nt(_0x33d375,_0x14ec56['getChild'](_0x1cf086));}}function yu(_0x543b71,_0x591ff5,_0x33939f,_0x32a32c){const _0x197ec7=k(_0x591ff5,_0x33939f),_0x366a7c=$e(_0x543b71['visibleWrites'],_0x197ec7);if(_0x366a7c!=null)return _0x366a7c;if(_0x32a32c['isCompleteForChild'](_0x33939f)){const _0x3fc268=ve(_0x543b71['visibleWrites'],_0x197ec7);return nt(_0x3fc268,_0x32a32c['getNode']()['getImmediateChild'](_0x33939f));}else return null;}function vu(_0x2c45a5,_0x2f2ef5){return $e(_0x2c45a5['visibleWrites'],_0x2f2ef5);}function Eu(_0x2886b2,_0x3c6d45,_0x61c082,_0x55f43e,_0x53c8e7,_0x172ed9,_0x3fc8e1){let _0x52103c;const _0x3c0616=ve(_0x2886b2['visibleWrites'],_0x3c6d45),_0x1d645d=$e(_0x3c0616,w());if(_0x1d645d!=null)_0x52103c=_0x1d645d;else{if(_0x61c082!=null)_0x52103c=nt(_0x3c0616,_0x61c082);else return[];}if(_0x52103c=_0x52103c['withIndex'](_0x3fc8e1),!_0x52103c['isEmpty']()&&!_0x52103c['isLeafNode']()){const _0x488978=[],_0x27524d=_0x3fc8e1['getCompare'](),_0x4f472d=_0x172ed9?_0x52103c['getReverseIteratorFrom'](_0x55f43e,_0x3fc8e1):_0x52103c['getIteratorFrom'](_0x55f43e,_0x3fc8e1);let _0x3b0b92=_0x4f472d['getNext']();for(;_0x3b0b92&&_0x488978['length']<_0x53c8e7;)_0x27524d(_0x3b0b92,_0x55f43e)!==0x0&&_0x488978['push'](_0x3b0b92),_0x3b0b92=_0x4f472d['getNext']();return _0x488978;}else return[];}function Iu(){return{'visibleWrites':Y['empty'](),'allWrites':[],'lastWriteId':-0x1};}function yn(_0x16b94d,_0x267f2f,_0x1ed28b,_0x11aa3c){return Vo(_0x16b94d['writeTree'],_0x16b94d['treePath'],_0x267f2f,_0x1ed28b,_0x11aa3c);}function ns(_0xde3b92,_0x1a0929){return gu(_0xde3b92['writeTree'],_0xde3b92['treePath'],_0x1a0929);}function lr(_0x56b805,_0x428ac0,_0x9a8b75,_0x2829c8){return mu(_0x56b805['writeTree'],_0x56b805['treePath'],_0x428ac0,_0x9a8b75,_0x2829c8);}function vn(_0xed68f5,_0x4c700c){return vu(_0xed68f5['writeTree'],k(_0xed68f5['treePath'],_0x4c700c));}function wu(_0x376e1e,_0x3ae634,_0x165efd,_0x45d7dd,_0x4b2b25,_0x5af19c){return Eu(_0x376e1e['writeTree'],_0x376e1e['treePath'],_0x3ae634,_0x165efd,_0x45d7dd,_0x4b2b25,_0x5af19c);}function is(_0x244aa7,_0x184301,_0x8ab485){return yu(_0x244aa7['writeTree'],_0x244aa7['treePath'],_0x184301,_0x8ab485);}function Ho(_0x349b48,_0xdf4a05){return $o(k(_0x349b48['treePath'],_0xdf4a05),_0x349b48['writeTree']);}function $o(_0x4b9f60,_0x585f86){return{'treePath':_0x4b9f60,'writeTree':_0x585f86};}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Cu{constructor(){this['changeMap']=new Map();}['trackChildChange'](_0x171e6f){const _0x3f748f=_0x171e6f['type'],_0xc26fe0=_0x171e6f['childName'];f(_0x3f748f==='child_added'||_0x3f748f==='child_changed'||_0x3f748f==='child_removed','Only\x20child\x20changes\x20supported\x20for\x20tracking'),f(_0xc26fe0!=='.priority','Only\x20non-priority\x20child\x20changes\x20can\x20be\x20tracked.');const _0x5e1a23=this['changeMap']['get'](_0xc26fe0);if(_0x5e1a23){const _0x34eab3=_0x5e1a23['type'];if(_0x3f748f==='child_added'&&_0x34eab3==='child_removed')this['changeMap']['set'](_0xc26fe0,Dt(_0xc26fe0,_0x171e6f['snapshotNode'],_0x5e1a23['snapshotNode']));else{if(_0x3f748f==='child_removed'&&_0x34eab3==='child_added')this['changeMap']['delete'](_0xc26fe0);else{if(_0x3f748f==='child_removed'&&_0x34eab3==='child_changed')this['changeMap']['set'](_0xc26fe0,Ot(_0xc26fe0,_0x5e1a23['oldSnap']));else{if(_0x3f748f==='child_changed'&&_0x34eab3==='child_added')this['changeMap']['set'](_0xc26fe0,et(_0xc26fe0,_0x171e6f['snapshotNode']));else{if(_0x3f748f==='child_changed'&&_0x34eab3==='child_changed')this['changeMap']['set'](_0xc26fe0,Dt(_0xc26fe0,_0x171e6f['snapshotNode'],_0x5e1a23['oldSnap']));else throw rt('Illegal\x20combination\x20of\x20changes:\x20'+_0x171e6f+'\x20occurred\x20after\x20'+_0x5e1a23);}}}}}else this['changeMap']['set'](_0xc26fe0,_0x171e6f);}['getChanges'](){return Array['from'](this['changeMap']['values']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Tu{['getCompleteChild'](_0x571ad0){return null;}['getChildAfterChild'](_0x3a0183,_0x1d8591,_0x5efdd3){return null;}}const Go=new Tu();class ss{constructor(_0x40373b,_0x4e5db1,_0x4de077=null){this['writes_']=_0x40373b,this['viewCache_']=_0x4e5db1,this['optCompleteServerCache_']=_0x4de077;}['getCompleteChild'](_0x4f661f){const _0x2ed7bf=this['viewCache_']['eventCache'];if(_0x2ed7bf['isCompleteForChild'](_0x4f661f))return _0x2ed7bf['getNode']()['getImmediateChild'](_0x4f661f);{const _0x59ac6a=this['optCompleteServerCache_']!=null?new Ce(this['optCompleteServerCache_'],!0x0,!0x1):this['viewCache_']['serverCache'];return is(this['writes_'],_0x4f661f,_0x59ac6a);}}['getChildAfterChild'](_0x1c6fe9,_0xf8800,_0x1c47f0){const _0x187760=this['optCompleteServerCache_']!=null?this['optCompleteServerCache_']:We(this['viewCache_']),_0x505a2d=wu(this['writes_'],_0x187760,_0xf8800,0x1,_0x1c47f0,_0x1c6fe9);return _0x505a2d['length']===0x0?null:_0x505a2d[0x0];}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Su(_0x37d5a8){return{'filter':_0x37d5a8};}function bu(_0x25109e,_0x3721c0){f(_0x3721c0['eventCache']['getNode']()['isIndexed'](_0x25109e['filter']['getIndex']()),'Event\x20snap\x20not\x20indexed'),f(_0x3721c0['serverCache']['getNode']()['isIndexed'](_0x25109e['filter']['getIndex']()),'Server\x20snap\x20not\x20indexed');}function Ru(_0x311c28,_0x4e813d,_0x326a55,_0x53104b,_0x8f0547){const _0x282122=new Cu();let _0x4d86f2,_0x3d5d9a;if(_0x326a55['type']===j['OVERWRITE']){const _0x47f570=_0x326a55;_0x47f570['source']['fromUser']?_0x4d86f2=Si(_0x311c28,_0x4e813d,_0x47f570['path'],_0x47f570['snap'],_0x53104b,_0x8f0547,_0x282122):(f(_0x47f570['source']['fromServer'],'Unknown\x20source.'),_0x3d5d9a=_0x47f570['source']['tagged']||_0x4e813d['serverCache']['isFiltered']()&&!v(_0x47f570['path']),_0x4d86f2=En(_0x311c28,_0x4e813d,_0x47f570['path'],_0x47f570['snap'],_0x53104b,_0x8f0547,_0x3d5d9a,_0x282122));}else{if(_0x326a55['type']===j['MERGE']){const _0x7984f8=_0x326a55;_0x7984f8['source']['fromUser']?_0x4d86f2=ku(_0x311c28,_0x4e813d,_0x7984f8['path'],_0x7984f8['children'],_0x53104b,_0x8f0547,_0x282122):(f(_0x7984f8['source']['fromServer'],'Unknown\x20source.'),_0x3d5d9a=_0x7984f8['source']['tagged']||_0x4e813d['serverCache']['isFiltered'](),_0x4d86f2=bi(_0x311c28,_0x4e813d,_0x7984f8['path'],_0x7984f8['children'],_0x53104b,_0x8f0547,_0x3d5d9a,_0x282122));}else{if(_0x326a55['type']===j['ACK_USER_WRITE']){const _0x899553=_0x326a55;_0x899553['revert']?_0x4d86f2=Ou(_0x311c28,_0x4e813d,_0x899553['path'],_0x53104b,_0x8f0547,_0x282122):_0x4d86f2=Nu(_0x311c28,_0x4e813d,_0x899553['path'],_0x899553['affectedTree'],_0x53104b,_0x8f0547,_0x282122);}else{if(_0x326a55['type']===j['LISTEN_COMPLETE'])_0x4d86f2=Pu(_0x311c28,_0x4e813d,_0x326a55['path'],_0x53104b,_0x282122);else throw rt('Unknown\x20operation\x20type:\x20'+_0x326a55['type']);}}}const _0x8317c1=_0x282122['getChanges']();return Au(_0x4e813d,_0x4d86f2,_0x8317c1),{'viewCache':_0x4d86f2,'changes':_0x8317c1};}function Au(_0x11a64e,_0x5a35f2,_0x1a0099){const _0x339719=_0x5a35f2['eventCache'];if(_0x339719['isFullyInitialized']()){const _0x38d3eb=_0x339719['getNode']()['isLeafNode']()||_0x339719['getNode']()['isEmpty'](),_0x5102a6=mn(_0x11a64e);(_0x1a0099['length']>0x0||!_0x11a64e['eventCache']['isFullyInitialized']()||_0x38d3eb&&!_0x339719['getNode']()['equals'](_0x5102a6)||!_0x339719['getNode']()['getPriority']()['equals'](_0x5102a6['getPriority']()))&&_0x1a0099['push'](Lo(mn(_0x5a35f2)));}}function qo(_0x2d4e73,_0xd7766d,_0x11c829,_0x22d48e,_0x7e0ad4,_0x454257){const _0x5caf90=_0xd7766d['eventCache'];if(vn(_0x22d48e,_0x11c829)!=null)return _0xd7766d;{let _0xa5aa13,_0x199d3d;if(v(_0x11c829)){if(f(_0xd7766d['serverCache']['isFullyInitialized'](),'If\x20change\x20path\x20is\x20empty,\x20we\x20must\x20have\x20complete\x20server\x20data'),_0xd7766d['serverCache']['isFiltered']()){const _0x3c9e6d=We(_0xd7766d),_0x3ca76d=_0x3c9e6d instanceof g?_0x3c9e6d:g['EMPTY_NODE'],_0x3a99c0=ns(_0x22d48e,_0x3ca76d);_0xa5aa13=_0x2d4e73['filter']['updateFullNode'](_0xd7766d['eventCache']['getNode'](),_0x3a99c0,_0x454257);}else{const _0x483b52=yn(_0x22d48e,We(_0xd7766d));_0xa5aa13=_0x2d4e73['filter']['updateFullNode'](_0xd7766d['eventCache']['getNode'](),_0x483b52,_0x454257);}}else{const _0x202adc=y(_0x11c829);if(_0x202adc==='.priority'){f(we(_0x11c829)===0x1,'Can\x27t\x20have\x20a\x20priority\x20with\x20additional\x20path\x20components');const _0x4efc85=_0x5caf90['getNode']();_0x199d3d=_0xd7766d['serverCache']['getNode']();const _0x104de1=lr(_0x22d48e,_0x11c829,_0x4efc85,_0x199d3d);_0x104de1!=null?_0xa5aa13=_0x2d4e73['filter']['updatePriority'](_0x4efc85,_0x104de1):_0xa5aa13=_0x5caf90['getNode']();}else{const _0xbf8d49=b(_0x11c829);let _0x25f3e3;if(_0x5caf90['isCompleteForChild'](_0x202adc)){_0x199d3d=_0xd7766d['serverCache']['getNode']();const _0x271c91=lr(_0x22d48e,_0x11c829,_0x5caf90['getNode'](),_0x199d3d);_0x271c91!=null?_0x25f3e3=_0x5caf90['getNode']()['getImmediateChild'](_0x202adc)['updateChild'](_0xbf8d49,_0x271c91):_0x25f3e3=_0x5caf90['getNode']()['getImmediateChild'](_0x202adc);}else _0x25f3e3=is(_0x22d48e,_0x202adc,_0xd7766d['serverCache']);_0x25f3e3!=null?_0xa5aa13=_0x2d4e73['filter']['updateChild'](_0x5caf90['getNode'](),_0x202adc,_0x25f3e3,_0xbf8d49,_0x7e0ad4,_0x454257):_0xa5aa13=_0x5caf90['getNode']();}}return Tt(_0xd7766d,_0xa5aa13,_0x5caf90['isFullyInitialized']()||v(_0x11c829),_0x2d4e73['filter']['filtersNodes']());}}function En(_0x5b9308,_0x41d05c,_0x4f27db,_0x447958,_0x2e3d59,_0x769e88,_0x7f3e86,_0x45a0f3){const _0x2bf198=_0x41d05c['serverCache'];let _0x55ecb9;const _0x912512=_0x7f3e86?_0x5b9308['filter']:_0x5b9308['filter']['getIndexedFilter']();if(v(_0x4f27db))_0x55ecb9=_0x912512['updateFullNode'](_0x2bf198['getNode'](),_0x447958,null);else{if(_0x912512['filtersNodes']()&&!_0x2bf198['isFiltered']()){const _0x2b7cc6=_0x2bf198['getNode']()['updateChild'](_0x4f27db,_0x447958);_0x55ecb9=_0x912512['updateFullNode'](_0x2bf198['getNode'](),_0x2b7cc6,null);}else{const _0x1b9cd=y(_0x4f27db);if(!_0x2bf198['isCompleteForPath'](_0x4f27db)&&we(_0x4f27db)>0x1)return _0x41d05c;const _0x45808e=b(_0x4f27db),_0x266f56=_0x2bf198['getNode']()['getImmediateChild'](_0x1b9cd)['updateChild'](_0x45808e,_0x447958);_0x1b9cd==='.priority'?_0x55ecb9=_0x912512['updatePriority'](_0x2bf198['getNode'](),_0x266f56):_0x55ecb9=_0x912512['updateChild'](_0x2bf198['getNode'](),_0x1b9cd,_0x266f56,_0x45808e,Go,null);}}const _0x1d241d=Uo(_0x41d05c,_0x55ecb9,_0x2bf198['isFullyInitialized']()||v(_0x4f27db),_0x912512['filtersNodes']()),_0x38b86a=new ss(_0x2e3d59,_0x1d241d,_0x769e88);return qo(_0x5b9308,_0x1d241d,_0x4f27db,_0x2e3d59,_0x38b86a,_0x45a0f3);}function Si(_0x56839e,_0x432992,_0x59d48b,_0x280ec2,_0x24e9b7,_0x40d31e,_0x6e2b99){const _0x5952fc=_0x432992['eventCache'];let _0x4a9570,_0x364c8b;const _0x2dfc6c=new ss(_0x24e9b7,_0x432992,_0x40d31e);if(v(_0x59d48b))_0x364c8b=_0x56839e['filter']['updateFullNode'](_0x432992['eventCache']['getNode'](),_0x280ec2,_0x6e2b99),_0x4a9570=Tt(_0x432992,_0x364c8b,!0x0,_0x56839e['filter']['filtersNodes']());else{const _0x2cc8d6=y(_0x59d48b);if(_0x2cc8d6==='.priority')_0x364c8b=_0x56839e['filter']['updatePriority'](_0x432992['eventCache']['getNode'](),_0x280ec2),_0x4a9570=Tt(_0x432992,_0x364c8b,_0x5952fc['isFullyInitialized'](),_0x5952fc['isFiltered']());else{const _0x53f7ae=b(_0x59d48b),_0xf39dd4=_0x5952fc['getNode']()['getImmediateChild'](_0x2cc8d6);let _0x562406;if(v(_0x53f7ae))_0x562406=_0x280ec2;else{const _0x6cb37e=_0x2dfc6c['getCompleteChild'](_0x2cc8d6);_0x6cb37e!=null?zi(_0x53f7ae)==='.priority'&&_0x6cb37e['getChild'](Ro(_0x53f7ae))['isEmpty']()?_0x562406=_0x6cb37e:_0x562406=_0x6cb37e['updateChild'](_0x53f7ae,_0x280ec2):_0x562406=g['EMPTY_NODE'];}if(_0xf39dd4['equals'](_0x562406))_0x4a9570=_0x432992;else{const _0x314842=_0x56839e['filter']['updateChild'](_0x5952fc['getNode'](),_0x2cc8d6,_0x562406,_0x53f7ae,_0x2dfc6c,_0x6e2b99);_0x4a9570=Tt(_0x432992,_0x314842,_0x5952fc['isFullyInitialized'](),_0x56839e['filter']['filtersNodes']());}}}return _0x4a9570;}function hr(_0x18f209,_0x2f7da3){return _0x18f209['eventCache']['isCompleteForChild'](_0x2f7da3);}function ku(_0x10d3b6,_0x2bbe2d,_0x559ce2,_0x5cb835,_0x209604,_0x313e8b,_0x45a428){let _0x183707=_0x2bbe2d;return _0x5cb835['foreach']((_0xe9989f,_0x6c210)=>{const _0x4000cd=k(_0x559ce2,_0xe9989f);hr(_0x2bbe2d,y(_0x4000cd))&&(_0x183707=Si(_0x10d3b6,_0x183707,_0x4000cd,_0x6c210,_0x209604,_0x313e8b,_0x45a428));}),_0x5cb835['foreach']((_0x23d5eb,_0x2e96c8)=>{const _0x42467b=k(_0x559ce2,_0x23d5eb);hr(_0x2bbe2d,y(_0x42467b))||(_0x183707=Si(_0x10d3b6,_0x183707,_0x42467b,_0x2e96c8,_0x209604,_0x313e8b,_0x45a428));}),_0x183707;}function ur(_0x41aca9,_0x533009,_0x49c5d8){return _0x49c5d8['foreach']((_0x213bd6,_0x566fea)=>{_0x533009=_0x533009['updateChild'](_0x213bd6,_0x566fea);}),_0x533009;}function bi(_0xba118d,_0xf946f4,_0x3b35fc,_0x3f7a98,_0x1b840e,_0x4364fc,_0x1a3550,_0x31ce72){if(_0xf946f4['serverCache']['getNode']()['isEmpty']()&&!_0xf946f4['serverCache']['isFullyInitialized']())return _0xf946f4;let _0x4f9632=_0xf946f4,_0x4e2e33;v(_0x3b35fc)?_0x4e2e33=_0x3f7a98:_0x4e2e33=new S(null)['setTree'](_0x3b35fc,_0x3f7a98);const _0x157772=_0xf946f4['serverCache']['getNode']();return _0x4e2e33['children']['inorderTraversal']((_0x4b6f1d,_0x4cbf3f)=>{if(_0x157772['hasChild'](_0x4b6f1d)){const _0xe8c6d8=_0xf946f4['serverCache']['getNode']()['getImmediateChild'](_0x4b6f1d),_0x337f54=ur(_0xba118d,_0xe8c6d8,_0x4cbf3f);_0x4f9632=En(_0xba118d,_0x4f9632,new C(_0x4b6f1d),_0x337f54,_0x1b840e,_0x4364fc,_0x1a3550,_0x31ce72);}}),_0x4e2e33['children']['inorderTraversal']((_0x16cb6c,_0x2590fd)=>{const _0x4e90cc=!_0xf946f4['serverCache']['isCompleteForChild'](_0x16cb6c)&&_0x2590fd['value']===null;if(!_0x157772['hasChild'](_0x16cb6c)&&!_0x4e90cc){const _0x3956cb=_0xf946f4['serverCache']['getNode']()['getImmediateChild'](_0x16cb6c),_0x6fe686=ur(_0xba118d,_0x3956cb,_0x2590fd);_0x4f9632=En(_0xba118d,_0x4f9632,new C(_0x16cb6c),_0x6fe686,_0x1b840e,_0x4364fc,_0x1a3550,_0x31ce72);}}),_0x4f9632;}function Nu(_0x482be0,_0x4ae619,_0x58ad31,_0x556239,_0x2102ec,_0x368aca,_0x118f18){if(vn(_0x2102ec,_0x58ad31)!=null)return _0x4ae619;const _0x25d907=_0x4ae619['serverCache']['isFiltered'](),_0xd7a276=_0x4ae619['serverCache'];if(_0x556239['value']!=null){if(v(_0x58ad31)&&_0xd7a276['isFullyInitialized']()||_0xd7a276['isCompleteForPath'](_0x58ad31))return En(_0x482be0,_0x4ae619,_0x58ad31,_0xd7a276['getNode']()['getChild'](_0x58ad31),_0x2102ec,_0x368aca,_0x25d907,_0x118f18);if(v(_0x58ad31)){let _0x22fc93=new S(null);return _0xd7a276['getNode']()['forEachChild'](ye,(_0x3db352,_0x12d490)=>{_0x22fc93=_0x22fc93['set'](new C(_0x3db352),_0x12d490);}),bi(_0x482be0,_0x4ae619,_0x58ad31,_0x22fc93,_0x2102ec,_0x368aca,_0x25d907,_0x118f18);}else return _0x4ae619;}else{let _0x34bd1a=new S(null);return _0x556239['foreach']((_0xa010b7,_0x402081)=>{const _0x7b7f13=k(_0x58ad31,_0xa010b7);_0xd7a276['isCompleteForPath'](_0x7b7f13)&&(_0x34bd1a=_0x34bd1a['set'](_0xa010b7,_0xd7a276['getNode']()['getChild'](_0x7b7f13)));}),bi(_0x482be0,_0x4ae619,_0x58ad31,_0x34bd1a,_0x2102ec,_0x368aca,_0x25d907,_0x118f18);}}function Pu(_0x22b438,_0x58ba41,_0x162e4a,_0x1b05b2,_0x125c18){const _0x298f0a=_0x58ba41['serverCache'],_0x392d64=Uo(_0x58ba41,_0x298f0a['getNode'](),_0x298f0a['isFullyInitialized']()||v(_0x162e4a),_0x298f0a['isFiltered']());return qo(_0x22b438,_0x392d64,_0x162e4a,_0x1b05b2,Go,_0x125c18);}function Ou(_0x23692d,_0x121709,_0x2f2c79,_0x96b6ad,_0x309cd6,_0x146b61){let _0x3cd7c2;if(vn(_0x96b6ad,_0x2f2c79)!=null)return _0x121709;{const _0xc47fd1=new ss(_0x96b6ad,_0x121709,_0x309cd6),_0x280e93=_0x121709['eventCache']['getNode']();let _0x4356d5;if(v(_0x2f2c79)||y(_0x2f2c79)==='.priority'){let _0x5e088e;if(_0x121709['serverCache']['isFullyInitialized']())_0x5e088e=yn(_0x96b6ad,We(_0x121709));else{const _0x431a88=_0x121709['serverCache']['getNode']();f(_0x431a88 instanceof g,'serverChildren\x20would\x20be\x20complete\x20if\x20leaf\x20node'),_0x5e088e=ns(_0x96b6ad,_0x431a88);}_0x5e088e=_0x5e088e,_0x4356d5=_0x23692d['filter']['updateFullNode'](_0x280e93,_0x5e088e,_0x146b61);}else{const _0x2f864d=y(_0x2f2c79);let _0x3795e7=is(_0x96b6ad,_0x2f864d,_0x121709['serverCache']);_0x3795e7==null&&_0x121709['serverCache']['isCompleteForChild'](_0x2f864d)&&(_0x3795e7=_0x280e93['getImmediateChild'](_0x2f864d)),_0x3795e7!=null?_0x4356d5=_0x23692d['filter']['updateChild'](_0x280e93,_0x2f864d,_0x3795e7,b(_0x2f2c79),_0xc47fd1,_0x146b61):_0x121709['eventCache']['getNode']()['hasChild'](_0x2f864d)?_0x4356d5=_0x23692d['filter']['updateChild'](_0x280e93,_0x2f864d,g['EMPTY_NODE'],b(_0x2f2c79),_0xc47fd1,_0x146b61):_0x4356d5=_0x280e93,_0x4356d5['isEmpty']()&&_0x121709['serverCache']['isFullyInitialized']()&&(_0x3cd7c2=yn(_0x96b6ad,We(_0x121709)),_0x3cd7c2['isLeafNode']()&&(_0x4356d5=_0x23692d['filter']['updateFullNode'](_0x4356d5,_0x3cd7c2,_0x146b61)));}return _0x3cd7c2=_0x121709['serverCache']['isFullyInitialized']()||vn(_0x96b6ad,w())!=null,Tt(_0x121709,_0x4356d5,_0x3cd7c2,_0x23692d['filter']['filtersNodes']());}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Du{constructor(_0x4f6061,_0x27997f){this['query_']=_0x4f6061,this['eventRegistrations_']=[];const _0x2e84c4=this['query_']['_queryParams'],_0x107987=new Ji(_0x2e84c4['getIndex']()),_0x5da831=Kh(_0x2e84c4);this['processor_']=Su(_0x5da831);const _0x5868e5=_0x27997f['serverCache'],_0x378b78=_0x27997f['eventCache'],_0x117efa=_0x107987['updateFullNode'](g['EMPTY_NODE'],_0x5868e5['getNode'](),null),_0x5e33f7=_0x5da831['updateFullNode'](g['EMPTY_NODE'],_0x378b78['getNode'](),null),_0x95adc=new Ce(_0x117efa,_0x5868e5['isFullyInitialized'](),_0x107987['filtersNodes']()),_0x5b5438=new Ce(_0x5e33f7,_0x378b78['isFullyInitialized'](),_0x5da831['filtersNodes']());this['viewCache_']=Mn(_0x5b5438,_0x95adc),this['eventGenerator_']=new su(this['query_']);}get['query'](){return this['query_'];}}function Mu(_0x501f4b){return _0x501f4b['viewCache_']['serverCache']['getNode']();}function Lu(_0x45a29a){return mn(_0x45a29a['viewCache_']);}function xu(_0x3a173d,_0x14b52e){const _0xd399f=We(_0x3a173d['viewCache_']);return _0xd399f&&(_0x3a173d['query']['_queryParams']['loadsAllData']()||!v(_0x14b52e)&&!_0xd399f['getImmediateChild'](y(_0x14b52e))['isEmpty']())?_0xd399f['getChild'](_0x14b52e):null;}function dr(_0x22bcff){return _0x22bcff['eventRegistrations_']['length']===0x0;}function Fu(_0x3dc518,_0x4f30e3){_0x3dc518['eventRegistrations_']['push'](_0x4f30e3);}function fr(_0x286b48,_0x45b1f2,_0x4e6bce){const _0x1a3517=[];if(_0x4e6bce){f(_0x45b1f2==null,'A\x20cancel\x20should\x20cancel\x20all\x20event\x20registrations.');const _0x499d76=_0x286b48['query']['_path'];_0x286b48['eventRegistrations_']['forEach'](_0x18f411=>{const _0x1f7016=_0x18f411['createCancelEvent'](_0x4e6bce,_0x499d76);_0x1f7016&&_0x1a3517['push'](_0x1f7016);});}if(_0x45b1f2){let _0x43fc4d=[];for(let _0x19735e=0x0;_0x19735e<_0x286b48['eventRegistrations_']['length'];++_0x19735e){const _0x1932a4=_0x286b48['eventRegistrations_'][_0x19735e];if(!_0x1932a4['matches'](_0x45b1f2))_0x43fc4d['push'](_0x1932a4);else{if(_0x45b1f2['hasAnyCallback']()){_0x43fc4d=_0x43fc4d['concat'](_0x286b48['eventRegistrations_']['slice'](_0x19735e+0x1));break;}}}_0x286b48['eventRegistrations_']=_0x43fc4d;}else _0x286b48['eventRegistrations_']=[];return _0x1a3517;}function pr(_0x16bf11,_0x290e69,_0x6603f8,_0x4640fd){_0x290e69['type']===j['MERGE']&&_0x290e69['source']['queryId']!==null&&(f(We(_0x16bf11['viewCache_']),'We\x20should\x20always\x20have\x20a\x20full\x20cache\x20before\x20handling\x20merges'),f(mn(_0x16bf11['viewCache_']),'Missing\x20event\x20cache,\x20even\x20though\x20we\x20have\x20a\x20server\x20cache'));const _0x297af6=_0x16bf11['viewCache_'],_0x1eb4b1=Ru(_0x16bf11['processor_'],_0x297af6,_0x290e69,_0x6603f8,_0x4640fd);return bu(_0x16bf11['processor_'],_0x1eb4b1['viewCache']),f(_0x1eb4b1['viewCache']['serverCache']['isFullyInitialized']()||!_0x297af6['serverCache']['isFullyInitialized'](),'Once\x20a\x20server\x20snap\x20is\x20complete,\x20it\x20should\x20never\x20go\x20back'),_0x16bf11['viewCache_']=_0x1eb4b1['viewCache'],zo(_0x16bf11,_0x1eb4b1['changes'],_0x1eb4b1['viewCache']['eventCache']['getNode'](),null);}function Uu(_0x4a8bce,_0x1a512a){const _0x3c4d45=_0x4a8bce['viewCache_']['eventCache'],_0x1868df=[];return _0x3c4d45['getNode']()['isLeafNode']()||_0x3c4d45['getNode']()['forEachChild'](R,(_0x48229e,_0x4dc982)=>{_0x1868df['push'](et(_0x48229e,_0x4dc982));}),_0x3c4d45['isFullyInitialized']()&&_0x1868df['push'](Lo(_0x3c4d45['getNode']())),zo(_0x4a8bce,_0x1868df,_0x3c4d45['getNode'](),_0x1a512a);}function zo(_0x38e05f,_0x46b452,_0x2117b7,_0x8009c8){const _0x3f7c01=_0x8009c8?[_0x8009c8]:_0x38e05f['eventRegistrations_'];return ru(_0x38e05f['eventGenerator_'],_0x46b452,_0x2117b7,_0x3f7c01);}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let In;class jo{constructor(){this['views']=new Map();}}function Wu(_0xfe3bc3){f(!In,'__referenceConstructor\x20has\x20already\x20been\x20defined'),In=_0xfe3bc3;}function Bu(){return f(In,'Reference.ts\x20has\x20not\x20been\x20loaded'),In;}function Vu(_0x20b940){return _0x20b940['views']['size']===0x0;}function rs(_0x4d0507,_0x398a76,_0xb296a7,_0x9b24a5){const _0x5e7a9f=_0x398a76['source']['queryId'];if(_0x5e7a9f!==null){const _0x134091=_0x4d0507['views']['get'](_0x5e7a9f);return f(_0x134091!=null,'SyncTree\x20gave\x20us\x20an\x20op\x20for\x20an\x20invalid\x20query.'),pr(_0x134091,_0x398a76,_0xb296a7,_0x9b24a5);}else{let _0xd7c37d=[];for(const _0x4796ff of _0x4d0507['views']['values']())_0xd7c37d=_0xd7c37d['concat'](pr(_0x4796ff,_0x398a76,_0xb296a7,_0x9b24a5));return _0xd7c37d;}}function Ko(_0x69b671,_0xf8b2bd,_0x405dd4,_0xdc6a60,_0x2b35d5){const _0x53be86=_0xf8b2bd['_queryIdentifier'],_0x7d0c55=_0x69b671['views']['get'](_0x53be86);if(!_0x7d0c55){let _0x388ba0=yn(_0x405dd4,_0x2b35d5?_0xdc6a60:null),_0x2bfbe6=!0x1;_0x388ba0?_0x2bfbe6=!0x0:_0xdc6a60 instanceof g?(_0x388ba0=ns(_0x405dd4,_0xdc6a60),_0x2bfbe6=!0x1):(_0x388ba0=g['EMPTY_NODE'],_0x2bfbe6=!0x1);const _0x3d0e8e=Mn(new Ce(_0x388ba0,_0x2bfbe6,!0x1),new Ce(_0xdc6a60,_0x2b35d5,!0x1));return new Du(_0xf8b2bd,_0x3d0e8e);}return _0x7d0c55;}function Hu(_0x5e8664,_0x476e16,_0x5cb588,_0xee02ae,_0x3f6c30,_0x55250a){const _0x2d7ee2=Ko(_0x5e8664,_0x476e16,_0xee02ae,_0x3f6c30,_0x55250a);return _0x5e8664['views']['has'](_0x476e16['_queryIdentifier'])||_0x5e8664['views']['set'](_0x476e16['_queryIdentifier'],_0x2d7ee2),Fu(_0x2d7ee2,_0x5cb588),Uu(_0x2d7ee2,_0x5cb588);}function $u(_0x375f2c,_0x37ba22,_0x3efbc9,_0x5459a5){const _0x792612=_0x37ba22['_queryIdentifier'],_0x27df29=[];let _0x2be456=[];const _0x133de7=Te(_0x375f2c);if(_0x792612==='default'){for(const [_0x21917a,_0x4de74c]of _0x375f2c['views']['entries']())_0x2be456=_0x2be456['concat'](fr(_0x4de74c,_0x3efbc9,_0x5459a5)),dr(_0x4de74c)&&(_0x375f2c['views']['delete'](_0x21917a),_0x4de74c['query']['_queryParams']['loadsAllData']()||_0x27df29['push'](_0x4de74c['query']));}else{const _0x392af8=_0x375f2c['views']['get'](_0x792612);_0x392af8&&(_0x2be456=_0x2be456['concat'](fr(_0x392af8,_0x3efbc9,_0x5459a5)),dr(_0x392af8)&&(_0x375f2c['views']['delete'](_0x792612),_0x392af8['query']['_queryParams']['loadsAllData']()||_0x27df29['push'](_0x392af8['query'])));}return _0x133de7&&!Te(_0x375f2c)&&_0x27df29['push'](new(Bu())(_0x37ba22['_repo'],_0x37ba22['_path'])),{'removed':_0x27df29,'events':_0x2be456};}function Yo(_0x41d9c2){const _0x5a479a=[];for(const _0x18d1d5 of _0x41d9c2['views']['values']())_0x18d1d5['query']['_queryParams']['loadsAllData']()||_0x5a479a['push'](_0x18d1d5);return _0x5a479a;}function Ee(_0x4bdacc,_0x112b4c){let _0xeffd3=null;for(const _0x44fd82 of _0x4bdacc['views']['values']())_0xeffd3=_0xeffd3||xu(_0x44fd82,_0x112b4c);return _0xeffd3;}function Qo(_0xd4eb4c,_0x4131df){if(_0x4131df['_queryParams']['loadsAllData']())return xn(_0xd4eb4c);{const _0x26e5fc=_0x4131df['_queryIdentifier'];return _0xd4eb4c['views']['get'](_0x26e5fc);}}function Jo(_0x52de25,_0x1edaa5){return Qo(_0x52de25,_0x1edaa5)!=null;}function Te(_0x6feae6){return xn(_0x6feae6)!=null;}function xn(_0x17e4d3){for(const _0x3f752c of _0x17e4d3['views']['values']())if(_0x3f752c['query']['_queryParams']['loadsAllData']())return _0x3f752c;return null;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let wn;function Gu(_0x92ebac){f(!wn,'__referenceConstructor\x20has\x20already\x20been\x20defined'),wn=_0x92ebac;}function qu(){return f(wn,'Reference.ts\x20has\x20not\x20been\x20loaded'),wn;}let zu=0x1;class _r{constructor(_0x599e6d){this['listenProvider_']=_0x599e6d,this['syncPointTree_']=new S(null),this['pendingWriteTree_']=Iu(),this['tagToQueryMap']=new Map(),this['queryToTagMap']=new Map();}}function os(_0x4eca87,_0x5a6ce1,_0x3627db,_0x2ffc83,_0x421ebf){return lu(_0x4eca87['pendingWriteTree_'],_0x5a6ce1,_0x3627db,_0x2ffc83,_0x421ebf),_0x421ebf?ut(_0x4eca87,new Ue(Zi(),_0x5a6ce1,_0x3627db)):[];}function ju(_0x55df05,_0x1f0af0,_0x555514,_0x25e447){hu(_0x55df05['pendingWriteTree_'],_0x1f0af0,_0x555514,_0x25e447);const _0x409654=S['fromObject'](_0x555514);return ut(_0x55df05,new tt(Zi(),_0x1f0af0,_0x409654));}function pe(_0x1c262d,_0x2c3c9a,_0x3b4b5e=!0x1){const _0x136036=uu(_0x1c262d['pendingWriteTree_'],_0x2c3c9a);if(du(_0x1c262d['pendingWriteTree_'],_0x2c3c9a)){let _0x3cc89e=new S(null);return _0x136036['snap']!=null?_0x3cc89e=_0x3cc89e['set'](w(),!0x0):x(_0x136036['children'],_0x38bbde=>{_0x3cc89e=_0x3cc89e['set'](new C(_0x38bbde),!0x0);}),ut(_0x1c262d,new gn(_0x136036['path'],_0x3cc89e,_0x3b4b5e));}else return[];}function Gt(_0x178d90,_0x247acc,_0x1da46f){return ut(_0x178d90,new Ue(es(),_0x247acc,_0x1da46f));}function Ku(_0x4f1133,_0x19c210,_0x52ed98){const _0x4e3119=S['fromObject'](_0x52ed98);return ut(_0x4f1133,new tt(es(),_0x19c210,_0x4e3119));}function Yu(_0x57940f,_0x5a584b){return ut(_0x57940f,new Lt(es(),_0x5a584b));}function Qu(_0x58ad10,_0x5d7415,_0x4681df){const _0x431e82=as(_0x58ad10,_0x4681df);if(_0x431e82){const _0x1a2c6a=cs(_0x431e82),_0x996acd=_0x1a2c6a['path'],_0x15abf9=_0x1a2c6a['queryId'],_0x9abd7b=F(_0x996acd,_0x5d7415),_0x271569=new Lt(ts(_0x15abf9),_0x9abd7b);return ls(_0x58ad10,_0x996acd,_0x271569);}else return[];}function Cn(_0x55b4d8,_0x2722d4,_0x435794,_0x386638,_0x39f786=!0x1){const _0x839464=_0x2722d4['_path'],_0x564bdc=_0x55b4d8['syncPointTree_']['get'](_0x839464);let _0x11fccf=[];if(_0x564bdc&&(_0x2722d4['_queryIdentifier']==='default'||Jo(_0x564bdc,_0x2722d4))){const _0xd0552e=$u(_0x564bdc,_0x2722d4,_0x435794,_0x386638);Vu(_0x564bdc)&&(_0x55b4d8['syncPointTree_']=_0x55b4d8['syncPointTree_']['remove'](_0x839464));const _0x529a50=_0xd0552e['removed'];if(_0x11fccf=_0xd0552e['events'],!_0x39f786){const _0x5c413b=_0x529a50['findIndex'](_0x25b58d=>_0x25b58d['_queryParams']['loadsAllData']())!==-0x1,_0x20fcb8=_0x55b4d8['syncPointTree_']['findOnPath'](_0x839464,(_0x5eeeb1,_0x41b372)=>Te(_0x41b372));if(_0x5c413b&&!_0x20fcb8){const _0x308f71=_0x55b4d8['syncPointTree_']['subtree'](_0x839464);if(!_0x308f71['isEmpty']()){const _0xee0353=Zu(_0x308f71);for(let _0xdccd84=0x0;_0xdccd84<_0xee0353['length'];++_0xdccd84){const _0x1c4668=_0xee0353[_0xdccd84],_0x2168fa=_0x1c4668['query'],_0x106619=ta(_0x55b4d8,_0x1c4668);_0x55b4d8['listenProvider_']['startListening'](bt(_0x2168fa),xt(_0x55b4d8,_0x2168fa),_0x106619['hashFn'],_0x106619['onComplete']);}}}!_0x20fcb8&&_0x529a50['length']>0x0&&!_0x386638&&(_0x5c413b?_0x55b4d8['listenProvider_']['stopListening'](bt(_0x2722d4),null):_0x529a50['forEach'](_0x28b015=>{const _0x4d5102=_0x55b4d8['queryToTagMap']['get'](Un(_0x28b015));_0x55b4d8['listenProvider_']['stopListening'](bt(_0x28b015),_0x4d5102);}));}ed(_0x55b4d8,_0x529a50);}return _0x11fccf;}function Xo(_0x48b108,_0x36fb17,_0x49ee7b,_0x3d6ade){const _0x42611c=as(_0x48b108,_0x3d6ade);if(_0x42611c!=null){const _0x22c98b=cs(_0x42611c),_0x2417e1=_0x22c98b['path'],_0x27eab5=_0x22c98b['queryId'],_0x5f259d=F(_0x2417e1,_0x36fb17),_0x2e12c4=new Ue(ts(_0x27eab5),_0x5f259d,_0x49ee7b);return ls(_0x48b108,_0x2417e1,_0x2e12c4);}else return[];}function Ju(_0x575cb2,_0x2ad26f,_0x4c3ccf,_0x57d206){const _0x577d22=as(_0x575cb2,_0x57d206);if(_0x577d22){const _0x32da55=cs(_0x577d22),_0x47e87f=_0x32da55['path'],_0x4fcc63=_0x32da55['queryId'],_0x37cffe=F(_0x47e87f,_0x2ad26f),_0x2b9a3c=S['fromObject'](_0x4c3ccf),_0x1d2fea=new tt(ts(_0x4fcc63),_0x37cffe,_0x2b9a3c);return ls(_0x575cb2,_0x47e87f,_0x1d2fea);}else return[];}function Ri(_0x343bdc,_0x96cf6a,_0x48e126,_0x27ff2b=!0x1){const _0x44ad86=_0x96cf6a['_path'];let _0x4ae363=null,_0x14037e=!0x1;_0x343bdc['syncPointTree_']['foreachOnPath'](_0x44ad86,(_0x256cab,_0x25311e)=>{const _0x2ed170=F(_0x256cab,_0x44ad86);_0x4ae363=_0x4ae363||Ee(_0x25311e,_0x2ed170),_0x14037e=_0x14037e||Te(_0x25311e);});let _0x26b115=_0x343bdc['syncPointTree_']['get'](_0x44ad86);_0x26b115?(_0x14037e=_0x14037e||Te(_0x26b115),_0x4ae363=_0x4ae363||Ee(_0x26b115,w())):(_0x26b115=new jo(),_0x343bdc['syncPointTree_']=_0x343bdc['syncPointTree_']['set'](_0x44ad86,_0x26b115));let _0x207400;_0x4ae363!=null?_0x207400=!0x0:(_0x207400=!0x1,_0x4ae363=g['EMPTY_NODE'],_0x343bdc['syncPointTree_']['subtree'](_0x44ad86)['foreachChild']((_0x42efc0,_0x517e6a)=>{const _0x9dfb39=Ee(_0x517e6a,w());_0x9dfb39&&(_0x4ae363=_0x4ae363['updateImmediateChild'](_0x42efc0,_0x9dfb39));}));const _0x491452=Jo(_0x26b115,_0x96cf6a);if(!_0x491452&&!_0x96cf6a['_queryParams']['loadsAllData']()){const _0x2abd7d=Un(_0x96cf6a);f(!_0x343bdc['queryToTagMap']['has'](_0x2abd7d),'View\x20does\x20not\x20exist,\x20but\x20we\x20have\x20a\x20tag');const _0x35e087=td();_0x343bdc['queryToTagMap']['set'](_0x2abd7d,_0x35e087),_0x343bdc['tagToQueryMap']['set'](_0x35e087,_0x2abd7d);}const _0x3ccc79=Ln(_0x343bdc['pendingWriteTree_'],_0x44ad86);let _0x4c85c2=Hu(_0x26b115,_0x96cf6a,_0x48e126,_0x3ccc79,_0x4ae363,_0x207400);if(!_0x491452&&!_0x14037e&&!_0x27ff2b){const _0x1b443f=Qo(_0x26b115,_0x96cf6a);_0x4c85c2=_0x4c85c2['concat'](nd(_0x343bdc,_0x96cf6a,_0x1b443f));}return _0x4c85c2;}function Fn(_0x19da4e,_0x509a02,_0x2c709d){const _0x41849f=_0x19da4e['pendingWriteTree_'],_0x20ec1c=_0x19da4e['syncPointTree_']['findOnPath'](_0x509a02,(_0x1bba8a,_0x2e22e0)=>{const _0x243eb4=F(_0x1bba8a,_0x509a02),_0x360e76=Ee(_0x2e22e0,_0x243eb4);if(_0x360e76)return _0x360e76;});return Vo(_0x41849f,_0x509a02,_0x20ec1c,_0x2c709d,!0x0);}function Xu(_0x185eb0,_0x306cb3){const _0x32f9fa=_0x306cb3['_path'];let _0x3d7570=null;_0x185eb0['syncPointTree_']['foreachOnPath'](_0x32f9fa,(_0x40f624,_0x1778ac)=>{const _0xa18d45=F(_0x40f624,_0x32f9fa);_0x3d7570=_0x3d7570||Ee(_0x1778ac,_0xa18d45);});let _0x3168ac=_0x185eb0['syncPointTree_']['get'](_0x32f9fa);_0x3168ac?_0x3d7570=_0x3d7570||Ee(_0x3168ac,w()):(_0x3168ac=new jo(),_0x185eb0['syncPointTree_']=_0x185eb0['syncPointTree_']['set'](_0x32f9fa,_0x3168ac));const _0x5a37f5=_0x3d7570!=null,_0x3d25a0=_0x5a37f5?new Ce(_0x3d7570,!0x0,!0x1):null,_0x28da44=Ln(_0x185eb0['pendingWriteTree_'],_0x306cb3['_path']),_0x5ac484=Ko(_0x3168ac,_0x306cb3,_0x28da44,_0x5a37f5?_0x3d25a0['getNode']():g['EMPTY_NODE'],_0x5a37f5);return Lu(_0x5ac484);}function ut(_0x3d29ca,_0x35b9a9){return Zo(_0x35b9a9,_0x3d29ca['syncPointTree_'],null,Ln(_0x3d29ca['pendingWriteTree_'],w()));}function Zo(_0x165d0d,_0x50be7c,_0x32010b,_0x9c503f){if(v(_0x165d0d['path']))return ea(_0x165d0d,_0x50be7c,_0x32010b,_0x9c503f);{const _0x4d527c=_0x50be7c['get'](w());_0x32010b==null&&_0x4d527c!=null&&(_0x32010b=Ee(_0x4d527c,w()));let _0x2f684d=[];const _0xddfb6a=y(_0x165d0d['path']),_0x2e3d0f=_0x165d0d['operationForChild'](_0xddfb6a),_0x47cad5=_0x50be7c['children']['get'](_0xddfb6a);if(_0x47cad5&&_0x2e3d0f){const _0x512c24=_0x32010b?_0x32010b['getImmediateChild'](_0xddfb6a):null,_0x1b0259=Ho(_0x9c503f,_0xddfb6a);_0x2f684d=_0x2f684d['concat'](Zo(_0x2e3d0f,_0x47cad5,_0x512c24,_0x1b0259));}return _0x4d527c&&(_0x2f684d=_0x2f684d['concat'](rs(_0x4d527c,_0x165d0d,_0x9c503f,_0x32010b))),_0x2f684d;}}function ea(_0x41c0fa,_0xfcf755,_0x3176f3,_0xaef7bc){const _0x22d812=_0xfcf755['get'](w());_0x3176f3==null&&_0x22d812!=null&&(_0x3176f3=Ee(_0x22d812,w()));let _0x5e21ed=[];return _0xfcf755['children']['inorderTraversal']((_0x29b08d,_0x4522a1)=>{const _0x396d61=_0x3176f3?_0x3176f3['getImmediateChild'](_0x29b08d):null,_0x3746b2=Ho(_0xaef7bc,_0x29b08d),_0x21456a=_0x41c0fa['operationForChild'](_0x29b08d);_0x21456a&&(_0x5e21ed=_0x5e21ed['concat'](ea(_0x21456a,_0x4522a1,_0x396d61,_0x3746b2)));}),_0x22d812&&(_0x5e21ed=_0x5e21ed['concat'](rs(_0x22d812,_0x41c0fa,_0xaef7bc,_0x3176f3))),_0x5e21ed;}function ta(_0x5a6ae8,_0x528984){const _0x476203=_0x528984['query'],_0x3e2de6=xt(_0x5a6ae8,_0x476203);return{'hashFn':()=>(Mu(_0x528984)||g['EMPTY_NODE'])['hash'](),'onComplete':_0x1e6b19=>{if(_0x1e6b19==='ok')return _0x3e2de6?Qu(_0x5a6ae8,_0x476203['_path'],_0x3e2de6):Yu(_0x5a6ae8,_0x476203['_path']);{const _0x5ab555=Kl(_0x1e6b19,_0x476203);return Cn(_0x5a6ae8,_0x476203,null,_0x5ab555);}}};}function xt(_0x4040ba,_0x200960){const _0x22572e=Un(_0x200960);return _0x4040ba['queryToTagMap']['get'](_0x22572e);}function Un(_0x53b015){return _0x53b015['_path']['toString']()+'$'+_0x53b015['_queryIdentifier'];}function as(_0x504e7e,_0x8fda43){return _0x504e7e['tagToQueryMap']['get'](_0x8fda43);}function cs(_0x5cb62e){const _0x58bf61=_0x5cb62e['indexOf']('$');return f(_0x58bf61!==-0x1&&_0x58bf61<_0x5cb62e['length']-0x1,'Bad\x20queryKey.'),{'queryId':_0x5cb62e['substr'](_0x58bf61+0x1),'path':new C(_0x5cb62e['substr'](0x0,_0x58bf61))};}function ls(_0x4b9e17,_0x37dd98,_0x3a4843){const _0x11ab63=_0x4b9e17['syncPointTree_']['get'](_0x37dd98);f(_0x11ab63,'Missing\x20sync\x20point\x20for\x20query\x20tag\x20that\x20we\x27re\x20tracking');const _0x13de52=Ln(_0x4b9e17['pendingWriteTree_'],_0x37dd98);return rs(_0x11ab63,_0x3a4843,_0x13de52,null);}function Zu(_0xe4ab94){return _0xe4ab94['fold']((_0x57f5c7,_0x6a19e,_0x1af5a2)=>{if(_0x6a19e&&Te(_0x6a19e))return[xn(_0x6a19e)];{let _0xebf17f=[];return _0x6a19e&&(_0xebf17f=Yo(_0x6a19e)),x(_0x1af5a2,(_0x363b6d,_0x196cfd)=>{_0xebf17f=_0xebf17f['concat'](_0x196cfd);}),_0xebf17f;}});}function bt(_0x12e9b5){return _0x12e9b5['_queryParams']['loadsAllData']()&&!_0x12e9b5['_queryParams']['isDefault']()?new(qu())(_0x12e9b5['_repo'],_0x12e9b5['_path']):_0x12e9b5;}function ed(_0x32a79c,_0x3b5ef4){for(let _0xb1dbf4=0x0;_0xb1dbf4<_0x3b5ef4['length'];++_0xb1dbf4){const _0x85c591=_0x3b5ef4[_0xb1dbf4];if(!_0x85c591['_queryParams']['loadsAllData']()){const _0x5b20c1=Un(_0x85c591),_0x50cac8=_0x32a79c['queryToTagMap']['get'](_0x5b20c1);_0x32a79c['queryToTagMap']['delete'](_0x5b20c1),_0x32a79c['tagToQueryMap']['delete'](_0x50cac8);}}}function td(){return zu++;}function nd(_0x586fce,_0x1585cb,_0x41651c){const _0x427303=_0x1585cb['_path'],_0x5caa8f=xt(_0x586fce,_0x1585cb),_0x67ada9=ta(_0x586fce,_0x41651c),_0xeaaba2=_0x586fce['listenProvider_']['startListening'](bt(_0x1585cb),_0x5caa8f,_0x67ada9['hashFn'],_0x67ada9['onComplete']),_0x2b21c9=_0x586fce['syncPointTree_']['subtree'](_0x427303);if(_0x5caa8f)f(!Te(_0x2b21c9['value']),'If\x20we\x27re\x20adding\x20a\x20query,\x20it\x20shouldn\x27t\x20be\x20shadowed');else{const _0x5e58be=_0x2b21c9['fold']((_0x1e3a45,_0x574ffd,_0x3ed4e4)=>{if(!v(_0x1e3a45)&&_0x574ffd&&Te(_0x574ffd))return[xn(_0x574ffd)['query']];{let _0x21991f=[];return _0x574ffd&&(_0x21991f=_0x21991f['concat'](Yo(_0x574ffd)['map'](_0x3302f8=>_0x3302f8['query']))),x(_0x3ed4e4,(_0x5f17b4,_0x4bbf37)=>{_0x21991f=_0x21991f['concat'](_0x4bbf37);}),_0x21991f;}});for(let _0x582ec9=0x0;_0x582ec9<_0x5e58be['length'];++_0x582ec9){const _0x388ff9=_0x5e58be[_0x582ec9];_0x586fce['listenProvider_']['stopListening'](bt(_0x388ff9),xt(_0x586fce,_0x388ff9));}}return _0xeaaba2;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class hs{constructor(_0x2ce206){this['node_']=_0x2ce206;}['getImmediateChild'](_0x902b22){const _0x1bf45f=this['node_']['getImmediateChild'](_0x902b22);return new hs(_0x1bf45f);}['node'](){return this['node_'];}}class us{constructor(_0x216b17,_0x5f1264){this['syncTree_']=_0x216b17,this['path_']=_0x5f1264;}['getImmediateChild'](_0x23a383){const _0x1d5842=k(this['path_'],_0x23a383);return new us(this['syncTree_'],_0x1d5842);}['node'](){return Fn(this['syncTree_'],this['path_']);}}const id=function(_0x3dd1a5){return _0x3dd1a5=_0x3dd1a5||{},_0x3dd1a5['timestamp']=_0x3dd1a5['timestamp']||new Date()['getTime'](),_0x3dd1a5;},gr=function(_0x776e9f,_0x5e1383,_0x39dbc4){if(!_0x776e9f||typeof _0x776e9f!='object')return _0x776e9f;if(f('.sv'in _0x776e9f,'Unexpected\x20leaf\x20node\x20or\x20priority\x20contents'),typeof _0x776e9f['.sv']=='string')return sd(_0x776e9f['.sv'],_0x5e1383,_0x39dbc4);if(typeof _0x776e9f['.sv']=='object')return rd(_0x776e9f['.sv'],_0x5e1383);f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x776e9f,null,0x2));},sd=function(_0x562dd2,_0x3d3719,_0x14ae86){switch(_0x562dd2){case'timestamp':return _0x14ae86['timestamp'];default:f(!0x1,'Unexpected\x20server\x20value:\x20'+_0x562dd2);}},rd=function(_0x3dfb35,_0x50b219,_0x2d84c4){_0x3dfb35['hasOwnProperty']('increment')||f(!0x1,'Unexpected\x20server\x20value:\x20'+JSON['stringify'](_0x3dfb35,null,0x2));const _0x433c15=_0x3dfb35['increment'];typeof _0x433c15!='number'&&f(!0x1,'Unexpected\x20increment\x20value:\x20'+_0x433c15);const _0xfe523c=_0x50b219['node']();if(f(_0xfe523c!==null&&typeof _0xfe523c<'u','Expected\x20ChildrenNode.EMPTY_NODE\x20for\x20nulls'),!_0xfe523c['isLeafNode']())return _0x433c15;const _0x470023=_0xfe523c['getValue']();return typeof _0x470023!='number'?_0x433c15:_0x470023+_0x433c15;},na=function(_0x34925e,_0x2ea108,_0x51ca09,_0x26147a){return fs(_0x2ea108,new us(_0x51ca09,_0x34925e),_0x26147a);},ds=function(_0x3b7c35,_0xaa8f1,_0x2839d8){return fs(_0x3b7c35,new hs(_0xaa8f1),_0x2839d8);};function fs(_0x3d4a9c,_0x54f9c3,_0x5db4b5){const _0x5011e4=_0x3d4a9c['getPriority']()['val'](),_0x30ac56=gr(_0x5011e4,_0x54f9c3['getImmediateChild']('.priority'),_0x5db4b5);let _0x5e9c84;if(_0x3d4a9c['isLeafNode']()){const _0xd2a20=_0x3d4a9c,_0x55ba17=gr(_0xd2a20['getValue'](),_0x54f9c3,_0x5db4b5);return _0x55ba17!==_0xd2a20['getValue']()||_0x30ac56!==_0xd2a20['getPriority']()['val']()?new D(_0x55ba17,P(_0x30ac56)):_0x3d4a9c;}else{const _0x1e652d=_0x3d4a9c;return _0x5e9c84=_0x1e652d,_0x30ac56!==_0x1e652d['getPriority']()['val']()&&(_0x5e9c84=_0x5e9c84['updatePriority'](new D(_0x30ac56))),_0x1e652d['forEachChild'](R,(_0x2ae1af,_0x524932)=>{const _0x2fb96b=fs(_0x524932,_0x54f9c3['getImmediateChild'](_0x2ae1af),_0x5db4b5);_0x2fb96b!==_0x524932&&(_0x5e9c84=_0x5e9c84['updateImmediateChild'](_0x2ae1af,_0x2fb96b));}),_0x5e9c84;}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ps{constructor(_0x296d22='',_0x3b848a=null,_0x848277={'children':{},'childCount':0x0}){this['name']=_0x296d22,this['parent']=_0x3b848a,this['node']=_0x848277;}}function Wn(_0x12a1db,_0x59232e){let _0x509e2c=_0x59232e instanceof C?_0x59232e:new C(_0x59232e),_0x196f6b=_0x12a1db,_0x4ddded=y(_0x509e2c);for(;_0x4ddded!==null;){const _0x3bdb87=De(_0x196f6b['node']['children'],_0x4ddded)||{'children':{},'childCount':0x0};_0x196f6b=new ps(_0x4ddded,_0x196f6b,_0x3bdb87),_0x509e2c=b(_0x509e2c),_0x4ddded=y(_0x509e2c);}return _0x196f6b;}function Ge(_0x22c289){return _0x22c289['node']['value'];}function _s(_0x525d2b,_0x14320e){_0x525d2b['node']['value']=_0x14320e,Ai(_0x525d2b);}function ia(_0x1d1421){return _0x1d1421['node']['childCount']>0x0;}function od(_0x5abf44){return Ge(_0x5abf44)===void 0x0&&!ia(_0x5abf44);}function Bn(_0x22d366,_0x27c8d5){x(_0x22d366['node']['children'],(_0x318e86,_0x42740d)=>{_0x27c8d5(new ps(_0x318e86,_0x22d366,_0x42740d));});}function sa(_0x56baf3,_0x14371a,_0x1edccb,_0x15c715){_0x1edccb&&_0x14371a(_0x56baf3),Bn(_0x56baf3,_0x224709=>{sa(_0x224709,_0x14371a,!0x0);});}function ad(_0xab9b51,_0x14d4eb,_0x318900){let _0x4d3a09=_0xab9b51['parent'];for(;_0x4d3a09!==null;){if(_0x14d4eb(_0x4d3a09))return!0x0;_0x4d3a09=_0x4d3a09['parent'];}return!0x1;}function qt(_0x53c131){return new C(_0x53c131['parent']===null?_0x53c131['name']:qt(_0x53c131['parent'])+'/'+_0x53c131['name']);}function Ai(_0x28cb91){_0x28cb91['parent']!==null&&cd(_0x28cb91['parent'],_0x28cb91['name'],_0x28cb91);}function cd(_0x15d925,_0x54f0b2,_0x17da44){const _0x261bb2=od(_0x17da44),_0x3cdc4f=J(_0x15d925['node']['children'],_0x54f0b2);_0x261bb2&&_0x3cdc4f?(delete _0x15d925['node']['children'][_0x54f0b2],_0x15d925['node']['childCount']--,Ai(_0x15d925)):!_0x261bb2&&!_0x3cdc4f&&(_0x15d925['node']['children'][_0x54f0b2]=_0x17da44['node'],_0x15d925['node']['childCount']++,Ai(_0x15d925));}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ld=/[\[\].#$\/\u0000-\u001F\u007F]/,hd=/[\[\].#$\u0000-\u001F\u007F]/,ai=0xa*0x400*0x400,gs=function(_0x2e87dd){return typeof _0x2e87dd=='string'&&_0x2e87dd['length']!==0x0&&!ld['test'](_0x2e87dd);},ra=function(_0x1c7f58){return typeof _0x1c7f58=='string'&&_0x1c7f58['length']!==0x0&&!hd['test'](_0x1c7f58);},ud=function(_0x4a9cd5){return _0x4a9cd5&&(_0x4a9cd5=_0x4a9cd5['replace'](/^\/*\.info(\/|$)/,'/')),ra(_0x4a9cd5);},Tn=function(_0x8a3bd5){return _0x8a3bd5===null||typeof _0x8a3bd5=='string'||typeof _0x8a3bd5=='number'&&!Vi(_0x8a3bd5)||_0x8a3bd5&&typeof _0x8a3bd5=='object'&&J(_0x8a3bd5,'.sv');},zt=function(_0x3713f0,_0x50f693,_0x46d514,_0x20ece6){_0x20ece6&&_0x50f693===void 0x0||jt(Pn(_0x3713f0,'value'),_0x50f693,_0x46d514);},jt=function(_0x25ea3a,_0x32dad2,_0x57c9ef){const _0x351ad5=_0x57c9ef instanceof C?new Ah(_0x57c9ef,_0x25ea3a):_0x57c9ef;if(_0x32dad2===void 0x0)throw new Error(_0x25ea3a+'contains\x20undefined\x20'+Pe(_0x351ad5));if(typeof _0x32dad2=='function')throw new Error(_0x25ea3a+'contains\x20a\x20function\x20'+Pe(_0x351ad5)+'\x20with\x20contents\x20=\x20'+_0x32dad2['toString']());if(Vi(_0x32dad2))throw new Error(_0x25ea3a+'contains\x20'+_0x32dad2['toString']()+'\x20'+Pe(_0x351ad5));if(typeof _0x32dad2=='string'&&_0x32dad2['length']>ai/0x3&&On(_0x32dad2)>ai)throw new Error(_0x25ea3a+'contains\x20a\x20string\x20greater\x20than\x20'+ai+'\x20utf8\x20bytes\x20'+Pe(_0x351ad5)+'\x20(\x27'+_0x32dad2['substring'](0x0,0x32)+'...\x27)');if(_0x32dad2&&typeof _0x32dad2=='object'){let _0x4ee929=!0x1,_0x5079b9=!0x1;if(x(_0x32dad2,(_0x4264f7,_0x4e38a6)=>{if(_0x4264f7==='.value')_0x4ee929=!0x0;else{if(_0x4264f7!=='.priority'&&_0x4264f7!=='.sv'&&(_0x5079b9=!0x0,!gs(_0x4264f7)))throw new Error(_0x25ea3a+'\x20contains\x20an\x20invalid\x20key\x20('+_0x4264f7+')\x20'+Pe(_0x351ad5)+'.\x20\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}kh(_0x351ad5,_0x4264f7),jt(_0x25ea3a,_0x4e38a6,_0x351ad5),Nh(_0x351ad5);}),_0x4ee929&&_0x5079b9)throw new Error(_0x25ea3a+'\x20contains\x20\x22.value\x22\x20child\x20'+Pe(_0x351ad5)+'\x20in\x20addition\x20to\x20actual\x20children.');}},dd=function(_0x5352c5,_0x29bf70){let _0x40405d,_0x480014;for(_0x40405d=0x0;_0x40405d<_0x29bf70['length'];_0x40405d++){_0x480014=_0x29bf70[_0x40405d];const _0x5c9f40=Pt(_0x480014);for(let _0x267c42=0x0;_0x267c42<_0x5c9f40['length'];_0x267c42++)if(!(_0x5c9f40[_0x267c42]==='.priority'&&_0x267c42===_0x5c9f40['length']-0x1)){if(!gs(_0x5c9f40[_0x267c42]))throw new Error(_0x5352c5+'contains\x20an\x20invalid\x20key\x20('+_0x5c9f40[_0x267c42]+')\x20in\x20path\x20'+_0x480014['toString']()+'.\x20Keys\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22/\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');}}_0x29bf70['sort'](Rh);let _0x127f6d=null;for(_0x40405d=0x0;_0x40405d<_0x29bf70['length'];_0x40405d++){if(_0x480014=_0x29bf70[_0x40405d],_0x127f6d!==null&&G(_0x127f6d,_0x480014))throw new Error(_0x5352c5+'contains\x20a\x20path\x20'+_0x127f6d['toString']()+'\x20that\x20is\x20ancestor\x20of\x20another\x20path\x20'+_0x480014['toString']());_0x127f6d=_0x480014;}},fd=function(_0x33a854,_0xf26487,_0x9dfc43,_0x938866){const _0x3c2c80=Pn(_0x33a854,'values');if(!(_0xf26487&&typeof _0xf26487=='object')||Array['isArray'](_0xf26487))throw new Error(_0x3c2c80+'\x20must\x20be\x20an\x20object\x20containing\x20the\x20children\x20to\x20replace.');const _0x1f579a=[];x(_0xf26487,(_0x37755e,_0x30f1df)=>{const _0x153bea=new C(_0x37755e);if(jt(_0x3c2c80,_0x30f1df,k(_0x9dfc43,_0x153bea)),zi(_0x153bea)==='.priority'&&!Tn(_0x30f1df))throw new Error(_0x3c2c80+'contains\x20an\x20invalid\x20value\x20for\x20\x27'+_0x153bea['toString']()+'\x27,\x20which\x20must\x20be\x20a\x20valid\x20Firebase\x20priority\x20(a\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null).');_0x1f579a['push'](_0x153bea);}),dd(_0x3c2c80,_0x1f579a);},ms=function(_0x4f4090,_0x1ceffd,_0x37112e,_0x1692cf){if(!ra(_0x37112e))throw new Error(Pn(_0x4f4090,_0x1ceffd)+'was\x20an\x20invalid\x20path\x20=\x20\x22'+_0x37112e+'\x22.\x20Paths\x20must\x20be\x20non-empty\x20strings\x20and\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22');},pd=function(_0x5145f0,_0x3ec365,_0x221f09,_0x197461){_0x221f09&&(_0x221f09=_0x221f09['replace'](/^\/*\.info(\/|$)/,'/')),ms(_0x5145f0,_0x3ec365,_0x221f09);},ys=function(_0x26ca95,_0x497a73){if(y(_0x497a73)==='.info')throw new Error(_0x26ca95+'\x20failed\x20=\x20Can\x27t\x20modify\x20data\x20under\x20/.info/');},_d=function(_0x38206a,_0x5b0d24){const _0xecfa1d=_0x5b0d24['path']['toString']();if(typeof _0x5b0d24['repoInfo']['host']!='string'||_0x5b0d24['repoInfo']['host']['length']===0x0||!gs(_0x5b0d24['repoInfo']['namespace'])&&_0x5b0d24['repoInfo']['host']['split'](':')[0x0]!=='localhost'||_0xecfa1d['length']!==0x0&&!ud(_0xecfa1d))throw new Error(Pn(_0x38206a,'url')+'must\x20be\x20a\x20valid\x20firebase\x20URL\x20and\x20the\x20path\x20can\x27t\x20contain\x20\x22.\x22,\x20\x22#\x22,\x20\x22$\x22,\x20\x22[\x22,\x20or\x20\x22]\x22.');};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class gd{constructor(){this['eventLists_']=[],this['recursionDepth_']=0x0;}}function Vn(_0x415388,_0x133109){let _0x4bbaea=null;for(let _0x3d052f=0x0;_0x3d052f<_0x133109['length'];_0x3d052f++){const _0x42a221=_0x133109[_0x3d052f],_0x2c2b6f=_0x42a221['getPath']();_0x4bbaea!==null&&!ji(_0x2c2b6f,_0x4bbaea['path'])&&(_0x415388['eventLists_']['push'](_0x4bbaea),_0x4bbaea=null),_0x4bbaea===null&&(_0x4bbaea={'events':[],'path':_0x2c2b6f}),_0x4bbaea['events']['push'](_0x42a221);}_0x4bbaea&&_0x415388['eventLists_']['push'](_0x4bbaea);}function oa(_0x1ca8b4,_0x389b3b,_0x184ac2){Vn(_0x1ca8b4,_0x184ac2),aa(_0x1ca8b4,_0x301bbf=>ji(_0x301bbf,_0x389b3b));}function H(_0x2b8afd,_0x21bf44,_0x183355){Vn(_0x2b8afd,_0x183355),aa(_0x2b8afd,_0x1727e6=>G(_0x1727e6,_0x21bf44)||G(_0x21bf44,_0x1727e6));}function aa(_0x838e4b,_0x58c2c6){_0x838e4b['recursionDepth_']++;let _0x2e30b4=!0x0;for(let _0xc42d7=0x0;_0xc42d7<_0x838e4b['eventLists_']['length'];_0xc42d7++){const _0x58495a=_0x838e4b['eventLists_'][_0xc42d7];if(_0x58495a){const _0x5f3603=_0x58495a['path'];_0x58c2c6(_0x5f3603)?(md(_0x838e4b['eventLists_'][_0xc42d7]),_0x838e4b['eventLists_'][_0xc42d7]=null):_0x2e30b4=!0x1;}}_0x2e30b4&&(_0x838e4b['eventLists_']=[]),_0x838e4b['recursionDepth_']--;}function md(_0x13d850){for(let _0x12ee27=0x0;_0x12ee27<_0x13d850['events']['length'];_0x12ee27++){const _0x4ff6c0=_0x13d850['events'][_0x12ee27];if(_0x4ff6c0!==null){_0x13d850['events'][_0x12ee27]=null;const _0x5e291c=_0x4ff6c0['getEventRunner']();wt&&L('event:\x20'+_0x4ff6c0['toString']()),ht(_0x5e291c);}}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ca='repo_interrupt',yd=0x19;class vd{constructor(_0x693cd8,_0x210ea2,_0x593f49,_0x1801d8){this['repoInfo_']=_0x693cd8,this['forceRestClient_']=_0x210ea2,this['authTokenProvider_']=_0x593f49,this['appCheckProvider_']=_0x1801d8,this['dataUpdateCount']=0x0,this['statsListener_']=null,this['eventQueue_']=new gd(),this['nextWriteId_']=0x1,this['interceptServerDataCallback_']=null,this['onDisconnect_']=_n(),this['transactionQueueTree_']=new ps(),this['persistentConnection_']=null,this['key']=this['repoInfo_']['toURLString']();}['toString'](){return(this['repoInfo_']['secure']?'https://':'http://')+this['repoInfo_']['host'];}}function Ed(_0x2a317b,_0x5ebfae,_0x1599db){if(_0x2a317b['stats_']=Gi(_0x2a317b['repoInfo_']),_0x2a317b['forceRestClient_']||Xl())_0x2a317b['server_']=new pn(_0x2a317b['repoInfo_'],(_0x413885,_0x40142f,_0x5dca96,_0x1e1190)=>{mr(_0x2a317b,_0x413885,_0x40142f,_0x5dca96,_0x1e1190);},_0x2a317b['authTokenProvider_'],_0x2a317b['appCheckProvider_']),setTimeout(()=>yr(_0x2a317b,!0x0),0x0);else{if(typeof _0x1599db<'u'&&_0x1599db!==null){if(typeof _0x1599db!='object')throw new Error('Only\x20objects\x20are\x20supported\x20for\x20option\x20databaseAuthVariableOverride');try{O(_0x1599db);}catch(_0x5b334d){throw new Error('Invalid\x20authOverride\x20provided:\x20'+_0x5b334d);}}_0x2a317b['persistentConnection_']=new se(_0x2a317b['repoInfo_'],_0x5ebfae,(_0x329bf9,_0x9b700d,_0x87f700,_0x75edf4)=>{mr(_0x2a317b,_0x329bf9,_0x9b700d,_0x87f700,_0x75edf4);},_0xf61f96=>{yr(_0x2a317b,_0xf61f96);},_0x2fb0ed=>{Id(_0x2a317b,_0x2fb0ed);},_0x2a317b['authTokenProvider_'],_0x2a317b['appCheckProvider_'],_0x1599db),_0x2a317b['server_']=_0x2a317b['persistentConnection_'];}_0x2a317b['authTokenProvider_']['addTokenChangeListener'](_0xae832e=>{_0x2a317b['server_']['refreshAuthToken'](_0xae832e);}),_0x2a317b['appCheckProvider_']['addTokenChangeListener'](_0x357369=>{_0x2a317b['server_']['refreshAppCheckToken'](_0x357369['token']);}),_0x2a317b['statsReporter_']=ih(_0x2a317b['repoInfo_'],()=>new iu(_0x2a317b['stats_'],_0x2a317b['server_'])),_0x2a317b['infoData_']=new Xh(),_0x2a317b['infoSyncTree_']=new _r({'startListening':(_0x368664,_0x5c9066,_0x5619dc,_0xc57932)=>{let _0x50fa45=[];const _0x51bd5e=_0x2a317b['infoData_']['getNode'](_0x368664['_path']);return _0x51bd5e['isEmpty']()||(_0x50fa45=Gt(_0x2a317b['infoSyncTree_'],_0x368664['_path'],_0x51bd5e),setTimeout(()=>{_0xc57932('ok');},0x0)),_0x50fa45;},'stopListening':()=>{}}),vs(_0x2a317b,'connected',!0x1),_0x2a317b['serverSyncTree_']=new _r({'startListening':(_0x35d325,_0x514463,_0x23457d,_0x35e5a1)=>(_0x2a317b['server_']['listen'](_0x35d325,_0x23457d,_0x514463,(_0x5746d4,_0x639fa2)=>{const _0x193a5f=_0x35e5a1(_0x5746d4,_0x639fa2);H(_0x2a317b['eventQueue_'],_0x35d325['_path'],_0x193a5f);}),[]),'stopListening':(_0x1bd140,_0x2d82da)=>{_0x2a317b['server_']['unlisten'](_0x1bd140,_0x2d82da);}});}function la(_0x9f92d0){const _0x484742=_0x9f92d0['infoData_']['getNode'](new C('.info/serverTimeOffset'))['val']()||0x0;return new Date()['getTime']()+_0x484742;}function Kt(_0x53a996){return id({'timestamp':la(_0x53a996)});}function mr(_0x5b5c0e,_0x4305b0,_0x1e22c2,_0x16b64c,_0xabce33){_0x5b5c0e['dataUpdateCount']++;const _0x5449b3=new C(_0x4305b0);_0x1e22c2=_0x5b5c0e['interceptServerDataCallback_']?_0x5b5c0e['interceptServerDataCallback_'](_0x4305b0,_0x1e22c2):_0x1e22c2;let _0x2a4329=[];if(_0xabce33){if(_0x16b64c){const _0x4dda02=hn(_0x1e22c2,_0x27d54d=>P(_0x27d54d));_0x2a4329=Ju(_0x5b5c0e['serverSyncTree_'],_0x5449b3,_0x4dda02,_0xabce33);}else{const _0x35431a=P(_0x1e22c2);_0x2a4329=Xo(_0x5b5c0e['serverSyncTree_'],_0x5449b3,_0x35431a,_0xabce33);}}else{if(_0x16b64c){const _0x334894=hn(_0x1e22c2,_0x20b632=>P(_0x20b632));_0x2a4329=Ku(_0x5b5c0e['serverSyncTree_'],_0x5449b3,_0x334894);}else{const _0x3afb08=P(_0x1e22c2);_0x2a4329=Gt(_0x5b5c0e['serverSyncTree_'],_0x5449b3,_0x3afb08);}}let _0x43b3d8=_0x5449b3;_0x2a4329['length']>0x0&&(_0x43b3d8=it(_0x5b5c0e,_0x5449b3)),H(_0x5b5c0e['eventQueue_'],_0x43b3d8,_0x2a4329);}function yr(_0x4145d9,_0x1903e3){vs(_0x4145d9,'connected',_0x1903e3),_0x1903e3===!0x1&&Sd(_0x4145d9);}function Id(_0x452669,_0x2102a2){x(_0x2102a2,(_0x1614e0,_0x45a15d)=>{vs(_0x452669,_0x1614e0,_0x45a15d);});}function vs(_0x51c47c,_0x1cd383,_0x5c30a9){const _0x5d4155=new C('/.info/'+_0x1cd383),_0x567fca=P(_0x5c30a9);_0x51c47c['infoData_']['updateSnapshot'](_0x5d4155,_0x567fca);const _0x5d7d5a=Gt(_0x51c47c['infoSyncTree_'],_0x5d4155,_0x567fca);H(_0x51c47c['eventQueue_'],_0x5d4155,_0x5d7d5a);}function Hn(_0x3be397){return _0x3be397['nextWriteId_']++;}function wd(_0x3155d2,_0x506be3,_0x880a51){const _0x43cd55=Xu(_0x3155d2['serverSyncTree_'],_0x506be3);return _0x43cd55!=null?Promise['resolve'](_0x43cd55):_0x3155d2['server_']['get'](_0x506be3)['then'](_0x34bada=>{const _0x70431=P(_0x34bada)['withIndex'](_0x506be3['_queryParams']['getIndex']());Ri(_0x3155d2['serverSyncTree_'],_0x506be3,_0x880a51,!0x0);let _0x50e7b7;if(_0x506be3['_queryParams']['loadsAllData']())_0x50e7b7=Gt(_0x3155d2['serverSyncTree_'],_0x506be3['_path'],_0x70431);else{const _0x2407bf=xt(_0x3155d2['serverSyncTree_'],_0x506be3);_0x50e7b7=Xo(_0x3155d2['serverSyncTree_'],_0x506be3['_path'],_0x70431,_0x2407bf);}return H(_0x3155d2['eventQueue_'],_0x506be3['_path'],_0x50e7b7),Cn(_0x3155d2['serverSyncTree_'],_0x506be3,_0x880a51,null,!0x0),_0x70431;},_0x47d876=>(dt(_0x3155d2,'get\x20for\x20query\x20'+O(_0x506be3)+'\x20failed:\x20'+_0x47d876),Promise['reject'](new Error(_0x47d876))));}function Cd(_0x40ed5a,_0x5d130d,_0x1ee58c,_0x48ae47,_0x2f2990){dt(_0x40ed5a,'set',{'path':_0x5d130d['toString'](),'value':_0x1ee58c,'priority':_0x48ae47});const _0x569e65=Kt(_0x40ed5a),_0x130b86=P(_0x1ee58c,_0x48ae47),_0x334375=Fn(_0x40ed5a['serverSyncTree_'],_0x5d130d),_0x4fd590=ds(_0x130b86,_0x334375,_0x569e65),_0x5ad801=Hn(_0x40ed5a),_0x435aa1=os(_0x40ed5a['serverSyncTree_'],_0x5d130d,_0x4fd590,_0x5ad801,!0x0);Vn(_0x40ed5a['eventQueue_'],_0x435aa1),_0x40ed5a['server_']['put'](_0x5d130d['toString'](),_0x130b86['val'](!0x0),(_0x1b3f6c,_0x5c816a)=>{const _0x4f5afd=_0x1b3f6c==='ok';_0x4f5afd||U('set\x20at\x20'+_0x5d130d+'\x20failed:\x20'+_0x1b3f6c);const _0x31e905=pe(_0x40ed5a['serverSyncTree_'],_0x5ad801,!_0x4f5afd);H(_0x40ed5a['eventQueue_'],_0x5d130d,_0x31e905),ki(_0x40ed5a,_0x2f2990,_0x1b3f6c,_0x5c816a);});const _0x5e4916=Is(_0x40ed5a,_0x5d130d);it(_0x40ed5a,_0x5e4916),H(_0x40ed5a['eventQueue_'],_0x5e4916,[]);}function Td(_0xa1f2f4,_0x140d25,_0x4f1478,_0x52e7e5){dt(_0xa1f2f4,'update',{'path':_0x140d25['toString'](),'value':_0x4f1478});let _0x2baeae=!0x0;const _0x5d1757=Kt(_0xa1f2f4),_0x1840b1={};if(x(_0x4f1478,(_0x17c764,_0x5c3161)=>{_0x2baeae=!0x1,_0x1840b1[_0x17c764]=na(k(_0x140d25,_0x17c764),P(_0x5c3161),_0xa1f2f4['serverSyncTree_'],_0x5d1757);}),_0x2baeae)L('update()\x20called\x20with\x20empty\x20data.\x20\x20Don\x27t\x20do\x20anything.'),ki(_0xa1f2f4,_0x52e7e5,'ok',void 0x0);else{const _0x3b27b0=Hn(_0xa1f2f4),_0x2bb0f4=ju(_0xa1f2f4['serverSyncTree_'],_0x140d25,_0x1840b1,_0x3b27b0);Vn(_0xa1f2f4['eventQueue_'],_0x2bb0f4),_0xa1f2f4['server_']['merge'](_0x140d25['toString'](),_0x4f1478,(_0x30a6c1,_0xee7719)=>{const _0x27449a=_0x30a6c1==='ok';_0x27449a||U('update\x20at\x20'+_0x140d25+'\x20failed:\x20'+_0x30a6c1);const _0x45db2a=pe(_0xa1f2f4['serverSyncTree_'],_0x3b27b0,!_0x27449a),_0x35ad80=_0x45db2a['length']>0x0?it(_0xa1f2f4,_0x140d25):_0x140d25;H(_0xa1f2f4['eventQueue_'],_0x35ad80,_0x45db2a),ki(_0xa1f2f4,_0x52e7e5,_0x30a6c1,_0xee7719);}),x(_0x4f1478,_0xce3a96=>{const _0x31bc42=Is(_0xa1f2f4,k(_0x140d25,_0xce3a96));it(_0xa1f2f4,_0x31bc42);}),H(_0xa1f2f4['eventQueue_'],_0x140d25,[]);}}function Sd(_0x1515a4){dt(_0x1515a4,'onDisconnectEvents');const _0x987e03=Kt(_0x1515a4),_0x28448b=_n();Ii(_0x1515a4['onDisconnect_'],w(),(_0x3c453b,_0x46bfbc)=>{const _0xa5bdc6=na(_0x3c453b,_0x46bfbc,_0x1515a4['serverSyncTree_'],_0x987e03);Fo(_0x28448b,_0x3c453b,_0xa5bdc6);});let _0x2bd44e=[];Ii(_0x28448b,w(),(_0x3bf310,_0x2fe566)=>{_0x2bd44e=_0x2bd44e['concat'](Gt(_0x1515a4['serverSyncTree_'],_0x3bf310,_0x2fe566));const _0x7c8895=Is(_0x1515a4,_0x3bf310);it(_0x1515a4,_0x7c8895);}),_0x1515a4['onDisconnect_']=_n(),H(_0x1515a4['eventQueue_'],w(),_0x2bd44e);}function bd(_0x413fd4,_0x4eef43,_0x2b743a){let _0x1dfc8b;y(_0x4eef43['_path'])==='.info'?_0x1dfc8b=Ri(_0x413fd4['infoSyncTree_'],_0x4eef43,_0x2b743a):_0x1dfc8b=Ri(_0x413fd4['serverSyncTree_'],_0x4eef43,_0x2b743a),oa(_0x413fd4['eventQueue_'],_0x4eef43['_path'],_0x1dfc8b);}function Rd(_0x338b8c,_0xc92986,_0x1da1c1){let _0x4dc33d;y(_0xc92986['_path'])==='.info'?_0x4dc33d=Cn(_0x338b8c['infoSyncTree_'],_0xc92986,_0x1da1c1):_0x4dc33d=Cn(_0x338b8c['serverSyncTree_'],_0xc92986,_0x1da1c1),oa(_0x338b8c['eventQueue_'],_0xc92986['_path'],_0x4dc33d);}function ha(_0x5efe65){_0x5efe65['persistentConnection_']&&_0x5efe65['persistentConnection_']['interrupt'](ca);}function Ad(_0x362fdb){_0x362fdb['persistentConnection_']&&_0x362fdb['persistentConnection_']['resume'](ca);}function dt(_0x3427f1,..._0x26cbca){let _0x2b2d7c='';_0x3427f1['persistentConnection_']&&(_0x2b2d7c=_0x3427f1['persistentConnection_']['id']+':'),L(_0x2b2d7c,..._0x26cbca);}function ki(_0x12d833,_0x5267bc,_0x3d5fbc,_0x445d61){_0x5267bc&&ht(()=>{if(_0x3d5fbc==='ok')_0x5267bc(null);else{const _0x1a49e8=(_0x3d5fbc||'error')['toUpperCase']();let _0x448129=_0x1a49e8;_0x445d61&&(_0x448129+=':\x20'+_0x445d61);const _0x54dc40=new Error(_0x448129);_0x54dc40['code']=_0x1a49e8,_0x5267bc(_0x54dc40);}});}function kd(_0xad796e,_0x24def3,_0x4b829c,_0x243117,_0x228421,_0x3deb8f){dt(_0xad796e,'transaction\x20on\x20'+_0x24def3);const _0x390d0e={'path':_0x24def3,'update':_0x4b829c,'onComplete':_0x243117,'status':null,'order':so(),'applyLocally':_0x3deb8f,'retryCount':0x0,'unwatcher':_0x228421,'abortReason':null,'currentWriteId':null,'currentInputSnapshot':null,'currentOutputSnapshotRaw':null,'currentOutputSnapshotResolved':null},_0x2aa6a3=Es(_0xad796e,_0x24def3,void 0x0);_0x390d0e['currentInputSnapshot']=_0x2aa6a3;const _0x35e431=_0x390d0e['update'](_0x2aa6a3['val']());if(_0x35e431===void 0x0)_0x390d0e['unwatcher'](),_0x390d0e['currentOutputSnapshotRaw']=null,_0x390d0e['currentOutputSnapshotResolved']=null,_0x390d0e['onComplete']&&_0x390d0e['onComplete'](null,!0x1,_0x390d0e['currentInputSnapshot']);else{jt('transaction\x20failed:\x20Data\x20returned\x20',_0x35e431,_0x390d0e['path']),_0x390d0e['status']=0x0;const _0x516299=Wn(_0xad796e['transactionQueueTree_'],_0x24def3),_0x389fa1=Ge(_0x516299)||[];_0x389fa1['push'](_0x390d0e),_s(_0x516299,_0x389fa1);let _0x4be660;typeof _0x35e431=='object'&&_0x35e431!==null&&J(_0x35e431,'.priority')?(_0x4be660=De(_0x35e431,'.priority'),f(Tn(_0x4be660),'Invalid\x20priority\x20returned\x20by\x20transaction.\x20Priority\x20must\x20be\x20a\x20valid\x20string,\x20finite\x20number,\x20server\x20value,\x20or\x20null.')):_0x4be660=(Fn(_0xad796e['serverSyncTree_'],_0x24def3)||g['EMPTY_NODE'])['getPriority']()['val']();const _0x139c60=Kt(_0xad796e),_0xcc143d=P(_0x35e431,_0x4be660),_0x4ab62c=ds(_0xcc143d,_0x2aa6a3,_0x139c60);_0x390d0e['currentOutputSnapshotRaw']=_0xcc143d,_0x390d0e['currentOutputSnapshotResolved']=_0x4ab62c,_0x390d0e['currentWriteId']=Hn(_0xad796e);const _0x3393fb=os(_0xad796e['serverSyncTree_'],_0x24def3,_0x4ab62c,_0x390d0e['currentWriteId'],_0x390d0e['applyLocally']);H(_0xad796e['eventQueue_'],_0x24def3,_0x3393fb),$n(_0xad796e,_0xad796e['transactionQueueTree_']);}}function Es(_0x30b8bf,_0x1911f2,_0x3c2cae){return Fn(_0x30b8bf['serverSyncTree_'],_0x1911f2,_0x3c2cae)||g['EMPTY_NODE'];}function $n(_0x10befb,_0x2697ad=_0x10befb['transactionQueueTree_']){if(_0x2697ad||Gn(_0x10befb,_0x2697ad),Ge(_0x2697ad)){const _0x49b125=da(_0x10befb,_0x2697ad);f(_0x49b125['length']>0x0,'Sending\x20zero\x20length\x20transaction\x20queue'),_0x49b125['every'](_0x174cba=>_0x174cba['status']===0x0)&&Nd(_0x10befb,qt(_0x2697ad),_0x49b125);}else ia(_0x2697ad)&&Bn(_0x2697ad,_0x23deb8=>{$n(_0x10befb,_0x23deb8);});}function Nd(_0x3b5da0,_0x457637,_0x2e5dfa){const _0x542883=_0x2e5dfa['map'](_0x16b43e=>_0x16b43e['currentWriteId']),_0x5a8b13=Es(_0x3b5da0,_0x457637,_0x542883);let _0x3a8169=_0x5a8b13;const _0x31e0d7=_0x5a8b13['hash']();for(let _0x2b66f1=0x0;_0x2b66f1<_0x2e5dfa['length'];_0x2b66f1++){const _0x71b87c=_0x2e5dfa[_0x2b66f1];f(_0x71b87c['status']===0x0,'tryToSendTransactionQueue_:\x20items\x20in\x20queue\x20should\x20all\x20be\x20run.'),_0x71b87c['status']=0x1,_0x71b87c['retryCount']++;const _0x203caa=F(_0x457637,_0x71b87c['path']);_0x3a8169=_0x3a8169['updateChild'](_0x203caa,_0x71b87c['currentOutputSnapshotRaw']);}const _0x1e3749=_0x3a8169['val'](!0x0),_0x17671c=_0x457637;_0x3b5da0['server_']['put'](_0x17671c['toString'](),_0x1e3749,_0x52f2df=>{dt(_0x3b5da0,'transaction\x20put\x20response',{'path':_0x17671c['toString'](),'status':_0x52f2df});let _0x2f27a9=[];if(_0x52f2df==='ok'){const _0x5a26e2=[];for(let _0x4630df=0x0;_0x4630df<_0x2e5dfa['length'];_0x4630df++)_0x2e5dfa[_0x4630df]['status']=0x2,_0x2f27a9=_0x2f27a9['concat'](pe(_0x3b5da0['serverSyncTree_'],_0x2e5dfa[_0x4630df]['currentWriteId'])),_0x2e5dfa[_0x4630df]['onComplete']&&_0x5a26e2['push'](()=>_0x2e5dfa[_0x4630df]['onComplete'](null,!0x0,_0x2e5dfa[_0x4630df]['currentOutputSnapshotResolved'])),_0x2e5dfa[_0x4630df]['unwatcher']();Gn(_0x3b5da0,Wn(_0x3b5da0['transactionQueueTree_'],_0x457637)),$n(_0x3b5da0,_0x3b5da0['transactionQueueTree_']),H(_0x3b5da0['eventQueue_'],_0x457637,_0x2f27a9);for(let _0x4c3dfd=0x0;_0x4c3dfd<_0x5a26e2['length'];_0x4c3dfd++)ht(_0x5a26e2[_0x4c3dfd]);}else{if(_0x52f2df==='datastale'){for(let _0x5a9656=0x0;_0x5a9656<_0x2e5dfa['length'];_0x5a9656++)_0x2e5dfa[_0x5a9656]['status']===0x3?_0x2e5dfa[_0x5a9656]['status']=0x4:_0x2e5dfa[_0x5a9656]['status']=0x0;}else{U('transaction\x20at\x20'+_0x17671c['toString']()+'\x20failed:\x20'+_0x52f2df);for(let _0x90bc7f=0x0;_0x90bc7f<_0x2e5dfa['length'];_0x90bc7f++)_0x2e5dfa[_0x90bc7f]['status']=0x4,_0x2e5dfa[_0x90bc7f]['abortReason']=_0x52f2df;}it(_0x3b5da0,_0x457637);}},_0x31e0d7);}function it(_0x53d75a,_0x16bd44){const _0x11d48a=ua(_0x53d75a,_0x16bd44),_0x38ad9e=qt(_0x11d48a),_0x54771c=da(_0x53d75a,_0x11d48a);return Pd(_0x53d75a,_0x54771c,_0x38ad9e),_0x38ad9e;}function Pd(_0x3a109f,_0x41ea44,_0x46f916){if(_0x41ea44['length']===0x0)return;const _0x170dbb=[];let _0x1171e3=[];const _0x3ccefd=_0x41ea44['filter'](_0x2e6f7a=>_0x2e6f7a['status']===0x0)['map'](_0x3b4133=>_0x3b4133['currentWriteId']);for(let _0x429af6=0x0;_0x429af6<_0x41ea44['length'];_0x429af6++){const _0x5222ad=_0x41ea44[_0x429af6],_0x3ed1fc=F(_0x46f916,_0x5222ad['path']);let _0x55c8d3=!0x1,_0x368bb3;if(f(_0x3ed1fc!==null,'rerunTransactionsUnderNode_:\x20relativePath\x20should\x20not\x20be\x20null.'),_0x5222ad['status']===0x4)_0x55c8d3=!0x0,_0x368bb3=_0x5222ad['abortReason'],_0x1171e3=_0x1171e3['concat'](pe(_0x3a109f['serverSyncTree_'],_0x5222ad['currentWriteId'],!0x0));else{if(_0x5222ad['status']===0x0){if(_0x5222ad['retryCount']>=yd)_0x55c8d3=!0x0,_0x368bb3='maxretry',_0x1171e3=_0x1171e3['concat'](pe(_0x3a109f['serverSyncTree_'],_0x5222ad['currentWriteId'],!0x0));else{const _0x43752a=Es(_0x3a109f,_0x5222ad['path'],_0x3ccefd);_0x5222ad['currentInputSnapshot']=_0x43752a;const _0x4f9222=_0x41ea44[_0x429af6]['update'](_0x43752a['val']());if(_0x4f9222!==void 0x0){jt('transaction\x20failed:\x20Data\x20returned\x20',_0x4f9222,_0x5222ad['path']);let _0x35974e=P(_0x4f9222);typeof _0x4f9222=='object'&&_0x4f9222!=null&&J(_0x4f9222,'.priority')||(_0x35974e=_0x35974e['updatePriority'](_0x43752a['getPriority']()));const _0x4e426e=_0x5222ad['currentWriteId'],_0x5e3416=Kt(_0x3a109f),_0x101833=ds(_0x35974e,_0x43752a,_0x5e3416);_0x5222ad['currentOutputSnapshotRaw']=_0x35974e,_0x5222ad['currentOutputSnapshotResolved']=_0x101833,_0x5222ad['currentWriteId']=Hn(_0x3a109f),_0x3ccefd['splice'](_0x3ccefd['indexOf'](_0x4e426e),0x1),_0x1171e3=_0x1171e3['concat'](os(_0x3a109f['serverSyncTree_'],_0x5222ad['path'],_0x101833,_0x5222ad['currentWriteId'],_0x5222ad['applyLocally'])),_0x1171e3=_0x1171e3['concat'](pe(_0x3a109f['serverSyncTree_'],_0x4e426e,!0x0));}else _0x55c8d3=!0x0,_0x368bb3='nodata',_0x1171e3=_0x1171e3['concat'](pe(_0x3a109f['serverSyncTree_'],_0x5222ad['currentWriteId'],!0x0));}}}H(_0x3a109f['eventQueue_'],_0x46f916,_0x1171e3),_0x1171e3=[],_0x55c8d3&&(_0x41ea44[_0x429af6]['status']=0x2,function(_0x3658dd){setTimeout(_0x3658dd,Math['floor'](0x0));}(_0x41ea44[_0x429af6]['unwatcher']),_0x41ea44[_0x429af6]['onComplete']&&(_0x368bb3==='nodata'?_0x170dbb['push'](()=>_0x41ea44[_0x429af6]['onComplete'](null,!0x1,_0x41ea44[_0x429af6]['currentInputSnapshot'])):_0x170dbb['push'](()=>_0x41ea44[_0x429af6]['onComplete'](new Error(_0x368bb3),!0x1,null))));}Gn(_0x3a109f,_0x3a109f['transactionQueueTree_']);for(let _0x4063d3=0x0;_0x4063d3<_0x170dbb['length'];_0x4063d3++)ht(_0x170dbb[_0x4063d3]);$n(_0x3a109f,_0x3a109f['transactionQueueTree_']);}function ua(_0x6584f6,_0xafaaf3){let _0x58846a,_0x22c6e6=_0x6584f6['transactionQueueTree_'];for(_0x58846a=y(_0xafaaf3);_0x58846a!==null&&Ge(_0x22c6e6)===void 0x0;)_0x22c6e6=Wn(_0x22c6e6,_0x58846a),_0xafaaf3=b(_0xafaaf3),_0x58846a=y(_0xafaaf3);return _0x22c6e6;}function da(_0x36df18,_0x18656f){const _0x3040d9=[];return fa(_0x36df18,_0x18656f,_0x3040d9),_0x3040d9['sort']((_0x2c00b1,_0x418c44)=>_0x2c00b1['order']-_0x418c44['order']),_0x3040d9;}function fa(_0x407ae,_0x32011c,_0x14754a){const _0x4e4f1f=Ge(_0x32011c);if(_0x4e4f1f){for(let _0x505f9d=0x0;_0x505f9d<_0x4e4f1f['length'];_0x505f9d++)_0x14754a['push'](_0x4e4f1f[_0x505f9d]);}Bn(_0x32011c,_0x232b45=>{fa(_0x407ae,_0x232b45,_0x14754a);});}function Gn(_0x5b4215,_0x3e4753){const _0x3701ae=Ge(_0x3e4753);if(_0x3701ae){let _0x34dbfa=0x0;for(let _0x449257=0x0;_0x449257<_0x3701ae['length'];_0x449257++)_0x3701ae[_0x449257]['status']!==0x2&&(_0x3701ae[_0x34dbfa]=_0x3701ae[_0x449257],_0x34dbfa++);_0x3701ae['length']=_0x34dbfa,_s(_0x3e4753,_0x3701ae['length']>0x0?_0x3701ae:void 0x0);}Bn(_0x3e4753,_0x3de053=>{Gn(_0x5b4215,_0x3de053);});}function Is(_0x1656f8,_0x4f65c2){const _0x1e16b0=qt(ua(_0x1656f8,_0x4f65c2)),_0x56edfd=Wn(_0x1656f8['transactionQueueTree_'],_0x4f65c2);return ad(_0x56edfd,_0x504a08=>{ci(_0x1656f8,_0x504a08);}),ci(_0x1656f8,_0x56edfd),sa(_0x56edfd,_0x554e5a=>{ci(_0x1656f8,_0x554e5a);}),_0x1e16b0;}function ci(_0x265240,_0x2a817b){const _0x45a4db=Ge(_0x2a817b);if(_0x45a4db){const _0x20e0ca=[];let _0xe15c50=[],_0x2ef2d6=-0x1;for(let _0x203bbb=0x0;_0x203bbb<_0x45a4db['length'];_0x203bbb++)_0x45a4db[_0x203bbb]['status']===0x3||(_0x45a4db[_0x203bbb]['status']===0x1?(f(_0x2ef2d6===_0x203bbb-0x1,'All\x20SENT\x20items\x20should\x20be\x20at\x20beginning\x20of\x20queue.'),_0x2ef2d6=_0x203bbb,_0x45a4db[_0x203bbb]['status']=0x3,_0x45a4db[_0x203bbb]['abortReason']='set'):(f(_0x45a4db[_0x203bbb]['status']===0x0,'Unexpected\x20transaction\x20status\x20in\x20abort'),_0x45a4db[_0x203bbb]['unwatcher'](),_0xe15c50=_0xe15c50['concat'](pe(_0x265240['serverSyncTree_'],_0x45a4db[_0x203bbb]['currentWriteId'],!0x0)),_0x45a4db[_0x203bbb]['onComplete']&&_0x20e0ca['push'](_0x45a4db[_0x203bbb]['onComplete']['bind'](null,new Error('set'),!0x1,null))));_0x2ef2d6===-0x1?_s(_0x2a817b,void 0x0):_0x45a4db['length']=_0x2ef2d6+0x1,H(_0x265240['eventQueue_'],qt(_0x2a817b),_0xe15c50);for(let _0x2bdf35=0x0;_0x2bdf35<_0x20e0ca['length'];_0x2bdf35++)ht(_0x20e0ca[_0x2bdf35]);}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Od(_0x224a32){let _0x122cf8='';const _0x19eaa8=_0x224a32['split']('/');for(let _0x1940c5=0x0;_0x1940c5<_0x19eaa8['length'];_0x1940c5++)if(_0x19eaa8[_0x1940c5]['length']>0x0){let _0x3e10da=_0x19eaa8[_0x1940c5];try{_0x3e10da=decodeURIComponent(_0x3e10da['replace'](/\+/g,'\x20'));}catch{}_0x122cf8+='/'+_0x3e10da;}return _0x122cf8;}function Dd(_0x4599a6){const _0x47e3ba={};_0x4599a6['charAt'](0x0)==='?'&&(_0x4599a6=_0x4599a6['substring'](0x1));for(const _0x15ed0d of _0x4599a6['split']('&')){if(_0x15ed0d['length']===0x0)continue;const _0x415331=_0x15ed0d['split']('=');_0x415331['length']===0x2?_0x47e3ba[decodeURIComponent(_0x415331[0x0])]=decodeURIComponent(_0x415331[0x1]):U('Invalid\x20query\x20segment\x20\x27'+_0x15ed0d+'\x27\x20in\x20query\x20\x27'+_0x4599a6+'\x27');}return _0x47e3ba;}const vr=function(_0x5b071e,_0x55acb1){const _0x3a47f1=Md(_0x5b071e),_0x11c84c=_0x3a47f1['namespace'];_0x3a47f1['domain']==='firebase.com'&&ae(_0x3a47f1['host']+'\x20is\x20no\x20longer\x20supported.\x20Please\x20use\x20<YOUR\x20FIREBASE>.firebaseio.com\x20instead'),(!_0x11c84c||_0x11c84c==='undefined')&&_0x3a47f1['domain']!=='localhost'&&ae('Cannot\x20parse\x20Firebase\x20url.\x20Please\x20use\x20https://<YOUR\x20FIREBASE>.firebaseio.com'),_0x3a47f1['secure']||$l();const _0xc2f4a2=_0x3a47f1['scheme']==='ws'||_0x3a47f1['scheme']==='wss';return{'repoInfo':new yo(_0x3a47f1['host'],_0x3a47f1['secure'],_0x11c84c,_0xc2f4a2,_0x55acb1,'',_0x11c84c!==_0x3a47f1['subdomain']),'path':new C(_0x3a47f1['pathString'])};},Md=function(_0x3bce66){let _0x491a7a='',_0xfc9350='',_0x6bcaf5='',_0x55be1a='',_0x195266='',_0x398325=!0x0,_0x50caab='https',_0x57f5f4=0x1bb;if(typeof _0x3bce66=='string'){let _0x2792c9=_0x3bce66['indexOf']('//');_0x2792c9>=0x0&&(_0x50caab=_0x3bce66['substring'](0x0,_0x2792c9-0x1),_0x3bce66=_0x3bce66['substring'](_0x2792c9+0x2));let _0x544469=_0x3bce66['indexOf']('/');_0x544469===-0x1&&(_0x544469=_0x3bce66['length']);let _0x2b6de0=_0x3bce66['indexOf']('?');_0x2b6de0===-0x1&&(_0x2b6de0=_0x3bce66['length']),_0x491a7a=_0x3bce66['substring'](0x0,Math['min'](_0x544469,_0x2b6de0)),_0x544469<_0x2b6de0&&(_0x55be1a=Od(_0x3bce66['substring'](_0x544469,_0x2b6de0)));const _0x529fd0=Dd(_0x3bce66['substring'](Math['min'](_0x3bce66['length'],_0x2b6de0)));_0x2792c9=_0x491a7a['indexOf'](':'),_0x2792c9>=0x0?(_0x398325=_0x50caab==='https'||_0x50caab==='wss',_0x57f5f4=parseInt(_0x491a7a['substring'](_0x2792c9+0x1),0xa)):_0x2792c9=_0x491a7a['length'];const _0x4b0cc0=_0x491a7a['slice'](0x0,_0x2792c9);if(_0x4b0cc0['toLowerCase']()==='localhost')_0xfc9350='localhost';else{if(_0x4b0cc0['split']('.')['length']<=0x2)_0xfc9350=_0x4b0cc0;else{const _0x3fbdee=_0x491a7a['indexOf']('.');_0x6bcaf5=_0x491a7a['substring'](0x0,_0x3fbdee)['toLowerCase'](),_0xfc9350=_0x491a7a['substring'](_0x3fbdee+0x1),_0x195266=_0x6bcaf5;}}'ns'in _0x529fd0&&(_0x195266=_0x529fd0['ns']);}return{'host':_0x491a7a,'port':_0x57f5f4,'domain':_0xfc9350,'subdomain':_0x6bcaf5,'secure':_0x398325,'scheme':_0x50caab,'pathString':_0x55be1a,'namespace':_0x195266};},Er='-0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ_abcdefghijklmnopqrstuvwxyz',Ld=(function(){let _0xc63b89=0x0;const _0x3e311a=[];return function(_0x40ab21){const _0x57b187=_0x40ab21===_0xc63b89;_0xc63b89=_0x40ab21;let _0x1abcf3;const _0x3fcab8=new Array(0x8);for(_0x1abcf3=0x7;_0x1abcf3>=0x0;_0x1abcf3--)_0x3fcab8[_0x1abcf3]=Er['charAt'](_0x40ab21%0x40),_0x40ab21=Math['floor'](_0x40ab21/0x40);f(_0x40ab21===0x0,'Cannot\x20push\x20at\x20time\x20==\x200');let _0x189566=_0x3fcab8['join']('');if(_0x57b187){for(_0x1abcf3=0xb;_0x1abcf3>=0x0&&_0x3e311a[_0x1abcf3]===0x3f;_0x1abcf3--)_0x3e311a[_0x1abcf3]=0x0;_0x3e311a[_0x1abcf3]++;}else{for(_0x1abcf3=0x0;_0x1abcf3<0xc;_0x1abcf3++)_0x3e311a[_0x1abcf3]=Math['floor'](Math['random']()*0x40);}for(_0x1abcf3=0x0;_0x1abcf3<0xc;_0x1abcf3++)_0x189566+=Er['charAt'](_0x3e311a[_0x1abcf3]);return f(_0x189566['length']===0x14,'nextPushId:\x20Length\x20should\x20be\x2020.'),_0x189566;};}());/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class xd{constructor(_0x2dbb6d,_0xfe74d,_0x4c0cc8,_0x2fccb2){this['eventType']=_0x2dbb6d,this['eventRegistration']=_0xfe74d,this['snapshot']=_0x4c0cc8,this['prevName']=_0x2fccb2;}['getPath'](){const _0x59134d=this['snapshot']['ref'];return this['eventType']==='value'?_0x59134d['_path']:_0x59134d['parent']['_path'];}['getEventType'](){return this['eventType'];}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['getPath']()['toString']()+':'+this['eventType']+':'+O(this['snapshot']['exportVal']());}}class Fd{constructor(_0x4fa7af,_0x45ebf0,_0x419330){this['eventRegistration']=_0x4fa7af,this['error']=_0x45ebf0,this['path']=_0x419330;}['getPath'](){return this['path'];}['getEventType'](){return'cancel';}['getEventRunner'](){return this['eventRegistration']['getEventRunner'](this);}['toString'](){return this['path']['toString']()+':cancel';}}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pa{constructor(_0xdaed33,_0x4697a6){this['snapshotCallback']=_0xdaed33,this['cancelCallback']=_0x4697a6;}['onValue'](_0x403eab,_0x3b5737){this['snapshotCallback']['call'](null,_0x403eab,_0x3b5737);}['onCancel'](_0x44d0f6){return f(this['hasCancelCallback'],'Raising\x20a\x20cancel\x20event\x20on\x20a\x20listener\x20with\x20no\x20cancel\x20callback'),this['cancelCallback']['call'](null,_0x44d0f6);}get['hasCancelCallback'](){return!!this['cancelCallback'];}['matches'](_0x483af9){return this['snapshotCallback']===_0x483af9['snapshotCallback']||this['snapshotCallback']['userCallback']!==void 0x0&&this['snapshotCallback']['userCallback']===_0x483af9['snapshotCallback']['userCallback']&&this['snapshotCallback']['context']===_0x483af9['snapshotCallback']['context'];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class be{constructor(_0x4ea5b,_0x387c86,_0x38175f,_0x2bcf69){this['_repo']=_0x4ea5b,this['_path']=_0x387c86,this['_queryParams']=_0x38175f,this['_orderByCalled']=_0x2bcf69;}get['key'](){return v(this['_path'])?null:zi(this['_path']);}get['ref'](){return new ee(this['_repo'],this['_path']);}get['_queryIdentifier'](){const _0xf7c292=rr(this['_queryParams']),_0x3b6f4f=Hi(_0xf7c292);return _0x3b6f4f==='{}'?'default':_0x3b6f4f;}get['_queryObject'](){return rr(this['_queryParams']);}['isEqual'](_0x595649){if(_0x595649=N(_0x595649),!(_0x595649 instanceof be))return!0x1;const _0x475f10=this['_repo']===_0x595649['_repo'],_0x30b001=ji(this['_path'],_0x595649['_path']),_0x5b1ea5=this['_queryIdentifier']===_0x595649['_queryIdentifier'];return _0x475f10&&_0x30b001&&_0x5b1ea5;}['toJSON'](){return this['toString']();}['toString'](){return this['_repo']['toString']()+bh(this['_path']);}}function _a(_0xe9593,_0x1d9eda){if(_0xe9593['_orderByCalled']===!0x0)throw new Error(_0x1d9eda+':\x20You\x20can\x27t\x20combine\x20multiple\x20orderBy\x20calls.');}function qn(_0x3a5bb7){let _0x3065e7=null,_0x19e7b2=null;if(_0x3a5bb7['hasStart']()&&(_0x3065e7=_0x3a5bb7['getIndexStartValue']()),_0x3a5bb7['hasEnd']()&&(_0x19e7b2=_0x3a5bb7['getIndexEndValue']()),_0x3a5bb7['getIndex']()===ye){const _0x5065d1='Query:\x20When\x20ordering\x20by\x20key,\x20you\x20may\x20only\x20pass\x20one\x20argument\x20to\x20startAt(),\x20endAt(),\x20or\x20equalTo().',_0x2ca62c='Query:\x20When\x20ordering\x20by\x20key,\x20the\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20string.';if(_0x3a5bb7['hasStart']()){if(_0x3a5bb7['getIndexStartName']()!==Fe)throw new Error(_0x5065d1);if(typeof _0x3065e7!='string')throw new Error(_0x2ca62c);}if(_0x3a5bb7['hasEnd']()){if(_0x3a5bb7['getIndexEndName']()!==Ie)throw new Error(_0x5065d1);if(typeof _0x19e7b2!='string')throw new Error(_0x2ca62c);}}else{if(_0x3a5bb7['getIndex']()===R){if(_0x3065e7!=null&&!Tn(_0x3065e7)||_0x19e7b2!=null&&!Tn(_0x19e7b2))throw new Error('Query:\x20When\x20ordering\x20by\x20priority,\x20the\x20first\x20argument\x20passed\x20to\x20startAt(),\x20startAfter()\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20must\x20be\x20a\x20valid\x20priority\x20value\x20(null,\x20a\x20number,\x20or\x20a\x20string).');}else{if(f(_0x3a5bb7['getIndex']()instanceof Qi||_0x3a5bb7['getIndex']()===Mo,'unknown\x20index\x20type.'),_0x3065e7!=null&&typeof _0x3065e7=='object'||_0x19e7b2!=null&&typeof _0x19e7b2=='object')throw new Error('Query:\x20First\x20argument\x20passed\x20to\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20or\x20equalTo()\x20cannot\x20be\x20an\x20object.');}}}function ga(_0x4de422){if(_0x4de422['hasStart']()&&_0x4de422['hasEnd']()&&_0x4de422['hasLimit']()&&!_0x4de422['hasAnchoredLimit']())throw new Error('Query:\x20Can\x27t\x20combine\x20startAt(),\x20startAfter(),\x20endAt(),\x20endBefore(),\x20and\x20limit().\x20Use\x20limitToFirst()\x20or\x20limitToLast()\x20instead.');}class ee extends be{constructor(_0x5bee65,_0x2f0b4f){super(_0x5bee65,_0x2f0b4f,new Xi(),!0x1);}get['parent'](){const _0x36d4f3=Ro(this['_path']);return _0x36d4f3===null?null:new ee(this['_repo'],_0x36d4f3);}get['root'](){let _0x1b2ee7=this;for(;_0x1b2ee7['parent']!==null;)_0x1b2ee7=_0x1b2ee7['parent'];return _0x1b2ee7;}}class st{constructor(_0x400925,_0x1d9859,_0x3518bf){this['_node']=_0x400925,this['ref']=_0x1d9859,this['_index']=_0x3518bf;}get['priority'](){return this['_node']['getPriority']()['val']();}get['key'](){return this['ref']['key'];}get['size'](){return this['_node']['numChildren']();}['child'](_0x4f49e2){const _0x4a4f1f=new C(_0x4f49e2),_0x420d8d=Ft(this['ref'],_0x4f49e2);return new st(this['_node']['getChild'](_0x4a4f1f),_0x420d8d,R);}['exists'](){return!this['_node']['isEmpty']();}['exportVal'](){return this['_node']['val'](!0x0);}['forEach'](_0x150925){return this['_node']['isLeafNode']()?!0x1:!!this['_node']['forEachChild'](this['_index'],(_0x426446,_0x3aa6ed)=>_0x150925(new st(_0x3aa6ed,Ft(this['ref'],_0x426446),R)));}['hasChild'](_0x49b471){const _0x418b03=new C(_0x49b471);return!this['_node']['getChild'](_0x418b03)['isEmpty']();}['hasChildren'](){return this['_node']['isLeafNode']()?!0x1:!this['_node']['isEmpty']();}['toJSON'](){return this['exportVal']();}['val'](){return this['_node']['val']();}}function __(_0x307f18,_0x4f5331){return _0x307f18=N(_0x307f18),_0x307f18['_checkNotDeleted']('ref'),_0x4f5331!==void 0x0?Ft(_0x307f18['_root'],_0x4f5331):_0x307f18['_root'];}function Ft(_0x132c85,_0x344ba2){return _0x132c85=N(_0x132c85),y(_0x132c85['_path'])===null?pd('child','path',_0x344ba2):ms('child','path',_0x344ba2),new ee(_0x132c85['_repo'],k(_0x132c85['_path'],_0x344ba2));}function g_(_0x39e711,_0xcf790a){_0x39e711=N(_0x39e711),ys('push',_0x39e711['_path']),zt('push',_0xcf790a,_0x39e711['_path'],!0x0);const _0x4a4f84=la(_0x39e711['_repo']),_0x548638=Ld(_0x4a4f84),_0x3bde02=Ft(_0x39e711,_0x548638),_0x59b9fc=Ft(_0x39e711,_0x548638);let _0x20f54d;return _0xcf790a!=null?_0x20f54d=Ud(_0x59b9fc,_0xcf790a)['then'](()=>_0x59b9fc):_0x20f54d=Promise['resolve'](_0x59b9fc),_0x3bde02['then']=_0x20f54d['then']['bind'](_0x20f54d),_0x3bde02['catch']=_0x20f54d['then']['bind'](_0x20f54d,void 0x0),_0x3bde02;}function Ud(_0x3391d3,_0x1e256a){_0x3391d3=N(_0x3391d3),ys('set',_0x3391d3['_path']),zt('set',_0x1e256a,_0x3391d3['_path'],!0x1);const _0x4d1d8c=new ot();return Cd(_0x3391d3['_repo'],_0x3391d3['_path'],_0x1e256a,null,_0x4d1d8c['wrapCallback'](()=>{})),_0x4d1d8c['promise'];}function m_(_0x1fa677,_0x23dee7){fd('update',_0x23dee7,_0x1fa677['_path']);const _0x2268da=new ot();return Td(_0x1fa677['_repo'],_0x1fa677['_path'],_0x23dee7,_0x2268da['wrapCallback'](()=>{})),_0x2268da['promise'];}function y_(_0x4d5881){_0x4d5881=N(_0x4d5881);const _0xa58826=new pa(()=>{}),_0x1390da=new zn(_0xa58826);return wd(_0x4d5881['_repo'],_0x4d5881,_0x1390da)['then'](_0x2bff55=>new st(_0x2bff55,new ee(_0x4d5881['_repo'],_0x4d5881['_path']),_0x4d5881['_queryParams']['getIndex']()));}class zn{constructor(_0xedc499){this['callbackContext']=_0xedc499;}['respondsTo'](_0x39a1db){return _0x39a1db==='value';}['createEvent'](_0x1aaa23,_0x2fb03b){const _0x230283=_0x2fb03b['_queryParams']['getIndex']();return new xd('value',this,new st(_0x1aaa23['snapshotNode'],new ee(_0x2fb03b['_repo'],_0x2fb03b['_path']),_0x230283));}['getEventRunner'](_0xf73a00){return _0xf73a00['getEventType']()==='cancel'?()=>this['callbackContext']['onCancel'](_0xf73a00['error']):()=>this['callbackContext']['onValue'](_0xf73a00['snapshot'],null);}['createCancelEvent'](_0x29f047,_0x432efd){return this['callbackContext']['hasCancelCallback']?new Fd(this,_0x29f047,_0x432efd):null;}['matches'](_0x2dfea7){return _0x2dfea7 instanceof zn?!_0x2dfea7['callbackContext']||!this['callbackContext']?!0x0:_0x2dfea7['callbackContext']['matches'](this['callbackContext']):!0x1;}['hasAnyCallback'](){return this['callbackContext']!==null;}}function Wd(_0x2e14a2,_0xa9c626,_0x44b5bf,_0x17987d,_0x2065e0){const _0x419183=new pa(_0x44b5bf,void 0x0),_0x59b029=new zn(_0x419183);return bd(_0x2e14a2['_repo'],_0x2e14a2,_0x59b029),()=>Rd(_0x2e14a2['_repo'],_0x2e14a2,_0x59b029);}function Bd(_0x1ffd70,_0x24a139,_0x4d3a4d,_0xe8d690){return Wd(_0x1ffd70,'value',_0x24a139);}class ft{}class ma extends ft{constructor(_0xb89e06,_0x1f3098){super(),this['_value']=_0xb89e06,this['_key']=_0x1f3098,this['type']='endAt';}['_apply'](_0x2c7bdf){zt('endAt',this['_value'],_0x2c7bdf['_path'],!0x0);const _0x250eff=Jh(_0x2c7bdf['_queryParams'],this['_value'],this['_key']);if(ga(_0x250eff),qn(_0x250eff),_0x2c7bdf['_queryParams']['hasEnd']())throw new Error('endAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt,\x20endBefore\x20or\x20equalTo).');return new be(_0x2c7bdf['_repo'],_0x2c7bdf['_path'],_0x250eff,_0x2c7bdf['_orderByCalled']);}}function v_(_0x4507dc,_0x1b261c){return new ma(_0x4507dc,_0x1b261c);}class ya extends ft{constructor(_0x532496,_0x33153f){super(),this['_value']=_0x532496,this['_key']=_0x33153f,this['type']='startAt';}['_apply'](_0x51c770){zt('startAt',this['_value'],_0x51c770['_path'],!0x0);const _0x50d801=Qh(_0x51c770['_queryParams'],this['_value'],this['_key']);if(ga(_0x50d801),qn(_0x50d801),_0x51c770['_queryParams']['hasStart']())throw new Error('startAt:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt,\x20startBefore\x20or\x20equalTo).');return new be(_0x51c770['_repo'],_0x51c770['_path'],_0x50d801,_0x51c770['_orderByCalled']);}}function E_(_0x4a7b54=null,_0x84c072){return new ya(_0x4a7b54,_0x84c072);}class Vd extends ft{constructor(_0x5577b0){super(),this['_limit']=_0x5577b0,this['type']='limitToFirst';}['_apply'](_0x331dee){if(_0x331dee['_queryParams']['hasLimit']())throw new Error('limitToFirst:\x20Limit\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20limitToFirst\x20or\x20limitToLast).');return new be(_0x331dee['_repo'],_0x331dee['_path'],Yh(_0x331dee['_queryParams'],this['_limit']),_0x331dee['_orderByCalled']);}}function I_(_0xc0438c){if(Math['floor'](_0xc0438c)!==_0xc0438c||_0xc0438c<=0x0)throw new Error('limitToFirst:\x20First\x20argument\x20must\x20be\x20a\x20positive\x20integer.');return new Vd(_0xc0438c);}class Hd extends ft{constructor(_0x172f68){super(),this['_path']=_0x172f68,this['type']='orderByChild';}['_apply'](_0x478afb){_a(_0x478afb,'orderByChild');const _0xcff561=new C(this['_path']);if(v(_0xcff561))throw new Error('orderByChild:\x20cannot\x20pass\x20in\x20empty\x20path.\x20Use\x20orderByValue()\x20instead.');const _0x209f76=new Qi(_0xcff561),_0x2a96cd=xo(_0x478afb['_queryParams'],_0x209f76);return qn(_0x2a96cd),new be(_0x478afb['_repo'],_0x478afb['_path'],_0x2a96cd,!0x0);}}function w_(_0x1ead65){if(_0x1ead65==='$key')throw new Error('orderByChild:\x20\x22$key\x22\x20is\x20invalid.\x20\x20Use\x20orderByKey()\x20instead.');if(_0x1ead65==='$priority')throw new Error('orderByChild:\x20\x22$priority\x22\x20is\x20invalid.\x20\x20Use\x20orderByPriority()\x20instead.');if(_0x1ead65==='$value')throw new Error('orderByChild:\x20\x22$value\x22\x20is\x20invalid.\x20\x20Use\x20orderByValue()\x20instead.');return ms('orderByChild','path',_0x1ead65),new Hd(_0x1ead65);}class $d extends ft{constructor(){super(...arguments),this['type']='orderByKey';}['_apply'](_0x196f52){_a(_0x196f52,'orderByKey');const _0x2d7f40=xo(_0x196f52['_queryParams'],ye);return qn(_0x2d7f40),new be(_0x196f52['_repo'],_0x196f52['_path'],_0x2d7f40,!0x0);}}function C_(){return new $d();}class Gd extends ft{constructor(_0x3d9b5c,_0x1d791b){super(),this['_value']=_0x3d9b5c,this['_key']=_0x1d791b,this['type']='equalTo';}['_apply'](_0x4c17c9){if(zt('equalTo',this['_value'],_0x4c17c9['_path'],!0x1),_0x4c17c9['_queryParams']['hasStart']())throw new Error('equalTo:\x20Starting\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20startAt/startAfter\x20or\x20equalTo).');if(_0x4c17c9['_queryParams']['hasEnd']())throw new Error('equalTo:\x20Ending\x20point\x20was\x20already\x20set\x20(by\x20another\x20call\x20to\x20endAt/endBefore\x20or\x20equalTo).');return new ma(this['_value'],this['_key'])['_apply'](new ya(this['_value'],this['_key'])['_apply'](_0x4c17c9));}}function T_(_0x3382b2,_0x24879d){return new Gd(_0x3382b2,_0x24879d);}function S_(_0x80b92c,..._0x4a0f57){let _0x10c9f9=N(_0x80b92c);for(const _0x491bc5 of _0x4a0f57)_0x10c9f9=_0x491bc5['_apply'](_0x10c9f9);return _0x10c9f9;}Wu(ee),Gu(ee);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const qd='FIREBASE_DATABASE_EMULATOR_HOST',Ni={};let zd=!0x1;function jd(_0x128a9d,_0x42ac77,_0x22bbff,_0x18e5f9){const _0x11c293=_0x42ac77['lastIndexOf'](':'),_0x5b98b0=_0x42ac77['substring'](0x0,_0x11c293),_0x13276a=at(_0x5b98b0);_0x128a9d['repoInfo_']=new yo(_0x42ac77,_0x13276a,_0x128a9d['repoInfo_']['namespace'],_0x128a9d['repoInfo_']['webSocketOnly'],_0x128a9d['repoInfo_']['nodeAdmin'],_0x128a9d['repoInfo_']['persistenceKey'],_0x128a9d['repoInfo_']['includeNamespaceInQueryParams'],!0x0,_0x22bbff),_0x18e5f9&&(_0x128a9d['authTokenProvider_']=_0x18e5f9);}function Kd(_0x44c5fc,_0x2e573c,_0xd1f3a9,_0x22b909,_0x5f3b45){let _0x2024ee=_0x22b909||_0x44c5fc['options']['databaseURL'];_0x2024ee===void 0x0&&(_0x44c5fc['options']['projectId']||ae('Can\x27t\x20determine\x20Firebase\x20Database\x20URL.\x20Be\x20sure\x20to\x20include\x20\x20a\x20Project\x20ID\x20when\x20calling\x20firebase.initializeApp().'),L('Using\x20default\x20host\x20for\x20project\x20',_0x44c5fc['options']['projectId']),_0x2024ee=_0x44c5fc['options']['projectId']+'-default-rtdb.firebaseio.com');let _0x6fb0e=vr(_0x2024ee,_0x5f3b45),_0x3ba7bb=_0x6fb0e['repoInfo'],_0x399b89;typeof process<'u'&&Vs&&(_0x399b89=Vs[qd]),_0x399b89?(_0x2024ee='http://'+_0x399b89+'?ns='+_0x3ba7bb['namespace'],_0x6fb0e=vr(_0x2024ee,_0x5f3b45),_0x3ba7bb=_0x6fb0e['repoInfo']):_0x6fb0e['repoInfo']['secure'];const _0x53f09d=new eh(_0x44c5fc['name'],_0x44c5fc['options'],_0x2e573c);_d('Invalid\x20Firebase\x20Database\x20URL',_0x6fb0e),v(_0x6fb0e['path'])||ae('Database\x20URL\x20must\x20point\x20to\x20the\x20root\x20of\x20a\x20Firebase\x20Database\x20(not\x20including\x20a\x20child\x20path).');const _0x5a6f5=Qd(_0x3ba7bb,_0x44c5fc,_0x53f09d,new Zl(_0x44c5fc,_0xd1f3a9));return new Jd(_0x5a6f5,_0x44c5fc);}function Yd(_0x4628fd,_0xc5598d){const _0x1f5de4=Ni[_0xc5598d];(!_0x1f5de4||_0x1f5de4[_0x4628fd['key']]!==_0x4628fd)&&ae('Database\x20'+_0xc5598d+'('+_0x4628fd['repoInfo_']+')\x20has\x20already\x20been\x20deleted.'),ha(_0x4628fd),delete _0x1f5de4[_0x4628fd['key']];}function Qd(_0x54b2a0,_0x31b8cc,_0x2e06e0,_0x3b468b){let _0x999c73=Ni[_0x31b8cc['name']];_0x999c73||(_0x999c73={},Ni[_0x31b8cc['name']]=_0x999c73);let _0x14f633=_0x999c73[_0x54b2a0['toURLString']()];return _0x14f633&&ae('Database\x20initialized\x20multiple\x20times.\x20Please\x20make\x20sure\x20the\x20format\x20of\x20the\x20database\x20URL\x20matches\x20with\x20each\x20database()\x20call.'),_0x14f633=new vd(_0x54b2a0,zd,_0x2e06e0,_0x3b468b),_0x999c73[_0x54b2a0['toURLString']()]=_0x14f633,_0x14f633;}class Jd{constructor(_0x5c9457,_0x523ab9){this['_repoInternal']=_0x5c9457,this['app']=_0x523ab9,this['type']='database',this['_instanceStarted']=!0x1;}get['_repo'](){return this['_instanceStarted']||(Ed(this['_repoInternal'],this['app']['options']['appId'],this['app']['options']['databaseAuthVariableOverride']),this['_instanceStarted']=!0x0),this['_repoInternal'];}get['_root'](){return this['_rootInternal']||(this['_rootInternal']=new ee(this['_repo'],w())),this['_rootInternal'];}['_delete'](){return this['_rootInternal']!==null&&(Yd(this['_repo'],this['app']['name']),this['_repoInternal']=null,this['_rootInternal']=null),Promise['resolve']();}['_checkNotDeleted'](_0x4b2972){this['_rootInternal']===null&&ae('Cannot\x20call\x20'+_0x4b2972+'\x20on\x20a\x20deleted\x20database.');}}function b_(_0x3028f2=Zr(),_0x16101c){const _0x325420=Bi(_0x3028f2,'database')['getImmediate']({'identifier':_0x16101c});if(!_0x325420['_instanceStarted']){const _0x15820e=cc('database');_0x15820e&&Xd(_0x325420,..._0x15820e);}return _0x325420;}function Xd(_0x40e663,_0x14992a,_0x455d08,_0x4c1922={}){_0x40e663=N(_0x40e663),_0x40e663['_checkNotDeleted']('useEmulator');const _0x2a5a9c=_0x14992a+':'+_0x455d08,_0x66833=_0x40e663['_repoInternal'];if(_0x40e663['_instanceStarted']){if(_0x2a5a9c===_0x40e663['_repoInternal']['repoInfo_']['host']&&Me(_0x4c1922,_0x66833['repoInfo_']['emulatorOptions']))return;ae('connectDatabaseEmulator()\x20cannot\x20initialize\x20or\x20alter\x20the\x20emulator\x20configuration\x20after\x20the\x20database\x20instance\x20has\x20started.');}let _0x2c44f0;if(_0x66833['repoInfo_']['nodeAdmin'])_0x4c1922['mockUserToken']&&ae('mockUserToken\x20is\x20not\x20supported\x20by\x20the\x20Admin\x20SDK.\x20For\x20client\x20access\x20with\x20mock\x20users,\x20please\x20use\x20the\x20\x22firebase\x22\x20package\x20instead\x20of\x20\x22firebase-admin\x22.'),_0x2c44f0=new nn(nn['OWNER']);else{if(_0x4c1922['mockUserToken']){const _0x528330=typeof _0x4c1922['mockUserToken']=='string'?_0x4c1922['mockUserToken']:lc(_0x4c1922['mockUserToken'],_0x40e663['app']['options']['projectId']);_0x2c44f0=new nn(_0x528330);}}at(_0x14992a)&&(jr(_0x14992a),Kr('Database',!0x0)),jd(_0x66833,_0x2a5a9c,_0x4c1922,_0x2c44f0);}function R_(_0x9bca3c){_0x9bca3c=N(_0x9bca3c),_0x9bca3c['_checkNotDeleted']('goOffline'),ha(_0x9bca3c['_repo']);}function A_(_0xb7f904){_0xb7f904=N(_0xb7f904),_0xb7f904['_checkNotDeleted']('goOnline'),Ad(_0xb7f904['_repo']);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Zd(_0x527877){Ul(lt),Ze(new Le('database',(_0x3841eb,{instanceIdentifier:_0x29505d})=>{const _0x4b8cb6=_0x3841eb['getProvider']('app')['getImmediate'](),_0x5d042e=_0x3841eb['getProvider']('auth-internal'),_0x1511ee=_0x3841eb['getProvider']('app-check-internal');return Kd(_0x4b8cb6,_0x5d042e,_0x1511ee,_0x29505d);},'PUBLIC')['setMultipleInstances'](!0x0)),me(Hs,$s,_0x527877),me(Hs,$s,'esm2020');}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ef={'.sv':'timestamp'};function k_(){return ef;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class tf{constructor(_0x52731d,_0x534bb0){this['committed']=_0x52731d,this['snapshot']=_0x534bb0;}['toJSON'](){return{'committed':this['committed'],'snapshot':this['snapshot']['toJSON']()};}}function N_(_0x3fd025,_0x2b9e11,_0x553bf4){if(_0x3fd025=N(_0x3fd025),ys('Reference.transaction',_0x3fd025['_path']),_0x3fd025['key']==='.length'||_0x3fd025['key']==='.keys')throw'Reference.transaction\x20failed:\x20'+_0x3fd025['key']+'\x20is\x20a\x20read-only\x20object.';const _0x21edc1=!0x0,_0x1ce0af=new ot(),_0x193935=(_0x23a7d8,_0x48abad,_0x50fa8a)=>{let _0x3fc3ec=null;_0x23a7d8?_0x1ce0af['reject'](_0x23a7d8):(_0x3fc3ec=new st(_0x50fa8a,new ee(_0x3fd025['_repo'],_0x3fd025['_path']),R),_0x1ce0af['resolve'](new tf(_0x48abad,_0x3fc3ec)));},_0x5213fd=Bd(_0x3fd025,()=>{});return kd(_0x3fd025['_repo'],_0x3fd025['_path'],_0x2b9e11,_0x193935,_0x5213fd,_0x21edc1),_0x1ce0af['promise'];}se['prototype']['simpleListen']=function(_0x13b717,_0x3abd3c){this['sendRequest']('q',{'p':_0x13b717},_0x3abd3c);},se['prototype']['echo']=function(_0x949f4d,_0x2464b8){this['sendRequest']('echo',{'d':_0x949f4d},_0x2464b8);},Zd();function va(){return{'dependent-sdk-initialized-before-auth':'Another\x20Firebase\x20SDK\x20was\x20initialized\x20and\x20is\x20trying\x20to\x20use\x20Auth\x20before\x20Auth\x20is\x20initialized.\x20Please\x20be\x20sure\x20to\x20call\x20`initializeAuth`\x20or\x20`getAuth`\x20before\x20starting\x20any\x20other\x20Firebase\x20SDK.'};}const nf=va,Ea=new Bt('auth','Firebase',va()),Sn=new Ui('@firebase/auth');function sf(_0x3e2c48,..._0x5e9468){Sn['logLevel']<=T['WARN']&&Sn['warn']('Auth\x20('+lt+'):\x20'+_0x3e2c48,..._0x5e9468);}function sn(_0x114e9b,..._0x23f7d1){Sn['logLevel']<=T['ERROR']&&Sn['error']('Auth\x20('+lt+'):\x20'+_0x114e9b,..._0x23f7d1);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Q(_0x287854,..._0x33e384){throw ws(_0x287854,..._0x33e384);}function X(_0x4861d8,..._0x2221af){return ws(_0x4861d8,..._0x2221af);}function Ia(_0x36c302,_0x38002a,_0x477bb1){const _0x2cafbd={...nf(),[_0x38002a]:_0x477bb1};return new Bt('auth','Firebase',_0x2cafbd)['create'](_0x38002a,{'appName':_0x36c302['name']});}function re(_0x316d5b){return Ia(_0x316d5b,'operation-not-supported-in-this-environment','Operations\x20that\x20alter\x20the\x20current\x20user\x20are\x20not\x20supported\x20in\x20conjunction\x20with\x20FirebaseServerApp');}function ws(_0x4d5f81,..._0x2b4cc9){if(typeof _0x4d5f81!='string'){const _0x500d2e=_0x2b4cc9[0x0],_0x5b6b2f=[..._0x2b4cc9['slice'](0x1)];return _0x5b6b2f[0x0]&&(_0x5b6b2f[0x0]['appName']=_0x4d5f81['name']),_0x4d5f81['_errorFactory']['create'](_0x500d2e,..._0x5b6b2f);}return Ea['create'](_0x4d5f81,..._0x2b4cc9);}function m(_0x2ec840,_0x4b4d8a,..._0x4a2774){if(!_0x2ec840)throw ws(_0x4b4d8a,..._0x4a2774);}function ne(_0x1e6575){const _0x4ddd60='INTERNAL\x20ASSERTION\x20FAILED:\x20'+_0x1e6575;throw sn(_0x4ddd60),new Error(_0x4ddd60);}function ce(_0x1579ba,_0x5a9c3e){_0x1579ba||ne(_0x5a9c3e);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Pi(){var _0x353645;return typeof self<'u'&&((_0x353645=self['location'])==null?void 0x0:_0x353645['href'])||'';}function rf(){return Ir()==='http:'||Ir()==='https:';}function Ir(){var _0x2fd0c8;return typeof self<'u'&&((_0x2fd0c8=self['location'])==null?void 0x0:_0x2fd0c8['protocol'])||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function of(){return typeof navigator<'u'&&navigator&&'onLine'in navigator&&typeof navigator['onLine']=='boolean'&&(rf()||fc()||'connection'in navigator)?navigator['onLine']:!0x0;}function af(){if(typeof navigator>'u')return null;const _0x1f72dc=navigator;return _0x1f72dc['languages']&&_0x1f72dc['languages'][0x0]||_0x1f72dc['language']||null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Yt{constructor(_0x5ad4fb,_0x314379){this['shortDelay']=_0x5ad4fb,this['longDelay']=_0x314379,ce(_0x314379>_0x5ad4fb,'Short\x20delay\x20should\x20be\x20less\x20than\x20long\x20delay!'),this['isMobile']=Fi()||Yr();}['get'](){return of()?this['isMobile']?this['longDelay']:this['shortDelay']:Math['min'](0x1388,this['shortDelay']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Cs(_0x1ce2c6,_0x59c09f){ce(_0x1ce2c6['emulator'],'Emulator\x20should\x20always\x20be\x20set\x20here');const {url:_0x339c3e}=_0x1ce2c6['emulator'];return _0x59c09f?''+_0x339c3e+(_0x59c09f['startsWith']('/')?_0x59c09f['slice'](0x1):_0x59c09f):_0x339c3e;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class wa{static['initialize'](_0x45943e,_0x33375d,_0x2bf245){this['fetchImpl']=_0x45943e,_0x33375d&&(this['headersImpl']=_0x33375d),_0x2bf245&&(this['responseImpl']=_0x2bf245);}static['fetch'](){if(this['fetchImpl'])return this['fetchImpl'];if(typeof self<'u'&&'fetch'in self)return self['fetch'];if(typeof globalThis<'u'&&globalThis['fetch'])return globalThis['fetch'];if(typeof fetch<'u')return fetch;ne('Could\x20not\x20find\x20fetch\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['headers'](){if(this['headersImpl'])return this['headersImpl'];if(typeof self<'u'&&'Headers'in self)return self['Headers'];if(typeof globalThis<'u'&&globalThis['Headers'])return globalThis['Headers'];if(typeof Headers<'u')return Headers;ne('Could\x20not\x20find\x20Headers\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}static['response'](){if(this['responseImpl'])return this['responseImpl'];if(typeof self<'u'&&'Response'in self)return self['Response'];if(typeof globalThis<'u'&&globalThis['Response'])return globalThis['Response'];if(typeof Response<'u')return Response;ne('Could\x20not\x20find\x20Response\x20implementation,\x20make\x20sure\x20you\x20call\x20FetchProvider.initialize()\x20with\x20an\x20appropriate\x20polyfill');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const cf={'CREDENTIAL_MISMATCH':'custom-token-mismatch','MISSING_CUSTOM_TOKEN':'internal-error','INVALID_IDENTIFIER':'invalid-email','MISSING_CONTINUE_URI':'internal-error','INVALID_PASSWORD':'wrong-password','MISSING_PASSWORD':'missing-password','INVALID_LOGIN_CREDENTIALS':'invalid-credential','EMAIL_EXISTS':'email-already-in-use','PASSWORD_LOGIN_DISABLED':'operation-not-allowed','INVALID_IDP_RESPONSE':'invalid-credential','INVALID_PENDING_TOKEN':'invalid-credential','FEDERATED_USER_ID_ALREADY_LINKED':'credential-already-in-use','MISSING_REQ_TYPE':'internal-error','EMAIL_NOT_FOUND':'user-not-found','RESET_PASSWORD_EXCEED_LIMIT':'too-many-requests','EXPIRED_OOB_CODE':'expired-action-code','INVALID_OOB_CODE':'invalid-action-code','MISSING_OOB_CODE':'internal-error','CREDENTIAL_TOO_OLD_LOGIN_AGAIN':'requires-recent-login','INVALID_ID_TOKEN':'invalid-user-token','TOKEN_EXPIRED':'user-token-expired','USER_NOT_FOUND':'user-token-expired','TOO_MANY_ATTEMPTS_TRY_LATER':'too-many-requests','PASSWORD_DOES_NOT_MEET_REQUIREMENTS':'password-does-not-meet-requirements','INVALID_CODE':'invalid-verification-code','INVALID_SESSION_INFO':'invalid-verification-id','INVALID_TEMPORARY_PROOF':'invalid-credential','MISSING_SESSION_INFO':'missing-verification-id','SESSION_EXPIRED':'code-expired','MISSING_ANDROID_PACKAGE_NAME':'missing-android-pkg-name','UNAUTHORIZED_DOMAIN':'unauthorized-continue-uri','INVALID_OAUTH_CLIENT_ID':'invalid-oauth-client-id','ADMIN_ONLY_OPERATION':'admin-restricted-operation','INVALID_MFA_PENDING_CREDENTIAL':'invalid-multi-factor-session','MFA_ENROLLMENT_NOT_FOUND':'multi-factor-info-not-found','MISSING_MFA_ENROLLMENT_ID':'missing-multi-factor-info','MISSING_MFA_PENDING_CREDENTIAL':'missing-multi-factor-session','SECOND_FACTOR_EXISTS':'second-factor-already-in-use','SECOND_FACTOR_LIMIT_EXCEEDED':'maximum-second-factor-count-exceeded','BLOCKING_FUNCTION_ERROR_RESPONSE':'internal-error','RECAPTCHA_NOT_ENABLED':'recaptcha-not-enabled','MISSING_RECAPTCHA_TOKEN':'missing-recaptcha-token','INVALID_RECAPTCHA_TOKEN':'invalid-recaptcha-token','INVALID_RECAPTCHA_ACTION':'invalid-recaptcha-action','MISSING_CLIENT_TYPE':'missing-client-type','MISSING_RECAPTCHA_VERSION':'missing-recaptcha-version','INVALID_RECAPTCHA_VERSION':'invalid-recaptcha-version','INVALID_REQ_TYPE':'invalid-req-type'},lf=['/v1/accounts:signInWithCustomToken','/v1/accounts:signInWithEmailLink','/v1/accounts:signInWithIdp','/v1/accounts:signInWithPassword','/v1/accounts:signInWithPhoneNumber','/v1/token'],hf=new Yt(0x7530,0xea60);function Re(_0x503eaa,_0x4a80d9){return _0x503eaa['tenantId']&&!_0x4a80d9['tenantId']?{..._0x4a80d9,'tenantId':_0x503eaa['tenantId']}:_0x4a80d9;}async function Ae(_0x5692c6,_0xb83122,_0x1eb189,_0x134616,_0x5b3dc5={}){return Ca(_0x5692c6,_0x5b3dc5,async()=>{let _0x1d841e={},_0x40a15a={};_0x134616&&(_0xb83122==='GET'?_0x40a15a=_0x134616:_0x1d841e={'body':JSON['stringify'](_0x134616)});const _0x1c1287=ct({'key':_0x5692c6['config']['apiKey'],..._0x40a15a})['slice'](0x1),_0x1b5372=await _0x5692c6['_getAdditionalHeaders']();_0x1b5372['Content-Type']='application/json',_0x5692c6['languageCode']&&(_0x1b5372['X-Firebase-Locale']=_0x5692c6['languageCode']);const _0x5db8af={'method':_0xb83122,'headers':_0x1b5372,..._0x1d841e};return dc()||(_0x5db8af['referrerPolicy']='no-referrer'),_0x5692c6['emulatorConfig']&&at(_0x5692c6['emulatorConfig']['host'])&&(_0x5db8af['credentials']='include'),wa['fetch']()(await Ta(_0x5692c6,_0x5692c6['config']['apiHost'],_0x1eb189,_0x1c1287),_0x5db8af);});}async function Ca(_0x356889,_0x56e386,_0x1c752e){_0x356889['_canInitEmulator']=!0x1;const _0x4e0583={...cf,..._0x56e386};try{const _0x40b321=new df(_0x356889),_0xb3b7a1=await Promise['race']([_0x1c752e(),_0x40b321['promise']]);_0x40b321['clearNetworkTimeout']();const _0x4c951f=await _0xb3b7a1['json']();if('needConfirmation'in _0x4c951f)throw tn(_0x356889,'account-exists-with-different-credential',_0x4c951f);if(_0xb3b7a1['ok']&&!('errorMessage'in _0x4c951f))return _0x4c951f;{const _0x228a37=_0xb3b7a1['ok']?_0x4c951f['errorMessage']:_0x4c951f['error']['message'],[_0x3a2811,_0x366a3f]=_0x228a37['split']('\x20:\x20');if(_0x3a2811==='FEDERATED_USER_ID_ALREADY_LINKED')throw tn(_0x356889,'credential-already-in-use',_0x4c951f);if(_0x3a2811==='EMAIL_EXISTS')throw tn(_0x356889,'email-already-in-use',_0x4c951f);if(_0x3a2811==='USER_DISABLED')throw tn(_0x356889,'user-disabled',_0x4c951f);const _0x2d8330=_0x4e0583[_0x3a2811]||_0x3a2811['toLowerCase']()['replace'](/[_\s]+/g,'-');if(_0x366a3f)throw Ia(_0x356889,_0x2d8330,_0x366a3f);Q(_0x356889,_0x2d8330);}}catch(_0x2e3824){if(_0x2e3824 instanceof Se)throw _0x2e3824;Q(_0x356889,'network-request-failed',{'message':String(_0x2e3824)});}}async function Qt(_0x4e1f2b,_0x221785,_0xa86cc,_0x325b79,_0x2a017e={}){const _0x179d7b=await Ae(_0x4e1f2b,_0x221785,_0xa86cc,_0x325b79,_0x2a017e);return'mfaPendingCredential'in _0x179d7b&&Q(_0x4e1f2b,'multi-factor-auth-required',{'_serverResponse':_0x179d7b}),_0x179d7b;}async function Ta(_0x36d12c,_0x512140,_0x2ffa61,_0x835702){const _0x1a7f07=''+_0x512140+_0x2ffa61+'?'+_0x835702,_0x484e20=_0x36d12c,_0x15f8c6=_0x484e20['config']['emulator']?Cs(_0x36d12c['config'],_0x1a7f07):_0x36d12c['config']['apiScheme']+'://'+_0x1a7f07;return lf['includes'](_0x2ffa61)&&(await _0x484e20['_persistenceManagerAvailable'],_0x484e20['_getPersistenceType']()==='COOKIE')?_0x484e20['_getPersistence']()['_getFinalTarget'](_0x15f8c6)['toString']():_0x15f8c6;}function uf(_0x4d739a){switch(_0x4d739a){case'ENFORCE':return'ENFORCE';case'AUDIT':return'AUDIT';case'OFF':return'OFF';default:return'ENFORCEMENT_STATE_UNSPECIFIED';}}class df{['clearNetworkTimeout'](){clearTimeout(this['timer']);}constructor(_0x4ada5e){this['auth']=_0x4ada5e,this['timer']=null,this['promise']=new Promise((_0x52e7fd,_0xf428f1)=>{this['timer']=setTimeout(()=>_0xf428f1(X(this['auth'],'network-request-failed')),hf['get']());});}}function tn(_0x383259,_0x7c4da2,_0x17135e){const _0x15c206={'appName':_0x383259['name']};_0x17135e['email']&&(_0x15c206['email']=_0x17135e['email']),_0x17135e['phoneNumber']&&(_0x15c206['phoneNumber']=_0x17135e['phoneNumber']);const _0x30264e=X(_0x383259,_0x7c4da2,_0x15c206);return _0x30264e['customData']['_tokenResponse']=_0x17135e,_0x30264e;}function wr(_0x510fe7){return _0x510fe7!==void 0x0&&_0x510fe7['enterprise']!==void 0x0;}class ff{constructor(_0x500447){if(this['siteKey']='',this['recaptchaEnforcementState']=[],_0x500447['recaptchaKey']===void 0x0)throw new Error('recaptchaKey\x20undefined');this['siteKey']=_0x500447['recaptchaKey']['split']('/')[0x3],this['recaptchaEnforcementState']=_0x500447['recaptchaEnforcementState'];}['getProviderEnforcementState'](_0x3b9725){if(!this['recaptchaEnforcementState']||this['recaptchaEnforcementState']['length']===0x0)return null;for(const _0x252bbb of this['recaptchaEnforcementState'])if(_0x252bbb['provider']&&_0x252bbb['provider']===_0x3b9725)return uf(_0x252bbb['enforcementState']);return null;}['isProviderEnabled'](_0x3dfe59){return this['getProviderEnforcementState'](_0x3dfe59)==='ENFORCE'||this['getProviderEnforcementState'](_0x3dfe59)==='AUDIT';}['isAnyProviderEnabled'](){return this['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')||this['isProviderEnabled']('PHONE_PROVIDER');}}async function pf(_0x2642d6,_0x538e2a){return Ae(_0x2642d6,'GET','/v2/recaptchaConfig',Re(_0x2642d6,_0x538e2a));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function _f(_0x4ca23c,_0x4a6711){return Ae(_0x4ca23c,'POST','/v1/accounts:delete',_0x4a6711);}async function bn(_0x591808,_0xdec424){return Ae(_0x591808,'POST','/v1/accounts:lookup',_0xdec424);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Rt(_0x1b9ecf){if(_0x1b9ecf)try{const _0x658e17=new Date(Number(_0x1b9ecf));if(!isNaN(_0x658e17['getTime']()))return _0x658e17['toUTCString']();}catch{}}async function gf(_0x42a8d0,_0x4f6a28=!0x1){const _0x30e2d0=N(_0x42a8d0),_0x2ff4c2=await _0x30e2d0['getIdToken'](_0x4f6a28),_0x5367d2=Ts(_0x2ff4c2);m(_0x5367d2&&_0x5367d2['exp']&&_0x5367d2['auth_time']&&_0x5367d2['iat'],_0x30e2d0['auth'],'internal-error');const _0xab6969=typeof _0x5367d2['firebase']=='object'?_0x5367d2['firebase']:void 0x0,_0x45c61e=_0xab6969==null?void 0x0:_0xab6969['sign_in_provider'];return{'claims':_0x5367d2,'token':_0x2ff4c2,'authTime':Rt(li(_0x5367d2['auth_time'])),'issuedAtTime':Rt(li(_0x5367d2['iat'])),'expirationTime':Rt(li(_0x5367d2['exp'])),'signInProvider':_0x45c61e||null,'signInSecondFactor':(_0xab6969==null?void 0x0:_0xab6969['sign_in_second_factor'])||null};}function li(_0x791fa6){return Number(_0x791fa6)*0x3e8;}function Ts(_0x33fcd1){const [_0x2333fb,_0x48c246,_0x1a51f1]=_0x33fcd1['split']('.');if(_0x2333fb===void 0x0||_0x48c246===void 0x0||_0x1a51f1===void 0x0)return sn('JWT\x20malformed,\x20contained\x20fewer\x20than\x203\x20sections'),null;try{const _0x4e4bd1=ln(_0x48c246);return _0x4e4bd1?JSON['parse'](_0x4e4bd1):(sn('Failed\x20to\x20decode\x20base64\x20JWT\x20payload'),null);}catch(_0x69395e){return sn('Caught\x20error\x20parsing\x20JWT\x20payload\x20as\x20JSON',_0x69395e==null?void 0x0:_0x69395e['toString']()),null;}}function Cr(_0x288d74){const _0x1af67e=Ts(_0x288d74);return m(_0x1af67e,'internal-error'),m(typeof _0x1af67e['exp']<'u','internal-error'),m(typeof _0x1af67e['iat']<'u','internal-error'),Number(_0x1af67e['exp'])-Number(_0x1af67e['iat']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ut(_0x2c4521,_0x257579,_0x2ba8d8=!0x1){if(_0x2ba8d8)return _0x257579;try{return await _0x257579;}catch(_0x4e33f5){throw _0x4e33f5 instanceof Se&&mf(_0x4e33f5)&&_0x2c4521['auth']['currentUser']===_0x2c4521&&await _0x2c4521['auth']['signOut'](),_0x4e33f5;}}function mf({code:_0x556753}){return _0x556753==='auth/user-disabled'||_0x556753==='auth/user-token-expired';}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class yf{constructor(_0x3798b4){this['user']=_0x3798b4,this['isRunning']=!0x1,this['timerId']=null,this['errorBackoff']=0x7530;}['_start'](){this['isRunning']||(this['isRunning']=!0x0,this['schedule']());}['_stop'](){this['isRunning']&&(this['isRunning']=!0x1,this['timerId']!==null&&clearTimeout(this['timerId']));}['getInterval'](_0x363750){if(_0x363750){const _0x175c80=this['errorBackoff'];return this['errorBackoff']=Math['min'](this['errorBackoff']*0x2,0xea600),_0x175c80;}else{this['errorBackoff']=0x7530;const _0x10395f=(this['user']['stsTokenManager']['expirationTime']??0x0)-Date['now']()-0x493e0;return Math['max'](0x0,_0x10395f);}}['schedule'](_0x166a57=!0x1){if(!this['isRunning'])return;const _0x68798c=this['getInterval'](_0x166a57);this['timerId']=setTimeout(async()=>{await this['iteration']();},_0x68798c);}async['iteration'](){try{await this['user']['getIdToken'](!0x0);}catch(_0x10a8a6){(_0x10a8a6==null?void 0x0:_0x10a8a6['code'])==='auth/network-request-failed'&&this['schedule'](!0x0);return;}this['schedule']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Oi{constructor(_0x4fe2a6,_0x2c288c){this['createdAt']=_0x4fe2a6,this['lastLoginAt']=_0x2c288c,this['_initializeTime']();}['_initializeTime'](){this['lastSignInTime']=Rt(this['lastLoginAt']),this['creationTime']=Rt(this['createdAt']);}['_copy'](_0x5d8a00){this['createdAt']=_0x5d8a00['createdAt'],this['lastLoginAt']=_0x5d8a00['lastLoginAt'],this['_initializeTime']();}['toJSON'](){return{'createdAt':this['createdAt'],'lastLoginAt':this['lastLoginAt']};}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Rn(_0x3528d2){var _0x153c66;const _0x4ba842=_0x3528d2['auth'],_0x122b18=await _0x3528d2['getIdToken'](),_0xfd01ad=await Ut(_0x3528d2,bn(_0x4ba842,{'idToken':_0x122b18}));m(_0xfd01ad==null?void 0x0:_0xfd01ad['users']['length'],_0x4ba842,'internal-error');const _0x535662=_0xfd01ad['users'][0x0];_0x3528d2['_notifyReloadListener'](_0x535662);const _0x486a34=(_0x153c66=_0x535662['providerUserInfo'])!=null&&_0x153c66['length']?Sa(_0x535662['providerUserInfo']):[],_0x495ea0=Ef(_0x3528d2['providerData'],_0x486a34),_0x27298d=_0x3528d2['isAnonymous'],_0x2201c1=!(_0x3528d2['email']&&_0x535662['passwordHash'])&&!(_0x495ea0!=null&&_0x495ea0['length']),_0x441600=_0x27298d?_0x2201c1:!0x1,_0x5cf11a={'uid':_0x535662['localId'],'displayName':_0x535662['displayName']||null,'photoURL':_0x535662['photoUrl']||null,'email':_0x535662['email']||null,'emailVerified':_0x535662['emailVerified']||!0x1,'phoneNumber':_0x535662['phoneNumber']||null,'tenantId':_0x535662['tenantId']||null,'providerData':_0x495ea0,'metadata':new Oi(_0x535662['createdAt'],_0x535662['lastLoginAt']),'isAnonymous':_0x441600};Object['assign'](_0x3528d2,_0x5cf11a);}async function vf(_0x15eefa){const _0x457833=N(_0x15eefa);await Rn(_0x457833),await _0x457833['auth']['_persistUserIfCurrent'](_0x457833),_0x457833['auth']['_notifyListenersIfCurrent'](_0x457833);}function Ef(_0x16b244,_0x583f91){return[..._0x16b244['filter'](_0x16e255=>!_0x583f91['some'](_0x3e6b36=>_0x3e6b36['providerId']===_0x16e255['providerId'])),..._0x583f91];}function Sa(_0x331193){return _0x331193['map'](({providerId:_0x4fd0cd,..._0x1011a5})=>({'providerId':_0x4fd0cd,'uid':_0x1011a5['rawId']||'','displayName':_0x1011a5['displayName']||null,'email':_0x1011a5['email']||null,'phoneNumber':_0x1011a5['phoneNumber']||null,'photoURL':_0x1011a5['photoUrl']||null}));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function If(_0x435360,_0x1c6c1c){const _0x5606b4=await Ca(_0x435360,{},async()=>{const _0x24da78=ct({'grant_type':'refresh_token','refresh_token':_0x1c6c1c})['slice'](0x1),{tokenApiHost:_0x56b6f2,apiKey:_0x504302}=_0x435360['config'],_0x3426b4=await Ta(_0x435360,_0x56b6f2,'/v1/token','key='+_0x504302),_0x54f8d5=await _0x435360['_getAdditionalHeaders']();_0x54f8d5['Content-Type']='application/x-www-form-urlencoded';const _0xcd884f={'method':'POST','headers':_0x54f8d5,'body':_0x24da78};return _0x435360['emulatorConfig']&&at(_0x435360['emulatorConfig']['host'])&&(_0xcd884f['credentials']='include'),wa['fetch']()(_0x3426b4,_0xcd884f);});return{'accessToken':_0x5606b4['access_token'],'expiresIn':_0x5606b4['expires_in'],'refreshToken':_0x5606b4['refresh_token']};}async function wf(_0x2fdd4b,_0x22e913){return Ae(_0x2fdd4b,'POST','/v2/accounts:revokeToken',Re(_0x2fdd4b,_0x22e913));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Qe{constructor(){this['refreshToken']=null,this['accessToken']=null,this['expirationTime']=null;}get['isExpired'](){return!this['expirationTime']||Date['now']()>this['expirationTime']-0x7530;}['updateFromServerResponse'](_0x5201c0){m(_0x5201c0['idToken'],'internal-error'),m(typeof _0x5201c0['idToken']<'u','internal-error'),m(typeof _0x5201c0['refreshToken']<'u','internal-error');const _0x31592d='expiresIn'in _0x5201c0&&typeof _0x5201c0['expiresIn']<'u'?Number(_0x5201c0['expiresIn']):Cr(_0x5201c0['idToken']);this['updateTokensAndExpiration'](_0x5201c0['idToken'],_0x5201c0['refreshToken'],_0x31592d);}['updateFromIdToken'](_0x5be185){m(_0x5be185['length']!==0x0,'internal-error');const _0x20895b=Cr(_0x5be185);this['updateTokensAndExpiration'](_0x5be185,null,_0x20895b);}async['getToken'](_0x3c33ba,_0x1a3805=!0x1){return!_0x1a3805&&this['accessToken']&&!this['isExpired']?this['accessToken']:(m(this['refreshToken'],_0x3c33ba,'user-token-expired'),this['refreshToken']?(await this['refresh'](_0x3c33ba,this['refreshToken']),this['accessToken']):null);}['clearRefreshToken'](){this['refreshToken']=null;}async['refresh'](_0x317b9a,_0x17bc07){const {accessToken:_0x41fb25,refreshToken:_0x16d307,expiresIn:_0x20d9c7}=await If(_0x317b9a,_0x17bc07);this['updateTokensAndExpiration'](_0x41fb25,_0x16d307,Number(_0x20d9c7));}['updateTokensAndExpiration'](_0x37dacd,_0x64481e,_0x28c2cf){this['refreshToken']=_0x64481e||null,this['accessToken']=_0x37dacd||null,this['expirationTime']=Date['now']()+_0x28c2cf*0x3e8;}static['fromJSON'](_0x313385,_0x265320){const {refreshToken:_0x26dc06,accessToken:_0x116b91,expirationTime:_0x152d01}=_0x265320,_0x3d02ea=new Qe();return _0x26dc06&&(m(typeof _0x26dc06=='string','internal-error',{'appName':_0x313385}),_0x3d02ea['refreshToken']=_0x26dc06),_0x116b91&&(m(typeof _0x116b91=='string','internal-error',{'appName':_0x313385}),_0x3d02ea['accessToken']=_0x116b91),_0x152d01&&(m(typeof _0x152d01=='number','internal-error',{'appName':_0x313385}),_0x3d02ea['expirationTime']=_0x152d01),_0x3d02ea;}['toJSON'](){return{'refreshToken':this['refreshToken'],'accessToken':this['accessToken'],'expirationTime':this['expirationTime']};}['_assign'](_0x1ab346){this['accessToken']=_0x1ab346['accessToken'],this['refreshToken']=_0x1ab346['refreshToken'],this['expirationTime']=_0x1ab346['expirationTime'];}['_clone'](){return Object['assign'](new Qe(),this['toJSON']());}['_performRefresh'](){return ne('not\x20implemented');}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function le(_0x58704e,_0x388fc2){m(typeof _0x58704e=='string'||typeof _0x58704e>'u','internal-error',{'appName':_0x388fc2});}class K{constructor({uid:_0x35cfdd,auth:_0x2181c5,stsTokenManager:_0x4e6bfe,..._0x3e6ddc}){this['providerId']='firebase',this['proactiveRefresh']=new yf(this),this['reloadUserInfo']=null,this['reloadListener']=null,this['uid']=_0x35cfdd,this['auth']=_0x2181c5,this['stsTokenManager']=_0x4e6bfe,this['accessToken']=_0x4e6bfe['accessToken'],this['displayName']=_0x3e6ddc['displayName']||null,this['email']=_0x3e6ddc['email']||null,this['emailVerified']=_0x3e6ddc['emailVerified']||!0x1,this['phoneNumber']=_0x3e6ddc['phoneNumber']||null,this['photoURL']=_0x3e6ddc['photoURL']||null,this['isAnonymous']=_0x3e6ddc['isAnonymous']||!0x1,this['tenantId']=_0x3e6ddc['tenantId']||null,this['providerData']=_0x3e6ddc['providerData']?[..._0x3e6ddc['providerData']]:[],this['metadata']=new Oi(_0x3e6ddc['createdAt']||void 0x0,_0x3e6ddc['lastLoginAt']||void 0x0);}async['getIdToken'](_0x52a62c){const _0x4b0101=await Ut(this,this['stsTokenManager']['getToken'](this['auth'],_0x52a62c));return m(_0x4b0101,this['auth'],'internal-error'),this['accessToken']!==_0x4b0101&&(this['accessToken']=_0x4b0101,await this['auth']['_persistUserIfCurrent'](this),this['auth']['_notifyListenersIfCurrent'](this)),_0x4b0101;}['getIdTokenResult'](_0x56bc66){return gf(this,_0x56bc66);}['reload'](){return vf(this);}['_assign'](_0x65b415){this!==_0x65b415&&(m(this['uid']===_0x65b415['uid'],this['auth'],'internal-error'),this['displayName']=_0x65b415['displayName'],this['photoURL']=_0x65b415['photoURL'],this['email']=_0x65b415['email'],this['emailVerified']=_0x65b415['emailVerified'],this['phoneNumber']=_0x65b415['phoneNumber'],this['isAnonymous']=_0x65b415['isAnonymous'],this['tenantId']=_0x65b415['tenantId'],this['providerData']=_0x65b415['providerData']['map'](_0x1f3cd8=>({..._0x1f3cd8})),this['metadata']['_copy'](_0x65b415['metadata']),this['stsTokenManager']['_assign'](_0x65b415['stsTokenManager']));}['_clone'](_0x451157){const _0x11d8ac=new K({...this,'auth':_0x451157,'stsTokenManager':this['stsTokenManager']['_clone']()});return _0x11d8ac['metadata']['_copy'](this['metadata']),_0x11d8ac;}['_onReload'](_0x1228da){m(!this['reloadListener'],this['auth'],'internal-error'),this['reloadListener']=_0x1228da,this['reloadUserInfo']&&(this['_notifyReloadListener'](this['reloadUserInfo']),this['reloadUserInfo']=null);}['_notifyReloadListener'](_0x3d46b9){this['reloadListener']?this['reloadListener'](_0x3d46b9):this['reloadUserInfo']=_0x3d46b9;}['_startProactiveRefresh'](){this['proactiveRefresh']['_start']();}['_stopProactiveRefresh'](){this['proactiveRefresh']['_stop']();}async['_updateTokensIfNecessary'](_0x1cd98c,_0x58c882=!0x1){let _0xac3964=!0x1;_0x1cd98c['idToken']&&_0x1cd98c['idToken']!==this['stsTokenManager']['accessToken']&&(this['stsTokenManager']['updateFromServerResponse'](_0x1cd98c),_0xac3964=!0x0),_0x58c882&&await Rn(this),await this['auth']['_persistUserIfCurrent'](this),_0xac3964&&this['auth']['_notifyListenersIfCurrent'](this);}async['delete'](){if($(this['auth']['app']))return Promise['reject'](re(this['auth']));const _0x3d5832=await this['getIdToken']();return await Ut(this,_f(this['auth'],{'idToken':_0x3d5832})),this['stsTokenManager']['clearRefreshToken'](),this['auth']['signOut']();}['toJSON'](){return{'uid':this['uid'],'email':this['email']||void 0x0,'emailVerified':this['emailVerified'],'displayName':this['displayName']||void 0x0,'isAnonymous':this['isAnonymous'],'photoURL':this['photoURL']||void 0x0,'phoneNumber':this['phoneNumber']||void 0x0,'tenantId':this['tenantId']||void 0x0,'providerData':this['providerData']['map'](_0x4489b5=>({..._0x4489b5})),'stsTokenManager':this['stsTokenManager']['toJSON'](),'_redirectEventId':this['_redirectEventId'],...this['metadata']['toJSON'](),'apiKey':this['auth']['config']['apiKey'],'appName':this['auth']['name']};}get['refreshToken'](){return this['stsTokenManager']['refreshToken']||'';}static['_fromJSON'](_0x340ade,_0x1b289a){const _0x42463f=_0x1b289a['displayName']??void 0x0,_0x6fb3ec=_0x1b289a['email']??void 0x0,_0x50faa2=_0x1b289a['phoneNumber']??void 0x0,_0x6d729c=_0x1b289a['photoURL']??void 0x0,_0x14ae02=_0x1b289a['tenantId']??void 0x0,_0x30fded=_0x1b289a['_redirectEventId']??void 0x0,_0x456393=_0x1b289a['createdAt']??void 0x0,_0x15982a=_0x1b289a['lastLoginAt']??void 0x0,{uid:_0x127cd4,emailVerified:_0x2b2749,isAnonymous:_0xcdf886,providerData:_0x154853,stsTokenManager:_0x336ef6}=_0x1b289a;m(_0x127cd4&&_0x336ef6,_0x340ade,'internal-error');const _0x5266f0=Qe['fromJSON'](this['name'],_0x336ef6);m(typeof _0x127cd4=='string',_0x340ade,'internal-error'),le(_0x42463f,_0x340ade['name']),le(_0x6fb3ec,_0x340ade['name']),m(typeof _0x2b2749=='boolean',_0x340ade,'internal-error'),m(typeof _0xcdf886=='boolean',_0x340ade,'internal-error'),le(_0x50faa2,_0x340ade['name']),le(_0x6d729c,_0x340ade['name']),le(_0x14ae02,_0x340ade['name']),le(_0x30fded,_0x340ade['name']),le(_0x456393,_0x340ade['name']),le(_0x15982a,_0x340ade['name']);const _0x1077bb=new K({'uid':_0x127cd4,'auth':_0x340ade,'email':_0x6fb3ec,'emailVerified':_0x2b2749,'displayName':_0x42463f,'isAnonymous':_0xcdf886,'photoURL':_0x6d729c,'phoneNumber':_0x50faa2,'tenantId':_0x14ae02,'stsTokenManager':_0x5266f0,'createdAt':_0x456393,'lastLoginAt':_0x15982a});return _0x154853&&Array['isArray'](_0x154853)&&(_0x1077bb['providerData']=_0x154853['map'](_0x4dd9d7=>({..._0x4dd9d7}))),_0x30fded&&(_0x1077bb['_redirectEventId']=_0x30fded),_0x1077bb;}static async['_fromIdTokenResponse'](_0x125f67,_0x2251ca,_0x349d22=!0x1){const _0x4cda7f=new Qe();_0x4cda7f['updateFromServerResponse'](_0x2251ca);const _0x21754d=new K({'uid':_0x2251ca['localId'],'auth':_0x125f67,'stsTokenManager':_0x4cda7f,'isAnonymous':_0x349d22});return await Rn(_0x21754d),_0x21754d;}static async['_fromGetAccountInfoResponse'](_0x412c56,_0x8242ec,_0x49e1cb){const _0x315be0=_0x8242ec['users'][0x0];m(_0x315be0['localId']!==void 0x0,'internal-error');const _0x1b0797=_0x315be0['providerUserInfo']!==void 0x0?Sa(_0x315be0['providerUserInfo']):[],_0x42ade4=!(_0x315be0['email']&&_0x315be0['passwordHash'])&&!(_0x1b0797!=null&&_0x1b0797['length']),_0x1b891b=new Qe();_0x1b891b['updateFromIdToken'](_0x49e1cb);const _0x2b1997=new K({'uid':_0x315be0['localId'],'auth':_0x412c56,'stsTokenManager':_0x1b891b,'isAnonymous':_0x42ade4}),_0x31ea8d={'uid':_0x315be0['localId'],'displayName':_0x315be0['displayName']||null,'photoURL':_0x315be0['photoUrl']||null,'email':_0x315be0['email']||null,'emailVerified':_0x315be0['emailVerified']||!0x1,'phoneNumber':_0x315be0['phoneNumber']||null,'tenantId':_0x315be0['tenantId']||null,'providerData':_0x1b0797,'metadata':new Oi(_0x315be0['createdAt'],_0x315be0['lastLoginAt']),'isAnonymous':!(_0x315be0['email']&&_0x315be0['passwordHash'])&&!(_0x1b0797!=null&&_0x1b0797['length'])};return Object['assign'](_0x2b1997,_0x31ea8d),_0x2b1997;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Tr=new Map();function ie(_0xbab94f){ce(_0xbab94f instanceof Function,'Expected\x20a\x20class\x20definition');let _0x361047=Tr['get'](_0xbab94f);return _0x361047?(ce(_0x361047 instanceof _0xbab94f,'Instance\x20stored\x20in\x20cache\x20mismatched\x20with\x20class'),_0x361047):(_0x361047=new _0xbab94f(),Tr['set'](_0xbab94f,_0x361047),_0x361047);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ba{constructor(){this['type']='NONE',this['storage']={};}async['_isAvailable'](){return!0x0;}async['_set'](_0x4ab076,_0x2ca851){this['storage'][_0x4ab076]=_0x2ca851;}async['_get'](_0x1084a4){const _0xf6540c=this['storage'][_0x1084a4];return _0xf6540c===void 0x0?null:_0xf6540c;}async['_remove'](_0x4dcba8){delete this['storage'][_0x4dcba8];}['_addListener'](_0xdf38df,_0x266a92){}['_removeListener'](_0x1e49ce,_0x222455){}}ba['type']='NONE';const Sr=ba;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rn(_0x42cf83,_0x5243d7,_0x510f25){return'firebase:'+_0x42cf83+':'+_0x5243d7+':'+_0x510f25;}class Je{constructor(_0xba909d,_0x528071,_0x15ced0){this['persistence']=_0xba909d,this['auth']=_0x528071,this['userKey']=_0x15ced0;const {config:_0x49f64f,name:_0x32e6f8}=this['auth'];this['fullUserKey']=rn(this['userKey'],_0x49f64f['apiKey'],_0x32e6f8),this['fullPersistenceKey']=rn('persistence',_0x49f64f['apiKey'],_0x32e6f8),this['boundEventHandler']=_0x528071['_onStorageEvent']['bind'](_0x528071),this['persistence']['_addListener'](this['fullUserKey'],this['boundEventHandler']);}['setCurrentUser'](_0x221bf1){return this['persistence']['_set'](this['fullUserKey'],_0x221bf1['toJSON']());}async['getCurrentUser'](){const _0x253651=await this['persistence']['_get'](this['fullUserKey']);if(!_0x253651)return null;if(typeof _0x253651=='string'){const _0x1ce479=await bn(this['auth'],{'idToken':_0x253651})['catch'](()=>{});return _0x1ce479?K['_fromGetAccountInfoResponse'](this['auth'],_0x1ce479,_0x253651):null;}return K['_fromJSON'](this['auth'],_0x253651);}['removeCurrentUser'](){return this['persistence']['_remove'](this['fullUserKey']);}['savePersistenceForRedirect'](){return this['persistence']['_set'](this['fullPersistenceKey'],this['persistence']['type']);}async['setPersistence'](_0x525cb9){if(this['persistence']===_0x525cb9)return;const _0x2e0fde=await this['getCurrentUser']();if(await this['removeCurrentUser'](),this['persistence']=_0x525cb9,_0x2e0fde)return this['setCurrentUser'](_0x2e0fde);}['delete'](){this['persistence']['_removeListener'](this['fullUserKey'],this['boundEventHandler']);}static async['create'](_0x4b4f93,_0x1a3fde,_0x5befea='authUser'){if(!_0x1a3fde['length'])return new Je(ie(Sr),_0x4b4f93,_0x5befea);const _0x8ee25e=(await Promise['all'](_0x1a3fde['map'](async _0x154639=>{if(await _0x154639['_isAvailable']())return _0x154639;})))['filter'](_0x1d516c=>_0x1d516c);let _0x3c93bd=_0x8ee25e[0x0]||ie(Sr);const _0x1206e2=rn(_0x5befea,_0x4b4f93['config']['apiKey'],_0x4b4f93['name']);let _0x3c2cbd=null;for(const _0x7df07f of _0x1a3fde)try{const _0x4643f9=await _0x7df07f['_get'](_0x1206e2);if(_0x4643f9){let _0x227fd5;if(typeof _0x4643f9=='string'){const _0x57097b=await bn(_0x4b4f93,{'idToken':_0x4643f9})['catch'](()=>{});if(!_0x57097b)break;_0x227fd5=await K['_fromGetAccountInfoResponse'](_0x4b4f93,_0x57097b,_0x4643f9);}else _0x227fd5=K['_fromJSON'](_0x4b4f93,_0x4643f9);_0x7df07f!==_0x3c93bd&&(_0x3c2cbd=_0x227fd5),_0x3c93bd=_0x7df07f;break;}}catch{}const _0x445dfc=_0x8ee25e['filter'](_0x5b0776=>_0x5b0776['_shouldAllowMigration']);return!_0x3c93bd['_shouldAllowMigration']||!_0x445dfc['length']?new Je(_0x3c93bd,_0x4b4f93,_0x5befea):(_0x3c93bd=_0x445dfc[0x0],_0x3c2cbd&&await _0x3c93bd['_set'](_0x1206e2,_0x3c2cbd['toJSON']()),await Promise['all'](_0x1a3fde['map'](async _0x1179ac=>{if(_0x1179ac!==_0x3c93bd)try{await _0x1179ac['_remove'](_0x1206e2);}catch{}})),new Je(_0x3c93bd,_0x4b4f93,_0x5befea));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function br(_0x2a9e5f){const _0x4e6163=_0x2a9e5f['toLowerCase']();if(_0x4e6163['includes']('opera/')||_0x4e6163['includes']('opr/')||_0x4e6163['includes']('opios/'))return'Opera';if(Na(_0x4e6163))return'IEMobile';if(_0x4e6163['includes']('msie')||_0x4e6163['includes']('trident/'))return'IE';if(_0x4e6163['includes']('edge/'))return'Edge';if(Ra(_0x4e6163))return'Firefox';if(_0x4e6163['includes']('silk/'))return'Silk';if(Oa(_0x4e6163))return'Blackberry';if(Da(_0x4e6163))return'Webos';if(Aa(_0x4e6163))return'Safari';if((_0x4e6163['includes']('chrome/')||ka(_0x4e6163))&&!_0x4e6163['includes']('edge/'))return'Chrome';if(Pa(_0x4e6163))return'Android';{const _0x1a05ce=/([a-zA-Z\d\.]+)\/[a-zA-Z\d\.]*$/,_0x295189=_0x2a9e5f['match'](_0x1a05ce);if((_0x295189==null?void 0x0:_0x295189['length'])===0x2)return _0x295189[0x1];}return'Other';}function Ra(_0x44537e=W()){return/firefox\//i['test'](_0x44537e);}function Aa(_0x48f150=W()){const _0x45a343=_0x48f150['toLowerCase']();return _0x45a343['includes']('safari/')&&!_0x45a343['includes']('chrome/')&&!_0x45a343['includes']('crios/')&&!_0x45a343['includes']('android');}function ka(_0x33f92d=W()){return/crios\//i['test'](_0x33f92d);}function Na(_0x24541e=W()){return/iemobile/i['test'](_0x24541e);}function Pa(_0x447d6e=W()){return/android/i['test'](_0x447d6e);}function Oa(_0x47ec45=W()){return/blackberry/i['test'](_0x47ec45);}function Da(_0x26b734=W()){return/webos/i['test'](_0x26b734);}function Ss(_0x2a80b9=W()){return/iphone|ipad|ipod/i['test'](_0x2a80b9)||/macintosh/i['test'](_0x2a80b9)&&/mobile/i['test'](_0x2a80b9);}function Cf(_0xfd7ac3=W()){var _0x3e58d9;return Ss(_0xfd7ac3)&&!!((_0x3e58d9=window['navigator'])!=null&&_0x3e58d9['standalone']);}function Tf(){return pc()&&document['documentMode']===0xa;}function Ma(_0x568e65=W()){return Ss(_0x568e65)||Pa(_0x568e65)||Da(_0x568e65)||Oa(_0x568e65)||/windows phone/i['test'](_0x568e65)||Na(_0x568e65);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function La(_0x1deda1,_0x4af646=[]){let _0x5db099;switch(_0x1deda1){case'Browser':_0x5db099=br(W());break;case'Worker':_0x5db099=br(W())+'-'+_0x1deda1;break;default:_0x5db099=_0x1deda1;}const _0x4132c1=_0x4af646['length']?_0x4af646['join'](','):'FirebaseCore-web';return _0x5db099+'/JsCore/'+lt+'/'+_0x4132c1;}/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Sf{constructor(_0x49318b){this['auth']=_0x49318b,this['queue']=[];}['pushCallback'](_0x43ced0,_0x5033a2){const _0x34d337=_0x2b5bf7=>new Promise((_0x4f232d,_0x5c513f)=>{try{const _0x1ae5c7=_0x43ced0(_0x2b5bf7);_0x4f232d(_0x1ae5c7);}catch(_0x4820cb){_0x5c513f(_0x4820cb);}});_0x34d337['onAbort']=_0x5033a2,this['queue']['push'](_0x34d337);const _0x2713fc=this['queue']['length']-0x1;return()=>{this['queue'][_0x2713fc]=()=>Promise['resolve']();};}async['runMiddleware'](_0x5a1be8){if(this['auth']['currentUser']===_0x5a1be8)return;const _0xdd9df1=[];try{for(const _0x41837c of this['queue'])await _0x41837c(_0x5a1be8),_0x41837c['onAbort']&&_0xdd9df1['push'](_0x41837c['onAbort']);}catch(_0x220328){_0xdd9df1['reverse']();for(const _0x4946f5 of _0xdd9df1)try{_0x4946f5();}catch{}throw this['auth']['_errorFactory']['create']('login-blocked',{'originalMessage':_0x220328==null?void 0x0:_0x220328['message']});}}}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function bf(_0x2a3cd7,_0x55b248={}){return Ae(_0x2a3cd7,'GET','/v2/passwordPolicy',Re(_0x2a3cd7,_0x55b248));}/**
 * @license
 * Copyright 2023 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Rf=0x6;class Af{constructor(_0x4d1c38){var _0xdcd2d1;const _0x196faa=_0x4d1c38['customStrengthOptions'];this['customStrengthOptions']={},this['customStrengthOptions']['minPasswordLength']=_0x196faa['minPasswordLength']??Rf,_0x196faa['maxPasswordLength']&&(this['customStrengthOptions']['maxPasswordLength']=_0x196faa['maxPasswordLength']),_0x196faa['containsLowercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsLowercaseLetter']=_0x196faa['containsLowercaseCharacter']),_0x196faa['containsUppercaseCharacter']!==void 0x0&&(this['customStrengthOptions']['containsUppercaseLetter']=_0x196faa['containsUppercaseCharacter']),_0x196faa['containsNumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNumericCharacter']=_0x196faa['containsNumericCharacter']),_0x196faa['containsNonAlphanumericCharacter']!==void 0x0&&(this['customStrengthOptions']['containsNonAlphanumericCharacter']=_0x196faa['containsNonAlphanumericCharacter']),this['enforcementState']=_0x4d1c38['enforcementState'],this['enforcementState']==='ENFORCEMENT_STATE_UNSPECIFIED'&&(this['enforcementState']='OFF'),this['allowedNonAlphanumericCharacters']=((_0xdcd2d1=_0x4d1c38['allowedNonAlphanumericCharacters'])==null?void 0x0:_0xdcd2d1['join'](''))??'',this['forceUpgradeOnSignin']=_0x4d1c38['forceUpgradeOnSignin']??!0x1,this['schemaVersion']=_0x4d1c38['schemaVersion'];}['validatePassword'](_0x10f8a1){const _0x7eba25={'isValid':!0x0,'passwordPolicy':this};return this['validatePasswordLengthOptions'](_0x10f8a1,_0x7eba25),this['validatePasswordCharacterOptions'](_0x10f8a1,_0x7eba25),_0x7eba25['isValid']&&(_0x7eba25['isValid']=_0x7eba25['meetsMinPasswordLength']??!0x0),_0x7eba25['isValid']&&(_0x7eba25['isValid']=_0x7eba25['meetsMaxPasswordLength']??!0x0),_0x7eba25['isValid']&&(_0x7eba25['isValid']=_0x7eba25['containsLowercaseLetter']??!0x0),_0x7eba25['isValid']&&(_0x7eba25['isValid']=_0x7eba25['containsUppercaseLetter']??!0x0),_0x7eba25['isValid']&&(_0x7eba25['isValid']=_0x7eba25['containsNumericCharacter']??!0x0),_0x7eba25['isValid']&&(_0x7eba25['isValid']=_0x7eba25['containsNonAlphanumericCharacter']??!0x0),_0x7eba25;}['validatePasswordLengthOptions'](_0x3d863e,_0x4ac310){const _0x2861b2=this['customStrengthOptions']['minPasswordLength'],_0x415adb=this['customStrengthOptions']['maxPasswordLength'];_0x2861b2&&(_0x4ac310['meetsMinPasswordLength']=_0x3d863e['length']>=_0x2861b2),_0x415adb&&(_0x4ac310['meetsMaxPasswordLength']=_0x3d863e['length']<=_0x415adb);}['validatePasswordCharacterOptions'](_0xc3fe0d,_0x5ed7b9){this['updatePasswordCharacterOptionsStatuses'](_0x5ed7b9,!0x1,!0x1,!0x1,!0x1);let _0x5f5afe;for(let _0x1f59de=0x0;_0x1f59de<_0xc3fe0d['length'];_0x1f59de++)_0x5f5afe=_0xc3fe0d['charAt'](_0x1f59de),this['updatePasswordCharacterOptionsStatuses'](_0x5ed7b9,_0x5f5afe>='a'&&_0x5f5afe<='z',_0x5f5afe>='A'&&_0x5f5afe<='Z',_0x5f5afe>='0'&&_0x5f5afe<='9',this['allowedNonAlphanumericCharacters']['includes'](_0x5f5afe));}['updatePasswordCharacterOptionsStatuses'](_0x153baa,_0x795fd1,_0x531bb9,_0x33cdd9,_0x188fda){this['customStrengthOptions']['containsLowercaseLetter']&&(_0x153baa['containsLowercaseLetter']||(_0x153baa['containsLowercaseLetter']=_0x795fd1)),this['customStrengthOptions']['containsUppercaseLetter']&&(_0x153baa['containsUppercaseLetter']||(_0x153baa['containsUppercaseLetter']=_0x531bb9)),this['customStrengthOptions']['containsNumericCharacter']&&(_0x153baa['containsNumericCharacter']||(_0x153baa['containsNumericCharacter']=_0x33cdd9)),this['customStrengthOptions']['containsNonAlphanumericCharacter']&&(_0x153baa['containsNonAlphanumericCharacter']||(_0x153baa['containsNonAlphanumericCharacter']=_0x188fda));}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class kf{constructor(_0x233c1b,_0x11fff1,_0x2efd86,_0x2fd2bb){this['app']=_0x233c1b,this['heartbeatServiceProvider']=_0x11fff1,this['appCheckServiceProvider']=_0x2efd86,this['config']=_0x2fd2bb,this['currentUser']=null,this['emulatorConfig']=null,this['operations']=Promise['resolve'](),this['authStateSubscription']=new Rr(this),this['idTokenSubscription']=new Rr(this),this['beforeStateQueue']=new Sf(this),this['redirectUser']=null,this['isProactiveRefreshEnabled']=!0x1,this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']=0x1,this['_canInitEmulator']=!0x0,this['_isInitialized']=!0x1,this['_deleted']=!0x1,this['_initializationPromise']=null,this['_popupRedirectResolver']=null,this['_errorFactory']=Ea,this['_agentRecaptchaConfig']=null,this['_tenantRecaptchaConfigs']={},this['_projectPasswordPolicy']=null,this['_tenantPasswordPolicies']={},this['_resolvePersistenceManagerAvailable']=void 0x0,this['lastNotifiedUid']=void 0x0,this['languageCode']=null,this['tenantId']=null,this['settings']={'appVerificationDisabledForTesting':!0x1},this['frameworks']=[],this['name']=_0x233c1b['name'],this['clientVersion']=_0x2fd2bb['sdkClientVersion'],this['_persistenceManagerAvailable']=new Promise(_0xee9b86=>this['_resolvePersistenceManagerAvailable']=_0xee9b86);}['_initializeWithPersistence'](_0x22b908,_0x591e0d){return _0x591e0d&&(this['_popupRedirectResolver']=ie(_0x591e0d)),this['_initializationPromise']=this['queue'](async()=>{var _0x1a5983,_0x522f92,_0x18bf40;if(!this['_deleted']&&(this['persistenceManager']=await Je['create'](this,_0x22b908),(_0x1a5983=this['_resolvePersistenceManagerAvailable'])==null||_0x1a5983['call'](this),!this['_deleted'])){if((_0x522f92=this['_popupRedirectResolver'])!=null&&_0x522f92['_shouldInitProactively'])try{await this['_popupRedirectResolver']['_initialize'](this);}catch{}await this['initializeCurrentUser'](_0x591e0d),this['lastNotifiedUid']=((_0x18bf40=this['currentUser'])==null?void 0x0:_0x18bf40['uid'])||null,!this['_deleted']&&(this['_isInitialized']=!0x0);}}),this['_initializationPromise'];}async['_onStorageEvent'](){if(this['_deleted'])return;const _0x336528=await this['assertedPersistence']['getCurrentUser']();if(!(!this['currentUser']&&!_0x336528)){if(this['currentUser']&&_0x336528&&this['currentUser']['uid']===_0x336528['uid']){this['_currentUser']['_assign'](_0x336528),await this['currentUser']['getIdToken']();return;}await this['_updateCurrentUser'](_0x336528,!0x0);}}async['initializeCurrentUserFromIdToken'](_0x3b76d9){try{const _0x434e04=await bn(this,{'idToken':_0x3b76d9}),_0x2ce7bd=await K['_fromGetAccountInfoResponse'](this,_0x434e04,_0x3b76d9);await this['directlySetCurrentUser'](_0x2ce7bd);}catch(_0x3b8477){console['warn']('FirebaseServerApp\x20could\x20not\x20login\x20user\x20with\x20provided\x20authIdToken:\x20',_0x3b8477),await this['directlySetCurrentUser'](null);}}async['initializeCurrentUser'](_0x334e6d){var _0x3f5781;if($(this['app'])){const _0x59f31e=this['app']['settings']['authIdToken'];return _0x59f31e?new Promise(_0x95c7f9=>{setTimeout(()=>this['initializeCurrentUserFromIdToken'](_0x59f31e)['then'](_0x95c7f9,_0x95c7f9));}):this['directlySetCurrentUser'](null);}const _0x4dc4ba=await this['assertedPersistence']['getCurrentUser']();let _0x2b5aae=_0x4dc4ba,_0x3d9588=!0x1;if(_0x334e6d&&this['config']['authDomain']){await this['getOrInitRedirectPersistenceManager']();const _0x456af6=(_0x3f5781=this['redirectUser'])==null?void 0x0:_0x3f5781['_redirectEventId'],_0x1dd3a3=_0x2b5aae==null?void 0x0:_0x2b5aae['_redirectEventId'],_0x132183=await this['tryRedirectSignIn'](_0x334e6d);(!_0x456af6||_0x456af6===_0x1dd3a3)&&(_0x132183!=null&&_0x132183['user'])&&(_0x2b5aae=_0x132183['user'],_0x3d9588=!0x0);}if(!_0x2b5aae)return this['directlySetCurrentUser'](null);if(!_0x2b5aae['_redirectEventId']){if(_0x3d9588)try{await this['beforeStateQueue']['runMiddleware'](_0x2b5aae);}catch(_0xf95c45){_0x2b5aae=_0x4dc4ba,this['_popupRedirectResolver']['_overrideRedirectResult'](this,()=>Promise['reject'](_0xf95c45));}return _0x2b5aae?this['reloadAndSetCurrentUserOrClear'](_0x2b5aae):this['directlySetCurrentUser'](null);}return m(this['_popupRedirectResolver'],this,'argument-error'),await this['getOrInitRedirectPersistenceManager'](),this['redirectUser']&&this['redirectUser']['_redirectEventId']===_0x2b5aae['_redirectEventId']?this['directlySetCurrentUser'](_0x2b5aae):this['reloadAndSetCurrentUserOrClear'](_0x2b5aae);}async['tryRedirectSignIn'](_0xfdc4b){let _0x5dc454=null;try{_0x5dc454=await this['_popupRedirectResolver']['_completeRedirectFn'](this,_0xfdc4b,!0x0);}catch{await this['_setRedirectUser'](null);}return _0x5dc454;}async['reloadAndSetCurrentUserOrClear'](_0x5e1c28){try{await Rn(_0x5e1c28);}catch(_0x315448){if((_0x315448==null?void 0x0:_0x315448['code'])!=='auth/network-request-failed')return this['directlySetCurrentUser'](null);}return this['directlySetCurrentUser'](_0x5e1c28);}['useDeviceLanguage'](){this['languageCode']=af();}async['_delete'](){this['_deleted']=!0x0;}async['updateCurrentUser'](_0x480724){if($(this['app']))return Promise['reject'](re(this));const _0x4e716e=_0x480724?N(_0x480724):null;return _0x4e716e&&m(_0x4e716e['auth']['config']['apiKey']===this['config']['apiKey'],this,'invalid-user-token'),this['_updateCurrentUser'](_0x4e716e&&_0x4e716e['_clone'](this));}async['_updateCurrentUser'](_0x224b00,_0x93c9f7=!0x1){if(!this['_deleted'])return _0x224b00&&m(this['tenantId']===_0x224b00['tenantId'],this,'tenant-id-mismatch'),_0x93c9f7||await this['beforeStateQueue']['runMiddleware'](_0x224b00),this['queue'](async()=>{await this['directlySetCurrentUser'](_0x224b00),this['notifyAuthListeners']();});}async['signOut'](){return $(this['app'])?Promise['reject'](re(this)):(await this['beforeStateQueue']['runMiddleware'](null),(this['redirectPersistenceManager']||this['_popupRedirectResolver'])&&await this['_setRedirectUser'](null),this['_updateCurrentUser'](null,!0x0));}['setPersistence'](_0x405463){return $(this['app'])?Promise['reject'](re(this)):this['queue'](async()=>{await this['assertedPersistence']['setPersistence'](ie(_0x405463));});}['_getRecaptchaConfig'](){return this['tenantId']==null?this['_agentRecaptchaConfig']:this['_tenantRecaptchaConfigs'][this['tenantId']];}async['validatePassword'](_0x42e5f3){this['_getPasswordPolicyInternal']()||await this['_updatePasswordPolicy']();const _0x43ddfc=this['_getPasswordPolicyInternal']();return _0x43ddfc['schemaVersion']!==this['EXPECTED_PASSWORD_POLICY_SCHEMA_VERSION']?Promise['reject'](this['_errorFactory']['create']('unsupported-password-policy-schema-version',{})):_0x43ddfc['validatePassword'](_0x42e5f3);}['_getPasswordPolicyInternal'](){return this['tenantId']===null?this['_projectPasswordPolicy']:this['_tenantPasswordPolicies'][this['tenantId']];}async['_updatePasswordPolicy'](){const _0xda00f8=await bf(this),_0x5077c2=new Af(_0xda00f8);this['tenantId']===null?this['_projectPasswordPolicy']=_0x5077c2:this['_tenantPasswordPolicies'][this['tenantId']]=_0x5077c2;}['_getPersistenceType'](){return this['assertedPersistence']['persistence']['type'];}['_getPersistence'](){return this['assertedPersistence']['persistence'];}['_updateErrorMap'](_0x37a2cd){this['_errorFactory']=new Bt('auth','Firebase',_0x37a2cd());}['onAuthStateChanged'](_0x3d5689,_0xef7efd,_0x4069f1){return this['registerStateListener'](this['authStateSubscription'],_0x3d5689,_0xef7efd,_0x4069f1);}['beforeAuthStateChanged'](_0x38d73e,_0x5d1bbc){return this['beforeStateQueue']['pushCallback'](_0x38d73e,_0x5d1bbc);}['onIdTokenChanged'](_0x54defb,_0x60372c,_0x1470fa){return this['registerStateListener'](this['idTokenSubscription'],_0x54defb,_0x60372c,_0x1470fa);}['authStateReady'](){return new Promise((_0x2d9aa4,_0x56cef8)=>{if(this['currentUser'])_0x2d9aa4();else{const _0x5747ba=this['onAuthStateChanged'](()=>{_0x5747ba(),_0x2d9aa4();},_0x56cef8);}});}async['revokeAccessToken'](_0x11f17c){if(this['currentUser']){const _0x522fca=await this['currentUser']['getIdToken'](),_0x5c9bf7={'providerId':'apple.com','tokenType':'ACCESS_TOKEN','token':_0x11f17c,'idToken':_0x522fca};this['tenantId']!=null&&(_0x5c9bf7['tenantId']=this['tenantId']),await wf(this,_0x5c9bf7);}}['toJSON'](){var _0x19dcc3;return{'apiKey':this['config']['apiKey'],'authDomain':this['config']['authDomain'],'appName':this['name'],'currentUser':(_0x19dcc3=this['_currentUser'])==null?void 0x0:_0x19dcc3['toJSON']()};}async['_setRedirectUser'](_0x12716d,_0x40a367){const _0xb15a30=await this['getOrInitRedirectPersistenceManager'](_0x40a367);return _0x12716d===null?_0xb15a30['removeCurrentUser']():_0xb15a30['setCurrentUser'](_0x12716d);}async['getOrInitRedirectPersistenceManager'](_0x3b8101){if(!this['redirectPersistenceManager']){const _0x260d1c=_0x3b8101&&ie(_0x3b8101)||this['_popupRedirectResolver'];m(_0x260d1c,this,'argument-error'),this['redirectPersistenceManager']=await Je['create'](this,[ie(_0x260d1c['_redirectPersistence'])],'redirectUser'),this['redirectUser']=await this['redirectPersistenceManager']['getCurrentUser']();}return this['redirectPersistenceManager'];}async['_redirectUserForId'](_0x2b2c08){var _0x59820e,_0x4fd6f6;return this['_isInitialized']&&await this['queue'](async()=>{}),((_0x59820e=this['_currentUser'])==null?void 0x0:_0x59820e['_redirectEventId'])===_0x2b2c08?this['_currentUser']:((_0x4fd6f6=this['redirectUser'])==null?void 0x0:_0x4fd6f6['_redirectEventId'])===_0x2b2c08?this['redirectUser']:null;}async['_persistUserIfCurrent'](_0x144c72){if(_0x144c72===this['currentUser'])return this['queue'](async()=>this['directlySetCurrentUser'](_0x144c72));}['_notifyListenersIfCurrent'](_0x50a4c5){_0x50a4c5===this['currentUser']&&this['notifyAuthListeners']();}['_key'](){return this['config']['authDomain']+':'+this['config']['apiKey']+':'+this['name'];}['_startProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x0,this['currentUser']&&this['_currentUser']['_startProactiveRefresh']();}['_stopProactiveRefresh'](){this['isProactiveRefreshEnabled']=!0x1,this['currentUser']&&this['_currentUser']['_stopProactiveRefresh']();}get['_currentUser'](){return this['currentUser'];}['notifyAuthListeners'](){var _0x587076;if(!this['_isInitialized'])return;this['idTokenSubscription']['next'](this['currentUser']);const _0x4d37b8=((_0x587076=this['currentUser'])==null?void 0x0:_0x587076['uid'])??null;this['lastNotifiedUid']!==_0x4d37b8&&(this['lastNotifiedUid']=_0x4d37b8,this['authStateSubscription']['next'](this['currentUser']));}['registerStateListener'](_0x267a74,_0x43a774,_0xd4316f,_0x50e9c9){if(this['_deleted'])return()=>{};const _0x2e0f5f=typeof _0x43a774=='function'?_0x43a774:_0x43a774['next']['bind'](_0x43a774);let _0x2d8818=!0x1;const _0x2757e6=this['_isInitialized']?Promise['resolve']():this['_initializationPromise'];if(m(_0x2757e6,this,'internal-error'),_0x2757e6['then'](()=>{_0x2d8818||_0x2e0f5f(this['currentUser']);}),typeof _0x43a774=='function'){const _0x148acc=_0x267a74['addObserver'](_0x43a774,_0xd4316f,_0x50e9c9);return()=>{_0x2d8818=!0x0,_0x148acc();};}else{const _0x1398c7=_0x267a74['addObserver'](_0x43a774);return()=>{_0x2d8818=!0x0,_0x1398c7();};}}async['directlySetCurrentUser'](_0x263aa8){this['currentUser']&&this['currentUser']!==_0x263aa8&&this['_currentUser']['_stopProactiveRefresh'](),_0x263aa8&&this['isProactiveRefreshEnabled']&&_0x263aa8['_startProactiveRefresh'](),this['currentUser']=_0x263aa8,_0x263aa8?await this['assertedPersistence']['setCurrentUser'](_0x263aa8):await this['assertedPersistence']['removeCurrentUser']();}['queue'](_0xc0692c){return this['operations']=this['operations']['then'](_0xc0692c,_0xc0692c),this['operations'];}get['assertedPersistence'](){return m(this['persistenceManager'],this,'internal-error'),this['persistenceManager'];}['_logFramework'](_0x5c328e){!_0x5c328e||this['frameworks']['includes'](_0x5c328e)||(this['frameworks']['push'](_0x5c328e),this['frameworks']['sort'](),this['clientVersion']=La(this['config']['clientPlatform'],this['_getFrameworks']()));}['_getFrameworks'](){return this['frameworks'];}async['_getAdditionalHeaders'](){var _0x282d39;const _0x309db2={'X-Client-Version':this['clientVersion']};this['app']['options']['appId']&&(_0x309db2['X-Firebase-gmpid']=this['app']['options']['appId']);const _0x580077=await((_0x282d39=this['heartbeatServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x282d39['getHeartbeatsHeader']());_0x580077&&(_0x309db2['X-Firebase-Client']=_0x580077);const _0x89e704=await this['_getAppCheckToken']();return _0x89e704&&(_0x309db2['X-Firebase-AppCheck']=_0x89e704),_0x309db2;}async['_getAppCheckToken'](){var _0x49f43a;if($(this['app'])&&this['app']['settings']['appCheckToken'])return this['app']['settings']['appCheckToken'];const _0x1f27cf=await((_0x49f43a=this['appCheckServiceProvider']['getImmediate']({'optional':!0x0}))==null?void 0x0:_0x49f43a['getToken']());return _0x1f27cf!=null&&_0x1f27cf['error']&&sf('Error\x20while\x20retrieving\x20App\x20Check\x20token:\x20'+_0x1f27cf['error']),_0x1f27cf==null?void 0x0:_0x1f27cf['token'];}}function qe(_0x11ba3f){return N(_0x11ba3f);}class Rr{constructor(_0x1462db){this['auth']=_0x1462db,this['observer']=null,this['addObserver']=Tc(_0x18aea3=>this['observer']=_0x18aea3);}get['next'](){return m(this['observer'],this['auth'],'internal-error'),this['observer']['next']['bind'](this['observer']);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let jn={async 'loadJS'(){throw new Error('Unable\x20to\x20load\x20external\x20scripts');},'recaptchaV2Script':'','recaptchaEnterpriseScript':'','gapiScript':''};function Nf(_0x48a180){jn=_0x48a180;}function xa(_0x168501){return jn['loadJS'](_0x168501);}function Pf(){return jn['recaptchaEnterpriseScript'];}function Of(){return jn['gapiScript'];}function Df(_0x276f2b){return'__'+_0x276f2b+Math['floor'](Math['random']()*0xf4240);}class Mf{constructor(){this['enterprise']=new Lf();}['ready'](_0x6cf5a4){_0x6cf5a4();}['execute'](_0x3fab9c,_0x21c230){return Promise['resolve']('token');}['render'](_0x2b9853,_0x3a73a9){return'';}}class Lf{['ready'](_0x127d05){_0x127d05();}['execute'](_0x10e78b,_0xa27ca){return Promise['resolve']('token');}['render'](_0x1bb9e6,_0x1d00e3){return'';}}const xf='recaptcha-enterprise',Fa='NO_RECAPTCHA';class Ff{constructor(_0x559de8){this['type']=xf,this['auth']=qe(_0x559de8);}async['verify'](_0x56710f='verify',_0x34c047=!0x1){async function _0x101ef1(_0x4673b8){if(!_0x34c047){if(_0x4673b8['tenantId']==null&&_0x4673b8['_agentRecaptchaConfig']!=null)return _0x4673b8['_agentRecaptchaConfig']['siteKey'];if(_0x4673b8['tenantId']!=null&&_0x4673b8['_tenantRecaptchaConfigs'][_0x4673b8['tenantId']]!==void 0x0)return _0x4673b8['_tenantRecaptchaConfigs'][_0x4673b8['tenantId']]['siteKey'];}return new Promise(async(_0x447421,_0x1c057a)=>{pf(_0x4673b8,{'clientType':'CLIENT_TYPE_WEB','version':'RECAPTCHA_ENTERPRISE'})['then'](_0x2f7f25=>{if(_0x2f7f25['recaptchaKey']===void 0x0)_0x1c057a(new Error('recaptcha\x20Enterprise\x20site\x20key\x20undefined'));else{const _0x5ee380=new ff(_0x2f7f25);return _0x4673b8['tenantId']==null?_0x4673b8['_agentRecaptchaConfig']=_0x5ee380:_0x4673b8['_tenantRecaptchaConfigs'][_0x4673b8['tenantId']]=_0x5ee380,_0x447421(_0x5ee380['siteKey']);}})['catch'](_0x89a372=>{_0x1c057a(_0x89a372);});});}function _0x1130b9(_0x5149e9,_0x4a2628,_0x566d0d){const _0x59fe06=window['grecaptcha'];wr(_0x59fe06)?_0x59fe06['enterprise']['ready'](()=>{_0x59fe06['enterprise']['execute'](_0x5149e9,{'action':_0x56710f})['then'](_0x3e8502=>{_0x4a2628(_0x3e8502);})['catch'](()=>{_0x4a2628(Fa);});}):_0x566d0d(Error('No\x20reCAPTCHA\x20enterprise\x20script\x20loaded.'));}return this['auth']['settings']['appVerificationDisabledForTesting']?new Mf()['execute']('siteKey',{'action':'verify'}):new Promise((_0xddf776,_0x26f641)=>{_0x101ef1(this['auth'])['then'](_0xece329=>{if(!_0x34c047&&wr(window['grecaptcha']))_0x1130b9(_0xece329,_0xddf776,_0x26f641);else{if(typeof window>'u'){_0x26f641(new Error('RecaptchaVerifier\x20is\x20only\x20supported\x20in\x20browser'));return;}let _0x24efc7=Pf();_0x24efc7['length']!==0x0&&(_0x24efc7+=_0xece329),xa(_0x24efc7)['then'](()=>{_0x1130b9(_0xece329,_0xddf776,_0x26f641);})['catch'](_0x58de35=>{_0x26f641(_0x58de35);});}})['catch'](_0x11d443=>{_0x26f641(_0x11d443);});});}}async function Ar(_0x481995,_0x2b18a2,_0x1cacc5,_0x46bb44=!0x1,_0x8c0347=!0x1){const _0x249690=new Ff(_0x481995);let _0x4a3d19;if(_0x8c0347)_0x4a3d19=Fa;else try{_0x4a3d19=await _0x249690['verify'](_0x1cacc5);}catch{_0x4a3d19=await _0x249690['verify'](_0x1cacc5,!0x0);}const _0x1db61b={..._0x2b18a2};if(_0x1cacc5==='mfaSmsEnrollment'||_0x1cacc5==='mfaSmsSignIn'){if('phoneEnrollmentInfo'in _0x1db61b){const _0x46f00c=_0x1db61b['phoneEnrollmentInfo']['phoneNumber'],_0x4b883d=_0x1db61b['phoneEnrollmentInfo']['recaptchaToken'];Object['assign'](_0x1db61b,{'phoneEnrollmentInfo':{'phoneNumber':_0x46f00c,'recaptchaToken':_0x4b883d,'captchaResponse':_0x4a3d19,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}else{if('phoneSignInInfo'in _0x1db61b){const _0x24722d=_0x1db61b['phoneSignInInfo']['recaptchaToken'];Object['assign'](_0x1db61b,{'phoneSignInInfo':{'recaptchaToken':_0x24722d,'captchaResponse':_0x4a3d19,'clientType':'CLIENT_TYPE_WEB','recaptchaVersion':'RECAPTCHA_ENTERPRISE'}});}}return _0x1db61b;}return _0x46bb44?Object['assign'](_0x1db61b,{'captchaResp':_0x4a3d19}):Object['assign'](_0x1db61b,{'captchaResponse':_0x4a3d19}),Object['assign'](_0x1db61b,{'clientType':'CLIENT_TYPE_WEB'}),Object['assign'](_0x1db61b,{'recaptchaVersion':'RECAPTCHA_ENTERPRISE'}),_0x1db61b;}async function Di(_0x5c29c0,_0x20c384,_0x1f4cb3,_0x45b66e,_0x3837ca){var _0x6e318e;if((_0x6e318e=_0x5c29c0['_getRecaptchaConfig']())!=null&&_0x6e318e['isProviderEnabled']('EMAIL_PASSWORD_PROVIDER')){const _0x49df55=await Ar(_0x5c29c0,_0x20c384,_0x1f4cb3,_0x1f4cb3==='getOobCode');return _0x45b66e(_0x5c29c0,_0x49df55);}else return _0x45b66e(_0x5c29c0,_0x20c384)['catch'](async _0x50c4f1=>{if(_0x50c4f1['code']==='auth/missing-recaptcha-token'){console['log'](_0x1f4cb3+'\x20is\x20protected\x20by\x20reCAPTCHA\x20Enterprise\x20for\x20this\x20project.\x20Automatically\x20triggering\x20the\x20reCAPTCHA\x20flow\x20and\x20restarting\x20the\x20flow.');const _0xbc4d=await Ar(_0x5c29c0,_0x20c384,_0x1f4cb3,_0x1f4cb3==='getOobCode');return _0x45b66e(_0x5c29c0,_0xbc4d);}else return Promise['reject'](_0x50c4f1);});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Uf(_0x598bbb,_0xd95225){const _0x43ddd9=Bi(_0x598bbb,'auth');if(_0x43ddd9['isInitialized']()){const _0x5b8272=_0x43ddd9['getImmediate'](),_0x4aca9c=_0x43ddd9['getOptions']();if(Me(_0x4aca9c,_0xd95225??{}))return _0x5b8272;Q(_0x5b8272,'already-initialized');}return _0x43ddd9['initialize']({'options':_0xd95225});}function Wf(_0x5bfdb4,_0x3f05ae){const _0x11adef=(_0x3f05ae==null?void 0x0:_0x3f05ae['persistence'])||[],_0x258fa9=(Array['isArray'](_0x11adef)?_0x11adef:[_0x11adef])['map'](ie);_0x3f05ae!=null&&_0x3f05ae['errorMap']&&_0x5bfdb4['_updateErrorMap'](_0x3f05ae['errorMap']),_0x5bfdb4['_initializeWithPersistence'](_0x258fa9,_0x3f05ae==null?void 0x0:_0x3f05ae['popupRedirectResolver']);}function Bf(_0x3d12d3,_0x93e427,_0x5dca52){const _0x6ad3de=qe(_0x3d12d3);m(/^https?:\/\//['test'](_0x93e427),_0x6ad3de,'invalid-emulator-scheme');const _0x3ddf17=!0x1,_0x530235=Ua(_0x93e427),{host:_0x283819,port:_0x3fdad7}=Vf(_0x93e427),_0x4ddf6c=_0x3fdad7===null?'':':'+_0x3fdad7,_0x1ab0c4={'url':_0x530235+'//'+_0x283819+_0x4ddf6c+'/'},_0x26116a=Object['freeze']({'host':_0x283819,'port':_0x3fdad7,'protocol':_0x530235['replace'](':',''),'options':Object['freeze']({'disableWarnings':_0x3ddf17})});if(!_0x6ad3de['_canInitEmulator']){m(_0x6ad3de['config']['emulator']&&_0x6ad3de['emulatorConfig'],_0x6ad3de,'emulator-config-failed'),m(Me(_0x1ab0c4,_0x6ad3de['config']['emulator'])&&Me(_0x26116a,_0x6ad3de['emulatorConfig']),_0x6ad3de,'emulator-config-failed');return;}_0x6ad3de['config']['emulator']=_0x1ab0c4,_0x6ad3de['emulatorConfig']=_0x26116a,_0x6ad3de['settings']['appVerificationDisabledForTesting']=!0x0,at(_0x283819)?(jr(_0x530235+'//'+_0x283819+_0x4ddf6c),Kr('Auth',!0x0)):Hf();}function Ua(_0x284f8a){const _0x9fc94c=_0x284f8a['indexOf'](':');return _0x9fc94c<0x0?'':_0x284f8a['substr'](0x0,_0x9fc94c+0x1);}function Vf(_0x58c9c2){const _0x1866bf=Ua(_0x58c9c2),_0x3f5256=/(\/\/)?([^?#/]+)/['exec'](_0x58c9c2['substr'](_0x1866bf['length']));if(!_0x3f5256)return{'host':'','port':null};const _0x4d48e5=_0x3f5256[0x2]['split']('@')['pop']()||'',_0x352848=/^(\[[^\]]+\])(:|$)/['exec'](_0x4d48e5);if(_0x352848){const _0x3c557c=_0x352848[0x1];return{'host':_0x3c557c,'port':kr(_0x4d48e5['substr'](_0x3c557c['length']+0x1))};}else{const [_0x11b895,_0x458a9d]=_0x4d48e5['split'](':');return{'host':_0x11b895,'port':kr(_0x458a9d)};}}function kr(_0x3e1399){if(!_0x3e1399)return null;const _0x2362fe=Number(_0x3e1399);return isNaN(_0x2362fe)?null:_0x2362fe;}function Hf(){function _0x57de06(){const _0x287549=document['createElement']('p'),_0x327e28=_0x287549['style'];_0x287549['innerText']='Running\x20in\x20emulator\x20mode.\x20Do\x20not\x20use\x20with\x20production\x20credentials.',_0x327e28['position']='fixed',_0x327e28['width']='100%',_0x327e28['backgroundColor']='#ffffff',_0x327e28['border']='.1em\x20solid\x20#000000',_0x327e28['color']='#b50000',_0x327e28['bottom']='0px',_0x327e28['left']='0px',_0x327e28['margin']='0px',_0x327e28['zIndex']='10000',_0x327e28['textAlign']='center',_0x287549['classList']['add']('firebase-emulator-warning'),document['body']['appendChild'](_0x287549);}typeof console<'u'&&typeof console['info']=='function'&&console['info']('WARNING:\x20You\x20are\x20using\x20the\x20Auth\x20Emulator,\x20which\x20is\x20intended\x20for\x20local\x20testing\x20only.\x20\x20Do\x20not\x20use\x20with\x20production\x20credentials.'),typeof window<'u'&&typeof document<'u'&&(document['readyState']==='loading'?window['addEventListener']('DOMContentLoaded',_0x57de06):_0x57de06());}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class bs{constructor(_0x27803f,_0x12f67a){this['providerId']=_0x27803f,this['signInMethod']=_0x12f67a;}['toJSON'](){return ne('not\x20implemented');}['_getIdTokenResponse'](_0x4079ef){return ne('not\x20implemented');}['_linkToIdToken'](_0xd103ca,_0xef5aae){return ne('not\x20implemented');}['_getReauthenticationResolver'](_0x2eaaf7){return ne('not\x20implemented');}}async function $f(_0x4874db,_0x5a8086){return Ae(_0x4874db,'POST','/v1/accounts:signUp',_0x5a8086);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Gf(_0x345c5f,_0x4b7673){return Qt(_0x345c5f,'POST','/v1/accounts:signInWithPassword',Re(_0x345c5f,_0x4b7673));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function qf(_0xd0eab6,_0x589bdb){return Qt(_0xd0eab6,'POST','/v1/accounts:signInWithEmailLink',Re(_0xd0eab6,_0x589bdb));}async function zf(_0x1c61c7,_0x4cc650){return Qt(_0x1c61c7,'POST','/v1/accounts:signInWithEmailLink',Re(_0x1c61c7,_0x4cc650));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wt extends bs{constructor(_0x282721,_0x493d68,_0x5d96fb,_0x4e4519=null){super('password',_0x5d96fb),this['_email']=_0x282721,this['_password']=_0x493d68,this['_tenantId']=_0x4e4519;}static['_fromEmailAndPassword'](_0x58a6bc,_0x599a5c){return new Wt(_0x58a6bc,_0x599a5c,'password');}static['_fromEmailAndCode'](_0x20f0d3,_0x2a3fa3,_0x273dfa=null){return new Wt(_0x20f0d3,_0x2a3fa3,'emailLink',_0x273dfa);}['toJSON'](){return{'email':this['_email'],'password':this['_password'],'signInMethod':this['signInMethod'],'tenantId':this['_tenantId']};}static['fromJSON'](_0x291e84){const _0xd7c6d8=typeof _0x291e84=='string'?JSON['parse'](_0x291e84):_0x291e84;if(_0xd7c6d8!=null&&_0xd7c6d8['email']&&(_0xd7c6d8!=null&&_0xd7c6d8['password'])){if(_0xd7c6d8['signInMethod']==='password')return this['_fromEmailAndPassword'](_0xd7c6d8['email'],_0xd7c6d8['password']);if(_0xd7c6d8['signInMethod']==='emailLink')return this['_fromEmailAndCode'](_0xd7c6d8['email'],_0xd7c6d8['password'],_0xd7c6d8['tenantId']);}return null;}async['_getIdTokenResponse'](_0x53c40c){switch(this['signInMethod']){case'password':const _0x41b89d={'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x53c40c,_0x41b89d,'signInWithPassword',Gf);case'emailLink':return qf(_0x53c40c,{'email':this['_email'],'oobCode':this['_password']});default:Q(_0x53c40c,'internal-error');}}async['_linkToIdToken'](_0x36b1ec,_0x204d1b){switch(this['signInMethod']){case'password':const _0x5c7a24={'idToken':_0x204d1b,'returnSecureToken':!0x0,'email':this['_email'],'password':this['_password'],'clientType':'CLIENT_TYPE_WEB'};return Di(_0x36b1ec,_0x5c7a24,'signUpPassword',$f);case'emailLink':return zf(_0x36b1ec,{'idToken':_0x204d1b,'email':this['_email'],'oobCode':this['_password']});default:Q(_0x36b1ec,'internal-error');}}['_getReauthenticationResolver'](_0x4a3157){return this['_getIdTokenResponse'](_0x4a3157);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xe(_0x4f69e2,_0x3d59e8){return Qt(_0x4f69e2,'POST','/v1/accounts:signInWithIdp',Re(_0x4f69e2,_0x3d59e8));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jf='http://localhost';class Be extends bs{constructor(){super(...arguments),this['pendingToken']=null;}static['_fromParams'](_0x1ed58f){const _0x59f8ae=new Be(_0x1ed58f['providerId'],_0x1ed58f['signInMethod']);return _0x1ed58f['idToken']||_0x1ed58f['accessToken']?(_0x1ed58f['idToken']&&(_0x59f8ae['idToken']=_0x1ed58f['idToken']),_0x1ed58f['accessToken']&&(_0x59f8ae['accessToken']=_0x1ed58f['accessToken']),_0x1ed58f['nonce']&&!_0x1ed58f['pendingToken']&&(_0x59f8ae['nonce']=_0x1ed58f['nonce']),_0x1ed58f['pendingToken']&&(_0x59f8ae['pendingToken']=_0x1ed58f['pendingToken'])):_0x1ed58f['oauthToken']&&_0x1ed58f['oauthTokenSecret']?(_0x59f8ae['accessToken']=_0x1ed58f['oauthToken'],_0x59f8ae['secret']=_0x1ed58f['oauthTokenSecret']):Q('argument-error'),_0x59f8ae;}['toJSON'](){return{'idToken':this['idToken'],'accessToken':this['accessToken'],'secret':this['secret'],'nonce':this['nonce'],'pendingToken':this['pendingToken'],'providerId':this['providerId'],'signInMethod':this['signInMethod']};}static['fromJSON'](_0x30298d){const _0x31db0f=typeof _0x30298d=='string'?JSON['parse'](_0x30298d):_0x30298d,{providerId:_0x1ea3af,signInMethod:_0x3e69a5,..._0x1f9734}=_0x31db0f;if(!_0x1ea3af||!_0x3e69a5)return null;const _0x350a8d=new Be(_0x1ea3af,_0x3e69a5);return _0x350a8d['idToken']=_0x1f9734['idToken']||void 0x0,_0x350a8d['accessToken']=_0x1f9734['accessToken']||void 0x0,_0x350a8d['secret']=_0x1f9734['secret'],_0x350a8d['nonce']=_0x1f9734['nonce'],_0x350a8d['pendingToken']=_0x1f9734['pendingToken']||null,_0x350a8d;}['_getIdTokenResponse'](_0x18524e){const _0x54ed52=this['buildRequest']();return Xe(_0x18524e,_0x54ed52);}['_linkToIdToken'](_0x109fd2,_0x3facec){const _0x5eee10=this['buildRequest']();return _0x5eee10['idToken']=_0x3facec,Xe(_0x109fd2,_0x5eee10);}['_getReauthenticationResolver'](_0x483092){const _0x46e5ef=this['buildRequest']();return _0x46e5ef['autoCreate']=!0x1,Xe(_0x483092,_0x46e5ef);}['buildRequest'](){const _0x1184c9={'requestUri':jf,'returnSecureToken':!0x0};if(this['pendingToken'])_0x1184c9['pendingToken']=this['pendingToken'];else{const _0x4fb6a8={};this['idToken']&&(_0x4fb6a8['id_token']=this['idToken']),this['accessToken']&&(_0x4fb6a8['access_token']=this['accessToken']),this['secret']&&(_0x4fb6a8['oauth_token_secret']=this['secret']),_0x4fb6a8['providerId']=this['providerId'],this['nonce']&&!this['pendingToken']&&(_0x4fb6a8['nonce']=this['nonce']),_0x1184c9['postBody']=ct(_0x4fb6a8);}return _0x1184c9;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Kf(_0x48157c){switch(_0x48157c){case'recoverEmail':return'RECOVER_EMAIL';case'resetPassword':return'PASSWORD_RESET';case'signIn':return'EMAIL_SIGNIN';case'verifyEmail':return'VERIFY_EMAIL';case'verifyAndChangeEmail':return'VERIFY_AND_CHANGE_EMAIL';case'revertSecondFactorAddition':return'REVERT_SECOND_FACTOR_ADDITION';default:return null;}}function Yf(_0xfda9f6){const _0x32605d=vt(Et(_0xfda9f6))['link'],_0x53a9f1=_0x32605d?vt(Et(_0x32605d))['deep_link_id']:null,_0x25fe2c=vt(Et(_0xfda9f6))['deep_link_id'];return(_0x25fe2c?vt(Et(_0x25fe2c))['link']:null)||_0x25fe2c||_0x53a9f1||_0x32605d||_0xfda9f6;}class Rs{constructor(_0x539298){const _0x4407bd=vt(Et(_0x539298)),_0x3256d8=_0x4407bd['apiKey']??null,_0x3e1444=_0x4407bd['oobCode']??null,_0x1ac44c=Kf(_0x4407bd['mode']??null);m(_0x3256d8&&_0x3e1444&&_0x1ac44c,'argument-error'),this['apiKey']=_0x3256d8,this['operation']=_0x1ac44c,this['code']=_0x3e1444,this['continueUrl']=_0x4407bd['continueUrl']??null,this['languageCode']=_0x4407bd['lang']??null,this['tenantId']=_0x4407bd['tenantId']??null;}static['parseLink'](_0x1a7c19){const _0x207733=Yf(_0x1a7c19);try{return new Rs(_0x207733);}catch{return null;}}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class pt{constructor(){this['providerId']=pt['PROVIDER_ID'];}static['credential'](_0x8c3eaf,_0x480ca6){return Wt['_fromEmailAndPassword'](_0x8c3eaf,_0x480ca6);}static['credentialWithLink'](_0x54f4bd,_0x3f3937){const _0x21c43b=Rs['parseLink'](_0x3f3937);return m(_0x21c43b,'argument-error'),Wt['_fromEmailAndCode'](_0x54f4bd,_0x21c43b['code'],_0x21c43b['tenantId']);}}pt['PROVIDER_ID']='password',pt['EMAIL_PASSWORD_SIGN_IN_METHOD']='password',pt['EMAIL_LINK_SIGN_IN_METHOD']='emailLink';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Wa{constructor(_0x4a5c55){this['providerId']=_0x4a5c55,this['defaultLanguageCode']=null,this['customParameters']={};}['setDefaultLanguage'](_0x1de2da){this['defaultLanguageCode']=_0x1de2da;}['setCustomParameters'](_0x5203f3){return this['customParameters']=_0x5203f3,this;}['getCustomParameters'](){return this['customParameters'];}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Jt extends Wa{constructor(){super(...arguments),this['scopes']=[];}['addScope'](_0x3a9638){return this['scopes']['includes'](_0x3a9638)||this['scopes']['push'](_0x3a9638),this;}['getScopes'](){return[...this['scopes']];}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class he extends Jt{constructor(){super('facebook.com');}static['credential'](_0x28d223){return Be['_fromParams']({'providerId':he['PROVIDER_ID'],'signInMethod':he['FACEBOOK_SIGN_IN_METHOD'],'accessToken':_0x28d223});}static['credentialFromResult'](_0x15ffec){return he['credentialFromTaggedObject'](_0x15ffec);}static['credentialFromError'](_0x513391){return he['credentialFromTaggedObject'](_0x513391['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x2847e9}){if(!_0x2847e9||!('oauthAccessToken'in _0x2847e9)||!_0x2847e9['oauthAccessToken'])return null;try{return he['credential'](_0x2847e9['oauthAccessToken']);}catch{return null;}}}he['FACEBOOK_SIGN_IN_METHOD']='facebook.com',he['PROVIDER_ID']='facebook.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ue extends Jt{constructor(){super('google.com'),this['addScope']('profile');}static['credential'](_0x34283b,_0x44545d){return Be['_fromParams']({'providerId':ue['PROVIDER_ID'],'signInMethod':ue['GOOGLE_SIGN_IN_METHOD'],'idToken':_0x34283b,'accessToken':_0x44545d});}static['credentialFromResult'](_0xb3268a){return ue['credentialFromTaggedObject'](_0xb3268a);}static['credentialFromError'](_0x55ce78){return ue['credentialFromTaggedObject'](_0x55ce78['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x2a7a30}){if(!_0x2a7a30)return null;const {oauthIdToken:_0x46d605,oauthAccessToken:_0xada095}=_0x2a7a30;if(!_0x46d605&&!_0xada095)return null;try{return ue['credential'](_0x46d605,_0xada095);}catch{return null;}}}ue['GOOGLE_SIGN_IN_METHOD']='google.com',ue['PROVIDER_ID']='google.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class de extends Jt{constructor(){super('github.com');}static['credential'](_0x3aefba){return Be['_fromParams']({'providerId':de['PROVIDER_ID'],'signInMethod':de['GITHUB_SIGN_IN_METHOD'],'accessToken':_0x3aefba});}static['credentialFromResult'](_0x1c6772){return de['credentialFromTaggedObject'](_0x1c6772);}static['credentialFromError'](_0x285f14){return de['credentialFromTaggedObject'](_0x285f14['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0xd9d71d}){if(!_0xd9d71d||!('oauthAccessToken'in _0xd9d71d)||!_0xd9d71d['oauthAccessToken'])return null;try{return de['credential'](_0xd9d71d['oauthAccessToken']);}catch{return null;}}}de['GITHUB_SIGN_IN_METHOD']='github.com',de['PROVIDER_ID']='github.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class fe extends Jt{constructor(){super('twitter.com');}static['credential'](_0x4fc96a,_0x33704a){return Be['_fromParams']({'providerId':fe['PROVIDER_ID'],'signInMethod':fe['TWITTER_SIGN_IN_METHOD'],'oauthToken':_0x4fc96a,'oauthTokenSecret':_0x33704a});}static['credentialFromResult'](_0x3a919f){return fe['credentialFromTaggedObject'](_0x3a919f);}static['credentialFromError'](_0x2a097b){return fe['credentialFromTaggedObject'](_0x2a097b['customData']||{});}static['credentialFromTaggedObject']({_tokenResponse:_0x4686d6}){if(!_0x4686d6)return null;const {oauthAccessToken:_0x17fb5b,oauthTokenSecret:_0x2dfd44}=_0x4686d6;if(!_0x17fb5b||!_0x2dfd44)return null;try{return fe['credential'](_0x17fb5b,_0x2dfd44);}catch{return null;}}}fe['TWITTER_SIGN_IN_METHOD']='twitter.com',fe['PROVIDER_ID']='twitter.com';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Qf(_0x52d707,_0x447611){return Qt(_0x52d707,'POST','/v1/accounts:signUp',Re(_0x52d707,_0x447611));}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ve{constructor(_0x44836e){this['user']=_0x44836e['user'],this['providerId']=_0x44836e['providerId'],this['_tokenResponse']=_0x44836e['_tokenResponse'],this['operationType']=_0x44836e['operationType'];}static async['_fromIdTokenResponse'](_0x4c2a60,_0x20a5f9,_0x3157bc,_0x2dc2b6=!0x1){const _0x51d4b4=await K['_fromIdTokenResponse'](_0x4c2a60,_0x3157bc,_0x2dc2b6),_0x12b162=Nr(_0x3157bc);return new Ve({'user':_0x51d4b4,'providerId':_0x12b162,'_tokenResponse':_0x3157bc,'operationType':_0x20a5f9});}static async['_forOperation'](_0xf8b1f9,_0x2a5d5c,_0x3bc80c){await _0xf8b1f9['_updateTokensIfNecessary'](_0x3bc80c,!0x0);const _0x14da97=Nr(_0x3bc80c);return new Ve({'user':_0xf8b1f9,'providerId':_0x14da97,'_tokenResponse':_0x3bc80c,'operationType':_0x2a5d5c});}}function Nr(_0x560737){return _0x560737['providerId']?_0x560737['providerId']:'phoneNumber'in _0x560737?'phone':null;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class An extends Se{constructor(_0x4688f4,_0x453446,_0x3ee5fd,_0x448609){super(_0x453446['code'],_0x453446['message']),this['operationType']=_0x3ee5fd,this['user']=_0x448609,Object['setPrototypeOf'](this,An['prototype']),this['customData']={'appName':_0x4688f4['name'],'tenantId':_0x4688f4['tenantId']??void 0x0,'_serverResponse':_0x453446['customData']['_serverResponse'],'operationType':_0x3ee5fd};}static['_fromErrorAndOperation'](_0x5a8e77,_0x426f4d,_0x3c7cfd,_0x5d44ba){return new An(_0x5a8e77,_0x426f4d,_0x3c7cfd,_0x5d44ba);}}function Ba(_0x36d255,_0x17a63d,_0xd8bd9d,_0x152f6f){return(_0x17a63d==='reauthenticate'?_0xd8bd9d['_getReauthenticationResolver'](_0x36d255):_0xd8bd9d['_getIdTokenResponse'](_0x36d255))['catch'](_0xac6739=>{throw _0xac6739['code']==='auth/multi-factor-auth-required'?An['_fromErrorAndOperation'](_0x36d255,_0xac6739,_0x17a63d,_0x152f6f):_0xac6739;});}async function Jf(_0x40b43d,_0x1d6867,_0x89b262=!0x1){const _0x350877=await Ut(_0x40b43d,_0x1d6867['_linkToIdToken'](_0x40b43d['auth'],await _0x40b43d['getIdToken']()),_0x89b262);return Ve['_forOperation'](_0x40b43d,'link',_0x350877);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Xf(_0x528a62,_0x1024a5,_0x38f61f=!0x1){const {auth:_0x26d809}=_0x528a62;if($(_0x26d809['app']))return Promise['reject'](re(_0x26d809));const _0x15806d='reauthenticate';try{const _0x284216=await Ut(_0x528a62,Ba(_0x26d809,_0x15806d,_0x1024a5,_0x528a62),_0x38f61f);m(_0x284216['idToken'],_0x26d809,'internal-error');const _0x28695b=Ts(_0x284216['idToken']);m(_0x28695b,_0x26d809,'internal-error');const {sub:_0x3d8a66}=_0x28695b;return m(_0x528a62['uid']===_0x3d8a66,_0x26d809,'user-mismatch'),Ve['_forOperation'](_0x528a62,_0x15806d,_0x284216);}catch(_0x32056b){throw(_0x32056b==null?void 0x0:_0x32056b['code'])==='auth/user-not-found'&&Q(_0x26d809,'user-mismatch'),_0x32056b;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Va(_0x2baf85,_0x56bcb9,_0x51b5a2=!0x1){if($(_0x2baf85['app']))return Promise['reject'](re(_0x2baf85));const _0x34bf25='signIn',_0x2d5053=await Ba(_0x2baf85,_0x34bf25,_0x56bcb9),_0x2e7ff9=await Ve['_fromIdTokenResponse'](_0x2baf85,_0x34bf25,_0x2d5053);return _0x51b5a2||await _0x2baf85['_updateCurrentUser'](_0x2e7ff9['user']),_0x2e7ff9;}async function Zf(_0x2a5493,_0x432202){return Va(qe(_0x2a5493),_0x432202);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Ha(_0xf2a576){const _0x28b8ea=qe(_0xf2a576);_0x28b8ea['_getPasswordPolicyInternal']()&&await _0x28b8ea['_updatePasswordPolicy']();}async function P_(_0x5ce44a,_0x29454a,_0x3d9855){if($(_0x5ce44a['app']))return Promise['reject'](re(_0x5ce44a));const _0x69e5be=qe(_0x5ce44a),_0x4b297d=await Di(_0x69e5be,{'returnSecureToken':!0x0,'email':_0x29454a,'password':_0x3d9855,'clientType':'CLIENT_TYPE_WEB'},'signUpPassword',Qf)['catch'](_0x28ef2e=>{throw _0x28ef2e['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x5ce44a),_0x28ef2e;}),_0x236c41=await Ve['_fromIdTokenResponse'](_0x69e5be,'signIn',_0x4b297d);return await _0x69e5be['_updateCurrentUser'](_0x236c41['user']),_0x236c41;}function O_(_0x310f3e,_0x3d15ca,_0x25b012){return $(_0x310f3e['app'])?Promise['reject'](re(_0x310f3e)):Zf(N(_0x310f3e),pt['credential'](_0x3d15ca,_0x25b012))['catch'](async _0x1995f5=>{throw _0x1995f5['code']==='auth/password-does-not-meet-requirements'&&Ha(_0x310f3e),_0x1995f5;});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function D_(_0x55cee2,_0x2c1460){return N(_0x55cee2)['setPersistence'](_0x2c1460);}function ep(_0xc0dfbf,_0x3074e6,_0x7841cc,_0x2cea35){return N(_0xc0dfbf)['onIdTokenChanged'](_0x3074e6,_0x7841cc,_0x2cea35);}function tp(_0x1e6be0,_0x5d38a4,_0x2c1e36){return N(_0x1e6be0)['beforeAuthStateChanged'](_0x5d38a4,_0x2c1e36);}function M_(_0x5a6515,_0x5459b0,_0x1da127,_0x1d8505){return N(_0x5a6515)['onAuthStateChanged'](_0x5459b0,_0x1da127,_0x1d8505);}function L_(_0x3320bc){return N(_0x3320bc)['signOut']();}const kn='__sak';/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class $a{constructor(_0x9b31ab,_0x51b434){this['storageRetriever']=_0x9b31ab,this['type']=_0x51b434;}['_isAvailable'](){try{return this['storage']?(this['storage']['setItem'](kn,'1'),this['storage']['removeItem'](kn),Promise['resolve'](!0x0)):Promise['resolve'](!0x1);}catch{return Promise['resolve'](!0x1);}}['_set'](_0x3da21a,_0x291c8a){return this['storage']['setItem'](_0x3da21a,JSON['stringify'](_0x291c8a)),Promise['resolve']();}['_get'](_0x19f536){const _0x50ad48=this['storage']['getItem'](_0x19f536);return Promise['resolve'](_0x50ad48?JSON['parse'](_0x50ad48):null);}['_remove'](_0x710176){return this['storage']['removeItem'](_0x710176),Promise['resolve']();}get['storage'](){return this['storageRetriever']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const np=0x3e8,ip=0xa;class Ga extends $a{constructor(){super(()=>window['localStorage'],'LOCAL'),this['boundEventHandler']=(_0x788e54,_0x3021a0)=>this['onStorageEvent'](_0x788e54,_0x3021a0),this['listeners']={},this['localCache']={},this['pollTimer']=null,this['fallbackToPolling']=Ma(),this['_shouldAllowMigration']=!0x0;}['forAllChangedKeys'](_0x4c38a2){for(const _0x40c47b of Object['keys'](this['listeners'])){const _0x4b0ebe=this['storage']['getItem'](_0x40c47b),_0xcd8ed0=this['localCache'][_0x40c47b];_0x4b0ebe!==_0xcd8ed0&&_0x4c38a2(_0x40c47b,_0xcd8ed0,_0x4b0ebe);}}['onStorageEvent'](_0x424376,_0x3845d4=!0x1){if(!_0x424376['key']){this['forAllChangedKeys']((_0x3349ea,_0x26a2ec,_0x408778)=>{this['notifyListeners'](_0x3349ea,_0x408778);});return;}const _0x18921f=_0x424376['key'];_0x3845d4?this['detachListener']():this['stopPolling']();const _0x579bc3=()=>{const _0x21cc27=this['storage']['getItem'](_0x18921f);!_0x3845d4&&this['localCache'][_0x18921f]===_0x21cc27||this['notifyListeners'](_0x18921f,_0x21cc27);},_0x3a5efe=this['storage']['getItem'](_0x18921f);Tf()&&_0x3a5efe!==_0x424376['newValue']&&_0x424376['newValue']!==_0x424376['oldValue']?setTimeout(_0x579bc3,ip):_0x579bc3();}['notifyListeners'](_0x2027a1,_0x19e657){this['localCache'][_0x2027a1]=_0x19e657;const _0x16968b=this['listeners'][_0x2027a1];if(_0x16968b){for(const _0x286198 of Array['from'](_0x16968b))_0x286198(_0x19e657&&JSON['parse'](_0x19e657));}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(()=>{this['forAllChangedKeys']((_0xb4d33a,_0x4694db,_0x4d4caa)=>{this['onStorageEvent'](new StorageEvent('storage',{'key':_0xb4d33a,'oldValue':_0x4694db,'newValue':_0x4d4caa}),!0x0);});},np);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['attachListener'](){window['addEventListener']('storage',this['boundEventHandler']);}['detachListener'](){window['removeEventListener']('storage',this['boundEventHandler']);}['_addListener'](_0x4d9735,_0x28ded0){Object['keys'](this['listeners'])['length']===0x0&&(this['fallbackToPolling']?this['startPolling']():this['attachListener']()),this['listeners'][_0x4d9735]||(this['listeners'][_0x4d9735]=new Set(),this['localCache'][_0x4d9735]=this['storage']['getItem'](_0x4d9735)),this['listeners'][_0x4d9735]['add'](_0x28ded0);}['_removeListener'](_0x4e5e6c,_0x4def9b){this['listeners'][_0x4e5e6c]&&(this['listeners'][_0x4e5e6c]['delete'](_0x4def9b),this['listeners'][_0x4e5e6c]['size']===0x0&&delete this['listeners'][_0x4e5e6c]),Object['keys'](this['listeners'])['length']===0x0&&(this['detachListener'](),this['stopPolling']());}async['_set'](_0x1381e3,_0x571d0c){await super['_set'](_0x1381e3,_0x571d0c),this['localCache'][_0x1381e3]=JSON['stringify'](_0x571d0c);}async['_get'](_0x104d2b){const _0x468a05=await super['_get'](_0x104d2b);return this['localCache'][_0x104d2b]=JSON['stringify'](_0x468a05),_0x468a05;}async['_remove'](_0x2550e3){await super['_remove'](_0x2550e3),delete this['localCache'][_0x2550e3];}}Ga['type']='LOCAL';const sp=Ga;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class qa extends $a{constructor(){super(()=>window['sessionStorage'],'SESSION');}['_addListener'](_0x49e980,_0x5c4810){}['_removeListener'](_0x14d024,_0x2bb9d5){}}qa['type']='SESSION';const za=qa;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function rp(_0x22fe47){return Promise['all'](_0x22fe47['map'](async _0x5491d3=>{try{return{'fulfilled':!0x0,'value':await _0x5491d3};}catch(_0x23552a){return{'fulfilled':!0x1,'reason':_0x23552a};}}));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Kn{constructor(_0x480fc1){this['eventTarget']=_0x480fc1,this['handlersMap']={},this['boundEventHandler']=this['handleEvent']['bind'](this);}static['_getInstance'](_0x22983c){const _0x2c9c4f=this['receivers']['find'](_0xc46777=>_0xc46777['isListeningto'](_0x22983c));if(_0x2c9c4f)return _0x2c9c4f;const _0x1aec24=new Kn(_0x22983c);return this['receivers']['push'](_0x1aec24),_0x1aec24;}['isListeningto'](_0x5124ad){return this['eventTarget']===_0x5124ad;}async['handleEvent'](_0x1ed10c){const _0x399e23=_0x1ed10c,{eventId:_0x43c5aa,eventType:_0x312d98,data:_0x4cc21b}=_0x399e23['data'],_0x58e0d4=this['handlersMap'][_0x312d98];if(!(_0x58e0d4!=null&&_0x58e0d4['size']))return;_0x399e23['ports'][0x0]['postMessage']({'status':'ack','eventId':_0x43c5aa,'eventType':_0x312d98});const _0x45eb32=Array['from'](_0x58e0d4)['map'](async _0x163c7f=>_0x163c7f(_0x399e23['origin'],_0x4cc21b)),_0x4ab2f3=await rp(_0x45eb32);_0x399e23['ports'][0x0]['postMessage']({'status':'done','eventId':_0x43c5aa,'eventType':_0x312d98,'response':_0x4ab2f3});}['_subscribe'](_0x3a2f3c,_0x11dc47){Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['addEventListener']('message',this['boundEventHandler']),this['handlersMap'][_0x3a2f3c]||(this['handlersMap'][_0x3a2f3c]=new Set()),this['handlersMap'][_0x3a2f3c]['add'](_0x11dc47);}['_unsubscribe'](_0x2b8d6e,_0x38387c){this['handlersMap'][_0x2b8d6e]&&_0x38387c&&this['handlersMap'][_0x2b8d6e]['delete'](_0x38387c),(!_0x38387c||this['handlersMap'][_0x2b8d6e]['size']===0x0)&&delete this['handlersMap'][_0x2b8d6e],Object['keys'](this['handlersMap'])['length']===0x0&&this['eventTarget']['removeEventListener']('message',this['boundEventHandler']);}}Kn['receivers']=[];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function As(_0x451d2a='',_0x21d266=0xa){let _0x51170c='';for(let _0x596bf2=0x0;_0x596bf2<_0x21d266;_0x596bf2++)_0x51170c+=Math['floor'](Math['random']()*0xa);return _0x451d2a+_0x51170c;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class op{constructor(_0x434bb3){this['target']=_0x434bb3,this['handlers']=new Set();}['removeMessageHandler'](_0x48d0f5){_0x48d0f5['messageChannel']&&(_0x48d0f5['messageChannel']['port1']['removeEventListener']('message',_0x48d0f5['onMessage']),_0x48d0f5['messageChannel']['port1']['close']()),this['handlers']['delete'](_0x48d0f5);}async['_send'](_0x16b8a8,_0x434801,_0x476616=0x32){const _0x4d3b14=typeof MessageChannel<'u'?new MessageChannel():null;if(!_0x4d3b14)throw new Error('connection_unavailable');let _0x1a51f2,_0x33046a;return new Promise((_0x1b5a35,_0x8640fb)=>{const _0x5665e4=As('',0x14);_0x4d3b14['port1']['start']();const _0x5b75a2=setTimeout(()=>{_0x8640fb(new Error('unsupported_event'));},_0x476616);_0x33046a={'messageChannel':_0x4d3b14,'onMessage'(_0x1fd7f5){const _0x518a09=_0x1fd7f5;if(_0x518a09['data']['eventId']===_0x5665e4)switch(_0x518a09['data']['status']){case'ack':clearTimeout(_0x5b75a2),_0x1a51f2=setTimeout(()=>{_0x8640fb(new Error('timeout'));},0xbb8);break;case'done':clearTimeout(_0x1a51f2),_0x1b5a35(_0x518a09['data']['response']);break;default:clearTimeout(_0x5b75a2),clearTimeout(_0x1a51f2),_0x8640fb(new Error('invalid_response'));break;}}},this['handlers']['add'](_0x33046a),_0x4d3b14['port1']['addEventListener']('message',_0x33046a['onMessage']),this['target']['postMessage']({'eventType':_0x16b8a8,'eventId':_0x5665e4,'data':_0x434801},[_0x4d3b14['port2']]);})['finally'](()=>{_0x33046a&&this['removeMessageHandler'](_0x33046a);});}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function Z(){return window;}function ap(_0x547ef6){Z()['location']['href']=_0x547ef6;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function ja(){return typeof Z()['WorkerGlobalScope']<'u'&&typeof Z()['importScripts']=='function';}async function cp(){if(!(navigator!=null&&navigator['serviceWorker']))return null;try{return(await navigator['serviceWorker']['ready'])['active'];}catch{return null;}}function lp(){var _0x375ca7;return((_0x375ca7=navigator==null?void 0x0:navigator['serviceWorker'])==null?void 0x0:_0x375ca7['controller'])||null;}function hp(){return ja()?self:null;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ka='firebaseLocalStorageDb',up=0x1,Nn='firebaseLocalStorage',Ya='fbase_key';class Xt{constructor(_0x3b6125){this['request']=_0x3b6125;}['toPromise'](){return new Promise((_0x4f6ef4,_0x3e011f)=>{this['request']['addEventListener']('success',()=>{_0x4f6ef4(this['request']['result']);}),this['request']['addEventListener']('error',()=>{_0x3e011f(this['request']['error']);});});}}function Yn(_0xe197f5,_0xa01082){return _0xe197f5['transaction']([Nn],_0xa01082?'readwrite':'readonly')['objectStore'](Nn);}function dp(){const _0x3269fb=indexedDB['deleteDatabase'](Ka);return new Xt(_0x3269fb)['toPromise']();}function Mi(){const _0x57c88b=indexedDB['open'](Ka,up);return new Promise((_0x3636ae,_0x1d3bbf)=>{_0x57c88b['addEventListener']('error',()=>{_0x1d3bbf(_0x57c88b['error']);}),_0x57c88b['addEventListener']('upgradeneeded',()=>{const _0x11bd73=_0x57c88b['result'];try{_0x11bd73['createObjectStore'](Nn,{'keyPath':Ya});}catch(_0x53372a){_0x1d3bbf(_0x53372a);}}),_0x57c88b['addEventListener']('success',async()=>{const _0x596f6f=_0x57c88b['result'];_0x596f6f['objectStoreNames']['contains'](Nn)?_0x3636ae(_0x596f6f):(_0x596f6f['close'](),await dp(),_0x3636ae(await Mi()));});});}async function Pr(_0x3e624b,_0x1e94c1,_0x419e2a){const _0x40f8fc=Yn(_0x3e624b,!0x0)['put']({[Ya]:_0x1e94c1,'value':_0x419e2a});return new Xt(_0x40f8fc)['toPromise']();}async function fp(_0x355584,_0x2549fc){const _0x3c0c1b=Yn(_0x355584,!0x1)['get'](_0x2549fc),_0x23a47f=await new Xt(_0x3c0c1b)['toPromise']();return _0x23a47f===void 0x0?null:_0x23a47f['value'];}function Or(_0x985483,_0x3722a9){const _0x3d0d61=Yn(_0x985483,!0x0)['delete'](_0x3722a9);return new Xt(_0x3d0d61)['toPromise']();}const pp=0x320,_p=0x3;class Qa{constructor(){this['type']='LOCAL',this['_shouldAllowMigration']=!0x0,this['listeners']={},this['localCache']={},this['pollTimer']=null,this['pendingWrites']=0x0,this['receiver']=null,this['sender']=null,this['serviceWorkerReceiverAvailable']=!0x1,this['activeServiceWorker']=null,this['_workerInitializationPromise']=this['initializeServiceWorkerMessaging']()['then'](()=>{},()=>{});}async['_openDb'](){return this['db']?this['db']:(this['db']=await Mi(),this['db']);}async['_withRetries'](_0x4bbd54){let _0x177026=0x0;for(;;)try{const _0x4d6e63=await this['_openDb']();return await _0x4bbd54(_0x4d6e63);}catch(_0x8574cb){if(_0x177026++>_p)throw _0x8574cb;this['db']&&(this['db']['close'](),this['db']=void 0x0);}}async['initializeServiceWorkerMessaging'](){return ja()?this['initializeReceiver']():this['initializeSender']();}async['initializeReceiver'](){this['receiver']=Kn['_getInstance'](hp()),this['receiver']['_subscribe']('keyChanged',async(_0x33bce3,_0x578f45)=>({'keyProcessed':(await this['_poll']())['includes'](_0x578f45['key'])})),this['receiver']['_subscribe']('ping',async(_0x2373f4,_0x50f468)=>['keyChanged']);}async['initializeSender'](){var _0x2f7a40,_0x1ac2d5;if(this['activeServiceWorker']=await cp(),!this['activeServiceWorker'])return;this['sender']=new op(this['activeServiceWorker']);const _0x4f9db1=await this['sender']['_send']('ping',{},0x320);_0x4f9db1&&(_0x2f7a40=_0x4f9db1[0x0])!=null&&_0x2f7a40['fulfilled']&&(_0x1ac2d5=_0x4f9db1[0x0])!=null&&_0x1ac2d5['value']['includes']('keyChanged')&&(this['serviceWorkerReceiverAvailable']=!0x0);}async['notifyServiceWorker'](_0xc945d6){if(!(!this['sender']||!this['activeServiceWorker']||lp()!==this['activeServiceWorker']))try{await this['sender']['_send']('keyChanged',{'key':_0xc945d6},this['serviceWorkerReceiverAvailable']?0x320:0x32);}catch{}}async['_isAvailable'](){try{if(!indexedDB)return!0x1;const _0x4ca3e7=await Mi();return await Pr(_0x4ca3e7,kn,'1'),await Or(_0x4ca3e7,kn),!0x0;}catch{}return!0x1;}async['_withPendingWrite'](_0x4b5cc7){this['pendingWrites']++;try{await _0x4b5cc7();}finally{this['pendingWrites']--;}}async['_set'](_0x3a2f22,_0x48ec49){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x49e663=>Pr(_0x49e663,_0x3a2f22,_0x48ec49)),this['localCache'][_0x3a2f22]=_0x48ec49,this['notifyServiceWorker'](_0x3a2f22)));}async['_get'](_0x50ab77){const _0x5a4979=await this['_withRetries'](_0x3062be=>fp(_0x3062be,_0x50ab77));return this['localCache'][_0x50ab77]=_0x5a4979,_0x5a4979;}async['_remove'](_0x179047){return this['_withPendingWrite'](async()=>(await this['_withRetries'](_0x5738f3=>Or(_0x5738f3,_0x179047)),delete this['localCache'][_0x179047],this['notifyServiceWorker'](_0x179047)));}async['_poll'](){const _0x4ce0a8=await this['_withRetries'](_0x48258e=>{const _0x3d7b24=Yn(_0x48258e,!0x1)['getAll']();return new Xt(_0x3d7b24)['toPromise']();});if(!_0x4ce0a8)return[];if(this['pendingWrites']!==0x0)return[];const _0xb5ef0c=[],_0x563c57=new Set();if(_0x4ce0a8['length']!==0x0){for(const {fbase_key:_0x5b94e6,value:_0x16919e}of _0x4ce0a8)_0x563c57['add'](_0x5b94e6),JSON['stringify'](this['localCache'][_0x5b94e6])!==JSON['stringify'](_0x16919e)&&(this['notifyListeners'](_0x5b94e6,_0x16919e),_0xb5ef0c['push'](_0x5b94e6));}for(const _0x430f9d of Object['keys'](this['localCache']))this['localCache'][_0x430f9d]&&!_0x563c57['has'](_0x430f9d)&&(this['notifyListeners'](_0x430f9d,null),_0xb5ef0c['push'](_0x430f9d));return _0xb5ef0c;}['notifyListeners'](_0x4911f8,_0x557ef5){this['localCache'][_0x4911f8]=_0x557ef5;const _0x799660=this['listeners'][_0x4911f8];if(_0x799660){for(const _0x48409a of Array['from'](_0x799660))_0x48409a(_0x557ef5);}}['startPolling'](){this['stopPolling'](),this['pollTimer']=setInterval(async()=>this['_poll'](),pp);}['stopPolling'](){this['pollTimer']&&(clearInterval(this['pollTimer']),this['pollTimer']=null);}['_addListener'](_0x53dd28,_0x190f3e){Object['keys'](this['listeners'])['length']===0x0&&this['startPolling'](),this['listeners'][_0x53dd28]||(this['listeners'][_0x53dd28]=new Set(),this['_get'](_0x53dd28)),this['listeners'][_0x53dd28]['add'](_0x190f3e);}['_removeListener'](_0xcdab5b,_0x3695a5){this['listeners'][_0xcdab5b]&&(this['listeners'][_0xcdab5b]['delete'](_0x3695a5),this['listeners'][_0xcdab5b]['size']===0x0&&delete this['listeners'][_0xcdab5b]),Object['keys'](this['listeners'])['length']===0x0&&this['stopPolling']();}}Qa['type']='LOCAL';const gp=Qa;new Yt(0x7530,0xea60);/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function mp(_0x5bfabd,_0x1550af){return _0x1550af?ie(_0x1550af):(m(_0x5bfabd['_popupRedirectResolver'],_0x5bfabd,'argument-error'),_0x5bfabd['_popupRedirectResolver']);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class ks extends bs{constructor(_0x2ae658){super('custom','custom'),this['params']=_0x2ae658;}['_getIdTokenResponse'](_0x426726){return Xe(_0x426726,this['_buildIdpRequest']());}['_linkToIdToken'](_0x40beb9,_0x3edabf){return Xe(_0x40beb9,this['_buildIdpRequest'](_0x3edabf));}['_getReauthenticationResolver'](_0x3f002d){return Xe(_0x3f002d,this['_buildIdpRequest']());}['_buildIdpRequest'](_0x4bbea2){const _0x5df553={'requestUri':this['params']['requestUri'],'sessionId':this['params']['sessionId'],'postBody':this['params']['postBody'],'tenantId':this['params']['tenantId'],'pendingToken':this['params']['pendingToken'],'returnSecureToken':!0x0,'returnIdpCredential':!0x0};return _0x4bbea2&&(_0x5df553['idToken']=_0x4bbea2),_0x5df553;}}function yp(_0x521950){return Va(_0x521950['auth'],new ks(_0x521950),_0x521950['bypassAuthState']);}function vp(_0x2368e5){const {auth:_0x607576,user:_0xd22785}=_0x2368e5;return m(_0xd22785,_0x607576,'internal-error'),Xf(_0xd22785,new ks(_0x2368e5),_0x2368e5['bypassAuthState']);}async function Ep(_0x3a5e8c){const {auth:_0x939cad,user:_0x20b578}=_0x3a5e8c;return m(_0x20b578,_0x939cad,'internal-error'),Jf(_0x20b578,new ks(_0x3a5e8c),_0x3a5e8c['bypassAuthState']);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Ja{constructor(_0x2e114d,_0x13c2a0,_0x258d79,_0x10d3a3,_0x31d331=!0x1){this['auth']=_0x2e114d,this['resolver']=_0x258d79,this['user']=_0x10d3a3,this['bypassAuthState']=_0x31d331,this['pendingPromise']=null,this['eventManager']=null,this['filter']=Array['isArray'](_0x13c2a0)?_0x13c2a0:[_0x13c2a0];}['execute'](){return new Promise(async(_0x29ff77,_0x58d8de)=>{this['pendingPromise']={'resolve':_0x29ff77,'reject':_0x58d8de};try{this['eventManager']=await this['resolver']['_initialize'](this['auth']),await this['onExecution'](),this['eventManager']['registerConsumer'](this);}catch(_0xc41d){this['reject'](_0xc41d);}});}async['onAuthEvent'](_0x58438f){const {urlResponse:_0x4fde48,sessionId:_0x2d72c4,postBody:_0x59d2ea,tenantId:_0xb7520b,error:_0x41c795,type:_0x4f806c}=_0x58438f;if(_0x41c795){this['reject'](_0x41c795);return;}const _0x2a901a={'auth':this['auth'],'requestUri':_0x4fde48,'sessionId':_0x2d72c4,'tenantId':_0xb7520b||void 0x0,'postBody':_0x59d2ea||void 0x0,'user':this['user'],'bypassAuthState':this['bypassAuthState']};try{this['resolve'](await this['getIdpTask'](_0x4f806c)(_0x2a901a));}catch(_0x1ff406){this['reject'](_0x1ff406);}}['onError'](_0x261b2c){this['reject'](_0x261b2c);}['getIdpTask'](_0x2fda4c){switch(_0x2fda4c){case'signInViaPopup':case'signInViaRedirect':return yp;case'linkViaPopup':case'linkViaRedirect':return Ep;case'reauthViaPopup':case'reauthViaRedirect':return vp;default:Q(this['auth'],'internal-error');}}['resolve'](_0x19cfae){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['resolve'](_0x19cfae),this['unregisterAndCleanUp']();}['reject'](_0x3963e5){ce(this['pendingPromise'],'Pending\x20promise\x20was\x20never\x20set'),this['pendingPromise']['reject'](_0x3963e5),this['unregisterAndCleanUp']();}['unregisterAndCleanUp'](){this['eventManager']&&this['eventManager']['unregisterConsumer'](this),this['pendingPromise']=null,this['cleanUp']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Ip=new Yt(0x7d0,0x2710);class Ke extends Ja{constructor(_0x357022,_0x1bf487,_0x278690,_0x26310e,_0x308cf){super(_0x357022,_0x1bf487,_0x26310e,_0x308cf),this['provider']=_0x278690,this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']&&Ke['currentPopupAction']['cancel'](),Ke['currentPopupAction']=this;}async['executeNotNull'](){const _0x33a5fd=await this['execute']();return m(_0x33a5fd,this['auth'],'internal-error'),_0x33a5fd;}async['onExecution'](){ce(this['filter']['length']===0x1,'Popup\x20operations\x20only\x20handle\x20one\x20event');const _0x5e1aa2=As();this['authWindow']=await this['resolver']['_openPopup'](this['auth'],this['provider'],this['filter'][0x0],_0x5e1aa2),this['authWindow']['associatedEvent']=_0x5e1aa2,this['resolver']['_originValidation'](this['auth'])['catch'](_0x4fe8af=>{this['reject'](_0x4fe8af);}),this['resolver']['_isIframeWebStorageSupported'](this['auth'],_0x57f836=>{_0x57f836||this['reject'](X(this['auth'],'web-storage-unsupported'));}),this['pollUserCancellation']();}get['eventId'](){var _0x5c8e1f;return((_0x5c8e1f=this['authWindow'])==null?void 0x0:_0x5c8e1f['associatedEvent'])||null;}['cancel'](){this['reject'](X(this['auth'],'cancelled-popup-request'));}['cleanUp'](){this['authWindow']&&this['authWindow']['close'](),this['pollId']&&window['clearTimeout'](this['pollId']),this['authWindow']=null,this['pollId']=null,Ke['currentPopupAction']=null;}['pollUserCancellation'](){const _0x4e6228=()=>{var _0x4f625b,_0x153176;if((_0x153176=(_0x4f625b=this['authWindow'])==null?void 0x0:_0x4f625b['window'])!=null&&_0x153176['closed']){this['pollId']=window['setTimeout'](()=>{this['pollId']=null,this['reject'](X(this['auth'],'popup-closed-by-user'));},0x1f40);return;}this['pollId']=window['setTimeout'](_0x4e6228,Ip['get']());};_0x4e6228();}}Ke['currentPopupAction']=null;/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const wp='pendingRedirect',on=new Map();class Cp extends Ja{constructor(_0x359b42,_0x4e2734,_0x530772=!0x1){super(_0x359b42,['signInViaRedirect','linkViaRedirect','reauthViaRedirect','unknown'],_0x4e2734,void 0x0,_0x530772),this['eventId']=null;}async['execute'](){let _0x51aad5=on['get'](this['auth']['_key']());if(!_0x51aad5){try{const _0x23323a=await Tp(this['resolver'],this['auth'])?await super['execute']():null;_0x51aad5=()=>Promise['resolve'](_0x23323a);}catch(_0x6127a8){_0x51aad5=()=>Promise['reject'](_0x6127a8);}on['set'](this['auth']['_key'](),_0x51aad5);}return this['bypassAuthState']||on['set'](this['auth']['_key'](),()=>Promise['resolve'](null)),_0x51aad5();}async['onAuthEvent'](_0x5aa10d){if(_0x5aa10d['type']==='signInViaRedirect')return super['onAuthEvent'](_0x5aa10d);if(_0x5aa10d['type']==='unknown'){this['resolve'](null);return;}if(_0x5aa10d['eventId']){const _0x19c747=await this['auth']['_redirectUserForId'](_0x5aa10d['eventId']);if(_0x19c747)return this['user']=_0x19c747,super['onAuthEvent'](_0x5aa10d);this['resolve'](null);}}async['onExecution'](){}['cleanUp'](){}}async function Tp(_0x1e32e1,_0x129fa7){const _0x308907=Rp(_0x129fa7),_0x1aefd1=bp(_0x1e32e1);if(!await _0x1aefd1['_isAvailable']())return!0x1;const _0x4a7dc=await _0x1aefd1['_get'](_0x308907)==='true';return await _0x1aefd1['_remove'](_0x308907),_0x4a7dc;}function Sp(_0x4a8880,_0x4d3d72){on['set'](_0x4a8880['_key'](),_0x4d3d72);}function bp(_0x42f15c){return ie(_0x42f15c['_redirectPersistence']);}function Rp(_0x745510){return rn(wp,_0x745510['config']['apiKey'],_0x745510['name']);}async function Ap(_0x1fb422,_0x4a2a0f,_0x21ca4d=!0x1){if($(_0x1fb422['app']))return Promise['reject'](re(_0x1fb422));const _0x3b4ee9=qe(_0x1fb422),_0x4a899c=mp(_0x3b4ee9,_0x4a2a0f),_0x455c60=await new Cp(_0x3b4ee9,_0x4a899c,_0x21ca4d)['execute']();return _0x455c60&&!_0x21ca4d&&(delete _0x455c60['user']['_redirectEventId'],await _0x3b4ee9['_persistUserIfCurrent'](_0x455c60['user']),await _0x3b4ee9['_setRedirectUser'](null,_0x4a2a0f)),_0x455c60;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const kp=0x258*0x3e8;class Np{constructor(_0x188cc2){this['auth']=_0x188cc2,this['cachedEventUids']=new Set(),this['consumers']=new Set(),this['queuedRedirectEvent']=null,this['hasHandledPotentialRedirect']=!0x1,this['lastProcessedEventTime']=Date['now']();}['registerConsumer'](_0x45d788){this['consumers']['add'](_0x45d788),this['queuedRedirectEvent']&&this['isEventForConsumer'](this['queuedRedirectEvent'],_0x45d788)&&(this['sendToConsumer'](this['queuedRedirectEvent'],_0x45d788),this['saveEventToCache'](this['queuedRedirectEvent']),this['queuedRedirectEvent']=null);}['unregisterConsumer'](_0xa8b842){this['consumers']['delete'](_0xa8b842);}['onEvent'](_0x3bafff){if(this['hasEventBeenHandled'](_0x3bafff))return!0x1;let _0x5e155b=!0x1;return this['consumers']['forEach'](_0x55f4da=>{this['isEventForConsumer'](_0x3bafff,_0x55f4da)&&(_0x5e155b=!0x0,this['sendToConsumer'](_0x3bafff,_0x55f4da),this['saveEventToCache'](_0x3bafff));}),this['hasHandledPotentialRedirect']||!Pp(_0x3bafff)||(this['hasHandledPotentialRedirect']=!0x0,_0x5e155b||(this['queuedRedirectEvent']=_0x3bafff,_0x5e155b=!0x0)),_0x5e155b;}['sendToConsumer'](_0x1a6924,_0x4b708d){var _0x1e323d;if(_0x1a6924['error']&&!Xa(_0x1a6924)){const _0x3bad4c=((_0x1e323d=_0x1a6924['error']['code'])==null?void 0x0:_0x1e323d['split']('auth/')[0x1])||'internal-error';_0x4b708d['onError'](X(this['auth'],_0x3bad4c));}else _0x4b708d['onAuthEvent'](_0x1a6924);}['isEventForConsumer'](_0x63426,_0x56b4ee){const _0x576f9a=_0x56b4ee['eventId']===null||!!_0x63426['eventId']&&_0x63426['eventId']===_0x56b4ee['eventId'];return _0x56b4ee['filter']['includes'](_0x63426['type'])&&_0x576f9a;}['hasEventBeenHandled'](_0x40d239){return Date['now']()-this['lastProcessedEventTime']>=kp&&this['cachedEventUids']['clear'](),this['cachedEventUids']['has'](Dr(_0x40d239));}['saveEventToCache'](_0xd5b653){this['cachedEventUids']['add'](Dr(_0xd5b653)),this['lastProcessedEventTime']=Date['now']();}}function Dr(_0xae2afd){return[_0xae2afd['type'],_0xae2afd['eventId'],_0xae2afd['sessionId'],_0xae2afd['tenantId']]['filter'](_0x146c74=>_0x146c74)['join']('-');}function Xa({type:_0x517cab,error:_0x36c324}){return _0x517cab==='unknown'&&(_0x36c324==null?void 0x0:_0x36c324['code'])==='auth/no-auth-event';}function Pp(_0x20aa93){switch(_0x20aa93['type']){case'signInViaRedirect':case'linkViaRedirect':case'reauthViaRedirect':return!0x0;case'unknown':return Xa(_0x20aa93);default:return!0x1;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function Op(_0x31ac67,_0x3a1192={}){return Ae(_0x31ac67,'GET','/v1/projects',_0x3a1192);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Dp=/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/,Mp=/^https?/;async function Lp(_0x36aa15){if(_0x36aa15['config']['emulator'])return;const {authorizedDomains:_0xa054f8}=await Op(_0x36aa15);for(const _0xf347c8 of _0xa054f8)try{if(xp(_0xf347c8))return;}catch{}Q(_0x36aa15,'unauthorized-domain');}function xp(_0x3da333){const _0x40da2c=Pi(),{protocol:_0x48a9ae,hostname:_0x105814}=new URL(_0x40da2c);if(_0x3da333['startsWith']('chrome-extension://')){const _0x37afdc=new URL(_0x3da333);return _0x37afdc['hostname']===''&&_0x105814===''?_0x48a9ae==='chrome-extension:'&&_0x3da333['replace']('chrome-extension://','')===_0x40da2c['replace']('chrome-extension://',''):_0x48a9ae==='chrome-extension:'&&_0x37afdc['hostname']===_0x105814;}if(!Mp['test'](_0x48a9ae))return!0x1;if(Dp['test'](_0x3da333))return _0x105814===_0x3da333;const _0x4a7151=_0x3da333['replace'](/\./g,'\x5c.');return new RegExp('^(.+\x5c.'+_0x4a7151+'|'+_0x4a7151+')$','i')['test'](_0x105814);}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Fp=new Yt(0x7530,0xea60);function Mr(){const _0x27bbe5=Z()['___jsl'];if(_0x27bbe5!=null&&_0x27bbe5['H']){for(const _0x1e1a62 of Object['keys'](_0x27bbe5['H']))if(_0x27bbe5['H'][_0x1e1a62]['r']=_0x27bbe5['H'][_0x1e1a62]['r']||[],_0x27bbe5['H'][_0x1e1a62]['L']=_0x27bbe5['H'][_0x1e1a62]['L']||[],_0x27bbe5['H'][_0x1e1a62]['r']=[..._0x27bbe5['H'][_0x1e1a62]['L']],_0x27bbe5['CP']){for(let _0xc527f9=0x0;_0xc527f9<_0x27bbe5['CP']['length'];_0xc527f9++)_0x27bbe5['CP'][_0xc527f9]=null;}}}function Up(_0x2e68d9){return new Promise((_0x1419a4,_0x590aa3)=>{var _0x3cdabd,_0x4c1898,_0x5b800a;function _0x2f47b0(){Mr(),gapi['load']('gapi.iframes',{'callback':()=>{_0x1419a4(gapi['iframes']['getContext']());},'ontimeout':()=>{Mr(),_0x590aa3(X(_0x2e68d9,'network-request-failed'));},'timeout':Fp['get']()});}if((_0x4c1898=(_0x3cdabd=Z()['gapi'])==null?void 0x0:_0x3cdabd['iframes'])!=null&&_0x4c1898['Iframe'])_0x1419a4(gapi['iframes']['getContext']());else{if((_0x5b800a=Z()['gapi'])!=null&&_0x5b800a['load'])_0x2f47b0();else{const _0x47d514=Df('iframefcb');return Z()[_0x47d514]=()=>{gapi['load']?_0x2f47b0():_0x590aa3(X(_0x2e68d9,'network-request-failed'));},xa(Of()+'?onload='+_0x47d514)['catch'](_0x228574=>_0x590aa3(_0x228574));}}})['catch'](_0x4774d3=>{throw an=null,_0x4774d3;});}let an=null;function Wp(_0x5d0a5f){return an=an||Up(_0x5d0a5f),an;}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const Bp=new Yt(0x1388,0x3a98),Vp='__/auth/iframe',Hp='emulator/auth/iframe',$p={'style':{'position':'absolute','top':'-100px','width':'1px','height':'1px'},'aria-hidden':'true','tabindex':'-1'},Gp=new Map([['identitytoolkit.googleapis.com','p'],['staging-identitytoolkit.sandbox.googleapis.com','s'],['test-identitytoolkit.sandbox.googleapis.com','t']]);function qp(_0x52093f){const _0x58707d=_0x52093f['config'];m(_0x58707d['authDomain'],_0x52093f,'auth-domain-config-required');const _0x9906af=_0x58707d['emulator']?Cs(_0x58707d,Hp):'https://'+_0x52093f['config']['authDomain']+'/'+Vp,_0x14b74e={'apiKey':_0x58707d['apiKey'],'appName':_0x52093f['name'],'v':lt},_0x321f25=Gp['get'](_0x52093f['config']['apiHost']);_0x321f25&&(_0x14b74e['eid']=_0x321f25);const _0xbc2d7c=_0x52093f['_getFrameworks']();return _0xbc2d7c['length']&&(_0x14b74e['fw']=_0xbc2d7c['join'](',')),_0x9906af+'?'+ct(_0x14b74e)['slice'](0x1);}async function zp(_0x43bc87){const _0x17fbbc=await Wp(_0x43bc87),_0x595a42=Z()['gapi'];return m(_0x595a42,_0x43bc87,'internal-error'),_0x17fbbc['open']({'where':document['body'],'url':qp(_0x43bc87),'messageHandlersFilter':_0x595a42['iframes']['CROSS_ORIGIN_IFRAMES_FILTER'],'attributes':$p,'dontclear':!0x0},_0x6b9e37=>new Promise(async(_0x192500,_0x49408c)=>{await _0x6b9e37['restyle']({'setHideOnLeave':!0x1});const _0x21d2c8=X(_0x43bc87,'network-request-failed'),_0x1fa440=Z()['setTimeout'](()=>{_0x49408c(_0x21d2c8);},Bp['get']());function _0x74ffc6(){Z()['clearTimeout'](_0x1fa440),_0x192500(_0x6b9e37);}_0x6b9e37['ping'](_0x74ffc6)['then'](_0x74ffc6,()=>{_0x49408c(_0x21d2c8);});}));}/**
 * @license
 * Copyright 2020 Google LLC.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const jp={'location':'yes','resizable':'yes','statusbar':'yes','toolbar':'no'},Kp=0x1f4,Yp=0x258,Qp='_blank',Jp='http://localhost';class Lr{constructor(_0x2936b5){this['window']=_0x2936b5,this['associatedEvent']=null;}['close'](){if(this['window'])try{this['window']['close']();}catch{}}}function Xp(_0x36337b,_0x2f0499,_0x278f71,_0x23acbb=Kp,_0x555ecb=Yp){const _0x7193f=Math['max']((window['screen']['availHeight']-_0x555ecb)/0x2,0x0)['toString'](),_0x54bd3b=Math['max']((window['screen']['availWidth']-_0x23acbb)/0x2,0x0)['toString']();let _0x48caaf='';const _0xa64fc4={...jp,'width':_0x23acbb['toString'](),'height':_0x555ecb['toString'](),'top':_0x7193f,'left':_0x54bd3b},_0x40e95f=W()['toLowerCase']();_0x278f71&&(_0x48caaf=ka(_0x40e95f)?Qp:_0x278f71),Ra(_0x40e95f)&&(_0x2f0499=_0x2f0499||Jp,_0xa64fc4['scrollbars']='yes');const _0x3d2c39=Object['entries'](_0xa64fc4)['reduce']((_0x1215e5,[_0x56a82f,_0x2033d0])=>''+_0x1215e5+_0x56a82f+'='+_0x2033d0+',','');if(Cf(_0x40e95f)&&_0x48caaf!=='_self')return Zp(_0x2f0499||'',_0x48caaf),new Lr(null);const _0x2decef=window['open'](_0x2f0499||'',_0x48caaf,_0x3d2c39);m(_0x2decef,_0x36337b,'popup-blocked');try{_0x2decef['focus']();}catch{}return new Lr(_0x2decef);}function Zp(_0x2cb5f9,_0x13b216){const _0x1e328d=document['createElement']('a');_0x1e328d['href']=_0x2cb5f9,_0x1e328d['target']=_0x13b216;const _0x5df03a=document['createEvent']('MouseEvent');_0x5df03a['initMouseEvent']('click',!0x0,!0x0,window,0x1,0x0,0x0,0x0,0x0,!0x1,!0x1,!0x1,!0x1,0x1,null),_0x1e328d['dispatchEvent'](_0x5df03a);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const e_='__/auth/handler',t_='emulator/auth/handler',n_=encodeURIComponent('fac');async function xr(_0x2ce4e1,_0x527de9,_0xff7260,_0x17e5f2,_0x2fe9ab,_0x5022f5){m(_0x2ce4e1['config']['authDomain'],_0x2ce4e1,'auth-domain-config-required'),m(_0x2ce4e1['config']['apiKey'],_0x2ce4e1,'invalid-api-key');const _0x5e66cf={'apiKey':_0x2ce4e1['config']['apiKey'],'appName':_0x2ce4e1['name'],'authType':_0xff7260,'redirectUrl':_0x17e5f2,'v':lt,'eventId':_0x2fe9ab};if(_0x527de9 instanceof Wa){_0x527de9['setDefaultLanguage'](_0x2ce4e1['languageCode']),_0x5e66cf['providerId']=_0x527de9['providerId']||'',ui(_0x527de9['getCustomParameters']())||(_0x5e66cf['customParameters']=JSON['stringify'](_0x527de9['getCustomParameters']()));for(const [_0x19362d,_0x15b5e8]of Object['entries']({}))_0x5e66cf[_0x19362d]=_0x15b5e8;}if(_0x527de9 instanceof Jt){const _0x4e53c6=_0x527de9['getScopes']()['filter'](_0x5a967d=>_0x5a967d!=='');_0x4e53c6['length']>0x0&&(_0x5e66cf['scopes']=_0x4e53c6['join'](','));}_0x2ce4e1['tenantId']&&(_0x5e66cf['tid']=_0x2ce4e1['tenantId']);const _0x2ad08e=_0x5e66cf;for(const _0x23c58f of Object['keys'](_0x2ad08e))_0x2ad08e[_0x23c58f]===void 0x0&&delete _0x2ad08e[_0x23c58f];const _0x522a20=await _0x2ce4e1['_getAppCheckToken'](),_0x50350a=_0x522a20?'#'+n_+'='+encodeURIComponent(_0x522a20):'';return i_(_0x2ce4e1)+'?'+ct(_0x2ad08e)['slice'](0x1)+_0x50350a;}function i_({config:_0x2a2c17}){return _0x2a2c17['emulator']?Cs(_0x2a2c17,t_):'https://'+_0x2a2c17['authDomain']+'/'+e_;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const hi='webStorageSupport';class s_{constructor(){this['eventManagers']={},this['iframes']={},this['originValidationPromises']={},this['_redirectPersistence']=za,this['_completeRedirectFn']=Ap,this['_overrideRedirectResult']=Sp;}async['_openPopup'](_0x5c08a8,_0x2f7ffd,_0x119569,_0x234d93){var _0x551a0d;ce((_0x551a0d=this['eventManagers'][_0x5c08a8['_key']()])==null?void 0x0:_0x551a0d['manager'],'_initialize()\x20not\x20called\x20before\x20_openPopup()');const _0xded4fb=await xr(_0x5c08a8,_0x2f7ffd,_0x119569,Pi(),_0x234d93);return Xp(_0x5c08a8,_0xded4fb,As());}async['_openRedirect'](_0x4367b9,_0x239ca4,_0x36b50a,_0x552b25){await this['_originValidation'](_0x4367b9);const _0x6552e5=await xr(_0x4367b9,_0x239ca4,_0x36b50a,Pi(),_0x552b25);return ap(_0x6552e5),new Promise(()=>{});}['_initialize'](_0x3cce72){const _0x24a0d9=_0x3cce72['_key']();if(this['eventManagers'][_0x24a0d9]){const {manager:_0x506d83,promise:_0x3ba036}=this['eventManagers'][_0x24a0d9];return _0x506d83?Promise['resolve'](_0x506d83):(ce(_0x3ba036,'If\x20manager\x20is\x20not\x20set,\x20promise\x20should\x20be'),_0x3ba036);}const _0x4ea829=this['initAndGetManager'](_0x3cce72);return this['eventManagers'][_0x24a0d9]={'promise':_0x4ea829},_0x4ea829['catch'](()=>{delete this['eventManagers'][_0x24a0d9];}),_0x4ea829;}async['initAndGetManager'](_0x278b07){const _0xdb3b71=await zp(_0x278b07),_0x3b44a8=new Np(_0x278b07);return _0xdb3b71['register']('authEvent',_0x11e195=>(m(_0x11e195==null?void 0x0:_0x11e195['authEvent'],_0x278b07,'invalid-auth-event'),{'status':_0x3b44a8['onEvent'](_0x11e195['authEvent'])?'ACK':'ERROR'}),gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']),this['eventManagers'][_0x278b07['_key']()]={'manager':_0x3b44a8},this['iframes'][_0x278b07['_key']()]=_0xdb3b71,_0x3b44a8;}['_isIframeWebStorageSupported'](_0x481d04,_0x58b5c0){this['iframes'][_0x481d04['_key']()]['send'](hi,{'type':hi},_0x213103=>{var _0xbbda13;const _0x23e225=(_0xbbda13=_0x213103==null?void 0x0:_0x213103[0x0])==null?void 0x0:_0xbbda13[hi];_0x23e225!==void 0x0&&_0x58b5c0(!!_0x23e225),Q(_0x481d04,'internal-error');},gapi['iframes']['CROSS_ORIGIN_IFRAMES_FILTER']);}['_originValidation'](_0x424b3c){const _0x1c8dff=_0x424b3c['_key']();return this['originValidationPromises'][_0x1c8dff]||(this['originValidationPromises'][_0x1c8dff]=Lp(_0x424b3c)),this['originValidationPromises'][_0x1c8dff];}get['_shouldInitProactively'](){return Ma()||Aa()||Ss();}}const r_=s_;var Fr='@firebase/auth',Ur='1.11.1';/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class o_{constructor(_0x4cf8ae){this['auth']=_0x4cf8ae,this['internalListeners']=new Map();}['getUid'](){var _0x9e27be;return this['assertAuthConfigured'](),((_0x9e27be=this['auth']['currentUser'])==null?void 0x0:_0x9e27be['uid'])||null;}async['getToken'](_0xfc5fb4){return this['assertAuthConfigured'](),await this['auth']['_initializationPromise'],this['auth']['currentUser']?{'accessToken':await this['auth']['currentUser']['getIdToken'](_0xfc5fb4)}:null;}['addAuthTokenListener'](_0x2c8326){if(this['assertAuthConfigured'](),this['internalListeners']['has'](_0x2c8326))return;const _0x1a6bca=this['auth']['onIdTokenChanged'](_0x4307b8=>{_0x2c8326((_0x4307b8==null?void 0x0:_0x4307b8['stsTokenManager']['accessToken'])||null);});this['internalListeners']['set'](_0x2c8326,_0x1a6bca),this['updateProactiveRefresh']();}['removeAuthTokenListener'](_0x5cd729){this['assertAuthConfigured']();const _0x3d7643=this['internalListeners']['get'](_0x5cd729);_0x3d7643&&(this['internalListeners']['delete'](_0x5cd729),_0x3d7643(),this['updateProactiveRefresh']());}['assertAuthConfigured'](){m(this['auth']['_initializationPromise'],'dependent-sdk-initialized-before-auth');}['updateProactiveRefresh'](){this['internalListeners']['size']>0x0?this['auth']['_startProactiveRefresh']():this['auth']['_stopProactiveRefresh']();}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function a_(_0x52c5bc){switch(_0x52c5bc){case'Node':return'node';case'ReactNative':return'rn';case'Worker':return'webworker';case'Cordova':return'cordova';case'WebExtension':return'web-extension';default:return;}}function c_(_0x5398bb){Ze(new Le('auth',(_0xfa7b0e,{options:_0x2df531})=>{const _0x4dd3f1=_0xfa7b0e['getProvider']('app')['getImmediate'](),_0x34b7cd=_0xfa7b0e['getProvider']('heartbeat'),_0x1a57c2=_0xfa7b0e['getProvider']('app-check-internal'),{apiKey:_0x4988be,authDomain:_0x831362}=_0x4dd3f1['options'];m(_0x4988be&&!_0x4988be['includes'](':'),'invalid-api-key',{'appName':_0x4dd3f1['name']});const _0x15081b={'apiKey':_0x4988be,'authDomain':_0x831362,'clientPlatform':_0x5398bb,'apiHost':'identitytoolkit.googleapis.com','tokenApiHost':'securetoken.googleapis.com','apiScheme':'https','sdkClientVersion':La(_0x5398bb)},_0x4a129c=new kf(_0x4dd3f1,_0x34b7cd,_0x1a57c2,_0x15081b);return Wf(_0x4a129c,_0x2df531),_0x4a129c;},'PUBLIC')['setInstantiationMode']('EXPLICIT')['setInstanceCreatedCallback']((_0xc6cb4a,_0x3cb529,_0x40b1dd)=>{_0xc6cb4a['getProvider']('auth-internal')['initialize']();})),Ze(new Le('auth-internal',_0x42fe5d=>{const _0x1acb24=qe(_0x42fe5d['getProvider']('auth')['getImmediate']());return(_0xd8101d=>new o_(_0xd8101d))(_0x1acb24);},'PRIVATE')['setInstantiationMode']('EXPLICIT')),me(Fr,Ur,a_(_0x5398bb)),me(Fr,Ur,'esm2020');}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const l_=0x12c,h_=zr('authIdTokenMaxAge')||l_;let Wr=null;const u_=_0x2fc022=>async _0x31004d=>{const _0x460dcd=_0x31004d&&await _0x31004d['getIdTokenResult'](),_0x9d14da=_0x460dcd&&(new Date()['getTime']()-Date['parse'](_0x460dcd['issuedAtTime']))/0x3e8;if(_0x9d14da&&_0x9d14da>h_)return;const _0x21099c=_0x460dcd==null?void 0x0:_0x460dcd['token'];Wr!==_0x21099c&&(Wr=_0x21099c,await fetch(_0x2fc022,{'method':_0x21099c?'POST':'DELETE','headers':_0x21099c?{'Authorization':'Bearer\x20'+_0x21099c}:{}}));};function x_(_0x350afd=Zr()){const _0x57dbac=Bi(_0x350afd,'auth');if(_0x57dbac['isInitialized']())return _0x57dbac['getImmediate']();const _0xaef80f=Uf(_0x350afd,{'popupRedirectResolver':r_,'persistence':[gp,sp,za]}),_0x920dde=zr('authTokenSyncURL');if(_0x920dde&&typeof isSecureContext=='boolean'&&isSecureContext){const _0x310f94=new URL(_0x920dde,location['origin']);if(location['origin']===_0x310f94['origin']){const _0x614bf8=u_(_0x310f94['toString']());tp(_0xaef80f,_0x614bf8,()=>_0x614bf8(_0xaef80f['currentUser'])),ep(_0xaef80f,_0x2c3371=>_0x614bf8(_0x2c3371));}}const _0x51e550=Gr('auth');return _0x51e550&&Bf(_0xaef80f,'http://'+_0x51e550),_0xaef80f;}function d_(){var _0x47a1b6;return((_0x47a1b6=document['getElementsByTagName']('head'))==null?void 0x0:_0x47a1b6[0x0])??document;}Nf({'loadJS'(_0xda4249){return new Promise((_0x566026,_0x2a8554)=>{const _0x37256e=document['createElement']('script');_0x37256e['setAttribute']('src',_0xda4249),_0x37256e['onload']=_0x566026,_0x37256e['onerror']=_0x1693f2=>{const _0x51ccfb=X('internal-error');_0x51ccfb['customData']=_0x1693f2,_0x2a8554(_0x51ccfb);},_0x37256e['type']='text/javascript',_0x37256e['charset']='UTF-8',d_()['appendChild'](_0x37256e);});},'gapiScript':'https://apis.google.com/js/api.js','recaptchaV2Script':'https://www.google.com/recaptcha/api.js','recaptchaEnterpriseScript':'https://www.google.com/recaptcha/enterprise.js?render='}),c_('Browser');export{P_ as A,L_ as B,C_ as C,x_ as a,sp as b,O_ as c,f_ as d,p_ as e,Zr as f,b_ as g,y_ as h,Sl as i,k_ as j,T_ as k,Ft as l,Ud as m,M_ as n,w_ as o,g_ as p,S_ as q,__ as r,D_ as s,A_ as t,m_ as u,R_ as v,N_ as w,E_ as x,v_ as y,I_ as z};